/**
 *  Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vhal_uart.c
 * @brief       乐鑫平台串口收发接口封装
 * @author      Dongri.Su
 * @date        2021-04-28
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/queue.h"
#include "driver/uart.h"
#include "vesync_log.h"
#include "vesync_common.h"
#include "vhal_uart_internal.h"
#include "vesync_task.h"


static TaskHandle_t s_uart_taskhd = NULL;      // UART数据接收任务句柄

static vhal_esp_uart_status_t s_uart_status[VHAL_UART_NUM_MAX] = {0};

#ifdef CONFIG_IDF_TARGET_ESP8266
static uint8_t s_uart_id[VHAL_UART_NUM_MAX] = {0};
#elif defined(CONFIG_IDF_TARGET_ESP32)
static uint8_t s_uart_id[VHAL_UART_NUM_MAX] = {1, 2};
#elif defined(CONFIG_IDF_TARGET_ESP32C3) || defined(CONFIG_IDF_TARGET_ESP32S2)
static uint8_t s_uart_id[VHAL_UART_NUM_MAX] = {1};
#endif

/**
 * @brief 串口事件任务
 * @param[in]  pvParameters             [未使用]
 */
static void vhal_esp_uart_evt_task(void *pvParameters)
{
    uint8_t idx = 0;
    int ret = 0;
    size_t length = 0;
    uint8_t *p_buf = (uint8_t *) malloc(UART_RECV_BUF_SIZE);

    while (1)
    {
        for (idx = 0; idx < VHAL_UART_NUM_MAX; idx++)
        {
            if (s_uart_status[idx].cfg_flag)
            {

                uart_get_buffered_data_len(s_uart_status[idx].uart_num, (size_t*)&length);

                if (length > 0)
                {
                    //HAL_LOG(LOG_DEBUG, "get uart %d len=%d\n",s_uart_status[idx].uart_num,length);
                    memset(p_buf, 0, UART_RECV_BUF_SIZE);
                    ret = uart_read_bytes(s_uart_status[idx].uart_num, p_buf, length, 100);     // 读取100ms，根据实际情况进行调整
                    //HAL_LOG(LOG_DEBUG, "s_uart_status[%d].uart_num = %d\n", idx, s_uart_status[idx].uart_num);
                    //LOG_RAW_HEX(LOG_INFO, "recv : ", p_buf, ret);
                    if (ret > 0)
                    {
                        // 接收到数据，回调给应用层
                        if (NULL != s_uart_status[idx].recv_cb)
                        {
                            s_uart_status[idx].recv_cb(idx, p_buf, length);
                        }
                    }
                }
            }

        }

        vTaskDelay(pdMS_TO_TICKS(20));      // Delay 20ms，不能去掉，否则上电串口还没初始化完，该任务可能会进入死循环
    }

    free(p_buf);
    p_buf = NULL;
    vTaskDelete(NULL);
}


/**
 * @brief  启动串口接收任务
 * @return     void
 */
void vhal_uart_start(void)
{
    // Create a task to handler UART event from ISR
    if (NULL != s_uart_taskhd)
    {
        return;
    }

    if (pdPASS != xTaskCreate(vhal_esp_uart_evt_task, UART_TASK_NAME, UART_TASK_STACK_SIZE, NULL, UART_TASK_PRIO, &s_uart_taskhd))
    {
        HAL_LOG(LOG_ERROR, "Create UART event task fail!!!\n");
    }
    else
    {
        HAL_LOG(LOG_DEBUG, "Create UART event task success\n");
    }
}

/**
 * @brief  串口参数配置
 * @param[in]  idx                  [串口编号]
 * @param[in]  rx_pin               [串口rx引脚]
 * @param[in]  rx_pin               [串口tx引脚]
 * @param[in]  baudrate             [串口波特率]
 * @return     void
 */
void vhal_uart_config(uint8_t idx, uint32_t rx_pin, uint32_t tx_pin, uint32_t baudrate)
{
    QueueHandle_t *uart_queue = NULL;           // typedef void * QueueHandle_t
    uart_config_t uart_config = {
        .baud_rate = baudrate,
        .data_bits = UART_DATA_8_BITS,
        .parity = UART_PARITY_DISABLE,
        .stop_bits = UART_STOP_BITS_1,
        .flow_ctrl = UART_HW_FLOWCTRL_DISABLE
    };

    if (idx >= VHAL_UART_NUM_MAX)
    {
        HAL_LOG(LOG_ERROR, "UART number(%d) is error!!\n", idx);
        return;
    }

    s_uart_status[idx].uart_num = s_uart_id[idx];
    uart_queue = &s_uart_status[idx].uart_queue;
    s_uart_status[idx].cfg_flag = true;


    // 配置uart协议
    uart_param_config(s_uart_status[idx].uart_num, &uart_config);

    // Install UART driver, and get the queue.
#if defined(CONFIG_IDF_TARGET_ESP8266)
    // 设置引脚,ESP8266不支持设置业务串口
    uart_driver_install(s_uart_status[idx].uart_num, UART_BUF_SIZE, UART_BUF_SIZE, 10, uart_queue, 0);
#else
    uart_set_pin(s_uart_status[idx].uart_num, tx_pin, rx_pin, UART_PIN_NO_CHANGE, UART_PIN_NO_CHANGE);
    uart_driver_install(s_uart_status[idx].uart_num, UART_BUF_SIZE, UART_BUF_SIZE, 20, uart_queue, 0);
#endif /* CONFIG_IDF_TARGET_ESP8266 */

}

/**
 * @brief 注册串口接收数据回调
 * @param[in]  idx                  [串口编号]
 * @param[in]  cb                   [串口数据接收回调函数]
 * @return     void
 */
void vhal_uart_reg_recv_cb(uint8_t idx, vhal_uart_recv_cb_t cb)
{
    if (idx >= VHAL_UART_NUM_MAX)
    {
        HAL_LOG(LOG_ERROR, "UART number(%d) is error!!\n", idx);
        return;
    }

    s_uart_status[idx].recv_cb = cb;
}

/**
 * @brief  串口发送数据
 * @param[in]  idx                  [串口编号]
 * @param[in]  p_buf                [待发送数据]
 * @param[in]  buf_len              [待发送数据长度]
 * @return     int                  [执行结果，0表示成功，其他值表示失败]
 */
int vhal_uart_send(uint8_t idx, uint8_t *p_buf, uint16_t buf_len)
{
    int send_bytes = -1;

    if (NULL == p_buf)
    {
        return VHAL_FAIL;
    }
    if (idx >= VHAL_UART_NUM_MAX)
    {
        return VHAL_FAIL;
    }

    if (buf_len != 0)
    {
        /* @return
         * - (-1) Parameter error
         * - OTHERS (>=0) The number of bytes pushed to the TX FIFO
         */
        //LOG_RAW_HEX(LOG_INFO, "send : ", p_buf, buf_len);
        send_bytes = uart_write_bytes(s_uart_status[idx].uart_num, (const char *)p_buf, buf_len);
    }

    if (send_bytes < 0)
    {
        return VHAL_FAIL;
    }

    return VHAL_OK;
}

