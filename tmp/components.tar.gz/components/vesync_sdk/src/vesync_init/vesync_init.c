/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_init.c
 * @brief       SDK初始化接口
 * @author      Joshua
 * @date        2021-04-22
 */

#include <stdio.h>

#if CONFIG_VESYNC_HAL_SYS_ENABLE
#include "vhal_sys.h"
#endif
#if CONFIG_VESYNC_HAL_BLE_ENABLE
#include "vhal_ble.h"
#endif

#include "vhal_utils.h"
#include "vesync_common.h"
#include "vesync_task.h"
#include "vesync_init_internal.h"
#include "vesync_log_internal.h"
#include "vesync_device_internal.h"
#include "vesync_event_internal.h"
#include "vesync_aes.h"
#if CONFIG_VESYNC_SDK_BYPASS_ENABLE
#include "vesync_bypass_internal.h"
#endif
#include "vesync_flash.h"
#if CONFIG_VESYNC_SDK_OTA_ENABLE
#include "vesync_ota_internal.h"
#endif
#if CONFIG_VESYNC_SDK_REPORT_ENABLE
#include "vesync_report_internal.h"
#endif
#if CONFIG_VESYNC_SDK_NET_SERVICE_ENABLE
#include "vesync_net_service_internal.h"
#endif
#if CONFIG_VESYNC_SDK_BUTTON_ENABLE
#include "vesync_button_internal.h"
#endif
#if CONFIG_VESYNC_SDK_UART_ENABLE
#include "vesync_uart_internal.h"
#endif
#if CONFIG_VESYNC_SDK_WIFI_ENABLE
#include "vesync_wifi_led_internal.h"
#endif
#if CONFIG_VESYNC_SDK_PRODUCTION_ENABLE
#include "vesync_production_internal.h"
#endif
#if CONFIG_VESYNC_SDK_NETCFG_ENABLE
#include "vesync_netcfg_internal.h"
#endif
#if CONFIG_VESYNC_SDK_LAN_COMM_ENABLE
#include "vesync_lan_comm.h"
#endif
#if CONFIG_VESYNC_SDK_FFS_ENABLE
#include "vesync_ffs_internal.h"
#endif
#if CONFIG_VESYNC_SDK_DEVELOPER_ENABLE
#include "vesync_developer_internal.h"
#endif
#if CONFIG_VESYNC_SDK_BLE_SERVICE_ENABLE
#include "vesync_ble_internal.h"
#endif
#if CONFIG_VESYNC_SDK_TIMEBASE_ENABLE
#include "vesync_timebase_internal.h"
#endif
#ifdef CONFIG_VESYNC_USE_LOOP_TIMER
#include "vesync_timer_internal.h"
#endif
#if CONFIG_VESYNC_SDK_SRPC_ENABLE
#include "vesync_srpc_internal.h"
#endif
#if CONFIG_VESYNC_SDK_SAUTH_ENABLE
#include "vesync_sauth_internal.h"
#endif
#if CONFIG_VESYNC_SDK_MQTT_ENABLE
#include "vesync_mqtt_internal.h"
#endif

static sdk_reg_run_cb_t s_sdk_pre_run_cb = NULL;
static sdk_reg_run_cb_t s_sdk_post_run_cb = NULL;


#if CONFIG_VESYNC_SDK_PRODUCTION_ENABLE
/**
 * @brief 初始化产测处理
 * @return bool             [true:进入产测处理，false:无需产测处理]
 */
static bool vesync_production_process(void)
{
    if (vesync_net_mgmt_get_reconnect_reason() == PRODUCTION_REASON) //如果为产测原因重连，立即进入产测
    {
        vesync_production_enter_testmode(false);
        return true;
    }

    if (vesync_production_get_status() != PRODUCTION_EXIT)  //已经在产测模式
    {
        return true;
    }

    if (!vesync_production_is_completed())
    {
#if PR_PRODUCTION_AUTO_ENTER
        vesync_production_enter_testmode(false);
#else
        if (vesync_net_mgmt_get_reconnect_reason() == UPGRADE_REASON)
        {
            vesync_production_enter_testmode(false);   //升级后直接进入产测,连接产测服务器
        }
        else
        {
            vesync_production_load_error_code();    //未自动进入产测， 先加载上次产测错误码
        }
#endif
        return true;
    }

    return false;
}
#endif /* CONFIG_VESYNC_SDK_PRODUCTION_ENABLE */

#if CONFIG_VESYNC_SDK_NET_SERVICE_ENABLE
/**
 * @brief 初始化配网处理
 * @return int             [成功：SDK_OK，失败：SDK_FAIL]
 */
static int vesync_netcfg_process(void)
{
    // 第一次使用或者恢复出厂重启后，开启配网
    int ret = vesync_net_mgmt_load_net_cfg();
    net_info_t *p_net_info = vesync_net_mgmt_get_net_cfg();

    SDK_LOG(LOG_DEBUG, "ret = %d, wifi ssid: %s\n", ret, (char *)p_net_info->wifiSSID);
    if (SDK_OK != ret || strlen((char *)p_net_info->wifiSSID) < 1)
    {
#if CONFIG_VESYNC_SDK_FFS_ENABLE
        if (vesync_ffs_is_active() == SDK_OK)
        {
            int ffs_result = vesync_ffs_start_netcfg();
            if (SDK_OK == ffs_result)
            {
                return SDK_OK;
            }
        }
#endif

#if CONFIG_VESYNC_SDK_PRODUCTION_ENABLE
        if (vesync_production_get_status() == PRODUCTION_EXIT)  // FFS失败，进入传统配网, 如果进入产测导致ffs退出，不进入传统配网
#endif
        {
#if CONFIG_VESYNC_SDK_NETCFG_ENABLE
#if PR_NETCFG_AUTO_START
            SDK_LOG(LOG_DEBUG, "vesync_netcfg_start\n");
            vesync_netcfg_start();
#elif CONFIG_VESYNC_HAL_BLE_ENABLE
            if (BLE_CONFIG == vesync_netcfg_get_mode())
            {
                SDK_LOG(LOG_DEBUG, "vhal_ble_advertising_start\n");
                vhal_ble_advertising_start();
            }
#endif
#endif
        }
    }
    else
    {
        vesync_wifi_client_connect((char *)p_net_info->wifiSSID,
                                    (char *)p_net_info->wifiPassword,
                                    (VHAL_WIFI_AUTH_MODE_E)p_net_info->auth_mode);

        vesync_wifi_led_set_behavior(WIFI_LED_CONNECTING);   // 连接Wi-Fi，快闪

        vesync_net_mgmt_set_reconnect_reason(POWER_ON_REASON);   // 统计设备掉线原因

#if CONFIG_VESYNC_SDK_LAN_COMM_ENABLE
        vesync_lan_comm_start();    // 启动局域网通信功能
#endif

#ifdef CONFIG_VESYNC_SDK_BLE_SERVICE_ENABLE
        if (BLE_CONFIG == vesync_netcfg_get_mode())
        {
            vesync_ble_adv_update_netcfg_status(NETCFG_STAT_CFGED); // 蓝牙广播已配网状态
        }
#endif
    }

    return SDK_OK;
}
#endif /* CONFIG_VESYNC_SDK_NET_SERVICE_ENABLE */


void vesync_sdk_entry(void *args)
{
    UNUSED(args);

    vesync_event_init();
    vesync_device_init();

#if CONFIG_VESYNC_SDK_BUTTON_ENABLE
    vesync_button_init();
#endif

#if CONFIG_VESYNC_SDK_UART_ENABLE
    vesync_uart_init();
#endif

#if CONFIG_VESYNC_SDK_NET_SERVICE_ENABLE
    vesync_wifi_client_init();
#endif

#if CONFIG_VESYNC_SDK_MQTT_ENABLE
    if (PR_NET_TRANS_PROT == NETWORK_MQTT || !vesync_production_is_completed())
    {
        vesync_mqtt_init();
    }
#endif

#if CONFIG_VESYNC_SDK_NET_SERVICE_ENABLE
    vesync_net_client_init();
#endif

#if CONFIG_VESYNC_SDK_BYPASS_ENABLE
    vesync_bypass_init();
#endif

#if CONFIG_VESYNC_SDK_DEVELOPER_ENABLE
    vesync_developer_init();
#endif

#if CONFIG_VESYNC_SDK_REPORT_ENABLE
    vesync_report_init();
#endif

#if CONFIG_VESYNC_SDK_OTA_ENABLE
    vesync_ota_init();
#endif

#if CONFIG_VESYNC_SDK_BLE_SERVICE_ENABLE
    vesync_ble_init();
#endif

    vhal_utils_start_sntp();    // 初始化SNTP服务(必须在Wi-Fi初始化后面)
    vesync_device_print_info();

#if CONFIG_VESYNC_SDK_WIFI_ENABLE
    vesync_wifi_led_set_behavior(WIFI_LED_STARTUP);
#endif

#if CONFIG_VESYNC_SDK_TIMEBASE_ENABLE
    vesync_timebase_init();
#endif

#if CONFIG_VESYNC_SDK_SRPC_ENABLE
    vesync_srpc_init();
#endif

#if CONFIG_VESYNC_SDK_SAUTH_ENABLE
    vesync_sauth_init();
#endif

    if (s_sdk_post_run_cb)
    {
        s_sdk_post_run_cb();
    }

#if CONFIG_VESYNC_SDK_PRODUCTION_ENABLE
    if (vesync_production_process())
    {
        return;
    }
#endif

#if CONFIG_VESYNC_SDK_NET_SERVICE_ENABLE
    vesync_netcfg_process();
#endif
}

void vesync_sdk_reg_pre_run_cb(void (*sdk_pre_run_cb)(void))
{
    s_sdk_pre_run_cb = sdk_pre_run_cb;
}

void vesync_sdk_reg_post_run_cb(void (*sdk_post_run_cb)(void))
{
    s_sdk_post_run_cb = sdk_post_run_cb;
}

int vesync_sdk_run(void)
{
    int ret = VOS_FAIL;
#if CONFIG_VESYNC_HAL_SYS_ENABLE
    vhal_sys_board_init();
#endif

    vesync_log_init();
    vesync_flash_init();
    vesync_aes_init();
#ifdef CONFIG_VESYNC_USE_LOOP_TIMER
    if (VOS_OK != vesync_timer_init())
    {
        SDK_LOG(LOG_ERROR, "vesync timer init fail\n");
        return SDK_FAIL;
    }
#endif

#if CONFIG_VESYNC_SDK_WIFI_ENABLE
    vesync_wifi_led_init();
#endif

    if (s_sdk_pre_run_cb)
    {
        s_sdk_pre_run_cb();
    }

    ret = vesync_task_new(INIT_TASK_NAME, NULL, vesync_sdk_entry, NULL, INIT_TASK_STACKSIZE, INIT_TASK_PRIO, NULL);
    if (ret != VOS_OK)
    {
        SDK_LOG(LOG_ERROR, "vesync sdk run fail\n");
        return SDK_FAIL;
    }

#if CONFIG_VESYNC_HAL_SYS_ENABLE
    vhal_sys_task_schedule();
#endif
    return SDK_OK;
}


