/**
 *  Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vhal_flash_internal.h
 * @brief       乐鑫平台nvs-flash读写驱动接口封装
 * @author      Dongri.Su
 * @date        2021-04-23
 */

#ifndef __VHAL_FLASH_INTERNAL__H__
#define __VHAL_FLASH_INTERNAL__H__

#ifdef __cplusplus
extern "C"
{
#endif

#define VHAL_ESP_DEFAULT_NVS_NAMESPACE          "nvs"               // NVS默认分区
#define VHAL_ESP_FAC_DATA_NAMESPACE             "fac_data"          // fac_data分区名
#define VHAL_ESP_USER_CFG_NAMESPACE             "usercfg"           // usercfg分区名
#define VHAL_ESP_LOG_NAMESPACE                  "log"               // log分区名
#define VHAL_ESP_DATA_CFG_NAMESPACE             "historydata"       // 历史数据分区


#ifdef __cplusplus
}
#endif

#endif /* __VHAL_FLASH_INTERNAL__H__ */
