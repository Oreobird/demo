/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_report.h
 * @brief       report模块接口定义
 * @date        2021-05-18
 */

#ifndef __VESYNC_REPORT_H__
#define __VESYNC_REPORT_H__

#include <stdint.h>
#include "cJSON.h"
#include "vesync_cfg.h"

#ifdef __cplusplus
extern "C" {
#endif

/*
 * @brief report topic类型
 */
 typedef enum
{
    REPORT_TOPIC_STATUS   = 0,      // 状态，设备端的运行状态，通常描述设备的工作情况和运行特征。包含：开关，挡位，速度等。
    REPORT_TOPIC_DATA     = 1,      // 数据，设备运行过程中所产生的运行数据，它通常与设备状态无关，包含：用电量，空气质量，湿度等。
    REPORT_TOPIC_LOG      = 2,      // 日志，设备运行过程中由软件打印的运行日志，它被用于分析设备状况。
    REPORT_TOPIC_RESP     = 3,      // bypass reply/ack topic
} REPORT_TOPIC_TYPE_E;

/**
 * @brief report QoS
 */
typedef enum
{
    REPORT_QOS0 = 0,
    REPORT_QOS1 = 1,
    REPORT_QOS2 = 2
} REPORT_QOS_E;

/**
* @enum    ANALYSIS_EVENT_E
* @brief   数据分析的事件类型
*/
typedef enum
{
    // 通用事件类型
    EVENT_SET_TIMER         = 0,        // 设置timer事件,"setTimer"
    EVENT_SET_SCHEDULE,                 // 设置schedule事件,"setSchedule"
    EVENT_ALTER_ON_OFF,                 // 开关机状态改变事件,"alterOnOff"

    // 专用设置或改变事件类型
    EVENT_ALTER_INDICATOR,              // 指示灯配置改变事件,"alterIndicatorLight"
    EVENT_ALTER_DISPLAY,                // 屏显配置改变事件,"alterDisplay"
    EVENT_ALTER_AUTO_STOP,              // 自动停止配置改变事件,"alterAutoStop"
    EVENT_ALTER_MIST_LEVEL,             // 冷雾档位改变事件,"alterMistLevel"
    EVENT_ALTER_TARGET_HUMIDITY,        // 目标湿度改变事件,"alterTargetHumidity"
    EVENT_ALTER_NIGHTLIGHT_BRIGHTNESS,  // 夜灯亮度改变事件,"alterNightlightBrightness"
    EVENT_ALTER_CHILD_LOCK,             // 童锁状态改变事件,"alterChildLock"
    EVENT_ALTER_PLASMA,                 // 等离子状态改变事件,"alterPlasma"
    EVENT_ALTER_AUTO_MODE_PREFERENCE,   // 设置自动模式偏好事件,"alterAutoModePreference"
    EVENT_RESET_FILTER,                 // 重置滤网事件,"resetFilter"

    // 专用进入某状态事件类型
    EVENT_ENTER_AUTO_MODE,              // 进入自动模式事件,"enterAutoMode"
    EVENT_ENTER_MANUAL_MODE,            // 进入手动模式事件,"enterManualMode"
    EVENT_ENTER_SLEEP_MODE,             // 进入睡眠模式事件,"enterSleepMode"
} ANALYSIS_EVENT_E;

/*
 * @brief 设备上报原因
 */
typedef enum
{
    CAUSE_NULL      = 0,    // 未知(非法制)
    CAUSE_CONNECT,          //连接上报
    CAUSE_TIME,             //定时上报
    CAUSE_CHANGE,           //改变上报
    CAUSE_QUERY,            //设备主动查询
    CAUSE_LOG               //日志上报
} REPORT_CAUSE_E;

/*
 * @brief  vesync report初始化
*/
void vesync_report_init(void);

/**
* @brief 设备上报云基础接口
* @param[in]   topic_type              [MQTT topic类型]
* @param[in]   method                  [方法字段]
* @param[in]   json_data               [json 格式的数据，填充到data对象]
* @param[in]   cause                   [上报原因]
* @return      int                     [成功/失败]
*/
int vesync_report_cloud(REPORT_TOPIC_TYPE_E topic_type, const char *method, cJSON *json_data, REPORT_CAUSE_E cause);

/**
* @brief 设备上报云基础接口
* @param[in]   topic_type              [MQTT topic类型]
* @param[in]   method                  [方法字段]
* @param[in]   json_data               [json 格式的数据，填充到data对象]
* @param[in]   cause                   [上报原因]
* @param[in]   qos                     [MQTT qos level]
* @param[in]   puback_cb               [收到qos1 ack后的回调]
* @return      int                     [成功/失败]
*/
int vesync_report_cloud_qos(REPORT_TOPIC_TYPE_E topic_type, const char *method, cJSON *json_data,
                                  REPORT_CAUSE_E cause, REPORT_QOS_E qos, void* puback_cb);


/**
* @brief       获取当前事件类型字符串值
* @param[in]   event   [事件类型]
* @return      事件类型对应字符串
*/
char* vesync_report_get_event_string(ANALYSIS_EVENT_E event);

/**
* @brief 上报第三方接口(http://34.194.32.46:8080/doc/POOTQH6Bs)，方法名：statusChangeNtyV2
*        设备状态上报(http://34.194.32.46:8080/doc/1LsQ4i5jz7)，方法名：statusChangeNtyV3
* @param[in]  json_data    [json 格式的数据，填充到data对象]
* @return     int          [成功/失败]
*/
int vesync_report_status_change_nty(cJSON *json_data);

/**
* @brief 更新设备在云端的属性(http://34.194.32.46:8080/doc/N5iaViSJO)，方法名：updateDevInfoV2。
*        设备初始化(http://34.194.32.46:8080/doc/1Lsk8K8lhN)，方法名：initDev
* @return int      [成功/失败]
*/
int vesync_report_update_dev_info(void);

/**
* @brief 设备上报运行日志(http://34.194.32.46:8080/doc/BVH3a8uib)， deviceLogReport
* @param[in]  json_data    [json 格式的数据，填充到data对象]
* @return     int          [成功/失败]
*/
int vesync_report_device_log(cJSON *json_data);

/**
* @brief       上报数据埋点到云端(http://wiki.vesync.com:8090/pages/viewpage.action?pageId=79265852)，方法名：uploadAnalyzeData
* @param[in]   event               [事件类型]
* @param[in]   json_report_data    [上报数据内容]
* @param[in]   control_type        [控制类型]
* @return      int                 [成功/失败]
*/
int vesync_report_analysis_data(cJSON *json_event_array_data, const char* control_type);

#if CONFIG_VESYNC_PLAT_FFS_ENABLE
/**
* @brief 上报证书类型下载结果
* @param[in]  cert_type         [证书类型]
* @param[in]  status            [升级状态]
* @return     int               [成功/失败]
*/
int vesync_report_cert_update(FFS_CERT_E cert_type, uint8_t status);
#endif

#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_REPORT_H__ */


