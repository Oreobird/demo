/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file    vhal_pcnt.h
 * @brief   pcnt(Pulse Counter)接口封装
 * @date    2021-04-22
 */

#ifndef __VHAL_PCNT_H__
#define __VHAL_PCNT_H__

#include <stdint.h>


#ifdef __cplusplus
extern "C"
{
#endif

#define VHAL_PCNT_PIN_NOT_USED      (-1)    // When selected for a pin, this pin will not be used

/*
 * @brief PCNT控制模式(Control mode)
 */
typedef enum
{
    VHAL_PCNT_MODE_KEEP = 0,                // won't change counter mode
    VHAL_PCNT_MODE_REVERSE = 1,             // invert counter mode(increase -> decrease, decrease -> increase)
    VHAL_PCNT_MODE_DISABLE = 2,             // Inhibit counter(counter value will not change in this condition)
    VHAL_PCNT_MODE_MAX
} PCNT_CTRL_MODE_E;

/*
 * @brief PCNT计数模式(Counter mode)
 */
typedef enum
{
    VHAL_PCNT_COUNT_DIS = 0,                // Inhibit counter(counter value will not change in this condition)
    VHAL_PCNT_COUNT_INC = 1,                // Increase counter value
    VHAL_PCNT_COUNT_DEC = 2,                // Decrease counter value
    VHAL_PCNT_COUNT_MAX
} PCNT_COUNT_MODE_E;

/*
 * @brief PCNT脉冲计数器单
 */
typedef enum
{
    VHAL_PCNT_UNIT_0 = 0,                   // PCNT unit 0
    VHAL_PCNT_UNIT_1 = 1,                   // PCNT unit 1
    VHAL_PCNT_UNIT_2 = 2,                   // PCNT unit 2
    VHAL_PCNT_UNIT_3 = 3,                   // PCNT unit 3
    VHAL_PCNT_UNIT_4 = 4,                   // PCNT unit 4
    VHAL_PCNT_UNIT_5 = 5,                   // PCNT unit 5
    VHAL_PCNT_UNIT_6 = 6,                   // PCNT unit 6
    VHAL_PCNT_UNIT_7 = 7,                   // PCNT unit 7
    VHAL_PCNT_UNIT_MAX,
} PCNT_UNIT_E;

/*
 * @brief PCNT通道
 */
typedef enum
{
    VHAL_PCNT_CHANNEL_0 = 0x00,             // PCNT channel 0
    VHAL_PCNT_CHANNEL_1 = 0x01,             // PCNT channel 1
    VHAL_PCNT_CHANNEL_MAX,
} PCNT_CHANNEL_E;

/*
 * @brief PCNT配置
 */
typedef struct
{
    int pulse_gpio_num;                     // Pulse input GPIO number, if you want to use GPIO16, enter pulse_gpio_num = 16, a negative value will be ignored
    int ctrl_gpio_num;                      // Control signal input GPIO number, a negative value will be ignored
    PCNT_CTRL_MODE_E lctrl_mode;            // PCNT low control mode
    PCNT_CTRL_MODE_E hctrl_mode;            // PCNT high control mode
    PCNT_COUNT_MODE_E pos_mode;             // PCNT positive edge count mode
    PCNT_COUNT_MODE_E neg_mode;             // PCNT negative edge count mode
    int16_t counter_h_lim;                  // Maximum counter value
    int16_t counter_l_lim;                  // Minimum counter value
    PCNT_UNIT_E unit;                       // PCNT unit number
    PCNT_CHANNEL_E channel;                 // the PCNT channel
} vhal_pcnt_config_t;

/**
 * @brief  pcnt单元配置函数
 * @param[in]  pcnt_config              [pcnt配置结构体指针]
 * @return     int32_t                  [操作结果, 0为成功，其他值表示失败]
 */
int32_t vhal_pcnt_unit_config(const vhal_pcnt_config_t *pcnt_config);

/**
 * @brief  获取pcnt计数值
 * @param[in]  pcnt_unit                [pcnt计数unit]
 * @param[out] count                    [pcnt计数值]
 * @return     int32_t                  [操作结果, 0为成功，其他值表示失败]
 */
int32_t vhal_pcnt_get_counter_value(PCNT_UNIT_E pcnt_unit, int16_t *count);

/**
 * @brief  暂停pcnt计数
 * @param[in]  pcnt_unit                [pcnt计数unit]
 * @return     int32_t                  [操作结果, 0为成功，其他值表示失败]
 */
int32_t vhal_pcnt_pause_counter(PCNT_UNIT_E pcnt_unit);

/**
 * @brief  pcnt重新计数
 * @param[in]  pcnt_unit               [pcnt计数unit]
 * @return     int32_t                  [操作结果, 0为成功，其他值表示失败]
 */
int32_t vhal_pcnt_resume_counter(PCNT_UNIT_E pcnt_unit);

/**
 * @brief  清除pcnt计数
 * @param[in]  pcnt_unit               [pcnt计数unit]
 * @return     int32_t                  [操作结果, 0为成功，其他值表示失败]
 */
int32_t vhal_pcnt_clear_counter(PCNT_UNIT_E pcnt_unit);

/**
 * @brief  使能pcnt滤波
 * @param[in]  pcnt_unit                [pcnt计数unit]
 * @return     int32_t                  [操作结果, 0为成功，其他值表示失败]
 */
int32_t vhal_pcnt_enable_filter(PCNT_UNIT_E pcnt_unit);

/**
 * @brief  除能pcnt滤波
 * @param[in]  pcnt_unit                [pcnt计数unit]
 * @return     int32_t                  [操作结果, 0为成功，其他值表示失败]
 */
int32_t vhal_pcnt_disable_filter(PCNT_UNIT_E pcnt_unit);

/**
 * @brief  设置pcnt滤波值
 * @param[in]  pcnt_unit                [pcnt计数unit]
 * @param[in]  filter_val               [pcnt滤波值（10bit,最大1023）]
 * @return     int32_t                  [操作结果, 0为成功，其他值表示失败]
 */
int32_t vhal_pcnt_set_filter_value(PCNT_UNIT_E pcnt_unit, uint16_t filter_val);

#ifdef __cplusplus
}
#endif

#endif /* __VHAL_PCNT_H__ */
