/**
*Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file     device.c
* @brief    设备业务处理
* @author   Joshua
*@date      2021-12-1
*/
#include <stdbool.h>
#include <string.h>
#include "vesync_log.h"
#include "vesync_production.h"
#include "vesync_net_service.h"
#include "device.h"
#include "light.h"
#include "event.h"
#include "scene.h"

static dev_cfg_t s_dev_cfg;

/**
 * @brief 清除应用层数据
 * @param[in]  rsn              [消息来源]
 * @param[in]  rst_type         [删除用户数据的类型]
 */
static void device_clear_all_data(const char* rsn, DEV_RESET_TYPE_E rst_type)
{
    if (rst_type == DEV_DEL_USER_CFG || rst_type == DEV_DEL_DEVICE)
    {
#if TODO
#if CONFIG_VESYNC_APP_SCHEDULE
        app_schedule_clear();
#endif
#if CONFIG_VESYNC_APP_AWAY
        app_away_clear();
#endif
#if CONFIG_VESYNC_APP_INCHING
        app_inching_clear();
#endif

#if CONFIG_VESYNC_APP_SCENE
        app_scene_clear();
#endif
#endif
#if CONFIG_VESYNC_APP_BYPASS_TIMER_SUPPORT
        if (s_dev_cfg.timing_cfg && s_dev_cfg.timing_cfg_len > 0)
        {
            memset(s_dev_cfg.timing_cfg, 0, s_dev_cfg.timing_cfg_len);
        }
#endif
        app_flash_cfg_reset(s_dev_cfg.flash);
    }
}

int app_device_cfg_save(dev_cfg_t *cfg)
{
    VCOM_NULL_PARAM_CHK(cfg, return APP_FAIL);
    app_flash_cfg_write(cfg->flash);
    return APP_OK;
}

dev_cfg_t *app_device_cfg_get(void)
{
    return &s_dev_cfg;
}

uint16_t app_device_bead_num(void)
{
    return s_dev_cfg.flash->cfg.bead_num;
}

uint8_t app_device_work_mode(void)
{
    return s_dev_cfg.flash->cfg.mode;
}

int app_device_init(void)
{
    memset(&s_dev_cfg, 0, sizeof(dev_cfg_t));
    s_dev_cfg.flash = app_flash_create();

    app_flash_cfg_default_init(s_dev_cfg.flash);
    app_flash_cfg_read(s_dev_cfg.flash);

    s_dev_cfg.fade = (LIGHT_FADE_ENABLE == 1) ? true : false;

    APP_LOG(LOG_DEBUG, "---------light mode:[%d], param: H[%d], S[%d], V[%d], C[%d], W[%d], segNum[%d], beadSize[%d], sceneId[%d]\n",
        s_dev_cfg.flash->cfg.mode,
        s_dev_cfg.flash->cfg.light_param.H,s_dev_cfg.flash->cfg.light_param.S,s_dev_cfg.flash->cfg.light_param.V,
        s_dev_cfg.flash->cfg.light_param.color_temp,s_dev_cfg.flash->cfg.light_param.brightness,
        s_dev_cfg.flash->cfg.seg_num,s_dev_cfg.flash->cfg.bead_num, s_dev_cfg.flash->cfg.scene_id);

    vesync_device_reg_clear_data_cb(device_clear_all_data);

    return APP_OK;
}

int app_device_deinit(void)
{
    return app_flash_destroy(s_dev_cfg.flash);
}

int app_device_startup(void)
{
    if (vesync_production_get_status() != PRODUCTION_EXIT)
    {
        scene_t *scene = scene_registry_get(SCENE_PRD, 0);
        prd_light_scene_start(scene);
    }
    else if (!vesync_net_is_configured())
    {
        scene_t *scene = scene_registry_get(SCENE_NETCFG, 0);
        netcfg_light_scene_wait(scene);
    }
    else
    {    
        uint8_t scene_type = SCENE_LIGHT;
        uint16_t scene_id = s_dev_cfg.flash->cfg.scene_id;
        app_scene_info_get_from_mode(&scene_type, &scene_id);
        POWERON_NOTIFY(ACT_SRC_INIT, scene_type, scene_id);
    }

    return APP_OK;
}