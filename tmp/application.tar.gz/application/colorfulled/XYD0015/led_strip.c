/**
*Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file    led_strip.c
* @brief   灯带应用业务
* @author  henrik
*@date     2021-10-25
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <stdio.h>

#include "vhal_led.h"
#include "vhal_gpio.h"

#include "vesync_mutex.h"
#include "vesync_common.h"
#include "vesync_init.h"
#include "vesync_log.h"
#include "vesync_queue.h"
#include "vesync_task.h"
#include "vesync_device.h"
#include "vesync_wifi_led.h"
#include "vesync_memory.h"
#include "vesync_production.h"
#include "vesync_netcfg.h"

#include "led_strip.h"
#include "led_display.h"
#include "led_strip_sound_detect.h"
#include "led_strip_board.h"
#include "led_strip_led_drv.h"
#include "led_strip_button.h"
#include "led_strip_production.h"
#include "led_strip_wifi_led.h"
#include "led_strip_flash.h"
#include "led_strip_schedule.h"
#include "led_strip_bypass.h"
#include "led_strip_report.h"
#include "led_strip_device.h"


static led_strip_signal_hsv_t  s_signal_hsv ;
static uint8_t s_audio_state = LS_TASK_STOP;
static vesync_queue_t *p_event_queue = NULL;          // 应用层事件队列消息
static ls_scene_dis_t s_display ;                     // 灯带灯效显示结构体
static led_rgb_handle_t *p_led_rgb_handle = NULL ;    // 灯带控制参数指针
static int32_t s_dc_component  = 0;                   // ADC初始分量


/*以下校准参数来源于gamma_calibrate.py ,路径在tools/gamma_calibrate.py*/

static const uint8_t s_red_calibrate[256] = {0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 7, 7, 8, 9, 9, 10, 11, 11, 12, 13, 13, 14,     \
                                       15, 15, 16, 17, 18, 18, 19, 20, 21, 21, 22, 23, 24, 25, 25, 26, 27, 28, 29, 29, 30, 31,     \
                                       32, 33, 33, 34, 35, 36, 37, 38, 39, 39, 40, 41, 42, 43, 44, 45, 46, 46, 47, 48, 49, 50,     \
                                       51, 52, 53, 54, 55, 56, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71,     \
                                       72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93,     \
                                       94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112,    \
                                       114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 128, 129, 130, 131, 132,   \
                                       133, 134, 135, 136, 137, 138, 140, 141, 142, 143, 144, 145, 146, 147, 149, 150, 151, 152,   \
                                       153, 154, 155, 156, 158, 159, 160, 161, 162, 163, 164, 166, 167, 168, 169, 170, 171, 172,   \
                                       174, 175, 176, 177, 178, 179, 181, 182, 183, 184, 185, 186, 188, 189, 190, 191, 192, 194,   \
                                       195, 196, 197, 198, 199, 201, 202, 203, 204, 205, 207, 208, 209, 210, 211, 213, 214, 215,   \
                                       216, 217, 219, 220, 221, 222, 224, 225, 226, 227, 228, 230, 231, 232, 233, 235, 236, 237,   \
                                       238, 239, 241, 242, 243, 244, 246, 247, 248, 249, 251, 252, 253, 254};
static const uint8_t s_green_calibrate[256] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 5, 5, 6,    \
                                         6, 6, 7, 7, 8, 8, 9, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13, 14, 14, 15, 16, 16, 17, 17,    \
                                         18, 18, 19, 20, 20, 21, 21, 22, 23, 23, 24, 25, 25, 26, 27, 27, 28, 29, 30, 30, 31, 32,   \
                                         32, 33, 34, 35, 35, 36, 37, 38, 39, 39, 40, 41, 42, 43, 43, 44, 45, 46, 47, 48, 48, 49,   \
                                         50, 51, 52, 53, 54, 55, 56, 57, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70,   \
                                         71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 87, 88, 89, 90, 91, 92, 93,   \
                                         94, 95, 97, 98, 99, 100, 101, 102, 103, 105, 106, 107, 108, 109, 111, 112, 113, 114, 115, \
                                         117, 118, 119, 120, 121, 123, 124, 125, 126, 128, 129, 130, 132, 133, 134, 135, 137, 138, \
                                         139, 141, 142, 143, 145, 146, 147, 149, 150, 151, 153, 154, 155, 157, 158, 160, 161, 162, \
                                         164, 165, 167, 168, 169, 171, 172, 174, 175, 176, 178, 179, 181, 182, 184, 185, 187, 188, \
                                         190, 191, 193, 194, 196, 197, 199, 200, 202, 203, 205, 206, 208, 209, 211, 212, 214, 215, \
                                         217, 219, 220, 222, 223, 225, 227, 228, 230, 231, 233, 235, 236, 238, 239, 241, 243, 244, \
                                         246, 248, 249, 251, 253, 254};


/**
 * @brief rgb颜色校准
 * @param[in/out] rgb                            [rgb 分量 ]
 * @return     int                            [成功或失败]
 * @note
 */
static int led_strip_rgb_calibration_handler(rgb_color_t *rgb)
{
    if (NULL == rgb)
    {
        APP_LOG(LOG_ERROR, "input illegal!\n");
        return APP_FAIL;
    }

    rgb->blue = s_green_calibrate[rgb->blue];   // 蓝色与绿色采用相同的gamma值（gamma = 0.6）
    rgb->green = s_green_calibrate[rgb->green];
    rgb->red = s_red_calibrate[rgb->red];
    rgb->blue = ((uint32_t) rgb->blue)* LS_BLUE_CALIBRATE_RATE;
    rgb->green = ((uint32_t) rgb->green) * LS_GREEN_CALIBRATE_RATE;

    return APP_OK;
}

/**
 * @brief      按键事件获取场景id
 * @return
 *      - APP_OK  成功
 *      - APP_FAIL  失败
 */
static void led_strip_get_scene_id(uint16_t * id)
{
    ls_info_t * p_info = NULL;

    if (NULL == id)
    {
        return ;
    }

    *id = 0;
    p_info = led_strip_get_info();

    // 开灯或从其他场景模式则恢复上一次的场景
    if ((LS_STATUS_OFF == p_info->status)||(SCENE_COLOR_MUSIC > p_info->mode))
    {
        if (0 != p_info->scene_now)
        {
            *id =  p_info->scene_now;
        }
        else
        {
            *id = p_info->scene_list[SCENE_CUSTOM_MAX_NUM - p_info->scene_num].id;
        }
        return ;
    }

    for (int i = 0 ; i < SCENE_MAX_NUM; i++)
    {
        if ((0 == p_info->scene_now)&&(0 !=p_info->scene_list[i].id))          // 遍历列表，找到当前ID
        {
            *id = p_info->scene_list[i].id;
            break;
        }
        else if ((0 != p_info->scene_now)&&(p_info->scene_now == p_info->scene_list[i].id)&&((i+1) < SCENE_MAX_NUM))
        {
            *id = p_info->scene_list[i+1].id;
            break;
        }
    }
    APP_LOG(LOG_DEBUG, "now: %d, next id:%d \n", p_info->scene_now,  *id );
    if (0 == *id)  // 未找到id，则回到第一个定义的场景
    {
       *id = p_info->scene_list[SCENE_CUSTOM_MAX_NUM - p_info->scene_num].id;
    }
    else
    {
        p_info->scene_now = *id;
    }
}

/**
* @brief  设置显示场景
* @param[in]  type           [场景类型]
* @param[in]  id             [场景id]
*/
static void led_strip_set_display_scene(uint8_t type, uint16_t id)
{
    ls_info_t * p_info = NULL;

    p_info = led_strip_get_info();
    p_info->status = LS_STATUS_ON;
    s_display.scene_id = id;
    s_display.scene_type = type;

    if (SCENE_TYPE_DEFINE == type)
    {
        APP_LOG(LOG_DEBUG, "scene id:%d \n", id);
        led_strip_set_power_io(1);
        p_info->scene_now = id;
        p_info->mode = SCENE_COLOR_SCENE;
        if (SCENE_SPECTRUM == id)
        {
            p_info->mode = SCENE_COLOR_MUSIC;
        }
        led_strip_set_voice_off_flag(false);
    }
    else if (SCENE_TYPE_REALTIME == type)
    {
        led_strip_set_power_io(1);
        APP_LOG(LOG_DEBUG, "realtime mode:%d \n", p_info->mode);
        p_info->scene_now = p_info->scene_list[SCENE_CUSTOM_MAX_NUM - p_info->scene_num].id;
        led_strip_set_voice_off_flag(false);
    }
    else if (SCENE_TYPE_OFF != type) // 配网、产测、复位灯效条件下，设备状态切换为白光模式，50%亮度
    {
        APP_LOG(LOG_DEBUG, "scene type:%d \n", type);
        led_strip_set_voice_off_flag(false);
        led_strip_set_power_io(1);
        p_info->mode = SCENE_COLOR_WHITE;
        p_info->brightness = DEFAULT_PULSE;
        if ((SCENE_TYPE_CFNET == type)&&(CFG_SCENE_SUCCESS == id))  // 配网完成灯效，这时保存状态到flash
        {
            led_strip_save_info(p_info);
            led_strip_report_set_chg_rsn(STAT_CHG_RSN_CONFIG_NET_STR);
            led_strip_report_status();  // 上报云，设备状态变化
        }
    }

    if ((SCENE_TYPE_REALTIME == type)||(SCENE_TYPE_DEFINE == type))
    {
        led_strip_report_status();  // 上报云，设备状态变化
        led_strip_save_info(p_info);
    }
    else if (SCENE_TYPE_OFF == type)
    {
        p_info->status = LS_STATUS_OFF;
        led_strip_save_info(p_info);
        led_strip_set_power_io(0);
        led_strip_report_status();  // 上报云，设备状态变化
    }

    s_display.change_count++;
}

/**
 * @brief      停止声音采集
 * @return
 *      - APP_OK  成功
 *      - APP_FAIL  失败
 */
static void led_strip_audio_stop(void)
{
    APP_LOG(LOG_DEBUG, "led_strip_audio_stop \n");
    led_strip_stop_sound_detect();
    s_audio_state = LS_TASK_STOP;
}


/**
 * @brief      声音采集接口
 * @param[in]  arg            [灯带参数指针]
 */
static void led_strip_sound_detect_handler(led_rgb_handle_t *arg)
{
    int32_t count = 0;
    static double  rec_max = 0;

    led_rgb_handle_t *led_rgb_handle = arg;
    rgb_parameters_t *rgb = led_rgb_handle->rgb_parameters;

    led_strip_get_sound_data(s_dc_component, rgb->audio_data, &count);
    if (0 != count)
    {
        for (int i = 0; i < rgb->freq_normal->n_samples / 2; i++)
        {
            /* Get the maximum value in a frame of source data */
            if (rgb->max_audio_data < rgb->audio_data[i])
            {
                rgb->max_audio_data = rgb->audio_data[i];
            }
        }

        if (rgb->max_audio_data < rgb->min_sound_threshold)
        {
            rgb->max_audio_data = 0;
        }

        if (rec_max < rgb->max_audio_data)
        {
            /* The stored program starts to the currently acquired view */
            rec_max = rgb->max_audio_data;
            rgb->max_rec = rec_max;
        }
        led_strip_sound_data_fft(led_rgb_handle->fft_array->s_y_cf2, rgb->freq_normal->n_samples,
                                 rgb->audio_data, led_rgb_handle->fft_array->s_wind);
    }

}

/**
 * @brief      开始声音采集模式
 * @param[in]  led_rgb_handle      [灯带参数指针]
 * @return
 *      - APP_OK  成功
 *      - APP_FAIL  失败
 */
static int led_strip_audio_start(led_rgb_handle_t *led_rgb_handle )
{
    int ret = APP_OK;
    int32_t count = 0;
    static uint8_t audio_init_flag = 0;

    if (NULL == led_rgb_handle)
    {
        APP_LOG(LOG_ERROR, "input illigal!\n");
        return APP_FAIL;
    }

    rgb_parameters_t *rgb = led_rgb_handle->rgb_parameters;

    /* Initialize adc */
    if (0 == audio_init_flag)
    {
        led_strip_sound_detect_init(ADC_CHANNEL,led_rgb_handle->fft_array->s_wind, \
                                led_rgb_handle->rgb_parameters->freq_normal->n_samples);
        audio_init_flag = 1;
        led_strip_start_sound_detect();
        /* Calculate the DC component */
        for (int i = 0;(APP_FAIL == ret)&&( i < 3); i++)
        {
            ret = led_strip_get_sound_data(s_dc_component, rgb->audio_data, &count);
        }

        for (int i = 1; i < count; i++)
        {
            rgb->audio_data[0] += rgb->audio_data[i];
        }

        if (0 != count)
        {
            s_dc_component = rgb->audio_data[0] / count;
        }
        else
        {
            s_dc_component = 100;
        }

        APP_LOG(LOG_DEBUG, "dc_component: %d, %d \n", s_dc_component, count);
    }

    return ret ;
}

/**
 * @brief  app任务事件处理
 * @param[in]    ev     [主任务事件结构体]
 */
static void app_event_handle(ls_ev_t ev)
{
    uint16_t button_id = 0;
    switch (ev.event)
    {
        case LS_EV_RESET:
            APP_LOG(LOG_INFO, "reset scene!\n");
            led_strip_set_display_scene(SCENE_TYPE_RESET, 0);
            vesync_device_factory_reset(true, STAT_CHG_RSN_BTN_STR);
            break;
        case LS_EV_BEFORE_NETCFG:
            led_strip_wifi_set_netcfg_flag(true);
            led_strip_set_display_scene(SCENE_TYPE_CFNET, CFG_SCENE_START);
            break;
        case LS_EV_NETCFG:
            if (LS_ACT_SRC_BTN == ev.act_src)
            {
                APP_LOG(LOG_INFO, "start netcfg\n");
                vesync_netcfg_restart();
            }
            else if (LS_ACT_SRC_WIFI_LED == ev.act_src)
            {
                led_strip_set_display_scene(ev.scene_type, ev.scene_id);
                APP_LOG(LOG_INFO, "wifi_led change scene_type:%d id:%d !\n", ev.scene_type, ev.scene_id);
            }
            break;
        case LS_EV_PRODUCTION:
            if (LS_ACT_SRC_BTN == ev.act_src)
            {
                APP_LOG(LOG_INFO, "enter production test mode !!\n");
                led_strip_clear_info();
                if (LS_TASK_RUNNING == s_audio_state)  // 音乐律动模式需要关闭声音采集任务
                {
                    led_strip_audio_stop();
                }
                vesync_production_enter_testmode(true);
            }
            else if (LS_ACT_SRC_PRD == ev.act_src)
            {
                led_strip_set_display_scene(ev.scene_type, ev.scene_id);
                APP_LOG(LOG_INFO, "prd change scene_type:%d id:%d !\n", ev.scene_type, ev.scene_id);
            }
            break;
        case LS_EV_CHANGE_SCENE:
            led_strip_set_cfgnet_scene(CFG_SCENE_UNKNOWN);
            if (LS_ACT_SRC_BTN == ev.act_src)
            {
                led_strip_get_scene_id(&button_id);
                led_strip_report_set_chg_rsn(STAT_CHG_RSN_BTN_STR);
                led_strip_set_display_scene(SCENE_TYPE_DEFINE, button_id);
                APP_LOG(LOG_INFO, "change scene:%d!\n", button_id);
            }
            else if ((LS_ACT_SRC_BYPASS == ev.act_src)||(LS_ACT_SRC_INIT == ev.act_src))
            {
                led_strip_set_display_scene(ev.scene_type, ev.scene_id);
                APP_LOG(LOG_INFO, "bypass change scene_type:%d id:%d src:%d!\n", ev.scene_type, ev.scene_id, ev.act_src);
            }
            break;
        case LS_EV_STATUS_OFF:
            led_strip_set_display_scene(SCENE_TYPE_OFF, 0);
            break;
        default:
            APP_LOG(LOG_WARN, "Unknown event\n");
            break;
    }

}


/**
* @brief  设置显示场景
* @param[in]  display               [场景显示结构体]
* @param[in]  led_rgb_handle        [灯带参数指针]
*/
static void led_strip_scene_change_handle(ls_scene_dis_t display , led_rgb_handle_t *led_rgb_handle )
{
    static uint8_t last_count = 0;  // 标识是否有灯效改变未执行
    ls_info_t * p_info = NULL;
    ls_color_seg_t temp_color ;

    if (last_count != display.change_count )
    {
        last_count = display.change_count;
        p_info = led_strip_get_info();
        s_signal_hsv.scene = display.scene_id;
        s_signal_hsv.count = 0;
        s_signal_hsv.display_pos = 0;

        if (SCENE_TYPE_REALTIME == display.scene_type)
        {
            switch(p_info->mode)
            {
                case SCENE_COLOR_MULT:
                    s_signal_hsv.number = p_info->multiple.num;
                    led_strip_scene_data_transform(p_info->multiple.color, &s_signal_hsv,p_info->mode);
                    break;
                case SCENE_COLOR_RGB:
                    s_signal_hsv.number = 0;
                    led_strip_scene_data_transform(&(p_info->color), &s_signal_hsv,p_info->mode);
                    break;
                case SCENE_COLOR_WHITE:
                    temp_color.val = p_info->brightness;
                    s_signal_hsv.number = 0;
                    led_strip_scene_data_transform(&(temp_color), &s_signal_hsv,p_info->mode);
                    break;
                default:
                    break;
            }

        }
    }

}

/**
 * @brief      灯效显示处理接口
 * @return     uint32_t             [灯效延时时间]
 */
static uint32_t  led_strip_display_handler(void)
{
    rgb_parameters_t *rgb = p_led_rgb_handle->rgb_parameters;
    ls_info_t * p_info = NULL;
    p_info = led_strip_get_info();
    uint32_t wait_ms = 0;
    if (p_info->led_num != rgb->leds_total_number)   // 灯珠数量改变，需要同步
    {
        rgb->leds_total_number = p_info->led_num;
    }

    led_strip_scene_change_handle(s_display, p_led_rgb_handle);

    switch(s_display.scene_type)
    {
        case SCENE_TYPE_CFNET:
            wait_ms = led_strip_cfgnet_scene(p_led_rgb_handle->strip, rgb, &s_signal_hsv);
            break;
        case SCENE_TYPE_PRD:
            wait_ms = led_strip_production_scene(p_led_rgb_handle->strip, rgb, &s_signal_hsv);
            break;
        case SCENE_TYPE_RESET:
            wait_ms = led_strip_reset_scene(p_led_rgb_handle->strip, rgb, &s_signal_hsv);
            break;
        case SCENE_TYPE_DEFINE:
            if ((SCENE_DEFAULT_MIN_ID <= s_display.scene_id)&&(SCENE_DEFAULT_MAX_ID >= s_display.scene_id))
            {
                if (SCENE_COLOR_MUSIC == p_info->mode)
                {
                    led_strip_sound_detect_handler(p_led_rgb_handle);
                }
                wait_ms = led_strip_default_scene(p_led_rgb_handle, &s_signal_hsv);

            }
            else if ((SCENE_CUSTOM_MAX_ID >= s_display.scene_id)&&(SCENE_CUSTOM_MIN_ID <= s_display.scene_id))
            {
               wait_ms = led_strip_custom_scene(p_led_rgb_handle->strip, rgb, &s_signal_hsv);
            }
            break;
        case SCENE_TYPE_REALTIME:
            wait_ms = led_strip_realtime_scene(p_led_rgb_handle->strip, rgb, &s_signal_hsv);
            break;
        case SCENE_TYPE_OFF:
        default :
            wait_ms = led_strip_off_scene(p_led_rgb_handle->strip, rgb, &s_signal_hsv);
           break;
    }

    if (0 == wait_ms)
    {
        wait_ms =  SCENE_WAIT_MS_DEFAULT;
    }
    return wait_ms;
}


/**
 * @brief  给ledstrip应用任务发通知
 * @param[in]   ev              [通知消息]
 * @return     int              [成功：APP_OK，失败：APP_FAIL]
 */
int led_strip_app_task_notify(ls_ev_t *ev)
{
    int ret = vesync_queue_send(p_event_queue, ev, VESYNC_OS_NO_WAIT);
    if (ret != VOS_OK)
    {
        APP_LOG(LOG_ERROR, "Event publish failed\n");
        return APP_FAIL;
    }
    return APP_OK;
}


/**
 * @brief      灯带应用事件处理任务
 * @param[in]  arg                  [任务传入参数]
 */
static void led_strip_app_task(void *arg)
{
    UNUSED(arg);
    ls_ev_t ev;
    uint32_t wait_ms = 0;
    led_strip_parameter_init();
    led_strip_audio_start(p_led_rgb_handle);
    while(1)
    {
        if (VOS_OK == vesync_queue_recv(p_event_queue, &ev, wait_ms))
        {
            app_event_handle(ev);
        }

        wait_ms = led_strip_display_handler();
    }
}

static void led_strip_pre_cb(void)
{
    p_led_rgb_handle = led_strip_rgb_ctrl_init();
    if (NULL == p_led_rgb_handle)
    {
        APP_LOG(LOG_ERROR,"led strip ctrl init fail!\n");
    }

    led_strip_signal_struct_init(&s_signal_hsv, MAX_SEGMENT_NUM);
    led_strip_reg_rgb_calibrate_cb(led_strip_rgb_calibration_handler);

    s_signal_hsv.scene = 0;
    s_display.scene_type = SCENE_TYPE_OFF;
}

static void led_strip_app_run(void)
{
    int ret = VOS_OK;

    ls_button_init();
    led_strip_device_init();
    led_strip_power_ctrl_init();
    led_strip_white_ctrl_init();
    led_strip_production_init();
    led_strip_reg_wifi_led();
    led_strip_schedule_init();
    led_strip_timing_init();
    led_strip_report_init();
    led_strip_bypass_reg_cb();

    p_event_queue = vesync_queue_new(LS_EVENT_QUEUE_MAX_NUM * sizeof(ls_ev_t), sizeof(ls_ev_t));
    if (p_event_queue == NULL)
    {
        APP_LOG(LOG_ERROR, "App event queue create failed\n");
        return;
    }

    /* Create led app task */
    ret = vesync_task_new("led_strip_app", NULL, led_strip_app_task, NULL,\
                           LED_STRIP_APP_TASK_STACKSIZE, LED_STRIP_APP_TASK_PRIORITY, NULL);
    if (ret != VOS_OK)
    {
        APP_LOG(LOG_ERROR, "led_strip_task create failed\n");
        return;
    }
}

/**
 * @brief  应用入口
 */
void app_main(void)
{
    vesync_sdk_reg_pre_run_cb(led_strip_pre_cb);
    vesync_sdk_reg_post_run_cb(led_strip_app_run);

    vesync_sdk_run();
}
