/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
 * @file        vdrv_fm11nt081dx.c
 * @brief       复旦FM11NT081Dx芯片驱动接口实现
 * @date        2021-11-15
 */

#include "vdrv_fm11nt081dx.h"
#include "vdrv_fm11nt081dx_internal.h"
#include "vhal_gpio.h"
#include "vhal_i2c.h"
#include "vesync_common.h"
#include "vesync_log_internal.h"
#include "vesync_os.h"
#include <string.h>

//唤醒功能回调函数
static void (*wake_up_cb_func)(uint8_t) = NULL;

//可选功能配置
VDRV_NT081D_OP_FUNC optional_func_cfg = OP_FUNC_NONE;

//iic CS片选引脚
static uint8_t iic_cs_pin = 0;

//nfc无线端进场中断信号引脚
static uint8_t nfc_int_pin = 0;

//卡片初始化信息
static uint8_t format_data_03h[] = {0xE1, 0x10, 0x6F, 0x0};
static uint8_t format_data_04h[] = {0x01, 0x03, 0xE8, 0x0E};
static uint8_t format_data_05h[] = {0x66, 0x03, 0x00, 0xFE};

//卡片写数据接口
static uint32_t fm11_write_data(uint16_t addr, uint8_t *buf, uint16_t len);

/**
 * @brief fm11nc081dx卡片格式化，卡片被写坏时调用此接口格式化
*/
uint32_t vdrv_card_fromat(void)
{
    fm11_write_data(0x03 * 4, format_data_03h, sizeof(format_data_03h));
    fm11_write_data(0x04 * 4, format_data_04h, sizeof(format_data_04h));
    fm11_write_data(0x05 * 4, format_data_05h, sizeof(format_data_05h));
    return SDK_OK;
}

uint32_t vdrv_fm11nt081dx_init(uint8_t sda_io, uint8_t scl_io, uint8_t cs_pin)
{
    uint32_t ret = SDK_OK;
    vhal_gpio_config_t gpio_cfg;

    if (vhal_i2c_master_init(NFC_CFG_I2C_PORT, sda_io, scl_io, NFC_CFG_I2C_SPEED) == VHAL_FAIL)
    {
        SDK_LOG(LOG_ERROR, "i2c init error\n");
        ret = SDK_FAIL;
        return ret;
    }

    memset(&gpio_cfg, 0, sizeof(gpio_cfg));

    gpio_cfg.pin_bit_mask = (1ULL << cs_pin);
    gpio_cfg.mode = GPIO_MODE_OUT;
    gpio_cfg.pull_up_en = 1;
    gpio_cfg.pull_down_en = 0;
    gpio_cfg.intr_type = GPIO_INTR_DIS;

    iic_cs_pin = cs_pin;

    vhal_gpio_init(gpio_cfg);
    vhal_gpio_set_output(cs_pin, 1); //拉高iic片选信号

    return ret;
}

/**
 * @brief  读取nfc卡EEPROM中一块数据(16byte)
 * @param[in]  addr           [要读取的ee地址]
 * @param[in]  buf            [数据缓存指针]
 * @param[in]  read_len       [要读取的长度]
 * @return    uint32_t        [读取到的长度,0表示失败]
 */
static uint32_t fm11_read_block(uint16_t addr, uint8_t *buf, uint16_t read_len)
{
    uint32_t ret = SDK_OK;
    uint32_t len = 0;
    uint8_t addr_send[2] = {0};

    len = (read_len > FM11_E2_BLOCK_SIZE ? FM11_E2_BLOCK_SIZE : read_len); //每次最多读16byte

    addr_send[0] = (uint8_t)((addr & 0xff00) >> 8);
    addr_send[0] &= 0x03;
    addr_send[1] = (uint8_t)(addr & 0x00ff);

    if (vhal_i2c_master_write(NFC_CFG_I2C_PORT, true, NFC_CARD_ADDR_WRITE, addr_send, sizeof(addr_send)) == VHAL_FAIL)
    {
        SDK_LOG(LOG_DEBUG, "write addr error\n");
        return SDK_FAIL;
    }


    vesync_sleep(30); //写完马上读中间要延时30ms，不然会读失败

    if (vhal_i2c_master_read(NFC_CFG_I2C_PORT, true, NFC_CARD_ADDR_READ, buf, len) != VHAL_OK)
    {
        ret = SDK_FAIL;
        SDK_LOG(LOG_DEBUG, "read data error\r\n");
    }
    vesync_sleep(10);

    return ret;
}

/**
 * @brief 向fm11芯片读数据，不限制地址,内部接口
 * @param[in]  addr     [要读数据的EE地址]
 * @param[in]  buf      [数据缓存]
 * @param[in]  len      [要读的长度]
 * @return int          [成功：SDK_OK，失败：SDK_FAIL]
 */
static uint32_t fm11_read_data(uint16_t addr, uint8_t *buf, uint16_t len)
{
    uint16_t blk_cnt = 0;
    uint16_t i = 0;
    uint32_t ret = SDK_OK;
    uint16_t remain_len = 0;

    if (buf == NULL || len == 0)
    {
        return SDK_FAIL;
    }

    vhal_gpio_set_output(iic_cs_pin, 0);
    vesync_sleep(10);

    blk_cnt = len / FM11_E2_BLOCK_SIZE;

    if (blk_cnt > 0)
    {
        for (i = 0; i < blk_cnt; i++)
        {
            ret |= fm11_read_block(addr + i * FM11_E2_BLOCK_SIZE, buf + i * FM11_E2_BLOCK_SIZE, FM11_E2_BLOCK_SIZE);
        }
    }

    if (len % FM11_E2_BLOCK_SIZE)
    {
        remain_len = len % FM11_E2_BLOCK_SIZE;
        ret |= fm11_read_block(addr + blk_cnt * FM11_E2_BLOCK_SIZE, buf + blk_cnt * FM11_E2_BLOCK_SIZE, remain_len);
    }

    vhal_gpio_set_output(iic_cs_pin, 1);

    return ret;
}


/**
 * @brief  写一块数据(16byte)到fm11 nfc卡EEPROM中
 * @param[in]  addr           [ee地址]
 * @param[in]  buf            [数据缓存指针]
 * @param[in]  read_len       [要读取的长度]
 * @return    uint32_t        [读取到的长度,0表示失败]
 */
static uint32_t fm11_write_block(uint16_t addr, uint8_t *buf, uint16_t write_len)
{
    uint32_t ret = SDK_OK;
    int32_t len = 0;
    uint8_t addr_send[18] = {0};

    len = (write_len > FM11_E2_BLOCK_SIZE ? FM11_E2_BLOCK_SIZE : write_len); //每次最多读16byte

    addr_send[0] = (uint8_t)((addr & 0xff00) >> 8);
    addr_send[0] &= 0x03;

    addr_send[1] = (uint8_t)(addr & 0x00ff);

    memcpy(addr_send + 2, buf, len);

    if (vhal_i2c_master_write(NFC_CFG_I2C_PORT, true, NFC_CARD_ADDR_WRITE, addr_send, len + 2) != VHAL_OK)
    {
        ret = SDK_FAIL;
    }

    vesync_sleep(10);
    return ret;
}

/**
 * @brief 内部fm11芯片写数据接口，不限制地址，内部接口
 * @param[in]  addr     [要写数据的EE地址]
 * @param[in]  buf      [数据缓存]
 * @param[in]  len      [数据长度]
 * @return int          [成功：SDK_OK，失败：SDK_FAIL]
 */
static uint32_t fm11_write_data(uint16_t addr, uint8_t *buf, uint16_t len)
{
    uint16_t blk_cnt = 0;
    uint16_t i = 0;
    uint32_t ret = SDK_OK;
    uint16_t remain_len = 0;

    uint16_t offset = 0;
    uint16_t block_write_len = 0;
    uint16_t block_write_addr = 0;
    uint8_t *blcok_buf = NULL;

    if (buf == NULL || len == 0)
    {
        return SDK_FAIL;
    }

    vhal_gpio_set_output(iic_cs_pin, 0);
    vesync_sleep(10);

    if (addr % FM11_E2_BLOCK_SIZE) //不能被16整除的地址先把零碎部分写进去
    {
        offset = FM11_E2_BLOCK_SIZE - (addr % FM11_E2_BLOCK_SIZE);

        if (len > offset)
        {
            ret = fm11_write_block(addr, buf, offset);
            if (ret == SDK_FAIL)
            {
                return ret;
            }

            block_write_len = len - offset;
            block_write_addr = addr + offset;
            blcok_buf = buf + offset;
        }
        else
        {
            block_write_len = len;
            block_write_addr = addr;
            blcok_buf = buf;
        }
    }
    else
    {
        block_write_len = len;
        block_write_addr = addr;
        blcok_buf = buf;
    }

    if (block_write_len > 0) //能被16整除的地址一块一块整的写
    {
        blk_cnt = block_write_len / FM11_E2_BLOCK_SIZE;

        if (blk_cnt > 0)
        {
            for (i = 0; i < blk_cnt; i++)
            {
                ret |= fm11_write_block(block_write_addr + i * FM11_E2_BLOCK_SIZE, blcok_buf + i * FM11_E2_BLOCK_SIZE, FM11_E2_BLOCK_SIZE);
            }
        }

        if (block_write_len % FM11_E2_BLOCK_SIZE)
        {
            remain_len = block_write_len % FM11_E2_BLOCK_SIZE;
            ret |= fm11_write_block(block_write_addr + blk_cnt * FM11_E2_BLOCK_SIZE, blcok_buf + blk_cnt * FM11_E2_BLOCK_SIZE, remain_len);
        }
    }

    vhal_gpio_set_output(iic_cs_pin, 1);

    return ret;
}


uint32_t vdrv_fm11nt081dx_set_auth_pwd(bool pwd_en, uint32_t pwd, uint16_t pwd_ack)
{
    return SDK_OK;
}


uint32_t vdrv_fm11nt081dx_lock_pwd(bool enable)
{
    return SDK_OK;
}


uint32_t vdrv_fm11nt081dx_set_auth_level(uint8_t level)
{
    return SDK_OK;
}


uint32_t vdrv_fm11nt081dx_set_auth_error_cnt(AUTH_ERROR_CNT_E auth_limit)
{
    return SDK_OK;
}


uint32_t vdrv_fm11nt081dx_set_wakeup(bool enable)
{
    if ((optional_func_cfg == OP_FUNC_NONE) && (enable == 1))
    {
        optional_func_cfg = OP_FUNC_WAKEUP;
        SDK_LOG(LOG_DEBUG, "set option =%d\n", optional_func_cfg);
    }
    return SDK_OK;
}


uint32_t vdrv_fm11nt081dx_set_sleep_en(bool sleep_enable)
{
    if (sleep_enable == true)
    {
        vhal_gpio_set_output(nfc_int_pin, 0);
    }
    else
    {
        vhal_gpio_set_output(nfc_int_pin, 1);
    }
    return SDK_OK;
}


uint32_t vdrv_fm11nt081dx_init_sleep(bool sleep_enable, uint32_t pin_num)
{
    vhal_gpio_config_t gpio_cfg;
    uint8_t dfp_mirror_cfg = 0;
    uint32_t ret = SDK_FAIL;

    if ((optional_func_cfg == OP_FUNC_NONE) && (sleep_enable == 1)) //没有初始化成唤醒功能才能初始化睡眠功能
    {
        nfc_int_pin = pin_num;
        optional_func_cfg = OP_FUNC_SLEEP;
        gpio_cfg.pin_bit_mask = (1ULL << nfc_int_pin);
        gpio_cfg.mode = GPIO_MODE_OUT;
        gpio_cfg.pull_up_en = 0;
        gpio_cfg.pull_down_en = 0;
        gpio_cfg.intr_type = GPIO_INTR_DIS;

        vhal_gpio_init(gpio_cfg);
        vhal_gpio_set_output(nfc_int_pin, 0);

        ret |= fm11_read_data(FM11_FDP_MIRROR_ADDR, &dfp_mirror_cfg, 1);

        dfp_mirror_cfg = FDP_MIRROR_SLEEP_EN_BIT_MASK | dfp_mirror_cfg;

        ret |= fm11_write_data(FM11_FDP_MIRROR_ADDR, &dfp_mirror_cfg, 1);
    }

    return ret;
}


uint32_t vdrv_fm11nt081dx_set_wake_mode(uint8_t mode)
{
    return SDK_OK;
}

/**
 * @brief NFC 卡唤醒回调函数定义
 */
void nfc_rf_wake_up_func(void *args)
{

    if (wake_up_cb_func)
    {
        wake_up_cb_func(nfc_int_pin);
    }
}


uint32_t vdrv_fm11nt081dx_register_wake_cb(void (*wake_up_cb)(uint8_t), uint8_t int_pin_num)
{
    vhal_gpio_config_t gpio_cfg;

    if (optional_func_cfg == OP_FUNC_WAKEUP)
    {
        SDK_LOG(LOG_DEBUG, "register wake cb pin= %d \n", int_pin_num);
        nfc_int_pin = int_pin_num;
        gpio_cfg.pin_bit_mask = (1ULL << int_pin_num);
        gpio_cfg.mode = GPIO_MODE_IN;
        gpio_cfg.pull_up_en = 1;
        gpio_cfg.pull_down_en = 0;
        gpio_cfg.intr_type = GPIO_INTR_NEG_EDGE;

        vhal_gpio_init(gpio_cfg);
        vhal_gpio_register_intr_cb(int_pin_num, GPIO_INTR_ANY_EDGE, nfc_rf_wake_up_func, (void *)int_pin_num);
        wake_up_cb_func = wake_up_cb;
        return SDK_OK;
    }
    else
    {
        SDK_LOG(LOG_DEBUG, "not register\n");
    }
    return SDK_FAIL;
}

uint32_t vdrv_fm11nt081dx_write_data(uint16_t addr, uint8_t *buf, uint16_t len)
{
    if (addr < FM11_E2_USER_DATA_ADDR || addr > FM11_E2_SYS_CFG_ADDR || buf == NULL || len == 0) //对EEPROM地址进行判断
    {
        return SDK_FAIL;
    }

    return fm11_write_data(addr, buf, len);
}

uint32_t vdrv_fm11nt081dx_read_data(uint16_t addr, uint8_t *buf, uint16_t len)
{

    if (addr < FM11_E2_USER_DATA_ADDR || addr > FM11_E2_SYS_CFG_ADDR || buf == NULL || len == 0) //对EEPROM地址进行判断
    {
        SDK_LOG(LOG_ERROR, "para error\n");
        return SDK_FAIL;
    }
    return fm11_read_data(addr, buf, len);
}

uint32_t vdrv_fm11nt081dx_get_uid(uint8_t *uid, uint8_t len)
{
    if ((len < FM11_UID_LEN) || (uid == NULL))
    {
        return SDK_FAIL;
    }
    memset(uid, 0, len);
    return fm11_read_data(FM11_UID_ADDR, uid, FM11_UID_LEN);
}

uint32_t vdrv_fm11nt081dx_disable_rfid(bool if_disable)
{
    if (if_disable == 1)
    {
        vhal_gpio_set_output(nfc_int_pin, 0);
    }
    else
    {
        vhal_gpio_set_output(nfc_int_pin, 1);
    }
    return SDK_OK;
}
