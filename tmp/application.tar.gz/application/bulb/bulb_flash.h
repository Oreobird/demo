/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        bulb_flash.h
 * @brief       灯泡数据的flash写入
 * @author      Dave
 * @date        2021-09-02
 */

#include"bulb.h"

#ifndef __BULB_FLASH_H__
#define __BULB_FLASH_H__

#ifdef __cplusplus
extern "C" {
#endif

#define BULB_USER_CFG_KEY_DATA "bulb"   // NVS采用key:value格式进行存储
#define BULB_KLV_DATA_LEN (60)

/*
 * @brief 配置数据key 定义
 */
typedef enum
{
    BULB_KEY_VERSION = 0,         // 版本
    BULB_KEY_ONOFF = 1,           // 开关机
    BULB_KEY_COLOR_MODE,          // 色彩模式
    BULB_KEY_COLOR_TEMP,          // 色温
    BULB_KEY_COLOR_BRIGHT,        // 亮度
    BULB_KEY_COLOR_HUE,
    BULB_KEY_COLOR_SATURATION,
    BULB_KEY_COLOR_VALUE,
    BULB_KEY_POWERNUM,
    BULB_KEY_INIT_FLAG,
    BULB_KEY_AGING_TEST,
    BULB_KEY_AGING_TEST_TIME,
    BULB_KEY_MAX,
}BULB_CFG_KEY_E;


/*
 * @brief 灯泡配置标识符
 */
typedef enum
{
    BULB_CFG_ONOFF = 0,             // 标识bulb_flash_data_t中的bulb_onoff
    BULB_CFG_COLOR_MODE,            // 标识bulb_flash_data_t中的bulb_color_mode
    BULB_CFG_COLOR_TEMP,            // 标识bulb_flash_data_t中的bulb_color_temp
    BULB_CFG_COLOR_BRIGHT,          // 标识bulb_flash_data_t中的bulb_color_bright
    BULB_CFG_COLOR_HUE,             // 标识bulb_flash_data_t中的bulb_color_hue
    BULB_CFG_COLOR_SATURATION,      // 标识bulb_flash_data_t中的bulb_color_saturastion
    BULB_CFG_COLOR_VALUE,           // 标识bulb_flash_data_t中的bulb_color_value
    BULB_CFG_POWERNUM,
    BULB_CFG_INIT_FLAG,
    BULB_CFG_AGING_TEST,
    BULB_CFG_AGING_TEST_TIME,
    BULB_CFG_UNKNOW,                // 未知
} BULB_CFG_FLAG_E;


/*
* @brief 灯泡存储的flash数据
*/
typedef struct
{
    uint8_t bulb_aging_test_time;     // 老化测试时长记录
    uint8_t bulb_aging_test;          // 老化标识
    uint8_t bulb_onoff;               // 开关状态，1为开启，0为关闭
    uint8_t bulb_color_mode;          // 灯泡的色彩模式，0为白光，1为彩光
    uint8_t bulb_color_temp;          // 白光模式下的色温
    uint8_t bulb_color_bright;        // 白光模式下的亮度
    uint16_t bulb_color_hue;          // 彩光模式下的色相
    uint16_t bulb_color_saturation;      // 彩光模式下的饱和度
    uint8_t bulb_color_value;         // 彩光模式下的明度
    uint8_t bulb_powernum;            // 设备上电计次
    uint8_t bulb_init_flag;           // 成功从flash中读取到数据，该标志位置位1，默认为0
} bulb_flash_data_t;

/**
* @brief 获取灯泡的配置
* @param[in]  BULB_CFG_FLAG_E    [标识符]
* @return     uint8_t              [配置值]
*/
int bulb_get_config(BULB_CFG_FLAG_E flag);

/**
* @brief 更新灯泡的配置
* @param[in]  BULB_CFG_FLAG_E    [标识符]
* @param[in]  uint8_t              [配置值]
* @return     int8_t               [成功/失败]
*/
int8_t bulb_update_config(BULB_CFG_FLAG_E flag, int val);

/**
* @brief 从flash加载灯泡配置
* @param[in]  BULB_ACT_SRC_E         [动作来源]
* @return void
*/
void bulb_load_config(BULB_ACT_SRC_E src);

/**
* @brief 清除灯泡配置
* @param void
* @return int
*/
int bulb_reset_config(void);

/**
* @brief 保存灯泡数据到flash
* @param[in]  bulb_flash_data_t  [灯泡配置]
* @return     int8_t               [成功：APP_OK， 失败：APP_FAIL]
*/
int8_t bulb_save_config(bulb_flash_data_t data);

/**
 * @brief 将内存配置重新写入flash
 * @return     int8_t               [成功：APP_OK， 失败：APP_FAIL]
 */
int bulb_resave_config(void);

#ifdef __cplusplus
}
#endif

#endif

