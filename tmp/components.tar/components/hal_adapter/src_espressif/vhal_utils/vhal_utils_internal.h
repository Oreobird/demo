/**
 *  Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vhal_utils_internal.h
 * @brief       厂家乐鑫 SDK提供的通用接口封装
 * @author      Joshua
 * @date        2021-05-25
 */

#ifndef _VHAL_UTILS_INTERNAL_H_
#define _VHAL_UTILS_INTERNAL_H_


#include "vhal_utils.h"

#ifdef __cplusplus
extern "C"
{
#endif

#define SNTP_SERVER_ADDR        "ntp.vesync.com"
// #define SNTP_SERVER_ADDR     "pool.ntp.org"
// #define SNTP_SERVER_ADDR     "time.windows.com"

#ifdef __cplusplus
}
#endif

#endif /* _VHAL_UTILS_INTERNAL_H_ */

