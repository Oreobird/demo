/**
 * Copyright © Vesync Technologies Co.Ltd. 2019-2021. All rights reserved.
 * @file    vesync_pb2json_reverse.c
 * @brief   Protobuf与JSON互转接口实现
 * @author  Herve Lin
 * @date    2021-12-13
 */

#include <string.h>
#include <stdio.h>
#include <assert.h>

#include "vesync_memory.h"
#include "vesync_common.h"

#include "vesync_pb2json_internal.h"
#include "vesync_log_internal.h"

/**
 * @brief 获取Protobuf类型的名称
 * @param[in] type          [Protobuf类型枚举]
 * @return const char*      [Protobuf类型名称的应用]
 */
static const char *json2protobuf_integer_name_by_c_type(ProtobufCType type)
{
    switch (type)
    {
    case PROTOBUF_C_TYPE_INT32:
        return "int32";
    case PROTOBUF_C_TYPE_SINT32:
        return "sint32";
    case PROTOBUF_C_TYPE_SFIXED32:
        return "sfixed32";
    case PROTOBUF_C_TYPE_UINT32:
        return "uint32";
    case PROTOBUF_C_TYPE_FIXED32:
        return "fixed32";
    case PROTOBUF_C_TYPE_INT64:
        return "int64";
    case PROTOBUF_C_TYPE_SINT64:
        return "sint64";
    case PROTOBUF_C_TYPE_SFIXED64:
        return "sfixed64";
    case PROTOBUF_C_TYPE_UINT64:
        return "uint64";
    case PROTOBUF_C_TYPE_FIXED64:
        return "fixed64";
    default:
        assert(0);
        return "unknown";
    }
}

/**
 * @brief JSON转Protobuf的Message处理方法（提前声明）
 * @param[in]   flag                        [功能选项]
 * @param[in]   json_object                 [指向输入的JSON对象]
 * @param[in]   protobuf_message_descriptor [指向输出Protobuf的描述符]
 * @param[out]  protobuf_message            [指向输出Protobuf的引用]
 * @return      int                         [PROTOBUF2JSON_ERR_E]
 */
static int json2protobuf_process_message(proc_flag_t flag, cJSON *json_object, const ProtobufCMessageDescriptor *protobuf_message_descriptor, ProtobufCMessage **protobuf_message);

/**
 * @brief JSON转Protobuf的Field处理方法
 * @param[in]   flag                        [功能选项]
 * @param[in]   field_descriptor            [指向Protobuf Field域描述符]
 * @param[in]   json_value                  [指向输入的JSON对象]
 * @param[out]  protobuf_value              [指向输出Protobuf的引用]
 * @return      int                         [PROTOBUF2JSON_ERR_E]
 */
static int json2protobuf_process_field(proc_flag_t flag, const ProtobufCFieldDescriptor *field_descriptor, cJSON *json_value, void *protobuf_value)
{
    if ((PROTOBUF_C_TYPE_INT32 == field_descriptor->type) || (PROTOBUF_C_TYPE_SINT32 == field_descriptor->type) || (PROTOBUF_C_TYPE_SFIXED32 == field_descriptor->type))
    {
        if (false == cJSON_IsNumber(json_value))
        {
            PB2JSON_LOG(LOG_DEBUG, "JSON value isn't an integer required for GPB %s\n", json2protobuf_integer_name_by_c_type(field_descriptor->type));
            return PROTOBUF2JSON_ERR_IS_NOT_INTEGER;
        }

        int32_t value_int32_t = (int32_t)(json_value->valueint);
        memcpy(protobuf_value, &value_int32_t, sizeof(value_int32_t));
    }
    else if ((PROTOBUF_C_TYPE_UINT32 == field_descriptor->type) || (PROTOBUF_C_TYPE_FIXED32 == field_descriptor->type))
    {
        if (false == cJSON_IsNumber(json_value))
        {
            PB2JSON_LOG(LOG_DEBUG, "JSON value isn't an integer required for GPB %s\n", json2protobuf_integer_name_by_c_type(field_descriptor->type));
            return PROTOBUF2JSON_ERR_IS_NOT_INTEGER;
        }

        uint32_t value_uint32_t = (uint32_t)(json_value->valueint);
        memcpy(protobuf_value, &value_uint32_t, sizeof(value_uint32_t));
    }
    else if ((PROTOBUF_C_TYPE_INT64 == field_descriptor->type) || (PROTOBUF_C_TYPE_SINT64 == field_descriptor->type) || (PROTOBUF_C_TYPE_SFIXED64 == field_descriptor->type))
    {
        if (false == cJSON_IsNumber(json_value))
        {
            PB2JSON_LOG(LOG_DEBUG, "JSON value isn't an integer required for GPB %s\n", json2protobuf_integer_name_by_c_type(field_descriptor->type));
            return PROTOBUF2JSON_ERR_IS_NOT_INTEGER;
        }

        int64_t value_int64_t = (int64_t)(json_value->valuedouble);
        memcpy(protobuf_value, &value_int64_t, sizeof(value_int64_t));
    }
    else if ((PROTOBUF_C_TYPE_UINT64 == field_descriptor->type) || (PROTOBUF_C_TYPE_FIXED64 == field_descriptor->type))
    {
        if (false == cJSON_IsNumber(json_value))
        {
            PB2JSON_LOG(LOG_DEBUG, "JSON value isn't an integer required for GPB %s\n", json2protobuf_integer_name_by_c_type(field_descriptor->type));
            return PROTOBUF2JSON_ERR_IS_NOT_INTEGER;
        }

        uint64_t value_uint64_t = (uint64_t)(json_value->valuedouble);
        memcpy(protobuf_value, &value_uint64_t, sizeof(value_uint64_t));
    }
    else if (PROTOBUF_C_TYPE_FLOAT == field_descriptor->type)
    {
        if (false == cJSON_IsNumber(json_value))
        {
            PB2JSON_LOG(LOG_DEBUG, "JSON value isn't a integer/real required for GPB float\n");
            return PROTOBUF2JSON_ERR_IS_NOT_INTEGER_OR_REAL;
        }

        float value_float = (float)(json_value->valuedouble);
        memcpy(protobuf_value, &value_float, sizeof(value_float));
    }
    else if (PROTOBUF_C_TYPE_DOUBLE == field_descriptor->type)
    {
        if (false == cJSON_IsNumber(json_value))
        {
            PB2JSON_LOG(LOG_DEBUG, "JSON value isn't a integer/real required for GPB double\n");
            return PROTOBUF2JSON_ERR_IS_NOT_INTEGER_OR_REAL;
        }

        double value_double = (double)(json_value->valuedouble);
        memcpy(protobuf_value, &value_double, sizeof(value_double));
    }
    else if (PROTOBUF_C_TYPE_BOOL == field_descriptor->type)
    {
        protobuf_c_boolean value_boolean;
        if (flag & PROC_FLAG_NUMBERIC_BOOL)
        {
            if (false == cJSON_IsNumber(json_value))
            {
                PB2JSON_LOG(LOG_DEBUG, "JSON value isn't a integer required for GPB bool\n");
                return PROTOBUF2JSON_ERR_IS_NOT_NUMBERIC_BOOLEAN;
            }
            value_boolean = (protobuf_c_boolean)((json_value->valueint != 0) ? PB_TRUE : PB_FALSE);
        }
        else
        {
            if (false == cJSON_IsBool(json_value))
            {
                PB2JSON_LOG(LOG_DEBUG, "JSON value isn't a boolean required for GPB bool\n");
                return PROTOBUF2JSON_ERR_IS_NOT_BOOLEAN;
            }
            value_boolean = (protobuf_c_boolean)(cJSON_IsTrue(json_value) ? PB_TRUE : PB_FALSE);
        }
        memcpy(protobuf_value, &value_boolean, sizeof(value_boolean));
    }
    else if (PROTOBUF_C_TYPE_ENUM == field_descriptor->type)
    {
        const ProtobufCEnumValue *enum_value;
        if (flag & PROC_FLAG_NUMBERIC_ENUM)
        {
            if (false == cJSON_IsNumber(json_value))
            {
                PB2JSON_LOG(LOG_DEBUG, "JSON value isn't a integer required for GPB enum\n");
                return PROTOBUF2JSON_ERR_IS_NOT_STRING;
            }
            enum_value = protobuf_c_enum_descriptor_get_value(field_descriptor->descriptor, (int)json_value->valueint);
            if (NULL == enum_value)
            {
                PB2JSON_LOG(LOG_DEBUG, "unknown value '%d' for enum '%s'\n", json_value->valueint, ((ProtobufCEnumDescriptor *)field_descriptor->descriptor)->name);
                return PROTOBUF2JSON_ERR_UNKNOWN_ENUM_VALUE;
            }
        }
        else
        {
            if (false == cJSON_IsString(json_value))
            {
                PB2JSON_LOG(LOG_DEBUG, "JSON value isn't a string required for GPB enum\n");
                return PROTOBUF2JSON_ERR_IS_NOT_STRING;
            }
            const char *enum_value_name = cJSON_GetStringValue(json_value);
            enum_value = protobuf_c_enum_descriptor_get_value_by_name(field_descriptor->descriptor, enum_value_name);
            if (NULL == enum_value)
            {
                PB2JSON_LOG(LOG_DEBUG, "unknown value '%s' for enum '%s'\n", enum_value_name, ((ProtobufCEnumDescriptor *)field_descriptor->descriptor)->name);
                return PROTOBUF2JSON_ERR_UNKNOWN_ENUM_VALUE;
            }
        }
        int32_t value_enum = (int32_t)enum_value->value;
        memcpy(protobuf_value, &value_enum, sizeof(value_enum));
    }
    else if (PROTOBUF_C_TYPE_STRING == field_descriptor->type)
    {
        if (false == cJSON_IsString(json_value))
        {
            PB2JSON_LOG(LOG_DEBUG, "JSON value isn't a string required for GPB string\n");
            return PROTOBUF2JSON_ERR_IS_NOT_STRING;
        }

        const char *value_string = cJSON_GetStringValue(json_value);
        size_t value_string_length = strlen(value_string);

        char *value_string_copy = vesync_calloc(value_string_length + 1, sizeof(char));
        if (NULL == value_string_copy)
        {
            PB2JSON_LOG(LOG_ERROR, "cannot allocate %zu bytes\n", (value_string_length + 1) * sizeof(char));
            return PROTOBUF2JSON_ERR_CANNOT_ALLOCATE_MEMORY;
        }

        memcpy(value_string_copy, value_string, value_string_length + 1);
        *(char **)(protobuf_value) = value_string_copy;
    }
    else if (PROTOBUF_C_TYPE_BYTES == field_descriptor->type)
    {
        if (false == cJSON_IsString(json_value))
        {
            PB2JSON_LOG(LOG_DEBUG, "JSON value isn't a string required for GPB bytes\n");
            return PROTOBUF2JSON_ERR_IS_NOT_STRING;
        }

        const char *value_string = cJSON_GetStringValue(json_value);
        size_t value_string_length = strlen(value_string);

        int base64_decoded_length = BASE64_DECODED_LEN(value_string_length);
        char *base64_decoded_data = vesync_calloc(base64_decoded_length, sizeof(char));
        if (NULL == base64_decoded_data)
        {
            PB2JSON_LOG(LOG_ERROR, "cannot allocate %zu bytes\n", base64_decoded_length * sizeof(char));
            return PROTOBUF2JSON_ERR_CANNOT_ALLOCATE_MEMORY;
        }

        /// @todo: check for zero length / error
        base64_decoded_length = base64_decode(base64_decoded_data, value_string, value_string_length);

        char *value_string_copy = vesync_calloc(base64_decoded_length, sizeof(char));
        if (NULL == value_string_copy)
        {
            PB2JSON_LOG(LOG_ERROR, "cannot allocate %zu bytes\n", base64_decoded_length * sizeof(char));
            return PROTOBUF2JSON_ERR_CANNOT_ALLOCATE_MEMORY;
        }

        memcpy(value_string_copy, base64_decoded_data, base64_decoded_length);
        vesync_free(base64_decoded_data);

        ProtobufCBinaryData value_binary = {
            data : (uint8_t *)value_string_copy,
            len : base64_decoded_length,
        };
        memcpy(protobuf_value, &value_binary, sizeof(value_binary));
    }
    else if (PROTOBUF_C_TYPE_MESSAGE == field_descriptor->type)
    {
        ProtobufCMessage *protobuf_message;
        int ret = json2protobuf_process_message(flag, json_value, field_descriptor->descriptor, &protobuf_message);
        if (ret != PROTOBUF2JSON_ERR_OK)
        {
            return ret;
        }
        memcpy(protobuf_value, &protobuf_message, sizeof(protobuf_message));
    }
    else
    {
        return PROTOBUF2JSON_ERR_INVALID_FIELD_TYPE;
    }

    return PROTOBUF2JSON_ERR_OK;
}

static int json2protobuf_process_message(proc_flag_t flag, cJSON *json_object, const ProtobufCMessageDescriptor *protobuf_message_descriptor, ProtobufCMessage **protobuf_message)
{
    bitmap_t presented_fields = NULL;

    if (false == cJSON_IsObject(json_object))
    {
        PB2JSON_LOG(LOG_DEBUG, "JSON isn't an object required for GPB message\n");
        return PROTOBUF2JSON_ERR_IS_NOT_OBJECT;
    }

    *protobuf_message = vesync_calloc(1, protobuf_message_descriptor->sizeof_message);
    if (NULL == *protobuf_message)
    {
        PB2JSON_LOG(LOG_ERROR, "cannot allocate %zu bytes\n", protobuf_message_descriptor->sizeof_message);
        return PROTOBUF2JSON_ERR_CANNOT_ALLOCATE_MEMORY;
    }

    protobuf_c_message_init(protobuf_message_descriptor, *protobuf_message);
    presented_fields = bitmap_alloc(protobuf_message_descriptor->n_fields);
    if (NULL == presented_fields)
    {
        SAFE_FREE_BITMAP_AND_MESSAGE();
        PB2JSON_LOG(LOG_ERROR, "cannot allocate bitmap object\n");
        return PROTOBUF2JSON_ERR_CANNOT_ALLOCATE_MEMORY;
    }

    cJSON *json_iter = NULL;
    cJSON_ArrayForEach(json_iter, json_object)
    {
        const char *json_key = json_iter->string;

        const ProtobufCFieldDescriptor *field_descriptor = protobuf_c_message_descriptor_get_field_by_name(protobuf_message_descriptor, json_key);
        if (NULL == field_descriptor)
        {
            if (flag & PROC_FLAG_IGNORE_UNKNOWN_FIELD)
            {
                continue;
            }
#if 0
            PB2JSON_LOG(LOG_DEBUG, "unknown field '%s' for message '%s'\n", json_key, protobuf_message_descriptor->name);
#else
            PB2JSON_LOG(LOG_DEBUG, "unknown field '%s'\n", json_key);
#endif
            SAFE_FREE_BITMAP_AND_MESSAGE();
            return PROTOBUF2JSON_ERR_UNKNOWN_FIELD;
        }

        unsigned int field_number = field_descriptor - protobuf_message_descriptor->fields;

        if (0 != bitmap_get(presented_fields, field_number))
        {
            SAFE_FREE_BITMAP_AND_MESSAGE();
#if 0
            PB2JSON_LOG(LOG_DEBUG, "duplicate field '%s' for message '%s'\n", json_key, protobuf_message_descriptor->name);
#else
            PB2JSON_LOG(LOG_DEBUG, "duplicate field '%s'\n", json_key);
#endif
            return PROTOBUF2JSON_ERR_DUPLICATE_FIELD;
        }
        bitmap_set(presented_fields, field_number);

        void *protobuf_value = ((char *)*protobuf_message) + field_descriptor->offset;
        void *protobuf_value_quantifier = ((char *)*protobuf_message) + field_descriptor->quantifier_offset;

        if (field_descriptor->flags & PROTOBUF_C_FIELD_FLAG_ONEOF)
        {
            uint32_t *oneof_case = (uint32_t *)protobuf_value_quantifier;
            *oneof_case = field_descriptor->id;
        }

        if (PROTOBUF_C_LABEL_REQUIRED == field_descriptor->label)
        {
            int ret = json2protobuf_process_field(flag, field_descriptor, json_iter, protobuf_value);
            if (ret != PROTOBUF2JSON_ERR_OK)
            {
                SAFE_FREE_BITMAP_AND_MESSAGE();
                return ret;
            }
        }
        else if (PROTOBUF_C_LABEL_OPTIONAL == field_descriptor->label)
        {
            if ((field_descriptor->type != PROTOBUF_C_TYPE_MESSAGE) && (field_descriptor->type != PROTOBUF_C_TYPE_STRING) && (!(field_descriptor->flags & PROTOBUF_C_FIELD_FLAG_ONEOF)))
            {
                protobuf_c_boolean *has_member = (protobuf_c_boolean *)protobuf_value_quantifier;
                *has_member = PB_TRUE;
            }

            int ret = json2protobuf_process_field(flag, field_descriptor, json_iter, protobuf_value);
            if (ret != PROTOBUF2JSON_ERR_OK)
            {
                SAFE_FREE_BITMAP_AND_MESSAGE();
                return ret;
            }
        }
        else if (PROTOBUF_C_LABEL_NONE == field_descriptor->label)
        {
            int ret = json2protobuf_process_field(flag, field_descriptor, json_iter, protobuf_value);
            if (ret != PROTOBUF2JSON_ERR_OK)
            {
                SAFE_FREE_BITMAP_AND_MESSAGE();
                return ret;
            }
        }
        else // PROTOBUF_C_LABEL_REPEATED
        {
            if (false == cJSON_IsArray(json_iter))
            {
                SAFE_FREE_BITMAP_AND_MESSAGE();
                PB2JSON_LOG(LOG_DEBUG, "JSON isn't an array required for repeatable GPB field\n");
                return PROTOBUF2JSON_ERR_IS_NOT_ARRAY;
            }

            size_t *protobuf_values_count = (size_t *)protobuf_value_quantifier;

            *protobuf_values_count = cJSON_GetArraySize(json_iter);
            if (*protobuf_values_count > 0)
            {
                size_t value_size = protobuf2json_value_size_by_type(field_descriptor->type);
                if (0 == value_size)
                {
                    SAFE_FREE_BITMAP_AND_MESSAGE();
                    PB2JSON_LOG(LOG_ERROR, "cannot calculate value size for %d\n", field_descriptor->type);
                    return PROTOBUF2JSON_ERR_UNSUPPORTED_FIELD_TYPE;
                }

                void *protobuf_value_repeated = vesync_calloc(*protobuf_values_count, value_size);
                if (NULL == protobuf_value_repeated)
                {
                    SAFE_FREE_BITMAP_AND_MESSAGE();
                    PB2JSON_LOG(LOG_ERROR, "cannot allocate %zu bytes\n", (size_t)*protobuf_values_count * value_size);
                    return PROTOBUF2JSON_ERR_CANNOT_ALLOCATE_MEMORY;
                }

                size_t json_index = 0;
                cJSON *json_array_iter = NULL;
                cJSON_ArrayForEach(json_array_iter, json_iter)
                {
                    char *protobuf_value_repeated_value = (char *)protobuf_value_repeated + json_index * value_size;

                    int ret = json2protobuf_process_field(flag, field_descriptor, json_array_iter, (void *)protobuf_value_repeated_value);
                    if (ret != PROTOBUF2JSON_ERR_OK)
                    {
                        if (PROTOBUF_C_TYPE_STRING == field_descriptor->type)
                        {
                            for (size_t t = 0; t <= json_index; t++)
                            {
                                vesync_free(((char **)protobuf_value_repeated)[t]);
                            }
                        }
                        else if (PROTOBUF_C_TYPE_BYTES == field_descriptor->type)
                        {
                            for (size_t t = 0; t <= json_index; t++)
                            {
                                vesync_free(((ProtobufCBinaryData *)protobuf_value_repeated)[t].data);
                            }
                        }
                        else if (PROTOBUF_C_TYPE_MESSAGE == field_descriptor->type)
                        {
                            for (size_t t = 0; t <= json_index; t++)
                            {
                                if (NULL != ((ProtobufCMessage **)protobuf_value_repeated)[t])
                                {
                                    protobuf_c_message_free_unpacked(((ProtobufCMessage **)protobuf_value_repeated)[t], NULL);
                                }
                            }
                        }
                        vesync_free(protobuf_value_repeated);
                        *protobuf_values_count = 0;
                        SAFE_FREE_BITMAP_AND_MESSAGE();
                        return ret;
                    }
                    json_index++;
                }

                memcpy(protobuf_value, &protobuf_value_repeated, sizeof(protobuf_value_repeated));
            }
        }
    }

    for (unsigned int i = 0; i < protobuf_message_descriptor->n_fields; i++)
    {
        const ProtobufCFieldDescriptor *field_descriptor = protobuf_message_descriptor->fields + i;
        if ((PROTOBUF_C_LABEL_REQUIRED == field_descriptor->label) && (NULL == field_descriptor->default_value) && (0 == bitmap_get(presented_fields, i)))
        {
            SAFE_FREE_BITMAP_AND_MESSAGE();
#if 0
            PB2JSON_LOG(LOG_DEBUG, "required field '%s' is missing in message '%s'\n", field_descriptor->name, protobuf_message_descriptor->name);
#else
            PB2JSON_LOG(LOG_DEBUG, "required field '%s' is missing\n", field_descriptor->name);
#endif
            return PROTOBUF2JSON_ERR_REQUIRED_IS_MISSING;
        }
    }

    bitmap_free(presented_fields);
    return PROTOBUF2JSON_ERR_OK;
}

int vesync_json2pb(proc_flag_t flag, cJSON *p_json, const ProtobufCMessageDescriptor *p_pb_msg_desc, ProtobufCMessage **p_pb_msg_ref)
{
    UNUSED(flag);

    int ret = json2protobuf_process_message(flag, p_json, p_pb_msg_desc, p_pb_msg_ref);
    if (ret != PROTOBUF2JSON_ERR_OK)
    {
        return ret;
    }

    return PROTOBUF2JSON_ERR_OK;
}
