/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_bypass_notify_device.c
 * @brief       bypass处理接口
 * @date        2021-05-17
 */
#include <string.h>

#include "vesync_common.h"
#include "vesync_memory.h"

#include "vesync_bypass_internal.h"

/**
 * @brief 通知设备(APP/云通知设备进行特殊设置)
 * @param p_trace_msg trace message
 * @param json数据指针
 * @return bypass_err_t
 */
static BYPASS_ERR_E bypass_method_notify_device_handle(bypass_trace_msg_t *p_trace_msg, cJSON *json)
{
    BYPASS_ERR_E ret = BP_OK;
    cJSON* json_data = NULL;

    if ((NULL == json) || (NULL == p_trace_msg))
        return BP_ERROR;

    json_data = cJSON_GetObjectItemCaseSensitive(json, "type");
    if (cJSON_IsString(json_data))
    {
        if (0 == strcmp(json_data->valuestring, "FFSSetupSuccess"))
        {
            //vesync_device_notify_ffs_succ("NULL");    // TODO:下发命令需要传递account_id，保存到flash
        }
        else
        {
            ret = BP_ERR_ARG;
        }
    }
    else
    {
        ret = BP_ERR_ARG;
    }

    return ret;
}

static bypass_item_data_t notify_device_method_tbl[] = {
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_NOTIFY_DEVICE, "notifyDevice", bypass_method_notify_device_handle, NULL},
};

void vesync_bypass_notify_device_init(void)
{
    for (int i = 0; i < SIZEOF_ARRAY(notify_device_method_tbl); i++)
    {
        bypass_item_t *item = vesync_bypass_init_item(&notify_device_method_tbl[i]);
        if (item != NULL)
        {
            vesync_bypass_add_item(item);
        }
    }
}
