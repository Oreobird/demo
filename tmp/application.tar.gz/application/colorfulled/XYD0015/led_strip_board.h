/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        led_strip_board.h
 * @brief       led strip板级硬件配置
 * @author      Henrik
 * @date        2021-09-29
 */
#ifndef __LED_STRIP_BOARD__
#define __LED_STRIP_BOARD__

#include "vhal_led.h"
#include "vesync_task.h"

#ifdef __cplusplus
extern "C" {
#endif
#define   RMT_TX_CHANNEL        (0)
#define   LED_CTRL_IO           (9)
#define   ADC_CHANNEL           (1)
#define   WHITE_LED_CHANNEL     (LED_CH0)
#define   WHITE_LED_NUM         (3)
#define   POWER_IO_NUM          (6)

#define   AUDIO_SAMPLE          (16000)
#define   N_SAMPLES             (1024)
#define   MINIMUM_SOUND         (170)
#define   MINIMUM_FREQ          (260)
#define   MAX_LED_NUM           (50)        // 灯带最长灯珠数
#define   MIN_LED_NUM           (10)        // 灯带最短灯珠数
#define   DEFAULT_LED_NUM       (50)        // 灯带最长灯珠数
#define   MAX_SEGMENT_NUM       (15)        // 最大分段数
#define   MIN_SEGMENT_NUM       (2)         // 最小分段数
#define   LED_BRIGHTNESS_MAX    100         // 亮度最大值100
#define   LED_HS_PARAM_MAX      10000       // hue、saturation最大值10000
#define   LED_DEFAULT_HUE       6666        // 彩光模式默认颜色为蓝色

#define   TIMES           (2048)
#define   DISPLAY_PRINTF  (0)

#define   LED_STRIP_BUTTON_GPIO_NUM       4              // 按键信号接入GPIO
#define   LED_STRIP_BUTTON_TASK_STACKSIZE (1024)
#define   LED_STRIP_APP_TASK_STACKSIZE    (1024*16)
#define   LED_STRIP_APP_TASK_PRIORITY     TASK_PRIORITY_HIGH
#define   LED_STRIP_EVENT_QUEUE_MAX_NUM   16

#define   APP_ERR_OUT_OF_RANGE            -2           //  参数超出范围
#define   APP_ERR_INTERNAL                -3           //  内部错误

/**
 * @brief 产测时，强制退出按键扫描任务
 */
void led_strip_button_task_exit(void);


#ifdef __cplusplus
}
#endif

#endif /* __LED_STRIP_BOARD__ */






