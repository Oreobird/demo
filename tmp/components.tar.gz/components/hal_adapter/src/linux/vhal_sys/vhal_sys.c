/**
 * Copyright © Vesync Technologies Co.Ltd. 2019-2021. All rights reserved.
 * @file        vhal_sys.c
 * @brief       系统相关功能
 * @author      Joshua
 * @date        2021-08-26
 */
#include <unistd.h>
#include "vhal_sys.h"

void vhal_sys_board_init(void)
{
    // Do nothing
}

void vhal_sys_task_schedule(void)
{
    while (1)
    {
        sleep(10000);
    }
}

