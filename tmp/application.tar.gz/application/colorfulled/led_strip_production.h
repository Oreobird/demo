/**
*Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file    led_strip_production.h
* @brief   产测功能配置
* @author  henrik
*@date     2021-10-25
*/


#ifndef __LED_STRIP_PRODUCTION_H__
#define __LED_STRIP_PRODUCTION_H__

#ifdef __cplusplus
extern "C" {
#endif

/**
* @brief  产测功能初始化配置
* @return     int             [成功/失败]
*/
void led_strip_production_init(void);

#ifdef __cplusplus
}
#endif

#endif
