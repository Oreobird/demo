/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        bulb_device.c
 * @brief       bulb device
 * @author      Dave
 * @date        2021-09-8
 */
#include <string.h>

#include "vesync_common.h"
#include "vesync_log.h"
#include "vesync_device.h"

#include "bulb.h"
#include "bulb_flash.h"
#include "bulb_device.h"
#include "bulb_schedule.h"
#include "bulb_timing.h"
#include "bulb_scene.h"
#include "bulb_pwr_mem.h"

/**
* @brief bulb设备恢复出厂的数据清理
*/
static void bulb_device_clear_all_data(const char *rsn, DEV_RESET_TYPE_E rst_type)
{
    UNUSED(rsn);
    UNUSED(rst_type);
    int ret = bulb_flash_reset_cfg();
    if (APP_OK != ret)
    {
        APP_LOG(LOG_ERROR, "flash data reset fail\n");
    }
    ret = bulb_schedule_clear();
    if (APP_OK != ret)
    {
        APP_LOG(LOG_ERROR, "schedule reset fail\n");
    }
    ret = bulb_timing_clear();
    if (APP_OK != ret)
    {
        APP_LOG(LOG_ERROR, "timer reset fail\n");
    }
    ret = bulb_scene_clear();
    if (APP_OK != ret)
    {
        APP_LOG(LOG_ERROR, "scene reset fail\n");
    }
    ret = bulb_pwr_mem_clear();
    if (APP_OK != ret)
    {
        APP_LOG(LOG_ERROR, "pwr_mem reset fail\n");
    }
}

void bulb_device_init(void)
{
    // 注册缓存数据清除函数(恢复出厂/删除设备时调用)
    vesync_device_reg_clear_data_cb(bulb_device_clear_all_data);
}
