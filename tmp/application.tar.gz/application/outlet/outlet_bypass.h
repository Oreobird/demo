/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        outlet_bypass.h
 * @brief       outlet bypass应用回调
 * @author      Joshua
 * @date        2021-06-04
 */

#ifndef __OUTLET_BYPASS_H__
#define __OUTLET_BYPASS_H__

#include "vesync_bypass.h"

#ifdef __cplusplus
extern "C" {
#endif


/**
 * @brief 注册bypass回调函数
 */
void outlet_bypass_reg_cb(void);


#ifdef __cplusplus
}
#endif

#endif


