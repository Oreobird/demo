/**
 * Copyright © Vesync Technologies Co.Ltd. 2022. All rights reserved.
 * @file        vesync_sauth_xcvr.c
 * @brief       Vesync SAUTH模块的收发流程实现
 * @author      Herve.Lin
 * @date        2022-01-10
 */
#include <string.h>

#include "pt.h"

#include "vesync_sauth_private.h"
#include "vesync_sauth_port.h"
#include "vesync_sauth_proto.h"
#include "vesync_log_internal.h"

#include "vesync_utils.h"

// 接收协程轮询外部接收回调的信息
static struct
{
    bool is_polling;
    uint16_t target_cmd;
    uint8_t *buf;
    uint16_t buf_len;
    uint16_t rx_len;
} s_cmd_rx_buf;

void sauth_msg_recv_cb(uint8_t *p_in, uint32_t len)
{
    uint16_t cmd_code;
    memcpy(&cmd_code, p_in, sizeof(cmd_code));
    cmd_code = vesync_le16toh(cmd_code);

#if SAUTH_DEBUG_PRINT_ENABLE
    SDK_LOG(LOG_INFO, "rx data from app[%d], cmd_code[0x%x]\n", len, cmd_code);
    LOG_RAW_HEX(LOG_INFO, "app_data: ", p_in, len);
#endif
    switch (cmd_code)
    {
    case SAUTH_CMD_REG_START:
    case SAUTH_CMD_LOGIN_START:
    case SAUTH_CMD_HELLO:
        sauth_schedule_start(cmd_code);
        break;
    default:
        sauth_port_enter_critical();
        if (cmd_code == s_cmd_rx_buf.target_cmd)
        {
            if (NULL != s_cmd_rx_buf.buf)
            {
                uint16_t buf_len = s_cmd_rx_buf.buf_len;
                uint16_t dat_len = len - sizeof(cmd_code);
                uint8_t *p_data = p_in + sizeof(cmd_code);
                if (buf_len < dat_len)
                {
                    dat_len = buf_len;
                }
                memcpy(s_cmd_rx_buf.buf, p_data, dat_len);
                s_cmd_rx_buf.rx_len = dat_len;
            }
            s_cmd_rx_buf.is_polling = false;
        }
        sauth_port_exit_critical();
        break;
    }
}

void sauth_send_status_code(uint16_t cmd_code)
{
    uint16_t tx_buf = vesync_htole16(cmd_code);
    sauth_port_tl_send_data((uint8_t *)&tx_buf, sizeof(tx_buf));
}

PT_THREAD(sauth_tx_thd(struct pt *pt, uint8_t *p_tx_buf, uint16_t tx_buf_len, uint16_t cmd_code, uint8_t *p_data, uint16_t len))
{
    PT_BEGIN(pt);
    uint16_t msg_len = sizeof(cmd_code);
    uint16_t le16_cc = vesync_htole16(cmd_code);
    if (p_data != NULL)
    {
        uint16_t data_len = tx_buf_len - sizeof(cmd_code);
        // 检查发送Buffer的大小是否合法
        if (len < data_len)
        {
            data_len = len;
        }
        msg_len += data_len;
        memmove(p_tx_buf + sizeof(cmd_code), p_data, data_len);
    }
    // CMD_CODE的赋值要在内存平移之后
    memcpy(p_tx_buf, (uint8_t *)&le16_cc, sizeof(cmd_code));
    sauth_port_tl_send_data(p_tx_buf, msg_len);
#if SAUTH_DEBUG_PRINT_ENABLE
    SDK_LOG(LOG_INFO, "tx data to app[%d], cmd_code[0x%x]\n", msg_len, cmd_code);
    LOG_RAW_HEX(LOG_INFO, "dev_data: ", p_tx_buf, msg_len);
#endif
    PT_END(pt);
}

PT_THREAD(sauth_rx_thd(struct pt *pt, uint16_t cmd_code, uint8_t *p_buf, uint16_t buf_len, uint16_t *p_rx_len))
{
    PT_BEGIN(pt);
    sauth_port_enter_critical();
    s_cmd_rx_buf.target_cmd = cmd_code;
    s_cmd_rx_buf.buf = (NULL != p_buf) ? p_buf : NULL;
    s_cmd_rx_buf.buf_len = (NULL != p_buf) ? buf_len : 0;
    s_cmd_rx_buf.rx_len = 0;
    s_cmd_rx_buf.is_polling = true;
    sauth_port_exit_critical();
    while (1)
    {
        PT_WAIT_UNTIL(pt, false == s_cmd_rx_buf.is_polling);
        if (NULL != p_rx_len)
        {
            *p_rx_len = s_cmd_rx_buf.rx_len;
        }
        PT_EXIT(pt);
    }
    PT_END(pt);
}