/**
 *  Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
 * @file        vhal_ble.c
 * @brief       蓝牙hal配置ble服务属性接口
 * @date        2021-06-22
 */

#include "freertos/FreeRTOS.h"
#include "freertos/event_groups.h"
#include "freertos/semphr.h"

#include "esp_system.h"
#include "nvs_flash.h"
#include "esp_bt.h"
#include "esp_gap_ble_api.h"
#include "esp_gatts_api.h"
#include "esp_bt_main.h"
#include "esp_gatt_common_api.h"

#include "vesync_common.h"
#include "vesync_log.h"

#include "vhal_ble.h"
#include "vhal_ble_internal.h"


static vhal_ble_evt_cb_t  hal_ble_evt_cb            = NULL;
static vhal_ble_recv_cb_t hal_ble_cmd_recv_cb       = NULL;
static vhal_ble_recv_cb_t hal_ble_netcfg_recv_cb    = NULL;

static vhal_ble_t s_ble_info = {0};

static uint16_t ble_max_send_length = ESP_GATT_DEF_BLE_MTU_SIZE - ATT_OPCODE_HANDLE_LEN;


static uint16_t cmd_handle_table[CMD_IDX_NB];
static uint16_t update_server_handle_table[DEV_UPDATE_NB];
static uint16_t netcfg_handle_table[NET_CFG_IDX_NB];


static prepare_type_env_t prepare_write_env;

static struct gatts_profile_inst profile_inst =
{
    .gatts_if = ESP_GATT_IF_NONE,
    .conn_id  = CONN_ID_INVALID,
    .remote_device_addr = {0},
    .master_remote_device_addr = {0},
};

static char advertise_name[ADV_NAME_MAX_LEN + 1];  //字符串多一个字符‘\0’
static uint8_t adver_manufacturer[26] ={0xd0,0x06,0x01,0x36,0x35,0x34,0x33,0x32,0x31,0xe0,0xa0, 0x0, 0x0, 0x0};/* 协议参考蓝牙协议接口规范:http://wiki.vesync.com:8090/pages/viewpage.action?pageId=14254597 */
static VHAL_BLE_ADV_WORK_E s_ble_adv_work = BLE_ADV_WORK_NORMAL;

/* The length of adv data must be less than 31 bytes */
static esp_ble_adv_data_t adv_data = {
    .set_scan_rsp        = false,
    .include_name        = false,
    .include_txpower     = false,
    .appearance          = 0x00,
    .manufacturer_len    = MFR_DEFAULT_DATA_LEN,
    .p_manufacturer_data = adver_manufacturer,
    .service_data_len    = 0,
    .p_service_data      = NULL,
    .flag = (ESP_BLE_ADV_FLAG_GEN_DISC | ESP_BLE_ADV_FLAG_BREDR_NOT_SPT),
};

// scan response data
static esp_ble_adv_data_t scan_rsp_data = {
    .set_scan_rsp        = true,
    .include_name        = true,
};

static esp_ble_adv_params_t adv_params = {
    .adv_int_min         = APP_ADV_INTERVAL_MIN,
    .adv_int_max         = APP_ADV_INTERVAL_MAX,
    .adv_type            = ADV_TYPE_IND,
    .own_addr_type       = BLE_ADDR_TYPE_PUBLIC,
    .channel_map         = ADV_CHNL_ALL,
    .adv_filter_policy   = ADV_FILTER_ALLOW_SCAN_ANY_CON_ANY,
};

/* user Service characteristic*/
static const uint16_t GATTS_SERVICE_CMD_UUID           = 0xFFF0;
static const uint16_t GATTS_CHAR_CMD_NOTIFY_UUID       = 0xFFF1;
static const uint16_t GATTS_CHAR_CMD_WRITE_UUID        = 0xFFF2;

/* net config Service characteristic*/
static const uint8_t GATTS_SERVICE_NET_CFG_UUID[ESP_UUID_LEN_128]       = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xB0, 0x00, 0x40, 0x51, 0x04, 0xE0, 0xFF, 0x00, 0xF0};
static const uint8_t GATTS_CHAR_NET_CFG_WRITE_UUID[ESP_UUID_LEN_128]    = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xB0, 0x00, 0x40, 0x51, 0x04, 0xE1, 0xFF, 0x00, 0xF0};
static const uint8_t GATTS_CHAR_NET_CFG_NOTIFY_UUID[ESP_UUID_LEN_128]   = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xB0, 0x00, 0x40, 0x51, 0x04, 0xE2, 0xFF, 0x00, 0xF0};

static const uint8_t net_cfg_notify_ccc[2]             = {0x00, 0x00};
static const uint8_t char_value_net_cfg[4]             = {0x06, 0xd0};


/* user update service*/
static const uint8_t GATTS_UPDATE_SERVICE_UUID[]       = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xB0, 0x00, 0x40, 0x51, 0x04, 0xC0, 0xFF, 0x00, 0xF0};
static const uint8_t GATTS_UPDATE_CHAR_NOTIFY_UUID[]   = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xB0, 0x00, 0x40, 0x51, 0x04, 0xC1, 0xFF, 0x00, 0xF0};
static const uint8_t GATTS_UPDATE_CHAR_WRITE_UUID[]    = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xB0, 0x00, 0x40, 0x51, 0x04, 0xC2, 0xFF, 0x00, 0xF0};
static const uint8_t upgrade_cccd[2]                 = {0x00, 0x00};
static const uint8_t upgrade_write_cccd[2]           = {0x00, 0x00};
static const uint8_t update_char_prop_write_notify   = ESP_GATT_CHAR_PROP_BIT_WRITE|ESP_GATT_CHAR_PROP_BIT_WRITE_NR|ESP_GATT_CHAR_PROP_BIT_NOTIFY;
static const uint8_t char_value_update[4]            = {0x06, 0xd0};

static const uint16_t primary_service_uuid         = ESP_GATT_UUID_PRI_SERVICE;
static const uint16_t character_declaration_uuid   = ESP_GATT_UUID_CHAR_DECLARE;
static const uint16_t character_client_config_uuid = ESP_GATT_UUID_CHAR_CLIENT_CONFIG;
static const uint8_t char_prop_write               = ESP_GATT_CHAR_PROP_BIT_WRITE|ESP_GATT_CHAR_PROP_BIT_WRITE_NR;
static const uint8_t char_prop_notify              = ESP_GATT_CHAR_PROP_BIT_NOTIFY;
static const uint8_t cmd_notify_ccc[2]      = {0x00, 0x00};
static const uint8_t char_value_cmd[4]      = {0x06, 0xd0};

static uint8_t sw_version[]  = "R0000V0001";



/**
 * @brief 设备应用通信服务 业务逻辑交互通道
 */
static const esp_gatts_attr_db_t cmd_gatt_db[CMD_IDX_NB] =
{
    // Service Declaration
    [IDX_CMD_SVC]        =
    {{ESP_GATT_AUTO_RSP}, {ESP_UUID_LEN_16, (uint8_t *)&primary_service_uuid, ESP_GATT_PERM_READ,
      sizeof(uint16_t), sizeof(GATTS_SERVICE_CMD_UUID), (uint8_t *)&GATTS_SERVICE_CMD_UUID}},

    /* Characteristic Declaration */
    [IDX_CHAR_CMD_NOTIFY]     =
    {{ESP_GATT_AUTO_RSP}, {ESP_UUID_LEN_16, (uint8_t *)&character_declaration_uuid, ESP_GATT_PERM_READ,
      CHAR_DECLARATION_SIZE, CHAR_DECLARATION_SIZE, (uint8_t *)&char_prop_notify}},

    /* Characteristic Value */
    [IDX_CHAR_VAL_CMD_NOTIFY] =
    {{ESP_GATT_AUTO_RSP}, {ESP_UUID_LEN_16, (uint8_t *)&GATTS_CHAR_CMD_NOTIFY_UUID, ESP_GATT_PERM_READ | ESP_GATT_PERM_WRITE,
      GATTS_CHAR_VAL_LEN_MAX, sizeof(char_value_cmd), (uint8_t *)char_value_cmd}},

    /* Client Characteristic Configuration Descriptor */
    [IDX_CHAR_CFG_CMD_NOTIFY]  =
    {{ESP_GATT_AUTO_RSP}, {ESP_UUID_LEN_16, (uint8_t *)&character_client_config_uuid, ESP_GATT_PERM_READ | ESP_GATT_PERM_WRITE,
      sizeof(uint16_t), sizeof(cmd_notify_ccc), (uint8_t *)cmd_notify_ccc}},

    /* Characteristic Declaration */
    [IDX_CHAR_CMD_WRITE]      =
    {{ESP_GATT_AUTO_RSP}, {ESP_UUID_LEN_16, (uint8_t *)&character_declaration_uuid, ESP_GATT_PERM_READ,
      CHAR_DECLARATION_SIZE, CHAR_DECLARATION_SIZE, (uint8_t *)&char_prop_write}},

    /* Characteristic Value */
    [IDX_CHAR_VAL_CMD_WRITE]  =
    {{ESP_GATT_AUTO_RSP}, {ESP_UUID_LEN_16, (uint8_t *)&GATTS_CHAR_CMD_WRITE_UUID, ESP_GATT_PERM_WRITE,
      GATTS_CHAR_VAL_LEN_MAX, sizeof(char_value_cmd), (uint8_t *)char_value_cmd}},
};



/**
 * @brief 设备升级服务，标准服务UUID，公共接口升级通道
 */
static const esp_gatts_attr_db_t update_att_db[DEV_UPDATE_NB] =
{
    // Service Declaration
    [IDX_UPDATE_SVC]        =
    {{ESP_GATT_AUTO_RSP}, {ESP_UUID_LEN_16, (uint8_t *)&primary_service_uuid, ESP_GATT_PERM_READ,
      sizeof(uint16_t), sizeof(GATTS_UPDATE_SERVICE_UUID), (uint8_t *)&GATTS_UPDATE_SERVICE_UUID}},

    /* Characteristic Declaration */
    [IDX_UPDATE]     =
    {{ESP_GATT_AUTO_RSP}, {ESP_UUID_LEN_16, (uint8_t *)&character_declaration_uuid, ESP_GATT_PERM_READ,
      CHAR_DECLARATION_SIZE, CHAR_DECLARATION_SIZE, (uint8_t *)&update_char_prop_write_notify}},

    /* Characteristic Value */
    [IDX_UPDATE_NOTIFY_CHAR] =
    {{ESP_GATT_AUTO_RSP}, {ESP_UUID_LEN_128, (uint8_t *)&GATTS_UPDATE_CHAR_NOTIFY_UUID, ESP_GATT_PERM_READ | ESP_GATT_PERM_WRITE,
      GATTS_CHAR_VAL_LEN_MAX, sizeof(char_value_update), (uint8_t *)char_value_update}},

    /* Client Characteristic Configuration Descriptor */
    [IDX_UPDATE_NOTIFY_CFG]  =
    {{ESP_GATT_AUTO_RSP}, {ESP_UUID_LEN_16, (uint8_t *)&character_client_config_uuid, ESP_GATT_PERM_READ | ESP_GATT_PERM_WRITE,
    sizeof(uint16_t), sizeof(upgrade_cccd), (uint8_t *)upgrade_cccd}},


    /* Characteristic Declaration */
    [IDX_UPDATE_WRITE_CHAR]      =
    {{ESP_GATT_AUTO_RSP}, {ESP_UUID_LEN_16, (uint8_t *)&character_declaration_uuid, ESP_GATT_PERM_READ,
      CHAR_DECLARATION_SIZE, CHAR_DECLARATION_SIZE, (uint8_t *)&update_char_prop_write_notify}},

    /* Characteristic Value */
    [IDX_UPDATE_WRITE_VAL]  =
    {{ESP_GATT_AUTO_RSP}, {ESP_UUID_LEN_128, (uint8_t *)&GATTS_UPDATE_CHAR_WRITE_UUID, ESP_GATT_PERM_WRITE,
      GATTS_CHAR_VAL_LEN_MAX, sizeof(char_value_update), (uint8_t *)char_value_update}},

    /* Client Characteristic Configuration Descriptor */
    [IDX_UPDATE_WRITE_NOTIFY_CFG]  =
    {{ESP_GATT_AUTO_RSP}, {ESP_UUID_LEN_16, (uint8_t *)&character_client_config_uuid, ESP_GATT_PERM_READ | ESP_GATT_PERM_WRITE,
      sizeof(uint16_t), sizeof(upgrade_write_cccd), (uint8_t *)upgrade_write_cccd}},

};

/**
 * @brief 配网接口
 */
static const esp_gatts_attr_db_t net_cfg_gatt_db[NET_CFG_IDX_NB] =
{
    // Service Declaration
    [IDX_NET_CFG_SVC]        =
    {{ESP_GATT_AUTO_RSP}, {ESP_UUID_LEN_16, (uint8_t *)&primary_service_uuid, ESP_GATT_PERM_READ,
      sizeof(uint16_t), sizeof(GATTS_SERVICE_NET_CFG_UUID), (uint8_t *)&GATTS_SERVICE_NET_CFG_UUID}},

    /* Characteristic Declaration */
    [IDX_CHAR_NET_CFG_NOTIFY]     =
    {{ESP_GATT_AUTO_RSP}, {ESP_UUID_LEN_16, (uint8_t *)&character_declaration_uuid, ESP_GATT_PERM_READ,
      CHAR_DECLARATION_SIZE, CHAR_DECLARATION_SIZE, (uint8_t *)&char_prop_notify}},

    /* Characteristic Value */
    [IDX_CHAR_VAL_NET_CFG_NOTIFY] =
    {{ESP_GATT_AUTO_RSP}, {ESP_UUID_LEN_128, (uint8_t *)&GATTS_CHAR_NET_CFG_NOTIFY_UUID, ESP_GATT_PERM_READ | ESP_GATT_PERM_WRITE,
      GATTS_CHAR_VAL_LEN_MAX, sizeof(char_value_net_cfg), (uint8_t *)char_value_net_cfg}},

    /* Client Characteristic Configuration Descriptor */
    [IDX_CHAR_CFG_NET_CFG_NOTIFY]  =
    {{ESP_GATT_AUTO_RSP}, {ESP_UUID_LEN_16, (uint8_t *)&character_client_config_uuid, ESP_GATT_PERM_READ | ESP_GATT_PERM_WRITE,
      sizeof(uint16_t), sizeof(net_cfg_notify_ccc), (uint8_t *)net_cfg_notify_ccc}},

    /* Characteristic Declaration */
    [IDX_CHAR_NET_CFG_WRITE]      =
    {{ESP_GATT_AUTO_RSP}, {ESP_UUID_LEN_16, (uint8_t *)&character_declaration_uuid, ESP_GATT_PERM_READ,
      CHAR_DECLARATION_SIZE, CHAR_DECLARATION_SIZE, (uint8_t *)&char_prop_write}},

    /* Characteristic Value */
    [IDX_CHAR_VAL_NET_CFG_WRITE]  =
    {{ESP_GATT_AUTO_RSP}, {ESP_UUID_LEN_128, (uint8_t *)&GATTS_CHAR_NET_CFG_WRITE_UUID, ESP_GATT_PERM_WRITE,
      GATTS_CHAR_VAL_LEN_MAX, sizeof(char_value_net_cfg), (uint8_t *)char_value_net_cfg}},
};



/**
 * @brief  上报蓝牙事件
 * @param[in]  evt         [蓝牙事件]
 * @return     void        [无]
 */
static void hal_ble_evt_set(VHAL_BLE_EVT_E evt)
{
    if(NULL != hal_ble_evt_cb)
    {
        hal_ble_evt_cb(evt);
    }
}


/**
 * @brief gap事件状态回调处理
 * @param[in] event             [回调事件]
 * @param[in] param             [回调参数]
 */
static void gap_event_handler(esp_gap_ble_cb_event_t event, esp_ble_gap_cb_param_t *param)
{
    switch (event) {
    case ESP_GAP_BLE_ADV_DATA_RAW_SET_COMPLETE_EVT:
        HAL_LOG(LOG_INFO, "ESP_GAP_BLE_ADV_DATA_RAW_SET_COMPLETE_EVT\n");
        break;
    case ESP_GAP_BLE_SCAN_RSP_DATA_RAW_SET_COMPLETE_EVT:
        HAL_LOG(LOG_INFO, "ESP_GAP_BLE_SCAN_RSP_DATA_RAW_SET_COMPLETE_EVT\n");
        break;
    case ESP_GAP_BLE_ADV_DATA_SET_COMPLETE_EVT:
        HAL_LOG(LOG_INFO, "ESP_GAP_BLE_ADV_DATA_SET_COMPLETE_EVT\n");
        break;
    case ESP_GAP_BLE_SCAN_RSP_DATA_SET_COMPLETE_EVT:
        HAL_LOG(LOG_INFO, "ESP_GAP_BLE_SCAN_RSP_DATA_SET_COMPLETE_EVT\n");
        break;
    case ESP_GAP_BLE_ADV_START_COMPLETE_EVT:
        if (param->adv_start_cmpl.status != ESP_BT_STATUS_SUCCESS) {
            HAL_LOG(LOG_ERROR, "advertising start failed\n");
        }else{
            HAL_LOG(LOG_INFO, "advertising start successfully\n");
        }
        break;
    case ESP_GAP_BLE_ADV_STOP_COMPLETE_EVT:
        if (param->adv_stop_cmpl.status != ESP_BT_STATUS_SUCCESS) {
            HAL_LOG(LOG_ERROR, "Advertising stop failed\n");
        }
        else {
            HAL_LOG(LOG_INFO, "Stop adv successfully\n");
        }
        break;
    case ESP_GAP_BLE_UPDATE_CONN_PARAMS_EVT:
        if(0 == memcmp(param->update_conn_params.bda,profile_inst.remote_device_addr,ESP_BD_ADDR_LEN))
        {
            HAL_LOG(LOG_INFO, "update connection params status = %d, min_int = %d, max_int = %d,conn_int = %d,latency = %d, timeout = %d\n",
                param->update_conn_params.status, param->update_conn_params.min_int, param->update_conn_params.max_int,
                param->update_conn_params.conn_int, param->update_conn_params.latency, param->update_conn_params.timeout);
            HAL_LOG(LOG_INFO, "update_conn_params.bda="MACSTR"\n", MAC2STR(param->update_conn_params.bda));
        }
        break;
    default:
        break;
    }
}


/**
 * @brief gatts_prepare_write事件处理
 * @param[in] prepare_write_env
 * @param[in] gatts_if                  [gatts接口]
 * @param[in] param                     [参数]
 */
static void gatts_prepare_write_event_handler(esp_gatt_if_t gatts_if, prepare_type_env_t *prepare_write_env, esp_ble_gatts_cb_param_t *param)
{
    HAL_LOG(LOG_INFO, "prepare write, handle = %d, value len = %d\n", param->write.handle, param->write.len);
    esp_gatt_status_t status = ESP_GATT_OK;
    if (prepare_write_env->prepare_buf == NULL)
    {
        prepare_write_env->prepare_buf = (uint8_t *)malloc(PREPARE_BUF_MAX_SIZE * sizeof(uint8_t));
        prepare_write_env->prepare_len = 0;
        if (prepare_write_env->prepare_buf == NULL)
        {
            HAL_LOG(LOG_ERROR, "Gatt_server prep no mem\n");
            status = ESP_GATT_NO_RESOURCES;
        }
        else
        {
            memset(prepare_write_env->prepare_buf, 0, PREPARE_BUF_MAX_SIZE * sizeof(uint8_t));
            HAL_LOG(LOG_INFO,"prepare write malloc prepare_buf success\n");
        }
    }
    else
    {
        if(param->write.offset > PREPARE_BUF_MAX_SIZE)
        {
            status = ESP_GATT_INVALID_OFFSET;
        }
        else if ((param->write.offset + param->write.len) > PREPARE_BUF_MAX_SIZE)
        {
            status = ESP_GATT_INVALID_ATTR_LEN;
        }
    }

    /*send response when param->write.need_rsp is true */
    if (param->write.need_rsp)
    {
        esp_gatt_rsp_t *gatt_rsp = (esp_gatt_rsp_t *)malloc(sizeof(esp_gatt_rsp_t));
        if (gatt_rsp != NULL)
        {
            memset(gatt_rsp, 0, sizeof(esp_gatt_rsp_t));
            gatt_rsp->attr_value.len = param->write.len;
            gatt_rsp->attr_value.handle = param->write.handle;
            gatt_rsp->attr_value.offset = param->write.offset;
            gatt_rsp->attr_value.auth_req = ESP_GATT_AUTH_REQ_NONE;
            memcpy(gatt_rsp->attr_value.value, param->write.value, param->write.len);

            esp_err_t response_err = esp_ble_gatts_send_response(gatts_if, param->write.conn_id, param->write.trans_id, status, gatt_rsp);
            if (response_err != ESP_OK)
            {
               HAL_LOG(LOG_ERROR, "Send response error\n");
            }
            free(gatt_rsp);
        }
        else
        {
            HAL_LOG(LOG_ERROR, "Malloc failed\n");
        }
    }

    if (status != ESP_GATT_OK)
    {
        return;
    }

    memcpy(prepare_write_env->prepare_buf + param->write.offset,param->write.value,param->write.len);
    prepare_write_env->prepare_len += param->write.len;
    prepare_write_env->handle       = param->write.handle;

}


/**
 * @brief gatts exec write 事件处理
 * @param[in] prepare_write_env
 * @param[in] param                     [参数]
 */
static void gatts_exec_write_event_handler(prepare_type_env_t *prepare_write_env, esp_ble_gatts_cb_param_t *param)
{
    if (param->exec_write.exec_write_flag == ESP_GATT_PREP_WRITE_EXEC && prepare_write_env->prepare_buf)
    {
        HAL_LOG(LOG_INFO,"gatts_exec_write hanle=%d\n",prepare_write_env->handle);
       // esp_log_buffer_hex(GATTS_TABLE_TAG, prepare_write_env->prepare_buf, prepare_write_env->prepare_len);
    }
    else
    {
        HAL_LOG(LOG_INFO,"ESP_GATT_PREP_WRITE_CANCEL\n");
    }

    if (prepare_write_env->prepare_buf)
    {
        free(prepare_write_env->prepare_buf);
        prepare_write_env->prepare_buf = NULL;

        HAL_LOG(LOG_INFO,"prepare write free prepare_buf success\n");
    }

    prepare_write_env->prepare_len = 0;
}



/**
 * @brief 创建att表格
 * @param[in] event             [gatts事件]
 * @param[in] gatts_if          [gatts接口]
 * @param[in] param             [参数]
 */
static void gatts_creat_att_tab_handler(esp_gatts_cb_event_t event, esp_gatt_if_t gatts_if, esp_ble_gatts_cb_param_t *param)
{
    if(ESP_GATTS_REG_EVT == event)  //ESP_GATTS_REG_EVT事件在调用esp_ble_gatts_app_register()之后产生
    {
        esp_err_t ret = esp_ble_gatts_create_attr_tab(cmd_gatt_db, gatts_if, CMD_IDX_NB, SVC_INST_ID);
        if (ret)
        {
            HAL_LOG(LOG_ERROR, "create attr table failed, error code = %x\n", ret);
        }

    }
    else if(ESP_GATTS_CREAT_ATTR_TAB_EVT == event) //，每次调用esp_ble_gatts_create_attr_tab()都会产生ESP_GATTS_CREAT_ATTR_TAB_EVT事件
    {
        if (param->add_attr_tab.status != ESP_GATT_OK)
        {
            HAL_LOG(LOG_ERROR, "create attribute table failed, error code=0x%x\n", param->add_attr_tab.status);
        }
        else
        {
            HAL_LOG(LOG_INFO, "ESP_GATTS_CREAT_ATTR_TAB_EVT\n");
            esp_err_t create_attr_ret;
            if(param->add_attr_tab.svc_uuid.uuid.uuid16 == GATTS_SERVICE_CMD_UUID)
            {
                HAL_LOG(LOG_INFO, "add tab uuid16 = %x,handle = 0x%x\n", GATTS_SERVICE_CMD_UUID,param->add_attr_tab.handles[0]);

                memcpy(cmd_handle_table, param->add_attr_tab.handles, sizeof(cmd_handle_table));
                esp_ble_gatts_start_service(cmd_handle_table[IDX_CMD_SVC]);

                create_attr_ret = esp_ble_gatts_create_attr_tab(update_att_db, gatts_if, DEV_UPDATE_NB, SVC_INST_ID);
                if (create_attr_ret)
                {
                    HAL_LOG(LOG_ERROR, "create update attr table failed, error code = %x\n", create_attr_ret);
                }
            }
            else if(0 == memcmp(param->add_attr_tab.svc_uuid.uuid.uuid128 ,GATTS_UPDATE_SERVICE_UUID,16))
            {
                HAL_LOG(LOG_INFO, "add tab uuid16 = %02x%02x,handle = 0x%x\n", GATTS_UPDATE_SERVICE_UUID[13],GATTS_UPDATE_SERVICE_UUID[12],param->add_attr_tab.handles[0]);

                memcpy(update_server_handle_table, param->add_attr_tab.handles, sizeof(update_server_handle_table));
                esp_ble_gatts_start_service(update_server_handle_table[IDX_UPDATE_SVC]);

                create_attr_ret = esp_ble_gatts_create_attr_tab(net_cfg_gatt_db, gatts_if, NET_CFG_IDX_NB, SVC_INST_ID);
                if (create_attr_ret)
                {
                    HAL_LOG(LOG_ERROR, "create update attr table failed, error code = %x\n", create_attr_ret);
                }
            }
            else if(0 == memcmp(param->add_attr_tab.svc_uuid.uuid.uuid128 ,GATTS_SERVICE_NET_CFG_UUID,16))
            {
                HAL_LOG(LOG_INFO, "add tab uuid16 = %02x%02x,handle = 0x%x\n", GATTS_SERVICE_NET_CFG_UUID[13],GATTS_SERVICE_NET_CFG_UUID[12],param->add_attr_tab.handles[0]);

                HAL_LOG(LOG_INFO, "create update attr table success\n");

                memcpy(netcfg_handle_table, param->add_attr_tab.handles, sizeof(netcfg_handle_table));
                esp_ble_gatts_start_service(netcfg_handle_table[IDX_NET_CFG_SVC]);

                hal_ble_evt_set(HB_EVT_INIT_COMPLETE);
            }
            else
            {
                HAL_LOG(LOG_ERROR, "add tab uuid16 = %x,handle = 0x%x\n", param->add_attr_tab.svc_uuid.uuid.uuid16,param->add_attr_tab.handles[0]);

                HAL_LOG(LOG_ERROR, "add tab uuid128 = %02x%02x,handle = 0x%x\n", param->add_attr_tab.svc_uuid.uuid.uuid128[13],param->add_attr_tab.svc_uuid.uuid.uuid128[12],param->add_attr_tab.handles[0]);
            }
        }
    }
}


/**
 * @brief gatts write事件处理函数
 * @param[in] event             [gatts事件]
 * @param[in] gatts_if          [gatts接口]
 * @param[in] param             [参数]
 */
static void gatts_write_event_handler(esp_gatts_cb_event_t event, esp_gatt_if_t gatts_if, esp_ble_gatts_cb_param_t *param)
{
    if(ESP_GATTS_WRITE_EVT != event)
    {
        return;
    }

    HAL_LOG(LOG_INFO, "GATT_WRITE_EVT, conn_id %d, trans_id %d, handle %d\n",
            param->write.conn_id, param->write.trans_id, param->write.handle);
    if (param->write.is_prep)
    {
        gatts_prepare_write_event_handler(gatts_if, &prepare_write_env, param);
        return;
    }

    if(param->write.handle == cmd_handle_table[IDX_CHAR_VAL_CMD_WRITE])
    {
        HAL_LOG(LOG_INFO,"write cmd\n");
        //esp_log_buffer_hex(GATTS_TABLE_TAG, param->write.value, param->write.len);
        LOG_RAW_HEX(LOG_DEBUG, "ble cmd: ", param->write.value, param->write.len);
        if (NULL != hal_ble_cmd_recv_cb)
        {
            hal_ble_cmd_recv_cb(param->write.value, param->write.len);
        }
    }
    else if(param->write.handle == netcfg_handle_table[IDX_CHAR_VAL_NET_CFG_WRITE])
    {
        HAL_LOG(LOG_INFO,"write net config\n");
        //esp_log_buffer_hex(GATTS_TABLE_TAG, param->write.value, param->write.len);
        if (NULL != hal_ble_netcfg_recv_cb)
        {
            hal_ble_netcfg_recv_cb(param->write.value, param->write.len);
        }
    }
    else if(param->write.handle == update_server_handle_table[IDX_UPDATE_WRITE_VAL])
    {
        HAL_LOG(LOG_INFO,"write update write\n");
        //esp_log_buffer_hex(GATTS_TABLE_TAG, param->write.value, param->write.len);
    }
    else if(param->write.handle == update_server_handle_table[IDX_UPDATE_NOTIFY_CHAR])
    {
        HAL_LOG(LOG_INFO,"write uapdate notify\n");
        //esp_log_buffer_hex(GATTS_TABLE_TAG, param->write.value, param->write.len);
    }
    else if(param->write.handle == cmd_handle_table[IDX_CHAR_CFG_CMD_NOTIFY] && param->write.len == 2)
    {
        LOG_RAW_HEX(LOG_DEBUG, "ble cmd: ", param->write.value, param->write.len);
        uint16_t descr_value = param->write.value[1]<<8 | param->write.value[0];
        if (descr_value == 0x0001)
        {
            HAL_LOG(LOG_INFO, "app notify enable\n");
        }
        else if (descr_value == 0x0002)
        {
            HAL_LOG(LOG_INFO, "app indicate enable\n");
        }
        else
        {
            HAL_LOG(LOG_INFO, "app notify disable\n");
        }
    }
    else if(param->write.handle == update_server_handle_table[IDX_UPDATE_NOTIFY_CFG] && param->write.len == 2)
    {
        uint16_t descr_value = param->write.value[1]<<8 | param->write.value[0];
        if (descr_value == 0x0001)
        {
            HAL_LOG(LOG_INFO, "update notify enable\n");

        }
        else if (descr_value == 0x0002)
        {
            HAL_LOG(LOG_INFO, "update indicate enable\n");
        }
        else
        {
            HAL_LOG(LOG_INFO, "update notify disable\n");
        }
    }
    else if(param->write.handle == update_server_handle_table[IDX_UPDATE_WRITE_NOTIFY_CFG] && param->write.len == 2)
    {
        uint16_t descr_value = param->write.value[1]<<8 | param->write.value[0];
        if (descr_value == 0x0001)
        {
            HAL_LOG(LOG_INFO, "update write notify enable\n");

        }
        else if (descr_value == 0x0002)
        {
            HAL_LOG(LOG_INFO, "update write indicate enable\n");
        }
        else
        {
            HAL_LOG(LOG_INFO, "update write notify disable\n");
        }
    }
    else if(param->write.handle == netcfg_handle_table[IDX_CHAR_CFG_NET_CFG_NOTIFY] && param->write.len == 2)
    {
        uint16_t descr_value = param->write.value[1]<<8 | param->write.value[0];
        if (descr_value == 0x0001)
        {
            HAL_LOG(LOG_INFO, "net config notify enable\n");

        }
        else if (descr_value == 0x0002)
        {
            HAL_LOG(LOG_INFO, "net config indicate enable\n");
        }
        else
        {
            HAL_LOG(LOG_INFO, "net config notify disable\n");
        }
    }

    if (param->write.need_rsp)
    {
        HAL_LOG(LOG_ERROR, "need response\n");
        esp_ble_gatts_send_response(gatts_if, param->write.conn_id, param->write.trans_id, ESP_GATT_OK, NULL);
    }
}


/**
 * @brief gatts数据回调
 * @param[in] event             [gatts事件]
 * @param[in] gatts_if          [gatts接口]
 * @param[in] param             [参数]
 */
static void gatts_profile_event_handler(esp_gatts_cb_event_t event, esp_gatt_if_t gatts_if, esp_ble_gatts_cb_param_t *param)
{
    esp_ble_gatts_cb_param_t *p_data = (esp_ble_gatts_cb_param_t *) param;

    switch (event)
    {
    case ESP_GATTS_REG_EVT:
    {
        HAL_LOG(LOG_INFO, "ESP_GATTS_REG_EVT gatts_if %d ,app_id %02x\n",gatts_if,param->reg.app_id);

        if (param->reg.status == ESP_GATT_OK)
        {
            profile_inst.gatts_if = gatts_if;
        }
        else
        {
            HAL_LOG(LOG_ERROR, "Reg app failed, app_id %04x, status %d\n", param->reg.app_id, param->reg.status);
            return;
        }

        esp_err_t ret = esp_ble_gap_set_device_name(advertise_name);
        if (ret)
        {
            HAL_LOG(LOG_ERROR, "set device name failed, error code = %x\n", ret);
        }
        //config adv data
        ret = esp_ble_gap_config_adv_data(&adv_data);
        if (ret)
        {
            HAL_LOG(LOG_ERROR, "config adv data failed, error code = %x\n", ret);
        }
        //config scan response data
        ret = esp_ble_gap_config_adv_data(&scan_rsp_data);
        if (ret)
        {
            HAL_LOG(LOG_ERROR, "config scan response data failed, error code = %x\n", ret);
        }

        gatts_creat_att_tab_handler(event, gatts_if, param);  //开始注册service

    }
        break;
    case ESP_GATTS_READ_EVT:
        HAL_LOG(LOG_INFO, "ESP_GATTS_READ_EVT\n");
        break;
    case ESP_GATTS_WRITE_EVT:         //写没有应答
        gatts_write_event_handler(event, gatts_if, param);
        break;
    case ESP_GATTS_EXEC_WRITE_EVT: //写应答
        // the length of gattc prapare write data must be less than GATTS_DEMO_CHAR_VAL_LEN_MAX.
        HAL_LOG(LOG_INFO, "ESP_GATTS_EXEC_WRITE_EVT\n");
        gatts_exec_write_event_handler(&prepare_write_env, param);
        break;
    case ESP_GATTS_MTU_EVT:
        ble_max_send_length  = (param->mtu.mtu > ESP_GATT_DEF_BLE_MTU_SIZE) ? param->mtu.mtu : ESP_GATT_DEF_BLE_MTU_SIZE;
        ble_max_send_length -= ATT_OPCODE_HANDLE_LEN;

        HAL_LOG(LOG_INFO, "ESP_GATTS_MTU_EVT, MTU %d\n", param->mtu.mtu);
        HAL_LOG(LOG_INFO, "ble_max_send_length %d\n",ble_max_send_length);
        break;
    case ESP_GATTS_CONF_EVT:
        //HAL_LOG(LOG_INFO, "ESP_GATTS_CONF_EVT, status = %d", param->conf.status);
        break;
    case ESP_GATTS_START_EVT:
        HAL_LOG(LOG_INFO, "SERVICE_START_EVT, status %d, service_handle %d\n", param->start.status, param->start.service_handle);
        break;
    case ESP_GATTS_CONNECT_EVT:
        if(0 != memcmp(param->connect.remote_bda,profile_inst.master_remote_device_addr,ESP_BD_ADDR_LEN))
        {
            HAL_LOG(LOG_INFO, "ESP_GATTS_CONNECT_EVT, conn_id = %d gatts_if =%d\n", param->connect.conn_id,gatts_if);
            HAL_LOG(LOG_INFO, "master_remote_device_addr="MACSTR"\n", MAC2STR(profile_inst.master_remote_device_addr));

            profile_inst.conn_id = param->connect.conn_id;
            memcpy(profile_inst.remote_device_addr,p_data->connect.remote_bda,ESP_BD_ADDR_LEN);

            HAL_LOG(LOG_INFO, "remote_device_addr="MACSTR"\n", MAC2STR(profile_inst.remote_device_addr));

            hal_ble_evt_set(HB_EVT_CONNECTED);

            //蓝牙连接后需要继续开启广播
            if((BLE_ADV_WORK_CONNECTED == s_ble_adv_work)&&(true == s_ble_info.adv_started))
            {
                adv_params.adv_type = ADV_TYPE_SCAN_IND;        //可扫描无定向广播
                vhal_ble_advertising_start();
            }
        }

        break;
    case ESP_GATTS_DISCONNECT_EVT:
        if(0 == memcmp(param->disconnect.remote_bda, profile_inst.remote_device_addr, ESP_BD_ADDR_LEN))
        {
            HAL_LOG(LOG_INFO, "ESP_GATTS_DISCONNECT_EVT, conn_id = %d, reason = 0x%x, gatts_if = %d\n", param->disconnect.conn_id, param->disconnect.reason, gatts_if);

            profile_inst.conn_id = CONN_ID_INVALID;

            ble_max_send_length = ESP_GATT_DEF_BLE_MTU_SIZE - ATT_OPCODE_HANDLE_LEN;
            HAL_LOG(LOG_INFO, "ble_max_send_length %d\n", ble_max_send_length);

            if(true == s_ble_info.adv_started)
            {
                vhal_ble_advertising_stop();
                adv_params.adv_type = ADV_TYPE_IND;
                vhal_ble_advertising_start();
            }

            hal_ble_evt_set(HB_EVT_DISCONNECTED);
        }
        break;

    case ESP_GATTS_CREAT_ATTR_TAB_EVT:
        gatts_creat_att_tab_handler(event,gatts_if,param);  //继续注册service
        break;
    case ESP_GATTS_CONGEST_EVT:
        HAL_LOG(LOG_INFO, "ESP_GATTS_CONGEST_EVT, congested = %d\n", param->congest.congested);
        break;
    case ESP_GATTS_CLOSE_EVT:
        HAL_LOG(LOG_INFO, "ESP_GATTS_CLOSE_EVT, conn_id = %d\n", param->close.conn_id);
        break;
    case ESP_GATTS_STOP_EVT:
    case ESP_GATTS_OPEN_EVT:
    case ESP_GATTS_CANCEL_OPEN_EVT:
    //case ESP_GATTS_CLOSE_EVT:
    case ESP_GATTS_LISTEN_EVT:

    case ESP_GATTS_UNREG_EVT:
    case ESP_GATTS_DELETE_EVT:
    default:
        break;
    }
}



/**
 * @brief ble发送数据
 * @param[in] handle        [发送的类型cmd/update/netcfg]
 * @param[in] p_data        [发送数据指针]
 * @param[in] length        [发送数据长度]
 * @return int32_t          [VHAL_OK/VHAL_FAIL]
 */
static int32_t vhal_ble_data_send(uint16_t handle, uint8_t *p_data, uint16_t length)
{
    uint16_t offset = 0, temp_len = 0;

    HAL_LOG(LOG_DEBUG,"handle=%d, len=%d\n", handle, length);
    while (offset < length)
    {
#if defined(ESP_IDF_VERSION)
#if ESP_IDF_VERSION >= ESP_IDF_VERSION_VAL(4, 2, 0)
        // esp-idf v3.3.4之后的SDK，BLE发送队列满了会导致发送失败，因此需要查询可用的缓存，当可用为0时需要延时等待
        if (esp_ble_get_cur_sendable_packets_num(profile_inst.conn_id) <= 0)
        {
            if (false == vhal_ble_is_connected())   // 蓝牙未连接则返回
            {
                HAL_LOG(LOG_DEBUG,"BLE disconnect, send fail\n");
                break;
            }
            else
            {
                vTaskDelay(20/portTICK_RATE_MS);// 延时
                HAL_LOG(LOG_DEBUG,"Delay 20ms to wait available send buffers\n");
                continue;
            }
        }
#endif /* ESP_IDF_VERSION >= ESP_IDF_VERSION_VAL(4, 2, 0) */
#else
#error "ESP_IDF_VERSION is not defined"
#endif /* ESP_IDF_VERSION */

        temp_len = ((length - offset) > ble_max_send_length ? ble_max_send_length : (length - offset));

        if(ESP_OK != esp_ble_gatts_send_indicate(profile_inst.gatts_if, profile_inst.conn_id,
                                            handle, temp_len, p_data + offset, false))
        {
            return VHAL_FAIL;
        }

        offset  += temp_len;
    }

    return VHAL_OK;
}




/**
 * @brief 主动断开当前的蓝牙连接
 * @return int32_t      [VHAL_OK/VHAL_FAIL]
 */
int32_t vhal_ble_disconnect(void)
{
    if (ESP_OK != esp_ble_gap_disconnect(profile_inst.remote_device_addr))
    {
        return VHAL_FAIL;
    }

    return VHAL_OK;
}


/**
 * @brief 启动广播
 * @return int32_t      [VHAL_OK/VHAL_FAIL]
 */
int32_t vhal_ble_advertising_start(void)
{
    s_ble_info.adv_started = true;
    if (ESP_OK != esp_ble_gap_start_advertising(&adv_params))
    {
        return VHAL_FAIL;
    }

    return VHAL_OK;
}

/**
 * @brief 停止广播
 * @return int32_t      [VHAL_OK/VHAL_FAIL]
 */
int32_t vhal_ble_advertising_stop(void)
{
    s_ble_info.adv_started = false;
    if (ESP_OK != esp_ble_gap_stop_advertising())
    {
        return VHAL_FAIL;
    }

    return VHAL_OK;
}


/**
 * @brief 设置主机对端设备地址
 * @param[in] master_remote_bda     [对端设备地址]
 */
void vhal_ble_set_master_remote_bda(uint8_t *master_remote_bda)
{
    memcpy(profile_inst.master_remote_device_addr, master_remote_bda, ESP_BD_ADDR_LEN);
}


/**
 * @brief 动态修改广播参数
 * @param[in] name              [蓝牙广播设备名称]
 * @return int32_t              [VHAL_OK/VHAL_FAIL]
 */
int32_t vhal_ble_set_device_name(char *p_name)
{
    esp_err_t ret;

    if (NULL == p_name)
    {
        return VHAL_FAIL;
    }

    strncpy(advertise_name, p_name, ADV_NAME_MAX_LEN);

    ret = esp_ble_gap_set_device_name(p_name);
    if (ESP_OK != ret)
    {
        HAL_LOG(LOG_ERROR, "set device name failed, error code = %x\n", ret);
        //return VHAL_FAIL;  ???
    }
    ret = esp_ble_gap_config_adv_data(&scan_rsp_data);
    if (ESP_OK != ret)
    {
        HAL_LOG(LOG_ERROR, "config scan response data failed, error code = %x\n", ret);
        return VHAL_FAIL;
    }

    return VHAL_OK;
}


/**
 * @brief 动态修改广播参数
 * @param[in] product_type
 * @param[in] product_model
 * @return int32_t              [VHAL_OK/VHAL_FAIL]
 */
int32_t vhal_ble_set_adv_product_info(uint8_t product_type, uint8_t product_model)
{
    esp_err_t ret;

    adver_manufacturer[9] = product_type;
    adver_manufacturer[10] = product_model;

    ret = esp_ble_gap_config_adv_data(&adv_data);
    if (ESP_OK != ret)
    {
        HAL_LOG(LOG_ERROR, "config adv data failed, error code = %d\r\n", ret);
        return VHAL_FAIL;
    }

    return VHAL_OK;
}

/**
 * @brief 动态修改广播命令字段
 * @param[in] cmd_data           [命令数据段]
 * @param[in] cmd_len            [命令数据长度]
 * @param[in] up_flag            [是否更新广播包长度, ]
 * @return  int32_t              [成功：VHAL_OK，失败：VHAL_FAIL]
 */
int32_t vhal_ble_set_adv_cmd_data(uint8_t * cmd_data, uint8_t cmd_len, bool up_flag)
{
    esp_err_t ret;

    if ((NULL == cmd_data)||(MFR_MAX_CMD_DATA_LEN < cmd_len))
    {
        HAL_LOG(LOG_ERROR, "input illigle!\r\n");
        return VHAL_FAIL;
    }

    memcpy(&adver_manufacturer[11], cmd_data, cmd_len);
    if (true == up_flag)
    {
        adv_data.manufacturer_len = MFR_DEFAULT_DATA_LEN + cmd_len - 3;
    }

    ret = esp_ble_gap_config_adv_data(&adv_data);
    if (ESP_OK != ret)
    {
        HAL_LOG(LOG_ERROR, "config adv data failed, error code = %d\r\n", ret);
        return VHAL_FAIL;
    }

    return VHAL_OK;

}


/**
 * @brief 蓝牙广播动态修改配网状态
 * @param[in] netcfg_status     [设备配网状态]
 * @return int32_t              [VHAL_OK/VHAL_FAIL]
 */
int32_t vhal_ble_set_adv_netcfg_status(uint8_t netcfg_status)
{
    esp_err_t ret;

    adver_manufacturer[13] = netcfg_status;

    ret = esp_ble_gap_config_adv_data(&adv_data);
    if (ESP_OK != ret)
    {
        HAL_LOG(LOG_ERROR, "config adv data failed, error code = %d\r\n", ret);
        return VHAL_FAIL;
    }

    return VHAL_OK;
}



/**
 * @brief 更新蓝牙连接间隔
 * @param min_interval min_interval = x*1.25ms
 * @param max_interval max_interval = x*1.25ms
 * @param time_out     timeout = x*10ms
 * @return int32_t     VHAL_OK/VHAL_FAIL
 *
 * interval Max*(slave latency+1)<=2s
 * interval min>=20ms
 * interval min+20ms<=interval max
 * slve latency<=4
 * connsupervisiontimeout <= 6s
 * interval max*(slave latency+1)*3 < connsupervisiontimeout
 */
int32_t vhal_ble_update_connect_interval(uint16_t min_interval, uint16_t max_interval, uint16_t timeout)
{
    esp_ble_conn_update_params_t conn_params = {0};

    HAL_LOG(LOG_INFO,"min:%d ms, max:%d ms, timeout:%d ms\n",
            (int)(min_interval*1.25),(int)(max_interval*1.25),(int)(timeout*10));

    if(CONN_ID_INVALID == profile_inst.conn_id)
    {
        HAL_LOG(LOG_ERROR,"invlid state\n");
        return VHAL_FAIL;
    }
    memcpy(conn_params.bda, profile_inst.remote_device_addr, sizeof(esp_bd_addr_t));
    conn_params.latency = 0;
    conn_params.min_int = min_interval;
    conn_params.max_int = max_interval;
    conn_params.timeout = timeout;

    if (ESP_OK != esp_ble_gap_update_conn_params(&conn_params))
    {
        return VHAL_FAIL;
    }

    return VHAL_OK;
}




/**
 * @brief cmd接口发送数据
 * @param[in] p_data        [发送数据指针]
 * @param[in] length        [发送数据长度]
 * @return int32_t          [VHAL_OK/VHAL_FAIL]
 */
int32_t vhal_ble_cmd_data_send(uint8_t *p_data, uint16_t len)
{
    if(NULL == p_data || 0 == len || len > 1500)
    {
        return VHAL_FAIL;
    }

    return vhal_ble_data_send(cmd_handle_table[IDX_CHAR_VAL_CMD_NOTIFY] , p_data , len);
}


/**
 * @brief 配网接口发送数据
 * @param[in] p_data        [发送数据指针]
 * @param[in] length        [发送数据长度]
 * @return int32_t          [VHAL_OK/VHAL_FAIL]
 */
int32_t vhal_ble_netcfg_data_send(uint8_t *p_data, uint16_t length)
{
    if(NULL == p_data || 0 == length || length > 1500)
    {
        return VHAL_FAIL;
    }

    return vhal_ble_data_send(netcfg_handle_table[IDX_CHAR_VAL_NET_CFG_NOTIFY] , p_data , length);
}



/**
 * @brief 注册蓝牙事件函数
 * @param[in]  cb           [蓝牙事件回调函数]
 */
void vhal_ble_reg_evt_cb(vhal_ble_evt_cb_t cb)
{
    hal_ble_evt_cb = cb;
}


/**
 * @brief 注册cmd接口接收回调
 * @param[in]  cb           [CMD接收回调函数]
 */
void vhal_ble_reg_cmd_recv_cb(vhal_ble_recv_cb_t cb)
{
    hal_ble_cmd_recv_cb = cb;
}

/**
 * @brief 注册配网接口接收回调
 * @param[in]  cb           [配网接收回调函数]
 */
void vhal_ble_reg_netcfg_recv_cb(vhal_ble_recv_cb_t cb)
{
    hal_ble_netcfg_recv_cb = cb;
}


/**
 * @brief 蓝牙是否连接成功？
 * @return bool         [true 连接 false 未连接]
 */
bool vhal_ble_is_connected(void)
{
    return (CONN_ID_INVALID != profile_inst.conn_id);
}


/**
 * @brief 关闭蓝牙功能
 * @return int32_t      [VHAL_OK/VHAL_FAIL]
 */
int32_t vhal_ble_disable(void)
{
    s_ble_info.adv_started = false;

    if(vhal_ble_is_connected())
    {
        return vhal_ble_disconnect();
    }
    else
    {
        return vhal_ble_advertising_stop();
    }
}


/**
 * @brief 关闭蓝牙协议栈，释放蓝牙资源
 */
void vhal_ble_deinit(void)
{
    ESP_ERROR_CHECK(esp_ble_gatts_app_unregister(GATTS_APP_ID));
    ESP_ERROR_CHECK(esp_bluedroid_disable());
    ESP_ERROR_CHECK(esp_bluedroid_deinit());
    ESP_ERROR_CHECK(esp_bt_controller_disable());
    ESP_ERROR_CHECK(esp_bt_controller_deinit());

    s_ble_info.init_flag = false;

    HAL_LOG(LOG_INFO,"ble deinit\n");
}


/**
 * @brief  蓝牙是否已经初始化
 * @return     bool             [是否已经初始化]
 */
bool vhal_ble_is_init(void)
{
    return s_ble_info.init_flag;
}


/**
 * @brief  初始化蓝牙协议栈及配置蓝牙广播参数
 * @param[in]  dev_name         [蓝牙设备名称]
 * @param[in]  prj_version      [软件版本号，必须是“1.0.00”的格式]
 * @param[in]  mfr_data         [厂商定义数据]
 * @return     int32_t          [执行结果]
 */
int32_t vhal_ble_init(char *dev_name, char *prj_version, ble_adv_mfr_data_t mfr_data)
{
    esp_err_t ret =0;

    if(s_ble_info.init_flag)
    {
        return VHAL_FAIL;
    }

    if((NULL == dev_name) || (strlen(dev_name) > ADV_NAME_MAX_LEN) ||
       (NULL == sw_version) || (6 != strlen(prj_version)))  //prj_version格式必须是“1.0.00”，所以长度必须是6
    {
        return VHAL_FAIL;
    }

    hal_ble_evt_set(HB_EVT_INIT);

    /* 软件版本号格式转换 */
    sw_version[6] = prj_version[0];
    sw_version[7] = prj_version[2];
    sw_version[8] = prj_version[4];
    sw_version[9] = prj_version[5];

    strncpy(advertise_name, dev_name, ADV_NAME_MAX_LEN);

    uint8_t mac[6] ={0};

    ret = esp_read_mac(&mac[0], ESP_MAC_BT);
    if (ret)
    {
        HAL_LOG(LOG_ERROR, "%s get mac failed: %s\n", __func__, esp_err_to_name(ret));
        return ret;
    }

    for(uint8_t i = 0;i < sizeof(mac); i++)
    {
        adver_manufacturer[3 + i] = mac[5-i];
    }

    adver_manufacturer[9]  = mfr_data.product_type;
    adver_manufacturer[10] = mfr_data.product_model;
    adver_manufacturer[11] = mfr_data.cmd_code;         // 配网新需求新增，2020-03-17
    adver_manufacturer[12] = mfr_data.netcfg_ver;
    adver_manufacturer[13] = mfr_data.netcfg_status;

    s_ble_adv_work = mfr_data.ble_adv_work;


    ESP_ERROR_CHECK(esp_bt_controller_mem_release(ESP_BT_MODE_CLASSIC_BT));

    esp_bt_controller_config_t bt_cfg = BT_CONTROLLER_INIT_CONFIG_DEFAULT();
    ret = esp_bt_controller_init(&bt_cfg);
    if (ret)
    {
        HAL_LOG(LOG_ERROR, "esp_bt_controller_init failed: %s\n", esp_err_to_name(ret));
        return VHAL_FAIL;
    }

    ret = esp_bt_controller_enable(ESP_BT_MODE_BLE);
    if (ret)
    {
        HAL_LOG(LOG_ERROR, "esp_bt_controller_enable failed: %s\n", esp_err_to_name(ret));
        return VHAL_FAIL;
    }

    ret = esp_bluedroid_init();
    if (ret)
    {
        HAL_LOG(LOG_ERROR, "esp_bluedroid_init failed: %s\n", esp_err_to_name(ret));
        return VHAL_FAIL;
    }

    ret = esp_bluedroid_enable();
    if (ret)
    {
        HAL_LOG(LOG_ERROR, "esp_bluedroid_enable failed: %s\n", esp_err_to_name(ret));
        return VHAL_FAIL;
    }

    ret = esp_ble_gatts_register_callback(gatts_profile_event_handler);
    if (ret)
    {
        HAL_LOG(LOG_ERROR, "gatts register error, error code = %x\n", ret);
        return VHAL_FAIL;
    }

    ret = esp_ble_gap_register_callback(gap_event_handler);
    if (ret)
    {
        HAL_LOG(LOG_ERROR, "gap register error, error code = %x\n", ret);
        return VHAL_FAIL;
    }

    ret = esp_ble_gatts_app_register(GATTS_APP_ID);
    if (ret)
    {
        HAL_LOG(LOG_ERROR, "gatts app register error, error code = %x", ret);
        return VHAL_FAIL;
    }

    ret = esp_ble_gatt_set_local_mtu(BLE_MAX_MTU);
    if (ret)
    {
        HAL_LOG(LOG_ERROR, "set local  MTU failed, error code = %x\n", ret);
    }

    ret = esp_ble_tx_power_set(ESP_BLE_PWR_TYPE_DEFAULT,TX_POWER);
    if (ret)
    {
        HAL_LOG(LOG_ERROR, "gatts app register error, error code = %x\n", ret);
        return VHAL_FAIL;
    }

    s_ble_info.init_flag = true;

    return VHAL_OK;
}



/**
 * @brief  获取BLE MAC
 * @param[out] dev_mac      [输出蓝牙MAC buffer]
 * @param[in]  max_len      [buffer 长度]
 * @return     int32_t      [执行结果]
 */
int32_t vhal_ble_get_mac(char *dev_mac, uint32_t max_len)
{
    esp_err_t ret = 0;
    uint8_t mac_addr[MAC_ADDR_HEX_LEN] = {0};

    if (NULL == dev_mac || max_len < MAC_ADDR_STR_MAX_LEN)
    {
        HAL_LOG(LOG_ERROR, "Invalid param.\r\n");
        return VHAL_FAIL;
    }

    ret = esp_read_mac(&mac_addr[0], ESP_MAC_BT);
    if (ret)
    {
        HAL_LOG(LOG_ERROR, "esp_read_mac failed: %s\r\n", esp_err_to_name(ret));
        return VHAL_FAIL;
    }

    snprintf(dev_mac, max_len, MACSTR, MAC2STR(mac_addr));

    return VHAL_OK;
}


