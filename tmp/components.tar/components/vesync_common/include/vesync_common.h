/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_common.h
 * @brief       定义通用宏
 * @date        2021-04-20
 */

#ifndef __VESYNC_COMMON_H__
#define __VESYNC_COMMON_H__

#ifdef __cplusplus
extern "C" {
#endif


// MAC地址相关
#define MAC_ADDR_HEX_LEN                (6)         // 十六进制格式的MAC地址长度
#define MAC_ADDR_STR_MAX_LEN            (18)        // 字符串形式带分隔符的MAC地址最大长度
#define MAC_ADDR_STR_NO_SEPARATOR_LEN   (12)        // 字符串形式无分隔符的MAC地址最大长度

// IP地址相关
#define IP_ADDR_STR_MAX_LEN             (16)        // 255.255.255.255,长度最大为15bytes

// Wi-Fi参数相关
#define WIFI_BSSID_MAX_LEN              (6)         // Wi-Fi MAC十六进制数个数，非转换成字符串后的长度
#define WIFI_SSID_MAX_LEN               (32)        // 协议规定最大为32bytes，对齐4字节
#define WIFI_PWD_MAX_LEN                (64)        // 协议规定最大为64bytes，在很多系统上最大长度为63bytes，

// 其他
#define CONUTRY_CODE_STR_MAX_LEN        (2)         // 2位格式国家码（如：US）最大长度
#define DHCP_HOST_NAME_MAX_LEN          (32)        // dhcp hostname最大长度
#define MD5_STR_LEN                     (32)        // md5字符串长度
#define ACCOUNT_ID_STR_LEN              (32)        //account id 最大长度32bytes
#define SENCONDS_PER_DAY                (86400UL)   //一天的秒数


/* 函数通用返回值 */
#define RET_OK            0    /* success (no error) */
#define RET_FAIL          1    /* failure */

/* HAL层返回值*/
#define VHAL_OK         RET_OK                 /* success (no error) */
#define VHAL_FAIL       RET_FAIL               /* failure */

/* OS层返回值*/
#define VOS_OK          RET_OK                 /* success (no error) */
#define VOS_FAIL        RET_FAIL               /* failure */

/* SDK层返回值*/
#define SDK_OK          RET_OK                 /* success (no error) */
#define SDK_FAIL        RET_FAIL               /* failure */

/* APP层返回值*/
#define APP_OK          RET_OK                  /* success (no error) */
#define APP_FAIL        RET_FAIL                /* failure */
#define APP_PARA_ERR    (APP_FAIL + 1)          /* Parameter error */
#define APP_NO_REPLY    (APP_FAIL + 2)          /* No need to do anything */

// MAC地址
#ifndef MAC2STR
#define MAC2STR(a)  (a)[0], (a)[1], (a)[2], (a)[3], (a)[4], (a)[5]
#define MACSTR      "%02x:%02x:%02x:%02x:%02x:%02x"
#endif

#define UNUSED(x) ((void)(x))
#define SIZEOF_ARRAY(x)   (sizeof(x) / sizeof((x)[0]))

// 内存释放
#define VCOM_SAFE_FREE(ptr)       \
    do{                                 \
        if (NULL != ptr) {              \
            vesync_free(ptr);           \
            ptr = NULL;                 \
        }                               \
    } while(0)

#define VCOM_NULL_PARAM_CHK(param, action) \
    do {                      \
        if (param == NULL) {  \
            action;        \
        }                     \
    } while (0)


#define VCOM_NULL_RET_CHK(ret, action) \
    do {                       \
        if (ret == NULL) {     \
            action;         \
        }                      \
    } while (0)

#define VCOM_ERR_RET_CHK(ret, action) \
    do {                      \
        if (ret < 0) {        \
            action;  \
        }   \
    } while (0)

#define VCOM_IN_RANGE_CHK(x, min, max, action) \
    do {                                  \
        if ((x) < (min) || (x) > (max)) { \
            action;                    \
        }                                 \
    } while (0)

#define VCOM_LEN_IS_TOO_SMALL(len, minLen, action) \
    do { \
        if (len < minLen) \
        {                 \
            action;       \
        } \
    } while (0)

#define VCOM_LEN_IS_TOO_LARGE(len, maxLen, action) \
    do { \
        if (len > maxLen) \
        {                 \
            action;       \
        } \
    } while (0)

#define VCOM_LEN_IS_NOT_EQUAL(len1, len2, action) \
    do { \
        if (len1 != len2) \
        {                 \
            action;       \
        } \
    } while (0)

#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_COMMON_H__ */

