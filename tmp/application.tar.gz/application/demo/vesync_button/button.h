/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        button.h
 * @brief       按键模块接口定义
 * @date        2021-12-23
 */

#ifndef __BUTTON_H__
#define __BUTTON_H__


#include "stdint.h"
#include "vesync_button.h"

#ifdef __cplusplus
extern "C" {
#endif


/**
 * @brief       配网按键初始化
 * @return  int                     [成功：SDK_OK，失败：SDK_FAIL]
 */
int button_netcfg_init(void);

/**
* @brief       配网按键模块反初始化
*/
int button_netcfg_deinit(void);

/**
 * @brief       开关按键初始化
 * @return  int                     [成功：SDK_OK，失败：SDK_FAIL]
 */
int button_switch_init(void);

/**
* @brief       开关按键模块反初始化
*/
int button_switch_deinit(void);


/**
 * @brief       按键初始化
 */
void app_button_init(void);

#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_BUTTON_H__ */



