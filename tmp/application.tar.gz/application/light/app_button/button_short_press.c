/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        button_short_press.c
 * @brief       短按业务实现
 * @author      Joshua
 * @date        2021-12-23
 */
#include <stdint.h>
#include <string.h>
#include <stdbool.h>

#include "vesync_log.h"
#include "vesync_common.h"

#include "button.h"


#if CONFIG_VESYNC_APP_BUTTON_ONOFF_SWITCH   // 开关
static void single_click_handle(void)
{
    APP_LOG(LOG_DEBUG, "------onoff_switch-------\n");
}
#elif CONFIG_VESYNC_APP_BUTTON_COLOR_SWITCH   // 颜色切换
static void single_click_handle(void)
{
    APP_LOG(LOG_DEBUG, "------color_switch-------\n");
}
#elif CONFIG_VESYNC_APP_BUTTON_SCENE_SWITCH  // 场景切换
static void single_click_handle(void)
{
    APP_LOG(LOG_DEBUG, "------scene_switch-------\n");
}
#elif CONFIG_VESYNC_APP_BUTTON_MODE_SWITCH    // 模式切换
static void single_click_handle(void)
{
    APP_LOG(LOG_DEBUG, "------mode_switch-------\n");
}
#elif CONFIG_VESYNC_APP_BUTTON_BRIGHTNESS_LEVEL_ADJUST    // 亮度调节
static void single_click_handle(void)
{
    APP_LOG(LOG_DEBUG, "------brightness_level_adjust-------\n");
}
#else
#define single_click_handle     NULL
#endif

int button_short_press_init(app_btn_cfg_t *app_btn_cfg)
{
    VCOM_NULL_PARAM_CHK(app_btn_cfg, return APP_FAIL);
    int ret = SDK_FAIL;

    btn_cfg_t cfg;

    memset(&cfg, 0, sizeof(btn_cfg_t));
    cfg.gpio = app_btn_cfg->gpio;
    cfg.active_level = app_btn_cfg->active_level;

    ret = vesync_button_reg_cb(cfg.gpio, EV_SINGLE_CLICK, single_click_handle);
    if (ret != SDK_OK)
    {
        ret = vesync_button_add(&cfg);
        if (ret != SDK_OK)
        {
            APP_LOG(LOG_ERROR, "button add fail\n");
            return APP_FAIL;
        }

        ret = vesync_button_reg_cb(cfg.gpio, EV_SINGLE_CLICK, single_click_handle);
        if (ret != SDK_OK)
        {
            APP_LOG(LOG_ERROR, "button reg cb fail\n");
            vesync_button_del(cfg.gpio);
            return APP_FAIL;
        }
    }

    return APP_OK;
}

int button_short_press_deinit(app_btn_cfg_t *app_btn_cfg)
{
    VCOM_NULL_PARAM_CHK(app_btn_cfg, return APP_FAIL);
    return (SDK_OK == vesync_button_del(app_btn_cfg->gpio)) ? APP_OK : APP_FAIL;
}

