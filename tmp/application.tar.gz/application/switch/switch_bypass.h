/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        switch_bypass.h
 * @brief       switch bypass头文件
 * @author      Charles.Mei
 * @date        2021-08-05
 */


#ifndef __SWITCH_BYPASS_H__
#define __SWITCH_BYPASS_H__

#ifdef __cplusplus
    extern "C" {
#endif


/**
 * @brief 注册bypass回调函数
 */
void switch_bypass_reg_cb(void);


#ifdef __cplusplus
}
#endif

#endif

