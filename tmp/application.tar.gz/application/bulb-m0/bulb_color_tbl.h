/**
* Copyright © Vesync Technologies Co.Ltd. 2022. All rights reserved
* @file        bulb_color_tbl.h
* @brief       bulb颜色表全局声明
* @author      Herve
* @date        2022-01-21
*/
#ifndef __BULB_COLOR_TBL_H__
#define __BULB_COLOR_TBL_H__

#include "bulb_status.h"

#ifdef __cplusplus
extern "C" {
#endif

#define BULB_HSV_RAINBOW_TBL_LEN (7)     // HSV彩虹颜色表的大小
#define BULB_HSV_GRAD_WHITE_TBL_LEN (11) // HSV渐变白色表的大小

// HSV红色
extern const bulb_status_hsv_t g_hsv_red_color;
// HSV橙色
extern const bulb_status_hsv_t g_hsv_orange_color;
// HSV黄色
extern const bulb_status_hsv_t g_hsv_yellow_color;
// HSV绿色
extern const bulb_status_hsv_t g_hsv_green_color;
// HSV青色
extern const bulb_status_hsv_t g_hsv_cyan_color;
// HSV蓝色
extern const bulb_status_hsv_t g_hsv_blue_color;
// HSV紫色
extern const bulb_status_hsv_t g_hsv_purple_color;
// HSV暗色
extern const bulb_status_hsv_t g_hsv_dark_color;
// HSV白色10%亮度
extern const bulb_status_hsv_t g_hsv_white_color_10_pct;
// HSV白色20%亮度
extern const bulb_status_hsv_t g_hsv_white_color_20_pct;
// HSV白色30%亮度
extern const bulb_status_hsv_t g_hsv_white_color_30_pct;
// HSV白色40%亮度
extern const bulb_status_hsv_t g_hsv_white_color_40_pct;
// HSV白色50%亮度
extern const bulb_status_hsv_t g_hsv_white_color_50_pct;
// HSV白色60%亮度
extern const bulb_status_hsv_t g_hsv_white_color_60_pct;
// HSV白色70%亮度
extern const bulb_status_hsv_t g_hsv_white_color_70_pct;
// HSV白色80%亮度
extern const bulb_status_hsv_t g_hsv_white_color_80_pct;
// HSV白色90%亮度
extern const bulb_status_hsv_t g_hsv_white_color_90_pct;
// HSV白色100%亮度
extern const bulb_status_hsv_t g_hsv_white_color;

// HSV七彩表
extern const bulb_status_hsv_t *g_hsv_rainbow_tbl[];
// HSV白色渐变表
extern const bulb_status_hsv_t *g_hsv_grad_white_tbl[];

// 关闭白光输出
extern const bulb_status_white_t g_white_shutdown;
// 最暖100%白光亮度
extern const bulb_status_white_t g_white_2700k_100;
// 最暖50%白光亮度
extern const bulb_status_white_t g_white_2700k_50;
// 中等色温100%白光亮度
extern const bulb_status_white_t g_white_4600k_100;
// 中等色温50%白光亮度
extern const bulb_status_white_t g_white_4600k_50;
// 最冷100%白光亮度
extern const bulb_status_white_t g_white_6500k_100;
// 最冷50%白光亮度
extern const bulb_status_white_t g_white_6500k_50;

#ifdef __cplusplus
}
#endif

#endif /* __BULB_COLOR_TBL_H__ */