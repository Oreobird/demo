/**
 *  Copyright © Vesync Technologies Co.Ltd. 2019-2021. All rights reserved.
 * @file        vesync_tl_payload_parse.h
 * @brief       数据帧解析和封装
 * @author      zhenlang
 * @date        2019-09-24
 */

#ifndef __VESYNC_TL_PAYLOAD_PARSE_H__
#define __VESYNC_TL_PAYLOAD_PARSE_H__

#include <stdint.h>

#ifdef __cplusplus
extern "C"
{
#endif

/* playload版本 */
#define TL_PAYLOAD_PROTOCOL_VERSION     (2)     // payload采用KLV格式，对应版本号未2
#define TL_PAYLOAD_PROTOCOL_HEAD_LEN    (4)     // payload协议头部长度为4bytes

#pragma pack(1)
/**
 * @brief payload信息结构体
 * @note  该结构体与uart_payload_info_t相同，该协议适用于串口、BLE等
 */
typedef struct
{
    uint8_t version;                    // payload版本号
    uint16_t op_code;                   // 操作码opcode
    uint8_t status_code;                // 状态码，0表示正常，非0表示异常，详见TL_FRAME_STATUS_CODE_E
    uint8_t payload_data[1];            // 数据
} tl_payload_info_t;
#pragma pack()



/**
 * @brief  payload封装
 * @param[in]  op_code                  [操作码]
 * @param[in]  status_code              [状态码]
 * @param[in]  in_data                  [数据指针]
 * @param[in]  in_len                   [数据输入长度]
 * @param[out] out_data                 [数据输出缓存区]
 * @param[out] out_len                  [数据输出长度]
 * @return     int32_t                  [0表示成功, 非零表示失败]
 */
int32_t vesync_tl_payload_encode(uint16_t op_code, uint8_t status_code, uint8_t *in_data,
                                         uint16_t in_len, uint8_t *out_data, uint16_t *out_len);

#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_TL_PAYLOAD_PARSE_H__ */
