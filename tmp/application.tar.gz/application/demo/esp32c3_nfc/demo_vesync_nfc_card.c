/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
 * @file        demo_vesync_nfc_card.c
 * @brief       nfc carrd模块测试代码
 * @date        2021-11-13
 */

#include "vesync_log.h"
#include "vesync_common.h"
#include "vesync_cfg.h"
#include "vesync_log.h"
#include "stdio.h"
#include "string.h"
#include "vesync_memory.h"
#include "vesync_task.h"
#include "vhal_i2c.h"
#include "vhal_gpio.h"
#include "vdrv_fm11nt081dx.h"
#include "vesync_nfc_card.h"
#include "vesync_nfc.h"
#include "vesync_cfg_internal.h"


#define EE_SIZE (0xE6 * 4)

static uint8_t netcfg_info[] = {"\"serverDN\": \"test-vdmpmqtt.vesync.com:1883\",\"configKey\": \"0LcfI1kSJhEgs321\",\"serverIP\": \"35.171.216.2\",\"bleDebugPort\": \"on\",\"wifiSSID\": \"R6100-2.4G\",\"wifiPassword\": \"12345678\",\"pid\": \"3awa9gqd5x3zab27\""};


/**
 * @brief  nfc 配网测试任务
 * @param[in]  args              [任务入参]
 * @note
 */
static void nfc_netcfg_test_task(void *args)
{
    static int i = 0;
    uint8_t buf[EE_SIZE] = {0};
    
    vesync_nfc_card_start_netcfg();

    while (1)
    {
        i++;

        APP_LOG(LOG_DEBUG, "i= %d \n", i);
        memset(buf, 0, sizeof(buf));

        vesync_sleep(100);

        if (i == 100)
        {
            APP_LOG(LOG_DEBUG, "1  now stop net cfg\n");
            vesync_nfc_card_stop_netcfg();
        }



        if (i == 140)
        {
            APP_LOG(LOG_DEBUG, "2 start net cfg\n");
            vesync_nfc_card_start_netcfg();
        }

        if (i == 160)
        {
            APP_LOG(LOG_DEBUG, "2 stop net cfg\n");
            vesync_nfc_card_stop_netcfg();
        }
        vesync_sleep(1000);
    }
}

/**
 * @brief  NFC事件回调函数
 * @param[in]  event           [蓝牙事件类型]
 */
void test_vesync_nfc_card_evt_cb(VESYNC_NFC_EVT_E event)
{
    APP_LOG(LOG_INFO, "event =%d \n", event);
}

/**
 * @brief  nfc数据接收回调函数
 * @param[in]  p_data          [接收的命令数据]
 * @param[in]  length          [数据长度]
 */
void test_vesync_nfc_card_recv_cb(uint8_t *p_data, uint16_t length)
{
    APP_LOG(LOG_INFO, "origin data: %s\n", netcfg_info);
    APP_LOG(LOG_INFO, "nfc cfg data=%s\n", p_data);
    APP_LOG(LOG_INFO, "data len =%d\n", length);
    LOG_RAW_HEX(LOG_INFO, "nfc net cfg data hex: \n", p_data, 64);
}





void demo_vesync_nfc_card_test_init()
{
    vesync_nfc_card_ctrl_t  nfc_card_ctrl;

    memset(&nfc_card_ctrl, 0, sizeof(nfc_card_ctrl));
    nfc_card_ctrl.hw_interface.iic_ctrl.iic_cs_pin = CONFIG_NFC_IIC_CS_PIN;
    nfc_card_ctrl.hw_interface.iic_ctrl.scl_pin = CONFIG_NFC_IIC_SCL_PIN;
    nfc_card_ctrl.hw_interface.iic_ctrl.sda_pin = CONFIG_NFC_IIC_SDA_PIN;
    nfc_card_ctrl.interface_init_cb.iic_init_cb = vdrv_fm11nt081dx_init;

    nfc_card_ctrl.basic_info.dev_info_addr = CONFIG_NFC_CARD_DEV_INFO_ADDR;
    nfc_card_ctrl.basic_info.dev_info_len = CONFIG_NFC_CARD_DEV_INFO_LEN;
    nfc_card_ctrl.basic_info.netcfg_info_addr = CONFIG_NFC_CARD_DEV_NET_CFG_INFO_ADDR;
    nfc_card_ctrl.basic_info.netcfg_info_len = CONFIG_NFC_CARD_DEV_NET_CFG_INFO_LEN;
    nfc_card_ctrl.basic_info.netcfg_error_info_addr = CONFIG_NFC_CARD_DEV_NET_CFG_ERROR_ADDR;
    nfc_card_ctrl.basic_info.netcfg_error_info_len = CONFIG_NFC_CARD_DEV_NET_CFG_ERROR_LEN;
    nfc_card_ctrl.basic_info.uid_len = CONFIG_NFC_UID_MAX_LEN;


    nfc_card_ctrl.wake_up_ctrl.wait_time_after_wakeup_s = CONFIG_NFC_WAKEUP_WAIT_TIME_S;
    nfc_card_ctrl.wake_up_ctrl.wake_up_en = 1;
    nfc_card_ctrl.wake_up_ctrl.wake_up_pin = CONFIG_NFC_WAKEUP_PIN;
    nfc_card_ctrl.wake_up_init_cb = vdrv_fm11nt081dx_set_wakeup;
    nfc_card_ctrl.nfc_card_wake_up_isr_register_cb = (vesync_nfc_card_wake_up_isr_register)vdrv_fm11nt081dx_register_wake_cb;


    nfc_card_ctrl.psw_ctrl.psw_en = CONFIG_VESYNC_NFC_CARD_PWD_EN;
    nfc_card_ctrl.psw_ctrl.psw = CONFIG_VESYNC_NFC_CARD_PWD;
    nfc_card_ctrl.psw_ctrl.psw_ack =CONFIG_VESYNC_NFC_CARD_PWD_ACK;
        
    nfc_card_ctrl.psw_inti_cb = vdrv_fm11nt081dx_set_auth_pwd;

    nfc_card_ctrl.write_data_cb = vdrv_fm11nt081dx_write_data;
    nfc_card_ctrl.read_cb = vdrv_fm11nt081dx_read_data;
    nfc_card_ctrl.uid_get_cb = vdrv_fm11nt081dx_get_uid;

    vesync_nfc_card_create(&nfc_card_ctrl);
   
    vesync_nfc_card_reg_recv_cb(test_vesync_nfc_card_recv_cb);
    
    vesync_nfc_card_reg_event_cb(test_vesync_nfc_card_evt_cb);

   
    if (VOS_OK != vesync_task_new("nfc task", NULL, nfc_netcfg_test_task, NULL, 4 * 1024, 3, NULL))
    {
        APP_LOG(LOG_ERROR, "Create NFC  task fail!\n");
    }

    vesync_nfc_card_netcfg_data_send(TYPE_DEV, netcfg_info, sizeof(netcfg_info));

    vesync_sleep(1000);


}




uint8_t test_buf[300]={0};

uint8_t i2c_test_data[] = {"\"serverDN\": \"gjaiofj ga to m:9999\",\"configKey\": \"dkagdian 15364156\",\"serverIP\": \"45.26.89.21\",\"bleDebugPort\": \"dji\",\"wifiSSID\": \"ad fgad\",\"wifiPassword\": \"bule12345678\",\"pid\": \"564dfajg5djk34.,c/a\""};

/**
 * @brief nfc数据处理任务
 * @param[in]  pvParameters             [未使用]
 */
static void demo_iic_test_task(void *pvParameters) //此处有硬件操作，以及调起应用层回调，因此用任务不用timer
{
    uint16_t i = 0;
    while (1)
    {
        
        if (vdrv_fm11nt081dx_read_data(0x00E4, test_buf, 300) != SDK_OK)
        {
            APP_LOG(LOG_INFO, "read error\n");
        }
        else
        {
            APP_LOG(LOG_INFO, "read ok\n");
        }

        
        if(vesync_nfc_card_netcfg_data_send(TYPE_NETCFG_INFO, i2c_test_data, (uint16_t)strlen((char*)i2c_test_data)) != SDK_OK)
        {

             APP_LOG(LOG_INFO, "send error\n");
        }
        
        
        vesync_sleep(50);

        i++;

    }


}




void demo_iic_init()
{
     vesync_nfc_init();
    if (VOS_OK != vesync_task_new("iic test task", NULL, demo_iic_test_task, NULL, 4 * 1024, 3, NULL))
    {
        APP_LOG(LOG_ERROR, "Create nfc task fail!!!\n");
    }

}

