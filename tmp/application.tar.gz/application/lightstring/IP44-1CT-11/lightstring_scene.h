/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file    lightstring_scene.h
* @brief   场景参数
* @author  Lind
* @date    2021-12-22
*/

#ifndef __LIGHTSTRING_SCENE__
#define __LIGHTSTRING_SCENE__

#ifdef __cplusplus
extern "C" {
#endif

/**
* @brief 获取产测灯效
* @param[out]  **pst_scene      [产测灯效指针]
*/
void ls_get_production_scene(ls_led_dynamic_params **pst_scene);


/**
* @brief 获取场景模式参数指针
* @param[in]  **mode_head   [指针]
*/
void ls_get_scene_head(void **mode_head);

/**
* @brief 是否可调速检查
* @param[in]  id    [scene id]
* @return  bool     [true/false]
*/
bool ls_scene_id_speed_check(uint8_t id);


/**
* @brief 获取循环模式每个模式循环次数
* @param[in]  **arry_head       [指针]
*/
void ls_get_comb_cycle_times(uint8_t **arry_head);

#ifdef __cplusplus
}
#endif

#endif /* __LIGHTSTRING_SCENE__ */

