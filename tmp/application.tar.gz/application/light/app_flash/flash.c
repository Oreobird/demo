/**
*Copyright © Vesync Technologies Co.Ltd. 2022. All rights reserved.
* @file     flash.c
* @brief    设备应用存储接口
* @author   Joshua
*@date      2022-1-7
*/
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include "vesync_log.h"
#include "vesync_memory.h"
#include "vesync_common.h"
#include "vesync_flash.h"
#include "vesync_klv.h"
#include "app_cfg.h"

#include "flash.h"

int app_flash_cfg_write(flash_t *thiz)
{
    VCOM_NULL_PARAM_CHK(thiz, return APP_FAIL);

    int ret = APP_OK;
    uint8_t *p_buf= NULL;
    uint32_t ofs = 0;
    uint8_t version = 0;
    uint32_t buf_len = APP_FLASH_DATA_LEN;

    if (thiz->len_cal)
    {
        buf_len = thiz->len_cal(thiz);
    }

    p_buf = (uint8_t *)vesync_malloc(buf_len);
    if (p_buf == NULL)
    {
        return APP_FAIL;
    }

    memset(p_buf, 0, buf_len);

    version = APP_FLASH_CFG_VERSION;
    ofs += vesync_klv_set(p_buf + ofs, buf_len - ofs, KEY_VERSION, sizeof(version), (uint8_t*)&version);
    ofs += vesync_klv_set(p_buf + ofs, buf_len - ofs, KEY_ONOFF, sizeof(thiz->cfg.onoff), (uint8_t*)&thiz->cfg.onoff);
    ofs += vesync_klv_set(p_buf + ofs, buf_len - ofs, KEY_COLOR_MODE, sizeof(thiz->cfg.mode), (uint8_t*)&thiz->cfg.mode);
    ofs += vesync_klv_set(p_buf + ofs, buf_len - ofs, KEY_BEAD_NUM, sizeof(thiz->cfg.bead_num), (uint8_t*)&thiz->cfg.bead_num);
    ofs += vesync_klv_set(p_buf + ofs, buf_len - ofs, KEY_SEG_NUM, sizeof(thiz->cfg.seg_num), (uint8_t*)&thiz->cfg.seg_num);
    ofs += vesync_klv_set(p_buf + ofs, buf_len - ofs, KEY_SCENE_ID, sizeof(thiz->cfg.scene_id), (uint8_t*)&thiz->cfg.scene_id);
    ofs += vesync_klv_set(p_buf + ofs, buf_len - ofs, KEY_COLOR_PARAM, sizeof(thiz->cfg.light_param), (uint8_t*)&thiz->cfg.light_param);

    if (thiz->ext_set)
    {
        ret = thiz->ext_set(thiz, p_buf, buf_len, &ofs, &(thiz->cfg.extra));
    }

    //将数据写入指定flash分区
    ret = vesync_flash_write(PARTITION_CFG, APP_USER_CFG_KEY_DATA, p_buf, ofs);
    if (ret != SDK_OK)
    {
        APP_LOG(LOG_ERROR, "write flash fail, ret[%d]\n", ret);
        ret = APP_FAIL;
    }

    VCOM_SAFE_FREE(p_buf);

    return ret;
}

int app_flash_cfg_read(flash_t *thiz)
{
    VCOM_NULL_PARAM_CHK(thiz, return APP_FAIL);

    int ret = 0;
    uint8_t *p_buf= NULL;
    uint8_t version = 0;
    uint32_t buf_len = APP_FLASH_DATA_LEN;

    if (thiz->len_cal)
    {
        buf_len = thiz->len_cal(thiz);
    }

    p_buf = (uint8_t *)vesync_malloc(buf_len);
    if (p_buf == NULL)
    {
        return APP_FAIL;
    }

    ret = vesync_flash_read(PARTITION_CFG, APP_USER_CFG_KEY_DATA, p_buf, &buf_len);
    if (ret != SDK_OK)
    {
        APP_LOG(LOG_WARN, "read flash fail, ret[%d]\n", ret);
        VCOM_SAFE_FREE(p_buf);
        return APP_FAIL;
    }

    vesync_klv_get(p_buf, buf_len, KEY_VERSION, sizeof(version), (uint8_t*)&version);
    vesync_klv_get(p_buf, buf_len, KEY_ONOFF, sizeof(thiz->cfg.onoff), (uint8_t*)&thiz->cfg.onoff);
    vesync_klv_get(p_buf, buf_len, KEY_COLOR_MODE, sizeof(thiz->cfg.mode), (uint8_t*)&thiz->cfg.mode);
    vesync_klv_get(p_buf, buf_len, KEY_BEAD_NUM, sizeof(thiz->cfg.bead_num), (uint8_t*)&thiz->cfg.bead_num);
    vesync_klv_get(p_buf, buf_len, KEY_SEG_NUM, sizeof(thiz->cfg.seg_num), (uint8_t*)&thiz->cfg.seg_num);
    vesync_klv_get(p_buf, buf_len, KEY_SCENE_ID, sizeof(thiz->cfg.scene_id), (uint8_t*)&thiz->cfg.scene_id);
    vesync_klv_get(p_buf, buf_len, KEY_COLOR_PARAM, sizeof(thiz->cfg.light_param), (uint8_t*)&thiz->cfg.light_param);

    if (thiz->ext_get)
    {
        thiz->ext_get(thiz, p_buf, buf_len, &(thiz->cfg.extra));
    }

    VCOM_SAFE_FREE(p_buf);
    return APP_OK;
}

int app_flash_cfg_default_init(flash_t * thiz)
{
    if (thiz->default_init)
    {
        thiz->default_init(thiz);
    }
    else
    {
        APP_LOG(LOG_ERROR, "flash default set not implemented\n");
        return APP_FAIL;
    }
    return APP_OK;
}

int app_flash_cfg_reset(flash_t *thiz)
{
    VCOM_NULL_PARAM_CHK(thiz, return APP_FAIL);
    if (app_flash_cfg_default_init(thiz) != APP_OK)
    {
        return APP_FAIL;
    }
    return app_flash_cfg_write(thiz);
}

int app_flash_destroy(flash_t *thiz)
{
    VCOM_NULL_PARAM_CHK(thiz, return APP_FAIL);
    VCOM_SAFE_FREE(thiz);
    return APP_OK;
}

