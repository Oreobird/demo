/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        bulb_report.h
 * @brief       bulb上报头文件
 * @author      Dave
 * @date        2021-09-08
 */


#ifndef __BULB_REPORT_H__
#define __BULB_REPORT_H__


#include <stdint.h>

#include "vesync_schedule.h"
#include "bulb_flash.h"
#include "bulb.h"


#ifdef __cplusplus
     extern "C" {
#endif

/**
 * @brief 设备状态变化，通知云端
 * @param[in]  status            [灯泡状态]
 * @return     int               [成功：APP_OK， 失败：APP_FAIL]
 */
int bulb_report_status_change(bulb_status_t* status);

/**
 * @brief timer执行结果上报， deviceLogReport
 * @param[in]  action           [动作]
 * @param[in]  ret              [timer执行结果]
 * @param[in]  p_err_msg        [开timer执行失败原因]
 * @return     int              [成功：APP_OK， 失败：APP_FAIL]
 */
int bulb_report_timing_exec( void *action, uint8_t ret, char *p_err_msg);

/**
 * @brief schedule执行结果上报， deviceLogReport
 * @param[in]  sch_cfg          [schedule配置]
 * @param[in]  action           [动作]
 * @param[in]  ret              [schedule执行结果]
 * @param[in]  p_err_msg        [schedule执行失败原因]
 * @return     int              [成功：APP_OK， 失败：APP_FAIL]
 */
int bulb_report_schedule_exec(vesync_schedule_t *sch_cfg, void *action, uint8_t ret, char *p_err_msg);


#ifdef __cplusplus
}
#endif

#endif

