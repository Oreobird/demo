/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        button.h
 * @brief       按键模块接口定义
 * @date        2021-12-23
 */

#ifndef __BUTTON_H__
#define __BUTTON_H__


#include "stdint.h"
#include "vesync_button.h"

#ifdef __cplusplus
extern "C" {
#endif

#define APP_BUTTON_MAX_NUM  (4)

/**
 * @brief  短按功能类型
 */
typedef enum {
    SP_NONE = 0,              // 无功能
    ONOFF_SWITCH,             // 开/关
    COLOR_SWITCH,             // 颜色切换
    SCENE_SWITCH,             // 场景切换
    MODE_SWITCH,              // 模式切换
    BRIGHTNESS_LEVEL_ADJUST   // 亮度档位调节
} BTN_SHORT_PRESS_TYPE_E;

/**
 * @brief  长按功能类型
 */
typedef enum {
    LP_NONE = 0,                  // 无功能
    NETCFG,                       // 重置配网
    COLOR_INFINITE_ADJUST,        // 颜色无极调节
    BRIGHTNESS_INFINITE_ADJUST    // 亮度无极调节
} BTN_LONG_PRESS_TYPE_E;

typedef void (*press_fn_t)(void);

typedef struct
{
    uint8_t gpio;
    uint8_t active_level;
    BTN_SHORT_PRESS_TYPE_E short_press_type;
    BTN_LONG_PRESS_TYPE_E long_press_type;
} app_btn_cfg_t;


/**
 * @brief       配网按键初始化
 * @ param[in] *app_btn_cfg        [应用层按键结构体指针]
 * @return  int                    [成功：APP_OK，失败：APP_FAIL]
 */
int button_netcfg_init(app_btn_cfg_t *app_btn_cfg);

/**
* @brief       配网按键模块反初始化
* @ param[in] *app_btn_cfg         [应用层按键结构体指针]
* @return  int                     [成功：APP_OK，失败：APP_FAIL]
*/
int button_netcfg_deinit(app_btn_cfg_t *app_btn_cfg);

/**
 * @brief       长按初始化
 * @ param[in] *app_btn_cfg        [应用层按键结构体指针]
 * @return  int                    [成功：APP_OK，失败：APP_FAIL]
 */
int button_long_press_init(app_btn_cfg_t *app_btn_cfg);

/**
* @brief       长按反初始化
* @ param[in] *app_btn_cfg         [应用层按键结构体指针]
* @return  int                     [成功：APP_OK，失败：APP_FAIL]
*/
int button_long_press_deinit(app_btn_cfg_t *app_btn_cfg);


/**
 * @brief       短按初始化
 * @ param[in] *app_btn_cfg        [应用层按键结构体指针]
 * @return  int                    [成功：APP_OK，失败：APP_FAIL]
 */
int button_short_press_init(app_btn_cfg_t *app_btn_cfg);

/**
* @brief       短按反初始化
* @ param[in] *app_btn_cfg         [应用层按键结构体指针]
* @return  int                     [成功：APP_OK，失败：APP_FAIL]
*/
int button_short_press_deinit(app_btn_cfg_t *app_btn_cfg);


/**
 * @brief       按键初始化
 * @return  int                     [成功：APP_OK，失败：APP_FAIL]
 */
int app_button_init(void);

#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_BUTTON_H__ */



