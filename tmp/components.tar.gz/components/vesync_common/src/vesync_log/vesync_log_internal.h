/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_log_internal.h
 * @brief       log模块内部类型定义
 * @author      Joshua
 * @date        2021-04-20
 */

#ifndef __VESYNC_LOG_INTERNAL_H__
#define __VESYNC_LOG_INTERNAL_H__

#include "vesync_log.h"
#include "vesync_mutex.h"

#ifdef __cplusplus
extern "C" {
#endif

#define ENABLE_LOG_MUTEX

#define VESYNC_LOG_BUFF_MAX (1536)

/*
* @brief log tag map table
*/
typedef struct
{
    TYPE_COMPONENT_E comp;
    char comp_str[4];
    LOG_LEVEL_E level;
    char level_str[2];
} str_map_tbl_t;

typedef struct
{
    LOG_LEVEL_E level;
    LOG_LEVEL_E raw_level;
#ifdef ENABLE_LOG_MUTEX
    vesync_mutex_t mutex;
#endif
    char log_buf[VESYNC_LOG_BUFF_MAX];

    print_cb_t print_cb;
    log_transfer_cb_t transfer_cb;
} vesync_log_t;

#ifdef CONFIG_VESYNC_LOG_COLOR_ENABLE
#define LOG_COLOR_BLACK         "30"
#define LOG_COLOR_RED           "31"
#define LOG_COLOR_GREEN         "32"
#define LOG_COLOR_BROWN         "33"
#define LOG_COLOR_BLUE          "34"
#define LOG_COLOR_PURPLE        "35"
#define LOG_COLOR_CYAN          "36"
// 不带粗体控制的颜色输出宏
#define LOG_COLOR(color)        "\033[0;" color "m"
// 带粗体控制的颜色输出宏
#define LOG_BOLD(bold, color)   "\033[" #bold ";" color "m"
#define LOG_RESET_COLOR         "\033[0m"

/**
 * @brief 不同的打印等级颜色设定
 */
#define LOG_COLOR_E     LOG_COLOR(LOG_COLOR_RED)
#define LOG_COLOR_W     LOG_COLOR(LOG_COLOR_BROWN)
#define LOG_COLOR_I     LOG_COLOR(LOG_COLOR_CYAN)
#define LOG_COLOR_D     LOG_COLOR(LOG_COLOR_GREEN)
#endif /* CONFIG_VESYNC_LOG_COLOR_ENABLE */

/**
 * @brief  SDK日志打印
 */
#define SDK_LOG(level, format, ...) LOG_IMPL(COMP_SDK, level, format, ##__VA_ARGS__)

/**
 * @brief 读取普通日志打印级别
 * @return LOG_LEVEL_E  [Log打印等级]
 */
LOG_LEVEL_E vesync_log_level_get(void);

/**
 * @brief 读取十六进制数据日志打印级别
 * @return LOG_LEVEL_E  [Log打印等级]
 */
LOG_LEVEL_E vesync_log_raw_level_get(void);

#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_LOG_INTERNAL_H__ */

