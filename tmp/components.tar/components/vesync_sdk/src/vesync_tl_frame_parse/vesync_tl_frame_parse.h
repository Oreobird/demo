/**
 *  Copyright © Vesync Technologies Co.Ltd. 2019-2021. All rights reserved.
 * @file        vesync_tl_frame_parse.h
 * @brief       数据帧协议头部解析和封装
 * @author      zhenlang
 * @date        2019-06-25
 */

#ifndef __VESYNC_TL_FRAME_PARSE_H__
#define __VESYNC_TL_FRAME_PARSE_H__

#include <stdint.h>

#ifdef __cplusplus
extern "C"
{
#endif


#define TL_FRAME_HEAD          0xA5     // 帧起始符


/**
 * @brief 用于数据帧完整帧组包判断过程
 */
typedef enum
{
    TL_FRAME_RECV_HEAD = 0,             // 收到协议头
    TL_FRAME_RECV_CTRL,                 // 收到控制字节
    TL_FRAME_RECV_SEQ,                  // 收到帧计数字节
    TL_FRAME_RECV_LEN_L,                // 收到长度低字节
    TL_FRAME_RECV_LEN_H,                // 收到长度高字节
    TL_FRAME_RECV_SUM,                  // 收到校验和字节
    TL_FRAME_RECV_PAYLOAD               // 收到payload字节
} TL_FRAME_RECV_STATE_E;

/*
 * @brief 通用协议大纲V2错误码/状态码
 */
typedef enum
{
    TL_FRAME_COMMON_ERR           = 1,  // 通用错误码
    TL_FRAME_INTERNAL_ERR         = 2,  // 内部系统错误
    TL_FRAME_EXEC_FAILED          = 3,  // 业务执行失败
    TL_FRAME_OPCODE_FORMAT_ERR    = 21, // 操作码格式错误
    TL_FRAME_OPCODE_NOT_SUPPORT   = 22, // 操作码不支持
    TL_FRAME_VER_NOT_SUPPORT      = 31, // 版本不支持
    TL_FRAME_PAYLOAD_FORMAT_ERR   = 51, // payload格式错误
    TL_FRAME_PAYLOAD_DECRYPT_FAIL = 52, // payload密文无法解密
} TL_FRAME_STATUS_CODE_E;


/**
 * @brief 数据帧控制字段定义
 */
typedef union
{
    uint8_t data;
    struct
    {
        uint8_t  version:     4;        // 协议版本号，当前版本定义为2；
        uint8_t  ack_flag:    1;        // 用于指示当前数据包是命令还是应答    0：命令    1: 应答；
        uint8_t  request_flag:1;        // 用于指示接收该数据包的设备是否需要回应答，0：不需要回应答  1：需要回应答；
        uint8_t  error_flag:  1;        // 应答包错误指示位
        uint8_t  resv:        1;        // 保留
    } bitN;
} tl_frame_ctrl_u;

/**
 * @brief 数据帧接收信息结构体
 */
typedef struct{
    tl_frame_ctrl_u       ctrl;         // 控制字段
    uint8_t               seq_id;       // 序列号
    uint16_t              payload_len;  // payload长度
    uint8_t               checksum;     // 校验和
    TL_FRAME_RECV_STATE_E state;        // 帧组合过程状态记录
    uint16_t              payload_pos;  // payload缓存计数
    uint8_t               *p_payload;   // payload指针
} tl_frame_recv_info_t;


/**
 * @brief 数据帧发送信息结构体
 */
typedef struct
{
    tl_frame_ctrl_u       ctrl;         // 控制字段
    uint8_t               seq_id;       // 序列号
    uint16_t              payload_len;  // payload长度
    uint8_t               checksum;     // 校验和
    uint8_t               *p_payload;   // payload指针
} tl_frame_send_info_t;

/**
 * @brief  计算和校验值
 * @param[in]  frame            [被校验数据帧结构]
 * @return     uint8_t          [校验值]
 * @note   该接口用于测试
 */
uint8_t vesync_tl_frame_checksum_cal(tl_frame_recv_info_t *frame);

/**
 * @brief  验证校验和计算结果
 * @param[in]  frame            [被校验数据帧结构]
 * @return     uint8_t          [校验结果 0:表示校验成功； 1：表示校验失败]
 */
uint8_t vesync_tl_frame_checksum_verify(tl_frame_recv_info_t *frame);

/**
 * @brief  传输层(transport layer)协议解析，协议数据按照顺序逐个字节传入
 * @param[in]  byte_data        [当前传入的字节数据]
 * @param[in]  max_pl_len       [payload最大长度]
 * @param[out] frame            [功能模块的结构体指针]
 * @return     uint8_t          [解析的结果，0：完整数据帧；1:非完整数据帧]
 */
uint8_t vesync_tl_frame_decode(uint8_t byte_data, uint32_t max_pl_len, tl_frame_recv_info_t *frame);

/**
 * @brief  传输层(transport layer)数据帧封包
 * @param[in]  frame            [功能模块的结构体指针]
 * @param[out] out_buf          [封装好的数据帧缓存区指针]
 * @param[out] out_len          [封装数据帧长度]
 * @return     uint8_t          [封包的结果，0：封包成功；1:封包失败]
 */
uint8_t vesync_tl_frame_encode(tl_frame_send_info_t *frame, uint8_t *out_buf, uint16_t *out_len);

#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_TL_FRAME_PARSE_H__ */
