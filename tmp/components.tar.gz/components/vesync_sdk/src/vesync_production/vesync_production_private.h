/*
 * Copyright © Vesync Technologies Co.Ltd. 2019-2021. All rights reserved.
 * @file    vesync_production_private.h
 * @brief   产测模块私有头文件
 * @author  CharlesMei
 * @date    2021-05-25
 */


#ifndef __VESYNC_PRODUCTION_PRIVATE_H__
#define __VESYNC_PRODUCTION_PRIVATE_H__


#include <stdint.h>

#include "vesync_cfg_internal.h"

#include "vesync_production_internal.h"

/* The following is the redirection of the interface called by this module */


#ifndef VERR_OK
#include "vesync_common.h"
#define VERR_OK SDK_OK
#define VERR_FAIL SDK_FAIL
#endif /* VERR_OK */

#ifndef PRODUCTION_LOG
#include "vesync_log_internal.h"
#ifdef SDK_LOG
#define PRODUCTION_LOG SDK_LOG
#else
#define PRODUCTION_LOG(level, format, ...)
#endif /* SDK_LOG */
#endif /* PRODUCTION_LOG */

#ifndef PRODUCTION_UTIL_MEM_CHECK
#include "vesync_common.h"
#ifdef VCOM_NULL_PARAM_CHK
#define PRODUCTION_UTIL_MEM_CHECK VCOM_NULL_PARAM_CHK
#else
#define PRODUCTION_UTIL_MEM_CHECK(param, action) \
    do {                                         \
        if (NULL == (param))                     \
        {                                        \
            action;                              \
        }                                        \
    } while (0)
#endif /* VCOM_NULL_PARAM_CHK */
#endif /* PRODUCTION_UTIL_MEM_CHECK */

#ifndef PRODUCTION_UTIL_SAFE_FREE
#include "vesync_common.h"
#ifdef VCOM_SAFE_FREE
#define PRODUCTION_UTIL_SAFE_FREE VCOM_SAFE_FREE
#else
#define PRODUCTION_UTIL_SAFE_FREE(ptr)      \
    do{                                     \
        if (NULL != ptr)                    \
        {                                   \
            vesync_free(ptr);               \
            ptr = NULL;                     \
        }                                   \
    } while(0)
#endif /* VCOM_SAFE_FREE */
#endif /* PRODUCTION_UTIL_SAFE_FREE */

#ifndef UNUSED
#define UNUSED(x) (void)(x);
#endif /* UNUSED */

#define VERR_UPLOAD(x, y)
#define VESYNC_PRINTF_FREE_HEAP()

#if CONFIG_VESYNC_SDK_NET_SERVICE_ENABLE
#include "vesync_net_service_internal.h"
#else
#define vesync_net_client_disconnect_server(...)
#define vesync_net_event_management_disable(...)
#endif /* CONFIG_VESYNC_SDK_NET_SERVICE_ENABLE */

#if CONFIG_VESYNC_SDK_NETCFG_ENABLE
#include "vesync_netcfg.h"
#else
#define vesync_netcfg_stop(...)
#endif /* CONFIG_VESYNC_SDK_NETCFG_ENABLE */

#if CONFIG_VESYNC_SDK_FFS_ENABLE
#include "vesync_ffs.h"
#else
#define vesync_ffs_stop(...)
#endif /* CONFIG_VESYNC_SDK_FFS_ENABLE */

#if CONFIG_VESYNC_SDK_LAN_COMM_ENABLE
#include "vesync_lan_comm.h"
#else
#define vesync_lan_comm_stop(...)
#endif /* CONFIG_VESYNC_SDK_LAN_COMM_ENABLE */

#if CONFIG_VESYNC_SDK_WIFI_ENABLE
#include "vesync_wifi_led.h"
#else
#define vesync_wifi_led_set_behavior(...)
#endif /* CONFIG_VESYNC_SDK_WIFI_ENABLE */

#if CONFIG_VESYNC_SDK_DEVELOPER_ENABLE
#include "vesync_developer_internal.h"
#else
#define vesync_developer_start(...)
#endif /* CONFIG_VESYNC_SDK_DEVELOPER_ENABLE */


#include "vesync_common.h"
#ifndef MAC_ADDR_STR_MAX_LEN
#define MAC_ADDR_STR_MAX_LEN    (20)
#endif /* MAC_ADDR_STR_MAX_LEN */
#ifndef WIFI_SSID_MAX_LEN
#define WIFI_SSID_MAX_LEN       (32)
#endif /* WIFI_SSID_MAX_LEN */
#ifndef WIFI_PWD_MAX_LEN
#define WIFI_PWD_MAX_LEN        (64)
#endif /* WIFI_PWD_MAX_LEN */
#ifndef CID_BUF_MAX_LEN
#define CID_BUF_MAX_LEN         (64)
#endif /* MAC_ADDR_STR_MAX_LEN */


/* The above is the redirection of the interface called by this module */


#if CONFIG_VESYNC_SDK_BLE_SERVICE_ENABLE
// 产测BLE相关参数
#define PRODUCTION_TYPE_BLE                0x88   // 产品类型
#define PRODUCTION_MODEL_BLE               0x88   // 产品型号
#define PRODUCTION_CMD_CODE                0xff   // 产测命令码


#define POROTOCOL_PAYLOAD_HEAD_LENGTH    4

#endif /* CONFIG_VESYNC_SDK_BLE_SERVICE_ENABLE */

// 等待上报准备完成，等待10s
#define REPROT_READY_FLAG_WAIT_TIME (10000)
// Wi-Fi test，等待wifi连接，等待20s
#define WIFI_TEST_CONNECTED_WAIT_TIME (20000)

// 产测上报已准备标志
#define REPORT_NETWORK_READY_FLAG   (0x01)
#define REPORT_MCU_READY_FLAG       (0x02)
#define REPORT_BLE_READY_FLAG       (0x04)

// testmode任务参数
#define PRODUCTION_TESTMODE_TASK_NAME       "testmode_task"
//
#if defined(PR_PRODUCTION_TESTMODE_TASK_STACKSIZE)
#define PRODUCTION_TESTMODE_TASK_STACKSIZE  (PR_PRODUCTION_TESTMODE_TASK_STACKSIZE)
#else
#define PRODUCTION_TESTMODE_TASK_STACKSIZE  (1024*2)
#endif
//
#define PRODUCTION_TESTMODE_TASK_PRIO       TASK_PRIORITY_ABOVE_NORMAL

// wifi_test任务参数
#define PRODUCTION_WIFI_TEST_TASK_NAME       "wifi_test_task"
#define PRODUCTION_WIFI_TEST_TASK_STACKSIZE  (2048)
#define PRODUCTION_WIFI_TEST_TASK_PRIO       TASK_PRIORITY_ABOVE_NORMAL


// 产测通过标志，如没有该标志标示未产测通过
#define PRODUCTION_MAGIC_CODE   (0xAABBCCDD)
#define PRODUCTION_DEFAULT_MAGIC_CODE    (0xFFFFFFFF)

// 键值名
#define USER_CFG_KEY_PRD_ERR_CODE           "prd_err_code"              // 存储产测过程中的错误码
#define USER_CFG_KEY_PRD_FLAG               "cfg_production"            // 产测成功字段
#define FAC_DATA_KEY_PRD_FLAG               USER_CFG_KEY_PRD_FLAG       // 产测成功字段(备份分区)

#define USER_CFG_KEY_PRD_CFG_DATA           "prd_cfg_data"
#define PRODUCTION_CID_LEN                  32
#define PRODUCTION_CID_DEFAULT              "defaultcid"                // CID默认值

#define PRODUCTION_BLE_RSSI_REPORT_OPCODE   (0xD006)                    // 蓝牙产测OPCODE

/**
 * @brief       产测相关数据结构体
 */
typedef struct
{
    uint8_t config_version;             // 产测数据版本，从1开始
    uint16_t err_code;                  // 产测错误码，默认为PRD_NO_ERR
    bool test_fail_flag;                // 产测失败标志，默认为true
    uint8_t cid[PRODUCTION_CID_LEN+4];  // 产品CID
}production_cfg_data_info_t;


typedef struct
{
    uint8_t wifiSSID[WIFI_SSID_MAX_LEN];
    uint8_t wifiPassword[WIFI_PWD_MAX_LEN];
} production_wifi_info_t;


#else
#error This private file can only be included by owner
#endif /* __VESYNC_PRODUCTION_PRIVATE_H__ */

