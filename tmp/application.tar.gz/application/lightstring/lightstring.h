/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file    lightstring.h
* @brief   灯串应用层
* @author  Lind
* @date     2021-12-13
*/

#ifndef __LIGHTSTRING_H__
#define __LIGHTSTRING_H__

#include "vesync_device.h"
#include "vesync_task.h"

#include "lightstring_led.h"

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#define LS_APP_TASK_NAME                   "app_task"
#define LS_APP_TASK_STACSIZE               (1024*2)
#define LS_APP_TASK_PRIO                   TASK_PRIORITY_NORMAL
#define LS_EVENT_QUEUE_MAX_NUM             16

#define LS_BRIGHTNESS_MAX       (100)   // 设置的亮度百分比
#define LS_SPEED_MAX            (4)     // 设置的速度分档


/**
 * @brief  lightstring应用事件id
 */
typedef enum
{
    LS_EV_RESET = 0,
    LS_EV_BEFORE_NETCFG,
    LS_EV_NETCFG,
    LS_EV_PRODUCTION,
    LS_EV_OFF,
    LS_EV_ON,
    LS_EV_VOICE_CTRL_ONOFF,
    LS_EV_SET_TIMER,
    LS_EV_UNKNOWN,
} LS_EV_E;

/**
 * @brief  lightstring应用事件来源
 */
typedef enum
{
    LS_ACT_SRC_INIT = 0,        // 初始化
    LS_ACT_SRC_DEVICE,          // 按键/遥控定时器
    LS_ACT_SRC_BYPASS,          // bypass指令
    LS_ACT_SRC_SCHEDULE,        // schedule
    LS_ACT_SRC_TIMER,           // timer
    LS_ACT_SRC_VOICE_CTRL,      // 声控
    LS_ACT_SRC_PRODUCTION,      // 产测
    LS_ACT_SRC_IR,              // 红外
    LS_ACT_SRC_UNKNOW,          // 未知
} LS_ACT_SRC_E;

typedef enum
{
    LS_TIMER_OFF = 0,
    LS_TIMER_6,
    LS_TIMER_8,
    LS_TIMER_6639,
} LS_TIMER_E;

/**
 * @brief  lightstring应用事件结构体
 */
typedef struct
{
    LS_EV_E id;
    LS_ACT_SRC_E act_src;
    union
    {
        bool voice_ctrl;
        LS_TIMER_E timer_mode;
        ls_mode_param_t mode_param;
    } param;
} ls_ev_t;

/**
 * @brief  lightstring状态记录
 */
typedef struct
{
    bool status;
    LS_MODE_E mode;         // 当前模式
    uint8_t scene_id;       // 普通场景id
    uint8_t music_id;       // 音乐场景id
    LS_TIMER_E timer_mode;  // 遥控定时器模式
    uint8_t speed;          // 动态场景速度
    bool voice_ctrl;        // 声控功能使能标志位
    uint8_t brightness;     // 普通场景最大亮度
} ls_status_t;

/**
 * @brief  给lightstring应用任务发通知
 * @param[in]   ev              [通知消息]
 * @return     int              [成功：APP_OK，失败：APP_FAIL]
 */
int ls_app_task_notify(ls_ev_t *ev);

/**
* @brief 获取遥控定时器模式
* @return  LS_TIMER_E       [定时器模式]
*/
LS_TIMER_E ls_get_timer_mode(void);

/**
* @brief
* @param[out]  *pst_status       [状态参数]
*/
void ls_get_status(ls_status_t *pst_status);


/**
* @brief 初始化应用层配置
*/
void ls_status_init(void);

#ifdef __cplusplus
 }
#endif /* __cplusplus */

#endif /* __LIGHTSTRING_H__ */


