/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_ffs.h
 * @brief       vesync平台与ffs SDK通信接口
 * @author      Dongri.Su
 * @date        2020-02-28
 */

#ifndef _VESYNC_FFS_INTERNAL_H_
#define _VESYNC_FFS_INTERNAL_H_

// 头文件
#include <string.h>
#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>

#include "vesync_device_internal.h"
#include "vesync_wifi_scan.h"
#include "vesync_net_service_internal.h"
#include "vesync_ffs.h"
#include "vesync_common.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef VERR_UPLOAD
#define VERR_UPLOAD(x, y)
#endif

#define FFS_PRINT_FREE_HEAP() VCOM_PRINT_FREE_HEAP()


#define vesync_ffs_aplist_get_apcount() vesync_wifi_aplist_get_num()
#define vesync_ffs_aplist_get_apinfo(x) vesync_wifi_get_apinfo_by_index(x)
#define vesync_ffs_aplist_clear() vesync_wifi_aplist_clear()
#define vesync_ffs_aplist_add_hal_cb vesync_wifi_scan_vhal_cb
#define vesync_ffs_aplist_scan() vesync_wifi_scan_start();

#define vesync_ffs_get_server_domain() vesync_net_mgmt_get_server_domain()
#define vesync_ffs_get_server_port() vesync_net_mgmt_get_server_port()    
#define vesync_ffs_get_server_ip() vesync_net_mgmt_get_server_ip()

#define vesync_ffs_delete_net_cfg_data() vesync_device_delete_net_cfg_data()


// 宏定义
#define MAX_FFS_NETCFG_TIME_MS                  (120*1000)      // FFS配网定时最大时间
#define MAX_FFS_WAIT_CLOUD_NOTIFY_MS            (60*1000)       // 等待云绑定用户的最大时间
#define FFS_EVENT_PUBLISH_STR       "ffs"

// 宏定义
#ifdef FFS_SERV_DEBUG
#define VESYNC_FFS_SERV_NAME "test-vdmpmqtt.vesync.com" //测试环境
#else
#define VESYNC_FFS_SERV_NAME "cloud-ffs-mqtt.vesync.com" //预发布环境
#endif


/*
 * @brief FFS配网状态
 */
typedef enum
{
    VESYNC_FFS_INIT         = 0,         // 初始化状态
    VESYNC_FFS_RUNNING      = 1,         // 正在进行中
    VESYNC_FFS_SUCC         = 2,         // 成功
    VESYNC_FFS_FAIL         = 3,         // 失败
} VESYNC_FFS_STATE_E;


/*
 * @brief FFS成功后保存的数据，用于vesync云与Amazon云通信
 */
typedef struct
{
    char *signature;
    char *sessionToken;
    //char *ssid;
    //char *pwd;
    char *alexaEvtGwEp;
} FfsResultString_t;

/**
 * @brief  FFS获取配网信息指针
 * @return net_info_t *         [配网信息指针]
 */
net_info_t *vesync_ffs_get_cfg(void);


/**
 * @brief   进入FFS配网模式，并进行MQTT连接、订阅
 * @param   void
 */
int vesync_ffs_start_netcfg(void);

/**
 * @brief   清除ffs配网结果，使设备可以重复进入ffs
 */
void vesync_ffs_result_clean(void);


/**
 * @brief  检查ffs配网功能是否有效, 配网成功后即失效
 * @return  int                     [SDK_OK FFS配网功能有效, SDK_FAIL FFS配网功能失效]
 */
int vesync_ffs_is_active(void);

/**
 * @brief  ffs配网功能失能
 * @return  int                     [SDK_OK 成功, SDK_FAIL 失败]
 */
int vesync_ffs_disable(void);

/**
 * @brief  FFS获取配网状态
 * @return VESYNC_FFS_STATE_E       [ffs配网状态]
 */
VESYNC_FFS_STATE_E vesync_ffs_get_state(void);

/**
 * @brief  FFS设置配网状态
 * @param[in]  state                [ffs配网状态]
 */
void vesync_ffs_set_state(VESYNC_FFS_STATE_E state);

/**
 * @brief  获取FFS Result string
 * @return FfsResultString_t        [ffs result string]
 */
FfsResultString_t vesync_ffs_get_result_string(void);

/**
 * @brief 结束FFS配网时清理和重置
 */
void vesync_ffs_exit(void);

/**
 * @brief   是否处于ffs配网
 * @return  bool                 [true：FFS配网中；false：非FFS配网中]
 */
bool vesync_ffs_is_running(void);

#ifdef __cplusplus
}
#endif

#endif //_VESYNC_FFS_INTERNAL_H_

