/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
 * @file        vdrv_sm2235egh.c
 * @brief       sm2235egh驱动接口
 * @author      Herve
 * @date        2021-11-30
 */
#include <stddef.h>
#include <stdbool.h>

#include "vesync_common.h"
#include "vesync_utils.h"
#include "vesync_log_internal.h"

#include "vhal_i2c.h"
#include "vdrv_sm2235egh.h"

#define SM2235EGH_IIC_PORT (0)       // IIC总线端口
#define SM2235EGH_IIC_ADDR (0xc0)    // IIC地址
#define SM2235EGH_IIC_SPEED (100000) // IIC速率
#define SM2235EGH_DEFAULT_CR (0x24)  // 默认的电流量程

// 输出寄存器地址枚举
enum out_reg_addr
{
    OUT1_ADDR = 0x00,
    OUT2_ADDR = 0x01,
    OUT3_ADDR = 0x02,
    OUT4_ADDR = 0x03,
    OUT5_ADDR = 0x04,
};

// 设备工作模式
static SM2235EGH_MODE_E s_dev_mode = SHUTDOWN;
// 设备电流量程
uint8_t s_curt_range = SM2235EGH_DEFAULT_CR;

// 设备寄存器映射类型定义
#pragma pack(push, 1)
struct ss2235egh_reg_map
{
    uint8_t curt_range;    // 电流量程
    uint16_t out_1r_or_4c; // IO1的灰度
    uint16_t out_2g_or_5w; // IO2的灰度
    uint16_t out_3b;       // IO3的灰度
    uint16_t out_4c;       // IO4的灰度
    uint16_t out_5w;       // IO5的灰度
};
#pragma pack(pop)

int vdrv_sm2235egh_init(uint8_t sda_io, uint8_t scl_io)
{
    int ret = vhal_i2c_master_init(SM2235EGH_IIC_PORT,
                                   sda_io,
                                   scl_io,
                                   SM2235EGH_IIC_SPEED);
    if (ret != VHAL_OK)
    {
        return SDK_FAIL;
    }

    return SDK_OK;
}

int vdrv_sm2235egh_set_mode(SM2235EGH_MODE_E mode)
{
    uint8_t addr = SM2235EGH_IIC_ADDR | mode;

    int ret = vhal_i2c_master_write(SM2235EGH_IIC_PORT, false, addr, NULL, 0);
    if (ret != VHAL_OK)
    {
        return SDK_FAIL;
    }
    s_dev_mode = mode;
    return SDK_OK;
}

int vdrv_sm2235egh_set_cr(uint8_t *p_rgb_or_cw, uint8_t *p_optional_cw)
{
    uint8_t addr = SM2235EGH_IIC_ADDR | s_dev_mode;

    if (NULL == p_rgb_or_cw)
    {
        return SDK_FAIL;
    }
    switch (s_dev_mode)
    {
    case RGB_MODE:
        s_curt_range = ((*p_rgb_or_cw) << 4) | (s_curt_range & 0x0f);
        break;
    case CW_MODE:
        s_curt_range = (s_curt_range & 0xf0) | ((*p_rgb_or_cw) & 0x0f);
        break;
    case SHUTDOWN:
    case RGBCW_MODE:
        if (NULL == p_optional_cw)
        {
            return SDK_FAIL;
        }
        s_curt_range = ((*p_rgb_or_cw) << 4) | ((*p_optional_cw) & 0x0f);
        break;
    default:
        SDK_LOG(LOG_ERROR, "invalid mode\n");
        return SDK_FAIL;
    }

    int ret = vhal_i2c_master_write(SM2235EGH_IIC_PORT,
                                    false,
                                    addr,
                                    &s_curt_range,
                                    1);
    if (ret != VHAL_OK)
    {
        return SDK_FAIL;
    }
    return SDK_OK;
}

int vdrv_sm2235egh_set_output(sm2235egh_gray_t *p_rgb_or_cw, sm2235egh_gray_t *p_optional_cw)
{
    uint8_t addr = SM2235EGH_IIC_ADDR | s_dev_mode;
    uint8_t data_len;
    struct ss2235egh_reg_map reg_map = {s_curt_range};

    if (NULL == p_rgb_or_cw)
    {
        return SDK_FAIL;
    }
    switch (s_dev_mode)
    {
    case RGB_MODE:
        addr |= OUT1_ADDR;
        data_len = 1 + 3 * 2;
        reg_map.out_1r_or_4c = vesync_htobe16(p_rgb_or_cw->rgb.out_1r);
        reg_map.out_2g_or_5w = vesync_htobe16(p_rgb_or_cw->rgb.out_2g);
        reg_map.out_3b = vesync_htobe16(p_rgb_or_cw->rgb.out_3b);
        break;
    case CW_MODE:
        addr |= OUT4_ADDR;
        data_len = 1 + 2 * 2;
        reg_map.out_1r_or_4c = vesync_htobe16(p_rgb_or_cw->cw.out_4c);
        reg_map.out_2g_or_5w = vesync_htobe16(p_rgb_or_cw->cw.out_5w);
        break;
    case SHUTDOWN:
    case RGBCW_MODE:
        addr |= OUT1_ADDR;
        data_len = 1 + 5 * 2;
        if (NULL == p_optional_cw)
        {
            return SDK_FAIL;
        }
        reg_map.out_1r_or_4c = vesync_htobe16(p_rgb_or_cw->rgb.out_1r);
        reg_map.out_2g_or_5w = vesync_htobe16(p_rgb_or_cw->rgb.out_2g);
        reg_map.out_3b = vesync_htobe16(p_rgb_or_cw->rgb.out_3b);
        reg_map.out_4c = vesync_htobe16(p_optional_cw->cw.out_4c);
        reg_map.out_5w = vesync_htobe16(p_optional_cw->cw.out_5w);
        break;
    default:
        SDK_LOG(LOG_ERROR, "invalid mode\n");
        return SDK_FAIL;
    }

    int ret = vhal_i2c_master_write(SM2235EGH_IIC_PORT,
                                    false,
                                    addr,
                                    (uint8_t *)&reg_map,
                                    data_len);
    if (ret != VHAL_OK)
    {
        return SDK_FAIL;
    }
    return SDK_OK;
}
