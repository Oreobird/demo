/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
* @file         production_light.h
* @brief        产测灯效控制
* @author       Joshua
* @date         2021-11-20
*/

#include <stdint.h>
#include "vesync_common.h"
#include "scene.h"

#ifndef __PRODUCTION_LIGHT_H__
#define __PRODUCTION_LIGHT_H__

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief  产测灯效回调
 * @return  int             [成功：APP_OK，失败：APP_FAIL]
 */
typedef int (*prd_light_cb_t)(void);

/**
 * @brief  产测灯效场景结构体
 */
typedef struct
{
    prd_light_cb_t prd_age_test_pre_light;
    prd_light_cb_t prd_age_testing_light;
    prd_light_cb_t prd_age_test_post_light;
    prd_light_cb_t prd_start_light;
    prd_light_cb_t prd_running_light;
    prd_light_cb_t prd_pass_light;
    prd_light_cb_t prd_fail_light;
} prd_light_scene_t;


/**
 * @brief  老化测试前场景灯效
 * @param[in] thiz          [场景结构体指针]
 * @return  int             [成功：APP_OK，失败：APP_FAIL]
 */
static inline int prd_light_scene_pre_age_test(scene_t *thiz)
{
    VCOM_NULL_PARAM_CHK(thiz, return APP_FAIL);
    prd_light_scene_t *ctx = (prd_light_scene_t *)thiz->ctx;
    return (ctx && ctx->prd_age_test_pre_light) ? ctx->prd_age_test_pre_light() : APP_FAIL;
}

/**
 * @brief  老化测试场景灯效
 * @param[in] thiz          [场景结构体指针]
 * @return  int             [成功：APP_OK，失败：APP_FAIL]
 */
static inline int prd_light_scene_age_testing(scene_t *thiz)
{
    VCOM_NULL_PARAM_CHK(thiz, return APP_FAIL);
    prd_light_scene_t *ctx = (prd_light_scene_t *)thiz->ctx;
    return (ctx && ctx->prd_age_testing_light) ? ctx->prd_age_testing_light() : APP_FAIL;
}

/**
 * @brief  老化测试扣场景灯效
 * @param[in] thiz          [场景结构体指针]
 * @return  int             [成功：APP_OK，失败：APP_FAIL]
 */
static inline int prd_light_scene_post_age_test(scene_t *thiz)
{
    VCOM_NULL_PARAM_CHK(thiz, return APP_FAIL);
    prd_light_scene_t *ctx = (prd_light_scene_t *)thiz->ctx;
    return (ctx && ctx->prd_age_test_post_light) ? ctx->prd_age_test_post_light() : APP_FAIL;
}

/**
 * @brief  产测测试开始场景灯效
 * @param[in] thiz          [场景结构体指针]
 * @return  int             [成功：APP_OK，失败：APP_FAIL]
 */
static inline int prd_light_scene_start(scene_t *thiz)
{
    VCOM_NULL_PARAM_CHK(thiz, return APP_FAIL);
    prd_light_scene_t *ctx = (prd_light_scene_t *)thiz->ctx;
    return (ctx && ctx->prd_start_light) ? ctx->prd_start_light() : APP_FAIL;
}

/**
 * @brief  产测测试场景灯效
 * @param[in] thiz          [场景结构体指针]
 * @return  int             [成功：APP_OK，失败：APP_FAIL]
 */
static inline int prd_light_scene_running(scene_t *thiz)
{
    VCOM_NULL_PARAM_CHK(thiz, return APP_FAIL);
    prd_light_scene_t *ctx = (prd_light_scene_t *)thiz->ctx;
    return (ctx && ctx->prd_running_light) ? ctx->prd_running_light() : APP_FAIL;
}

/**
 * @brief  产测测试成功场景灯效
 * @param[in] thiz          [场景结构体指针]
 * @return  int             [成功：APP_OK，失败：APP_FAIL]
 */
static inline int prd_light_scene_pass(scene_t *thiz)
{
    VCOM_NULL_PARAM_CHK(thiz, return APP_FAIL);
    prd_light_scene_t *ctx = (prd_light_scene_t *)thiz->ctx;
    return (ctx && ctx->prd_pass_light) ? ctx->prd_pass_light() : APP_FAIL;
}

/**
 * @brief  产测测试失败场景灯效
 * @param[in] thiz          [场景结构体指针]
 * @return  int             [成功：APP_OK，失败：APP_FAIL]
 */
static inline int prd_light_scene_fail(scene_t *thiz)
{
    VCOM_NULL_PARAM_CHK(thiz, return APP_FAIL);
    prd_light_scene_t *ctx = (prd_light_scene_t *)thiz->ctx;
    return (ctx && ctx->prd_fail_light) ? ctx->prd_fail_light() : APP_FAIL;
}

/**
 * @brief  产测场景灯效实现初始化
 * @return int           [成功：APP_OK， 失败：APP_FAIL]
 */
int prd_light_scene_impl_init(void);


/**
 * @brief  注册产测场景灯效
 * @param[in] *light_scene      [产测灯效场景结构体指针]
 * @return  int                 [成功：APP_OK，失败：APP_FAIL]
 */
int prd_light_scene_reg(prd_light_scene_t *light_scene);

/**
 * @brief  注销产测场景灯效
 * @return  int             [成功：APP_OK，失败：APP_FAIL]
 */
int prd_light_scene_unreg(void);

#ifdef __cplusplus
}
#endif

#endif

