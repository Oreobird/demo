/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file    vhal_i2c.h
 * @brief   vesync设备i2c读写接口
 * @author  Charles.Mei
 * @date    2021-03-22
 */

#include <stdint.h>

#include "hal_i2c.h"

#include "vesync_common.h"
#include "vhal_i2c.h"


int32_t vhal_i2c_master_init(uint8_t i2c_num, uint8_t sda_io, uint8_t scl_io, uint32_t speed)
{
    UNUSED(sda_io);
    UNUSED(scl_io);
    return (0 == hal_i2c_init(i2c_num, speed)) ? VHAL_OK : VHAL_FAIL;
}

int32_t vhal_i2c_master_read(uint8_t i2c_num, bool check_ack, uint8_t addr, uint8_t *p_data, int32_t len)
{
    UNUSED(i2c_num);
    UNUSED(check_ack);
    return (EV_I2C_END_INT == hal_i2c_read_block(addr, (char *)p_data, len, 0, 0x00)) ? VHAL_OK : VHAL_FAIL;
}

int32_t vhal_i2c_master_write(uint8_t i2c_num, bool check_ack, uint8_t addr, uint8_t *p_data, int32_t len)
{
    UNUSED(i2c_num);
    UNUSED(check_ack);
    return (EV_I2C_END_INT == hal_i2c_write_block(addr, (char *)p_data, len, 0, 0x00)) ? VHAL_OK : VHAL_FAIL;
}

int32_t vhal_i2c_master_write_stop_condition(uint8_t i2c_num)
{
    //TODO:
    UNUSED(i2c_num);
    return 0;
}
