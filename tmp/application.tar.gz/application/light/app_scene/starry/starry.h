/**
* Copyright © Vesync Technologies Co.Ltd. 2022. All rights reserved
* @file         starry.h
* @brief        星夜场景
* @author       Joshua
* @date         2022-1-12
*/

#include <stdint.h>
#include "vesync_common.h"
#include "scene.h"

#ifndef __STARRY_H__
#define __STARRY_H__

#ifdef __cplusplus
extern "C" {
#endif


/**
 * @brief  星夜场景灯效实现初始化
 * @return int              [成功：APP_OK， 失败：APP_FAIL]
 */
int starry_light_scene_impl_init(void);

/**
 * @brief  注册星夜场景灯效
 * @return  int             [成功：APP_OK，失败：APP_FAIL]
 */
int starry_light_scene_reg(light_scene_t *light_scene);

/**
 * @brief  注销星夜场景灯效
 * @return  int             [成功：APP_OK，失败：APP_FAIL]
 */
int starry_light_scene_unreg(void);

#ifdef __cplusplus
}
#endif

#endif




