/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        switch.c
 * @brief       switch入口
 * @author      Charles.Mei
 * @date        2021-07-29
 */


#include "vesync_common.h"
#include "vesync_init.h"
#include "vesync_log.h"
#include "vesync_uart.h"

#include "switch.h"
#include "switch_app.h"
#include "switch_device.h"
#include "switch_production.h"
#include "switch_wifi_led.h"
#include "switch_bypass.h"
#include "switch_timing.h"
#include "switch_schedule.h"


static void switch_pre_cb(void)
{
    APP_LOG(LOG_DEBUG, "switch pre init callback\n");
    switch_wifi_led_init();
}

static void switch_app_run(void)
{

    APP_LOG(LOG_INFO, "Vesync APP Switch start\n");

    vesync_uart_init();
    APP_LOG(LOG_DEBUG, "switch uart init done\n");

    switch_app_init();
    switch_schedule_init();
    switch_timing_init();
    switch_device_init();
    switch_production_init();
    switch_bypass_reg_cb();
}


void app_main(void)
{
    vesync_sdk_reg_pre_run_cb(switch_pre_cb);
    vesync_sdk_reg_post_run_cb(switch_app_run);

    vesync_sdk_run();
}


