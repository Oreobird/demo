/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_task.h
 * @brief       task抽象层，封装任务相关接口
 * @date        2021-04-20
 */

#ifndef __VESYNC_TASK_H__
#define __VESYNC_TASK_H__

#include "vesync_os.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef enum
{
    TASK_PRIORITY_IDLE = 0,                                 /* lowest, special for idle task */
    /* User task priority begin, please define your task priority at this interval */
    TASK_PRIORITY_LOW,                                      /* low */
    TASK_PRIORITY_BELOW_NORMAL,                             /* below normal */
    TASK_PRIORITY_NORMAL,                                   /* normal */
    TASK_PRIORITY_ABOVE_NORMAL,                             /* above normal */
    TASK_PRIORITY_HIGH,                                     /* high */
    TASK_PRIORITY_SOFT_REALTIME,                            /* soft real time */
    TASK_PRIORITY_HARD_REALTIME,                            /* hard real time */
    /* User task priority end */
} TASK_PRIORITY_TYPE_E;


typedef vesync_handle_t vesync_task_t;

/*
 * @brief  创建任务
 * @param[in]  name                    [任务名称]
 * @param[in]  fn                      [任务执行函数]
 * @param[in]  arg                     [参数]
 * @param[in]  stack_size              [栈大小]
 * @param[in]  prio                    [任务优先级]
 * @param[in]  task_handle             [创建的任务结构体指针]
 * @return int                         [成功：0；失败：-1]
 */
int vesync_task_new(const char *name,
                          void (*fn)(void *),
                          void *arg,
                          int stack_size,
                          int prio,
                          vesync_task_t *task);

/*
 * @brief  销毁任务
 * @param[in]  task                    [任务结构体指针]
 * @return void
 */
void vesync_task_free(vesync_task_t *task);

/*
 * @brief  获取当前任务名称
 * @return const char *                [返回当前任务名称]
 */
const char *vesync_task_name(void);

/*
 * @brief  运行任务调度
 * @return const char *                [返回当前任务名称]
 */
void vesync_task_start(vesync_task_t *task);

#ifdef __cplusplus
}
#endif
#endif /* __VESYNC_TASK_H__ */

