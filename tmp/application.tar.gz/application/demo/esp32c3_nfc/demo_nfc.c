/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
 * @file        demo_nfc.c
 * @brief       nfc vesync层测试代码
 * @date        2021-11-13
 */
#include "vesync_log.h"
#include "vesync_common.h"
#include "vesync_log_internal.h"
#include "vesync_cfg.h"
#include "stdio.h"
#include "string.h"
#include "vesync_memory.h"
#include "vesync_task.h"
#include "vhal_i2c.h"
#include "vhal_gpio.h"
#include "vesync_frame.h"
#include "vesync_nfc.h"
#include "vesync_nfc_card.h"
#include "vesync_net_service_internal.h"
#include "vhal_wifi.h"
#include "vesync_event_internal.h"
#include "vesync_netcfg_internal.h"

//配网信息记录
static net_info_t s_nfc_net_cfg_info;




/**
 * @brief  nfc 配网测试任务
 * @param[in]  args              [任务入参]
 * @note
 */
static void vesync_nfc_netcfg_test_task(void *args)
{
    static uint8_t i = 0;

    vesync_sleep(5000);

    vesync_nfc_start_netcfg();
    vesync_netcfg_restart();
    vesync_nfc_send_dev_info(0);  

    while (1)
    {
        APP_LOG(LOG_DEBUG, "i= %d \n", i);
        i++;

        vesync_sleep(1000);

        if (i == 300)
        {
            APP_LOG(LOG_DEBUG, "timeout stop nfc net cfg\n");
            vesync_nfc_stop_netcfg();
            vesync_netcfg_stop();
        }

    }
}

/**
 * @brief 数据接收返回应用层回调函数,将正确的数据帧通过此回调函数传给应用层
 * @param[in]  frame        [接收功能模块的结构体指针]
 */
void vesync_nfc_frame_recv_cb(tl_frame_recv_info_t *frame)
{
    char *ptr = NULL;
    char *ptrEnd = NULL;
    net_info_t *p_net_cfg;
    vesync_ev_t ev = {0};

    APP_LOG(LOG_DEBUG, "rcv frame p_payload = %s\n", frame->p_payload);
    
    APP_LOG(LOG_DEBUG, "start net connect\n");

    ptr =strstr((char*)frame->p_payload, "ssid:");
    if(ptr)
    {
        ptrEnd = strstr(ptr, " ");
        if(ptrEnd)
        {
            strncpy((char*)s_nfc_net_cfg_info.wifiSSID, ptr + strlen("ssid:"), ptrEnd - ptr - strlen("ssid:"));
        }
    }

    ptr = NULL;
    
    ptr =strstr((char*)frame->p_payload, "pwd:");
    if(ptr)
    {
        ptrEnd = strstr(ptr, " ");
        if(ptrEnd)
        {
            strncpy((char*)s_nfc_net_cfg_info.wifiPassword, ptr + strlen("pwd:"), ptrEnd - ptr - strlen("pwd:"));
        }
    }

    APP_LOG(LOG_DEBUG, "ssid =%s pwd =%s \r\n", s_nfc_net_cfg_info .wifiSSID, s_nfc_net_cfg_info.wifiPassword);


    p_net_cfg = vesync_net_mgmt_get_net_cfg();
    if(p_net_cfg)
    {
        strncpy((char*)p_net_cfg->wifiSSID, (char*)s_nfc_net_cfg_info.wifiSSID,sizeof(p_net_cfg->wifiSSID) - 1);
        strncpy((char*)p_net_cfg->wifiPassword, (char*)s_nfc_net_cfg_info.wifiPassword, sizeof(p_net_cfg->wifiPassword) - 1);
        p_net_cfg->auth_mode = VHAL_WIFI_AUTH_WPA2_PSK;

         //为了demo 测试，此处自己填入其他信息，configkey 用重连的时的"0",真实configkey 仅用一次，后续每次走重连流程，避免每次要新的configkey
        //strncpy((char*)p_net_cfg->configKey, "0MrtqGgnhRNgTTi1",sizeof(p_net_cfg->configKey) - 1);              
        strncpy((char*)p_net_cfg->configKey, "0",sizeof(p_net_cfg->configKey) - 1);
        strncpy((char*)p_net_cfg->serverDN, "test-vdmpmqtt.vesync.com",sizeof(p_net_cfg->serverDN) - 1);
        p_net_cfg->serverPort = 2883;
        strncpy((char*)p_net_cfg->account_id, "1165800",sizeof(p_net_cfg->account_id) - 1);

        //发出收到配网信息事件
        VESYNC_POPULATE_EV(ev, EVENT_NETCFG_RECEIVE_CONFIG, NETCFG_TASK_NAME, 0, NULL);
        vesync_event_publish(&ev);
    }

}

/**
 * @brief  nfc 配网成功回调处理
 */
void demo_nfc_net_cfg_ok_cb(void)
{
    APP_LOG(LOG_DEBUG, "NFC cfg ok stop net cfg\n");
    vesync_nfc_stop_netcfg();
    vesync_netcfg_stop();   
}



void demo_nfc_init()
{
    vesync_nfc_init();
    vesync_net_cfg_reg_success_cb(demo_nfc_net_cfg_ok_cb);
    
    if (VOS_OK != vesync_task_new("nfc task", NULL, vesync_nfc_netcfg_test_task, NULL, 4 * 1024, 3, NULL))
    {
        APP_LOG(LOG_ERROR, "Create NFC  task fail!\n");
    }

    memset(&s_nfc_net_cfg_info, 0, sizeof(s_nfc_net_cfg_info));
    vesync_nfc_reg_netcfg_recv_cb(vesync_nfc_frame_recv_cb);
}
