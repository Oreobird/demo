/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_pb2json_test.cpp
 * @brief       vesync pb2json测试用例
 * @author      Herve
 * @date        2021-11-12
 */

#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <gtest/gtest.h>

#include "cJSON.h"

#include "vesync_log_internal.h"
#include "vesync_json_internal.h"

#include "vesync_log.h"
#include "vesync_pb2json.h"
#include "vesync_memory.h"

#define TEST_PROTO3 0

#if TEST_PROTO3
#include "pb2json_fixtures/pb_test_proto3.pb-c.h"
#else
#include "pb2json_fixtures/proto2/pb_test_proto2.pb-c.h"
#endif

class vesync_pb2json_test : public testing::Test
{
protected:
    static void SetUpTestCase()
    {
        vesync_log_init();
    }

    static void TearDownTestCase()
    {
        vesync_log_deinit();
    }
};

#if TEST_PROTO3
TEST_F(vesync_pb2json_test, pb2json_test)
{
    char const *expected_json_out = "{"
                                    "\"name\":\"herve lin\","
                                    "\"id\":0,"
                                    "\"email\":\"herve.lin@test.com\","
                                    "\"phone\":["
                                    "{"
                                    "\"number\":\"111555666\","
                                    "\"type\":\"MOBILE\""
                                    "},"
                                    "{"
                                    "\"number\":\"999888\","
                                    "\"type\":\"HOME\""
                                    "}],"
                                    "\"mac_addr\":\"AAECAwQFBgcICQ==\","
                                    "\"address\":\"shenzhen\""
                                    "}";

    Foo__Person person = FOO__PERSON__INIT;

    person.name = (char *)"herve lin";
    person.id = 0;
    person.email = (char *)"herve.lin@test.com";
    uint8_t *bin = (uint8_t *)vesync_malloc(10);
    for (int i = 0; i < 10; i++)
    {
        bin[i] = i;
    }
    person.mac_addr.data = bin;
    person.mac_addr.len = 10;

    Foo__Person__PhoneNumber **person_phonenumber = (Foo__Person__PhoneNumber **)vesync_malloc(2 * sizeof(Foo__Person__PhoneNumber *));
    for (int i = 0; i < 2; i++)
    {
        person_phonenumber[i] = (Foo__Person__PhoneNumber *)vesync_malloc(sizeof(Foo__Person__PhoneNumber));
        foo__person__phone_number__init(person_phonenumber[i]);
    }
    person_phonenumber[0]->number = (char *)"111555666";
    person_phonenumber[0]->type = FOO__PERSON__PHONE_TYPE__MOBILE;
    person_phonenumber[1]->number = (char *)"999888";
    person_phonenumber[1]->type = FOO__PERSON__PHONE_TYPE__HOME;
    person.phone = person_phonenumber;
    person.n_phone = 2;
    person.address = (char *)"shenzhen";

#if 0
    size_t size = foo__person__get_packed_size(&person);
    uint8_t *buffer = (uint8_t *)vesync_malloc(size);
    size_t out = foo__person__pack(&person, buffer);
    LOG_RAW_HEX(LOG_INFO, "person serialized:", buffer, out);
    vesync_free(buffer);
#endif

    cJSON *json = NULL;
    int ret = vesync_pb2json(PROC_FLAG_NULL, &person.base, &json);
    EXPECT_EQ(ret, PROTOBUF2JSON_ERR_OK);

    vesync_json_print(json);

    char *json_out = cJSON_PrintUnformatted(json);
    EXPECT_STREQ(json_out, expected_json_out);
    vesync_free(json_out);

    vesync_free(bin);
    for (int i = 0; i < 2; i++)
    {
        vesync_free(person_phonenumber[i]);
    }
    vesync_free(person_phonenumber);
}

TEST_F(vesync_pb2json_test, pb2json_test_zero_item)
{
    Foo__Person person = FOO__PERSON__INIT;

    person.name = (char *)"herve lin";

    uint8_t *bin = (uint8_t *)vesync_malloc(10);
    for (int i = 0; i < 10; i++)
    {
        bin[i] = i;
    }
    person.mac_addr.data = bin;
    person.mac_addr.len = 10;

    Foo__Person__PhoneNumber **person_phonenumber = (Foo__Person__PhoneNumber **)vesync_malloc(2 * sizeof(Foo__Person__PhoneNumber *));
    for (int i = 0; i < 2; i++)
    {
        person_phonenumber[i] = (Foo__Person__PhoneNumber *)vesync_malloc(sizeof(Foo__Person__PhoneNumber));
        foo__person__phone_number__init(person_phonenumber[i]);
    }
    person_phonenumber[0]->number = (char *)"111555666";
    person_phonenumber[0]->type = FOO__PERSON__PHONE_TYPE__MOBILE;
    person_phonenumber[1]->number = (char *)"999888";
    person_phonenumber[1]->type = FOO__PERSON__PHONE_TYPE__HOME;
    person.phone = person_phonenumber;
    person.n_phone = 2;

    cJSON *json = NULL;
    int ret = vesync_pb2json(PROC_FLAG_NULL, &person.base, &json);
    EXPECT_EQ(ret, PROTOBUF2JSON_ERR_OK);

    vesync_json_print(json);

    vesync_free(bin);
    for (int i = 0; i < 2; i++)
    {
        vesync_free(person_phonenumber[i]);
    }
    vesync_free(person_phonenumber);
}

TEST_F(vesync_pb2json_test, json2pb_test)
{
    char const *target_json_out = "{"
                                  "\"name\":\"herve lin\","
                                  "\"id\":52,"
                                  "\"email\":\"herve.lin@test.com\","
                                  "\"mac_addr\":\"AAECAwQFBgcICQ==\","
                                  "\"phone\":["
                                  "{"
                                  "\"number\":\"111555666\","
                                  "\"type\":\"MOBILE\""
                                  "},"
                                  "{"
                                  "\"number\":\"999888\","
                                  "\"type\":\"HOME\""
                                  "}],"
                                  "\"address\":\"shenzhen\""
                                  "}";

    cJSON *json = cJSON_Parse(target_json_out);

    Foo__Person *person = NULL;
    int ret = vesync_json2pb(PROC_FLAG_NULL, json, &foo__person__descriptor, (ProtobufCMessage **)&person);
    EXPECT_EQ(ret, PROTOBUF2JSON_ERR_OK);

    SDK_LOG(LOG_DEBUG,
            "\n"
            "name: %s\n"
            "id: %d\n"
            "email: %s\n"
            "address: %s\n"
            "i has %d phones\n"
            "phone.number.1: %s\n"
            "phone.type.1: %d\n"
            "phone.number.2: %s\n"
            "phone.type.2: %d\n",
            person->name,
            person->id,
            person->email,
            person->address,
            person->n_phone,
            person->phone[0]->number,
            person->phone[0]->type,
            person->phone[1]->number,
            person->phone[1]->type);

    LOG_RAW_HEX(LOG_INFO, "mac_addr:", person->mac_addr.data, person->mac_addr.len);

    EXPECT_STREQ("herve lin", person->name);
    EXPECT_EQ(52, person->id);
    EXPECT_STREQ("herve.lin@test.com", person->email);
    EXPECT_STREQ("shenzhen", person->address);
    EXPECT_EQ(2, person->n_phone);

    foo__person__free_unpacked(person, NULL);
}

TEST_F(vesync_pb2json_test, process_flag_test)
{
    char const *expected_json_out = "{"
                                    "\"numberic_bool\":true,"
                                    "\"numberic_enum\":\"numberic_enum_3\""
                                    "}";

    Foo__NumbericBoolAndEnum bool_and_enum = FOO__NUMBERIC_BOOL_AND_ENUM__INIT;

    bool_and_enum.numberic_bool = 1;
    bool_and_enum.numberic_enum = FOO__NUMBERIC_BOOL_AND_ENUM__NUMBERIC_ENUM__numberic_enum_3;

    char *json_out = NULL;
    int ret;

    cJSON *json = NULL;
    ret = vesync_pb2json(PROC_FLAG_NULL, &bool_and_enum.base, &json);
    EXPECT_EQ(ret, PROTOBUF2JSON_ERR_OK);

    vesync_json_print(json);

    json_out = cJSON_PrintUnformatted(json);
    EXPECT_STREQ(json_out, expected_json_out);
    vesync_free(json_out);

    char const *expected_json_out_1 = "{"
                                      "\"numberic_bool\":1,"
                                      "\"numberic_enum\":\"numberic_enum_3\""
                                      "}";

    cJSON *json_1 = NULL;
    ret = vesync_pb2json(PROC_FLAG_NUMBERIC_BOOL, &bool_and_enum.base, &json_1);
    EXPECT_EQ(ret, PROTOBUF2JSON_ERR_OK);

    vesync_json_print(json_1);

    json_out = cJSON_PrintUnformatted(json_1);
    EXPECT_STREQ(json_out, expected_json_out_1);
    vesync_free(json_out);

    char const *expected_json_out_2 = "{"
                                      "\"numberic_bool\":1,"
                                      "\"numberic_enum\":2"
                                      "}";

    cJSON *json_2 = NULL;
    ret = vesync_pb2json(PROC_FLAG_NUMBERIC_BOOL | PROC_FLAG_NUMBERIC_ENUM, &bool_and_enum.base, &json_2);
    EXPECT_EQ(ret, PROTOBUF2JSON_ERR_OK);

    vesync_json_print(json_2);

    json_out = cJSON_PrintUnformatted(json_2);
    EXPECT_STREQ(json_out, expected_json_out_2);
    vesync_free(json_out);

    ////////////////////////////////////////////////////

    Foo__NumbericBoolAndEnum *reverse_bool_and_enum = NULL;
    ret = vesync_json2pb(PROC_FLAG_NULL, json, &foo__numberic_bool_and_enum__descriptor, (ProtobufCMessage **)&reverse_bool_and_enum);
    EXPECT_EQ(ret, PROTOBUF2JSON_ERR_OK);

    EXPECT_EQ(1, reverse_bool_and_enum->numberic_bool);
    EXPECT_EQ(FOO__NUMBERIC_BOOL_AND_ENUM__NUMBERIC_ENUM__numberic_enum_3, reverse_bool_and_enum->numberic_enum);

    Foo__NumbericBoolAndEnum *reverse_bool_and_enum_1 = NULL;
    ret = vesync_json2pb(PROC_FLAG_NUMBERIC_BOOL, json_1, &foo__numberic_bool_and_enum__descriptor, (ProtobufCMessage **)&reverse_bool_and_enum_1);
    EXPECT_EQ(ret, PROTOBUF2JSON_ERR_OK);

    EXPECT_EQ(1, reverse_bool_and_enum_1->numberic_bool);
    EXPECT_EQ(FOO__NUMBERIC_BOOL_AND_ENUM__NUMBERIC_ENUM__numberic_enum_3, reverse_bool_and_enum_1->numberic_enum);

    Foo__NumbericBoolAndEnum *reverse_bool_and_enum_2 = NULL;
    ret = vesync_json2pb(PROC_FLAG_NUMBERIC_BOOL | PROC_FLAG_NUMBERIC_ENUM, json_2, &foo__numberic_bool_and_enum__descriptor, (ProtobufCMessage **)&reverse_bool_and_enum_2);
    EXPECT_EQ(ret, PROTOBUF2JSON_ERR_OK);

    EXPECT_EQ(1, reverse_bool_and_enum_2->numberic_bool);
    EXPECT_EQ(FOO__NUMBERIC_BOOL_AND_ENUM__NUMBERIC_ENUM__numberic_enum_3, reverse_bool_and_enum_2->numberic_enum);

    cJSON_Delete(json);
    cJSON_Delete(json_1);
    cJSON_Delete(json_2);
}
#else
TEST_F(vesync_pb2json_test, pb2json_test_zero_item)
{
    Foo__Person person = FOO__PERSON__INIT;

    person.name = (char *)"herve lin";

    uint8_t *bin = (uint8_t *)vesync_malloc(10);
    for (int i = 0; i < 10; i++)
    {
        bin[i] = i;
    }
    person.mac_addr.data = bin;
    person.mac_addr.len = 10;

    Foo__Person__PhoneNumber **person_phonenumber = (Foo__Person__PhoneNumber **)vesync_malloc(2 * sizeof(Foo__Person__PhoneNumber *));
    for (int i = 0; i < 2; i++)
    {
        person_phonenumber[i] = (Foo__Person__PhoneNumber *)vesync_malloc(sizeof(Foo__Person__PhoneNumber));
        foo__person__phone_number__init(person_phonenumber[i]);
    }
    person_phonenumber[0]->number = (char *)"111555666";
    person_phonenumber[0]->type = FOO__PERSON__PHONE_TYPE__MOBILE;
    person_phonenumber[1]->number = (char *)"999888";
    person_phonenumber[1]->type = FOO__PERSON__PHONE_TYPE__HOME;
    person.phone = person_phonenumber;
    person.n_phone = 2;

    cJSON *json = NULL;
    int ret = vesync_pb2json(PROC_FLAG_NULL, &person.base, &json);
    EXPECT_EQ(ret, PROTOBUF2JSON_ERR_OK);

    vesync_json_print(json);

    vesync_free(bin);
    for (int i = 0; i < 2; i++)
    {
        vesync_free(person_phonenumber[i]);
    }
    vesync_free(person_phonenumber);

    cJSON_Delete(json);
}

TEST_F(vesync_pb2json_test, json2pb_test_zero_item)
{
    int ret;
    char const *target_json_out = "{"
                                  "\"name\":\"herve lin\","
                                  "\"id\":52,"
                                  "\"email\":\"herve.lin@test.com\","
                                  "\"mac_addr\":\"AAECAwQFBgcICQ==\","
                                  "\"phone\":["
                                  "{"
                                  "\"number\":\"111555666\","
                                  "\"type\":\"MOBILE\""
                                  "},"
                                  "{"
                                  "\"number\":\"999888\","
                                  "\"type\":\"HOME\""
                                  "}],"
                                  "\"address\":\"shenzhen\","
                                  "\"id_1\":30"
                                  "}";

    cJSON *json = cJSON_Parse(target_json_out);

    Foo__Person *person = NULL;
    ret = vesync_json2pb(PROC_FLAG_NULL, json, &foo__person__descriptor, (ProtobufCMessage **)&person);
    EXPECT_EQ(ret, PROTOBUF2JSON_ERR_OK);

    SDK_LOG(LOG_DEBUG,
            "\n"
            "name: %s\n"
            "id: %d\n"
            "has_id: %d \n"
            "id_1: %d\n"
            "has_id_1: %d \n"
            "id_2: %d\n"
            "has_id_2: %d \n"
            "id_3: %d\n"
            "has_id_3: %d \n"
            "id_4: %d\n"
            "has_id_4: %d \n",
            person->name,
            person->id,
            person->has_id,
            person->id_1,
            person->has_id_1,
            person->id_2,
            person->has_id_2,
            person->id_2,
            person->has_id_2,
            person->id_3,
            person->has_id_3);

    cJSON *json_2 = NULL;
    ret = vesync_pb2json(PROC_FLAG_NULL, &person->base, &json_2);
    EXPECT_EQ(ret, PROTOBUF2JSON_ERR_OK);

    vesync_json_print(json_2);

    foo__person__free_unpacked(person, NULL);

    cJSON_Delete(json);
    cJSON_Delete(json_2);
}
#endif