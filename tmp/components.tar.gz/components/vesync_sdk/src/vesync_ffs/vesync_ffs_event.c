/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file     vesync_ffs_event.c
* @brief    vesync ffs事件处理接口
* @author   Joshua
* @date     2021-06-10
*/

#include "vesync_common.h"
#include "vesync_log_internal.h"
#include "vesync_sem.h"
#include "vesync_wifi_led.h"
#include "vesync_ffs_internal.h"
#include "vesync_net_service_internal.h"
#include "vesync_ffs_event.h"
#include "vhal_wifi.h"

static vesync_sem_t *s_wifi_scan_done_sem = NULL;         // WiFi 列表扫描完毕信号量
static bool s_mqtt_connected_success = false;
static int s_mqtt_reconnect_cnt = 0;


/**
 * @brief 配网超时或结束时停止wifi和mqtt连接
 */
static void vesync_ffs_stop_wifi(void)
{
#if CONFIG_VESYNC_SDK_NET_SERVICE_ENABLE
    vesync_net_client_disconnect_server();
#endif

    vhal_wifi_stop();
}

static int ffs_netcfg_force_exit_cb(void *data)
{
    SDK_LOG(LOG_DEBUG, "ffs netcfg force exit\n");
    vesync_wifi_led_set_behavior(WIFI_LED_CONFIG_TIMEOUT); // 配网失败，退出配网，灯灭
    vesync_ffs_stop_wifi();
    vesync_ffs_set_state(VESYNC_FFS_FAIL);
    vesync_ffs_exit();
    return SDK_OK;
}

static int ffs_netcfg_timeout_cb(void *data)
{
    SDK_LOG(LOG_DEBUG, "config network timeout.\n");

    vesync_wifi_led_set_behavior(WIFI_LED_CONFIG_TIMEOUT); // 配网失败，退出配网，灯灭
    vesync_ffs_stop_wifi();
    vesync_ffs_set_state(VESYNC_FFS_FAIL);
    vesync_ffs_exit();

    return SDK_OK;
}

static int ffs_wifi_connected_cb(void *data)
{
    SDK_LOG(LOG_DEBUG, "connected wifi.\n");

    //vesync_netcfg_set_status(NETCFG_STATUS_CONNECTED_WIFI);

    return SDK_OK;
}

static int ffs_router_got_ip_cb(void *data)
{
    SDK_LOG(LOG_DEBUG, "get ip, start mqtt connect.\n");
    //vesync_netcfg_set_status(NETCFG_STATUS_GOT_IP);

    return SDK_OK;
}

static int ffs_netcfg_recv_cfg_cb(void *data)
{
#if CONFIG_VESYNC_SDK_MQTT_ENABLE
    //if (vesync_net_client_get_status() == NETWORK_UNINIT)
    {
        char mqtt_pwd[300] = {0};
        FfsResultString_t ffs_result = vesync_ffs_get_result_string();
        snprintf(mqtt_pwd, sizeof(mqtt_pwd), VESYNC_FFS_PWD,
                 ffs_result.sessionToken, ffs_result.signature, ffs_result.alexaEvtGwEp);

        net_info_t net_cfg;
        memset(&net_cfg, 0, sizeof(net_info_t));
        snprintf(net_cfg.serverDN, sizeof(net_cfg.serverDN), VESYNC_FFS_SERV_NAME);
        snprintf(net_cfg.configKey, sizeof(net_cfg.configKey), mqtt_pwd)
        vesync_net_client_connect((char *)VESYNC_FFS_SERV_NAME, "", mqtt_pwd, NULL, TLS_CA_SERVER); // pwd需要用token填充
        vesync_ffs_event_notify(EVENT_NWK_RESET);
    }
#endif
    return SDK_OK;
}

static int ffs_dns_resolved_cb(void *data)
{
    SDK_LOG(LOG_DEBUG, "dns resolved.\n");
    //vesync_netcfg_set_status(NETCFG_STATUS_DNS_RESOLVED);

    return SDK_OK;
}

static int ffs_cloud_connected_cb(void *data)
{
    int subscribe_msgid = -1;
    SDK_LOG(LOG_DEBUG, "mqtt connected...\n");

    //vesync_netcfg_set_status(NETCFG_STATUS_CONNECTED_SERVER);

    s_mqtt_connected_success = true;

    // if(SDK_OK == vesync_flash_write_net_info(p_ffs_cfg))     // 云端绑定成功后，通知设备才认为是配网成功
    // {
    //     vesync_wifi_single_led_set_behavior(WIFI_LED_LOGIN_SUCCESS);
    //     //vesync_netcfg_set_status(NETCFG_STATUS_SAVE_CFG_SUCCESS);
    //     netcfg_success = true;
    //     break;
    // }
    // else
    // {
    //     SDK_LOG(LOG_ERROR, "write network config to flash error!\r\n");
    // }

    return SDK_OK;
}


static int ffs_cloud_rsp_cb(void *data)
{
    int ret = SDK_FAIL;

    vesync_ev_t *event = (vesync_ev_t *)data;
    if (event && event->len > 0 && event->buf)
    {
        SDK_LOG(LOG_DEBUG, "event len=%d, event buf=%s\n", event->len, event->buf);
        net_info_t *p_ffs_cfg = vesync_ffs_get_cfg();
        snprintf((char *)p_ffs_cfg->account_id, event->len, "%s", (char *)event->buf);

        ret = vesync_net_flash_write_net_info(p_ffs_cfg);
        if (ret != SDK_OK)
        {
            SDK_LOG(LOG_ERROR, "write network config to flash error!\r\n");
            return SDK_FAIL;
        }

        vesync_wifi_led_set_behavior(WIFI_LED_LOGIN_SUCCESS);

        vesync_ffs_exit();

        // 配网成功，通知平台层
        vesync_ffs_event_notify(EVENT_NETCFG_SUCCEED);
        vesync_ffs_set_state(VESYNC_FFS_SUCC);
        ret = SDK_OK;
    }

    return ret;
}

static int ffs_mqtt_disconnected_cb(void *data)
{
    // only calcuate the reconnect count after a successful connect.
    if (true == s_mqtt_connected_success)
    {
        s_mqtt_reconnect_cnt++;
    }

    // reset password after a successful connect.
    if (1 == s_mqtt_reconnect_cnt)
    {
        char *p_server_domain = (char *)vesync_ffs_get_server_domain();
        char *p_server_ip = (char *)vesync_ffs_get_server_ip();
        uint32_t *p_server_port = vesync_ffs_get_server_port();
        if (NULL != p_server_domain)
        {
#if CONFIG_VESYNC_SDK_NET_SERVICE_ENABLE
            vesync_net_client_connect(p_server_domain, p_server_ip, "0", p_server_port, TLS_CA_SERVER);
#endif
        }
    }

    return SDK_OK;
}

static int ffs_wifi_scan_done_cb(void *data)
{
    SDK_LOG(LOG_DEBUG, "wifi scan done, total %d APs.\n", vesync_ffs_aplist_get_apcount());
    if (s_wifi_scan_done_sem)
    {
        vesync_sem_signal(s_wifi_scan_done_sem);
    }

    return SDK_OK;
}

static event_cb_tbl_t s_ev_cb_tbl[] = {
    {EVENT_NETCFG_FORCE_EXIT,       ffs_netcfg_force_exit_cb},
    {EVENT_NETCFG_TIMEOUT,          ffs_netcfg_timeout_cb   },
    {EVENT_WIFI_CONNECTED,          ffs_wifi_connected_cb   },
    {EVENT_ROUTER_GOT_IP,           ffs_router_got_ip_cb    },
    {EVENT_NETCFG_RECEIVE_CONFIG,   ffs_netcfg_recv_cfg_cb  },
    {EVENT_DNS_RESOLVED,            ffs_dns_resolved_cb     },
    {EVENT_NWK_CONNECTED,           ffs_cloud_connected_cb  },
    {EVENT_FFS_CLOUD_RSP,           ffs_cloud_rsp_cb        },
    {EVENT_NWK_DISCONNECTED,        ffs_mqtt_disconnected_cb},
    {EVENT_WIFI_SCANDONE,           ffs_wifi_scan_done_cb   },
};


/**
 * @brief  ffs订阅事件
 * @param[in]  event_id      [事件ID]
 * @return     void          [无]
 */
static int vesync_ffs_subscribe_events(void)
{
    int idx = 0, ret = SDK_OK;
    bool subscribe_fail = false;

    for (idx = 0; idx < SIZEOF_ARRAY(s_ev_cb_tbl); idx++)
    {
        if (s_ev_cb_tbl[idx].cb != NULL)
        {
            ret = vesync_event_subscribe(s_ev_cb_tbl[idx].event_id, SUB_ID_FFS, s_ev_cb_tbl[idx].cb);
            if (ret != SDK_OK)
            {
                subscribe_fail = true;
                break;
            }
        }
    }

    if (subscribe_fail)
    {
        for (int i = 0; i < idx; i++)
        {
            vesync_event_unsubscribe(s_ev_cb_tbl[i].event_id, SUB_ID_FFS);
        }
    }

    return ret;
}

/**
 * @brief  ffs取消订阅
 * @param[in]  event_id      [事件ID]
 * @return     void          [无]
 */
static void vesync_ffs_unsubscribe_events(void)
{
    for (int i = 0; i < SIZEOF_ARRAY(s_ev_cb_tbl); i++)
    {
        vesync_event_unsubscribe(s_ev_cb_tbl[i].event_id, SUB_ID_FFS);
    }
}


/**
 * @brief  ffs发送事件通知
 * @param[in]  event_id      [事件ID]
 * @return     void          [无]
 */
int vesync_ffs_event_notify(EVENT_ID_E event_id)
{
    vesync_ev_t event;
    VESYNC_POPULATE_EV(event, event_id, FFS_EVENT_PUBLISH_STR, 0, NULL);
    return vesync_event_publish(&event);
}

/**
 * @brief  ffs事件处理资源初始化
 * @param[in]  event_id      [事件ID]
 * @return     void          [无]
 */
int vesync_ffs_event_init(void)
{
    s_wifi_scan_done_sem = vesync_sem_binary_new();
    if (NULL == s_wifi_scan_done_sem)
    {
        SDK_LOG(LOG_ERROR, "wifi scan sem create fail!\n");
        return SDK_FAIL;
    }

    int ret = vesync_ffs_subscribe_events();
    if (ret != SDK_OK)
    {
        SDK_LOG(LOG_ERROR, "ffs subscribe events failed!\n");
        vesync_sem_free(s_wifi_scan_done_sem);
        return SDK_FAIL;
    }

    return SDK_OK;
}

/**
 * @brief  ffs等待wifi扫描
 * @param[in]  event_id      [事件ID]
 * @return     void          [无]
 */
void vesync_ffs_event_wait_for_wifi_scan(void)
{
    int ret = vesync_sem_wait(s_wifi_scan_done_sem, 8000);
    if (ret == VOS_OK) //等待wifi列表扫描同步信号量
    {
        SDK_LOG(LOG_INFO, "FFS WiFi list scan done!!!\n");
    }

    if (s_wifi_scan_done_sem)
    {
        vesync_sem_free(s_wifi_scan_done_sem);
        s_wifi_scan_done_sem = NULL;
    }
}


/**
 * @brief  ffs事件资源销毁
 * @param[in]  event_id      [事件ID]
 * @return     void          [无]
 */
void vesync_ffs_event_deinit(void)
{
    vesync_ffs_unsubscribe_events();

    if (s_wifi_scan_done_sem)
    {
        vesync_sem_free(s_wifi_scan_done_sem);
        s_wifi_scan_done_sem = NULL;
    }
}

