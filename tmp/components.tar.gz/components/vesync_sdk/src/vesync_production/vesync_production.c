/**
 * Copyright © Vesync Technologies Co.Ltd. 2019-2021. All rights reserved.
 * @file    vesync_production.c
 * @brief   产测模块
 * @author  CharlesMei
 * @date    2021-05-25
 */


#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include "cJSON.h"

#include "vesync_timer.h"
#include "vesync_memory.h"
#include "vesync_sem.h"
#include "vesync_utils.h"

#include "vhal_wifi.h"
#include "vhal_utils.h"

#include "vesync_flash.h"
#include "vesync_device_internal.h"
#include "vesync_event_internal.h"
#include "vesync_report_internal.h"
#include "vesync_production_private.h"
#include "vesync_klv.h"
#include "vesync_cfg_internal.h"

#if CONFIG_VESYNC_SDK_OTA_ENABLE
#include "vesync_ota_internal.h"
#endif /* CONFIG_VESYNC_SDK_OTA_ENABLE */

#if CONFIG_VESYNC_HAL_BLE_ENABLE
#include "vhal_ble.h"
#endif /* CONFIG_VESYNC_HAL_BLE_ENABLE */

#if CONFIG_VESYNC_SDK_BLE_SERVICE_ENABLE
#include "vesync_ble_internal.h"
#include "vesync_tl_payload_parse.h"
#endif /* CONFIG_VESYNC_SDK_BLE_SERVICE_ENABLE */

#include "string.h"
#include "vesync_mutex.h"

// 四个回调函数，通知应用层处理相应业务
static production_status_cb_t s_production_status_cb = NULL;
static production_result_cb_t s_production_result_cb = NULL;
static production_para_cb_t   s_production_extend_data_cb = NULL;
static production_wifi_cb_t s_production_wifi_cb  = NULL;
static production_pre_test_cb_t s_production_pre_test_cb  = NULL;


// 上报准备标志位，每bit对应一个准备标志，详见宏——产测上报已准备标志(e.g. REPORT_MCU_READY_FLAG)
static uint8_t s_report_ready_flag = 0x00;

// 上报准备标志信号量
static vesync_sem_t *s_report_ready_semp = NULL;

// Wi-Fi test，Wi-Fi连接成功标志信号量
static vesync_sem_t *s_wifi_connected_semp = NULL;

//产测错误码
static PRODUCTION_ERROR_E s_production_error_code = PRD_NO_ERR;
// 产测状态
static PRODUCTION_STATUS_E s_production_status = PRODUCTION_EXIT;

#if CONFIG_VESYNC_SDK_BLE_SERVICE_ENABLE
//产测ble rssi
static int8_t production_ble_rssi = -80;
#endif /* CONFIG_VESYNC_HAL_BLE_ENABLE */

//产测配置数据
static production_cfg_data_info_t  production_cfg_data;


//产测配置数据保护数据互斥锁
static vesync_mutex_t  production_mutex = NULL;

//产测数据操作缓存大小
#define PRODUCTION_DATA_BUF_LEN     200


#if CONFIG_VESYNC_SDK_BLE_SERVICE_ENABLE
/**
 * @brief  蓝牙产测数据接收回调函数
 * @param[in]   p_data          [Vesync Frame中的透传数据]
 * @param[in]   len             [透传数据长度]
 * @param[in]   need_ack        [是否需要应答]
 * @return      bool            [消息是否被接收者消费]
 */
static bool vesync_production_ble_data_recv_cb(uint8_t *p_data, uint16_t len, bool need_ack);
#endif /* CONFIG_VESYNC_HAL_BLE_ENABLE */



/**
 * @brief       设置某项数据的默认值，若增加了数据项此函数要增加代码
 * @return     uint32_t         [VERR_OK成功，VERR_FAIL失败]
 */
static int production_set_deault_data_by_key(uint8_t   key)
{

    switch(key)
    {
        case PRODUCTION_KEY_ID_CFG_VERSION:           //产测数据版本，uint8_t
            production_cfg_data.config_version = PR_PRODUCTION_CFG_VERSION;
            break;

        case  PRODUCTION_KEY_ID_CID:                      //产测CID，string型，32byte
            //strncpy((char *)production_cfg_data.cid,PRODUCTION_CID_DEFAULT,strlen(PRODUCTION_CID_DEFAULT));
            memset(production_cfg_data.cid,0,sizeof(production_cfg_data.cid));
            strcpy((char *)production_cfg_data.cid,PRODUCTION_CID_DEFAULT);
            break;

        case PRODUCTION_KEY_ID_TEST_FAIL_FLAG:          //产测失败标志，bool型，默认true
            production_cfg_data.test_fail_flag = true;
            break;

        case PRODUCTION_KEY_ID_ERROR_CODE:               //产测错误码，uint8_t
            production_cfg_data.err_code = PRD_NO_ERR;
            break;

        default:
            return VERR_FAIL;
            break;

    }

    return VERR_OK;

}


/**
 * @brief       将产测数据按klv格式写入flash中
 * @return     uint32_t         [VERR_OK成功，VERR_FAIL失败]
 */
static int production_set_data_to_flash(void)
{
    int ret =SDK_OK;
    char *production_buf =NULL;
    uint32_t magic_code= 0;
    uint32_t  offset = 0;

    if(NULL == (production_buf = vesync_malloc(PRODUCTION_DATA_BUF_LEN)))
    {
        PRODUCTION_LOG(LOG_ERROR,"malloc error\n");
        return VERR_FAIL;
    }

    memset(production_buf,0,PRODUCTION_DATA_BUF_LEN);


    offset += vesync_klv_set((uint8_t *)production_buf + offset, PRODUCTION_DATA_BUF_LEN - offset, PRODUCTION_KEY_ID_CFG_VERSION, sizeof(production_cfg_data.config_version),&production_cfg_data.config_version);


    if(strlen((char *)production_cfg_data.cid) >0)
    {
       offset += vesync_klv_set((uint8_t *)production_buf + offset,PRODUCTION_DATA_BUF_LEN - offset, PRODUCTION_KEY_ID_CID, strlen((char *)production_cfg_data.cid),production_cfg_data.cid);
    }


    if(production_cfg_data.test_fail_flag == false)
    {
        magic_code = PRODUCTION_MAGIC_CODE;
    }
    else
    {
        magic_code =  PRODUCTION_DEFAULT_MAGIC_CODE;
    }

    offset += vesync_klv_set((uint8_t *)production_buf + offset, PRODUCTION_DATA_BUF_LEN - offset,
        PRODUCTION_KEY_ID_TEST_FAIL_FLAG, sizeof(magic_code), (uint8_t *)&magic_code);

    offset += vesync_klv_set((uint8_t *)production_buf + offset,PRODUCTION_DATA_BUF_LEN - offset,
        PRODUCTION_KEY_ID_ERROR_CODE, sizeof(production_cfg_data.err_code), (uint8_t *)&production_cfg_data.err_code);

    ret |= vesync_flash_aes_crypto_write(PARTITION_CFG, USER_CFG_KEY_PRD_CFG_DATA, (uint8_t *)production_buf, offset);
    ret |= vesync_flash_aes_crypto_write(PARTITION_FAC, USER_CFG_KEY_PRD_CFG_DATA, (uint8_t *)production_buf, offset);

    vesync_free(production_buf);

    if(ret == SDK_OK)
    {
        return VERR_OK;
    }
    else
    {
        PRODUCTION_LOG(LOG_ERROR,"write fail\r\n",ret);
        return VERR_FAIL;
    }
}




/**
 * @brief       产测数据初始化
 * @return     uint32_t         [VERR_OK成功，VERR_FAIL失败]
 */
int vesync_production_cfg_init(void)
{
    char *production_buf =NULL;
    int ret = VERR_OK;
    uint32_t buf_len = 0;
    uint32_t magic_code= 0;
    uint8_t  need_update_flag = 0;
    uint32_t i =0;

    if(NULL == (production_buf = vesync_malloc(PRODUCTION_DATA_BUF_LEN)))
    {
        PRODUCTION_LOG(LOG_ERROR,"malloc error\n");
        return VERR_FAIL;
    }

    memset(production_buf,0,PRODUCTION_DATA_BUF_LEN);
    memset(&production_cfg_data,0,sizeof(production_cfg_data));
    buf_len = PRODUCTION_DATA_BUF_LEN;

    if(NULL == (production_mutex = vesync_mutex_new()))
    {
        PRODUCTION_LOG(LOG_ERROR,"mutex error\n");
        vesync_free(production_buf);
        return VERR_FAIL;
    }


    // 读cfg区产测数据
    if(SDK_FAIL == vesync_flash_aes_crypto_read(PARTITION_CFG, USER_CFG_KEY_PRD_CFG_DATA, (uint8_t *)production_buf, &buf_len))
    {
        PRODUCTION_LOG(LOG_ERROR,"read main flash err\n");
        if(SDK_FAIL == vesync_flash_aes_crypto_read(PARTITION_FAC, USER_CFG_KEY_PRD_CFG_DATA, (uint8_t *)production_buf, &buf_len))
        {
            PRODUCTION_LOG(LOG_ERROR,"read backup flash error\n");   // 主区备份区均读取失败则设置默认值到flash
            for(i=0;i<PRODUCTION_KEY_ID_MAX;i++)
            {
                production_set_deault_data_by_key(i);
            }
            production_set_data_to_flash();

            vesync_free(production_buf);
            return VERR_OK;
        }
        else    // 若备份区有，主区没有，需要把数据copy到主区去
        {
            need_update_flag = 1;
        }
    }

    // 获取每一项数据，若获取失败则写入此项数据默认数据进去
    if(SDK_FAIL == vesync_klv_get((uint8_t *)production_buf, PRODUCTION_DATA_BUF_LEN, PRODUCTION_KEY_ID_CFG_VERSION,
        sizeof(production_cfg_data.config_version), &production_cfg_data.config_version))
    {
        need_update_flag = 1;
        production_set_deault_data_by_key(PRODUCTION_KEY_ID_CFG_VERSION);
    }
    else if(production_cfg_data.config_version != PR_PRODUCTION_CFG_VERSION)   //跟配置版本不一致则修改版本
    {
        need_update_flag = 1;
        production_set_deault_data_by_key(PRODUCTION_KEY_ID_CFG_VERSION);
    }


    if(SDK_FAIL == vesync_klv_get((uint8_t *)production_buf, PRODUCTION_DATA_BUF_LEN, PRODUCTION_KEY_ID_CID,
        sizeof(production_cfg_data.cid),production_cfg_data.cid))
    {
        need_update_flag = 1;
        production_set_deault_data_by_key(PRODUCTION_KEY_ID_CID);
    }

    if(SDK_FAIL == vesync_klv_get((uint8_t *)production_buf, PRODUCTION_DATA_BUF_LEN, PRODUCTION_KEY_ID_ERROR_CODE,
    sizeof(production_cfg_data.err_code),(uint8_t *)&production_cfg_data.err_code))
    {
        need_update_flag = 1;
        production_set_deault_data_by_key(PRODUCTION_KEY_ID_ERROR_CODE);
    }

    if(SDK_FAIL == vesync_klv_get((uint8_t *)production_buf, PRODUCTION_DATA_BUF_LEN, PRODUCTION_KEY_ID_TEST_FAIL_FLAG,
    sizeof(magic_code),(uint8_t *)&magic_code))
    {
        need_update_flag = 1;
        production_set_deault_data_by_key(PRODUCTION_KEY_ID_TEST_FAIL_FLAG);
    }

    if(magic_code != PRODUCTION_MAGIC_CODE)
    {
        production_cfg_data.test_fail_flag = true;
    }
    else
    {
        production_cfg_data.test_fail_flag = false;
    }

    if(need_update_flag == 1)   // 若有默认数据需要更新，写到Flash
    {
        ret = production_set_data_to_flash();
    }

    vesync_free(production_buf);

    if(ret ==SDK_OK)
    {
        return VERR_OK;
    }
    else
    {
        return VERR_FAIL;
    }
}



/**
 * @brief           获取产测数据
 * @param[in]       key_id          [key id值]
 * @param[out]      value           [产测数据]
 * @param[in/out]   len             [in:value缓存长度，out：value有效长度]
 * @return          uint32_t        [SDK_OK成功，SDK_FAIL失败]
 */
int vesync_production_get_value_by_key(uint8_t key_id,uint8_t *value,uint16_t *len)
{
    int value_len =0;
    uint8_t *value_ptr = NULL;
    int ret = VERR_OK;

    PRODUCTION_UTIL_MEM_CHECK(value, return VERR_FAIL);
    vesync_mutex_lock(production_mutex);    // 互斥锁保护数据

    switch(key_id)
    {
        case PRODUCTION_KEY_ID_CFG_VERSION: // 产测数据版本，uint8_t
            value_ptr =  &production_cfg_data.config_version;
            value_len = sizeof(production_cfg_data.config_version);
            break;

        case  PRODUCTION_KEY_ID_CID:        // 产测CID，string型，32byte,若长度不对说明cid不对
            value_len = strlen((char *)production_cfg_data.cid);
            if(value_len != PRODUCTION_CID_LEN)
            {
                PRODUCTION_LOG(LOG_ERROR, "cid len error get fail\n");
                ret =  VERR_FAIL;
            }
            else
            {
                value_ptr = production_cfg_data.cid;
            }
            break;

        case PRODUCTION_KEY_ID_TEST_FAIL_FLAG:          // 当产测失败标志位false 以及cid是有效cid才认为产测成功
            if((production_cfg_data.test_fail_flag == false) &&(strlen((char*)production_cfg_data.cid) == PRODUCTION_CID_LEN)
                &&(strstr((char*)production_cfg_data.cid, PRODUCTION_CID_DEFAULT) == NULL))
            {
                production_cfg_data.test_fail_flag = false;
            }
            else
            {
                production_cfg_data.test_fail_flag = true;
            }
            value_ptr = (uint8_t *)&production_cfg_data.test_fail_flag;
            value_len = sizeof(production_cfg_data.test_fail_flag);
            break;

        case PRODUCTION_KEY_ID_ERROR_CODE:               // 产测错误码，uint8_t
            value_ptr = (uint8_t *)&production_cfg_data.err_code;
            value_len = sizeof(production_cfg_data.err_code);
            break;
        default:
            ret =  VERR_FAIL;
            break;

    }

    if(value_ptr != NULL)
    {
        memcpy(value,value_ptr,VCOM_MIN(*len,value_len));
        *len = value_len;

    }

    vesync_mutex_unlock(production_mutex);
    return ret;
}


/**
 * @brief           设置产测数据
 * @param[in]       key_id          [key id值]
 * @param[out]      value           [产测数据]
 * @param[in/out]   len             [value有效长度]
 * @return          uint32_t        [SDK_OK成功，SDK_FAIL失败]
 */
int vesync_production_set_value_by_key(uint8_t key_id,uint8_t *value,uint16_t len)
{
    uint8_t *value_ptr = NULL;
    int ret = VERR_OK;

    PRODUCTION_UTIL_MEM_CHECK(value, return VERR_FAIL);
    vesync_mutex_lock(production_mutex);

    switch(key_id)
    {
        case PRODUCTION_KEY_ID_CFG_VERSION:           //产测数据版本，uint8_t
            value_ptr =  &production_cfg_data.config_version;
            break;

        case  PRODUCTION_KEY_ID_CID:                      //产测CID，string型，32byte
            if(len != PRODUCTION_CID_LEN)
            {
                PRODUCTION_LOG(LOG_ERROR,"cid len error\n\n");
            }
            else
            {
                value_ptr = production_cfg_data.cid;
            }
            break;

        case PRODUCTION_KEY_ID_TEST_FAIL_FLAG:          //产测失败标志，bool型，默认true
            value_ptr = (uint8_t *)&production_cfg_data.test_fail_flag;
            break;

        case PRODUCTION_KEY_ID_ERROR_CODE:               //产测错误码，uint8_t
            value_ptr = (uint8_t *)&production_cfg_data.err_code;
            break;
        default:
            ret =  VERR_FAIL;
            break;

    }

    if(value_ptr != NULL)
    {
        memcpy(value_ptr,value,len);
        ret = production_set_data_to_flash();
    }

    vesync_mutex_unlock(production_mutex);

    return  ret;
}



/**
 * @brief       注册产测状态(进度)回调函数
 */
void vesync_production_reg_status_cb(production_status_cb_t cb)
{
    s_production_status_cb = cb;
}

/**
 * @brief       注册产测状态(进度)回调函数
 */
void vesync_production_reg_pre_test_cb(production_pre_test_cb_t cb)
{
    s_production_pre_test_cb = cb;
}


/**
 * @brief       注册产测结果回调函数
 */
void vesync_production_reg_result_cb(production_result_cb_t cb)
{
    s_production_result_cb = cb;
}

/**
 * @brief       注册产测获取设备参数回调函数
 */
void vesync_production_reg_extend_data_cb(production_para_cb_t cb)
{
    s_production_extend_data_cb = cb;
}

/**
 * @brief       设置产测状态，并同步进行回调
 * @param[in]   status          [产测状态值]
 */
static void vesync_production_set_status(PRODUCTION_STATUS_E status)
{
    s_production_status = status;
    if (NULL != s_production_status_cb)
    {
        s_production_status_cb(status);
    }
}

/**
 * @brief       设置产测状态，并同步进行回调
 * @return      bool            [true:已准备完成，可以上报; false:未准备完成，不可上报]
 */
static bool vesync_production_get_report_ready(void)
{
    bool flag = true && (s_report_ready_flag & REPORT_NETWORK_READY_FLAG);

#if (PR_OTA_TYPE_MCU > 0)
    flag = flag && (s_report_ready_flag & REPORT_MCU_READY_FLAG);
#endif
#if CONFIG_VESYNC_SDK_BLE_SERVICE_ENABLE
    flag = flag && (s_report_ready_flag & REPORT_BLE_READY_FLAG);
#endif

    return flag;
}

/**
 * @brief       初始化信号量，用于产测状态下上报准备完成与产测任务同步
 */
static void vesync_production_init_report_semp(void)
{
    s_report_ready_flag = 0x00;
    if (NULL == s_report_ready_semp)
    {
        s_report_ready_semp = vesync_sem_binary_new();
    }
    else
    {
        vesync_sem_free(s_report_ready_semp);
        s_report_ready_semp = vesync_sem_binary_new();
    }
}

/**
 * @brief       产测状态下，等待上报准备完成
 * @return      int             [获取信号量成功，返回OK；失败返回fail]
 */
static int vesync_production_wait_report_semp(void)
{
    PRODUCTION_LOG(LOG_DEBUG, "Wait to report\r\n");
    // 正常模式下等待信号量
    if (NULL != s_report_ready_semp)
    {
        if (VERR_OK != vesync_sem_wait(s_report_ready_semp, REPROT_READY_FLAG_WAIT_TIME))
        {
            PRODUCTION_LOG(LOG_ERROR, "take semaphore fail!\n");
            return VERR_FAIL;
        }
    }
    else
    {
        // 创建失败，一般是堆空间导致
        PRODUCTION_LOG(LOG_ERROR, "Semaphore create fail!!\n");
        return VERR_FAIL;
    }

    return VERR_OK;
}

/**
 * @brief       产测状态下，任意上报条件准备完成后，尝试释放信号量。所有准备完成才会释放信号量
 * @return      int             [释放信号量成功，返回OK；失败返回fail]
 */
static int vesync_production_try_release_report_semp(void)
{
    if (!vesync_production_get_report_ready())
    {
        return VERR_OK;
    }
    PRODUCTION_LOG(LOG_DEBUG, "report ready, give Semaphore.\n");
    if (NULL != s_report_ready_semp)
    {
        if (VERR_OK != vesync_sem_signal(s_report_ready_semp))
        {
            PRODUCTION_LOG(LOG_ERROR, "Release semaphore fail!\n");
            return VERR_FAIL;
        }
    }
    else
    {
        // 创建失败，一般是堆空间导致
        PRODUCTION_LOG(LOG_ERROR, "Semaphore create fail!!\n");
        return VERR_FAIL;
    }

    return VERR_OK;
}

/**
 * @brief        MCU已准备完毕，通知产测模块
 */
void vesync_production_set_mcu_ready(void)
{
    s_report_ready_flag |= REPORT_MCU_READY_FLAG;
    vesync_production_try_release_report_semp();
}

/**
 * @brief        网络已准备完毕
 */
static void vesync_production_set_network_ready(void)
{
    s_report_ready_flag |= REPORT_NETWORK_READY_FLAG;
    vesync_production_try_release_report_semp();
}

/**
 * @brief       产测系统连接成功后上报数据
 * @return      int             [成功/失败]
 */
static int vesync_production_report_to_server(void)
{
    int ret = -1;
    int avg_rssi = 0;
    char gw_mac_str[MAC_ADDR_STR_MAX_LEN];
    char sta_mac_str[MAC_ADDR_STR_MAX_LEN];
    uint8_t ota_num = 0;
    vhal_wifi_sta_cfg_t sta_cfg;
    reconn_data_t reconn_data;
    dev_fw_info_t firm_info;
    cJSON *data = NULL;
    cJSON *conn_info = NULL;
    cJSON *firm_info_arr = NULL;

#if CONFIG_VESYNC_HAL_BLE_ENABLE
    char bt_mac_str[MAC_ADDR_STR_MAX_LEN];

    memset(bt_mac_str, 0, sizeof(bt_mac_str));
#endif /* CONFIG_VESYNC_HAL_BLE_ENABLE */

    memset(gw_mac_str, 0, sizeof(gw_mac_str));
    memset(sta_mac_str, 0, sizeof(sta_mac_str));

    // 获取参数
    ret = vhal_utils_get_dev_mac(VHAL_MAC_ROUTER, gw_mac_str, sizeof(gw_mac_str));
    if (VHAL_OK != ret)
    {
        snprintf(gw_mac_str, sizeof(gw_mac_str), "00:00:00:00:00:00");   // 获取mac地址失败，使用0填充
    }
    ret = vhal_utils_get_dev_mac(VHAL_MAC_WIFI_STA, sta_mac_str, sizeof(sta_mac_str));
    if (VHAL_OK != ret)
    {
        snprintf(sta_mac_str, sizeof(sta_mac_str), "00:00:00:00:00:00");   // 获取mac地址失败，使用0填充
    }
    ret = vhal_wifi_get_sta_cfg(&sta_cfg);
    if (VHAL_OK != ret)
    {
        snprintf(sta_cfg.ssid, sizeof(sta_cfg.ssid), "Unknown");
    }

    avg_rssi = vhal_wifi_get_router_rssi(10);   // 10次的均值
    vesync_net_mgmt_get_reconnect_data(&reconn_data);
    ota_num = vesync_device_get_ota_num();

#if CONFIG_VESYNC_HAL_BLE_ENABLE
    if (strcmp(vesync_cfg_get_country_code(), "CN") == 0)
    {
        ret = vhal_ble_get_mac(bt_mac_str, sizeof(bt_mac_str));
        if (VHAL_OK != ret)
        {
            snprintf(bt_mac_str, sizeof(bt_mac_str), "00:00:00:00:00:00");
        }
    }
#endif /* CONFIG_VESYNC_HAL_BLE_ENABLE */

    // json组装
    data = cJSON_CreateObject();
    if (NULL == data)
    {
        PRODUCTION_LOG(LOG_ERROR, "Create data object fail\n");
        return VERR_FAIL;
    }

    cJSON_AddStringToObject(data, "wifiName", sta_cfg.ssid);
    cJSON_AddStringToObject(data, "mac", sta_mac_str);
    cJSON_AddStringToObject(data, "routerMac", gw_mac_str);
    cJSON_AddStringToObject(data, "initState", vesync_net_mgmt_get_reconnect_reason_str(reconn_data.reason));
    cJSON_AddNumberToObject(data, "rssi", avg_rssi);

#if CONFIG_VESYNC_HAL_BLE_ENABLE
    if (strcmp(vesync_cfg_get_country_code(), "CN") == 0)
    {
        cJSON_AddStringToObject(data, "BTMac", bt_mac_str);
    }
#endif /* CONFIG_VESYNC_HAL_BLE_ENABLE */

#if CONFIG_VESYNC_SDK_BLE_SERVICE_ENABLE
    cJSON_AddNumberToObject(data, "bleRssi", production_ble_rssi);
#endif /* CONFIG_VESYNC_SDK_BLE_SERVICE_ENABLE */

    if (NETWORK_REASON == reconn_data.reason || WIFI_REASON == reconn_data.reason)
    { // Wi-Fi/MQTT掉线原因，上报这些信息
        cJSON_AddItemToObject(data, "connInfo", conn_info = cJSON_CreateObject());
        if (NULL != conn_info)
        {
            char tmp_buf[32];
            memset(tmp_buf, 0, sizeof(tmp_buf));
            snprintf(tmp_buf, sizeof(tmp_buf)-1, "W%u,%u,%u,M%u",
                    (unsigned int)reconn_data.retry_cnt[WIFI_RETRY_NO_AP_FOUND], (unsigned int)reconn_data.retry_cnt[WIFI_RETRY_INVALID_PWD],
                    (unsigned int)reconn_data.retry_cnt[WIFI_RETRY_CONNECT_FAIL], (unsigned int)reconn_data.retry_cnt[NETWORK_RETRY_FAIL]);
            cJSON_AddNumberToObject(conn_info, "mqttDisTs", reconn_data.network_disconn_ts);
            cJSON_AddNumberToObject(conn_info, "mqttRecTs", reconn_data.network_reconn_ts);
            cJSON_AddNumberToObject(conn_info, "wifiDisTs", reconn_data.wifi_disconn_ts);
            cJSON_AddNumberToObject(conn_info, "wifiRecTs", reconn_data.wifi_reconn_ts);
            cJSON_AddStringToObject(conn_info, "retry", tmp_buf);
        }
    }

    for (uint8_t idx = 0; idx < ota_num; idx++)
    {   // 获取固件信息
        memset(&firm_info, 0, sizeof(dev_fw_info_t));
        vesync_device_get_fw_info_by_idx(idx, &firm_info);

        if (NULL == firm_info_arr)
        {
            cJSON_AddItemToObject(data, "firmwareInfos", firm_info_arr = cJSON_CreateArray());
        }

        if (NULL != firm_info_arr)
        {
            cJSON *firm_info_num = cJSON_CreateObject();
            if (NULL != firm_info_num)
            {
                cJSON_AddStringToObject(firm_info_num, "pluginName", firm_info.plugin_name);
                cJSON_AddStringToObject(firm_info_num, "version", firm_info.cur_firm_ver);
                cJSON_AddNumberToObject(firm_info_num, "priority", firm_info.priority);
                cJSON_AddBoolToObject(firm_info_num, "isMainFw", firm_info.main_fw);
                cJSON_AddItemToArray(firm_info_arr, firm_info_num);
            }
        }
    }

    if (s_production_extend_data_cb)
    {
        cJSON *item_arr = cJSON_CreateObject();
        char item_name[32];
        memset(item_name, 0, sizeof(item_name));
        if (NULL != item_arr)
        {
            s_production_extend_data_cb(item_arr, item_name);
            cJSON_AddItemToObject(data, item_name, item_arr);
        }
    }

    // 发送，成功后清除缓存和flash中的记录
#if defined(PR_REPORT_PROTOCOL_VER) && (PR_REPORT_PROTOCOL_VER == 3)
    ret = vesync_report_cloud(NET_DATA_TOPIC_STATUS, "initDev", data, CAUSE_CONNECT);
#else
    ret = vesync_report_cloud(NET_DATA_TOPIC_STATUS, "updateDevInfoV2", data, CAUSE_NULL);
#endif

    if (ret == VERR_OK)
    {
        // 在恢复出厂或者ota重启时，才会保存flash，因此也只在这两种情况下清除flash中的记录
        if (UPGRADE_REASON == reconn_data.reason/* || FACTORY_RESET == reconn_data.reason*/\
            || PRODUCTION_REASON == reconn_data.reason)
        {
            vesync_net_flash_write_reconnect_reason(RECONNECT_NONE_REASON);

#if CONFIG_VESYNC_SDK_OTA_ENABLE
            // 如果是ota，设备连上服务器后，需要将升级成功状态上报给服务器
            vesync_report_firm_up(UPG_TP_WIFI, vesync_cfg_get_fw_version(), "", UPG_SUCCESS, 100);

#endif /* CONFIG_VESYNC_SDK_OTA_ENABLE */
        }
        vesync_net_mgmt_clear_reconnect_data();
    }

    return ret;
}

/**
 * @brief       产测系统连接成功后，上报数据的任务
 */
static void vesync_production_testmode_task(void *args)
{
    UNUSED(args);
    //vesync_production_try_release_report_semp();
    vesync_production_wait_report_semp();
    vesync_production_report_to_server();
    vesync_production_set_status(PRODUCTION_RUNNING);   // 设置产测进行中
}

/**
 * @brief       初始化信号量，用于Wi-Fi test，Wi-Fi连接成功同步
 */
static void vesync_production_init_wifi_connected_semp(void)
{
    if (NULL == s_wifi_connected_semp)
    {
        s_wifi_connected_semp = vesync_sem_binary_new();
    }
    else
    {
        vesync_sem_free(s_wifi_connected_semp);
        s_wifi_connected_semp = vesync_sem_binary_new();
    }
}

/**
 * @brief       产测状态下，等待上报准备完成
 * @return      int             [获取信号量成功，返回OK；失败返回fail]
 */
static int vesync_production_wait_wifi_connected_semp(void)
{
    PRODUCTION_LOG(LOG_DEBUG, "Wait for wifi connect...\r\n");
    // 正常模式下等待信号量
    if (NULL != s_wifi_connected_semp)
    {
        if (VERR_OK != vesync_sem_wait(s_wifi_connected_semp, WIFI_TEST_CONNECTED_WAIT_TIME))
        {
            PRODUCTION_LOG(LOG_ERROR, "take semaphore fail!\n");
            return VERR_FAIL;
        }
    }
    else
    {
        // 创建失败，一般是堆空间导致
        PRODUCTION_LOG(LOG_ERROR, "Semaphore create fail!!\n");
        return VERR_FAIL;
    }

    return VERR_OK;
}

/**
 * @brief       产测状态下，任意上报条件准备完成后，尝试释放信号量。所有准备完成才会释放信号量
 * @return      int             [释放信号量成功，返回OK；失败返回fail]
 */
static int vesync_production_release_wifi_connected_semp(void)
{
    PRODUCTION_LOG(LOG_DEBUG, "wifi connected, give Semaphore.\n");
    if (NULL != s_wifi_connected_semp)
    {
        if (VERR_OK != vesync_sem_signal(s_wifi_connected_semp))
        {
            PRODUCTION_LOG(LOG_ERROR, "Release semaphore fail!\n");
            return VERR_FAIL;
        }
    }
    else
    {
        // 创建失败，一般是堆空间导致
        PRODUCTION_LOG(LOG_ERROR, "Semaphore create fail!!\n");
        return VERR_FAIL;
    }

    return VERR_OK;
}

/**
 * @brief       wifi连接成功后，处理回调
 */
static void vesync_production_wifi_test_task(void *args)
{
    UNUSED(args);

    if (NULL == s_production_wifi_cb)
    {
        PRODUCTION_LOG(LOG_WARN, "wifi test callback func is null\r\n");
        return;
    }
    if (VERR_OK != vesync_production_wait_wifi_connected_semp())
    {
        s_production_wifi_cb(0);
    }
    else
    {
        s_production_wifi_cb(1);
    }
    s_production_wifi_cb = NULL;
}

/**
 * @brief       Wi-Fi断开事件处理
 * @param[in]   p_msg           [未使用]
 * @return      int             [成功/失败]
 */
static int production_wifi_disconnected_event_handle_cb(void *p_msg)
{
    UNUSED(p_msg);

    vesync_wifi_led_set_behavior(WIFI_LED_PRODUCTION_TEST);

    return VERR_OK;
}

/**
 * @brief       Wi-Fi连接成功事件处理
 * @param[in]   p_msg           [未使用]
 * @return      int             [成功/失败]
 */
static int production_wifi_connected_event_handle_cb(void *p_msg)
{
    UNUSED(p_msg);

    if (PRODUCTION_WIFI_TEST == vesync_production_get_status())
    {
        vesync_production_release_wifi_connected_semp();
        vesync_event_unsubscribe(EVENT_WIFI_CONNECTED, SUB_ID_PRODUCTION);
    }

    return VERR_OK;
}

/**
 * @brief       设备获取ip事件处理
 * @param[in]   p_msg           [未使用]
 * @return      int             [成功/失败]
 */
static int production_wifi_got_ip_event_handle_cb(void *p_msg)
{
    UNUSED(p_msg);
    vesync_net_mgmt_set_reconnect_time(WIFI_RECONN_TS);

    //if (NETWORK_UNINIT == vesync_net_client_get_status())
    {
        char *p_cid = vesync_device_get_cid();
        char *p_server = NULL;

        if (PRODUCTION_WIFI_TEST == vesync_production_get_status())
        {
            PRODUCTION_LOG(LOG_ERROR, "Wi-Fi test ignore the event that Wi-Fi get ip.\n");
            return VERR_FAIL;
        }
        else if (PRODUCTION_EXIT == vesync_production_get_status())
        {
            PRODUCTION_LOG(LOG_ERROR, "production mode already exit.\n");
            return VERR_FAIL;
        }
        else
        {
            p_server = PR_PRODUCTION_SERVER_ADDR;
        }

        if (NULL != p_server && NULL != p_cid)
        {
            if ((strlen(p_cid) > 0 ) && (strlen(p_server) > 0))
            {
                // 产测使用默认端口
                vesync_net_client_connect(p_server, "", "0", NULL, TLS_CA_NONE);
            }
        }
    }

    return VERR_OK;
}

/**
 * @brief       服务器断开连接事件处理
 * @param[in]   p_msg           [未使用]
 * @return      int             [成功/失败]
 */
static int production_network_disconnected_event_handle_cb(void *p_msg)
{
    UNUSED(p_msg);

    vesync_wifi_led_set_behavior(WIFI_LED_PRODUCTION_TEST);

    return VERR_OK;
}

/**
 * @brief       服务器连接成功事件处理
 * @param[in]   p_msg           [未使用]
 * @return      int             [成功/失败]
 */
static int production_network_connected_event_handle_cb(void *p_msg)
{
    UNUSED(p_msg);
    int ret = VERR_FAIL;

    vesync_production_set_network_ready();
    ret = vesync_task_new(PRODUCTION_TESTMODE_TASK_NAME,
                          NULL,
                          vesync_production_testmode_task,
                          NULL,
                          PRODUCTION_TESTMODE_TASK_STACKSIZE,
                          PRODUCTION_TESTMODE_TASK_PRIO,
                          NULL);
    if (VERR_OK != ret)
    {
        PRODUCTION_LOG(LOG_ERROR, "testmode task create fail\n");
        return VERR_FAIL;
    }
    vesync_wifi_led_set_behavior(WIFI_LED_LOGIN_SUCCESS);

    return VERR_OK;
}

/**
 * @brief       产测网络事件处理禁用
 */
static void vesync_production_net_event_handle_disable(void)
{
    vesync_event_unsubscribe(EVENT_WIFI_DISCONNECTED, SUB_ID_PRODUCTION);
    vesync_event_unsubscribe(EVENT_ROUTER_GOT_IP, SUB_ID_PRODUCTION);
    vesync_event_unsubscribe(EVENT_NWK_DISCONNECTED, SUB_ID_PRODUCTION);
    vesync_event_unsubscribe(EVENT_NWK_CONNECTED, SUB_ID_PRODUCTION);
}


/**
 * @brief       产测网络事件处理使能
 * @return      int             [成功/失败]
 */
static int vesync_production_net_event_handle_enable(void)
{
    if (VERR_OK != vesync_event_subscribe(EVENT_WIFI_DISCONNECTED, SUB_ID_PRODUCTION, production_wifi_disconnected_event_handle_cb))
    {
        goto exit_fail;
    }
    if (VERR_OK != vesync_event_subscribe(EVENT_ROUTER_GOT_IP, SUB_ID_PRODUCTION, production_wifi_got_ip_event_handle_cb))
    {
        goto exit_fail;
    }
    if (VERR_OK != vesync_event_subscribe(EVENT_NWK_DISCONNECTED, SUB_ID_PRODUCTION, production_network_disconnected_event_handle_cb))
    {
        goto exit_fail;
    }
    if (VERR_OK != vesync_event_subscribe(EVENT_NWK_CONNECTED, SUB_ID_PRODUCTION, production_network_connected_event_handle_cb))
    {
        goto exit_fail;
    }

    return VERR_OK;

exit_fail:
    vesync_production_net_event_handle_disable();
    return VERR_FAIL;

}

/**
 * @brief       检查是否产测OK
 * @return      bool             [true:已产测；false：未产测]
 */
bool vesync_production_is_completed(void)
{
    bool test_fail_flag = true;
    uint16_t len = sizeof(test_fail_flag);
    vesync_production_get_value_by_key(PRODUCTION_KEY_ID_TEST_FAIL_FLAG, (uint8_t*)&test_fail_flag, &len);
    return (test_fail_flag == true) ? false : true;
}

/**
 * @brief       进入产测模式
 * @param[in]   reset_record    [true，重置设备重连记录；false，不重置设备连接记录]
 * @return      int             [成功/失败]
 */
int vesync_production_enter_testmode(bool reset_record)
{

    char *p_prd_wifi_ssid = NULL;
    char *p_prd_wifi_pwd = NULL;
    VHAL_WIFI_AUTH_MODE_E auth_mode = VHAL_WIFI_AUTH_OPEN;
    char sta_mac_str[MAC_ADDR_STR_MAX_LEN];

    if (NULL != s_production_pre_test_cb)
    {
        s_production_pre_test_cb();
    }
    memset(sta_mac_str, 0 ,sizeof(sta_mac_str));

    if (PRODUCTION_EXIT != vesync_production_get_status())
    {
        PRODUCTION_LOG(LOG_ERROR, "device already enter production, exit production test mode\n");
        return VERR_FAIL;
    }

    vesync_production_set_status(PRODUCTION_START);

    vesync_ffs_stop();
    vesync_netcfg_stop();
    vesync_lan_comm_stop();
    vesync_net_client_disconnect_server();
    vesync_net_event_mgmt_disable();
    vhal_wifi_scan_stop();
    vhal_wifi_stop();

    if (VERR_OK != vesync_production_net_event_handle_enable())
    {
        PRODUCTION_LOG(LOG_ERROR, "production event subscribe fail!\n");
        return VERR_FAIL;
    }
    vesync_production_init_report_semp();

    // 1.设置产测灯效，启动开发者模式
    vesync_wifi_led_set_behavior(WIFI_LED_PRODUCTION_TEST);      // 注意，停止配网有灯效设置
    vesync_developer_start();

    // 2.设置产测开始
    if (reset_record)
    {
        vesync_net_mgmt_clear_reconnect_data();      // 按键操作需要重置设备重连原因
    }

    vesync_production_load_error_code();

    vesync_net_mgmt_set_reconnect_reason(POWER_ON_REASON);   // 统计设备掉线原因

    // 3.连接产测Wi-Fi
    p_prd_wifi_ssid = PR_PRODUCTION_WIFI_SSID;
    p_prd_wifi_pwd = PR_PRODUCTION_WIFI_PWD;
    if (NULL != p_prd_wifi_pwd && strlen(p_prd_wifi_pwd) > 0)
    {
        auth_mode = VHAL_WIFI_AUTH_WPA_WPA2_PSK;
    }

    PRODUCTION_LOG(LOG_DEBUG, "Wi-Fi SSID[%s], PWD[%s].\n", p_prd_wifi_ssid, p_prd_wifi_pwd);
    vesync_wifi_client_connect(p_prd_wifi_ssid, p_prd_wifi_pwd, auth_mode);      // Wi-Fi连接

    // 4.设置cid(= Wi-Fi mac)，注：获取MAC地址必须在Wi-Fi连接后，即STA接口必须先启动。
    if (VHAL_OK != vhal_utils_get_dev_mac(VHAL_MAC_WIFI_STA, sta_mac_str, sizeof(sta_mac_str)))
    {
        snprintf(sta_mac_str, sizeof(sta_mac_str), "00:00:00:00:00:00");   // 获取mac地址失败，使用0填充
    }
    PRODUCTION_LOG(LOG_DEBUG, "Production param, cid: %s\n", sta_mac_str);
    vesync_device_set_cid(sta_mac_str);

    // 由于云端通过cid识别客户端，需要刷新网络层中的device配置
#if CONFIG_VESYNC_SDK_NET_SERVICE_ENABLE
    vesync_net_client_device_refresh();
#endif

// 蓝牙暂未使用，接口待修改
#if CONFIG_VESYNC_SDK_BLE_SERVICE_ENABLE
    uint8_t product_cmd = PRODUCTION_CMD_CODE;

    // 产测，广播特定的蓝牙
    vhal_ble_set_adv_cmd_data(&product_cmd, 1, false);
    // 打开蓝牙
    vhal_ble_advertising_start();
    // 注册蓝牙产测接收回调函数
    vesync_ble_muxer_add_rxer(vesync_production_ble_data_recv_cb);
#endif /* CONFIG_VESYNC_SDK_BLE_SERVICE_ENABLE */

    return VERR_OK;
}

/**
 * @brief       获取产测状态
 * @return      PRODUCTION_STATUS_E [产测状态值]
 */
PRODUCTION_STATUS_E vesync_production_get_status(void)
{
    return s_production_status;
}

/**
 * @brief       产测连接路由器测试
 * @param[in]   ssid            [路由器ssid]
 * @param[in]   passwd          [路由器密码, 如没有密码传NULL]
 * @param[in]   cb              [测试结果回调函数]
 */
void vesync_production_connect_router_test(const char *ssid, const char *passwd, production_wifi_cb_t cb)
{
    VHAL_WIFI_AUTH_MODE_E auth_mode = VHAL_WIFI_AUTH_OPEN;

    if (PRODUCTION_WIFI_TEST == vesync_production_get_status())
    {
        PRODUCTION_LOG(LOG_ERROR, "production wifi test running...\n");
        return;
    }
    if (NULL == ssid)
    {
        PRODUCTION_LOG(LOG_ERROR, "ssid empty\n");
        return;
    }

    vesync_production_set_status(PRODUCTION_WIFI_TEST);     //产测wifi自检模式

    s_production_wifi_cb = cb;

    vesync_production_net_event_handle_disable();
    vesync_ffs_stop();
    vesync_netcfg_stop();
    vesync_lan_comm_stop();
    vesync_net_client_disconnect_server();
    vesync_net_event_mgmt_disable();

    vhal_wifi_stop();

    if (VERR_OK != vesync_event_subscribe(EVENT_WIFI_CONNECTED, SUB_ID_PRODUCTION, production_wifi_connected_event_handle_cb))
    {
        if (NULL != s_production_wifi_cb)
        {
            s_production_wifi_cb(0);
        }
        PRODUCTION_LOG(LOG_ERROR, "Cannot subscribe network connected event.\n");
        return;
    }
    vesync_production_init_wifi_connected_semp();
    vesync_wifi_led_set_behavior(WIFI_LED_STARTUP);     // 重置灯效

    if (VERR_OK != vesync_task_new(PRODUCTION_WIFI_TEST_TASK_NAME,
                          NULL,
                          vesync_production_wifi_test_task,
                          NULL,
                          PRODUCTION_WIFI_TEST_TASK_STACKSIZE,
                          PRODUCTION_WIFI_TEST_TASK_PRIO,
                          NULL))
    {
        PRODUCTION_LOG(LOG_ERROR, "Cannot create wifi test task!!!\r\n");
        return ;
    }

    if (NULL != passwd && strlen(passwd) > 0)
    {
        auth_mode = VHAL_WIFI_AUTH_WPA_WPA2_PSK;
    }
    vesync_wifi_client_connect(ssid, passwd, auth_mode);
}



/**
 * @brief       设置产测错误码
 * @param       err             [产测错误码]
 * @param       save_flg        [保存flash标记，true写入是flash, false不保存flash]
 */
static void vesync_production_set_error_code(PRODUCTION_ERROR_E err, bool save_flg)
{
    s_production_error_code = err;

    if (NULL != s_production_result_cb)
    {
        s_production_result_cb(err);
    }

    // 退出产测，更新蓝牙广播码
#if CONFIG_VESYNC_SDK_BLE_SERVICE_ENABLE
    uint8_t cmd_code = 0;
    cmd_code = vesync_cfg_get_ble_cmd() & 0xFF;
    vhal_ble_set_adv_cmd_data(&cmd_code, 1, false);
#endif
    if (save_flg)
    {
       // vesync_production_flash_write_production_err_code(s_production_error_code);    //产测错误码保存到本地

        vesync_production_set_value_by_key(PRODUCTION_KEY_ID_ERROR_CODE,(uint8_t *)&s_production_error_code,sizeof(uint16_t));
    }

    PRODUCTION_LOG(LOG_DEBUG, "Update production test error code(%d)\n", s_production_error_code);
}

/**
 * @brief       产测完成，错误码设置
 * @param[in]   err_code        [产测错误码]
 */
void vesync_production_complete_error(PRODUCTION_ERROR_E err_code)
{
    vesync_production_set_error_code(err_code, true);
    vesync_production_set_status(PRODUCTION_TEST_FAIL);
}

/**
 * @brief       产测成功，收到服务器的ack后的回调，设置产测成功
 */
void vesync_production_complete_success_ack_cb(void)
{
    bool test_fail_flag;
    test_fail_flag =false;

    PRODUCTION_LOG(LOG_DEBUG, "production complete ack arrive server event\n");
    //vesync_production_flash_write_production_flag(false);
    vesync_production_set_value_by_key(PRODUCTION_KEY_ID_TEST_FAIL_FLAG,(uint8_t *)&test_fail_flag,sizeof(test_fail_flag));

    vesync_production_set_error_code(PRD_NO_ERR, true);
    vesync_production_set_status(PRODUCTION_TEST_PASS);
}

/**
 * @brief       强制退出产测模式
 * @note        ！仅用于未产测的设备流入市场后，通过配网接口调用
 */
void vesync_production_force_exit_testmode(void)
{
    vesync_production_net_event_handle_disable();
    vesync_event_unsubscribe(EVENT_WIFI_CONNECTED, SUB_ID_PRODUCTION);
    vesync_production_set_status(PRODUCTION_EXIT);
}

/**
 * @brief        从flash加载上一次产测错误码
 */
void vesync_production_load_error_code(void)
{
    // 读取flash中保存上一次产测的错误码
    if(production_cfg_data.err_code > 0)
    {
        vesync_production_set_error_code(production_cfg_data.err_code, false);
    }
}

#if CONFIG_VESYNC_SDK_BLE_SERVICE_ENABLE
/**
 * @brief        蓝牙已准备完毕，通知产测模块
 */
static void vesync_production_set_ble_ready(void)
{
    s_report_ready_flag |= REPORT_BLE_READY_FLAG;
    vesync_production_try_release_report_semp();
}

static bool vesync_production_ble_data_recv_cb(uint8_t *p_data, uint16_t len, bool need_ack)
{
    uint16_t opcode;
    uint8_t status_code;

    uint16_t pl_len;
    uint8_t *p_pl = vesync_tl_payload_decode(p_data, len, &opcode, &status_code, &pl_len);
    if (opcode != PRODUCTION_BLE_RSSI_REPORT_OPCODE)
    {
        return false;
    }
    if ((p_pl != NULL) && (pl_len >= sizeof(int8_t)))
    {
        production_ble_rssi = (int8_t)p_pl[0];

        vesync_ble_disable();
        vesync_production_set_ble_ready();
    }
    else
    {
        PRODUCTION_LOG(LOG_INFO, "invalid rssi_msg\n");
    }
    return true;
}
#endif /* CONFIG_VESYNC_SDK_BLE_SERVICE_ENABLE */
