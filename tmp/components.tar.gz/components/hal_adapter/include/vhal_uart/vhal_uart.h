/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vhal_uart.h
 * @brief       UART串口收发接口
 * @date        2021-04-28
 */

#ifndef __VHAL_UART_H__
#define __VHAL_UART_H__

#include <stdint.h>


#ifdef __cplusplus
extern "C"
{
#endif


/**
 * @brief  串口数据接收回调函数指针]
 * @param[in]  idx                  [串口编号]
 * @param[out] p_buf                [串口数据]
 * @param[in]  buf_len              [串口数据长度]
 */
typedef void (*vhal_uart_recv_cb_t)(uint8_t idx, uint8_t *p_buf, uint16_t buf_len);

/**
 * @brief  启动串口接收任务
 */
void vhal_uart_start(void);

/**
 * @brief  串口参数配置
 * @param[in]  idx                  [串口编号]
 * @param[in]  rx_pin               [串口rx引脚]
 * @param[in]  tx_pin               [串口tx引脚]
 * @param[in]  baudrate             [串口波特率]
 */
void vhal_uart_config(uint8_t idx, uint32_t rx_pin, uint32_t tx_pin, uint32_t baudrate);

/**
 * @brief 注册串口接收数据回调
 * @param[in]  idx                  [串口编号]
 * @param[in]  cb                   [串口数据接收回调函数]
 */
void vhal_uart_reg_recv_cb(uint8_t idx, vhal_uart_recv_cb_t cb);

/**
 * @brief  串口发送数据
 * @param[in]  idx                  [串口编号]
 * @param[in]  p_buf                [待发送数据]
 * @param[in]  buf_len              [待发送数据长度]
 * @return  int                     [成功：VHAL_OK，失败：VHAL_FAIL]
 */
int vhal_uart_send(uint8_t idx, uint8_t *p_buf, uint16_t buf_len);

#ifdef __cplusplus
}
#endif

#endif /* __VHAL_UART_H__ */
