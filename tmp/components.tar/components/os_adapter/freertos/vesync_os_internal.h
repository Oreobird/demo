/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_os_internal.h
 * @brief       定义os相关宏及通用结构体，供内部调用
 * @date        2021-04-21
 */

#ifndef __VESYNC_OS_INTERNAL_H__
#define __VESYNC_OS_INTERNAL_H__

#include <freertos/FreeRTOS.h>

#ifdef __cplusplus
extern "C" {
#endif

// 时间(单位毫秒)转tick，
// 说明：freeRTOS平台，configTICK_RATE_HZ=1000时，pdMS_TO_TICKS()最大只能转换4294秒，否则会溢出；
// configTICK_RATE_HZ=100时，pdMS_TO_TICKS()最大只能转换42949秒，否则会溢出；
#define VESYNC_TIME_ONE_HOUR_IN_MS          (3600000)       // 1小时的毫秒数
#define VESYNC_MS_TO_TICKS(ms)      \
    ((TickType_t)(((ms) <= VESYNC_TIME_ONE_HOUR_IN_MS)? pdMS_TO_TICKS(ms):((TickType_t)(ms)/1000*configTICK_RATE_HZ)))


#ifdef __cplusplus
}
#endif
#endif /* __VESYNC_OS_INTERNAL_H__ */

