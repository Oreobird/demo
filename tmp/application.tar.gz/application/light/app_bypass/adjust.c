/*
 * Copyright © Vesync Technologies Co.Ltd. 2022. All rights reserved.
 * @file        adjust.c
 * @brief       adjust处理接口
 * @date        2022-01-24
 */

#include <stdio.h>

#include "vesync_common.h"
#include "vesync_log.h"
#include "vesync_memory.h"
#include "app_bypass.h"
#include "event.h"
#include "device.h"
#include "scene.h"

int request_data_handle_for_adjust_percent(bp_adjust_percent_request_t *request_data, int *err_code, char *err_msg, void **extra)
{
    int ret = APP_OK;
    dev_cfg_t *p_dev_cfg = app_device_cfg_get();
    if (p_dev_cfg == NULL)
    {
        *err_code = BP_ERR_PARA_ILLEGAL;
        snprintf(err_msg, BP_ERR_MSG_LEN, "device abnormal");
        ret = APP_FAIL;
        goto EXIT;
    }

    if (request_data->step == BP_NO_VALUE)
    {
        *err_code = BP_ERR_ARG;
        snprintf(err_msg, BP_ERR_MSG_LEN, BP_ERR_PARAM_CONV(step, BP_ERR_PARAM_MISS));
        ret = APP_FAIL;
        goto EXIT;
    }

    if (request_data->adjust_type == BP_NO_VALUE)
    {
        *err_code = BP_ERR_ARG;
        snprintf(err_msg, BP_ERR_MSG_LEN, BP_ERR_PARAM_CONV(adjustType, BP_ERR_PARAM_MISS));
        ret = APP_FAIL;
        goto EXIT;
    }

    *extra = vesync_malloc(sizeof(request_data->adjust_type));
    if (*extra == NULL)
    {
        *err_code = BP_ERR_OUT_OF_MEMORY;
        snprintf(err_msg, BP_ERR_MSG_LEN, "no enough memory");
        ret = APP_FAIL;
        goto EXIT;
    }

    memcpy(*extra, &(request_data->adjust_type), sizeof(request_data->adjust_type));

    switch (request_data->adjust_type)
    {
        case BP_ADJUST_TYPE_COLORTEMP:
        {
            if (p_dev_cfg->flash->cfg.mode != LIGHT_MODE_WHITE)
            {
                *err_code = BP_ERR_NOT_EXEC_IN_CUR_MODE;
                snprintf(err_msg, BP_ERR_MSG_LEN, "Params invalid.");
                ret = APP_FAIL;
                goto EXIT;
            }

            int color_temp = (LIGHT_STATUS_OFF == p_dev_cfg->flash->cfg.onoff) ? LIGHT_COLOR_TEMP_MIN : p_dev_cfg->flash->cfg.light_param.color_temp;
            color_temp += request_data->step;
            color_temp = VCOM_MAX(color_temp, LIGHT_COLOR_TEMP_MIN);
            color_temp = VCOM_MIN(color_temp, LIGHT_COLOR_TEMP_MAX);
            p_dev_cfg->flash->cfg.onoff = LIGHT_STATUS_ON;
            p_dev_cfg->flash->cfg.light_param.color_temp = (uint8_t)color_temp;
            break;
        }
        case BP_ADJUST_TYPE_BRIGHTNESS:
        {
            // 开启状态下，除了白光模式与彩光模式，其它模式不执行调整亮度
            if (p_dev_cfg->flash->cfg.onoff == LIGHT_STATUS_ON
                && p_dev_cfg->flash->cfg.mode != LIGHT_MODE_WHITE
                && p_dev_cfg->flash->cfg.mode != LIGHT_MODE_COLOR)
            {
                *err_code = BP_ERR_NOT_EXEC_IN_CUR_MODE;
                snprintf(err_msg, BP_ERR_MSG_LEN, "Params invalid.");
                ret = APP_FAIL;
                goto EXIT;
            }

            // 关闭状态下不响应降低亮度，其他都需要调整亮度
            if (p_dev_cfg->flash->cfg.onoff != LIGHT_STATUS_OFF || request_data->step > 0)
            {
                int status = LIGHT_STATUS_ON;
                switch (p_dev_cfg->flash->cfg.mode)
                {
                    case LIGHT_MODE_WHITE:
                    {
                        int brightness = (LIGHT_STATUS_OFF == p_dev_cfg->flash->cfg.onoff) ? LIGHT_BRIGHTNESS_MIN : p_dev_cfg->flash->cfg.light_param.brightness;
                        brightness += request_data->step;
                        brightness = VCOM_MAX(brightness, LIGHT_BRIGHTNESS_MIN);
                        brightness = VCOM_MIN(brightness, LIGHT_BRIGHTNESS_MAX);
                        if (brightness == LIGHT_BRIGHTNESS_MIN)
                        {
                            status = LIGHT_STATUS_OFF;  // 调到最低亮度时，状态改为关，不修改亮度
                        }
                        else
                        {
                            p_dev_cfg->flash->cfg.light_param.brightness = (uint8_t)brightness;
                        }
                        break;
                    }
                    case LIGHT_MODE_COLOR:
                    {
                        int v = (LIGHT_STATUS_OFF == p_dev_cfg->flash->cfg.onoff) ? LIGHT_VALUE_MIN : p_dev_cfg->flash->cfg.light_param.V;
                        v += request_data->step;
                        v = VCOM_MAX(v, LIGHT_VALUE_MIN);
                        v = VCOM_MIN(v, LIGHT_VALUE_MAX);
                        if (v == LIGHT_VALUE_MIN)
                        {
                            status = LIGHT_STATUS_OFF; // 调到最低亮度时，状态改为关，不修改透明度
                        }
                        else
                        {
                            p_dev_cfg->flash->cfg.light_param.V = (uint8_t)v;
                        }
                        break;
                    }
                    default: // 其它模式只把状态改为开启，暂不支持亮度调整 TODO

                        break;
                }
                p_dev_cfg->flash->cfg.onoff = status;
            }
            break;
        }
        default:
        {
            *err_code = BP_ERR_PARA_ILLEGAL;
            snprintf(err_msg, BP_ERR_MSG_LEN, BP_ERR_PARAM_CONV(adjustType, BP_ERR_PARAM_MISS));
            ret = APP_FAIL;
            goto EXIT;
        }
    }

    app_device_cfg_save(p_dev_cfg);
    uint8_t scene_type = SCENE_LIGHT;
    uint16_t scene_id = p_dev_cfg->flash->cfg.scene_id;
    app_scene_info_get_from_mode(&scene_type, &scene_id);

EXIT:
    if (ret == APP_OK)
    {
        BYPASS_NOTIFY(scene_type, scene_id);
    }
    else
    {
        VCOM_SAFE_FREE(*extra);
    }

    return ret;
}

int reply_data_get_for_adjust_percent(bp_adjust_percent_reply_t *reply_data, int *err_code, char *err_msg, void *extra)
{
    int ret = APP_OK;
    dev_cfg_t *p_dev_cfg = app_device_cfg_get();
    if (p_dev_cfg == NULL)
    {
        *err_code = BP_ERR_PARA_ILLEGAL;
        snprintf(err_msg, BP_ERR_MSG_LEN, "device abnormal");
        ret = APP_FAIL;
        goto EXIT;
    }

    switch (p_dev_cfg->flash->cfg.mode)
    {
        case LIGHT_MODE_WHITE:
        {
            int adjust_type = (extra == NULL) ? BP_ADJUST_TYPE_BRIGHTNESS : *((int *)extra);
            if (adjust_type == BP_ADJUST_TYPE_BRIGHTNESS)
            {
                reply_data->percent = (int)(p_dev_cfg->flash->cfg.light_param.brightness);
            }
            else if (adjust_type == BP_ADJUST_TYPE_COLORTEMP)
            {
                reply_data->percent = (int)(p_dev_cfg->flash->cfg.light_param.color_temp);
            }
            break;
        }
        case LIGHT_MODE_COLOR:
        {
            reply_data->percent = (int)(p_dev_cfg->flash->cfg.light_param.V);
            break;
        }
        default:
            break;
    }

EXIT:
    VCOM_SAFE_FREE(extra);
    return ret;
}

