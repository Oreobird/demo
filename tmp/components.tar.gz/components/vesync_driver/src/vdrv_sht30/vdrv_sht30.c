/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
 * @file        vdrv_sht30.c
 * @brief       sht30驱动接口
 * @author      WatWu
 * @date        2019-01-03
 */

#include "vesync_common.h"
#include "vhal_i2c.h"
#include "vdrv_sht30.h"

#define SHT30_IIC_PORT          0       //SHT30传感器所接的IIC总线端口

#define SHT30_POLYNOMIAL        0x131 // P(x) = x^8 + x^5 + x^4 + 1 = 100110001
// ID register mask (bits 0...5 are SHT30-specific product code
#define SHT30_PRODUCT_ID_MASK   0x003F // SHT30-product ID = xxxx'xxxx'xx00'0111 (where x=unspecific information)

/**
 * @brief SHT30 命令
 */
typedef enum
{
    SHT30_SOFT_RESET = 0x30A2,                      // soft reset
    SHT30_MEASUERE_TH_SINGLESHOT_HIGH_CLK = 0x2C06, // meas. read T first, clock stretching disabled, high repeatibility
    SHT30_MEASUERE_TH_SINGLESHOT_MED_CLK = 0x2C0D,  // meas. read T first, clock stretching disabled, median repeatibility
    SHT30_MEASUERE_TH_SINGLESHOT_LOW_CLK = 0x2C10,  // meas. read T first, clock stretching disabled, low repeatibility
    SHT30_MEASUERE_TH_SINGLESHOT_HIGH = 0x2400,     // meas. read T first, clock stretching disabled, high repeatibility
    SHT30_MEASUERE_TH_SINGLESHOT_MED = 0x240B,      // meas. read T first, clock stretching disabled, median repeatibility
    SHT30_MEASUERE_TH_SINGLESHOT_LOW = 0x2416,      // meas. read T first, clock stretching disabled, low repeatibility
} SHT30_CMD_E;

/**
 * @brief  SHT30 I2C Address
 */
typedef enum
{
    SHT30_I2C_ADDR = 0x44,           // sensor I2C address (7-bit)
    SHT30_I2C_ADDR_WRITE_BIT = 0x88, // sensor I2C address + write bit
    SHT30_I2C_ADDR_READ_BIT = 0x89   // sensor I2C address + read bit
} SHT30_I2C_ADDR_E;

/**
 * @brief 计算温度值
 * @param[in]  raw_value            [传感器原始值]
 * @return  float                   [温度值，单位：摄氏度]
 */
static float vdrv_sht30_calc_temperature(const uint16_t raw_value)
{
    return 175 * (float)raw_value / 65536 - 45;
}

/**
 * @brief 计算湿度值
 * @param[in]  raw_value            [传感器原始值]
 * @return  float                   [湿度值，单位：百分比]
 */
static float vdrv_sht30_calc_humidity(const uint16_t raw_value)
{
    return 100 * (float)raw_value / 65536;
}

/**
 * @brief 检验CRC
 * @param[in] data              [需要计算CRC的数据]
 * @param[in] data_byte         [数据长度]
 * @param[in] checksum          [crc校验值]
 * @return int                  [校验结果，0为成功]
 */
static int vdrv_sht30_check_crc(const uint8_t data[], const uint8_t data_byte, uint8_t const checksum)
{
    uint8_t bit;
    uint8_t crc = 0xFF;
    uint8_t byteCtr;

    for (byteCtr = 0; byteCtr < data_byte; byteCtr++)
    {
        crc ^= (data[byteCtr]);
        for (bit = 8; bit > 0; --bit)
        {
            if(crc & 0x80) crc = (crc << 1) ^ SHT30_POLYNOMIAL;
            else crc = (crc << 1);
        }
    }

    return (crc != checksum) ? SDK_FAIL : SDK_OK;
}

/**
 * @brief 软件复位传感器
 * @return int                  [成功：SDK_OK，失败：SDK_FAIL]
 */
static int vdrv_sht30_soft_reset(void)
{
    uint8_t i2c_data[2];

    i2c_data[0] = (SHT30_SOFT_RESET >> 8);
    i2c_data[1] = (0xFF & SHT30_SOFT_RESET);

    if (VHAL_OK != vhal_i2c_master_write(SHT30_IIC_PORT, true, SHT30_I2C_ADDR_WRITE_BIT, i2c_data, 2))
    {
        return SDK_FAIL;
    }

    return SDK_OK;
}

/**
 * @brief 初始化传感器
 * @return int                  [成功：SDK_OK，失败：SDK_FAIL]
 */
int vdrv_sht30_init(void)
{
    vhal_i2c_master_init(SHT30_IIC_PORT, 21, 19, 100000);
    return vdrv_sht30_soft_reset();
}

/**
 * @brief 读取温湿度值
 * @param[out] p_temp            [温度值]
 * @param[out] p_humi            [湿度值]
 * @return int                   [成功：SDK_OK，失败：SDK_FAIL]
 */
int vdrv_sht30_get_temp_and_humi(float *p_temp, float *p_humi)
{
    int error = SDK_FAIL;

    uint16_t raw_value_temp;
    uint16_t raw_value_humi;
    uint8_t i2c_data[6];

    i2c_data[0] = (SHT30_MEASUERE_TH_SINGLESHOT_HIGH >> 8);
    i2c_data[1] = (0xFF & SHT30_MEASUERE_TH_SINGLESHOT_HIGH);

    error = vhal_i2c_master_write(SHT30_IIC_PORT, true, SHT30_I2C_ADDR_WRITE_BIT, i2c_data, 2);
    if (VHAL_OK != error)
    {
        return SDK_FAIL;
    }
    error = vhal_i2c_master_read(SHT30_IIC_PORT, true, SHT30_I2C_ADDR_READ_BIT, i2c_data, 6);
    if (VHAL_OK != error)
    {
        return SDK_FAIL;
    }

    error = vdrv_sht30_check_crc(&(i2c_data[0]), 2, i2c_data[2]);
    if (SDK_OK != error)
    {
        return error;
    }

    error = vdrv_sht30_check_crc(&(i2c_data[3]), 2, i2c_data[5]);
    if (SDK_OK != error)
    {
        return error;
    }

    raw_value_temp = ((uint16_t)(i2c_data[0]) << 8) + (uint16_t)(i2c_data[1]);
    raw_value_humi = ((uint16_t)(i2c_data[3]) << 8) + (uint16_t)(i2c_data[4]);
    *p_temp = vdrv_sht30_calc_temperature(raw_value_temp);
    *p_humi = vdrv_sht30_calc_humidity(raw_value_humi);

    return error;
}

