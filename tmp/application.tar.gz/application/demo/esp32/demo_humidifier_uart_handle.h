/**
 * Copyright © Vesync Technologies Co.Ltd. 2019-2021. All rights reserved.
 * @file    humidifier_uart_handle.h
 * @brief   应用层处理uart具体业务
 * @author  Niki
 * @date    2021-07-08
 */

#ifndef __DEMO_HUMIDIFIER_UART_HANDLE_H__
#define __DEMO_HUMIDIFIER_UART_HANDLE_H__
#include "vhal_utils.h"
#include "vesync_common.h"

#ifdef __cplusplus
extern "C"
{
#endif




/*
 * @brief       串口服务初始化
 * @return      int32_t         [APP_OK成功  /APP_FAIL失败]
 */
int32_t   demo_uart_app_init();



#ifdef __cplusplus
}
#endif


#endif
