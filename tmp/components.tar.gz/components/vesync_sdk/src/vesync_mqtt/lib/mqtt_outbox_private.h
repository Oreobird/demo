/*
 * This file is subject to the terms and conditions defined in
 * file 'LICENSE', which is part of this source code package.
 * Tuan PM <tuanpm at live dot com>
 */


#ifndef __MQTT_OUTOBX_PRIVATE_H__
#define __MQTT_OUTOBX_PRIVATE_H__


#include "queue.h"
#include "mqtt_outbox.h"


/* The following is the redirection of the interface called by this module */

#ifndef VERR_OK
#include "vesync_common.h"
#define VERR_OK SDK_OK
#define VERR_FAIL SDK_FAIL
#endif /* VERR_OK */

#ifndef MQTT_LOG
#include "vesync_log_internal.h"
#ifdef SDK_LOG
#define MQTT_LOG SDK_LOG
#else
#define MQTT_LOG(level, format, ...)
#endif /* SDK_LOG */
#endif /* MQTT_LOG */

#define VERR_UPLOAD(x, y)

/* The above is the redirection of the interface called by this module */


typedef struct outbox_item
{
    char *buffer;
    int len;
    int msg_id;
    int msg_type;
    int msg_qos;
    outbox_tick_t tick;
    int retry_count;
    pending_state_t pending;
    void (*ack_cb)(void);
    STAILQ_ENTRY(outbox_item) next;
} outbox_item_t;

STAILQ_HEAD(outbox_list_t, outbox_item);


#else
#error This private file can only be included by owner
#endif /* __MQTT_OUTOBX_PRIVATE_H__ */

