/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file    lightstring_scene.c
* @brief   场景参数
* @author  Lind
* @date    2021-12-22
*/

#include <stdbool.h>
#include <stddef.h>

#include "lightstring_led.h"
#include "lightstring_scene.h"
#include "lightstring_board.h"

// 场景灯效参数
static ls_led_node_t node_reverse_slow[24] = {{0, 1024,180}, {1024, 0, 180}, {0, 1024,180}, {1024, 0, 180}, {0, 1024,180}, {1024, 0, 180}, {0, 1024,180}, {1024, 0, 180},
                                              {0, 1024,90}, {1024, 0, 90}, {0, 1024,90}, {1024, 0, 90}, {0, 1024,90}, {1024, 0, 90}, {0, 1024,90}, {1024, 0, 90},
                                              {0, 1024,50}, {1024, 0, 50}, {0, 1024,50}, {1024, 0, 50}, {0, 1024,50}, {1024, 0, 50}, {0, 1024,50}, {1024, 0, 50}};
static ls_led_node_t node_reverse_fast[24] = {{0, 1024,200}, {1024, 0, 200}, {0, 1024,200}, {1024, 0, 200}, {0, 1024,200}, {1024, 0, 200}, {0, 1024,200}, {1024, 0, 200},
                                              {0, 1024,150}, {1024, 0, 150}, {0, 1024,150}, {1024, 0, 150}, {0, 1024,150}, {1024, 0, 150}, {0, 1024,150}, {1024, 0, 150},
                                              {0, 1024,80}, {1024, 0, 80}, {0, 1024,80}, {1024, 0, 80}, {0, 1024,80}, {1024, 0, 80}, {0, 1024,80}, {1024, 0, 80}};
static ls_led_node_t node_alternate_breathing[4] = {{0, 0, 350}, {1024, 0, 350}, {0, 0, 350}, {0, 1024, 350}};
static ls_led_node_t node_alternate_flash[18] = {{1024, 0, 30}, {0, 0, 30}, {1024, 0, 30}, {0, 0, 30}, {1024, 0, 30}, {0, 0, 30},
                                                 {0, 1024, 30}, {0, 0, 30}, {0, 1024, 30}, {0, 0, 30}, {0, 1024, 30}, {0, 0, 30},
                                                 {0, 1024, 30}, {1024, 0, 30}, {0, 1024, 30}, {1024, 0, 30}, {0, 1024, 30}, {0, 1024, 30}};
static ls_led_node_t node_all_breathing[2] = {{0, 0, 300}, {1024, 1024, 300}};
static ls_led_node_t node_alternate_switch[16] = {{1024, 0, 30}, {0, 0, 30}, {1024, 0, 30}, {0, 0, 30}, {1024, 0, 30}, {0, 0, 30}, {1024, 0, 30}, {0, 0, 30},
                                                  {0, 1024, 30}, {0, 0, 30}, {0, 1024, 30}, {0, 0, 30}, {0, 1024, 30}, {0, 0, 30}, {0, 1024, 30}, {0, 0, 30}};

static ls_led_node_t node_all_brighten = {1024, 1024,1500};


// 模式2
static ls_led_dynamic_params reverse_breathing =
{
    .node_num = 24,
    .mode = LS_LED_BREATHING,
    .type = MODE_TYPE_ALL,
    .node_head = node_reverse_slow,
};

// 模式3
static ls_led_dynamic_params reverse_switch =
{
    .node_num = 24,
    .mode = LS_LED_SWITCH,
    .type = MODE_TYPE_ALL,
    .node_head = node_reverse_fast,
};

// 模式4
static ls_led_dynamic_params alternate_breathing =
{
    .node_num = 4,
    .mode = LS_LED_BREATHING,
    .type = MODE_TYPE_ALTERNATE,
    .node_head = node_alternate_breathing,
};

// 模式5
static ls_led_dynamic_params alternate_flash =
{
    .node_num = 18,
    .mode = LS_LED_SWITCH,
    .type = MODE_TYPE_ALL,
    .node_head = node_alternate_flash,
};

// 模式6
static ls_led_dynamic_params all_breathing =
{
    .node_num = 2,
    .mode = LS_LED_BREATHING,
    .type = MODE_TYPE_ALL,
    .node_head = node_all_breathing,
};

// 模式7
static ls_led_dynamic_params alternate_switch =
{
    .node_num = 16,
    .mode = LS_LED_SWITCH,
    .type = MODE_TYPE_ALL,
    .node_head = node_alternate_switch,
};

// 模式8
static ls_led_dynamic_params all_brighten =
{
    .node_num = 1,
    .mode = LS_LED_SWITCH,
    .type = MODE_TYPE_ALL,
    .node_head = &node_all_brighten,
};




static ls_led_dynamic_params *mode_list[7] = {&reverse_breathing, &reverse_switch, &alternate_breathing, &alternate_flash, &all_breathing, &alternate_switch, &all_brighten};
static uint8_t mode_cycle_times[LS_MODE_NUM - 1] = {1, 1, 2, 5, 5, 5, 2};

/**
* @brief 获取产测灯效
* @param[out]  **pst_scene      [产测灯效指针]
*/
void ls_get_production_scene(ls_led_dynamic_params **pst_scene)
{
    *pst_scene = &reverse_switch;
}


/**
* @brief 获取场景模式参数指针
* @param[in]  **mode_head   [指针]
*/
void ls_get_scene_head(void **mode_head)
{
    if (NULL == mode_head)
    {
        return;
    }

    *mode_head = (void *)mode_list;
}

/**
* @brief 是否可调速检查
* @param[in]  id    [scene id]
* @return  bool     [true/false]
*/
bool ls_scene_id_speed_check(uint8_t id)
{
    if (1 == id || 8 == id)
    {
        return false;
    }

    return true;
}


/**
* @brief 获取循环模式每个模式循环次数
* @param[in]  **arry_head       [指针]
*/
void ls_get_comb_cycle_times(uint8_t **arry_head)
{
    if (NULL == arry_head)
    {
        return;
    }

    *arry_head = mode_cycle_times;
}
