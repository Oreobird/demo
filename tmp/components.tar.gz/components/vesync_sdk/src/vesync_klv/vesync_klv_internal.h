/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_klv_internal.h
 * @brief       vesync_klv数据处理模块内部定义
 * @date        2021-04-21
 */

#ifndef __VESYNC_KLV_INTERNAL_H__
#define __VESYNC_KLV_INTERNAL_H__

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define KEY_ARR_ITEM        (0xFF)

#define CHECK_KEY_KLV(key)      (key <= 0xEF)    // 一般KLV用的KEY
#define CHECK_KEY_ARR(key)      (key >= 0xF0 && key <= 0xFE)    // 数组专用的KEY
#define CHECK_KEY_ITEM(key)     (key == KEY_ARR_ITEM)       // 数组元素专用的KEY


#define VCOM_HIGH_BYTE(len)     ((len >> 8) & 0xff)
#define VCOM_LOW_BYTE(len)      (len & 0xff)

#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_KLV_INTERNAL_H__ */

