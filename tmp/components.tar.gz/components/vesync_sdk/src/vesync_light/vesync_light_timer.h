/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_light_internal.h
 * @brief       灯光照明控制模块内部接口定义
 * @author      Herve
 * @date        2021-11-09
 */
#ifndef __VESYNC_LIGHT_TIMER_H__
#define __VESYNC_LIGHT_TIMER_H__

#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief 定时器回调函数类型定义
 */
typedef void (*light_timer_cb_t)(void *arg);

/**
 * @brief 开始定时器任务
 * @return int              [LIGHT_RESULT_E]
 */
int light_timer_task_start(void);

/**
 * @brief 停止定时器任务
 * @return int              [LIGHT_RESULT_E]
 */
int light_timer_task_stop(void);

/**
 * @brief 创建灯光控制器调度定时器
 * @param[in] reload        [是否自动重载]
 * @param[in] intvl         [定时器倒计时周期（毫秒）]
 * @param[in] cb            [定时器回调]
 * @param[in] arg           [回调参数]
 * @return void *           [返回定时器回调，若为NULL，则创建失败]
 */
void *light_timer_new(bool reload, uint32_t intvl, light_timer_cb_t cb, void *arg);

/**
 * @brief 销毁灯光控制器调度定时器
 * @param[in] p_timer       [指向灯光控制器的调度定时器]
 * @return int              [LIGHT_RESULT_E]
 */
int light_timer_del(void *p_timer);

/**
 * @brief 启动灯光控制器调度定时器
 * @return int              [LIGHT_RESULT_E]
 */
int light_timer_start(void *p_timer);

/**
 * @brief 停止灯光控制器调度定时器
 * @return int              [LIGHT_RESULT_E]
 */
int light_timer_stop(void *p_timer);

#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_LIGHT_TIMER_H__ */