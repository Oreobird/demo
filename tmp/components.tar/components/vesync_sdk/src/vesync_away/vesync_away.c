/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file        vesync_away.c
* @brief       away离家功能实现
* @author      PatrickWu
* @date        2019-09-11
*/

#include <time.h>
#include <stdlib.h>
#include <string.h>

#include "vhal_utils.h"
#include "vesync_common.h"
#include "vesync_memory.h"
#include "vesync_log_internal.h"
#include "vesync_away_internal.h"

static away_mgt_t s_away_mgt;

/*-----------------------------------------------------------------------------*
 *                                 内部函数实现                          *
 *-----------------------------------------------------------------------------*/

/**
 * @brief loop跨天计算, 将loop循环左移
 * @param[in] loop
 * @return uint8_t       [返回新的loop]
 */
static uint8_t away_cycle_loop_across_day_calc(uint8_t loop)
{
    uint8_t val = 0;
    if (loop & (uint8_t)0x80)
    {
        val = (loop & LSB_CLEAN_MASK) << 1;
        val |= 1<<1;
    }
    else
    {
        val = (loop & LSB_CLEAN_MASK) << 1;
    }

    val |= (loop & 0x01);
    return val;
}

/**
 * @brief away 时间戳和当前比较并执行
 * @param[in] cur_tm                    [当前时间结构体]
 * @param[in] away_ts                   [要比较的时间戳]
 * @param[in] loop                      [循环执行参数]
 * @param[in] pAway_cycle               [away cycle 数据结构指针]
 * @param[in] away_event                [away 事件]
 * @return  AWAY_COMPARE_RESULT_E       [比较的结果]
 */
static AWAY_COMPARE_RESULT_E away_cycle_time_compare_and_execute(struct tm cur_tm, uint32_t away_ts, uint8_t loop,
                                away_cycle_data_t *pAway_cycle, AWAY_EVENT_E away_event)
{
    AWAY_COMPARE_RESULT_E ret = AWAY_NOT_EXE;

    if (NULL == pAway_cycle)
    {
        return AWAY_EXE_ERR;
    }

    uint8_t thisWeekday = cur_tm.tm_wday;
    if (0 == cur_tm.tm_wday)    //0 表示星期天
    {
        thisWeekday = 7;
    }

    struct tm away_tm = {0};
    time_t ts = (time_t)away_ts;
    gmtime_r(&ts, &away_tm);    //away时间戳转成时分

    SDK_LOG(LOG_INFO, "away_ts = %d, hour = %d min = %d\r\n", away_ts, away_tm.tm_hour, away_tm.tm_min);

    if ((away_tm.tm_hour == cur_tm.tm_hour)&&(away_tm.tm_min == cur_tm.tm_min)&&((loop&LSB_CLEAN_MASK)&(1<<thisWeekday)))
    {
        if (pAway_cycle->away_cb)
        {
            if (pAway_cycle->away_cb(pAway_cycle->pConfig_data, away_event) != AWAY_RESULT_OK)
            {
                SDK_LOG(LOG_ERROR, "away exe fail...\r\n");
                ret = AWAY_EXE_ERR;
            }
            else
            {
                ret = AWAY_EXE_WEEKLY;

                if (!(loop&(uint8_t)0x01))  //loop bit0=0 只执行一次
                {
                    return AWAY_EXE_ONCE;
                }
            }
        }
    }

    return ret;
}


/**
 * @brief 开始时间、结束时间跨天判断api
 * @param[in] begin_ts      [开始时间]
 * @param[in] end_ts        [结束时间]
 * @return bool         [true：开始时间、结束时间不是同一天，false  ：开始时间、结束时间是同一天]
 */
static bool away_cycle_is_across_day(uint32_t begin_ts, uint32_t end_ts)
{
    if ((begin_ts > 1) && (end_ts > 1)
        && ((begin_ts % SENCONDS_PER_DAY) > (end_ts % SENCONDS_PER_DAY))) //服务器下发时间戳0或者1表示无效
    {
        return true;
    }

    return false;
}

/**
 * @brief away cycle　定时轮询函数 10秒执行一次
 * @param[in] *arg
 */
static void away_cycle_loop(void *arg)
{
    static uint8_t old_min = INVALID_MINUTE;
    struct tm cur_tm;
    time_t cur_ts;

    cur_ts = vhal_utils_get_system_time_sec();

    gmtime_r(&cur_ts, &cur_tm); //时间戳转成时分秒

    //SDK_LOG(LOG_DEBUG,"away cycle loop  %d-%d-%d %d:%d:%d, week=%d\r\n",
    //      cur_tm.tm_year, cur_tm.tm_mon, cur_tm.tm_mday, cur_tm.tm_hour,
    //      cur_tm.tm_min,cur_tm.tm_sec, cur_tm.tm_wday);
    SDK_LOG(LOG_DEBUG, "Local time is %s, week=%d\n", ctime(&cur_ts), cur_tm.tm_wday);

    if (old_min == INVALID_MINUTE)
    {
        old_min = cur_tm.tm_min;
    }

    if (old_min == cur_tm.tm_min)
    {
        return;
    }

    old_min = cur_tm.tm_min;

    bool away_remove_flag = false;
    away_cycle_t *pos, *n;
    struct list_head *head = &(s_away_mgt.cycle_list);

    list_for_each_entry_safe(pos, n, head, list)
    {
        away_cycle_data_t *pAway_cycle = &(pos->data);
        if (pAway_cycle->awayId > 0)
        {
            away_remove_flag = false;
            AWAY_COMPARE_RESULT_E compare_ret = AWAY_NOT_EXE;

            uint32_t time_point_count = 0;
            AWAY_EVENT_E event = AWAY_START_ACTION;
            uint32_t ts_offset = 0;

            for (time_point_count = 0; time_point_count < s_away_mgt.rnd_time_point_num; time_point_count++)
            {
                if (pAway_cycle->random_time_point[time_point_count] == 0)  //等于零表示无效值
                {
                    continue;
                }

                ts_offset += pAway_cycle->random_time_point[time_point_count];  //加载随机时间点

                if (0 == (time_point_count % 2))    //偶数为开，奇数为关
                {
                    event = AWAY_RANDOM_ON;
                }
                else
                {
                    event = AWAY_RANDOM_OFF;
                }

                if (0 == time_point_count)
                {
                    event = AWAY_START_ACTION;  //开始动作
                }
                else if ((s_away_mgt.rnd_time_point_num - 1) == time_point_count)
                {
                    event = AWAY_END_ACTION;    //结束动作
                }

                uint8_t loop_val = pAway_cycle->loop;
                //判断是否跨天
                if (away_cycle_is_across_day(pAway_cycle->start_ts, pAway_cycle->start_ts+ts_offset) == true)
                {
                    loop_val = away_cycle_loop_across_day_calc(loop_val);   //跨天重新计算loop
                }

                compare_ret = away_cycle_time_compare_and_execute(cur_tm, pAway_cycle->start_ts+ts_offset, loop_val, pAway_cycle, event);

                if ((compare_ret == AWAY_EXE_ONCE)&&(event == AWAY_END_ACTION))
                {
                    away_remove_flag = true;
                }
                else if (compare_ret == AWAY_EXE_ERR)
                {
                    SDK_LOG(LOG_ERROR,"away cycle execute error\r\n");
                }
                else if (compare_ret == AWAY_EXE_ONCE)
                {// 只执行1次，执行过的点进行清零
                    vesync_away_cycle_clear_random_ts(time_point_count);
                }
            }

            if (true == away_remove_flag)
            {
                SDK_LOG(LOG_DEBUG,"remove away cycle id= %d\r\n", pAway_cycle->awayId);
                list_del(&pos->list);   //移除away cycle任务节点
                s_away_mgt.cycle_num--;
                INIT_LIST_HEAD(&pos->list);
                vesync_free(pos);
                continue;
            }

        }
    }
}

/**
 * @brief away cycle 轮询定时器
 */
static void vesync_away_cycle_start(void)
{
    if (s_away_mgt.away_cycle_running)
    {
        return;
    }

    s_away_mgt.away_cycle_running = true;

    int ret = vesync_timer_new(&s_away_mgt.away_cycle_timer, "away_timer", away_cycle_loop, NULL, AWAY_CYCLE_TIMER_INTERVAL, true);
    if (VOS_OK == ret)
    {
        ret = vesync_timer_start(&s_away_mgt.away_cycle_timer);
        if (VOS_OK != ret)
        {
            SDK_LOG(LOG_ERROR, "Start away timer fail!!!\n");
        }
    }
    else
    {
        SDK_LOG(LOG_ERROR, "Create away timer fail!!!\n");
    }
}

/**
 * @brief 停止away cycle 轮询定时器
 */
static void vesync_away_cycle_stop(void)
{
    vesync_timer_stop(&s_away_mgt.away_cycle_timer);
    s_away_mgt.away_cycle_running = false;
}

/**
 * @brief 生成的随机时间调整,间隔保证1分钟
 * @param[in] pAway_cycle       [away数据结构]
 */
static void away_cycle_ramdom_timepoint_adjust(away_cycle_data_t *pAway_cycle, uint16_t data_num)
{
    uint16_t cnt = 0;

    if (NULL == pAway_cycle)
    {
        return ;
    }

    for (cnt = 0; cnt < data_num; cnt++)
    {
        if (cnt >= AWAY_RANDOM_TIME_MAX_NUM)
        {
            break;
        }

        if (pAway_cycle->random_time_point[cnt] < 60)
        {
            pAway_cycle->random_time_point[cnt] = 60;
        }
    }
}

/**
 * @brief away 随机时间生成
 * @param[in] pAway_cycle             [away数据结构]
 */
static void away_cycle_random_generate(away_cycle_data_t *pAway_cycle)
{
    uint32_t time_point_num = 0, count = 0;
    uint32_t interval = 0;
    uint32_t cur_ts = 0;
    uint32_t old_tick_second = 0, tick_second = 0, tick_random = 0;

    if (NULL == pAway_cycle)
    {
        return;
    }

    memset(&pAway_cycle->random_time_point, 0, sizeof(uint32_t)*AWAY_RANDOM_TIME_MAX_NUM);
    if (pAway_cycle->start_ts >= pAway_cycle->end_ts)
    {
        return;
    }

    interval = pAway_cycle->end_ts - pAway_cycle->start_ts;
    if(interval > 600)  //大于10分钟才开关3次
    {
        time_point_num = AWAY_RANDOM_TIME_MAX_NUM;
    }
    else
    {
        time_point_num = AWAY_RANDOM_TIME_MIN_NUM;
    }

    //srand((unsigned int)time(NULL));// RTL8710cx不支持time获取时间戳
    srand((unsigned int)vhal_utils_get_system_time_sec());

    for (count = 0; count < time_point_num; count++)
    {
        tick_second = interval / 7;
        tick_random = rand() % (tick_second / 2 + 1 ) + 1;
        if (count % 2 )
        {
            tick_second += tick_random;
        }
        else
        {
            tick_second -= tick_random;
        }

        if ((1 == count) && (AWAY_RANDOM_TIME_MIN_NUM == time_point_num))
        {
            pAway_cycle->random_time_point[count] = interval - tick_second - old_tick_second;
        }
        else
        {
            pAway_cycle->random_time_point[count] = tick_second;
        }
        old_tick_second = tick_second;
    }

    away_cycle_ramdom_timepoint_adjust(pAway_cycle, time_point_num);

    // 保存6个(/2个)执行时间点
    s_away_mgt.rnd_time_point_num = time_point_num;

    memset(s_away_mgt.rnd_time_point, 0, sizeof(s_away_mgt.rnd_time_point));
    s_away_mgt.rnd_time_point[0] = pAway_cycle->start_ts + pAway_cycle->random_time_point[0];     // 第1个点，后续的进行累加

    for (count = 1; count < s_away_mgt.rnd_time_point_num; count++)
    {
        s_away_mgt.rnd_time_point[count] = s_away_mgt.rnd_time_point[count - 1] + pAway_cycle->random_time_point[count];
    }

    SDK_LOG(LOG_DEBUG, "s_away_mgt.rnd_time_point_num = %d\r\n", s_away_mgt.rnd_time_point_num);

    // 如果开始时间比当前时间早，但结束时间又比当前时间晚，小于当前时间的随机点，都应该清零
    cur_ts = vhal_utils_get_system_time_sec();

    if (pAway_cycle->start_ts < cur_ts && pAway_cycle->end_ts > cur_ts)
    {
        for (count = 0; count < s_away_mgt.rnd_time_point_num; count++)
        {
            if (s_away_mgt.rnd_time_point[count] < cur_ts)
            {
                s_away_mgt.rnd_time_point[count] = 0;
                //pAway_cycle->random_time_point[count] = 0; // 不能清零，因为该数组需要前后进行累加
            }
        }
    }
}


/**
 * @brief 添加away cycle数据结构到链表
 * @param[in] pAwayData      [away cycle数据结构]
 * @return int               [成功：0, 失败：其它]
 */
static int away_cycle_list_add(away_cycle_data_t *pAwayData)
{
    if (NULL == pAwayData)
    {
        return AWAY_CYCLE_FAIL;
    }

    //TODO: 原实现没有查重，允许添加重复away id节点？?

    away_cycle_t *node = (away_cycle_t *)vesync_malloc(sizeof(away_cycle_t));
    if (node == NULL)
    {
        SDK_LOG(LOG_ERROR, "away vesync_malloc fail\r\n");
        return AWAY_CYCLE_FAIL;
    }

    memset(node, 0, sizeof(away_cycle_t));
    away_cycle_random_generate(pAwayData);

    memcpy(&(node->data), pAwayData, sizeof(away_cycle_data_t));

    list_add(&(node->list), &(s_away_mgt.cycle_list));
    s_away_mgt.cycle_num++;

    return AWAY_CYCLE_OK;
}

/**
 * @brief 从away cycle链表里面删除away节点
 * @param[in] awayId        [away id]
 * @return int              [成功：0, 失败：其它]
 */
static int away_cycle_list_del(uint32_t awayId)
{
    int ret = AWAY_CYCLE_FAIL;
    away_cycle_t *pos, *n;
    struct list_head *head = &(s_away_mgt.cycle_list);

    list_for_each_entry_safe(pos, n, head, list)
    {
        if (awayId == pos->data.awayId)
        {
            list_del(&pos->list);
            s_away_mgt.cycle_num--;
            INIT_LIST_HEAD(&pos->list);
            vesync_free(pos);
            ret = AWAY_CYCLE_OK;
        }
    }

    return ret;
}

/*-----------------------------------------------------------------------------*
 *                           外部函数API实现                                         *
 *-----------------------------------------------------------------------------*/

/**
 * @brief 应用层增加away cycle任务api
 * @param[in] pAwayData             [away cycle 的数据结构]
 * @return  int                     [添加结果]
 */
int vesync_away_cycle_add(away_cycle_data_t *pAwayData)
{
    if (NULL == pAwayData)
    {
        return AWAY_CYCLE_FAIL;
    }

    vesync_away_cycle_stop();
    away_cycle_list_del(pAwayData->awayId);
    int ret = away_cycle_list_add(pAwayData);
    vesync_away_cycle_start();

    return ret;
}

/**
 * @brief 移除away cycle 中的任务
 * @param[in] awayid                [away id]
 * @return int                      [0 移除成功 -1 移除失败]
 */
int vesync_away_cycle_remove(uint8_t awayid)
{
    vesync_away_cycle_stop();
    int ret = away_cycle_list_del(awayid);
    vesync_away_cycle_start();
    return ret;
}


/**
 * @brief 获取当前away cycle 任务数量
 * @return  uint8_t                 [away cycle 的数量]
 */
uint8_t vesync_away_cycle_get_num(void)
{
    return s_away_mgt.cycle_num;
}


/**
 * @brief away loop 计算api
 * @param[in] repeat                [重复次数]
 * @param[in] attr                  [away属性]
 * @return loop 的数值
 */
uint8_t vesync_away_cycle_loop_calc(uint8_t repeat, AWAY_ATTRIBUTE_E attr)
{
    uint8_t loop = repeat & 0xfe;

    if (AWAY_WEEKLY == attr)
    {
        loop |= 0x01;
    }
    return loop;
}


/**
 * @brief 传入时间戳计算星期
 * @param[in] ts                [需要计算的时间戳]
 * @return 1-7                  [周一到周日]
 */
uint8_t vesync_away_get_timestamp_weekday(uint32_t ts)
{
    struct tm cur_tm;
    time_t tmp = (time_t)ts;    // time_t = long

    gmtime_r(&tmp, &cur_tm);    //时间戳转成时分秒
    uint8_t thisWeekday = cur_tm.tm_wday;

    if (0 == cur_tm.tm_wday)    //0 表示星期天
    {
        thisWeekday = 7;
    }

    return thisWeekday;
}


/**
 * @brief  判断away单次执行时，下发的结束时间比当前时间早，则进行调整
 * @param[in]   end_ts          [away结束时间戳]
 * @param[in]   repeat          [away是否重复执行]
 * @return      int32_t         [需要调整的天数]
 */
int32_t vesync_away_cycle_check_end_ts(uint32_t end_ts, uint8_t repeat)
{
    time_t cur_ts = 0;
    int32_t day = 0;

    // cur_ts = time((time_t *)NULL);   // RTL8710cx不支持time获取时间戳
    cur_ts = vhal_utils_get_system_time_sec();

    SDK_LOG(LOG_DEBUG, "repeat is 0x%02x, current ts is %ld, end_ts: %d.\n", repeat, cur_ts, end_ts);

    if ((!repeat) && (end_ts < cur_ts))
    {
        //单次执行，如果下发结束时间比当前时间早，则增加1天
        day = (cur_ts / SENCONDS_PER_DAY) - (end_ts / SENCONDS_PER_DAY);
        if ((end_ts % SENCONDS_PER_DAY) < (cur_ts % SENCONDS_PER_DAY))
        {
            day++;
        }
        SDK_LOG(LOG_DEBUG, "Add %d day.\n", day);
    }

    return day;
}

/**
 * @brief 获取away的6个随机时间点
 * @param[in]  uint32_t *        [读取away随机时间点的缓存指针]
 * @param[in]  int32_t           [缓存长度]
 * @return     int32_t           [0表示成功，非零表示失败]
 */
int32_t vesync_away_get_random_ts(uint32_t *p_rand_ts, int32_t len)
{
    int32_t ret = -1;
    uint16_t cnt;

    if (NULL == p_rand_ts || len < AWAY_RANDOM_TIME_MAX_NUM)
    {
        return ret;
    }

    for (cnt = 0; cnt < AWAY_RANDOM_TIME_MAX_NUM; cnt++)
    {
        p_rand_ts[cnt] = s_away_mgt.rnd_time_point[cnt];
    }

    ret = 0;

    return ret;
}

/**
 * @brief 清除away的6个随机时间点
 * @param[in]  uint32_t          [下标]
 * @return     void              [none]
 */
void vesync_away_clear_random_ts(uint32_t idx)
{
    //SDK_LOG(LOG_DEBUG, "point[%d] = %d\r\n", idx, s_away_mgt.rnd_time_point[idx]);
    // 删除
    if (idx >= AWAY_RANDOM_TIME_MAX_NUM)
    {
        memset(s_away_mgt.rnd_time_point, 0, sizeof(s_away_mgt.rnd_time_point));   // 长度超过随机点总数，清空所有数据
        //s_away_mgt.rnd_time_point_num = 0;
    }
    else
    {
        s_away_mgt.rnd_time_point[idx] = 0;
    }

    SDK_LOG(LOG_DEBUG, "point[%d] = %d\r\n", idx, s_away_mgt.rnd_time_point[idx]);
}

/**
 * @brief 获取随机时间点的实际数量
 * @return     uint32_t              [随机时间点的实际数量]
 */
uint32_t vesync_away_get_random_num(void)
{
    return s_away_mgt.rnd_time_point_num;
}

/**
 * @brief away初始化
 */
void vesync_away_init(void)
{
    memset(&s_away_mgt, 0, sizeof(away_mgt_t));
    s_away_mgt.away_cycle_running = false;
    INIT_LIST_HEAD(&(s_away_mgt.cycle_list));
}

