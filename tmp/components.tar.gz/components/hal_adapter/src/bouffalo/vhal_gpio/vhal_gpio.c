/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file    vhal_gpio.h
 * @brief   vesync设备硬件GPIO抽象层
 * @author  Charles.Mei
 * @date    2021-03-22
 */


#include <stdint.h>

#include "bl602_glb.h"
#include "bl_gpio.h"

#include "vesync_common.h"
#include "vesync_log.h"
#include "vhal_gpio.h"

#define GPIO_MAX_NUM        31      // copy from bl602_hal\hal_gpio.c

/**
 * @brief  GPIO电平获取函数
 * @param[in]  gpio_num             [GPIO编号]
 * @return     int                  [输出电平(0为低电平，1为高电平)]
 */
int32_t vhal_gpio_get_output(uint8_t gpio_num)
{
    return GLB_GPIO_Read((GLB_GPIO_Type)gpio_num);
}

/**
 * @brief  设置GPIO输出电平函数
 * @param[in]  gpio_num             [GPIO编号]
 * @param[in]  level                [输出电平，0: low ; 1: high]
 * @return     int                  [成功/失败]
 */
int32_t vhal_gpio_set_output(uint8_t gpio_num, uint32_t level)
{
    return (SUCCESS == GLB_GPIO_Write((GLB_GPIO_Type)gpio_num, level ? 1 : 0)) ? VHAL_OK : VHAL_FAIL;
}

/**
 * @brief  GPIO状态变更
 * @param[in]  gpio_num             [GPIO编号]
 * @param[in]  pullup               [true时表示GPIO需要pullup；false时表示GPIO需要pulldown]
 * @param[in]  enable               [true表示使能pullup/pulldown；false表示禁用pullup/pulldown]
 * @return     void
 */
void vhal_gpio_change_pull_status(uint8_t gpio_num, bool pullup, bool enable)
{
    UNUSED(gpio_num);
    UNUSED(pullup);
    UNUSED(enable);
    HAL_LOG(LOG_ERROR, "bl602 not support change pull!!!\r\n");
}

/**
 * @brief  GPIO初始化
 * @param[in]  io_conf              [GPIO配置]
 * @return     void
 */
void vhal_gpio_init(vhal_gpio_config_t io_conf)
{
    uint8_t pin_num = 0;
    uint64_t pin_bit_mask = io_conf.pin_bit_mask;

    while((pin_bit_mask = pin_bit_mask >> 1))
    {
        ++pin_num;
    }
    VCOM_LEN_IS_TOO_LARGE(pin_num, GPIO_MAX_NUM, return);

    if (GPIO_MODE_IN == io_conf.mode)
    {
        bl_gpio_enable_input(pin_num, io_conf.pull_up_en, io_conf.pull_down_en);
    }
    else if (GPIO_MODE_OUT == io_conf.mode)
    {
        bl_gpio_enable_output(pin_num, io_conf.pull_up_en, io_conf.pull_down_en);
    }
    else
    {
        HAL_LOG(LOG_ERROR, "bl602 not support gpio mode %d.\r\n", io_conf.mode);
    }
}

/**
 * @brief  GPIO设置方向
 * @param[in]  gpio_num             [GPIO编号]
 * @param[in]  mode                 [GPIO方向]
 * @return     void
 */
void vhal_gpio_set_direction(uint8_t gpio_num, GPIO_MODE_E mode)
{
    if (GPIO_MODE_IN == mode)
    {
        GLB_GPIO_INPUT_Enable(gpio_num);
    }
    else if (GPIO_MODE_OUT == mode)
    {
        GLB_GPIO_OUTPUT_Enable(gpio_num);
    }
    else
    {
        HAL_LOG(LOG_ERROR, "bl602 not support gpio mode %d", mode);
    }
}

void vhal_gpio_register_intr_cb(uint8_t gpio_num, GPIO_INTR_TYPE_E intr_type, vhal_gpio_int_cb_t cb_func, void *arg)
{

}



