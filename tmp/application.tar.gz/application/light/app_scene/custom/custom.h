/**
* Copyright © Vesync Technologies Co.Ltd. 2022. All rights reserved
* @file         custom.h
* @brief        自定义场景
* @author       Joshua
* @date         2022-1-12
*/

#include <stdint.h>
#include "vesync_common.h"
#include "light.h"
#include "scene.h"
#include "device.h"

#ifndef __CUSTOM_H__
#define __CUSTOM_H__

#ifdef __cplusplus
extern "C" {
#endif

#ifndef CUSTOM_SCENE_ID_MIN
#define CUSTOM_SCENE_ID_MIN   (1025)
#endif
#ifndef CUSTOM_SCENE_MAX_NUM
#define CUSTOM_SCENE_MAX_NUM    (16)
#endif

/**
 * @brief 自定义场景结构体
 */
typedef struct
{
    uint8_t reference;      // 场景被使用的次数（如schedule/timer/away等添加的定时执行场景）
    uint8_t mode;
    uint16_t seg_num;
    void seg_param[0];
} custom_light_scene_t;

/**
 * @brief 自定义场景最大数据长度
 * @return int          [场景最大数据长度]
 */
int custom_scene_max_data_size(void);

/**
 * @brief  自定义场景ID生成
 * @return int          [场景ID]
 */
int custom_scene_id_gen(void);

/**
 * @brief  添加自定义场景灯效
 * @param[in] custom_scene  [自定义场景结构体指针]
 * @param[in] id            [自定义场景id]
 * @return  int             [成功：APP_OK，失败：APP_FAIL]
 */
int custom_scene_add(int *scene_id);

/**
 * @brief  删除自定义场景灯效
 * @param[in] id            [场景ID]
 * @return  int             [成功：APP_OK，失败：APP_FAIL]
 */
int custom_scene_del(int scene_id);

#ifdef __cplusplus
}
#endif

#endif





