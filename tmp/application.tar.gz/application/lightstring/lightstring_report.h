/**
*Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file    lightstring_report.h
* @brief   设备状态上报接口
* @author  Lind
*@date     2021-12-20
*/

#ifndef __LIGHTSTRING_REPORT_H__
#define __LIGHTSTRING_REPORT_H__

#include <stdio.h>
#include <stdbool.h>

#include "lightstring_timing.h"
#include "lightstring_schedule.h"

#ifdef __cplusplus
extern "C" {
#endif


/**
* @brief 上报第三方接口(http://34.194.32.46:8080/doc/POOTQH6Bs)，方法名：statusChangeNtyV2
*
* @deprecated 设备开关状态变化，通知云端(http://34.194.32.46:8080/doc/POgSBTDFF)，方法名：updateOnOffV2
* @return     int               [成功/失败]
*/
int report_ls_status(void);

/**
* @brief 设置状态改变原因
* @param  *rsn      状态改变原因
*/
void ls_report_set_chg_rsn(const char* rsn);


/**
* @brief   上报模块初始化
* @return  void
*/
void ls_report_init(void);

/**
* @brief timer执行结果上报(http://34.194.32.46:8080/doc/BVH3a8uib)， deviceLogReport
* @param[in]  ls_timer_t       [灯带timer结构体]
* @param[in]  ret              [灯带timer执行结果]
* @param[in]  p_err_msg        [灯带timer执行失败原因]
* @return     int              [成功/失败]
*/
int ls_report_timing_exec(ls_timing_t *p_timer, uint8_t ret, char *p_err_msg);

/**
* @brief Schedule执行结果上报(http://34.194.32.46:8080/doc/BVH3a8uib)， deviceLogReport
* @param[in] sche_id   [Schedule配置项ID]
* @param[in] type      [Schedule类型]
* @param[in] repeat    [重复配置]
* @param[in] p_app_cfg [APP的Action相关配置]
* @param[in] ret       [执行的返回码]
* @param[in] p_err_msg [指向失败的原因字符串]
* @return int          [成功/失败]
*/
int ls_report_schedule_exec(uint32_t sche_id, uint8_t type, uint8_t repeat,
                                ls_schedule_t *p_app_cfg, uint8_t ret, char *p_err_msg);

#ifdef __cplusplus
}
#endif

#endif

