/**
 *  Copyright © Vesync Technologies Co.Ltd. 2019-2021. All rights reserved
 * @file        vesync_led_color_palette.h
 * @brief       led color palettes definition
 * @author      henrik
 * @date        2021-09-26
 */
#ifndef __LED_COLOR_PALETTE_H__
#define __LED_COLOR_PALETTE_H__

#include "led_display.h"

#ifdef __cplusplus
    {
#endif

/*
 *  @brief 灯带默认色盘ID枚举
 */
typedef enum
{
    LIGHTING = 0,
    MOVIE ,
    SWEET ,
    ROMATIC ,
    CHRISTMAS ,
    FLOWING ,
    RAINBOW,
    BREATH ,
    PALETTE_MAX
}LS_PALETTE_E;


typedef struct
{
    uint8_t id;
    uint8_t color_num ;      // the number of colors of palette
    rgb_color_t *color;      // rgb color array
    hsv_color_t * hsv;
}color_palette_t;


/**
 * @brief 读取指定名称的色盘信息
 * @param[in ]        id                                     [色盘id]
 * @return            palette                                [成功返回色盘指针或失败返回空]
 * @note
 */
color_palette_t * led_strip_color_get_palette(uint8_t id);

#ifdef __cplusplus
}
#endif

#endif

