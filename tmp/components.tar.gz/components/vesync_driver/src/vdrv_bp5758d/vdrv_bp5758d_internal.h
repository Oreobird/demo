/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
 * @file        vdrv_bp5758d_internal.h
 * @brief       bp5758d驱动接口
 * @date        2021-09-14
 */

#ifndef __VDRV_BP5758D_INTERNAL_H__
#define __VDRV_BP5758D_INTERNAL_H__

#include <stdint.h>
#include "vdrv_bp5758d.h"

#ifdef __cplusplus
extern "C"
{
#endif

#define BP5758D_IIC_PORT (0)             // BP5758D所接的IIC总线端口
#define BP5758D_MAX_OUT_DATA_LEN (16)    // BP5758D最大输出数据长度
#define BP5758D_RANGE_START_BYTE_IDX (1) // 输出通道数据起始字节
#define BP5758D_GRAY_START_BYTE_IDX (6)  // 输出通道数据起始字节
#define BP5758D_DEBUG_PRINT (0)          // 调试打印开关

/**
 * @brief  I2C command
 */
typedef enum
{
    BP5758D_SLEEP_MODE = 0x80,  // 睡眠模式
    BP5758D_NORMAL_MODE = 0xB0, // 正常模式
} BP5758D_CMD_E;

#ifdef __cplusplus
}
#endif

#endif

