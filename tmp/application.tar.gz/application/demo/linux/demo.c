/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        demo.c
 * @brief       SDK入口函数
 * @author      Joshua
 * @date        2021-04-22
 */

#include <stddef.h>
#include "vesync_init.h"
#include "vesync_log.h"
#include "vesync_task.h"

#include "vhal_utils.h"

static void demo_pre_cb(void)
{
    APP_LOG(LOG_DEBUG, "Demo pre init callback\n");
}

static void demo_app_run(void)
{
    APP_LOG(LOG_INFO, "Vesync APP Demo start\n");
}

int main(void)
{
    vesync_sdk_reg_pre_run_cb(demo_pre_cb);
    vesync_sdk_reg_post_run_cb(demo_app_run);

    vesync_sdk_run();
}

