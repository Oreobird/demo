/**
 *  Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_uart.h
 * @brief       UART初始化、UART数据收/发
 * @date        2021-05-08
 */

#ifndef __VESYNC_UART_H__
#define __VESYNC_UART_H__

#include <stdint.h>

#include "vhal_uart.h"


#ifdef __cplusplus
extern "C"
{
#endif

#define bypass_trace_msg_t  void    // 测试用

/**
 * @brief 串口通用状态码
 */
typedef enum
{
    UART_COMMON_ERR           = 1,      // 通用错误码
    UART_INTERNAL_ERR         = 2,      // 内部系统错误
    UART_EXEC_FAILED          = 3,      // 业务执行失败
    UART_OPCODE_FORMAT_ERR    = 21,     // 操作码格式错误
    UART_OPCODE_NOT_SUPPORT   = 22,     // 操作码不支持
    UART_VER_NOT_SUPPORT      = 31,     // 版本不支持
    UART_PAYLOAD_FORMAT_ERR   = 51,     // payload格式错误
    UART_PAYLOAD_DECRYPT_FAIL = 52,     // payload密文无法解密
} UART_STATUS_CODE_E;

/*
 * @brief 串口待发送消息来源(发起)类型
 */
typedef enum
{
    UART_MSG_SRC_NONE = 0,              // 非法
    UART_MSG_SRC_BYPASS,                // 消息来源bypass
    UART_MSG_SRC_CLOUD,                 // 消息来源云端
    UART_MSG_SRC_3RD_PARTY,             // 第三方
    UART_MSG_SRC_SELF,                  // 消息来源Wi-Fi模块自身
} UART_MSG_SRC_E;

/**
* @brief 串口待发送消息类型
*/
typedef enum
{
    UART_MSG_TYPE_INVALID = 0,          // 非法值
    UART_MSG_TYPE_CMD,                  // 待发送数据为控制命令
    UART_MSG_TYPE_ACK,                  // 待发送数据为ACK
} UART_MSG_TYPE_E;

/*
 * @brief UART发送结果事件
 */
typedef enum
{
    UART_SEND_SUCCESS = 0,              // 发送成功
    UART_SEND_FAIL                      // 发送失败
} UART_SEND_TYPE_E;

#pragma pack(1)
/**
 * @brief payload信息结构体
 */
typedef struct
{
    uint8_t version;                    // payload版本号
    uint16_t op_code;                   // 操作码opcode
    uint8_t status_code;                // 状态码，0表示正常，非0表示异常，详见TL_FRAME_STATUS_CODE_E
    uint8_t payload_data[1];            // 数据
} uart_payload_info_t;
#pragma pack()

/*
 * @brief 串口消息发送队列数据结构
 */
typedef struct
{
    UART_MSG_SRC_E src;                 // 消息来源
    UART_MSG_TYPE_E type;               // 消息类型
    uint8_t uart_num;                   // 串口编号
    int8_t  seq_id;                     // 序列号
    uint8_t err_flag;                   // 应答包错误指示
    uint8_t status_code;                // 状态码
    uint32_t opcode;                    // 操作码
    bypass_trace_msg_t *p_trace_msg;    // bypass来源的消息，需要记录trace_msg
    void *p_data;                       // 待发送数据
    uint32_t data_len;                  // 数据长度
    void *p_app_data;                   // 可选数据
} uart_msg_queue_t;


/**
 * @brief  收到数据后，按格式组合成一个完整的帧，校验成功之后通过此函数把正确的数据传给应用层
 * @param[in]  uart_num                 [串口编号]
 * @param[in]  frame                    [接收功能模块的结构体指针]
 */
typedef void (*uart_recv_data_cb_t)(VHAL_UART_PORT_E uart_num, uart_payload_info_t *p_payload, uint16_t payload_len);

/**
 * @brief  此回调函数是用于通知应用层之前调用发送函数发送数据成功或者失败
 * @param[in]  event                    [串口数据发送成功/失败事件]
 * @param[in]  p_payload                [发送应答帧的数据字段]
 * @param[in]  payload_len              [应答帧的payload长度]
 * @param[in]  p_msg                    [发送的消息]
 */
typedef void (*uart_tx_event_cb_t)(UART_SEND_TYPE_E event, uart_payload_info_t *p_payload, uint16_t payload_len, uart_msg_queue_t *p_msg);

/**
 * @brief  vesync平台串口服务初始化
 * @param[in]  rx_pin                   [接收管脚]
 * @param[in]  tx_pin                   [发送管脚]
 * @param[in]  baudrate                 [波特率]
 * @return     void
 */
void vesync_uart_init(uint32_t rx_pin, uint32_t tx_pin, uint32_t baudrate);

/**
 * @brief  待发送数据发送到串口发送队列中
 * @return  int32_t                     [0表示发送成功，其他值表示发送失败]
 */
int32_t vesync_uart_send(uart_msg_queue_t *p_msg);

/**
 * @brief  注册UART数据接收回调函数，应用层cb处理具体的业务
 * @param[in]  cb                       [串口数据接收回调函数]
 */
void vesync_uart_reg_recv_cb(uart_recv_data_cb_t cb);

/**
 * @brief  注册UART串口发送成功后返回事件回调函数
 * @param[in]  cb                       [发送返回事件回调函数]
 */
void vesync_uart_reg_tx_event_cb(uart_tx_event_cb_t cb);


#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_UART_H__ */
