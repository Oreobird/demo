/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vhal_gpio.h
 * @brief       GPIO接口封装
 * @date        2021-04-22
 */

#ifndef _VHAL_GPIO_H_
#define _VHAL_GPIO_H_

#include <stdint.h>
#include <stdbool.h>


#ifdef __cplusplus
extern "C"
{
#endif

#define VHAL_GPIO_DATA_HIGH  1
#define VHAL_GPIO_DATA_LOW   0

/**
 * @brief GPIO输入输出方向
 */
typedef enum
{
    GPIO_MODE_DIS       = 0x0,         // disable input and output
    GPIO_MODE_IN        = 0x1,         // input only
    GPIO_MODE_OUT       = 0x2,         // output only
    GPIO_MODE_IN_OUT    = 0x3,         // output and input mode
} GPIO_MODE_E;


/**
 * @brief GPIO pull-up resistor
 */
typedef enum
{
    GPIO_PULLUP_DIS     = 0x0,         // Disable GPIO pull-up resistor
    GPIO_PULLUP_EN      = 0x1,         // Enable GPIO pull-up resistor
} GPIO_PULLUP_E;

/**
 * @brief GPIO pull down resistor
 */
typedef enum
{
    GPIO_PULLDOWN_DIS   = 0x0,         // Disable GPIO pull-down resistor
    GPIO_PULLDOWN_EN    = 0x1,         // Enable GPIO pull-down resistor
} GPIO_PULLDOWN_E;

/**
 * @brief GPIO interrupt type
 */
typedef enum
{
    GPIO_INTR_DIS       = 0,            // Disable GPIO interrupt
    GPIO_INTR_POS_EDGE  = 1,            // GPIO interrupt type : rising edge
    GPIO_INTR_NEG_EDGE  = 2,            // GPIO interrupt type : falling edge
    GPIO_INTR_ANY_EDGE  = 3,            // GPIO interrupt type : both rising and falling edge
    GPIO_INTR_LOW_LVL   = 4,            // GPIO interrupt type : input low level trigger
    GPIO_INTR_HIGH_LVL  = 5,            // GPIO interrupt type : input high level trigger
    GPIO_INTR_TOTAL,
} GPIO_INTR_TYPE_E;

/**
 * @brief GPIO 中断回调函数类型定义
 */
typedef void (*vhal_gpio_int_cb_t)(void *args);


/**
 * @brief Configuration parameters of GPIO pad for gpio_config function
 */
typedef struct
{
    uint64_t pin_bit_mask;              // GPIO pin: set with bit mask, each bit maps to a GPIO
    GPIO_MODE_E mode;                   // GPIO mode: set input/output mode
    GPIO_PULLUP_E pull_up_en;           // GPIO pull-up
    GPIO_PULLDOWN_E pull_down_en;       // GPIO pull-down
    GPIO_INTR_TYPE_E intr_type;         // GPIO interrupt type
} vhal_gpio_config_t;


/**
 * @brief  GPIO初始化
 * @param[in]  io_conf              [GPIO配置]
 */
void vhal_gpio_init(vhal_gpio_config_t io_conf);

/**
 * @brief  GPIO电平获取函数
 * @param[in]  gpio_num             [GPIO编号]
 * @return  int32_t                 [输出电平(0为低电平，1为高电平)]
 */
int32_t vhal_gpio_get_output(uint8_t gpio_num);

/**
 * @brief  设置GPIO输出电平函数
 * @param[in]  gpio_num             [GPIO编号]
 * @param[in]  level                [输出电平，0: low ; 1: high]
 * @return  int32_t                 [成功：VHAL_OK，失败：VHAL_FAIL]
 */
int32_t vhal_gpio_set_output(uint8_t gpio_num, uint32_t level);

/**
 * @brief  GPIO状态变更
 * @param[in]  gpio_num             [GPIO编号]
 * @param[in]  pullup               [true时表示GPIO需要pullup；false时表示GPIO需要pulldown]
 * @param[in]  enable               [true表示使能pullup/pulldown；false表示禁用pullup/pulldown]
 */
void vhal_gpio_change_pull_status(uint8_t gpio_num, bool pullup, bool enable);

/**
 * @brief  GPIO设置方向
 * @param[in]  gpio_num             [GPIO编号]
 * @param[in]  mode                 [GPIO方向]
 * @return  void 
 */
void vhal_gpio_set_direction(uint8_t gpio_num, GPIO_MODE_E mode);


/**
 * @brief  注册GPIO中断回调函数
 * @param[in]  gpio_num          [GPIO编号]
 * @param[in]  intr_type         [GPIO中断沿设置]
 * @param[in]  cb_func           [GPIO中断回调函数]
 * @param[in]  arg               [中断回调函数输入参数]
 * @return  void 
 */
void vhal_gpio_register_intr_cb(uint8_t gpio_num, GPIO_INTR_TYPE_E intr_type, vhal_gpio_int_cb_t cb_func, void *arg);



#ifdef __cplusplus
}
#endif

#endif /* _VHAL_GPIO_H_ */
