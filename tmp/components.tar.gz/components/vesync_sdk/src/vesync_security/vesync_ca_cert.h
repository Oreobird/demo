/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file       vesync_ca_cert.h
* @brief      vesync ca cert head file.
* @date       2022-03-03
* @note       File auto generated, DO NOT edit.
*/


#ifndef __VESYNC_CA_CERT_H__
#define __VESYNC_CA_CERT_H__

#ifdef __cplusplus
extern "C" {
#endif


extern const char brand_aes_key[];

#if CONFIG_VESYNC_SDK_PRODUCTION_ENABLE
#if CONFIG_VESYNC_SDK_MQTT_ENABLE
extern const char vesync_mqtt_production_ca_cert_pem[];
extern const unsigned char vesync_mqtt_production_ca_cert_der[];
extern const int vesync_mqtt_production_ca_cert_der_len;
#endif
#endif

#if CONFIG_VESYNC_SDK_MQTT_ENABLE
extern const char vesync_mqtt_ca_cert_pem[];
extern const unsigned char vesync_mqtt_ca_cert_der[];
extern const int vesync_mqtt_ca_cert_der_len;

extern const char vesync_mqtt_client_cert_pem[];
extern const unsigned char vesync_mqtt_client_cert_der[];
extern const int vesync_mqtt_client_cert_der_len;

extern const unsigned char vesync_mqtt_client_key_pem[];
extern const int vesync_mqtt_client_key_pem_len;

extern const unsigned char vesync_mqtt_client_key_der[];
extern const int vesync_mqtt_client_key_der_len;
#endif

#if CONFIG_VESYNC_SDK_HTTPS_ENABLE
extern const char vesync_https_ca_cert_pem[];
extern const char vesync_https_client_cert_pem[];
extern const char vesync_https_client_key_pem[];
#endif


#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_CA_CERT_H__ */
