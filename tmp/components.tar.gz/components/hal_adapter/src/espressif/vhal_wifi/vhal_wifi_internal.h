/**
 *  Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
 * @file        vhal_wifi_internal.h
 * @brief       封装厂家乐鑫 SDK提供的Wi-Fi相关接口
 * @author      Dongri.Su
 * @date        2021-04-20
 */

#ifndef __VHAL_WIFI_INTERNAL_H__
#define __VHAL_WIFI_INTERNAL_H__

#include "vesync_common.h"

#include "vhal_wifi.h"


#ifdef __cplusplus
extern "C"
{
#endif

#define ENABLE_DEL_TMR_SEM                  1           // vesync平台Wi-Fi重连方式定时器信号量标志位

// Wi-Fi状态、网络状态事件标志组位定义
#define VHAL_WIFI_EVENT_BIT_CONNECT         0X000001
#define VHAL_WIFI_EVENT_BIT_DISCONNECT      0X000002


/*
 * @brief  Wi-Fi连接失败错误原因
 * @note  从components/esp32/event_default_handlers.c拷贝过来的
 */
typedef struct
{
    int err;
    const char *reason;
} wifi_reason_t;

/*
 * @brief  Wi-Fi运行配置
 * @note
 */
typedef struct
{
    VHAL_WIFI_PS_TYPE_E ps_type;                    // Wi-Fi节能模式
    char country_code[CONUTRY_CODE_STR_MAX_LEN + 1];// 国家码
    char hostname[DHCP_HOST_NAME_MAX_LEN];          // DHCP hostname
} vhal_esp_wifi_cfg_t;

/*
 * @brief  Wi-Fi运行状态
 * @note
 */
typedef struct
{
    int32_t chan;                                   // 当前工作信道
    bool scan_flag;                                 // Wi-Fi扫描列表标志位，true表示正在扫描
    bool stop_flag;                                 // Wi-Fi停止标志位，true表示应用层主动停止Wi-Fi连接，忽略event中的disconnect事件
    bool netcfg_flag;                               // 配网标志位，true表示正在配网，false表示非配网
    VHAL_WIFI_STATUS_E net_status;                  // 当前网络状态(Wi-Fi)

    // 回调函数指针
    vhal_wifi_status_cb_t status_cb;                // Wi-Fi连接状态回调函数指针
    vhal_wifi_scan_cb_t scan_cb;                    // 保存扫描结果到WiFi扫描列表管理模块回调函数
    vhal_wifi_disc_log_cb_t disc_log_cb;            // Wi-Fi异常断开连接时传递错误码和错误描述的callback
} vhal_esp_wifi_status_t;

/**
 * @brief 修改dhcp的hostname
 * @param[in] p_hostname   [新的hostname]
 */
void vhal_wifi_chg_dhcp_hostname(const char *p_hostname);

/**
 * @brief 设备作为STA时，获取分配到的IP。
 * @param[in]  p_buf    [保存IP的缓存]
 * @param[in]  buf_len  [缓存大小]
 * @return     char*    [IP地址]
 */
char* vhal_wifi_get_sta_ip(char *p_buf, int32_t buf_len);

#ifdef __cplusplus
}
#endif

#endif /* __VHAL_WIFI_INTERNAL_H__ */

