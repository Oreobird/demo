/**
* Copyright © Vesync Technologies Co.Ltd. 2022. All rights reserved.
* @file    led_strip_button.c
* @brief   按键功能
* @author  Lind
* @date    2022-01-01
*/

#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <stdio.h>

#include "vhal_gpio.h"

#include "vesync_log.h"
#include "vesync_common.h"
#include "vesync_task.h"
#include "vesync_button.h"

#include "led_strip.h"
#include "led_strip_board.h"
#include "led_strip_report.h"
#include "led_strip_button.h"

#define TRIGGER_NETCFG_TIME_MS  5000
#define TRIGGER_RESET_TIME_MS   15000
#define TRIGGER_PRODUCTION_TIME_MS  2000
#define POWERON_TIME_MS  10000

static uint64_t s_hold_start_ts = 0;
static uint64_t s_power_on_ts = 0;
static uint8_t s_click_cnt = 0;
static uint64_t s_press_down_ts = 0;
static bool s_press_down_tick = true;
static bool s_wifi_led_flag = false; // 防止重启前后都按着按键

/**
* @brief 按下触发回调
*/
static void press_down_handle(void)
{
    if (s_press_down_tick)
    {
        s_press_down_ts = vesync_task_get_tick_ms();
        s_press_down_tick = false;
    }
    ls_ev_t ev;
    ev.act_src = LS_ACT_SRC_BTN;
    s_hold_start_ts = vesync_task_get_tick_ms();
    s_wifi_led_flag = true;

    if (s_hold_start_ts - s_power_on_ts <= POWERON_TIME_MS)  // 上电10秒内
    {
        if (s_hold_start_ts - s_press_down_ts < TRIGGER_PRODUCTION_TIME_MS)  // 2s内按5次
        {
            s_click_cnt++;
            APP_LOG(LOG_DEBUG, "click cnt = %d\n", s_click_cnt);
            if (s_click_cnt >= 5)
            {
                s_click_cnt = 0;
                APP_LOG(LOG_DEBUG, "------Trigger production: %d-------\n", (int)(s_hold_start_ts - s_press_down_ts));
                ev.id = LS_EV_PRODUCTION;
                ls_report_set_chg_rsn(STAT_CHG_RSN_BTN_STR);
                ls_app_task_notify(&ev);
            }
        }
        else
        {
            s_press_down_ts = vesync_task_get_tick_ms();
            s_click_cnt = 1;
            APP_LOG(LOG_DEBUG, "click cnt = %d\n", s_click_cnt);
        }
    }
}

/**
* @brief 松开触发回调
*/
static void press_up_handle(void)
{
    uint64_t hold_end_ts = vesync_task_get_tick_ms();
    if (hold_end_ts - s_hold_start_ts > TRIGGER_NETCFG_TIME_MS)
    {
        APP_LOG(LOG_DEBUG, "-------Trigger netcfg: %d-------\n", (int)(hold_end_ts - s_hold_start_ts));
        ls_ev_t ev;
        ev.act_src = LS_ACT_SRC_BTN;
        ev.id = LS_EV_NETCFG;
        ls_app_task_notify(&ev);
        ls_report_set_chg_rsn(STAT_CHG_RSN_BTN_STR);
    }
}

/**
* @brief 单击触发回调
*/
static void single_click_handle(void)
{
    ls_ev_t ev;
    ev.act_src = LS_ACT_SRC_BTN;
    ev.id = LS_EV_TURN_ON;
    ev.mode = LS_MODE_SCENE;
    ev.scene_id = 0;

    APP_LOG(LOG_DEBUG, "-------Single_click-------\n");
    ls_report_set_chg_rsn(STAT_CHG_RSN_BTN_STR);
    ls_app_task_notify(&ev);
}

/**
* @brief 双击触发回调
*/
static void double_click_handle(void)
{
    APP_LOG(LOG_DEBUG, "-------Trigger double_click_handle-------\n");
    ls_ev_t ev;
    ev.id = LS_EV_TURN_OFF;
    ev.act_src = LS_ACT_SRC_BTN;
    ls_app_task_notify(&ev);
}

/**
* @brief 长按定时回调
*/
static void long_press_hold_handle(void)
{
    uint64_t hold_ts = vesync_task_get_tick_ms();
    ls_ev_t ev;
    ev.act_src = LS_ACT_SRC_BTN;

    APP_LOG(LOG_DEBUG, "-------Trigger long_press_hold_handle-------\n");
    if (hold_ts - s_hold_start_ts > TRIGGER_RESET_TIME_MS)
    {
        APP_LOG(LOG_DEBUG, "-------Trigger reset: %d-------\n", (int)(hold_ts - s_hold_start_ts));
        ev.id = LS_EV_RESET;
        ev.scene_id = 50;
        ls_app_task_notify(&ev);
        ls_report_set_chg_rsn(STAT_CHG_RSN_BTN_STR);
        s_hold_start_ts = hold_ts;
    }
    else if (hold_ts - s_hold_start_ts > TRIGGER_NETCFG_TIME_MS && s_wifi_led_flag == true)
    {
        ev.id = LS_EV_BEFORE_NETCFG;
        ev.scene_id = 20;
        ls_app_task_notify(&ev);
        ls_report_set_chg_rsn(STAT_CHG_RSN_BTN_STR);
        s_wifi_led_flag = false;
    }

}

/**
 * @brief ledstrip button事件表
 */
static btn_ev_cb_t s_ev_cb_tbl[] = {
    {EV_PRESS_DOWN, press_down_handle},
    {EV_PRESS_UP, press_up_handle},
    {EV_SINGLE_CLICK, single_click_handle},
    {EV_DOUBLE_CLICK, double_click_handle},
    {EV_LONG_PRESS_HOLD, long_press_hold_handle}
};

/**
 * @brief ledstrip button初始化
 */
int ls_button_init(void)
{
    int ret = SDK_FAIL;

    s_power_on_ts = vesync_task_get_tick_ms();

    btn_cfg_t cfg;

    memset(&cfg, 0, sizeof(btn_cfg_t));
    cfg.gpio = LS_BUTTON_IO;
    cfg.active_level = ACTIVE_LOW;
    cfg.long_press_cb_interval_ms = 5000;

    ret = vesync_button_add(&cfg);
    if (ret != SDK_OK)
    {
        APP_LOG(LOG_ERROR, "button add fail\n");
        return APP_FAIL;
    }

    ret = vesync_button_reg_cb_arr(LS_BUTTON_IO, s_ev_cb_tbl, SIZEOF_ARRAY(s_ev_cb_tbl));
    if (ret != SDK_OK)
    {
        APP_LOG(LOG_ERROR, "button reg cb fail\n");
        vesync_button_del(LS_BUTTON_IO);
        return APP_FAIL;
    }

    return APP_OK;
}

int ls_button_deinit(void)
{
    return (SDK_OK == vesync_button_del(LS_BUTTON_IO)) ? APP_OK : APP_FAIL;
}

