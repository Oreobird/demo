/**
 * Copyright © Vesync Technologies Co.Ltd. 2019-2021. All rights reserved.
 * @file    hal_ota.c
 * @brief   ota功能实现
 * @author  Louis
 * @date    2021-03-26
 */

//#include <stdio.h>
#include <FreeRTOS.h>
#include <task.h>
#include <semphr.h>
#include <lwip/ip4_addr.h>
#include <http_client.h>
#include <utils_sha256.h>
#include <hal_boot2.h>
#include <bl_mtd.h>
#include <hal_sys.h>
#include <lwip/dhcp.h>
#include <lwip/tcpip.h>
#include <lwip/ip_addr.h>
#include <lwip/sockets.h>
#include <lwip/netdb.h>
#include "vesync_common.h"
#include "vesync_log.h"
#include "vhal_ota.h"
#include "vhal_ota_internal.h"


static ota_info_t s_ota_info = {0};
static ota_cb_t s_ota_cb = {0};

static bl_mtd_handle_t handle_mcu = NULL;

/**
 * @brief  更新OTA升级状态
 * @param status        [ota状态]
 * @param prog          [固件下载进度]
 * @return                 [无]
 */
static void hal_ota_update_status(VHAL_OTA_STATE_E status, uint8_t prog)
{
    s_ota_info.stat = status;
    s_ota_info.percent = prog;
    if (NULL != s_ota_cb.hal_stat_cb)
    {
        s_ota_cb.hal_stat_cb(status, prog);
    }
}


/**
 * @brief 从http的URL中提取host和port
 * @param pUrl      [入参指针，完整的URL]
 * @param urlParts  [输出指针，包含保存host地址、path目录文件、port]
 * @return int      [成功/失败]
 */
static int vhal_http_parse_url(const char *pUrl, URLParts_t* urlParts)
{
    if(pUrl == NULL)
    {
        HAL_LOG(LOG_ERROR, "The parameter contains a null pointer!\n");
        return VHAL_FAIL;
    }

    char *pPartA = NULL;
    char *pPartB = NULL;

    urlParts->port = 80;        //设置默认端口为80，当传递的URL为不带端口号时使用默认端口
    pPartA = (char *)pUrl;

    if(!strncmp(pPartA, "http://", strlen("http://")))      // 检查头部
    {
        pPartA += strlen("http://");
    }
    else
    {
        return VHAL_FAIL;
    }

    pPartB = (char *)strstr(pPartA, ":");
    if (!pPartB)
    {
        pPartB = (char *)strstr(pPartA, "/");
    }

    if(pPartB)                                                      // 如果有URI
    {
        strncpy(urlParts->host, pPartA, pPartB - pPartA);     // 将Host提取出来
        urlParts->host[pPartB - pPartA] = 0;                 // Host结束
    }
    else
    {
        strncpy(urlParts->host, pPartA, sizeof(urlParts->host) - 1);
    }

    if(pPartB && pPartB[0] == ':')
    {
        pPartA = pPartB + 1;
        pPartB = strstr(pPartA, "/");
        urlParts->port = atoi(pPartA);
    }

    if(pPartB)
    {
        strncpy(urlParts->path, pPartB, sizeof(urlParts->path) -1);    // 将FileName提取出来
    }else
    {
        strncpy(urlParts->path, "/", sizeof(urlParts->path) -1);    // 将FileName提取出来
    }

    HAL_LOG(LOG_INFO, "host is:%s\n", urlParts->host);
    HAL_LOG(LOG_INFO, "port is: %d \n", urlParts->port);
    HAL_LOG(LOG_INFO, "path is:%s\n", urlParts->path);
    return VHAL_OK;
}


static int check_ota_header(ota_header_t *ota_header, uint32_t *ota_len, int *use_xz)
{
    char str[33];//assume max segment size
    int i;

    memcpy(str, ota_header->u.s.header, sizeof(ota_header->u.s.header));
    str[sizeof(ota_header->u.s.header)] = '\0';
    HAL_LOG(LOG_DEBUG, "[OTA] [HEADER] ota header is %s\r\n", str);

    memcpy(str, ota_header->u.s.type, sizeof(ota_header->u.s.type));
    str[sizeof(ota_header->u.s.type)] = '\0';
    HAL_LOG(LOG_DEBUG, "[OTA] [HEADER] file type is %s\r\n", str);

    if (strstr(str, "XZ")) {
        *use_xz = 1;
    } else {
        *use_xz = 0;
    }

    memcpy(ota_len, &(ota_header->u.s.len), 4);
    HAL_LOG(LOG_DEBUG, "[OTA] [HEADER] file length (exclude ota header) is %lu\r\n", *ota_len);

    memcpy(str, ota_header->u.s.ver_hardware, sizeof(ota_header->u.s.ver_hardware));
    str[sizeof(ota_header->u.s.ver_hardware)] = '\0';
    HAL_LOG(LOG_DEBUG, "[OTA] [HEADER] ver_hardware is %s\r\n", str);

    memcpy(str, ota_header->u.s.ver_software, sizeof(ota_header->u.s.ver_software));
    str[sizeof(ota_header->u.s.ver_software)] = '\0';
    HAL_LOG(LOG_DEBUG, "[OTA] [HEADER] ver_software is %s\r\n", str);

    memcpy(str, ota_header->u.s.sha256, sizeof(ota_header->u.s.sha256));
    str[sizeof(ota_header->u.s.sha256)] = '\0';
    HAL_LOG(LOG_DEBUG, "[OTA] [HEADER] sha256 is:\r\n");
    for (i = 0; i < sizeof(ota_header->u.s.sha256); i++) {
        printf("%02X", str[i]);
    }
    printf("\r\n");

    return 0;
}


static int32_t ota_gethostbyname(char *hostname, char *ip_buff, uint32_t buff_len)
{
    struct hostent *hostinfo;
    struct in_addr dest;

    hostinfo = gethostbyname(hostname);
    if (hostinfo) {
        dest = *((struct in_addr *) hostinfo->h_addr);
        char *ip = inet_ntoa(dest.s_addr);

        strncpy(ip_buff, ip, buff_len);
        HAL_LOG(LOG_DEBUG, "[%s] ip address [%s]\r\n", hostname, ip_buff);
        return 0;
    } else {
        return -1;
    }
}

static int socket_create(const char *host, int port)
{
    struct sockaddr_in server_addr; 
    int socket_fd;
    int ret;
    char ip[16] = {0};
 
    memset(ip,0,sizeof(ip)); 
    ret = ota_gethostbyname((char *)host, ip, 16);
    if(ret < 0){
        HAL_LOG(LOG_ERROR, "get ip error\r\n");
        return -1;
    }

    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(port);
    server_addr.sin_addr.s_addr = inet_addr(ip);
 
    socket_fd = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if(socket_fd == -1){
        HAL_LOG(LOG_ERROR, "create socket failed.\r\n");
        return -1;
    }
 
    if(connect(socket_fd, (struct sockaddr *)&server_addr,sizeof(server_addr)) == -1){
        HAL_LOG(LOG_ERROR, "connect failed\r\n");
        return -1;
    }

    fcntl(socket_fd, F_GETFL, 0);

    return socket_fd;
}


static int ota_send(int socket_fd, char *send_buf, int send_len)
{
    int send_ok = 0;
    int ret_len = 0;

    while(send_ok < send_len){
        ret_len = send(socket_fd, send_buf + send_ok, send_len - send_ok, 0);
        if(ret_len == -1){
            return -1;
        }
        send_ok += ret_len;
    }
    return send_ok;
}

static int32_t ota_recv( int32_t fd, void *buf, int32_t len, int32_t flags, uint32_t timeout_ms )
{
    int32_t ret;
    fd_set fds;
    struct timeval tv;

    FD_ZERO(&fds);
    FD_SET(fd, &fds);
    tv.tv_sec = timeout_ms / 1000;
    tv.tv_usec = (timeout_ms % 1000) * 1000;
    ret = select(fd+1, &fds, NULL, NULL, &tv);
    if (ret < 0)
    {
        HAL_LOG(LOG_ERROR, "ret = %s\n", strerror(errno));
    }
    else if (ret == 0)
    {
        // 超时返回-1，防止跟断开连接无法区分。
        ret = -1;
        HAL_LOG(LOG_DEBUG, "timeout\n");
    }
    else
    {
        ret = recv(fd, buf, len, flags);
        if (ret <= 0)
        {
            // 返回值为0表示连接以断开
            HAL_LOG(LOG_DEBUG, "ret = %d, errno = %s\n", ret, strerror(errno));
        }
    }

    return ret;
}

static int ota_set_download_len(int socket_fd, URLParts_t *url_info)
{
    char *recv_p1 = NULL;
    char *recv_p2 = NULL;
    char buf[1024] = {0};
    int recv_len = 0;
    int ret_len = 0;
    long int download_len = 0;

    snprintf(buf, sizeof(buf), HTTP_GET, url_info->path, url_info->host);
    HAL_LOG(LOG_DEBUG, "send:\r\n%s\r\n",buf);

    if(ota_send(socket_fd, buf, strlen(buf)) < 0){
        HAL_LOG(LOG_ERROR, "get_file_data send failed!\n");
        return -1;
    }

    memset(buf, 0, 1024);
    while(1){
        ret_len = ota_recv(socket_fd, buf + recv_len, 1, 0, 2000);
        if(ret_len < 0){
            HAL_LOG(LOG_ERROR, "get_file_data recv failed!\n");
            return -1;
        }
        
        recv_len += ret_len;
        if(recv_len < 200) continue;

        recv_p1 = strstr(buf, "\r\n\r\n");
        if(recv_p1 == NULL) continue;

        recv_p2 = strstr(buf, "Content-Length");
        if(recv_p2 == NULL){
            HAL_LOG(LOG_ERROR, "Parse data length error!\n");
            return -1;
        }
        recv_p2 = recv_p2 + strlen("Content-Length") + 2; 
        download_len = atoi(recv_p2);
        break;
    }

    HAL_LOG(LOG_DEBUG, "download_len: %ld, recv:\r\n%s\r\n", download_len, buf);

    return download_len;
}

static int ota_get_data(URLParts_t *url_info)
{
    int socket_fd = 0;
    int32_t download_len = 0;
    int ret_len = 0;
    char recv_buf[EVERY_PACKET_LEN] = {0};
    int use_xz;
    uint32_t ota_bin_size;
    uint8_t activeID;
    HALPartition_Entry_Config ptEntry;
    uint32_t ota_part_addr, ota_part_size;
    bl_mtd_handle_t handle;
    int ret, i;
    uint32_t percent = 0;

    iot_sha256_context sha_ctx;
    uint8_t sha256_result[32];
    uint8_t sha256_img[32];

    utils_sha256_init(&sha_ctx);
    utils_sha256_starts(&sha_ctx);
    memset(sha256_result, 0, sizeof(sha256_result));

    ret = bl_mtd_open(BL_MTD_PARTITION_NAME_FW_DEFAULT, &handle, BL_MTD_OPEN_FLAG_BACKUP);
    if (ret) {
        HAL_LOG(LOG_ERROR, "[OTA] Open default FW partition failed\r\n");
        hal_ota_update_status(VHAL_OTA_ST_FLASH_ERR, 0);
        return VHAL_FAIL;
    }
    ret = VHAL_OK;

    activeID = hal_boot2_get_active_partition();
    HAL_LOG(LOG_DEBUG, "[OTA] cur partition activeID is %u\r\n", activeID);

    if (hal_boot2_get_active_entries(BOOT2_PARTITION_TYPE_FW, &ptEntry)) {
        HAL_LOG(LOG_ERROR, "[OTA] hal_boot2_get_active_entries failed\r\n");
        hal_ota_update_status(VHAL_OTA_ST_FLASH_ERR, 0);
        ret = VHAL_FAIL;
        goto leave;
    }
    ota_part_addr = ptEntry.Address[!ptEntry.activeIndex];
    ota_part_size = ptEntry.maxLen[!ptEntry.activeIndex];

    HAL_LOG(LOG_DEBUG, "[OTA] OTA partition addr %08lX, size %lu B(%lu KiB)\r\n", 
                ota_part_addr, ota_part_size, ota_part_size / 1024);

    socket_fd = socket_create(url_info->host, url_info->port);
    if (socket_fd < 0) {
        HAL_LOG(LOG_ERROR, "socket create failed\n");
        hal_ota_update_status(VHAL_OTA_ST_HTTP_CONN_FAIL, 0);
        ret = VHAL_FAIL;
        goto leave;
    }

    download_len = ota_set_download_len(socket_fd, url_info);
    if(download_len < 0){
        HAL_LOG(LOG_ERROR, "set download_len error!\n");
        hal_ota_update_status(VHAL_OTA_ST_DL_FAIL, 0);
        ret = VHAL_FAIL;
        goto leave;
    }

    s_ota_info.total_len = download_len;
    s_ota_info.ota_offset = 0;

    HAL_LOG(LOG_DEBUG, "[OTA] Erase OTA partition...\r\n");
    bl_mtd_erase_all(handle);
    HAL_LOG(LOG_DEBUG, "Done\r\n");

    while (download_len > 0) {
        ret_len = ota_recv(socket_fd, recv_buf, EVERY_PACKET_LEN, 0, 12000);
        if (ret_len <= 0) 
        {
            HAL_LOG(LOG_ERROR, "recv file data error!\n");
            hal_ota_update_status(VHAL_OTA_ST_DL_FAIL, percent);
            ret = VHAL_FAIL;
            break;
        }

        // 由平台层计时，超时后设置该标志位
        if (s_ota_info.timeout_flag)
        {
            HAL_LOG(LOG_ERROR, "OTA timeout!!\n");
            hal_ota_update_status(VHAL_OTA_ST_TIME_OUT, percent);
            ret = VHAL_FAIL;
            break;
        }

        memcpy(s_ota_info.buffer + s_ota_info.ota_offset, recv_buf, ret_len);
        s_ota_info.ota_offset += ret_len;
        HAL_LOG(LOG_DEBUG, "ota_offset : %lu\r\n", s_ota_info.ota_offset);

        download_len -= ret_len;
        // 计算下载进度，百分比
        percent = ((s_ota_info.total_len - download_len) * 100) /s_ota_info.total_len;
        hal_ota_update_status(VHAL_OTA_ST_PROCESS, percent);   // 上报下载进度

        if(false == s_ota_info.header_checked){
            if(s_ota_info.ota_offset >= s_ota_cb.head_len + BL_OTA_HEADER_LEN)
            {
                //vesync header
                if (NULL != s_ota_cb.check_header_cb)
                {
                    if (VHAL_OK != s_ota_cb.check_header_cb((uint8_t *)s_ota_info.buffer, s_ota_cb.head_len))
                    {
                        HAL_LOG(LOG_DEBUG, "check header failed!\r\n");
                        hal_ota_update_status(VHAL_OTA_ST_FAIL, percent);
                        ret = VHAL_FAIL;
                        break;
                    }
                }
                for(i = 0; i < s_ota_info.ota_offset - s_ota_cb.head_len; i++){
                    s_ota_info.buffer[i] = s_ota_info.buffer[i+s_ota_cb.head_len];
                }
                s_ota_info.ota_offset -= s_ota_cb.head_len;

                //bouffalo header
                check_ota_header((ota_header_t*)s_ota_info.buffer, &ota_bin_size, &use_xz);
                memcpy(sha256_img, ((ota_header_t*)s_ota_info.buffer)->u.s.sha256, sizeof(sha256_img));
                for(i = 0; i < s_ota_info.ota_offset - BL_OTA_HEADER_LEN; i++){
                    s_ota_info.buffer[i] = s_ota_info.buffer[i+BL_OTA_HEADER_LEN];
                }
                s_ota_info.ota_offset -= BL_OTA_HEADER_LEN;

                s_ota_info.header_checked = true;
                s_ota_info.flash_offset = 0;
            }
        }
        else
        {
            utils_sha256_update(&sha_ctx, s_ota_info.buffer, s_ota_info.ota_offset);

            bl_mtd_write(handle, s_ota_info.flash_offset, s_ota_info.ota_offset, s_ota_info.buffer);
            s_ota_info.flash_offset += s_ota_info.ota_offset;
            HAL_LOG(LOG_DEBUG, "Write %lu[%d]\r\n", s_ota_info.flash_offset, s_ota_info.total_len);

            s_ota_info.ota_offset = 0;

            if ((s_ota_info.flash_offset + s_ota_cb.head_len + BL_OTA_HEADER_LEN) == s_ota_info.total_len) {
                percent = 100;
                hal_ota_update_status(VHAL_OTA_ST_DL_COMP, percent);   // 固件下载完成

                utils_sha256_finish(&sha_ctx, sha256_result);
                printf("\r\nCalculated SHA256 Checksum:");
                for (int i = 0; i < sizeof(sha256_result); i++) {
                    printf("%02X", sha256_result[i]);
                }
                printf("\r\nHeader SET SHA256 Checksum:");
                for (int i = 0; i < sizeof(sha256_img); i++) {
                    printf("%02X", sha256_img[i]);
                }
                printf("\r\n");

                if (memcmp(sha256_img, sha256_result, sizeof(sha256_img))) 
                {
                    HAL_LOG(LOG_ERROR, "[OTA] SHA256 NOT Correct\r\n");
                    hal_ota_update_status(VHAL_OTA_ST_FAIL, percent);
                    ret = VHAL_FAIL;
                    break;
                }

                HAL_LOG(LOG_DEBUG, "[OTA] prepare OTA partition info\r\n");
                ptEntry.len = s_ota_info.flash_offset;
                HAL_LOG(LOG_DEBUG, "[OTA] Update PARTITION, partition len is %lu\r\n", ptEntry.len);

                hal_boot2_update_ptable(&ptEntry);

                hal_ota_update_status(VHAL_OTA_ST_SUCCESS, percent);
            }
        }
    }

leave:
    bl_mtd_close(handle);
    utils_sha256_free(&sha_ctx);

    if (socket_fd >= 0)
    {
        close(socket_fd);
    }

    return ret;
}



/**
 * @brief 注册ota升级头部校验回调
 * @param[in]  cb               [ota头部校验回调函数]
 * @return     void
 */
void vhal_ota_check_header_reg_cb(vhal_ota_check_header_cb_t cb, int32_t head_len)
{
    s_ota_cb.check_header_cb = cb;
    s_ota_cb.head_len = head_len;
}

/**
 * @brief 注册ota升级md5校验回调
 * @param[in]  cb               [ota头部校验回调函数]
 * @return     void
 */
void vhal_ota_check_md5_reg_cb(vhal_ota_check_md5_cb_t cb)
{
    s_ota_cb.check_md5_cb = cb;
}


/**
 * @brief  注册ota升级状态数据回调
 * @param[in]  cb               [ota升级状态回调函数]
 * @return     void
 */
void vhal_ota_status_reg_cb(vhal_ota_status_cb_t cb)
{
    s_ota_cb.hal_stat_cb = cb;
}


/*
 * @brief  设置OTA超时标志位
 * @param[in]  flag             [true表示升级超时，false表示未超时]
 * @return     void
 */
void vhal_ota_set_timeout_flag(bool flag)
{
    s_ota_info.timeout_flag = flag;
}



/**
 * @brief  开始OTA升级
 * @param[in]  p_url            [固件下载URL]
 * @param[in]  dg_flag          [true表示进行降级；false表示进行升级]
 * @return     int              [成功返回0，其他值表示失败]
 */
int vhal_ota_start(char *p_url, bool dg_flag)
{
    int ret;
    URLParts_t urlParts;

    // ota状态判断，若为忙的状态，则直接返回
    if (VHAL_OTA_ST_IDLE != s_ota_info.stat)
    {
        HAL_LOG(LOG_WARN, "OTA is busy now, skip!!\n");
        hal_ota_update_status(VHAL_OTA_ST_PROCESS, s_ota_info.percent);
        return VHAL_OK;
    }

    HAL_LOG(LOG_INFO, "OTA is starting...\n");

    // URL解析
    memset(&urlParts, 0, sizeof(URLParts_t));
    if (NULL == p_url || VHAL_OK != vhal_http_parse_url(p_url, &urlParts))
    {
        HAL_LOG(LOG_ERROR, "http url parse error!\n");
        hal_ota_update_status(VHAL_OTA_ST_URL_ERR, 0);
        return VHAL_FAIL;
    }

    s_ota_info.buffer = pvPortMalloc(OTA_BUFFER_SIZE);
    if (NULL == s_ota_info.buffer)
    {
        HAL_LOG(LOG_ERROR, "malloc memory fail!!\r\n");
        hal_ota_update_status(VHAL_OTA_ST_OUT_MEM, 0);   // 内存不足
        return VHAL_FAIL;
    }

    ret = ota_get_data(&urlParts);
    if(ret != VHAL_OK){
        HAL_LOG(LOG_ERROR, "ota get data failed!\n");
    }

    HAL_LOG(LOG_INFO, "ota exit\n");
    if(s_ota_info.buffer != NULL)
    {
        vPortFree(s_ota_info.buffer);
        s_ota_info.buffer = NULL;
    }
    memset(&s_ota_info, 0, sizeof(ota_info_t));

    return ret;
}


/**
 * @brief  保存文件到flash
 * @param[in]  offset           [偏移地址]
 * @param[in]  p_data           [待保存的数据]
 * @param[in]  data_len         [待保存数据的长度]
 * @return     int              [成功返回0，其他值表示失败]
 * @note   用于存放非自身固件的其他大文件
 */
int vhal_ota_save_bin_file(int offset, char *p_data, int data_len)
{
    int ret;
    if (NULL == p_data)
    {
        return VHAL_FAIL;
    }

    if (NULL == handle_mcu)
    {
        ret = bl_mtd_open(BL_MTD_PARTITION_NAME_ROMFS, &handle_mcu, BL_MTD_OPEN_FLAG_BUSADDR);
        if (ret < 0) {
            HAL_LOG(LOG_ERROR, "error when get media partition %d\r\n", ret);
            return VHAL_FAIL;
        }
    }

    if (0 == offset)
    {
        HAL_LOG(LOG_INFO, "Erase entire partition!\n");
        bl_mtd_erase_all(handle_mcu);
    }

    bl_mtd_write(handle_mcu, offset, data_len, (uint8_t *)p_data);

    return VHAL_OK;
}


/**
 * @brief 从flash中读出文件
 * @param[in]  offset           [偏移地址]
 * @param[in]  p_data           [待保存的数据]
 * @param[in]  data_len         [待保存数据的长度]
 * @return     int              [成功返回0，其他值表示失败]
 * @note   用于存放非自身固件的其他大文件
 */
int vhal_ota_read_bin_file(int offset, char *p_data, int data_len)
{
    int ret;
    if (NULL == p_data)
    {
        return VHAL_FAIL;
    }

    if (NULL == handle_mcu)
    {
        ret = bl_mtd_open(BL_MTD_PARTITION_NAME_ROMFS, &handle_mcu, BL_MTD_OPEN_FLAG_BUSADDR);
        if (ret < 0) {
            HAL_LOG(LOG_ERROR, "error when get media partition %d\r\n", ret);
            return VHAL_FAIL;
        }
    }

    bl_mtd_read(handle_mcu, offset, data_len, (uint8_t *)p_data);

    return VHAL_OK;
}
