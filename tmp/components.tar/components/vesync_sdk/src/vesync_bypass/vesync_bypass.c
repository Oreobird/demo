/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_bypass.c
 * @brief       bypass处理接口
 * @date        2021-05-13
 */

#include <string.h>
#include <stdio.h>

#include "vesync_cfg.h"
#include "vesync_common.h"
#include "vesync_memory.h"

#include "vesync_report.h"
#include "vesync_device_internal.h"
#include "vesync_bypass_internal.h"
#include "vesync_log_internal.h"
#include "vesync_json_internal.h"

static bypass_mgt_t s_bypass_mgt;
static bypass_get_uart_mq_freesize_cb_t s_bypass_get_uart_mq_freesize_cb;


/*-----------------------------------------------------------------------------*
*-----------------------------------内部函数API实现-------------------------------*
*-----------------------------------------------------------------------------*/

/**
 * @brief 通过method_id获取节点
 * @param method_id                   [方法ID]
 * @return bypass_item_t *            [对应的节点指针]
 */
static bypass_item_t *vesync_bypass_get_item_by_id(BYPASS_METHOD_ID_E  method_id)
{
    bypass_item_t *pos, *n;
    struct list_head *head;

    head = &s_bypass_mgt.list;

    list_for_each_entry_safe(pos, n, head, list)
    {
        if (pos->data.method_id == method_id)
        {
            return pos;
        }
    }

    return NULL;
}

/**
* @brief 初始化节点
* @param bypass_item_data_t          [节点数据]
* @return bypass_item_t *            [节点指针]
*/
bypass_item_t *vesync_bypass_init_item(bypass_item_data_t *data)
{
    bypass_item_t *item = vesync_bypass_get_item_by_id(data->method_id);
    if (item != NULL)
    {
        SDK_LOG(LOG_INFO, "bypass item already exist\n");
        return NULL;
    }

    item = (bypass_item_t *)vesync_malloc(sizeof(bypass_item_t));
    if (item == NULL)
    {
        SDK_LOG(LOG_ERROR, "bypass init item failed\n");
        return NULL;
    }

    memset(item, 0, sizeof(bypass_item_t));
    memcpy(&item->data, data, sizeof(bypass_item_data_t));

    INIT_LIST_HEAD(&item->list);

    return item;
}


/**
 * @brief 添加节点
 * @param bypass_item_t                [节点]
 * @return                             [SDK_OK/SDK_FAIL]
 */
int vesync_bypass_add_item(bypass_item_t *item)
{
    VCOM_NULL_PARAM_CHK(item, return SDK_FAIL);

    bypass_item_t *pos = vesync_bypass_get_item_by_id(item->data.method_id);
    if (pos != NULL)
    {
        SDK_LOG(LOG_ERROR, "bypass item add failed\n");
        return SDK_FAIL;
    }

    list_add(&item->list, &s_bypass_mgt.list);
    s_bypass_mgt.num++;
    return SDK_OK;
}

/**
* @brief 校验release固件的bypass指令来源是否是授权的
* @param[in]  mask                     [消息支持的来源]
* @param[in]  msg_src                  [消息实际来源]
* @return     bool                     [消息来源是授权的返回true，非授权的返回false]
*/
static bool vesync_bypass_check_auth_msg(uint32_t auth_mask, uint32_t msg_tag)
{
    bool ret = true;

    // release固件才对消息进行过滤，debug固件则不限制
#if defined(PR_FW_TYPE) && (PR_FW_TYPE == 1)
    SDK_LOG(LOG_DEBUG, "auth_mask = 0x%x, msg_tag = 0x%x.\n", auth_mask, msg_tag);
    if ((auth_mask & msg_tag) != msg_tag)
    {
        ret = false;
    }
#endif

    return ret;
}

/*-----------------------------------------------------------------------------*
*-----------------------------------SDK层函数API实现-------------------------------*
*-----------------------------------------------------------------------------*/


/**
 * @brief 通过method id 找到method 的回调函数
 * @param                                [method_id]
 * @return bypass_method_cb_t            [method 回调函数]
 */
bypass_method_cb_t vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_E  method_id)
{
    bypass_item_t *pos, *n;
    struct list_head *head;

    head = &s_bypass_mgt.list;

    list_for_each_entry_safe(pos, n, head, list)
    {
        if (pos->data.method_id == method_id)
        {
            return pos->data.app_cb;
        }
    }

    return NULL;
}


/*-----------------------------------------------------------------------------*
*-----------------------------------外部函数API实现-------------------------------*
*-----------------------------------------------------------------------------*/
/**
* @brief bypass消息处理入口
* @param[in]  pMsg             [数据指针]
* @param[in]  msg_tag          [消息来源标签]
* @return     none
*/
void vesync_bypass_msg_handle(char *pMsg, uint32_t msg_tag)
{
    bool check_flag = false;
    BYPASS_ERR_E bypass_ret = BP_OK;
    bypass_trace_msg_t trace_msg;

    cJSON *root = NULL;
    cJSON *json_trceid = NULL;
    cJSON *json_cid = NULL;
    cJSON *json_method = NULL;
    cJSON *json_payload = NULL;
    cJSON *json_data = NULL;

    SDK_LOG(LOG_DEBUG, "===receive data=== \r\n");
    root = cJSON_Parse(pMsg);
    if (NULL == root)
    {
        return;
    }

    //vesync_json_print(root); //json标准格式，带缩进

    memset(&trace_msg, 0, sizeof(bypass_trace_msg_t));

    json_trceid = cJSON_GetObjectItemCaseSensitive(root, "traceId");    //解析trace id
    if (cJSON_IsString(json_trceid))
    {
        strncpy(trace_msg.trace_id, json_trceid->valuestring, sizeof(trace_msg.trace_id) - 1);
    }
    else
    {
        //处理参数错误
        SDK_LOG(LOG_WARN, "miss traceID\r\n");
        bypass_ret = BP_ERR_ARG;
        strncpy(trace_msg.trace_id, "xxxx", sizeof(trace_msg.trace_id) - 1);
        goto _exit;
    }

    json_cid = cJSON_GetObjectItemCaseSensitive(root, "cid");
    if (cJSON_IsString(json_cid))
    {
        SDK_LOG(LOG_DEBUG, "cid:%s \r\n", json_cid->valuestring);
    }

    json_method = cJSON_GetObjectItemCaseSensitive(root, "method");
    if (!cJSON_IsString(json_method))
    {
        SDK_LOG(LOG_ERROR, "miss method\r\n");
        bypass_ret = BP_ERR_ARG;
        goto _exit;
    }

    if (strcmp(json_method->valuestring, "bypassV2") != 0)
    {
        SDK_LOG(LOG_ERROR, "bypass method error\r\n");
        bypass_ret = BP_ERR_ARG;
        goto _exit;
    }

    // 解析payload
    json_payload = cJSON_GetObjectItemCaseSensitive(root, "payload");
    if (!cJSON_IsObject(json_payload))
    {
        SDK_LOG(LOG_ERROR, "paylaod err\r\n");
        bypass_ret = BP_ERR_ARG;
        goto _exit;
    }

    cJSON *json_src = cJSON_GetObjectItemCaseSensitive(json_payload, "source");
    if (cJSON_IsString(json_src))
    {
        strncpy(trace_msg.src_type, json_src->valuestring, sizeof(trace_msg.src_type) - 1);
    }
    else
    {
        strncpy(trace_msg.src_type, STAT_CHG_RSN_BP_APP_STR, sizeof(trace_msg.src_type) - 1);     //无source字段则默认来源为"APP"
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json_payload, "method");
    if (!cJSON_IsString(json_data))
    {
        SDK_LOG(LOG_ERROR, "bypass payload method error\r\n");
        bypass_ret = BP_ERR_ARG;
        goto _exit;
    }

    SDK_LOG(LOG_DEBUG,"method : %s\r\n", json_data->valuestring);
    check_flag = false;

    bypass_item_t *pos, *n;
    struct list_head *head = &s_bypass_mgt.list;

    list_for_each_entry_safe(pos, n, head, list)
    {
        if (strcmp(json_data->valuestring, pos->data.method) == 0)
        {
            // 消息授权校验
            if (false == vesync_bypass_check_auth_msg(pos->data.auth_mask, msg_tag))
            {
                bypass_ret = BP_ERR_UN_AUTH;
                goto _exit;
            }

            check_flag = true;

            if (pos->data.method_handle)
            {
                cJSON *json_sub = cJSON_GetObjectItemCaseSensitive(json_payload, "data");
                if (cJSON_IsObject(json_sub))
                {
                    bypass_ret = pos->data.method_handle(&trace_msg, json_sub);
                    break;
                }
                else if (NULL == json_sub)      //getTimer 特殊处理
                {
                    bypass_ret = pos->data.method_handle(&trace_msg, NULL);
                    break;
                }
            }
        }
    }

    // payload method未找到
    if (!check_flag)
    {
        SDK_LOG(LOG_ERROR, "bypass payload method error\r\n");
        bypass_ret = BP_ERR_ARG;
        goto _exit;
    }


_exit:
    if (BP_ERR_ARG == bypass_ret)    // 参数不合法
    {
        SDK_LOG(LOG_ERROR, "bypass arg error\r\n");
        vesync_bypass_reply_noqos(BP_ERR_PARA_ILLEGAL, &trace_msg, NULL);
    }
    else if (BP_ERR_APP_CB_NULL == bypass_ret)     // 应用层回调函数未注册
    {
        SDK_LOG(LOG_ERROR, "bypass app cb null\r\n");
        vesync_bypass_reply_noqos(BP_METHOD_NOT_SUPPORT, &trace_msg, NULL);
    }
    else if (BP_ERR_NOMEM == bypass_ret)          // 内存不足
    {
        SDK_LOG(LOG_ERROR, "bypass not enough memory\n");
        vesync_bypass_reply_noqos(BP_OUT_OF_MEMOTY, &trace_msg, NULL);
    }
    else if (BP_ERR_UN_AUTH == bypass_ret)          // 指令未授权
    {
        SDK_LOG(LOG_ERROR, "CMD is not authorized!!!\n");
        vesync_bypass_reply_noqos(BP_ERR_CMD_EXECUTE_FAIL, &trace_msg, NULL);
    }
    else if (BP_ERROR == bypass_ret)
    {
        SDK_LOG(LOG_ERROR, "bypass normal error\r\n");
    }

    cJSON_Delete(root);
}



/**
 * @brief bypass 模块初始化
 */
void veysnc_bypass_init(void)
{
    memset(&s_bypass_mgt, 0, sizeof(bypass_mgt_t));
    INIT_LIST_HEAD(&s_bypass_mgt.list);

#if CONFIG_VESYNC_BYPASS_SWITCH_SUPPORT
    vesync_bypass_switch_init();
#endif

#if CONFIG_VESYNC_BYPASS_INDICATOR_SUPPORT
    vesync_bypass_indicator_init();
#endif

#if CONFIG_VESYNC_BYPASS_TIMER_SUPPORT
    vesync_bypass_timer_init();
#endif

#if CONFIG_VESYNC_BYPASS_SCHEDULE_SUPPORT
    vesync_bypass_schedule_init();
#endif

#if CONFIG_VESYNC_BYPASS_AWAY_SUPPORT
    vesync_bypass_away_init();
#endif

#if CONFIG_VESYNC_BYPASS_TARGET_TEMP_SUPPORT
    vesync_bypass_target_temp_init();
#endif

#if CONFIG_VESYNC_BYPASS_TEMP_UNIT_SUPPORT
    vesync_bypass_temp_unit_init();
#endif

#if CONFIG_VESYNC_BYPASS_LIGHT_SUPPORT
    vesync_bypass_light_init();
#endif

#if CONFIG_VESYNC_BYPASS_COOKING_SUPPORT
    vesync_bypass_cooking_init();
#endif

#if CONFIG_VESYNC_BYPASS_LIGHT_SWITCH_SUPPORT
    vesync_bypass_light_switch_init();
#endif

#if CONFIG_VESYNC_BYPASS_LEVEL_SUPPORT
    vesync_bypass_level_init();
#endif

#if CONFIG_VESYNC_BYPASS_RANGE_SUPPORT
    vesync_bypass_range_init();
#endif

#if CONFIG_VESYNC_BYPASS_SET_TEMP_UNIT_SUPPORT
    vesync_bypass_set_temp_unit_init();
#endif

#if CONFIG_VESYNC_BYPASS_SET_DISPLAY_SUPPORT
    vesync_bypass_set_display_init();
#endif

#if CONFIG_VESYNC_BYPASS_HUMIDITY_SUPPORT
    vesync_bypass_humidity_init();
#endif

#if CONFIG_VESYNC_BYPASS_PURIFIER_SUPPORT
    vesync_bypass_purifier_init();
#endif

#if CONFIG_VESYNC_BYPASS_CHILDLOCK_SUPPORT
    vesync_bypass_childlock_init();
#endif

#if CONFIG_VESYNC_BYPASS_RELAY_SUPPORT
    vesync_bypass_relay_init();
#endif

#if CONFIG_VESYNC_BYPASS_NIGHTLIGHT_SUPPORT
    vesync_bypass_nightlight_init();
#endif

#if CONFIG_VESYNC_BYPASS_NIGHTLIGHT_BRIGHTNESS_SUPPORT
    vesync_bypass_nightlight_brightness_init();
#endif

#if CONFIG_VESYNC_BYPASS_NOTIFY_DEVICE_SUPPORT
    vesync_bypass_notify_device_init();
#endif

#if CONFIG_VESYNC_BYPASS_PLASMA_SUPPORT
    vesync_bypass_plasma_init();
#endif

#if CONFIG_VESYNC_BYPASS_SET_DEVICE_TRIGGER_SUPPORT
    vesync_bypass_set_device_trigger_init();
#endif

#if CONFIG_VESYNC_BYPASS_UPGRADE_SUPPORT
    vesync_bypass_upgrade_init();
#endif

#if CONFIG_VESYNC_BYPASS_DEVICE_SUPPORT
    vesync_bypass_device_init();
#endif

}


/**
 * @brief 应用层注册bypass method 回调函数
 * @param method_id method                   [对应的id]
 * @param cb bypass method                   [回调函数]
 * @return                                   [0 注册成功  -1 注册失败]
 */
int vesync_bypass_reg_mothod_cb(BYPASS_METHOD_ID_E method_id, bypass_method_cb_t cb)
{
    bypass_item_t *pos, *n;
    struct list_head *head;

    head = &s_bypass_mgt.list;
    list_for_each_entry_safe(pos, n, head, list)
    {
        if (pos->data.method_id == method_id)
        {
            pos->data.app_cb = cb;
            return SDK_OK;
        }
    }

    return SDK_FAIL;
}


/**
 * @brief bypass 消息应答函数
 * @param[in] code                               [错误码]
 * @param[in] p_trace_msg                        [trace message app 发送过来原样返回]
 * @param[out] json                              [返回数据json指针， 如果没返回数据返回空指针]
 * @return bypass_err_t
 */
BYPASS_ERR_E vesync_bypass_reply_noqos(int code, const bypass_trace_msg_t *p_trace_msg, cJSON *json)
{
    VCOM_NULL_PARAM_CHK(p_trace_msg, return BP_ERR_ARG);

    BYPASS_ERR_E ret = BP_OK;
    cJSON *root = cJSON_CreateObject();
    if (NULL == root)
    {
        if (json)
        {
            cJSON_Delete(json);
        }
        return BP_ERR_NOMEM;
    }

    cJSON_AddStringToObject(root, "traceId", p_trace_msg->trace_id);
    cJSON_AddNumberToObject(root, "code", code);

    if (NULL != json)
    {
        cJSON_AddItemToObject(root, "result", json);
    }

    char* out_buf = cJSON_PrintUnformatted(root);
    if (out_buf)
    {
        int tx_ret = -1;
#if CONFIG_BYPASS_METHOD_LAN_COMM_SUPPORT
        if (0 == strcmp(p_trace_msg->src_type, STAT_CHG_RSN_BP_LAN_STR))
        {
            tx_ret = vesync_lan_comm_tcp_data_send((uint8_t*)(out_buf), strlen(out_buf), LAN_COMM_OP_TCP_COMMUNICATE, LAN_COMM_ENCRYPT, code == 0? 0 : 1);  //正常执行status为0，否则为1
        }
        else
#endif

#if CONFIG_VESYNC_SDK_MQTT_ENABLE
        {
            tx_ret = vesync_mqtt_publish(MQTT_TOPIC_RESP, out_buf, strlen(out_buf), MQTT_QOS0, NULL);
        }
#endif
        if (tx_ret < 0)
        {
            ret = BP_ERROR;
        }
        free(out_buf);
    }

    vesync_json_print(root);
    cJSON_Delete(root);
    return ret;

}


/**
 * @brief bypass异常处理，回复信息封装
 * @param[in] err_code                       [错误码]
 * @param[in] p_trace_msg                    [trace message]
 * @param[in] p_msg                          [错误消息(字符串)，支持NULL]
 */
void vesync_bypass_reply_pkg_err_msg(int err_code, bypass_trace_msg_t *p_trace_msg, char *p_msg)
{
    cJSON *json_data = NULL;

    if (NULL != p_msg)
    {
        SDK_LOG(LOG_ERROR, "code = %d, %s\n", err_code, p_msg);

        json_data = cJSON_CreateObject();
        if (NULL != json_data)
        {
            cJSON_AddStringToObject(json_data, "msg", p_msg);
        }
    }

    vesync_bypass_reply_noqos(err_code, p_trace_msg, json_data);
}


/**
 * @brief 应用层注册查询串口队列剩余空间 回调函数
 * @param cb                                 [串口队列剩余空间 回调函数]
 * @return void
 */
void vesync_bypass_reg_get_uart_mq_freesize_cb(bypass_get_uart_mq_freesize_cb_t cb)
{
    s_bypass_get_uart_mq_freesize_cb = cb;
}


/**
 * @brief bypass 消息应答函数, 带MQTT消息等级
 * @param[in] code                           [错误码]
 * @param[in] p_trace_msg                    [trace message app发送过来原样返回]
 * @param[in] json                           [返回数据json指针， 如果没返回数据返回空指针]
 * @param[in] qos                            [MQTT消息等级]
 * @param[in] puback_cb                      [收到qos1确认包后的回调函数]
 * @return bypass_err_t
 */
int vesync_bypass_reply_qos(int code, const bypass_trace_msg_t *p_trace_msg, cJSON *json, REPORT_QOS_E qos, void* puback_cb)
{
    int ret = -1;

    VCOM_NULL_PARAM_CHK(p_trace_msg, return SDK_FAIL);

    cJSON *root = cJSON_CreateObject();
    if (NULL == root)
    {
        if(json)
        {
            cJSON_Delete(json);
        }
        return BP_ERR_NOMEM;
    }

    cJSON_AddStringToObject(root, "traceId", p_trace_msg->trace_id);
    cJSON_AddNumberToObject(root, "code", code);

    if (NULL != json)
    {
        cJSON_AddItemToObject(root, "result", json);
    }

    char* out_buf = cJSON_PrintUnformatted(root);
    if (out_buf)
    {
        int tx_ret = -1;
#if CONFIG_VESYNC_PLAT_MQTT_ENABLE
        tx_ret = vesync_mqtt_publish(MQTT_TOPIC_RESP, out_buf, strlen(out_buf), vesync_get_mqtt_qos_from_report(qos), puback_cb);
#endif
        ret = tx_ret;
        free(out_buf);
    }

    vesync_json_print(root);
    cJSON_Delete(root);
    return ret;
}


