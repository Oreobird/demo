/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file    vesync_ble_private.h
 * @brief   ble私有头文件
 * @author      Louis
 * @date    2021-11-19
 */


#ifndef __VESYNC_BLE_PRIVATE_H__
#define __VESYNC_BLE_PRIVATE_H__


#include "vesync_ble_internal.h"


#ifdef __cplusplus
extern "C"
{
#endif /* __cplusplus */


#define VESYNC_BLE_TASK_NAME            "vesync_ble_task"
#define VESYNC_BLE_TASK_STACSIZE        (1024*4)
#define VESYNC_BLE_TASK_PRIO            TASK_PRIORITY_NORMAL

#define VESYNC_BLE_SEND_ACK_QUEUE_MAX_NUM           (10)
#define VESYNC_BLE_SEND_REQ_QUEUE_MAX_NUM           (20)
#define VESYNC_BLE_SEND_DATA_QUEUE_MAX_NUM          (10)
#define VESYNC_BLE_RECV_QUEUE_MAX_NUM               (10)

#define VESYNC_PROTOCO_VERSION          (2)
#define VESYNC_PROTOCO_HEAD_LEN         (6)

#define VESYNC_FRAME_HEADER_LEN         (32)    // should >= sizeof(tl_frame_recv_info_t)
#define VESYNC_FRAME_PAYLOAD_MAX_LEN    (1500)

#define VESYNC_BLE_SEND_REPEAT_MAX_CNT  (3)
#define VESYNC_SEND_REQUEST_TIMEOUT     (2000)  // MS


#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* __VESYNC_BLE_PRIVATE_H__ */
