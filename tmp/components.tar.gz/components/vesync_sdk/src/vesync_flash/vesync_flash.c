/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_flash.c
 * @brief       flash接口
 * @author      Joshua
 * @date        2021-05-17
 */
#include "stdio.h"
#include "mbedtls/md.h"
#include "mbedtls/md5.h"

#include "vesync_common.h"
#include "vesync_memory.h"
#include "vesync_flash_internal.h"
#include "vesync_base64.h"
#include "vesync_aes.h"
#include "vesync_cfg_internal.h"
#include "vesync_log_internal.h"
#include "vesync_ca_cert.h"

static uint8_t s_flash_aes_key[AES_KEY_LEN];
static uint8_t s_flash_aes_iv[AES_KEY_LEN];


/**
 * @brief  flash 密钥初始化
 * @return     int32_t              [错误码]
 */
static int32_t flash_security_init(void)
{
    char *brand = (char *)brand_aes_key;
    mbedtls_md5_context *p_md5 = NULL;

    p_md5 = (mbedtls_md5_context*)vesync_malloc(sizeof(mbedtls_md5_context) +1);
    if (NULL == p_md5)
    {
        return SDK_FAIL;
    }
    memset(s_flash_aes_key, 0, AES_KEY_LEN);
    memset(p_md5, 0, sizeof(mbedtls_md5_context) + 1 );
    mbedtls_md5_init(p_md5);
#if !defined(MBEDTLS_DEPRECATED_REMOVED)
    mbedtls_md5_starts(p_md5);
#else
    mbedtls_md5_starts_ret(p_md5);
#endif
    mbedtls_md5_update(p_md5, (unsigned char *)brand, strlen((char *)brand) + 1);
    mbedtls_md5_finish(p_md5, s_flash_aes_key);
    mbedtls_md5_free(p_md5);
#if 0
    LOG_RAW_HEX(LOG_INFO, "Security AES Key:", s_flash_aes_key, AES_KEY_LEN);
#endif
    VCOM_SAFE_FREE(p_md5);

    memcpy(s_flash_aes_iv, s_flash_aes_key, AES_KEY_LEN);
    return SDK_OK;
}

/**
 * @brief  flash初始化
 * @param[in]  part_id              [分区ID]
 * @return     int32_t              [错误码]
 */
int32_t vesync_flash_init(void)
{
    vhal_flash_init(PARTITION_DEFAULT);
    vhal_flash_init(PARTITION_CFG);
    vhal_flash_init(PARTITION_FAC);
    vhal_flash_init(PARTITION_LOG);
    vhal_flash_init(PARTITION_DATA);
    flash_security_init();
    return SDK_OK;
}

/**
 * @brief  从flash读取数据
 * @param[in]  part_id              [分区ID]
 * @param[in]  key_name             [键值名称]
 * @param[in]  p_data               [读取数据缓存区；如果该读取Buffer为NULL，则返回该数据的长度]
 * @param[in]  p_len                [当前读取的数据长度]
 * @return  int32_t                 [成功：SDK_OK，失败：SDK_FAIL]
 */
int32_t vesync_flash_read(PARTITION_ID_E part_id, const char *key_name, uint8_t *p_data, uint32_t *p_len)
{
    VCOM_NULL_PARAM_CHK(key_name, return SDK_FAIL);
    VCOM_NULL_PARAM_CHK(p_len, return SDK_FAIL);

    int32_t ret = vhal_flash_read(part_id, key_name, p_data, p_len);
    return ret == VHAL_OK ? SDK_OK : SDK_FAIL;
}

/**
 * @brief  往flash写入数据
 * @param[in]  part_id              [分区ID]
 * @param[in]  key_name             [键值名称]
 * @param[in]  p_data               [写入的数据]
 * @param[in]  len                  [写入数据的长度]
 * @return     int32_t              [0表示写入成功，非0表示写入失败]
 */
int32_t vesync_flash_write(PARTITION_ID_E part_id, const char *key_name, uint8_t *p_data, uint32_t len)
{
    VCOM_NULL_PARAM_CHK(key_name, return SDK_FAIL);
    VCOM_NULL_PARAM_CHK(p_data, return SDK_FAIL);

    int32_t ret = vhal_flash_write(part_id, key_name, p_data, len);
    return ret == VHAL_OK ? SDK_OK : SDK_FAIL;
}

int vesync_flash_brand_aes_decrypt(const uint8_t *p_in, int len, uint8_t **p_out)
{
    return vesync_aes_decrypt_with_key(PKCS7_PADDING,
                                       (uint8_t *)p_in, len,
                                       p_out,
                                       s_flash_aes_key, s_flash_aes_iv);
}

/**
 * @brief  从flash读取加密数据
 * @param[in]  part_id              [分区ID]
 * @param[in]  key_name             [键值名称]
 * @param[in]  p_data               [读取数据缓存区]
 * @param[in/out]  p_len            [当前读取的数据长度]
 * @return     int32_t              [0表示读取成功，非0表示读取失败]
 */
int32_t vesync_flash_aes_crypto_read(PARTITION_ID_E part_id, const char *key_name, uint8_t *p_data, uint32_t *p_len)
{
    uint8_t *p_encrypt = NULL;
    uint8_t *p_out = NULL;
    size_t encrypt_len = *p_len + AES_KEY_LEN - (*p_len % AES_KEY_LEN);
    int ret = VHAL_FAIL;

    p_encrypt = vesync_malloc(encrypt_len);
    if (NULL == p_encrypt)
    {
        return SDK_FAIL;
    }

    ret = vhal_flash_read(part_id, key_name, p_encrypt, (uint32_t*)(&encrypt_len));
    if (ret != VHAL_OK || 0 == encrypt_len)
    {
        VCOM_SAFE_FREE(p_encrypt);
        return SDK_FAIL;
    }

    ret = vesync_flash_brand_aes_decrypt(p_encrypt, encrypt_len, &p_out);
    if (0 == ret || NULL == p_out)
    {
        VCOM_SAFE_FREE(p_encrypt);
        //VCOM_SAFE_FREE(p_out);
        return SDK_FAIL;
    }

    *p_len = ret < *p_len ? ret : *p_len;
    memcpy(p_data, p_out, *p_len);

    VCOM_SAFE_FREE(p_encrypt);
    VCOM_SAFE_FREE(p_out);
    return SDK_OK;
}

/**
 * @brief  往flash加密写入数据
 * @param[in]  part_id              [分区ID]
 * @param[in]  key_name             [键值名称]
 * @param[in]  p_data               [写入的数据]
 * @param[in]  len                  [写入数据的长度]
 * @return     int32_t              [0表示写入成功，非0表示写入失败]
 */
int32_t vesync_flash_aes_crypto_write(PARTITION_ID_E part_id, const char *key_name, uint8_t *p_data, uint32_t len)
{
    uint8_t * p_encrypt = NULL;
    int ret = VHAL_FAIL;

    int encrypt_len = vesync_aes_encrypt_with_key(PKCS7_PADDING, p_data, len, &p_encrypt, s_flash_aes_key, s_flash_aes_iv);
    if (0 == encrypt_len)
    {
        VCOM_SAFE_FREE(p_encrypt);
        return SDK_FAIL;
    }

    ret = vhal_flash_write(part_id, key_name, p_encrypt, encrypt_len);
    if (ret != VHAL_OK)
    {
        VCOM_SAFE_FREE(p_encrypt);
        return SDK_FAIL;
    }

    VCOM_SAFE_FREE(p_encrypt);
    return SDK_OK;
}

/**
 * @brief  从flash读取加密数据
 * @param[in]  part_id              [分区ID]
 * @param[in]  key_name             [键值名称]
 * @param[in]  p_data               [读取数据缓存区]
 * @param[in/out]  p_len            [当前读取的数据长度]
 * @return     int32_t              [0表示读取成功，非0表示读取失败]
 */
int32_t vesync_flash_crypto_read(PARTITION_ID_E part_id, const char *key_name, uint8_t *p_data, uint32_t *p_len)
{
    unsigned char *base64_buf = NULL;
    size_t olen = 0;
    size_t buf_len = ((*p_len + 2) / 3) * 4 + 1; //ceil(len/3)*4;
    base64_buf = vesync_malloc(buf_len);
    if (base64_buf == NULL)
    {
        return SDK_FAIL;
    }

    memset(base64_buf, 0, buf_len);
    int ret = vhal_flash_read(part_id, key_name, base64_buf, (uint32_t*)(&buf_len));
    if (ret != VHAL_OK)
    {
        vesync_free(base64_buf);
        return SDK_FAIL;
    }

    ret = vesync_base64_decode(p_data, *p_len, &olen, base64_buf, buf_len);
    if (ret != SDK_OK)
    {
        vesync_free(base64_buf);
        return SDK_FAIL;
    }

    *p_len = olen;

    vesync_free(base64_buf);
    return SDK_OK;
}

/**
 * @brief  往flash加密写入数据
 * @param[in]  part_id              [分区ID]
 * @param[in]  key_name             [键值名称]
 * @param[in]  p_data               [写入的数据]
 * @param[in]  len                  [写入数据的长度]
 * @return     int32_t              [0表示写入成功，非0表示写入失败]
 */
int32_t vesync_flash_crypto_write(PARTITION_ID_E part_id, const char *key_name, uint8_t *p_data, uint32_t len)
{
    unsigned char *base64_buf = NULL;
    size_t olen = 0;

    size_t buf_len = ((len + 2) / 3) * 4 + 1; //ceil(len/3)*4 + 1;
    base64_buf = vesync_malloc(sizeof(unsigned char)*buf_len);
    if (base64_buf == NULL)
    {
        return SDK_FAIL;
    }

    memset(base64_buf, 0, buf_len);

    int ret = vesync_base64_encode(base64_buf, buf_len, &olen, p_data, len);
    if (ret != SDK_OK)
    {
        vesync_free(base64_buf);
        return SDK_FAIL;
    }

    ret = vhal_flash_write(part_id, key_name, base64_buf, olen);
    if (ret != VHAL_OK)
    {
        vesync_free(base64_buf);
        return SDK_FAIL;
    }

    vesync_free(base64_buf);
    return SDK_OK;
}


/**
 * @brief  擦除指定分区
 * @param[in]  part_id              [分区ID]
 * @return     int32_t              [0表示擦除成功，非0表示擦除失败]
 */
int32_t vesync_flash_erase(PARTITION_ID_E part_id)
{
    int32_t ret = vhal_flash_erase(part_id);
    return ret == VHAL_OK ? SDK_OK : SDK_FAIL;
}

/**
 * @brief  擦除指定分区中的指定键值对
 * @param[in]  part_id              [分区ID]
 * @param[in]  key_name             [键值名称]
 * @return     int32_t              [0表示擦除成功，非0表示擦除失败]
 */
int32_t vesync_flash_erase_key(PARTITION_ID_E part_id, const char *key_name)
{
    VCOM_NULL_PARAM_CHK(key_name, return SDK_FAIL);

    int32_t ret = vhal_flash_erase_key(part_id, key_name);
    return ret == VHAL_OK ? SDK_OK : SDK_FAIL;
}

