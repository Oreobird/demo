/**
 * Copyright © Vesync Technologies Co.Ltd. 2019-2021. All rights reserved.
 * @file    hal_ota_http.c
 * @brief   esp32的ota功能依赖的HTTP接口封装
 * @author  Herve.Lin
 * @date    2021-09-09
 */
#ifndef CONFIG_IDF_TARGET_ESP8266
#include "mbedtls/md5.h"
#include "vesync_log.h"
#include "vesync_common.h"
#include "vhal_ota_internal.h"
#ifdef CONFIG_VESYNC_HAL_OTA_ESP_MINI_HTTP_ENABLE
#include "lwip/netdb.h"
#endif /* CONFIG_VESYNC_HAL_OTA_ESP_MINI_HTTP_ENABLE */

#ifdef CONFIG_VESYNC_HAL_OTA_ESP_MINI_HTTP_ENABLE
/**
 * @brief TCP连接
 * @param[out] sockfd       [返回创建成功的TCP Socket]
 * @param[in]  p_http_cfg   [HTTP的配置]
 * @return int              [VHAL_OK/VHAL_FAIL]
 */
static int tcp_connect(int *sockfd, http_client_config_t *p_http_cfg)
{
    int ret;
    char http_port_string[8];
    const struct addrinfo hints =
        {
            .ai_family = AF_INET,
            .ai_socktype = SOCK_STREAM,
        };
    struct addrinfo *res = NULL;
    struct in_addr *addr = NULL;

    snprintf(http_port_string, sizeof(http_port_string), "%d", p_http_cfg->port);
    ret = getaddrinfo(p_http_cfg->host, http_port_string, &hints, &res);
    if (ret != 0 || res == NULL)
    {
        return VHAL_FAIL;
    }
    addr = &((struct sockaddr_in *)res->ai_addr)->sin_addr;
    HAL_LOG(LOG_DEBUG, "DNS lookup succeeded. IP=%s\n", inet_ntoa(*addr));

    *sockfd = socket(res->ai_family, res->ai_socktype, 0);
    if (*sockfd < 0)
    {
        freeaddrinfo(res);
        return VHAL_FAIL;
    }

    if (connect(*sockfd, res->ai_addr, res->ai_addrlen) != 0)
    {
        freeaddrinfo(res);
        close(*sockfd);
        return VHAL_FAIL;
    }

    struct timeval tx_rx_timeout;
    // Set sending & receiveing timeout
    tx_rx_timeout.tv_sec = HTTP_TCP_RX_TX_TIMEOUT_SEC;
    tx_rx_timeout.tv_usec = HTTP_TCP_TX_RX_TIMEOUT_USEC;
    if ((setsockopt(*sockfd, SOL_SOCKET, SO_SNDTIMEO, &tx_rx_timeout, sizeof(tx_rx_timeout)) < 0) ||
        (setsockopt(*sockfd, SOL_SOCKET, SO_RCVTIMEO, &tx_rx_timeout, sizeof(tx_rx_timeout)) < 0))
    {
        freeaddrinfo(res);
        close(*sockfd);
        return VHAL_FAIL;
    }

    HAL_LOG(LOG_INFO, "http connected\n");
    freeaddrinfo(res);
    return VHAL_OK;
}

/**
 * @brief 发送HTTP Get请求
 * @param[in] client    [指向HTTP客户端]
 * @return int          [VHAL_OK/VHAL_FAIL]
 */
static int send_get_request(http_client_handle_t client)
{
    const char *get_format_tmpl = "GET %s HTTP/1.1\r\n"
                                  "Host: %s:%d\r\n"
                                  "User-Agent: esp-idf/1.0 esp32\r\n"
                                  "Content-Length: 0\r\n"
                                  "\r\n";

    void *send_buffer = malloc(HTTP_SEND_BUF_SIZE);
    if (NULL == send_buffer)
    {
        return VHAL_FAIL;
    }
    snprintf(send_buffer, HTTP_SEND_BUF_SIZE, get_format_tmpl, client->cfg->path, client->cfg->host, client->cfg->port);
    if (0 > send(client->socket, send_buffer, strlen(send_buffer), 0))
    {
        return VHAL_FAIL;
    }
#if 0
    HAL_LOG(LOG_DEBUG, "http header row: \nSTART\n%s\nEOF\n", send_buffer);
#endif
    free(send_buffer);
    return VHAL_OK;
}

/**
 * @brief 从http的URL中提取host和port
 * @param[in] p_http_cfg    [HTTP的配置]
 * @param[in] url           [入参，完整的URL]
 * @return int              [VHAL_OK/VHAL_FAIL]
 */
static int http_parse_url(http_client_config_t *p_http_cfg, const char *url)
{
    const char *ptr1 = url;
    char *ptr2 = NULL;
    int len = 0;

    if (0 == strncmp(ptr1, "http://", strlen("http://")))
    {
        ptr1 += strlen("http://");
    }
    else
    {
        return VHAL_FAIL;
    }

    ptr2 = strchr(ptr1, '/');
    if (ptr2)
    {
        len = strlen(ptr1) - strlen(ptr2);
        if (len >= HTTP_HOST_LEN)
        {
            HAL_LOG(LOG_WARN, "http host is too long\r\n");
            return VHAL_FAIL;
        }
        if (*(ptr2 + 1))
        {
            if (strlen(ptr2) >= HTTP_PATH_LEN)
            {
                HAL_LOG(LOG_WARN, "http path is too long\r\n");
                return VHAL_FAIL;
            }
            memcpy(p_http_cfg->path, ptr2, strlen(ptr2));
            p_http_cfg->path[strlen(ptr2)] = '\0';
        }
        else
        {
            memcpy(p_http_cfg->path, "/", 1);
            p_http_cfg->path[1] = '\0';
        }
        HAL_LOG(LOG_DEBUG, "http path: %s\n", p_http_cfg->path);
    }

    memcpy(p_http_cfg->host, ptr1, len);
    p_http_cfg->host[len] = '\0';
    ptr2 = strchr(p_http_cfg->host, ':');
    if (ptr2)
    {
        *ptr2++ = '\0';
        int port = atoi(ptr2);
        if (port > 0xffff)
        {
            HAL_LOG(LOG_WARN, "invalid http port: %d\n", port);
            return VHAL_FAIL;
        }
        p_http_cfg->port = port;
    }
    else
    {
        p_http_cfg->port = HTTP_DEFAULT_PORT;
    }
    HAL_LOG(LOG_DEBUG, "http host: %s, port: %d\n", p_http_cfg->host, p_http_cfg->port);

    return VHAL_OK;
}

/**
 * @brief HTTP客户端初始化
 * @param[in] p_http_cfg        [HTTP客户端配置]
 * @return http_client_handle_t [返回一个新建的HTTP客户端句柄，需要释放]
 */
http_client_handle_t http_client_init(http_client_config_t *p_http_cfg)
{
    if (VHAL_OK != http_parse_url(p_http_cfg, p_http_cfg->url))
    {
        return NULL;
    }

    http_client_handle_t client = malloc(sizeof(struct http_client));
    if (NULL == client)
    {
        return NULL;
    }

    client->cfg = p_http_cfg;
    client->is_head_fetch = false;
    client->http_buf = NULL;
    client->ctx_len = 0;
    client->ctx_recv = 0;
    client->socket = 0;

    return client;
}

/**
 * @brief 建立HTTP连接并发送GET请求
 * @param[in] client    [指向HTTP客户端]
 * @return int          [VHAL_OK/VHAL_FAIL]
 */
int http_client_open(http_client_handle_t client)
{
    if (VHAL_OK != tcp_connect(&client->socket, client->cfg))
    {
        HAL_LOG(LOG_ERROR, "tcp connected fail\n");
        return VHAL_FAIL;
    }
    if (VHAL_OK != send_get_request(client))
    {
        HAL_LOG(LOG_ERROR, "send http get requet fail\n");
        return VHAL_FAIL;
    }
    return VHAL_OK;
}

/**
 * @brief 接收并解析HTTP头部
 * @param[in] client    [指向HTTP客户端]
 * @return int          [VHAL_OK/VHAL_FAIL]
 */
int http_client_fetch_headers(http_client_handle_t client)
{
    if (!client->is_head_fetch)
    {
        client->http_buf = malloc(HTTP_BUF_SIZE);
        if (NULL == client->http_buf)
        {
            return VHAL_FAIL;
        }
        client->buf_len = 0;
        client->buf_ofs = 0;

        int rd_len = recv(client->socket, client->http_buf, HTTP_BUF_SIZE, 0);
        if (rd_len < 0)
        {
            return VHAL_FAIL;
        }
        client->buf_len += rd_len;

        char *find = NULL;
        find = (char *)strstr(client->http_buf, "HTTP/1.1");
        if (!find)
        {
            HAL_LOG(LOG_ERROR, "http/1.1 not found\n");
            return VHAL_FAIL;
        }
        client->result = atoi(find + 9);
        if (client->result != 200)
        {
            HAL_LOG(LOG_ERROR, "http_request_fail:\n%s\n", client->http_buf);
            return VHAL_FAIL;
        }
        find = (char *)strstr(client->http_buf, "Content-Length:");
        if (!find)
        {
            HAL_LOG(LOG_ERROR, "http Content-Length not found\n");
            return VHAL_FAIL;
        }
        else
        {
            client->ctx_len = atoi(find + strlen("Content-Length:") + 1);
        }
        find = (char *)strstr(client->http_buf, "\r\n\r\n");
        if (!find)
        {
            HAL_LOG(LOG_ERROR, "header length is invalid\n");
            return VHAL_FAIL;
        }

        // 指针偏移到内容
        find += 4;
        // 更新http读取缓存
        client->buf_ofs += (int)(find - (char *)client->http_buf);
        client->buf_len -= (int)(find - (char *)client->http_buf);
        client->is_head_fetch = true;
#if 0
        HAL_LOG(LOG_DEBUG, "http content_len: %d, buf_len: %d\n", client->ctx_len, client->buf_len);
        LOG_RAW_HEX(LOG_DEBUG, "http buffer: ", client->http_buf, client->buf_len);
#endif
    }
    return VHAL_OK;
}

/**
 * @brief 读取HTTP响应
 * @param[in] client    [指向HTTP客户端]
 * @param[in] p_buf     [读取的Buffer]
 * @param[in] len       [读取的长度]
 * @return int          [小于0：读取失败；大于等于0：返回最终读取的长度]
 */
int http_client_read(http_client_handle_t client, void *p_buf, int len)
{
    if (VHAL_OK != http_client_fetch_headers(client))
    {
        return -1;
    }

    int read_idx = 0;
    int need_to_read = len;
    if (NULL != client->http_buf)
    {
        int need_to_flush = need_to_read > client->buf_len ? client->buf_len : need_to_read;
        // 读取http头部处理时剩下的respone数据
        memcpy(p_buf, client->http_buf + client->buf_ofs, need_to_flush);
        client->buf_ofs += need_to_flush;
        client->buf_len -= need_to_flush;
        if (client->buf_len <= 0)
        {
            free(client->http_buf);
            client->http_buf = NULL;
        }
        read_idx += need_to_flush;
        need_to_read -= need_to_flush;
    }

    bool is_data_remain = true;
    while (need_to_read > 0 && is_data_remain)
    {
        is_data_remain = client->ctx_recv < client->ctx_len;
        if (!is_data_remain)
        {
            break;
        }

        int rlen = recv(client->socket, p_buf + read_idx, need_to_read, 0);
        if (rlen > 0)
        {
            read_idx += rlen;
            need_to_read -= rlen;
            continue;
        }
        // recv()返回0，TCP连接已经被关闭
        // 注意，Mini HTTP客户端的HTTP Request请求的是HTTP/1.1协议，且Request
        //   没有设置keep-alive的信息，所以服务器将默认使能keep-alive。这种情况
        //   下，当HTTP Response被读取完后，也就是一次HTTP请求结束后，服务器不会
        //   主动关闭TCP连接。继续调用recv()将返回负错误码，在服务器关闭keep-alive
        //   的情况下，则返回0，标志着TCP连接关闭。
        if (rlen < 0)
        {
            HAL_LOG(LOG_WARN, "socket recv() errno[%d]\n", errno);
            if (read_idx == 0)
            {
                return -2;
            }
        }
        else
        {
            HAL_LOG(LOG_WARN, "socket close\n");
        }
        break;
    }

    // 更新累计读取的Respone数据
    client->ctx_recv += read_idx;
#if 0
    HAL_LOG(LOG_INFO, "read:%d, content_recv:%d, content_len:%d\n", read_idx, client->ctx_recv, client->ctx_len);
#endif
    return read_idx;
}

/**
 * @brief 获取HTTP响应内容的长度
 * @param[in] client    [指向HTTP客户端]
 * @return int          [VHAL_OK/VHAL_FAIL]
 */
int http_client_get_content_length(http_client_handle_t client)
{
    return client->ctx_len;
}

/**
 * @brief 清理HTTP客户端
 * @param[in] client    [指向HTTP客户端]
 * @return int          [VHAL_OK/VHAL_FAIL]
 */
int http_cleanup(http_client_handle_t client)
{
    if (NULL == client)
    {
        return VHAL_FAIL;
    }

    close(client->socket);
    if (NULL != client->http_buf)
    {
        free(client->http_buf);
    }
    free(client);
    return VHAL_OK;
}
#else
/**
 * @brief HTTP客户端初始化
 * @param[in] p_http_cfg        [HTTP客户端配置]
 * @return http_client_handle_t [返回一个新建的HTTP客户端句柄，需要释放]
 */
http_client_handle_t http_client_init(http_client_config_t *p_http_cfg)
{
    return esp_http_client_init(p_http_cfg);
}

/**
 * @brief 建立HTTP连接并发送GET请求
 * @param[in] client    [指向HTTP客户端]
 * @return int          [VHAL_OK/VHAL_FAIL]
 */
int http_client_open(http_client_handle_t client)
{
    esp_err_t err = esp_http_client_open(client, 0);
    if (ESP_OK != err)
    {
        HAL_LOG(LOG_ERROR, "failed to open http connection: %s\n", esp_err_to_name(err));
        return VHAL_FAIL;
    }
    return VHAL_OK;
}

/**
 * @brief 接收并解析HTTP头部
 * @param[in] client    [指向HTTP客户端]
 * @return int          [VHAL_OK/VHAL_FAIL]
 */
int http_client_fetch_headers(http_client_handle_t client)
{
    esp_http_client_fetch_headers(client);
    return VHAL_OK;
}

/**
 * @brief 读取HTTP响应
 * @param[in] client    [指向HTTP客户端]
 * @param[in] p_buf     [读取的Buffer]
 * @param[in] len       [读取的长度]
 * @return int          [小于0：读取失败；大于等于0：返回最终读取的长度]
 */
int http_client_read(http_client_handle_t client, void *p_buf, int len)
{
    return esp_http_client_read(client, p_buf, len);
}

/**
 * @brief 获取HTTP响应内容的长度
 * @param[in] client    [指向HTTP客户端]
 * @return int          [返回的长度]
 */
int http_client_get_content_length(http_client_handle_t client)
{
    return esp_http_client_get_content_length(client);
}

/**
 * @brief 清除HTTP客户端会话
 * @param[in] client    [客户端句柄]
 */
int http_cleanup(http_client_handle_t client)
{
    esp_http_client_close(client);
    esp_http_client_cleanup(client);

    return VHAL_OK;
}
#endif /* CONFIG_VESYNC_HAL_OTA_ESP_MINI_HTTP_ENABLE */
#endif /* not defined CONFIG_IDF_TARGET_ESP8266 */
