/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
* @file         netcfg_light.h
* @brief        配网灯效控制
* @author       Joshua
* @date         2021-11-20
*/

#include <stdint.h>
#include "vesync_common.h"
#include "scene.h"

#ifndef __RESET_LIGHT_H__
#define __RESET_LIGHT_H__

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief  重置灯效回调
 * @return  int             [成功：APP_OK，失败：APP_FAIL]
 */
typedef int (*reset_light_cb_t)(void);


/**
 * @brief  重置灯效场景结构体
 */
typedef struct
{
    reset_light_cb_t reset_process_light;
} reset_light_scene_t;


/**
 * @brief  重置灯效
 * @param[in] thiz          [场景结构体指针]
 * @return  int             [成功：APP_OK，失败：APP_FAIL]
 */
static inline int reset_light_scene_process(scene_t *thiz)
{
    VCOM_NULL_PARAM_CHK(thiz, return APP_FAIL);
    reset_light_scene_t *ctx = (reset_light_scene_t *)thiz->ctx;
    return (ctx && ctx->reset_process_light) ? ctx->reset_process_light() : APP_FAIL;
}


/**
 * @brief  重置场景灯效实现初始化
 * @return int              [成功：APP_OK， 失败：APP_FAIL]
 */
int reset_light_scene_impl_init(void);

/**
 * @brief  注册重置场景灯效
 * @return  int             [成功：APP_OK，失败：APP_FAIL]
 */
int reset_light_scene_reg(reset_light_scene_t *light_scene);

/**
 * @brief  注销重置场景灯效
 * @return  int             [成功：APP_OK，失败：APP_FAIL]
 */
int reset_light_scene_unreg(void);

#ifdef __cplusplus
}
#endif

#endif


