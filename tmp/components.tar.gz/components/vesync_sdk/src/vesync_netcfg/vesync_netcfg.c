/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_netcfg.c
 * @brief       配网模块接口
 * @author      Louis
 * @date        2021-05-21
 */

#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "vhal_wifi.h"
#include "vhal_utils.h"
#include "vesync_task.h"
#include "vesync_common.h"
#include "vesync_cfg_internal.h"
#include "vesync_log_internal.h"
#include "vesync_net_service_internal.h"
#include "vesync_wifi_scan.h"
#include "vesync_wifi_led.h"
#ifdef CONFIG_VESYNC_SDK_LAN_COMM_ENABLE
#include "vesync_lan_comm.h"
#endif
#ifdef CONFIG_VESYNC_SDK_BLE_SERVICE_ENABLE
#include "vesync_ble_internal.h"
#endif
#include "vesync_ota_internal.h"
#include "vesync_loop_timer_internal.h"
#include "vesync_netcfg_timer.h"
#include "vesync_netcfg_event.h"
#include "vesync_netcfg_internal.h"
#include "vesync_netcfg_recv.h"
#include "vesync_netcfg_send.h"
#include "vesync_tcp_server.h"

static vesync_netcfg_status_t s_netcfg_status = {0};
// APP层注册的配网前回调
static void (*s_net_cfg_pre_cb)(void) = NULL;



/**
 * @brief   wifi连接断开上报log的回调函数
 * @param[in] reason_name           [wifi断开原因描述]
 */
static void vesync_netcfg_log_wifi_disconnect_cb(const char* reason_name)
{
    vesync_netcfg_report_wifi_disconnect(reason_name);
}

/**
 * @brief   创建配网任务前的初始化
 */
static int vesync_netcfg_init(void)
{
    // 初始化定时器
    if (SDK_OK != netcfg_timer_init())
    {
        SDK_LOG(LOG_ERROR, "timer init failed!\r\n");
        goto exit;
    }

    // 注册事件监听
    if (SDK_OK != netcfg_event_init())
    {
        SDK_LOG(LOG_ERROR, "event init failed!\r\n");
        goto exit;
    }
    return SDK_OK;

exit:
    return SDK_FAIL;
}

/**
 * @brief   配网任务退出后的清理
 */
static void vesync_netcfg_deinit(void)
{
    netcfg_event_deinit();
    netcfg_timer_deinit();

    vesync_wifi_aplist_clear();

    vesync_net_event_mgmt_enable();

    NETCFG_MODE_E config_mode = vesync_netcfg_get_mode();

    if (AP_CONFIG == config_mode)
    {
        SDK_LOG(LOG_DEBUG,"Disable Wi-Fi AP mode\r\n");
        vesync_tcp_server_stop();
        vhal_wifi_stop_ap_mode();   // 停止AP热点，不会导致Wi-Fi断开重连
    }

    vhal_wifi_unreg_netcfg_cb();
#ifdef CONFIG_VESYNC_SDK_BLE_SERVICE_ENABLE
    vesync_ble_reg_netcfg_recv_cb(NULL);
#endif

    vesync_netcfg_recv_deinit();

    if (s_netcfg_status.status == NETCFG_STATUS_SAVE_CFG_SUCCESS)
    {
        vesync_ev_t ev = {0};
        VESYNC_POPULATE_EV(ev, EVENT_NETCFG_SUCCEED, NETCFG_TASK_NAME, 0, NULL);
        vesync_event_publish(&ev);

        if (s_netcfg_status.need_reset == true)
        {
            VESYNC_POPULATE_EV(ev, EVENT_DEL_USER_DATA, NETCFG_TASK_NAME, 0, NULL);
            vesync_event_publish(&ev);
        }
    }
    else
    {
        vesync_net_mgmt_load_net_cfg();
        net_info_t *p_net_cfg = vesync_net_mgmt_get_net_cfg();
        if (strlen((char *)p_net_cfg->wifiSSID) > 0)
        {
            vesync_wifi_client_connect((char *)p_net_cfg->wifiSSID,
                                       (char *)p_net_cfg->wifiPassword,
                                       (VHAL_WIFI_AUTH_MODE_E)p_net_cfg->auth_mode);
        }
    }

#ifdef CONFIG_VESYNC_SDK_BLE_SERVICE_ENABLE
    if (BLE_CONFIG == config_mode)
    {
        vesync_ble_disconnect();    // 如果有连接主动断开蓝牙连接

        if (s_netcfg_status.status == NETCFG_STATUS_SAVE_CFG_SUCCESS)
        {
            vesync_ble_adv_update_netcfg_status(NETCFG_STAT_CFGED);
        }
        else
        {
            net_info_t *p_net_cfg = vesync_net_mgmt_get_net_cfg();
            if (strlen((char *)p_net_cfg->wifiSSID) > 0)
            {
                vesync_ble_adv_update_netcfg_status(NETCFG_STAT_CFGED);
            }
            else
            {
                vesync_ble_adv_update_netcfg_status(NETCFG_STAT_UNCFG);
            }
        }
    }
#endif

    memset(&s_netcfg_status, 0, sizeof(vesync_netcfg_status_t));
}

/**
 * @brief   配网任务
 */
static void vesync_netcfg_task(void *args)
{
    vesync_ev_t event;

    // 记录状态(必须在MQTT和Wi-Fi断开前记录)
    vesync_net_mgmt_set_reconnect_reason(CONFIG_NET_REASON);

    vesync_wifi_led_set_behavior(WIFI_LED_NOT_CONFIG);   // 等待配网，慢闪
    vesync_netcfg_set_status(NETCFG_STATUS_IDLE);

    vesync_net_event_mgmt_disable();
    vesync_net_client_disconnect_server();     // disconnect server

#ifdef CONFIG_VESYNC_SDK_LAN_COMM_ENABLE
    vesync_lan_comm_stop();                         //关闭局域网通信功能
#endif

    vhal_wifi_stop();                               // disconnect Wi-Fi

    vhal_wifi_reg_netcfg_cb(vesync_wifi_scan_vhal_cb, vesync_netcfg_log_wifi_disconnect_cb);
#ifdef CONFIG_VESYNC_SDK_BLE_SERVICE_ENABLE
    // 注册BLE配网通道的接收函数
    vesync_ble_reg_netcfg_recv_cb(vesync_netcfg_ble_recv_cb);
#endif

    vesync_net_mgmt_clear_net_cfg();

    SDK_LOG(LOG_DEBUG, "free_heap:%d\r\n", vhal_utils_get_free_heap_size());

    if (SDK_OK != vesync_netcfg_init())
    {
        SDK_LOG(LOG_ERROR, "init failed!\r\n");
        goto exit;
    }

    // 添加配网超时定时器
    netcfg_add_main_timer();

    // 提前进行一次wifi列表扫描
    vesync_wifi_scan_start();

    while(1)
    {
        SDK_LOG(LOG_DEBUG, "free_heap:%d\r\n", vhal_utils_get_free_heap_size());
        memset(&event, 0, sizeof(vesync_ev_t));
        if (SDK_OK == netcfg_receive_event(&event, netcfg_process_expired_timer()))
        {
            // 监听到事件，调用对应的事件回调函数
            SDK_LOG(LOG_DEBUG, "event_id:%d\r\n",event.event_id);
            netcfg_dispatch_event(&event);
        }

        // 退出配网任务
        if (true == s_netcfg_status.set_exit)
        {
            break;
        }
    }

exit:
    SDK_LOG(LOG_DEBUG, "netcfg task exit\r\n");
}


/**
 * @brief   进入配网模式, 此接口开放给应用层调用
 */
int vesync_netcfg_start(void)
{
    if (NULL != s_net_cfg_pre_cb)
    {
        s_net_cfg_pre_cb();
    }
#ifdef CONFIG_VESYNC_SDK_OTA_ENABLE
    if(vesync_ota_is_upgrading())
    {
        SDK_LOG(LOG_ERROR, "upgrading, can not netcfg!\r\n");
        return SDK_FAIL;
    }
#endif

    NETCFG_MODE_E config_mode = vesync_netcfg_get_mode();
    SDK_LOG(LOG_WARN, "Enter config mode(%d) interface.\n", config_mode);
    if (UNKNOW_CONFIG == config_mode)
    {
        return SDK_FAIL;
    }

    if (s_netcfg_status.running)
    {
        return SDK_OK;
    }
    else
    {
        s_netcfg_status.running = true;
    }

#ifdef CONFIG_VESYNC_SDK_BLE_SERVICE_ENABLE
    if (BLE_CONFIG == config_mode)
    {
        vesync_ble_disconnect();    // 如果有连接主动断开蓝牙连接
        vesync_ble_adv_update_netcfg_status(NETCFG_STAT_READY); // 蓝牙广播配网等待状态
    }
#endif

    if (VOS_OK != vesync_task_new(NETCFG_TASK_NAME,
                                  vesync_netcfg_deinit,
                                  vesync_netcfg_task,
                                  NULL,
                                  NETCFG_TASK_STACKSIZE,
                                  NETCFG_TASK_PRIO,
                                  NULL))
    {
        SDK_LOG(LOG_ERROR, "Create task fail.\r\n");
        vesync_netcfg_deinit();
        return SDK_FAIL;
    }

    return SDK_OK;
}

/**
 * @brief   停止配网模式, 此接口开放给应用层调用
 */
int vesync_netcfg_stop(void)
{
    vesync_ev_t ev = {0};
    VESYNC_POPULATE_EV(ev, EVENT_NETCFG_FORCE_EXIT, NETCFG_TASK_NAME, 0, NULL);
    vesync_event_publish(&ev);

    return SDK_OK;
}

/**
 * @brief   重新启动配网模式, 此接口开放给应用层调用
 * @return  int                 [成功：SDK_OK，失败：SDK_FAIL]
 * @note    1.配网任务运行中，则会等待退出操作完成后，重新进入配网任务
 *          2.配网任务未运行，直接启动配网任务。
 */
int vesync_netcfg_restart(void)
{
    uint8_t count  = VESYNC_NETCFG_EXIT_TIMEOUT; // 最多等待2S

    if (vesync_netcfg_is_running())
    {
        vesync_netcfg_stop();
        while ((count > 0)&&(vesync_netcfg_is_running()))
        {
            vesync_sleep(10);  // 让出足够的时间给配网任务执行退出配网任务操作
            count--;
        }

        if ((0 == count)&&(vesync_netcfg_is_running()))
        {
            SDK_LOG(LOG_ERROR, "netcfg stop fail.\n");
            return SDK_FAIL;
        }
    }

    vesync_netcfg_start();
    return SDK_OK;
}



/**
 * @brief   停止配网模式, 此接口内部使用
 * @attention 此函数只能由事件统一调用
 */
void vesync_netcfg_set_exit(void)
{
    s_netcfg_status.set_exit = true;
}

/**
 * @brief 设置配网状态
 * @param[in] status        [配网的状态]
 */
void vesync_netcfg_set_status(NETCFG_STATUS_E status)
{
    if(NETCFG_STATUS_IDLE <= status && NETCFG_STATUS_MAX > status)
    {
        s_netcfg_status.status = status;
    }
}

/**
 * @brief 获取当前配网状态
 * @return NETCFG_STATUS_E      [当前配网状态]
 */
NETCFG_STATUS_E vesync_netcfg_get_status(void)
{
    return s_netcfg_status.status;
}


void vesync_netcfg_set_reset_flag(bool reset)
{
    s_netcfg_status.need_reset = reset;
}

/**
 * @brief 获取协议版本
 * @return    uint8_t   [协议版本]
 */
uint8_t vesync_netcfg_config_get_protocol_version()
{
#ifndef PR_PROT_PAYLOAD_VER
#error "Error: Please set PR_PROT_PAYLOAD_VER in vesync_profile"
#endif
    uint8_t protocol_version = 0;

    protocol_version = PR_PROT_PAYLOAD_VER & 0xFF;
    if (protocol_version > 0x01)
    {
        protocol_version = protocol_version | (NETCFG_VERSION_SECURITY_AES << 4);
    }

    return protocol_version;
}


/**
 * @brief 获取配网模式
 * @return    NETCFG_MODE_E     [配网模式]
 */
NETCFG_MODE_E vesync_netcfg_get_mode(void)
{
    static int mode = -1;
    char *netcfg_mode = vesync_cfg_get_netcfg_mode();

    if (mode < 0)
    {
        if (0 == strcmp(netcfg_mode, "cfg_by_ap"))  // AP配网模式
        {
            mode = AP_CONFIG;
        }
        else if (0 == strcmp(netcfg_mode, "cfg_by_ble"))    // BLE配网模式
        {
            mode = BLE_CONFIG;
        }
        else if(0 == strcmp(netcfg_mode, "cfg_by_nfc"))
        {
            mode = NFC_CONFIG;
        }
        else
        {
            mode = UNKNOW_CONFIG;
        }
    }

    return mode;
}


/**
 * @brief  获取当前状态是否处于配网中
 * @return     bool         [true-配网中，false-非配网状态]
 */
bool vesync_netcfg_is_running(void)
{
    return s_netcfg_status.running;
}


int vesync_net_cfg_reg_pre_cb(void(* net_cfg_pre_cb)(void))
{
    s_net_cfg_pre_cb = net_cfg_pre_cb;

    return SDK_OK;
}


