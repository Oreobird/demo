/*
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file        vesync_bypass_internal.h
* @brief       bypass处理接口
* @date        2021-05-13
*/

#ifndef __VESYNC_BYPASS_INTERNAL_H__
#define __VESYNC_BYPASS_INTERNAL_H__

#include "vesync_bypass.h"
#include "vesync_list.h"

#ifdef __cplusplus
extern "C" {
#endif

#define BYPASS_METHOD_NAME_MAX_LEN  (64)

// 设备消息来源
#define BP_AUTH_MSG_FROM_DVLPR       (MSG_TAG_DVLPR)                                 // 只允许developer来源的消息
#define BP_AUTH_MSG_FROM_MQTT        (MSG_TAG_MQTT)                                  // 只允许MQTT来源的消息
#define BP_AUTH_MSG_FROM_LOCAL       (MSG_TAG_LOCAL)                                 // 只允许局域网（本地通信）来源的消息
#define BP_AUTH_MSG_FROM_MQTT_LOCAL  (MSG_TAG_MQTT | MSG_TAG_LOCAL)                  // 允许MQTT和局域网来源的消息
#define BP_AUTH_MSG_FROM_ALL         (MSG_TAG_DVLPR | MSG_TAG_MQTT | MSG_TAG_LOCAL)  // 允许所有来源的消息

/**
 * @brief bypass item 数据结构
 */
typedef struct
{
    uint32_t auth_mask;             // 接口授权掩码
    BYPASS_METHOD_ID_E  method_id;  // 接口id
    char method[BYPASS_METHOD_NAME_MAX_LEN]; // 接口名称
    bypass_method_handle_fn_t method_handle;       // 接口json解析回调函数
    bypass_method_cb_t app_cb;                     // 接口应用层回调函数
} bypass_item_data_t;


/**
 * @brief bypass item 数据结构
 */
typedef struct
{
    struct list_head list;
    bypass_item_data_t data;
} bypass_item_t;


/**
 * @brief bypass item 数据结构
 */
typedef struct
{
    int num;
    //vesync_mutex_t mutex;
    struct list_head list;
} bypass_mgt_t;


/**
 * @brief 应用层注册查询串口队列剩余空间 回调函数
 * @param cb                                 [串口队列剩余空间 回调函数]
 * @return void
 */
void vesync_bypass_reg_get_uart_mq_freesize_cb(bypass_get_uart_mq_freesize_cb_t cb);


/**
 * @brief bypass 消息应答函数, 带MQTT消息等级
 * @param[in] code                           [错误码]
 * @param[in] p_trace_msg                    [trace message app发送过来原样返回]
 * @param[in] json                           [返回数据json指针， 如果没返回数据返回空指针]
 * @param[in] qos                            [MQTT消息等级]
 * @param[in] puback_cb                      [收到qos1确认包后的回调函数]
 * @return bypass_err_t
 */
int vesync_bypass_reply_qos(int code, const bypass_trace_msg_t *p_trace_msg, cJSON *json, REPORT_QOS_E qos, void* puback_cb);


#ifdef __cplusplus
}
#endif /* __VESYNC_BYPASS_H__ */

