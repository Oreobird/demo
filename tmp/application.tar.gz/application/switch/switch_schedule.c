/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        switch_schedule.c
 * @brief       switch schedule
 * @author      Charles.Mei
 * @date        2021-08-05
 */

#include <string.h>
#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>

#include "vhal_flash.h"

#include "vesync_common.h"
#include "vesync_log.h"
#include "vesync_memory.h"
#include "vesync_schedule.h"
#include "vesync_device.h"

#include "switch_app.h"
#include "switch_report.h"
#include "switch_uart_cmd.h"
#include "switch_schedule.h"


/**
 * @brief 灯schedule执行回调
 * @param[in]   sch_cfg     [Schedule配置]
 * @param[in]   app_cfg     [Schedule动作]
 * @return int              [成功/失败]
 */
static int switch_schedule_light_exec_cb(vesync_schedule_t sch_cfg, vesync_buf_t app_cfg)
{
    int ret = APP_FAIL;

    if (app_cfg.len < sizeof(light_action_t))
    {
        return SCHE_ERR;
    }

    light_action_t light_action;
    memset(&light_action, 0, sizeof(light_action_t));
    vesync_buf_get(&app_cfg, &light_action, sizeof(light_action_t));

    APP_LOG(LOG_INFO, "Schedule task executes. sche_id:[%ld]\n", sch_cfg.id);

    if (false == light_action.onoff)
    {
        ret = switch_uart_set_switch(DEVICE_LIGHT, 0, light_action.duration, NULL);
    }
    else
    {
        if (0 != light_action.lightness)
        {
            ret = switch_uart_set_lightness(light_action.lightness, light_action.duration, NULL);
        }
        else
        {
            ret = switch_uart_set_switch(DEVICE_LIGHT, 1, light_action.duration, NULL);
        }
    }
    switch_app_update_status_chg_rsn(STAT_CHG_RSN_SCHD_STR);

    if (APP_OK != ret)
    {
        switch_report_schedule_exec(DEVICE_LIGHT, &sch_cfg, &light_action, ret, "uart send fail");
    }
    else
    {
        switch_report_schedule_exec(DEVICE_LIGHT, &sch_cfg, &light_action, ret, "");
    }

    return SCHE_OK;
}

/**
 * @brief 风扇schedule执行回调
 * @param[in]   sch_cfg     [Schedule配置]
 * @param[in]   app_cfg     [Schedule动作]
 * @return int              [成功/失败]
 */
static int switch_schedule_fan_exec_cb(vesync_schedule_t sch_cfg, vesync_buf_t app_cfg)
{
    int ret = APP_FAIL;

    if (app_cfg.len < sizeof(fan_action_t))
    {
        return SCHE_ERR;
    }

    fan_action_t fan_action;
    memset(&fan_action, 0, sizeof(fan_action_t));
    vesync_buf_get(&app_cfg, &fan_action, sizeof(fan_action_t));

    APP_LOG(LOG_INFO, "Schedule task executes. sche_id:[%ld]\n", sch_cfg.id);

    if (false == fan_action.onoff)
    {
        ret = switch_uart_set_switch(DEVICE_FAN, 0, 0, NULL);
    }
    else
    {
        if (0 != fan_action.level)
        {
            ret = switch_uart_set_level(DEVICE_FAN, fan_action.level, 0, NULL);
        }
        else
        {
            ret = switch_uart_set_switch(DEVICE_FAN, 1, 0, NULL);
        }
    }
    switch_app_update_status_chg_rsn(STAT_CHG_RSN_SCHD_STR);

    if (APP_OK != ret)
    {
        switch_report_schedule_exec(DEVICE_FAN, &sch_cfg, &fan_action, ret, "uart send fail");
    }
    else
    {
        switch_report_schedule_exec(DEVICE_FAN, &sch_cfg, &fan_action, ret, "");
    }

    return SCHE_OK;
}

/**
 * @brief Bypass添加Schedule配置项
 * @param[in]   dev_id      [设备id]
 * @param[in]   sch_cfg     [Schedule配置]
 * @param[in]   action      [Schedule动作]
 * @param[out]  p_out_id    [添加成功后，返回生成的ID]
 * @return int              [返回BYPASS的错误定义]
 */
int switch_schedule_add(DEVICE_ID_E dev_id, vesync_schedule_t *sch_cfg, void *action, uint32_t *p_out_id)
{
    int err_code = BP_ERR_NO_ERR;
    int ret = SCHE_ERR;

    if (NULL == sch_cfg || NULL == action || NULL == p_out_id)
    {
        return BP_ERR_CMD_EXECUTE_FAIL;
    }

    if (DEVICE_ALL == dev_id || dev_id >= DEVICE_MAX)
    {
        return BP_ERR_CMD_EXECUTE_FAIL;
    }
    // 缓存应用层的配置
    vesync_buf_t app_cfg_buf = vesync_buf_new();

    if (DEVICE_LIGHT == dev_id)
    {
        vesync_buf_set(&app_cfg_buf, action, sizeof(light_action_t));
        ret = vesync_schedule_add(SWITCH_SCHE_INS_LIGHT_ID, sch_cfg, &app_cfg_buf, true);
    }
    else if (DEVICE_FAN == dev_id)
    {
        vesync_buf_set(&app_cfg_buf, action, sizeof(fan_action_t));
        ret = vesync_schedule_add(SWITCH_SCHE_INS_FAN_ID, sch_cfg, &app_cfg_buf, true);
    }
    else
    {
        err_code = BP_ERR_CMD_EXECUTE_FAIL;
        goto exit;
    }


    if (ret != SCHE_OK)
    {
        APP_LOG(LOG_WARN, "Schedule added fail: %d\n", ret);
        if (ret == SCHE_CFLT_ERR)
        {
            err_code = BP_ERR_SCHEDULE_CONFLICT;
            goto exit;
        }
        if (ret == SCHE_EXCEED_MAX)
        {
            err_code = BP_ERR_SCHEDULE_EXCEED_MAX;
            goto exit;
        }
        err_code = BP_ERR_CMD_EXECUTE_FAIL;
        goto exit;
    }

    // 添加的配置项ID返回给BP调用端
    *p_out_id = sch_cfg->id;

exit:
    vesync_buf_clr(&app_cfg_buf);
    return err_code;
}

/**
 * @brief Bypass更新Schedule配置项
 * @param[in]   dev_id      [设备id]
 * @param[in]   sch_cfg     [Schedule配置]
 * @param[in]   action      [Schedule动作]
 * @param[out]  p_out_id    [添加成功后，返回生成的ID]
 * @return int              [返回BYPASS的错误定义]
 */
int switch_schedule_upd(DEVICE_ID_E dev_id, vesync_schedule_t *sch_cfg, void *action, uint32_t *p_out_id)
{
    int err_code = BP_ERR_NO_ERR;
    int ret = SCHE_ERR;

    if (NULL == sch_cfg || NULL == p_out_id)
    {
        return BP_ERR_CMD_EXECUTE_FAIL;
    }

    if (DEVICE_ALL == dev_id || dev_id >= DEVICE_MAX)
    {
        return BP_ERR_CMD_EXECUTE_FAIL;
    }
    // ID 是必选项
    if (0 == sch_cfg->id || SWITCH_SCHEDULE_MIN_ID > sch_cfg->id)
    {
        return BP_ERR_PARA_ILLEGAL;
    }
    // 缓存应用层的配置
    vesync_buf_t app_cfg_buf = vesync_buf_new();

    if (DEVICE_LIGHT == dev_id)
    {
        if (NULL == action)
        {
            vesync_schedule_t old_sch_cfg;
            // 使用旧action
            ret = vesync_schedule_get_by_id(SWITCH_SCHE_INS_LIGHT_ID, sch_cfg->id, &old_sch_cfg, &app_cfg_buf);
            if (ret != SCHE_OK)
            {
                if (ret != SCHE_INV_ID_ERR)
                {
                    err_code = BP_ERR_UNDEFINE;
                    goto exit;
                }
                err_code = BP_ERR_SCHEDULE_NOT_FOUND;
                goto exit;
            }
            ret = vesync_schedule_upd(SWITCH_SCHE_INS_LIGHT_ID, sch_cfg, &app_cfg_buf);
        }
        else
        {
            vesync_buf_set(&app_cfg_buf, action, sizeof(light_action_t));
            ret = vesync_schedule_upd(SWITCH_SCHE_INS_LIGHT_ID, sch_cfg, &app_cfg_buf);
        }
    }
    else if (DEVICE_FAN == dev_id)
    {
        if (NULL == action)
        {
            vesync_schedule_t old_sch_cfg;
            // 使用旧action
            ret = vesync_schedule_get_by_id(SWITCH_SCHE_INS_FAN_ID, sch_cfg->id, &old_sch_cfg, &app_cfg_buf);
            if (ret != SCHE_OK)
            {
                if (ret != SCHE_INV_ID_ERR)
                {
                    err_code = BP_ERR_UNDEFINE;
                    goto exit;
                }
                err_code = BP_ERR_SCHEDULE_NOT_FOUND;
                goto exit;
            }
            ret = vesync_schedule_upd(SWITCH_SCHE_INS_FAN_ID, sch_cfg, &app_cfg_buf);
        }
        else
        {
            vesync_buf_set(&app_cfg_buf, action, sizeof(fan_action_t));
            ret = vesync_schedule_upd(SWITCH_SCHE_INS_FAN_ID, sch_cfg, &app_cfg_buf);
        }

    }
    else
    {
        err_code = BP_ERR_CMD_EXECUTE_FAIL;
        goto exit;
    }

    if (ret != SCHE_OK)
    {
        if (ret != SCHE_CFLT_ERR)
        {
            err_code = BP_ERR_CMD_EXECUTE_FAIL;
            goto exit;
        }

        err_code = BP_ERR_SCHEDULE_CONFLICT;
        goto exit;
    }

    // 添加的配置项ID返回给BP调用端
    *p_out_id = sch_cfg->id;

exit:
    vesync_buf_clr(&app_cfg_buf);
    return err_code;
}

/**
 * @brief Bypass按顺序获取Schedule多个配置项
 * @note  返回多少个连续的配置项是由Schedule模块决定
 * @param[in]  dev_id       [设备id]
 * @param[in]  index        [要获取的Schedule配置项的初始序号]
 * @param[in]  sche_cfg     [schedule配置数组]
 * @param[in]  action       [schedule动作数组]
 * @param[in]  cur_num      [返回的schedule数]
 * @param[in]  total_num    [配置项总数]
 * @return int              [返回BYPASS的错误定义]
 */
int switch_schedule_get_mult(DEVICE_ID_E dev_id, uint32_t index, vesync_schedule_t *sche_cfg, void *action, uint32_t *cur_num, uint32_t *total_num)
{
    int ret = SCHE_ERR;
    int err_code = BP_ERR_NO_ERR;
    vesync_buf_t app_cfg_buf[SWITCH_SCHEDULE_GET_MAX_NUM];

    if (NULL == sche_cfg || NULL == action || NULL == cur_num || NULL == total_num)
    {
        return BP_ERR_CMD_EXECUTE_FAIL;
    }
    if (DEVICE_ALL == dev_id || dev_id >= DEVICE_MAX)
    {
        return BP_ERR_CMD_EXECUTE_FAIL;
    }

    for (uint32_t i = 0; i < SWITCH_SCHEDULE_GET_MAX_NUM; i++)
    {
        app_cfg_buf[i] = vesync_buf_new();
    }

    if (DEVICE_LIGHT == dev_id)
    {
        ret = vesync_schedule_get_by_index(SWITCH_SCHE_INS_LIGHT_ID, index, SWITCH_SCHEDULE_GET_MAX_NUM,
            total_num, sche_cfg, app_cfg_buf, cur_num);
        for (uint32_t i = 0; i < SWITCH_SCHEDULE_GET_MAX_NUM; i++)
        {
            vesync_buf_get(&app_cfg_buf[i], (light_action_t *)action + i, sizeof(light_action_t));
        }
    }
    else if (DEVICE_FAN == dev_id)
    {
        ret = vesync_schedule_get_by_index(SWITCH_SCHE_INS_FAN_ID, index, SWITCH_SCHEDULE_GET_MAX_NUM,
            total_num, sche_cfg, app_cfg_buf, cur_num);
        for (uint32_t i = 0; i < SWITCH_SCHEDULE_GET_MAX_NUM; i++)
        {
            vesync_buf_get(&app_cfg_buf[i], (fan_action_t *)action + i, sizeof(fan_action_t));
        }
    }
    else
    {
        err_code = BP_ERR_CMD_EXECUTE_FAIL;
        goto exit;
    }
    if (ret != SCHE_OK)
    {
        if (ret == SCHE_INV_IDX_ERR)
        {
            err_code = BP_ERR_SCHEDULE_NOT_FOUND;
            goto exit;
        }

        ret = BP_ERR_CMD_EXECUTE_FAIL;
        goto exit;
    }

exit:
    // 销毁APP配置读取缓存
    for (uint32_t i = 0; i < SWITCH_SCHEDULE_GET_MAX_NUM; i++)
    {
        vesync_buf_clr(&app_cfg_buf[i]);
    }
    return err_code;
}


/**
 * @brief Bypass删除指定ID的Schedule配置项
 * @param[in]   dev_id      [设备id]
 * @param[in]   id_to_del   [要删除的Schedule配置项ID]
 * @return      int         [返回BYPASS的错误定义]
 */
int switch_schedule_del(DEVICE_ID_E dev_id, uint32_t id_to_del)
{
    int ret = SCHE_ERR;

    switch (dev_id)
    {
        case DEVICE_LIGHT:
            ret = vesync_schedule_del(SWITCH_SCHE_INS_LIGHT_ID, id_to_del);
            break;
        case DEVICE_FAN:
            ret = vesync_schedule_del(SWITCH_SCHE_INS_FAN_ID, id_to_del);
            break;
        default:
            return BP_ERR_CMD_EXECUTE_FAIL;
    }
    if (ret != SCHE_OK)
    {
        if (ret != SCHE_INV_ID_ERR)
        {
            return BP_ERR_CMD_EXECUTE_FAIL;
        }
        return BP_ERR_SCHEDULE_NOT_FOUND;
    }

    return BP_ERR_NO_ERR;
}

/**
 * @brief App层调用，复位Schedule的所有配置信息
 * @return      int         [返回APP的错误定义： APP_OK, APP_FAIL]
 */
int switch_schedule_clear(void)
{
    vesync_schedule_clear(SWITCH_SCHE_INS_LIGHT_ID);
    vesync_schedule_clear(SWITCH_SCHE_INS_FAN_ID);
    return APP_OK;
}

/**
 * @brief 初始化Schedule功能
 * @return      int         [返回APP的错误定义： APP_OK, APP_FAIL]
 */
int switch_schedule_init(void)
{
    int ret = 0;

    // 初始化Schedule模块
    if (SCHE_OK != vesync_schedule_main_init())
    {
        APP_LOG(LOG_ERROR, "Schedule module init fail\n");

        return APP_FAIL;
    }

    vesync_schedule_param_t schedule_param;
    schedule_param.rd_cfg_cb = NULL;
    schedule_param.wr_cfg_cb = NULL;
    schedule_param.exec_app_task_cb = switch_schedule_light_exec_cb;
    schedule_param.max_app_cfg_size = SWITCH_SCHEDULE_MAX_APP_CFG_SIZE;
    schedule_param.max_sche_nbr = SWITCH_SCHEDULE_MAX_NUM;
    schedule_param.min_id_limit = SWITCH_SCHEDULE_MIN_ID;
    ret = vesync_schedule_new_instance(SWITCH_SCHE_INS_LIGHT_ID, &schedule_param);
    if (ret != SCHE_OK)
    {
        switch_schedule_clear();
        APP_LOG(LOG_ERROR, "Schedule instance init error: [%ld]\n", ret);

        return APP_FAIL;
    }

    schedule_param.rd_cfg_cb = NULL;
    schedule_param.wr_cfg_cb = NULL;
    schedule_param.exec_app_task_cb = switch_schedule_fan_exec_cb;
    schedule_param.max_app_cfg_size = SWITCH_SCHEDULE_MAX_APP_CFG_SIZE;
    schedule_param.max_sche_nbr = SWITCH_SCHEDULE_MAX_NUM;
    schedule_param.min_id_limit = SWITCH_SCHEDULE_MIN_ID;
    ret = vesync_schedule_new_instance(SWITCH_SCHE_INS_FAN_ID, &schedule_param);
    if (ret != SCHE_OK)
    {
        switch_schedule_clear();
        APP_LOG(LOG_ERROR, "Schedule instance init error: [%ld]\n", ret);

        return APP_FAIL;
    }

    APP_LOG(LOG_INFO, "Schedule initialized\n");
    return APP_OK;
}


