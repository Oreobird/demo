/**
 *  Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vhal_i2c.c
 * @brief       realtek amebaZ2的i2c读写接口
 * @author      Dongri.Su
 * @date        2021-04-22
 */

#include <stdio.h>
#include "i2c_api.h"

#include "vesync_log.h"
#include "vesync_common.h"


#include "vhal_i2c.h"
#include "vhal_gpio.h"


static i2c_t s_i2c_master;              // i2c主机object
static uint8_t s_i2c_num;               // i2c编号


/**
 * @brief  iic初始化为主机模式
 * @param[in]  i2c_num              [iic编号，0或1]
 * @param[in]  sda_io               [SDA数据线引脚]
 * @param[in]  scl_io               [SCL时钟线引脚]
 * @param[in]  speed                [通信速率]
 * @return     int32_t              [初始化结果，0为成功，其他值表示失败]
 */
int32_t vhal_i2c_master_init(uint8_t i2c_num, uint8_t sda_io, uint8_t scl_io, uint32_t speed)
{
    s_i2c_num = i2c_num;
    i2c_init(&s_i2c_master, vhal_rtl_giop_get_pin_name(sda_io), vhal_rtl_giop_get_pin_name(scl_io));
    i2c_frequency(&s_i2c_master, speed);

    return VHAL_OK;
}

/**
 * @brief  iic读取客户端数据
 * @param[in]  i2c_num              [iic编号，0或1]
 * @param[in]  addr                 [操作的地址]
 * @param[in]  p_data               [读取的数据缓存buffer]
 * @param[in]  len                  [读取的数据大小]
 * @return     int32_t              [读取结果，0为成功，其他值表示失败]
 * @note
 *_______________________________________________________________________________________
 * | start | slave_addr + rd_bit +ack | read n-1 bytes + ack | read 1 byte + nack | stop |
 * --------|--------------------------|----------------------|--------------------|------|
 */
int32_t vhal_i2c_master_read(uint8_t i2c_num, uint8_t addr, uint8_t *p_data, int32_t len)
{
    int stop = 1;   // 接收完后停止
    int val = 0;

    if(i2c_num != s_i2c_num)
    {
        HAL_LOG(LOG_ERROR, "I2C number(%d) is uninitialized!!\n", i2c_num);
        return 0;
    }
    if (NULL == p_data)
    {
        HAL_LOG(LOG_ERROR, "Input parameter contains null pointer!!\n");
        return 0;
    }

    val = i2c_read(&s_i2c_master, addr, (char *)p_data, len, stop);    // 返回实际读取的长度
    HAL_LOG(LOG_DEBUG, "I2C read %d bytes.\n", val);

    return val;
}

/**
 * @brief  iic写数据到客户端
 * @param[in]  i2c_num              [iic编号，0或1]
 * @param[in]  addr                 [操作的地址]
 * @param[in]  p_data               [待写入的数据]
 * @param[in]  len                  [待写入的数据大小]
 * @return     int32_t              [写入结果，0为成功，其他值表示失败]
 * @note
 * ___________________________________________________________________
 * | start | slave_addr + wr_bit + ack | write n bytes + ack  | stop |
 * --------|---------------------------|----------------------|------|
 */
int32_t vhal_i2c_master_write(uint8_t i2c_num, uint8_t addr, uint8_t *p_data, int32_t len)
{
    int stop = 1;   // 发送完后停止
    int val = 0;

    if(i2c_num != s_i2c_num)
    {
        HAL_LOG(LOG_ERROR, "I2C number(%d) is uninitialized!!\n", i2c_num);
        return VHAL_FAIL;
    }
    if (NULL == p_data)
    {
        HAL_LOG(LOG_DEBUG, "Input parameter contains null pointer!!\n");
        return VHAL_FAIL;
    }

    val = i2c_write(&s_i2c_master, addr, (char *)p_data, len, stop);
    HAL_LOG(LOG_DEBUG, "I2C write %d bytes.\n", val);

    return val;
}

/**
 * @brief  iic总线单独写stop信号到客户端
 * @param[in]  i2c_num              [iic编号，0或1]
 * @return     int32_t              [写入结果，0为成功，其他值表示失败]
 */
int32_t vhal_i2c_master_write_stop_condition(uint8_t i2c_num)
{
    return VHAL_OK;
}
