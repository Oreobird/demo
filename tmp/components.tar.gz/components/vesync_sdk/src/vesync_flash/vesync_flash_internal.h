/**
 * Copyright © Vesync Technologies Co.Ltd. 2022. All rights reserved.
 * @file        vesync_flash_interl.h
 * @brief       Vesync Flash模块内部接口声明
 * @date        2022-01-19
 */
#ifndef __VESYNC_FLASH_INTERNAL_H__
#define __VESYNC_FLASH_INTERNAL_H__

#include <stdint.h>

#include "vesync_flash.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief 解密由Brand AES密钥加密的数据
 * @param[in]   p_in                [指向被解密数据的缓存]
 * @param[in]   len                 [被解密数据的长度]
 * @param[out]  p_out               [指向输出解密完数据的引用]
 * @return      int                 [返回解密完数据的长度]
 */
int vesync_flash_brand_aes_decrypt(const uint8_t *p_in, int len, uint8_t **p_out);

#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_FLASH_INTERNAL_H__ */