/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_away_internal.h
 * @brief       away内部头文件
 * @date        2021-05-27
 */

#ifndef __VESYNC_AWAY_INTERNAL_H__
#define __VESYNC_AWAY_INTERNAL_H__

#include <stdint.h>
#include <stdbool.h>
#include "vesync_away.h"
#include "vesync_timer.h"
#include "vesync_list.h"

#ifdef __cplusplus
extern "C" {
#endif

#define INVALID_MINUTE              (0xff)
#define AWAY_CYCLE_TIMER_INTERVAL   (10000)     //定时器轮询间隔
#define LSB_CLEAN_MASK              (0xfe)  //最低位清零宏

#define AWAY_RANDOM_TIME_MIN_NUM    (2)     // 最小的away随机时间点个数

#define AWAY_CYCLE_OK               (SDK_OK)     //AWAY cycle api 操作成功
#define AWAY_CYCLE_FAIL             (SDK_FAIL)    //AWAY cycle api 操作失败

/**
 * @brief  away cycle 链表结构体
*/
typedef struct
{
    away_cycle_data_t data;
    struct list_head list;
} away_cycle_t;

/**
 * @brief  away cycle管理对象结构体
*/
typedef struct
{
    bool away_cycle_running;
    uint32_t rnd_time_point_num;                       // away随机点数量
    uint32_t rnd_time_point[AWAY_RANDOM_TIME_MAX_NUM]; // away随机时间

    vesync_timer_t away_cycle_timer;

    uint32_t cycle_num;

    struct list_head cycle_list;
} away_mgt_t;

#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_AWAY_INTERNAL_H__ */



