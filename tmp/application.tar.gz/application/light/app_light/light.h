/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
* @file         light.h
* @brief        灯光控制接口
* @author       Joshua
* @date         2021-11-16
*/

#include <stdint.h>
#include <stdbool.h>
#include "vesync_common.h"

#include "app_cfg.h"

#ifndef __LIGHT_H__
#define __LIGHT_H__

#ifdef __cplusplus
extern "C" {
#endif

#ifndef LIGHT_BRIGHTNESS_MAX
#define LIGHT_BRIGHTNESS_MAX    (100)
#endif
#ifndef LIGHT_BRIGHTNESS_MIN
#define LIGHT_BRIGHTNESS_MIN    (0)
#endif
#ifndef LIGHT_COLOR_TEMP_MAX
#define LIGHT_COLOR_TEMP_MAX     (100)
#endif
#ifndef LIGHT_COLOR_TEMP_MIN
#define LIGHT_COLOR_TEMP_MIN     (0)
#endif
#ifndef LIGHT_HUE_MAX
#define LIGHT_HUE_MAX           (10000)
#endif
#ifndef LIGHT_HUE_MIN
#define LIGHT_HUE_MIN           (0)
#endif
#ifndef LIGHT_SATURATION_MAX
#define LIGHT_SATURATION_MAX    (10000)
#endif
#ifndef LIGHT_SATURATION_MIN
#define LIGHT_SATURATION_MIN    (0)
#endif
#ifndef LIGHT_VALUE_MAX
#define LIGHT_VALUE_MAX         (100)
#endif
#ifndef LIGHT_VALUE_MIN
#define LIGHT_VALUE_MIN         (0)
#endif
#ifndef LIGHT_FADE_ENABLE
#define LIGHT_FADE_ENABLE       (0)
#endif

#define LIGHT_PARAM_MAX_NUM   (100)
#define LIGHT_REFLESH_INTERVAL_MS   (1000)

/**
 * @brief 灯光状态
 */
typedef enum
{
    LIGHT_STATUS_OFF = 0,
    LIGHT_STATUS_ON = 1,
    LIGHT_STATUS_FLOW = 2,
    LIGHT_STATUS_SWITCH = 3,
    LIGHT_STATUS_MAX
} LIGHT_STATUS_E;


/**
 * @brief 灯光模式
 */
typedef enum
{
    LIGHT_MODE_WHITE = 0,
    LIGHT_MODE_COLOR = 1,
    LIGHT_MODE_MULTI = 2,
    LIGHT_MODE_MUSIC = 3,
    LIGHT_MODE_SCENE = 4,
    LIGHT_MODE_MAX
} LIGHT_MODE_E;


/**
 * @brief vesync_light灯光通道的枚举
 */
typedef enum
{
    LIGHT_CH_IDX_C = 0,
    LIGHT_CH_IDX_W = 1,
    LIGHT_CH_IDX_R = 2,
    LIGHT_CH_IDX_G = 3,
    LIGHT_CH_IDX_B = 4,
    LIGHT_CH_IDX_MAX = 5,
} LIGHT_CH_IDX_E;

/**
 * @brief 白光参数
 */
typedef struct
{
    uint8_t brightness;
    uint8_t color_temp;
} light_white_t;

/**
 * @brief 彩光参数
 */
typedef struct
{
    uint16_t H;                 // 色相
    uint16_t S;                 // 饱和度
    uint8_t V;                  // 明度
} light_color_t;

/**
 * @brief 灯光参数
 */
typedef struct
{
    uint8_t color_temp;         // 白光模式下的色温
    uint8_t brightness;         // 白光模式下的亮度
    uint16_t H;                 // 彩光模式下的色相
    uint16_t S;                 // 彩光模式下的饱和度
    uint8_t V;                  // 彩光模式下的明度
} light_param_t;

/**
 * @brief 灯光驱动控制数据结构
 */
typedef struct
{
    uint16_t r;
    uint16_t g;
    uint16_t b;
    uint16_t c;
    uint16_t w;
} light_ctrl_data_t;

/**
 * @brief 白光是否独立控制
 * @return bool           [是：true， 否：false]
 */
bool light_white_is_seperated(void);

/**
 * @brief 灯是否处于关闭状态
 * @return bool           [是：true， 否：false]
 */
bool light_is_off(void);

/**
 * @brief 灯光控制初始化
 * @return int           [成功：APP_OK， 失败：APP_FAIL]
 */
int app_light_init(void);


/**
 * @brief 白灯亮
 * @param[in] color_temp        [色温]
 * @param[in] brightness        [亮度]
 * @param[in] delay             [延迟执行时间（毫秒）]
 * @param[in] fade              [是否渐变]
 */
void app_light_white_on(uint8_t color_temp, uint8_t brightness, uint32_t delay, bool fade);

/**
 * @brief 白灯亮
 * @param[in] delay             [延迟执行时间（毫秒）]
 * @param[in] fade              [是否渐变]
 */
void app_light_white_off(uint32_t delay, bool fade);

/**
 * @brief 白灯呼吸
 * @param[in] color_temp        [色温]
 * @param[in] brightness        [亮度]
 * @param[in] times             [次数]
 * @param[in] delay             [延迟执行时间（毫秒）]
 */
void app_light_white_breath(uint8_t color_temp, uint8_t brightness, uint32_t times, uint32_t delay);

/**
 * @brief 白灯闪
 * @param[in] color_temp        [色温]
 * @param[in] brightness        [亮度]
 * @param[in] times             [次数]
 * @param[in] delay             [延迟执行时间（毫秒）]
 */
void app_light_white_blink(uint8_t color_temp, uint8_t brightness, uint32_t times, uint32_t delay);

/**
 * @brief 彩灯亮
 * @param[in] H          [色相]
 * @param[in] S          [饱和度]
 * @param[in] V          [明度]
 * @param[in] delay      [延迟执行时间（毫秒）]
 * @param[in] fade              [是否渐变]
 */
void app_light_color_on(uint16_t H, uint16_t S, uint8_t V, uint32_t delay, bool fade);

/**
 * @brief 彩灯灭
 * @param[in] delay      [延迟执行时间（毫秒）]
 * @param[in] fade       [是否渐变]
 */
void app_light_color_off(uint32_t delay, bool fade);

/**
 * @brief 彩灯闪
 * @param[in] H          [色相]
 * @param[in] S          [饱和度]
 * @param[in] V          [明度]
 * @param[in] times      [次数]
 * @param[in] delay      [延迟执行时间（毫秒）]
 */
void app_light_color_blink(uint16_t H, uint16_t S, uint8_t V, uint32_t times, uint32_t delay);

/**
 * @brief 彩灯呼吸
 * @param[in] H          [色相]
 * @param[in] S          [饱和度]
 * @param[in] V          [明度]
 * @param[in] times      [次数]
 * @param[in] delay      [延迟执行时间（毫秒）]
 */
void app_light_color_breath(uint16_t H, uint16_t S, uint8_t V, uint32_t times, uint32_t delay);

/**
 * @brief 流动
 * @param[in] *param              [灯效数据指针]
 * @param[in] param_num           [参数个数]
 * @param[in] flow_step           [流动步长]
 * @param[in] period              [渐变时长]
 * @param[in] delay               [延迟执行时间（毫秒）]
 * @param[in] overall             [是否整体变化]
 */
void app_light_color_flow(light_param_t *param, uint8_t param_num, uint8_t flow_step, uint32_t period, uint32_t delay, bool overall);

/**
 * @brief 红灯亮
 * @param[in] delay      [延迟执行时间（毫秒）]
 * @param[in] fade       [是否渐变]
 */
void app_light_red_on(uint32_t delay, bool fade);

/**
 * @brief 红灯闪
 * @param[in] times      [次数]
 * @param[in] delay      [延迟执行时间（毫秒）]
 */
void app_light_red_blink(uint32_t times, uint32_t delay);

/**
 * @brief 红灯呼吸
 * @param[in] times      [次数]
 * @param[in] delay      [延迟执行时间（毫秒）]
 */
void app_light_red_breath(uint32_t times, uint32_t delay);

/**
 * @brief 绿灯亮
 * @param[in] delay      [延迟执行时间（毫秒）]
 * @param[in] fade       [是否渐变]
 */
void app_light_green_on(uint32_t delay, bool fade);


/**
 * @brief 绿灯闪
 * @param[in] times      [次数]
 * @param[in] delay      [延迟执行时间（毫秒）]
 */
void app_light_green_blink(uint32_t times, uint32_t delay);

/**
 * @brief 绿灯呼吸
 * @param[in] times      [次数]
 * @param[in] delay      [延迟执行时间（毫秒）]
 */
void app_light_green_breath(uint32_t times, uint32_t delay);

/**
 * @brief 蓝灯亮
 * @param[in] delay      [延迟执行时间（毫秒）]
 * @param[in] fade       [是否渐变]
 */
void app_light_blue_on(uint32_t delay, bool fade);


/**
 * @brief 蓝灯闪
 * @param[in] times      [次数]
 * @param[in] delay      [延迟执行时间（毫秒）]
 */
void app_light_blue_blink(uint32_t times, uint32_t delay);

/**
 * @brief 蓝灯呼吸
 * @param[in] times      [次数]
 * @param[in] delay      [延迟执行时间（毫秒）]
 */
void app_light_blue_breath(uint32_t times, uint32_t delay);

/**
 * @brief 分段开
 * @param[in] *seg_param        [分段颜色参数]
 * @param[in] seg_num           [分段数]
 * @param[in] delay             [延迟执行时间（毫秒）]
 * @param[in] fade              [是否渐变]
 */
void app_light_segment_on(light_color_t *seg_param, uint8_t seg_num, uint32_t delay, bool fade);

/**
 * @brief 分段关
 * @param[in] delay             [延迟执行时间（毫秒）]
 * @param[in] fade              [是否渐变]
 */
void app_light_segment_off(uint32_t delay, bool fade);

#ifdef __cplusplus
}
#endif

#endif


