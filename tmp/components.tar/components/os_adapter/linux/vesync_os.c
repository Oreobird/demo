/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_os.c
 * @brief       os系统函数抽象层，封装linux系统相关接口
 * @author      Joshua
 * @date        2021-05-07
 */

#include <unistd.h>

/*
 * @brief  延时函数
 * @param[in]  ms                     [延时时间，毫秒]
 * @return none
 */
void vesync_sleep(int ms)
{
    usleep(ms*1000);
}


