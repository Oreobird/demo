/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_bypass_schedule.c
 * @brief       Bypass Schedule接口定义
 * @author      Herve Lin
 * @date        2021-06-29
 */
#include <string.h>

#include "vesync_common.h"
#include "vesync_memory.h"
#include "vesync_bypass_internal.h"
#include "vesync_timebase_internal.h"


/**
 * @brief "addScheduleV3" method数据解析
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  json                     [json数据指针]
 * @return BYPASS_ERR_E                 [错误码]
 */
static BYPASS_ERR_E bypass_method_add_schedule_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    BYPASS_ERR_E ret = BP_OK;

    bypass_schedule_base_t psch_base;
    memset(&psch_base, 0, sizeof(bypass_schedule_base_t));

    cJSON* json_data = cJSON_GetObjectItemCaseSensitive(json, "enabled");
    if (cJSON_IsBool(json_data))
    {
        psch_base.enabled = (int32_t *)&json_data->valueint;
    }
    else
    {
        ret = BP_ERR_ARG;
        goto EXIT;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "type");
    if (cJSON_IsNumber(json_data))
    {
        psch_base.type = (int32_t *)&json_data->valueint;
    }
    else
    {
        ret = BP_ERR_ARG;
        goto EXIT;
    }

    if (BYPASS_SCHEDULE_JSON_TYPE_TMG_EVT == *psch_base.type)
    {
        json_data = cJSON_GetObjectItemCaseSensitive(cJSON_GetObjectItemCaseSensitive(json, "tmgEvt"), "clkSec");
        if (cJSON_IsNumber(json_data))
        {
            psch_base.clock_sec = (int32_t *)&json_data->valueint;
        }
        else
        {
            ret = BP_ERR_ARG;
            goto EXIT;
        }
    }
    else if (BYPASS_SCHEDULE_JSON_TYPE_SUN_EVT == *psch_base.type)
    {
        json_data = cJSON_GetObjectItemCaseSensitive(cJSON_GetObjectItemCaseSensitive(json, "sunEvt"), "isRise");
        if (cJSON_IsBool(json_data))
        {
            psch_base.is_sunrise = (int32_t *)&json_data->valueint;
        }
        else
        {
            ret = BP_ERR_ARG;
            goto EXIT;
        }
        json_data = cJSON_GetObjectItemCaseSensitive(cJSON_GetObjectItemCaseSensitive(json, "sunEvt"), "ofsSec");
        if (cJSON_IsNumber(json_data))
        {
            psch_base.offset_sec = (int32_t *)&json_data->valueint;
        }
        else
        {
            ret = BP_ERR_ARG;
            goto EXIT;
        }
    }
    else
    {
        ret = BP_ERR_ARG;
        goto EXIT;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "repeat");
    if (cJSON_IsNumber(json_data) && vesync_timebase_is_rpt_valid(json_data->valueint))
    {
        psch_base.repeat_config = (int32_t *)&json_data->valueint;
    }
    else
    {
        ret = BP_ERR_ARG;
        goto EXIT;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "startAct");
    if (cJSON_IsArray(json_data) && cJSON_GetArraySize(json_data))
    {
        psch_base.json_action = json_data;     // startAct 指针传给应用层处理
    }
    else
    {
        ret = BP_ERR_ARG;
        goto EXIT;
    }

    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_ADD_SCHEDULE_V3);
    if (method_cb)
    {
        method_cb(p_msg_ctx, (void*)&psch_base);
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

EXIT:
    return ret;
}

/**
 * @brief "updScheduleV3" method数据解析
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  json                     [json数据指针]
 * @return BYPASS_ERR_E                 [错误码]
 */
static BYPASS_ERR_E bypass_method_upd_schedule_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    BYPASS_ERR_E ret = BP_OK;

    bypass_schedule_base_t psch_base;
    memset(&psch_base, 0, sizeof(bypass_schedule_base_t));

    cJSON* json_data = cJSON_GetObjectItemCaseSensitive(json, "id");
    if (cJSON_IsNumber(json_data))
    {
        psch_base.id = json_data->valueint;
    }
    else
    {
        ret = BP_ERR_ARG;
        goto EXIT;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "enabled");
    if (cJSON_IsBool(json_data))
    {
        psch_base.enabled = (int32_t *)&json_data->valueint;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "repeat");
    if (cJSON_IsNumber(json_data))
    {
        if (!vesync_timebase_is_rpt_valid(json_data->valueint))
        {
            ret = BP_ERR_ARG;
            goto EXIT;
        }
        psch_base.repeat_config = (int32_t *)&json_data->valueint;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "startAct");
    if (cJSON_IsArray(json_data) && cJSON_GetArraySize(json_data))
    {
        psch_base.json_action = json_data;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "type");
    if (cJSON_IsNumber(json_data))
    {
        psch_base.type = (int32_t *)&json_data->valueint;

        if (BYPASS_SCHEDULE_JSON_TYPE_TMG_EVT == *psch_base.type)
        {
            json_data = cJSON_GetObjectItemCaseSensitive(cJSON_GetObjectItemCaseSensitive(json, "tmgEvt"), "clkSec");
            if (cJSON_IsNumber(json_data))
            {
                psch_base.clock_sec = (int32_t *)&json_data->valueint;
            }
        }
        else if (BYPASS_SCHEDULE_JSON_TYPE_SUN_EVT == *psch_base.type)
        {
            json_data = cJSON_GetObjectItemCaseSensitive(cJSON_GetObjectItemCaseSensitive(json, "sunEvt"), "isRise");
            if (cJSON_IsBool(json_data))
            {
                psch_base.is_sunrise = (int32_t *)&json_data->valueint;
            }
            json_data = cJSON_GetObjectItemCaseSensitive(cJSON_GetObjectItemCaseSensitive(json, "sunEvt"), "ofsSec");
            if (cJSON_IsNumber(json_data))
            {
                psch_base.offset_sec = (int32_t *)&json_data->valueint;
            }
        }
        else
        {
            ret = BP_ERR_ARG;
            goto EXIT;
        }
    }

    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_UPD_SCHEDULE_V3);
    if (method_cb)
    {
        method_cb(p_msg_ctx, (void*)&psch_base);
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

EXIT:
    return ret;
}

/**
 * @brief "delScheduleV3" method数据解析
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  json                     [json数据指针]
 * @return BYPASS_ERR_E                 [错误码]
 */
static BYPASS_ERR_E bypass_method_del_schedule_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    BYPASS_ERR_E ret = BP_OK;
    int32_t pId = 0;


    cJSON* json_data = cJSON_GetObjectItemCaseSensitive(json, "id");
    if (cJSON_IsNumber(json_data))
    {
        pId = json_data->valueint;
    }
    else
    {
        ret = BP_ERR_ARG;
        goto EXIT;
    }

    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_DEL_SCHEDULE_V3);
    if (method_cb)
    {
        method_cb(p_msg_ctx, (void*)&pId);
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

EXIT:
    return ret;
}

/**
 * @brief "getSchedulesV3" method数据解析
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  json                     [json数据指针]
 * @return BYPASS_ERR_E                 [错误码]
 */
static BYPASS_ERR_E bypass_method_get_schedules_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    BYPASS_ERR_E ret = BP_OK;
    int32_t index = 0;

    cJSON* json_data = cJSON_GetObjectItemCaseSensitive(json, "index");
    if (cJSON_IsNumber(json_data))
    {
        index = json_data->valueint;
    }
    else
    {
        ret = BP_ERR_ARG;
        goto EXIT;
    }

    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_GET_SCHEDULES_V3);
    if (method_cb)
    {
        method_cb(p_msg_ctx, (void*)&index);
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

EXIT:
    return ret;
}

static bypass_item_data_t schedule_method_tbl[] = {
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_ADD_SCHEDULE_V3, "addScheduleV3", bypass_method_add_schedule_handle, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_UPD_SCHEDULE_V3, "updScheduleV3", bypass_method_upd_schedule_handle, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_DEL_SCHEDULE_V3, "delScheduleV3", bypass_method_del_schedule_handle, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_GET_SCHEDULES_V3, "getSchedulesV3", bypass_method_get_schedules_handle, NULL},
};

void vesync_bypass_schedule_init(void)
{
    for (int i = 0; i < SIZEOF_ARRAY(schedule_method_tbl); i++)
    {
        bypass_item_t *item = vesync_bypass_init_item(&schedule_method_tbl[i]);
        if (item != NULL)
        {
            vesync_bypass_add_item(item);
        }
    }
}
