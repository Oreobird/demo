/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        outlet_inching.c
 * @brief       outlet inching文件
 * @author      CharlesMei
 * @date        2021-06-23
 */


#include <stdint.h>
#include "vhal_flash.h"
#include "vesync_common.h"
#include "vesync_log.h"
#include "vesync_timer.h"
#include "vesync_klv.h"
#include "vesync_memory.h"
#include "outlet.h"
#include "outlet_gpio.h"
#include "outlet_inching.h"
#include "outlet_report.h"
#include "outlet_board.h"

#define SWITCH_INCHING_CFG_KEY_DATA     "inching_cfg"
#define SWITCH_INCHING_TIMER_NAME       "inching_timer"
#define STAT_CHG_RSN_INCHING_STR        "Inching"      // inching执行导致的状态变化


// inching参数
static inching_status_t s_inching_status;
// inching定时器句柄
static vesync_timer_t *s_inching_timer_hd = NULL;


/**
 * @brief       inching定时器回调函数
 * @note        倒数计数，1s循环，inching执行后对应定时器
 */
static void outlet_inching_timer_cb(void *args)
{
    outlet_ev_t ev = {
        id: OUTLET_EV_OFF,
        act_src: OUTLET_ACT_SRC_TASK,
        rsn: STAT_CHG_RSN_INCHING_STR
    };


    if (INCHING_STOP == s_inching_status.state)
    {
        // 处理定时器无法关闭，inching状态异常时
        return;
    }
    if (0 == s_inching_status.remain_sec)
    {
        outlet_app_task_notify(&ev);
        s_inching_status.state = INCHING_STOP;
        s_inching_status.remain_sec = s_inching_status.total_sec;
        if (s_inching_timer_hd)
        {
            vesync_timer_stop(s_inching_timer_hd);
        }
        return;
    }
    --(s_inching_status.remain_sec);
}

/**
 * @brief       outlet inching启动
 * @return      int         [成功：APP_OK；失败：APP_FAIL]
 */
int outlet_inching_start(void)
{
    if (0 != s_inching_status.total_sec && INCHING_COUNTDOWN != s_inching_status.state)
    {
        s_inching_status.remain_sec = s_inching_status.total_sec;

        if (NULL == s_inching_timer_hd)
        {
            APP_LOG(LOG_ERROR, "inching timer no exist!!!\r\n");
            return APP_FAIL;
        }
        if (VOS_OK != vesync_timer_start(s_inching_timer_hd))
        {
            APP_LOG(LOG_ERROR, "inching timer start fail!!!\r\n");
            return APP_FAIL;
        }
        s_inching_status.state = INCHING_COUNTDOWN;
        return APP_OK;
    }
    return APP_OK;
}

/**
 * @brief       outlet inching停止
 * @return      int         [成功：APP_OK；失败：APP_FAIL]
 */
int outlet_inching_stop(void)
{
    int ret = APP_FAIL;
    if (0 != s_inching_status.total_sec && INCHING_STOP != s_inching_status.state)
    {
        if (NULL == s_inching_timer_hd)
        {
            APP_LOG(LOG_ERROR, "inching timer no exist!!!\r\n");
            ret = APP_FAIL;
            goto exit;
        }
        if (VOS_OK != vesync_timer_stop(s_inching_timer_hd))
        {
            APP_LOG(LOG_ERROR, "inching timer stop fail!!!\r\n");
            ret = APP_FAIL;
            goto exit;
        }
        ret = APP_OK;
    }
    ret = APP_OK;
exit:
    s_inching_status.state = INCHING_STOP;
    s_inching_status.remain_sec = s_inching_status.total_sec;
    return ret;
}


/**
 * @brief       设置inching配置
 * @param[in]   total_sec   [inching配置的总时间]
 * @return      int         [成功：APP_OK；失败：APP_FAIL]
 */
static int outlet_inching_set_cfg(uint32_t total_sec)
{
    uint8_t *p_buf = NULL;
    int offset = 0;
    uint8_t version = 0;
    int ret = 0;

    outlet_inching_stop();
    s_inching_status.total_sec = total_sec;
    s_inching_status.remain_sec = total_sec;

    if(NULL == (p_buf = (uint8_t *)vesync_malloc(INCHING_KLV_DATA_BUF_LEN)))
    {
        APP_LOG(LOG_ERROR, "malloc fail!!\r\n");
        return APP_FAIL;
    }

    memset(p_buf, 0, INCHING_KLV_DATA_BUF_LEN);

    version = OUTLET_INCHING_CFG_VERSION;
    offset +=  vesync_klv_set(p_buf+offset, INCHING_KLV_DATA_BUF_LEN-offset, INCHING_KEY_VERSION, sizeof(version), &version);
    offset +=  vesync_klv_set(p_buf+offset, INCHING_KLV_DATA_BUF_LEN-offset, INCHING_KEY_TOTAL_SEC, sizeof(s_inching_status.total_sec), (uint8_t *)&s_inching_status.total_sec);

    if (VHAL_OK != vhal_flash_write(PARTITION_CFG,SWITCH_INCHING_CFG_KEY_DATA,p_buf,offset))
    {
        APP_LOG(LOG_ERROR, "inching_cfg save fail!\r\n");

        ret =  APP_FAIL;
    }

    vesync_free(p_buf);

    return ret;
}


/**
 * @brief       outlet inching增加配置
 * @param[in]   total_sec   [inching配置的总时间]
 * @return      int         [成功：APP_OK；失败：APP_FAIL]
 * @note        只支持一个配置，此函数即为设置配置
 */
int outlet_inching_add_cfg(uint32_t total_sec)
{
    return outlet_inching_set_cfg(total_sec);
}

/**
 * @brief       outlet inching删除配置
 * @return      int         [成功：APP_OK；失败：APP_FAIL]
 * @note        只支持一个配置，此函数同时会停止当前inching
 */
int outlet_inching_delete_cfg(void)
{
    return outlet_inching_set_cfg(0);
}

/**
 * @brief       outlet inching获取当前状态
 * @return      uint32_t    [inching状态]
 */
const inching_status_t* outlet_inching_get_status(void)
{
    return &s_inching_status;
}



/**
 * @brief       加载inching配置
 * @return      int         [成功：APP_OK；失败：APP_FAIL]
 */
static int outlet_inching_load_cfg(void)
{
    //uint32_t read_len = 0;
    uint32_t len = 0;
    uint8_t *p_buf= NULL;
    uint8_t version = 0;

    if(NULL == (p_buf = (uint8_t *)vesync_malloc(INCHING_KLV_DATA_BUF_LEN)))
    {
        return APP_FAIL;
    }

    len = INCHING_KLV_DATA_BUF_LEN;

    if(VHAL_OK != vhal_flash_read(PARTITION_CFG, SWITCH_INCHING_CFG_KEY_DATA, p_buf, &len))
    {
        APP_LOG(LOG_INFO, "inching_cfg load fail!!!\r\n");
        vesync_free(p_buf);
        return APP_FAIL;
    }

    memset(&s_inching_status, 0, sizeof(s_inching_status));
    vesync_klv_get(p_buf, len, INCHING_KEY_VERSION, sizeof(version), &version);
    vesync_klv_get(p_buf, len, INCHING_KEY_TOTAL_SEC, sizeof(s_inching_status.total_sec), (uint8_t *)&s_inching_status.total_sec);

    s_inching_status.remain_sec = s_inching_status.total_sec;
    s_inching_status.state = INCHING_STOP;
    APP_LOG(LOG_INFO, "inching_cfg load success.version =%d total =%d \r\n",version,s_inching_status.total_sec);

    vesync_free(p_buf);
    return APP_OK;
}

/**
 * @brief       outlet inching初始化
 */
void outlet_inching_init(void)
{
    outlet_inching_load_cfg();

    /* 1s循环扫描 */
    s_inching_timer_hd = vesync_timer_new(SWITCH_INCHING_TIMER_NAME,
                                                 outlet_inching_timer_cb,
                                                 NULL, 1000, true);
    if (NULL == s_inching_timer_hd)
    {
        APP_LOG(LOG_ERROR, "inching init fail!!!\r\n");
        return;
    }
    APP_LOG(LOG_INFO, "inching init success\r\n");
}
