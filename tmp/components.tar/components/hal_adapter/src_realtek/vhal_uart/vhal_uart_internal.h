/**
 *  Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vhal_uart_internal.h
 * @brief       Realtek平台串口配置参数
 * @author      Dongri.Su
 * @date        2021-04-28
 */

#ifndef __VHAL_UART_INTERNAL_H__
#define __VHAL_UART_INTERNAL_H__

#include <stdint.h>

#include "vhal_uart.h"


#ifdef __cplusplus
extern "C"
{
#endif

#define UART_BUF_SIZE               (1024)
#define UART_RECV_BUF_SIZE          (UART_BUF_SIZE)


#define UART_TIMEOUT_MS     300    // 3 sec


/*
 * @brief  串口收发状态
 */
typedef struct
{
    bool cfg_flag;                          // 配置（初始化）标志位，true表示该串口已被配置
    uint8_t uart_num;                       // 串口号
    serial_t uart_obj;                    // UART结构体
    vhal_uart_recv_cb_t recv_cb;            // 接收回调
} vhal_rtl_uart_status_t;


#ifdef __cplusplus
}
#endif

#endif  /* __VHAL_UART_INTERNAL_H__ */
