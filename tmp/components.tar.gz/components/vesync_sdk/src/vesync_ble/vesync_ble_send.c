/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_ble_send.c
 * @brief       BLE模块发送接口
 * @author      Louis
 * @date        2021-07-21
 */

#include <string.h>
#include <stdint.h>
#include <stdbool.h>

#include "vhal_ble.h"
#include "vesync_memory.h"
#include "vesync_queue.h"
#include "vesync_common.h"
#include "vesync_log_internal.h"
#include "vesync_loop_timer_internal.h"

#include "vesync_ble.h"
#include "vesync_ble_private.h"
#include "vesync_tl_frame_parse.h"

static vesync_queue_t *s_ble_ack_send_queue = NULL;
static vesync_queue_t *s_ble_req_send_queue = NULL;
static vesync_queue_t *s_ble_data_send_queue = NULL;

static uint8_t s_send_seq_id[BLE_DATA_CHAN_MAX] = {0};

static bool s_ble_data_send_busy = false;
static vesync_ble_data_t s_ble_req_send = {0};

static vloop_timer_header_t st_timer_header = {0}; // 定时器头部指针
static vloop_timer_t s_send_timeout_timer = {0};   // BLE发送超时重发定时器
static uint8_t s_send_repeat_cnt = 0;

/**
 * @brief  发送BLE数据，先缓存到发送队列
 * @param[in]  p_data           [数据指针]
 * @param[in]  len              [数据长度]
 * @param[in]  chan             [数据通道]
 * @param[in]  ack              [是否为ACK]
 * @param[in]  req              [是否需要对方回复]
 * @param[in]  err              [错误码]
 * @return     int32_t          [SDK_OK/SDK_FAIL]
 */
static int32_t vesync_ble_send_data(uint8_t *p_data, uint16_t len, BLE_DATA_CHAN_E chan,
                                    uint8_t ack, uint8_t req, uint8_t err)
{
    int32_t ret = SDK_OK;
    uint8_t *buf = NULL;
    uint16_t buf_len = 0;
    vesync_queue_t *ble_send_queue = NULL;
    vesync_ble_data_t send_data = {0};
    tl_frame_send_info_t frame_info = {0};

    if (vesync_ble_is_init() != true)
    {
        ret = SDK_FAIL;
        goto EXIT;
    }

    if (len > 0 && NULL == p_data)
    {
        ret = SDK_FAIL;
        goto EXIT;
    }

    if (!ack)
    {
        s_send_seq_id[chan]++;
        frame_info.seq_id = s_send_seq_id[chan];

        if (req)
        {
            ble_send_queue = s_ble_req_send_queue;
        }
        else
        {
            ble_send_queue = s_ble_data_send_queue;
        }
    }
    else
    {
        frame_info.seq_id = vesync_ble_get_recv_seq_id(chan);
        ble_send_queue = s_ble_ack_send_queue;
    }

    frame_info.payload_len = len;
    frame_info.p_payload = p_data;
    frame_info.ctrl.bitN.version = VESYNC_PROTOCO_VERSION;
    frame_info.ctrl.bitN.ack_flag = ack;
    frame_info.ctrl.bitN.request_flag = req;
    frame_info.ctrl.bitN.error_flag = err;

    buf_len = len + VESYNC_PROTOCO_HEAD_LEN;
    buf = vesync_malloc(buf_len);
    if (NULL == buf)
    {
        ret = SDK_FAIL;
        goto EXIT;
    }
    vesync_tl_frame_encode(&frame_info, buf, &buf_len);

    send_data.type = BLE_DATA_TYPE_SEND;
    send_data.chan = chan;
    send_data.p_data = buf;
    send_data.len = buf_len;

    if (VOS_OK != vesync_queue_send(ble_send_queue, &send_data, VESYNC_OS_NO_WAIT))
    {
        SDK_LOG(LOG_ERROR, "send failed\n");
        ret = SDK_FAIL;
        goto EXIT;
    }

    vesync_ble_sem_signal();

EXIT:
    if (SDK_FAIL == ret)
    {
        VCOM_SAFE_FREE(buf);
    }
    return ret;
}

/**
 * @brief  调用vhal接口将数据发送出去
 * @param[in]  ble_data         [BLE数据]
 */
static void vesync_ble_send_to_vhal(vesync_ble_data_t *ble_data)
{
    switch (ble_data->chan)
    {
    case BLE_DATA_CHAN_CMD:
        vhal_ble_cmd_data_send(ble_data->p_data, ble_data->len);
        break;
    case BLE_DATA_CHAN_NETCFG:
        vhal_ble_netcfg_data_send(ble_data->p_data, ble_data->len);
        break;
    default:
        // should not be here, return
        break;
    }
}

/**
 * @brief  发送后对端回复超时的回调处理函数
 * @param[in]  arg              [回调函数参数]
 */
static void vesync_ble_send_timeout_cb(void *arg)
{
    SDK_LOG(LOG_DEBUG, "BLE send timeout!\r\n");

    // 超时重发次数未达上限，继续重发并重置定时器
    if (s_send_repeat_cnt < VESYNC_BLE_SEND_REPEAT_MAX_CNT)
    {
        vesync_ble_send_to_vhal(&s_ble_req_send);
        s_send_repeat_cnt++;
        vesync_ble_add_send_timeout_timer();
    }
    else // 超时重发次数已达上限，重置通道，并释放信号量
    {
        VCOM_SAFE_FREE(s_ble_req_send.p_data);
        s_ble_data_send_busy = false;
        vesync_ble_sem_signal();
    }
}

/**
 * @brief  发送CMD数据
 * @param[in]  p_data           [数据指针]
 * @param[in]  len              [数据长度]
 * @param[in]  req_flag         [是否需要对端回复]
 * @return     int32_t          [SDK_OK/SDK_FAIL]
 */
int32_t vesync_ble_send_cmd_data(uint8_t *p_data, uint16_t len, uint8_t req_flag)
{
    return vesync_ble_send_data(p_data, len, BLE_DATA_CHAN_CMD, 0, req_flag, 0);
}

/**
 * @brief  发送CMD ACK
 * @param[in]  p_data           [数据指针]
 * @param[in]  len              [数据长度]
 * @param[in]  err_flag         [错误码]
 * @return     int32_t          [SDK_OK/SDK_FAIL]
 */
int32_t vesync_ble_send_cmd_ack(uint8_t *p_data, uint16_t len, uint8_t err_flag)
{
    return vesync_ble_send_data(p_data, len, BLE_DATA_CHAN_CMD, 1, 0, err_flag);
}

/**
 * @brief  发送NETCFG数据
 * @param[in]  p_data           [数据指针]
 * @param[in]  len              [数据长度]
 * @param[in]  req_flag         [是否需要对端回复]
 * @return     int32_t          [SDK_OK/SDK_FAIL]
 */
int32_t vesync_ble_send_netcfg_data(uint8_t *p_data, uint16_t len, uint8_t req_flag)
{
    return vesync_ble_send_data(p_data, len, BLE_DATA_CHAN_NETCFG, 0, req_flag, 0);
}

/**
 * @brief  发送NETCFG ACK
 * @param[in]  p_data           [数据指针]
 * @param[in]  len              [数据长度]
 * @param[in]  err_flag         [错误码]
 * @return     int32_t          [SDK_OK/SDK_FAIL]
 */
int32_t vesync_ble_send_netcfg_ack(uint8_t *p_data, uint16_t len, uint8_t err_flag)
{
    return vesync_ble_send_data(p_data, len, BLE_DATA_CHAN_NETCFG, 1, 0, err_flag);
}

/**
 * @brief  BLE模块发送初始化
 * @return     int32_t          [SDK_OK/SDK_FAIL]
 */
int32_t vesync_ble_send_init()
{
    s_ble_ack_send_queue = vesync_queue_new(VESYNC_BLE_SEND_ACK_QUEUE_MAX_NUM * sizeof(vesync_ble_data_t), sizeof(vesync_ble_data_t));
    if (NULL == s_ble_ack_send_queue)
    {
        SDK_LOG(LOG_ERROR, "queue create fail\n");
        return SDK_FAIL;
    }

    s_ble_req_send_queue = vesync_queue_new(VESYNC_BLE_SEND_REQ_QUEUE_MAX_NUM * sizeof(vesync_ble_data_t), sizeof(vesync_ble_data_t));
    if (NULL == s_ble_req_send_queue)
    {
        SDK_LOG(LOG_ERROR, "queue create fail\n");
        return SDK_FAIL;
    }

    s_ble_data_send_queue = vesync_queue_new(VESYNC_BLE_SEND_DATA_QUEUE_MAX_NUM * sizeof(vesync_ble_data_t), sizeof(vesync_ble_data_t));
    if (NULL == s_ble_data_send_queue)
    {
        SDK_LOG(LOG_ERROR, "queue create fail\n");
        return SDK_FAIL;
    }

    s_send_timeout_timer.reload = false;
    s_send_timeout_timer.period = VESYNC_SEND_REQUEST_TIMEOUT;
    s_send_timeout_timer.cb = vesync_ble_send_timeout_cb;

    return SDK_OK;
}

/**
 * @brief  BLE模块发送退出
 */
void vesync_ble_send_deinit()
{
    if (s_ble_ack_send_queue)
    {
        vesync_queue_free(s_ble_ack_send_queue);
        s_ble_ack_send_queue = NULL;
    }

    if (s_ble_req_send_queue)
    {
        vesync_queue_free(s_ble_req_send_queue);
        s_ble_req_send_queue = NULL;
    }

    if (s_ble_data_send_queue)
    {
        vesync_queue_free(s_ble_data_send_queue);
        s_ble_data_send_queue = NULL;
    }
}

/**
 * @brief  从发送队列中取出数据，然后调用vhal接口发送出去
 * @note   数据处理优先级：ACK数据、无需对端回复的数据、需要对端回复的数据
 */
int32_t vesync_ble_parse_send_data(void)
{
    int32_t ret = SDK_FAIL;
    vesync_ble_data_t ble_data_send = {0};

    // 优先处理ACK
    if (VOS_OK == vesync_queue_recv(s_ble_ack_send_queue, &ble_data_send, VESYNC_OS_NO_WAIT))
    {
        vesync_ble_send_to_vhal(&ble_data_send);
        VCOM_SAFE_FREE(ble_data_send.p_data);
        ret = SDK_OK;
    }

    // 接着处理REPORT（无需对端回复）
    if (VOS_OK == vesync_queue_recv(s_ble_data_send_queue, &ble_data_send, VESYNC_OS_NO_WAIT))
    {
        vesync_ble_send_to_vhal(&ble_data_send);
        VCOM_SAFE_FREE(ble_data_send.p_data);
        ret = SDK_OK;
    }

    // 最后处理REQUEST（需要对端回复）
    if (false == s_ble_data_send_busy &&
        VOS_OK == vesync_queue_recv(s_ble_req_send_queue, &s_ble_req_send, VESYNC_OS_NO_WAIT))
    {
        vesync_ble_send_to_vhal(&s_ble_req_send);

        s_send_repeat_cnt = 1;
        vesync_ble_add_send_timeout_timer();

        s_ble_data_send_busy = true;

        ret = SDK_OK;
    }

    // 任一队列读取到消息则可能还有其他消息，处理后需释放信号量，通知收发任务可以处理下一包了
    if (SDK_OK == ret)
    {
        vesync_ble_sem_signal();
    }
    return ret;
}

/**
 * @brief 添加超时重发定时器
 */
void vesync_ble_add_send_timeout_timer(void)
{
    vloop_timer_add(&st_timer_header, &s_send_timeout_timer);
}

/**
 * @brief 删除超时重发定时器
 */
void vesync_ble_del_send_timeout_timer(void)
{
    // 删除定时器后需要重置通道，并释放信号量通知收发任务继续处理下一包
    vloop_timer_del(&st_timer_header, &s_send_timeout_timer);
    VCOM_SAFE_FREE(s_ble_req_send.p_data);
    s_ble_data_send_busy = false;
    vesync_ble_sem_signal();
}

/**
 * @brief 处理已经超时的定时器
 * @return    uint64_t      [下一个即将超时定时器的时间ms]
 */
uint64_t vesync_ble_process_expired_timer(void)
{
    return vloop_timer_process_expired(&st_timer_header);
}

/**
 * @brief  获取发送的sequence id
 * @param[in]  chan                [数据通道]
 * @return     uint8_t             [sequence id]
 */
uint8_t vesync_ble_get_send_seq_id(BLE_DATA_CHAN_E chan)
{
    return s_send_seq_id[chan];
}
