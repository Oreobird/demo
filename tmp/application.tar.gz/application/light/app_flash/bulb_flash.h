/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
* @file         bulb_flash.h
* @brief        存储数据定义
* @author       Joshua
* @date         2021-12-2
*/

#include <stdint.h>

#ifndef __BULB_FLASH_H__
#define __BULB_FLASH_H__

#ifdef __cplusplus
extern "C" {
#endif

/*
* @brief 存储的flash数据
*/
typedef struct
{
    uint8_t poweron_num;         // 设备上电计次
    uint8_t aging_test_time;     // 老化测试时长记录
    uint8_t pre_aging_test_done; // 老化前灯效是否完成
} extra_cfg_t;


/**
 * @brief 配置数据key 定义
 */
typedef enum
{
    KEY_POWERNUM = EXTRA_CFG_SLOT,  // 上电时间
    KEY_PRE_AGING_TEST_DONE,        // 老化前灯效是否完成
    KEY_AGING_TEST_TIME,            // 老化测试时间
    KEY_MAX
} EXTRA_CFG_KEY_E;



#ifdef __cplusplus
}
#endif

#endif




