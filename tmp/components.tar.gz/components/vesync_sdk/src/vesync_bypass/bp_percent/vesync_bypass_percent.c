/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_bypass_percent.c
 * @brief       bypass处理接口
 * @date        2021-08-05
 */
#include <string.h>

#include "vesync_common.h"
#include "vesync_memory.h"
#include "vesync_bypass_internal.h"
#include "vesync_log_internal.h"


/**
 * @brief 设置百分比
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  json                     [json数据指针]
 * @return BYPASS_ERR_E
 */
static BYPASS_ERR_E bypass_method_set_percent_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    BYPASS_ERR_E ret = BP_OK;

    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    bypass_percent_t *p_data = (bypass_percent_t *)vesync_malloc(sizeof(bypass_percent_t));

    if (NULL == p_data)
    {
        return BP_ERR_NOMEM;
    }

    memset(p_data, 0, sizeof(bypass_percent_t));

    cJSON *json_data = cJSON_GetObjectItemCaseSensitive(json, "percent");
    if (cJSON_IsNumber(json_data))
    {
        p_data->percent = json_data->valueint;
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_SET_PERCENT);
    if (method_cb)
    {
        method_cb(p_msg_ctx, p_data);
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

_exit:
    vesync_free(p_data);
    return ret;

}

/**
 * @brief 调整百分比
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  json                     [json数据指针]
 * @return BYPASS_ERR_E
 */
static BYPASS_ERR_E bypass_method_adjust_percent_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{

    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    bypass_adjust_percent_t *p_data = (bypass_adjust_percent_t *)vesync_malloc(sizeof(bypass_adjust_percent_t));

    if (NULL == p_data)
    {
        return BP_ERR_NOMEM;
    }

    memset(p_data, 0, sizeof(bypass_adjust_percent_t));

    cJSON *json_data = cJSON_GetObjectItemCaseSensitive(json, "step");
    if (cJSON_IsNumber(json_data))
    {
        p_data->step = json_data->valueint;
    }
    else
    {
        vesync_free(p_data);
        return BP_ERR_ARG;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "rule");
    if (NULL != json_data)
    {
        // 可选字段 
        if (cJSON_IsNumber(json_data))
        {
            p_data->rule = (BP_PERCENT_RULE_E)json_data->valueint;
        }
        else
        {
            vesync_free(p_data);
            return BP_ERR_ARG;
        }
    }
    json_data = cJSON_GetObjectItemCaseSensitive(json, "type");
    if (NULL != json_data)
    {
        // 可选字段 
        if (!cJSON_IsString(json_data))
        {
            vesync_free(p_data);
            return BP_ERR_ARG;
        }
        memcpy(p_data->type, json_data->valuestring, sizeof(p_data->type) - 1);
    }

    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_ADJUST_PERCENT);
    if (method_cb)
    {
        method_cb(p_msg_ctx, p_data);
    }
    else
    {
        vesync_free(p_data);
        return BP_ERR_APP_CB_NULL;
    }

    return BP_OK;
}

/**
 * @brief 测试最低百分比
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  json                     [json数据指针]
 * @return BYPASS_ERR_E                 [错误码]
 */
static BYPASS_ERR_E bypass_method_test_min_percent_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    BYPASS_ERR_E ret = BP_OK;

    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    bypass_percent_t *p_data = (bypass_percent_t *)vesync_malloc(sizeof(bypass_percent_t));

    if (NULL == p_data)
    {
        return BP_ERR_NOMEM;
    }

    memset(p_data, 0, sizeof(bypass_percent_t));

    cJSON *json_data = cJSON_GetObjectItemCaseSensitive(json, "percent");
    if (cJSON_IsNumber(json_data))
    {
        p_data->percent = json_data->valueint;
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_TEST_MIN_PERCENT);
    if (method_cb)
    {
        method_cb(p_msg_ctx, p_data);
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

_exit:
    vesync_free(p_data);
    return ret;
}

/**
 * @brief 设置最低百分比
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  json                     [json数据指针]
 * @return BYPASS_ERR_E                 [错误码]
 */
static BYPASS_ERR_E bypass_method_set_min_percent_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    BYPASS_ERR_E ret = BP_OK;

    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    bypass_percent_t *p_data = (bypass_percent_t *)vesync_malloc(sizeof(bypass_percent_t));

    if (NULL == p_data)
    {
        return BP_ERR_NOMEM;
    }

    memset(p_data, 0, sizeof(bypass_percent_t));

    cJSON *json_data = cJSON_GetObjectItemCaseSensitive(json, "percent");
    if (cJSON_IsNumber(json_data))
    {
        p_data->percent = json_data->valueint;
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_SET_MIN_PERCENT);
    if (method_cb)
    {
        method_cb(p_msg_ctx, p_data);
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

_exit:
    vesync_free(p_data);
    return ret;
}

static bypass_item_data_t percent_method_tbl[] = {
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_SET_PERCENT, "setPercent", bypass_method_set_percent_handle, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_TEST_MIN_PERCENT, "testMinPercent", bypass_method_test_min_percent_handle, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_SET_MIN_PERCENT, "setMinPercent", bypass_method_set_min_percent_handle, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_ADJUST_PERCENT, "adjustPercent", bypass_method_adjust_percent_handle, NULL}
};

void vesync_bypass_percent_init(void)
{
    for (int i = 0; i < SIZEOF_ARRAY(percent_method_tbl); i++)
    {
        bypass_item_t *item = vesync_bypass_init_item(&percent_method_tbl[i]);
        if (item != NULL)
        {
            vesync_bypass_add_item(item);
        }
    }
}

