/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        switch_uart_cmd.h
 * @brief       switch串口命令头文件
 * @author      Charles.Mei
 * @date        2021-08-02
 */


#include <stdint.h>

#include "vesync_uart.h"
#include "vesync_bypass.h"
#include "vesync_wifi_led.h"
#include "vesync_production.h"

#include "switch_app.h"

#ifndef __SWITCH_UART_CMD_H__
#define __SWITCH_UART_CMD_H__

#ifdef __cplusplus
     extern "C" {
#endif


#define UART_TL_PROT_PAYLOAD_VER                (2)         // 串口通信协议payload版本


typedef enum
{
    OP_REPORT               = 0x6000,
    OP_INQUIRY              = 0x6001,
    OP_SET_MIN_LIGHTNESS    = 0x6002,
    OP_TEST_LIGHT           = 0x6003,
    OP_SET_LIGHT_MOD        = 0x5027,
    OP_SET_SWITCH           = 0x5000,
    OP_SET_LEVEL            = 0x5006,
    OP_CTR_WIFI_LED         = 0x5018,
    OP_TEST_UART            = 0x5208,
    OP_REST_MCU             = 0x5301,
    OP_ENTER_NETCFG         = 0x5302,
    OP_REST_WIFI            = 0x5303,
    OP_TEST_WIFI            = 0x5304,
    OP_SET_PRODUCTION_STATE = 0x5205,
    OP_SET_PRODUCTION_RESULT= 0x5206,
} OPCODE_E;

typedef enum
{
    RESET_RANK_RESTART =            0,      // 重启MCU
    RESET_RANK_FACTORY =            1,      // MCU恢复出厂并重启
    RESET_RANK_ONLY_CLEAR_DATA =    2,      // MCU恢复出厂不重启
    RESET_RANK_MAX
} MCU_RESET_RANK_E;


/**
 * @brief  switch查询设备状态
 * @return     int                      [成功：APP_OK，失败：APP_FAIL]
 */
int switch_uart_inquire_status(void);

/**
 * @brief  switch设置灯最低亮度
 * @param[in]  min_lightness            [灯最低亮度亮度]
 * @param[in]  src                      [请求来源]
 * @param[in]  p_trace_msg              [bypass跟踪数据]
 * @return     int                      [成功：APP_OK，失败：APP_FAIL]
 */
int switch_uart_set_min_lightness(uint8_t min_lightness, bypass_trace_msg_t *p_trace_msg);

/**
 * @brief  switch最低亮度测试
 * @param[in]  min_lightness            [灯最低亮度]
 * @param[in]  test_time                [测试执行时间]
 * @param[in]  src                      [请求来源]
 * @param[in]  p_trace_msg              [bypass跟踪数据]
 * @return     int                      [成功：APP_OK，失败：APP_FAIL]
 */
int switch_uart_test_min_lightness(uint8_t min_lightness, uint8_t test_time, bypass_trace_msg_t *p_trace_msg);

/**
 * @brief  switch调光模式
 * @param[in]  light_mode               [调光模式]
 * @param[in]  src                      [请求来源]
 * @param[in]  p_trace_msg              [bypass跟踪数据]
 * @return     int                      [成功：APP_OK，失败：APP_FAIL]
 */
int switch_uart_set_light_mode(uint8_t light_mode, bypass_trace_msg_t *p_trace_msg);

/**
 * @brief  switch设置开关
 * @param[in]  dev_id                   [子设备id，见DEVICE_ID_E]
 * @param[in]  onoff                    [0:关闭；1：开启]
 * @param[in]  exec_time                [执行时间，控制灯时有效，其它无效]
 * @param[in]  src                      [请求来源]
 * @param[in]  p_trace_msg              [bypass跟踪数据]
 * @return     int                      [成功：APP_OK，失败：APP_FAIL]
 */
int switch_uart_set_switch(DEVICE_ID_E dev_id, uint8_t onoff, uint16_t exec_time, bypass_trace_msg_t *p_trace_msg);

/**
 * @brief  switch设置档位
 * @param[in]  dev_id                   [子设备id，见DEVICE_ID_E]
 * @param[in]  level                    [灯代表亮度，风扇代表档位]
 * @param[in]  exec_time                [执行时间，控制灯时有效，其它无效]
 * @param[in]  src                      [请求来源]
 * @param[in]  p_trace_msg              [bypass跟踪数据]
 * @return     int                      [成功：APP_OK，失败：APP_FAIL]
 */
int switch_uart_set_level(DEVICE_ID_E dev_id, uint8_t level, uint16_t exec_time, bypass_trace_msg_t *p_trace_msg);

/**
 * @brief  switch设置灯亮度
 * @param[in]  level                    [灯亮度]
 * @param[in]  exec_time                [执行时间，非零时有效]
 * @param[in]  src                      [请求来源]
 * @param[in]  p_trace_msg              [bypass跟踪数据]
 * @return     int                      [成功：APP_OK，失败：APP_FAIL]
 */
int switch_uart_set_lightness(uint8_t lightness, uint16_t exec_time, bypass_trace_msg_t *p_trace_msg);

/**
 * @brief  设置wifi指示灯
 * @param[in]  led                      [WI-FI灯配置]
 * @return     int                      [成功：APP_OK，失败：APP_FAIL]
 */
int switch_uart_set_wifi_led(wifi_led_cfg_t led);

/**
 * @brief  串口测试命令
 * @return     int                      [成功：APP_OK，失败：APP_FAIL]
 */
int switch_uart_test_cmd(void);

/**
 * @brief  重置MCU
 * @param[in]  rank                     [重置等级]
 * @param[in]  src                      [请求来源]
 * @param[in]  p_trace_msg              [bypass跟踪数据]
 * @return     int                      [成功：APP_OK，失败：APP_FAIL]
 */
int switch_uart_reset_mcu(MCU_RESET_RANK_E rank, bypass_trace_msg_t *p_trace_msg);

/**
 * @brief  通知产测状态
 * @param[in]  state                    [产测状态]
 * @return     int                      [成功：APP_OK，失败：APP_FAIL]
 */
int switch_uart_set_production_state(PRODUCTION_STATUS_E state);

/**
 * @brief  通知产测结果
 * @param[in]  err_code                 [产测结果]
 * @return     int                      [成功：APP_OK，失败：APP_FAIL]
 */
int switch_uart_set_production_result(PRODUCTION_ERROR_E err_code);

#ifdef __cplusplus
}
#endif

#endif

