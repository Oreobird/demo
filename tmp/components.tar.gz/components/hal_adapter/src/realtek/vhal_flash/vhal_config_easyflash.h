/**
 *  Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vhal_config_easyflash.h
 * @brief       配置easyflash的参数
 * @author      Louis
 * @date        2021-04-23
 */

#ifndef __VHAL_CONFIG_EASYFLASH_H__
#define __VHAL_CONFIG_EASYFLASH_H__


#ifdef __cplusplus
extern "C" {
#endif

// AmebaZ2 方案，默认只有2MB flash, 用户分区基地址(64KB + 2*sizeKB)，分区表partition.json
// 其中，RTL8710CX的OTA分区大小为768KB，而RTL8720CF的OTA分区大小为864KB。另外，OTA分区必须是16KB的倍数。
#if defined(CONFIG_TARGET_RTL8720CF)
#define VHAL_SPI_FLASH_BASE                 (0x10000 + 0xD8000 + 0xD8000)
#elif defined(CONFIG_TARGET_RTL8710CX)
#define VHAL_SPI_FLASH_BASE                 (0x10000 + 0xC0000 + 0xC0000)
#endif

#define VHAL_SPI_FLASH_SEC_SIZE             (0x1000)       // SPI flash一个扇区大小为4K
#define CONFIG_EASYFLASH_ENV_ADDR           (VHAL_SPI_FLASH_BASE + VHAL_SPI_FLASH_SEC_SIZE) //第一个扇区用来存放产测数据
#define CONFIG_EASYFLASH_ENV_SIZE           (0x20000)       // 128k
#define CONFIG_EASYFLASH_ERASE_MIN_SIZE     (VHAL_SPI_FLASH_SEC_SIZE)       // SPI flash一个扇区大小为4K

#ifdef __cplusplus
}
#endif

#endif /* __VHAL_CONFIG_EASYFLASH_H__ */
