/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        led_strip_bypass.c
 * @brief       led strip bypass通信接口
 * @author      Henrik
 * @date        2021-11-01
 */
#include <stdint.h>
#include <string.h>

#include "vesync_common.h"
#include "vesync_log.h"
#include "vesync_memory.h"
#include "vesync_buffer.h"
#include "vesync_bypass.h"
#include "vesync_timing.h"
#include "vesync_device.h"

#include "led_strip.h"
#include "led_strip_timing.h"
#include "led_strip_schedule.h"
#include "led_strip_bypass.h"
#include "led_strip_production.h"
#include "led_strip_report.h"
#include "led_strip_scene.h"
#include "led_strip_flash.h"


static bool s_ls_voice_off_flag = false; // 第三方语音设置亮度为0，标志位（认证需求）


/**
* @brief 设置语音关闭标志位，
* @param[in]  flag          [true:语音导致灯带关闭;false:当前状态不是语音关闭]
*/
void led_strip_set_voice_off_flag(bool flag)
{
    s_ls_voice_off_flag = flag;
}

/**
* @brief 新增timer
* @note  新增bypass method
* @param[in]        p_msg_ctx       [bypass上下文]
* @param[in]        json            [传入json]
* @return           BYPASS_ERR_E    [错误码]
*/
static BYPASS_ERR_E ls_bp_add_timer(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    ls_timing_t action ;
    cJSON* json_data = NULL;
    cJSON* json_timer = NULL;
    cJSON* json_obj = NULL;
    cJSON* json_act = NULL;
    cJSON* json_type = NULL;
    int ret = 0;

    if (NULL == p_msg_ctx || NULL == p_msg_ctx->p_trace_msg || NULL == json)
    {
        APP_LOG(LOG_DEBUG, " addTimerV2 error \n");
        return BP_ERROR;
    }

    APP_LOG(LOG_DEBUG, "-------addTimerV2 handle--------\n");

    memset(&action, 0, sizeof(ls_timing_t));

    json_data = cJSON_GetObjectItemCaseSensitive(json, "total");
    if (cJSON_IsNumber(json_data))
    {
         action.total_sec = json_data->valueint;
         VCOM_IN_RANGE_CHK(action.total_sec, TIMER_SEC_MIN, TIMER_SEC_MAX, (ret++));
         if (ret)
         {
            return BP_ERR_ARG;
         }
    }
    else
    {
        return BP_ERR_ARG;
    }
    json_data = cJSON_GetObjectItemCaseSensitive(json, "startAct");
    if (!cJSON_IsArray(json_data))
    {
        return BP_ERR_ARG;
    }
    int arr_size = cJSON_GetArraySize(json_data);
    if (arr_size > 2)
    {
        return BP_ERR_ARG;
    }
    for (int i = 0; i < arr_size; i++)
    {
        json_obj = cJSON_GetArrayItem(json_data, i);
        if (NULL == json_obj)
        {
            return BP_ERR_ARG;
        }
        json_type = cJSON_GetObjectItemCaseSensitive(json_obj, "type");
        if (0 == strcmp(json_type->valuestring, "switch"))
        {
            json_act = cJSON_GetObjectItemCaseSensitive(json_obj, "act");
            if (0 == strcmp(json_act->valuestring, "off"))
            {
                action.ctrl.action = LS_STATUS_OFF;
                break;
            }
            else
            {
                action.ctrl.action = LS_STATUS_ON;
            }
        }
        else if (0 == strcmp(json_type->valuestring, "change_scene"))
        {
            json_act = cJSON_GetObjectItemCaseSensitive(json_obj, "act");
            if (!cJSON_IsString(json_act))
            {
                return BP_ERR_ARG;
            }

            cJSON *json_param = NULL;
            cJSON *json_id = NULL;
            if (0 == strcmp(json_act->valuestring, "manual"))
            {
                json_param = cJSON_GetObjectItemCaseSensitive(json_obj, "params");
                if (NULL == json_param)
                {
                    return BP_ERR_ARG;
                }

                json_id = cJSON_GetObjectItemCaseSensitive(json_param, "sceneId");
                if (NULL == json_id)
                {
                    return BP_ERR_ARG;
                }
                else
                {
                    ret = led_strip_scene_id_check(json_id->valueint, &(action.ctrl.id));
                    if (APP_OK != ret)  // 场景不存在
                    {
                        vesync_bypass_reply_pkg_err_msg(ret, p_msg_ctx->p_trace_msg, NULL);
                        return BP_OK;
                    }
                }
            }
            else
            {
                return BP_ERR_ARG;
            }

            VCOM_IN_RANGE_CHK(action.ctrl.id, 0, SCENE_CUSTOM_MAX_ID, (ret++));
            if (ret != 0)
            {
                return BP_ERR_ARG;
            }

        }
        else
        {
            return BP_ERR_ARG;
        }
    }


    if (APP_OK == led_strip_timing_add(action.total_sec, &(action.id), action.ctrl))
    {
        json_timer = cJSON_CreateObject();
        if (NULL != json_timer)
        {
            cJSON_AddNumberToObject(json_timer, "id", action.id);
            APP_LOG(LOG_DEBUG,"add timer %d\n", action.id);
            vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, json_timer);
        }
        else
        {
            return BP_ERR_NOMEM;
        }
    }
    else
    {
        return BP_ERROR;
    }

    return BP_OK;
}

/**
* @brief 获取timer
* @note  新增bypass method
* @param[in]        p_msg_ctx       [bypass上下文]
* @param[in]        json            [传入json]
* @return           BYPASS_ERR_E    [错误码]
*/
static BYPASS_ERR_E ls_bp_get_timer(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    BYPASS_ERR_E ret = BP_OK;
    uint16_t timer_id = 0;
    ls_timing_t *timing = NULL;
    cJSON *json_data = NULL;
    cJSON *json_timers = NULL;
    cJSON *json_timer = NULL;
    cJSON *json_arr = NULL;
    cJSON *json_mode = NULL;
    cJSON *json_action = NULL;
    cJSON *json_params = NULL;
    timing_data_t tm;
    memset(&tm, 0, sizeof(timing_data_t));

    if (NULL == p_msg_ctx || NULL == p_msg_ctx->p_trace_msg)
    {
        return BP_ERROR;
    }
    UNUSED(json);

    json_data = cJSON_CreateObject();
    if (NULL == json_data)
    {
        return BP_ERR_NOMEM;
    }
    cJSON_AddItemToObject(json_data, "timers", json_timers =  cJSON_CreateArray());
    if (NULL == json_timers)
    {
        ret = BP_ERR_NOMEM;
        goto exit;
    }

    timing = led_strip_timing_get_act();
    timer_id = timing->id;
    if (timer_id == 0)
    {
        vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, json_data);
        return BP_OK;
    }
    if (SDK_OK == vesync_timing_get(timer_id, &tm))
    {
        cJSON_AddItemToArray(json_timers, json_timer = cJSON_CreateObject());
        if (NULL == json_timer)
        {
            ret = BP_ERR_NOMEM;
            goto exit;
        }
        cJSON_AddNumberToObject(json_timer, "id", tm.timing_id);
        cJSON_AddNumberToObject(json_timer, "total", tm.total_second);
        cJSON_AddNumberToObject(json_timer, "remain", tm.remain_second);
        // package
        cJSON_AddItemToObject(json_timer, "startAct", json_arr = cJSON_CreateArray());
        cJSON_AddItemToArray(json_arr, json_mode = cJSON_CreateObject());
        if (NULL == json_arr || NULL == json_mode)
        {
            ret = BP_ERR_NOMEM;
            goto exit;
        }
        cJSON_AddStringToObject(json_mode, "type", "switch");
        cJSON_AddNumberToObject(json_mode, "num", 0);
        if (timing->ctrl.action == LS_STATUS_OFF)
        {
            cJSON_AddStringToObject(json_mode, "act", "off");
        }
        else
        {
            cJSON_AddStringToObject(json_mode, "act", "on");
            cJSON_AddItemToArray(json_arr, json_action = cJSON_CreateObject());
            if (NULL == json_action)
            {
                ret = BP_ERR_NOMEM;
                goto exit;
            }
            cJSON_AddStringToObject(json_action, "type", "change_scene");
            cJSON_AddStringToObject(json_action, "act", "manual");
            cJSON_AddNumberToObject(json_action, "num", 0);
            cJSON_AddItemToObject(json_action, "params",json_params = cJSON_CreateObject());
            if (NULL == json_params)
            {
                ret = BP_ERR_NOMEM;
                goto exit;
            }
            cJSON_AddNumberToObject(json_params, "sceneId", timing->ctrl.id);
        }

    }

    vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, json_data);
    return BP_OK;

exit:
    vesync_bypass_reply_pkg_err_msg(ret, p_msg_ctx->p_trace_msg, NULL);
    cJSON_Delete(json_data);
    return ret;
}

/**
* @brief 删除timer
* @note  新增bypass method
* @param[in]        p_msg_ctx       [bypass上下文]
* @param[in]        json            [传入json]
* @return           BYPASS_ERR_E    [错误码]
*/
static BYPASS_ERR_E ls_bp_del_timer(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    if (NULL == p_msg_ctx || NULL == p_msg_ctx->p_trace_msg || NULL == json)
    {
        return BP_ERROR;
    }

    cJSON *json_data = cJSON_GetObjectItemCaseSensitive(json, "id");
    if (cJSON_IsNumber(json_data))
    {
        if (APP_OK == led_strip_timing_remove(json_data->valueint))
        {
            cJSON *json_ret = cJSON_CreateObject();
            if (NULL != json_ret)
            {
                cJSON_AddNumberToObject(json_ret, "id", json_data->valueint);
            }
            vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, json_ret);
        }
        else
        {
            vesync_bypass_reply_pkg_err_msg(BP_ERR_TIMER_NOT_FOUND, p_msg_ctx->p_trace_msg, "Timer remove fail");
        }
    }
    else
    {
        return BP_ERR_ARG;
    }

    return BP_OK;
}


/**
* @brief ledstrip bypass 添加Schedule回调接口
* @param[in]  p_msg_ctx                [msg context]
* @param[in]  p_data                   [回调函数传入数据]
*/
static void ls_bp_add_schedule(bypass_msg_ctx_t *p_msg_ctx, void *p_data)
{
    int error_code = BP_ERR_ARG;

    if(NULL == p_data)
    {
        vesync_bypass_reply_pkg_err_msg(BP_ERR_PARA_ILLEGAL, p_msg_ctx->p_trace_msg, BP_ERR_PARAM_CONV(p_data, BP_ERR_PARAM_NULL_PTR));
        return;
    }

    uint32_t sch_id = 0;
    cJSON *json_sch_ret = NULL;
    bypass_schedule_base_t *p_bp_sch = (bypass_schedule_base_t *)p_data;

    error_code = led_strip_schedule_add(p_bp_sch, &sch_id);
    if (BP_ERR_NO_ERR == error_code)
    {
        // 添加成功，生成回应
        json_sch_ret = cJSON_CreateObject();
        if (NULL != json_sch_ret)
        {
            cJSON_AddNumberToObject(json_sch_ret, "id", sch_id);
        }
    }

    vesync_bypass_reply_noqos(error_code, p_msg_ctx->p_trace_msg, json_sch_ret);
}

/**
* @brief Outlet bypass 更新Schedule回调接口
* @param[in]  p_msg_ctx                [msg context]
* @param[in]  p_data                   [回调函数传入数据]
*/
static void ls_bp_upd_schedule(bypass_msg_ctx_t *p_msg_ctx, void *p_data)
{
    int error_code = BP_ERR_PARA_ILLEGAL;

    if(NULL == p_data)
    {
        vesync_bypass_reply_pkg_err_msg(BP_ERR_PARA_ILLEGAL, p_msg_ctx->p_trace_msg, BP_ERR_PARAM_CONV(p_data, BP_ERR_PARAM_NULL_PTR));
        return;
    }

    uint32_t sch_id = 0;
    cJSON *json_sch_ret = NULL;
    bypass_schedule_base_t *p_bp_sch = (bypass_schedule_base_t *)p_data;

    error_code = led_strip_schedule_upd(p_bp_sch, &sch_id);
    if (BP_ERR_NO_ERR == error_code)
    {
        // 更新成功，生成回应
        json_sch_ret = cJSON_CreateObject();
        if (NULL != json_sch_ret)
        {
            cJSON_AddNumberToObject(json_sch_ret, "id", sch_id);
        }
    }

    vesync_bypass_reply_noqos(error_code, p_msg_ctx->p_trace_msg, json_sch_ret);
}

/**
* @brief Outlet bypass 删除Schedule回调接口
* @param[in]  p_msg_ctx                [msg context]
* @param[in]  p_data                   [回调函数传入数据]
*/
static void ls_bp_del_schedule(bypass_msg_ctx_t *p_msg_ctx, void *p_data)
{
    APP_LOG(LOG_DEBUG, "del schedule \n");
    int error_code = BP_ERR_PARA_ILLEGAL;

    if(NULL == p_data)
    {
        vesync_bypass_reply_pkg_err_msg(BP_ERR_PARA_ILLEGAL, p_msg_ctx->p_trace_msg, BP_ERR_PARAM_CONV(p_data, BP_ERR_PARAM_NULL_PTR));
        return;
    }

    uint32_t sch_id = *((uint32_t *)p_data);
    cJSON *json_sch_ret = NULL;

    error_code = led_strip_schedule_del(sch_id);
    if (BP_ERR_NO_ERR == error_code)
    {
        // 删除成功，生成回应
        json_sch_ret = cJSON_CreateObject();
        if (NULL != json_sch_ret)
        {
            cJSON_AddNumberToObject(json_sch_ret, "id", sch_id);
        }
    }

    vesync_bypass_reply_noqos(error_code, p_msg_ctx->p_trace_msg, json_sch_ret);
}


/**
* @brief 生成Schedule配置项列表的JSON
* @param[in] json_array    [JSON数组根对象]
* @param[in] p_list        [Schedule配置项列表]
* @param[in] list_len      [列表的最大长度,注意大于等于列表内的配置项数量]
* @return      int         [Bypass定义的错误]
*/
static int schedule_list_json_marshal(void *json_array, bypass_schedule_base_t *p_list, uint32_t list_len)
{
    cJSON *p_out = (cJSON *)json_array;

    if (!cJSON_IsArray(p_out))
    {
        return BP_ERR_PARA_ILLEGAL;
    }

    for (uint32_t cnt = 0; cnt < list_len; cnt++)
    {
        // 判断列表结束
        if (0 == p_list[cnt].id)
        {
            break;
        }

        cJSON *sch_obj = cJSON_CreateObject();
        cJSON *sub_obj = NULL;
        uint8_t type = *((uint8_t *)p_list[cnt].type);

        if (NULL == sch_obj)
        {
            APP_LOG(LOG_ERROR,"creat error!\n");
            return BP_ERROR;
        }

        cJSON_AddNumberToObject(sch_obj, "id", p_list[cnt].id);
        cJSON_AddBoolToObject(sch_obj, "enabled", *((bool *)p_list[cnt].enabled));
        cJSON_AddItemToObject(sch_obj, "startAct", (cJSON*)p_list[cnt].json_action);
        cJSON_AddNumberToObject(sch_obj, "type", type);
        if (BYPASS_SCHEDULE_JSON_TYPE_TMG_EVT == type)
        {
            sub_obj = cJSON_AddObjectToObject(sch_obj, "tmgEvt");

            cJSON_AddNumberToObject(sub_obj, "clkSec", *p_list[cnt].clock_sec);
        }
        else if (BYPASS_SCHEDULE_JSON_TYPE_SUN_EVT == type)
        {
            sub_obj = cJSON_AddObjectToObject(sch_obj, "sunEvt");

            cJSON_AddBoolToObject(sub_obj, "isRise", *((bool *)p_list[cnt].is_sunrise));
            cJSON_AddNumberToObject(sub_obj, "ofsSec", *p_list[cnt].offset_sec);
        }

        cJSON_AddNumberToObject(sch_obj, "repeat", *((uint8_t *)p_list[cnt].repeat_config));
        cJSON_AddItemToArray(p_out, sch_obj);
    }

    return BP_ERR_NO_ERR;
}


/**
* @brief bypass 查询Schedule回调接口
* @param[in]  p_msg_ctx                [msg context]
* @param[in]  p_data                   [回调函数传入数据]
*/
static void ls_bp_get_schedules(bypass_msg_ctx_t *p_msg_ctx, void *p_data)
{
    int error_code = BP_ERR_PARA_ILLEGAL;

    if(NULL == p_data)
    {
        vesync_bypass_reply_pkg_err_msg(BP_ERR_PARA_ILLEGAL, p_msg_ctx->p_trace_msg, BP_ERR_PARAM_CONV(p_data, BP_ERR_PARAM_NULL_PTR));
        return;
    }

    uint32_t index = *((uint32_t *)p_data);
    cJSON *json_sch_ret = NULL;
    cJSON *json_array = NULL;
    // 配置项总数
    uint32_t total_num = 0;
    void *mult_sche_buf = NULL;

    // 输出列表
    bypass_schedule_base_t sch_bp_list[LS_SCHEDULE_GET_MAX_NUM];
    // 初始化输出列表
    memset(sch_bp_list, 0, sizeof(bypass_schedule_base_t) * LS_SCHEDULE_GET_MAX_NUM);
    // 读取配置项
    error_code = led_strip_schedule_get_mult(index, &mult_sche_buf, sch_bp_list, &total_num);
    if (BP_ERR_NO_ERR == error_code)
    {
        // 查询成功，生成回应
        json_sch_ret = cJSON_CreateObject();
        if (NULL != json_sch_ret)
        {
            cJSON_AddNumberToObject(json_sch_ret, "total", total_num);
            json_array = cJSON_AddArrayToObject(json_sch_ret, "schedules");
            // 把配置项列表生成JSON添加到回应的JSON
            error_code =  schedule_list_json_marshal(json_array, sch_bp_list, LS_SCHEDULE_GET_MAX_NUM);
        }
    }

    if (BP_ERR_SCHEDULE_NOT_FOUND == error_code)
    {
        error_code = BP_ERR_NO_ERR;

        // 生成空回应
        json_sch_ret = cJSON_CreateObject();
        if (NULL != json_sch_ret)
        {
            cJSON_AddNumberToObject(json_sch_ret, "total", total_num);
            cJSON_AddArrayToObject(json_sch_ret, "schedules");
        }
    }

    // 释放配置读取内存
    vesync_free(mult_sche_buf);
    vesync_bypass_reply_noqos(error_code, p_msg_ctx->p_trace_msg, json_sch_ret);
}


/**
* @brief 设置开关开启/关闭
* @param[in]  p_msg_ctx                [msg context]
* @param[in]  p_data                   [回调函数传入数据]
*/
static void ls_bp_set_switch_onoff(bypass_msg_ctx_t *p_msg_ctx, void *p_data)
{
    if (NULL == p_data)
    {
        vesync_bypass_reply_pkg_err_msg(BP_ERR_PARA_ILLEGAL, p_msg_ctx->p_trace_msg, BP_ERR_PARAM_CONV(p_data, BP_ERR_PARAM_NULL_PTR));
        return;
    }
    bypass_switch_data_t *p_sw = (bypass_switch_data_t*)p_data;
    ls_info_t *hsv_info = NULL;
    ls_ev_t ev;
    ev.event = LS_EV_CHANGE_SCENE;
    ev.act_src = LS_ACT_SRC_BYPASS;
    ev.scene_type = SCENE_TYPE_UNKNOWN;

    hsv_info = led_strip_get_info();
    APP_LOG(LOG_DEBUG,"id:%d, mode:%d \n", hsv_info->scene_now, hsv_info->mode);
    if (p_sw->enable && hsv_info->status == LS_STATUS_OFF)
    {
        switch(hsv_info->mode)
        {
            case SCENE_COLOR_SCENE:
                ev.scene_type = SCENE_TYPE_DEFINE;
                ev.scene_id = hsv_info->scene_now;
                break;
            case SCENE_COLOR_MUSIC:
                ev.scene_type = SCENE_TYPE_DEFINE;
                ev.scene_id = SCENE_SPECTRUM;
                break;
            case SCENE_COLOR_MULT:
            case SCENE_COLOR_RGB:
            case SCENE_COLOR_WHITE:
                ev.scene_type = SCENE_TYPE_REALTIME;
                ev.scene_id = hsv_info->mode;
                break;
            default:
                break;
        }
    }
    else if ((hsv_info->status == LS_STATUS_ON) && p_sw->enable == false)
    {
        ev.scene_type = SCENE_TYPE_OFF;
        ev.scene_id = 0;
    }

    if (SCENE_TYPE_UNKNOWN != ev.scene_type)
    {
     led_strip_app_task_notify(&ev);
    }

    led_strip_report_set_chg_rsn(p_msg_ctx->p_trace_msg->src_type);
    vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, NULL);
}

/**
* @brief 反转开关的开启/关闭状态
* @param[in]  p_msg_ctx                [msg context]
* @param[in]  p_data                   [回调函数传入数据]
*/
static void ls_bp_toggle(bypass_msg_ctx_t *p_msg_ctx, void *p_data)
{
    ls_info_t *hsv_info = NULL;
    ls_ev_t ev;
    ev.event = LS_EV_CHANGE_SCENE;
    ev.act_src = LS_ACT_SRC_BYPASS;
    ev.scene_type = SCENE_TYPE_UNKNOWN;

    hsv_info = led_strip_get_info();
    // 翻转开关
    if (LS_STATUS_OFF == hsv_info->status)
    {
        switch(hsv_info->mode)
        {
            case SCENE_COLOR_SCENE:
                ev.scene_type = SCENE_TYPE_DEFINE;
                ev.scene_id = hsv_info->scene_now;
                break;
            case SCENE_COLOR_MUSIC:
                ev.scene_type = SCENE_TYPE_DEFINE;
                ev.scene_id = SCENE_SPECTRUM;
                break;
            case SCENE_COLOR_MULT:
            case SCENE_COLOR_RGB:
            case SCENE_COLOR_WHITE:
                ev.scene_type = SCENE_TYPE_REALTIME;
                ev.scene_id = hsv_info->mode;
                break;
            default:
                break;
        }
    }
    else
    {
        ev.scene_type = SCENE_TYPE_OFF;
        ev.scene_id = 0;
    }

    if (SCENE_TYPE_UNKNOWN != ev.scene_type)
    {
        led_strip_app_task_notify(&ev);
    }

    led_strip_report_set_chg_rsn(p_msg_ctx->p_trace_msg->src_type);
    vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, NULL);
}

/**
* @brief 调整亮度色温百分比
* @param[in]  p_msg_ctx                [msg context]
* @param[in]  p_data                   [回调函数传入数据]
*/
static void ls_bp_adjust_percent(bypass_msg_ctx_t *p_msg_ctx, void *p_data)
{
    if (NULL == p_data)
    {
        vesync_bypass_reply_pkg_err_msg(BP_ERR_PARA_ILLEGAL, p_msg_ctx->p_trace_msg, BP_ERR_PARAM_CONV(p_data, BP_ERR_PARAM_NULL_PTR));
        return;
    }

    bypass_adjust_percent_t *data = (bypass_adjust_percent_t*)p_data;
    int temp = 0;
    ls_info_t *hsv_info = NULL;
    ls_ev_t ev;
    ev.event = LS_EV_CHANGE_SCENE;
    ev.act_src = LS_ACT_SRC_BYPASS;
    ev.scene_type = SCENE_TYPE_UNKNOWN;

    hsv_info = led_strip_get_info();

    if (0 == strcmp(data->type, "brightness"))
    {
        if ((LS_STATUS_ON == hsv_info->status)&&(SCENE_COLOR_WHITE != hsv_info->mode)&&(SCENE_COLOR_RGB != hsv_info->mode))
        {
            // 开启状态下，该接口设置亮度时处于情景模式下不响应
            vesync_bypass_reply_pkg_err_msg(BP_ERR_NOT_EXEC_IN_CUR_MODE, p_msg_ctx->p_trace_msg, "Params matched error! ");
            return;
        }

        // 不响应关闭模式下降低亮度，其他都需要调整亮度
        if (LS_STATUS_OFF != hsv_info->status || 0 < data->step)
        {
            if (SCENE_COLOR_WHITE == hsv_info->mode)
            {
                int cur_bright = (LS_STATUS_OFF == hsv_info->status) ? 0 : hsv_info->brightness;
                temp = cur_bright + data->step;
                if (temp <= 0)
                {
                    hsv_info->status = LS_STATUS_OFF;
                    temp = 0;
                }
                else if (temp > 100)
                {
                    temp = 100;
                }
            }
            else if (SCENE_COLOR_RGB == hsv_info->mode)
            {
                int cur_V = (LS_STATUS_OFF == hsv_info->status) ? 0: (hsv_info->color).val;
                temp = cur_V + data->step;
                if (temp <= 0)
                {
                    hsv_info->status = LS_STATUS_OFF;
                    temp = 0;
                }
                else if (temp > 100)
                {
                    temp = 100;
                }
            }
            else
            {
                hsv_info->status = LS_STATUS_ON;
            }

            if (0 < temp )
            {
                if (SCENE_COLOR_WHITE == hsv_info->mode)
                {
                    hsv_info->brightness = (uint8_t)temp;
                }
                else if (SCENE_COLOR_RGB == hsv_info->mode)
                {
                    (hsv_info->color).val = (uint8_t)temp;
                }
                hsv_info->status = LS_STATUS_ON;
            }
        }
    }
    else
    {
        vesync_bypass_reply_pkg_err_msg(BP_ERR_PARA_ILLEGAL, p_msg_ctx->p_trace_msg, "Invalid type ! ");
        return;
    }

    if (LS_STATUS_OFF == hsv_info->status)
    {
        ev.scene_type = SCENE_TYPE_OFF;
        ev.scene_id = 0;
    }
    else
    {
        if (SCENE_COLOR_MUSIC == hsv_info->mode)
        {
            ev.scene_type = SCENE_TYPE_DEFINE;
            ev.scene_id = SCENE_SPECTRUM;
        }
        else if (SCENE_COLOR_SCENE == hsv_info->mode)
        {
            ev.scene_type = SCENE_TYPE_DEFINE;
            ev.scene_id = hsv_info->scene_now;
        }
        else
        {
            ev.scene_type = SCENE_TYPE_REALTIME;
            ev.scene_id = hsv_info->mode;
        }
    }

    if (SCENE_TYPE_UNKNOWN != ev.scene_type)
    {
     led_strip_app_task_notify(&ev);
    }

    // 回复与上报
    cJSON *p_json_result = NULL;
    p_json_result = cJSON_CreateObject();
    if (p_json_result != NULL)
    {
        cJSON_AddNumberToObject(p_json_result, "percent", temp);
    }

    led_strip_report_set_chg_rsn(p_msg_ctx->p_trace_msg->src_type);
    vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, p_json_result);
}


/**
* @brief led状态json数据打包
* @param[in]  light_params      [led参数]
* @param[out]  *p_data          [json指针]
*/
static void ls_bp_light_status_json_marshal(ls_info_t *light_params, cJSON *p_data)
{
    if (light_params->status == LS_STATUS_OFF)
    {
        cJSON_AddStringToObject(p_data, "enabled", "off");
    }
    else
    {
        cJSON_AddStringToObject(p_data, "enabled", "on");
        switch(light_params->mode)
        {
            case SCENE_COLOR_SCENE:
                cJSON_AddStringToObject(p_data, "colorMode", "scenario");
                break;
            case SCENE_COLOR_MUSIC:
                cJSON_AddStringToObject(p_data, "colorMode", "music");
                break;
            case SCENE_COLOR_MULT:
                cJSON_AddStringToObject(p_data, "colorMode", "multiHsv");
                break;
            case SCENE_COLOR_RGB:
                cJSON_AddStringToObject(p_data, "colorMode", "hsv");
                break;
            case SCENE_COLOR_WHITE:
                cJSON_AddStringToObject(p_data, "colorMode", "white");
                break;
            default:
                break;
        }
    }

    cJSON_AddNumberToObject(p_data, "brightness", light_params->brightness);
    cJSON_AddNumberToObject(p_data, "colorTemp", 0);
    cJSON_AddNumberToObject(p_data, "hue", light_params->color.hue);
    cJSON_AddNumberToObject(p_data, "saturation", light_params->color.sat);
    cJSON_AddNumberToObject(p_data, "value", light_params->color.val);
}

/**
* @brief 设置灯状态
* @param[in]         src            [传入灯带数据信息结构指针]
* @param[out]        dst            [传出灯带数据信息结构指针]
*/
static void ls_set_info_data(ls_info_t * src, ls_info_t * dst)
{
    dst->scene_now = (src->scene_now == 0xffff)?dst->scene_now:src->scene_now;
    dst->status = (src->status == 0xff)?dst->status:src->status;
    dst->color.hue = (src->color.hue == 0xffff)?dst->color.hue:src->color.hue;
    dst->color.sat = (src->color.sat == 0xffff)?dst->color.sat:src->color.sat;
    dst->multiple.num = (src->multiple.num == 0xff)?dst->multiple.num:src->multiple.num;
    dst->mode = (src->mode == 0xff)?dst->mode:src->mode;

    if (SCENE_COLOR_WHITE == dst->mode)
    {
        dst->brightness = (src->brightness == 0xff)?dst->brightness:src->brightness;
    }
    else if (SCENE_COLOR_RGB == dst->mode)
    {
        dst->color.val = (src->brightness == 0xff)?dst->color.val:src->brightness;
    }

    if (NULL != src->multiple.color)
    {
        memcpy(dst->multiple.color, src->multiple.color, dst->multiple.num*sizeof(ls_color_seg_t));
    }
}
/**
* @brief 设置灯状态
* @param[in]  p_msg_ctx                [msg context]
* @param[in]        json            [传入json]
* @return           BYPASS_ERR_E    [错误码]
*/
static BYPASS_ERR_E ls_bp_set_light_status(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    cJSON* json_data = NULL;
    uint8_t force = 0;
    int ret = 0;
    ls_info_t *hsv_info = NULL;
    ls_info_t temp_info ;
    cJSON* json_H = NULL;
    cJSON* json_S = NULL;
    ls_ev_t ev;
    ev.event = LS_EV_CHANGE_SCENE;
    ev.act_src = LS_ACT_SRC_BYPASS;
    ev.scene_type = SCENE_TYPE_UNKNOWN;

    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    hsv_info = led_strip_get_info();

    memset(&temp_info, 0xff, sizeof(ls_info_t));
    temp_info.multiple.color = NULL;
    json_data = cJSON_GetObjectItemCaseSensitive(json, "force");
    if (NULL != json_data)
    {
        force = json_data->valueint;
    }
    else // force字段可选，没有时为0
    {
        force = 0;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "brightness");
    if (NULL != json_data)
    {
        VCOM_IN_RANGE_CHK(json_data->valueint, 0, LED_BRIGHTNESS_MAX, (ret++));
        temp_info.brightness = json_data->valueint;
    }

    json_H = cJSON_GetObjectItemCaseSensitive(json, "hue");
    if (NULL != json_H)
    {
        VCOM_IN_RANGE_CHK(json_H->valueint, 0, LED_HS_PARAM_MAX, (ret++));
        temp_info.color.hue = json_H->valueint;
    }

    json_S = cJSON_GetObjectItemCaseSensitive(json, "saturation");
    if (NULL != json_S)
    {
        VCOM_IN_RANGE_CHK(json_S->valueint, 0, LED_HS_PARAM_MAX, (ret++));
        temp_info.color.sat = json_S->valueint;
    }

    if (ret > 0)
    {
        return BP_ERR_ARG;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "sceneId");
    if (NULL != json_data)
    {
        ret = led_strip_scene_id_check(json_data->valueint, &(temp_info.scene_now));
        if (APP_OK != ret)  // 场景不存在
        {
            vesync_bypass_reply_pkg_err_msg(ret, p_msg_ctx->p_trace_msg, NULL);
            return BP_OK; // 避免回两次reply
        }
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "colorMode");
    if (NULL != json_data)  // APP 下发的指令
    {
        // colorMode != NULL
        if (!cJSON_IsString(json_data))
        {
            return BP_ERR_ARG;
        }

        if (temp_info.brightness == 0)
        {
            return BP_ERR_ARG;
        }

        if (0 == strcmp(json_data->valuestring, "white"))
        {
            temp_info.mode = SCENE_COLOR_WHITE;
        }
        else if (0 == strcmp(json_data->valuestring, "hsv"))
        {
                temp_info.mode = SCENE_COLOR_RGB;
        }
        else if (0 == strcmp(json_data->valuestring, "multiHsv"))
        {
            json_H = cJSON_GetObjectItemCaseSensitive(json, "cnt");
            json_S = cJSON_GetObjectItemCaseSensitive(json, "hsv");;

            if ((NULL !=json_S )&&(NULL !=json_H ))
            {
                if ((json_H->valueint > MAX_SEGMENT_NUM)||(MIN_SEGMENT_NUM > json_H->valueint))
                {
                    return BP_ERR_ARG;
                }
                else
                {
                    temp_info.multiple.num = json_H->valueint;
                    temp_info.multiple.color = (ls_color_seg_t *)vesync_malloc(sizeof(ls_color_seg_t)*temp_info.multiple.num);
                    if (NULL == temp_info.multiple.color)
                    {
                        APP_LOG(LOG_ERROR,"malloc fail!\n");
                        return BP_ERR_NOMEM;
                    }
                    temp_info.mode = SCENE_COLOR_MULT;
                }
                APP_LOG(LOG_DEBUG,"segment num:%d !\n", temp_info.multiple.num);
                for (int i = 0; i < temp_info.multiple.num ; i++)
                {
                    json_H = cJSON_GetArrayItem(json_S, i);
                    ret = 0;
                    if (NULL != json_H)
                    {
                        json_data = cJSON_GetArrayItem(json_H, 0);
                        temp_info.multiple.color[i].hue = json_data->valueint;
                        VCOM_IN_RANGE_CHK(json_data->valueint, 0, LED_HS_PARAM_MAX, (ret++));
                        json_data = cJSON_GetArrayItem(json_H, 1);
                        temp_info.multiple.color[i].sat = json_data->valueint;
                        VCOM_IN_RANGE_CHK(json_data->valueint, 0, LED_HS_PARAM_MAX, (ret++));
                        json_data = cJSON_GetArrayItem(json_H, 2);
                        temp_info.multiple.color[i].val = json_data->valueint;
                        VCOM_IN_RANGE_CHK(json_data->valueint, 0, LED_BRIGHTNESS_MAX, (ret++));
                        if (ret > 0)
                        {
                            vesync_free(temp_info.multiple.color);
                            return BP_ERR_ARG;
                        }
                    }
                    else
                    {
                        vesync_free(temp_info.multiple.color);
                        return BP_ERR_ARG;
                    }
                }
            }
            else
            {
                return BP_ERR_ARG;
            }
        }
        else if (0 == strcmp(json_data->valuestring, "scenario"))
        {
            temp_info.mode = SCENE_COLOR_SCENE;
        }
        else if (0 == strcmp(json_data->valuestring, "music"))
        {
            temp_info.mode = SCENE_COLOR_MUSIC;
        }

    }
    else  // 云和第三方的指令
    {
        if (LS_STATUS_ON == hsv_info->status)   // 亮灯模式下，才根据模式判断是否执行
        {
            if ((hsv_info->mode != SCENE_COLOR_RGB)&&(hsv_info->mode != SCENE_COLOR_WHITE))
            {
                // force不为0，在分段彩光、音乐律动、场景模式都不支持设定到指定亮度,但可以转化到单彩光模式
                // force为0，只能白光或者单一彩光模式进行设置
                if (((0xffff == temp_info.color.hue)&&(0xffff == temp_info.color.sat)&&(0xff != temp_info.brightness))||\
                    (0 == force))
                {
                    if ((2 == force)&&(LED_BRIGHTNESS_MAX == temp_info.brightness))  // 第三方语音 TURN ON 指令回复OK
                    {
                        vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, NULL);
                    }
                    else
                    {
                        vesync_bypass_reply_pkg_err_msg(BP_ERR_NOT_EXEC_IN_CUR_MODE, p_msg_ctx->p_trace_msg, NULL);
                    }

                    return BP_OK;  // 避免回两次reply
                }
            }
        }

        // 灭灯条件下，场景、音乐、多段照常点亮，白光、彩光，根据指令内容亮灯
        if (2 == force)
        {
            if (0 == temp_info.brightness)
            {
                temp_info.status = LS_STATUS_OFF;
                temp_info.brightness = 0xff;   // 不能更新此次亮度值
                s_ls_voice_off_flag = true;
            }
            else if (100 == temp_info.brightness) // 开机，并恢复到之前的亮灯模式
            {
                temp_info.status = LS_STATUS_ON;
                if (true == s_ls_voice_off_flag)
                {
                    s_ls_voice_off_flag = false;
                    temp_info.color.val = temp_info.brightness;
                }
                else
                {
                    if (SCENE_COLOR_WHITE == hsv_info->mode)
                    {
                        temp_info.brightness = hsv_info->brightness;
                    }
                    else if (SCENE_COLOR_RGB == hsv_info->mode)
                    {
                        temp_info.brightness = hsv_info->color.val;
                    }
                }
            }

            if (temp_info.status == hsv_info->status)
            {
                vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, NULL);
                return BP_ERR_NO_ERR;
            }
        }
        else if (1 == force)
        {
            // 亮灯条件下，force为1，可以颜色模式切换为白光或者彩光
            if ((0xffff != temp_info.color.hue)||(0xffff != temp_info.color.sat))
            {
                temp_info.mode = SCENE_COLOR_RGB;
            }
        }
        else
        {
            // 亮灯条件下，force为0，白光模式下不响应颜色切换
            if ((hsv_info->mode == SCENE_COLOR_WHITE)&&(LS_STATUS_ON == hsv_info->status))
            {
                if ((0xffff != temp_info.color.hue)||(0xffff != temp_info.color.sat))
                {
                    vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, NULL);
                    return BP_ERR_NO_ERR;
                }
            }

        }
    }

    ls_set_info_data(&temp_info, hsv_info);
    APP_LOG(LOG_DEBUG, "mode:%d, scene:%d",hsv_info->mode, hsv_info->scene_now);
    if (temp_info.status == LS_STATUS_OFF)
    {
        ev.scene_type = SCENE_TYPE_OFF;
        ev.scene_id = 0;
    }
    else
    {
        switch(hsv_info->mode)
        {
            case SCENE_COLOR_SCENE:
                ev.scene_type = SCENE_TYPE_DEFINE;
                ev.scene_id = hsv_info->scene_now;
                break;
            case SCENE_COLOR_MUSIC:
                ev.scene_type = SCENE_TYPE_DEFINE;
                ev.scene_id = SCENE_SPECTRUM;
                break;
            case SCENE_COLOR_MULT:
            case SCENE_COLOR_RGB:
            case SCENE_COLOR_WHITE:
                ev.scene_type = SCENE_TYPE_REALTIME;
                ev.scene_id = hsv_info->mode;
                break;
            default:
                break;
        }
     }

    if (SCENE_TYPE_UNKNOWN != ev.scene_type)
    {
        led_strip_app_task_notify(&ev);
    }

    led_strip_report_set_chg_rsn(p_msg_ctx->p_trace_msg->src_type);
    // 回复led状态数据
    cJSON *json_result = NULL;
    json_result = cJSON_CreateObject();
    if (NULL== json_result)
    {
        vesync_bypass_reply_pkg_err_msg(BP_ERR_OUT_OF_MEMORY, p_msg_ctx->p_trace_msg, NULL);
    }
    else
    {
        ls_bp_light_status_json_marshal(hsv_info, json_result);
        vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, json_result);
    }

    vesync_free(temp_info.multiple.color);
    return BP_OK;
}


/**
* @brief 获取灯状态
* @param[in]  p_msg_ctx                [msg context]
* @param[in]        json            [传入json]
* @return           BYPASS_ERR_E    [错误码]
*/
static BYPASS_ERR_E ls_bp_get_light_status(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    cJSON *json_result = NULL;
    ls_info_t *hsv_info = NULL;
    cJSON *array = NULL;
    cJSON *hsv = NULL;
    int ret = BP_OK;
    int  temp_color[3] = {0, 0, 0};

    hsv_info = led_strip_get_info();

    json_result = cJSON_CreateObject();
    if (NULL== json_result)
    {
        ret =  BP_ERR_NOMEM;
        goto EXIT;
    }

    if (hsv_info->status == LS_STATUS_OFF)
    {
        cJSON_AddStringToObject(json_result, "enabled", "off");
    }
    else
    {
        cJSON_AddStringToObject(json_result, "enabled", "on");
    }

    switch(hsv_info->mode)
    {
        case SCENE_COLOR_SCENE:
            cJSON_AddStringToObject(json_result, "colorMode", "scenario");
            cJSON_AddNumberToObject(json_result, "sceneId", hsv_info->scene_now);
            break;
        case SCENE_COLOR_MUSIC:
            cJSON_AddStringToObject(json_result, "colorMode", "music");
            break;
        case SCENE_COLOR_MULT:
            cJSON_AddStringToObject(json_result, "colorMode", "multiHsv");
            cJSON_AddNumberToObject(json_result, "cnt", hsv_info->multiple.num);
            hsv = cJSON_AddArrayToObject(json_result, "hsv");
            if(NULL == hsv )
            {
                APP_LOG(LOG_ERROR, "Create object fail\n");
                ret =  BP_ERR_NOMEM;
                goto EXIT;
            }

            for (int i = 0; i < hsv_info->multiple.num; i++)
            {
                temp_color[0] = hsv_info->multiple.color[i].hue;
                temp_color[1] = hsv_info->multiple.color[i].sat;
                temp_color[2] = hsv_info->multiple.color[i].val;
                array = cJSON_CreateIntArray(temp_color, 3);
                if(NULL == array )
                {
                    APP_LOG(LOG_ERROR, "Create array fail\n");
                    ret =  BP_ERR_NOMEM;
                    goto EXIT;
                }
                cJSON_AddItemToArray(hsv, array);
            }

            break;
        case SCENE_COLOR_RGB:
            cJSON_AddStringToObject(json_result, "colorMode", "hsv");
            cJSON_AddNumberToObject(json_result, "hue", hsv_info->color.hue);
            cJSON_AddNumberToObject(json_result, "saturation", hsv_info->color.sat);
            cJSON_AddNumberToObject(json_result, "value", hsv_info->color.val);
            break;
        case SCENE_COLOR_WHITE:
            cJSON_AddStringToObject(json_result, "colorMode", "white");
            cJSON_AddNumberToObject(json_result, "brightness", hsv_info->brightness);
            break;
        default:
            break;
    }

EXIT:
    if (BP_OK == ret)
    {
        vesync_bypass_reply_noqos(BP_OK, p_msg_ctx->p_trace_msg, json_result);
    }

    return ret;
}

/**
* @brief 增加场景
* @param[in]  p_msg_ctx                [msg context]
* @param[in]        json            [传入json]
* @return           BYPASS_ERR_E    [错误码]
*/
static BYPASS_ERR_E ls_bp_add_light_scene(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    cJSON* json_result = NULL;
    ls_info_t *hsv_info = NULL;
    ls_color_seg_t * color = NULL ;
    uint16_t scene_id = 0xffff;
    int ret = BP_OK;

    if (NULL == p_msg_ctx || NULL == p_msg_ctx->p_trace_msg)
    {
        APP_LOG(LOG_ERROR, " error \n");
        return BP_ERROR;
    }

    json_result = cJSON_CreateObject();
    if (NULL== json_result)
    {
        ret =  BP_ERR_OUT_OF_MEMORY;
        goto EXIT;
    }

    hsv_info = led_strip_get_info();

    switch(hsv_info->mode)
    {
        case SCENE_COLOR_MULT:
            color = (ls_color_seg_t * )vesync_malloc(sizeof(ls_color_seg_t)*(hsv_info->multiple.num));
            if (NULL== color)
            {
                ret =  BP_ERR_OUT_OF_MEMORY;
                goto EXIT;
            }
            memcpy(color, hsv_info->multiple.color, sizeof(ls_color_seg_t)*(hsv_info->multiple.num));
            ret = led_strip_scene_add(&scene_id,hsv_info->mode, hsv_info->multiple.num, color);
            break;
        case SCENE_COLOR_RGB:
        case SCENE_COLOR_WHITE:
            color = (ls_color_seg_t *) vesync_malloc(sizeof(ls_color_seg_t));
            if (NULL== color)
            {
                ret =  BP_ERR_OUT_OF_MEMORY;
                goto EXIT;
            }

            if (SCENE_COLOR_RGB == hsv_info->mode)
            {
                memcpy(color, &(hsv_info->color), sizeof(ls_color_seg_t));
            }
            else
            {
                color->hue = 0xffff;
                color->sat = 0xffff;
                color->val = hsv_info->brightness;
            }
            ret = led_strip_scene_add(&scene_id, hsv_info->mode, 1, color);
            break;
        case SCENE_COLOR_SCENE:
        case SCENE_COLOR_MUSIC:
        default:
            APP_LOG(LOG_DEBUG, " BP_ERR_NOT_EXEC_IN_CUR_MODE \n");
            ret = BP_ERR_NOT_EXEC_IN_CUR_MODE;
            break;
    }

    if (APP_OK == ret)
    {
        cJSON_AddNumberToObject(json_result, "sceneId", scene_id);
    }
    else
    {
        if (APP_FAIL == ret)
        {
            ret = BP_ERR_CMD_EXECUTE_FAIL;
        }
        else
        {
            ret = BP_ERR_VALUE_OUT_OF_RANGE;
        }
        vesync_free(color);
    }
EXIT:
    if (BP_OK == ret)
    {
        vesync_bypass_reply_noqos(BP_OK, p_msg_ctx->p_trace_msg, json_result);
    }
    else
    {
        vesync_bypass_reply_pkg_err_msg(ret, p_msg_ctx->p_trace_msg, NULL);
        if (NULL != json_result)
        {
            cJSON_Delete(json_result);
        }
    }

    return BP_OK;  // 避免回两次 reply
}

/**
* @brief 删除场景
* @param[in]  p_msg_ctx                [msg context]
* @param[in]        json            [传入json]
* @return           BYPASS_ERR_E    [错误码]
*/
static BYPASS_ERR_E ls_bp_del_light_scene(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    cJSON* json_data = NULL;
    int ret = BP_OK;
    uint16_t id = 0;
    ls_info_t *hsv_info = NULL;

    if (NULL == p_msg_ctx || NULL == p_msg_ctx->p_trace_msg || NULL == json)
    {
        APP_LOG(LOG_DEBUG, "error \n");
        return BP_ERROR;
    }
    hsv_info = led_strip_get_info();
    json_data = cJSON_GetObjectItemCaseSensitive(json, "sceneId");
    if (NULL != json_data)
    {
        ret = led_strip_scene_id_check(json_data->valueint, &id);
        if (APP_OK != ret)  // 场景不存在
        {
            vesync_bypass_reply_pkg_err_msg(ret, p_msg_ctx->p_trace_msg, NULL);
            return BP_OK; // 避免回两次reply
        }

        ret = led_strip_scene_delete(json_data->valueint);
        if (APP_OK != ret)
        {
            ret = BP_ERR_CMD_EXECUTE_FAIL;
        }

        if ((APP_OK == ret)&&(json_data->valueint == hsv_info->scene_now))
        {
            hsv_info->scene_now = 0;
            led_strip_save_info(hsv_info);
        }
    }
    else
    {
        ret = BP_ERR_PARA_ILLEGAL;
    }

    if (BP_OK == ret)
    {
        vesync_bypass_reply_noqos(BP_OK, p_msg_ctx->p_trace_msg, NULL);
    }
    else
    {
        vesync_bypass_reply_pkg_err_msg(ret, p_msg_ctx->p_trace_msg, NULL);
    }

    return BP_OK; // 避免回两次 reply
}

/**
* @brief 获取自定义场景列表
* @param[in]  p_msg_ctx                [msg context]
* @param[in]        json            [传入json]
* @return           BYPASS_ERR_E    [错误码]
*/
static BYPASS_ERR_E ls_bp_get_light_scene(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    cJSON* json_result = NULL;
    cJSON* json_array = NULL;
    ls_info_t *hsv_info = NULL;
    int ret = BP_OK;
    int * list = NULL;
    uint8_t count = 0;

    if (NULL == p_msg_ctx || NULL == p_msg_ctx->p_trace_msg)
    {
        APP_LOG(LOG_DEBUG, "error \n");
        return BP_ERROR;
    }

    hsv_info = led_strip_get_info();
    list = (int *) vesync_malloc(4*(SCENE_CUSTOM_MAX_NUM));
    if (NULL== list)
    {
        ret =  BP_ERR_OUT_OF_MEMORY;
        goto EXIT;
    }

    json_result = cJSON_CreateObject();
    if (NULL== json_result)
    {
        ret =  BP_ERR_OUT_OF_MEMORY;
        goto EXIT;
    }

    for (int i = SCENE_CUSTOM_MAX_NUM -1 ; i >= 0 ; i--)
    {
        if (NULL != hsv_info->scene_list[i].color)
        {
            list[count] = hsv_info->scene_list[i].id;
            if (count < hsv_info->scene_num)   // 防止越界
            {
                count++;
            }
            else  // 异常报错
            {
                APP_LOG(LOG_ERROR, "scene_num error\n");
            }
        }
    }

    APP_LOG(LOG_DEBUG, "scene_num:%d\n", count);
    cJSON_AddNumberToObject(json_result, "total", count);
    if (0 < count)
    {
        json_array = cJSON_CreateIntArray(list, count);;
        if (NULL== json_array)
        {
            ret =  BP_ERR_OUT_OF_MEMORY;
            goto EXIT;
        }
        else
        {
            cJSON_AddItemToObject(json_result, "scenes",json_array);
        }
    }
EXIT:
    if (BP_OK == ret)
    {
        vesync_bypass_reply_noqos(BP_OK, p_msg_ctx->p_trace_msg, json_result);
    }
    else
    {
        vesync_bypass_reply_pkg_err_msg(ret, p_msg_ctx->p_trace_msg, NULL);
        if (NULL != json_result)
        {
            cJSON_Delete(json_result);
        }
    }

    vesync_free(list);
    return BP_OK;
}

/**
* @brief 设置灯带灯珠数量
* @param[in]  p_msg_ctx                [msg context]
* @param[in]        json            [传入json]
* @return           BYPASS_ERR_E    [错误码]
*/
static BYPASS_ERR_E ls_bp_set_led_num(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    cJSON* json_data = NULL;
    ls_info_t *hsv_info = NULL;
    int ret = BP_OK;

    if (NULL == p_msg_ctx || NULL == p_msg_ctx->p_trace_msg || NULL == json)
    {
        APP_LOG(LOG_DEBUG, "error \n");
        return BP_ERROR;
    }

    hsv_info = led_strip_get_info();
    json_data = cJSON_GetObjectItemCaseSensitive(json, "lightBeadsSize");
    if ((NULL != json_data)&&(json_data->valueint <= MAX_LED_NUM )&&(json_data->valueint >= MIN_LED_NUM ))
    {
        hsv_info->led_num = json_data->valueint;
        ret = led_strip_save_info(hsv_info);   // 改变了灯珠的数量，所以需要存储到flash
    }
    else
    {
        ret = BP_ERR_PARA_ILLEGAL;
    }

    if (BP_OK == ret)
    {
        vesync_bypass_reply_noqos(BP_OK, p_msg_ctx->p_trace_msg, NULL);
    }
    else
    {
        vesync_bypass_reply_pkg_err_msg(ret, p_msg_ctx->p_trace_msg, NULL);
    }
    return BP_OK;
}

/**
* @brief 获取灯带灯珠数量
* @param[in]  p_msg_ctx                [msg context]
* @param[in]        json            [传入json]
* @return           BYPASS_ERR_E    [错误码]
*/
static BYPASS_ERR_E ls_bp_get_led_num(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    cJSON* json_result = NULL;
    ls_info_t *hsv_info = NULL;

    if (NULL == p_msg_ctx || NULL == p_msg_ctx->p_trace_msg)
    {
        APP_LOG(LOG_DEBUG, "error \n");
        return BP_ERROR;
    }

    hsv_info = led_strip_get_info();
    json_result = cJSON_CreateObject();
    if (NULL== json_result)
    {
        vesync_bypass_reply_pkg_err_msg(BP_ERR_OUT_OF_MEMORY, p_msg_ctx->p_trace_msg, NULL);
        return BP_OK;
    }

    cJSON_AddNumberToObject(json_result, "lightBeadsSize", hsv_info->led_num);
    vesync_bypass_reply_noqos(BP_OK, p_msg_ctx->p_trace_msg, json_result);
    return BP_OK;
}


static bypass_user_data_t ls_method_tbl[] = {
    // timer
    {"addTimerV2", ls_bp_add_timer},
    {"getTimerV2", ls_bp_get_timer},
    {"delTimerV2", ls_bp_del_timer},
    {"setLightStatusV2",ls_bp_set_light_status},
    {"getLightStatusV2",ls_bp_get_light_status},
    {"addScene", ls_bp_add_light_scene},
    {"getScenes",  ls_bp_get_light_scene},
    {"delScene", ls_bp_del_light_scene},
    {"setLightBeadsSize",ls_bp_set_led_num},
    {"getLightBeadsSize",ls_bp_get_led_num}
};



/**
* @brief 注册bypass回调函数
*/
void led_strip_bypass_reg_cb(void)
{
    // LED
    vesync_bypass_reg_method_cb(BYPASS_METHOD_ID_SET_SWITCH, ls_bp_set_switch_onoff);
    vesync_bypass_reg_method_cb(BYPASS_METHOD_ID_TOGGLE_SWITCH, ls_bp_toggle);
    // addjustPercent
    vesync_bypass_reg_method_cb(BYPASS_METHOD_ID_ADJUST_PERCENT, ls_bp_adjust_percent);
    // Schedule
    vesync_bypass_reg_method_cb(BYPASS_METHOD_ID_ADD_SCHEDULE_V3, ls_bp_add_schedule);
    vesync_bypass_reg_method_cb(BYPASS_METHOD_ID_UPD_SCHEDULE_V3, ls_bp_upd_schedule);
    vesync_bypass_reg_method_cb(BYPASS_METHOD_ID_DEL_SCHEDULE_V3, ls_bp_del_schedule);
    vesync_bypass_reg_method_cb(BYPASS_METHOD_ID_GET_SCHEDULES_V3, ls_bp_get_schedules);

    for (int i = 0; i < SIZEOF_ARRAY(ls_method_tbl); i++)
    {
        vesync_bypass_add_user_item(&ls_method_tbl[i]);
    }

}




