/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_klv.h
 * @brief       vesync_klv数据处理模块接口定义
 * @date        2021-04-21
 */

#ifndef __VESYNC_KLV_H__
#define __VESYNC_KLV_H__

#include <stdint.h>

#if defined(CONFIG_VESYNC_BUFFER_ENABLE)
#include "vesync_buffer.h"
#endif

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief  KLV结构体
 */
typedef struct
{
    uint8_t key;
    uint16_t len;
    uint8_t *value;
} klv_t;


/**
 * @brief  填充数组元素的回调函数
 * @param[in] count             [数据序列号，表示数组第几个元素]
 * @param[in] pdata             [数据缓存指针]
 * @param[out] len              [缓存长度]
 * @return uint32_t             [数据组装的长度]
 */
typedef uint32_t (*vesync_klv_arr_item_cb_t)(uint32_t count, uint8_t *pdata, uint32_t len);


/**
 * @brief  数组元素迭代器回调定义
 * @param[in] p_iter            [迭代算子]
 * @param[in] iter_cnt          [迭代次数]
 * @param[out] p_buf            [KLV写入Buffer]
 * @param[in] len               [Buffer长度]
 * @return uint32_t             [KLV写入长度]
 */
typedef uint32_t (*vesync_klv_arr_iterator_t)(void **p_iter, uint32_t iter_cnt, uint8_t *p_buf, uint32_t len);


/**
 * @brief  klv组装
 * @param[out] p_buf            [接收klv组装后数据的Buffer, 如果Buffer为NULL，则该函数会返回最终KLV组装完成的大小]
 * @param[in]  buf_len          [Buffer的长度，当p_buf不为NULL，会校验Buffer长度是否合法]
 * @param[in]  key              [KLV数据的Key值]
 * @param[in]  len              [KLV数据的长度]
 * @param[in]  p_val            [KLV数据Value值]
 * @return     uint32_t         [KLV组装后的总长度]
 */
uint32_t vesync_klv_set(uint8_t *p_buf, uint32_t buf_len, uint8_t key, uint16_t len, uint8_t *p_val);


/**
 * @brief  往klv中添加数组
 * @param[out] p_buf            [接收klv组装后数据的Buffer, 如果Buffer为NULL，则该函数会返回最终KLV组装完成的大小]
 * @param[in]  buf_len          [Buffer长度，当p_buf不为NULL，会校验Buffer长度是否合法]
 * @param[in]  key              [数组KLV所用的Key]
 * @param[in]  count            [数组元素的总个数]
 * @param[in]  item_cb          [填充数组元素的回调函数]
 * @return     uint32_t         [KLV组装后的总长度]
 */
uint32_t vesync_klv_set_arr(uint8_t *p_buf, uint32_t buf_len, uint8_t key, uint32_t count, vesync_klv_arr_item_cb_t item_cb);


/**
 * @brief  通过key值获取klv 将value的值拷贝到用户缓存中，适合获取末端节点的klv内容
 * @param[in]  pdata            [klv数据头部的指针]
 * @param[in]  len              [pdata缓存的长度]
 * @param[in]  key              [要获取的klv或数组的key值]
 * @param[in]  value_len        [value缓存长度]
 * @param[out]  value           [key取值]
 * @return  int                 [成功：SDK_OK；失败：SDK_FAIL]
 */
int vesync_klv_get(uint8_t *pdata, uint32_t len, uint8_t key, uint16_t value_len, uint8_t *value);


/**
 * @brief  通过key值获取klv节点指针，适合非末端节点的klv节点,其中value是一个指针
 * @param[in]  pdata            [klv数据头部的指针]
 * @param[in]  len              [pdata缓存的长度]
 * @param[in]  key              [要获取的klv或数组的key值]
 * @param[out]  klv             [获取到的klv节点]
 * @return  int                 [成功：SDK_OK；失败：SDK_FAIL]
 */
int vesync_klv_get_ptr(uint8_t *pdata, uint32_t len, uint8_t key, klv_t *klv);


/**
 * @brief  通过index获取数组的一个元素
 * @param[in]  pdata            [数组数据头部的指针]
 * @param[in]  len              [数组数据的长度]
 * @param[in]  index            [要获取数组中的第几个元素]
 * @param[out]  klv             [获取到的内容]
 * @return  int                 [成功：SDK_OK；失败：SDK_FAIL]
 */
int vesync_klv_get_item(uint8_t *pdata, uint32_t len, uint32_t index, klv_t *klv);


/**
 * @brief  以迭代器的方式组装klv数组或者返回组装的klv数组的总大小
 * @param[out] p_buf            [接收klv组装后数据的Buffer]
 * @param[in]  buf_len          [Buffer长度]
 * @param[in]  key              [数组所用的key]
 * @param[in]  count            [迭代次数]
 * @param[in]  p_data           [迭代数据]
 * @param[in]  iterator         [填充数组元素的迭代器回调函数]
 * @return     uint32_t         [klv组装后的总长度]
 */
uint32_t vesync_klv_set_arr_iter(uint8_t *p_buf, uint32_t buf_len, uint8_t key, uint32_t count, void *p_data, vesync_klv_arr_iterator_t iterator);


#if defined(CONFIG_VESYNC_BUFFER_ENABLE)
/**
 * @brief  klv组装Vesync buffer
 * @param[out] buf              [接收klv组装后数据的buf]
 * @param[in]  buf_len          [buf长度]
 * @param[in]  key              [数据key值]
 * @param[in]  p_in             [Vesync Buffer]
 * @return     uint32_t         [klv组装后的总长度]
 * @note  组装总长度返回后用于指针后移
 */
uint32_t vesync_klv_set_buf(uint8_t *buf, uint32_t buf_len, uint8_t key, vesync_buf_t *p_in);

/**
 * @brief  获取klv中的vesync buffer
 * @param[in]   p_data  [klv数据头部的指针]
 * @param[in]   len     [p_data缓存的长度]
 * @param[in]   key     [要获取的klv或数组的key值]
 * @param[out]  p_out   [Vesync Buffer]
 * @return  int                 [成功：SDK_OK；失败：SDK_FAIL]
 */
int vesync_klv_get_buf(uint8_t *p_data, uint32_t len, uint8_t key, vesync_buf_t *p_out);
#endif  /* CONFIG_VESYNC_BUFFER_ENABLE */

#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_KLV_H__ */

