/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_ota.h
 * @brief       OTA升级Wi-Fi固件接口
 * @date        2021-05-19
 */

#ifndef __VESYNC_OTA_H__
#define __VESYNC_OTA_H__

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif


/**
 * @brief 获取设备工作状态回调函数指针
 * @return bool                  [true:设备运行中，false:设备空闲]
 */
typedef bool (*vesync_ota_get_status_cb_t)(void);


/**
 * @brief  升级前处理回调
 * @param[in]  force             [true表示强制升级；false表示非强制升级]
 */
typedef void (*vesync_ota_pre_cb_t)(bool force);


/**
 * @brief 升级后处理回调
 * @param[in]  success            [true表示升级成功处理（此回调在重启前执行），false表示升级失败处理]
 */
typedef void (*vesync_ota_post_cb_t)(bool success);


/**
 * @brief mcu升级前回调函数指针
 */
typedef void (*vesync_ota_mcu_pre_cb_t)(void);


/**
 * @brief mcu升级结果回调函数指针
 * @param[in]  err_code          [MCU升级结果错误码]
 */
typedef void (*vesync_ota_mcu_post_cb_t)(uint32_t err_code);


/**
 * @brief 注册获取工作状态回调函数
 * @param[in]  cb                [获取ota状态回调函数]
 */
void vesync_ota_reg_get_status_cb(vesync_ota_get_status_cb_t cb);


/**
 * @brief 注册升级前与升级失败后处理回调函数
 * @param[in]  pre_cb            [升级前回调函数]
 * @param[in]  post_cb           [升级后回调函数]
 */
void vesync_ota_reg_pre_post_cb(vesync_ota_pre_cb_t pre_cb, vesync_ota_post_cb_t post_cb);


/**
 * @brief 注册mcu固件升级结果回调函数
 * @param[in]  pre_cb            [mcu升级前回调函数指针]
 * @param[in]  post_cb           [mcu升级结果回调函数指针]
 */
void vesync_ota_reg_mcu_pre_post_cb(vesync_ota_mcu_pre_cb_t pre_cb, vesync_ota_mcu_post_cb_t post_cb);


/**
 * @brief 获取升级错误码
 * @return uint8_t               [升级错误码]
 */
uint8_t vesync_ota_get_upgrade_code(void);


/**
 * @brief 获取MCU升级错误码
 * @return uint8_t               [mcu升级错误码]
 */
uint8_t vesync_ota_mcu_get_upgrade_code(void);


#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_OTA_H__ */

