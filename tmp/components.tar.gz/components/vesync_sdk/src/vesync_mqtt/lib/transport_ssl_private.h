/**
 * Copyright © Vesync Technologies Co.Ltd. 2019-2021. All rights reserved
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


#ifndef __TRANSPORT_SSL_PRIVATE_H__
#define __TRANSPORT_SSL_PRIVATE_H__


#include "mbedtls/platform.h"
#include "mbedtls/net_sockets.h"
#include "mbedtls/ssl.h"
#include "mbedtls/entropy.h"
#include "mbedtls/ctr_drbg.h"
#include "mbedtls/error.h"
#include "mbedtls/certs.h"

#include "transport_ssl.h"


/* The following is the redirection of the interface called by this module */

#ifndef VERR_OK
#include "vesync_common.h"
#define VERR_OK SDK_OK
#define VERR_FAIL SDK_FAIL
#endif /* VERR_OK */

#ifndef TRANSPORT_LOG
#include "vesync_log_internal.h"
#ifdef SDK_LOG
#define TRANSPORT_LOG SDK_LOG
#else
#define TRANSPORT_LOG(level, format, ...)
#endif /* SDK_LOG */
#endif /* TRANSPORT_LOG */

#ifndef TRANSPORT_LOG_ERROR
#include "mqtt_log.h"
#ifdef MQTT_LOG_ERROR
#define TRANSPORT_LOG_ERROR MQTT_LOG_ERROR
#else
#define TRANSPORT_LOG_ERROR(format, ...)
#endif /* MQTT_LOG_ERROR */
#endif /* TRANSPORT_LOG_ERROR */

#define VERR_UPLOAD(x, y)

/* The above is the redirection of the interface called by this module */

#define VESYNC_SSL_REMOVE_SERVER_NAME_INDICATION


#ifdef read
#undef read
#endif

#ifdef write
#undef write
#endif

#define VESYNC_TRANSPORT_MEM_CHECK(ptr, action) \
    do                          \
    {                           \
        if (NULL == (ptr))      \
        {                       \
            action;             \
        }                       \
    } while (0)

/**
 *  @brief 最近一次DNS解析成功的域名信息
 */
typedef struct {
    int ai_family;              // AF_INET,AF_INET6,UNIX etc
    int ai_socktype;            // STREAM,DATAGRAM,RAW
    int ai_protocol;            // IPPROTO_IP, IPPROTO_IPV4, IPPROTO_IPV6 etc
    size_t ai_addrlen;          // length of ai_addr
    struct sockaddr ai_addr;    // addr of host
} ip_addr_info_t;

/**
 *  @brief VESYNC-TLS Connection State
 */
typedef enum vesync_tls_conn_state {
    VESYNC_TLS_INIT = 0,
    VESYNC_TLS_CONNECTING,
    VESYNC_TLS_HANDSHAKE,
    VESYNC_TLS_FAIL,
    VESYNC_TLS_DONE,
} VESYNC_TLS_CONN_STATE_E;

typedef enum {
    TRANS_SSL_INIT = 0,
    TRANS_SSL_CONNECTING,
} TRANSPORT_SSL_CONN_STATE_E;

/**
 * @brief      vesync-TLS configuration parameters
 */
typedef struct vesync_tls_cfg {
    const char **alpn_protos;               /*!< Application protocols required for HTTP2.
                                                 If HTTP2/ALPN support is required, a list
                                                 of protocols that should be negotiated.
                                                 The format is length followed by protocol
                                                 name.
                                                 For the most common cases the following is ok:
                                                 const char **alpn_protos = { "h2", NULL };
                                                 - where 'h2' is the protocol name */

    union {
    const unsigned char *cacert_buf;        /*!< Certificate Authority's certificate in a buffer.
                                                 Format may be PEM or DER, depending on mbedtls-support
                                                 This buffer should be NULL terminated in case of PEM */
    const unsigned char *cacert_pem_buf;    /*!< CA certificate buffer legacy name */
    };

    union {
    unsigned int cacert_bytes;              /*!< Size of Certificate Authority certificate
                                                 pointed to by cacert_buf
                                                 (including NULL-terminator in case of PEM format) */
    unsigned int cacert_pem_bytes;          /*!< Size of Certificate Authority certificate legacy name */
    };

    union {
    const unsigned char *clientcert_buf;    /*!< Client certificate in a buffer
                                                 Format may be PEM or DER, depending on mbedtls-support
                                                 This buffer should be NULL terminated in case of PEM */
    const unsigned char *clientcert_pem_buf;     /*!< Client certificate legacy name */
    };

    union {
    unsigned int clientcert_bytes;          /*!< Size of client certificate pointed to by
                                                 clientcert_pem_buf
                                                 (including NULL-terminator in case of PEM format) */
    unsigned int clientcert_pem_bytes;      /*!< Size of client certificate legacy name */
    };

    union {
    const unsigned char *clientkey_buf;     /*!< Client key in a buffer
                                                 Format may be PEM or DER, depending on mbedtls-support
                                                 This buffer should be NULL terminated in case of PEM */
    const unsigned char *clientkey_pem_buf; /*!< Client key legacy name */
    };

    union {
    unsigned int clientkey_bytes;           /*!< Size of client key pointed to by
                                                 clientkey_pem_buf
                                                 (including NULL-terminator in case of PEM format) */
    unsigned int clientkey_pem_bytes;       /*!< Size of client key legacy name */
    };

    const unsigned char *clientkey_password;/*!< Client key decryption password string */

    unsigned int clientkey_password_len;    /*!< String length of the password pointed to by
                                                 clientkey_password */

    bool non_block;                         /*!< Configure non-blocking mode. If set to true the
                                                 underneath socket will be configured in non
                                                 blocking mode after tls session is established */

    bool use_secure_element;                /*!< Enable this option to use secure element or
                                                 atecc608a chip ( Integrated with vesync32-WROOM-32SE ) */

    int timeout_ms;                         /*!< Network timeout in milliseconds */

    bool use_global_ca_store;               /*!< Use a global ca_store for all the connections in which
                                                 this bool is set. */

} vesync_tls_cfg_t;

/**
 * @brief      vesync-TLS Connection Handle
 */
typedef struct vesync_tls {
    mbedtls_ssl_context ssl;                                                    /*!< TLS/SSL context */

    mbedtls_entropy_context entropy;                                            /*!< mbedTLS entropy context structure */

    mbedtls_ctr_drbg_context ctr_drbg;                                          /*!< mbedTLS ctr drbg context structure.
                                                                                     CTR_DRBG is deterministic random
                                                                                     bit generation based on AES-256 */

    mbedtls_ssl_config conf;                                                    /*!< TLS/SSL configuration to be shared
                                                                                     between mbedtls_ssl_context
                                                                                     structures */

    mbedtls_net_context server_fd;                                              /*!< mbedTLS wrapper type for sockets */

    mbedtls_x509_crt cacert;                                                    /*!< Container for the X.509 CA certificate */

    mbedtls_x509_crt *cacert_ptr;                                               /*!< Pointer to the cacert being used. */

    mbedtls_x509_crt clientcert;                                                /*!< Container for the X.509 client certificate */

    mbedtls_pk_context clientkey;                                               /*!< Container for the private key of the client
                                                                                     certificate */

    int sockfd;                                                                 /*!< Underlying socket file descriptor. */

    ssize_t (*read)(struct vesync_tls  *tls, char *data, size_t datalen);          /*!< Callback function for reading data from TLS/SSL
                                                                                     connection. */

    ssize_t (*write)(struct vesync_tls *tls, const char *data, size_t datalen);    /*!< Callback function for writing data to TLS/SSL
                                                                                     connection. */

    VESYNC_TLS_CONN_STATE_E  conn_state;                                           /*!< vesync-TLS Connection state */

    fd_set rset;                                                                /*!< read file descriptors */

    fd_set wset;                                                                /*!< write file descriptors */

#ifdef VESYNC_SSL_REMOVE_SERVER_NAME_INDICATION
    char *hostname;                                                             /*!< expected peer CN for verification */
#endif /* VESYNC_SSL_REMOVE_SERVER_NAME_INDICATION */
} vesync_tls_t;

/**
 *  mbedtls specific transport data
 */
typedef struct {
    vesync_tls_t                *tls;
    vesync_tls_cfg_t            cfg;
    bool                     ssl_initialized;
    TRANSPORT_SSL_CONN_STATE_E conn_state;
} transport_ssl_t;


#else
#error This private file can only be included by owner
#endif /* __TRANSPORT_SSL_PRIVATE_H__ */

