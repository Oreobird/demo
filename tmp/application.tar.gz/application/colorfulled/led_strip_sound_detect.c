/**
 *  Copyright © Vesync Technologies Co.Ltd. 2019-2021. All rights reserved
 * @file        led_strip_adc.c
 * @brief       led strip voice detecting function
 * @author      henrik
 * @date        2021-09-29
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "driver/adc.h"
#include "esp_dsp.h"

#include "vesync_common.h"
#include "vesync_memory.h"
#include "vesync_log.h"
#include "led_strip_board.h"
#include "led_strip_sound_detect.h"

static uint8_t * p_sound_buf = NULL;

/**
 * @brief      Initialize the fft component
 * @param[in]  s_wind                Buffer to store window array
 * @param[in]  n_samples             Length of the window array
 * @return
 *      - ESP_OK
 *      - ESP_FAIL
 */
esp_err_t fft_init(float *s_wind, int32_t n_samples)
{
    esp_err_t ret = ESP_OK;
    ret = dsps_fft2r_init_fc32(NULL, CONFIG_DSP_MAX_FFT_SIZE);
    if (ret != ESP_OK) {
        APP_LOG(LOG_DEBUG, "Not possible to initialize FFT. Error = %i", ret);
        return ret;
    }
    dsps_wind_hann_f32(s_wind, n_samples); /*  gradual hann window */
    return ret;
}

static bool check_valid_data(const adc_digi_output_data_t *data)
{
    const unsigned int unit = data->type2.unit;
    if (unit > 2) return false;
    if (data->type2.channel >= SOC_ADC_CHANNEL_NUM(unit)) return false;
    return true;
}


/**
 * @brief 声音监测功能初始化
 * @param[in]  channel                  [监测通道]
 * @param[in]  s_wind                   [存储采样窗口数据缓存]
 * @param[in]  n_samples                [采样窗口点数]
 * @note
 */
int32_t led_strip_sound_detect_init(uint8_t channel, float *s_wind, int32_t n_samples)
{
    int32_t ret = APP_OK;
    uint16_t adc1_chan_mask  = BIT(channel);

    ret = fft_init(s_wind, n_samples);
    if (ESP_OK != ret)
    {
        APP_LOG(LOG_ERROR, "fft init fail!\n");
        return ret;
    }

    if (NULL == p_sound_buf)
    {
        p_sound_buf = (uint8_t *)vesync_malloc(TIMES);
        if (NULL == p_sound_buf)
        {
            return APP_FAIL;
        }
        memset(p_sound_buf, 0xcc, TIMES);
    }

    adc_digi_init_config_t adc_dma_config = {
        .max_store_buf_size = 4096,
        .conv_num_each_intr = 256,
        .adc1_chan_mask = adc1_chan_mask,
    };
    ret = adc_digi_initialize(&adc_dma_config);
    assert(ret == APP_OK);
    adc_digi_pattern_table_t adc_pattern[10] = {0};

    /* Do not set the sampling frequency out of the range between `SOC_ADC_SAMPLE_FREQ_THRES_LOW` and `SOC_ADC_SAMPLE_FREQ_THRES_HIGH` */
    adc_digi_config_t dig_cfg = {
        .conv_limit_en  = 0,
        .conv_limit_num = 250,
        .sample_freq_hz = AUDIO_SAMPLE,
    };

    dig_cfg.adc_pattern_len = 1;
    uint8_t unit = ((channel >> 3) & 0x1);
    uint8_t ch = channel & 0x7;
    adc_pattern[0].atten   = ADC_ATTEN_11db;
    adc_pattern[0].unit    = unit;
    adc_pattern[0].channel = ch;
    dig_cfg.adc_pattern = adc_pattern;
    ret = adc_digi_controller_config(&dig_cfg);
    assert(ret == APP_OK);

   return ret;
}

/**
 * @brief      将ADC采样数值经过FFT运算后的值存储在y_cf数组中
 * @param[in]  y_cf             Stores the FFT converted array
 * @param[in]  n_samples        FFT sampling points
 * @param[in]  audio_data       Audio source data
 * @param[in]  s_wind           FFT window array
 *      - APP_OK  成功
 *      - APP_FAIL  失败
 */
int32_t led_strip_sound_data_fft(float *y_cf, uint32_t n_samples, \
                                               float *audio_data, float *s_wind)
{
    if ((NULL == y_cf)||(NULL == audio_data)||(NULL == s_wind))
    {
        APP_LOG(LOG_ERROR, "input error!\n");
        return APP_FAIL;
    }

    memset(y_cf, 0, sizeof(float) * n_samples * 2);
    for (int i = 0; i < n_samples; i++) {
        y_cf[i * 2 + 0] = audio_data[i] * s_wind[i];    /* replace real with x1 for internal input signal */
        y_cf[i * 2 + 1] = 0;
    }

    // FFT
    dsps_fft2r_fc32(y_cf, n_samples);
    // Bit reverse
    dsps_bit_rev_fc32(y_cf, n_samples);
    dsps_cplx2reC_fc32(y_cf, n_samples);
    for (int i = 0; i < n_samples / 2; i++) {
        y_cf[i] = 10 * log10f((y_cf[i * 2 + 0] * y_cf[i * 2 + 0] + y_cf[i * 2 + 1] * y_cf[i * 2 + 1]) / n_samples);
    }
    return APP_OK;
}

/**
 * @brief      获取ADC的声音采样数据
 * @param[in]   dc_component       ADC的直流分量
 * @param[in]   audio_data         声音采样数据存储缓存
 * @param[out]  count         声音采样点数
 * @return
 *      - APP_OK  成功
 *      - APP_FAIL  失败
 */
int32_t led_strip_get_sound_data(int32_t dc_component, float *audio_data, int32_t* count)
{
    uint32_t ret_num = 0;
    int32_t ret = APP_OK;
    int32_t tmp_count = 0;
    adc_digi_output_data_t *p = NULL;
    if (NULL == audio_data)
    {
        APP_LOG(LOG_ERROR, "input error!\n");
        return APP_FAIL ;
    }

    if (NULL != p_sound_buf)
    {

        ret = adc_digi_read_bytes(p_sound_buf, TIMES, &ret_num, 50);
        if (ret == ESP_ERR_TIMEOUT)
        {
            APP_LOG(LOG_ERROR, "adc read fail :%d !\n", ret);
            return ret;
        }
        ret = APP_OK;

        for (int i = 0; i < ret_num; i+=4) {
            p = (void *)(p_sound_buf+i);
            if (check_valid_data(p)) {
                audio_data[tmp_count] = (float)(p->type2.data - dc_component);
            } else {
                APP_LOG(LOG_DEBUG, "Invalid data [%d_%d_%x] \n", p->type2.unit+1, p->type2.channel, p->type2.data);
            }
            tmp_count++;
        }
    }
    else
    {
        APP_LOG(LOG_ERROR, "malloc error!\n");
        ret = APP_FAIL;
    }
    *count = tmp_count;
    return ret;
}

/**
 * @brief      开始声音采集
 */
void led_strip_start_sound_detect(void)
{
    int ret = APP_OK;
    /* Start adc */
    ret = adc_digi_start();
    if (ret != APP_OK)
    {
         APP_LOG(LOG_ERROR, "adc start fail!\n");
    }
}


/**
 * @brief      停止声音采集
 */
void led_strip_stop_sound_detect(void)
{
    int ret = APP_OK;
    ret = adc_digi_stop();
    if (ret != APP_OK)
    {
        APP_LOG(LOG_ERROR, "adc stop fail!\n");
    }
}



