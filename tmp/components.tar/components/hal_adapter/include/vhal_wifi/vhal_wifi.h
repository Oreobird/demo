/**
 *  Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
 * @file        vhal_wifi.h
 * @brief       Wi-Fi驱动抽象层，封装厂家SDK提供的Wi-Fi相关接口
 * @date        2021-04-20
 */

#ifndef __VHAL_WIFI_H__
#define __VHAL_WIFI_H__

#include <stdbool.h>
#include <stdint.h>

#include "vesync_common.h"


#ifdef __cplusplus
extern "C"
{
#endif

/*
 * @brief Wi-Fi 2.4G信道定义
 */
typedef enum
{
    VHAL_WIFI_2G4_CHAN1 = 1,            // 2.4G channel 1
    VHAL_WIFI_2G4_CHAN2,                // 2.4G channel 2
    VHAL_WIFI_2G4_CHAN3,                // 2.4G channel 3
    VHAL_WIFI_2G4_CHAN4,                // 2.4G channel 4
    VHAL_WIFI_2G4_CHAN5,                // 2.4G channel 5
    VHAL_WIFI_2G4_CHAN6,                // 2.4G channel 6
    VHAL_WIFI_2G4_CHAN7,                // 2.4G channel 7
    VHAL_WIFI_2G4_CHAN8,                // 2.4G channel 8
    VHAL_WIFI_2G4_CHAN9,                // 2.4G channel 9
    VHAL_WIFI_2G4_CHAN10,               // 2.4G channel 10
    VHAL_WIFI_2G4_CHAN11,               // 2.4G channel 11
    VHAL_WIFI_2G4_CHAN12,               // 2.4G channel 12
    VHAL_WIFI_2G4_CHAN13,               // 2.4G channel 13
    VHAL_WIFI_2G4_CHAN14,               // 2.4G channel 14
    VHAL_WIFI_2G4_CHAN_MAX,
} VHAL_WIFI_CHAN_E;

/*
 * @brief Wi-Fi认证加密模式定义
 */
typedef enum
{
    VHAL_WIFI_AUTH_OPEN = 0,            // authenticate mode: open
    VHAL_WIFI_AUTH_WEP,                 // authenticate mode: WEP
    VHAL_WIFI_AUTH_WPA_PSK,             // authenticate mode: WPA_PSK
    VHAL_WIFI_AUTH_WPA2_PSK,            // authenticate mode: WPA2_PSK
    VHAL_WIFI_AUTH_WPA_WPA2_PSK,        // authenticate mode: WPA_WPA2_PSK
    VHAL_WIFI_AUTH_WPA2_ENTERPRISE,     // authenticate mode: WPA2_ENTERPRISE
    VHAL_WIFI_AUTH_WPA3_PSK,            // authenticate mode: WPA3_PSK
    VHAL_WIFI_AUTH_WPA2_WPA3_PSK,       // authenticate mode: WPA2_WPA3_PSK
    VHAL_WIFI_AUTH_WAPI_PSK,            // authenticate mode: WAPI_PSK
    VHAL_WIFI_AUTH_MAX
} VHAL_WIFI_AUTH_MODE_E;

/*
 * @brief Wi-Fi模式
 */
typedef enum
{
    VHAL_WIFI_MODE_NULL = 0,            // null mode
    VHAL_WIFI_MODE_STA,                 // WiFi station mode
    VHAL_WIFI_MODE_AP,                  // WiFi soft-AP mode
    VHAL_WIFI_MODE_APSTA,               // WiFi station + softAP mode
    //VHAL_WIFI_MODE_MAX
} VHAL_WIFI_MODE_E;

/**
 * @brief Wi-Fi连接事件状态
 */
typedef enum
{
    VHAL_WIFI_INIT = -1,
    VHAL_WIFI_CONNECTING = 0,           // Wi-Fi正在连接
    VHAL_WIFI_CONNECTED,                // Wi-Fi已连接
    VHAL_WIFI_GOT_IP,                   // 获取IP成功
    VHAL_WIFI_LOST_IP,                  // IP丢失
    VHAL_WIFI_WRONG_PWD,                // Wi-Fi密码错误(认证失败)
    VHAL_WIFI_NO_AP_FOUND,              // AP找不到
    VHAL_WIFI_CONNECT_FAIL,             // Wi-Fi连接失败
    VHAL_WIFI_SCAN_DONE,                // 扫描Wi-Fi列表成功
    VHAL_WIFI_STA_CONNECT_SOFTAP,       // 设备作为AP模式时，有STA连接成功
    VHAL_WIFI_STA_DISCONNECT_SOFTAP,    // 设备作为AP模式时，有STA断开连接
} VHAL_WIFI_STATUS_E;

/*
 * @brief Wi-Fi节能模式
 */
typedef enum {
    VHAL_WIFI_PS_NONE = 0,              // Wi-Fi不节能
    VHAL_WIFI_PS_LOW,                   // Wi-Fi运行在常规节能模式
    VHAL_WIFI_PS_ULTRA_LOW,             // Wi-Fi运行在超低功耗模式(每次重连Wi-Fi都先关闭射频链路N秒后再重连)
} VHAL_WIFI_PS_TYPE_E;

/*
 * @brief Wi-Fi station的配置
 */
 typedef struct
{
    char ssid[WIFI_SSID_MAX_LEN];
    char pwd[WIFI_PWD_MAX_LEN];
    VHAL_WIFI_AUTH_MODE_E auth_mode;
} vhal_wifi_sta_cfg_t;


/*
 * @brief  连接Wi-Fi回调函数指针
 * @param[in]  wifi_status              [Wi-Fi状态]
 * @return     void (*)
 */
typedef void (*vhal_wifi_status_cb_t)(VHAL_WIFI_STATUS_E wifi_status);

/*
 * @brief  保存Wi-Fi扫描结果到Wi-Fi扫描列表管理模块的回调函数指针
 * @param[in]  bssid                    [AP的BSSID]
 * @param[in]  ssid                     [AP的SSID]
 * @param[in]  rssi                     [接收到AP的信号强度]
 * @param[in]  auth_mode                [Wi-Fi认证加密模式]
 * @param[in]  total_cnt                [扫描到的AP总个数]
 * @return int (*)
 */
typedef int (*vhal_wifi_scan_cb_t)(const uint8_t* bssid, const uint8_t* ssid, const int8_t rssi,
                                          const int auth_mode, const uint16_t total_count);

/*
 * @brief  Wi-Fi断开连接时传递错误码和错误描述的回调函数指针
 * @param[out] reason_name              [字符串形式重连原因]
 * @return void (*)
 */
typedef void (*vhal_wifi_disc_log_cb_t)(const char* reason_name);

/*
 * @brief  初始化Wi-Fi模块
 * @param[in]  status_cb                [Wi-Fi的连接状态回调函数]
 * @param[in]  power_save               [Wi-Fi节能模式标志位]
 * @param[in]  p_hostname               [DHCP hostname]
 * @param[in]  p_country_code           [长度为2byte的国家码，如：US、EU、CN]
 * @return void
 */
void vhal_wifi_init(vhal_wifi_status_cb_t status_cb, VHAL_WIFI_PS_TYPE_E power_save, char *p_hostname, char *p_country_code);

/*
 * @brief  卸载Wi-Fi驱动
 * @return void
 */
void vhal_wifi_deinit(void);

/*
 * @brief  Wi-Fi启动工作
 * @return void
 */
void vhal_wifi_start(void);

/*
 * @brief Wi-Fi停止工作
 * @return void
 */
void vhal_wifi_stop(void);

/*
 * @brief  设备作为STA，主动发起关联AP
 * @param[in]  p_ssid                   [Wi-Fi的名称]
 * @param[in]  p_pwd                    [Wi-Fi的密码]
 * @param[in]  auth_mode                [Wi-Fi加密模式]
 * @return     int                      [执行成功，返回OK；执行失败，返回FAIL]
 */
int vhal_wifi_connect(char *p_ssid, char *p_pwd, VHAL_WIFI_AUTH_MODE_E auth_mode);

/*
 * @brief  Wi-Fi运行在STA模式时，与router AP的连接状态
 * @param[in]  wait_time_ms             [最大阻塞等待时间]
 * @return     bool                     [关联AP成功且获取IP成功，返回true；否则返回false]
 */
bool vhal_wifi_get_link_status(int32_t wait_time_ms);

/*
 * @brief 设备作为STA时，与AP关联成功，检测到AP的接收信号强度
 * @param[in]  points                   [循环检测的次数]
 * @return     int                      [平均rssi(连续point个测试数据取平均)]
 */
int vhal_wifi_get_router_rssi(int points);

/*
 * @brief 获取当前Wi-Fi信道
 * @return     int                      [Wi-Fi工作信道]
 */
int vhal_wifi_get_channel(void);

/*
 * @brief 设备作为STA时，获取当前连接路由器成功所使用的ssid和密码。
 * @param[out] p_sta_cfg                [保存Wi-Fi连接使用的ssid和密码]
 * @return     int                      [执行成功，返回OK；执行失败，返回FAIL]
 */
int vhal_wifi_get_sta_cfg(vhal_wifi_sta_cfg_t *p_sta_cfg);

/*
 * @brief  注册配网时需要的Wi-Fi回调函数
 * @param[in]  scan_cb                  [Wi-Fi列表扫描结果回调]
 * @param[in]  disconn_cb               [Wi-Fi断开连接时回调]
 * @return void
 */
void vhal_wifi_reg_cfgnet_cb(vhal_wifi_scan_cb_t scan_cb, vhal_wifi_disc_log_cb_t disconn_cb);

/*
 * @brief 撤销注册配网时需要的Wi-Fi回调函数
 */
void vhal_wifi_unreg_cfgnet_cb(void);

/*
 * @brief 硬件抽象层设置设备为WiFi热点
 * @param[in]  wifi_mode  Wi-Fi模式(AP/APSTA)
 * @param[in]  ssid                     [ssid名称]
 * @param[in]  pwd                      [Wi-Fi密码]
 * @param[in]  chan                     [Wi-Fi信道]
 * @param[in]  auth_mode                [加密方式]
 * @return     int                      [执行成功，返回OK；执行失败，返回FAIL]
 */
int vhal_wifi_setup_ap_cfg(VHAL_WIFI_MODE_E wifi_mode, char *ssid, char* pwd, uint8_t chan, uint8_t auth_mode);

/*
 * @brief 关闭Wi-Fi的AP模式，不影响STA接口
 * @return     void            [none]
 */
void vhal_wifi_stop_ap_mode(void);

/*
 * @brief  Wi-Fi开始扫描周围的AP热点
 * @return      int                     [执行成功，返回OK；执行失败，返回FAIL]
 */
int vhal_wifi_scan_start(void);

/*
 * @brief  Wi-Fi停止扫描AP热点
 * @return      int                     [执行成功，返回OK；执行失败，返回FAIL]
 */
int vhal_wifi_scan_stop(void);

#ifdef __cplusplus
}
#endif

#endif /* __VHAL_WIFI_H__ */