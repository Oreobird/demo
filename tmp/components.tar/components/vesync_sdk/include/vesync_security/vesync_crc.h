/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_crc.h
 * @brief       crc检验计算相关接口
 * @date        2021-04-25
 */

#ifndef __VESYNC_CRC_H__
#define __VESYNC_CRC_H__

#ifdef __cplusplus
extern "C" {
#endif


/**
 * @brief 计算crc8
 * @param[in]  data                 [crc数据]
 * @param[in]  len                  [用来计算的起始数据]
 * @param[out] crc8                 [数据的长度]
 * @return int                      [成功返回SDK_OK, 失败返回SDK_FAIL]
 * @note CRC-8算法: MAXIM x8+x5+x4+1
 */
int vesync_crc8(unsigned char const *data, unsigned short len, unsigned char *crc8);

#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_CRC_H__ */

