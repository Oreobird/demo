/**
 * Copyright © Vesync Technologies Co.Ltd. 2022. All rights reserved.
 * @file        vesync_sauth_crypto.c
 * @brief       Vesync SAUTH模块的加密依赖接口实现
 * @author      Herve.Lin
 * @date        2022-01-04
 */
#include <string.h>

#include "vesync_sauth_crypto.h"
#include "vesync_sauth_backend.h"
#if CONFIG_VERYNS_SDK_SAUTH_UNSAFE_CERT
#include "vesync_sauth_cert.h"
#endif

#if CONFIG_VESYNC_SDK_SAUTH_BACKEND_ECC_UECC
// 后端的ECC私钥缓存
static __ALIGN(4) ecc256_sk_t s_dev_sk;
// 后端的ECC证书私钥缓存
static __ALIGN(4) ecc256_sk_t s_dev_crt_sk;
#endif

#if CONFIG_VERYNS_SDK_SAUTH_UNSAFE_CERT
#include "vesync_sauth_cert.h"
static const uint8_t *s_root_pub;
static int s_root_pub_size;
static const uint8_t *s_dev_cert_sk;
static int s_dev_cert_sk_size;
static const uint8_t *s_dev_cert;
static int s_dev_cert_size;

int sauth_crypto_load_unsafe_cert(const uint8_t *p_root_pub, int root_pub_size,
                                  const uint8_t *p_dev_cert_sk, int dev_cert_sk_size,
                                  const uint8_t *p_dev_cert, int dev_cert_size)
{
    s_root_pub = p_root_pub;
    s_root_pub_size = root_pub_size;
    s_dev_cert_sk = p_dev_cert_sk;
    s_dev_cert_sk_size = dev_cert_sk_size;
    s_dev_cert = p_dev_cert;
    s_dev_cert_size = dev_cert_size;

    // 缓存设备证书密钥
    memcpy(s_dev_crt_sk, s_dev_cert_sk, s_dev_cert_sk_size);

    return CRYPTO_OK;
}
#endif

int sauth_crypto_init(crypto_rnd_block_gen_cb_t cb)
{
#if CONFIG_VESYNC_SDK_SAUTH_BACKEND_ECC_UECC
    micro_ecc_init(NULL, cb);
#if CONFIG_VERYNS_SDK_SAUTH_UNSAFE_CERT
    sauth_crypto_load_unsafe_cert(sauth_root_cert_pub, SAUTH_ROOT_CERT_PUB_SIZE,
                                  sauth_dev_cert_pri, SAUTH_DEV_CERT_PRI_SIZE,
                                  sauth_dev_certificate, SAUTH_DEV_CERTIFICATE_SIZE);
#endif
#endif
    return CRYPTO_OK;
}

int sauth_crypto_ecc_keypair_gen(ECC_CURVE_E curve, ecc256_pk_t pk)
{
    if (NULL == pk)
    {
        return CRYPTO_ERROR;
    }
#if CONFIG_VESYNC_SDK_SAUTH_BACKEND_ECC_UECC
    return micro_ecc_keypair_gen(&curve, s_dev_sk, pk);
#endif
}

int sauth_crypto_ecc_pubkey_compute(ECC_CURVE_E curve, const ecc256_sk_t sk, ecc256_pk_t pk)
{
    if (NULL == sk || NULL == pk)
    {
        return CRYPTO_ERROR;
    }
#if CONFIG_VESYNC_SDK_SAUTH_BACKEND_ECC_UECC
    return micro_ecc_public_key_compute(&curve, sk, pk);
#endif
}

int sauth_crypto_ecc_shared_secret_compute(ECC_CURVE_E curve, const ecc256_pk_t pk, ecc256_ss_t ss)
{
    if (NULL == pk || NULL == ss)
    {
        return CRYPTO_ERROR;
    }
#if CONFIG_VESYNC_SDK_SAUTH_BACKEND_ECC_UECC
    return micro_ecc_shared_secret_compute(&curve, s_dev_sk, pk, ss);
#endif
}

int sauth_crypto_ecc_sign_by_dev_crt(ECC_CURVE_E curve, const uint8_t *p_hash, uint8_t *p_sig)
{
    if (NULL == p_hash || NULL == p_sig)
    {
        return CRYPTO_ERROR;
    }
#if CONFIG_VESYNC_SDK_SAUTH_BACKEND_ECC_UECC
#if CONFIG_VERYNS_SDK_SAUTH_UNSAFE_CERT
    return micro_ecc_sign(&curve, (const uint8_t *)s_dev_crt_sk, (const uint8_t *)p_hash, p_sig);
#endif
#endif
}

int sauth_crypto_ecc_verify(ECC_CURVE_E curve, const ecc256_pk_t pk, const uint8_t *p_hash, const uint8_t *p_sig)
{
    if (NULL == pk || NULL == p_hash || NULL == p_sig)
    {
        return CRYPTO_ERROR;
    }
#if CONFIG_VESYNC_SDK_SAUTH_BACKEND_ECC_UECC
    return micro_ecc_verify(&curve, (const uint8_t *)pk, (const uint8_t *)p_hash, (const uint8_t *)p_sig);
#endif
}

int sauth_crypto_ecc_verify_by_root(ECC_CURVE_E curve, const uint8_t *p_hash, const uint8_t *p_sig)
{
#if CONFIG_VERYNS_SDK_SAUTH_UNSAFE_CERT
    return sauth_crypto_ecc_verify(curve, s_root_pub, p_hash, p_sig);
#endif
}

int sauth_crypto_get_crt_len(SAUTH_CERT_TYPE_E type, uint16_t *p_cert_len)
{
    if (NULL == p_cert_len)
    {
        return CRYPTO_ERROR;
    }
    switch (type)
    {
    case SAUTH_DEV_CERT:
#if CONFIG_VESYNC_SDK_SAUTH_BACKEND_ECC_UECC
        *p_cert_len = s_dev_cert_size;
#endif
        break;
    case SAUTH_MANU_CERT:
    case SAUTH_ROOT_CERT:
        *p_cert_len = 0;
    default:
        return CRYPTO_ERROR;
    }
    return CRYPTO_OK;
}

int sauth_crypto_get_crt_der(SAUTH_CERT_TYPE_E type, uint8_t *p_der, uint16_t der_len)
{
    if (NULL == p_der)
    {
        return CRYPTO_ERROR;
    }
    switch (type)
    {
    case SAUTH_DEV_CERT:
#if CONFIG_VESYNC_SDK_SAUTH_BACKEND_ECC_UECC
        memcpy(p_der, s_dev_cert, der_len);
#endif
        break;
    case SAUTH_MANU_CERT:
    case SAUTH_ROOT_CERT:
        break;
    default:
        return CRYPTO_ERROR;
    }
    return CRYPTO_OK;
}

int sauth_crypto_crt_parse_der(const uint8_t *p_der, uint16_t der_len, const sauth_crt_time_t *p_now, sauth_crt_t *p_sauth_crt)
{
#if CONFIG_VESYNC_SDK_SAUTH_BACKEND_CRT_MBEDTLS
    return mbedtls_crt_parse_der(p_der, (size_t)der_len, p_now, p_sauth_crt);
#endif
#if CONFIG_VESYNC_SDK_SAUTH_BACKEND_CRT_MBEDTLS_COMPACT
    return mbedtls_crt_parse_der_compact(p_der, (size_t)der_len, p_now, p_sauth_crt);
#endif
    return CRYPTO_ERROR;
}

int sauth_crypto_sha256(uint8_t *p_in, uint32_t in_len, uint8_t *p_out)
{
#if CONFIG_VESYNC_SDK_SAUTH_BACKEND_SHA256_MBEDTLS
    mbedtls_sha256_port(p_in, in_len, p_out);
#endif
    return CRYPTO_OK;
}

int sauth_crypto_hkdf_sha256(const uint8_t *key, uint8_t key_len, const uint8_t *salt, uint8_t salt_len,
                             const uint8_t *info, uint16_t info_len, uint8_t *out, uint8_t out_len)
{
#if CONFIG_VESYNC_SDK_SAUTH_BACKEND_SHA256_MBEDTLS
    return mbedtls_sha256_hkdf(key, key_len, salt, salt_len, info, info_len, out, out_len);
#endif
    return CRYPTO_ERROR;
}

int sauth_crypto_ccm_encrypt(const uint8_t *key,
                             const uint8_t *iv, size_t iv_len,
                             const uint8_t *add, size_t add_len,
                             const uint8_t *in, size_t in_len,
                             uint8_t *out,
                             uint8_t *tag, size_t tag_len)
{
#if CONFIG_VESYNC_SDK_SAUTH_BACKEND_CCM_MBEDTLS
    return mbedtls_ccm_encrypt_and_tag_port(key, iv, iv_len, add, add_len,
                                            in, in_len, out, tag, tag_len);
#endif
    return CRYPTO_ERROR;
}

int sauth_crypto_ccm_decrypt(const uint8_t *key,
                             const uint8_t *iv, size_t iv_len,
                             const uint8_t *add, size_t add_len,
                             const uint8_t *in, size_t in_len,
                             uint8_t *out,
                             const uint8_t *tag, size_t tag_len)
{
#if CONFIG_VESYNC_SDK_SAUTH_BACKEND_CCM_MBEDTLS
    return mbedtls_ccm_auth_dencrypt_port(key, iv, iv_len, add, add_len,
                                          in, in_len, out, tag, tag_len);
#endif
    return CRYPTO_ERROR;
}