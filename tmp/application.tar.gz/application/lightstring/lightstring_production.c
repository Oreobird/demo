/**
*Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file    lightstring_production.c
* @brief   产测功能
* @author  Lind
*@date     2021-12-20
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "vesync_common.h"
#include "vesync_log.h"
#include "vesync_device.h"
#include "vesync_production.h"

#include "lightstring.h"
#include "lightstring_button.h"
#include "lightstring_production.h"
#include "lightstring_flash.h"
#include "lightstring_report.h"

/**
* @brief 产测状态回调函数
* @param[in]  status          [产测状态码]
*/
static void ls_production_status_cb(PRODUCTION_STATUS_E status)
{
    ls_ev_t ev;
    memset(&ev, 0,sizeof(ls_ev_t));
    ev.id = LS_EV_PRODUCTION;
    ev.act_src = LS_ACT_SRC_PRODUCTION;
    switch(status)
    {
        case PRODUCTION_START:
            ls_button_task_exit();
            ev.param.mode_param.scene_id = 0;
            break;
        case PRODUCTION_RUNNING:
            ev.param.mode_param.scene_id = 1;
            break;
        case PRODUCTION_TEST_PASS:
            APP_LOG(LOG_INFO, "production pass\n");
            ev.param.mode_param.scene_id = 2;
            ls_clear_config();
            break;
        case PRODUCTION_TEST_FAIL:
            APP_LOG(LOG_INFO, "production fail\n");
            ev.param.mode_param.scene_id = 3;
            break;
        default:
            break;
    }
    if (status < PRODUCTION_EXIT)
    {
        ls_app_task_notify(&ev);
        ls_report_set_chg_rsn(STAT_CHG_RSN_PRODUCTION_STR);
    }
}

/**
* @brief 产测结果回调函数
* @param[in]  err_code          [产测状态码]
*/
static void ls_production_result_cb(PRODUCTION_ERROR_E err_code)
{
    if (PRD_NO_ERR == err_code)
    {
        APP_LOG(LOG_INFO, "production success\n");
    }
    else
    {
        APP_LOG(LOG_INFO, "production error %d\n", err_code);
    }
}

/**
* @brief ledstrip产测功能初始化
*/
void ls_production_init(void)
{
    vesync_production_reg_status_cb(ls_production_status_cb);
    vesync_production_reg_result_cb(ls_production_result_cb);
}

