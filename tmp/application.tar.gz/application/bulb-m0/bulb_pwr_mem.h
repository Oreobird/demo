/**
 * Copyright © Vesync Technologies Co.Ltd. 2022. All rights reserved.
 * @file        bulb_pwr_mem.h
 * @brief       Bulb断电记忆接口声明
 * @author      Herve
 * @date        2022-01-21
 */
#ifndef __BULB_PWR_MEM_H__
#define __BULB_PWR_MEM_H__

#include <stdint.h>

#include "bulb.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief Bulb 上电记忆模块初始化
 * @return      int                 [成功：APP_OK， 失败：APP_FAIL]
 */
int bulb_pwr_mem_init(void);

/**
 * @brief Bulb 上电记忆模块读取配置
 * @param[out]  p_mode              [指向输出模式缓存]
 * @param[out]  p_act               [指向输出动作数据缓存]
 * @return      int                 [成功：APP_OK， 失败：APP_FAIL]
 */
int bulb_pwr_mem_get(uint8_t *p_mode, bulb_action_t *p_act);

/**
 * @brief Bulb 上电记忆模块写入配置
 * @param[in]   p_mode              [指向输入新模式缓存]
 * @param[in]   p_act               [指向输入新动作数据缓存]
 * @return      int                 [成功：APP_OK， 失败：APP_FAIL]
 */
int bulb_pwr_mem_set(uint8_t *p_mode, bulb_action_t *p_act);

/**
 * @brief Bulb 上电记忆模块清除自定义配置
 * @return      int                 [成功：APP_OK， 失败：APP_FAIL]
 */
int bulb_pwr_mem_clear(void);

#ifdef __cplusplus
}
#endif

#endif /* __BULB_PWR_MEM_H__ */