/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        bulb_switch.c
 * @brief       bulb上电触发事件
 * @author      Dave.Ming
 * @date        2021-09-06
 */

#ifndef __BULB_SWITCH_H__
#define __BULB_SWITCH_H__

#ifdef __cplusplus
extern "C" {
#endif

/**
* @brief bulb设备上电事件的回调
*/
void bulb_switch_poweron_cb(void);

/**
 * @brief bulb更新上电开关触发计数
 */
void bulb_switch_upd_poweron_cnt(void);

#ifdef __cplusplus
}
#endif

#endif


