/**
 * Copyright © Etekcity Technologies Co., Ltd. 2021. All rights reserved.
 * @file        vesync_certificate.h
 * @brief       处理ffs 证书以及相关设备私钥更新
 * @author      Owen.zhang
 * @date        2020-03-02
 */
#ifndef _VESYNC_FFS_FLASH_H_
#define _VESYNC_FFS_FLASH_H_

#include <stdint.h>
#include <stdbool.h>
#include "vesync_net_service_internal.h"

#ifdef __cplusplus
extern "C"
{
#endif

#define VERR_FLASH_WRITE_FAIL 0
#define VERR_FLASH_ERASE_FAIL 1


// ffs信息
#define USER_CFG_KEY_FFS_CLIENT_CHAIN       "ffs_cli_chain"             //
#define USER_CFG_KEY_FFS_CA_CHAIN           "ffs_ca_chain"              // CA证书
#define USER_CFG_KEY_FFS_PRIVATE_KEY        "ffs_private_key"           // 私钥
#define USER_CFG_KEY_FFS_FFS_RESULT         "ffs_result"                // ffs配网结果
#define FFS_RESULT_MAGIC                    0xABCD                      // 随机数

/*
 * @brief ffs存储的flash数据
 */
typedef struct
{
    uint16_t magic;
    bool result;
} ffs_result_flash_data_t;


/**
 * @brief 读取"DHA private key"
 * @param[out] char            [保存private key的缓存]
 * @param[in]  int             [缓存长度]
 * @return     int             [成功/失败]
 */
int vesync_ffs_flash_read_dha_private_key(char *p_key, int* buf_len);

/**
 * @brief 写"DHA private key"
 * @param[in]  char            [待写入的private key]
 * @param[in]  int             [长度]
 * @return     int             [成功/失败]
 */
int vesync_ffs_flash_write_dha_private_key(char *p_key, int buf_len);

/**
 * @brief 读取"certificate chain"
 * @param[out] char            [保存certificate chain的缓存]
 * @param[in]  int             [缓存长度]
 * @return     int             [成功/失败]
 */
int vesync_ffs_flash_read_cert_chain(char *p_key, int *buf_len);

/**
 * @brief 写"certificate chain"
 * @param[in]  char            [待写入的certificate chain]
 * @param[in]  int             [长度]
 * @return     int             [成功/失败]
 */
int vesync_ffs_flash_write_cert_chain(char *p_key, int buf_len);

/**
 * @brief 写读取ffs配网结果到flash中
 * @param[in]  ffs_result_flash_data_t [待写入的ffs配网结果]
 * @param[in]  int             [长度]
 * @return     int             [成功/失败]
 */
int vesync_ffs_flash_write_result_data(ffs_result_flash_data_t *p_data);

/**
 * @brief 从flash中读取ffs配网结果数据到内存
 * @param[out] ffs_result_flash_data_t  [配网结果]
 * @param[out] len                      [长度]
 * @return     int               [成功/失败]
 */
int vesync_ffs_flash_read_result_data(ffs_result_flash_data_t *p_data , uint32_t *len);

/**
 * @brief 清除ffs配网结果
 * @return int
 */
int vesync_ffs_flash_clear_result_data(void);

#ifdef __cplusplus
}
#endif

#endif //_VESYNC_FFS_FLASH_H_

