/**
 * Copyright © Vesync Technologies Co.Ltd. 2019-2021. All rights reserved.
 * @file    lightstring_schedule.c
 * @brief   Schedule 模块
 * @author  Lind
 * @date    2021-12-20
 */

#include <string.h>
#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>

#include "vhal_flash.h"

#include "vesync_common.h"
#include "vesync_log.h"
#include "vesync_memory.h"
#include "vesync_schedule.h"
#include "vesync_device.h"
#include "vesync_klv.h"
#include "vesync_buffer.h"

#include "lightstring.h"
#include "lightstring_board.h"
#include "lightstring_report.h"
#include "lightstring_schedule.h"
#include "lightstring_bypass.h"
#include "lightstring_flash.h"

/**
* @brief 将schedule应用层数据转为klv格式
* @param[out]  *p_buf       [存入的buf]
* @param[in]  app_cfg       [应用层数据]
*/
static int ls_sche_klv_buf_set(vesync_buf_t *app_cfg_buf, ls_schedule_t app_cfg)
{
    uint16_t len = 0;
    uint8_t *p_buf = (uint8_t*)vesync_malloc(LS_KLV_DATE_LEN);
    if (p_buf == NULL)
    {
        return APP_FAIL;
    }

    memset(p_buf, 0, LS_KLV_DATE_LEN);
    len +=  vesync_klv_set(p_buf+len, LS_KLV_DATE_LEN-len, LS_SCHE_KLV_MODE, sizeof(app_cfg.mode), (uint8_t*)&app_cfg.mode);
    len +=  vesync_klv_set(p_buf+len, LS_KLV_DATE_LEN-len, LS_SCHE_KLV_SCENE_ID, sizeof(app_cfg.scene_id), (uint8_t*)&app_cfg.scene_id);


    vesync_buf_set(app_cfg_buf, (void *)p_buf, len);
    VCOM_SAFE_FREE(p_buf);
    APP_LOG(LOG_DEBUG, "Schedule app_cfg buffer len: %d\n", len);
    return APP_OK;
}

/**
* @brief 将klv格式的schedule应用层数据读出
* @param[in]  *p_app_buf    [要读取的buf]
* @param[out]  *p_app_cfg   [应用层数据]
*/
static void ls_sche_klv_buf_get(vesync_buf_t *p_app_buf, ls_schedule_t *p_app_cfg)
{
    vesync_klv_get((uint8_t*)p_app_buf->buf, p_app_buf->len, LS_SCHE_KLV_MODE, sizeof(LS_MODE_E), (uint8_t*)&p_app_cfg->mode);
    vesync_klv_get((uint8_t*)p_app_buf->buf, p_app_buf->len, LS_SCHE_KLV_SCENE_ID, sizeof(uint8_t), (uint8_t*)&p_app_cfg->scene_id);
}


/**
* @brief Schedule模块任务执行回调
* @param[in]  sch_cfg   [schedule配置]
* @param[in]  app_cfg   [schedule应用层配置]
* @return     int       [APP_OK/APP_FAIL]
*/
static int ls_module_exec_cb(vesync_schedule_t sch_cfg, vesync_buf_t app_cfg)
{

    ls_schedule_t *ls_cfg = (ls_schedule_t*)vesync_malloc(sizeof(ls_schedule_t));
    if (NULL == ls_cfg)
    {
        return APP_FAIL;
    }

    memset(ls_cfg, 0, sizeof(ls_schedule_t));
    ls_sche_klv_buf_get(&app_cfg, ls_cfg);

    ls_ev_t ev;
    memset(&ev, 0, sizeof(ls_ev_t));
    ev.act_src = LS_ACT_SRC_SCHEDULE;
    if (ls_cfg->mode == LS_MODE_OFF)
    {
        ev.id = LS_EV_OFF;
    }
    else
    {
        ev.id = LS_EV_ON;
        ev.param.mode_param.mode = ls_cfg->mode;
        ev.param.mode_param.scene_id = ls_cfg->scene_id;
    }
    ls_report_schedule_exec(sch_cfg.id, sch_cfg.type, sch_cfg.repeat_config, ls_cfg, 0, STAT_CHG_RSN_SCHD_STR);
    ls_app_task_notify(&ev);
    return APP_OK;
}

/**
* @brief 初始化Schedule功能
* @return int  [返回APP的错误定义： APP_OK, APP_FAIL]
*/
int ls_schedule_init(void)
{
    int ret = 0;

    // 初始化Schedule模块
    if (SCHE_OK != vesync_schedule_main_init())
    {
        APP_LOG(LOG_ERROR, "Schedule module init fail\n");

        return APP_FAIL;
    }

    vesync_schedule_param_t schedule_param;
    memset(&schedule_param, 0, sizeof(vesync_schedule_param_t));
    schedule_param.exec_app_task_cb = ls_module_exec_cb;
    schedule_param.max_app_cfg_size = LS_SCHEDULE_MAX_APP_CFG_SIZE;
    schedule_param.max_sche_nbr = LS_SCHEDULE_MAX_NUM;
    schedule_param.min_id_limit = LS_SCHEDULE_MIN_ID;
    ret = vesync_schedule_new_instance(LS_SCHE_INS_ID, &schedule_param);
    if (ret != SCHE_OK)
    {
        APP_LOG(LOG_ERROR, "Schedule instance init error: [%ld]\n", ret);
        return APP_FAIL;
    }

    return APP_OK;
}

/**
* @brief 应用层json数据解析
* @param[in]  *p_json       [待解析数据]
* @param[out]  *app_cfg     [schedule应用层数据]
* @return  int              [错误码]
*/
static int ls_schedule_app_params_cpy(cJSON *p_json, ls_schedule_t *app_cfg)
{
    cJSON* json_obj = NULL;
    cJSON* json_act = NULL;
    cJSON* json_type = NULL;
    uint8_t ret = 0;

    int arr_size = cJSON_GetArraySize(p_json);
    if (arr_size > 2)
    {
        return BP_ERR_PARA_ILLEGAL;
    }
    for (int i = 0; i < arr_size; i++)
    {
        json_obj = cJSON_GetArrayItem(p_json, i);
        if (NULL == json_obj)
        {
            return BP_ERR_PARA_ILLEGAL;
        }
        json_type = cJSON_GetObjectItemCaseSensitive(json_obj, "type");
        if (0 == strcmp(json_type->valuestring, "switch"))
        {
            json_act = cJSON_GetObjectItemCaseSensitive(json_obj, "act");
            if (0 == strcmp(json_act->valuestring, "off"))
            {
                app_cfg->mode = LS_MODE_OFF;
                break;
            }
        }
        else if (0 == strcmp(json_type->valuestring, "color_mode"))
        {
            app_cfg->mode = LS_MODE_SCENE;
            json_act = cJSON_GetObjectItemCaseSensitive(json_obj, "act");
            if (!cJSON_IsString(json_act))
            {
                return BP_ERR_PARA_ILLEGAL;
            }

            cJSON *json_param = NULL;
            cJSON *json_id = NULL;
            json_param = cJSON_GetObjectItemCaseSensitive(json_obj, "params");
            if (NULL == json_param)
            {
                return BP_ERR_PARA_ILLEGAL;
            }

            if (0 == strcmp(json_act->valuestring, "scenario"))
            {
                app_cfg->mode = LS_MODE_SCENE;
                json_id = cJSON_GetObjectItemCaseSensitive(json_param, "sceneId");
            }
            else if (0 == strcmp(json_act->valuestring, "music"))
            {
                app_cfg->mode = LS_MODE_MUSIC;
                json_id = cJSON_GetObjectItemCaseSensitive(json_param, "musicModeId");
            }
            else
            {
                return BP_ERR_PARA_ILLEGAL;
            }

            if (NULL == json_id)
            {
                return BP_ERR_PARA_ILLEGAL;
            }
            else
            {
                VCOM_IN_RANGE_CHK( json_id->valueint, 1, (app_cfg->mode == LS_MODE_SCENE ? LS_MODE_NUM : LS_MODE_MUSIC_NUM),
                                 (ret++));
                if (ret)
                {
                    return BP_ERR_PARA_ILLEGAL;
                }
                app_cfg->scene_id = json_id->valueint;
            }
        }
        else
        {
            return BP_ERR_PARA_ILLEGAL;
        }
    }

    return BP_ERR_NO_ERR;
}

/**
* @brief Bypass添加Schedule配置项
* @param[in]  p_bp_msg     [Bypass添加的Schedule配置项信息]
* @param[out] p_out_id     [添加成功后，返回生成的ID]
* @return int              [返回BYPASS的错误定义]
*/
int ls_schedule_add(bypass_schedule_base_t *p_bp_msg, uint32_t *p_out_id)
{
    if (NULL == p_bp_msg || NULL == p_out_id)
    {
        return BP_ERR_PARA_ILLEGAL;
    }

    int ret = 0;
    vesync_schedule_t sch_cfg;     // Schedule 模块的配置项定义
    ls_schedule_t app_cfg; // Schedule 应用的配置项定义

    memset(&app_cfg, 0, sizeof(app_cfg));
    memset(&sch_cfg, 0, sizeof(sch_cfg));
    // Enabled 是必选项
    // Repeat Config 是必选项
    // Type 是必选项
    if (NULL == p_bp_msg->enabled ||
        NULL == p_bp_msg->repeat_config ||
        NULL == p_bp_msg->type ||
        NULL == p_bp_msg->json_action)
    {
        return BP_ERR_PARA_ILLEGAL;
    }
    sch_cfg.enabled = (bool)*p_bp_msg->enabled;
    sch_cfg.repeat_config = (uint8_t)*p_bp_msg->repeat_config;

    switch (*p_bp_msg->type)
    {
        case BYPASS_SCHEDULE_JSON_TYPE_TMG_EVT:
            sch_cfg.type = SCHE_TMG_EVT;
            //
            if (NULL == p_bp_msg->clock_sec)
            {
                return BP_ERR_PARA_ILLEGAL;
            }
            sch_cfg.event_config.timing.clock_sec = (uint32_t)*p_bp_msg->clock_sec;
            break;
        case BYPASS_SCHEDULE_JSON_TYPE_SUN_EVT:
            sch_cfg.type = SCHE_SUN_EVT;
            //
            if (NULL == p_bp_msg->is_sunrise)
            {
                APP_LOG(LOG_ERROR, "JSON parse error.\n");
                return BP_ERR_PARA_ILLEGAL;
            }
            if (NULL == p_bp_msg->offset_sec)
            {
                APP_LOG(LOG_ERROR, "JSON parse error.\n");
                return BP_ERR_PARA_ILLEGAL;
            }
            sch_cfg.event_config.sun.is_sunrise = (bool)*p_bp_msg->is_sunrise;
            sch_cfg.event_config.sun.offset_sec = (int32_t)*p_bp_msg->offset_sec;
            if (sch_cfg.event_config.sun.offset_sec > LS_SCHE_SUNEVT_MAX_SEC
                || sch_cfg.event_config.sun.offset_sec < LS_SCHE_SUNEVT_MIN_SEC)
            {
                APP_LOG(LOG_ERROR, "JSON parse error.\n");
                return BP_ERR_VALUE_OUT_OF_RANGE;
            }
            break;
        default:
            APP_LOG(LOG_ERROR, "JSON parse error.\n");
            return BP_ERR_PARA_ILLEGAL;
    }

    // 解析
    ret = ls_schedule_app_params_cpy(p_bp_msg->json_action, &app_cfg);
    if (ret != BP_ERR_NO_ERR)
    {
        return ret;
    }
    // 缓存应用层的配置

    vesync_buf_t app_cfg_buf = vesync_buf_new();
    if (APP_FAIL == ls_sche_klv_buf_set(&app_cfg_buf, app_cfg))
    {
        return BP_ERR_OUT_OF_MEMORY;
    }
    // 调用模块的添加Schedule接口；Schedule配置项ID由模块生成
    ret = vesync_schedule_add(LS_SCHE_INS_ID, &sch_cfg, &app_cfg_buf, true);
    if (ret != SCHE_OK)
    {
        APP_LOG(LOG_WARN, "Schedule added fail: %d\n", ret);
        vesync_buf_clr(&app_cfg_buf);
        if (ret == SCHE_CFLT_ERR)
        {
            return BP_ERR_SCHEDULE_CONFLICT;
        }

        if (ret == SCHE_EXCEED_MAX)
        {
            return BP_ERR_SCHEDULE_EXCEED_MAX;
        }

        return BP_ERR_UNDEFINE;
    }

    // 添加的配置项ID返回给BP调用端
    *p_out_id = sch_cfg.id;

    // 销毁缓存
    vesync_buf_clr(&app_cfg_buf);
    return BP_ERR_NO_ERR;
}

/**
* @brief Bypass更新Schedule配置项
* @param[in]  p_bp_msg     [Bypass需要修改的相关Schedule配置项信息，注意有的字段是可选的]
* @param[out] p_out_id     [更新Schedule配置项后返回对于的配置项ID]
* @return int              [返回BYPASS的错误定义]
*/
int ls_schedule_upd(bypass_schedule_base_t *p_bp_msg, uint32_t *p_out_id)
{
    if (NULL == p_bp_msg || NULL == p_out_id)
    {
        return BP_ERR_PARA_ILLEGAL;
    }

    // ID 是必选项
    if (0 == p_bp_msg->id || LS_SCHEDULE_MIN_ID > p_bp_msg->id)
    {
        return BP_ERR_PARA_ILLEGAL;
    }
    uint32_t id = (uint32_t)p_bp_msg->id;

    int ret = BP_ERR_UNDEFINE;
    vesync_schedule_t sch_cfg;
    ls_schedule_t app_cfg;
    memset(&app_cfg, 0, sizeof(app_cfg));
    memset(&sch_cfg, 0, sizeof(sch_cfg));

    vesync_buf_t app_cfg_buf = vesync_buf_new();
    // 先把更新前的配置读出来作修改
    ret = vesync_schedule_get_by_id(LS_SCHE_INS_ID, id, &sch_cfg, &app_cfg_buf);
    if (ret != SCHE_OK)
    {
        if (ret != SCHE_INV_ID_ERR)
        {
            ret = BP_ERR_UNDEFINE;
            goto EXIT;
        }

        ret = BP_ERR_SCHEDULE_NOT_FOUND;
        goto EXIT;
    }

    // Enabled 是可选项
    sch_cfg.enabled = (NULL != p_bp_msg->enabled) ? (bool)*p_bp_msg->enabled : sch_cfg.enabled;
    // Repeat Config 是可选项
    sch_cfg.repeat_config = (NULL != p_bp_msg->repeat_config) ? (uint8_t)*p_bp_msg->repeat_config : sch_cfg.repeat_config;

    // Type 是可选项
    if (NULL != p_bp_msg->type)
    {
        switch (*p_bp_msg->type)
        {
            case BYPASS_SCHEDULE_JSON_TYPE_TMG_EVT:
                sch_cfg.type = SCHE_TMG_EVT;
                // Clock Second 是可选字段
                sch_cfg.event_config.timing.clock_sec = (NULL != p_bp_msg->clock_sec) ? (uint32_t)*p_bp_msg->clock_sec : sch_cfg.event_config.timing.clock_sec;
                break;
            case BYPASS_SCHEDULE_JSON_TYPE_SUN_EVT:
                sch_cfg.type = SCHE_SUN_EVT;
                // Is Sunrise 是可选字段
                sch_cfg.event_config.sun.is_sunrise = (NULL != p_bp_msg->is_sunrise) ? (bool)*p_bp_msg->is_sunrise : sch_cfg.event_config.sun.is_sunrise;
                // Offset 是可选字段
                sch_cfg.event_config.sun.offset_sec = (NULL != p_bp_msg->offset_sec) ? (int32_t)*p_bp_msg->offset_sec : sch_cfg.event_config.sun.offset_sec;
                // 日出日落时间边界判断
                if (sch_cfg.event_config.sun.offset_sec > LS_SCHE_SUNEVT_MAX_SEC
                || sch_cfg.event_config.sun.offset_sec < LS_SCHE_SUNEVT_MIN_SEC)
                {
                    APP_LOG(LOG_ERROR, "JSON parse error.\n");
                    ret = BP_ERR_VALUE_OUT_OF_RANGE;
                    goto EXIT;
                }
                break;
            default:
                ret = BP_ERR_PARA_ILLEGAL;
                goto EXIT;
        }
    }
    // 可选字段
    if (NULL != p_bp_msg->json_action)
    {
        // 解析
        ret = ls_schedule_app_params_cpy(p_bp_msg->json_action, &app_cfg);
        if (ret != BP_ERR_NO_ERR)
        {
            goto EXIT;
        }

        // APP配置直接覆盖处理
        if (APP_FAIL == ls_sche_klv_buf_set(&app_cfg_buf, app_cfg))
        {
            ret = BP_ERR_OUT_OF_MEMORY;
            goto EXIT;
        }
    }

    ret = vesync_schedule_upd(LS_SCHE_INS_ID, &sch_cfg, &app_cfg_buf);
    if (ret != SCHE_OK)
    {
        if (ret != SCHE_CFLT_ERR)
        {
            ret = BP_ERR_UNDEFINE;
            goto EXIT;
        }

        ret = BP_ERR_SCHEDULE_CONFLICT;
        goto EXIT;
    }

    // 操作的配置项ID返回给BP调用端
    *p_out_id = sch_cfg.id;
    ret = BP_ERR_NO_ERR;
EXIT:
    // 销毁APP配置缓存
    vesync_buf_clr(&app_cfg_buf);
    return ret;
}

/**
* @brief Bypass按顺序获取Schedule多个配置项
* @note  返回多少个连续的配置项是由Schedule模块决定
* @param[in]  index        [要获取的Schedule配置项的初始序号]
* @param[in]  p_buf        [用于读取Schedule配置项的缓存，函数内会作缓存的分配,调用结束后需要释放]
* @param[out] p_out_list   [指向输出读取结果的列表]
* @param[in]  total_num    [配置项总数]
* @return int              [返回BYPASS的错误定义]
*/
int ls_schedule_get_mult(uint32_t index, void **p_buf, bypass_schedule_base_t *p_out_list, uint32_t *total_num)
{
    if (NULL == p_buf || NULL == p_out_list)
    {
        return BP_ERR_PARA_ILLEGAL;
    }

    *p_buf = vesync_malloc(LS_SCHEDULE_GET_MAX_NUM * sizeof(vesync_schedule_t));
    if (NULL == *p_buf)
    {
        return BP_ERR_UNDEFINE;
    }
    // Schedule 模块配置读取Buffer
    vesync_schedule_t *p_sch_cfg = (vesync_schedule_t *)*p_buf;
    // Schedule 模块配置读取数量
    uint32_t sch_cfg_num = 0;

    vesync_buf_t app_cfg_buf[LS_SCHEDULE_GET_MAX_NUM];
    // APP配置读取缓存初始化
    for (uint32_t i = 0; i < LS_SCHEDULE_GET_MAX_NUM; i++)
    {
        app_cfg_buf[i] = vesync_buf_new();
    }

    int ret = vesync_schedule_get_by_index(LS_SCHE_INS_ID, index, LS_SCHEDULE_GET_MAX_NUM, total_num, p_sch_cfg, app_cfg_buf, &sch_cfg_num);
    if (ret != SCHE_OK)
    {
        if (ret == SCHE_INV_IDX_ERR)
        {
            ret = BP_ERR_SCHEDULE_NOT_FOUND;
            goto EXIT;
        }

        ret = BP_ERR_UNDEFINE;
        goto EXIT;
    }

    for (uint32_t cnt = 0; cnt < sch_cfg_num; cnt ++)
    {
        p_out_list[cnt].id = p_sch_cfg[cnt].id;

        // 读取应用层的配置
        ls_schedule_t app_cfg;
        memset(&app_cfg, 0, sizeof(ls_schedule_t));
        ls_sche_klv_buf_get(&app_cfg_buf[cnt], &app_cfg);

        // startAct JSON Section
        cJSON *json_sch_act = cJSON_CreateArray();
        cJSON *json_sch_switch = cJSON_CreateObject();
        cJSON *json_sch_action = cJSON_CreateObject();
        cJSON *json_sch_params = cJSON_CreateObject();
        if ((NULL != json_sch_switch) && (NULL != json_sch_act) && (NULL != json_sch_action) && (NULL != json_sch_params))
        {
            cJSON_AddStringToObject(json_sch_switch, "type", "switch");
            cJSON_AddNumberToObject(json_sch_switch, "num", 0);

            if (LS_MODE_OFF == app_cfg.mode)
            {
                cJSON_AddStringToObject(json_sch_switch, "act", "off");
                cJSON_Delete(json_sch_action);
                cJSON_Delete(json_sch_params);
            }
            else
            {
                cJSON_AddStringToObject(json_sch_switch, "act", "on");
                cJSON_AddStringToObject(json_sch_action, "type", "color_mode");
                cJSON_AddNumberToObject(json_sch_action, "num", 0);
                cJSON_AddItemToObject(json_sch_action, "params", json_sch_params);
                if (LS_MODE_SCENE == app_cfg.mode)
                {
                    cJSON_AddStringToObject(json_sch_action, "act", "scenario");
                    cJSON_AddNumberToObject(json_sch_params, "sceneId", app_cfg.scene_id);
                }
                else
                {
                    cJSON_AddStringToObject(json_sch_action, "act", "music");
                    cJSON_AddNumberToObject(json_sch_params, "musicModeId", app_cfg.scene_id);
                }
                cJSON_AddItemToArray(json_sch_act, json_sch_action);
            }
            cJSON_AddItemToArray(json_sch_act, json_sch_switch);
        }
        else
        {
            APP_LOG(LOG_ERROR, "JSON creates fail.\n");
            cJSON_Delete(json_sch_act);
            cJSON_Delete(json_sch_switch);
            cJSON_Delete(json_sch_action);
            cJSON_Delete(json_sch_params);
            ret = BP_ERR_OUT_OF_MEMORY;
            goto EXIT;
        }
        p_out_list[cnt].json_action = json_sch_act;
        p_out_list[cnt].enabled = (int32_t *)&p_sch_cfg[cnt].enabled;

        if (p_sch_cfg[cnt].type == SCHE_TMG_EVT)
        {
            p_sch_cfg[cnt].type = BYPASS_SCHEDULE_JSON_TYPE_TMG_EVT;
            p_out_list[cnt].clock_sec = (int32_t *)&p_sch_cfg[cnt].event_config.timing.clock_sec;
        }
        else if (p_sch_cfg[cnt].type == SCHE_SUN_EVT)
        {
            p_sch_cfg[cnt].type = BYPASS_SCHEDULE_JSON_TYPE_SUN_EVT;
            p_out_list[cnt].is_sunrise = (int32_t *)&p_sch_cfg[cnt].event_config.sun.is_sunrise;
            p_out_list[cnt].offset_sec = (int32_t *)&p_sch_cfg[cnt].event_config.sun.offset_sec;
        }
        else
        {
            ret = BP_ERR_UNDEFINE;
            cJSON_Delete(json_sch_act);
            cJSON_Delete(json_sch_switch);
            cJSON_Delete(json_sch_action);
            cJSON_Delete(json_sch_params);
            goto EXIT;
        }
        // Type 处理
        p_out_list[cnt].type = (int32_t *)&p_sch_cfg[cnt].type;

        p_out_list[cnt].repeat_config = (int32_t *)&p_sch_cfg[cnt].repeat_config;
    }

    ret = BP_ERR_NO_ERR;

EXIT:
    // 销毁APP配置读取缓存
    for (uint32_t i = 0; i < LS_SCHEDULE_GET_MAX_NUM; i++)
    {
        vesync_buf_clr(&app_cfg_buf[i]);
    }
    return ret;
}

/**
* @brief Bypass删除指定ID的Schedule配置项
* @param[in]  id_to_del    [要删除的Schedule配置项ID]
* @return int              [返回BYPASS的错误定义]
*/
int ls_schedule_del(uint32_t id_to_del)
{
    int ret = 0;
    ret = vesync_schedule_del(LS_SCHE_INS_ID, id_to_del);
    if (ret != 0)
    {
        if (ret != SCHE_INV_ID_ERR)
        {
            return BP_ERR_UNDEFINE;
        }
        return BP_ERR_SCHEDULE_NOT_FOUND;
    }

    return BP_ERR_NO_ERR;
}

/**
* @brief App层调用，复位Schedule的所有配置信息
* @return int [返回APP的错误定义： APP_OK, APP_FAIL]
*/
int ls_schedule_clear(void)
{
    vesync_schedule_clear(LS_SCHE_INS_ID);

    return APP_OK;
}

