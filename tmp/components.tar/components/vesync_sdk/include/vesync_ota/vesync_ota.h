/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_ota.h
 * @brief       OTA升级Wi-Fi固件接口
 * @date        2021-05-19
 */

#ifndef __VESYNC_OTA_H__
#define __VESYNC_OTA_H__

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif


/**
* @brief 获取设备工作状态回调函数指针
* @return bool
*/
typedef bool (*vesync_ota_get_work_status_cb_t)(void);

/**
* @brief 通知设备停止工作回调函数指针
*/
typedef void (*vesync_ota_stop_work_cb_t)(void);

/**
* @brief  升级前/升级失败，需要进行的处理
* @param[in]  bool            [true表示升级前；false表示升级失败]
*/
typedef void (*vesync_ota_process_cb_t)(bool before);

/**
* @brief mcu升级结果回调函数指针
* @param[in] err_code         [MCU升级结果错误码]
*/
typedef void (*vesync_ota_mcu_upgrade_cb_t)(uint32_t err_code);

/**
 * @brief 注册获取工作状态回调函数
 * @param[in] cb              [应用层获取工作状态回调函数]
 */
void vesync_ota_reg_work_status_cb(vesync_ota_get_work_status_cb_t cb);

/**
 * @brief 注册停止设备工作回调函数
 * @param[in] cb              [应用层获取工作状态回调函数]
 */
void vesync_ota_reg_stop_work_cb(vesync_ota_stop_work_cb_t cb);

/**
 * @brief 注册"升级前准备工作/升级失败"处理回调函数
 * @param[in] cb              [应用层处理"升级前准备工作/升级失败"函数]
 */
void vesync_ota_reg_before_and_after_process(vesync_ota_process_cb_t cb);


#if (CONFIG_VESYNC_SDK_HTTP_ENABLE && PR_OTA_TYPE_MCU > 0)
/**
 * @brief 注册mcu固件升级结果回调函数
 * @param[in]                 [mcu固件升级结果回调函数]
 */
void vesync_ota_reg_mcu_upgrade_result_cb(vesync_ota_mcu_upgrade_cb_t cb);
#endif


/**
 * @brief 获取升级错误码
 * @return uint8_t            [升级错误码]
 */
uint8_t vesync_ota_get_upgrade_code(void);


/**
 * @brief 获取MCU升级错误码
 * @return uint8_t            [mcu升级错误码]
 */
uint8_t vesync_ota_mcu_get_upgrade_code(void);


#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_OTA_H__ */

