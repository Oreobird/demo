/**
* Copyright © Vesync Technologies Co.Ltd. 2022. All rights reserved
* @file         ledstrip_sunset_scene_impl.c
* @brief        日落场景回调业务实现
* @author       Joshua
* @date         2022-1-14
*/

#include <string.h>
#include "vesync_log.h"
#include "vesync_common.h"
#include "sunset.h"
#include "light.h"

static int sunset(void *param)
{
    UNUSED(param);
    APP_LOG(LOG_DEBUG, "sunset scene\n");
    light_param_t light_param[] = {{0, 0, 450, 10000, 100},
                                 {0, 0, 600, 10000, 100},
                                 {0, 0, 800, 10000, 100}};
    app_light_color_flow(light_param, SIZEOF_ARRAY(light_param), 1, LIGHT_REFLESH_INTERVAL_MS, 0, true);
    return APP_OK;
}

int sunset_light_scene_impl_init(void)
{
    light_scene_t light_scene;
    memset(&light_scene, 0, sizeof(light_scene_t));
    light_scene.light_cb = sunset;
    return sunset_light_scene_reg(&light_scene);
}

