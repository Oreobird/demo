/**
* Copyright © Vesync Technologies Co.Ltd. 2022. All rights reserved
* @file         bulb_rainbow_scene_impl.c
* @brief        彩虹场景回调业务实现
* @author       Joshua
* @date         2022-1-14
*/

#include <string.h>
#include "vesync_log.h"
#include "vesync_common.h"
#include "rainbow.h"
#include "light.h"

static int rainbow(void *param)
{
    UNUSED(param);
    APP_LOG(LOG_DEBUG, "rainbow scene\n");
    light_param_t light_param[] = {{0, 0, 0, 10000, 100}, {0, 0, 1000, 10000, 100},
                                 {0, 0, 2000, 10000, 100}, {0, 0, 3000, 10000, 100},
                                 {0, 0, 4000, 10000, 100}, {0, 0, 5000, 10000, 100},
                                 {0, 0, 6000, 10000, 100}, {0, 0, 7000, 10000, 100},
                                 {0, 0, 8000, 10000, 100}, {0, 0, 9000, 10000, 100},
                                 {0, 0, 10000, 10000, 100}, {0, 0, 9000, 10000, 100},
                                 {0, 0, 8000, 10000, 100}, {0, 0, 7000, 10000, 100},
                                 {0, 0, 6000, 10000, 100}, {0, 0, 5000, 10000, 100},
                                 {0, 0, 4000, 10000, 100}, {0, 0, 3000, 10000, 100},
                                 {0, 0, 2000, 10000, 100}, {0, 0, 1000, 10000, 100}};
    app_light_color_flow(light_param, SIZEOF_ARRAY(light_param), 1, LIGHT_REFLESH_INTERVAL_MS, 0, false);
    return APP_OK;
}

int rainbow_light_scene_impl_init(void)
{
    light_scene_t light_scene;
    memset(&light_scene, 0, sizeof(light_scene_t));
    light_scene.light_cb = rainbow;
    return rainbow_light_scene_reg(&light_scene);
}


