/**
* Copyright © Vesync Technologies Co.Ltd. 2022. All rights reserved
* @file         forest.h
* @brief        森林灯效
* @author       Joshua
* @date         2022-1-12
*/

#include <stdint.h>
#include "vesync_common.h"
#include "scene.h"

#ifndef __FOREST_H__
#define __FOREST_H__

#ifdef __cplusplus
extern "C" {
#endif


/**
 * @brief  森林场景灯效实现初始化
 * @return int              [成功：APP_OK， 失败：APP_FAIL]
 */
int forest_light_scene_impl_init(void);

/**
 * @brief  注册森林场景灯效
 * @return  int             [成功：APP_OK，失败：APP_FAIL]
 */
int forest_light_scene_reg(light_scene_t *light_scene);

/**
 * @brief  注销森林场景灯效
 * @return  int             [成功：APP_OK，失败：APP_FAIL]
 */
int forest_light_scene_unreg(void);

#ifdef __cplusplus
}
#endif

#endif




