/**
 *  Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vhal_ota_internal.h
 * @brief       esp32/esp8266的ota功能实现
 * @author      Dongri.Su
 * @date        2021-04-23
 */

#ifndef _VHAL_OTA_INTERNAL_H_
#define _VHAL_OTA_INTERNAL_H_

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#include "vhal_ota.h"


#ifdef __cplusplus
extern "C"
{
#endif


#define MAX_URL_LEN             (256)
#define BUFFSIZE                4096
//#define OTA_BUFFSIZE            1300
#define MAX_TCP_BUFF_SIZE       1500        // 每1包数据长度是1460


#ifdef CONFIG_IDF_TARGET_ESP8266
/*
 * @brief  ota http解析
 * @note  该定义应该放到平台层，但目前还使用乐鑫的升级程序，先放着hal层
 */
 typedef struct
{
    char host[128];
    int  port;
    char path[256];
} vhal_esp_url_t;

/*
 * @brief  ota 升级状态
 * @note   8266平台使用
 */
typedef enum
{
    ESP_OTA_INIT = 0,
    ESP_OTA_PREPARE,
    ESP_OTA_START,
    ESP_OTA_RECVED,
    ESP_OTA_FINISH,
    ESP_OTA_FAILED,
} VHAL_ESP_OTA_STATE_E;

/*
 * @brief  ota 升级状态
 * @note   8266平台使用独立升级函数，非调用库函数，
 */
typedef struct
{
    uint8_t             ota_num;                // OTA分区数量
    uint8_t             update_ota_num;         // OTA升级的分区序号
    VHAL_ESP_OTA_STATE_E    state;              // 升级状态，详见esp_ota_firm_state_t定义
    size_t              content_len;            // http内容的总长度(包括vesync头部)
    size_t              read_bytes;             // 当前读取(接收)的长度
    size_t              write_bytes;            // 已写入的长度
    size_t              ota_size;               // 待写入flash的固件总大小(不包括vesync头部)
    size_t              ota_offset;             // 偏移(第1包数据跳过的字节数)
    size_t              bytes;                  // 当前待写入的长度
    const char          *buf;                   // 当前待写入内容
} vhal_esp8266_ota_t;
#endif

/*
 * @brief  OTA执行状态
 */
typedef struct
{
    int32_t header_len;                         // 固件头部长度
    VHAL_OTA_STATE_E status;                    // OTA升级状态
    bool timeout_flag;                          // OTA超时标志位
    mbedtls_md5_context *md5;                   // 存放md5计算中间值
#ifdef CONFIG_IDF_TARGET_ESP8266
    int socket_id;                              // socket id
#endif

    // 回调函数指针
    vhal_ota_status_cb_t status_cb;             // OTA状态更新回调函数
    vhal_ota_check_header_cb_t header_check_cb; // 固件头部校验（不包括md5）回调函数
    vhal_ota_check_md5_cb_t md5_check_cb;       // 固件头部md5与固件实际md5比较回调函数
} vhal_esp_ota_status_t;



#ifdef __cplusplus
}
#endif

#endif /* _VHAL_OTA_INTERNAL_H_ */

