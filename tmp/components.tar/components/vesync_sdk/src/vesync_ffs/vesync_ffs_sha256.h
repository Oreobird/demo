/**
 * Copyright © Vesync Technologies Co.Ltd. 2019-2021. All rights reserved.
 * @file    vesync_ffs_sha256.h
 * @brief   sha256
 * @author  Owen.zhang
 * @date    2020-03-02
 */

#ifndef _VESYNC_FFS_SHA256_H_
#define _VESYNC_FFS_SHA256_H_
#include <stdio.h>
#include <string.h>

#define SHA256_BLOCK_LENGTH 64
#define SHA256_DIGEST_LENGTH 32
#define BASE64_DIGEST_LENGTH 128
typedef struct SHA256_CTX
{
	uint32_t state[8];
	uint64_t bitcount;
	uint8_t buffer[SHA256_BLOCK_LENGTH];
} SHA256_CTX;

#endif
