/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_bypass_set_temp_unit.c
 * @brief       bypass处理接口
 * @date        2021-05-17
 */

#include <string.h>
#include "vesync_common.h"
#include "vesync_memory.h"

#include "vesync_bypass_internal.h"

/**
 * @brief 设置温度单位
 * @param p_trace_msg trace message
 * @param json数据指针
 * @return bypass_err_t
 */
static BYPASS_ERR_E bypass_method_set_temp_unit_handle(bypass_trace_msg_t *p_trace_msg, cJSON *json)
{
    BYPASS_ERR_E ret = BP_OK;

    if ((NULL == json)||(NULL == p_trace_msg))    return BP_ERROR;

    bypass_update_temp_unit_t *pTemp_unit = (bypass_update_temp_unit_t *)vesync_malloc(sizeof(bypass_update_temp_unit_t));
    if (NULL == pTemp_unit)
    {
        return BP_ERR_NOMEM;
    }

    memset(pTemp_unit, 0, sizeof(bypass_update_temp_unit_t));

    cJSON *json_data = cJSON_GetObjectItemCaseSensitive(json, "unit");
    if (cJSON_IsString(json_data))
    {
        if (strcmp(json_data->valuestring, "f") == 0)
        {
            pTemp_unit->temp_unit = 1;
        }
        else if (strcmp(json_data->valuestring, "c") == 0)
        {
            pTemp_unit->temp_unit = 2;
        }
        else
        {
            ret = BP_ERR_ARG;
            goto _exit;
        }
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_SET_TEMP_UNIT);
    if (method_cb)
    {
        method_cb(p_trace_msg, (void*)pTemp_unit, sizeof(bypass_update_temp_unit_t));
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

_exit:
    vesync_free(pTemp_unit);
    return ret;
}

/**
 * @brief 更新温度单位
 * @param p_trace_msg trace message
 * @param json数据指针
 * @return BYPASS_ERR_E
 */
static BYPASS_ERR_E bypass_method_update_temp_unit_handle(bypass_trace_msg_t *p_trace_msg, cJSON *json)
{
    BYPASS_ERR_E ret = BP_OK;

    if ((NULL == json)||(NULL == p_trace_msg))    return BP_ERROR;

    bypass_update_temp_unit_t *pTemp_unit = (bypass_update_temp_unit_t *)vesync_malloc(sizeof(bypass_update_temp_unit_t));
    if (NULL == pTemp_unit)
    {
        return BP_ERR_NOMEM;
    }

    memset(pTemp_unit, 0, sizeof(bypass_update_temp_unit_t));

    cJSON *json_data = cJSON_GetObjectItemCaseSensitive(json, "tempUnit");
    if (cJSON_IsNumber(json_data))
    {
        pTemp_unit->temp_unit = json_data->valueint;
        if ((pTemp_unit->temp_unit > BP_TEMP_CENTIGRADE)||(BP_TEMP_INVALID == pTemp_unit->temp_unit))
        {
            ret = BP_ERR_ARG;
            goto _exit;
        }
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_UPDATE_TEMP_UNIT);
    if (method_cb)
    {
        method_cb(p_trace_msg, (void*)pTemp_unit, sizeof(bypass_update_temp_unit_t));
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

_exit:
    vesync_free(pTemp_unit);
    return ret;
}

static bypass_item_data_t set_temp_unit_method_tbl[] = {
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_SET_TEMP_UNIT, "setTempUnit", bypass_method_set_temp_unit_handle, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_UPDATE_TEMP_UNIT, "updateTempUnit", bypass_method_update_temp_unit_handle, NULL},
};

void vesync_bypass_set_temp_unit_init(void)
{
    for (int i = 0; i < SIZEOF_ARRAY(set_temp_unit_method_tbl); i++)
    {
        bypass_item_t *item = vesync_bypass_init_item(&set_temp_unit_method_tbl[i]);
        if (item != NULL)
        {
            vesync_bypass_add_item(item);
        }
    }
}
