/**
 * Copyright © Vesync Technologies Co.Ltd. 2019-2021. All rights reserved.
 * @file    vesync_ffs_crypto.h
 * @brief   crypto
 * @author  Owen.zhang
 * @date    2020-04-22
 */

#ifndef _VESYNC_FFS_CRYPTO_H_
#define _VESYNC_FFS_CRYPTO_H_
#include <stdio.h>
#include <string.h>
#include "mbedtls/ecp.h"
#include "ffs/common/ffs_stream.h"
#define VESYNC_ASSERT(x)                                                  \
    do                                                                    \
    {                                                                     \
        int ret;                                                          \
        if ((ret = (x)) != 0)                                             \
        {                                                                 \
            printf("%s:%d error: -0x%x\n", __FUNCTION__, __LINE__, -ret); \
            goto exit;                                                    \
        }                                                                 \
    } while (0)

typedef struct FfsKeyContext_s
{
    uint8_t len;
    uint8_t *buf;
} FfsKeyContext_t;

int vesync_ffs_rand(void *rng_state, unsigned char *output, size_t len);
int vesync_ffs_load_public_key(int grp_id, mbedtls_ecp_keypair *ecp, uint8_t *point, char len);
int vesync_ffs_load_private_key(int grp_id, mbedtls_ecp_keypair *ecp, uint8_t *private_key, char len);
int vesync_ffs_compute_ecdh_key(FfsKeyContext_t *privateKey, FfsKeyContext_t *publicKey, FfsKeyContext_t *secretKey);
void vesync_ffs_dump_buf(char *info, uint8_t *buf, uint32_t len);
void parsePublicKeyToHex(FfsKeyContext_t *keyValue, const char *KeyPem);
void parsePublicKeyExtToHex(FfsKeyContext_t *keyValue, const char *KeyPem);
void parsePrivateKeyToHex(FfsKeyContext_t *keyValue, const char *KeyPem);
void parseCloudPublicKeyToHex(FfsKeyContext_t *keyValue, const char *KeyPem);
int vesync_ffs_sign_from_sessionToken(FfsKeyContext_t *privateKey, FfsKeyContext_t *publicKey, char *sessionTokenStream, unsigned char *buf);
#endif
