/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
* @file        bulb_status.h
* @brief       灯泡状态控制
* @author      Dave
* @date        2021-09-1
*/
#include <stdint.h>

#ifndef __BULB_STATUS_H__
#define __BULB_STATUS_H__

#ifdef __cplusplus
extern "C" {
#endif

#define BULB_TEMP_MAX (100) // 色温值上限

#define BULB_W_WARMEST (0)        // 白光模式最暖色温值
#define BULB_W_MODEST (50)        // 白光模式中间色温
#define BULB_W_COLDEST (100)      // 白光模式最冷色温值
#define BULB_W_FULL_BRIGHT (100)  // 白光模式满亮度值
#define BULB_W_HALF_BRIGHT (50)   // 白光模式半亮度值

typedef struct
{
    uint16_t red;
    uint16_t blue;
    uint16_t green;
    uint16_t cold;
    uint16_t warm;
} bulb_led_data_t;

/**
 * @brief 白光模式数据写入和直接设置输出
 * @param[in]  temp      [色温]
 * @param[in]  bright    [亮度]
 * @return int           [成功：APP_OK， 失败：APP_FAIL]
 */
int bulb_white_mode_write(uint8_t temp, uint8_t bright);

/**
 * @brief 彩光模式数据写入和直接设置输出
 * @param[in]  H         [色相]
 * @param[in]  S         [饱和度]
 * @param[in]  V         [明度]
 * @return int           [成功：APP_OK， 失败：APP_FAIL]
 */
int bulb_color_mode_write(uint16_t H, uint16_t S, uint8_t V);

/**
 * @brief  关断灯泡所有输出
 * @return int           [成功：APP_OK， 失败：APP_FAIL]
 */
int bulb_sleep_mode_write(void);

/**
 * @brief 以flash中保存状态开启灯泡
 */
void bulb_open(void);

/**
 * @brief 更新渐变目标
 */
void bulb_gradient_new_tgt_set(void);

/**
 * @brief 设备重新上电的默认状态
 */
void bulb_poweron(void);

/**
 * @brief Bulb LED驱动的初始化
 */
void bulb_led_init(void);

#ifdef __cplusplus
}
#endif

#endif

