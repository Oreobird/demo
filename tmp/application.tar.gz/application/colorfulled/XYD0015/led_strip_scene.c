/**
 *  Copyright © Vesync Technologies Co.Ltd. 2019-2021. All rights reserved
 * @file        vesync_led_strip_scene.c
 * @brief       led strip working scene function
 * @author      henrik
 * @date        2021-09-16
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "vesync_task.h"

#include "vesync_log.h"
#include "vesync_memory.h"
#include "vesync_common.h"
#include "vesync_bypass.h"

#include "led_strip_scene.h"
#include "led_strip_signal.h"
#include "led_color_palette.h"
#include "vhal_led.h"
#include "led_strip_board.h"
#include "led_strip_led_drv.h"
#include "led_strip.h"
#include "led_strip_flash.h"

static ls_info_t s_led_strip;    // 灯带信息

/* 场景列表*/
static ls_scene_t s_scene_list[SCENE_MAX_NUM] ;
static uint8_t s_cfgnet_scene = CFG_SCENE_UNKNOWN;

/**
 * @brief  设置配网灯效标记位，配网状态下切换场景后，重新配网需要将type变成UNKOWN,进行开始配网灯效
 * @param[in]     type                                   [配网灯效类型]
 */
void led_strip_set_cfgnet_scene(uint8_t type)
{
    s_cfgnet_scene = type;
}

/**
 * @brief  获取灯带参数初始化
 * @return     ls_info_t *             [灯带信息结构体指针]
 */
ls_info_t * led_strip_get_info(void)
{
    return &s_led_strip;
}

/**
 * @brief  设置灯带参数为默认值
 * @return     ls_info_t *             [灯带信息结构体指针]
 */
static void led_strip_set_parameter_default(void)
{
    s_led_strip.last_id = SCENE_CUSTOM_MIN_ID;
    s_led_strip.mode = SCENE_COLOR_WHITE;
    s_led_strip.scene_now = 0;
    s_led_strip.led_num = DEFAULT_LED_NUM;
    s_led_strip.scene_num = 0;
    s_led_strip.status = LS_STATUS_OFF;
    s_led_strip.brightness = DEFAULT_PULSE;
    s_led_strip.multiple.num = MAX_SEGMENT_NUM;
    s_led_strip.color.hue = LED_DEFAULT_HUE;
    s_led_strip.color.sat = LED_HS_PARAM_MAX;
    s_led_strip.color.val = LED_BRIGHTNESS_MAX;
}
/**
 * @brief  灯带参数初始化
 * @return     int              [成功：APP_OK，失败：APP_FAIL]
 */
int led_strip_parameter_init(void)
{
    int ret = APP_FAIL;
    ls_ev_t ev;
    ev.event = LS_EV_CHANGE_SCENE;
    ev.act_src = LS_ACT_SRC_INIT;

    led_strip_set_parameter_default();
    s_led_strip.multiple.color = (ls_color_seg_t *)vesync_malloc(sizeof(ls_color_seg_t)*MAX_SEGMENT_NUM);
    if (NULL == s_led_strip.multiple.color)
    {
        APP_LOG(LOG_ERROR,"malloc fail!\n");
    }

    // 从flash中加载信息
    ret = led_strip_read_info(&s_led_strip);
    if (APP_FAIL == ret)
    {
        APP_LOG(LOG_ERROR,"info read fail!\n");
    }

    s_led_strip.scene_list = s_scene_list;
    for (int i = 0; i < SCENE_MAX_NUM;i++)
    {
        s_scene_list[i].color = NULL;
        s_scene_list[i].num = 0;
        s_scene_list[i].type = 0;
        if (i < SCENE_CUSTOM_MAX_NUM)
        {
            s_scene_list[i].id = 0;
        }
        else
        {
            s_scene_list[i].id = i + 1 - SCENE_CUSTOM_MAX_NUM;
        }
    }

    ret = led_strip_read_scene(s_scene_list, &s_led_strip.scene_num);
    if (APP_FAIL == ret)
    {
        APP_LOG(LOG_ERROR,"scene read fail!\n");
    }

    if (LS_STATUS_ON ==  s_led_strip.status)
    {
        if (SCENE_COLOR_MUSIC > s_led_strip.mode)
        {
            ev.scene_type = SCENE_TYPE_REALTIME;
            ev.scene_id = s_led_strip.mode;
        }
        else
        {
            APP_LOG(LOG_DEBUG,"set scene:%d!\n", s_led_strip.scene_now);
            if (0 == s_led_strip.scene_now)
            {
                s_led_strip.scene_now = s_scene_list[SCENE_CUSTOM_MAX_NUM - s_led_strip.scene_num].id;
            }
            ev.scene_type = SCENE_TYPE_DEFINE;
            ev.scene_id = s_led_strip.scene_now;
        }
    }
    else
    {
        ev.scene_type = SCENE_TYPE_OFF;
        ev.scene_id = s_led_strip.mode;
    }

    led_strip_app_task_notify(&ev);
    return ret;
}

/**
 * @brief  灯带参数初始化
 */
void led_strip_parameter_deinit(void)
{
    led_strip_set_parameter_default();
    s_led_strip.status = LS_STATUS_ON;
    s_led_strip.scene_list = s_scene_list;
    if (NULL != s_led_strip.multiple.color)
    {
        memset(s_led_strip.multiple.color, 0, sizeof(ls_color_seg_t)*MAX_SEGMENT_NUM);
    }

    for (int i = 0; i < SCENE_CUSTOM_MAX_NUM;i++)
    {
        s_scene_list[i].color = NULL;
        if (NULL != s_scene_list[i].color)
        {
            vesync_free(s_scene_list[i].color);
        }
        s_scene_list[i].color = NULL;
        s_scene_list[i].num = 0;
        s_scene_list[i].type = 0;
        s_scene_list[i].id = 0;
    }
}

/**
 * @brief  新增场景
 * @param[out]    id                                     [场景id ]
 * @param[in]     type                                   [分段类型]
 * @param[in]     num                                    [分段数量]
 * @param[in]     color                                  [分段颜色数组]
 * @return     int              [成功：APP_OK，失败：APP_FAIL]
 */
int led_strip_scene_add(uint16_t* id , uint8_t type ,uint8_t num , ls_color_seg_t * color)
{
    int ret = APP_FAIL;
    uint8_t repeat_flag = 0;
    uint8_t end_index = 0;   // 循环终止偏移
    uint16_t temp_id = s_led_strip.last_id ;
    int i = 0;

    if ((NULL == id)||(NULL == color))
    {
        APP_LOG(LOG_ERROR,"input illegal!\n");
        return ret;
    }

    if (s_led_strip.scene_num >= SCENE_CUSTOM_MAX_NUM)
    {
        return APP_ERR_OUT_OF_RANGE ;
    }

    end_index = SCENE_CUSTOM_MAX_NUM - s_led_strip.scene_num -1;
    // 至多SCENE_CUSTOM_MAX_NUM个已用的场景ID，所以至多循环SCENE_CUSTOM_MAX_NUM
    for (int j = SCENE_CUSTOM_MAX_NUM -1; j > end_index ; j-- )
    {
        repeat_flag = 0;
        temp_id++;
        if (SCENE_CUSTOM_MIN_ID > temp_id)
        {
            temp_id = SCENE_CUSTOM_MIN_ID;
        }

        for (i = SCENE_CUSTOM_MAX_NUM -1; i > end_index ;i--) // 检查id是否重复
        {
            if (0 != s_scene_list[i].id)
            {
                if (s_scene_list[i].id == temp_id)
                {
                    repeat_flag = 1;
                    break;
                }
            }
        }

        if (0 == repeat_flag)  // ID 没有重复
        {
            break;
        }
    }

    *id = s_scene_list[end_index].id = temp_id;
    s_scene_list[end_index].color = color;
    s_scene_list[end_index].num = num;
    s_scene_list[end_index].type = type;
    s_led_strip.scene_num++;
    APP_LOG(LOG_DEBUG,"index:%d ,id:%d, last_id:%d, point:%x !\n", end_index, temp_id, s_led_strip.last_id, color);

    // 将信息存入flash中
    ret = led_strip_save_scene(s_scene_list, s_led_strip.scene_num);
    if (APP_OK != ret)
    {
        *id = s_scene_list[end_index].id = 0;
        s_scene_list[end_index].color = NULL;
        s_scene_list[end_index].num = 0;
        s_scene_list[end_index].type = 0;
        s_led_strip.scene_num--;
        APP_LOG(LOG_ERROR,"save scene fail!\n");
    }
    else
    {
        s_led_strip.last_id = temp_id ;
        led_strip_save_info(&s_led_strip);  // 更新了分配的ID，所以需要将数据存入flash
    }

    return ret;
}

/**
 * @brief  更新场景
  * @param[in]     id                                     [场景id ]
  * @param[in]     type                                   [分段类型]
  * @param[in]     num                                    [分段数量]
  * @param[in]     color                                  [分段颜色数组]
  * @return     int              [成功：APP_OK，失败：APP_FAIL]
  */
 int led_strip_scene_update(uint16_t id , uint8_t type ,uint8_t num , ls_color_seg_t * color)
{
    uint16_t temp_index = SCENE_MAX_NUM;
    ls_scene_t temp_scence = {0,0,0,NULL};
    int i = 0;
    int ret = APP_FAIL;

    for (i = 0; i < SCENE_CUSTOM_MAX_NUM;i++)
    {
        if ((NULL != s_scene_list[i].color)&&((s_scene_list[i].id == id)))
        {
            temp_index = i;
            temp_scence.color = s_scene_list[i].color;
            temp_scence.id = s_scene_list[i].id;
            temp_scence.num = s_scene_list[i].num;
            temp_scence.type = s_scene_list[i].type;
            s_scene_list[i].color = color;
            s_scene_list[i].id = id;
            s_scene_list[i].num = num;
            s_scene_list[i].type = type;
            APP_LOG(LOG_DEBUG,"index:%d num:%d \n", temp_index, s_led_strip.scene_num);
            break;
        }
    }

    if (NULL == temp_scence.color)  // 未找到对应id场景
    {
        return APP_ERR_OUT_OF_RANGE;
    }

    // 数据写入flash
    ret = led_strip_save_scene(s_scene_list, s_led_strip.scene_num);

    if (APP_FAIL == ret)
    {
        s_scene_list[temp_index].color = temp_scence.color;
        s_scene_list[temp_index].id = temp_scence.id;
        s_scene_list[temp_index].num = temp_scence.num;
        s_scene_list[temp_index].type = temp_scence.type;
        APP_LOG(LOG_ERROR,"scene save fail\n");
    }
    else
    {
        vesync_free(temp_scence.color);
    }

    return  ret;
}


/**
 * @brief  删除场景
 * @param[in]     id                                    [场景id]
 * @return     int              [成功：APP_OK，失败：APP_FAIL]
 */
int led_strip_scene_delete(uint16_t id)
{
    uint16_t temp_index = SCENE_MAX_NUM;
    int i = 0;
    int ret = APP_FAIL;

    for (i = 0; i < SCENE_CUSTOM_MAX_NUM;i++)
    {
        if ((NULL != s_scene_list[i].color)&&((s_scene_list[i].id == id)))
        {
                temp_index = i;
                vesync_free(s_scene_list[i].color);
                s_scene_list[i].color = NULL;
                if (s_led_strip.scene_num > 0)
                {
                    s_led_strip.scene_num--;
                }
                APP_LOG(LOG_DEBUG,"index:%d num:%d \n", temp_index, s_led_strip.scene_num);
                break;
        }
    }

    if (SCENE_MAX_NUM == temp_index)  // 未找到对应id场景
    {
        return APP_ERR_OUT_OF_RANGE;
    }

    for (i = temp_index ; i >= 0;i--)   // 保证有效数据连续，而且按照从新到旧
    {
        if ((0 != s_scene_list[i].id)&&(0 < i))
        {
            s_scene_list[i].color = s_scene_list[i-1].color;
            s_scene_list[i].id = s_scene_list[i-1].id;
            s_scene_list[i].num = s_scene_list[i - 1].num;
            s_scene_list[i].type = s_scene_list[i -1].type;
        }
        else if ((0 == i)||(0 == s_scene_list[i].id))
        {
            s_scene_list[i].color = NULL;
            s_scene_list[i].id = 0;
            s_scene_list[i].num = 0;
            s_scene_list[i].type = 0;
            break;
        }
    }

    // 数据写入flash
    ret = led_strip_save_scene(s_scene_list, s_led_strip.scene_num);
    if (APP_FAIL == ret)
    {
        APP_LOG(LOG_ERROR,"scene save fail\n");
    }

    for (int j = SCENE_CUSTOM_MAX_NUM -1; j >= 0 ; j-- )
    {
        APP_LOG(LOG_DEBUG,"i:%d id:%d \n", j, s_scene_list[j].id);
    }
    return  ret;
}

/**
 * @brief  验证场景ID是否存在,存在则赋值给新的存储空间
 * @param[in]     id                                    [待验证场景id]
 * @param[out]    data                                  [待赋值的场景存储]
 * @return     int              [成功：APP_OK，失败：else]
 */
int led_strip_scene_id_check(uint16_t id, uint16_t * data)
{
    int ret = APP_FAIL;

    if (0 == id)
    {
        return  BP_ERR_PARA_ILLEGAL;
    }

    for (int i = 0; i < SCENE_MAX_NUM; i++)
    {
        if (s_scene_list[i].id == id)
        {
            ret = APP_OK;
            break;
        }
    }

    if (APP_OK != ret)  // 场景不存在
    {
        if ((SCENE_DEFAULT_MIN_ID <= id)&&(SCENE_DEFAULT_MAX_ID >= id))
        {
            ret = BP_ERR_DEFAULT_SCENE_NON_EXISTENT;
        }
        else
        {
            ret = BP_ERR_CUSTOM_SCENE_NON_EXISTENT;
        }
    }
    else
    {
        *data = id;
    }
    return  ret;
}


/**
 * @brief 场景数据转化
 * @param[in]      p_info                                 [灯带状态参数结构体]
 * @param[out]     signal                                 [灯带灯效控制参数结构体指针]
 * @param[in]      mode                                   [工作模式]
 * @note
 */
void led_strip_scene_data_transform(ls_color_seg_t *p_color, led_strip_signal_hsv_t *signal, uint8_t mode)
{
    switch(mode)
    {
        case SCENE_COLOR_MULT:
            for(int j = 0; j < signal->number; j++)
            {
                signal->hsv[j].hue = p_color[j].hue ;
                signal->hsv[j].hue = signal->hsv[j].hue*360/LED_HS_PARAM_MAX;
                signal->hsv[j].saturation = p_color[j].sat;
                signal->hsv[j].saturation = signal->hsv[j].saturation / LED_HS_PARAM_MAX;
                signal->hsv[j].value = p_color[j].val ;
                signal->hsv[j].value = signal->hsv[j].value / LED_BRIGHTNESS_MAX;
            }

            break;
        case SCENE_COLOR_RGB:
            signal->hsv[0].hue = p_color->hue ;
            signal->hsv[0].hue = signal->hsv[0].hue *360 /LED_HS_PARAM_MAX;
            signal->hsv[0].saturation = p_color->sat ;
            signal->hsv[0].saturation = signal->hsv[0].saturation /LED_HS_PARAM_MAX;
            signal->hsv[0].value = p_color->val;
            signal->hsv[0].value = signal->hsv[0].value/LED_BRIGHTNESS_MAX;
            led_strip_hsv2rgb(&(signal->rgb), signal->hsv);
            APP_LOG(LOG_DEBUG, "r:%d  b:%d g:%d\n", signal->rgb.red, signal->rgb.blue, signal->rgb.green);
            break;
        case SCENE_COLOR_WHITE:
            signal->number = 0;
            signal->rgb.red = p_color->val;
            break;
        default:
            APP_LOG(LOG_DEBUG, "default\n");
            break;
    }

    signal->scene = mode;
}



/**
 * @brief hsv颜色空间转化成RGB空间
 * @param[in out] freq_normal                            [归一化频率 分量 ]
 * @param[in]     begin                                  [起始坐标]
 * @param[in]     end                                    [终止坐标]
 * @note
 */
void led_strip_frequency_fast_sort(freq_normal_t *freq_normal, int32_t begin, int32_t end)
{
    int32_t i = begin,j = end;
    int32_t temp_num = 0;
    float   temp_value = 0;

    if (NULL == freq_normal)
    {
        APP_LOG(LOG_ERROR, "input error!\n");
        return ;
    }

    temp_value = freq_normal->value[begin];
    temp_num = freq_normal->num[begin];

    if(begin < end)
    {
        while (i < j)
        {
            while (i<j && (freq_normal->num[j] > temp_num) )
            {
                j--;
            }
            freq_normal->num[i] = freq_normal->num[j];
            freq_normal->value[i] = freq_normal->value[j];

            while (i<j && (freq_normal->num[i] <= temp_num) )
            {
                i++;
            }
            freq_normal->num[j] = freq_normal->num[i];
            freq_normal->value[j] = freq_normal->value[i];

        }
        freq_normal->num[i] = temp_num;
        freq_normal->value[i] = temp_value;
        led_strip_frequency_fast_sort(freq_normal, begin, i-1);
        led_strip_frequency_fast_sort(freq_normal, i+1, end);
    }
    else
        return ;
}

/**
 * @brief 通过色盘产生灯带颜色
 * @param[in]  strip                        [The pointer of led strip]
 * @param[in]  rgb                          [RGB parameters(It contains all the parameters related to rgb)]
 * @param[in]  palette                      [色盘指针]
 * @param[in]  led_num                      [灯带分段的led数量]
 * @return     int                          [成功或失败]
 * @note
 */
static void led_rgb_generate_from_palette(led_strip_t *strip, rgb_parameters_t *rgb, color_palette_t * palette, uint8_t led_num)
{
    static uint8_t display_pos = 0;
    uint32_t color_index = 0;
    uint8_t segment_index = 0;

    if ((NULL == strip)||(NULL == rgb))
    {
        APP_LOG(LOG_ERROR, "input error!\n");
        return ;
    }

    display_pos++;
    if (display_pos >= palette->color_num)
    {
        display_pos = 0;
    }

    for (uint32_t i = 0; i < rgb->leds_total_number; i++)
    {
        segment_index = i % led_num;
        color_index = segment_index * palette->color_num/led_num + display_pos;
        color_index = color_index % palette->color_num;
        led_set_pixel(strip, i, palette->color[color_index].red, palette->color[color_index].blue, \
                      palette->color[color_index].green);
    }
}


/**
 * @brief      This is an example of a user-defined light effect function
 *
 * @param[in]  strip                The pointer of led strip
 * @param[in]  rgb                  RGB parameters(It contains all the parameters related to rgb)
 * @param[in]  signal               the signals that generate rgb data buffer
 */
void led_strip_scene_form_palette (led_strip_t *strip, rgb_parameters_t *rgb, \
                                                           led_strip_signal_hsv_t *signal)
{
    color_palette_t * palette = NULL;
    uint8_t id = 0;

    if ((NULL == strip)||(NULL == rgb)||(NULL == signal))
    {
        APP_LOG(LOG_ERROR, "input error!\n");
        return ;
    }
    switch(signal->scene)
    {
        case SCENE_LIGHTING:
            id = LIGHTING;
            break;
        case SCENE_MOVIE:
            id = MOVIE;
            break;
        case SCENE_SWEET:
            id = SWEET;
            break;
        case SCENE_ROMATIC:
            id = ROMATIC;
            break;
        default:
            vesync_sleep(10);
            break;
    }
    palette  = led_strip_color_get_palette(id);

    if (NULL != palette)
    {
        led_rgb_generate_from_palette(strip, rgb, palette, signal->number);
        led_reflash_pixel(strip, 5);
    }
}

/**
 * @brief 关闭所有彩灯
 * @param[in]  strip                        [灯带控制参数指针]
 * @param[in]  rgb                          [颜色控制参数指针]
 * @note
 */
static void led_strip_close_rgb(led_strip_t *strip, rgb_parameters_t *rgb)
{
    for (int i = 0; i < rgb->leds_total_number; i++)  // 关闭彩灯
    {
        led_set_pixel(strip, i, 0, 0, 0);
    }
    led_reflash_pixel(strip, 2);
}

/**
 * @brief 点亮所有彩灯
 * @param[in]  strip                        [灯带控制参数指针]
 * @param[in]  rgb                          [颜色控制参数指针]
 * @param[in]  color                        [点亮颜色]
 * @note
 */
static void led_strip_light_up_rgb(led_strip_t *strip, rgb_parameters_t *rgb, rgb_color_t color)
{
    for (int i = 0; i < rgb->leds_total_number; i++)  // 关闭彩灯
    {
        led_set_pixel(strip, i, color.red, color.blue, color.green);
    }
    led_reflash_pixel(strip, 2);
}


/**
 * @brief      This is an example of a user-defined light effect function
 *
 * @param[in]  strip                The pointer of led strip
 * @param[in]  rgb                  RGB parameters(It contains all the parameters related to rgb)
 * @param[in]  signal               the signals that generate rgb data buffer
 */
void led_strip_breath_scene (led_strip_t *strip, rgb_parameters_t *rgb, \
                                                           led_strip_signal_hsv_t *signal)
{
    static char flag = 0;
    rgb_color_t t_rgb ;
    hsv_color_t t_hsv ;
    led_strip_signal_hsv_t * hsv_signal = signal;
    color_palette_t * palette = NULL;

    if ((NULL == strip)||(NULL == rgb)||(NULL == signal))
    {
        APP_LOG(LOG_ERROR, "input error!\n");
        return ;
    }
    palette  = led_strip_color_get_palette(BREATH);

    if (0 == signal->count)  // 从其他场景转化回当前场景需要从0开始渐亮
    {
        flag = 0;
    }

    if (0 == flag)
    {
        signal->count += 1;
        if (100 <= signal->count)
        {
            flag = 1;
        }
    }
    else
    {
        signal->count -= 1;
        if (0 >= signal->count)
        {
            flag = 0;
            hsv_signal->display_pos++;
            if (hsv_signal->display_pos >= palette->color_num)
            {
                hsv_signal->display_pos = 0;
            }
        }
    }

    t_hsv.value = (float)signal->count/100.0;
    t_hsv.hue = palette->hsv[hsv_signal->display_pos].hue;
    t_hsv.saturation = palette->hsv[hsv_signal->display_pos].saturation;
    led_strip_hsv2rgb(&t_rgb, &t_hsv);
    led_strip_light_up_rgb(strip, rgb, t_rgb);
}

/**
 * @brief      This is an example of a user-defined light effect function
 *
 * @param[in]  strip                The pointer of led strip
 * @param[in]  rgb                  RGB parameters(It contains all the parameters related to rgb)
 * @param[in]  signal               the signals that generate rgb data buffer
 */
void led_strip_flowing_scene (led_strip_t *strip, rgb_parameters_t *rgb, \
                                                           led_strip_signal_hsv_t *signal)
{
    int32_t pos = 0;
    uint8_t color_index = 0;
    uint8_t peroid = 0;
    rgb_color_t t_rgb ;
    color_palette_t * palette = NULL;

    if ((NULL == strip)||(NULL == rgb)||(NULL == signal))
    {
        APP_LOG(LOG_ERROR, "input error!\n");
        return ;
    }

    signal->count += 1;
    if (rgb->leds_total_number <= signal->count)
    {
        signal->count = 0;
    }
     palette  = led_strip_color_get_palette(FLOWING);

    for (int i = 0; i < rgb->leds_total_number; i++)
    {
        peroid = i % 4;         // 连续两个灯珠同一个颜色，总共两个颜色，所以四个灯珠为一个颜色周期
        color_index = peroid >> 1;
        t_rgb.blue = palette->color[color_index].blue;
        t_rgb.green = palette->color[color_index].green;
        t_rgb.red = palette->color[color_index].red;

        pos = i + signal->count;
        if ( pos >= rgb->leds_total_number)
        {
            pos = pos - rgb->leds_total_number;
        }
        led_set_pixel(strip, pos, t_rgb.red, t_rgb.green, t_rgb.blue);
    }

    led_reflash_pixel(strip, 5);
}

/**
 * @brief      This is an example of a user-defined light effect function
 *
 * @param[in]  strip                The pointer of led strip
 * @param[in]  rgb                  RGB parameters(It contains all the parameters related to rgb)
 * @param[in]  signal               the signals that generate rgb data buffer
 */
void led_strip_rainbow_scene (led_strip_t *strip, rgb_parameters_t *rgb, \
                                                           led_strip_signal_hsv_t *signal)
{
    int32_t pos = 0;
    uint8_t color_index = 0;
    rgb_color_t t_rgb ;
    color_palette_t * palette = NULL;

    if ((NULL == strip)||(NULL == rgb)||(NULL == signal))
    {
        APP_LOG(LOG_ERROR, "input error!\n");
        return ;
    }

    signal->count += 1;
    if (rgb->leds_total_number <= signal->count)
    {
        signal->count = 0;
    }
    palette  = led_strip_color_get_palette(RAINBOW);

    for (int i = 0; i < rgb->leds_total_number; i++)
    {
        color_index = i % palette->color_num;
        t_rgb.blue = palette->color[color_index].blue;
        t_rgb.green = palette->color[color_index].green;
        t_rgb.red = palette->color[color_index].red;

        pos = i + signal->count;
        if ( pos >= rgb->leds_total_number)
        {
            pos = pos - rgb->leds_total_number;
        }
        led_set_pixel(strip, pos, t_rgb.red, t_rgb.blue, t_rgb.green);
    }

    led_reflash_pixel(strip, 5);
}


/**
 * @brief      This is an example of a user-defined light effect function
 *
 * @param[in]  strip                The pointer of led strip
 * @param[in]  rgb                  RGB parameters(It contains all the parameters related to rgb)
 * @param[in]  signal               the signals that generate rgb data buffer
 */
void led_strip_christmas_scene (led_strip_t *strip, rgb_parameters_t *rgb, \
                                                           led_strip_signal_hsv_t *signal)
{
    color_palette_t * palette = NULL;

    if ((NULL == strip)||(NULL == rgb)||(NULL == signal))
    {
        APP_LOG(LOG_ERROR, "input error!\n");
        return ;
    }

    palette  = led_strip_color_get_palette(CHRISTMAS);
    if (NULL != palette)
    {
        led_rgb_generate_from_palette(strip, rgb, palette, 6);
        led_reflash_pixel(strip, 5);
    }
}

/**
 * @brief      This is an example of a user-defined light effect function
 *
 * @param[in]  strip                The pointer of led strip
 * @param[in]  rgb                  RGB parameters(It contains all the parameters related to rgb)
 * @param[in]  signal               the signals that generate rgb data buffer
 */
void led_strip_spectrum_scene (led_strip_t *strip, rgb_parameters_t *rgb, \
                                                           led_strip_signal_hsv_t *signal)
{
    rgb_color_t t_rgb ;
    uint32_t half_samples = 0;
    uint32_t begin = 0;
    uint32_t end  = 0;
    uint32_t pos = 0;
    hsv_color_t hsv_color = {.hue = 0.0, .saturation = 1.0, .value =1.0};

    if ((NULL == strip)||(NULL == rgb)||(NULL == signal))
    {
        APP_LOG(LOG_ERROR, "input error!\n");
        return ;
    }

    half_samples = rgb->freq_normal->n_samples>>2;
    begin = half_samples - SCENE_SPECTRUM_LED_NUM;
    end  = half_samples ;

    if (begin >= rgb->freq_normal->n_samples)
    {
        begin = 0;
    }

    if (end >= rgb->freq_normal->n_samples)
    {
        end = rgb->freq_normal->n_samples - 1;
    }

    led_strip_frequency_fast_sort(rgb->freq_normal, begin, end);

    if (rgb->max_audio_data >= rgb->min_sound_threshold)
    {
        for(int i=0; i < rgb->leds_total_number; i++)
        {
            pos = end - (i % SCENE_SPECTRUM_LED_NUM);
            hsv_color.value = rgb->freq_normal->value[pos] *2 + 0.3;
            hsv_color.hue = rgb->freq_normal->num[pos] % 360;
            if (hsv_color.value > 1.0)
            {
                hsv_color.value = 1.0;
            }
            led_strip_hsv2rgb (&t_rgb, &hsv_color);
            led_set_pixel(strip, i, t_rgb.red, t_rgb.blue, t_rgb.green);
        }
    }

    led_reflash_pixel(strip, 2);
}

/**
 * @brief      默认场景显示
 *
 * @param[in]  handle                The pointer of led strip
 * @param[in]  signal               the signals that generate rgb data buffer
 * @return     uint32_t             [灯效延时时间]
 */
uint32_t led_strip_default_scene(led_rgb_handle_t *handle, led_strip_signal_hsv_t *signal)
{
    uint32_t wait_ms = SCENE_WAIT_MS_DEFAULT;

    if ((NULL == handle)||(NULL == signal))
    {
        APP_LOG(LOG_ERROR, "input error!\n");
        return wait_ms;
    }

    if ((0 == signal->count)&&(SCENE_LIGHTING != signal->scene))
    {
        led_strip_set_white_pulse(0);
    }

    switch(signal->scene) {
        case SCENE_LIGHTING:
            if (0 == signal->count)
            {
                signal->count++;
                for(int i=0; i < handle->rgb_parameters->leds_total_number; i++)
                {
                    led_set_pixel(handle->strip, i, 0, 0, 0);
                }
                led_reflash_pixel(handle->strip, 2);
                led_strip_set_white_pulse(MAX_PULSE);
            }
            wait_ms = SCENE_WAIT_MS_DEFAULT; // 单色场景，无需频繁刷新
            break;
        case SCENE_MOVIE:
        case SCENE_SWEET:
        case SCENE_ROMATIC:
            led_strip_scene_form_palette(handle->strip, handle->rgb_parameters, signal);
            wait_ms = SCENE_WAIT_MS_DEFAULT;  // 单色场景，无需频繁刷新
            break;
        case SCENE_BREATH:
            led_strip_breath_scene(handle->strip, handle->rgb_parameters, signal);
            wait_ms = SCENE_WAIT_MS_BREATH;
            break;
        case SCENE_FLOWING:
            led_strip_flowing_scene(handle->strip, handle->rgb_parameters, signal);
            wait_ms = SCENE_WAIT_MS_FLOWING;
            break;
        case SCENE_RAINBOW:
            led_strip_rainbow_scene(handle->strip, handle->rgb_parameters, signal);
            wait_ms = SCENE_WAIT_MS_FLOWING;
            break;
        case SCENE_CHRISTMAS:
            led_strip_christmas_scene(handle->strip, handle->rgb_parameters, signal);
            wait_ms = SCENE_WAIT_MS_CHRISTMAS;
            break;
        case SCENE_SPECTRUM:
            normaliton(handle->fft_array->s_y_cf2, handle->rgb_parameters->freq_normal);
            led_strip_spectrum_scene(handle->strip, handle->rgb_parameters, signal);
            wait_ms = SCENE_WAIT_MS_MUSIC;
            break;
        default:
            wait_ms = SCENE_WAIT_MS_DEFAULT;
            break;
    }
    return wait_ms;
}

/**
 * @brief      产测灯效
 *
 * @param[in]  strip                [灯带结构体指针]
 * @param[in]  rgb                  [灯带灯珠颜色参数结构体指针]
 * @param[in]  signal               [灯带灯效控制参数结构体指针]
 * @return     uint32_t             [灯效延时时间]
 */
uint32_t led_strip_production_scene(led_strip_t *strip, rgb_parameters_t *rgb, \
                                                           led_strip_signal_hsv_t *signal)
{
    static char flag = 0;
    rgb_color_t t_rgb = {0, 0, 0};
    uint32_t wait_ms = SCENE_WAIT_MS_PRD;

    if ((NULL == strip)||(NULL == rgb)||(NULL == signal))
    {
        APP_LOG(LOG_ERROR, "input error!\n");
        return wait_ms;
    }

    switch (signal->scene)
    {
        case PRD_SCENE_START:
            signal->count += 5;
            signal->count = signal->count % 510;
            if (255 < signal->count)
            {
                t_rgb.red = 510 - signal->count;
            }
            else
            {
                t_rgb.red = signal->count;
                if (0 == signal->count)
                {
                    flag++;
                    flag = flag % 4;
                }
            }

            switch (flag)
            {
                case 1:
                    t_rgb.green = t_rgb.red;
                    t_rgb.red = 0;
                    break;
                case 2:
                    t_rgb.blue = t_rgb.red;
                    t_rgb.red = 0;
                    break;
                case 3:
                    t_rgb.red = t_rgb.blue = t_rgb.green = 0;
                    //点亮白灯
                    led_strip_set_white_pulse(DEFAULT_PULSE);
                    break;
                default:
                    t_rgb.blue = t_rgb.green = 0;
                    //关闭白灯
                    led_strip_set_white_pulse(0);
                    break;
            }
            break;
        case PRD_SCENE_RUNNING:
            //点亮白灯
            led_strip_set_white_pulse(DEFAULT_PULSE);
            break;
        case PRD_SCENE_PASS:
            //点亮绿灯
            t_rgb.red = t_rgb.blue = 0;
            t_rgb.green = 255;
            //关闭白灯
            led_strip_set_white_pulse(0);
            break;
        case PRD_SCENE_FAIL:
            //点亮红灯
            t_rgb.green = t_rgb.blue = 0;
            t_rgb.red = 255;
            //关闭白灯
            led_strip_set_white_pulse(0);
            break;
        default :
            break;
    }

    for (int i = 0; i < rgb->leds_total_number; i++)
    {
        led_set_pixel(strip, i, t_rgb.red, t_rgb.blue , t_rgb.green);
    }
    led_reflash_pixel(strip, 2);
    return wait_ms;
}

/**
 * @brief      配网灯效
 *
 * @param[in]  strip                [灯带结构体指针]
 * @param[in]  rgb                  [灯带灯珠颜色参数结构体指针]
 * @param[in]  signal               [灯带灯效控制参数结构体指针]
 * @return     uint32_t             [灯效延时时间]
 */
uint32_t led_strip_cfgnet_scene(led_strip_t *strip, rgb_parameters_t *rgb, \
                                                           led_strip_signal_hsv_t *signal)
{
    static uint8_t count = 0;
    uint32_t wait_ms = SCENE_WAIT_MS_DEFAULT;

    if ((NULL == strip)||(NULL == rgb)||(NULL == signal))
    {
        APP_LOG(LOG_ERROR, "input error!\n");
        return wait_ms;
    }

    led_strip_close_rgb(strip, rgb);

    switch (signal->scene)
    {
        case CFG_SCENE_START:
            if (CFG_SCENE_START != s_cfgnet_scene)
            {
                count = 0;
                s_cfgnet_scene = CFG_SCENE_START;
            }

            if (count < 50)   // 闪烁时间为5S，周期为1S，后续为常亮
            {
                if (5 == (count % 10))
                {
                    led_strip_set_white_pulse(DEFAULT_PULSE);
                }
                else if (0 == (count % 10))
                {
                    led_strip_set_white_pulse(0);
                }
                count++;
            }
            else
            {
                led_strip_set_white_pulse(DEFAULT_PULSE);
            }

            break;
        case CFG_SCENE_RUNNING:
            s_cfgnet_scene = CFG_SCENE_RUNNING;
            led_strip_set_white_pulse(DEFAULT_PULSE);
            break;
        case CFG_SCENE_SUCCESS:
            s_cfgnet_scene = CFG_SCENE_SUCCESS;
            led_strip_set_white_pulse(DEFAULT_PULSE);
        default :
            break;
    }
    signal->count++;
    return wait_ms;
}

/**
 * @brief      复位场景灯效
 *
 * @param[in]  strip                [灯带结构体指针]
 * @param[in]  rgb                  [灯带灯珠颜色参数结构体指针]
 * @param[in]  signal               [灯带灯效控制参数结构体指针]
 * @return     uint32_t             [灯效延时时间]
 */

uint32_t led_strip_reset_scene(led_strip_t *strip, rgb_parameters_t *rgb, \
                                                           led_strip_signal_hsv_t *signal)
{
    uint32_t wait_ms = SCENE_WAIT_MS_DEFAULT;
    rgb_color_t t_rgb;

    if ((NULL == strip)||(NULL == rgb)||(NULL == signal))
    {
        APP_LOG(LOG_ERROR, "input error!\n");
        return wait_ms;
    }
    if (signal->count < 49)   // 闪烁时间为5S，周期为1S，后续为常亮
    {
        if (5 == (signal->count % 10))
        {
            led_strip_close_rgb(strip, rgb);
        }
        else if (0 == (signal->count % 10))
        {
            led_strip_set_white_pulse(0); // 关闭白灯
            t_rgb.red = 255;
            t_rgb.green = 0;
            t_rgb.blue = 0;
            led_strip_light_up_rgb(strip, rgb, t_rgb);
        }
        signal->count ++;
    }

    return wait_ms;
}

/**
 * @brief      自定义场景灯效
 *
 * @param[in]  strip                [灯带结构体指针]
 * @param[in]  rgb                  [灯带灯珠颜色参数结构体指针]
 * @param[in]  signal               [灯带灯效控制参数结构体指针]
 * @return     uint32_t             [灯效延时时间]
 */
uint32_t led_strip_custom_scene(led_strip_t *strip, rgb_parameters_t *rgb, \
                                                           led_strip_signal_hsv_t *signal)
{
    uint8_t  find_res = 0;
    uint32_t wait_ms = SCENE_WAIT_MS_REALTIME;

    if ((NULL == strip)||(NULL == rgb)||(NULL == signal))
    {
        APP_LOG(LOG_ERROR, "input error!\n");
        return wait_ms;
    }

    if (0 == signal->count)
    {
        for (int i = 0 ; i < SCENE_CUSTOM_MAX_NUM; i++)
        {
            if (signal->scene == s_led_strip.scene_list[i].id)          // 遍历列表，找到当前ID
            {
                signal->number = s_led_strip.scene_list[i].num;
                led_strip_scene_data_transform(s_led_strip.scene_list[i].color, signal, s_led_strip.scene_list[i].type);
                find_res = 1;
                break;
            }
        }

        if (0 == find_res) // 没有找到对应ID的场景，退出执行
        {
            return wait_ms;
        }
        wait_ms = led_strip_realtime_scene(strip, rgb, signal);
    }
    return wait_ms;
}

/**
 * @brief      实时控制灯效
 *
 * @param[in]  strip                [灯带结构体指针]
 * @param[in]  rgb                  [灯带灯珠颜色参数结构体指针]
 * @param[in]  signal               [灯带灯效控制参数结构体指针]
 * @return     uint32_t             [灯效延时时间]
 */
uint32_t led_strip_realtime_scene(led_strip_t *strip, rgb_parameters_t *rgb, \
                                                           led_strip_signal_hsv_t *signal)
{
    uint8_t segment = MAX_SEGMENT_NUM;
    uint8_t last_segment = MAX_SEGMENT_NUM;
    uint32_t wait_ms = SCENE_WAIT_MS_REALTIME;

    if ((NULL == strip)||(NULL == rgb)||(NULL == signal))
    {
        APP_LOG(LOG_ERROR, "input error!\n");
        return wait_ms;
    }
    if (0 == signal->count)
    {
        signal->count = 1;
        switch (signal->scene)
        {
            case SCENE_COLOR_WHITE:
                led_strip_set_white_pulse(signal->rgb.red);
                led_strip_close_rgb(strip, rgb);
                break;
            case SCENE_COLOR_RGB:
                led_strip_set_white_pulse(0);   // 关闭白灯
                led_strip_light_up_rgb(strip, rgb, signal->rgb);
                break;
            case SCENE_COLOR_MULT:
                led_strip_set_white_pulse(0);   // 关闭白灯
                for (int i = 0; i < rgb->leds_total_number; i++)
                {
                    if (signal->number < rgb->leds_total_number)
                    {
                        segment = (i*signal->number)/rgb->leds_total_number;
                    }
                    else
                    {
                        segment = i;
                    }

                    if (last_segment != segment)
                    {
                        led_strip_hsv2rgb(&(signal->rgb), signal->hsv + segment);
                        last_segment = segment;
                    }
                    led_set_pixel(strip, i, signal->rgb.red, signal->rgb.blue, signal->rgb.green);
                }
                led_reflash_pixel(strip, 2);
                break;
            default :
                break;
        }
    }

    return wait_ms;
}

/**
 * @brief      关闭灯效
 *
 * @param[in]  strip                [灯带结构体指针]
 * @param[in]  rgb                  [灯带灯珠颜色参数结构体指针]
 * @param[in]  signal               [灯带灯效控制参数结构体指针]
 * @return     uint32_t             [灯效延时时间]
 */
uint32_t led_strip_off_scene(led_strip_t *strip, rgb_parameters_t *rgb, \
                                                           led_strip_signal_hsv_t *signal)
{
    uint32_t wait_ms = SCENE_WAIT_MS_DEFAULT;
    if (0 == signal->count)
    {
        led_strip_close_rgb(strip, rgb);
        led_strip_set_white_pulse(0); //关闭白灯
        signal->count = 1;
    }
    else
    {
        wait_ms = SCENE_WAIT_MS_DEFAULT;
    }
    return wait_ms;
}

#if 0

//freq_segment_t t_freq_led_num_conf_table[] = {           /*<! This structure array defines the number of lights in each frequency band */
//    { 120,  400},
//    { 400,  600},
//    { 600,  800},
//    { 800,  1000},
//    { 1000, 1200},
//    {1200, 1400},
//    {1400, 1600},
//    {1600, 1800},
//    {1800, 2000},
//    {2000, 2200},
//    { 2200,  2400},
//    { 2400,  2600},
//    { 2600,  2800},
//    { 3000,  3250},
//    { 3250, 3500},
//    {3750, 4000},
//    {4000, 4500},
//    {4500, 5000},
//    {5000, 6000},
//    {6000, 8500},
//};

/**
 * @brief      This is an example of a user-defined light effect function
 *
 * @param[in]  strip                The pointer of led strip
 * @param[in]  rgb                  RGB parameters(It contains all the parameters related to rgb)
 * @param[in]  signal               the signals that generate rgb data buffer
 */
void led_strip_loudness_scene (led_strip_t *strip, rgb_parameters_t *rgb, \
                                                           led_strip_signal_hsv_t *signal)
{
    rgb_color_t t_rgb ;
    static hsv_color_t hsv_color = {.hue = 0.0, .saturation = 1.0, .value =1.0};

    if ((NULL == strip)||(NULL == rgb))
    {
        APP_LOG(LOG_ERROR, "input error!\n");
        return ;
    }

    if (rgb->max_audio_data < rgb->min_sound_threshold)
    {
        t_rgb.green = t_rgb.red = t_rgb.blue = 0;
    }
    else{
        hsv_color.hue = hsv_color.hue + 1.0;
        if (hsv_color.hue > 360.0)
        {
            hsv_color.hue = 0.0;
        }
        hsv_color.value = rgb->max_audio_data / rgb->max_rec ;
        if (hsv_color.value > 1.0)
        {
            hsv_color.value = 1.0;
        }
        led_strip_hsv2rgb (&t_rgb, &hsv_color);
    }

    for(int i=0; i < rgb->leds_total_number; i++)
    {
        led_set_pixel(strip, i, t_rgb.red, t_rgb.green, t_rgb.blue);
    }

    led_reflash_pixel(strip, 1);
    vTaskDelay(5);
}

/**
 * @brief      This is an example of a user-defined light effect function
 *
 * @param[in]  strip                The pointer of led strip
 * @param[in]  rgb                  RGB parameters(It contains all the parameters related to rgb)
 * @param[in]  signal               the signals that generate rgb data buffer
 */
void led_strip_frequency_scene (led_strip_t *strip, rgb_parameters_t *rgb, \
                                                           led_strip_signal_hsv_t *signal)
{
    float freq = 0;
    int32_t *num = rgb->freq_normal->num;
    rgb_ctrl_t *rgb_ctrl = rgb->rgb_ctrl;
    uint32_t light_num = 0;
    uint32_t color_hue = 0;
    rgb_color_t t_rgb ;
    int32_t pos = 0;
    static uint32_t s_hue = 0.0;
    hsv_color_t hsv_color = {.hue = 0.0, .saturation = 1.0, .value =1.0};
    uint8_t segment_num  = sizeof(t_freq_led_num_conf_table)/sizeof(t_freq_led_num_conf_table[0]);

    if ((NULL == strip)||(NULL == rgb))
    {
        APP_LOG(LOG_ERROR, "input error!\n");
        return ;
    }

    if (rgb->max_audio_data < rgb->min_sound_threshold)
    {
        rgb_ctrl->led_num = 0;               /* Turn off the lights */
    }
    else{
        freq = num[(rgb->freq_normal->n_samples>>2) - 1] * rgb->audio_samplerate / rgb->freq_normal->n_samples;   /* Calculation frequency */
        for (int i = 0; i < segment_num; i++) {
            if (freq < rgb->min_freq_threshold) {
                rgb_ctrl->led_num = 0;
            } else if ((freq >= t_freq_led_num_conf_table[i].freq_min) && (freq < t_freq_led_num_conf_table[i].freq_max)) {
                rgb_ctrl->led_num = i + 1;
            } else if (freq > t_freq_led_num_conf_table[i].freq_max) {
                rgb_ctrl->led_num = i + 1;
            }
        }
        s_hue = s_hue + 1;
    }

    light_num = rgb_ctrl->led_num;
    rgb->begin = (segment_num>>1) - (light_num>>1);
//    printf("light:%d, begin:%d \n", light_num, rgb->begin);

    for(int i=0; i < rgb->leds_total_number; i++)
    {
        pos = i % segment_num;
        if ((rgb->begin <= pos)&&((rgb->begin + light_num) > pos))
        {
            color_hue =(s_hue + (pos<<3))%360;
            hsv_color.hue = (float)color_hue;
            led_strip_hsv2rgb (&t_rgb, &hsv_color);
            led_set_pixel(strip, i, t_rgb.red, t_rgb.green, t_rgb.blue);
        }
        else
        {
            led_set_pixel(strip, i, 0, 0, 0);
        }
    }

    led_reflash_pixel(strip, 1);
    vTaskDelay(5);
}

/**
 * @brief      This is an example of a user-defined light effect function
 *
 * @param[in]  strip                The pointer of led strip
 * @param[in]  rgb                  RGB parameters(It contains all the parameters related to rgb)
 * @param[in]  signal               the signals that generate rgb data buffer
 */
void led_strip_custom_scene (led_strip_t *strip, rgb_parameters_t *rgb, \
                                                           led_strip_signal_hsv_t *signal)
{
//    int32_t hsv_pos = 0;
//    rgb_color_t t_rgb ;
//    led_strip_signal_hsv_t * hsv_signal = signal;
    static uint8_t  pulse = 0;
    static char flag = 0;

    if ((NULL == strip)||(NULL == rgb))
    {
        APP_LOG(LOG_ERROR, "input error!\n");
        return ;
    }
    vhal_led_set_duty(WHITE_LED_CHANNEL, pulse);
    if (0 == flag)
    {
        pulse += 2;
        if (100 <= pulse)
        {
            flag = 1;
        }
    }
    else
    {
        pulse -= 2;
        if (0 >= pulse)
        {
            flag = 0;
            pulse = 0;
        }
    }

    if (0 == pulse)
    {
        for (int i = 0; i < rgb->leds_total_number; i++)
        {
    //        hsv_pos = i%hsv_signal->number;
    //        led_strip_hsv2rgb(&t_rgb, hsv_signal->hsv + hsv_pos);
            led_set_pixel(strip, i, 0, 0, 0);
        }
        led_reflash_pixel(strip, 5);
    }

    vTaskDelay(10);
}

/**
 * @brief      This is an example of a user-defined light effect function
 *
 * @param[in]  strip                The pointer of led strip
 * @param[in]  rgb                  RGB parameters(It contains all the parameters related to rgb)
 * @param[in]  signal               the signals that generate rgb data buffer
 */
void led_strip_dynamic_scene (led_strip_t *strip, rgb_parameters_t *rgb, \
                                                           led_strip_signal_hsv_t *signal)
{
    static uint8_t round = 0;
    static int16_t display_count = 0;
    static uint16_t total_num = 0;
    int16_t right = 0 ;
    int16_t left = 0;
    rgb_color_t t_rgb ;
    led_strip_signal_hsv_t * hsv_signal = signal;

    if ((NULL == strip)||(NULL == rgb))
    {
        APP_LOG(LOG_ERROR, "input error!\n");
        return ;
    }

    led_strip_hsv2rgb(&t_rgb, hsv_signal->hsv+hsv_signal->display_pos);
    if (total_num != rgb->leds_total_number)  // 灯珠个数发生变化
    {
        total_num = rgb->leds_total_number;
        for (int i = 0; i < rgb->leds_total_number; i++)
        {
            led_set_pixel(strip, i, t_rgb.red, t_rgb.green, t_rgb.blue);
            hsv_signal->display_pos++;
        }
    }
    else
    {
        right = (total_num >> 1);
        left = total_num - right - display_count;
        right += display_count;

        if (0 > left)
        {
            left = 0;
        }

        if (right >= total_num)
        {
            right = total_num -1;
        }

        if (0 == round)
        {

            for (int i = left; i <=right; i++)
            {
                led_set_pixel(strip, i, t_rgb.green, t_rgb.red, t_rgb.blue);
            }
            display_count++;
            if((total_num >> 1) == display_count)
            {
                round = 1;
                hsv_signal->display_pos++;
                if (hsv_signal->display_pos >= hsv_signal->number)
                {
                    hsv_signal->display_pos = 0;
                }
            }
        }
        else
        {
            for (int i = 0; i < left; i++)
            {
                led_set_pixel(strip, i, t_rgb.red, t_rgb.green, t_rgb.blue);
            }

            for (int i = right; i < rgb->leds_total_number; i++)
            {
                led_set_pixel(strip, i, t_rgb.red, t_rgb.green, t_rgb.blue);
            }
            display_count--;
            if(0 > display_count)
            {
                display_count = round = 0;
                hsv_signal->display_pos++;
                if (hsv_signal->display_pos >= hsv_signal->number)
                {
                    hsv_signal->display_pos = 0;
                }
            }
        }
    }
    led_reflash_pixel(strip, 5);
    vTaskDelay(10);
}

/**
 * @brief      This is an example of a user-defined light effect function
 *
 * @param[in]  strip                The pointer of led strip
 * @param[in]  rgb                  RGB parameters(It contains all the parameters related to rgb)
 * @param[in]  signal               the signals that generate rgb data buffer
 */
void led_strip_dream_scene (led_strip_t *strip, rgb_parameters_t *rgb, \
                                                           led_strip_signal_hsv_t *signal)
{

    color_palette_t * palette = NULL;

    if ((NULL == strip)||(NULL == rgb))
    {
        APP_LOG(LOG_ERROR, "input error!\n");
        return ;
    }
    palette  = led_strip_color_get_palette("dream");
    //APP_LOG(LOG_DEBUG, "color num:%d \n", palette->color_num);
    if (NULL != palette)
    {
        led_rgb_generate_from_palette(strip, rgb, palette, signal->number);
        led_reflash_pixel(strip, 5);
        //APP_LOG(LOG_DEBUG, "led_sunset_glow scene set success\n");
    }
    vTaskDelay(10);

}


/**
 * @brief      This is an example of a user-defined light effect function
 *
 * @param[in]  strip                The pointer of led strip
 * @param[in]  rgb                  RGB parameters(It contains all the parameters related to rgb)
 * @param[in]  signal               the signals that generate rgb data buffer
 */
void led_strip_sunset_glow_scene (led_strip_t *strip, rgb_parameters_t *rgb, \
                                                           led_strip_signal_hsv_t *signal)
{
    color_palette_t * palette = NULL;

    if ((NULL == strip)||(NULL == rgb))
    {
        APP_LOG(LOG_ERROR, "input error!\n");
        return ;
    }

    palette  = led_strip_color_get_palette("sunset");
    //APP_LOG(LOG_DEBUG, "color num:%d \n", palette->color_num);
    if (NULL != palette)
    {
        led_rgb_generate_from_palette(strip, rgb, palette, signal->number);
        led_reflash_pixel(strip, 5);
        //APP_LOG(LOG_DEBUG, "led_sunset_glow scene set success\n");
    }
    vTaskDelay(10);

}

/**
 * @brief      This is an example of a user-defined light effect function
 *
 * @param[in]  strip                The pointer of led strip
 * @param[in]  rgb                  RGB parameters(It contains all the parameters related to rgb)
 * @param[in]  signal               the signals that generate rgb data buffer
 */
void led_strip_colorful_scene (led_strip_t *strip, rgb_parameters_t *rgb, \
                                                           led_strip_signal_hsv_t *signal)
{
    static int32_t count = 0;
    static char flag = 0;
    rgb_color_t t_rgb ;
    uint16_t hsv_index = 0;
    led_strip_signal_hsv_t * hsv_signal = signal;

    if ((NULL == strip)||(NULL == rgb))
    {
        APP_LOG(LOG_ERROR, "input error!\n");
        return ;
    }

    if (0 == flag)
    {
        count += 2;
        if (100 <= count)
        {
            flag = 1;
        }
    }
    else
    {
        count -= 2;
        if (0 >= count)
        {
            flag = 0;
        }
    }

    hsv_signal->value.amplitude_max = (float)count/100.0;
    for (int i = 0; i < rgb->leds_total_number; i++)
    {
        hsv_index = i % hsv_signal->number;
        hsv_signal->hsv[hsv_index].value = hsv_signal->value.amplitude_max;
        led_strip_hsv2rgb(&t_rgb, hsv_signal->hsv+hsv_index);
        led_set_pixel(strip, i, t_rgb.red, t_rgb.green, t_rgb.blue);
    }
    led_reflash_pixel(strip, 1);
    vTaskDelay(2);
}

/**
 * @brief 根据工作场景生成hsv颜色空间信息
 * @param[in]     hue_period                             [hue信号周期]
 * @param[in]     value_period                           [vaue信号周期]
 * @param[in out] led_strip_signal_hsv_t                 [hsv 颜色空间数据信息]
 * @note
 */
int led_strip_hsv_genneration(uint8_t hue_period, uint8_t value_period, led_strip_signal_hsv_t *signal)
{
    int ret = FAILURE;
    led_strip_signal_hsv_t * hsv_signal = signal;

    if ((NULL == signal)||(MAX_SEGMENT_NUM < hue_period)||(MAX_SEGMENT_NUM < value_period))
    {
        APP_LOG(LOG_ERROR, "input error!\n");
        return ret;
    }

    hsv_signal->display_pos = 0;
    hsv_signal->saturation.range = 1.0;
    hsv_signal->saturation.period = hsv_signal->number;
    hsv_signal->saturation.amplitude_max = 1.0;
    hsv_signal->saturation.amplitude_min = 1.0 ;
    hsv_signal->saturation.signal_type = SIGNAL_LINE;

    switch (hsv_signal->scene)
    {
        case SCENE_FLOWING:
            hsv_signal->hue.period = 4;
            hsv_signal->hue.amplitude_max = 240;
            hsv_signal->hue.amplitude_min = 140 ;
            hsv_signal->hue.range = 360;
            hsv_signal->hue.signal_type = SIGNAL_SQUARE;

            hsv_signal->value.range = 1.0;
            hsv_signal->value.period = 4;
            hsv_signal->value.amplitude_max = 1.0;
            hsv_signal->value.amplitude_min = 0.5 ;
            hsv_signal->value.signal_type = SIGNAL_SLOPE;
            break;
        case SCENE_RAINBOW:
        case SCENE_BREATH:
            hsv_signal->hue.period = hue_period;
            hsv_signal->hue.amplitude_max = 320;
            hsv_signal->hue.amplitude_min = 40 ;
            hsv_signal->hue.range = 360;
            hsv_signal->hue.signal_type = SIGNAL_SLOPE;

            hsv_signal->value.range = 1.0;
            hsv_signal->value.period = value_period;
            hsv_signal->value.amplitude_max = 1.0;
            hsv_signal->value.amplitude_min = 0.3 ;
            hsv_signal->value.signal_type = SIGNAL_TRIANGLE;
            break;

        default :
            hsv_signal->hue.period = hue_period;
            hsv_signal->hue.amplitude_max = 360;
            hsv_signal->hue.amplitude_min = 360 ;
            hsv_signal->hue.range = 360;
            hsv_signal->hue.signal_type = SIGNAL_LINE;

            hsv_signal->value.range = 1.0;
            hsv_signal->value.period = value_period;
            hsv_signal->value.amplitude_max = 0.0;
            hsv_signal->value.amplitude_min = 0.0 ;
            hsv_signal->value.signal_type = SIGNAL_LINE;
            break;
    }

    for (int i = 0; i < hsv_signal->number; i++)
    {
        led_strip_signal_generate(i, &hsv_signal->hsv[i].hue, hsv_signal->hue);
        led_strip_signal_generate(i, &hsv_signal->hsv[i].saturation, hsv_signal->saturation);
        led_strip_signal_generate(i, &hsv_signal->hsv[i].value, hsv_signal->value);
    }
    return ret ;
}


#endif

