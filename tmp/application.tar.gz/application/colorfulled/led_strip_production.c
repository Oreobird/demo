/**
*Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file    ledstrip_production.c
* @brief   产测功能
* @author  henrik
*@date     2021-10-25
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "vesync_common.h"
#include "vesync_log.h"
#include "vesync_device.h"
#include "vesync_production.h"

#include "led_strip.h"
#include "led_strip_scene.h"
#include "led_strip_button.h"
#include "led_strip_production.h"

/**
* @brief 产测状态回调函数
* @param[in]  status          [产测状态码]
*/
static void led_strip_production_status_cb(PRODUCTION_STATUS_E status)
{
    ls_ev_t ev;
    ev.event = LS_EV_PRODUCTION;
    ev.act_src = LS_ACT_SRC_PRD;
    ev.scene_type = SCENE_TYPE_PRD;

    switch(status)
    {
        case PRODUCTION_START:
            led_strip_button_task_exit();
            ev.scene_id = PRD_SCENE_START;
            break;
        case PRODUCTION_RUNNING:
            ev.scene_id = PRD_SCENE_RUNNING;
            break;
        case PRODUCTION_TEST_PASS:
            APP_LOG(LOG_INFO, "production pass\n");
            ev.scene_id = PRD_SCENE_PASS;
            break;
        case PRODUCTION_TEST_FAIL:
            APP_LOG(LOG_INFO, "production fail\n");
            ev.scene_id = PRD_SCENE_FAIL;
            break;
        default:
            break;
    }

    if (status < PRODUCTION_EXIT)
    {
        led_strip_app_task_notify(&ev);
    }
}

/**
* @brief 产测结果回调函数
* @param[in]  err_code          [产测状态码]
*/
static void led_strip_production_result_cb(PRODUCTION_ERROR_E err_code)
{
    if (PRD_NO_ERR == err_code)
    {
        APP_LOG(LOG_INFO, "production success\n");
    }
    else
    {
        APP_LOG(LOG_INFO, "production error %d\n", err_code);
    }
}

/**
* @brief ledstrip产测功能初始化
*/
void led_strip_production_init(void)
{
    vesync_production_reg_status_cb(led_strip_production_status_cb);
    vesync_production_reg_result_cb(led_strip_production_result_cb);
}


