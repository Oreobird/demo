/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_developer.c
 * @brief       开发者模式接口实现
 * @date        2021-06-22
 */

#include <string.h>
#include <stdio.h>

#if defined(CONFIG_TARGET_LINUX)
#include <sys/types.h>
#include <sys/socket.h>
#include <unistd.h>
#include <errno.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#else
#include "lwip/netif.h"
#include "lwip/tcpip.h"
#include "lwip/sockets.h"
#include "lwip/sockets.h"
#include "netif/etharp.h"
#endif
#include "vhal_flash.h"
#include "vhal_utils.h"
#include "vesync_common.h"
#include "vesync_log_internal.h"
#include "vesync_os.h"
#include "vesync_timer.h"
#include "vesync_memory.h"
#include "vesync_developer_internal.h"
#include "vesync_sem.h"
#include "vesync_queue.h"
#include "vesync_mutex.h"
#include "vesync_bypass_internal.h"
#include "vesync_event_internal.h"

static struct sockaddr_in server_addr;
static int socket_fd = DEVELOPER_INVALID_SOCK;
static char *s_dlper_buf = NULL;
static int s_client_num = 0;

static vesync_task_t developer_taskhd = NULL;

static vesync_queue_t *s_dlper_queue = NULL;
static vesync_sem_t *s_dlper_queue_sem = NULL;

static bool s_developer_stop = false;


/**
 * @brief 信号量初始化
 * @return    void              [无]
 */
static uint8_t vesync_developer_sem_init(void)
{
    s_dlper_queue_sem = vesync_sem_binary_new();
    if (s_dlper_queue_sem == NULL)
    {
        return SDK_FAIL;
    }

    vesync_sem_signal(s_dlper_queue_sem);

    return SDK_OK;
}

/**
 * @brief 信号量初始化
 * @return    void              [无]
 */
static void vesync_developer_sem_deinit(void)
{
    vesync_sem_free(s_dlper_queue_sem);
    s_dlper_queue_sem = NULL;
}

/**
 * @brief msgbuf创建信号量
 * @return    void              [无]
 */
static uint8_t vesync_developer_buf_wait_semp(void)
{
    int ret = vesync_sem_wait(s_dlper_queue_sem, 2000);
    if (ret != VOS_OK)
    {
        SDK_LOG(LOG_ERROR, "Wait semaphore fail!\n");
        return SDK_FAIL;
    }

    return SDK_OK;
}

/**
 * @brief msgbuf释放信号量
 * @return    void              [无]
 */
static uint8_t vesync_developer_buf_release_semp(void)
{
    int ret = vesync_sem_signal(s_dlper_queue_sem);
    if (ret != VOS_OK)
    {
        SDK_LOG(LOG_ERROR, "Give semaphore fail!\n");
        return SDK_FAIL;
    }

    return SDK_OK;
}

/**
 * @brief msgbuf 初始化
 * @return    void              [无]
 */
static void vesync_developer_queue_init(void)
{
    s_dlper_queue = vesync_queue_new(DEVELOPER_BUFFER_SIZE, DEVELOPER_BUFFER_SIZE);
    if (NULL == s_dlper_queue)
    {
        SDK_LOG(LOG_ERROR, "developer_queue_init error.\n");
    }
}

/**
 * @brief msgbuf 复位
 * @return    void              [无]
 */
static void vesync_developer_queue_reset(void)
{
    int ret = vesync_queue_clear(s_dlper_queue);
    if (VOS_OK != ret)
    {
        SDK_LOG(LOG_ERROR, "queue clear error.\n");
    }
}


/**
 * @brief msgbuf 释放
 * @return    void              [无]
 */
static void vesync_developer_queue_destroy(void)
{
    if (NULL != s_dlper_queue)
    {
        vesync_queue_free(s_dlper_queue);
        s_dlper_queue = NULL;
    }
}


/**
 * @brief 读取开发者msgbuf数据
 * @return    int               [<=0,失败; >0,读取数据的长度]
 */
static int vesync_developer_queue_read(void)
{
    if ((NULL == s_dlper_queue) || (NULL == s_dlper_buf))
    {
        return -1;
    }

    memset(s_dlper_buf, 0, DEVELOPER_BUFFER_SIZE);
    int ret = vesync_queue_recv(s_dlper_queue, (void *)s_dlper_buf, VESYNC_OS_NO_WAIT);
    return ret == VOS_OK ? SDK_OK : SDK_FAIL;
}


/**
 * @brief 往开发者msgbuf数据
 * @param[in]  p_data           [待插入数据]
 * @param[in]  len              [待插入数据长度]
 * @return     int              [<=0,失败; >0, 写入队列的数据长度]
 */
static int vesync_developer_queue_write(char *p_data, int len)
{
    if ((s_client_num < 1) || (NULL == s_dlper_queue) || (NULL == p_data) || (0 == len))
    {
        return -1;
    }

    // 防止多任务同时发送，添加信号量，超时时间设置为0
    vesync_developer_buf_wait_semp();
    vesync_queue_send(s_dlper_queue, (void *)p_data, 0);
    vesync_developer_buf_release_semp();

    return len;
}



/**
 * @brief   关闭socket
 */
static void vesync_developer_close_sock(void)
{
    if (socket_fd >= 0)
    {
        close(socket_fd);
        socket_fd = DEVELOPER_INVALID_SOCK;
    }
}


/**
 * @brief 开发者模式处理命令
 * @param[in]   pDat        [接收数据指针]
 */
static void vesync_developer_recv_handle(char *p_data)
{
    vesync_bypass_msg_handle(p_data, MSG_TAG_DVLPR);
}


/**
 * @brief 读取tcp数据
 *
 * @param my_socket
 * @param buffer
 * @param len
 * @param timeout_ms
 * @return int
 */
static int vesync_developer_data_read(int my_socket, unsigned char *buffer, unsigned int len, unsigned int timeout_ms)
{
    int recvLen = 0, rc = 0, ret = 0;
    struct timeval timeout;
    fd_set fdset;

    FD_ZERO(&fdset);
    FD_SET(my_socket, &fdset);

    timeout.tv_sec = 0;
    timeout.tv_usec = timeout_ms * 1000;
    ret = select(my_socket + 1, &fdset, 0, 0, &timeout);
    if (ret == 0)
    {
        // ret == 0: timeout
        // ret < 0:  socket err
        //SDK_LOG(LOG_ERROR, "timeout.\n");
        return ret;
    }
    else if(ret < 0)
    {
        SDK_LOG(LOG_ERROR, "select error .\n");
        return ret;
    }

    if (FD_ISSET(my_socket, &fdset))
    {
        rc = recv(my_socket, buffer , len, MSG_DONTWAIT);
        if (rc > 0)
        {
            recvLen = rc;
        }
        else if (rc < 0)
        {
            recvLen = rc;
        }
        else
        {
            recvLen = -1;
        }
    }
    //SDK_LOG(LOG_DEBUG, "recvLen = %d.\n", recvLen);
    return recvLen;
}

/**
 * @brief 发通知到开发者任务
 *
 * @param ulValue   [通知消息，取相应位设置1]
 */
static void vesync_developer_event_notify(EVENT_ID_E event_id)
{
    vesync_ev_t event;
    VESYNC_POPULATE_EV(event, event_id, DEVELOPER_TASK_NAME, 0, NULL);
    vesync_event_publish(&event);
}

/**
 * @brief 开发者模式线程
 * @param args [无]
 */
static void vesync_developer_server_task(void *args)
{
    int ret_len = 0;
    int client_fd = -1;
    int keepAlive = VESYNC_DEVELOPER_KEEPALIVE;
    int keepIdle = VESYNC_DEVELOPER_KEEPIDLE;
    int keepInterval = VESYNC_DEVELOPER_KEEPINTV;
    int keepCount = VESYNC_DEVELOPER_KEEPCNT;
    socklen_t sockaddr_len = sizeof(server_addr);

    vesync_developer_sem_init();

    while (1)
    {
        if (s_dlper_buf)      //先释放上次申请的内存
        {
            vesync_free(s_dlper_buf);
            s_dlper_buf = NULL;
        }

        client_fd = accept(socket_fd, (struct sockaddr*)&server_addr, &sockaddr_len);
        if (client_fd < 0)
        {
            SDK_LOG(LOG_ERROR, "TCP server accept error : %d, sock_id = %d.\n", errno, socket_fd);
            goto exit;
        }

        s_client_num++;
        SDK_LOG(LOG_INFO, "Developer client connected, client_fd = %d.\n", client_fd);

        vesync_developer_queue_reset();

        //有tcp 客户端接入再申请内存
        s_dlper_buf = (char*)vesync_malloc(DEVELOPER_BUFFER_SIZE);
        if (NULL == s_dlper_buf)
        {
            SDK_LOG(LOG_ERROR, "malloc error...\n");
            goto exit;
        }

        setsockopt(client_fd, SOL_SOCKET, SO_KEEPALIVE, &keepAlive, sizeof(int));
        setsockopt(client_fd, IPPROTO_TCP, TCP_KEEPIDLE, &keepIdle, sizeof(int));
        setsockopt(client_fd, IPPROTO_TCP, TCP_KEEPINTVL, &keepInterval, sizeof(int));
        setsockopt(client_fd, IPPROTO_TCP, TCP_KEEPCNT, &keepCount, sizeof(int));

        while (1)
        {
            ret_len = vesync_developer_data_read(client_fd, (unsigned char *)s_dlper_buf, (DEVELOPER_BUFFER_SIZE - 1), 50);
            if (ret_len > 0)
            {
                s_dlper_buf[ret_len] = 0;
                SDK_LOG(LOG_DEBUG, "Developer recv: %s\n", s_dlper_buf);
                vesync_developer_recv_handle(s_dlper_buf);
            }
            else if(0 == ret_len)
            {
                //read timeout
            }
            else
            {
                 SDK_LOG(LOG_ERROR, "Developer tcp close.\n");
                 break;
            }

            if (SDK_OK == vesync_developer_queue_read())
            {
                ret_len = send(client_fd, s_dlper_buf, strlen(s_dlper_buf), MSG_DONTWAIT);
                if (ret_len <= 0)
                {
                    SDK_LOG(LOG_ERROR, "send error : buf_len=%d\n", strlen(s_dlper_buf));
                    break;
                }
            }

            if (s_developer_stop)
            {
                SDK_LOG(LOG_DEBUG, "[developer] stop.\n");
                close(client_fd);
                goto exit;
            }
        }

        SDK_LOG(LOG_DEBUG, "developer client disconnect.\n");
        if (client_fd >= 0)
        {
            shutdown(client_fd, SHUT_RDWR);
            close(client_fd);
            client_fd = DEVELOPER_INVALID_SOCK;
            s_client_num--;
        }
    }

exit:

    vesync_developer_close_sock();

    if(s_dlper_buf)
    {
        vesync_free(s_dlper_buf);
        s_dlper_buf = NULL;
    }

    SDK_LOG(LOG_DEBUG, "[developer] exit task.\n");
    developer_taskhd = NULL;
}


/**
 * @biref  事件回调
 * @return  int      [0为成功，其他值为失败]
 */
static int developer_stop_event_cb(void *data)
{
    UNUSED(data);
    s_developer_stop = true;
    return SDK_OK;
}


/**
 * @biref  事件订阅
 */
static void developer_event_init(void)
{
    vesync_event_subscribe(EVENT_DEVELOPER_STOP, SUB_ID_DEVELOPER, developer_stop_event_cb);
}

/**
 * @biref  取消事件订阅
 */
static void developer_event_deinit(void)
{
    vesync_event_unsubscribe(EVENT_DEVELOPER_STOP, SUB_ID_DEVELOPER);
}

/**
 * @brief   启动开发者模式
 * @return    int           [启动结果，0为成功，其他值为失败]
 */
int vesync_developer_start(void)
{
    int ret = -1;
    int reuse = 1;          // 1表示可以重用，0表示不可以重用

    if (socket_fd >= 0)
    {
        SDK_LOG(LOG_WARN, "Developer tcp server already started.\n");
        return 0;
    }

    memset(&server_addr, 0, sizeof(server_addr));
    //server_addr.sin_len = sizeof(server_addr);
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(DEVELOPER_LISTEN_PORT);
    server_addr.sin_addr.s_addr = htonl(INADDR_ANY);

    SDK_LOG(LOG_DEBUG, "Developer tcp server start.\n");

    vesync_developer_queue_init();
    vesync_log_reg_transfer_cb(vesync_developer_queue_write);

    socket_fd = socket(AF_INET, SOCK_STREAM, 0);
    if(socket_fd < 0)
    {
        SDK_LOG(LOG_ERROR, "TCP server create failed.\n");
        return -1;
    }

    setsockopt(socket_fd, SOL_SOCKET, SO_REUSEADDR, &reuse, sizeof(reuse));
    setsockopt(socket_fd, SOL_SOCKET, SO_REUSEPORT, &reuse, sizeof(reuse));

    ret = bind(socket_fd, (struct sockaddr*)&server_addr, sizeof(server_addr));
    if(ret < 0)
    {
        SDK_LOG(LOG_ERROR, "TCP server bind failed.\n");
        vesync_developer_close_sock();
        return -1;
    }

    ret = listen(socket_fd, 2);
    if (ret < 0)
    {
        SDK_LOG(LOG_ERROR, "TCP server listen failed.\n");
        vesync_developer_close_sock();
        return -1;
    }

    ret = vesync_task_new(DEVELOPER_TASK_NAME,
                            vesync_developer_deinit,
                            vesync_developer_server_task,
                            NULL,
                            DEVELOPER_TASK_STACSIZE,
                            DEVELOPER_TASK_PRIO,
                            &developer_taskhd);
    if (ret != VOS_OK)
    {
        SDK_LOG(LOG_ERROR, "Cannot create developer tcp server thread.\n");
        vesync_developer_close_sock();
        developer_taskhd = NULL;
        return -1;
    }

    developer_event_init();

    return 0;
}


/**
 * @brief 开发者模式停止
 * @return    void          [无]
 */
void vesync_developer_stop(void)
{
    if (socket_fd == DEVELOPER_INVALID_SOCK)
    {
        return;
    }

    vesync_developer_event_notify(EVENT_DEVELOPER_STOP);    // client未连接上时，该通知无效，因为会阻塞在accept()处

    developer_event_deinit();
}

/**
 * @brief   开发者模式初始化
 * @return    int           [启动结果，0为成功，其他值为失败]
 */
int vesync_developer_init(void)
{
    dbg_cfg_t dbg_cfg;

    int ret = vesync_developer_flash_read_dbg_cfg(&dbg_cfg);
    // 修改日志打印级别，根据配置重新设置日志级别，默认情况下，debug固件为debug级别，release固件为warn级别
    if (SDK_OK == ret
        && (LOG_DEBUG <= dbg_cfg.log_level && dbg_cfg.log_level <= LOG_DISABLE)
        && (LOG_DEBUG <= dbg_cfg.log_raw_level && dbg_cfg.log_raw_level <= LOG_DISABLE))
    {
        vesync_log_level_set(dbg_cfg.log_level);
        vesync_log_raw_level_set(dbg_cfg.log_raw_level);
    }


#if defined(PR_FW_TYPE) && (PR_FW_TYPE == 0)
    vesync_developer_start();
    SDK_LOG(LOG_DEBUG, "Enable developer mode\n");
#else
    if ((SDK_OK == ret) && dbg_cfg.enable_developer) // release模式下，根据配置决定是否开启
    {
        vesync_developer_start();
        SDK_LOG(LOG_DEBUG, "User enable developer mode\n");
    }
#endif
    return SDK_OK;
}

/**
 * @brief   开发者模式退出
 */
void vesync_developer_deinit(void)
{
    vesync_developer_queue_destroy();
    vesync_developer_sem_deinit();
}

