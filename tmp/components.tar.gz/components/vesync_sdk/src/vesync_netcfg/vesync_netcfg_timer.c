/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_netcfg_timer.c
 * @brief       配网模块的定时器
 * @author      Louis
 * @date        2021-05-21
 */

#include <string.h>
#include <stdio.h>

#include "vhal_wifi.h"

#include "vesync_memory.h"
#include "vesync_common.h"
#include "vesync_loop_timer_internal.h"
#include "vesync_wifi.h"
#include "vesync_log_internal.h"
#include "vesync_wifi_led.h"
#include "vesync_wifi_scan.h"
#include "vesync_net_service_internal.h"
#include "vesync_netcfg_internal.h"
#include "vesync_netcfg_send.h"
#include "vesync_netcfg_recv.h"
#include "vesync_netcfg_timer.h"
#include "vesync_tcp_server.h"


static vloop_timer_header_t st_timer_header = {0};  // 定时器链表指针
static vloop_timer_t *pst_main_timer = NULL;        // 配网超时判断定时器
static vloop_timer_t *pst_step_timer = NULL;        // 配网连接过程超时判断定时器
static vloop_timer_t *pst_restart_timer = NULL;     // APN配网失败，等待10s重回配网定时器
static vloop_timer_t *pst_netlog_timer = NULL;      // 配网过程每5s上报一次状态



/**
 * @brief 上报网络连接超时原因
 */
static void vesync_netcfg_report_timeout(void)
{
    switch (vesync_netcfg_get_status())
    {
    case NETCFG_STATUS_RECV_CFG_DATA:
        switch (vesync_wifi_get_fail_rsn())
        {
        case VHAL_WIFI_WRONG_PWD:
            vesync_netcfg_prot_report_result(ERR_CONFIG_WRONG_PASSWORD, \
                                                ERR_CONFIG_WRONG_PASSWORD_MSG);
            break;
        case VHAL_WIFI_NO_AP_FOUND:
            vesync_netcfg_prot_report_result(ERR_CONFIG_NO_AP_FOUND, \
                                                ERR_CONFIG_NO_AP_FOUND_MSG);
            break;
        case VHAL_WIFI_CONNECT_FAIL:
        default:
            vesync_netcfg_prot_report_result(ERR_CONFIG_CONNECT_WIFI_FAIL, \
                                                ERR_CONFIG_CONNECT_WIFI_FAIL_MSG);
            break;
        }
        break;

    case NETCFG_STATUS_CONNECTED_WIFI:
        vesync_netcfg_prot_report_result(ERR_CONFIG_GET_IP_FAIL, ERR_CONFIG_GET_IP_FAIL_MSG);
        break;

    case NETCFG_STATUS_GOT_IP:
        vesync_netcfg_prot_report_result(ERR_CONFIG_DNS_RESOLVE_FAIL, ERR_CONFIG_DNS_RESOLVE_FAIL_MSG);
        break;

    case NETCFG_STATUS_DNS_RESOLVED:
        vesync_netcfg_prot_report_result(ERR_CONFIG_CONNECT_SERVER_FAIL, ERR_CONFIG_CONNECT_SERVER_FAIL_MSG);
        break;

    case NETCFG_STATUS_CONNECTED_SERVER:
        vesync_netcfg_prot_report_result(ERR_CONFIG_SUBSCRIBE_FAIL, ERR_CONFIG_SUBSCRIBE_FAIL_MSG);
        break;

    case NETCFG_STATUS_SUBSCRIBE_SUCCESS:
        SDK_LOG(LOG_ERROR, "should not be here!\n");
    default:
        break;
    }
}


/**
 * @brief  配网超时定时器回调函数
 * @param[in]  arg              [回调函数参数]
 */
static void netcfg_timeout_cb(void *arg)
{
    SDK_LOG(LOG_ERROR, "netcfg timeout!\r\n");

    vesync_wifi_led_set_behavior(WIFI_LED_CONFIG_TIMEOUT);   // 配网失败，退出配网，灯灭

    vesync_net_client_disconnect_server();
    vhal_wifi_stop();

    vesync_netcfg_stop();
}


/**
 * @brief  配网步骤超时定时器回调函数
 * @param[in]  arg              [回调函数参数]
 */
static void step_timeout_cb(void *arg)
{
    SDK_LOG(LOG_ERROR, "netcfg step timeout!\r\n");
    vesync_netcfg_report_timeout();

    netcfg_del_netlog_timer();
    vesync_netcfg_set_status(NETCFG_STATUS_IDLE);

    // APN配网失败，关闭热点和tcp server，等待10秒后再次进入等待配网，10秒等待过程灯效依然保持快闪
    if (AP_CONFIG == vesync_netcfg_get_mode())
    {
        vesync_tcp_server_stop();
        vesync_net_client_disconnect_server();
        vhal_wifi_stop();

        // MQTT完全断开后，再启动定时器
        netcfg_add_restart_timer();
    }
    else
    {
        vesync_wifi_led_set_behavior(WIFI_LED_NOT_CONFIG);   // 配网失败，慢闪
        vesync_net_client_disconnect_server();
        vhal_wifi_stop();
    }
}


/**
 * @brief  重新启动APN配网超时定时器回调函数
 * @param[in]  arg              [回调函数参数]
 */
static void restart_timeout_cb(void *arg)
{
    SDK_LOG(LOG_DEBUG, "Restart timeout!\r\n");
    vesync_wifi_led_set_behavior(WIFI_LED_NOT_CONFIG);   // 配网失败，慢闪
    vesync_wifi_scan_start();
}


/**
 * @brief  配网状态监控定时器回调函数
 * @param[in]  arg              [回调函数参数]
 */
static void netlog_timeout_cb(void* arg)
{
    vesync_netcfg_report_status(NULL);
}

static vloop_timer_t *netcfg_timer_create(bool reload, uint64_t period, vloop_timer_handler_t cb)
{
    vloop_timer_t *p_timer = vesync_calloc(1, sizeof(vloop_timer_t));
    VCOM_NULL_RET_CHK(p_timer, return NULL);

    p_timer->reload = reload;
    p_timer->period = period;
    p_timer->cb = cb;

    return p_timer;
}

/**
 * @brief 定时器初始化
 * @return    int       [初始化成功与否]
 */
int netcfg_timer_init(void)
{
    //初始化定时器
    memset(&st_timer_header, 0, sizeof(vloop_timer_header_t));

    // 申请定时节点内存
    pst_main_timer = netcfg_timer_create(false, NETCFG_TIMER_MAIN_PERIOD, netcfg_timeout_cb);
    VCOM_NULL_RET_CHK(pst_main_timer, goto exit);

    pst_step_timer = netcfg_timer_create(false, NETCFG_TIMER_STEP_PERIOD, step_timeout_cb);
    VCOM_NULL_RET_CHK(pst_step_timer, goto exit);

    pst_restart_timer = netcfg_timer_create(false, NETCFG_TIMER_RESTART_PERIOD, restart_timeout_cb);
    VCOM_NULL_RET_CHK(pst_restart_timer, goto exit);

    pst_netlog_timer = netcfg_timer_create(true, NETCFG_TIMER_NETLOG_PERIOD, netlog_timeout_cb);
    VCOM_NULL_RET_CHK(pst_netlog_timer, goto exit);

    return SDK_OK;

exit:   // 异常退出
    VCOM_SAFE_FREE(pst_main_timer);
    VCOM_SAFE_FREE(pst_step_timer);
    VCOM_SAFE_FREE(pst_restart_timer);
    VCOM_SAFE_FREE(pst_netlog_timer);
    return SDK_FAIL;
}

/**
 * @brief 定时器销毁
 */
void netcfg_timer_deinit(void)
{
    // 删除所有定时器
    vloop_timer_del(&st_timer_header, pst_main_timer);
    vloop_timer_del(&st_timer_header, pst_step_timer);
    vloop_timer_del(&st_timer_header, pst_restart_timer);
    vloop_timer_del(&st_timer_header, pst_netlog_timer);

    // 释放各个定时器内存
    VCOM_SAFE_FREE(pst_main_timer);
    VCOM_SAFE_FREE(pst_step_timer);
    VCOM_SAFE_FREE(pst_restart_timer);
    VCOM_SAFE_FREE(pst_netlog_timer);

    return;
}

/**
 * @brief 添加配网超时定时器
 */
void netcfg_add_main_timer(void)
{
    vloop_timer_add(&st_timer_header, pst_main_timer);
}

/**
 * @brief 删除配网超时定时器
 */
void netcfg_del_main_timer(void)
{
    vloop_timer_del(&st_timer_header, pst_main_timer);
}

/**
 * @brief 添加配网步骤超时定时器
 */
void netcfg_add_step_timer(void)
{
    vloop_timer_add(&st_timer_header, pst_step_timer);
}

/**
 * @brief 删除配网步骤超时定时器
 */
void netcfg_del_step_timer(void)
{
    vloop_timer_del(&st_timer_header, pst_step_timer);
}

/**
 * @brief 添加配网重启定时器
 */
void netcfg_add_restart_timer(void)
{
    vloop_timer_add(&st_timer_header, pst_restart_timer);
}

/**
 * @brief 删除配网重启定时器
 */
void netcfg_del_restart_timer(void)
{
    vloop_timer_del(&st_timer_header, pst_restart_timer);
}


/**
 * @brief 添加配网log上报定时器
 */
void netcfg_add_netlog_timer(void)
{
    vloop_timer_add(&st_timer_header, pst_netlog_timer);
}


/**
 * @brief 删除配网log上报定时器
 */
void netcfg_del_netlog_timer(void)
{
    vloop_timer_del(&st_timer_header, pst_netlog_timer);
}


/**
 * @brief 处理已经超时的定时器
 * @return    uint64_t      [下一个即将超时定时器的时间ms]
 */
uint64_t netcfg_process_expired_timer(void)
{
    return vloop_timer_process_expired(&st_timer_header);
}

