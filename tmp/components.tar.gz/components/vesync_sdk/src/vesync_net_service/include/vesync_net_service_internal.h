/*
 * Copyright © Vesync Technologies Co.Ltd. 2019-2021. All rights reserved.
 * @file    vesync_net_service_internal.h
 * @brief   网络服务提供给内部的接口
 * @author  CharlesMei
 * @date    2021-05-27
 */


#ifndef __VESYNC_NET_SERVICE_INTERNAL_H__
#define __VESYNC_NET_SERVICE_INTERNAL_H__


#include <stdint.h>
#include <stdbool.h>

#include "vesync_common.h"

#include "vhal_wifi.h"
#include "vesync_wifi.h"
#include "vesync_device_internal.h"
#include "vesync_net_service.h"


#ifdef __cplusplus
extern "C"
{
#endif /* __cplusplus */


#ifndef DEVICE_PID_LEN
#define DEVICE_PID_LEN (16)
#endif /* DEVICE_PID_LEN */

#ifndef WIFI_SSID_MAX_LEN
#define WIFI_SSID_MAX_LEN (32)
#endif /* WIFI_SSID_MAX_LEN */

#ifndef WIFI_PWD_MAX_LEN
#define WIFI_PWD_MAX_LEN (64)
#endif /* WIFI_PWD_MAX_LEN */

#ifndef IP_ADDR_STR_MAX_LEN
#define IP_ADDR_STR_MAX_LEN (16)
#endif /* IP_ADDR_STR_MAX_LEN */

#ifndef ACCOUNT_ID_STR_LEN
#define ACCOUNT_ID_STR_LEN (32)
#endif /* ACCOUNT_ID_STR_LEN */

#define CONFIG_KEY_LEN (16)
#define SERVER_DOMAIN_NAME_LEN (64)

/**
 * @brief 网络应用层协议
 */
typedef enum
{
    NETWORK_MQTT            = 0,
    NETWORK_HTTPS           = 1,
} NETWORK_APP_PROTOCOL_E;

/**
 * @brief TLS证书选项
 */
typedef enum
{
    TLS_DSIABLE             = 0,    // 关闭tls
    TLS_CA_NONE             = 1,    // 不校验CA证书
    TLS_CA_SERVER           = 2,    // 校验bypass服务器CA证书
    TLS_CA_PRODUTION        = 3,    // 校验产测服务器CA证书
    TLS_CA_ONE_WAY_AUTH     = 4,    // 单向验证
} NETWORK_TLS_CA_E;

/**
 * @brief 设备在线/离线状态
 */
typedef enum
{
    RECONNECT_NONE_REASON   = 0,
    POWER_ON_REASON         = 1,    /* 设备上电 */
    CONFIG_NET_REASON       = 2,    /* 配网导致的重新上线 */
    NETWORK_REASON          = 3,    /* 网络断开(应用层协议)导致的重新上线 */
    WIFI_REASON             = 4,    /* Wi-Fi断开导致的重新上线 */
    UPGRADE_REASON          = 5,    /* OTA升级导致的重新上线 */
    PRODUCTION_REASON       = 6,    /* 产测升级导致重新上线*/
} RECONNECT_REASON_E;

/*
 * @brief   设备链路断开->重连的时间
 */
typedef enum
{
    WIFI_DISCONN_TS     = 0,
    WIFI_RECONN_TS,
    NETWORK_DISCONN_TS,
    NETWORK_RECONN_TS,
} DEV_RECORD_TS_E;

/**
 * @brief 记录设备离线原因和时间戳
 */
typedef struct
{
    uint32_t wifi_disconn_ts;       // 时间戳
    uint32_t wifi_reconn_ts;
    uint32_t network_disconn_ts;
    uint32_t network_reconn_ts;
    uint32_t retry_cnt[CONNECT_RETRY_TYPE_TOTAL];   // 记录几种错误原因的重连次数
    uint8_t  flag;                  // 第1次离线标识
    RECONNECT_REASON_E reason;      // 设备上线原因
} reconn_data_t;

/**
 * @brief 设备配网参数配置
 */
typedef struct{
    uint8_t configKey[CONFIG_KEY_LEN + 4];       // 配网下发，每次都不同
    uint8_t serverDN[SERVER_DOMAIN_NAME_LEN];    // 服务器域名
    uint8_t serverIP[IP_ADDR_STR_MAX_LEN];       // 服务器IP
    uint32_t serverPort;                         // 服务器端口号
    uint32_t auth_mode;                          // Wi-Fi加密类型，VHAL_WIFI_AUTH_MODE_E
    uint8_t wifiSSID[WIFI_SSID_MAX_LEN];         // Wi-Fi ssid
    uint8_t wifiPassword[WIFI_PWD_MAX_LEN];      // Wi-Fi 密码
    uint8_t account_id[ACCOUNT_ID_STR_LEN + 4];  //account_id;
    uint8_t data_version;
} net_info_t;

/**
 * @brief 网络接收数据处理回调函数
 * @param[in]  p_msg            [数据指针]
 */
typedef void (*vesync_net_msg_recv_cb_t)(void *p_msg);


/**
 * @brief  bypass回调函数注册
 * @param[in]  cb               [网络接收数据处理回调函数指针]
 */
void vesync_net_reg_bypass_recv_cb(vesync_net_msg_recv_cb_t cb);

/**
 * @brief  非bypass回调函数注册
 * @param[in]  cb               [网络接收数据处理回调函数指针]
 */
void vesync_net_reg_non_bypass_recv_cb(vesync_net_msg_recv_cb_t cb);

/**
 * @brief       网络客户端对有关device的设置进行刷新
 * @note        在device设置更新时（例如进入产测前）调用
 */
void vesync_net_client_device_refresh(void);


/**
 * @brief       网络客户端初始化
 * @return      int                  [成功/失败]
 */
int vesync_net_client_init(void);


/**
 * @brief       获取网络服务应用层协议
 * @return      NETWORK_APP_PROTOCOL_E [网络服务应用层协议]
 */
NETWORK_APP_PROTOCOL_E vesync_net_client_get_protocol(void);

/**
 * @brief  获取TLS证书选项
 * @return  NETWORK_TLS_CA_E       [TLS证书选项]
 */
NETWORK_TLS_CA_E vesync_net_client_get_tls_option(void);

/**
 * @brief  获取云端服务器默认端口
 * @return  int       [端口号]
 */
int vesync_net_client_get_default_port(void);

/**
 * @brief       连接服务器
 * @param[in]  p_srv                [服务器地址]
 * @param[in]  p_ip                 [mqtt服务器地址ip]
 * @param[in]  p_pwd                [连接的用户密码，BLE/APN配网时为configKey，断开重连时为"0"，FFS配网时为token]
 * @param[in]  p_port               [mqtt连接端口， 指针置空则连接默认端口]
 * @param[in]  tls                  [tls选项]
 * @return  int                     [成功：VERR_OK，失败：VERR_FAIL]
 */
int vesync_net_client_connect(char *p_srv, char *p_ip, char *p_pwd, uint32_t *p_port, NETWORK_TLS_CA_E tls);


/**
 * @brief       销毁网络服务客户端，释放内存，重置状态
 */
void vesync_net_client_destroy(void);


/**
 * @brief       vesync平台网络服务客户端断开与服务器的连接
 * @return      int                  [成功/失败]
 */
int vesync_net_client_disconnect_server(void);

/**
 * @brief       网络服务事件管理使能
 * @return      int                 [成功/失败]
 * @note        网络服务对网络事件自动处理，网络服务初始化后自动完成，不必再调用
 */
int vesync_net_event_mgmt_enable(void);

/**
 * @brief       网络服务事件管理禁用
 * @note        配网或产测时，自定义网络事件处理，需要关闭网络服务对事件的自动处理
 */
void vesync_net_event_mgmt_disable(void);

/**
 * @brief       设置重连服务器原因，连上服务器会上报
 * @param[in]   reason               [设备连接服务器的原因]
 */
void vesync_net_mgmt_set_reconnect_reason(RECONNECT_REASON_E reason);

/**
 * @brief       查询重连服务器原因
 * @return      RECONNECT_REASON_E   [设备连接服务器的原因]
 */
RECONNECT_REASON_E vesync_net_mgmt_get_reconnect_reason(void);

/**
 * @brief       返回重连原因的字符串
 * @param[in]   reason               [网络重连原因，详见enum声明]
 * @return      char*                [网络重连原因字符串形式]
 */
const char* vesync_net_mgmt_get_reconnect_reason_str(RECONNECT_REASON_E reason);

/**
 * @brief       记录Wi-Fi/MQTT的重连次数
 * @param[in]   fail_type            [网络连接失败错误类型]
 */
void vesync_net_mgmt_set_reconnect_count(DEV_CONNECT_FAIL_TYPE_E fail_type);

/**
 * @brief       设置链路断开->重连成功的时间
 * @param[in]   type                 [掉线类型]
 * @param       bool                 [掉线时间超过10min，返回true；否则返回false]
 */
bool vesync_net_mgmt_set_reconnect_time(DEV_RECORD_TS_E type);

/**
 * @brief       获取链路断开->重连成功的时间
 * @param[in]   p_data               [保存离线数据]
 */
void vesync_net_mgmt_get_reconnect_data(reconn_data_t *p_data);

/**
 * @brief       清除离线记录信息
 */
void vesync_net_mgmt_clear_reconnect_data(void);

/**
 * @brief       从flash中读取网络配置到s_net_cfg中。
 * @return      int                  [成功/失败]
 */
int vesync_net_mgmt_load_net_cfg(void);

/**
 * @brief       清除内存中的网络配置
 * @return      int                 [成功/失败]
 */
int vesync_net_mgmt_clear_net_cfg(void);

/**
 * @brief       获取一份网络配置的拷贝。
 * @return      net_info_t           [配网数据]
 */
net_info_t* vesync_net_mgmt_get_net_cfg(void);

/**
 * @brief       获取云端域名。
 * @return      uint8_t*             [域名地址指针]
 */
uint8_t* vesync_net_mgmt_get_server_domain(void);

/**
 * @brief       获取云端IP。
 * @return      uint8_t*            [IP地址指针]
 */
uint8_t* vesync_net_mgmt_get_server_ip(void);

/**
 * @brief       获取云端端口。
 * @return      uint32_t*           [端口数据指针]
 */
uint32_t* vesync_net_mgmt_get_server_port(void);

#if CONFIG_VESYNC_SDK_NETCFG_ENABLE
/**
 * @brief  获取当前状态是否处于配网中
 * @param[in]  void         [无]
 * @return     bool         [true-配网中，false-非配网状态]
 */
bool vesync_net_mgmt_netcfg_running(void);
#endif

/**
 * @brief       flash写配网信息
 * @param[in]   p_info               [配网参数指针]
 * @return      int                  [成功/失败]
 */
int vesync_net_flash_write_net_info(net_info_t *p_info);

/**
 * @brief       flash读配网信息
 * @param[in]   p_info               [配网参数指针]
 * @return      int                  [成功/失败]
 */
int vesync_net_flash_read_net_info(net_info_t *p_info);

/**
 * @brief       flash清除配网信息
 * @return      int                  [成功/失败]
 */
int vesync_net_flash_clear_net_info(void);

/**
 * @brief       网络重连原因，保存到flash用户分区
 * @param[in]   reason               [网络重连原因]
 * @return      int                  [成功/失败]
 */
int vesync_net_flash_write_reconnect_reason(uint32_t reason);

/**
 * @brief       flash读取网络重连原因
 * @para        p_reason             [网络重连原因]
 * @return      int                  [成功/失败]
 */
int vesync_net_flash_read_reconnect_reason(uint32_t *p_reason);


#ifdef __cplusplus
}
#endif /* __cplusplus */


#endif /* __VESYNC_NET_SERVICE_INTERNAL_H__ */
