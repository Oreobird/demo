/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        demo.c
 * @brief       vesync_light模块例程
 * @author      Herve
 * @date        2021-11-15
 */
#include <stddef.h>

#include "vesync_init.h"
#include "vesync_log.h"
#include "vesync_cfg.h"

#include "vesync_common.h"
#include "vesync_light.h"

#include "vhal_led.h"

enum
{
    LIGHT_CH_IDX_0 = 0,
    LIGHT_CH_IDX_1 = 1,
    LIGHT_CH_IDX_2 = 2,
    LIGHT_CH_IDX_3 = 3,
    LIGHT_CH_IDX_4 = 4,
    LIGHT_CH_IDX_MAX,
};

static void demo_pre_cb(void)
{
    APP_LOG(LOG_DEBUG, "Demo pre init callback\n");
}

static void light_pwm_ctrl(void *opt, uint16_t ch_num, uint32_t* duty)
{
    UNUSED(opt);

    for (uint16_t ch = 0; ch < ch_num; ch++)
    {
        vhal_led_set_duty_bits(ch, duty[ch], 1024);
    }
}

static void demo_app_run(void)
{
    APP_LOG(LOG_INFO, "Vesync APP Demo start\n");

    vhal_led_timer_cfg_t led_timer_cfg =
        {
            .duty_resolution = (LED_DUTY_RST_E)LED_DUTY_RST_10_BIT,
            .freq_hz = 800,
        };
    int ret = vhal_led_timer_cfg(&led_timer_cfg);
    if (VHAL_OK != ret)
    {
        APP_LOG(LOG_WARN, "led timer cfg fail[%d]\n", ret);
    }

    vhal_led_gpio_cfg_t gpio_cfg[] =
        {
            {
                .gpio_num = 3,
                .channel = LED_CH0,
                .duty = 0,
            },
            {
                .gpio_num = 2,
                .channel = LED_CH1,
                .duty = 0,
            },
        };
    ret = vhal_led_gpio_cfg(2, gpio_cfg);
    if (VHAL_OK != ret)
    {
        APP_LOG(LOG_WARN, "led gpio cfg fail[%d]\n", ret);
    }

    vesync_light_t light;
    vesync_light_init();

    light = vesync_light_create(5, 20, 1023, light_pwm_ctrl, NULL);
    if (NULL == light)
    {
        APP_LOG(LOG_WARN, "create light fail\n");
    }

    vesync_light_breath_cfg(light, LIGHT_CH_IDX_0, 0.9, 1000, 0, 0);
    vesync_light_blink_cfg(light, LIGHT_CH_IDX_1, 0.5, 500, 0, 0);

    vesync_light_start(light, LIGHT_CH_IDX_0);
    vesync_light_start(light, LIGHT_CH_IDX_1);
}

void app_main(void)
{
    vesync_sdk_reg_pre_run_cb(demo_pre_cb);
    vesync_sdk_reg_post_run_cb(demo_app_run);

    vesync_sdk_run();
}

