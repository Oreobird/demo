/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_cfg.h
 * @brief       Vesync SDK配置接口
 * @date        2022-03-03
 * @note        File auto generated, DO NOT edit.
 */

#ifndef __VESYNC_CFG_H__
#define __VESYNC_CFG_H__

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif


/**
 * @brief 设置本产品固件版本号,格式为“1.0.00”
 * @param[in]  data          [设置的配置]
 * @return  int              [成功：SDK_OK，失败：SDK_FAIL]
 * @note  字符长度范围: [6, 6]
 */
int vesync_cfg_set_fw_version(char * data);

/**
 * @brief 获取本产品固件版本号,格式为“1.0.00”
 * @return  char *              [获取的配置]
 */
char * vesync_cfg_get_fw_version(void);

/**
 * @brief 设置本产品硬件版本号
 * @param[in]  data          [设置的配置]
 * @return  int              [成功：SDK_OK，失败：SDK_FAIL]
 * @note  字符长度范围: [1, 8]
 */
int vesync_cfg_set_hw_version(char * data);

/**
 * @brief 获取本产品硬件版本号
 * @return  char *              [获取的配置]
 */
char * vesync_cfg_get_hw_version(void);

/**
 * @brief 设置本产品品牌标识
 * @param[in]  data          [设置的配置]
 * @return  int              [成功：SDK_OK，失败：SDK_FAIL]
 * @note  字符长度范围: [1, 16]
 */
int vesync_cfg_set_brand(char * data);

/**
 * @brief 获取本产品品牌标识
 * @return  char *              [获取的配置]
 */
char * vesync_cfg_get_brand(void);

/**
 * @brief 设置本产品类目标识
 * @param[in]  data          [设置的配置]
 * @return  int              [成功：SDK_OK，失败：SDK_FAIL]
 * @note  字符长度范围: [1, 16]
 */
int vesync_cfg_set_type(char * data);

/**
 * @brief 获取本产品类目标识
 * @return  char *              [获取的配置]
 */
char * vesync_cfg_get_type(void);

/**
 * @brief 设置本产品型号标识
 * @param[in]  data          [设置的配置]
 * @return  int              [成功：SDK_OK，失败：SDK_FAIL]
 * @note  字符长度范围: [1, 16]
 */
int vesync_cfg_set_model(char * data);

/**
 * @brief 获取本产品型号标识
 * @return  char *              [获取的配置]
 */
char * vesync_cfg_get_model(void);

/**
 * @brief 设置本产品型号别名
 * @param[in]  data          [设置的配置]
 * @return  int              [成功：SDK_OK，失败：SDK_FAIL]
 * @note  字符长度范围: [1, 16]
 */
int vesync_cfg_set_alias_model(char * data);

/**
 * @brief 获取本产品型号别名
 * @return  char *              [获取的配置]
 */
char * vesync_cfg_get_alias_model(void);

/**
 * @brief 设置本产品国家代码
 * @param[in]  data          [设置的配置]
 * @return  int              [成功：SDK_OK，失败：SDK_FAIL]
 * @note  字符长度范围: [1, 3]
 */
int vesync_cfg_set_country_code(char * data);

/**
 * @brief 获取本产品国家代码
 * @return  char *              [获取的配置]
 */
char * vesync_cfg_get_country_code(void);

/**
 * @brief 设置本产品国家代码（OTA）
 * @param[in]  data          [设置的配置]
 * @return  int              [成功：SDK_OK，失败：SDK_FAIL]
 * @note  字符长度范围: [1, 32]
 */
int vesync_cfg_set_support_ctry_code(char * data);

/**
 * @brief 获取本产品国家代码（OTA）
 * @return  char *              [获取的配置]
 */
char * vesync_cfg_get_support_ctry_code(void);

/**
 * @brief 设置本产品配置模型
 * @param[in]  data          [设置的配置]
 * @return  int              [成功：SDK_OK，失败：SDK_FAIL]
 * @note  字符长度范围: [1, 32]
 */
int vesync_cfg_set_config_model(char * data);

/**
 * @brief 获取本产品配置模型
 * @return  char *              [获取的配置]
 */
char * vesync_cfg_get_config_model(void);

/**
 * @brief 设置MQTT连接认证密钥
 * @param[in]  data          [设置的配置]
 * @return  int              [成功：SDK_OK，失败：SDK_FAIL]
 * @note  字符长度范围: [1, 33]
 */
int vesync_cfg_set_authkey(char * data);

/**
 * @brief 获取MQTT连接认证密钥
 * @return  char *              [获取的配置]
 */
char * vesync_cfg_get_authkey(void);

/**
 * @brief 设置Vesync SDK 初始化任务堆栈大小
 * @param[in]  data          [设置的配置]
 * @return  int              [成功：SDK_OK，失败：SDK_FAIL]
 * @note  数值范围:[1024*2, 1024*8]
 */
int vesync_cfg_set_init_task_stacksize(int data);

/**
 * @brief 获取Vesync SDK 初始化任务堆栈大小
 * @return  int              [获取的配置]
 */
int vesync_cfg_get_init_task_stacksize(void);

/**
 * @brief 设置配网模式："cfg_by_ble" - 蓝牙配网； "cfg_by_ap" - AP配网
 * @param[in]  data          [设置的配置]
 * @return  int              [成功：SDK_OK，失败：SDK_FAIL]
 * @note  字符长度范围: [9, 10]
 */
int vesync_cfg_set_netcfg_mode(char * data);

/**
 * @brief 获取配网模式："cfg_by_ble" - 蓝牙配网； "cfg_by_ap" - AP配网
 * @return  char *              [获取的配置]
 */
char * vesync_cfg_get_netcfg_mode(void);

/**
 * @brief 设置WiFi配网AP SSID名称前缀字符串设置
 * @param[in]  data          [设置的配置]
 * @return  int              [成功：SDK_OK，失败：SDK_FAIL]
 * @note  字符长度范围: [1, 27]
 */
int vesync_cfg_set_ssid_prefix(char * data);

/**
 * @brief 获取WiFi配网AP SSID名称前缀字符串设置
 * @return  char *              [获取的配置]
 */
char * vesync_cfg_get_ssid_prefix(void);

/**
 * @brief 设置蓝牙设备名称
 * @param[in]  data          [设置的配置]
 * @return  int              [成功：SDK_OK，失败：SDK_FAIL]
 * @note  字符长度范围: [1, 29]
 */
int vesync_cfg_set_ble_name(char * data);

/**
 * @brief 获取蓝牙设备名称
 * @return  char *              [获取的配置]
 */
char * vesync_cfg_get_ble_name(void);

/**
 * @brief 设置蓝牙广播产品类型标识
 * @param[in]  data          [设置的配置]
 * @return  int              [成功：SDK_OK，失败：SDK_FAIL]
 * @note  数值范围:[0x0, 0xFF]
 */
int vesync_cfg_set_ble_type(uint8_t data);

/**
 * @brief 获取蓝牙广播产品类型标识
 * @return  uint8_t              [获取的配置]
 */
uint8_t vesync_cfg_get_ble_type(void);

/**
 * @brief 设置蓝牙广播产品型号标识
 * @param[in]  data          [设置的配置]
 * @return  int              [成功：SDK_OK，失败：SDK_FAIL]
 * @note  数值范围:[0x0, 0xFF]
 */
int vesync_cfg_set_ble_model(uint8_t data);

/**
 * @brief 获取蓝牙广播产品型号标识
 * @return  uint8_t              [获取的配置]
 */
uint8_t vesync_cfg_get_ble_model(void);

/**
 * @brief 设置蓝牙广播命令码
 * @param[in]  data          [设置的配置]
 * @return  int              [成功：SDK_OK，失败：SDK_FAIL]
 * @note  数值范围:[0x0, 0xFF]
 */
int vesync_cfg_set_ble_cmd(uint8_t data);

/**
 * @brief 获取蓝牙广播命令码
 * @return  uint8_t              [获取的配置]
 */
uint8_t vesync_cfg_get_ble_cmd(void);

/**
 * @brief 设置外挂MCU总数
 * @param[in]  data          [设置的配置]
 * @return  int              [成功：SDK_OK，失败：SDK_FAIL]
 * @note  数值范围:[0, 1]
 */
int vesync_cfg_set_total_mcu_num(int data);

/**
 * @brief 获取外挂MCU总数
 * @return  int              [获取的配置]
 */
int vesync_cfg_get_total_mcu_num(void);

/**
 * @brief 设置WiFi OTA使能
 * @param[in]  data          [设置的配置]
 * @return  int              [成功：SDK_OK，失败：SDK_FAIL]
 * @note  数值范围:[0, 1]
 */
int vesync_cfg_set_ota_type_wifi(int data);

/**
 * @brief 获取WiFi OTA使能
 * @return  int              [获取的配置]
 */
int vesync_cfg_get_ota_type_wifi(void);

/**
 * @brief 设置蓝牙 OTA使能
 * @param[in]  data          [设置的配置]
 * @return  int              [成功：SDK_OK，失败：SDK_FAIL]
 * @note  数值范围:[0, 1]
 */
int vesync_cfg_set_ota_type_ble(int data);

/**
 * @brief 获取蓝牙 OTA使能
 * @return  int              [获取的配置]
 */
int vesync_cfg_get_ota_type_ble(void);

/**
 * @brief 设置MCU OTA使能, 0表示不使能MCU的OTA，>0表示使能第n路MCU的OTA
 * @param[in]  data          [设置的配置]
 * @return  int              [成功：SDK_OK，失败：SDK_FAIL]
 * @note  数值范围:[0, 1]
 */
int vesync_cfg_set_ota_type_mcu(int data);

/**
 * @brief 获取MCU OTA使能, 0表示不使能MCU的OTA，>0表示使能第n路MCU的OTA
 * @return  int              [获取的配置]
 */
int vesync_cfg_get_ota_type_mcu(void);

/**
 * @brief 设置OTA超时时间（秒）
 * @param[in]  data          [设置的配置]
 * @return  int              [成功：SDK_OK，失败：SDK_FAIL]
 * @note  数值范围:[1, 285000]
 */
int vesync_cfg_set_ota_timeout_time(int data);

/**
 * @brief 获取OTA超时时间（秒）
 * @return  int              [获取的配置]
 */
int vesync_cfg_get_ota_timeout_time(void);

/**
 * @brief 设置WiFi节能模式设置
 * @param[in]  data          [设置的配置]
 * @return  int              [成功：SDK_OK，失败：SDK_FAIL]
 * @note  数值范围:[0, 1]
 */
int vesync_cfg_set_wifi_ps_type(int data);

/**
 * @brief 获取WiFi节能模式设置
 * @return  int              [获取的配置]
 */
int vesync_cfg_get_wifi_ps_type(void);

/**
 * @brief 设置串口UART0的索引号
 * @param[in]  data          [设置的配置]
 * @return  int              [成功：SDK_OK，失败：SDK_FAIL]
 * @note  数值范围:[0, 1]
 */
int vesync_cfg_set_uart0_idx(int data);

/**
 * @brief 获取串口UART0的索引号
 * @return  int              [获取的配置]
 */
int vesync_cfg_get_uart0_idx(void);

/**
 * @brief 设置串口TX脚设置数组
 * @param[in]  data          [设置的配置]
 * @return  int              [成功：SDK_OK，失败：SDK_FAIL]
 * @note  处理的最大个数为1，超出部分将不处理
 */
int vesync_cfg_set_uart_tx_pin_arr(int * data);

/**
 * @brief 获取串口TX脚设置数组
 * @return  int *              [获取的配置]
 */
int * vesync_cfg_get_uart_tx_pin_arr(void);

/**
 * @brief 设置串口RX脚设置数组
 * @param[in]  data          [设置的配置]
 * @return  int              [成功：SDK_OK，失败：SDK_FAIL]
 * @note  处理的最大个数为1，超出部分将不处理
 */
int vesync_cfg_set_uart_rx_pin_arr(int * data);

/**
 * @brief 获取串口RX脚设置数组
 * @return  int *              [获取的配置]
 */
int * vesync_cfg_get_uart_rx_pin_arr(void);

/**
 * @brief 设置串口波特率设置数组
 * @param[in]  data          [设置的配置]
 * @return  int              [成功：SDK_OK，失败：SDK_FAIL]
 * @note  处理的最大个数为1，超出部分将不处理
 */
int vesync_cfg_set_uart_baud_rate_arr(int * data);

/**
 * @brief 获取串口波特率设置数组
 * @return  int *              [获取的配置]
 */
int * vesync_cfg_get_uart_baud_rate_arr(void);

/**
 * @brief 设置串口重发次数设置
 * @param[in]  data          [设置的配置]
 * @return  int              [成功：SDK_OK，失败：SDK_FAIL]
 * @note  数值范围:[0, 10]
 */
int vesync_cfg_set_uart_resend_cnt(int data);

/**
 * @brief 获取串口重发次数设置
 * @return  int              [获取的配置]
 */
int vesync_cfg_get_uart_resend_cnt(void);

/**
 * @brief 设置串口发送超时（毫秒）
 * @param[in]  data          [设置的配置]
 * @return  int              [成功：SDK_OK，失败：SDK_FAIL]
 * @note  数值范围:[1, 10000]
 */
int vesync_cfg_set_uart_send_timeout_ms(int data);

/**
 * @brief 获取串口发送超时（毫秒）
 * @return  int              [获取的配置]
 */
int vesync_cfg_get_uart_send_timeout_ms(void);

/**
 * @brief 设置串口收发单个包的最大长度
 * @param[in]  data          [设置的配置]
 * @return  int              [成功：SDK_OK，失败：SDK_FAIL]
 * @note  数值范围:[1, 1000]
 */
int vesync_cfg_set_uart_payload_max_len(int data);

/**
 * @brief 获取串口收发单个包的最大长度
 * @return  int              [获取的配置]
 */
int vesync_cfg_get_uart_payload_max_len(void);


#ifdef __cplusplus
}
#endif

#endif


