/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        outlet_board.h
 * @brief       outlet 板级硬件配置
 * @author      Herve
 * @date        2021-09-03
 */
#ifndef __OUTLET_BOARD_H__
#define __OUTLET_BOARD_H__

#ifdef __cplusplus
extern "C" {
#endif

#define OUTLET_BUTTON_GPIO_NUM (4)           // 触摸按键信号接入GPIO
#define OUTLET_RELAY_GPIO_NUM (5)            // 继电器控制GPIO
#define OUTLET_WIFI_GPIO_NUM (6)             // WIFI指示灯GPIO
#define OUTLET_INDICATOR_GPIO_NUM (7)        // 继电器指示灯GPIO
#define OUTLET_BUTTON_TASK_STACKSIZE (1024)  // 按键任务栈大小
#define OUTLET_APP_TASK_STACKSIZE (1024 * 4) // APP任务栈大小
#define OUTLET_EVENT_QUEUE_MAX_NUM (16)      // APP事件队列最大长度
#define OUTLET_APP_DATA_VERSION (1)          // APP数据的配置版本
#define OUTLET_INCHING_CFG_VERSION (1)       // Inching配置版本
#define OUTLET_SCHE_MIN_ID (100)             // Schedule ID生成的最小限制
#define OUTLET_SCHE_MAX_NUM (26)             // Schedule每个实例的最大数量限制
#define OUTLET_SCHE_GET_MAX_NUM (6)          // Schedule每个实例读取Schedule时，最大一次读取数量
#define OUTLET_SCHE_MAX_APP_CFG_SIZE (8)     // APP配置传入Schedule实例的时候，对APP大小校验的最大限制

#ifdef __cplusplus
}
#endif

#endif /* __OUTLET_BOARD_H__ */