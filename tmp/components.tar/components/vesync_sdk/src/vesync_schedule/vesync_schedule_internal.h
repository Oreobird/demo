/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_schedule_internal.h
 * @brief       schedule模块内部定义
 * @date        2021-05-27
 */

#ifndef __VESYNC_SCHEDULE_INTERNAL_H__
#define __VESYNC_SCHEDULE_INTERNAL_H__

#include <stdint.h>
#include <stdbool.h>
#include "vesync_timer.h"
#include "vesync_schedule.h"
#include "vesync_list.h"

#ifdef __cplusplus
extern "C" {
#endif

#define SCHEDULE_INVALID_MINUTE         (0xff)
#define SCHEDULE_CYCLE_TIMER_INTERVAL   (10000) //定时器轮询间隔

#define MIN_SCHD_ID      100         // schedule最小ID
#define MAX_SCHD_NUM     26          // schedule最大条目数

#define SCH_CYCLE_OK     SDK_OK      //Schedule cycle api 操作成功
#define SCH_CYCLE_FAIL   SDK_FAIL    //Schedule cycle api 操作失败


/**
 * @brief  away cycle 链表结构体
*/
typedef struct
{
    schedule_data_t data;
    struct list_head list;
} schedule_t;

/**
 * @brief  away cycle管理对象结构体
*/
typedef struct
{
    bool schedule_running;
    vesync_timer_t schedule_timer;
    uint8_t sche_num;
    struct list_head cycle_list;
} schedule_mgt_t;



#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_SCHEDULE_INTERNAL_H__ */

