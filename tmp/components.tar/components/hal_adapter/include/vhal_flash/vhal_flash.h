/**
 *  Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vhal_flash.h
 * @brief       flash读写驱动接口封装
 * @date        2021-04-23
 */

#ifndef __VHAL_FLASH_H__
#define __VHAL_FLASH_H__

#include <stdint.h>
#include <stdlib.h>
#include <string.h>


#ifdef __cplusplus
extern "C"
{
#endif

/**
 * @brief 用户可操作的flash分区ID
 */
typedef enum
{
    PARTITION_MIN = 0,      // 最小分区数
    PARTITION_DEFAULT,      // 系统默认分区
    PARTITION_FAC,          // 产测数据备份分区，出厂后不再更改
    PARTITION_CFG,          // 用户配置分区
    PARTITION_DATA,         // 产品数据存储分区
    PARTITION_LOG,          // log存储分区
    PARTITION_MAX,          // 最大分区数
} PARTITION_ID_E;


/**
 * @brief  flash初始化
 * @param[in]  part_id              [分区ID]
 * @return     int32_t              [错误码]
 */
int32_t vhal_flash_init(PARTITION_ID_E part_id);

/**
 * @brief  从flash读取数据
 * @param[in]  part_id              [分区ID]
 * @param[in]  key_name             [键值名称]
 * @param[in]  p_data               [读取数据缓存区]
 * @param[in/out]  p_len                [当前读取的数据长度]
 * @return     int32_t              [0表示读取成功，非0表示读取失败]
 */
int32_t vhal_flash_read(PARTITION_ID_E part_id, const char *key_name, uint8_t *p_data, uint32_t *p_len);

/**
 * @brief  往flash写入数据
 * @param[in]  part_id              [分区ID]
 * @param[in]  key_name             [键值名称]
 * @param[in]  p_data               [写入的数据]
 * @param[in]  len                  [写入数据的长度]
 * @return     int32_t              [0表示写入成功，非0表示写入失败]
 */
int32_t vhal_flash_write(PARTITION_ID_E part_id, const char *key_name, uint8_t *p_data, uint32_t len);

/**
 * @brief  擦除指定分区
 * @param[in]  part_id              [分区ID]
 * @return     int32_t              [0表示擦除成功，非0表示擦除失败]
 */
int32_t vhal_flash_erase(PARTITION_ID_E part_id);

/**
 * @brief  擦除指定分区中的指定键值对
 * @param[in]  part_id              [分区ID]
 * @param[in]  key_name             [键值名称]
 * @return     int32_t              [0表示擦除成功，非0表示擦除失败]
 */
int32_t vhal_flash_erase_key(PARTITION_ID_E part_id, const char *key_name);

#ifdef __cplusplus
}
#endif

#endif /* __VHAL_FLASH_H__ */
