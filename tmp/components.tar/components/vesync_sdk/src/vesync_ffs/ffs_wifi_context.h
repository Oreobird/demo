/**
 * Copyright © Etekcity Technologies Co., Ltd. 2019-2099. All rights reserved.
 * @file    vesync_wifi_context.h
 * @brief   wifi context
 * @author  Owen.zhang
 * @date    2020-04-22
 */

#ifndef FFS_WIFI_CONTEXT_H_
#define FFS_WIFI_CONTEXT_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "ffs/common/ffs_result.h"
#include "ffs/common/ffs_wifi.h"
#include "ffs_linked_list.h"

#include <stdbool.h>

/** @brief Ffs Wi-Fi context structure
 */
typedef struct FfsWifiContext_s {
    FfsLinkedList_t connectionAttemptList;              //!< Wi-Fi connection attempts.
    FfsLinkedList_t configurationList;                  //!< Wi-Fi configuration list.
    FFS_WIFI_CONNECTION_STATE state; //!< Wi-Fi connection state.
} FfsWifiContext_t;

/** @brief Initialize a Ffs Wi-Fi context.
 *
 * @param wifiContext Ffs Wi-Fi context structure
 *
 * @returns Enumerated [result](@ref FFS_RESULT)
 */
FFS_RESULT ffsInitializeWifiContext(FfsWifiContext_t *wifiContext);

/** @brief Deinitialize a Ffs Wi-Fi context.
 *
 * @param wifiContext Ffs Wi-Fi context structure
 *
 * @returns Enumerated [result](@ref FFS_RESULT)
 */
FFS_RESULT ffsDeinitializeWifiContext(FfsWifiContext_t *wifiContext);

/** @brief Update the Wi-Fi connection details.
 *
 * @param wifiContext Ffs Wi-Fi context structure
 * @param configuration Wi-Fi configuration
 *
 * @returns Enumerated [result](@ref FFS_RESULT)
 */
FFS_RESULT ffsUpdateWifiConnectionDetails(FfsWifiContext_t *wifiContext,
        FfsWifiConfiguration_t *configuration);

/** @brief Update the Wi-Fi connection state.
 *
 * @param wifiContext Ffs Wi-Fi context structure
 * @param state Wi-Fi connection state
 *
 * @returns Enumerated [result](@ref FFS_RESULT)
 */
FFS_RESULT ffsUpdateWifiConnectionState(FfsWifiContext_t *wifiContext,
        FFS_WIFI_CONNECTION_STATE state);

/** @brief Update the Wi-Fi connection state in the failure case.
 *
 * @param wifiContext Ffs Wi-Fi context structure
 * @param errorDetails Error details object
 *
 * @returns Enumerated [result](@ref FFS_RESULT)
 */
FFS_RESULT ffsUpdateWifiConnectionFailure(FfsWifiContext_t *wifiContext,
        const FfsErrorDetails_t *errorDetails);

#ifdef __cplusplus
}
#endif

#endif /* FFS_LINUX_COMPAT_WIFI_CONTEXT_H_ */
