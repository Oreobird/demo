/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        demo_production.c
 * @brief       产测
 * @author      Joshua
 * @date        2021-10-5
 */
#include "vesync_device.h"
#include "vesync_log.h"
#include "vesync_production.h"
#include "demo_production.h"

/**
* @brief 产测结果回调函数
* @param[in]  err_code          [产测状态码]
*/
static void demo_production_result_cb(PRODUCTION_ERROR_E err_code)
{
    if (PRD_NO_ERR == err_code)
    {
        APP_LOG(LOG_INFO, "production success\n");
        vesync_device_factory_reset(true, STAT_CHG_RSN_PRODUCTION_STR);
    }
    else
    {
        APP_LOG(LOG_INFO, "production error %d\n", err_code);
    }
}

/**
* @brief 产测功能初始化
*/
void demo_production_init(void)
{
    vesync_production_reg_result_cb(demo_production_result_cb);
}

