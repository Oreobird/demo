/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_ffs_crypto.h
 * @brief       crypto
 * @author      Owen.zhang
 * @date        2020-04-22
 */

#ifndef _VESYNC_FFS_CRYPTO_H_
#define _VESYNC_FFS_CRYPTO_H_

#include <stdio.h>
#include <string.h>
#include "mbedtls/ecp.h"
#include "ffs/common/ffs_stream.h"

#ifdef __cplusplus
extern "C"
{
#endif

#define VESYNC_ASSERT(x)                                                  \
    do                                                                    \
    {                                                                     \
        int ret;                                                          \
        if ((ret = (x)) != 0)                                             \
        {                                                                 \
            printf("%s:%d error: -0x%x\n", __FUNCTION__, __LINE__, -ret); \
            goto exit;                                                    \
        }                                                                 \
    } while (0)

#define SHA256_BLOCK_LENGTH 64
#define SHA256_DIGEST_LENGTH 32
#define BASE64_DIGEST_LENGTH 128

typedef struct FfsKeyContext_s
{
    uint8_t len;
    uint8_t *buf;
} FfsKeyContext_t;

/**
 * @brief random function for ECDH
 * @param rng_state: none use
 * @param output : the string make of radom data
 * @param len : the string's len
 * @return 0
 */
int vesync_ffs_rand(void *rng_state, unsigned char *output, size_t len);

/**
 * @brief load public key for ECDH
 * @param ecp: keypair
 * @param input : public key
 * @param len : the public len
 * @return 0 or -1
 */
int vesync_ffs_load_public_key(int grp_id, mbedtls_ecp_keypair *ecp, uint8_t *point, char len);

/**
 * @brief load private key for ECDH
 * @param ecp: keypair
 * @param input : private key
 * @param len : the private_key len
 * @return 0 or -1
 */
int vesync_ffs_load_private_key(int grp_id, mbedtls_ecp_keypair *ecp, uint8_t *private_key, char len);

/**
 * @brief compute ECDH key
 * @param input : privateKey
 * @param input : publicKey
 * @param output: secretKey
 * @return 0 or -1
 */
int vesync_ffs_compute_ecdh_key(FfsKeyContext_t *privateKey, FfsKeyContext_t *publicKey, FfsKeyContext_t *secretKey);

/**
 * @brief print the hex data in the special buff .
 * @param input :headline
 * @param input :buff
 * @param len
 * @return void
 */
void vesync_ffs_dump_buf(char *info, uint8_t *buf, uint32_t len);

/**
 * @brief Extracts device Public key from a pem chain file .
 * @param output:keyValue without ext info
 * @param input :KeyPem
 * @return void
 */
void parsePublicKeyToHex(FfsKeyContext_t *keyValue, const char *KeyPem);

/**
 * @brief Extracts device Public key with ext info from a pem chain file .
 * @param output:keyValue with ext info
 * @param input :KeyPem
 * @return void
 */
void parsePublicKeyExtToHex(FfsKeyContext_t *keyValue, const char *KeyPem);

/**
 * @brief Extracts device Private key from a pem file.
 * @param output:keyValue
 * @param input :KeyPem
 * @return void
 */
void parsePrivateKeyToHex(FfsKeyContext_t *keyValue, const char *KeyPem);

/**
 * @brief Extracts device  Public key from a pem file.
 * @param output:keyValue
 * @param input :KeyPem
 * @return void
 */
void parseCloudPublicKeyToHex(FfsKeyContext_t *keyValue, const char *KeyPem);

/**
 * @brief compute signatrue from sessionTok
 * @param[in] privateKey
 * @param[in] publicKey
 * @param[in] sessionToken
 * @param[out] buf
 * @return len of buf
 */
int vesync_ffs_sign_from_sessionToken(FfsKeyContext_t *privateKey, FfsKeyContext_t *publicKey, char *sessionTokenStream, unsigned char *buf);


#ifdef __cplusplus
}
#endif

#endif //_VESYNC_FFS_CRYPTO_H_