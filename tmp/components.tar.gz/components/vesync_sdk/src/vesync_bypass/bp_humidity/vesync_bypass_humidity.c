/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_bypass_humidity.c
 * @brief       bypass处理接口
 * @date        2021-05-17
 */
#include <string.h>

#include "vesync_common.h"
#include "vesync_memory.h"
#include "vesync_log_internal.h"
#include "vesync_bypass_internal.h"

/**
 * @brief "getHumidifierStatus" method数据解析
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  json                     [json数据指针]
 * @return BYPASS_ERR_E                 [错误码]
 */
static BYPASS_ERR_E bypass_method_get_humidifier_status_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    UNUSED(json);
    BYPASS_ERR_E ret = BP_OK;
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);
    //查询无需解析json
    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_GET_DEVICE_STATUS);
    if (method_cb)
    {
        method_cb(p_msg_ctx, NULL);
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

    return ret;
}

/**
 * @brief "getSleepSetting" method数据解析
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  json                     [json数据指针]
 * @return BYPASS_ERR_E                 [错误码]
 */
static BYPASS_ERR_E bypass_method_get_sleep_setting_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    UNUSED(json);
    BYPASS_ERR_E ret = BP_OK;
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);
    //查询无需解析json
    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_GET_SLEEP_STATE);
    if (method_cb)
    {
        method_cb(p_msg_ctx, NULL);
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

    return ret;
}

/**
 * @brief 设置手动睡眠模式数据
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  json                     [json数据指针]
 * @return BYPASS_ERR_E                 [错误码]
 */
static BYPASS_ERR_E bypass_method_set_sleep_manual_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    BYPASS_ERR_E ret = BP_OK;
    cJSON* json_data = NULL;

    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    bypass_sleep_manual_t *pSleep_data = (bypass_sleep_manual_t *)vesync_malloc(sizeof(bypass_sleep_manual_t));
    if (NULL == pSleep_data)
    {
        return BP_ERR_NOMEM;
    }

    memset(pSleep_data, 0, sizeof(bypass_sleep_manual_t));

    json_data = cJSON_GetObjectItemCaseSensitive(json, "warm_enabled");
    if (cJSON_IsBool(json_data))
    {
        pSleep_data->warm_enabled = json_data->valueint;
        SDK_LOG(LOG_DEBUG,"warm_enabled: %d\r\n", pSleep_data->warm_enabled);
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "warm_level");
    if (cJSON_IsNumber(json_data))
    {
        pSleep_data->warm_level = json_data->valueint&0xFF;
        SDK_LOG(LOG_DEBUG, "warm_level : %d\r\n", pSleep_data->warm_level);
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "mist_level");
    if (cJSON_IsNumber(json_data))
    {
        pSleep_data->mist_level = json_data->valueint&0xFF;
        SDK_LOG(LOG_DEBUG, "mist_level : %d\r\n", pSleep_data->mist_level);
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "display");
    if (cJSON_IsBool(json_data))
    {
        pSleep_data->display = json_data->valueint;
        SDK_LOG(LOG_DEBUG, "display : %d\r\n", pSleep_data->display);
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_SET_SLEEP_MANUAL);
    if (method_cb)
    {
        method_cb(p_msg_ctx, (void*)pSleep_data);
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

_exit:
    vesync_free(pSleep_data);
    return ret;
}


/**
 * @brief 设置睡眠自动模式数据
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  json                     [json数据指针]
 * @return BYPASS_ERR_E                 [错误码]
 */
static BYPASS_ERR_E bypass_method_set_sleep_auto_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    BYPASS_ERR_E ret = BP_OK;
    cJSON* json_data = NULL;

    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    bypass_sleep_auto_t *pSleep_data = (bypass_sleep_auto_t *)vesync_malloc(sizeof(bypass_sleep_auto_t));
    if (NULL == pSleep_data)
    {
        return BP_ERR_NOMEM;
    }

    memset(pSleep_data, 0, sizeof(bypass_sleep_auto_t));

    json_data = cJSON_GetObjectItemCaseSensitive(json, "target_humidity");
    if (cJSON_IsNumber(json_data))
    {
        pSleep_data->target_humidity = json_data->valueint&0xFF;
        SDK_LOG(LOG_DEBUG,"target_humidity : %d\r\n",pSleep_data->target_humidity);
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "display");
    if (cJSON_IsBool(json_data))
    {
        pSleep_data->display = json_data->valueint;
        SDK_LOG(LOG_DEBUG,"display : %d\r\n",pSleep_data->display);
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_SET_SLEEP_AUTO);
    if (method_cb)
    {
        method_cb(p_msg_ctx, (void*)pSleep_data);
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

_exit:
    vesync_free(pSleep_data);
    return ret;
}


/**
 * @brief 设置自动/恒湿模式下的目标湿度
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  json                     [json数据指针]
 * @return BYPASS_ERR_E                 [错误码]
 */
static BYPASS_ERR_E bypass_method_set_target_humidity_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    BYPASS_ERR_E ret = BP_OK;
    cJSON* json_data = NULL;

    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    bypass_target_humidity_t *pHumidity_data = (bypass_target_humidity_t *)vesync_malloc(sizeof(bypass_target_humidity_t));
    if (NULL == pHumidity_data)
    {
        return BP_ERR_NOMEM;
    }

    memset(pHumidity_data, 0, sizeof(bypass_target_humidity_t));

    // 2020-5-9，修改协议，不再使用type字段
    /*json_data = cJSON_GetObjectItemCaseSensitive(json, "type");
    if (cJSON_IsString(json_data))
    {
        if (0 == strcmp("auto", json_data->valuestring))
            pHumidity_data->mode = BP_HUM_AUTO;
        else if (0 == strcmp("humidity", json_data->valuestring))
            pHumidity_data->mode = BP_HUM_HUMIDITY;
        else
        {
            ret = BP_ERR_ARG;
            goto _exit;
        }
        SDK_LOG(LOG_DEBUG,"mode: %d\n", pHumidity_data->mode);
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }*/

    json_data = cJSON_GetObjectItemCaseSensitive(json, "target_humidity");
    if (cJSON_IsNumber(json_data))
    {
        pHumidity_data->target_humidity = json_data->valueint&0xFF;
        SDK_LOG(LOG_DEBUG,"target_humidity: %d\n",pHumidity_data->target_humidity);
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_SET_TARGET_HUMIDITY);
    if (method_cb)
    {
        method_cb(p_msg_ctx, (void*)pHumidity_data);
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

_exit:
    vesync_free(pHumidity_data);
    return ret;
}

/**
 * @brief 设置加湿器模式
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  json                     [json数据指针]
 * @return BYPASS_ERR_E                 [错误码]
 */
static BYPASS_ERR_E bypass_method_set_humidifier_mode_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    BYPASS_ERR_E ret = BP_OK;
    cJSON* json_data = NULL;

    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    bypass_humidifier_mode_t *pHumidity_data = (bypass_humidifier_mode_t *)vesync_malloc(sizeof(bypass_humidifier_mode_t));
    if (NULL == pHumidity_data)
    {
        return BP_ERR_NOMEM;
    }
    memset(pHumidity_data, 0, sizeof(bypass_humidifier_mode_t));


    json_data = cJSON_GetObjectItemCaseSensitive(json, "mode");
    if (cJSON_IsString(json_data))
    {
        memcpy(pHumidity_data->mode, json_data->valuestring, sizeof(pHumidity_data->mode) - 1);
        SDK_LOG(LOG_DEBUG,"mode : %s\r\n",pHumidity_data->mode);
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_SET_HUMIDITY_MODE);
    if (method_cb)
    {
        method_cb(p_msg_ctx, (void*)pHumidity_data);
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

_exit:
    vesync_free(pHumidity_data);
    return ret;
}


/**
 * @brief 设置热雾档位的开关
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  json                     [json数据指针]
 * @return BYPASS_ERR_E                 [错误码]
 */
static BYPASS_ERR_E bypass_method_set_warm_switch_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    BYPASS_ERR_E ret = BP_OK;
    cJSON* json_data = NULL;

    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    bypass_warm_mode_t *pHumidity_data = (bypass_warm_mode_t *)vesync_malloc(sizeof(bypass_warm_mode_t));
    if (NULL == pHumidity_data)
    {
        return BP_ERR_NOMEM;
    }

    memset(pHumidity_data, 0, sizeof(bypass_warm_mode_t));

    json_data = cJSON_GetObjectItemCaseSensitive(json, "warm_enabled");
    if (cJSON_IsBool(json_data))
    {
        pHumidity_data->warm_enabled = json_data->valueint;
        SDK_LOG(LOG_DEBUG,"warm_enable : %d\r\n",pHumidity_data->warm_enabled);
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_SET_WARM_SWITCH);
    if (method_cb)
    {
        method_cb(p_msg_ctx, (void*)pHumidity_data);
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

_exit:
    vesync_free(pHumidity_data);
    return ret;
}

/**
 * @brief "setAutomaticStop"  method数据解析
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  json                     [json数据指针]
 * @return BYPASS_ERR_E                 [错误码]
 */
static BYPASS_ERR_E bypass_method_set_automatic_stop_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    BYPASS_ERR_E ret = BP_OK;

    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    bypass_auto_stop_data_t *p_auto_stop = vesync_malloc(sizeof(bypass_auto_stop_data_t));
    if (NULL == p_auto_stop)
    {
        return BP_ERR_NOMEM;
    }


    cJSON* json_data = cJSON_GetObjectItemCaseSensitive(json, "enabled");
    if (cJSON_IsBool(json_data))
    {
        p_auto_stop->enable = json_data->valueint;
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_SET_AUTOMATIC_STOP);
    if (method_cb)
    {
        method_cb(p_msg_ctx, (void*)p_auto_stop);
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

_exit:
    vesync_free(p_auto_stop);

    return ret;
}

/***************************** 以下是测试接口 *****************************/
#if defined(PR_FW_TYPE) && (PR_FW_TYPE == 0)
/**
 * @brief 添加加湿器历史数据
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  json                     [json数据指针]
 * @return BYPASS_ERR_E                 [错误码]
 */
static BYPASS_ERR_E bypass_method_add_humidifier_data_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    BYPASS_ERR_E ret = BP_OK;

    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    bypass_hum_data_t *pHumidity_data = (bypass_hum_data_t *)vesync_malloc(sizeof(bypass_hum_data_t));
    if (NULL == pHumidity_data)
    {
        return BP_ERR_NOMEM;
    }

    memset(pHumidity_data, 0, sizeof(bypass_hum_data_t));

    cJSON *json_rcd = cJSON_GetObjectItemCaseSensitive(json, "recordTime");
    if (cJSON_IsNumber(json_rcd))
    {
        pHumidity_data->recordTime = json_rcd->valueint;
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    cJSON *json_hum = cJSON_GetObjectItemCaseSensitive(json, "humidity");
    if (cJSON_IsNumber(json_hum))
    {
        pHumidity_data->humidity = (json_hum->valueint)&0xFF;
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    cJSON *json_tot = cJSON_GetObjectItemCaseSensitive(json, "totalTime");
    if (cJSON_IsNumber(json_tot))
    {
        pHumidity_data->totalTime = json_tot->valueint;
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    SDK_LOG(LOG_DEBUG,"recordTime: %d, humidity: %d, totalTime: %d\r\n",
        pHumidity_data->recordTime, pHumidity_data->humidity, pHumidity_data->totalTime);

    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_ADD_HUM_DATA);
    if (method_cb)
    {
        method_cb(p_msg_ctx, (void*)pHumidity_data);
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

_exit:
    vesync_free(pHumidity_data);
    return ret;
}


/**
 * @brief 获取加湿器历史数据条目数
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  json                     [json数据指针]
 * @return BYPASS_ERR_E                 [错误码]
 */
static BYPASS_ERR_E bypass_method_get_humidifier_data_cnt_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    UNUSED(json);
    BYPASS_ERR_E ret = BP_OK;

    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    //查询无需解析json
    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_GET_HUM_DATA_CNT);
    if (method_cb)
    {
        method_cb(p_msg_ctx, NULL);
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

    return ret;
}

/**
 * @brief 设置加湿器的当前湿度值，用于测试
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  json                     [json数据指针]
 * @return BYPASS_ERR_E                 [错误码]
 */
static BYPASS_ERR_E bypass_method_set_cur_humidity_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    BYPASS_ERR_E ret = BP_OK;
    cJSON* json_data = NULL;

    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    bypass_cur_humidity_data_t *p_curhumidity_data = (bypass_cur_humidity_data_t *)vesync_malloc(sizeof(bypass_cur_humidity_data_t));
    if (NULL == p_curhumidity_data)
    {
        return BP_ERR_NOMEM;
    }

    memset(p_curhumidity_data, 0, sizeof(bypass_cur_humidity_data_t));

    json_data = cJSON_GetObjectItemCaseSensitive(json, "humidity");
    if (cJSON_IsNumber(json_data))
    {
        p_curhumidity_data->cur_humidity_value = json_data->valueint;
        SDK_LOG(LOG_INFO,"set curhumidity value : %d\r\n",p_curhumidity_data->cur_humidity_value);
    }


    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_SET_CUR_HUM);
    if (method_cb)
    {
        method_cb(p_msg_ctx, (void*)p_curhumidity_data);
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

    vesync_free(p_curhumidity_data);
    return ret;
}

/**
 * @brief 获取加湿器状态上报信息，用于自动化脚本测试
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  json                     [json数据指针]
 * @return BYPASS_ERR_E                 [错误码]
 */
static BYPASS_ERR_E bypass_method_get_humidifier_report_info_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    UNUSED(json);
    BYPASS_ERR_E ret = BP_OK;

    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    //查询无需解析json
    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_GET_HUM_REPORT_INFO);
    if (method_cb)
    {
        method_cb(p_msg_ctx, NULL);
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

    return ret;
}
#endif /* defined(PR_FW_TYPE) && (PR_FW_TYPE == 0) */

static bypass_item_data_t humidity_method_tbl[] = {
    {BP_AUTH_MSG_FROM_MQTT_LOCAL,   BYPASS_METHOD_ID_GET_DEVICE_STATUS,     "getHumidifierStatus",  bypass_method_get_humidifier_status_handle, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL,   BYPASS_METHOD_ID_GET_SLEEP_STATE,       "getSleepSetting",      bypass_method_get_sleep_setting_handle, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL,   BYPASS_METHOD_ID_SET_SLEEP_MANUAL,      "setSleepManual",       bypass_method_set_sleep_manual_handle, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL,   BYPASS_METHOD_ID_SET_SLEEP_AUTO,        "setSleepAuto",         bypass_method_set_sleep_auto_handle, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL,   BYPASS_METHOD_ID_SET_TARGET_HUMIDITY,   "setTargetHumidity",    bypass_method_set_target_humidity_handle, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL,   BYPASS_METHOD_ID_SET_HUMIDITY_MODE,     "setHumidityMode",      bypass_method_set_humidifier_mode_handle, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL,   BYPASS_METHOD_ID_SET_WARM_SWITCH,       "setWarmSwitch",        bypass_method_set_warm_switch_handle, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL,   BYPASS_METHOD_ID_SET_AUTOMATIC_STOP,    "setAutomaticStop",     bypass_method_set_automatic_stop_handle, NULL},
    //加湿器测试接口
#if defined(PR_FW_TYPE) && (PR_FW_TYPE == 0)
    {BP_AUTH_MSG_FROM_MQTT_LOCAL,   BYPASS_METHOD_ID_ADD_HUM_DATA,          "addHumidifierData",    bypass_method_add_humidifier_data_handle, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL,   BYPASS_METHOD_ID_GET_HUM_DATA_CNT,      "getHumidifierDataCount", bypass_method_get_humidifier_data_cnt_handle, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL,   BYPASS_METHOD_ID_SET_CUR_HUM,           "setCurHumidity",       bypass_method_set_cur_humidity_handle, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL,   BYPASS_METHOD_ID_GET_HUM_REPORT_INFO,   "getHumidifierReportInfo", bypass_method_get_humidifier_report_info_handle, NULL},
#endif /* defined(PR_FW_TYPE) && (PR_FW_TYPE == 0) */
};

void vesync_bypass_humidity_init(void)
{
    for (int i = 0; i < SIZEOF_ARRAY(humidity_method_tbl); i++)
    {
        bypass_item_t *item = vesync_bypass_init_item(&humidity_method_tbl[i]);
        if (item != NULL)
        {
            vesync_bypass_add_item(item);
        }
    }
}
