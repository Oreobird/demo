/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_net_https.h
 * @brief       https网络服务
 * @author      Joshua
 * @date        2021-09-24
 */

#if CONFIG_VESYNC_SDK_HTTPS_ENABLE
#include <string.h>
#include "cJSON.h"
#include "vesync_common.h"
#include "vesync_memory.h"
#include "vesync_device.h"
#include "vesync_json_internal.h"
#include "vesync_report_internal.h"
#include "vesync_https_internal.h"
#include "vesync_net_https_internal.h"
#include "vesync_ca_cert.h"
#if CONFIG_VESYNC_HAL_BLE_ENABLE
#include "vhal_ble.h"
#endif
#include "vhal_utils.h"
#include "vesync_netcfg_internal.h"

/**
 * @brief 为cjson格式的协议方法添加固定的接口头部 v4版本协议
 * @param[in]  trace_id      [trace id]
 * @param[in]  method        [接口方法名]
 * @param[in]  p_data        [data json对线]
 * @param[in]  cause         [上报原因]
 * @param[in]  token         [token]
 * @return  cJSON*           [添加了固定头部后的cjson格式数据，使用完后必须调用cJSON_Delete进行删除！！！]
 */
static cJSON *vnet_https_json_add_method_head(char *trace_id, char *method, cJSON *p_data, REPORT_CAUSE_E cause, char * token)
{
    cJSON *root = NULL;
    cJSON *context = NULL;
    char mac[MAC_ADDR_STR_MAX_LEN] = {0};

/* V4版本协议格式如下:
    {
        "context": {
            "traceId": "根据中国区生成规范",
            "method": "verifyToken",
            "cid": "cid",
            "mac": "mac",
            "token": "tokenxxxxxxxxxx",
            "configModel": "configModel"，
            "mainFwVersion":""
            "casue":""
        },
        "data": {
            "configKey": "configKey"
        }
    }
*/

    root = cJSON_CreateObject();
    if(NULL == root)
    {
        NET_LOG(LOG_ERROR, "Create root object fail\n");
        return NULL;
    }

    if (vesync_netcfg_get_mode() == BLE_CONFIG)
    {
#if CONFIG_VESYNC_HAL_BLE_ENABLE
        vhal_ble_get_mac(mac, MAC_ADDR_STR_MAX_LEN);
#endif
    }
    else
    {
        vhal_utils_get_dev_mac(VHAL_MAC_WIFI_STA, mac, sizeof(mac));
    }

    cJSON_AddItemToObject(root, "context", context = cJSON_CreateObject());
    if (NULL != context)
    {
        cJSON_AddStringToObject(context, "traceId", trace_id);
        cJSON_AddStringToObject(context, "method", method);
        cJSON_AddStringToObject(context, "cid", vesync_device_get_cid());
        cJSON_AddStringToObject(context, "mac", mac);
        cJSON_AddStringToObject(context, "token", token);
        cJSON_AddStringToObject(context, "configModel", vesync_cfg_get_config_model());

        dev_fw_info_t firm_info;
        vesync_device_get_fw_info_by_type(UPG_TP_WIFI, &firm_info);
        cJSON_AddStringToObject(context, "mainFwVersion", firm_info.cur_firm_ver);
        cJSON_AddStringToObject(context, "cause", vesync_report_get_cause_str(cause));
    }
    else
    { // context创建失败，相当于没有头部，失败返回
        NET_LOG(LOG_ERROR, "Create context object fail\n");
        cJSON_Delete(root);
        return NULL;
    }

    if (NULL != p_data)
    {
        //cJSON_AddItemReferenceToObject(root, p_data->string, p_data);
        cJSON_AddItemToObject(root, "data", p_data);
    }

    return root;
}

/**
 * @brief  解析返回"刷新token"处理
 * @param[in]  read_buf                     [带解析刷新token响应数据指针]
 * @return     int                          [成功/失败]
 */
static int vesync_https_token_refresh(char *buf)
{
    SDK_LOG(LOG_DEBUG, "https_receive : %s \n", buf);
    cJSON *root = cJSON_Parse(buf);
    uint8_t ret = VERR_FAIL;

    if (NULL == root)
    {
        SDK_LOG(LOG_ERROR, "Parse cjson error !\r\n");
        return ret;
    }

    vesync_json_print(root);    //json标准格式，带缩进

    cJSON *code = cJSON_GetObjectItemCaseSensitive(root, "code");
    if (true == cJSON_IsNumber(code))
    {
        SDK_LOG(LOG_DEBUG, "code : %d\r\n", code->valueint);
        if (code->valueint == 0)
        {
            cJSON *result = cJSON_GetObjectItemCaseSensitive(root, "result");
            if (true == cJSON_IsObject(result))
            {
                cJSON *token = cJSON_GetObjectItemCaseSensitive(result, "token");
                if (true == cJSON_IsString(token))
                {
                    vesync_https_flash_token_write(token->valuestring, strlen(token->valuestring));
                    SDK_LOG(LOG_DEBUG,"token : %s\r\n", token->valuestring);
                }

                cJSON *expireIn = cJSON_GetObjectItemCaseSensitive(result, "expireIn");
                if (true == cJSON_IsNumber(expireIn))
                {
                    SDK_LOG(LOG_DEBUG,"expireIn : %d\r\n", expireIn->valueint); //token的过期时间 单位s
                    ret = VERR_OK;
                }
            }
        }
        else if(code->valueint == -12003009) //提示配网信息未找到
        {
            /*删除旧的配网信息*/
            SDK_LOG(LOG_ERROR, "https cfgnet server report error\r\n");
        }
    }

    cJSON_Delete(root);

    return ret;
}


/**
 * @brief  HTTPS客户端初始化
 * @return  int                     [成功：VERR_OK，失败：VERR_FAIL]
 */
static int vnet_https_cli_init(void)
{
    return VERR_OK;
}


/**
 * @brief  HTTPS客户端连接服务器
 * @param[in]   p_srv               [https服务器地址]
 * @param[in]   p_pwd               [https连接的用户密码，BLE/APN配网时为configKey，断开重连时为"0"，FFS配网时为token]
 * @param[in]   p_port              [https连接端口， 指针置空则连接默认端口]
 * @param[in]   tls                 [tls选项]
 * @return  int                     [成功：VERR_OK，失败：VERR_FAIL]
 */
static int vnet_https_cli_netcfg_connect(char *p_srv, char *ip, char *p_pwd, uint32_t *p_port, NETWORK_TLS_CA_E tls)
{
    if (NULL == p_srv || NULL == p_pwd)
    {
        NET_LOG(LOG_DEBUG, "Params err\n");
        return VERR_FAIL;
    }

    int ret = VERR_FAIL;
    char *p_recv_buf = NULL;
    bool net_cfged = false;
    cJSON* info = NULL;
    int buff_len = VESYNC_HTTPS_CFGNET_MAX_BUF_LEN;

    net_info_t *p_net_cfg = vesync_net_mgmt_get_net_cfg();
    if (strlen((char *)p_net_cfg->wifiSSID) > 0 && !vesync_netcfg_is_running())
    {
        return VERR_OK; // 已配网
    }

    int rssi = vhal_wifi_get_router_rssi(8);
    vesync_https_cli_cfg_t https_cfg = {
                .url = NULL,
                .host = p_srv,
                .path = VESYNC_HTTPS_CFGNET_URL_PATH,
                .ca_pem = (char *)vesync_https_ca_cert_pem,
                .client_pem = (tls == TLS_CA_ONE_WAY_AUTH) ? NULL : (char *)vesync_https_client_cert_pem,
                .client_key = (tls == TLS_CA_ONE_WAY_AUTH) ? NULL : (char *)vesync_https_client_key_pem,
                .keep_alive = false,    //true表示设置为长连接，否则为fasle
                .port = *p_port,
                .timeout_ms = HTTPS_WAIT_TIME_MS};

    SDK_LOG(LOG_DEBUG,"start connect https server !\r\n");

    ret = vesync_https_cli_init(&https_cfg);
    if (VERR_OK != ret)
    {
        SDK_LOG(LOG_ERROR,"init https client faild:%d!\r\n", ret);
        return VERR_FAIL;
    }

    ret = vesync_https_cli_connect();
    if (VERR_OK != ret)
    {
        SDK_LOG(LOG_ERROR,"connect https server faild:%d!\r\n", ret);
        return VERR_FAIL;
    }

    p_recv_buf = (char *)vesync_malloc(buff_len);
    if (NULL == p_recv_buf)
    {
        SDK_LOG(LOG_ERROR,"malloc space is faild !\r\n");
        return VERR_FAIL;
    }

    if (!net_cfged)
    {
        info = cJSON_CreateObject();
        if (NULL != info)
        {
            cJSON_AddStringToObject(info, "configKey", (char *)p_net_cfg->configKey);
            cJSON_AddStringToObject(info, "accountID", (char *)p_net_cfg->account_id);
            cJSON_AddNumberToObject(info, "rssi", rssi);
        }
    }

    char token[12] = {0};
    char trace_id_buf[32] = {0};
    vhal_utils_get_system_time_ms_str(trace_id_buf, sizeof(trace_id_buf));

    cJSON *p_msg = vnet_https_json_add_method_head(trace_id_buf, "deviceRegisterV3", info, CAUSE_NULL, token);
    if (NULL == p_msg)
    {
        NET_LOG(LOG_ERROR, "p_msg is NULL !\r\n");
        cJSON_Delete(info);
        VCOM_SAFE_FREE(p_recv_buf);
        return VERR_FAIL;
    }

    vesync_json_print(p_msg);
    char *request = cJSON_PrintUnformatted(p_msg);

    ret = vesync_https_request(HTTPS_METHOD_POST, request, p_recv_buf, &buff_len, false);
    if (buff_len > 0 && ret == VERR_OK)
    {
        NET_LOG(LOG_DEBUG, "start connect https server !\r\n");
        ret = vesync_https_token_refresh(p_recv_buf);
    }
    else
    {
        NET_LOG(LOG_ERROR, "connect https server faild:%d!\r\n", ret);
    }

    cJSON_Delete(p_msg);
    VCOM_SAFE_FREE(request);
    VCOM_SAFE_FREE(p_recv_buf);

    vesync_net_event_notify(EVENT_NWK_READY, NULL);

    return ret;
}


/**
 * @brief  数据发送，可设置qos及收到回包后回调函数
 * @param[in]  topic_type           [topic类型]
 * @param[in]  pData                [数据指针]
 * @param[in]  len                  [数据的长度]
 * @param[in]  qos                  [qos级别，当前支持0和1]
 * @return  int                     [成功：VERR_OK，失败：VERR_FAIL]
 */
static int vnet_https_cli_send(NET_DATA_TOPIC_TYPE_E topic_type, const char *p_data, int len, SEND_QOS_E qos, net_recv_ack_cb_t ack_cb)
{
    int ret = VERR_OK;

    return ret;
}


/**
 * @brief  获取网络服务客户端在线状态
 * @return  VESYNC_NETWORK_STATUS_E [https客户端在线状态]
 */
static VESYNC_NETWORK_STATUS_E vnet_https_cli_status_get(void)
{
    return NETWORK_OFFLINE;
}

/**
 * @brief  vesync平台网络服务客户端断开与服务器的连接
 * @return  int                     [成功：VERR_OK，失败：VERR_FAIL]
 */
static int vnet_https_cli_disconnect(void)
{
    return VERR_FAIL;
}

/**
 * @brief  销毁网络服务客户端，释放内存，重置状态
 */
static void vnet_https_cli_destroy(void)
{
    // Do nothing
}

/**
 * @brief  获取https默认端口
 * @return  int             [端口号，错误返回-1]
 */
static int vnet_https_cli_get_default_port(void)
{
#if CONFIG_VESYNC_SDK_HTTPS_ENABLE
    return HTTPS_DEFAULT_PORT;
#else
    return -1;
#endif
}

/**
 * @brief  https客户端设置
 * @param[in]  p_cli                [客户端结构体指针]
 * @return  int                     [成功：VERR_OK，失败：VERR_FAIL]
 */
int vesync_net_https_cli_setup(vnet_cli_t *p_cli)
{
    NET_UTIL_MEM_CHECK(p_cli, return VERR_FAIL);

    p_cli->init = vnet_https_cli_init;
    p_cli->connect = vnet_https_cli_netcfg_connect;
    p_cli->disconnect = vnet_https_cli_disconnect;
    p_cli->send = vnet_https_cli_send;
    p_cli->destroy = vnet_https_cli_destroy;
    p_cli->status_get = vnet_https_cli_status_get;
    p_cli->fresh = NULL;
    p_cli->get_default_port = vnet_https_cli_get_default_port;
    p_cli->reg_bypass_recv_cb = NULL;
    p_cli->reg_non_bypass_recv_cb = NULL;

    return VERR_OK;
}
#endif

