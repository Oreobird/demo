/**
 * Copyright © Vesync Technologies Co.Ltd. 2019-2021. All rights reserved.
 * @file        vesync_https_private.h
 * @brief       https私有头文件
 * @author      CharlesMei
 * @date        2021-05-24
 */

#ifndef __VESYNC_HTTPS_PRIVATE_H__
#define __VESYNC_HTTPS_PRIVATE_H__

#include "mbedtls/platform.h"
#include "mbedtls/net_sockets.h"
#include "mbedtls/ssl.h"
#include "mbedtls/entropy.h"
#include "mbedtls/ctr_drbg.h"
#include "mbedtls/error.h"
#include "mbedtls/certs.h"
#include "mbedtls/debug.h"
#include "mbedtls/x509_crt.h"
#include "mbedtls/x509_csr.h"

#include "vesync_https_internal.h"


/* The following is the redirection of the interface called by this module */

#ifndef VERR_OK
#include "vesync_common.h"
#define VERR_OK SDK_OK
#define VERR_FAIL SDK_FAIL
#endif /* VERR_OK */

#ifndef HTTPS_LOG
#include "vesync_log_internal.h"
#ifdef SDK_LOG
#define HTTPS_LOG SDK_LOG
#else
#define HTTPS_LOG(level, format, ...)
#endif /* SDK_LOG */
#endif /* HTTPS_LOG */

#ifndef HTTPS_UTIL_MEM_CHECK
#include "vesync_common.h"
#ifdef VCOM_NULL_PARAM_CHK
#define HTTPS_UTIL_MEM_CHECK VCOM_NULL_PARAM_CHK
#else
#define HTTPS_UTIL_MEM_CHECK(param, action) \
    do {                                    \
        if (NULL == (param))                \
        {                                   \
            action;                         \
        }                                   \
    } while (0)
#endif /* VCOM_NULL_PARAM_CHK */
#endif /* HTTPS_UTIL_MEM_CHECK */

#ifndef HTTPS_UTIL_SAFE_FREE
#include "vesync_common.h"
#ifdef VCOM_SAFE_FREE
#define HTTPS_UTIL_SAFE_FREE VCOM_SAFE_FREE
#else
#define HTTPS_UTIL_SAFE_FREE(ptr)           \
    do{                                     \
        if (NULL != ptr)                    \
        {                                   \
            vesync_free(ptr);               \
            ptr = NULL;                     \
        }                                   \
    } while(0)
#endif /* VCOM_SAFE_FREE */
#endif /* HTTPS_UTIL_SAFE_FREE */

#ifndef UNUSED
#define UNUSED(x) (void)(x);
#endif /* UNUSED */

#define VERR_UPLOAD(x, y)
#define VESYNC_PRINTF_FREE_HEAP()

/* The above is the redirection of the interface called by this module */

#define HTTPS_DEFAULT_PORT           (443)       // http默认端口

#define HTTPS_HOST_LEN               (128)
#define HTTPS_PATH_LEN               (256)
#define USER_CFG_KEY_HTTPS_TOKEN      "https_token"

/**
 *@ brief  https mbedtls配置结构体
 */
typedef struct
{
    mbedtls_entropy_context  entropy;
    mbedtls_ctr_drbg_context ctr_drbg;
    mbedtls_ssl_context      ssl_context;
    mbedtls_x509_crt         cacert;
    mbedtls_ssl_config       ssl_conf;
    mbedtls_net_context      server_fd;

    //双向认证定义
    mbedtls_x509_crt client_cert;
    mbedtls_pk_context pk_ctx;
} vhttps_tls_cfg_t;

/**
 *@ brief  https 配置结构体
 */
typedef struct
{
    char host[HTTPS_HOST_LEN];
    char path[HTTPS_PATH_LEN];
    uint16_t port;
    bool keep_alive_enable;
    bool is_keep_alive;
    bool head_fetched;
    bool is_chunked;
} vhttps_cli_t;

#else
#error This private file can only be included by owner
#endif /* __VESYNC_HTTPS_PRIVATE_H__ */

