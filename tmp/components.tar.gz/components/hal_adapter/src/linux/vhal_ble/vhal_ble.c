/**
 *  Copyright © Vesync Technologies Co.Ltd. 2022. All rights reserved
 * @file        vhal_ble.c
 * @brief       蓝牙hal配置ble服务属性接口
 * @date        2022-01-11
 */
#include "vhal_ble.h"

int32_t vhal_ble_init(char *dev_name, char *prj_version, ble_adv_mfr_data_t mfr_data)
{
    return VHAL_FAIL;
}

void vhal_ble_reg_evt_cb(vhal_ble_evt_cb_t cb)
{
    return;
}

void vhal_ble_reg_cmd_recv_cb(vhal_ble_recv_cb_t cb)
{
    return;
}

void vhal_ble_reg_netcfg_recv_cb(vhal_ble_recv_cb_t cb)
{
    return;
}

int32_t vhal_ble_advertising_start(void)
{
    return VHAL_FAIL;
}

int32_t vhal_ble_advertising_stop(void)
{
    return VHAL_FAIL;
}

int32_t vhal_ble_disconnect(void)
{
    return VHAL_FAIL;
}

int32_t vhal_ble_disable(void)
{
    return VHAL_FAIL;
}

int32_t vhal_ble_cmd_data_send(uint8_t *p_data, uint16_t len)
{
    return VHAL_FAIL;
}

int32_t vhal_ble_update_data_send(uint8_t *p_data, uint16_t len)
{
    return VHAL_FAIL;
}

int32_t vhal_ble_netcfg_data_send(uint8_t *p_data, uint16_t len)
{
    return VHAL_FAIL;
}

bool vhal_ble_is_init(void)
{
    return VHAL_FAIL;
}

bool vhal_ble_is_connected(void)
{
    return VHAL_FAIL;
}

int32_t vhal_ble_get_mac(char *dev_mac, uint32_t max_len)
{
    return VHAL_FAIL;
}

int32_t vhal_ble_set_adv_product_info(uint8_t product_type, uint8_t product_model)
{
    return VHAL_FAIL;
}

int32_t vhal_ble_set_adv_netcfg_status(uint8_t netcfg_status)
{
    return VHAL_FAIL;
}

int32_t vhal_ble_set_adv_cmd_data(uint8_t * cmd_data, uint8_t cmd_len, bool up_flag)
{
    return VHAL_FAIL;
}