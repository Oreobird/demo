/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file        vesync_bypass.h
* @brief       bypass处理接口
* @date        2021-05-15
*/

#ifndef __VESYNC_BYPASS_H__
#define __VESYNC_BYPASS_H__

#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>

#include "cJSON.h"
#include "vesync_bypass_error_code.h"
#include "vesync_bypass_method_data.h"

#ifdef __cplusplus
extern "C" {
#endif

#define BP_SOURCE_MAX_LEN            (16) //"source"值的最大长度
#define BP_TRACE_ID_MAX_LEN          (32) //trace id的最大长度
#define BYPASS_METHOD_NAME_MAX_LEN   (64) //method名称的最大长度
#define BYPASS_SUB_DEV_TYPE_MAX_LEN  (16) //sub device type最大长度

/**
 * @brief bypass函数返回值
 */
typedef enum
{
    BP_OK = 0,                    // 无异常
    BP_ERROR = 1,                 // 通用错误
    BP_ERR_ARG = 2,               // 参数不合法
    BP_ERR_NOMEM = 3,             // 内存不足
    BP_ERR_APP_CB_NULL = 4,       // 应用层回调函数为空
    BP_ERR_UN_AUTH = 5,           // 指令未授权
    BP_ERR_UNDEF_USER_METHOD = 6, // 未定义的User Method
    BP_ERR_UNDEF_PRE_METHOD = 7,  // 未定义的Inner pre-method。Inner pre-method
                                  //   只对Bypass信息做预处理，真正的
                                  //   业务需要注册进的相应的Application
                                  //   callback进行处理
    BP_ERR_RESP_ALREADY = 8,      // 该Bypass已经返回Response
} BYPASS_ERR_E;


/**
 * @brief bypass trace message
 */
typedef struct
{
    char trace_id[BP_TRACE_ID_MAX_LEN];  // 消息id
    char src_type[BP_SOURCE_MAX_LEN];    // 消息来源
    char *p_method_str;                  // Bypass Method字符串
    bool is_responsed;                   // 是否完成Bypass Response
} bypass_trace_msg_t;


/**
 * @brief bypass method参数
 */
typedef struct
{
    char dev_type[BYPASS_SUB_DEV_TYPE_MAX_LEN];  // 子设备类型, 为空则表示该设备无子设备类型
    uint32_t dev_idx;  // 子设备索引，0: 操作整个设备, 1-N:操作某个子设备
} bypass_method_info_t;


/**
 * @brief bypass消息上下文结构体
 */
typedef struct
{
    bypass_trace_msg_t *p_trace_msg;     // Bypass Trace Message
    bypass_method_info_t *p_method_info; // Bypass Method的参数
    cJSON *p_request;                    // Bypass请求的JSON Payload
    int resp_error_code;                 // Bypass响应的Error Code
    char *p_resp_error_msg;              // Bypass响应的错误信息
    cJSON *p_response;                   // Bypass响应的JSON Payload
} bypass_msg_ctx_t;

/**
 * @brief bypass 命令应用层回调函数
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  p_data                   [回调函数传入数据]
 */
typedef void (*bypass_method_cb_t)(bypass_msg_ctx_t *p_msg_ctx, void *p_data);


/**
 * @brief bypass 命令处理函数
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  json                     [json数据指针]
 * @return BYPASS_ERR_E                 [错误码]
 */
typedef BYPASS_ERR_E (*bypass_method_handle_fn_t)(bypass_msg_ctx_t *p_msg_ctx, cJSON *json);


/**
 * @brief bypass item 数据结构
 */
typedef struct
{
    char method[BYPASS_METHOD_NAME_MAX_LEN]; // 接口名称
    bypass_method_handle_fn_t method_handle; // 接口json解析回调函数
} bypass_user_data_t;


/**
 * @brief 添加节点
 * @param[in]  data                    [节点数据]
 * @return  int                        [成功：SDK_OK，失败：SDK_FAIL]
 */
int vesync_bypass_add_user_item(bypass_user_data_t *data);


/**
 * @brief 应用层注册bypass method 回调函数
 * @param[in]  method_id               [对应的id]
 * @param[in]  cb                      [回调函数]
 * @return  int                        [成功：SDK_OK，失败：SDK_FAIL]
 */
int vesync_bypass_reg_method_cb(BYPASS_METHOD_ID_E method_id, bypass_method_cb_t cb);

/**
 * @brief Bypass 消息应答函数
 * @param[in]  code                    [错误码]
 * @param[in]  p_trace_msg             [Bypass Trace Message]
 * @param[in]  json                    [Bypass Response的Result JSON数据，可以为NULL]
 * @return  BYPASS_ERR_E               [Bypass错误码]
 */
BYPASS_ERR_E vesync_bypass_reply_noqos(int code, bypass_trace_msg_t *p_trace_msg, cJSON *json);

/**
 * @brief Bypass 异常处理，回复信息封装
 * @param[in]  err_code                [错误码]
 * @param[in]  p_trace_msg             [Bypass Trace Message]]
 * @param[in]  p_msg                   [错误消息(字符串)，支持NULL]
 */
void vesync_bypass_reply_pkg_err_msg(int err_code, bypass_trace_msg_t *p_trace_msg, const char *p_msg);


#ifdef __cplusplus
}
#endif
#endif /* __VESYNC_BYPASS_H__ */

