/*
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file        vesync_away.h
* @brief       离家功能实现
* @date        2021-05-27
*/

#ifndef VESYNC_AWAY_H
#define VESYNC_AWAY_H

#include <stdint.h>
#include "vesync_list.h"

#ifdef __cplusplus
extern "C" {
#endif

#define AWAY_RANDOM_TIME_MAX_NUM    (6)     // 最大的away随机时间点个数

/**
@brief away对比结果类型
*/
typedef enum
{
    AWAY_NOT_EXE,
    AWAY_EXE_ONCE,
    AWAY_EXE_WEEKLY,
    AWAY_EXE_ERR
} AWAY_COMPARE_RESULT_E;

/**
@brief away属性类型
*/
typedef enum
{
    AWAY_ONCE,
    AWAY_WEEKLY
} AWAY_ATTRIBUTE_E;

/**
@brief away结果类型
*/
typedef enum
{
    AWAY_RESULT_OK = 0,
    AWAY_RESULT_NOEXEC = 1,
    AWAY_RESULT_FAIL = 2
} AWAY_RESULT_E;

/**
@brief away事件类型
*/
typedef enum
{
    AWAY_START_ACTION = 0,      //开始时间动作
    AWAY_END_ACTION = 1,        //结束时间动作
    AWAY_RANDOM_ON = 2,         //随机开	中间执行3次随机开关动作
    AWAY_RANDOM_OFF = 3,        //随机关
} AWAY_EVENT_E;

/**
 * @brief away 回调函数定义
 * @param[in]  pConfig_data     [指向away应用程序配置数据结构]
 * @param[in]  away_event       [通知应用程序away该执行的动作]
 */
typedef AWAY_RESULT_E (*away_cb_t)(void *pConfig_data, AWAY_EVENT_E away_event);

/**
 * @brief  away周期的数据结构
*/
typedef struct
{
    uint32_t awayId;            //由应用层传递进来
    uint8_t loop;               //循环周循环loop
    uint32_t start_ts;          //away 开始时间
    uint32_t end_ts;            //away 结束时间
    void *pConfig_data;         //指向应用层配置数据
    away_cb_t away_cb;          //away回调函数
    uint32_t random_time_point[AWAY_RANDOM_TIME_MAX_NUM];   //away随机时间
} away_cycle_data_t;


/**
 * @brief 应用层增加away cycle任务api
 * @param pAwayData away cycle 的数据结构
 * @return  添加结果
 */
int vesync_away_cycle_add(away_cycle_data_t *pAwayData);


/**
 * @brief 移除away cycle 中的任务
 * @param awayid away　id
 * @return 0 移除成功 -1 移除失败
 */
int vesync_away_cycle_remove(uint8_t awayid);

/**
 * @brief 获取当前away cycle 任务数量
 * @return  away cycle 的数量
 */
uint8_t vesync_away_cycle_get_num(void);


/**
 * @brief 传入时间戳计算星期
 * @param ts 需要计算的时间戳
 * @return 1-7 周一到周日
 */
uint8_t vesync_away_cycle_get_timestamp_weekday(uint32_t ts);

/**
 * @brief away loop 计算api
 * @return loop 的数值
 */
uint8_t vesync_away_cycle_loop_calc(uint8_t repeat, AWAY_ATTRIBUTE_E attr);

/**
 * @brief  判断away单次执行时，下发的结束时间比当前时间早，则进行调整
 * @param[in]   end_ts          [away结束时间戳]
 * @param[in]   repeat          [away是否重复执行]
 * @return      int32_t         [需要调整的天数]
 */
int32_t vesync_away_cycle_check_end_ts(uint32_t end_ts, uint8_t repeat);

/**
 * @brief 获取away的6个随机时间点
 * @param[in]  uint32_t *        [读取away随机时间点的缓存指针]
 * @param[in]  int32_t           [缓存长度]
 * @return     int32_t           [0表示成功，非零表示失败]
 */
int32_t vesync_away_cycle_get_random_ts(uint32_t *p_rand_ts, int32_t len);

/**
 * @brief 清除away的6个随机时间点
 * @param[in]  uint32_t          [下标]
 * @return     void              [none]
 */
void vesync_away_cycle_clear_random_ts(uint32_t idx);

/**
 * @brief 获取随机时间点的实际数量
 * @return     uint32_t              [随机时间点的实际数量]
 */
uint32_t vesync_away_cycle_get_random_num(void);



#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_AWAY_H__ */

