/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_log_internal.h
 * @brief       log模块内部类型定义
 * @author      Joshua
 * @date        2021-04-20
 */

#ifndef __VESYNC_LOG_INTERNAL_H__
#define __VESYNC_LOG_INTERNAL_H__

#include "vesync_log.h"
#include "vesync_mutex.h"

#ifdef __cplusplus
extern "C" {
#endif

#define ENABLE_LOG_MUTEX

#define VESYNC_LOG_BUFF_MAX (1536)

/*
* @brief log tag map table
*/
typedef struct
{
    TYPE_COMPONENT_E comp;
    char comp_str[4];
    LOG_LEVEL_E level;
    char level_str[2];
} str_map_tbl_t;

typedef struct
{
    LOG_LEVEL_E level;
    LOG_LEVEL_E raw_level;
#ifdef ENABLE_LOG_MUTEX
    vesync_mutex_t mutex;
#endif
    char log_buf[VESYNC_LOG_BUFF_MAX];

    print_cb_t print_cb;
    log_transfer_cb_t transfer_cb;
} vesync_log_t;


/* SDK log API */
#define SDK_LOG(level, format,...)  \
    do  \
    {   \
        vesync_log_print(COMP_SDK, level, __FUNCTION__, __LINE__, format, ##__VA_ARGS__); \
    } while(0)

/*
 * @function vesync_log_level_get
 * @brief Get log level
 * @param[out] LOG_LEVEL_E level
 * @return void
*/
LOG_LEVEL_E vesync_log_level_get(void);

/*
 * @function vesync_log_raw_level_get
 * @brief Get log raw level
 * @return  log raw level
*/
LOG_LEVEL_E vesync_log_raw_level_get(void);

#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_LOG_INTERNAL_H__ */

