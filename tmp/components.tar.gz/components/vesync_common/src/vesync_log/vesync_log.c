/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_log.c
 * @brief       log功能实现
 * @author      Joshua
 * @date        2021-04-20
 */

#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "vesync_common.h"
#include "vesync_memory.h"
#include "vesync_log_internal.h"

static vesync_log_t *s_log = NULL;

static str_map_tbl_t map_tbl[] = {
    {COMP_HAL, "HAL", LOG_DEBUG, "D"},
    {COMP_OS,  "OS",  LOG_INFO,  "I"},
    {COMP_SDK, "SDK", LOG_WARN,  "W"},
    {COMP_APP, "APP", LOG_ERROR, "E"}
};

/**
 * @brief 初始化日志接口
 * @return int  [成功：SDK_OK, 失败：SDK_FAIL]
 */
int vesync_log_init(void)
{
    if (s_log != NULL)
    {
        return SDK_OK;
    }

    s_log = vesync_malloc(sizeof(vesync_log_t));
    VCOM_NULL_RET_CHK(s_log, return -1);

    memset(s_log, 0, sizeof(vesync_log_t));

#if defined(PR_FW_TYPE) && (PR_FW_TYPE == 0)
    s_log->level = LOG_DEBUG;
    s_log->raw_level = LOG_INFO;
#else
    s_log->level = LOG_WARN;
    s_log->raw_level = LOG_WARN;
#endif

    s_log->print_cb = printf;
    s_log->transfer_cb = NULL;

#ifdef ENABLE_LOG_MUTEX
    s_log->mutex = vesync_mutex_new();
    if (s_log->mutex == NULL)
    {
        vesync_free(s_log);
        return SDK_FAIL;
    }
#endif

    return SDK_OK;
}

/**
 * @brief 反初始化日志接口
 * @return void
 */
void vesync_log_deinit(void)
{
    if (s_log)
    {
#ifdef ENABLE_LOG_MUTEX
        vesync_mutex_free(s_log->mutex);
#endif
        vesync_free(s_log);
        s_log = NULL;
    }
}

/**
 * @brief 设置普通日志打印级别
 * @param[in] LOG_LEVEL_E level
 * @return void
 */
void vesync_log_level_set(LOG_LEVEL_E level)
{
    if (NULL != s_log)
    {
        s_log->level = level;
    }
}

/**
 * @brief 设置十六进制数据日志打印级别
 * @param[in] LOG_LEVEL_E level
 * @return void
 */
void vesync_log_raw_level_set(LOG_LEVEL_E level)
{
    if (NULL != s_log)
    {
        s_log->raw_level = level;
    }
}

/**
 * @brief 读取普通日志打印级别
 * @return LOG_LEVEL_E  [Log打印等级]
 */
LOG_LEVEL_E vesync_log_level_get(void)
{
    return s_log != NULL ? s_log->level : LOG_INVALID;
}

/**
 * @brief 读取十六进制数据日志打印级别
 * @return LOG_LEVEL_E  [Log打印等级]
 */
LOG_LEVEL_E vesync_log_raw_level_get(void)
{
    return s_log != NULL ? s_log->raw_level : LOG_INVALID;
}

#if CONFIG_VESYNC_LOG_PREFIX_NONE_ENABLE
void vesync_log_print(TYPE_COMPONENT_E comp, LOG_LEVEL_E level, int line, const char *format, ...)
#else
void vesync_log_print(TYPE_COMPONENT_E comp, LOG_LEVEL_E level, const char *anchor, int line, const char *format, ...)
#endif
{
    if (s_log == NULL || s_log->print_cb == NULL)
    {
        return;
    }

    if (level >= s_log->level && LOG_DISABLE != s_log->level)
    {
        va_list arg_ptr;

#ifdef ENABLE_LOG_MUTEX
        vesync_mutex_lock(s_log->mutex);
#endif

        memset(s_log->log_buf, 0, sizeof(s_log->log_buf));

        char *str = s_log->log_buf;

        va_start(arg_ptr, format);  // 获取函数可变参列表的起始位置，注意使用的是format，非fmt
        vsnprintf(str, VESYNC_LOG_BUFF_MAX - 1, format, arg_ptr);   // 格式化字符串，注意使用的是fmt，非format，ets_vsnprintf不能直接读取FLASH
        va_end(arg_ptr);

        if (s_log->transfer_cb)
        {
            s_log->transfer_cb(str, (int)strlen(str));
        }

        char *comp_str = "";
        char *level_str = "";
        for (int i = 0; i < sizeof(map_tbl)/sizeof(str_map_tbl_t); i++)
        {
            if (comp == map_tbl[i].comp)
            {
                comp_str = map_tbl[i].comp_str;
            }

            if (level == map_tbl[i].level)
            {
                level_str = map_tbl[i].level_str;
            }
        }

        // 实际打印函数，可以根据实际使用系统，由HAL/APP层进行注册
        if (s_log->print_cb)
        {
#ifdef CONFIG_VESYNC_LOG_COLOR_ENABLE
#if CONFIG_VESYNC_LOG_PREFIX_NONE_ENABLE
            switch (level)
            {
            case LOG_DEBUG:
                s_log->print_cb(LOG_COLOR_D "[%s %s %d] %s" LOG_RESET_COLOR, comp_str, level_str, line, str);
                break;
            case LOG_INFO:
                s_log->print_cb(LOG_COLOR_I "[%s %s %d] %s" LOG_RESET_COLOR, comp_str, level_str, line, str);
                break;
            case LOG_WARN:
                s_log->print_cb(LOG_COLOR_W "[%s %s %d] %s" LOG_RESET_COLOR, comp_str, level_str, line, str);
                break;
            case LOG_ERROR:
                s_log->print_cb(LOG_COLOR_E "[%s %s %d] %s" LOG_RESET_COLOR, comp_str, level_str, line, str);
                break;
            default:
                break;
            }
#else
            switch (level)
            {
            case LOG_DEBUG:
                s_log->print_cb(LOG_COLOR_D "[%s %s %s:%d] %s" LOG_RESET_COLOR, comp_str, level_str, anchor, line, str);
                break;
            case LOG_INFO:
                s_log->print_cb(LOG_COLOR_I "[%s %s %s:%d] %s" LOG_RESET_COLOR, comp_str, level_str, anchor, line, str);
                break;
            case LOG_WARN:
                s_log->print_cb(LOG_COLOR_W "[%s %s %s:%d] %s" LOG_RESET_COLOR, comp_str, level_str, anchor, line, str);
                break;
            case LOG_ERROR:
                s_log->print_cb(LOG_COLOR_E "[%s %s %s:%d] %s" LOG_RESET_COLOR, comp_str, level_str, anchor, line, str);
                break;
            default:
                break;
            }
#endif
#else
#if CONFIG_VESYNC_LOG_PREFIX_NONE_ENABLE
            s_log->print_cb("[%s %s %s:%d] %s", comp_str, level_str, line, str);
#else
            s_log->print_cb("[%s %s %s:%d] %s", comp_str, level_str, anchor, line, str);
#endif
#endif


        }

#ifdef ENABLE_LOG_MUTEX
        vesync_mutex_unlock(s_log->mutex);
#endif
    }
}

/**
 * @brief 十六进制数据日志打印级别
 * @param[in] level          [打印等级]
 * @param[in] p_prefix       [字符前缀]
 * @param[in] p_data         [打印数据]
 * @param[in] length         [打印数据长度]
 * @return void
 */
void vesync_log_hex_print(LOG_LEVEL_E level, const char *p_prefix, void *p_data, unsigned short length)
{
    if (s_log == NULL || s_log->print_cb == NULL || p_data == NULL)
    {
        return;
    }

    if (level >= s_log->raw_level && LOG_DISABLE != s_log->raw_level)
    {
        if (NULL != p_prefix)
        {
            s_log->print_cb("%s ", p_prefix);
        }

        unsigned short hex_len = ((length > VESYNC_LOG_BUFF_MAX) ? VESYNC_LOG_BUFF_MAX : length);
        unsigned char *hex = (unsigned char *)vesync_malloc(hex_len);
        if (NULL == hex)
        {
            return;
        }

        memset(hex, 0, hex_len);
        memcpy(hex, p_data, hex_len);

        for (unsigned short i = 0; i < hex_len ; i++)
        {
            s_log->print_cb("%02X ", hex[i]);
        }

        s_log->print_cb("\n");

        vesync_free(hex);
    }
}

/**
 * @brief 注册日志打印的传输钩子回调函数
 * @param[in] cb    [钩子回调函数]
 */
void vesync_log_reg_transfer_cb(log_transfer_cb_t cb)
{
    if (NULL != s_log)
    {
        s_log->transfer_cb = cb;
    }
}

