/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_ffs.c
 * @brief       ffs SDK用户上下文声明及相关处理
 * @author      Dongri.Su
 * @date        2020-02-28
 */

#ifndef _VESYNC_FFS_USER_CONTEXT_H_
#define _VESYNC_FFS_USER_CONTEXT_H_

// 头文件
#include <string.h>
#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>


#include "ffs/conversion/ffs_convert_wifi_provisionee_state.h"
#include "ffs/common/ffs_stream.h"
#include "ffs_rtos_configuration_map.h"
#include "ffs_wifi_context.h"
#include "vesync_ffs_crypto.h"
#include "vesync_http_internal.h"

#ifdef __cplusplus
extern "C"
{
#endif

#define DSS_HOST_NAME_BUFFER_SIZE                   (256)
#define DSS_SESSION_ID_BUFFER_SIZE                  (1024)
#define DSS_NONCE_BUFFER_SIZE                       (32)
#define DSS_BODY_BUFFER_SIZE                        (4096)

typedef enum
{
    FFS_KEY_CLIENT_PUBLIC = 0,  //client public key
    FFS_KEY_CLOUD_PUBLIC,       //clound public key
    FFS_KEY_PRIVATE,            //private key
    FFS_KEY_CA_KEY,             //CA key
    FFS_KEY_OTHER               //other
} FFS_KEY_TYPE_E;


/** @brief Ffs Wi-Fi RTOS user context structure
 */
typedef struct FfsUserContext_s
{
    FfsWifiContext_t wifiContext;                 //!< Wi-Fi context.
    FfsRTOSConfigMap_t configMap;                 // Configuration map.
    FfsRegistrationRequest_t registrationRequest; // Register Request Token
    bool cancel;                                  // Custom stop ffs flag
    bool CanPostWifiScanData;                     // Custom post wifi scan data flag
    bool CanGetWifiCredentials;                   // Custom get wifi credentials flag

    char *setupNetworkSsid;                       // Custom setup network SSID.
    char *setupNetworkPsk;                        // Custom setup network PSK.

    char *userNetworkSsid;                        // User network SSID.
    char *userNetworkPsk;                         // User network PSK.
    char *dssHost;                                //!< Custom DSS host.
    int32_t dssPort;                              //!< Custom DSS port.
    bool hasDssPort;                              //!< Do we have a custom DSS port?

    char *sessoinToken;                           // SessionToken
    char *lang;                                   // LanguageLocale
    char *market;                                 // Marketplace
    char *alexaEvtGwEp;                           // AlexaEventGatewayEndpoint
    char *utc;                                    // UTC

    FFS_WIFI_PROVISIONEE_STATE provisioneeState;  // Current provisionee state.
    //SemaphoreHandle_t provisioneeStateSem;      // Semaphore protecting the provisionee state.

    FfsKeyContext_t cloudPublicKey;               // Cloud public key.
    FfsKeyContext_t devicePrivateKey;             // Device private key.
    FfsKeyContext_t devicePublicKey;              // Device public key.
    FfsKeyContext_t devicePublicKeyExt;           // Device public key with ext info.
    uint8_t *hostNameBuffer;                      // DSS client host name buffer.
    uint8_t *sessionIdBuffer;                     // DSS client session ID buffer.
    uint8_t *nonceBuffer;                         // DSS client nonce buffer.
    uint8_t *bodyBuffer;                          // DSS client body buffer.

    char *client_pem;
    char *private_pem;
} FfsUserContext_t;



/**
 * @brief  Initialize the Ffs Wi-Fi freeRTOS user context.
 * @param[out] FfsUserContext_t    [用户上下文定义]
 * @return     FFS_RESULT          [成功/失败]
 */
FFS_RESULT ffsInitializeUserContext(FfsUserContext_t *userContext);

/**
 * @brief  Deinitialize the Ffs Wi-Fi Linux user context.
 * @param[out] FfsUserContext_t    [用户上下文定义]
 * @return     FFS_RESULT          [成功/失败]
 */
FFS_RESULT ffsDeinitializeUserContext(FfsUserContext_t *userContext);

/*
 * read files and get string's pointer.
 * param[in] FFS_KEY_TYPE_E type
 * retrun const char*
 */
const char* getCertKeyString(FfsUserContext_t *userContext, FFS_KEY_TYPE_E type);

/**
 * @brief   通过http获取client CA证书 测试用例
 *
 * 示例：url = "http://192.168.15.106:8888/firmware-debug/test/dss/certificate.pem"; mode = HTTP_GET_CLI_CA;
 * @param[in]  url
 * @param[in]  mode
 * @return     PLAT_OK 获取成功        PLAT_FAIL获取失败
 */
int vesync_ffs_get_generate_ca_files_api(char* url, HTTP_GET_MODE_E mode);

#ifdef __cplusplus
}
#endif

#endif //_VESYNC_FFS_USER_CONTEXT_H_