import os


class Parser:
    def __init__(self, feature_list=[], start_token="#if BYPASS_METHOD", end_token="#endif"):
        self.start_token = start_token
        self.end_token = end_token
        self.feature_list = feature_list
        self.save_lines = []

    def feature_support(self, line):
        for feat in self.feature_list:
            if feat in line:
                return True
        return False

    def parse(self, file_name):
        count = 0
        with open(file_name, 'r') as f:
            lines = f.readlines()
            ignore = False
            for line in lines:
                if self.start_token in line:
                    count += 1
                    if not self.feature_support(line):
                        ignore = True
                        continue
                elif self.end_token in line:
                    count -= 1
                    if not ignore and count == 0:
                        self.save_lines.append(line)
                    ignore = False
                    continue

                if not ignore: 
                    self.save_lines.append(line)

    def save(self, file_name):
        with open(file_name, 'w') as f:
            for line in self.save_lines:
                f.write(line)

feature_list = ["TIMER", "AWAY"]
parser = Parser(feature_list)
parser.parse("vesync_bypass.h")
parser.save("vesync_bypass_support.h")

