/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_memory.h
 * @brief       memory抽象层，封装内存相关接口
 * @date        2021-04-20
 */

#ifndef __VESYNC_MEMORY_H__
#define __VESYNC_MEMORY_H__

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief  申请内存
 * @param[in]  size                    [内存块大小，以字节为单位]
 * @return void (*)                    [成功：返回内存地址；失败：返回 NULL]
 */
void *vesync_malloc(uint32_t size);

/**
 * @brief  申请内存并初始化
 * @param[in]  nmemb                   [要被分配的元素个数]
 * @param[in]  size                    [元素的大小]
 * @return void (*)                    [成功：返回内存地址；失败：返回 NULL]
 */
void *vesync_calloc(uint32_t nmemb, uint32_t size);

/**
 * @brief  重新分配内存大小
 * @param[in]  ptr                     [指向一个要重新分配内存的内存块]
 * @param[in]  size                    [内存块新的大小，以字节为单位]
 * @return void (*)                    [成功：返回内存地址；失败：返回 NULL]
 */
void *vesync_realloc(void *ptr, uint32_t size);

/**
 * @brief  释放内存空间
 * @param[in]  ptr                     [指向的内存地址]
 */
void vesync_free(void *ptr);

#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_MEMORY_H__ */