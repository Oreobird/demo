/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        switch.h
 * @brief       switch入口头文件
 * @author      Charles.Mei
 * @date        2021-07-29
 */


#ifndef __SWITCH_H__
#define __SWITCH_H__

#ifdef __cplusplus
    extern "C" {
#endif

#define SWITCH_UART_NUM (0) // 串口号，需要根据SDK的配置确定

#ifdef __cplusplus
}
#endif

#endif


