/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
 * @file        outlet_production.c
 * @brief       产测过程和状态处理
 * @author      Joshua
 * @date        2021-06-20
 */


#ifndef _OUTLET_PRODUCTION_H_
#define _OUTLET_PRODUCTION_H_

#include "vesync_production.h"


#ifdef __cplusplus
extern "C" {
#endif


#define PRO_WIFI_TEST_SSID      "vesync_Test"
#define PRO_WIFI_TEST_PWD       NULL

/**
 * @brief 继电器测试
 *
 * @param arg
 */
void outlet_production_test_relay(void);

/**
 * @brief 产测回调函数
 * @param[in]  arg          [产测状态码]
 */
void outlet_production_callback(PRODUCTION_STATUS_E arg);

/**
 * @brief PCBA测试，计量自校正
 */
void outlet_production_self_cal_metering(void);

/**
 * @brief 执行PCBA测试
 * @return int             [错误码，成功/失败]
 */
int outlet_pcba_test_process(void);


#ifdef __cplusplus
}
#endif

#endif

