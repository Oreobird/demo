/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        app_bypass.h
 * @brief       bypass处理接口
 * @date        2022-03-04
 */

#ifndef __APP_BYPASS_H__
#define __APP_BYPASS_H__

#include "vesync_bypass.h"

#ifdef __cplusplus
extern "C" {
#endif

#define BP_ERR_MSG_LEN (256)
#define BP_NO_VALUE (0xFFFFFFFF)


typedef enum {
    BP_WORK_MODE_WHITE = 0,
    BP_WORK_MODE_HSV = 1,
    BP_WORK_MODE_SEGHSV = 2,
    BP_WORK_MODE_MUSIC = 3,
    BP_WORK_MODE_SCENE = 4,
} BP_WORK_MODE_E;

typedef enum {
    BP_ADJUST_RULE_NORMAL = 0,
    BP_ADJUST_RULE_ROLLBACK = 1,
} BP_ADJUST_RULE_E;

typedef enum {
    BP_ADJUST_TYPE_BRIGHTNESS = 0,
    BP_ADJUST_TYPE_COLORTEMP = 1,
} BP_ADJUST_TYPE_E;
        
typedef enum {
    BP_FORCE_SILENT = 0,
    BP_FORCE_RESPONSE = 1,
    BP_FORCE_WWA = 2,
} BP_FORCE_E;
    
typedef enum {
    BP_START_ACT_ACT_TYPE_SWITCH = 0,
    BP_START_ACT_ACT_TYPE_COLORMODE = 1,
    BP_START_ACT_ACT_TYPE_CHANGESCENE = 2,
} BP_START_ACT_ACT_TYPE_E;

typedef enum {
    BP_START_ACT_ACT_OFF = 0,
    BP_START_ACT_ACT_ON = 1,
    BP_START_ACT_ACT_WHITE = 2,
    BP_START_ACT_ACT_HSV = 3,
    BP_START_ACT_ACT_MUSIC = 4,
    BP_START_ACT_ACT_SCENARIO = 5,
    BP_START_ACT_ACT_MANUAL = 6,
} BP_START_ACT_ACT_E;
                
typedef enum {
    BP_SCH_TYPE_TIMING = 0,
    BP_SCH_TYPE_SUN = 1,
} BP_SCH_TYPE_E;
                                                
typedef struct {
    int power_switch;
    int switch_idx;
} bp_set_switch_request_t;

int request_data_handle_for_set_switch(bp_set_switch_request_t *request_data, int *err_code, char *err_msg, void **extra);

typedef struct {
    int switch_idx;
} bp_toggle_switch_request_t;

int request_data_handle_for_toggle_switch(bp_toggle_switch_request_t *request_data, int *err_code, char *err_msg, void **extra);

typedef struct {
    int work_mode;
    int color_temp;
    int brightness;
    int hue;
    int saturation;
    int value;
    int force;
    int scene_id;
    int seg_num;
    int seg_hsv_num; // array实际元素个数
    struct {
        int hue;
        int saturation;
        int value;
    } seg_hsv[15];
} bp_set_status_request_t;

int request_data_handle_for_set_status(bp_set_status_request_t *request_data, int *err_code, char *err_msg, void **extra);

typedef struct {
    int power_switch;
    int work_mode;
    int color_temp;
    int brightness;
    int hue;
    int saturation;
    int value;
    int scene_id;
    int seg_num;
    int seg_hsv_num; // array实际元素个数
    struct {
        int hue;
        int saturation;
        int value;
    } seg_hsv[15];
} bp_set_status_reply_t;

int reply_data_get_for_set_status(bp_set_status_reply_t *reply_data, int *err_code, char *err_msg, void *extra);

typedef struct {
    int power_switch;
    int work_mode;
    int color_temp;
    int brightness;
    int hue;
    int saturation;
    int value;
    int scene_id;
    int seg_num;
    int seg_hsv_num; // array实际元素个数
    struct {
        int hue;
        int saturation;
        int value;
    } seg_hsv[15];
} bp_get_status_reply_t;

int reply_data_get_for_get_status(bp_get_status_reply_t *reply_data, int *err_code, char *err_msg, void *extra);

typedef struct {
    int adjust_rule;
    int adjust_type;
    int step;
} bp_adjust_percent_request_t;

int request_data_handle_for_adjust_percent(bp_adjust_percent_request_t *request_data, int *err_code, char *err_msg, void **extra);

typedef struct {
    int percent;
} bp_adjust_percent_reply_t;

int reply_data_get_for_adjust_percent(bp_adjust_percent_reply_t *reply_data, int *err_code, char *err_msg, void *extra);

typedef struct {
    int bead_size;
} bp_set_bead_size_request_t;

int request_data_handle_for_set_bead_size(bp_set_bead_size_request_t *request_data, int *err_code, char *err_msg, void **extra);

typedef struct {
    int bead_size;
} bp_get_bead_size_reply_t;

int reply_data_get_for_get_bead_size(bp_get_bead_size_reply_t *reply_data, int *err_code, char *err_msg, void *extra);

int handle_for_reset_aging(int *err_code, char *err_msg);

typedef struct {
    int scene_id;
} bp_add_scene_reply_t;

int reply_data_get_for_add_scene(bp_add_scene_reply_t *reply_data, int *err_code, char *err_msg, void *extra);

typedef struct {
    int idx;
} bp_get_scenes_request_t;

int request_data_handle_for_get_scenes(bp_get_scenes_request_t *request_data, int *err_code, char *err_msg, void **extra);

typedef struct {
    int total_num;
    int scene_ids_num; // array实际元素个数
    int scene_ids[15];
} bp_get_scenes_reply_t;

int reply_data_get_for_get_scenes(bp_get_scenes_reply_t *reply_data, int *err_code, char *err_msg, void *extra);

typedef struct {
    int scene_id;
} bp_del_scene_request_t;

int request_data_handle_for_del_scene(bp_del_scene_request_t *request_data, int *err_code, char *err_msg, void **extra);

typedef struct {
    int total_time;
    int start_act_num; // array实际元素个数
    struct {
        int num;
        int act_type;
        int act;
        struct {
            
            int brightness;
            int hue;
            int saturation;
            int value;
            int color_temp;
            int scene_id;
            int music_id;
        } params;
    } start_act[4];
} bp_add_timer_request_t;

int request_data_handle_for_add_timer(bp_add_timer_request_t *request_data, int *err_code, char *err_msg, void **extra);

typedef struct {
    int timers_num; // array实际元素个数
    struct {
        int uid;
        int total_time;
        int remain_time;
        int start_act_num; // array实际元素个数
        struct {
            int num;
            int act_type;
            int act;
            struct {
                
                int brightness;
                int hue;
                int saturation;
                int value;
                int color_temp;
                int scene_id;
                int music_id;
            } params;
        } start_act[4];
    } timers[1];
} bp_get_timer_reply_t;

int reply_data_get_for_get_timer(bp_get_timer_reply_t *reply_data, int *err_code, char *err_msg, void *extra);

typedef struct {
    int uid;
} bp_del_timer_request_t;

int request_data_handle_for_del_timer(bp_del_timer_request_t *request_data, int *err_code, char *err_msg, void **extra);

typedef struct {
    
    int enabled;
    int repeat;
    int sch_type;
    struct {
    
        int is_rise;
        int ofs_sec;
    } sun_evt;
    struct {
    
        int clk_sec;
    } tmg_evt;
    int start_act_num; // array实际元素个数
    struct {
        int num;
        int act_type;
        int act;
        struct {
            
            int brightness;
            int hue;
            int saturation;
            int value;
            int color_temp;
            int scene_id;
            int music_id;
        } params;
    } start_act[4];
} bp_add_schedule_request_t;

int request_data_handle_for_add_schedule(bp_add_schedule_request_t *request_data, int *err_code, char *err_msg, void **extra);

typedef struct {
    int uid;
} bp_add_schedule_reply_t;

int reply_data_get_for_add_schedule(bp_add_schedule_reply_t *reply_data, int *err_code, char *err_msg, void *extra);

typedef struct {
    int uid;
    
    int enabled;
    int repeat;
    int sch_type;
    struct {
    
        int is_rise;
        int ofs_sec;
    } sun_evt;
    struct {
    
        int clk_sec;
    } tmg_evt;
    int start_act_num; // array实际元素个数
    struct {
        int num;
        int act_type;
        int act;
        struct {
            
            int brightness;
            int hue;
            int saturation;
            int value;
            int color_temp;
            int scene_id;
            int music_id;
        } params;
    } start_act[4];
} bp_upd_schedule_request_t;

int request_data_handle_for_upd_schedule(bp_upd_schedule_request_t *request_data, int *err_code, char *err_msg, void **extra);

typedef struct {
    int uid;
} bp_upd_schedule_reply_t;

int reply_data_get_for_upd_schedule(bp_upd_schedule_reply_t *reply_data, int *err_code, char *err_msg, void *extra);

typedef struct {
    int idx;
} bp_get_schedules_request_t;

int request_data_handle_for_get_schedules(bp_get_schedules_request_t *request_data, int *err_code, char *err_msg, void **extra);

typedef struct {
    int total_num;
    int schedules_num; // array实际元素个数
    struct {
        int uid;
        int enabled;
        int repeat;
        int sch_type;
        struct {
            
            int is_rise;
            int ofs_sec;
        } sun_evt;
        struct {
            
            int clk_sec;
        } tmg_evt;
        int start_act_num; // array实际元素个数
        struct {
            int num;
            int act_type;
            int act;
            struct {
                
                int brightness;
                int hue;
                int saturation;
                int value;
                int color_temp;
                int scene_id;
                int music_id;
            } params;
        } start_act[4];
    } schedules[26];
} bp_get_schedules_reply_t;

int reply_data_get_for_get_schedules(bp_get_schedules_reply_t *reply_data, int *err_code, char *err_msg, void *extra);

typedef struct {
    int uid;
} bp_del_schedule_request_t;

int request_data_handle_for_del_schedule(bp_del_schedule_request_t *request_data, int *err_code, char *err_msg, void **extra);

typedef struct {
    int uid;
} bp_del_schedule_reply_t;

int reply_data_get_for_del_schedule(bp_del_schedule_reply_t *reply_data, int *err_code, char *err_msg, void *extra);


/**
 * @brief 注册bypass回调函数
 */
void app_bypass_init(void);

#ifdef __cplusplus
}
#endif

#endif


