/**
 * Copyright © Vesync Technologies Co.Ltd. 2019-2021. All rights reserved
 * @file    mqtt_log.c
 * @brief   mqtt log
 * @author  Charles.Mei
 * @date    2021-05-13
 */


#include <string.h>
#include <stdio.h>

#include "mqtt_log.h"


#ifdef MQTT_LOG_ENABLE

/**
 * @brief   check whether the step is valid.
 */
#define mqtt_log_step_is_valid(step) ((step) >= MLOG_STEP_INIT && (step) <= MLOG_STEP_UNKNOWN)


static int s_mlog_step = MLOG_STEP_INIT;

static char s_mqtt_log_buf[MQTT_LOG_BUFF_MAX] = "unknown error.";

static const char* s_mlog_step_str[] =
{
    "INIT:",                /*!< status before starting to connect >*/
    "CONNECTING:",          /*!< connecting mqtt server >*/
    "CONNECTED:",           /*!<  >*/
    "UNKNOWN:",
};

/**
 * @brief   The function gets the value of current step.
 * @return      int         [the value of current step]
 */
static int mqtt_log_get_step(void)
{
    return s_mlog_step;
}

/**
 * @brief   The function gets the name string of current step.
 * @return      const char* [pointer to the name string of current step]
 */
static const char* mqtt_log_get_step_str(void)
{
    int cur_step = mqtt_log_get_step();
    /* step value is alwasy checked in mqtt_log_set_step, no need to check here */

    if (cur_step >= 0 && cur_step < sizeof(s_mlog_step_str) / sizeof(s_mlog_step_str[0]))
    {
        return s_mlog_step_str[cur_step];
    }
    else
    {
        /* return step "UNKNOWN" */
        return s_mlog_step_str[sizeof(s_mlog_step_str) / sizeof(s_mlog_step_str[0]) - 1];
    }
}

/**
 * @brief   The function sets the value of current step.
 * @param[in]   step        [the value of new step]
 */
void mqtt_log_set_step(const int step)
{
    if (mqtt_log_step_is_valid(step))
    {
        s_mlog_step = step;
    }
    else
    {
        s_mlog_step = MLOG_STEP_UNKNOWN;
    }
}

/**
 * @brief   The function sets the error message to s_mqtt_log_buf.
 * @param[in]   format
 * @param[in]   ...
 */
void mqtt_log_set_err_msg(const char *format, ...)
{
    va_list arg_ptr;

    memset(s_mqtt_log_buf, 0, sizeof(s_mqtt_log_buf));
    char *p_mlog_str = s_mqtt_log_buf;

    const char* p_step_str = mqtt_log_get_step_str();
    size_t step_str_len = strlen(p_step_str);
    if(step_str_len > MQTT_LOG_BUFF_MAX - 1)
    {
        return;
    }
    strncpy(p_mlog_str, p_step_str, step_str_len);
    p_mlog_str += step_str_len;

    va_start(arg_ptr, format);
    vsnprintf(p_mlog_str, MQTT_LOG_BUFF_MAX - 1 - step_str_len, format, arg_ptr);
    va_end(arg_ptr);
}

/**
 * @brief   The function gets the pointer to the error message in s_mqtt_log_buf.
 * @return      const char* [pointer to the error message in s_mqtt_log_buf]
 */
const char* mqtt_log_get_err_msg(void)
{
    return s_mqtt_log_buf;
}

#endif /* MQTT_LOG_ENABLE */

