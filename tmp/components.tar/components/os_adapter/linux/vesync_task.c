/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_task.c
 * @brief       task抽象层，封装linux posix任务相关接口
 * @author      Joshua
 * @date        2021-04-20
 */

#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <pthread.h>
#include <sys/prctl.h>
#include <stdio.h>

#include "vesync_common.h"
#include "vesync_os.h"
#include "vesync_task.h"

#define VESYNC_TASK_NAME_MAX_LEN (32)

/*
 * @brief  任务入口函数参数结构体
 */
typedef struct
{
    char name[VESYNC_TASK_NAME_MAX_LEN];
    void (*fn)(void *);
    void *arg;
} targ_t;

/*
 * @brief  任务函数执行入口
 */
static void *task_entry(void *arg)
{
    targ_t *targ = arg;
    void (*fn)(void *) = targ->fn;
    void *farg = targ->arg;

    if (targ->name != NULL)
    {
        prctl(PR_SET_NAME, (unsigned long)targ->name, 0, 0, 0);
    }

    free(targ);
    fn(farg);

    return 0;
}

/*
 * @brief  创建任务
 * @param[in]  name                    [任务名称]
 * @param[in]  fn                      [任务执行函数]
 * @param[in]  arg                     [参数]
 * @param[in]  stack_size              [栈大小]
 * @param[in]  prio                    [任务优先级]
 * @param[in]  task_handle             [创建的任务结构体指针]
 * @return int                         [成功：0；失败：-1]
 */
int vesync_task_new(const char *name,
                          void (*fn)(void *),
                          void *arg,
                          int stack_size,
                          int prio,
                          vesync_task_t *task)
{
    UNUSED(stack_size);
    UNUSED(prio);

    VCOM_NULL_PARAM_CHK(fn, return -1);

    int ret = -1;
    pthread_t task_id;

    if (fn == NULL)
    {
        return -1;
    }

    targ_t *targ = malloc(sizeof(*targ));
    if (targ == NULL)
    {
        return -1;
    }

    if (name != NULL)
    {
        strncpy(targ->name, name, sizeof(targ->name) - 1);
    }

    targ->fn = fn;
    targ->arg = arg;

    ret = pthread_create(&task_id, NULL, task_entry, targ);
    if (ret == 0)
    {
        ret = pthread_detach(task_id);
    }
    else
    {
        free(targ);
    }

    if (task)
    {
        task->handle = (pthread_t*)task_id;
    }

    return ret;
}

/*
* @brief  销毁任务
* @param[in]  task                    [任务结构体指针]
* @return void
*/
void vesync_task_free(vesync_task_t *task)
{
    if (task == NULL)
    {
        pthread_exit(0);
        return;
    }

    pthread_exit(task->handle);
}

/*
 * @brief  获取当前任务名称
 * @return const char *                [返回当前任务名称]
 */
const char *vesync_task_name(void)
{
    static char name[VESYNC_TASK_NAME_MAX_LEN];
    prctl(PR_GET_NAME, (unsigned long)name, 0, 0, 0);
    return name;
}

/*
 * @brief  运行任务调度
 * @return const char *                [返回当前任务名称]
 */
void vesync_task_start(vesync_task_t *task)
{
    while (1)
    {
        sleep(10000);
    }
}

/*
 * @brief  获取系统tick，单位转为毫秒
 * @return uint64_t                     [返回系统tick]
 */
uint64_t vesync_task_get_tick_ms(void)
{
    // to be completed
    return 0;
}

