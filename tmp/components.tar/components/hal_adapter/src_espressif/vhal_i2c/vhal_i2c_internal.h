/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file       vhal_i2c.c
 * @brief      乐鑫平台的i2c读写接口
 * @author     Dongri.Su
 * @date       2021-04-22
 */
#ifndef __VHAL_I2C_INTERNAL_H__
#define __VHAL_I2C_INTERNAL_H__


#include "driver/i2c.h"

#ifdef __cplusplus
extern "C"
{
#endif


#define I2C_MASTER_TX_BUF_DISABLE   0                           // I2C master doesn't need buffer
#define I2C_MASTER_RX_BUF_DISABLE   0                           // I2C master doesn't need buffer

#define WRITE_BIT                   I2C_MASTER_WRITE            // I2C master write
#define READ_BIT                    I2C_MASTER_READ             // I2C master read
#define ACK_CHECK_EN                0x01                        // I2C master will check ack from slave
#define ACK_CHECK_DIS               0x00                        // I2C master will not check ack from slave
#define ACK_VAL                     0x00                        // I2C ack value
#define NACK_VAL                    0x01                        // I2C nack value


#ifdef __cplusplus
}
#endif

#endif /* __VHAL_I2C_INTERNAL_H__ */
