/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        button.c
 * @brief       应用按键接口
 * @author      Joshua
 * @date        2021-12-23
 */
#include <stddef.h>
#include <string.h>

#include "vesync_log.h"
#include "vesync_common.h"

#include "button.h"

void app_button_init(void)
{
    button_netcfg_init();
    button_switch_init();
}

