/*
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file        vesync_ota_mcu.c
* @brief       OTA模块接口实现
* @date        2021-05-19
*/

#include "vesync_cfg.h"
#if (PR_OTA_TYPE_MCU > 0)

#include <stddef.h>
#include <string.h>

#include "vhal_ota.h"
#include "vesync_memory.h"

#include "vesync_common.h"
#include "vesync_log_internal.h"
#include "vesync_uart_internal.h"
#include "vesync_ota_mcu_internal.h"

static vesync_ota_mcu_t s_ota_mcu;

/*-----------------------------------------------------------------------------*
*                                 内部函数实现                          *
*-----------------------------------------------------------------------------*/

/**
* @brief  串口发送函数
* @param[in] opcode                  [操作码]
* @param[in] p_dat                   [数据]
* @param[in] len                     [数据长度]
* @return int32_t                    [返回0表示成功，否则失败]
*/
static int32_t ota_mcu_uart_send(uint16_t opcode, uint8_t *p_dat, uint16_t len)
{
    return vesycn_uart_send_data(1, s_ota_mcu.uart_num, opcode, p_dat, len);
}

/**
* @brief 串口应答函数
* @param[in] err_flag              [错误标志位，0：无错误； 1：错误]
* @param[in] opcode                [操作码]
* @param[in] status_code           [状态码]
* @param[in] p_dat                 [数据]
* @param[in] len                   [数据长度]
* @return int32_t                  [返回0表示成功，否则失败]
*/
static int32_t ota_mcu_uart_send_ack(uint8_t err_flag, uint16_t opcode, uint16_t status_code,uint8_t *p_dat,uint16_t len)
{
    return vesync_uart_send_ack(err_flag, s_ota_mcu.uart_num, opcode, status_code, p_dat, len);
}


/**
 * @brief 启动ota mcu命令
 * @return int32_t                [返回0表示成功，否则失败]
 */
static int32_t ota_mcu_start(void)
{
    int32_t ret = 0;
    ota_mcu_start_protocol_t ota_mcu_start_info;

    ota_mcu_start_info.mtu = OTA_MCU_MAX_PACKET_LEN;
    memcpy(ota_mcu_start_info.sw_version, s_ota_mcu.upg_info.sw_version, 3);
    ota_mcu_start_info.bin_size = s_ota_mcu.upg_info.bin_size;
    ota_mcu_start_info.reserve = 0xffff;

    ret = ota_mcu_uart_send(OPC_OTA_MCU_START, (uint8_t *)&ota_mcu_start_info, sizeof(ota_mcu_start_protocol_t));
    if (SDK_OK != ret)
    {
        return SDK_FAIL;
    }

    return SDK_OK;
}

/**
 * @brief 固件数据请求命令处理
 *
 * @param quest_data 命令数据
 * @return int32_t 返回0表示成功，否则失败
 */
static int32_t ota_mcu_bin_requst(ota_mcu_bin_requst_protocol_t *quest_data)
{
    int32_t ret = 0;
    int32_t temp_len = 0;
    ota_mcu_bin_requst_ack_protocol_t *p_data = NULL;
    uint32_t addr_offset = quest_data->addr_offset;

    SDK_LOG(LOG_DEBUG,"ota_mcu_bin_requst,state:%d, offset= %d\n", s_ota_mcu.upg_state, addr_offset);

    if ((NULL != s_ota_mcu.ota_mcu_state_cb) && (OTA_MCU_STATE_BIN_REQ == s_ota_mcu.upg_state))
    {
        s_ota_mcu.ota_mcu_state_cb(s_ota_mcu.upg_state, NULL);
    }

    if (OTA_MCU_STATE_BIN_REQ != s_ota_mcu.upg_state)
    {
        p_data = (ota_mcu_bin_requst_ack_protocol_t *)vesync_malloc(VESYNC_OTA_MCU_HEADER_LEN); //7不带固件数据的长度
        if (NULL == p_data)
        {
            return SDK_FAIL;
        }

        memset(p_data, 0, VESYNC_OTA_MCU_HEADER_LEN);
        p_data->packet_id   = OTA_MCU_PACKET_ID_OTA_OVER;
        p_data->addr_offset = 0;
        p_data->data_len    = 0;

        temp_len = p_data->data_len + VESYNC_OTA_MCU_HEADER_LEN;

        ret =  ota_mcu_uart_send_ack(0,OPC_OTA_MCU_BIN_REQ,0,(uint8_t *)p_data, temp_len);

        vesync_free(p_data);
        return SDK_FAIL;
    }

    if (addr_offset < s_ota_mcu.upg_info.bin_size)
    {
        p_data = (ota_mcu_bin_requst_ack_protocol_t *)vesync_malloc(s_ota_mcu.upg_info.mtu + VESYNC_OTA_MCU_HEADER_LEN); //7不带固件数据的长度
        if (NULL == p_data)
        {
            //TODO:FIXME
            //VERR_UPLOAD(VERR_LINK_MOD_COM(VERR_MEM_ALLOC_FAIL), vhal_get_free_heap_size());
            return SDK_FAIL;
        }

        memset(p_data, 0, s_ota_mcu.upg_info.mtu + VESYNC_OTA_MCU_HEADER_LEN);

        if ((s_ota_mcu.upg_info.bin_size - addr_offset) > s_ota_mcu.upg_info.mtu)
        {
            p_data->packet_id   = OTA_MCU_PACKET_ID_NORMAL;
            p_data->addr_offset = addr_offset;
            p_data->data_len    = s_ota_mcu.upg_info.mtu;

            temp_len = p_data->data_len + VESYNC_OTA_MCU_HEADER_LEN;

            ret = vhal_ota_read_bin_file(addr_offset, (char *)p_data->data, p_data->data_len);
            if(VHAL_OK != ret)
            {
                vesync_free(p_data);
                //TODO:FIXME
                //VERR_UPLOAD(VERR_RD_FW_FAIL, ret);
                return -1;
            }
            ret =  ota_mcu_uart_send_ack(0,OPC_OTA_MCU_BIN_REQ,0,(uint8_t *)p_data, temp_len);
            if (SDK_OK != ret)
            {
                vesync_free(p_data);
                return SDK_FAIL;
            }
        }
        else
        {
            p_data->packet_id   = OTA_MCU_PACKET_ID_END;
            p_data->addr_offset = addr_offset;
            p_data->data_len    = s_ota_mcu.upg_info.bin_size - addr_offset;

            temp_len = p_data->data_len + VESYNC_OTA_MCU_HEADER_LEN;

            ret = vhal_ota_read_bin_file(addr_offset,(char *)p_data->data, p_data->data_len);
            if (VHAL_OK != ret)
            {
                vesync_free(p_data);
                //TODO:FIXME
                //VERR_UPLOAD(VERR_RD_FW_FAIL, ret);
                return SDK_FAIL;
            }

            ret =  ota_mcu_uart_send_ack(0,OPC_OTA_MCU_BIN_REQ,0,(uint8_t *)p_data,temp_len);
            if (SDK_OK != ret)
            {
                vesync_free(p_data);
                return SDK_FAIL;
            }
        }

        vesync_free(p_data);
    }
    else
    {
        p_data = (ota_mcu_bin_requst_ack_protocol_t *)vesync_malloc(VESYNC_OTA_MCU_HEADER_LEN); //7不带固件数据的长度
        if (NULL == p_data)
        {
            return SDK_FAIL;
        }

        memset(p_data, 0, VESYNC_OTA_MCU_HEADER_LEN);
        p_data->packet_id   = OTA_MCU_PACKET_ID_END;
        p_data->addr_offset = addr_offset;
        p_data->data_len    = 0;

        temp_len = p_data->data_len + VESYNC_OTA_MCU_HEADER_LEN;

        ret =  ota_mcu_uart_send_ack(0,OPC_OTA_MCU_BIN_REQ,0, (uint8_t *)p_data, temp_len);

        vesync_free(p_data);

        return SDK_FAIL;
    }

    return SDK_FAIL;
}

/**
 * @brief 固件下载结果命令处理
 * @param[in] download_result              [命令参数]
 * @return int32_t                         [返回0表示成功，否则失败]
 */
static int32_t ota_mcu_download_result_report(ota_mcu_download_result_protocol_t *download_result)
{
    ota_mcu_state_param_u ota_mcu_state_param;

    SDK_LOG(LOG_DEBUG,"ota_mcu_download_result_report\n");
    s_ota_mcu.upg_state = OTA_MCU_STATE_DOWNLOAD_RESULT;

    int32_t ret = ota_mcu_uart_send_ack(0,OPC_OTA_MCU_DOWNLOAD_RESULT,0,NULL,0);
    if (SDK_OK != ret)
    {
        return SDK_FAIL;
    }

    if (NULL != s_ota_mcu.ota_mcu_state_cb)
    {
        ota_mcu_state_param.download_result = download_result->result;
        s_ota_mcu.ota_mcu_state_cb(s_ota_mcu.upg_state, &ota_mcu_state_param);
    }

    if (DOWNLOAD_SUCCESS != download_result->result)
    {
        s_ota_mcu.upg_err_code = UPG_TRANSFER_TIME_OUT;
        vesync_sem_signal(s_ota_mcu.mcu_upgrade_sem);
    }

    return 0;
}

/**
 * @brief 升级结果命令处理
 *
 * @param ota_mcu_result 命令参数
 * @return int32_t 返回0表示成功，否则失败
 */
static int32_t ota_mcu_result_report(ota_mcu_result_protocol_t * ota_mcu_result)
{
    ota_mcu_state_param_u ota_mcu_state_param;

    SDK_LOG(LOG_DEBUG,"ota_mcu_result_report\n");

    s_ota_mcu.upg_state = OTA_MCU_STATE_RESULT;

    int32_t ret = ota_mcu_uart_send_ack(0,OPC_OTA_MCU_RESULT,0,NULL,0);
    if (SDK_OK != ret)
    {
        return SDK_FAIL;
    }

    if (NULL != s_ota_mcu.ota_mcu_state_cb)
    {
        ota_mcu_state_param.ota_mcu_result = ota_mcu_result->result;
        s_ota_mcu.ota_mcu_state_cb(s_ota_mcu.upg_state,&ota_mcu_state_param);
    }

    if (OTA_MCU_SUCCESS != ota_mcu_result->result)
    {
        s_ota_mcu.upg_err_code = UPG_FAIL;
    }
    else
    {
        s_ota_mcu.upg_err_code = UPG_SUCCESS;
    }

    vesync_sem_signal(s_ota_mcu.mcu_upgrade_sem);

    return SDK_OK;
}

/**
* @brief 调用发送函数发送数据成功或者失败 (发送状态函数)
* @param[in]  event                    [串口数据发送成功/失败事件]
* @param[in]  p_payload                [发送应答帧的数据字段]
* @param[in]  payload_len              [应答帧的payload长度]
* @param[in]  p_msg                    [发送的消息]
*/
static void uart_tx_event_cb(UART_SEND_TYPE_E event, uart_payload_info_t *p_payload, uint16_t payload_len, uart_msg_queue_t *p_msg)
{
    UNUSED(payload_len);
    UNUSED(p_msg);
    SDK_LOG(LOG_DEBUG, "ota_mcu_uart_tx_event_cb():%d\r\n",event);
    // if(NULL != frame)
    // {
    //     SDK_LOG(LOG_DEBUG, " frame.ctrl=0x%02x\r\n",frame->ctrl);
    //     SDK_LOG(LOG_DEBUG, " frame.sequence_id=0x%02x\r\n",frame->sequence_id);
    //     SDK_LOG(LOG_DEBUG, " frame.payload_length=0x%04x\r\n",frame->payload_length);
    //     SDK_LOG(LOG_DEBUG, " frame.checksum=0x%02x\r\n",frame->checksum);
    //     SDK_LOG(LOG_DEBUG, " frame_rframeecv_info.payload[0]=0x%02x\r\n",frame->p_payload[0]);
    // }

    if((OTA_MCU_STATE_START == s_ota_mcu.upg_state) && (NULL != p_payload))
    {
        ota_mcu_start_ack_protocol_t *p_data = (ota_mcu_start_ack_protocol_t *)p_payload->payload_data;
        if (OPC_OTA_MCU_START == p_payload->op_code)
        {
            if (OTA_MCU_OTA_CONFIRM == p_data->ota_confirm)
            {
                s_ota_mcu.upg_info.mtu = (p_data->mtu > OTA_MCU_MAX_PACKET_LEN ? OTA_MCU_MAX_PACKET_LEN : p_data->mtu);
                s_ota_mcu.upg_state = OTA_MCU_STATE_BIN_REQ;

                SDK_LOG(LOG_DEBUG,"enter OTA_MCU_STATE_BIN_REQ\n");
                SDK_LOG(LOG_DEBUG,"ota_mcu_info.mtu= %d\n", s_ota_mcu.upg_info.mtu);
            }
            else if(OTA_MCU_UNABLE_OTA == p_data->ota_confirm)
            {
                s_ota_mcu.upg_err_code = UPG_NOT_SUPT;
                vesync_sem_signal(s_ota_mcu.mcu_upgrade_sem);
            }
            else
            {
                s_ota_mcu.upg_err_code = UPG_FAIL;
                vesync_sem_signal(s_ota_mcu.mcu_upgrade_sem);
            }
        }
    }
}



/**
 * @brief 串口数据处理
 * @param[in] frame                    [接收到的指针]
 */
static void uart_recv_data_cb(VHAL_UART_PORT_E uart_num, uart_payload_info_t *p_payload, uint16_t payload_len)
{
    if (payload_len >= 4)
    {
        switch (p_payload->op_code)
        {
            case OPC_OTA_MCU_BIN_REQ:
                ota_mcu_bin_requst((ota_mcu_bin_requst_protocol_t *)p_payload->payload_data);
                break;
            case OPC_OTA_MCU_DOWNLOAD_RESULT:
                ota_mcu_download_result_report((ota_mcu_download_result_protocol_t *)p_payload->payload_data);
                break;
            case OPC_OTA_MCU_RESULT:
                ota_mcu_result_report((ota_mcu_result_protocol_t *)p_payload->payload_data);
                break;
            default:
                break;
        }
    }
}

/*-----------------------------------------------------------------------------*
*                                 外部函数实现                          *
*-----------------------------------------------------------------------------*/

/**
 * @brief ota超时设置
 */
void vesync_ota_mcu_timeout_set(void)
{
    s_ota_mcu.upg_err_code = UPG_TRANSFER_TIME_OUT;
    vesync_sem_signal(s_ota_mcu.mcu_upgrade_sem);
}

/**
 * @brief 注册升级状态通知回调函数
 * @param[in] cb                    [回调函数]
 */
void vesync_ota_mcu_reg_state_cb(vesync_ota_mcu_state_cb_t cb)
{
    s_ota_mcu.ota_mcu_state_cb = cb;
}


/**
 * @brief ota mcu处理函数
 *
 * @param[in] sw_version             [mcu固件版本 三个字节（0x010109 表示 v1.1.9）]
 * @param[in] bin_size               [mcu固件大小]
 * @return int32_t                   [返回0表示成功，否则失败]
 */
uint32_t vesync_ota_mcu_start(uint8_t *sw_version, uint32_t bin_size)
{
    uint32_t ret = 0;

    SDK_LOG(LOG_DEBUG, "ota mcu start,bin size %d\n",bin_size);

    s_ota_mcu.mcu_upgrade_sem = vesync_sem_new();
    if (s_ota_mcu.mcu_upgrade_sem == NULL)
    {
        SDK_LOG(LOG_ERROR, "mcu ota upgrade sem create fail \n");
        //return SDK_FAIL;
    }

    vesync_uart_reg_tx_event_ota_cb(uart_tx_event_cb);
    vesync_uart_reg_recv_ota_cb(uart_recv_data_cb);

    s_ota_mcu.upg_info.mtu        = OTA_MCU_MAX_PACKET_LEN;
    s_ota_mcu.upg_info.bin_size   = bin_size;
    memcpy(s_ota_mcu.upg_info.sw_version, sw_version, 3);

    s_ota_mcu.upg_state = OTA_MCU_STATE_START;

    ota_mcu_start();

    while (1)
    {
        ret = vesync_sem_wait(s_ota_mcu.mcu_upgrade_sem, 1000);
        if (ret == VOS_OK)     //等待同步信号量
        {
            vesync_sem_signal(s_ota_mcu.mcu_upgrade_sem);
            break;
        }
    }

    ret = s_ota_mcu.upg_err_code;
    s_ota_mcu.upg_state = OTA_MCU_STATE_START;

    vesync_sem_free(s_ota_mcu.mcu_upgrade_sem);

    vesync_uart_reg_tx_event_ota_cb(NULL);
    vesync_uart_reg_recv_ota_cb(NULL);

    SDK_LOG(LOG_DEBUG,"ota mcu end\n");
    return ret;
}

/**
 * @brief 获取MCU升级错误码
 * @return uint8_t                [mcu升级错误码]
 */
uint8_t vesync_ota_mcu_get_upgrade_code(void)
{
    return s_ota_mcu.upg_err_code;
}

/**
 * @brief OTA mcu初始化
 */
void vesync_ota_mcu_init(void)
{
    memset(&s_ota_mcu, 0, sizeof(vesync_ota_mcu_t));
    s_ota_mcu.uart_num = PR_UART_NUM;  //TODO:FIXME
}

#endif
