/**
 *  Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vhal_gpio.c
 * @brief       GPIO接口封装
 * @author      Joshua
 * @date        2021-12-14
 */

#include "vesync_log.h"
#include "vesync_common.h"

#include "vhal_gpio.h"


/*-----------------------------------------------------------------------------*
 *                           外部函数API实现                                         *
 *-----------------------------------------------------------------------------*/

void vhal_gpio_init(vhal_gpio_config_t io_conf)
{
}


int32_t vhal_gpio_get_output(uint8_t gpio_num)
{
    return 1;
}


int32_t vhal_gpio_set_output(uint8_t gpio_num, uint32_t level)
{
    return VHAL_OK;
}


void vhal_gpio_change_pull_status(uint8_t gpio_num, bool pullup, bool enable)
{
}


void vhal_gpio_set_direction(uint8_t gpio_num, GPIO_MODE_E mode)
{

}


void vhal_gpio_register_intr_cb(uint8_t gpio_num, GPIO_INTR_TYPE_E intr_type, vhal_gpio_int_cb_t cb_func, void *arg)
{

}


