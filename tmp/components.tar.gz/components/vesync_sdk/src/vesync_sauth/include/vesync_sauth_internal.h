/**
 * Copyright © Vesync Technologies Co.Ltd. 2022. All rights reserved.
 * @file        vesync_sauth_internal.h
 * @brief       Vesync SAUTH模块的开放接口定义
 * @author      Herve
 * @date        2022-01-04
 */
#ifndef __VESYNC_SAUTH_INTERNAL_H__
#define __VESYNC_SAUTH_INTERNAL_H__

#ifdef __cplusplus
extern "C"
{
#endif

/**
 * @brief Sauth查询是否已注册
 * @return      true            [已注册]
 * @return      false           [未注册]
 */
bool vesync_sauth_is_reg(void);

/**
 * @brief Sauth查询是否已登录
 * @return      true            [已登录]
 * @return      false           [未登录]
 */
bool vesync_sauth_is_login(void);

/**
 * @brief Sauth模块初始化
 * @return      int             [成功：SDK_OK；失败：SDK_FAIL]
 */
int vesync_sauth_init(void);

/**
 * @brief Sauth模块恢复出厂状态
 * @return      int             [成功：SDK_OK；失败：SDK_FAIL]
 */
int vesync_sauth_clear(void);

/**
 * @brief Sauth加密会话数据，需要完成登录
 * @param[in]   p_in            [指向输入待加密数据的缓存]
 * @param[in]   in_len          [待加密数据长度]
 * @param[out]  p_out           [指向输出加密后数据的缓存]
 * @param[out]  out_len         [输出加密数据的缓存大小，长度要大于
 *                                  in_len + SAUTH_SESSION_UPCNT_SIZE
 *                                  + SAUTH_SESSION_ENC_DEC_TAG_SIZE]
 * @return      int             [成功：SDK_OK；失败：SDK_FAIL]
 */
int vesync_sauth_session_encrypt(const uint8_t *p_in, uint16_t in_len, uint8_t *p_out, uint16_t out_len);

/**
 * @brief Sauth解密会话数据，需要完成登录
 * @param[in]   p_in            [指向输入待解密数据的缓存]
 * @param[in]   in_len          [待解密数据长度]
 * @param[out]  p_out           [指向输出解密后数据的缓存]
 * @param[out]  out_len         [输出解密数据的缓存大小，长度要大于
 *                                  in_len - SAUTH_SESSION_UPCNT_SIZE
 *                                  - SAUTH_SESSION_ENC_DEC_TAG_SIZE]
 * @return      int             [成功：SDK_OK；失败：SDK_FAIL]
 */
int vesync_sauth_session_decrypt(const uint8_t *p_in, uint16_t in_len, uint8_t *p_out, uint16_t out_len);

#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_SAUTH_INTERNAL_H__ */
