/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_netcfg_recv.c
 * @brief       配网模块的协议处理
 * @author      Louis
 * @date        2021-05-21
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "cJSON.h"

#include "vhal_utils.h"

#include "vesync_utils.h"
#include "vesync_memory.h"
#include "vesync_tl_frame_parse.h"
#include "vesync_cfg_internal.h"
#include "vesync_device.h"
#include "vesync_common.h"
#include "vesync_aes.h"
#include "vesync_rsa.h"
#include "vesync_base64.h"
#include "vesync_log_internal.h"
#include "vesync_event_internal.h"
#include "vesync_wifi_scan.h"
#include "vesync_net_service_internal.h"
#include "vesync_netcfg_internal.h"
#include "vesync_netcfg_send.h"
#include "vesync_netcfg_recv.h"
#include "vesync_json_internal.h"


// AES秘钥更新标志位，true表示秘钥已更新（非默认秘钥）
static bool s_aes_key_updated= false;
// 配网configkey
static uint8_t s_netcfg_key[NETCFG_KEY_LEN]=  {0};
// 上一次配网失败的原因
static int32_t s_errno = -1;
// aplist回复标志，true表示可回复（默认false不可回复）
static bool s_aplist_reply_flag = false;

// AES初始密钥
static uint8_t aes_init_key[] = {0x6c, 0x6c, 0x77, 0x61, 0x6e, 0x74, 0x61, 0x65, 0x73, 0x6b, 0x65, 0x79, 0x31, 0x2e, 0x30, 0x31};
static uint8_t aes_init_iv[]  = {0x6c, 0x6c, 0x77, 0x61, 0x6e, 0x74, 0x61, 0x65, 0x73, 0x69, 0x76, 0x76, 0x31, 0x2e, 0x30, 0x31};



/**
 * @brief  解析公钥
 * @param[in]  p_data           [数据]
 * @param[in]  data_len         [长度]
 * @param[out] public           [公钥]
 * @param[in]  buf_len          [公钥buf长度]
 * @return     int              [解析公钥成功或失败]
 */
static int vesync_netcfg_get_public_key(uint8_t *p_data, uint16_t data_len, char *public, uint16_t buf_len)
{
    int ret = SDK_FAIL;
    uint32_t decrypt_len = 0;
    uint8_t *decrypt_data = NULL;
    cJSON *root = NULL, *key = NULL;

    decrypt_len = vesync_aes_decrypt(p_data, data_len, &decrypt_data);
    if (0 == decrypt_len)
    {
        goto exit;
    }

    root = cJSON_Parse((const char *)decrypt_data);
    if(NULL == root)
    {
        goto exit;
    }

    key = cJSON_GetObjectItemCaseSensitive(root, "key");
    if(cJSON_IsString(key))
    {
        strncpy(public, key->valuestring, buf_len - 1);
        ret = SDK_OK;
    }

exit:
    if (NULL != root)
    {
        cJSON_Delete(root);
    }

    VCOM_SAFE_FREE(decrypt_data);
    return ret;
}


/**
 * @brief  通过随机数生成128 bytes AES密钥
 * @param[out] p_key            [密钥]
 * @param[in]  size             [长度]
 */
static void vesync_generate_aes_key(uint8_t *p_key, uint32_t size)
{
    int i = 0, j = 0;
    bool flag = false;

    if (NULL == p_key)
    {
        SDK_LOG(LOG_ERROR, "pkey null\r\n");
        return;
    }

    for (i = 0; i < 10; i++)
    {
        vhal_utils_get_random(p_key, size);
        for (j = 0; j < size; j++)
        {
            if (0x0 == p_key[j])
            {
                break;
            }
        }

        if (j >= size)
        {
            flag = true;
            break;      // 已经生成合法的秘钥
        }
    }

    // 10次都没生成合法的秘钥，采用默认秘钥
    if (!flag)
    {
        for (j = 0; j < size; j++)
        {
            p_key[j] = aes_init_key[j];
        }
        SDK_LOG(LOG_WARN, "Use default AES key.\n");
    }
}


/**
 * @brief  密钥协商处理，并返回给app
 * @param[in]  p_data           [数据]
 * @param[in]  data_len         [长度]
 * @return     int              [密钥协商成功或失败]
 */
static int vesync_netcfg_key_exchange(uint8_t *p_data, uint16_t data_len)
{
    int ret = SDK_FAIL;

    uint32_t rsa_enc_len = 0;
    uint32_t b64_enc_len = 0;

    cJSON *root = NULL;
    char *p_enc_msg = NULL;
    char *p_public_key_pem = NULL;
    char *p_base64_buf = NULL;
    uint8_t aes_new[VESYNC_NETCFG_AES_KEY_LEN] = {0};

    if (NULL == p_data)
    {
        SDK_LOG(LOG_ERROR, "null pointer!\r\n");
        goto exit;
    }

    p_public_key_pem = (char *)vesync_malloc(VESYNC_NETCFG_PUB_KEY_PEM_LEN);
    p_base64_buf = (char *)vesync_malloc(VESYNC_NETCFG_BASE64_BUF_LEN);
    if (NULL == p_public_key_pem || NULL == p_base64_buf)
    {
        SDK_LOG(LOG_ERROR, "Malloc fail!\r\n");
        goto exit;
    }
    memset(p_public_key_pem, 0, VESYNC_NETCFG_PUB_KEY_PEM_LEN);
    memset(p_base64_buf, 0, VESYNC_NETCFG_BASE64_BUF_LEN);

    vesync_aes_reg_key(aes_init_key, aes_init_iv);     //注册初始密钥

    if (SDK_OK != vesync_netcfg_get_public_key(p_data, data_len, p_public_key_pem, VESYNC_NETCFG_PUB_KEY_PEM_LEN))
    {
        SDK_LOG(LOG_ERROR, "decrypt public key fail\n");
        goto exit;
    }

    vesync_generate_aes_key(aes_new, sizeof(aes_new));           // 生成新秘钥

    // 秘钥进行RSA加密
    p_enc_msg = (char*)vesync_malloc(256);
    if (NULL == p_enc_msg)
    {
        goto exit;
    }
    memset(p_enc_msg, 0, 256);
    rsa_enc_len = 0;

    if(SDK_OK != vesync_rsa_pk_encrypt((uint8_t *)aes_new, sizeof(aes_new), (uint8_t *)p_enc_msg,
            (size_t*)(&rsa_enc_len), 256, p_public_key_pem, strlen(p_public_key_pem)+1))
    {
        SDK_LOG(LOG_ERROR, "rsa encrypt fail\n");
        goto exit;
    }
    SDK_LOG(LOG_DEBUG, "rsa encrypt success, encrypt_msg_len = %d\n", rsa_enc_len);

    // 进行base64加密
    if(SDK_OK != vesync_base64_encode((unsigned char *)p_base64_buf, VESYNC_NETCFG_BASE64_BUF_LEN,
                                    (size_t*)(&b64_enc_len), (unsigned char *)p_enc_msg, rsa_enc_len))
    {
        SDK_LOG(LOG_ERROR, "base64 encrypt fail\n");
        goto exit;
    }
    SDK_LOG(LOG_DEBUG, "b64_enc_len = %d\n", b64_enc_len);

    // 数据发送
    root = cJSON_CreateObject();
    if(NULL == root)
    {
        goto exit;
    }
    cJSON_AddStringToObject(root, "key", p_base64_buf);
    cJSON_AddStringToObject(root, "iv", p_base64_buf);
    vesync_netcfg_send_data(OP_KEY_EXCHANGE, MTYPE_ACK, root);

    // 注册新的aes密钥, 用于以后的通信加密
    vesync_aes_reg_key(aes_new, aes_new);

    ret = SDK_OK;

exit:
    VCOM_SAFE_FREE(p_public_key_pem);
    VCOM_SAFE_FREE(p_base64_buf);
    VCOM_SAFE_FREE(p_enc_msg);

    if (NULL != root)
    {
        cJSON_Delete(root);
    }

    return ret;
}


/**
 * @brief  查询设备信息应答
 */
static void vesync_netcfg_handle_devinfo(void)
{
    cJSON *root = NULL;
    net_info_t netcfg_info;
    char mac_str[MAC_ADDR_STR_MAX_LEN] = {0};

    root = cJSON_CreateObject();
    if(NULL == root)
    {
        return;
    }

    cJSON_AddStringToObject(root, "firmVersion", vesync_cfg_get_fw_version());
#if 1
    cJSON_AddStringToObject(root, "deviceType", vesync_cfg_get_model());
#else
    cJSON_AddStringToObject(root, "deviceType", vesync_cfg_get_alias_model());
#endif
    cJSON_AddStringToObject(root, "cid", vesync_device_get_cid());

    memset(&netcfg_info, 0, sizeof(netcfg_info));
    if(SDK_OK != vesync_net_flash_read_net_info(&netcfg_info) || strlen((char *)netcfg_info.wifiSSID) < 1)
    {
        /* 1st time to use or reset device config. */
        cJSON_AddNumberToObject(root, "networkStatus", 0);
        cJSON_AddStringToObject(root, "accountId", "");
    }
    else
    {
        cJSON_AddNumberToObject(root, "networkStatus", 1);
        cJSON_AddStringToObject(root, "accountId", vesync_device_get_account_id());
    }

    vhal_utils_get_dev_mac(VHAL_MAC_WIFI_STA, mac_str, sizeof(mac_str));
    // if fail to get mac, it would be "deviceMac":    ""
    cJSON_AddStringToObject(root, "deviceMac", mac_str);
    cJSON_AddStringToObject(root, "deviceRegion", vesync_cfg_get_country_code());

    vesync_netcfg_send_data(OP_QUERY_INFO, MTYPE_ACK, root);
    cJSON_Delete(root);
}


/**
 * @brief  查询WiFi列表消息处理
 * @param[in]  p_data           [命令的payload]
 * @param[in]  data_len         [命令的payload长度]
 */
static void vesync_netcfg_handle_aplist(char *p_data, uint32_t data_len)
{
    uint16_t page = 0;
    uint32_t decrypt_len = 0;
    uint8_t *decrypt_data = NULL;
    cJSON *root = NULL, *item = NULL;

    if(NULL == p_data)
    {
        SDK_LOG(LOG_ERROR, "p_data null\r\n");
        return;
    }

    decrypt_len = vesync_aes_decrypt((uint8_t *)p_data, data_len, &decrypt_data);
    if (0 == decrypt_len)
    {
        goto exit;
    }

    root = cJSON_Parse((const char *)decrypt_data);
    if(NULL == root)
    {
        SDK_LOG(LOG_ERROR, "Not json msg\n");
        vesync_netcfg_send_error(OP_QUERY_WIFI_LIST, TL_FRAME_OPCODE_FORMAT_ERR);
        goto exit;
    }

    item = cJSON_GetObjectItemCaseSensitive(root, "page");
    if(cJSON_IsNumber(item) == true)
    {
        page = item->valueint;
    }
    else
    {
        SDK_LOG(LOG_ERROR, "page(%d) is invaild!\n", page);
        goto exit;
    }
    SDK_LOG(LOG_DEBUG, "page = %d.\n", page);

    if(page == 1)
    {
        // only parse "needScan" in page 1 query
        item = cJSON_GetObjectItemCaseSensitive(root, "needScan");
        if(cJSON_IsNumber(item) && 1 == item->valueint) // rescan when "needScan" is 1
        {
            s_aplist_reply_flag = true;
            vesync_wifi_scan_start();
            goto exit;
        }
    }

    s_aplist_reply_flag = true;
    vesync_netcfg_reply_aplist(page);

exit:
    VCOM_SAFE_FREE(decrypt_data);
    if (NULL != root)
    {
        cJSON_Delete(root);
    }
}


/**
 * @brief  设置服务器地址与端口
 * @param[in] addr_str               [服务器地址与端口字符串]
 * @param[in] serverDN               [服务器地址]
 * @param[in] server_port            [端口]
 * @return  int                      [成功：VERR_OK，失败：VERR_FAIL]
 */
static int vesync_netcfg_set_srv_info(char *addr_str, uint8_t **serverDN, uint32_t *server_port)
{
    if (addr_str == NULL || *serverDN == NULL || server_port == NULL)
    {
        return SDK_FAIL;
    }

    int default_port = vesync_net_client_get_default_port();
    if (default_port < 0)
    {
        SDK_LOG(LOG_ERROR, "default port error\n");
        return SDK_FAIL;
    }

    *server_port = default_port;

    char *srv_idx = NULL;
    char *port_idx = NULL;
    char *idx = strstr(addr_str, "://");
    srv_idx = (idx != NULL) ? idx + 3 : addr_str;
    port_idx = strstr(srv_idx, ":");
    if (port_idx != NULL)
    {
        VCOM_IN_RANGE_CHK(port_idx - srv_idx, 1, SERVER_DOMAIN_NAME_LEN, return SDK_FAIL);
        strncpy((char*)*serverDN, srv_idx, port_idx - srv_idx);
        (*serverDN)[port_idx - srv_idx] = '\0';
        *server_port = atoi(port_idx + 1);
        VCOM_IN_RANGE_CHK(*server_port, 1024, 65535, return SDK_FAIL);
    }
    else
    {
        VCOM_IN_RANGE_CHK(strlen(addr_str), 1, SERVER_DOMAIN_NAME_LEN, return SDK_FAIL);
        strncpy((char*)*serverDN, srv_idx, strlen(addr_str));
        (*serverDN)[strlen(addr_str)] = '\0';
    }

    SDK_LOG(LOG_DEBUG, "serverDN: %s, server port: %d\n", *serverDN, *server_port);
    return SDK_OK;
}


/**
 * @brief  设置配网消息处理
 * @param[in]  p_data           [命令的payload]
 * @param[in]  data_len         [命令的payload长度]
 */
static int vesync_netcfg_handle_cfginfo(char *p_data, uint32_t data_len)
{
    int ret = SDK_FAIL;
    int need_reset = 0;
    uint32_t decrypt_len = 0;
    uint8_t *decrypt_data = NULL;
    cJSON *root = NULL, *item = NULL;
    net_info_t *p_net_cfg = NULL;

    if(NULL == p_data)
    {
        return SDK_FAIL;
    }

    decrypt_len = vesync_aes_decrypt((uint8_t *)p_data, data_len, &decrypt_data);
    if (0 == decrypt_len)
    {
        goto exit;
    }

    p_net_cfg = vesync_net_mgmt_get_net_cfg();

    root = cJSON_Parse((const char *)decrypt_data);
    if(NULL == root)
    {
        vesync_netcfg_send_error(OP_CONFIG_INFO, TL_FRAME_OPCODE_FORMAT_ERR);
        goto exit;
    }

    /// @attention: 调试用途
    vesync_json_print(root);

#if 0
    item = cJSON_GetObjectItemCaseSensitive(root, "pid");
    if(true == cJSON_IsString(item))
    {
        strncpy((char*)s_net_cfg->pid, item->valuestring, sizeof(s_net_cfg->pid) - 1);
        SDK_LOG(LOG_DEBUG, "pid: %s\r\n", (char*)s_net_cfg->pid);
    }
#endif

    item = cJSON_GetObjectItemCaseSensitive(root, "configKey");
    if(true == cJSON_IsString(item))
    {
        strncpy((char*)p_net_cfg->configKey, item->valuestring, sizeof(p_net_cfg->configKey) - 1);
        strncpy((char *)s_netcfg_key, item->valuestring, sizeof(s_netcfg_key) - 1);
        SDK_LOG(LOG_DEBUG, "configKey: %s\n", (char*)p_net_cfg->configKey);
    }

    item = cJSON_GetObjectItemCaseSensitive(root, "serverDN");
    if(true == cJSON_IsString(item))
    {
        uint8_t *p_serverDN = p_net_cfg->serverDN;
        vesync_netcfg_set_srv_info(item->valuestring, &p_serverDN, &(p_net_cfg->serverPort));
    }

    item = cJSON_GetObjectItemCaseSensitive(root, "serverIP");
    if(true == cJSON_IsString(item))
    {
        strncpy((char*)p_net_cfg->serverIP, item->valuestring, sizeof(p_net_cfg->serverIP) - 1);
        SDK_LOG(LOG_DEBUG, "serverIP: %s\n", p_net_cfg->serverIP);
    }

    item = cJSON_GetObjectItemCaseSensitive(root, "wifiSSID");
    if(true == cJSON_IsString(item))
    {
        strncpy((char*)p_net_cfg->wifiSSID, item->valuestring, sizeof(p_net_cfg->wifiSSID) - 1);
        SDK_LOG(LOG_DEBUG, "wifiSSID: %s\n", p_net_cfg->wifiSSID);
    }

    item = cJSON_GetObjectItemCaseSensitive(root, "wifiPassword");
    if(true == cJSON_IsString(item))
    {
        strncpy((char*)p_net_cfg->wifiPassword, item->valuestring, sizeof(p_net_cfg->wifiPassword) - 1);
        SDK_LOG(LOG_DEBUG, "wifiPassword: %s\n", p_net_cfg->wifiPassword);
    }

    item = cJSON_GetObjectItemCaseSensitive(root, "accountID");
    if(true == cJSON_IsString(item))
    {
        strncpy((char*)p_net_cfg->account_id, item->valuestring, sizeof(p_net_cfg->account_id) - 1);
        vesync_device_set_account_id((char*)p_net_cfg->account_id);
        SDK_LOG(LOG_DEBUG, "accountId: %s\n", p_net_cfg->account_id);
    }

    item = cJSON_GetObjectItemCaseSensitive(root, "needReset");
    if(true == cJSON_IsNumber(item))
    {
         need_reset = item->valueint;
         vesync_netcfg_set_reset_flag(0 == need_reset ? false : true);
    }

    char info_buffer[64] = {0};
#if 0
    SDK_LOG(LOG_DEBUG,"CID LEN:%d (%d) \r\n", strlen(vesync_device_info_get_str(FLAG_DEV_INFO_DEV_CID)), DEVICE_CID_LEN);
#endif
    if(strlen(vesync_device_get_cid()) != DEVICE_CID_LEN)
    {
        SDK_LOG(LOG_ERROR, "CID was missed !\r\n");
        strncpy(info_buffer, "CONFIG_CID_MISSED", sizeof(info_buffer) - 1);
        vesync_netcfg_prot_report_result(ERR_CONFIG_CID_MISSED, info_buffer);
        goto exit;
    }
    else if(strlen((char*)p_net_cfg->wifiSSID) == 0)
    {
        SDK_LOG(LOG_ERROR, "Config wifi ssid was missed !\r\n");
        strncpy(info_buffer, "CONFIG_WIFI_SSID_MISSED", sizeof(info_buffer) - 1);
        vesync_netcfg_prot_report_result(ERR_CONFIG_WIFI_SSID_MISSED, info_buffer);
        goto exit;
    }
    else if(strlen((char*)p_net_cfg->configKey) == 0)
    {
        SDK_LOG(LOG_ERROR, "Config key was missed !\r\n");
        strncpy(info_buffer, "CONFIG_CONFIGKEY_MISSED", sizeof(info_buffer) - 1);
        vesync_netcfg_prot_report_result(ERR_CONFIG_CONFIGKEY_MISSED, info_buffer);
        goto exit;
    }
    else if(strlen((char*)p_net_cfg->serverDN) == 0)
    {
        SDK_LOG(LOG_ERROR, "Config server domain was missed !\r\n");
        strncpy(info_buffer, "CONFIG_SERVER_DOMAIN_MISSED", sizeof(info_buffer) - 1);
        vesync_netcfg_prot_report_result(ERR_CONFIG_SERVER_DOMAIN_MISSED, info_buffer);
        goto exit;
    }
    else
    {
        // 加密类型
        vesync_bss_info_t *bss_info = vesync_wifi_get_apinfo_by_ssid(p_net_cfg->wifiSSID);
        p_net_cfg->auth_mode = bss_info ? bss_info->authmode : VHAL_WIFI_AUTH_WPA_WPA2_PSK;
#if 0
        SDK_LOG(LOG_DEBUG, "auth_mode = %d.\r\n", p_config_net_cfg->station_config.auth_mode);
#endif
        SDK_LOG(LOG_INFO, "Add remain config.\r\n");

        ret = SDK_OK;
    }

exit:
    if (NULL != root)
    {
        cJSON_Delete(root);
    }
    VCOM_SAFE_FREE(decrypt_data);

    return ret;
}


/**
 * @brief  查询配网失败的原因
 */
static void vesync_netcfg_handle_fail_info(void)
{
    cJSON *root = NULL;
    cJSON *json_arr = NULL;
    cJSON *json_data = NULL;

    root = cJSON_CreateObject();
    if(NULL == root)
    {
        return;
    }

    if (strlen((char *)s_netcfg_key) < 1)
    {
        cJSON_AddNullToObject(root, "configKey");
    }
    else
    {
        cJSON_AddStringToObject(root, "configKey", (char *)s_netcfg_key);
    }

    cJSON_AddItemToObject(root, "logList", json_arr =  cJSON_CreateArray());
    if (NULL != json_arr && s_errno > 0)
    {
        cJSON_AddItemToArray(json_arr, json_data = cJSON_CreateObject());
        if (NULL != json_data)
        {
            cJSON_AddNumberToObject(json_data,"err", s_errno);

            switch(s_errno)
            {
            case ERR_CONFIG_NO_AP_FOUND:
                cJSON_AddStringToObject(json_data, "description", "ERR_CONFIG_NO_AP_FOUND");
                break;
            case ERR_CONFIG_WRONG_PASSWORD:
                cJSON_AddStringToObject(json_data, "description", "ERR_CONFIG_WRONG_PASSWORD");
                break;
            case ERR_CONFIG_CONNECT_WIFI_FAIL:
                cJSON_AddStringToObject(json_data, "description", "ERR_CONFIG_CONNECT_WIFI_FAIL");
                break;
            case ERR_CONFIG_GET_IP_FAIL:
                cJSON_AddStringToObject(json_data, "description", "ERR_CONFIG_GET_IP_FAIL");
                break;
            case ERR_CONFIG_DNS_RESOLVE_FAIL:
                cJSON_AddStringToObject(json_data, "description", "ERR_CONFIG_DNS_RESOLVE_FAIL");
                break;
            case ERR_CONFIG_CONNECT_SERVER_FAIL:
                cJSON_AddStringToObject(json_data, "description", "ERR_CONFIG_CONNECT_SERVER_FAIL");
                break;
            case ERR_CONFIG_SUBSCRIBE_FAIL:
                cJSON_AddStringToObject(json_data, "description", "ERR_CONFIG_SUBSCRIBE_FAIL");
                break;
            default:
                cJSON_AddStringToObject(json_data, "description", "ERR_CONFIG_TIMEOUT_FAIL");
                break;
            }
        }
    }

    vesync_netcfg_send_data(OP_QUERY_FAIL_INFO, MTYPE_ACK, root);

    cJSON_Delete(root);
}


/**
 * @brief  关闭AP热点命令处理
 */
static void vesync_netcfg_handle_close_ap(void)
{
    cJSON *root = cJSON_CreateObject();
    if(NULL != root)
    {
        cJSON_AddStringToObject(root, "result", 0);
        vesync_netcfg_send_data(OP_CLOSE_AP, MTYPE_ACK, root);
        cJSON_Delete(root);
    }

    vhal_wifi_stop_ap_mode();
}


/**
 * @brief  业务消息转发
 * @param[in]  opcode       [操作码]
 * @param[in]  p_data       [数据指针]
 * @param[in]  data_len     [数据长度(注意，不带4bytes的头部)]
 */
static void vesync_netcfg_forwarding(uint16_t opcode, uint8_t *p_data, uint32_t data_len)
{
    vesync_ev_t ev = {0};

    if (NULL == p_data)
    {
        SDK_LOG(LOG_ERROR, "p_data null\r\n");
        return;
    }

    SDK_LOG(LOG_DEBUG, "opcode = 0x%04x, flag = %d\r\n", opcode, s_aes_key_updated);
    // 秘钥未更新，不允许进行配网
    if (OP_KEY_EXCHANGE != opcode && false == s_aes_key_updated)
    {
        vesync_netcfg_send_error(opcode, TL_FRAME_PAYLOAD_DECRYPT_FAIL);
        return;
    }

    switch (opcode)
    {
    case OP_KEY_EXCHANGE:
        if(SDK_OK == vesync_netcfg_key_exchange(p_data, data_len))
        {
            s_aes_key_updated = true;       // AES秘钥更新成功
            SDK_LOG(LOG_INFO, "key_exchange success.\n");
        }
        else
        {
            s_aes_key_updated = false;       // AES秘钥更新失败
            SDK_LOG(LOG_ERROR, "key_exchange fail\n");
        }
        break;

    case OP_QUERY_INFO:
        vesync_netcfg_handle_devinfo();
        break;

    case OP_QUERY_WIFI_LIST:
        vesync_netcfg_handle_aplist((char *)p_data, data_len);
        break;

    case OP_CONFIG_INFO:
        if(SDK_OK == vesync_netcfg_handle_cfginfo((char *)p_data, data_len))
        {
            VESYNC_POPULATE_EV(ev, EVENT_NETCFG_RECEIVE_CONFIG, NETCFG_TASK_NAME, 0, NULL);
            vesync_event_publish(&ev);
            vesync_netcfg_send_data(opcode, MTYPE_ACK, NULL);
        }
        break;

    case OP_CANCLE_CONFIG:
        VESYNC_POPULATE_EV(ev, EVENT_NETCFG_APP_CANCEL, NETCFG_TASK_NAME, 0, NULL);
        vesync_event_publish(&ev);
        break;

    case OP_QUERY_FAIL_INFO:
        vesync_netcfg_handle_fail_info();
        break;

    case OP_CLOSE_AP:
        vesync_netcfg_handle_close_ap();
        break;

    default:
        vesync_netcfg_send_error(opcode, TL_FRAME_OPCODE_NOT_SUPPORT);
        break;
    }
}


void vesync_netcfg_ble_recv_cb(uint8_t *p_data, uint16_t len, bool need_ack)
{
    if(NULL == p_data)
    {
        return;
    }

    payload_info_t *netcfg_pl = (payload_info_t *)p_data;
    uint32_t netcfg_pl_len = len;
    if(netcfg_pl_len < sizeof(payload_info_t))
    {
        SDK_LOG(LOG_ERROR, "invalid netcfg_payload:%d\n", netcfg_pl_len);
        return;
    }

    // UART/BLE通信用的小端字节序
    uint16_t opcode = vesync_le16toh(netcfg_pl->opcode);
    // 版本判断
    if (netcfg_pl->version != vesync_netcfg_config_get_protocol_version())
    {
        SDK_LOG(LOG_ERROR, "version(0x%02x) not support!\n", netcfg_pl->version);
        vesync_netcfg_send_error(opcode, TL_FRAME_VER_NOT_SUPPORT);
        return;
    }

    // 计算配网的数据长度
    uint32_t netcfg_data_len = netcfg_pl_len - sizeof(payload_info_t);
    // 根据opcode进行业务转发
    vesync_netcfg_forwarding(opcode, netcfg_pl->payload_data, netcfg_data_len);
}


/**
 * @brief AP配网时局域网收包入口
 * @param[in]  p_data       [配网信息的指针]
 * @param[in]  data_len     [配网信息长度]
 */
void vesync_netcfg_lan_recv_cb(uint8_t *p_data, uint32_t data_len)
{
    if(NULL == p_data || data_len < sizeof(payload_info_t))
    {
        SDK_LOG(LOG_ERROR, "invalid netcfg_payload: %d\n", data_len);
        return;
    }

    payload_info_t *netcfg_pl = (payload_info_t *)p_data;
    // WIFI（局域网）通信用的是大端字节序
    uint16_t opcode = vesync_be16toh(netcfg_pl->opcode);
    // 版本判断
    if (netcfg_pl->version != vesync_netcfg_config_get_protocol_version())
    {
        SDK_LOG(LOG_ERROR, "version(0x%02x) not support!\n", netcfg_pl->version);
        vesync_netcfg_send_error(opcode, TL_FRAME_VER_NOT_SUPPORT);
        return;
    }

    // 计算配网的数据长度
    uint32_t netcfg_data_len = data_len - sizeof(payload_info_t);
    // 根据opcode进行业务转发
    vesync_netcfg_forwarding(opcode, netcfg_pl->payload_data, netcfg_data_len);
}


/**
 * @brief 配网结果上报
 * @param[in]  err_code         [错误码]
 * @param[in]  err_describe     [错误描述]
 */
void vesync_netcfg_prot_report_result(const int err_code, const char *err_describe)
{
    cJSON *root = NULL;
    root = cJSON_CreateObject();
    if(NULL == root)
    {
        return;
    }

    cJSON_AddNumberToObject(root,"err", err_code);
    cJSON_AddStringToObject(root, "description", err_describe);

    vesync_netcfg_send_data(OP_NETCFG_RESULT, MTYPE_REPORT, root);
    cJSON_Delete(root);

    // 存储失败错误码，待下次配网时回传给APP；配网成功后删除configKey
    s_errno = err_code;
    if (ERR_CONFIG_NET_SUCCESS == s_errno)
    {
        memset((char *)s_netcfg_key, 0, sizeof(s_netcfg_key));
    }
}


/**
 * @brief 配网wifi列表返回
 * @param page      [需要返回的页码数]
 */
void vesync_netcfg_reply_aplist(const uint16_t page)
{
    cJSON *root = NULL, *wifiList = NULL;
    uint16_t total_page = 0;
    uint16_t total_num = 0;

    if (!s_aplist_reply_flag)
    {
        return;
    }
    s_aplist_reply_flag = false;
    total_num = vesync_wifi_aplist_get_num();
    if(0 == total_num)
    {
        //返回wifi列表空
        root = cJSON_CreateObject();
        if(root)
        {
            cJSON_AddNumberToObject(root, "result", -1);
        }
        goto exit;
    }

    // 一页最多传输16个AP信息
    total_page = (total_num + 15) / 16;

    if(0 == page)
    {
        root = cJSON_CreateObject();
        if(root)
        {
            cJSON_AddNumberToObject(root, "result", -1);
        }
        goto exit;
    }
    else if(page > total_page)      //页码数超出
    {
        root = cJSON_CreateObject();
        if(root)
        {
            cJSON_AddNumberToObject(root, "result", -2);
        }
        goto exit;
    }

    root = cJSON_CreateObject();
    if(NULL == root)
    {
        goto exit;
    }

    cJSON_AddNumberToObject(root, "result", 0);
    cJSON_AddNumberToObject(root, "totalPage", total_page);
    cJSON_AddNumberToObject(root, "currentPage", page);
    cJSON_AddItemToObject(root, "wifiList", wifiList =  cJSON_CreateArray());
    if(NULL != wifiList)
    {
        uint16_t ap_index = 0;
        for (ap_index = (page - 1) * 16;
             ap_index < page * 16 && ap_index < total_num;
             ap_index++)
        {
            vesync_bss_info_t* apinfo = vesync_wifi_get_apinfo_by_index(ap_index);

            cJSON *wifiList_root = cJSON_CreateObject();
            if (NULL != wifiList_root)
            {
                cJSON_AddStringToObject(wifiList_root, "SSID", (const char * const)apinfo->ssid);
                cJSON_AddNumberToObject(wifiList_root, "AUTH", apinfo->authmode);
                cJSON_AddNumberToObject(wifiList_root, "RSSI", apinfo->rssi);
                cJSON_AddItemToArray(wifiList, wifiList_root);
            }
        }
    }

exit:
    if(NULL == root)
    {
        return;
    }

    vesync_netcfg_send_data(OP_QUERY_WIFI_LIST, MTYPE_ACK, root);
    cJSON_Delete(root);
}


/**
 * @brief 配网接收处理模块退出处理
 */
void vesync_netcfg_recv_deinit(void)
{
    // 重置密钥更新标志
    s_aes_key_updated = false;
    // 重置aplist回复标志
    s_aplist_reply_flag = false;
}
