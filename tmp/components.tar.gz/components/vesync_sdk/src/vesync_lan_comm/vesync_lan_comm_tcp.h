/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_tcp.h
 * @brief       局域网通信-TCP模块
 * @author      henrikzhou
 * @date        2020-9-21
 */

#ifndef _VESYNC_LAN_COMM_TCP_H_
#define _VESYNC_LAN_COMM_TCP_H_

#if defined(CONFIG_TARGET_LINUX)
#include <netinet/in.h>
#else
#include "lwip/sockets.h"
#endif

#ifdef __cplusplus
extern "C" {
#endif


#define VESYNC_TCP_SERVER_KEEPALIVE     (1)     // enable/disable keepalive
#define VESYNC_TCP_SERVER_KEEPIDLE      (10)     // if 5s no data recv from client, send keep-alive probe packet
#define VESYNC_TCP_SERVER_KEEPINTV      (2)     // every 1s to send keep-alive probe packet
#define VESYNC_TCP_SERVER_KEEPCNT       (5)     // send 3 times keep-alive probe packet


/**
 * @brief 初始化TCP server
 * @param[in] addr              [tcp server socket 结构体地址]
 * @param[in] fd                [tcp sever socket 句柄指针]
 * @param[in] port              [tcp sever 端口]
 * @param[in] listen_num        [tcp sever 监听未连接队列长度]
 * @return int                  [成功/失败]
 */
int vesync_tcp_sever_init(struct sockaddr_in* addr, int* fd,uint32_t port,int listen_num );

/**
 * @brief TCP server 连接监听接口
 * @param[in] fd                [tcp sever socket 句柄指针]
 * @param[in] accept_fd         [tcp 连接句柄指针]
 * @param[in] tcp_addr          [tcp server socket 结构体地址]
 * @param[in] timeout_ms        [tcp server 连接监听超时时间，单位毫秒]
 * @return int                  [成功/失败]
 */
int vesync_tcp_sever_accept( int fd,int *accept_fd,struct sockaddr_in* tcp_addr,int timeout_ms);

/**
 * @brief TCP server 数据接收监听接口
 * @param[in] fd                [tcp 连接句柄]
 * @param[in] timeout_ms        [tcp server 数据接收监听超时时间，单位毫秒]
 * @param[out] buffer           [tcp 数据接收缓存起始地址]
 * @param[in]  len              [数据接收缓存的最大长度]
 * @return int                  [成功/失败/实际接收数据长度]
 */
int  vesync_tcp_recv(int fd,int timeout,char*buffer,int len );

/**
 * @brief 获取TCP server  连接状态
 * @param[in] fd             [tcp sever 句柄]
 * @return int               [连接/断开，0:连接/-1:断开]
 */
int  vesync_get_tcp_conn_state(int fd);


/**
 * @brief 关闭TCP 连接或者 tcp server
 * @param[in] fd             [tcp 句柄指针]
 */
void vesync_tcp_stop(int* fd);

#ifdef __cplusplus
}
#endif

#endif //_VESYNC_LAN_COMM_TCP_H_
