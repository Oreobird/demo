/**
*Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file    ledstrip_bypass.c
* @brief   应用层bypass处理
* @author  Lind
*@date     2021-09-09
*/

#include <stdint.h>
#include <string.h>

#include "vesync_common.h"
#include "vesync_log.h"
#include "vesync_memory.h"
#include "vesync_buffer.h"
#include "vesync_bypass.h"
#include "vesync_timing.h"
#include "vesync_device.h"

#include "ledstrip.h"
#include "ledstrip_timing.h"
#include "ledstrip_schedule.h"
#include "ledstrip_led.h"
#include "ledstrip_bypass.h"
#include "ledstrip_production.h"
#include "ledstrip_report.h"

static bool s_ls_voice_off_flag = false; // 第三方语音设置亮度为0，标志位（认证需求）


/**
* @brief 设置语音关闭标志位，
* @param[in]  flag          [true:语音导致灯带关闭;false:当前状态不是语音关闭]
*/
void ls_set_voice_off_flag(bool flag)
{
    s_ls_voice_off_flag = flag;
}

/**
* @brief 新增timer
* @note  新增bypass method
* @param[in]        p_msg_ctx       [bypass上下文]
* @param[in]        json            [传入json]
* @return           BYPASS_ERR_E    [错误码]
*/
static BYPASS_ERR_E ls_bp_add_timer(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    ls_timing_t* action = NULL;
    cJSON* json_data = NULL;
    cJSON* json_timer = NULL;
    cJSON* json_obj = NULL;
    cJSON* json_act = NULL;
    cJSON* json_type = NULL;
    uint8_t ret = 0;

    if (NULL == p_msg_ctx || NULL == p_msg_ctx->p_trace_msg || NULL == json)
    {
        APP_LOG(LOG_DEBUG, " addTimerV2 error \n");
        return BP_ERROR;
    }

    APP_LOG(LOG_DEBUG, "-------addTimerV2 handle--------\n");
    action = (ls_timing_t*)vesync_malloc(sizeof(ls_timing_t));
    if (NULL == action)
    {
        return BP_ERR_NOMEM;
    }
    memset(action, 0, sizeof(ls_timing_t));

    json_data = cJSON_GetObjectItemCaseSensitive(json, "total");
    if (cJSON_IsNumber(json_data))
    {
         action->total_sec = json_data->valueint;
         VCOM_IN_RANGE_CHK(action->total_sec, TIMER_SEC_MIN, TIMER_SEC_MAX, (ret++));
         if (ret)
         {
            vesync_free(action);
            return BP_ERR_ARG;
         }
    }
    else
    {
        vesync_free(action);
        return BP_ERR_ARG;
    }
    json_data = cJSON_GetObjectItemCaseSensitive(json, "startAct");
    if (!cJSON_IsArray(json_data))
    {
        vesync_free(action);
        return BP_ERR_ARG;
    }
    int arr_size = cJSON_GetArraySize(json_data);
    if (arr_size > 2)
    {
        vesync_free(action);
        return BP_ERR_ARG;
    }
    for (int i = 0; i < arr_size; i++)
    {
        json_obj = cJSON_GetArrayItem(json_data, i);
        if (NULL == json_obj)
        {
            vesync_free(action);
            return BP_ERR_ARG;
        }
        json_type = cJSON_GetObjectItemCaseSensitive(json_obj, "type");
        if (0 == strcmp(json_type->valuestring, "switch"))
        {
            json_act = cJSON_GetObjectItemCaseSensitive(json_obj, "act");
            if (0 == strcmp(json_act->valuestring, "off"))
            {
                action->mode = LS_MODE_OFF;
                break;
            }
        }
        else if (0 == strcmp(json_type->valuestring, "color_mode"))
        {
            json_act = cJSON_GetObjectItemCaseSensitive(json_obj, "act");
            if (!cJSON_IsString(json_act))
            {
                vesync_free(action);
                return BP_ERR_ARG;
            }

            cJSON *json_param = NULL;
            cJSON *json_temp = NULL;
            if (0 == strcmp(json_act->valuestring, "white"))
            {
                action->mode = LS_MODE_WHITE;
                json_param = cJSON_GetObjectItemCaseSensitive(json_obj, "params");
                if (NULL == json_param)
                {
                    vesync_free(action);
                    return BP_ERR_ARG;
                }

                json_temp = cJSON_GetObjectItemCaseSensitive(json_param, "colorTemp");
                if (json_temp->valueint > 100)
                {
                    vesync_free(action);
                    return BP_ERR_ARG;
                }
                (action->color).colortemp = json_temp->valueint;
                json_temp = cJSON_GetObjectItemCaseSensitive(json_param, "brightness");
                if (json_temp->valueint == 0)
                {
                    vesync_free(action);
                    return BP_ERR_ARG;
                }
                (action->color).brightness = json_temp->valueint;
            }
            else if(0 == strcmp(json_act->valuestring, "hsv"))
            {
                action->mode = LS_MODE_COLOR;
                json_param = cJSON_GetObjectItemCaseSensitive(json_obj, "params");
                if (NULL == json_param)
                {
                    vesync_free(action);
                    return BP_ERR_ARG;
                }
                json_temp = cJSON_GetObjectItemCaseSensitive(json_param, "hue");
                (action->color).H = json_temp->valueint;
                json_temp = cJSON_GetObjectItemCaseSensitive(json_param, "saturation");
                (action->color).S = json_temp->valueint;
                json_temp = cJSON_GetObjectItemCaseSensitive(json_param, "value");
                if (json_temp->valueint == 0)
                {
                    vesync_free(action);
                    return BP_ERR_ARG;
                }
                (action->color).V = json_temp->valueint;
            }
            else
            {
                vesync_free(action);
                return BP_ERR_ARG;
            }

            VCOM_IN_RANGE_CHK((action->color).colortemp, 0, LED_COLORTEMP_MAX, (ret++));
            VCOM_IN_RANGE_CHK((action->color).brightness, 0, LED_BRIGHTNESS_MAX, (ret++));
            VCOM_IN_RANGE_CHK((action->color).H, 0, LED_HS_PARAM_MAX, (ret++));
            VCOM_IN_RANGE_CHK((action->color).S, 0, LED_HS_PARAM_MAX, (ret++));
            VCOM_IN_RANGE_CHK((action->color).V, 0, LED_BRIGHTNESS_MAX, (ret++));
            if (ret != 0)
            {
                vesync_free(action);
                return BP_ERR_ARG;
            }
        }
        else
        {
            vesync_free(action);
            return BP_ERR_ARG;
        }
    }


    if (APP_OK == ls_timing_add(action->total_sec, &(action->id), action->mode, &(action->color)))
    {
        json_timer = cJSON_CreateObject();
        if (NULL != json_timer)
        {
            cJSON_AddNumberToObject(json_timer, "id", action->id);
            APP_LOG(LOG_DEBUG,"add timer %d\n", action->id);
            vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, json_timer);
        }
        else
        {
            vesync_free(action);
            return BP_ERR_NOMEM;
        }
    }
    else
    {
        vesync_free(action);
        return BP_ERROR;
    }
    return BP_OK;
}

/**
* @brief 获取timer
* @note  新增bypass method
* @param[in]        p_msg_ctx       [bypass上下文]
* @param[in]        json            [传入json]
* @return           BYPASS_ERR_E    [错误码]
*/
static BYPASS_ERR_E ls_bp_get_timer(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    BYPASS_ERR_E ret = BP_OK;
    uint16_t timer_id = 0;
    ls_timing_t *timing = NULL;
    cJSON *json_data = NULL;
    cJSON *json_timers = NULL;
    cJSON *json_timer = NULL;
    cJSON *json_arr = NULL;
    cJSON *json_mode = NULL;
    cJSON *json_action = NULL;
    cJSON *json_params = NULL;
    timing_data_t tm;
    memset(&tm, 0, sizeof(timing_data_t));

    if (NULL == p_msg_ctx || NULL == p_msg_ctx->p_trace_msg)
    {
        return BP_ERROR;
    }
    UNUSED(json);

    json_data = cJSON_CreateObject();
    if (NULL == json_data)
    {
        return BP_ERR_NOMEM;
    }
    cJSON_AddItemToObject(json_data, "timers", json_timers =  cJSON_CreateArray());
    if (NULL == json_timers)
    {
        ret = BP_ERR_NOMEM;
        goto exit;
    }

    timing = ls_timing_get_act();
    timer_id = timing->id;
    if (timer_id == 0)
    {
        vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, json_data);
        return BP_OK;
    }
    if (SDK_OK == vesync_timing_get(timer_id, &tm))
    {
        cJSON_AddItemToArray(json_timers, json_timer = cJSON_CreateObject());
        if (NULL == json_timer)
        {
            ret = BP_ERR_NOMEM;
            goto exit;
        }
        cJSON_AddNumberToObject(json_timer, "id", tm.timing_id);
        cJSON_AddNumberToObject(json_timer, "total", tm.total_second);
        cJSON_AddNumberToObject(json_timer, "remain", tm.remain_second);
        // package
        cJSON_AddItemToObject(json_timer, "startAct", json_arr = cJSON_CreateArray());
        cJSON_AddItemToArray(json_arr, json_mode = cJSON_CreateObject());
        if (NULL == json_arr || NULL == json_mode)
        {
            ret = BP_ERR_NOMEM;
            goto exit;
        }
        cJSON_AddStringToObject(json_mode, "type", "switch");
        cJSON_AddNumberToObject(json_mode, "num", 0);
        if (timing->mode == LS_MODE_OFF)
        {
            cJSON_AddStringToObject(json_mode, "act", "off");
        }
        else
        {
            cJSON_AddStringToObject(json_mode, "act", "on");
            cJSON_AddItemToArray(json_arr, json_action = cJSON_CreateObject());
            if (NULL == json_action)
            {
                ret = BP_ERR_OUT_OF_MEMORY;
                goto exit;
            }
            cJSON_AddItemToObject(json_action, "params",json_params = cJSON_CreateObject());
            if (NULL == json_params)
            {
                ret = BP_ERR_OUT_OF_MEMORY;
                goto exit;
            }
            cJSON_AddStringToObject(json_action, "type", "color_mode");
            cJSON_AddNumberToObject(json_action, "num", 0);
            if (timing->mode == LS_MODE_WHITE)
            {
                cJSON_AddStringToObject(json_action, "act", "white");
                cJSON_AddNumberToObject(json_params, "brightness", (timing->color).brightness);
                cJSON_AddNumberToObject(json_params, "colorTemp", (timing->color).colortemp);

            }
            else
            {
                cJSON_AddStringToObject(json_action, "act", "hsv");
                cJSON_AddNumberToObject(json_params, "hue", (timing->color).H);
                cJSON_AddNumberToObject(json_params, "saturation", (timing->color).S);
                cJSON_AddNumberToObject(json_params, "value", (timing->color).V);
            }
        }

    }

    vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, json_data);
    return BP_OK;

exit:
    vesync_bypass_reply_pkg_err_msg(ret, p_msg_ctx->p_trace_msg, NULL);
    cJSON_Delete(json_data);
    return ret;
}

/**
* @brief 删除timer
* @note  新增bypass method
* @param[in]        p_msg_ctx       [bypass上下文]
* @param[in]        json            [传入json]
* @return           BYPASS_ERR_E    [错误码]
*/
static BYPASS_ERR_E ls_bp_del_timer(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    if (NULL == p_msg_ctx || NULL == p_msg_ctx->p_trace_msg || NULL == json)
    {
        return BP_ERROR;
    }

    cJSON *json_data = cJSON_GetObjectItemCaseSensitive(json, "id");
    if (cJSON_IsNumber(json_data))
    {
        if (APP_OK == ls_timing_remove(json_data->valueint))
        {
            cJSON *json_ret = cJSON_CreateObject();
            if (NULL != json_ret)
            {
                cJSON_AddNumberToObject(json_ret, "id", json_data->valueint);
            }
            vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, json_ret);
        }
        else
        {
            vesync_bypass_reply_pkg_err_msg(BP_ERR_TIMER_NOT_FOUND, p_msg_ctx->p_trace_msg, "Timer remove fail");
        }
    }
    else
    {
        return BP_ERR_ARG;
    }

    return BP_OK;
}


/**
* @brief ledstrip bypass 添加Schedule回调接口
* @param[in]  p_msg_ctx                [msg context]
* @param[in]  p_data                   [回调函数传入数据]
*/
static void ls_bp_add_schedule(bypass_msg_ctx_t *p_msg_ctx, void *p_data)
{
    int error_code = BP_ERR_PARA_ILLEGAL;

    if(NULL == p_data)
    {
        vesync_bypass_reply_pkg_err_msg(BP_ERR_PARA_ILLEGAL, p_msg_ctx->p_trace_msg, BP_ERR_PARAM_CONV(p_data, BP_ERR_PARAM_NULL_PTR));
        return;
    }

    uint32_t sch_id = 0;
    cJSON *json_sch_ret = NULL;
    bypass_schedule_base_t *p_bp_sch = (bypass_schedule_base_t *)p_data;

    error_code = ls_schedule_add(p_bp_sch, &sch_id);
    if (BP_ERR_NO_ERR == error_code)
    {
        // 添加成功，生成回应
        json_sch_ret = cJSON_CreateObject();
        if (NULL != json_sch_ret)
        {
            cJSON_AddNumberToObject(json_sch_ret, "id", sch_id);
        }
    }

    vesync_bypass_reply_noqos(error_code, p_msg_ctx->p_trace_msg, json_sch_ret);
}

/**
* @brief Outlet bypass 更新Schedule回调接口
* @param[in]  p_msg_ctx                [msg context]
* @param[in]  p_data                   [回调函数传入数据]
*/
static void ls_bp_upd_schedule(bypass_msg_ctx_t *p_msg_ctx, void *p_data)
{
    int error_code = BP_ERR_PARA_ILLEGAL;

    if(NULL == p_data)
    {
        vesync_bypass_reply_pkg_err_msg(BP_ERR_PARA_ILLEGAL, p_msg_ctx->p_trace_msg, BP_ERR_PARAM_CONV(p_data, BP_ERR_PARAM_NULL_PTR));
        return;
    }

    uint32_t sch_id = 0;
    cJSON *json_sch_ret = NULL;
    bypass_schedule_base_t *p_bp_sch = (bypass_schedule_base_t *)p_data;

    error_code = ls_schedule_upd(p_bp_sch, &sch_id);
    if (BP_ERR_NO_ERR == error_code)
    {
        // 更新成功，生成回应
        json_sch_ret = cJSON_CreateObject();
        if (NULL != json_sch_ret)
        {
            cJSON_AddNumberToObject(json_sch_ret, "id", sch_id);
        }
    }

    vesync_bypass_reply_noqos(error_code, p_msg_ctx->p_trace_msg, json_sch_ret);
}

/**
* @brief Outlet bypass 删除Schedule回调接口
* @param[in]  p_msg_ctx                [msg context]
* @param[in]  p_data                   [回调函数传入数据]
*/
static void ls_bp_del_schedule(bypass_msg_ctx_t *p_msg_ctx, void *p_data)
{
    APP_LOG(LOG_DEBUG, "del schedule \n");
    int error_code = BP_ERR_PARA_ILLEGAL;

    if(NULL == p_data)
    {
        vesync_bypass_reply_pkg_err_msg(BP_ERR_PARA_ILLEGAL, p_msg_ctx->p_trace_msg, BP_ERR_PARAM_CONV(p_data, BP_ERR_PARAM_NULL_PTR));
        return;
    }

    uint32_t sch_id = *((uint32_t *)p_data);
    cJSON *json_sch_ret = NULL;

    error_code = ls_schedule_del(sch_id);
    if (BP_ERR_NO_ERR == error_code)
    {
        // 删除成功，生成回应
        json_sch_ret = cJSON_CreateObject();
        if (NULL != json_sch_ret)
        {
            cJSON_AddNumberToObject(json_sch_ret, "id", sch_id);
        }
    }

    vesync_bypass_reply_noqos(error_code, p_msg_ctx->p_trace_msg, json_sch_ret);
}


/**
* @brief 生成Schedule配置项列表的JSON
* @param[in] json_array    [JSON数组根对象]
* @param[in] p_list        [Schedule配置项列表]
* @param[in] list_len      [列表的最大长度,注意大于等于列表内的配置项数量]
* @return      int         [Bypass定义的错误]
*/
static int schedule_list_json_marshal(void *json_array, bypass_schedule_base_t *p_list, uint32_t list_len)
{
    cJSON *p_out = (cJSON *)json_array;

    if (!cJSON_IsArray(p_out))
    {
        return BP_ERR_PARA_ILLEGAL;
    }

    for (uint32_t cnt = 0; cnt < list_len; cnt++)
    {
        // 判断列表结束
        if (0 == p_list[cnt].id)
        {
            break;
        }

        cJSON *sch_obj = cJSON_CreateObject();
        cJSON *sub_obj = NULL;
        uint8_t type = *((uint8_t *)p_list[cnt].type);

        cJSON_AddNumberToObject(sch_obj, "id", p_list[cnt].id);
        cJSON_AddBoolToObject(sch_obj, "enabled", *((bool *)p_list[cnt].enabled));
        cJSON_AddItemToObject(sch_obj, "startAct", (cJSON*)p_list[cnt].json_action);
        cJSON_AddNumberToObject(sch_obj, "type", type);
        if (BYPASS_SCHEDULE_JSON_TYPE_TMG_EVT == type)
        {
            sub_obj = cJSON_AddObjectToObject(sch_obj, "tmgEvt");

            cJSON_AddNumberToObject(sub_obj, "clkSec", *p_list[cnt].clock_sec);
        }
        else if (BYPASS_SCHEDULE_JSON_TYPE_SUN_EVT == type)
        {
            sub_obj = cJSON_AddObjectToObject(sch_obj, "sunEvt");

            cJSON_AddBoolToObject(sub_obj, "isRise", *((bool *)p_list[cnt].is_sunrise));
            cJSON_AddNumberToObject(sub_obj, "ofsSec", *p_list[cnt].offset_sec);
        }

        cJSON_AddNumberToObject(sch_obj, "repeat", *((uint8_t *)p_list[cnt].repeat_config));
        cJSON_AddItemToArray(p_out, sch_obj);
    }

    return BP_ERR_NO_ERR;
}


/**
* @brief bypass 查询Schedule回调接口
* @param[in]  p_msg_ctx                [msg context]
* @param[in]  p_data                   [回调函数传入数据]
*/
static void ls_bp_get_schedules(bypass_msg_ctx_t *p_msg_ctx, void *p_data)
{
    int error_code = BP_ERR_PARA_ILLEGAL;

    if(NULL == p_data)
    {
        vesync_bypass_reply_pkg_err_msg(BP_ERR_PARA_ILLEGAL, p_msg_ctx->p_trace_msg, BP_ERR_PARAM_CONV(p_data, BP_ERR_PARAM_NULL_PTR));
        return;
    }

    uint32_t index = *((uint32_t *)p_data);
    cJSON *json_sch_ret = NULL;
    cJSON *json_array = NULL;
    // 配置项总数
    uint32_t total_num = 0;
    void *mult_sche_buf = NULL;

    // 输出列表
    bypass_schedule_base_t sch_bp_list[LS_SCHEDULE_GET_MAX_NUM];
    // 初始化输出列表
    memset(sch_bp_list, 0, sizeof(bypass_schedule_base_t) * LS_SCHEDULE_GET_MAX_NUM);
    // 读取配置项
    error_code = ls_schedule_get_mult(index, &mult_sche_buf, sch_bp_list, &total_num);
    if (BP_ERR_NO_ERR == error_code)
    {
        // 查询成功，生成回应
        json_sch_ret = cJSON_CreateObject();
        if (NULL != json_sch_ret)
        {
            cJSON_AddNumberToObject(json_sch_ret, "total", total_num);
            json_array = cJSON_AddArrayToObject(json_sch_ret, "schedules");
            // 把配置项列表生成JSON添加到回应的JSON
            schedule_list_json_marshal(json_array, sch_bp_list, LS_SCHEDULE_GET_MAX_NUM);
        }
    }

    if (BP_ERR_SCHEDULE_NOT_FOUND == error_code)
    {
        error_code = BP_ERR_NO_ERR;

        // 生成空回应
        json_sch_ret = cJSON_CreateObject();
        if (NULL != json_sch_ret)
        {
            cJSON_AddNumberToObject(json_sch_ret, "total", total_num);
            cJSON_AddArrayToObject(json_sch_ret, "schedules");
        }
    }

    // 释放配置读取内存
    vesync_free(mult_sche_buf);
    vesync_bypass_reply_noqos(error_code, p_msg_ctx->p_trace_msg, json_sch_ret);
}


/**
* @brief 设置开关开启/关闭
* @param[in]  p_msg_ctx                [msg context]
* @param[in]  p_data                   [回调函数传入数据]
*/
static void ls_bp_set_switch_onoff(bypass_msg_ctx_t *p_msg_ctx, void *p_data)
{
    if (NULL == p_data)
    {
        vesync_bypass_reply_pkg_err_msg(BP_ERR_PARA_ILLEGAL, p_msg_ctx->p_trace_msg, BP_ERR_PARAM_CONV(p_data, BP_ERR_PARAM_NULL_PTR));
        return;
    }
    bypass_switch_data_t *p_sw = (bypass_switch_data_t*)p_data;
    ls_led_hsv_param_t *hsv_params = NULL;
    ls_led_status_t cur_status;
    memset(&cur_status, 0, sizeof(ls_led_status_t));

    ls_led_get_status(false, &cur_status);
    if (p_sw->enable && cur_status.status == false)
    {
        hsv_params = (ls_led_hsv_param_t*)vesync_malloc(sizeof(ls_led_hsv_param_t));
        if (hsv_params == NULL)
        {
            vesync_bypass_reply_pkg_err_msg(BP_ERR_OUT_OF_MEMORY, p_msg_ctx->p_trace_msg, NULL);
            return;
        }

        hsv_params->mode = cur_status.last_mode;
        hsv_params->color = cur_status.color;
        ls_led_set_led((void *)hsv_params, LS_LED_ACT_SRC_OUTSIDE);
    }
    else if (cur_status.status && p_sw->enable == false)
    {
        ls_led_off(LS_LED_ACT_SRC_OUTSIDE);
    }

    ls_report_set_chg_rsn(p_msg_ctx->p_trace_msg->src_type);
    vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, NULL);
}

/**
* @brief 反转开关的开启/关闭状态
* @param[in]  p_msg_ctx                [msg context]
* @param[in]  p_data                   [回调函数传入数据]
*/
static void ls_bp_toggle(bypass_msg_ctx_t *p_msg_ctx, void *p_data)
{
    ls_led_hsv_param_t *hsv_params = NULL;
    ls_led_status_t cur_status;
    memset(&cur_status, 0, sizeof(ls_led_status_t));

    ls_led_get_status(false, &cur_status);
    // 翻转开关
    if (LS_MODE_OFF == cur_status.model)
    {
        hsv_params = (ls_led_hsv_param_t*)vesync_malloc(sizeof(ls_led_hsv_param_t));
        if (hsv_params == NULL)
        {
            vesync_bypass_reply_pkg_err_msg(BP_ERR_OUT_OF_MEMORY, p_msg_ctx->p_trace_msg, NULL);
            return;
        }
        hsv_params->mode = cur_status.last_mode;
        hsv_params->color = cur_status.color;
        ls_led_set_led((void *)hsv_params, LS_LED_ACT_SRC_OUTSIDE);
    }
    else
    {
        ls_led_off(LS_LED_ACT_SRC_OUTSIDE);
    }

    ls_report_set_chg_rsn(p_msg_ctx->p_trace_msg->src_type);
    vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, NULL);
}

/**
* @brief 调整亮度色温百分比
* @param[in]  p_msg_ctx                [msg context]
* @param[in]  p_data                   [回调函数传入数据]
*/
static void ls_bp_adjust_percent(bypass_msg_ctx_t *p_msg_ctx, void *p_data)
{
    if (NULL == p_data)
    {
        vesync_bypass_reply_pkg_err_msg(BP_ERR_PARA_ILLEGAL, p_msg_ctx->p_trace_msg, BP_ERR_PARAM_CONV(p_data, BP_ERR_PARAM_NULL_PTR));
        return;
    }
    bypass_adjust_percent_t *data = (bypass_adjust_percent_t*)p_data;
    ls_led_status_t cur_status;
    memset(&cur_status, 0, sizeof(ls_led_status_t));

    ls_led_get_status(false, &cur_status);

    ls_led_hsv_param_t *ls_cfg = (ls_led_hsv_param_t*)vesync_malloc(sizeof(ls_led_hsv_param_t));
    if (NULL == ls_cfg)
    {
        vesync_bypass_reply_pkg_err_msg(BP_ERR_OUT_OF_MEMORY, p_msg_ctx->p_trace_msg, BP_ERR_PARAM_CONV(p_data, BP_ERR_PARAM_NULL_PTR));
        return;
    }
    memset(ls_cfg, 0, sizeof(ls_led_hsv_param_t));

    int temp = 0;
    if (0 == strcmp(data->type, "colorTemp"))
    {

        ls_cfg->mode = LS_MODE_WHITE;
        if (LS_MODE_SCENE == cur_status.model || LS_MODE_COLOR == cur_status.model)
        {
            // 该接口设置色温时处于情景模式和彩光模式下不响应
            vesync_free(ls_cfg);
            vesync_bypass_reply_pkg_err_msg(BP_ERR_NOT_EXEC_IN_CUR_MODE, p_msg_ctx->p_trace_msg, "Params matched error! ");
            return;
        }
        (ls_cfg->color).brightness = cur_status.color.brightness;
        int cur_colortemp = cur_status.color.colortemp;
        temp = cur_colortemp + data->step;
        if (temp < 0)
        {
            temp = 0;
        }
        else if (temp > 100)
        {
            temp = 100;
        }
        (ls_cfg->color).colortemp = (uint8_t)temp;
    }
    else if (0 == strcmp(data->type, "brightness"))
    {
        ls_cfg->mode = cur_status.last_mode;
        if (LS_MODE_SCENE == cur_status.model)
        {
            // 该接口设置亮度时处于情景模式下不响应
            vesync_free(ls_cfg);
            vesync_bypass_reply_pkg_err_msg(BP_ERR_NOT_EXEC_IN_CUR_MODE, p_msg_ctx->p_trace_msg, "Params matched error! ");
            return;
        }
        // 不响应关闭模式下降低亮度，其他都需要调整亮度
        if (LS_MODE_OFF != cur_status.model || 0 < data->step)
        {
            if (LS_MODE_WHITE == cur_status.last_mode)
            {
                (ls_cfg->color).colortemp = cur_status.color.colortemp;
                int cur_bright = (LS_MODE_OFF == cur_status.model) ? 0 : cur_status.color.brightness;
                temp = cur_bright + data->step;
                if (temp < 0)
                {
                    temp = 0;
                }
                else if (temp > 100)
                {
                    temp = 100;
                }
                (ls_cfg->color).brightness = (uint8_t)temp;
            }
            else if (LS_MODE_COLOR == cur_status.last_mode)
            {
                (ls_cfg->color).H = cur_status.color.H;
                (ls_cfg->color).S = cur_status.color.S;
                int cur_V = (LS_MODE_OFF == cur_status.model) ? 0 : cur_status.color.V;
                temp = cur_V + data->step;
                if (temp < 0)
                {
                    temp = 0;
                }
                else if (temp > 100)
                {
                    temp = 100;
                }
                (ls_cfg->color).V = (uint8_t)temp;
            }
        }
    }
    else
    {
        vesync_bypass_reply_pkg_err_msg(BP_ERR_PARA_ILLEGAL, p_msg_ctx->p_trace_msg, "Invalid type ! ");
        return;
    }

    if ((ls_cfg->color).brightness == 0 && (ls_cfg->color).V == 0)
    {
        ls_led_off(LS_LED_ACT_SRC_OUTSIDE);
    }
    else
    {
        ls_led_set_led(ls_cfg, LS_LED_ACT_SRC_OUTSIDE);
    }

    // 回复与上报
    cJSON *p_json_result = NULL;
    p_json_result = cJSON_CreateObject();
    if (p_json_result != NULL)
    {
        cJSON_AddNumberToObject(p_json_result, "percent", temp);
    }

    ls_report_set_chg_rsn(p_msg_ctx->p_trace_msg->src_type);
    vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, p_json_result);
}



/**
* @brief   拷贝有效赋值,传入0xff/0xffff，代表该参数为赋值
* @param[out]  *hsv_params          [输出的参数]
* @param[in]  *hsv_set_params       [传入的设置参数]
* @param[in]  cur_status            [当前的参数]
*/
static void ls_copy_hsv_params(ls_led_hsv_param_t *hsv_params, bypass_hsv_base_t *hsv_set_params, ls_led_status_t cur_status)
{
    (hsv_params->color).V = cur_status.color.V;
    (hsv_params->color).H = (hsv_set_params->H == 0xffff) ? cur_status.color.H :
                                                          hsv_set_params->H;
    (hsv_params->color).S = (hsv_set_params->S == 0xffff) ? cur_status.color.S :
                                                          hsv_set_params->S;
    (hsv_params->color).brightness= cur_status.color.brightness;
    (hsv_params->color).colortemp = (hsv_set_params->colorTemp == 0xff) ? cur_status.color.colortemp :
                                                                        hsv_set_params->colorTemp;
}


/**
* @brief led状态json数据打包
* @param[in]  mode              [当前模式]
* @param[in]  light_params      [led参数]
* @param[out]  *p_data          [json指针]
*/
static void ls_bp_light_status_json_marshal(LS_MODE_E mode, ls_led_hsv_t light_params, cJSON *p_data)
{
    if (mode == LS_MODE_OFF)
    {
        cJSON_AddStringToObject(p_data, "enabled", "off");
    }
    else
    {
        cJSON_AddStringToObject(p_data, "enabled", "on");
        if (mode == LS_MODE_WHITE)
        {
            cJSON_AddStringToObject(p_data, "colorMode", "white");
        }
        else if (mode == LS_MODE_COLOR)
        {
            cJSON_AddStringToObject(p_data, "colorMode", "hsv");
        }
        else
        {
            cJSON_AddStringToObject(p_data, "colorMode", "scenario");
        }
    }

    cJSON_AddNumberToObject(p_data, "brightness", light_params.brightness);
    cJSON_AddNumberToObject(p_data, "colorTemp", light_params.colortemp);
    cJSON_AddNumberToObject(p_data, "hue", light_params.H);
    cJSON_AddNumberToObject(p_data, "saturation", light_params.S);
    cJSON_AddNumberToObject(p_data, "value", light_params.V);
}

/**
* @brief 设置灯状态
* @param[in]  p_msg_ctx                [msg context]
* @param[in]  p_data                   [回调函数传入数据]
*/
static void ls_bp_set_light_status(bypass_msg_ctx_t *p_msg_ctx, void *p_data)
{
    if(NULL == p_data)
    {
        vesync_bypass_reply_pkg_err_msg(BP_ERR_PARA_ILLEGAL, p_msg_ctx->p_trace_msg, BP_ERR_PARAM_CONV(p_data, BP_ERR_PARAM_NULL_PTR));
        return;
    }

    uint8_t ret = 0;
    bypass_hsv_base_t *hsv_set_params = (bypass_hsv_base_t*)p_data;
    ls_led_hsv_param_t *hsv_params = NULL;
    ls_led_status_t cur_status;
    memset(&cur_status, 0, sizeof(ls_led_status_t));

    ls_led_get_status(false, &cur_status);
    hsv_params = (ls_led_hsv_param_t*)vesync_malloc(sizeof(ls_led_hsv_param_t));
    if (hsv_params == NULL)
    {
        vesync_bypass_reply_pkg_err_msg(BP_ERR_OUT_OF_MEMORY, p_msg_ctx->p_trace_msg, NULL);
        return;
    }
    memset(hsv_params, 0, sizeof(ls_led_hsv_param_t));
    ls_copy_hsv_params(hsv_params, hsv_set_params, cur_status);
    if (0 == strcmp(hsv_set_params->colorMode, "white"))
    {
        hsv_params->mode = LS_MODE_WHITE;
        (hsv_params->color).brightness = hsv_set_params->brightness;
        (hsv_params->color).colortemp = hsv_set_params->colorTemp;

        if (hsv_set_params->brightness == 0)
        {
            vesync_bypass_reply_pkg_err_msg(BP_ERR_PARA_ILLEGAL, p_msg_ctx->p_trace_msg, NULL);
            return;
        }
    }
    else if (0 == strcmp(hsv_set_params->colorMode, "hsv"))
    {
        hsv_params->mode = LS_MODE_COLOR;
        (hsv_params->color).V = hsv_set_params->brightness;
        (hsv_params->color).H = hsv_set_params->H;
        (hsv_params->color).S = hsv_set_params->S;

        if (hsv_set_params->brightness == 0)
        {
            vesync_bypass_reply_pkg_err_msg(BP_ERR_PARA_ILLEGAL, p_msg_ctx->p_trace_msg, NULL);
            return;
        }
    }
    else if (0 == strcmp(hsv_set_params->colorMode, "force"))
    {
        // 第三方强行更换模式
        hsv_params->mode = cur_status.last_mode;
        if (hsv_set_params->H != 0xffff)
        {
            // 无色温参数则强行变为彩光模式
            hsv_params->mode = LS_MODE_COLOR;
        }
        else if (hsv_set_params->colorTemp != 0xff)
        {
            // 变为白光模式
            hsv_params->mode = LS_MODE_WHITE;
        }

        if (hsv_set_params->brightness != 0xff)
        {
            // 亮度为0时关闭
            if (hsv_set_params->brightness == 0)
            {
                hsv_params->mode = LS_MODE_OFF;
            }
            else if (hsv_params->mode == LS_MODE_COLOR)
            {
                (hsv_params->color).V = hsv_set_params->brightness;
            }
            else if (hsv_params->mode == LS_MODE_WHITE)
            {
                (hsv_params->color).brightness = hsv_set_params->brightness;
            }
        }
    }
    else if (0 == strcmp(hsv_set_params->colorMode, "match"))
    {
        // 联动或group 参数匹配才响应
        if (hsv_set_params->colorTemp != 0xff && LS_MODE_WHITE == cur_status.model)
        {
            hsv_params->mode = LS_MODE_WHITE;
        }
        else if (hsv_set_params->H != 0xffff && LS_MODE_COLOR == cur_status.model)
        {
            hsv_params->mode = LS_MODE_COLOR;
        }
        else if (hsv_set_params->brightness != 0xff && LS_MODE_SCENE != cur_status.model)
        {
            // 未指定模式且非情景模式下设置亮度
            hsv_params->mode = cur_status.last_mode;
            if (hsv_set_params->brightness == 0)
            {
                // 亮度为0时关闭
                hsv_params->mode = LS_MODE_OFF;
            }
        }
        else if (LS_MODE_OFF == cur_status.model)
        {
            // 关闭状态下调整
            if (hsv_set_params->H != 0xffff)
            {
                hsv_params->mode = LS_MODE_COLOR;
            }
            else if (hsv_set_params->colorTemp != 0xff)
            {
                hsv_params->mode = LS_MODE_WHITE;
            }
            else
            {
                hsv_params->mode = cur_status.last_mode;
            }
        }
        else
        {
            // 模式不匹配
            vesync_free(p_data);
            vesync_free(hsv_params);
            vesync_bypass_reply_pkg_err_msg(BP_ERR_NOT_EXEC_IN_CUR_MODE, p_msg_ctx->p_trace_msg, "Mode match failed !");
            return;
        }

        if (hsv_set_params->brightness != 0xff && hsv_set_params->brightness != 0)
        {
            if (hsv_params->mode == LS_MODE_COLOR)
            {
                (hsv_params->color).V = hsv_set_params->brightness;
            }
            else if (hsv_params->mode == LS_MODE_WHITE)
            {
                (hsv_params->color).brightness = hsv_set_params->brightness;
            }
        }
    }
    else if (0 == strcmp(hsv_set_params->colorMode, "off"))
    {
        if (cur_status.status == true)
        {
            hsv_params->mode = LS_MODE_OFF;
            ls_set_voice_off_flag(true);
        }
        else
        {
            // 已处于关闭状态
            vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, NULL);
            return;
        }
    }
    else if (0 == strcmp(hsv_set_params->colorMode, "on"))
    {
        if (cur_status.status == false)
        {
            hsv_params->mode = cur_status.last_mode;
            if (s_ls_voice_off_flag == true)
            {
                // 语音控制亮度为0后，用语音开启时以亮度100%开启。
                if (hsv_params->mode == LS_MODE_COLOR)
                {
                    (hsv_params->color).V = 100;
                }
                else if (hsv_params->mode == LS_MODE_WHITE)
                {
                    (hsv_params->color).brightness = 100;
                }
            }
        }
        else
        {
            // 已处于开启状态
            vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, NULL);
            return;
        }
    }

    if (LS_MODE_OFF == hsv_params->mode)
    {
        ls_led_off(LS_LED_ACT_SRC_OUTSIDE);
    }
    else
    {
        VCOM_IN_RANGE_CHK((hsv_params->color).colortemp, 0, LED_COLORTEMP_MAX, (ret++));
        VCOM_IN_RANGE_CHK((hsv_params->color).brightness, 0, LED_BRIGHTNESS_MAX, (ret++));
        VCOM_IN_RANGE_CHK((hsv_params->color).H, 0, LED_HS_PARAM_MAX, (ret++));
        VCOM_IN_RANGE_CHK((hsv_params->color).S, 0, LED_HS_PARAM_MAX, (ret++));
        VCOM_IN_RANGE_CHK((hsv_params->color).V, 0, LED_BRIGHTNESS_MAX, (ret++));
        if (ret != 0)
        {
            vesync_free(p_data);
            vesync_free(hsv_params);
            vesync_bypass_reply_pkg_err_msg(BP_ERR_VALUE_OUT_OF_RANGE, p_msg_ctx->p_trace_msg, "Params out of range !");
            return;
        }

        ls_led_set_led((void *)hsv_params, LS_LED_ACT_SRC_OUTSIDE);
    }

    ls_report_set_chg_rsn(p_msg_ctx->p_trace_msg->src_type);
    // 回复led状态数据
    cJSON *json_result = NULL;
    json_result = cJSON_CreateObject();
    if (NULL== json_result)
    {
        vesync_bypass_reply_pkg_err_msg(BP_ERR_OUT_OF_MEMORY, p_msg_ctx->p_trace_msg, NULL);
    }
    else
    {
        ls_bp_light_status_json_marshal(hsv_params->mode, hsv_params->color, json_result);
        vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, json_result);
    }

    vesync_free(p_data);
}

/**
* @brief 获取灯状态
* @param[in]  p_msg_ctx                [msg context]
* @param[in]  p_data                   [回调函数传入数据]
*/
static void ls_bp_get_light_status(bypass_msg_ctx_t *p_msg_ctx, void *p_data)
{
    cJSON *json_result = NULL;
    ls_led_status_t cur_status;
    memset(&cur_status, 0, sizeof(ls_led_status_t));

    ls_led_get_status(false, &cur_status);
    json_result = cJSON_CreateObject();
    if (NULL== json_result)
    {
        vesync_bypass_reply_pkg_err_msg(BP_ERR_OUT_OF_MEMORY, p_msg_ctx->p_trace_msg, NULL);
        return;
    }

    ls_bp_light_status_json_marshal(cur_status.model, cur_status.color, json_result);
    vesync_bypass_reply_noqos(BP_OK, p_msg_ctx->p_trace_msg, json_result);
}

static bypass_user_data_t ls_method_tbl[] = {
    // timer
    {"addTimerV2", ls_bp_add_timer},
    {"getTimerV2", ls_bp_get_timer},
    {"delTimerV2", ls_bp_del_timer}
};



/**
* @brief 注册bypass回调函数
*/
void ls_bypass_reg_cb(void)
{
    // LED
    vesync_bypass_reg_method_cb(BYPASS_METHOD_ID_SET_SWITCH, ls_bp_set_switch_onoff);
    vesync_bypass_reg_method_cb(BYPASS_METHOD_ID_TOGGLE_SWITCH, ls_bp_toggle);
    // addjustPercent
    vesync_bypass_reg_method_cb(BYPASS_METHOD_ID_ADJUST_PERCENT, ls_bp_adjust_percent);

    // setLight / getLight
    vesync_bypass_reg_method_cb(BYPASS_METHOD_ID_SET_LIGHT_V2, ls_bp_set_light_status);
    vesync_bypass_reg_method_cb(BYPASS_METHOD_ID_GET_LIGHT_V2, ls_bp_get_light_status);

    // Schedule
    vesync_bypass_reg_method_cb(BYPASS_METHOD_ID_ADD_SCHEDULE_V3, ls_bp_add_schedule);
    vesync_bypass_reg_method_cb(BYPASS_METHOD_ID_UPD_SCHEDULE_V3, ls_bp_upd_schedule);
    vesync_bypass_reg_method_cb(BYPASS_METHOD_ID_DEL_SCHEDULE_V3, ls_bp_del_schedule);
    vesync_bypass_reg_method_cb(BYPASS_METHOD_ID_GET_SCHEDULES_V3, ls_bp_get_schedules);

    for (int i = 0; i < SIZEOF_ARRAY(ls_method_tbl); i++)
    {
        vesync_bypass_add_user_item(&ls_method_tbl[i]);
    }

}


