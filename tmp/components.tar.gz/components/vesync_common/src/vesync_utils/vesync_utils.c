/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_utils.c
 * @brief       Vesync工具类函数实现
 * @author      Herve
 * @date        2021-04-20
 */
#include "vesync_utils.h"


/**
 * @brief 主机序转16位整形小端
 * @param[in] host          [16位整形主机序数据]
 * @return uint16_t         [16位整形小端数据]
 */
uint16_t vesync_htole16(uint16_t host)
{
    uint16_t res;
    uint8_t *p = (uint8_t *)&res;

    *p++ = host & 0xffu;
    *p = host >> 8;
    return res;
}

/**
 * @brief 主机序转16位整形大端
 * @param host              [16位整形主机序数据]
 * @return uint16_t         [16位整形大端数据]
 */
uint16_t vesync_htobe16(uint16_t host)
{
    uint16_t res;
    uint8_t *p = (uint8_t *)&res;

    *p++ = host >> 8;
    *p = host & 0xffu;
    return res;
}

/**
 * @brief 16位整形小端转主机序
 * @param le                [16位整形小端数据]
 * @return uint16_t         [16位整形主机序数据]
 */
uint16_t vesync_le16toh(uint16_t le)
{
    uint16_t host;
    uint8_t *p = (uint8_t *)&le;

    host = *p++;
    host += *p << 8;
    return host;
}

/**
 * @brief 16位整形大端转主机序
 * @param be                [16位整形大端数据]
 * @return uint16_t         [16位整形主机序数据]
 */
uint16_t vesync_be16toh(uint16_t be)
{
    uint16_t host;
    uint8_t *p = (uint8_t *)&be;

    host = *p++ << 8;
    host += *p;
    return host;
}

/**
 * @brief exp2的快速实现
 * @note 来自：http://code.google.com/p/fastapprox/
 * @param[in]   p           [指数]
 * @return      float       [计算结果]
 */
static inline float fastpow2(float p)
{
    float offset = (p < 0) ? 1.0f : 0.0f;
    float clipp = (p < -126) ? -126.0f : p;
    int w = (int)clipp;
    float z = clipp - w + offset;
    union
    {
        unsigned int i;
        float f;
    } v = {(unsigned int)((1 << 23) * (clipp + 121.2740575f + 27.7280233f / (4.84252568f - z) - 1.49012907f * z))};
    return v.f;
}

/**
 * @brief log2的快速实现
 * @note 来自：http://code.google.com/p/fastapprox/
 * @param[in]   x           [幂数]
 * @return      float       [计算结果]
 */
static inline float fastlog2(float x)
{
    union
    {
        float f;
        unsigned int i;
    } vx = {x};
    union
    {
        unsigned int i;
        float f;
    } mx = {(vx.i & 0x007FFFFF) | 0x3f000000};
    float y = (float)vx.i;
    y *= 1.1920928955078125e-7f;
    return y - 124.22551499f - 1.498030302f * mx.f - 1.72587999f / (0.3520887068f + mx.f);
}

float vesync_powf(float x, float p)
{
    if (x == 1.0f || x == 0.0f || p == 1.0f)
    {
        return x;
    }
    if (p == 0.0f)
    {
        return 1.0f;
    }
    return fastpow2(p * fastlog2(x));
}

float vesync_log10f(float x)
{
    if (x == 1.0f || x <= 0)
    {
        return 0;
    }
    return fastlog2(x) / fastlog2(10.0f);
}

#ifdef __cplusplus
#define cast_uint32_t static_cast<uint32_t>
#else
#define cast_uint32_t (uint32_t)
#endif

/**
 * @brief exp2的更快速实现
 * @note 来自：http://code.google.com/p/fastapprox/
 * @param[in]   p           [指数]
 * @return      float       [计算结果]
 */
static inline float fasterpow2(float p)
{
    float clipp = (p < -126) ? -126.0f : p;
    union
    {
        uint32_t i;
        float f;
    } v = {cast_uint32_t((1 << 23) * (clipp + 126.94269504f))};
    return v.f;
}

/**
 * @brief log2的更快速实现
 * @note 来自：http://code.google.com/p/fastapprox/
 * @param[in]   x           [幂数]
 * @return      float       [计算结果]
 */
static inline float fasterlog2(float x)
{
    union
    {
        float f;
        uint32_t i;
    } vx = {x};
    float y = vx.i;
    y *= 1.1920928955078125e-7f;
    return y - 126.94269504f;
}

float vesync_powf_x(float x, float p)
{
    if (x == 1.0f || x == 0.0f || p == 1.0f)
    {
        return x;
    }
    if (p == 0.0f)
    {
        return 1.0f;
    }
    return fasterpow2(p * fasterlog2(x));
}

float vesync_log10f_x(float x)
{
    if (x == 1.0f || x <= 0)
    {
        return 0;
    }
    return fasterlog2(x) / fasterlog2(10.0f);
}
