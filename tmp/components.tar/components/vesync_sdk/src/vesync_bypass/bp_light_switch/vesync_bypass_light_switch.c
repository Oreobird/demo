/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_bypass_light_switch.c
 * @brief       bypass处理接口
 * @date        2021-05-17
 */
#include <string.h>

#include "vesync_common.h"
#include "vesync_memory.h"
#include "vesync_bypass_internal.h"

/**
 * @brief 控制灯开关
 * @param p_trace_msg trace message
 * @param json数据指针
 * @return BYPASS_ERR_E
 */
static BYPASS_ERR_E bypass_method_set_light_switch_handle(bypass_trace_msg_t *p_trace_msg, cJSON *json)
{
    BYPASS_ERR_E ret = BP_OK;
    if ((NULL == json)||(NULL == p_trace_msg))    return BP_ERROR;

    bypass_light_switch_para_t *para = (bypass_light_switch_para_t *)vesync_malloc(sizeof(bypass_light_switch_para_t));
    if (NULL == para)
    {
        return BP_ERR_NOMEM;
    }

    memset(para, 0, sizeof(bypass_light_switch_para_t));

    cJSON *json_data = cJSON_GetObjectItemCaseSensitive(json, "enabled");
    if (cJSON_IsBool(json_data))
    {
        para->enable = json_data->valueint;
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }


    json_data = cJSON_GetObjectItemCaseSensitive(json, "Id");
    if (cJSON_IsNumber(json_data))
    {
        para->id = json_data->valueint;
    }
    else
    {
        json_data = cJSON_GetObjectItemCaseSensitive(json, "id");
        if (cJSON_IsNumber(json_data))
        {
            para->id = json_data->valueint;
        }
        else
        {
            ret = BP_ERR_ARG;
            goto _exit;
        }
    }

    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_SET_LIGHT_SWITCH);
    if (method_cb)
    {
        method_cb(p_trace_msg, para, sizeof(bypass_light_switch_para_t));
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

_exit:
    vesync_free(para);
    return ret;
}

static bypass_item_data_t light_switch_method_tbl[] = {
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_SET_LIGHT_SWITCH, "setLightSwitch", bypass_method_set_light_switch_handle, NULL},
};

void vesync_bypass_light_switch_init(void)
{
    for (int i = 0; i < SIZEOF_ARRAY(light_switch_method_tbl); i++)
    {
        bypass_item_t *item = vesync_bypass_init_item(&light_switch_method_tbl[i]);
        if (item != NULL)
        {
            vesync_bypass_add_item(item);
        }
    }
}
