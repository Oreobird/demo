/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file    vesync_net_service.c
 * @brief       网络客户端控制
 * @author      CharlesMei & Joshua
 * @date        2021-06-04
 */

#include <string.h>
#include <stdint.h>
#include "vesync_event_internal.h"
#if CONFIG_VESYNC_SDK_HTTPS_ENABLE
#include "vesync_net_https_internal.h"
#endif
#if CONFIG_VESYNC_SDK_MQTT_ENABLE
#include "vesync_net_mqtt_internal.h"
#endif
#include "vesync_net_service_private.h"
#include "vesync_production_internal.h"

static vnet_cli_t s_vnet_cli;

/**
 * @brief  网络重连原因初始化
 */
static void vesync_net_reconnect_init(void)
{
    uint32_t reason = RECONNECT_NONE_REASON;

    int ret = vesync_net_flash_read_reconnect_reason(&reason);
    if (VERR_OK == ret && reason > 0)
    {
        vesync_net_mgmt_set_reconnect_reason((RECONNECT_REASON_E)reason);
    }
}

/**
 * @brief  云客户端配置
 */
static void vesync_net_client_setup(NETWORK_APP_PROTOCOL_E prot)
{
    s_vnet_cli.protocol = prot;

    switch (prot)
    {
        case NETWORK_MQTT:
#if CONFIG_VESYNC_SDK_MQTT_ENABLE
            vesync_net_mqtt_cli_setup(&s_vnet_cli);
#endif
            break;
        case NETWORK_HTTPS:
#if CONFIG_VESYNC_SDK_HTTPS_ENABLE
            vesync_net_https_cli_setup(&s_vnet_cli);
#endif
            break;
        default:
            NET_LOG(LOG_ERROR, "Not supported protocol\n");
            break;
    }
}

/**
 * @brief  bypass回调函数注册
 * @param[in]  cb
 */
void vesync_net_reg_bypass_recv_cb(vesync_net_msg_recv_cb_t cb)
{
    NET_UTIL_MEM_CHECK(s_vnet_cli.reg_bypass_recv_cb, return);
    s_vnet_cli.reg_bypass_recv_cb(cb);
}

/**
 * @brief  非bypass回调函数注册
 * @param[in]   cb
 */
void vesync_net_reg_non_bypass_recv_cb(vesync_net_msg_recv_cb_t cb)
{
    NET_UTIL_MEM_CHECK(s_vnet_cli.reg_non_bypass_recv_cb, return);
    s_vnet_cli.reg_non_bypass_recv_cb(cb);
}

/**
 * @brief  网络客户端对有关device的设置进行刷新
 * @note  在device设置更新时（例如进入产测前）调用
 */
void vesync_net_client_device_refresh(void)
{
    NET_UTIL_MEM_CHECK(s_vnet_cli.fresh, return);
    s_vnet_cli.fresh();
}


/**
 * @brief       网络客户端初始化
 * @param[in]   protocol             [应用层协议]
 * @return      int                  [成功/失败]
 */
int vesync_net_client_init(void)
{
    int ret = VERR_OK;

    vesync_net_client_setup(NETWORK_MQTT);

    if (vesync_production_is_completed() && NET_TRANS_PROT == NETWORK_HTTPS)
    {
        vesync_net_client_setup(NETWORK_HTTPS);
    }

    NET_UTIL_MEM_CHECK(s_vnet_cli.init, return VERR_FAIL);
    ret = s_vnet_cli.init();
    if (ret != VERR_OK)
    {
        NET_LOG(LOG_ERROR, "client init fail!!!\n");
        return VERR_FAIL;
    }

    ret = vesync_net_event_init();
    if (ret != VERR_OK)
    {
        NET_LOG(LOG_ERROR, "client event subscribe fail!!!\n");
        return VERR_FAIL;
    }

    vesync_net_reconnect_init();

    return VERR_OK;
}

/**
 * @brief  连接服务器
 * @param[in]   p_srv                [mqtt服务器地址hostname]
 * @param[in]   p_ip                 [mqtt服务器地址ip]
 * @param[in]   p_pwd                [mqtt连接的用户密码，BLE/APN配网时为configKey，断开重连时为"0"，FFS配网时为token]
 * @param[in]   p_port               [mqtt连接端口， 指针置空则连接默认端口]
 * @param[in]   tls                  [tls选项]
 * @return  int                      [成功：VERR_OK，失败：VERR_FAIL]
 */
int vesync_net_client_connect(char *p_srv, char *p_ip, char *p_pwd, uint32_t *p_port, NETWORK_TLS_CA_E tls)
{
    NET_UTIL_MEM_CHECK(s_vnet_cli.connect, return VERR_FAIL);
    return s_vnet_cli.connect(p_srv, p_ip, p_pwd, p_port, tls);
}

/**
 * @brief  销毁网络服务客户端，释放内存，重置状态
 */
void vesync_net_client_destroy(void)
{
    if (s_vnet_cli.destroy)
    {
        s_vnet_cli.destroy();
    }
}

/**
 * @brief  vesync平台网络服务客户端断开与服务器的连接
 * @return  int                 [成功/失败]
 */
int vesync_net_client_disconnect_server(void)
{
    NET_UTIL_MEM_CHECK(s_vnet_cli.disconnect, return VERR_FAIL);
    return s_vnet_cli.disconnect();
}

/**
 * @brief  获取网络服务客户端在线状态
 * @return  VESYNC_NETWORK_STATUS_E [mqtt客户端在线状态]
 */
VESYNC_NETWORK_STATUS_E vesync_net_client_get_status(void)
{
    NET_UTIL_MEM_CHECK(s_vnet_cli.status_get, return NETWORK_UNKNOW);
    return s_vnet_cli.status_get();
}

/**
 * @brief  数据发送，可设置qos及收到回包后回调函数
 * @param[in]  topic_type           [topic类型]
 * @param[in]  p_data               [数据指针]
 * @param[in]  len                  [数据的长度]
 * @param[in]  qos                  [qos级别，当前支持0和1]
 * @param[in]  ack_cb               [收到回包后回调函数指针]
 * @return  int                     [成功：SDK_OK，失败：SDK_FAIL]
 */
int vesync_net_client_send(NET_DATA_TOPIC_TYPE_E topic_type, const char *p_data, int len, SEND_QOS_E qos, net_recv_ack_cb_t ack_cb)
{
    NET_UTIL_MEM_CHECK(s_vnet_cli.send, return VERR_FAIL);
    return s_vnet_cli.send(topic_type, p_data, len, qos, ack_cb);
}

/**
 * @brief  获取网络服务应用层协议
 * @return  NETWORK_APP_PROTOCOL_E [网络服务应用层协议]
 */
NETWORK_APP_PROTOCOL_E vesync_net_client_get_protocol(void)
{
    return s_vnet_cli.protocol;
}

/**
 * @brief  设置TLS证书选项
 * @return  NETWORK_TLS_CA_E       [TLS证书选项]
 */
NETWORK_TLS_CA_E vesync_net_client_get_tls_option(void)
{
    return (NET_TRANS_PROT == NETWORK_HTTPS) ? TLS_CA_ONE_WAY_AUTH : TLS_CA_SERVER;
}

/**
 * @brief  获取云端服务器默认端口
 * @return  int       [端口号，失败返回-1]
 */
int vesync_net_client_get_default_port(void)
{
    NET_UTIL_MEM_CHECK(s_vnet_cli.get_default_port, return -1);
    return s_vnet_cli.get_default_port();
}

