import os
from mako.template import Template

PR_TYPE="humidifier"

reg_dict={"BYPASS_METHOD_ADD_TIMER": PR_TYPE+"_bp_add_timer", "BYPASS_METHOD_DEL_TIMER": PR_TYPE+"_bp_del_timer"}

mytemplate = Template(filename="./test.c.mako")
with open("test.c", 'w') as test_c:
    test_c.write(mytemplate.render(data=reg_dict))
