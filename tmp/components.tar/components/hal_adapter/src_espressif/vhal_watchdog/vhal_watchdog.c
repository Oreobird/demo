/**
 *  Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vhal_watchdog.c
 * @brief       开门狗开启和关闭
 * @author      DongriSu
 * @date        2021-04-22
 */

#include "freertos/FreeRTOS.h"
//#include "freertos/task.h"
#include "freertos/timers.h"

#include "vesync_log.h"


#include "vhal_watchdog.h"




/**
 * @brief   初始化并启动看门狗
 * @param[in]  uint32_t         [看门狗周期]
 * @return  void
 * @note 只能启动1次
 */
void vhal_watchdog_start(uint32_t timeout_ms)
{
    return;
}

/**
 * @brief   停止看门狗
 * @return  void
 */
void vhal_watchdog_stop(void)
{
    return;
}

