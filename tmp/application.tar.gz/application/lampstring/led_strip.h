/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file    led_strip.h
* @brief   炫彩灯串应用层
* @author  Lind
* @date    2021-12-19
*/

#ifndef __LED_STRIP_H__
#define __LED_STRIP_H__

#include "vesync_device.h"
#include "vesync_task.h"

#include "led_strip_led.h"
#include "led_strip_scene.h"

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#define LS_APP_TASK_NAME                   "app_task"
#define LS_APP_TASK_STACSIZE               (1024 * 8)
#define LS_APP_TASK_PRIO                   TASK_PRIORITY_ABOVE_NORMAL
#define LS_EVENT_QUEUE_MAX_NUM             16

#define LS_TASK_CYCLE       (20)        // 任务间隔周期
#define LS_INIT_TIMS        (100)       // 初始化时间

/**
 * @brief  ledstrip应用事件类型id
 */
typedef enum
{
    LS_EV_RESET = 0,       // 恢复出厂灯效事件
    LS_EV_BEFORE_NETCFG,   // 开始配网灯效
    LS_EV_NETCFG,          // 配网任务中灯效
    LS_EV_PRODUCTION,      // 开始产测
    LS_EV_TURN_ON,         // BYPASS、按键切换场景、schedule、timer等单纯控制灯效，需要记录状态
    LS_EV_TURN_OFF,        // BYPASS、按键切换场景、schedule、timer等单纯控制灯效，需要记录状态
    LS_EV_SET_NODE_NUM,    // 设置灯泡数量
    LS_EV_ADD_SCENE,
    LS_EV_DEL_SCENE,
    LS_EV_UNKNOWN,
} LS_EV_E;

/**
 * @brief  ledstrip应用事件来源
 */
typedef enum
{
    LS_ACT_SRC_BTN = 0,             // 控制来源：按键执行
    LS_ACT_SRC_BYPASS,              // 控制来源：BYPASS
    LS_ACT_SRC_PRD,                 // 控制来源：产测
    LS_ACT_SRC_TIMER,               // 控制来源：timer
    LS_ACT_SRC_SCHEDULE,            // 控制来源：schedule
    LS_ACT_SRC_WIFI_LED,            // 控制来源：wifi led
    LS_ACT_SRC_UNKNOW,              // 控制来源：未知
} LS_ACT_SRC_E;

/**
 * @brief  模式
 */
typedef enum
{
    LS_MODE_WHITE = 0,      // 白光
    LS_MODE_HSV,            // 彩光
    LS_MODE_MULTI_SEG,      // 多段彩光
    LS_MODE_SCENE,          // 场景模式
    LS_MODE_OFF,
} LS_MODE_E;

/**
 * @brief  事件结构体
 */
typedef struct
{
    LS_EV_E id;
    LS_ACT_SRC_E act_src;
    LS_MODE_E mode;         // 模式
    uint16_t scene_id;      // 场景id
} ls_ev_t;

/**
 * @brief  状态参数
 */
typedef struct
{
    bool      status;
    LS_MODE_E mode;
    uint8_t   node_num;
    uint8_t   custom_scene_num;
    uint16_t  scene_id; // 场景ID  默认场景id(1~1024) 自定义场景id (1025~65535)
    ls_hsv_t  hsvw;
    ls_hsv_t  *multi_hsv;
    uint16_t  last_gen_id;  // 最近生成的id
} ls_status_t;

/**
* @brief 获取状态
* @param[out]  *pst_status       [状态参数]
*/
void ls_get_status(ls_status_t *pst_status);

/**
* @brief 获取状态指针，修改灯效参数
* @return[out]  ls_status_t*        [状态指针]
*/
ls_status_t* ls_get_status_pointer(void);

/**
 * @brief  给ledstrip应用任务发通知
 * @param[in]   ev              [通知消息]
 * @return     int              [成功：APP_OK，失败：APP_FAIL]
 */
int ls_app_task_notify(ls_ev_t *ev);

/**
* @brief 应用灯效参数初始化
*/
void ls_init(void);

/**
* @brief 获取添加场景信号量
*/
void ls_wait_scene_sem(void);

#ifdef __cplusplus
 }
#endif /* __cplusplus */

#endif /* __LED_STRIP_H__ */

