/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
 * @file        switch_device.c
 * @brief       产测功能
 * @author      Charles.Mei
 * @date        2021-07-30
 */


#include "vesync_common.h"
#include "vesync_device.h"

#include "switch_schedule.h"
#include "switch_timing.h"
#include "switch_uart_cmd.h"

/**
 * @brief 恢复出厂回调函数
 */
static void switch_device_pre_reset_cb(void *args)
{
    // do nothing
}

/**
 * @brief 清除开关应用层数据
 * @param[in]  rsn              [消息来源]
 * @param[in]  rst_type         [删除用户数据的类型]
 * @return
 */
static void switch_device_clear_all_data(const char* rsn, DEV_RESET_TYPE_E rst_type)
{
    switch_app_update_status_chg_rsn(rsn);

    switch (rst_type)
    {
        case DEV_DEL_USER_CFG:
            switch_uart_reset_mcu(RESET_RANK_ONLY_CLEAR_DATA, NULL);
            switch_schedule_clear();
            switch_timing_clear();
            break;
        case DEV_DEL_DEVICE:
            switch_uart_reset_mcu(RESET_RANK_FACTORY, NULL);
            switch_schedule_clear();
            switch_timing_clear();
            break;
        case DEV_DEL_NET_CFG:
        case DEV_REBOOT:
            switch_uart_reset_mcu(RESET_RANK_RESTART, NULL);
            break;
        default:
            break;
    }
}

/**
* @brief switch设备管理初始化
*/
void switch_device_init(void)
{
    // 注册恢复出厂重启前其它事务处理回调函数
    vesync_device_reg_reset_pre_reboot_cb(switch_device_pre_reset_cb);
    // 注册缓存数据清除函数(恢复出厂/删除设备时调用)
    vesync_device_reg_clear_data_cb(switch_device_clear_all_data);
}

