/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_init.h
 * @brief       初始化模块接口定义
 * @date        2021-04-22
 */

#ifndef __VESYNC_INIT_H__
#define __VESYNC_INIT_H__

#ifdef __cplusplus
extern "C" {
#endif

 /*
  * @brief  vesync sdk 初始化
  * @return int                         [成功：0；失败：-1]
  */
 int vesync_sdk_init(void);


#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_INIT_H__ */

