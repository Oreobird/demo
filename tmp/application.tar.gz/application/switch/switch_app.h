/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        switch_app.h
 * @brief       switch主任务头文件
 * @author      Charles.Mei
 * @date        2021-07-29
 */


#include <stdint.h>
#include <stdbool.h>


#ifndef __SWITCH_APP_H__
#define __SWITCH_APP_H__

#ifdef __cplusplus
    extern "C" {
#endif


// 详见串口协议文档
#define MCU_FW_VERSION_SIZE                     (1)
#define MCU_SW_VERSION_SIZE                     (3)
#define SWITCH_LIGHT_LEVEL_MAX                  (14)    // 灯光控制MCU有14个档位
#define SWITCH_LIGHT_MOD_MAX                    (3)     // 灯光控制MCU有3个调试模式
#define SWITCH_LIGHT_EXEC_LIGHTNESS_TIME_MAX    (7200U) // 调整灯亮度的最大执行时间
#define SWITCH_LIGHT_TEST_LIGHTNESS_TIME_MAX    (255U)  // 测试灯最小亮度的最大执行时间
#define SWITCH_LIGHT_PERCENT_MIN                (1)     // 灯初始最低亮度百分比1%，支持app设置
#define SWITCH_LIGHT_PERCENT_MAX                (100)   // 灯初始最高亮度百分比100%，不支持修改
#define SWITCH_LIGHT_LIGHTNESS_MIN              (10)    // 灯光最小亮度为10
#define SWITCH_LIGHT_LIGHTNESS_MAX              (1000)  // 灯光最大亮度为1000
#define SWITCH_LIGHT_LIGHTNESS_PRECISION        (10)    // MCU控制精度10-1000，与百分比的倍率为10
#define SWITCH_FAN_LEVEL_MAX                    (4)     // 风扇最大档位为4

#define STAT_CHG_RSN_STR_LEN_MAX                (16)    // 状态变化原因字符串最大长度
/*
 * @brief 事件类型
 */
typedef enum
{
    SWITCH_EV_UART_REQUEST      = 0,    // 串口请求事件
    SWITCH_EV_UART_ACK          = 1,    // 串口回复事件
    SWITCH_EV_UART_FAIL         = 2,    // 串口请求发送失败事件
    SWITCH_EV_NET_CONNECTED     = 3,    // 网络连接成功事件
    SWITCH_EV_NET_SETUP         = 4,    // 配网成功事件
    SWITCH_EV_UNKNOWN
} SWITCH_EVENT_E;

/*
 * @brief 事件
 */
typedef struct
{
    SWITCH_EVENT_E id;
    int len;
    void *buf;
} switch_ev_t;

/*
 * @brief 子设备id
 */
typedef enum
{
    DEVICE_ALL = 0,
    DEVICE_LIGHT = 1,
    DEVICE_FAN = 2,
    DEVICE_MAX
} DEVICE_ID_E;

/**
 * @brief   灯状态改变标志
 */
typedef enum
{
    LIGHT_ONOFF_CHANGE_FLAG                 = 0x00000001,
    LIGHT_LIGHTNESS_CHANGE_FLAG             = 0x00000002,
    LIGHT_LEVEL_CHANGE_FLAG                 = 0x00000004,
    LIGHT_MODE_CHANGE_FLAG                  = 0x00000008,
    LIGHT_MIN_LIGHTNESS_CHANGE_FLAG         = 0x00000010,
} LIGHT_CHANGE_FLAG_E;

/**
 * @brief   风扇状态改变标志
 */
typedef enum
{
    FAN_ONOFF_CHANGE_FLAG                 = 0x00000001,
    FAN_LEVEL_CHANGE_FLAG                 = 0x00000002,
} FAN_CHANGE_FLAG_E;

/*
 * @brief 灯状态
 */
typedef struct
{
    bool onoff;
    uint8_t net_lightness;      // 网络端亮度1-100%
    uint16_t uart_lightness;    // uart端亮度最低亮度10-1000，实际刻度根据最低亮度不同
    uint8_t level;
    uint16_t min_lightness;
    uint8_t light_mode;
    uint32_t report_flag;
} light_status_t;

/*
 * @brief 风扇状态
 */
typedef struct
{
    bool onoff;
    uint8_t level;
    uint32_t report_flag;
} fan_status_t;

/*
 * @brief switch状态
 */
typedef struct
{
    uint8_t mcu_fw_ver[MCU_FW_VERSION_SIZE];  //MCU硬件版本
    uint8_t mcu_sw_ver[MCU_SW_VERSION_SIZE];  //MCU固件版本
    DEVICE_ID_E cur_id; // MCU当前档位调节按键调节的对象id
    light_status_t light;
    fan_status_t fan;
    char chg_rsn[STAT_CHG_RSN_STR_LEN_MAX];
} switch_status_t;

/**
 * @brief timer和schedule执行时，light的动作
 * @note
 */
typedef struct
{
    bool onoff;            // 开关状态
    uint8_t lightness;      // 灯亮度，为0时无效，switch设置为off时无效
    uint16_t duration;      // 晨起/助眠执行时间
} light_action_t;

/**
 * @brief timer和schedule执行时，fan的动作
 * @note
 */
typedef struct
{
    bool onoff;            // 开关状态
    uint8_t level;          // 风扇档位，为0时无效，switch设置为off时无效
} fan_action_t;


/**
 * @brief  switch主任务初始化
 * @return     int                      [成功：SDK_OK，失败：SDK_FAIL]
 */
int switch_app_init(void);

/**
 * @brief  给switch主任务发通知
 * @param[in]  event_id                 [通知消息]
 * @return     int                      [成功：SDK_OK，失败：SDK_FAIL]
 */
int switch_app_task_notify(switch_ev_t *ev);

/**
 * @brief  网络端亮度转uart端亮度
 * @param[in]  lightness                [网络端亮度]
 * @return     int                      [uart端亮度，0表示执行失败]
 * @note    uart端亮度使用MCU控制的真实百分比
 * @note    网络端亮度是将新的最低亮度替换1%（初始最低亮度）后的新百分比
 */
uint16_t switch_lightness_net_to_uart(uint8_t lightness);

/**
 * @brief  设置网络端亮度
 * @param[in]  lightness                [网络端亮度]
 * @note    bypass设置亮度时必须先调用此接口
 * @note    由于uart端亮度对应多个网络端亮度，所以设置前必须保存
 */
void switch_app_set_net_lightness(uint8_t lightness);

/**
 * @brief  更新switch状态
 * @param[in]  status                   [switch状态]
 * @return     int                      [成功：APP_OK，失败：APP_FAIL]
 */
int switch_app_update_status(switch_status_t *status);

/**
 * @brief  更新switch改变原因
 * @param[in]  status                   [switch状态]
 * @return     int                      [成功：APP_OK，失败：APP_FAIL]
 */
int switch_app_update_status_chg_rsn(const char* chg_rsn);

/**
 * @brief  获取开关状态
 * @param[in]  dev_id                   [设备id]
 * @return     bool                     [开关状态]
 */
bool switch_app_get_switch_onoff(DEVICE_ID_E dev_id);

/**
 * @brief  获取档位
 * @param[in]  dev_id                   [设备id]
 * @return     uint8_t                  [档位，0表示获取失败]
 */
uint8_t switch_app_get_level(DEVICE_ID_E dev_id);

/**
 * @brief  获取灯亮度
 * @return     uint8_t                  [亮度，0表示获取失败]
 */
uint8_t switch_app_get_light_lightness(void);


#ifdef __cplusplus
}
#endif

#endif

