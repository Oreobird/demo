/**
* Copyright © Vesync Technologies Co.Ltd. 2022. All rights reserved
* @file         ocean.c
* @brief        海洋场景注册
* @author       Joshua
* @date         2022-1-12
*/

#include <string.h>
#include <stdint.h>
#include "vesync_common.h"
#include "vesync_memory.h"
#include "vesync_log.h"
#include "ocean.h"


int ocean_light_scene_reg(light_scene_t *light_scene)
{
    VCOM_NULL_PARAM_CHK(light_scene, return APP_FAIL);

    scene_t *thiz = (scene_t *) vesync_malloc(sizeof(scene_t) + sizeof(light_scene_t));
    if (thiz == NULL)
    {
        APP_LOG(LOG_ERROR, "ocean light scene reg fail\n");
        return APP_FAIL;
    }

    memset(thiz, 0, sizeof(scene_t) + sizeof(light_scene_t));

    thiz->type = SCENE_LIGHT;
    thiz->id = SCENE_OCEAN;

    light_scene_t *ctx = (light_scene_t *)thiz->ctx;
    memcpy(ctx, light_scene, sizeof(light_scene_t));

    scene_registry_add(thiz);

    return APP_OK;
}

int ocean_light_scene_unreg(void)
{
    return scene_registry_del(SCENE_LIGHT, SCENE_OCEAN);
}


