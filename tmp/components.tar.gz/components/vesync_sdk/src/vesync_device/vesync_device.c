/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_device.c
 * @brief       设备初始化、配置属性及操作接口
 * @date        2021-05-06
 */

#include <string.h>
#include <stdio.h>

#include "vhal_flash.h"
#include "vhal_utils.h"
#include "vesync_common.h"
#include "vesync_log_internal.h"
#include "vesync_os.h"
#include "vesync_timer.h"
#include "vesync_memory.h"
#include "vesync_flash.h"
#include "vesync_device_internal.h"
#include "vesync_net_service_internal.h"
#if CONFIG_VESYNC_SDK_WIFI_ENABLE
#include "vesync_wifi_led.h"
#endif
#if CONFIG_VESYNC_SDK_DEVELOPER_ENABLE
#include "vesync_developer_internal.h"
#endif
#if CONFIG_VESYNC_SDK_REPORT_ENABLE
#include "vesync_report_internal.h"
#endif
#include "vesync_production.h"
#include "vesync_event_internal.h"
#if CONFIG_VESYNC_SDK_TIMEBASE_ENABLE
#include "vesync_timebase_internal.h"
#endif

static vesync_dev_t *s_dev = NULL;
static vesync_timer_t *s_reboot_tmr_hd = NULL;   // 重启倒计时定时器

/*-----------------------------------------------------------------------------*
 *                                 内部函数实现                                  *
 *-----------------------------------------------------------------------------*/

/**
* @brief   设备重启定时器
* @return  bool            [创建并启动定时器成功，返回true，否则返回false]
*/
static int vesync_device_reboot_tmr_start(void)
{
    // 创建单次执行定时器，FAC_RESET_REBOOT_DELAY_MS 时间后执行
    s_reboot_tmr_hd = vesync_timer_new("device_reboot_timer",
                                       vhal_utils_restart,
                                       NULL,
                                       FAC_RESET_REBOOT_DELAY_MS,
                                       false);
    if (s_reboot_tmr_hd == NULL)
    {
        SDK_LOG(LOG_ERROR, "Create reboot timer fail!!!\n");
        return SDK_FAIL;
    }

    int ret = vesync_timer_start(s_reboot_tmr_hd);
    if (ret != VOS_OK)
    {
        SDK_LOG(LOG_ERROR, "Start reboot timer fail!!!\n");
        return SDK_FAIL;
    }

    return SDK_OK;
}

/*-----------------------------------------------------------------------------*
 *                           SDK内部函数API实现                                  *
 *-----------------------------------------------------------------------------*/

/**
 * @brief 删除用户（应用层）数据
 * @param[in]  src_type             [消息(动作)来源]
 * @param[in]  rst_type             [删除用户数据的类型]
 */
void vesync_device_delete_user_data(const char* src_type, DEV_RESET_TYPE_E rst_type)
{
#if CONFIG_VESYNC_SDK_DEVELOPER_ENABLE
    vesync_developer_flash_clear_dbg_cfg();
#endif

    switch (rst_type)
    {
    case DEV_DEL_DEVICE:
#if CONFIG_VESYNC_SDK_TIMEBASE_ENABLE
        // 时基信息是相当于配网信息的存在，只在删除设备的时候清除
        vesync_timebase_clear();
#endif
        break;
    default:
        break;
    }

    SDK_LOG(LOG_INFO, "Delete user data.\n");

    // 删除历史数据和缓存数据，设备运行在默认状态
    if (s_dev && s_dev->dev_clear_data_cb)
    {
        s_dev->dev_clear_data_cb(src_type, rst_type);
        SDK_LOG(LOG_INFO, "Delete history data.\n");
    }
}

/**
* @brief 时间戳更新标志是否使能
* @return bool               [true时禁止更新时间戳；false时，允许更新时间戳]
*/
bool vesync_device_is_ts_update_disable(void)
{
    VCOM_NULL_PARAM_CHK(s_dev, return false);
    return s_dev->ts_update_disable;
}

/**
* @brief 更新时间戳
* @param[in] uint32_t           [时间戳]
* @param[in] bool               [true时禁止更新时间戳；false时，允许更新时间戳]
*/
void vesync_device_set_ts_update_status(uint32_t ts, bool disable)
{
    vhal_utils_update_system_time(ts, 0);
    // 标志位修改时，才进行操作
    if (s_dev && s_dev->ts_update_disable != disable)
    {
        SDK_LOG(LOG_INFO, "disable ts update flag is %d.\n", disable);
        s_dev->ts_update_disable = disable;
        if (s_dev->ts_update_disable)
        {
            vhal_utils_stop_sntp();
        }
        else
        {
            vhal_utils_start_sntp();
        }
    }
}


/**
* @brief 更新时间
* @param[in]  utc_time     [utc时间戳]
* @param[in]  time_zone    [时区]
*/
void vesync_device_update_system_time(uint32_t utc_time, int8_t time_zone)
{
    if (s_dev && !(s_dev->ts_update_disable))
    {
        vhal_utils_update_system_time(utc_time, time_zone);
    }
}

/**
 * @brief  获取配置信息保存扇区，打印固件及设备相关信息等
 */
void vesync_device_print_info(void)
{
    //设备MAC地址
    char wifi_mac_str[MAC_ADDR_STR_MAX_LEN] = {0};
#if defined(PR_FW_TYPE) && (PR_FW_TYPE == 0)
    char sdk_ver[8] = {0};
#endif
    if (VHAL_OK != vhal_utils_get_dev_mac(VHAL_MAC_WIFI_STA, wifi_mac_str, sizeof(wifi_mac_str)))
    {
        snprintf(wifi_mac_str, MAC_ADDR_STR_MAX_LEN, "unknown");
    }

    SDK_LOG(LOG_WARN,
            "\n---------------Device Info---------------\n"
            "  Device MAC: %s\n"
            "  Device CID: %s\n"
            "  Device type: %s\n"
            "  Device model: %s\n"
            "  Device alias model: %s\n"
#if defined(PR_FW_TYPE) && (PR_FW_TYPE == 0)
            "  Firmware type: debug\n"
            "  Platform SDK version: %s-%s\n"
#else
            "  Firmware type: release\n"
#endif
            "  Hardware version: %s\n"
            "  Vesync SDK version: %s\n"
            "  Firmware version: %s\n"
            "  Country code: %s\n"
            "----------------------------------------\n",
            wifi_mac_str, vesync_device_get_cid(),
            vesync_cfg_get_type(), vesync_cfg_get_model(), vesync_cfg_get_alias_model(),
#if defined(PR_FW_TYPE) && (PR_FW_TYPE == 0)
            vhal_utils_get_chip_name(), vhal_utils_get_sdk_version(sdk_ver, sizeof(sdk_ver)),
#endif
            vesync_cfg_get_hw_version(),  // Wi-Fi模块硬件版本号(非产品硬件版本号)
            VESYNC_SDK_VERSION, vesync_cfg_get_fw_version(), vesync_cfg_get_country_code());
}

/**
* @brief 删除用户数据事件回调
*/
static int vesync_device_del_user_data_cb(void *data)
{
    UNUSED(data);
    vesync_device_delete_user_data(STAT_CHG_RSN_CONFIG_NET_STR, DEV_DEL_USER_CFG);
    return SDK_OK;
}

/**
* @brief 订阅EVENT_DEL_USER_DATA事件
*/
static void vesync_device_subscribe_event(void)
{
    vesync_event_subscribe(EVENT_DEL_USER_DATA, SUB_ID_DEVICE, vesync_device_del_user_data_cb);
}

/**
 * @brief 设置升级信息
 */
static void vesync_device_set_fw_info(void)
{
    uint32_t idx = 0;

    if (vesync_cfg_get_ota_type_ble())
    {
        snprintf(s_dev->fw_info[idx].plugin_name, sizeof(s_dev->fw_info[idx].plugin_name), VESYNC_BLE_DEFAULT_PLUGIN_NAME);
        s_dev->fw_info[idx].main_fw = false;
        s_dev->fw_info[idx].is_upgrade = true;
        s_dev->fw_info[idx].priority = idx;
        s_dev->fw_info[idx++].type = UPG_TP_BLE;
    }

    if (vesync_cfg_get_total_mcu_num() >= 1)
    {
        snprintf(s_dev->fw_info[idx].plugin_name, sizeof(s_dev->fw_info[idx].plugin_name), VESYNC_MCU_DEFAULT_PLUGIN_NAME);
        s_dev->fw_info[idx].main_fw = false;
        s_dev->fw_info[idx].is_upgrade = (PR_OTA_TYPE_MCU&0x1) > 0 ? true:false;    // bit0
        s_dev->fw_info[idx].priority = idx;
        s_dev->fw_info[idx++].type = UPG_TP_MCU;
    }

    if (vesync_cfg_get_total_mcu_num() >= 2)
    {
        snprintf(s_dev->fw_info[idx].plugin_name, sizeof(s_dev->fw_info[idx].plugin_name), VESYNC_MCU2_DEFAULT_PLUGIN_NAME);
        s_dev->fw_info[idx].main_fw = false;
        s_dev->fw_info[idx].is_upgrade = (PR_OTA_TYPE_MCU&0x2) > 0 ? true:false;    // bit1
        s_dev->fw_info[idx].priority = idx;
        s_dev->fw_info[idx++].type = UPG_TP_MCU2;
    }

    if (vesync_cfg_get_total_mcu_num() >= 3)
    {
        snprintf(s_dev->fw_info[idx].plugin_name, sizeof(s_dev->fw_info[idx].plugin_name), VESYNC_MCU3_DEFAULT_PLUGIN_NAME);
        s_dev->fw_info[idx].main_fw = false;
        s_dev->fw_info[idx].is_upgrade = (PR_OTA_TYPE_MCU&0x4) > 0 ? true:false;    // bit2
        s_dev->fw_info[idx].priority = idx;
        s_dev->fw_info[idx++].type = UPG_TP_MCU3;
    }

    if (vesync_cfg_get_ota_type_wifi())
    {
        snprintf(s_dev->fw_info[idx].plugin_name, sizeof(s_dev->fw_info[idx].plugin_name), VESYNC_WIFI_DEFAULT_PLUGIN_NAME);
        s_dev->fw_info[idx].main_fw = true;
        s_dev->fw_info[idx].is_upgrade = true;
        s_dev->fw_info[idx].priority = idx;
        s_dev->fw_info[idx++].type = UPG_TP_WIFI;
    }
}
/*-----------------------------------------------------------------------------*
 *                           外部函数API实现                                     *
 *-----------------------------------------------------------------------------*/

/**
* @brief  初始化设备信息
* @return     int                  [成功/失败]
*/
int vesync_device_init(void)
{
    int ota_num = 0;

    // 设备OTA个数
    if (vesync_cfg_get_ota_type_wifi())
    {
        ota_num++;
    }

    if (vesync_cfg_get_ota_type_ble())
    {
        ota_num++;
    }

    ota_num += vesync_cfg_get_total_mcu_num();

    vesync_production_cfg_init();

    if (ota_num <= 0)
    {
        SDK_LOG(LOG_ERROR, "device ota number error\n");
        return SDK_FAIL;
    }

    SDK_LOG(LOG_INFO, "device num is %d \n", ota_num);

    int dev_len = sizeof(vesync_dev_t) + sizeof(dev_fw_info_t)*ota_num;
    s_dev = (vesync_dev_t *)vesync_malloc(dev_len);
    if (s_dev == NULL)
    {
        SDK_LOG(LOG_ERROR, "Malloc fail for device init\n");
        return SDK_FAIL;
    }

    memset(s_dev, 0, dev_len);
    s_dev->total_ota_num = ota_num;

    vesync_device_set_fw_info();

    // 更新Wi-Fi固件的版本信息
    vesync_device_update_fw_ver(UPG_TP_WIFI, vesync_cfg_get_fw_version());

    // 读取产品CID
    uint8_t cid[36] = {0};
    uint16_t  cid_len = sizeof(cid);

    //int ret = vesync_device_flash_read_cid(cid, sizeof(cid));
    int ret = vesync_production_get_value_by_key(PRODUCTION_KEY_ID_CID,cid,&cid_len);
    if (ret != SDK_OK)
    {
        SDK_LOG(LOG_ERROR, "device cid read fail\n");
    }

    snprintf(s_dev->cid, sizeof(s_dev->cid), "%s", cid);

    s_dev->dev_clear_data_cb = NULL;
    s_dev->dev_reset_pre_reboot_cb = NULL;
    s_dev->ts_update_disable = false;

    vesync_device_subscribe_event();

    return SDK_OK;
}

/**
* @brief  释放设备资源
* @return  none
*/
void vesync_device_deinit(void)
{
    if (s_dev)
    {
        vesync_free(s_dev);
        s_dev = NULL;
    }
}

/**
* @brief 获取产品ota类型配置信息
* @return  uint8_t            [获取可进行ota的设备个数]
*/
uint8_t vesync_device_get_ota_num(void)
{
    VCOM_NULL_PARAM_CHK(s_dev, return 0);
    return s_dev->total_ota_num;
}


/**
* @brief 更新各固件版本信息
* @param[in]  type                 [固件类型]
* @param[in]  p_ver                [固件版本]
* @return     int                  [成功/失败]
*/
int vesync_device_update_fw_ver(FW_TYPE_E type, char *p_ver)
{
    uint8_t idx = 0;
    VCOM_NULL_PARAM_CHK(p_ver, return SDK_FAIL);
    VCOM_NULL_PARAM_CHK(s_dev, return SDK_FAIL);

    SDK_LOG(LOG_DEBUG, "type: %d, p_ver: %s\n", type, p_ver);

    for (idx = 0; idx < s_dev->total_ota_num; idx++)
    {
        if (type == s_dev->fw_info[idx].type)
        {
            snprintf(s_dev->fw_info[idx].cur_firm_ver, sizeof(s_dev->fw_info[idx].cur_firm_ver), "%s", p_ver);
            break;
        }
    }

    if (idx >= s_dev->total_ota_num)
    {
        SDK_LOG(LOG_ERROR, "Unknown OTA type(0x%x)!!\n", type);
        return SDK_FAIL;
    }

    return SDK_OK;
}


/**
* @brief 更新各固件升级优先顺序
* @param[in]  type                 [固件类型]
* @param[in]  priority             [优先级，数值越小优先级越高]
* @return     int                  [成功/失败]
*/
int vesync_device_update_fw_priority(FW_TYPE_E type, uint8_t priority)
{
    VCOM_NULL_PARAM_CHK(s_dev, return SDK_FAIL);
    uint8_t idx = 0;

    for (idx = 0; idx < s_dev->total_ota_num; idx++)
    {
        if (type == s_dev->fw_info[idx].type)
        {
            s_dev->fw_info[idx].priority = priority;
            break;
        }
    }

    if (idx >= s_dev->total_ota_num)
    {
        SDK_LOG(LOG_ERROR, "Unknow OTA type(0x%x)!!\n", type);
        return SDK_FAIL;
    }

    return SDK_OK;
}


/**
* @brief 更新固件的插件名(plugin_name)，在默认基础上添加后缀
* @param[in]  type                 [固件类型]
* @param[in]  p_suffix             [插件名后缀]
* @return     int                  [成功/失败]
*/
int vesync_device_add_plugin_name_suffix(FW_TYPE_E type, const char *p_suffix)
{
    VCOM_NULL_PARAM_CHK(p_suffix, return SDK_FAIL);
    VCOM_NULL_PARAM_CHK(s_dev, return SDK_FAIL);

    uint8_t idx = 0;
    char plugin_name[MAX_PLUGIN_NAME_STR_LEN];

    for (idx = 0; idx < s_dev->total_ota_num; idx++)
    {
        if (type == s_dev->fw_info[idx].type)
        {
            memset(plugin_name, 0, sizeof(plugin_name));
            switch (type)
            {
                case UPG_TP_WIFI:
                    snprintf(plugin_name, sizeof(plugin_name), "%s-C%s", VESYNC_WIFI_DEFAULT_PLUGIN_NAME, p_suffix);
                    break;

                case UPG_TP_BLE:
                    snprintf(plugin_name, sizeof(plugin_name), "%s-C%s", VESYNC_BLE_DEFAULT_PLUGIN_NAME, p_suffix);
                    break;

                case UPG_TP_MCU:
                    snprintf(plugin_name, sizeof(plugin_name), "%s-C%s", VESYNC_MCU_DEFAULT_PLUGIN_NAME, p_suffix);
                    break;

                case UPG_TP_MCU2:
                    snprintf(plugin_name, sizeof(plugin_name), "%s-C%s", VESYNC_MCU2_DEFAULT_PLUGIN_NAME, p_suffix);
                    break;

                case UPG_TP_MCU3:
                    snprintf(plugin_name, sizeof(plugin_name), "%s-C%s", VESYNC_MCU3_DEFAULT_PLUGIN_NAME, p_suffix);
                    break;
                default:
                    SDK_LOG(LOG_ERROR, "Not supported upgrade type\n");
                    break;
            }

            memset(s_dev->fw_info[idx].plugin_name, 0, sizeof(s_dev->fw_info[idx].plugin_name));
            snprintf(s_dev->fw_info[idx].plugin_name, sizeof(s_dev->fw_info[idx].plugin_name), "%s", plugin_name);
            break;
        }
    }

    if (idx >= s_dev->total_ota_num)
    {
        SDK_LOG(LOG_ERROR, "Unknow FW type(0x%x)!!\n", type);
        return SDK_FAIL;
    }

    return SDK_OK;
}

/**
* @brief 获取固件的插件名(plugin_name)信息
* @param[in]  type                 [固件类型]
* @return     char*                [成功：固件的plugin_name，失败："InvalidType"]
*/
char *vesync_device_get_plugin_name_by_type(FW_TYPE_E type)
{
    VCOM_NULL_PARAM_CHK(s_dev, return (char *)VESYNC_INVALID_PLUGIN_NAME);

    uint8_t idx = 0;
    for (idx = 0; idx < s_dev->total_ota_num; idx++)
    {
        if (type == s_dev->fw_info[idx].type)
        {
            return s_dev->fw_info[idx].plugin_name;
        }
    }

    return (char *)VESYNC_INVALID_PLUGIN_NAME;
}

/**
* @brief 根据下标获取各固件的信息
* @param[in]  idx                  [下标]
* @param[out] p_firw_info          [返回固件信息]
* @return     int                  [成功/失败]
*/
int vesync_device_get_fw_info_by_idx(uint8_t idx, dev_fw_info_t *p_fw_info)
{
    VCOM_NULL_PARAM_CHK(p_fw_info, return SDK_FAIL);
    VCOM_NULL_PARAM_CHK(s_dev, return SDK_FAIL);

    VCOM_LEN_IS_TOO_LARGE(idx, s_dev->total_ota_num - 1, return SDK_FAIL);

    snprintf(p_fw_info->cur_firm_ver, sizeof(p_fw_info->cur_firm_ver), "%s", s_dev->fw_info[idx].cur_firm_ver);
    snprintf(p_fw_info->plugin_name, sizeof(p_fw_info->plugin_name), "%s", s_dev->fw_info[idx].plugin_name);
    p_fw_info->main_fw = s_dev->fw_info[idx].main_fw;
    p_fw_info->priority = s_dev->fw_info[idx].priority;
    p_fw_info->is_upgrade = s_dev->fw_info[idx].is_upgrade;

    return SDK_OK;
}

/**
* @brief 获取各固件的信息
* @param[in]  type                 [固件类型]
* @param[out] p_firw_info          [返回固件信息]
* @return     int                  [成功/失败]
*/
int vesync_device_get_fw_info_by_type(FW_TYPE_E type, dev_fw_info_t *p_fw_info)
{
    VCOM_NULL_PARAM_CHK(p_fw_info, return SDK_FAIL);
    VCOM_NULL_PARAM_CHK(s_dev, return SDK_FAIL);

    uint8_t idx = 0;

    for (idx = 0; idx < s_dev->total_ota_num; idx++)
    {
        if (type == s_dev->fw_info[idx].type)
        {
            snprintf(p_fw_info->cur_firm_ver, sizeof(p_fw_info->cur_firm_ver), "%s", s_dev->fw_info[idx].cur_firm_ver);
            snprintf(p_fw_info->plugin_name, sizeof(p_fw_info->plugin_name), "%s", s_dev->fw_info[idx].plugin_name);
            p_fw_info->main_fw = s_dev->fw_info[idx].main_fw;
            p_fw_info->priority = s_dev->fw_info[idx].priority;
            p_fw_info->is_upgrade = s_dev->fw_info[idx].is_upgrade;
            break;
        }
    }

    if (idx >= s_dev->total_ota_num)
    {
        SDK_LOG(LOG_ERROR, "Unknown OTA type(0x%x)!!\n", type);
        return SDK_FAIL;
    }

#if 0
    SDK_LOG(LOG_DEBUG, "main_fw: %d, priority: %d, cur_firm_ver: %s, plugin_name: %s\n",
        p_fw_info->main_fw, p_fw_info->priority, p_fw_info->cur_firm_ver, p_fw_info->plugin_name);
#endif

    return SDK_OK;
}

/**
 * @brief 向device_info 结构体内填充cid
 * @param[in]  cid                  [设备cid]
 * @return     int                  [成功/失败]
 */
int vesync_device_set_cid(char *cid)
{
    VCOM_NULL_PARAM_CHK(cid, return SDK_FAIL);
    VCOM_NULL_PARAM_CHK(s_dev, return SDK_FAIL);

    snprintf(s_dev->cid, sizeof(s_dev->cid), "%s", cid);

    return SDK_OK;
}

/**
* @brief 获取设备cid
* @return  int                   [设备cid]
*/
char *vesync_device_get_cid(void)
{
    VCOM_NULL_PARAM_CHK(s_dev, return NULL);
    return (char *)s_dev->cid;
}


/**
 * @brief 设置account id
 * @param[in]  account_id           [用户ID]
 * @return     int                  [设置成功/失败]
 */
int vesync_device_set_account_id(char *account_id)
{
    VCOM_NULL_PARAM_CHK(account_id, return SDK_FAIL);
    VCOM_NULL_PARAM_CHK(s_dev, return SDK_FAIL);

    strncpy(s_dev->account_id, account_id, ACCOUNT_ID_STR_LEN);

    return SDK_OK;
}

/**
 * @brief 获取account id
 * @return     char*                [账号id]
 */
char *vesync_device_get_account_id(void)
{
    VCOM_NULL_PARAM_CHK(s_dev, return NULL);
    return (char *)s_dev->account_id;
}

/**
* @brief 重启设备
* @return     none
*/
void vesync_device_reboot(void)
{
    // 采用定时器实现重启，确保调用该接口的任务(也包括其他任务)处理完所有的事情。
    int ret = vesync_device_reboot_tmr_start();
    if (ret != SDK_OK)
    {
        // 创建定时器失败，延时FAC_RESET_REBOOT_DELAY_MS重启(保证消息传输到云端)，重启设备
        vesync_sleep(FAC_RESET_REBOOT_DELAY_MS);
        vhal_utils_restart(NULL);
    }
}


/**
 * @brief 清除设备数据回调
 *
 * @param cb                      [清除historydata分区数据接收回调函数]
 * @return int                    [成功/失败]
 */
int vesync_device_reg_clear_data_cb(vesync_device_clear_data_cb_t cb)
{
    VCOM_NULL_PARAM_CHK(s_dev, return SDK_FAIL);
    s_dev->dev_clear_data_cb = cb;
    return SDK_OK;
}

/**
 * @brief  设备仅删除网络配置信息
 */
void vesync_device_delete_net_cfg_data(void)
{
#if CONFIG_VESYNC_SDK_WIFI_ENABLE
    // 恢复出厂，灯效修改
    vesync_wifi_led_set_behavior(WIFI_LED_RESET_DEVICE);
#endif

    // 清除配网数据
    vesync_net_flash_clear_net_info();

    // 重启
    vesync_device_reboot();
}

/*
 * @brief  注册恢复出厂重启前其它事务处理回调函数
 * @param[in]  cb                   [恢复出厂重启前其它事务处理回调函数]
 * @return     none
 */
int vesync_device_reg_reset_pre_reboot_cb(vesync_device_reset_pre_reboot_cb_t cb)
{
    VCOM_NULL_PARAM_CHK(s_dev, return SDK_FAIL);
    s_dev->dev_reset_pre_reboot_cb = cb;
    return SDK_OK;
}

/*
 * @brief  设备恢复出厂，删除所有配置信息
 * @param[in]  report               [true通知云端， false不上报]
 * @param[in]  src_type             [消息(动作)来源]
 * @return     none
 */
void vesync_device_factory_reset(bool report, const char* src_type)
{
#if CONFIG_VESYNC_SDK_WIFI_ENABLE
    // 恢复出厂，灯效修改
    vesync_wifi_led_set_behavior(WIFI_LED_RESET_DEVICE);
    SDK_LOG(LOG_DEBUG, "Reset Wi-Fi led.\n");
#endif

    // 删除用户数据
    vesync_device_delete_user_data(src_type, DEV_DEL_DEVICE);
    SDK_LOG(LOG_DEBUG, "Delete user data.\n");

    // 清除配网数据
    vesync_net_flash_clear_net_info();

    if (report)
    {
#if CONFIG_VESYNC_SDK_REPORT_ENABLE
        vesync_report_reset_device();
#endif
    }

    if (s_dev->dev_reset_pre_reboot_cb)
    {
        //处理其它事务
        s_dev->dev_reset_pre_reboot_cb(NULL);
    }

    // 重启
    vesync_device_reboot();
}


