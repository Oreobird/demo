/**
*Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file    led_strip_timing.c
* @brief   倒计时接口
* @author  henrik
* @date     2021-10-29
*/

#include <string.h>
#include <stdio.h>

#include "vesync_common.h"
#include "vesync_log.h"
#include "vesync_timing.h"
#include "vesync_device.h"
#include "vesync_memory.h"

#include "led_strip_timing.h"
#include "led_strip_report.h"
#include "led_strip.h"
#include "led_strip_scene.h"

static ls_timing_t s_ls_timing;       // 保存timer

/**
* @brief timer时间到时执行的动作
* @param[in]  uint16_t                 [timer id]
* @return     void                     [none]
*/
static void ls_timing_act(uint16_t id)
{
    uint16_t temp_id = 0;
    int ret = 0;
    ls_ev_t ev;
    ev.act_src = LS_ACT_SRC_BYPASS;
    ev.event = LS_EV_CHANGE_SCENE;
    ev.scene_id = s_ls_timing.ctrl.id;

    if (LS_STATUS_ON == s_ls_timing.ctrl.action)
    {
        ret = led_strip_scene_id_check(s_ls_timing.ctrl.id, &temp_id);
        if (APP_OK == ret)
        {
            ev.scene_type = SCENE_TYPE_DEFINE;
            led_strip_app_task_notify(&ev);
        }
        else
        {
            APP_LOG(LOG_DEBUG, "scene:%d is not exit\n", s_ls_timing.ctrl.id);
        }
    }
    else
    {
        ev.scene_type = SCENE_TYPE_OFF;
        led_strip_app_task_notify(&ev);
    }

    // 上报云接口
    led_strip_report_timing_exec(&s_ls_timing, APP_OK, STAT_CHG_RSN_TIMER_STR);
    led_strip_timing_remove(id);                         // 删除应用层数据
}

/**
* @brief 新增一个timer
* @param[in]   total_sec   [timer定时时间]
* @param[out]  p_id        [timer id]
* @param[in]   ctrl        [控制参数]
* @return     int                    [错误码]
*/
int led_strip_timing_add(uint32_t total_sec, uint16_t *p_id, ls_ctrl_t ctrl)
{
    int ret = -1;

    if (NULL == p_id )
    {
        return APP_FAIL;
    }

    *p_id = MIN_LS_TIMER_ID;

    if (0 != s_ls_timing.id)
    {
        APP_LOG(LOG_ERROR, "Timing is exist!\n");
        return APP_FAIL;
    }

    s_ls_timing.id = *p_id;
    s_ls_timing.ctrl.action = ctrl.action;
    s_ls_timing.total_sec = total_sec;
    s_ls_timing.ctrl.id = ctrl.id;

    ret = vesync_timing_add(s_ls_timing.id, total_sec);
    if (SDK_OK != ret)
    {
        return APP_FAIL;
    }

    return APP_OK;
}

/**
* @brief 获取timer执行的动作
*/
ls_timing_t *led_strip_timing_get_act(void)
{
    return &s_ls_timing;
}

/**
* @brief 删除一个timer
* @param[in]  uint16_t                 [timer id]
* @return     int_t                    [成功/失败]
*/
int led_strip_timing_remove(uint16_t timer_id)
{
    if (s_ls_timing.id != timer_id)
    {
        APP_LOG(LOG_ERROR, "Input ID is %d, not equal %d!\n", timer_id, s_ls_timing.id);
        return APP_FAIL;
    }

    // 从队列中删除
    vesync_timing_remove(timer_id);

    // 清除缓存
    memset((uint8_t *)&s_ls_timing, 0, sizeof(ls_timing_t));

    return APP_OK;
}

/**
* @brief 删除imer
*/
void led_strip_timing_clear(void)
{

    // 从队列中删除
    vesync_timing_clear();

    // 清除缓存
    memset((uint8_t *)&s_ls_timing, 0, sizeof(ls_timing_t));
}


/**
* @brief 初始化timer
* @param void
*/
void led_strip_timing_init(void)
{
    // 注册定时器动作回调
    vesync_timing_reg_cb(ls_timing_act);
}
