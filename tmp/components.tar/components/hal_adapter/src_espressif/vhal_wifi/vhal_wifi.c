/**
 *  Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
 * @file        vhal_wifi.c
 * @brief       Wi-Fi驱动抽象层，封装厂家乐鑫 SDK提供的Wi-Fi相关接口
 * @author      Dongri.Su
 * @date        2021-04-20
 */

#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/semphr.h"
#include "freertos/task.h"
#include "freertos/event_groups.h"

#include "esp_idf_version.h"
#include "esp_heap_caps.h"
#include "esp_wifi.h"
#if defined(CONFIG_IDF_TARGET_ESP32) && defined(ESP_IDF_VERSION)
#if ESP_IDF_VERSION >= ESP_IDF_VERSION_VAL(4, 2, 0)
#include "esp_event.h"
#endif /* ESP_IDF_VERSION >= ESP_IDF_VERSION_VAL(4, 2, 0) */
#else
#include "esp_event_loop.h"
#endif /* ESP_IDF_VERSION */

#include "vesync_log.h"

//#include "vhal_wifi.h"
#include "vhal_wifi_internal.h"
#include "vhal_utils.h"


#ifdef ENABLE_DEL_TMR_SEM
static SemaphoreHandle_t s_sem_del_tmr_hd = NULL;           // 删除定时器二值信号量
#endif

static TimerHandle_t s_esp_wifi_cnnt_tmrhd = NULL;          // 定时重连wifi定时器
static EventGroupHandle_t s_esp_wifi_event_group = NULL;    // 网络事件标志组，从右往左，0位表示wifi状态，1位表示网络状态，置位代表连接成功

static vhal_esp_wifi_cfg_t s_esp_wifi_cfg;                  // Wi-Fi运行配置
static vhal_esp_wifi_status_t s_esp_wifi_status;            // Wi-Fi运行状态


/**
 * @brief report the wifi err reason according the 802.11 specification
 *        only report the name of the error reason, not the description.
 */
static wifi_reason_t esp_wifi_reason[] =
{
    {0,                                    "OTHER_REASON"},
    {WIFI_REASON_UNSPECIFIED,              "UNSPECIFIED_REASON"},
    {WIFI_REASON_AUTH_EXPIRE,              "INVALID_AUTHENTICATION"},
    {WIFI_REASON_AUTH_LEAVE,               "LEAVING_NETWORK_DEAUTH"},
    {WIFI_REASON_ASSOC_EXPIRE,             "REASON_INACTIVITY"},
    {WIFI_REASON_ASSOC_TOOMANY,            "NO_MORE_STAS"},
    {WIFI_REASON_NOT_AUTHED,               "INVALID_CLASS2_FRAME"},
    {WIFI_REASON_NOT_ASSOCED,              "INVALID_CLASS3_FRAME"},
    {WIFI_REASON_ASSOC_LEAVE,              "LEAVING_NETWORK_DISASSOC"},
    {WIFI_REASON_ASSOC_NOT_AUTHED,         "NOT_AUTHENTICATED"},
    {WIFI_REASON_DISASSOC_PWRCAP_BAD,      "UNACCEPTABLE_POWER_CAPABILITY"},
    {WIFI_REASON_DISASSOC_SUPCHAN_BAD,     "UNACCEPTABLE_SUPPORTED_CHANNELS"},
    {WIFI_REASON_IE_INVALID,               "REASON_INVALID_ELEMENT"},
    {WIFI_REASON_MIC_FAILURE,              "MIC_FAILURE"},
    {WIFI_REASON_4WAY_HANDSHAKE_TIMEOUT,   "4WAY_HANDSHAKE_TIMEOUT"},
    {WIFI_REASON_GROUP_KEY_UPDATE_TIMEOUT, "GK_HANDSHAKE_TIMEOUT"},
    {WIFI_REASON_IE_IN_4WAY_DIFFERS,       "HANDSHAKE_ELEMENT_MISMATCH"},
    {WIFI_REASON_GROUP_CIPHER_INVALID,     "REASON_INVALID_GROUP_CIPHER"},
    {WIFI_REASON_PAIRWISE_CIPHER_INVALID,  "REASON_INVALID_PAIRWISE_CIPHER"},
    {WIFI_REASON_AKMP_INVALID,             "REASON_INVALID_AKMP"},
    {WIFI_REASON_UNSUPP_RSN_IE_VERSION,    "UNSUPPORTED_RSNE_VERSION"},
    {WIFI_REASON_INVALID_RSN_IE_CAP,       "INVALID_RSNE_CAPABILITIES"},
    {WIFI_REASON_802_1X_AUTH_FAILED,       "802_1_X_AUTH_FAILED"},
    {WIFI_REASON_CIPHER_SUITE_REJECTED,    "REASON_CIPHER_OUT_OF_POLICY"},

    {WIFI_REASON_BEACON_TIMEOUT,           "ESP_BEACON_TIMEOUT"},
    {WIFI_REASON_NO_AP_FOUND,              "ESP_NO_AP_FOUND"},
    {WIFI_REASON_AUTH_FAIL,                "ESP_AUTH_FAIL"},
    {WIFI_REASON_ASSOC_FAIL,               "ESP_ASSOC_FAIL"},
    {WIFI_REASON_HANDSHAKE_TIMEOUT,        "ESP_HANDSHAKE_TIMEOUT"},
#ifdef CONFIG_IDF_TARGET_ESP32
    {WIFI_REASON_CONNECTION_FAIL,          "ESP32_CONNECTION_FAIL"},
#elif defined(CONFIG_IDF_TARGET_ESP8266)
    {WIFI_REASON_BASIC_RATE_NOT_SUPPORT,   "ESP8266_BASIC_RATE_NOT_SUPPORT"},
#endif
};

/*-----------------------------------------------------------------------------*
 *                           内部函数API实现                                         *
 *-----------------------------------------------------------------------------*/
/**
 * @brief 等待信号量
 * @param[in]  err                  [错误码]
 * @return      uint8_t             [成功/失败]
 */
static const char* vhal_esp_wifi_get_reason(int err)
{
    int i=0;

    for (i=0;  i< sizeof(esp_wifi_reason)/sizeof(wifi_reason_t); i++)
    {
        if (err == esp_wifi_reason[i].err){
            return esp_wifi_reason[i].reason;
        }
    }

    return esp_wifi_reason[0].reason;
}

#if ENABLE_DEL_TMR_SEM
/**
 * @brief  创建并获取信号量
 * @return      uint8_t             [成功/失败]
 */
static int32_t vhal_esp_wifi_wait_tmr_hd_semp(void)
{
    if (s_sem_del_tmr_hd == NULL)
    {
        s_sem_del_tmr_hd = xSemaphoreCreateBinary();
        // 创建成功，先释放1次，将初始值修改为1
        if (NULL != s_sem_del_tmr_hd)
            xSemaphoreGive(s_sem_del_tmr_hd);
    }

    // 正常模式下等待信号量，最大等待时长为2秒
    if (NULL != s_sem_del_tmr_hd)
    {
        if (xSemaphoreTake(s_sem_del_tmr_hd, pdMS_TO_TICKS(2000)) != pdPASS)
        {
            HAL_LOG(LOG_ERROR, "Take semaphore fail!\n");
            return VHAL_FAIL;
        }
        else
        {
            HAL_LOG(LOG_ERROR, "Take semaphore success!\n");
        }
    }
    else
    {
        // 创建失败，一般是堆空间导致
        HAL_LOG(LOG_ERROR, "Semaphore create fail!!\n");
        return VHAL_FAIL;
    }
    return VHAL_OK;
}

/**
 * @brief 释放信号量
 * @return      uint8_t             [成功/失败]
 */
static int32_t vhal_esp_wifi_release_tmr_hd_semp(void)
{
    if (NULL != s_sem_del_tmr_hd)
    {
        if (xSemaphoreGive(s_sem_del_tmr_hd) != pdTRUE)
        {
            HAL_LOG(LOG_ERROR, "Release semaphore fail!\n");
            return VHAL_FAIL;
        }
    }
    return VHAL_OK;
}
#endif

/*
 * @brief  更新Wi-Fi状态，当状态发生改变时通知上层
 * @param[in]  status                   [Wi-Fi状态]
 * @return     void
 */
static void vhal_esp_wifi_update_status(VHAL_WIFI_STATUS_E status)
{
    /* 网络状态发生改变，主动通知上一层(消息处理中心)     */
    s_esp_wifi_status.net_status = status;
    HAL_LOG(LOG_DEBUG, "Wi-Fi new status is %d\n", status);
    // 定义：vesync_connect_wifi_callback()
    if (NULL != s_esp_wifi_status.status_cb)
    {
        s_esp_wifi_status.status_cb(status);
    }
}

/*
 * @brief 获取当前模式下的Wi-Fi配置
 * @param[in]  interface                [Wi-Fi接口(AP/STA)]
 * @param[in]  cfg                      [Wi-Fi配置信息]
 * @return     int                      [执行成功，返回OK；执行失败，返回FAIL]
 */
static int32_t vhal_esp_wifi_get_config(wifi_interface_t interface, wifi_config_t *cfg)
{
    int ret = ESP_FAIL;

    if (NULL == cfg)
    {
        HAL_LOG(LOG_ERROR, "Input param is a null pointer!\n");
        return VHAL_FAIL;
    }

    ret = esp_wifi_get_config(interface, cfg);
    if (ESP_OK != ret)
    {
        HAL_LOG(LOG_ERROR, "Get config fail, ret = 0x%x!\n", ret);
        return VHAL_FAIL;
    }

    return VHAL_OK;
}

/*
 * @brief  厂商SDK中的Wi-Fi认证方式转换为vesync平台的认证方式
 * @param[in]  mode                     [Wi-Fi驱动返回的auth mode]
 * @return     VHAL_WIFI_AUTH_MODE_E    [vesync平台支持的auth mode]
 */
static VHAL_WIFI_AUTH_MODE_E vhal_esp_wifi_conv_auth_mode(wifi_auth_mode_t mode)
{
    switch (mode)
    {
        case WIFI_AUTH_OPEN:
            return VHAL_WIFI_AUTH_OPEN;
        case WIFI_AUTH_WEP:
            return VHAL_WIFI_AUTH_WEP;
        case WIFI_AUTH_WPA_PSK:
            return VHAL_WIFI_AUTH_WPA_PSK;
        case WIFI_AUTH_WPA2_PSK:
            return VHAL_WIFI_AUTH_WPA2_PSK;
        case WIFI_AUTH_WPA_WPA2_PSK:
            return VHAL_WIFI_AUTH_WPA_WPA2_PSK;
        case WIFI_AUTH_WPA2_ENTERPRISE:
            return VHAL_WIFI_AUTH_WPA2_ENTERPRISE;

#if defined(CONFIG_IDF_TARGET_ESP32) && defined(ESP_IDF_VERSION)

#if ESP_IDF_VERSION >= ESP_IDF_VERSION_VAL(4, 2, 0)
        case WIFI_AUTH_WPA3_PSK:
            return VHAL_WIFI_AUTH_WPA3_PSK;
        case WIFI_AUTH_WPA2_WPA3_PSK:
            return VHAL_WIFI_AUTH_WPA2_WPA3_PSK;
#endif /* ESP_IDF_VERSION >= ESP_IDF_VERSION_VAL(4, 2, 0) */

#if ESP_IDF_VERSION >= ESP_IDF_VERSION_VAL(4, 3, 0)
        case WIFI_AUTH_WAPI_PSK:
            return VHAL_WIFI_AUTH_WAPI_PSK;
#endif /* ESP_IDF_VERSION >= ESP_IDF_VERSION_VAL(4, 3, 0) */

#endif /* ESP_IDF_VERSION */

        default:
            return VHAL_WIFI_AUTH_MAX;
    }
}

/*
 * @brief  停止Wi-Fi
 * @return     void
 */
static void vhal_esp_wifi_stop(void)
{
    if (false == s_esp_wifi_status.stop_flag)
    {
        s_esp_wifi_status.stop_flag = true;
        ESP_ERROR_CHECK(esp_wifi_stop());
        vhal_esp_wifi_update_status(VHAL_WIFI_INIT);
        HAL_LOG(LOG_DEBUG, "ESP Wi-Fi stop.\n");
    }
    else
    {
        HAL_LOG(LOG_DEBUG, "ESP Wi-Fi already stop.\n");
    }
}


/*
 * @brief  获取设备网络信息(gw/mask/dns)
 * @param[in]  char*            [字符串格式的ip地址]
 * @return void
 */
static void vhal_esp_wifi_get_netif_info(void)
{
    esp_err_t ret = ESP_FAIL;
    char ip_addr[IP_ADDR_STR_MAX_LEN] = {0};
    char gw_addr[IP_ADDR_STR_MAX_LEN] = {0};
    char mask_addr[IP_ADDR_STR_MAX_LEN] = {0};
    char dns_addr[IP_ADDR_STR_MAX_LEN] = {0};
    char dns_addr2[IP_ADDR_STR_MAX_LEN] = {0};
    tcpip_adapter_ip_info_t sta_ip;
    tcpip_adapter_dns_info_t dns;

    memset(&sta_ip, 0, sizeof(tcpip_adapter_ip_info_t));
    ret = tcpip_adapter_get_ip_info(TCPIP_ADAPTER_IF_STA, &sta_ip);
    if (ESP_OK == ret)
    {
        snprintf(ip_addr, sizeof(ip_addr), "%s", ip4addr_ntoa(&sta_ip.ip));
        snprintf(gw_addr, sizeof(gw_addr), "%s", ip4addr_ntoa(&sta_ip.gw));
        snprintf(mask_addr, sizeof(mask_addr), "%s", ip4addr_ntoa(&sta_ip.netmask));
    }

    memset(&dns, 0, sizeof(tcpip_adapter_dns_info_t));
#if defined(CONFIG_IDF_TARGET_ESP32) && defined(ESP_IDF_VERSION)

#if ESP_IDF_VERSION >= ESP_IDF_VERSION_VAL(4, 2, 0)
    ret = tcpip_adapter_get_dns_info(TCPIP_ADAPTER_IF_STA, ESP_NETIF_DNS_MAIN, &dns);
#endif /* ESP_IDF_VERSION >= ESP_IDF_VERSION_VAL(4, 2, 0) */

#else
    ret = tcpip_adapter_get_dns_info(TCPIP_ADAPTER_IF_STA, TCPIP_ADAPTER_DNS_MAIN, &dns);
#endif /* ESP_IDF_VERSION */
    if (ESP_OK == ret)
    {
        snprintf(dns_addr, sizeof(dns_addr), "%s", ip4addr_ntoa((ip4_addr_t *)&dns.ip));
    }

    memset(&dns, 0, sizeof(tcpip_adapter_dns_info_t));
#if defined(CONFIG_IDF_TARGET_ESP32) && defined(ESP_IDF_VERSION)

#if ESP_IDF_VERSION >= ESP_IDF_VERSION_VAL(4, 2, 0)
    ret = tcpip_adapter_get_dns_info(TCPIP_ADAPTER_IF_STA, ESP_NETIF_DNS_BACKUP, &dns);
#endif /* ESP_IDF_VERSION >= ESP_IDF_VERSION_VAL(4, 2, 0) */

#else

    ret = tcpip_adapter_get_dns_info(TCPIP_ADAPTER_IF_STA, TCPIP_ADAPTER_DNS_BACKUP, &dns);
#endif /* ESP_IDF_VERSION */
    if (ESP_OK == ret)
    {
        snprintf(dns_addr2, sizeof(dns_addr2), "%s", ip4addr_ntoa((ip4_addr_t *)&dns.ip));
    }

    HAL_LOG(LOG_DEBUG, "Device got IP: %s, GW: %s, mask: %s, DNS: %s(%s).\n", ip_addr, gw_addr, mask_addr, dns_addr, dns_addr2);
}

/*
 * @brief  Wi-Fi重连回调
 * @param[in]  arg              [参数(未使用)]
 * @return void
 */
static void vhal_esp_wifi_reconnect_cb(void *arg)
{
    vhal_wifi_start();
    ESP_ERROR_CHECK(esp_wifi_connect());
}

/*
 * @brief 创建并启动Wi-Fi连接定时器
 * @param void
 */
static void vhal_esp_wifi_reconnect_tmr_start(void)
{
#ifdef ENABLE_DEL_TMR_SEM
    vhal_esp_wifi_wait_tmr_hd_semp();
#endif

    if (NULL == s_esp_wifi_cnnt_tmrhd)
    {
        //创建定时器，单次执行
        s_esp_wifi_cnnt_tmrhd = xTimerCreate("wifi_cnnt", pdMS_TO_TICKS(2000), pdFALSE, NULL, vhal_esp_wifi_reconnect_cb);
    }

    if (NULL != s_esp_wifi_cnnt_tmrhd)
    {
        if (xTimerStart(s_esp_wifi_cnnt_tmrhd, 1000) != pdPASS)
            HAL_LOG(LOG_ERROR, "Wi-Fi reconnect timer start fail!!\n");
        else
            HAL_LOG(LOG_DEBUG, "Wi-Fi reconnect timer start successful...\n");
    }
    else
    {
        HAL_LOG(LOG_ERROR, "Wi-Fi reconnect timer create fail!!\n");
    }

#ifdef ENABLE_DEL_TMR_SEM
    vhal_esp_wifi_release_tmr_hd_semp();
#endif
}

/**
 * @brief 停止Wi-Fi连接定时器
 */
void vhal_esp_wifi_reconnect_tmr_stop(void)
{
#ifdef ENABLE_DEL_TMR_SEM
    vhal_esp_wifi_wait_tmr_hd_semp();
#endif

    if(NULL != s_esp_wifi_cnnt_tmrhd)
    {
        if (xTimerStop(s_esp_wifi_cnnt_tmrhd, 1000) == pdPASS)
        {
            if (xTimerDelete(s_esp_wifi_cnnt_tmrhd, 1000) == pdPASS)
            {
                s_esp_wifi_cnnt_tmrhd = NULL;
            }
        }
    }

#ifdef ENABLE_DEL_TMR_SEM
    vhal_esp_wifi_release_tmr_hd_semp();
#endif
}

/*
 * @brief  乐鑫方案Wi-Fi重连函数
 * @param  void
 * @note   vesync平台自定义方式，为了降低烤箱/炸锅产品上的Wi-Fi模块表面温度，Wi-Fi重连改为2秒连接一次
 */
static void vhal_esp_wifi_connect(void)
{
    HAL_LOG(LOG_DEBUG, "ps_type = %d, cfgnet status = %d\n", s_esp_wifi_cfg.ps_type, s_esp_wifi_status.cfgnet_flag);
    // 运行在超低功耗模式
    if (VHAL_WIFI_PS_ULTRA_LOW == s_esp_wifi_cfg.ps_type)
    {
        if (s_esp_wifi_status.cfgnet_flag)   // 当前在配网
        {
            esp_wifi_connect();
        }
        else    // 非配网
        {
            vhal_esp_wifi_stop();
            vhal_esp_wifi_reconnect_tmr_start();
        }
    }
    else
    {
        esp_wifi_connect();
    }
}


#if defined(CONFIG_IDF_TARGET_ESP32) && defined(ESP_IDF_VERSION)
#if ESP_IDF_VERSION >= ESP_IDF_VERSION_VAL(4, 2, 0)
/*
 * @brief Wi-Fi连接事件应用程序任务回调函数
 * @param[in]  arg                      [保留未使用]
 * @param[in]  event_base               [事件表示]
 * @param[in]  event_id                 [事件ID]
 * @param[in]  event_data               [事件对应数据]
 * @return     void
 */
static void vhal_esp_wifi_event_hdl(void* arg, esp_event_base_t event_base, int32_t event_id, void* event_data)
{
    VHAL_WIFI_STATUS_E ostatus = VHAL_WIFI_INIT;

    HAL_LOG(LOG_DEBUG, "Event base: %s, id: %d.\n", event_base, event_id);

    if (WIFI_EVENT == event_base)
    {
        switch (event_id)
        {
            case WIFI_EVENT_STA_START:
                if (false == s_esp_wifi_status.scan_flag)      // 扫描状态不调用esp_wifi_connect()
                {
                    // 收到该事件，说明已经调用了esp_wifi_start()。修改dhcp hostname必须在esp_wifi_start()之后且esp_wifi_connect()之前，
                    vhal_utils_chg_dhcp_hostname(s_esp_wifi_cfg.hostname);
                    esp_wifi_connect();
                    HAL_LOG(LOG_DEBUG, "Wi-Fi STA Connecting to AP...\n");
                    ostatus = VHAL_WIFI_CONNECTING;
                }
                break;

            case WIFI_EVENT_STA_STOP:
                HAL_LOG(LOG_DEBUG, "Wi-Fi STA stop.\n");
                break;

            case WIFI_EVENT_STA_CONNECTED:
                HAL_LOG(LOG_DEBUG, "Wi-Fi STA Connect to AP successful, chan = %d.\n", vhal_wifi_get_channel());
                ostatus = VHAL_WIFI_CONNECTED;
                break;

            case WIFI_EVENT_STA_DISCONNECTED:
            {
                wifi_event_sta_disconnected_t* disconnected = (wifi_event_sta_disconnected_t*) event_data;
                uint8_t reason = disconnected->reason;
                HAL_LOG(LOG_DEBUG, "Disconnect reason(%d): %s\n", reason, vhal_esp_wifi_get_reason(reason));
                if (NULL != s_esp_wifi_status.disc_log_cb)
                    s_esp_wifi_status.disc_log_cb(vhal_esp_wifi_get_reason(reason));

                xEventGroupClearBits(s_esp_wifi_event_group, VHAL_WIFI_EVENT_BIT_CONNECT);
                xEventGroupSetBits(s_esp_wifi_event_group, VHAL_WIFI_EVENT_BIT_DISCONNECT);

                switch(reason)
                {
                    case WIFI_REASON_NO_AP_FOUND:
                        HAL_LOG(LOG_ERROR, "WIFI_NO_AP_FOUND\n");
                        ostatus = VHAL_WIFI_NO_AP_FOUND;
                        break;

                    case WIFI_REASON_AUTH_EXPIRE:
                    case WIFI_REASON_4WAY_HANDSHAKE_TIMEOUT:
                    case WIFI_REASON_HANDSHAKE_TIMEOUT:
                        HAL_LOG(LOG_ERROR,"WIFI_WRONG_PASSWORD\n");
                        ostatus = VHAL_WIFI_WRONG_PWD;
                        break;

                    case WIFI_REASON_AUTH_FAIL:
                    case WIFI_REASON_ASSOC_FAIL:
                    case WIFI_REASON_BEACON_TIMEOUT:
#ifdef CONFIG_IDF_TARGET_ESP32
                    case WIFI_REASON_CONNECTION_FAIL:
#elif defined(CONFIG_IDF_TARGET_ESP8266)
                    case WIFI_REASON_BASIC_RATE_NOT_SUPPORT:
#endif
                    default:
                        HAL_LOG(LOG_ERROR,"VESYNC_WIFI_CONNECT_FAIL\n");
                        ostatus = VHAL_WIFI_CONNECT_FAIL;
                        break;
                }

                // 上层调用esp_wifi_stop()停止Wi-Fi，不应该进行重连；Wi-Fi检测到异常断开，则应该再次进行重连。
                if (s_esp_wifi_status.stop_flag)
                {
                    HAL_LOG(LOG_DEBUG, "ignore WIFI_EVENT_STA_DISCONNECTED when wifi is stopping\n");
                }
                else
                {
                    vhal_esp_wifi_connect();
                }

                break;
            }

            case WIFI_EVENT_STA_AUTHMODE_CHANGE:
                HAL_LOG(LOG_DEBUG, "The auth mode of AP connected by ESP32 station changed.\n");
                break;

            // Wi-Fi work with AP mode
            case WIFI_EVENT_AP_START:
                HAL_LOG(LOG_INFO, "ESP soft-AP start");
                break;

            case WIFI_EVENT_AP_STOP:
                HAL_LOG(LOG_INFO, "ESP soft-AP stop");
                break;

            case WIFI_EVENT_AP_STACONNECTED:
            {
                wifi_event_ap_staconnected_t* event = (wifi_event_ap_staconnected_t*) event_data;
                HAL_LOG(LOG_INFO, "STA "MACSTR" join, AID=%d\n", MAC2STR(event->mac), event->aid);
                break;
            }

            case WIFI_EVENT_AP_STADISCONNECTED:
            {
                wifi_event_ap_stadisconnected_t* event = (wifi_event_ap_stadisconnected_t*) event_data;
                HAL_LOG(LOG_INFO, "STA "MACSTR" leave, AID=%d\n", MAC2STR(event->mac), event->aid);
                break;
            }

            // scan Wi-Fi list
            case WIFI_EVENT_SCAN_DONE:
            {
                uint16_t ap_cnt = 0, idx = 0;
                wifi_ap_record_t *ap_list = NULL;

                esp_wifi_scan_get_ap_num(&ap_cnt);
                if (ap_cnt == 0)
                {
                    HAL_LOG(LOG_ERROR, "No AP found.\n");
                    s_esp_wifi_status.scan_flag = false;
                    break;
                }

                ap_list = (wifi_ap_record_t *)malloc(sizeof(wifi_ap_record_t) * ap_cnt);
                if (NULL == ap_list)
                {
                    HAL_LOG(LOG_ERROR,"malloc error, ap_list is NULL!\n");
                    s_esp_wifi_status.scan_flag = false;
                    break;
                }
                memset(ap_list, 0, sizeof(wifi_ap_record_t) * ap_cnt);

                //确保只调用esp_wifi_scan_get_ap_records（）一次。
                ESP_ERROR_CHECK(esp_wifi_scan_get_ap_records(&ap_cnt, ap_list));
                s_esp_wifi_status.scan_flag = false;
                /* 保存扫描到的wifi列表 */
                if (ap_cnt > 0)
                {
                    for (idx = 0; idx < ap_cnt; idx ++)
                    {
                        if (NULL != s_esp_wifi_status.scan_cb)
                        {
                            s_esp_wifi_status.scan_cb(ap_list[idx].bssid, ap_list[idx].ssid,
                                        ap_list[idx].rssi, vhal_esp_wifi_conv_auth_mode(ap_list[idx].authmode), ap_cnt);
                        }
                    }
                }
                free(ap_list);
                ostatus = VHAL_WIFI_SCAN_DONE;
                break;
            }

            default:
                HAL_LOG(LOG_INFO, "Other Wi-Fi event(id = %d).\n", event_id);
                break;
        }
    }
    else if (IP_EVENT == event_base)
    {
        switch (event_id)
        {
            case IP_EVENT_STA_GOT_IP:
                //HAL_LOG(LOG_INFO, "Device got ip: %s.\n", ip4addr_ntoa(&event->event_info.got_ip.ip_info.ip));
                xEventGroupClearBits(s_esp_wifi_event_group, VHAL_WIFI_EVENT_BIT_DISCONNECT);
                xEventGroupSetBits(s_esp_wifi_event_group, VHAL_WIFI_EVENT_BIT_CONNECT);
                ostatus = VHAL_WIFI_GOT_IP;
                vhal_esp_wifi_get_netif_info();
                break;

            case IP_EVENT_STA_LOST_IP:
                // IP丢失后，可以通知应用层进行一些处理
                HAL_LOG(LOG_INFO, "Device lost ip.\n");
                xEventGroupClearBits(s_esp_wifi_event_group, VHAL_WIFI_EVENT_BIT_CONNECT);
                xEventGroupSetBits(s_esp_wifi_event_group, VHAL_WIFI_EVENT_BIT_DISCONNECT);
                ostatus = VHAL_WIFI_LOST_IP;
                break;

            case IP_EVENT_AP_STAIPASSIGNED:
                HAL_LOG(LOG_DEBUG, "Assign IP to connected sta.\n");
                break;
            case IP_EVENT_GOT_IP6:
                HAL_LOG(LOG_DEBUG, "Got IPv6 addr.\n");
                break;
            //case IP_EVENT_ETH_GOT_IP:
            //    break;
            //case IP_EVENT_PPP_GOT_IP:
            //    break;
            //case IP_EVENT_PPP_LOST_IP:
            //    break;
            default:
                HAL_LOG(LOG_DEBUG, "Other IP event.\n");
        }
    }

    vhal_esp_wifi_update_status(ostatus);
}
#endif /* ESP_IDF_VERSION >= ESP_IDF_VERSION_VAL(4, 2, 0) */

#else
/*
 * @brief Wi-Fi连接事件应用程序任务回调函数
 * @param[in]  ctx                  [保留未使用]
 * @param[in]  event                [系统事件指针]
 * @return     int32_t              [执行成功，返回OK；执行失败，返回FAIL]
 */
static int32_t vhal_esp_wifi_event_hdl(void *ctx, system_event_t *event)
{
    VHAL_WIFI_STATUS_E ostatus = VHAL_WIFI_INIT;
    HAL_LOG(LOG_DEBUG, "Wi-Fi APP event task id: %d.\n", event->event_id);
    //HAL_LOG(LOG_DEBUG, "Wi-Fi scan status: %d.\n", s_wifi_scan_status);
    //HAL_LOG(LOG_DEBUG, "Free heap size %d\n", xPortGetFreeHeapSize());

    switch(event->event_id)
    {
        case SYSTEM_EVENT_STA_START:
            if(false == s_esp_wifi_status.scan_flag)      //扫描状态不调用esp_wifi_connect()
            {
                // 收到该事件，说明已经调用了esp_wifi_start()。修改dhcp hostname必须在esp_wifi_start()之后且esp_wifi_connect()之前，
                vhal_utils_chg_dhcp_hostname(s_esp_wifi_cfg.hostname);
                esp_wifi_connect();
                HAL_LOG(LOG_DEBUG, "Wi-Fi STA Connecting to AP...\n");
                ostatus = VHAL_WIFI_CONNECTING;
            }
            break;
        case SYSTEM_EVENT_STA_STOP:
            HAL_LOG(LOG_DEBUG, "Wi-Fi STA stop.\n");
            break;
        case SYSTEM_EVENT_STA_GOT_IP:
            //HAL_LOG(LOG_INFO, "Device got ip: %s.\n", ip4addr_ntoa(&event->event_info.got_ip.ip_info.ip));
            xEventGroupClearBits(s_esp_wifi_event_group, VHAL_WIFI_EVENT_BIT_DISCONNECT);
            xEventGroupSetBits(s_esp_wifi_event_group, VHAL_WIFI_EVENT_BIT_CONNECT);
            ostatus = VHAL_WIFI_GOT_IP;
            vhal_esp_wifi_get_netif_info();
            break;
        case SYSTEM_EVENT_STA_LOST_IP:
            // IP丢失后，可以通知应用层进行一些处理
            HAL_LOG(LOG_INFO, "Device lost ip.\n");
            xEventGroupClearBits(s_esp_wifi_event_group, VHAL_WIFI_EVENT_BIT_CONNECT);
            xEventGroupSetBits(s_esp_wifi_event_group, VHAL_WIFI_EVENT_BIT_DISCONNECT);
            ostatus = VHAL_WIFI_LOST_IP;
            break;
        case SYSTEM_EVENT_STA_CONNECTED:
            HAL_LOG(LOG_DEBUG, "Wi-Fi STA Connect to AP successful, chan = %d.\n", vhal_wifi_get_channel());
            ostatus = VHAL_WIFI_CONNECTED;
            break;
        case SYSTEM_EVENT_STA_DISCONNECTED:
        {
            uint8_t reason = event->event_info.disconnected.reason;
            HAL_LOG(LOG_DEBUG, "Disconnect reason(%d): %s\n", reason, vhal_esp_wifi_get_reason(reason));
            if (NULL != s_esp_wifi_status.disc_log_cb)
                s_esp_wifi_status.disc_log_cb(vhal_esp_wifi_get_reason(reason));

            xEventGroupClearBits(s_esp_wifi_event_group, VHAL_WIFI_EVENT_BIT_CONNECT);
            xEventGroupSetBits(s_esp_wifi_event_group, VHAL_WIFI_EVENT_BIT_DISCONNECT);

            switch(reason)
            {
                case WIFI_REASON_NO_AP_FOUND:
                    HAL_LOG(LOG_ERROR,"VESYNC_WIFI_NO_AP_FOUND\n");
                    ostatus = VHAL_WIFI_NO_AP_FOUND;
                    break;

                case WIFI_REASON_AUTH_EXPIRE:
                case WIFI_REASON_4WAY_HANDSHAKE_TIMEOUT:
                case WIFI_REASON_HANDSHAKE_TIMEOUT:
                    HAL_LOG(LOG_ERROR,"VESYNC_WIFI_WRONG_PASSWORD\n");
                    ostatus = VHAL_WIFI_WRONG_PWD;
                    break;
#ifdef CONFIG_IDF_TARGET_ESP32
                case WIFI_REASON_CONNECTION_FAIL:
                    if (VHAL_WIFI_WRONG_PASSWORD == ostatus)
                    {
                        HAL_LOG(LOG_ERROR,"Ignore ESP32_CONNECTION_FAIL after got wrong password error.\n");
                        vhal_esp_wifi_connect();
                        return ESP_OK;
                    }
#elif defined(CONFIG_IDF_TARGET_ESP8266)
                case WIFI_REASON_BASIC_RATE_NOT_SUPPORT:
#endif
                case WIFI_REASON_BEACON_TIMEOUT:
                default:
                    HAL_LOG(LOG_ERROR,"VESYNC_WIFI_CONNECT_FAIL\n");
                    ostatus = VHAL_WIFI_CONNECT_FAIL;
                    break;
            }
            // 由于某些原因导致disconnect，若不是调用esp_wifi_disconnect()，则应该再次进行重连
            if (s_esp_wifi_status.stop_flag)
                HAL_LOG(LOG_DEBUG, "Ignore SYSTEM_EVENT_STA_DISCONNECTED when wifi is stopping\n");
            else
                vhal_esp_wifi_connect();
            break;
        }
        case SYSTEM_EVENT_STA_AUTHMODE_CHANGE:
            HAL_LOG(LOG_DEBUG, "The auth mode of AP connected by ESP32 station changed.\n");
            break;
        case SYSTEM_EVENT_SCAN_DONE:
        {
            /*if (!hal_api_wifi_scan_status())
            {
                HAL_LOG(LOG_DEBUG,"Wi-Fi scan do nothing!\n");
                break;
            }*/

            uint16_t apCount = 0;
            esp_wifi_scan_get_ap_num(&apCount);
            if (apCount == 0) {
                HAL_LOG(LOG_ERROR, "No AP found.\n");
                //vesync_reply_response("/queryWifiList",ERR_CONFIG_WIFI_DEIVER_INIT, "CONFIG_WIFI_DEIVER_INIT");
                s_esp_wifi_status.scan_flag = false;
                break;
            }

            wifi_ap_record_t *ap_list = (wifi_ap_record_t *)malloc(sizeof(wifi_ap_record_t) * apCount);
            if (!ap_list) {
                //vesync_reply_response("/queryWifiList",ERR_CONFIG_WIFI_DEIVER_INIT, "malloc_list_fail");
                HAL_LOG(LOG_ERROR,"malloc error, ap_list is NULL!\n");
                s_esp_wifi_status.scan_flag = false;
                break;
            }
            memset(ap_list, 0, sizeof(wifi_ap_record_t) * apCount);

            //确保只调用esp_wifi_scan_get_ap_records（）一次。
            ESP_ERROR_CHECK(esp_wifi_scan_get_ap_records(&apCount, ap_list));
            s_esp_wifi_status.scan_flag = false;
            /* 保存扫描到的wifi列表 */
            if(0 < apCount){
                int ap_index = 0;
                for(ap_index = 0; ap_index < apCount; ap_index ++) {
                    if (NULL != s_esp_wifi_status.scan_cb)
                        s_esp_wifi_status.scan_cb(ap_list[ap_index].bssid, ap_list[ap_index].ssid,
                                    ap_list[ap_index].rssi, vhal_esp_wifi_conv_auth_mode(ap_list[ap_index].authmode), apCount);
                }
            }
            free(ap_list);
            ostatus = VHAL_WIFI_SCAN_DONE;
            break;
        }
        // AP mode
        case SYSTEM_EVENT_AP_STACONNECTED:
            HAL_LOG(LOG_INFO, "Station:"MACSTR" join, AID=%d\n",    MAC2STR(event->event_info.sta_connected.mac),
                    event->event_info.sta_connected.aid);
            break;
        case SYSTEM_EVENT_AP_STADISCONNECTED:
            HAL_LOG(LOG_INFO, "Station:"MACSTR"leave, AID=%d\n",    MAC2STR(event->event_info.sta_disconnected.mac),
                    event->event_info.sta_disconnected.aid);
            break;
        default:
            HAL_LOG(LOG_INFO, "WiFi untreated event id: %d\n", event->event_id);
            break;
    }

    vhal_esp_wifi_update_status(ostatus);  //用于本文件处理
    return ESP_OK;
}
#endif /* ESP_IDF_VERSION */

/*
 * @brief  Wi-Fi作为STA时，初始化Wi-Fi驱动
 * @param[in]  power_save               [Wi-Fi省电模式标志位]
 * @return void
 */
static void vhal_esp_wifi_sta_init(VHAL_WIFI_PS_TYPE_E power_save)
{
    wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
    wifi_country_t wifi_country = { 0 };

    ESP_ERROR_CHECK(esp_wifi_init(&cfg));
    // 设置国家码需要在esp_wifi_init()之后，policy默认为auto，设备的国家码跟随AP的国家码；manual时，根据实际设置生效(不跟随AP)
    if (strlen(s_esp_wifi_cfg.country_code) > 0)
    {
        ESP_ERROR_CHECK(esp_wifi_get_country(&wifi_country) );
        HAL_LOG(LOG_DEBUG, "Wi-Fi default POLICY: %d, country code: %s, schan: %u, nchan: %u.\n",
            wifi_country.policy, wifi_country.cc, wifi_country.schan, wifi_country.nchan);

        strncpy(wifi_country.cc, s_esp_wifi_cfg.country_code, 2);      // 国家码都是只有2位的
        if (0 == strcmp(wifi_country.cc, "JP"))
        {
            wifi_country.policy = WIFI_COUNTRY_POLICY_MANUAL;
            wifi_country.schan = VHAL_WIFI_2G4_CHAN1;
            wifi_country.nchan = VHAL_WIFI_2G4_CHAN14;
        }
        else if (0 == strcmp(wifi_country.cc, "US"))
        {
            wifi_country.policy = WIFI_COUNTRY_POLICY_MANUAL;
            wifi_country.schan = VHAL_WIFI_2G4_CHAN1;
            wifi_country.nchan = VHAL_WIFI_2G4_CHAN11;
        }
        else if (0 == strcmp(wifi_country.cc, "CN") || 0 == strcmp(wifi_country.cc, "EU"))
        {
            wifi_country.policy = WIFI_COUNTRY_POLICY_MANUAL;
            wifi_country.schan = VHAL_WIFI_2G4_CHAN1;
            wifi_country.nchan = VHAL_WIFI_2G4_CHAN13;
        }
        //else  // 其他国家码，默认设置(policy为auto, cc为CN)
        //{
        //}
        ESP_ERROR_CHECK(esp_wifi_set_country(&wifi_country));

        ESP_ERROR_CHECK(esp_wifi_get_country(&wifi_country));
        HAL_LOG(LOG_DEBUG, "Wi-Fi reset POLICY: %d, country code: %s, schan: %u, nchan: %u.\n",
            wifi_country.policy, wifi_country.cc, wifi_country.schan, wifi_country.nchan);
    }

    ESP_ERROR_CHECK(esp_wifi_set_storage(WIFI_STORAGE_RAM));
    ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_STA));

    if(power_save >= VHAL_WIFI_PS_LOW)
    {
#if defined(CONFIG_IDF_TARGET_ESP32) && defined(ESP_IDF_VERSION)

#if ESP_IDF_VERSION >= ESP_IDF_VERSION_VAL(4, 2, 0)
        ESP_ERROR_CHECK(esp_wifi_set_ps(WIFI_PS_MIN_MODEM));            //开启wifi省电模式;
#endif /* ESP_IDF_VERSION >= ESP_IDF_VERSION_VAL(4, 2, 0) */

#else
        ESP_ERROR_CHECK(esp_wifi_set_ps(WIFI_PS_MODEM));            //开启wifi省电模式;
#endif
    }
    else
    {
        ESP_ERROR_CHECK(esp_wifi_set_ps(WIFI_PS_NONE));
    }
}

/*
 * @brief  Wi-Fi驱动卸载
 * @return    void
 */
static void vhal_esp_wifi_sta_deinit(void)
{
    ESP_ERROR_CHECK(esp_wifi_disconnect());
    ESP_ERROR_CHECK(esp_wifi_stop());
    ESP_ERROR_CHECK(esp_wifi_deinit());
}

/*
 * @brief  阻塞等待网络连接成功
 * @param[in]  wait_time                [等待时间，单位：毫秒]
 * @return     int                      [OK - 等待网络连接成功；FAIL - 等待网络连接超时]
 */
static int vhal_esp_wifi_wait_connected(int32_t wait_time)
{
    int ret = 0;
    if (NULL == s_esp_wifi_event_group)
    {
        HAL_LOG(LOG_INFO, "Evnet hdl null!!\n");
        return VHAL_FAIL;
    }

    //阻塞等待网络事件标志组网络连接标志置位
    ret = xEventGroupWaitBits(s_esp_wifi_event_group,
                              VHAL_WIFI_EVENT_BIT_CONNECT,
                              pdFALSE,
                              pdTRUE,
                              (TickType_t)wait_time / portTICK_RATE_MS);

    if (ret & VHAL_WIFI_EVENT_BIT_CONNECT)
        return VHAL_OK;
    else
        return VHAL_FAIL;
}


/*
 * @brief  阻塞等待网络断开成功
 * @param[in]  wait_time                    [等待时间，单位：毫秒]
 * @return     int                          [OK - 等待网络断开成功；FAIL - 等待网络断开超时]
 */
static int vhal_esp_wifi_wait_disconnected(uint32_t wait_time)
{
    int ret = 0;
    if (NULL == s_esp_wifi_event_group)
    {
        HAL_LOG(LOG_INFO, "Evnet hdl null!!\n");
        return VHAL_FAIL;
    }

    //阻塞等待网络事件标志组网络连接标志置位
    ret = xEventGroupWaitBits(s_esp_wifi_event_group,
                              VHAL_WIFI_EVENT_BIT_DISCONNECT,
                              pdFALSE,
                              pdFALSE,
                              wait_time / portTICK_RATE_MS);

    if (ret & VHAL_WIFI_EVENT_BIT_DISCONNECT)
        return VHAL_OK;
    else
        return VHAL_FAIL;
}


/*
 * @brief  切换Wi-Fi运行模式
 * @param[in]  wifi_mode                [Wi-Fi模式(AP/APSTA)]
 * @return     int                      [执行成功，返回OK；执行失败，返回FAIL]
 */
static int vhal_esp_wifi_chg_wifi_mode(VHAL_WIFI_MODE_E wifi_mode)
{
    int32_t ret = ESP_FAIL;
    wifi_mode_t esp_mode = WIFI_MODE_NULL;

    switch(wifi_mode)
    {
    case VHAL_WIFI_MODE_STA:
        esp_mode = WIFI_MODE_STA;
        break;
    case VHAL_WIFI_MODE_AP:
        esp_mode = WIFI_MODE_AP;
        break;
    case VHAL_WIFI_MODE_APSTA:
        esp_mode = WIFI_MODE_APSTA;
        break;
    default:
        HAL_LOG(LOG_ERROR, "Unknow wifi mode(%d)\n", wifi_mode);
        return VHAL_FAIL;
    }

    ret = esp_wifi_set_mode(esp_mode);
    if (ESP_OK != ret)
    {
        HAL_LOG(LOG_ERROR, "Set mode failed\n");
        return VHAL_FAIL;
    }

    return VHAL_OK;
}


/*-----------------------------------------------------------------------------*
 *                           外部函数API实现                                         *
 *-----------------------------------------------------------------------------*/
/*
 * @brief  初始化Wi-Fi模块
 * @param[in]  status_cb                [Wi-Fi的连接状态回调函数]
 * @param[in]  power_save               [Wi-Fi节能模式标志位]
 * @param[in]  p_hostname               [DHCP hostname]
 * @param[in]  p_country_code           [长度为2byte的国家码，如：US、EU、CN]
 * @return void
 */
void vhal_wifi_init(vhal_wifi_status_cb_t status_cb, VHAL_WIFI_PS_TYPE_E power_save, char *p_hostname, char *p_country_code)
{
    // 参数配置
    memset(&s_esp_wifi_cfg, 0, sizeof(vhal_esp_wifi_cfg_t));
    s_esp_wifi_cfg.ps_type = power_save;        // 保存Wi-Fi节能标志位
    if (NULL != p_country_code)
    {
        snprintf(s_esp_wifi_cfg.country_code, sizeof(s_esp_wifi_cfg.country_code), "%s", p_country_code);
    }
    if (NULL != p_hostname)
    {
        snprintf(s_esp_wifi_cfg.hostname, sizeof(s_esp_wifi_cfg.hostname), "%s", p_hostname);
    }

    // 状态初始化
    memset(&s_esp_wifi_status, 0, sizeof(vhal_esp_wifi_status_t));
    s_esp_wifi_status.chan = -1;
    s_esp_wifi_status.scan_flag = false;
    s_esp_wifi_status.stop_flag = true;
    s_esp_wifi_status.cfgnet_flag = false;
    s_esp_wifi_status.status_cb = status_cb;


    // 初始化Wi-Fi驱动
#if defined(CONFIG_IDF_TARGET_ESP32) && defined(ESP_IDF_VERSION)

#if ESP_IDF_VERSION >= ESP_IDF_VERSION_VAL(4, 2, 0)
    // esp-idf v4.2之后的SDK，接口发生变化
    esp_event_handler_instance_t instance_any_id;
    esp_event_handler_instance_t instance_got_ip;

    ESP_ERROR_CHECK(esp_netif_init());
    ESP_ERROR_CHECK(esp_event_loop_create_default());
    esp_netif_create_default_wifi_sta();
    ESP_ERROR_CHECK(esp_event_handler_instance_register(WIFI_EVENT,
                                                        ESP_EVENT_ANY_ID,
                                                        &vhal_esp_wifi_event_hdl,
                                                        NULL,
                                                        &instance_any_id));
    ESP_ERROR_CHECK(esp_event_handler_instance_register(IP_EVENT,
                                                        ESP_EVENT_ANY_ID,
                                                        &vhal_esp_wifi_event_hdl,
                                                        NULL,
                                                        &instance_got_ip));
#endif /* ESP_IDF_VERSION >= ESP_IDF_VERSION_VAL(4, 2, 0) */

#else
    tcpip_adapter_init();
    ESP_ERROR_CHECK(esp_event_loop_init(vhal_esp_wifi_event_hdl, NULL));
#endif

    // 配置Wi-Fi参数
    vhal_esp_wifi_sta_init(power_save);


    // 创建网络事件标志组，网络状态发生变化时及时通知上层
    s_esp_wifi_event_group = xEventGroupCreate();
    if (NULL == s_esp_wifi_event_group)
    {
        HAL_LOG(LOG_ERROR, "Create network event group fail!!\n");
    }

    HAL_LOG(LOG_INFO, "Init wifi module done.\n");
}

/*
 * @brief  卸载Wi-Fi驱动
 * @return void
 */
void vhal_wifi_deinit(void)
{
    if (NULL != s_esp_wifi_event_group)
    {
        vEventGroupDelete(s_esp_wifi_event_group);
        s_esp_wifi_status.status_cb = NULL;
    }

    vhal_esp_wifi_sta_deinit();

    HAL_LOG(LOG_INFO, "Deinit wifi module done.\n");
}

/*
 * @brief  Wi-Fi启动工作
 * @return void
 */
void vhal_wifi_start(void)
{
    ESP_ERROR_CHECK(esp_wifi_start());
    s_esp_wifi_status.stop_flag = false;
    HAL_LOG(LOG_DEBUG, "ESP Wi-Fi start.\n");
}

/*
 * @brief Wi-Fi停止工作
 * @return void
 */
void vhal_wifi_stop(void)
{
    // 超低功耗模式，先停止定时器
    if (VHAL_WIFI_PS_ULTRA_LOW == s_esp_wifi_cfg.ps_type)
        vhal_esp_wifi_reconnect_tmr_stop();
    vhal_esp_wifi_stop();
}

/*
 * @brief  设备作为STA，主动发起关联AP
 * @param[in]  p_ssid                   [Wi-Fi的名称]
 * @param[in]  p_pwd                    [Wi-Fi的密码]
 * @param[in]  auth_mode                [Wi-Fi加密模式]
 * @return     int                      [执行成功，返回OK；执行失败，返回FAIL]
 */
int vhal_wifi_connect(char *p_ssid, char *p_pwd, VHAL_WIFI_AUTH_MODE_E auth_mode)
{
    wifi_config_t wifi_config;

    (void)auth_mode;
    if (NULL == p_ssid)
    {
        HAL_LOG(LOG_ERROR, "Null ptr!\n");
        return VHAL_FAIL;
    }

    VHAL_WIFI_STATUS_E wifi_status = s_esp_wifi_status.net_status;

    // 如果WiFi已经连上，并且新配置的ssid/pwd和已关联的是一致，直接返回ok，不需要断开重连。
    if(VHAL_WIFI_GOT_IP == wifi_status)
    {
        memset(&wifi_config,0,sizeof(wifi_config_t));
        if ((VHAL_OK == vhal_esp_wifi_get_config(ESP_IF_WIFI_STA, &wifi_config)) &&
            (0 == strcmp((char *)wifi_config.sta.ssid, p_ssid) &&
            ((NULL != p_pwd && 0 == strcmp((char *)wifi_config.sta.password, p_pwd)) ||
            (NULL == p_pwd && 0 == strlen((char *)wifi_config.sta.password)))))
        {
            HAL_LOG(LOG_INFO, "Wi-Fi sta has been associated(%s/%s).\n", p_ssid, p_pwd);
            return VHAL_OK;
        }
    }

    if((VHAL_WIFI_GOT_IP == wifi_status) || (VHAL_WIFI_CONNECTED == wifi_status))
    {
        // 采用新的ssid/pwd，需要断开已有的连接
        HAL_LOG(LOG_INFO, "Wi-Fi disconnect......\n");
        ESP_ERROR_CHECK(esp_wifi_disconnect());//不加导致配网时发送扫描不到ap的bug;
        //vhal_wifi_stop();
        vhal_esp_wifi_wait_disconnected(3000);
    }
#if defined(CONFIG_IDF_TARGET_ESP32)
    s_esp_wifi_status.stop_flag = false;    // 停止Wi-Fi, ESP8266不能连续2次调用stop，否则会出现崩溃
#endif
    vhal_wifi_stop();

    if(NULL == p_pwd)
    {
        HAL_LOG(LOG_DEBUG, "Setting Wi-Fi SSID [%s], pwd [null]\n", p_ssid);
    }
    else
    {
        HAL_LOG(LOG_DEBUG, "Setting Wi-Fi SSID [%s], pwd [%s]\n", p_ssid, p_pwd);
    }

    memset(&wifi_config,0,sizeof(wifi_config_t));
    strncpy((char *)wifi_config.sta.ssid, (char *)p_ssid, WIFI_SSID_MAX_LEN); // 详见结构体wifi_config_t定义
    if(NULL != p_pwd)
    {
        strncpy((char *)wifi_config.sta.password, (char *)p_pwd, WIFI_PWD_MAX_LEN);
    }
#if defined(CONFIG_IDF_TARGET_ESP32) && defined(ESP_IDF_VERSION)

#if ESP_IDF_VERSION >= ESP_IDF_VERSION_VAL(4, 2, 0)
    // Configuration for Protected Management Frame. Will be advertized in RSN Capabilities in RSN IE
    wifi_config.sta.pmf_cfg.capable = true;
    wifi_config.sta.pmf_cfg.required = false;
#endif /* ESP_IDF_VERSION >= ESP_IDF_VERSION_VAL(4, 2, 0) */

#endif /* ESP_IDF_VERSION */

    ESP_ERROR_CHECK(esp_wifi_set_config(ESP_IF_WIFI_STA, &wifi_config));
    ESP_ERROR_CHECK(esp_wifi_start());

    // 修改dhcp hostname必须在esp_wifi_start()之后且esp_wifi_connect()之前
    vhal_utils_chg_dhcp_hostname(s_esp_wifi_cfg.hostname);
    //ESP_ERROR_CHECK(esp_wifi_connect());

    s_esp_wifi_status.stop_flag = false;        // Wi-Fi已启动，设置标志位为false
    HAL_LOG(LOG_INFO, "Wi-Fi start connect...........\n");

#if 0
    wifi_country_t country;
    esp_wifi_get_country(&country);
    HAL_LOG(LOG_DEBUG, "Wi-Fi country code is %s, start ch=%d, end ch=%d, txpower=%d.\n", country.cc, country.schan, country.nchan, country.max_tx_power);

    int8_t power = 0;
    esp_wifi_get_max_tx_power(&power);
    HAL_LOG(LOG_DEBUG, "power = %d\n", power);

    uint8_t protocol_bitmap = 0;
    esp_wifi_get_protocol(ESP_IF_WIFI_STA, &protocol_bitmap);
    HAL_LOG(LOG_DEBUG, "protocol_bitmap = 0x%02x\n", protocol_bitmap); // 11bgn, WIFI_PROTOCOL_11B|WIFI_PROTOCOL_11G|WIFI_PROTOCOL_11N
#endif

    return VHAL_OK;
}

/*
 * @brief  Wi-Fi运行在STA模式时，与router AP的连接状态
 * @param[in]  wait_time_ms             [最大阻塞等待时间]
 * @return     bool                     [关联AP成功且获取IP成功，返回true；否则返回false]
 */
bool vhal_wifi_get_link_status(int32_t wait_time_ms)
{
    // 已关联上AP，返回true，否则返回false
    if (VHAL_WIFI_GOT_IP == s_esp_wifi_status.net_status)
        return true;
    else
    {
        if (VHAL_OK == vhal_esp_wifi_wait_connected(wait_time_ms))
            return true;
        else
            return false;
    }
}

/*
 * @brief 设备作为STA时，与AP关联成功，检测到AP的接收信号强度
 * @param[in]  points                   [循环检测的次数]
 * @return     int                      [平均rssi(连续point个测试数据取平均)]
 */
int vhal_wifi_get_router_rssi(int points)
{
    wifi_ap_record_t ap_cfg;
    long rssi =0;
    int averageRSSI =0;

    for(int i=0;i < points;i++){
        if(esp_wifi_sta_get_ap_info(&ap_cfg) == 0){
            rssi += ap_cfg.rssi;
            vTaskDelay(25 / portTICK_PERIOD_MS);
        }
    }
    averageRSSI = rssi /points;
    HAL_LOG(LOG_DEBUG, "RSSI strength is %d.\n", averageRSSI);

    return averageRSSI;
}

/*
 * @brief 获取当前Wi-Fi信道
 * @return     int                      [Wi-Fi工作信道]
 */
int vhal_wifi_get_channel(void)
{
    uint8_t primary = 0;
    wifi_second_chan_t second = 0;
    esp_err_t ret = 0;

    ret = esp_wifi_get_channel(&primary, &second);
    if(ESP_OK == ret)
    {
        HAL_LOG(LOG_DEBUG, "Channel is %d.\n", primary);
        if (primary > VHAL_WIFI_2G4_CHAN1 && primary <= VHAL_WIFI_2G4_CHAN14)
            s_esp_wifi_status.chan = primary;
    }
    else
    {
        HAL_LOG(LOG_DEBUG, "Get channel error(%d).\n", ret);
    }

    return (int)primary;
}

/*
 * @brief 设备作为STA时，获取当前连接路由器成功所使用的ssid和密码。
 * @param[out] p_sta_cfg                [保存Wi-Fi连接使用的ssid和密码]
 * @return     int                      [执行成功，返回OK；执行失败，返回FAIL]
 */
int vhal_wifi_get_sta_cfg(vhal_wifi_sta_cfg_t *p_sta_cfg)
{
    if (NULL == p_sta_cfg)
    {
        HAL_LOG(LOG_ERROR, "Null ptr!\n");
        return VHAL_FAIL;
    }

    wifi_config_t sta_cfg;
    memset(&sta_cfg, 0, sizeof(wifi_config_t));
    memset((uint8_t *)p_sta_cfg, 0, sizeof(vhal_wifi_sta_cfg_t));
    if (VHAL_OK != vhal_esp_wifi_get_config(ESP_IF_WIFI_STA, &sta_cfg))
    {
        HAL_LOG(LOG_ERROR, "Get Wi-Fi STA cfg fail!\n");
        return VHAL_FAIL;
    }

    memcpy(p_sta_cfg->ssid, sta_cfg.sta.ssid, sizeof(sta_cfg.sta.ssid));
    memcpy(p_sta_cfg->pwd, sta_cfg.sta.password, sizeof(sta_cfg.sta.password));

    return VHAL_OK;
}

/*
 * @brief  注册配网时需要的Wi-Fi回调函数
 * @param[in]  scan_cb                  [Wi-Fi列表扫描结果回调]
 * @param[in]  disconn_cb               [Wi-Fi断开连接时回调]
 * @return void
 */
void vhal_wifi_reg_cfgnet_cb(vhal_wifi_scan_cb_t scan_cb, vhal_wifi_disc_log_cb_t disconn_cb)
{
    s_esp_wifi_status.scan_cb = scan_cb;
    s_esp_wifi_status.disc_log_cb = disconn_cb;

    s_esp_wifi_status.cfgnet_flag = true;         // 当前处于配网模式中
}

/*
 * @brief 撤销注册配网时需要的Wi-Fi回调函数
 */
void vhal_wifi_unreg_cfgnet_cb(void)
{
    s_esp_wifi_status.scan_cb = NULL;
    s_esp_wifi_status.disc_log_cb = NULL;

    s_esp_wifi_status.cfgnet_flag = false;        // 离开配网模式
}

/*
 * @brief 硬件抽象层设置设备为WiFi热点
 * @param[in]  wifi_mode  Wi-Fi模式(AP/APSTA)
 * @param[in]  ssid                     [ssid名称]
 * @param[in]  pwd                      [Wi-Fi密码]
 * @param[in]  chan                     [Wi-Fi信道]
 * @param[in]  auth_mode                [加密方式]
 * @return     int                      [执行成功，返回OK；执行失败，返回FAIL]
 */
int vhal_wifi_setup_ap_cfg(VHAL_WIFI_MODE_E wifi_mode, char *ssid, char* pwd, uint8_t chan, uint8_t auth_mode)
{
    wifi_config_t wifi_config;

    if(NULL == ssid || (NULL == pwd && VHAL_WIFI_AUTH_OPEN != auth_mode))
    {
        HAL_LOG(LOG_ERROR, "Null ptr!\n");
        return VHAL_FAIL;
    }

    memset(&wifi_config, 0, sizeof(wifi_config_t));

    if (VHAL_WIFI_MODE_AP == wifi_mode || VHAL_WIFI_MODE_APSTA == wifi_mode)
    {
        strncpy((char *)&(wifi_config.ap.ssid), ssid, WIFI_SSID_MAX_LEN); // 详见结构体wifi_config_t定义
        if(NULL != pwd)
            strncpy((char *)&(wifi_config.ap.password), pwd, WIFI_PWD_MAX_LEN);
        wifi_config.ap.ssid_len = strlen(ssid);
        wifi_config.ap.authmode = auth_mode;
        wifi_config.ap.max_connection = 4;
        if (s_esp_wifi_status.chan >= VHAL_WIFI_2G4_CHAN1 && s_esp_wifi_status.chan <= VHAL_WIFI_2G4_CHAN13)
            wifi_config.ap.channel = s_esp_wifi_status.chan;
        else
            wifi_config.ap.channel = chan;

        // 扫描Wi-Fi列表时，已经启动了Wi-Fi，切换模式时，先停止Wi-Fi
        vhal_wifi_stop();
        /* set STA panic in vhal_esp_wifi_connect when set mode with WIFI_MODE_AP */
        //ESP_ERROR_CHECK(esp_wifi_set_mode(wifi_mode));
        if (VHAL_OK != vhal_esp_wifi_chg_wifi_mode(wifi_mode))
            return VHAL_FAIL;
        ESP_ERROR_CHECK(esp_wifi_set_config(ESP_IF_WIFI_AP, &wifi_config));
        ESP_ERROR_CHECK(esp_wifi_start());
    }
    else
    {
        HAL_LOG(LOG_ERROR, "Unkown Wi-Fi mode (%d)!\n", wifi_mode);
        return VHAL_FAIL;
    }

    HAL_LOG(LOG_INFO, "%s is started\n", ssid);

    return VHAL_OK;
}

/*
 * @brief 关闭Wi-Fi的AP模式，不影响STA接口
 * @return     void            [none]
 */
void vhal_wifi_stop_ap_mode(void)
{
    esp_err_t ret = ESP_FAIL;
    ret = esp_wifi_set_mode(WIFI_MODE_STA);
    HAL_LOG(LOG_DEBUG, "Stop AP mode, ret = %d\n", ret);
}

/*
 * @brief  Wi-Fi开始扫描周围的AP热点
 * @return      int                     [执行成功，返回OK；执行失败，返回FAIL]
 */
int vhal_wifi_scan_start(void)
{
    int ret = ESP_FAIL;
    wifi_scan_config_t scanConf = {
                    .ssid = NULL,
                    .bssid = NULL,
                    .channel = 0,   // 为0，则会进行全通道扫描; 否则，将进行特定通道扫描。//
                    .show_hidden = false    /* 为0，则扫描忽略具有隐藏SSID的AP; 否则，扫描会将隐藏的AP视为正常AP。 */
    };

    if (s_esp_wifi_status.scan_flag)
    {
        HAL_LOG(LOG_INFO ,"Scanning Wi-Fi, skip.\n");
        return VHAL_OK;
    }

    // 需要在esp_wifi_scan_start()之前设置状态，因为扫描WiFi列表时，驱动返回事件SYSTEM_EVENT_SCAN_DONE后，函数才返回。
    s_esp_wifi_status.scan_flag = true;

    // 平台层在调用Wi-Fi扫描列表时，已经进行了esp_wifi_stop，ESP8266如果不先esp_wifi_start，会崩溃
    ESP_ERROR_CHECK(esp_wifi_start());
    ret = esp_wifi_scan_start(&scanConf, true);
    if (ESP_OK != ret){
        HAL_LOG(LOG_ERROR ,"Scanning Wi-Fi error: 0x%x\n", ret);
        // wifi未初始化，需要重新初始化WiFi驱动，

        // 如果Wi-Fi已经断开连接，调用esp_wifi_disconnect()会报错
        vhal_esp_wifi_stop();
        ESP_ERROR_CHECK(esp_wifi_deinit());
        vhal_esp_wifi_sta_init(VHAL_WIFI_PS_LOW); //初始化wifi驱动，再次进行扫描。
        vhal_wifi_start();
        vTaskDelay(50/portTICK_RATE_MS);    // 延时50ms,等待WiFi初始化完成

        // 可以考虑加一个网络状态事件等待消息，以便确定wifi驱动已经初始化.
        ret = esp_wifi_scan_start(&scanConf, true);
        if (ESP_OK != ret){
            HAL_LOG(LOG_ERROR ,"Scanning Wi-Fi error:0x%x\n", ret);
            s_esp_wifi_status.scan_flag = false;
            return VHAL_FAIL;
        }
    }

    HAL_LOG(LOG_DEBUG ,"Start scanning Wi-Fi.\n");

    return VHAL_OK;
}

/*
 * @brief  Wi-Fi停止扫描AP热点
 * @return      int                     [执行成功，返回OK；执行失败，返回FAIL]
 */
int vhal_wifi_scan_stop(void)
{
    int ret = ESP_FAIL;

    s_esp_wifi_status.scan_flag = false;

    ret = esp_wifi_scan_stop();
    if (ESP_OK != ret)
    {
        HAL_LOG(LOG_ERROR ,"Stop scanning Wi-Fi error :%d\n", ret);
        return VHAL_FAIL;
    }

    HAL_LOG(LOG_DEBUG ,"Stop scanning Wi-Fi.\n");

    return VHAL_OK;
}
