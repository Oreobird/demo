/**
*Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file    ledstrip_flash.c
* @brief   ledstrip flash 接口
* @author  Lind
*@date     2021-09-07
*/

#include <stdio.h>
#include <string.h>

#include "vesync_common.h"
#include "vesync_log.h"
#include "vesync_flash.h"
#include "vesync_device.h"
#include "vesync_klv.h"
#include "vesync_memory.h"

#include "ledstrip_flash.h"
#include "ledstrip.h"
#include "ledstrip_button.h"


#define LEDSTRIP_APP_DATA_VERSION (1)  // APP数据的配置版本

/**
 * @brief 保存开关数据到flash
 * @param[in]  data                 [开关配置]
 * @return     int8_t               [成功：APP_OK ，失败:：APP_FAIL]
 */
int8_t ls_save_config(ls_flash_data_t data)
{
    int ret = APP_FAIL;
    uint8_t *p_buf= NULL;
    int offset = 0;
    bool init_flag = true;
    uint8_t version = 0;
    data.scene_cnt = ls_get_button_cnt();
    if (NULL == (p_buf = (uint8_t *)vesync_malloc(LS_KLV_DATE_LEN)))
    {
        return APP_FAIL;
    }

    memset(p_buf, 0, LS_KLV_DATE_LEN);

    version = LEDSTRIP_APP_DATA_VERSION;
    offset +=  vesync_klv_set(p_buf+offset, LS_KLV_DATE_LEN-offset, LS_KEY_VERSION, sizeof(version), (uint8_t*)&version);
    offset +=  vesync_klv_set(p_buf+offset, LS_KLV_DATE_LEN-offset, LS_KEY_INIT, sizeof(bool), (uint8_t*)&init_flag);
    offset +=  vesync_klv_set(p_buf+offset, LS_KLV_DATE_LEN-offset, LS_KEY_STATUS, sizeof(data.status), (uint8_t*)&data.status);
    offset +=  vesync_klv_set(p_buf+offset, LS_KLV_DATE_LEN-offset, LS_KEY_MODEL, sizeof(data.model), (uint8_t*)&data.model);
    offset +=  vesync_klv_set(p_buf+offset, LS_KLV_DATE_LEN-offset, LS_KEY_LAST_MODE, sizeof(data.last_app_mode), (uint8_t*)&data.last_app_mode);
    offset +=  vesync_klv_set(p_buf+offset, LS_KLV_DATE_LEN-offset, LS_KEY_COLOR, sizeof(data.app_color), (uint8_t*)&data.app_color);
    offset +=  vesync_klv_set(p_buf+offset, LS_KLV_DATE_LEN-offset, LS_KEY_SCENE, sizeof(data.scene_cnt), (uint8_t*)&data.scene_cnt);
    ret = vhal_flash_write(PARTITION_CFG, LS_USER_CFG_KEY_DATA,p_buf,offset);

    vesync_free(p_buf);

    if (VHAL_OK != ret)
    {
        APP_LOG(LOG_ERROR, "Write data fail, ret = %d.\n", ret);
        return APP_FAIL;
    }
    return APP_OK;
}

/**
 * @brief 清除开关配置
 * @return int          [APP_OK/APP_FAIL]
 */
int ls_clear_config(void)
{
    int ret = APP_FAIL;

    ret = vhal_flash_erase_key(PARTITION_CFG, LS_USER_CFG_KEY_DATA);
    if (VHAL_OK != ret)
    {
        APP_LOG(LOG_ERROR, "Clear ledstrip data fail\n");
        return APP_FAIL;
    }

    return APP_OK;
}

/**
 * @brief 从flash中读取数据到内存
 * @param[out] p_data               [开关配置]
 * @return     int8_t               [成功：APP_OK ，失败:：APP_FAIL]
 */
int8_t ls_read_config(ls_flash_data_t *p_data)
{
    int ret = APP_FAIL;
    uint32_t len = 0;
    uint8_t *p_buf= NULL;
    uint8_t version = 0;

    if (NULL == p_data)
    {
        APP_LOG(LOG_ERROR, "Input parameters contain null pointers!\n");
        return APP_FAIL;
    }

     if(NULL == (p_buf = (uint8_t *)vesync_malloc(LS_KLV_DATE_LEN)))
    {
        return APP_FAIL;
    }

    len = LS_KLV_DATE_LEN;
    if (VHAL_OK != vhal_flash_read(PARTITION_CFG, LS_USER_CFG_KEY_DATA, p_buf, &len))
    {
        APP_LOG(LOG_ERROR, "Read ledstrip data fail, ret = %d.\n", ret);
        vesync_free(p_buf);
        return APP_FAIL;
    }

    vesync_klv_get(p_buf, len, LS_KEY_VERSION, sizeof(version), (uint8_t*)&version);
    vesync_klv_get(p_buf, len, LS_KEY_STATUS, sizeof(p_data->status), (uint8_t*)&p_data->status);
    vesync_klv_get(p_buf, len, LS_KEY_INIT, sizeof(p_data->init_flag), (uint8_t*)&p_data->init_flag);
    vesync_klv_get(p_buf, len, LS_KEY_MODEL, sizeof(p_data->model), (uint8_t*)&p_data->model);
    vesync_klv_get(p_buf, len, LS_KEY_LAST_MODE, sizeof(p_data->last_app_mode), (uint8_t*)&p_data->last_app_mode);
    vesync_klv_get(p_buf, len, LS_KEY_COLOR, sizeof(ls_led_hsv_t), (uint8_t*)&p_data->app_color);
    vesync_klv_get(p_buf, len, LS_KEY_SCENE, sizeof(p_data->scene_cnt), (uint8_t*)&p_data->scene_cnt);
    vesync_free(p_buf);

    return APP_OK;
}


/**
 * @brief 给Schedule应用层调用的读取对应配置的接口
 * @param[out] p_rd_buf      [指向数据读取的Buffer]
 * @param[out] p_rd_len      [指向储存读取的长度]
 * @return int               [成功：APP_OK， 失败：APP_FAIL]
 */
int ls_read_schedule_cfg(uint8_t *p_rd_buf, uint32_t *p_rd_len)
{
    int ret = APP_OK;

    if (NULL == p_rd_len)
    {
        APP_LOG(LOG_ERROR, "Input parameters contain null pointers!\n");
        return APP_FAIL;
    }

    /// @attention: p_rd_buf为NULL，返回存储数据的长度
    ret = vesync_flash_read(PARTITION_CFG, LS_SCHEDULE_MOD_CFG_KEY, p_rd_buf, p_rd_len);
    if (VHAL_OK != ret)
    {
        APP_LOG(LOG_ERROR, "Read schedule data fail, ret = %d.\n", ret);
        return APP_FAIL;
    }

    return APP_OK;
}

/**
 * @brief 给Schedule应用层调用的写入对应配置的接口
 * @param[in]  p_wr_buf      [指向被写入的Buffer]
 * @param[in]  len           [将被写入的数据长度]
 * @return int               [成功：APP_OK， 失败：APP_FAIL]
 */
int ls_write_schedule_cfg(uint8_t *p_wr_buf, uint32_t len)
{
    int ret = APP_OK;

    if (NULL == p_wr_buf || len == 0)
    {
        APP_LOG(LOG_ERROR, "Input parameters contain null pointers!\n");
        return APP_FAIL;
    }

    ret = vesync_flash_write(PARTITION_CFG, LS_SCHEDULE_MOD_CFG_KEY, p_wr_buf, len);
    if (VHAL_OK != ret)
    {
        APP_LOG(LOG_ERROR, "Write schedule data fail, ret = %d.\n", ret);
        return APP_FAIL;
    }

    return APP_OK;
}



