/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        task_test.cpp
 * @brief       os_adapter task测试用例
 * @author      Joshua
 * @date        2021-04-21
 */


#include <gtest/gtest.h>
#include "vesync_os.h"
#include "vesync_task.h"
#include "vesync_memory.h"

static void task_new_test(void *arg)
{
}

TEST(task_test, task_new)
{
    int ret = 0;
    ret = vesync_task_new(NULL, NULL, task_new_test, NULL, 1024, 0, NULL);
    EXPECT_EQ(ret, 0);

    ret = vesync_task_new("task_new_test", NULL, NULL, NULL, 1024, 0, NULL);
    EXPECT_EQ(ret, 1);

    ret = vesync_task_new("task_new_test", NULL, task_new_test, NULL, 1024, 0, NULL);
    EXPECT_EQ(ret, 0);

    vesync_task_t task;
    ret = vesync_task_new("task_new_test", NULL, task_new_test, NULL, 1024, 0, &task);
    EXPECT_EQ(ret, 0);
    printf("task id: %ld\n", *(long unsigned int*)(task));
}

static void task_getname_test1(void *arg)
{
    EXPECT_TRUE(std::string(vesync_task_name()) == std::string("getname_test"));
}

static void task_getname_test2(void *arg)
{
    EXPECT_FALSE(std::string(vesync_task_name()) == std::string("getname_test"));
}

static void task_getname_test3(void *arg)
{
    EXPECT_FALSE(std::string(vesync_task_name()) == std::string("getname_test"));
}



TEST(task_test, task_get_name)
{
    int ret = 0;
    ret = vesync_task_new("getname_test",
                          NULL, task_getname_test1,
                          NULL, 1024, 0, NULL);
    EXPECT_EQ(ret, 0);

    ret = vesync_task_new(NULL,
                          NULL, task_getname_test2,
                          NULL, 1024, 0, NULL);
    EXPECT_EQ(ret, 0);

    ret = vesync_task_new("",
                          NULL, task_getname_test3,
                          NULL, 1024, 0, NULL);
    EXPECT_EQ(ret, 0);
}

#define TEST_MSG "Test_verify"

typedef struct
{
    char msg[16];
    int num;
} test_arg_t;

static void task_new_test_args(void *arg)
{
    test_arg_t *targ = (test_arg_t *)arg;
    EXPECT_STREQ(TEST_MSG, targ->msg);
    EXPECT_EQ(10, targ->num);
    vesync_free(targ);
}

TEST(task_test, task_new_with_args)
{
    int ret = 0;
    test_arg_t *test_arg = (test_arg_t *)vesync_malloc(sizeof(test_arg_t));
    snprintf(test_arg->msg, sizeof(test_arg->msg), "%s", TEST_MSG);
    test_arg->num = 10;

    ret = vesync_task_new(NULL, NULL, task_new_test_args, test_arg, 1024, 0, NULL);
    EXPECT_EQ(ret, 0);
}


