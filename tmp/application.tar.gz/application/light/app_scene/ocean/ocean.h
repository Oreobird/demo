/**
* Copyright © Vesync Technologies Co.Ltd. 2022. All rights reserved
* @file         ocean.h
* @brief        海洋场景注册
* @author       Joshua
* @date         2022-1-12
*/

#include <stdint.h>
#include "vesync_common.h"
#include "scene.h"

#ifndef __OCEAN_H__
#define __OCEAN_H__

#ifdef __cplusplus
extern "C" {
#endif


/**
 * @brief  海洋场景灯效实现初始化
 * @return int              [成功：APP_OK， 失败：APP_FAIL]
 */
int ocean_light_scene_impl_init(void);

/**
 * @brief  注册海洋场景灯效
 * @return  int             [成功：APP_OK，失败：APP_FAIL]
 */
int ocean_light_scene_reg(light_scene_t *light_scene);

/**
 * @brief  注销海洋场景灯效
 * @return  int             [成功：APP_OK，失败：APP_FAIL]
 */
int ocean_light_scene_unreg(void);

#ifdef __cplusplus
}
#endif

#endif




