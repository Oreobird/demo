/*
 * Copyright © Vesync Technologies Co.Ltd. 2019-2021. All rights reserved.
 * @file    vesync_net_service_private.h
 * @brief   网络服务私有头文件
 * @author  CharlesMei
 * @date    2021-05-27
 */


#ifndef __VESYNC_NET_SERVICE_PRIVATE_H__
#define __VESYNC_NET_SERVICE_PRIVATE_H__


#include <time.h>

#include "vhal_wifi.h"
#include "vhal_utils.h"

#include "vesync_net_service_internal.h"
#include "vesync_event_internal.h"

/* The following is the redirection of the interface called by this module */

#ifndef VERR_OK
#include "vesync_common.h"
#define VERR_OK SDK_OK
#define VERR_FAIL SDK_FAIL
#endif /* VERR_OK */

#ifndef NET_LOG
#include "vesync_log_internal.h"
#ifdef SDK_LOG
#define NET_LOG SDK_LOG
#else
#define NET_LOG(level, format, ...)
#endif /* SDK_LOG */
#endif /* NET_LOG */

#ifndef NET_UTIL_MEM_CHECK
#include "vesync_common.h"
#ifdef VCOM_NULL_PARAM_CHK
#define NET_UTIL_MEM_CHECK VCOM_NULL_PARAM_CHK
#else
#define NET_UTIL_MEM_CHECK(param, action)   \
    do                                      \
    {                                       \
        if (NULL == (param))                \
        {                                   \
            action;                         \
        }                                   \
    } while (0)
#endif /* VCOM_NULL_PARAM_CHK */
#endif /* NET_UTIL_MEM_CHECK */

#ifndef NET_UTIL_SAFE_FREE
#include "vesync_common.h"
#ifdef VCOM_SAFE_FREE
#define NET_UTIL_SAFE_FREE VCOM_SAFE_FREE
#else
#define NET_UTIL_SAFE_FREE(ptr)             \
    do                                      \
    {                                       \
        if (NULL != ptr)                    \
        {                                   \
            vesync_free(ptr);               \
            ptr = NULL;                     \
        }                                   \
    } while (0)
#endif /* VCOM_SAFE_FREE */
#endif /* NET_UTIL_SAFE_FREE */

#if CONFIG_VESYNC_SDK_WIFI_ENABLE
#include "vesync_wifi_led.h"
#else
#define vesync_wifi_led_set_behavior(...)
#endif /* CONFIG_VESYNC_SDK_WIFI_ENABLE */

#define VESYNC_PRINTF_FREE_HEAP()       \
    do                                  \
    {                                       \
        NET_LOG(LOG_DEBUG, "free_heap_size = %d\n", vhal_utils_get_free_heap_size());    \
    }while(0)

#ifndef UNUSED
#define UNUSED(x) (void)(x)
#endif /* UNUSED */

#define VERR_UPLOAD(x, y)


/* The above is the redirection of the interface called by this module */


#ifdef __cplusplus
extern "C"
{
#endif /* __cplusplus */

#if CONFIG_VESYNC_SDK_MQTT_ENABLE
#include "vesync_mqtt_config.h"
#define NET_CLIENT_BUFFER_SIZE  MQTT_BUFFER_SIZE_BYTE
#else
#define NET_CLIENT_BUFFER_SIZE 1024
#endif /* CONFIG_VESYNC_SDK_MQTT_ENABLE */

#ifdef PR_NET_TRANS_PROT
#define NET_TRANS_PROT PR_NET_TRANS_PROT
#else
#define NET_TRANS_PROT NETWORK_MQTT
#endif

#define NET_RECV_ACK_HD_MAX              (8)
#define NET_VERIFID_ACK_NUM              (2)
#define USER_CFG_KEY_NET_INFO            "net_info"      // 配网数据，详见net_info_t结构体定义
#define USER_CFG_KEY_RECONNECT_REASON    "rec_reason"    // 存储网络重连原因
#define NET_SERVICE_EVENT_PUBLISH_STR    "net_service"


/**
 * @brief struct for pair of qos1 message id and its callback when it is acked
 */
typedef struct
{
    int msg_id;
    net_recv_ack_cb_t ack_cb;
} net_recv_ack_handler_t;


/**
 * @brief 网络管理结构体
 */
typedef struct
{
    time_t old_ts;                 // 应用层协议断开记录，旧
    time_t new_ts;                 // 应用层协议断开记录，新
    bool wifi_timeout_flag;        // Wi-Fi连接超时标志，true为已超时
    bool serv_timeout_flag;        // 服务器连接超时标志，true为已超时

#if CONFIG_VESYNC_SDK_MQTT_ENABLE
    bool reset_net_cfg;            // 重连服务器时清零密码重连标志，false为清零密码重连
    bool net_disc_flag;            // 服务器断开记录点，用于应用层协议连续2min连接不上时，重连Wi-Fi
#endif
} network_mgt_t;


/**
 * @brief  客户端初始化函数
 * @return  int                     [成功：VERR_OK，失败：VERR_FAIL]
 */
typedef int (*vnet_cli_init_fn_t)(void);

/**
 * @brief  客户端连接函数
 * @param[in]  p_srv                [服务器地址]
 * @param[in]  p_pwd                [连接的用户密码，BLE/APN配网时为configKey，断开重连时为"0"，FFS配网时为token]
 * @param[in]  p_port               [mqtt连接端口， 指针置空则连接默认端口]
 * @param[in]  tls                  [tls选项]
 * @return  int                     [成功：VERR_OK，失败：VERR_FAIL]
 */
typedef int (*vnet_cli_connect_fn_t)(char *p_srv, char *ip, char *p_pwd, uint32_t *p_port, NETWORK_TLS_CA_E tls);

/**
 * @brief  客户端断开连接函数
 * @return  int                     [成功：VERR_OK，失败：VERR_FAIL]
 */
typedef int (*vnet_cli_disconnect_fn_t)(void);

/**
 * @brief  客户端发送函数
 * @param[in]   topic_type           [topic类型]
 * @param[in]   pData                [数据指针]
 * @param[in]   len                  [数据的长度]
 * @param[in]   qos                  [qos级别，当前支持0和1]
 * @return  int                      [成功：VERR_OK，失败：VERR_FAIL]
 */
typedef int (*vnet_cli_send_fn_t)(NET_DATA_TOPIC_TYPE_E topic_type, const char *p_data, int len, SEND_QOS_E qos, net_recv_ack_cb_t ack_cb);


/**
 * @brief  客户端获取在线状态
 * @return  VESYNC_NETWORK_STATUS_E     [客户端在线状态]
 */
typedef VESYNC_NETWORK_STATUS_E (*vnet_cli_status_get_fn_t)(void);

/**
 * @brief  客户端资源销毁
 */
typedef void (*vnet_cli_destroy_fn_t)(void);


/**
 * @brief  网络客户端对有关device的设置进行刷新
 * @note  在device设置更新时（例如进入产测前）调用
 */
typedef void (*vnet_cli_fresh_fn_t)(void);

/**
 * @brief  获取默认端口
 * @return  int             [端口号，错误返回-1]
 */
typedef int (*vnet_cli_get_default_port_fn_t)(void);

/**
 * @brief  bypass回调函数注册
 * @param[in]  cb
 */
typedef void (*vnet_cli_reg_bypass_recv_cb_fn_t)(vesync_net_msg_recv_cb_t cb);

/**
 * @brief  非bypass回调函数注册
 * @param[in]   cb
 */
typedef void  (*vnet_cli_reg_non_bypass_recv_cb_fn_t)(vesync_net_msg_recv_cb_t cb);


/**
 * @brief  云客户端结构体
 */
typedef struct
{
    NETWORK_APP_PROTOCOL_E protocol;                          // 网络应用层协议，默认为MQTT
    net_recv_ack_handler_t recv_ack_hd[NET_RECV_ACK_HD_MAX];  // list(array) of callback for specific qos1 message id when it is acked
    uint8_t recv_ack_hd_idx;                                  // index to the latest registered list item in recv_ack_hd

    vnet_cli_init_fn_t init;
    vnet_cli_connect_fn_t connect;
    vnet_cli_disconnect_fn_t disconnect;
    vnet_cli_send_fn_t send;
    vnet_cli_status_get_fn_t status_get;
    vnet_cli_destroy_fn_t destroy;
    vnet_cli_fresh_fn_t fresh;
    vnet_cli_get_default_port_fn_t get_default_port;
    vnet_cli_reg_bypass_recv_cb_fn_t reg_bypass_recv_cb;
    vnet_cli_reg_non_bypass_recv_cb_fn_t reg_non_bypass_recv_cb;
} vnet_cli_t;



/**
 * @brief       网络服务事件管理初始化
 * @return      int                 [成功/失败]
 * @note        使能所有的事件处理
 */
int vesync_net_event_init(void);

/**
 * @brief  事件通知接口
 * @param[in]  ev_id                [事件ID]
 * @param[in]  p_msg                [消息数据指针]
 */
void vesync_net_event_notify(EVENT_ID_E ev_id, void *p_msg);

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* __VESYNC_NET_SERVICE_PRIVATE_H__ */


