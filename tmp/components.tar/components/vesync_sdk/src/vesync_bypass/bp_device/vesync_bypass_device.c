/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_bypass_common.c
 * @brief       bypass处理接口
 * @date        2021-05-14
 */

#include <string.h>

#include "vesync_cfg.h"
#include "vesync_common.h"
#include "vesync_device.h"
#include "vesync_log_internal.h"
#include "vesync_bypass_internal.h"

/**
 * @brief "setLogLevel" method数据解析
 * @param p_trace_msg trace message
 * @param json数据指针
 * @return BYPASS_ERR_E
 */
static BYPASS_ERR_E bypass_method_set_log_level(bypass_trace_msg_t *p_trace_msg, cJSON *json)
{
    uint8_t change = 0;
    DEBUG_CONFIG_S dbg_cfg;
    cJSON *log_lvl = NULL;
    cJSON *log_raw_lvl = NULL;

    if ((NULL == json) || (NULL == p_trace_msg))
    {
        return BP_ERROR;
    }

    memset((uint8_t *)&dbg_cfg, 0, sizeof(DEBUG_CONFIG_S));

    log_lvl = cJSON_GetObjectItemCaseSensitive(json, "logLevel");
    if (cJSON_IsString(log_lvl))
    {
        if (strcmp(log_lvl->valuestring, "OFF") == 0)
        {
            dbg_cfg.log_level = LOG_DISABLE;
        }
        else if (strcmp(log_lvl->valuestring, "ALL") == 0 || strcmp(log_lvl->valuestring, "DEBUG") == 0)
        {
            dbg_cfg.log_level = LOG_DEBUG;
        }
        else if (strcmp(log_lvl->valuestring, "INFO") == 0)
        {
            dbg_cfg.log_level = LOG_INFO;
        }
        else if (strcmp(log_lvl->valuestring, "WARN") == 0)
        {
            dbg_cfg.log_level = LOG_WARN;
        }
        else if (strcmp(log_lvl->valuestring, "ERROR") == 0)
        {
            dbg_cfg.log_level = LOG_ERROR;
        }
        else
        {
            vesync_bypass_reply_pkg_err_msg(BP_ERR_PARA_ILLEGAL, p_trace_msg, "logLevel is invaild!");
            return BP_ERROR;
        }
        change |= DBG_CFG_CHANGE_LOG_LVL_FLAG;
    }

    log_raw_lvl = cJSON_GetObjectItemCaseSensitive(json, "logRawLevel");
    if (cJSON_IsString(log_raw_lvl))
    {
        if (strcmp(log_raw_lvl->valuestring, "OFF") == 0)
        {
            dbg_cfg.log_raw_level = LOG_DISABLE;
        }
        else if (strcmp(log_raw_lvl->valuestring, "ALL") == 0 || strcmp(log_raw_lvl->valuestring, "DEBUG") == 0)
        {
            dbg_cfg.log_raw_level = LOG_DEBUG;
        }
        else if (strcmp(log_raw_lvl->valuestring, "INFO") == 0)
        {
            dbg_cfg.log_raw_level = LOG_INFO;
        }
        else if (strcmp(log_raw_lvl->valuestring, "WARN") == 0)
        {
            dbg_cfg.log_raw_level = LOG_WARN;
        }
        else if (strcmp(log_raw_lvl->valuestring, "ERROR") == 0)
        {
            dbg_cfg.log_raw_level = LOG_ERROR;
        }
        else
        {
            vesync_bypass_reply_pkg_err_msg(BP_ERR_PARA_ILLEGAL, p_trace_msg, "logRawLevel is invaild!");
            return BP_ERROR;
        }
        change |= DBG_CFG_CHANGE_LOG_RAW_LVL_FLAG;
    }

    if (change > 0)
        vesync_flash_update_dbg_config(dbg_cfg, change);

    vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_trace_msg, NULL);

    return BP_OK;
}

/**
 * @brief "setCid" method数据解析
 * @param p_trace_msg trace message
 * @param json数据指针
 * @return BYPASS_ERR_E
 */
static BYPASS_ERR_E bypass_method_set_cid(bypass_trace_msg_t *p_trace_msg, cJSON *json)
{
    BYPASS_ERR_E by_ret = BP_OK;

    if ((NULL == json)||(NULL == p_trace_msg))
        return BP_ERROR;

    cJSON *json_data = cJSON_GetObjectItemCaseSensitive(json, "cid");
    if (cJSON_IsString(json_data))
    {
        SDK_LOG(LOG_DEBUG,"bypass_method_set_cid = %s \r\n", json_data->valuestring);

        uint8_t cid[64] = {0};
        int rd_ret = vesync_flash_read_cid(cid, sizeof(cid));
        if ((SDK_OK == rd_ret)/*&&(strlen((char*)cid) == CID_STR_LEN)*/)    //cid 已写入
        {
            cJSON *cid_json = cJSON_CreateObject();
            if (cid_json)
            {
                cJSON_AddStringToObject(cid_json, "cid", (char*)cid);
            }
            vesync_bypass_reply_noqos(BP_ERR_CID_EXIST, p_trace_msg, cid_json);
        }
        else
        {
            int write_ret  = vesync_flash_write_cid(json_data->valuestring);
            if (0 != write_ret)
            {
                by_ret = BP_ERR_ARG;
            }
            else
            {
                vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_trace_msg, NULL);
            }
        }
    }
    else
    {
        by_ret = BP_ERR_ARG;
    }

    return by_ret;
}


/**
 * @brief "setComplete" method数据解析
 * @param p_trace_msg trace message
 * @param json数据指针
 * @return BYPASS_ERR_E
 */
static BYPASS_ERR_E bypass_method_set_complete(bypass_trace_msg_t *p_trace_msg, cJSON *json)
{
    if ((NULL == json)||(NULL == p_trace_msg))    return BP_ERROR;
    BYPASS_ERR_E ret = BP_OK;

    uint32_t err_code = PRD_NO_ERR;


    cJSON *json_data = cJSON_GetObjectItemCaseSensitive(json, "complete");
    if (cJSON_IsString(json_data))
    {
        if (strncmp(json_data->valuestring, "ok", 2) == 0)
        {
            SDK_LOG(LOG_INFO,"production recv complete!\r\n");
            void* puback_cb = NULL;
#if CONFIG_VESYNC_SDK_PRODUCTION_ENABLE
            puback_cb = (void*)vesync_production_complete_ack;
#endif
            vesync_bypass_reply_qos(BP_ERR_NO_ERR, p_trace_msg, NULL, REPORT_QOS1, puback_cb);  //使用QOS1应答，确认服务器收到才认为产测成功
        }
        else
        {
            cJSON *json_err = cJSON_GetObjectItemCaseSensitive(json, "err");
            if (cJSON_IsNumber(json_err))
            {
                err_code = json_err->valueint;
                vesync_production_set_error_code(err_code, true);
                vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_trace_msg, NULL);  // 必须在vesync_production_set_status()之前
                vesync_production_set_status(PRODUCTION_TEST_FAIL);
            }
            else
            {
                ret = BP_ERR_ARG;
            }
        }
    }
    else
    {
        ret = BP_ERR_ARG;
    }

    return ret;
}


/**
 * @brief "resetDevice" method数据解析
 * @param p_trace_msg trace message
 * @param json数据指针
 * @return BYPASS_ERR_E
 */
static BYPASS_ERR_E bypass_method_reset_device(bypass_trace_msg_t *p_trace_msg, cJSON *json)
{
    SDK_LOG(LOG_DEBUG,"bypass_method_reset_device \r\n");

    if ((NULL == json)||(NULL == p_trace_msg))    return BP_ERROR;
    BYPASS_ERR_E ret = BP_OK;


    cJSON *json_data = cJSON_GetObjectItemCaseSensitive(json, "type");
    if (cJSON_IsString(json_data))
    {
        vesync_bypass_reply_noqos(0, p_trace_msg, NULL);  // 删除设备时会恢复出厂，先回复，再重启
        if (strcmp(json_data->valuestring, "delUser") == 0)
        {
            SDK_LOG(LOG_DEBUG, "delUser\r\n");
            vesync_device_clear_user_data(p_trace_msg->src_type, DEV_DEL_USER_CFG); //删除用户信息
        }
        else if (strcmp(json_data->valuestring, "delDevice") == 0)
        {
            SDK_LOG(LOG_DEBUG, "delDevice\r\n");
            vesync_device_factory_reset(true, p_trace_msg->src_type);  //删除配网信息+复位+用户信息
        }
        else if (strcmp(json_data->valuestring, "delConfig") == 0)
        {
            SDK_LOG(LOG_DEBUG, "delConfig\r\n"); //删除配网信息+复位

            vesync_device_delete_net_config_data();
        }
        else if (strcmp(json_data->valuestring, "reboot") == 0)
        {
            SDK_LOG(LOG_DEBUG, "reboot\r\n"); //重启设备

            vesync_device_reboot();
        }
        else
        {
            ret = BP_ERR_ARG;
        }
    }
    else
    {
        ret = BP_ERR_ARG;
    }

    return ret;
}


/**
 * @brief "setCid" method数据解析
 * @param p_trace_msg trace message
 * @param json数据指针
 * @return BYPASS_ERR_E
 */
static BYPASS_ERR_E bypass_method_set_timestamp(bypass_trace_msg_t *p_trace_msg, cJSON *json)
{

    if ((NULL == json)||(NULL == p_trace_msg))
        return BP_ERROR;

    BYPASS_ERR_E by_ret = BP_OK;
    uint32_t ts = 0;
    bool ts_update_flag = false;

    cJSON *json_ts = cJSON_GetObjectItemCaseSensitive(json, "ts");
    if (cJSON_IsNumber(json_ts))
    {
        ts = json_ts->valueint;
        SDK_LOG(LOG_DEBUG,"ts = %d.\n", ts);
    }
    else
    {
        by_ret = BP_ERR_ARG;
        goto exit;
    }

    cJSON *json_flag = cJSON_GetObjectItemCaseSensitive(json, "disable");
    if (cJSON_IsBool(json_flag))
    {
        ts_update_flag = json_flag->valueint;
        SDK_LOG(LOG_DEBUG,"disable ts update flag = %d.\n", ts_update_flag);
    }
    else
    {
        by_ret = BP_ERR_ARG;
        goto exit;
    }

    vesync_update_ts(ts, ts_update_flag);

exit:
    if (BP_OK == by_ret)
        vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_trace_msg, NULL);
    else
        vesync_bypass_reply_noqos(BP_ERR_PARA_ILLEGAL, p_trace_msg, NULL);

    return by_ret;
}

/**
 * @brief "debug cmd" method数据解析
 * @param p_trace_msg trace message
 * @param json数据指针
 * @return BYPASS_ERR_E
 */
static BYPASS_ERR_E bypass_method_debug_cmd(bypass_trace_msg_t *p_trace_msg, cJSON *json)
{
    BYPASS_ERR_E by_ret = BP_OK;

    if ((NULL == json)||(NULL == p_trace_msg))
        return BP_ERROR;

    cJSON *json_cmd = cJSON_GetObjectItemCaseSensitive(json, "productionTest");
    if (cJSON_IsString(json_cmd))
    {
        if (strcmp(json_cmd->valuestring, "exit") == 0)
        {
            vesync_flash_write_production_flag(false);
        }
#if defined(PR_FW_TYPE) && (PR_FW_TYPE == 0)    // release固件不允许通过该命令进入产测
        else if (strcmp(json_cmd->valuestring, "repeat") == 0)
        {
            vesync_flash_write_production_flag(true);
        }
#endif
        else
        {
            by_ret = BP_ERR_ARG;
        }
    }

    cJSON *json_data = cJSON_GetObjectItemCaseSensitive(json, "cid");
    if (cJSON_IsString(json_data))
    {

#if defined(PR_FW_TYPE) && (PR_FW_TYPE == 0)
        SDK_LOG(LOG_DEBUG,"set cid = %s \r\n", json_data->valuestring);
        // release固件不允许通过该命令修改cid
        if (SDK_OK != vesync_flash_write_cid(json_data->valuestring))
        {
            by_ret = BP_ERR_ARG;
        }
#else
        SDK_LOG(LOG_DEBUG,"Release FW not support!!\n");
#endif
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "netconfig");
    if (cJSON_IsString(json_data))
    {
         if ((strcmp(json_data->valuestring, "ble") == 0)||(strcmp(json_data->valuestring, "ap") == 0))
         {
            vesync_cfgnet_start();
         }
#if CONFIG_VESYNC_SDK_FFS_ENABLE
         else if (strcmp(json_data->valuestring, "ffs") == 0)
         {
            vesync_ffs_result_clean();
         }
#endif
    }

    if (BP_OK == by_ret)
        vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_trace_msg, NULL);

    return by_ret;
}


/**
 * @brief "setTcpDebug" method数据解析，开启/关闭开发者模式
 * @param[in]  p_trace_msg              [trace message]
 * @param[in]  json                     [数据指针]
 * @return     BYPASS_ERR_E             [bypass处理结果]
 */
static BYPASS_ERR_E bypass_method_set_tcp_debug_handle(bypass_trace_msg_t *p_trace_msg, cJSON *json)
{
    int ret = SDK_FAIL;
    BYPASS_ERR_E by_ret = BP_OK;
    bool enable = false;
    cJSON *json_data = NULL;
    DEBUG_CONFIG_S dbgcfg;

    if ((NULL == json) || (NULL == p_trace_msg))
    {
        return BP_ERROR;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "enabled");
    if (cJSON_IsBool(json_data))
    {
        enable = json_data->valueint;
    }
    else
    {
        by_ret = BP_ERR_ARG;
    }

    // 读取flash中的标志位，并和当前设置进行比较，不相同则更新flash中的数据
    memset((void *)&dbgcfg, 0, sizeof(dbgcfg));
    vesync_flash_read_dbg_config(&dbgcfg);
    //SDK_LOG(LOG_DEBUG, "enable_developer = 0x%x, enable = 0x%x\n", dbgcfg.enable_developer, enable);
    if (dbgcfg.enable_developer != enable)
    {
        dbgcfg.enable_developer = enable;
        ret = vesync_flash_update_dbg_config(dbgcfg, DBG_CFG_CHANGE_DEVELOPER_FLAG);
        if (SDK_OK != ret)
        {
            SDK_LOG(LOG_ERROR, "Update dbg config fail!\n");
            vesync_bypass_reply_noqos(BP_ERR_CMD_EXECUTE_FAIL, p_trace_msg, NULL);
            by_ret = BP_ERROR;
        }
        else
        {
#if CONFIG_VESYNC_SDK_DEVELOPER_ENABLE
            if (enable)
            {
                vesync_developer_start();       // 开启tcp调试口
            }
#endif
        }
    }

    if (BP_OK == by_ret)
        vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_trace_msg, NULL);

    return by_ret;
}


/**
 * @brief 获取设备工作状态 method数据解析
 * @param p_trace_msg trace message
 * @param json数据指针
 * @return BYPASS_ERR_E
 */
static BYPASS_ERR_E bypass_method_get_working_state_handle(bypass_trace_msg_t *p_trace_msg, cJSON *json)
{
    BYPASS_ERR_E ret = BP_OK;
    if (NULL == p_trace_msg)   return BP_ERROR;
    //查询无需解析json
    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_GET_WORKING_STATE);
    if (method_cb)
    {
        method_cb(p_trace_msg, NULL, 0);
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

    return ret;
}

/**
 * @brief 获取设备信息(非设备状态)
 * @param[in]  p_trace_msg              [trace message]
 * @param[in]  json                     [数据指针]
 * @return     BYPASS_ERR_E
 */
static BYPASS_ERR_E bypass_method_get_dev_info(bypass_trace_msg_t *p_trace_msg, cJSON *json)
{
    int ret = -1;
    char dev_mac[MAC_ADDR_STR_MAX_LEN] = {0};
    char ap_mac[MAC_ADDR_STR_MAX_LEN] = {0};
    char ip_buf[IP_ADDR_STR_MAX_LEN] = {0};      // 保存ip空间

    cJSON *json_data = NULL;
    net_info_t *p_net_info = NULL;
    bool tcp_debug = false;
    DEBUG_CONFIG_S dbgcfg;

    if (NULL == p_trace_msg)
    {
        return BP_ERROR;
    }

    // 1.获取设备信息
    ret = vhal_utils_get_dev_mac(VHAL_MAC_WIFI_STA, dev_mac, sizeof(dev_mac));
    if (VHAL_OK != ret || strlen(dev_mac) <= 0)
    {
        snprintf(dev_mac, MAC_ADDR_STR_MAX_LEN, "00:00:00:00:00:00");
    }

    ret = vhal_utils_get_dev_mac(VHAL_MAC_ROUTER, ap_mac, sizeof(ap_mac));
    if (VHAL_OK != ret || strlen(ap_mac) <= 0)
    {
        snprintf(ap_mac, MAC_ADDR_STR_MAX_LEN, "00:00:00:00:00:00");
    }

    memset((void *)&dbgcfg, 0, sizeof(dbgcfg));
    vesync_flash_read_dbg_config(&dbgcfg);

#if CONFIG_VESYNC_PLAT_DEVELOPER_ENABLE
    if (dbgcfg.enable_developer > 0)    // developer功能开启，才能启动开发者模式
    {
        tcp_debug = true;
    }
#endif
    p_net_info = vesync_net_service_get_net_cfg();

    // 2.json组装
    json_data = cJSON_CreateObject();
    if (NULL != json_data)
    {
        cJSON_AddStringToObject(json_data, "cid", vesync_device_get_cid());
        cJSON_AddStringToObject(json_data, "countryCode", PR_COUNTRY_CODE);
#if defined(PR_FW_TYPE) && (PR_FW_TYPE == 0)
        cJSON_AddStringToObject(json_data, "fwType", "debug");
#else
        cJSON_AddStringToObject(json_data, "fwType", "release");
#endif /* defined(PR_FW_TYPE) && (PR_FW_TYPE == 0) */
        cJSON_AddStringToObject(json_data, "fwVersion", PR_FW_VERSION);
        cJSON_AddStringToObject(json_data, "mac", dev_mac);
        cJSON_AddStringToObject(json_data, "routerMac", ap_mac);
        cJSON_AddStringToObject(json_data, "wifiSsid", (char *)p_net_info->station_config.wifiSSID);
        cJSON_AddStringToObject(json_data, "ip", vhal_utils_get_sta_ip(ip_buf, sizeof(ip_buf)));
        cJSON_AddBoolToObject(json_data,   "tcpDebug", tcp_debug);
    }

    // 3.回复
    vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_trace_msg, json_data);

    return BP_OK;
}

/**
 * @brief 串口通信测试
 * @param p_trace_msg trace message
 * @param json数据指针
 * @return BYPASS_ERR_E
 */
static BYPASS_ERR_E bypass_method_test_uart_handle(bypass_trace_msg_t *p_trace_msg, cJSON *json)
{
    BYPASS_ERR_E ret = BP_OK;
    if (NULL == p_trace_msg)   return BP_ERROR;

    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_TEST_UART);
    if (method_cb)
    {
        method_cb(p_trace_msg, NULL, 0);
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

    return ret;
}

#if defined(PR_FW_TYPE) && (PR_FW_TYPE == 0)

/**
 * @brief 修改设备的MAC地址
 * @param p_trace_msg trace message
 * @param json数据指针
 * @return bypass_err_t
 */
static BYPASS_ERR_E bypass_method_set_mac_addr(bypass_trace_msg_t *p_trace_msg, cJSON *json)
{
    int ret = -1;
    BYPASS_ERR_E bp_ret = BP_ERROR;
    char mac[MAX_MAC_STR_LEN] = {0};
    char type[BUF_SIZE_8B] = {0};
    cJSON *json_data = NULL;

    if (NULL == p_trace_msg)
        return BP_ERROR;

    json_data = cJSON_GetObjectItemCaseSensitive(json, "type");
    if (cJSON_IsString(json_data))
    {
        snprintf(type, sizeof(type), "%s", json_data->valuestring);
    }
    else
    {
        bp_ret = BP_ERR_ARG;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "mac");
    if (cJSON_IsString(json_data))
    {
        snprintf(mac, sizeof(mac), "%s", json_data->valuestring);

        if (0 == strcmp(type, "Wi-Fi"))
        {
            ret = vhal_utils_set_wifi_mac(mac);
        }
#if defined(CONFIG_VESYNC_HAL_BLE_ENABLE) && CONFIG_VESYNC_HAL_BLE_ENABLE
        else if (0 == strcmp(type, "BLE"))
        {
            ret = vhal_utils_set_ble_mac(mac);
        }
#endif
        else
        {
            bp_ret = BP_ERR_ARG;
        }

        if (VHAL_OK != ret)
        {
            vesync_bypass_reply_pkg_err_msg(BP_ERR_ARG, p_trace_msg, "Set MAC error");
            //bp_ret = BP_ERROR;
        }
        else
        {
            vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_trace_msg, NULL);
            bp_ret = BP_OK;
        }
    }
    else
    {
        bp_ret = BP_ERR_ARG;
    }


    return bp_ret;
}
#endif

static bypass_item_data_t device_method_tbl[] = {
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_SET_LOG_LEVEL,      "setLogLevel",          bypass_method_set_log_level, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_SET_CID,            "setCid",               bypass_method_set_cid, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_SET_COMPLETE,       "setComplete",          bypass_method_set_complete, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_RESET_DEVICE,       "resetDevice",          bypass_method_reset_device, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_SET_TS,             "setTimestamp",         bypass_method_set_timestamp, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_DEBUG_CMD,          "softDebugCmd",         bypass_method_debug_cmd, NULL},
    {BP_AUTH_MSG_FROM_MQTT,       BYPASS_METHOD_ID_SET_TCP_DEBUG,      "setTcpDebug",          bypass_method_set_tcp_debug_handle, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_GET_WORKING_STATE,  "getDeviceWorkingState", bypass_method_get_working_state_handle, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_GET_DEV_INFO,       "getDevInfo",           bypass_method_get_dev_info, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_TEST_UART,          "testUart",             bypass_method_test_uart_handle, NULL},
#if defined(PR_FW_TYPE) && (PR_FW_TYPE == 0)
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_SET_MAC,            "setMacAddr",           bypass_method_set_mac_addr, NULL},
#endif
};


void vesync_bypass_device_init(void)
{
    for (int i = 0; i < SIZEOF_ARRAY(device_method_tbl); i++)
    {
        bypass_item_t *item = vesync_bypass_init_item(&device_method_tbl[i]);
        if (item != NULL)
        {
            vesync_bypass_add_item(item);
        }
    }
}

