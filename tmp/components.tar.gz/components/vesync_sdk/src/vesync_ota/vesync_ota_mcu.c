/*
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file        vesync_ota_mcu.c
* @brief       OTA模块接口实现
* @date        2021-05-19
*/

#include "vesync_cfg_internal.h"
#if (PR_OTA_TYPE_MCU > 0)

#include <stddef.h>
#include <string.h>

#include "vhal_ota.h"
#include "vesync_memory.h"

#include "vesync_common.h"
#include "vesync_log_internal.h"
#include "vesync_uart_internal.h"
#include "vesync_ota_mcu_internal.h"

static vesync_ota_mcu_t s_ota_mcu;

/*-----------------------------------------------------------------------------*
*                                 内部函数实现                          *
*-----------------------------------------------------------------------------*/

/**
* @brief  串口发送函数
* @param[in] opcode                  [操作码]
* @param[in] p_dat                   [数据]
* @param[in] len                     [数据长度]
* @return int32_t                    [返回0表示成功，否则失败]
*/
static int32_t ota_mcu_uart_send(uint16_t opcode, uint8_t *p_dat, uint16_t len)
{
    uart_msg_send_t msg = {0};
    msg.type = UART_MSG_TYPE_CMD;
    msg.request_flag = 1;
    msg.status_code = 0;
    msg.opcode = opcode;
    msg.p_data = p_dat;
    msg.data_len = len;
    msg.p_extra_data = NULL;
    return vesync_uart_send(s_ota_mcu.uart_num, &msg);
}

/**
* @brief 串口应答函数
* @param[in] opcode                [操作码]
* @param[in] status_code           [状态码]
* @param[in] p_dat                 [数据]
* @param[in] len                   [数据长度]
* @return int32_t                  [返回0表示成功，否则失败]
*/
static int32_t ota_mcu_uart_send_ack(uint16_t opcode, uint16_t status_code,uint8_t *p_dat,uint16_t len)
{
    uart_msg_send_t msg = {0};
    msg.type = UART_MSG_TYPE_ACK;
    msg.request_flag = 0;
    msg.status_code = status_code;
    msg.opcode = opcode;
    msg.p_data = p_dat;
    msg.data_len = len;
    msg.p_extra_data = NULL;
    return vesync_uart_send(s_ota_mcu.uart_num, &msg);
}


/**
 * @brief 启动ota mcu命令
 * @return int32_t                [返回0表示成功，否则失败]
 */
static int32_t ota_mcu_start(void)
{
    int32_t ret = 0;
    ota_mcu_start_prot_t *p_ota_mcu_start_info = vesync_malloc(sizeof(ota_mcu_start_prot_t));

    memset(p_ota_mcu_start_info, 0, sizeof(ota_mcu_start_prot_t));
    p_ota_mcu_start_info->mtu = OTA_MCU_MAX_PACKET_LEN;
    memcpy(p_ota_mcu_start_info->sw_version, s_ota_mcu.upg_info.sw_version, 3);
    p_ota_mcu_start_info->bin_size = s_ota_mcu.upg_info.bin_size;
    p_ota_mcu_start_info->reserve = 0xffff;

    ret = ota_mcu_uart_send(OPC_OTA_MCU_START, (uint8_t *)p_ota_mcu_start_info, sizeof(ota_mcu_start_prot_t));
    VCOM_SAFE_FREE(p_ota_mcu_start_info);
    if (SDK_OK != ret)
    {
        return SDK_FAIL;
    }

    return SDK_OK;
}

/**
 * @brief 固件数据填充
 * @param[in]  req_len              [请求数据长度]
 * @param[in]  pkg_id               [packet_id]
 * @param[in]  offset               [offset]
 * @param[in]  pkg_data_len         [pkg_data_len]
 * @return  int32_t                 [成功：SDK_OK，失败：SDK_FAIL]
 */
static ota_mcu_bin_req_ack_prot_t *ota_mcu_req_pkg_create(uint32_t req_len, uint8_t pkg_id, uint32_t offset,
                                                                 uint16_t pkg_data_len)
{
    ota_mcu_bin_req_ack_prot_t *p_data = NULL;

    p_data = (ota_mcu_bin_req_ack_prot_t *)vesync_malloc(req_len);
    if (p_data == NULL)
    {
        return NULL;
    }

    memset(p_data, 0, req_len);
    p_data->packet_id = pkg_id;
    p_data->addr_offset = offset;
    p_data->data_len = pkg_data_len;

    return p_data;
}

/**
 * @brief 固件数据请求命令处理
 * @param[in]  quest_data           [命令数据]
 * @return  int32_t                 [成功：SDK_OK，失败：SDK_FAIL]
 */
static int32_t ota_mcu_bin_requst(ota_mcu_bin_req_prot_t *req_data)
{
    int32_t ret = 0;
    int32_t uart_snd_len = 0;
    ota_mcu_bin_req_ack_prot_t *p_data = NULL;
    uint32_t addr_offset = req_data->addr_offset;

    SDK_LOG(LOG_DEBUG,"ota_mcu_bin_requst,state:%d, offset= %d\n", s_ota_mcu.upg_state, addr_offset);

    if ((NULL != s_ota_mcu.ota_mcu_state_cb) && (OTA_MCU_STATE_BIN_REQ == s_ota_mcu.upg_state))
    {
        s_ota_mcu.ota_mcu_state_cb(s_ota_mcu.upg_state, NULL);
    }

    if (OTA_MCU_STATE_BIN_REQ != s_ota_mcu.upg_state)
    {
        p_data = ota_mcu_req_pkg_create(VESYNC_OTA_MCU_HEADER_LEN, OTA_MCU_PACKET_ID_OTA_OVER, 0, 0);
        if (NULL == p_data)
        {
            return SDK_FAIL;
        }

        uart_snd_len = p_data->data_len + VESYNC_OTA_MCU_HEADER_LEN;
        ret = ota_mcu_uart_send_ack(OPC_OTA_MCU_BIN_REQ, 0, (uint8_t *)p_data, uart_snd_len);
        vesync_free(p_data);

        return SDK_FAIL;
    }

    if (addr_offset < s_ota_mcu.upg_info.bin_size)
    {
        uint8_t pkg_id = 0;
        uint16_t pkg_data_len = 0;

        if ((s_ota_mcu.upg_info.bin_size - addr_offset) > s_ota_mcu.upg_info.mtu)
        {
            pkg_id = OTA_MCU_PACKET_ID_NORMAL;
            pkg_data_len = s_ota_mcu.upg_info.mtu;
        }
        else
        {
            pkg_id = OTA_MCU_PACKET_ID_END;
            pkg_data_len = s_ota_mcu.upg_info.bin_size - addr_offset;
        }

        p_data = ota_mcu_req_pkg_create(s_ota_mcu.upg_info.mtu + VESYNC_OTA_MCU_HEADER_LEN, pkg_id, addr_offset, pkg_data_len);
        if (NULL == p_data)
        {
            //TODO:FIXME
            //VERR_UPLOAD(VERR_LINK_MOD_COM(VERR_MEM_ALLOC_FAIL), vhal_get_free_heap_size());
            return SDK_FAIL;
        }

        ret = vhal_ota_read_bin_file(addr_offset, (char *)p_data->data, p_data->data_len);
        if (VHAL_OK != ret)
        {
            vesync_free(p_data);
            //TODO:FIXME
            //VERR_UPLOAD(VERR_RD_FW_FAIL, ret);
            return SDK_FAIL;
        }

        uart_snd_len = p_data->data_len + VESYNC_OTA_MCU_HEADER_LEN;
        ret =  ota_mcu_uart_send_ack(OPC_OTA_MCU_BIN_REQ, 0, (uint8_t *)p_data, uart_snd_len);
        vesync_free(p_data);
        if (SDK_OK != ret)
        {
            return SDK_FAIL;
        }

    }
    else
    {
        p_data = ota_mcu_req_pkg_create(VESYNC_OTA_MCU_HEADER_LEN, OTA_MCU_PACKET_ID_END, addr_offset, 0);
        if (NULL == p_data)
        {
            return SDK_FAIL;
        }

        uart_snd_len = p_data->data_len + VESYNC_OTA_MCU_HEADER_LEN;
        ret = ota_mcu_uart_send_ack(OPC_OTA_MCU_BIN_REQ, 0, (uint8_t *)p_data, uart_snd_len);
        vesync_free(p_data);

        return SDK_FAIL;
    }

    return SDK_OK;
}


/**
 * @brief 固件下载结果命令处理
 * @param[in] download_result              [命令参数]
 * @return int32_t                         [返回0表示成功，否则失败]
 */
static int32_t ota_mcu_dl_result_report(ota_mcu_dl_result_prot_t *download_result)
{
    ota_mcu_state_param_u ota_mcu_state_param;

    SDK_LOG(LOG_DEBUG,"ota_mcu_download_result_report\n");
    s_ota_mcu.upg_state = OTA_MCU_STATE_DOWNLOAD_RESULT;

    int32_t ret = ota_mcu_uart_send_ack(OPC_OTA_MCU_DOWNLOAD_RESULT,0,NULL,0);
    if (SDK_OK != ret)
    {
        return SDK_FAIL;
    }

    if (NULL != s_ota_mcu.ota_mcu_state_cb)
    {
        ota_mcu_state_param.download_result = download_result->result;
        s_ota_mcu.ota_mcu_state_cb(s_ota_mcu.upg_state, &ota_mcu_state_param);
    }

    if (DOWNLOAD_SUCCESS != download_result->result)
    {
        s_ota_mcu.upg_err_code = UPG_TRANSFER_TIME_OUT;
        vesync_sem_signal(s_ota_mcu.mcu_upgrade_sem);
    }

    return 0;
}

/**
 * @brief 升级结果命令处理
 *
 * @param ota_mcu_result 命令参数
 * @return int32_t 返回0表示成功，否则失败
 */
static int32_t ota_mcu_result_report(ota_mcu_result_prot_t * ota_mcu_result)
{
    ota_mcu_state_param_u ota_mcu_state_param;

    SDK_LOG(LOG_DEBUG,"ota_mcu_result_report\n");

    s_ota_mcu.upg_state = OTA_MCU_STATE_RESULT;

    int32_t ret = ota_mcu_uart_send_ack(OPC_OTA_MCU_RESULT,0,NULL,0);
    if (SDK_OK != ret)
    {
        return SDK_FAIL;
    }

    if (NULL != s_ota_mcu.ota_mcu_state_cb)
    {
        ota_mcu_state_param.ota_mcu_result = ota_mcu_result->result;
        s_ota_mcu.ota_mcu_state_cb(s_ota_mcu.upg_state,&ota_mcu_state_param);
    }

    if (OTA_MCU_SUCCESS != ota_mcu_result->result)
    {
        s_ota_mcu.upg_err_code = UPG_FAIL;
    }
    else
    {
        s_ota_mcu.upg_err_code = UPG_SUCCESS;
    }

    vesync_sem_signal(s_ota_mcu.mcu_upgrade_sem);

    return SDK_OK;
}


/**
* @brief 检查opcode是否为OTA所关注的
* @param[in]  opcode                   [待检查的opcode]
* @return     uint32_t                 [SDK_OK：是OTA的opcode；SDK_FAIL:非OTA的opcode]
*/
static uint32_t ota_mcu_check_opcode(uint32_t opcode)
{
    switch (opcode)
    {
        case OPC_OTA_MCU_START:
        case OPC_OTA_MCU_BIN_REQ:
        case OPC_OTA_MCU_DOWNLOAD_RESULT:
        case OPC_OTA_MCU_RESULT:
            return SDK_OK;
        default:    //非OTA关注的数据包，返回FAIL
            return SDK_FAIL;
    }
}


/**
* @brief 调用发送函数发送数据成功或者失败 (发送状态函数)
* @param[in]  event                    [串口数据发送成功/失败事件]
* @param[in]  p_payload                [发送应答帧的数据字段]
* @param[in]  payload_len              [应答帧的payload长度]
* @param[in]  p_msg                    [发送的消息]
* @return     uint32_t                 [SDK_OK：是OTA数据包；SDK_FAIL:非OTA数据包，不处理]
*/
static uint32_t uart_tx_event_cb(UART_SEND_TYPE_E event, tl_payload_info_t *p_payload, uint16_t payload_len, void *p_extra_data)
{
    UNUSED(payload_len);
    UNUSED(p_extra_data);
    SDK_LOG(LOG_DEBUG, "ota_mcu_uart_tx_event_cb():%d\r\n",event);

    if(NULL == p_payload)
    {
        return SDK_FAIL;
    }

    if (SDK_OK != ota_mcu_check_opcode(p_payload->op_code))
    {
        return SDK_FAIL;
    }

    /*传输失败直接释放信号量*/
    if(UART_SEND_FAIL == event)
    {
        s_ota_mcu.upg_err_code = UPG_TRANSFER_TIME_OUT;
        vesync_sem_signal(s_ota_mcu.mcu_upgrade_sem);
        return SDK_OK;
    }

    if(OTA_MCU_STATE_START == s_ota_mcu.upg_state)
    {
        ota_mcu_start_ack_prot_t *p_data = (ota_mcu_start_ack_prot_t *)p_payload->payload_data;
        if (OPC_OTA_MCU_START == p_payload->op_code)
        {
            if (OTA_MCU_OTA_CONFIRM == p_data->ota_confirm)
            {
                s_ota_mcu.upg_info.mtu = (p_data->mtu > OTA_MCU_MAX_PACKET_LEN ? OTA_MCU_MAX_PACKET_LEN : p_data->mtu);
                s_ota_mcu.upg_state = OTA_MCU_STATE_BIN_REQ;

                SDK_LOG(LOG_DEBUG,"enter OTA_MCU_STATE_BIN_REQ\n");
                SDK_LOG(LOG_DEBUG,"ota_mcu_info.mtu= %d\n", s_ota_mcu.upg_info.mtu);
            }
            else if(OTA_MCU_UNABLE_OTA == p_data->ota_confirm)
            {
                s_ota_mcu.upg_err_code = UPG_NOT_SUPT;
                vesync_sem_signal(s_ota_mcu.mcu_upgrade_sem);
            }
            else
            {
                s_ota_mcu.upg_err_code = UPG_FAIL;
                vesync_sem_signal(s_ota_mcu.mcu_upgrade_sem);
            }
        }
    }
    return SDK_OK;
}



/**
 * @brief 串口数据处理
 * @param[in] frame                    [接收到的指针]
 * @return    uint32_t                 [SDK_OK：是OTA数据包；SDK_FAIL:非OTA数据包，不处理]
 */
static uint32_t uart_recv_data_cb(uint8_t idx, void *p_payload, uint16_t payload_len)
{
     tl_payload_info_t *payload_ptr  = NULL;

     payload_ptr = (tl_payload_info_t *) p_payload;

    if (SDK_OK != ota_mcu_check_opcode(payload_ptr->op_code))
    {
        return SDK_FAIL;
    }

    if (payload_len >= 4)
    {
        switch (payload_ptr->op_code)
        {
            case OPC_OTA_MCU_BIN_REQ:
                ota_mcu_bin_requst((ota_mcu_bin_req_prot_t *)payload_ptr->payload_data);
                break;
            case OPC_OTA_MCU_DOWNLOAD_RESULT:
                ota_mcu_dl_result_report((ota_mcu_dl_result_prot_t *)payload_ptr->payload_data);
                break;
            case OPC_OTA_MCU_RESULT:
                ota_mcu_result_report((ota_mcu_result_prot_t *)payload_ptr->payload_data);
                break;
            default:
                break;
        }
    }
    return SDK_OK;
}

/*-----------------------------------------------------------------------------*
*                                 外部函数实现                          *
*-----------------------------------------------------------------------------*/

/**
 * @brief ota超时设置
 */
void vesync_ota_mcu_timeout_set(void)
{
    s_ota_mcu.upg_err_code = UPG_TRANSFER_TIME_OUT;
    vesync_sem_signal(s_ota_mcu.mcu_upgrade_sem);
}

/**
 * @brief 注册升级状态通知回调函数
 * @param[in] cb                    [回调函数]
 */
void vesync_ota_mcu_reg_state_cb(vesync_ota_mcu_state_cb_t cb)
{
    s_ota_mcu.ota_mcu_state_cb = cb;
}


/**
 * @brief ota mcu处理函数
 *
 * @param[in] sw_version             [mcu固件版本 三个字节（0x010109 表示 v1.1.9）]
 * @param[in] bin_size               [mcu固件大小]
 * @return int32_t                   [返回0表示成功，否则失败]
 */
uint32_t vesync_ota_mcu_start(uint8_t *sw_version, uint32_t bin_size)
{
    uint32_t ret = 0;

    SDK_LOG(LOG_DEBUG, "ota mcu start,bin size %d\n",bin_size);

    s_ota_mcu.mcu_upgrade_sem = vesync_sem_binary_new();
    if (s_ota_mcu.mcu_upgrade_sem == NULL)
    {
        SDK_LOG(LOG_ERROR, "mcu ota upgrade sem create fail \n");
        //return SDK_FAIL;
    }

    vesync_uart_reg_ota_event_cb(s_ota_mcu.uart_num, uart_tx_event_cb);
    vesync_uart_reg_ota_recv_cb(s_ota_mcu.uart_num, uart_recv_data_cb);

    s_ota_mcu.upg_info.mtu        = OTA_MCU_MAX_PACKET_LEN;
    s_ota_mcu.upg_info.bin_size   = bin_size;
    memcpy(s_ota_mcu.upg_info.sw_version, sw_version, 3);

    s_ota_mcu.upg_state = OTA_MCU_STATE_START;

    ota_mcu_start();

    while (1)
    {
        ret = vesync_sem_wait(s_ota_mcu.mcu_upgrade_sem, 1000);
        if (ret == VOS_OK)     //等待同步信号量
        {
            vesync_sem_signal(s_ota_mcu.mcu_upgrade_sem);
            break;
        }
    }

    ret = s_ota_mcu.upg_err_code;
    s_ota_mcu.upg_state = OTA_MCU_STATE_START;

    vesync_sem_free(s_ota_mcu.mcu_upgrade_sem);

    vesync_uart_reg_ota_event_cb(s_ota_mcu.uart_num, NULL);
    vesync_uart_reg_ota_recv_cb(s_ota_mcu.uart_num, NULL);

    SDK_LOG(LOG_DEBUG,"ota mcu end\n");
    return ret;
}

/**
 * @brief 获取MCU升级错误码
 * @return uint8_t                [mcu升级错误码]
 */
uint8_t vesync_ota_mcu_get_upgrade_code(void)
{
    return s_ota_mcu.upg_err_code;
}

/**
 * @brief OTA mcu初始化
 */
void vesync_ota_mcu_init(void)
{
    memset(&s_ota_mcu, 0, sizeof(vesync_ota_mcu_t));
    s_ota_mcu.uart_num = vesync_cfg_get_uart0_idx();  //TODO:FIXME
}

#endif
