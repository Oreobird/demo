/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_netcfg_internal.h
 * @brief       配网模块接口
 * @author      Louis
 * @date        2021-05-21
 */

#ifndef __VESYNC_NETCFG_INTERNAL_H__
#define __VESYNC_NETCFG_INTERNAL_H__

#include <stdbool.h>

#include "vesync_task.h"
#include "vesync_netcfg.h"

#ifdef __cplusplus
extern "C" {
#endif


#define NETCFG_TASK_NAME        "netcfg_task"
#define NETCFG_TASK_PRIO        TASK_PRIORITY_SOFT_REALTIME

#ifndef PR_NETCFG_TASK_STACKSIZE
#define NETCFG_TASK_STACKSIZE    (1024*4)
#else
#define NETCFG_TASK_STACKSIZE    PR_NETCFG_TASK_STACKSIZE
#endif

// v2及以上版本，payload第一个byte的高四位标识加密类型，配网加密算法RSA1024/AES128/CBC-PKCS1Padding.
#define NETCFG_VERSION_SECURITY_AES     (0x1)
#define  VESYNC_NETCFG_EXIT_TIMEOUT            200     //  退出配网任务等待超时时间2S, 单位10ms


#define ERR_CONFIG_NET_SUCCESS                  0       // 配网时设备连接MQTT服务器成功
#define ERR_CONFIG_CMD_SUCCESS                  1       // 收到命令应答
#define ERR_CONFIG_HTTPS_NET_SUCCESS            2       // HTTPS配网成功
#define ERR_CONFIG_WIFI_SSID_MISSED             50      // 路由器ssid出错
#define ERR_CONFIG_CONFIGKEY_MISSED             51      // mqtt configkey出错
#define ERR_CONFIG_NO_AP_FOUND                  52      // 找不到热点
#define ERR_CONFIG_WRONG_PASSWORD               53      // 路由器密码出错
#define ERR_CONFIG_CONNECT_WIFI_FAIL            54      // 连接路由器失败
#define ERR_CONFIG_CID_MISSED                   55      // MQTT CID缺失
#define ERR_CONFIG_SERVER_IP_MISSED             56      // MQTT服务器IP缺失
#define ERR_CONFIG_URI_ERROR                    57
#define ERR_CONFIG_PID_DO_NOT_MATCHED           58      // pid与产测不匹配
#define ERR_CONFIG_NO_APP_LINK                  59
#define ERR_CONFIG_PARSE_JSON_FAIL              60      // json解析出错
#define ERR_CONFIG_SMART_CONFIG_RESTART         61      // 配网时设备端SMARTCONFIG发生了超时重启，超时时间现设置为240s
#define ERR_CONFIG_LINK_SERVER_FAILED           62      // 配网时设备连接MQTT服务器失败
#define ERR_CONFIG_TIMEOUT                      63      // 配网超时，全程共5分钟
#define ERR_CONFIG_WIFI_DEIVER_INIT             64      // wifi驱动未初始化

#define ERR_CONFIG_CONNECT_ROUTER_TIMEOUT       65      // 连接路由器超时
#define ERR_CONFIG_SERVER_DOMAIN_MISSED         66      // 配网数据的"serverDN"字段缺失
#define ERR_CONFIG_GET_IP_FAIL                  67      // 获取不到IP

#define ERR_CONFIG_TLS_HANDSHAKE_FAIL           70      // 配网时设备连接服务器时tls握手失败（暂未启用）
#define ERR_CONFIG_DNS_RESOLVE_FAIL             71      // 配网时DNS解析失败
#define ERR_CONFIG_CONNECT_SERVER_FAIL          72      // 配网时设备连接服务器失败
#define ERR_CONFIG_SUBSCRIBE_FAIL               73      // 配网时设备向服务器订阅失败

#define ERR_CONFIG_NET_INFO_MISSED              79      // 配网信息缺失
#define ERR_CONFIG_SERVER_URL_MISSED            80      // https uri地址出错
#define ERR_CONFIG_ACCOUNT_ID_MISSED            81      // 账户信息出错
#define ERR_WIFI_LINK_BUSY                      82      // wifi链路忙，不能进入扫描模式
#define ERR_NO_ALLOCATION_CID                   83      // 未分配cid
#define ERR_CONNECT_MQTT_SERVER_FAIL            84      // 连接MQTT服务器失败
#define ERR_CONNECT_HTTPS_SERVER_FAIL           85      // 连接https配网失败
#define ERR_NOT_NET_CONFIG                      86      // 设备未配网
#define ERR_STORE_NET_CONFIG                    87      // 设备有配网信息

#define ERR_TOTAL                               100


#define ERR_CONFIG_NET_SUCCESS_MSG              "CONFIG_NET_SUCCESS"

#define ERR_CONFIG_NO_AP_FOUND_MSG              "ERR_CONFIG_NO_AP_FOUND"
#define ERR_CONFIG_WRONG_PASSWORD_MSG           "ERR_CONFIG_WRONG_PASSWORD"
#define ERR_CONFIG_CONNECT_WIFI_FAIL_MSG        "ERR_CONFIG_CONNECT_WIFI_FAIL"

#define ERR_CONFIG_GET_IP_FAIL_MSG              "ERR_CONFIG_GET_IP_FAIL"

#define ERR_CONFIG_DNS_RESOLVE_FAIL_MSG         "ERR_CONFIG_DNS_RESOLVE_FAIL"
#define ERR_CONFIG_CONNECT_SERVER_FAIL_MSG      "ERR_CONFIG_CONNECT_SERVER_FAIL"
#define ERR_CONFIG_SUBSCRIBE_FAIL_MSG           "ERR_CONFIG_SUBSCRIBE_FAIL"



/**
 * @brief 配网模式
 */
typedef enum
{
    AP_CONFIG = 0,              // AP模式配网
    BLE_CONFIG,                 // 蓝牙配网模式
    NFC_CONFIG,                 // NFC配网模式
    UNKNOW_CONFIG,              // 错误参数
} NETCFG_MODE_E;

/**
 * @brief 设备配网状况：未配网、 等待配网、已配网
 */
typedef enum
{
    NETCFG_STAT_UNCFG = 0,          // 设备不存在配网信息
    NETCFG_STAT_READY = 1,          // 设备配网等待
    NETCFG_STAT_CFGED = 2           // 设备已配过网
} NETCFG_STAT_E;



/**
 * @brief 配网过程不同阶段
 * @details 1 2 3 4四项的值依照通用协议大纲opcode定义！实际wifi配网5 6两项在先
 *          即下面几项的顺序不代表配网过程中的先后顺序
 */
typedef enum
{
    NETCFG_STATUS_IDLE              = 0,        // 不在配网状态
    NETCFG_STATUS_RECV_CFG_DATA     = 1,        // 配网过程设备收到配网信息
    NETCFG_STATUS_CONNECTED_WIFI    = 2,        // 配网过程设备连上路由器
    NETCFG_STATUS_GOT_IP            = 3,        // 配网过程获取ip地址
    NETCFG_STATUS_DNS_RESOLVED      = 4,        // DNS解析成功
    NETCFG_STATUS_CONNECTED_SERVER  = 5,        // MQTT连接成功
    NETCFG_STATUS_SUBSCRIBE_SUCCESS = 6,        // 订阅成功
    NETCFG_STATUS_SAVE_CFG_SUCCESS  = 7,        // 保存配网数据成功
    NETCFG_STATUS_MAX
} NETCFG_STATUS_E;


/**
 * @brief 配网状态
 */
typedef struct
{
    bool running;
    bool set_exit;
    bool need_reset;
    NETCFG_STATUS_E status;
} vesync_netcfg_status_t;


/**
 * @brief [设置配网状态]
 * @param[in] status [配网的状态]
 */
void vesync_netcfg_set_status(NETCFG_STATUS_E status);

/**
 * @brief [获取当前配网状态]
 * @return  [当前配网状态]
 */
NETCFG_STATUS_E vesync_netcfg_get_status(void);


/**
 * @brief   停止配网模式, 此接口内部使用
 */
void vesync_netcfg_set_exit(void);


/**
 * @brief   设置重启标记
 */
void vesync_netcfg_set_reset_flag(bool reset);


/**
 * @brief 获取协议版本
 * @return    uint8_t   [协议版本]
 */
uint8_t vesync_netcfg_config_get_protocol_version(void);


/**
 * @brief 获取配网模式
 * @return    NETCFG_MODE_E     [配网模式]
 */
NETCFG_MODE_E vesync_netcfg_get_mode(void);


#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_NETCFG_INTERNAL_H__ */

