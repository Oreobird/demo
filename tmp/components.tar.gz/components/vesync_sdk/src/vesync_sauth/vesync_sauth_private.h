/**
 * Copyright © Vesync Technologies Co.Ltd. 2022. All rights reserved.
 * @file        vesync_sauth_private.h
 * @brief       Vesync SAUTH模块的内部接口定义
 * @author      Herve
 * @date        2022-01-04
 */
#ifndef __VESYNC_SAUTH_PRIVATE_H__
#define __VESYNC_SAUTH_PRIVATE_H__

#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>

#include "pt.h"

#include "vesync_sauth_internal.h"

#ifdef __cplusplus
extern "C"
{
#endif

#if defined (__CC_ARM)
#ifndef __ASM
#define __ASM               __asm
#endif
#ifndef __INLINE
#define __INLINE            __inline
#endif
#ifndef __WEAK
#define __WEAK              __weak
#endif
#ifndef __ALIGN
#define __ALIGN(n)          __align(n)
#endif
#ifndef __PACKED
#define __PACKED            __packed
#endif
#define GET_SP()            __current_sp()
#elif defined(__ICCARM__)
#ifndef __ASM
#define __ASM               __asm
#endif
#ifndef __INLINE
#define __INLINE            inline
#endif
#ifndef __WEAK
#define __WEAK              __weak
#endif
#ifndef __ALIGN
#define STRING_PRAGMA(x)    _Pragma(#x)
#define __ALIGN(n)          STRING_PRAGMA(data_alignment = n)
#endif
#define GET_SP()            __get_SP()
#elif defined(__GNUC__)
#ifndef __ASM
#define __ASM               __asm
#endif
#ifndef __INLINE
#define __INLINE            inline
#endif
#ifndef __WEAK
#define __WEAK              __attribute__((weak))
#endif
#ifndef __ALIGN
#define __ALIGN(n)          __attribute__((aligned(n)))
#endif
#ifndef __PACKED
#define __PACKED            __attribute__((packed))
#endif
#define GET_SP()            __gcc_current_sp()
static inline unsigned int __gcc_current_sp(void)
{
    register unsigned sp __ASM("sp");
    return sp;
}
#endif

#define SAUTH_DEBUG_PRINT_ENABLE (0)           // Sauth模块内部加密打印开关
#define SAUTH_CIPER_STATUS_IS_REG_BIT (0x01)   // 加密状态标志中，是否注册的标志位
#define SAUTH_CIPER_STATUS_IS_LOGIN_BIT (0x02) // 加密状态标志中，是否登录的标志位
#define SAUTH_SCHD_IDLE (0)                    // 调度器空闲的标志流程码
#define SAUTH_SCHD_DISABLE (0xFF00)            // 调度器被禁用的流程码
#define SAUTH_SESSION_ENC_DEC_TAG_SIZE (4)     // 会话AES-CCM加解密的校验值长度
#define SAUTH_SESSION_UPCNT_SIZE (2)           // 会话AES-CCM加解密的上计数值长度
#define SAUTH_SESSION_NONCE_IV_SIZE (7)        // 会话密钥中的IV长度，不等于最终加密输入的IV长度


/**
 * @brief Sauth调度事件定义
 */
typedef enum
{
    SCHD_EVT_REG_SUCCESS,
    SCHD_EVT_REG_FAIL,
    SCHD_EVT_LOGIN_SUCCESS,
    SCHD_EVT_LOGIN_FAIL,
    SCHD_EVT_TIMEOUT,
    SCHD_EVT_INTERNAL,
} schd_evt_id_t;

/**
 * @brief Sauth设备信息定义
 */
#if defined(__CC_ARM)
typedef __PACKED struct
#elif defined(__GNUC__)
typedef struct __PACKED
#endif
{
    uint16_t version;      // Sauth的协议版本
    uint8_t cipher_status; // 当前的加密状态
    uint8_t io_capability; // 当前的OOB能力
    uint8_t cipher_suit;   // 当前支持的加密套件
} sauth_dev_info_t;

/**
 * @brief Sauth登录口令定义
 */
#if defined(__CC_ARM)
typedef __PACKED struct
#elif defined(__GNUC__)
typedef struct __PACKED
#endif
{
    uint8_t ciper[4];
    uint8_t mic[4];
} sauth_login_token_t;

/**
 * @brief 会话加密上下文定义
 */
#if defined(__CC_ARM)
typedef __PACKED struct
#elif defined(__GNUC__)
typedef struct __PACKED
#endif
{
    uint8_t dev_key[16];
    uint8_t app_key[16];
    uint8_t dev_iv[SAUTH_SESSION_NONCE_IV_SIZE];
    uint8_t app_iv[SAUTH_SESSION_NONCE_IV_SIZE];
    uint8_t reserve[18];
} sauth_sess_ctx_t;

#if defined(__CC_ARM)
typedef __PACKED struct
#elif defined(__GNUC__)
typedef struct __PACKED
#endif
{
    uint8_t iv[SAUTH_SESSION_NONCE_IV_SIZE];
    uint8_t reserve[1];
    uint32_t counter;
} sauth_sess_nonce_t;

/**
 * @brief Sauth内部初始化
 * @param[in]   schd_step_ms    [外部调用sauth_schedule()的间隔时间（毫秒）]
 * @param[in]   timeout_ms      [每一个流程的超时时间（注册流程或者登录流程）]
 * @param[in]   p_mass_buf      [提供给内部的大型缓存]
 * @param[in]   buf_len         [大型缓存的大小]
 * @return      int             [成功：SDK_OK；失败：SDK_FAIL]
 */
int sauth_internal_init(uint32_t schd_step_ms, uint32_t timeout_ms, uint8_t *p_mass_buf, uint16_t buf_len);

/**
 * @brief Sauth发起一个流程的处理，调度器开始生效
 * @param[in]   procedure       [流程码，内部参数]
 * @return      int             [成功：SDK_OK；失败：SDK_FAIL]
 */
int sauth_schedule_start(uint16_t procedure);

/**
 * @brief Sauth的调度主体，需要在port中按照一定的间隔调用
 */
void sauth_schedule(void);

/**
 * @brief Sauth发送一个状态码
 * @param[in]   cmd_code        [应发送状态码对于的命令码]
 */
void sauth_send_status_code(uint16_t cmd_code);

/**
 * @brief Sauth消息接收回调
 * @param[in]   p_in            [指向接收数据]
 * @param[in]   len             [接收数据大小]
 */
void sauth_msg_recv_cb(uint8_t *p_in, uint32_t len);

/**
 * @brief Sauth会话注销、登出操作
 */
void sauth_login_out(void);

/**
 * @brief Sauth发送一个命令包的协程定义
 * @param[in]   pt              [协程句柄]
 * @param[in]   p_tx_buf        [发送缓存]
 * @param[in]   tx_buf_len      [发送缓存的大小]
 * @param[in]   cmd_code        [命令码]
 * @param[in]   p_data          [命令码携带的数据]
 * @param[in]   len             [发送数据的大小]
 */
PT_THREAD(sauth_tx_thd(struct pt *pt, uint8_t *p_tx_buf, uint16_t tx_buf_len, uint16_t cmd_code, uint8_t *p_data, uint16_t len));

/**
 * @brief Sauth发送一个命令包的协程定义
 * @param[in]   pt              [协程句柄]
 * @param[in]   cmd_code        [等待接收的目标命令码]
 * @param[out]  p_buf           [接收缓存]
 * @param[in]   buf_len         [接收缓存大小]
 * @param[out]  p_rx_len        [输出最终接收的大小]
 */
PT_THREAD(sauth_rx_thd(struct pt *pt, uint16_t cmd_code, uint8_t *p_buf, uint16_t buf_len, uint16_t *p_rx_len));

/**
 * @brief Sauth会话初始化，通常在登录时调用
 * @param[in]   p_ctx           [指向会话上下文]
 * @return      int             [成功：SDK_OK；失败：SDK_FAIL]
 */
int sauth_session_init(sauth_sess_ctx_t *p_ctx);

/**
 * @brief Sauth会话反初始化，通常在登出时调用
 * @return      int             [成功：SDK_OK；失败：SDK_FAIL]
 */
int sauth_session_deinit(void);

#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_SAUTH_PRIVATE_H__ */