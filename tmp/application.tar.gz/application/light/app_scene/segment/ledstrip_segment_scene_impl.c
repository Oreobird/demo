/**
* Copyright © Vesync Technologies Co.Ltd. 2022. All rights reserved
* @file         ledstrip_segment_scene_impl.c
* @brief        彩灯控制场景业务实现
* @author       Joshua
* @date         2022-2-11
*/

#include <string.h>
#include "vesync_log.h"
#include "vesync_common.h"
#include "device.h"
#include "light.h"
#include "segment.h"

static int segment_on(void *param)
{
    UNUSED(param);
    APP_LOG(LOG_DEBUG, "segment on scene\n");

    dev_cfg_t *p_dev_cfg = app_device_cfg_get();
    VCOM_NULL_RET_CHK(p_dev_cfg, return APP_FAIL);

    light_color_t *seg_param = p_dev_cfg->flash->cfg.extra.seg_param;
    int seg_num = p_dev_cfg->flash->cfg.seg_num;
    app_light_segment_on(seg_param, seg_num, 0, p_dev_cfg->fade);
    return APP_OK;
}

static int segment_off(void *param)
{
    UNUSED(param);
    APP_LOG(LOG_DEBUG, "segment off scene\n");
    dev_cfg_t *p_dev_cfg = app_device_cfg_get();
    VCOM_NULL_RET_CHK(p_dev_cfg, return APP_FAIL);
    app_light_segment_off(0, p_dev_cfg->fade);
    return APP_OK;
}

int segment_on_light_scene_impl_init(void)
{
    light_scene_t light_scene;
    memset(&light_scene, 0, sizeof(light_scene_t));
    light_scene.light_cb = segment_on;
    return segment_on_light_scene_reg(&light_scene);
}

int segment_off_light_scene_impl_init(void)
{
    light_scene_t light_scene;
    memset(&light_scene, 0, sizeof(light_scene_t));
    light_scene.light_cb = segment_off;
    return segment_off_light_scene_reg(&light_scene);
}

