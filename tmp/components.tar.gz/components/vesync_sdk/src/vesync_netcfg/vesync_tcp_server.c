/**
 * Copyright © Vesync Technologies Co.Ltd. 2019-2021. All rights reserved.
 * @file    tcp_server.c
 * @brief   本地TCP服务器
 * @author  Dongri.Su
 * @date    2019-11-17
 */

#include <string.h>

#if defined(CONFIG_TARGET_LINUX)
#include <sys/types.h>
#include <sys/socket.h>
#include <unistd.h>
#include <errno.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#else
#include "lwip/netif.h"
#include "lwip/tcpip.h"
#include "lwip/sockets.h"
#include "netif/etharp.h"
#endif
#include "vesync_common.h"
#include "vesync_memory.h"
#include "vesync_log_internal.h"
#include "vesync_tcp_server.h"
#include "vesync_lan_trans_prot.h"
#include "vesync_netcfg.h"
#include "vesync_netcfg_internal.h"
#include "vesync_netcfg_recv.h"


static struct sockaddr_in s_server_addr;
static int s_tcp_socket_fd = -1;
static int s_vesync_tcp_client = -1;              // 指向最新连接上的客户端
static char *sp_recv_buf = NULL;

static bool s_exit_flag = false;

/**
* @brief    apn配网数据包处理回调函数
* @param[in]  *p_data  [完整数据包buffer]
* @param[in]  data_len [数据长度]
*/
void vesync_netcfg_lan_cb(uint8_t *p_data, uint32_t data_len)
{
    // 处于配网中，调用配网模块进行处理
    if (true == vesync_netcfg_is_running() && AP_CONFIG == vesync_netcfg_get_mode())
    {
        vesync_netcfg_lan_recv_cb(p_data + LAN_PROT_HEADER_LEN, data_len - LAN_PROT_HEADER_LEN);
    }
    else
    {
        SDK_LOG(LOG_DEBUG, "Don't under config_net mode.\n");
    }
}


/**
 * @brief tcp服务器端主动断开客户端连接
 */
static void vesync_tcp_server_disconnect_client(void)
{
    int ret = -1;

    if(s_vesync_tcp_client >= 0)
    {
        ret = shutdown(s_vesync_tcp_client, SHUT_RDWR);
        if (0 != ret)
            SDK_LOG(LOG_ERROR, "shutdown err: errno = %d!\n", errno);

        ret = close(s_vesync_tcp_client);
        if (0 != ret)
            SDK_LOG(LOG_ERROR, "close err: errno = %d!\n", errno);

        s_vesync_tcp_client = -1;
    }
}



/**
 * @brief vesync的本地TCP服务器线程，阻塞式读取来自APP的配网注册信息
 * @param[in] args      [任务参数]
 */
static void vesync_tcp_server_thread(void *args)
{
    int recv_len = 0;
    int keepAlive = VESYNC_TCP_SERVER_KEEPALIVE;
    int keepIdle = VESYNC_TCP_SERVER_KEEPIDLE;
    int keepInterval = VESYNC_TCP_SERVER_KEEPINTV;
    int keepCount = VESYNC_TCP_SERVER_KEEPCNT;
    socklen_t sockaddr_len = sizeof(s_server_addr);
    int offset = 0;
    UNUSED(args);
    sp_recv_buf = (char*)vesync_malloc(VESYNC_TCP_SERVER_RECV_BUF);
    if (NULL == sp_recv_buf)
    {
        SDK_LOG(LOG_ERROR, "malloc fail.\n");
        goto _exit;
    }

    s_exit_flag = false;

    while(1)
    {
        s_vesync_tcp_client = accept(s_tcp_socket_fd, (struct sockaddr*)&s_server_addr, &sockaddr_len);
        if(s_vesync_tcp_client < 0)
        {
            SDK_LOG(LOG_WARN, "Vesync tcp server accept error : %d!\n", errno);
            goto _exit;
        }

        SDK_LOG(LOG_INFO, "APP client connected.\n");

        setsockopt(s_vesync_tcp_client, SOL_SOCKET, SO_KEEPALIVE, &keepAlive, sizeof(int));
        setsockopt(s_vesync_tcp_client, IPPROTO_TCP, TCP_KEEPIDLE, &keepIdle, sizeof(int));
        setsockopt(s_vesync_tcp_client, IPPROTO_TCP, TCP_KEEPINTVL, &keepInterval, sizeof(int));
        setsockopt(s_vesync_tcp_client, IPPROTO_TCP, TCP_KEEPCNT, &keepCount, sizeof(int));

        while(1)
        {
            recv_len = recv(s_vesync_tcp_client, sp_recv_buf + offset, VESYNC_TCP_SERVER_RECV_BUF - 1 -offset, 0);
            if(recv_len < 0)
            {
                SDK_LOG(LOG_ERROR, "Tcp read error: errno %d!\n", errno);
                break;
            }
            if(recv_len == 0)
            {
                SDK_LOG(LOG_INFO, "Client disconnected.\n");
                break;
            }

            offset = vesync_tcp_data_parse((uint8_t*)sp_recv_buf, recv_len + offset, vesync_netcfg_lan_cb);
            if(s_exit_flag)  //stop tcp server
            {
                close(s_vesync_tcp_client);
                s_vesync_tcp_client = -1;

                goto _exit;
            }
        }

        SDK_LOG(LOG_INFO, "APP client disconnect.\n");
        vesync_tcp_server_disconnect_client();
    }

_exit:
    VCOM_SAFE_FREE(sp_recv_buf);

    SDK_LOG(LOG_INFO, "TCP serv close.\n");
    if (s_tcp_socket_fd >= 0)
    {
        close(s_tcp_socket_fd);
        s_tcp_socket_fd = -1;
    }
}

/**
 * @brief  TCP发送数据
 * @param[in]  buf      [待发送数据]
 * @param[in]  length   [待发送数据长度]
 * @return              [发送结果]
 */
int vesync_tcp_server_send(const uint8_t *buf, uint32_t length)
{
    if(s_vesync_tcp_client < 0)
    {
        SDK_LOG(LOG_ERROR, "Vesync tcp server not established or has been closed!\n");
        return -1;
    }

    int err = send(s_vesync_tcp_client, buf, length, MSG_DONTWAIT);
    if(err <= 0)
    {
        SDK_LOG(LOG_ERROR, "Vesync tcp server send data failed, error code : %d!\n", err);
    }

    return err;
}

/**
 * @brief 启动TCP服务监听APP的配网注册信息
 * @param[in] port                  [TCP监听端口]
 * @return int                      [启动结果，0为成功]
 */
int vesync_tcp_server_start(uint32_t port)
{
    int ret = -1;
    int reuse = 1;

    if(s_tcp_socket_fd >= 0)          //tcp socket已存在
        return 0;

    vesync_tcp_server_disconnect_client();
    SDK_LOG(LOG_INFO, "Vesync tcp server starts.\n");

    memset(&s_server_addr, 0, sizeof(s_server_addr));
    //s_server_addr.sin_len = sizeof(s_server_addr);
    s_server_addr.sin_family = AF_INET;
    s_server_addr.sin_port = htons(port);
    s_server_addr.sin_addr.s_addr = htonl(INADDR_ANY);

    s_tcp_socket_fd = socket(AF_INET, SOCK_STREAM, 0);
    if(s_tcp_socket_fd < 0)
    {
        SDK_LOG(LOG_ERROR, "TCP server create failed!\n");
        return -1;
    }

    setsockopt(s_tcp_socket_fd, SOL_SOCKET, SO_REUSEADDR, &reuse, sizeof(reuse));

    ret = bind(s_tcp_socket_fd, (struct sockaddr*)&s_server_addr, sizeof(s_server_addr));
    if(ret < 0)
    {
        SDK_LOG(LOG_ERROR, "TCP server bind failed: errno %d!\n", errno);
        close(s_tcp_socket_fd);
        s_tcp_socket_fd = -1;
        return -1;
    }

    ret = listen(s_tcp_socket_fd, 2);
    if(ret < 0)
    {
        SDK_LOG(LOG_ERROR, "TCP server listen failed: errno %d!\n", errno);
        close(s_tcp_socket_fd);
        s_tcp_socket_fd = -1;
        return -1;
    }

    if (VOS_OK != vesync_task_new(TCP_SERVER_TASK_NAME,
                                NULL,
                                vesync_tcp_server_thread,
                                NULL,
                                TCP_SERVER_TASK_STACSIZE,
                                TCP_SERVER_TASK_PRIO,
                                NULL))
    {
        SDK_LOG(LOG_ERROR, "Cannot create vesync tcp server thread!\n");
        close(s_tcp_socket_fd);
        s_tcp_socket_fd = -1;
        return -1;
    }

    return 0;
}

/**
 * @brief 关闭配网TCP服务器
 */
void vesync_tcp_server_stop(void)
{
    vesync_tcp_server_disconnect_client();

    s_exit_flag = true;

    if(s_tcp_socket_fd >= 0)
    {
        SDK_LOG(LOG_INFO, "TCP serv close(%d).\n", s_tcp_socket_fd);
        close(s_tcp_socket_fd);
        s_tcp_socket_fd = -1;
    }

    VCOM_SAFE_FREE(sp_recv_buf);
}

/**
 * @brief 检查tcp服务器是否已经启动
 * @return bool         [true:已启动，false：未启动]
 */
bool vesync_tcp_server_is_started(void)
{
    return (s_tcp_socket_fd >= 0);
}
