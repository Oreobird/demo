/**
*Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file    led_strip_device.h
* @brief   设备重置
* @author  henrik
*@date     2021-11-22
*/

#ifndef __LEDSTRIP_DEVICE_H__
#define __LEDSTRIP_DEVICE_H__

#ifdef __cplusplus
extern "C" {
#endif


/**
* @brief ledstrip设备管理初始化
*/
void led_strip_device_init(void);

#ifdef __cplusplus
}
#endif

#endif

