/**
 *  Copyright © Vesync Technologies Co.Ltd. 2019-2021. All rights reserved
 * @file        led_strip_scene.h
 * @brief       led strip working scene function
 * @author      henrik
 * @date        2021-09-16
 */
#ifndef __LED_STRIP_SCENE_H__
#define __LED_STRIP_SCENE_H__
#include "led_strip_board.h"
#include "led_display.h"
#include "led_strip_signal.h"

#ifdef __cplusplus
{
#endif
#define   SCENE_DEFAULT_NUM               9       //  默认场景数量
#define   SCENE_CUSTOM_MAX_NUM            16      //  自定义场景数量
#define   SCENE_MAX_NUM                   (SCENE_DEFAULT_NUM+SCENE_CUSTOM_MAX_NUM)
#define   SCENE_DEFAULT_MAX_ID            1024    //  默认场景的ID最大值为1024
#define   SCENE_DEFAULT_MIN_ID            1       //  默认场景的ID最大值为1024
#define   SCENE_CUSTOM_MAX_ID             65535   //  默认场景的ID最大值为1024
#define   SCENE_CUSTOM_MIN_ID             1025    //  默认场景的ID最大值为1024
#define   SCENE_SPECTRUM_LED_NUM          25      //  音乐频谱模式下频点数量

#define   SCENE_WAIT_MS_BREATH            20      //  呼吸场景灯效延时时间
#define   SCENE_WAIT_MS_MUSIC             10      //  音乐场景灯效延时时间
#define   SCENE_WAIT_MS_FLOWING           100     //  流动场景灯效延时时间
#define   SCENE_WAIT_MS_CHRISTMAS         500     //  圣诞场景灯效延时时间
#define   SCENE_WAIT_MS_DEFAULT           100     //  默认场景灯效延时时间
#define   SCENE_WAIT_MS_PRD               10      //  产测场景灯效延时时间
#define   SCENE_WAIT_MS_REALTIME          10      //  实时场景灯效延时时间
/*
 *  @brief 灯带默认场景ID枚举
 */
typedef enum
{
    SCENE_LIGHTING = 1,
    SCENE_MOVIE = 2,
    SCENE_SWEET = 3,
    SCENE_ROMATIC = 4,
    SCENE_RAINBOW = 5,
    SCENE_BREATH = 6,
    SCENE_FLOWING = 7,
    SCENE_CHRISTMAS = 8,
    SCENE_SPECTRUM = 9,
}LS_SCENE_E;

/**
 * @brief  产测灯效类型枚举
 */
typedef enum
{
    PRD_SCENE_START = 0,        // 产测开始灯效
    PRD_SCENE_RUNNING,          // 产测中灯效
    PRD_SCENE_PASS,          	// 产测通过灯效
    PRD_SCENE_FAIL,             // 产测失败场景
} PRD_SCENE_E;

/**
 * @brief  配网灯效类型枚举
 */
typedef enum
{
    CFG_SCENE_START = 0,       // 配网开始灯效
    CFG_SCENE_RUNNING,         // 配网中灯效
    CFG_SCENE_SUCCESS,         // 配网成功灯效
    CFG_SCENE_UNKNOWN
} CFG_SCENE_E;

/**
 * @brief  灯效模式类型枚举
 */
typedef enum
{
    SCENE_COLOR_WHITE  = 0,    // 白灯模式
    SCENE_COLOR_RGB,           // 彩灯模式
    SCENE_COLOR_MULT,          // 多段彩灯
    SCENE_COLOR_MUSIC,         // 声音律动
    SCENE_COLOR_SCENE         // 场景模式
} SCENE_COLOR_E;

/**
 * @brief  ledstrip场景类型枚举
 */
typedef enum
{
    SCENE_TYPE_CFNET = 0,        // 配网灯效
    SCENE_TYPE_PRD,              // 产测灯效
    SCENE_TYPE_RESET,            // 复位灯效
    SCENE_TYPE_DEFINE,           // 定义场景灯效
    SCENE_TYPE_REALTIME,         // 用户实时灯效
    SCENE_TYPE_OFF ,             // 灯带关闭
    SCENE_TYPE_UNKNOWN           // 未知场景类型
} LS_SCENE_TYPE_E;

/**
 * @brief  ledstrip显示灯效结构体
 */
typedef struct
{
    LS_SCENE_TYPE_E  scene_type;     // 场景类型
    uint8_t change_count;            // 灯效变化计数
    uint16_t scene_id;               // 场景id (默认场景id(1~1024)) 自定义场景id (1025~65535)
} ls_scene_dis_t;

/**
 * @brief  ledstrip场景色段结构体
 */
typedef struct
{
    uint16_t  hue;       //  色调
    uint16_t  sat;       //  饱和度
    uint8_t  val;        //  透明度
} ls_color_seg_t;

/**
 * @brief  ledstrip场景结构体
 */
typedef struct
{
    uint8_t  num;               //  场景分段数
    uint8_t  type;              //  场景类型
    uint16_t  id;               //  场景ID
    ls_color_seg_t *  color;    //  分段颜色指针
} ls_scene_t;

/**
 * @brief  ledstrip信息结构体
 */
typedef struct
{
    uint8_t  mode;                              //  工作模式
    uint8_t  status;                            //  开关状态
    uint8_t  scene_num ;                        //  自定义场景数量
    uint8_t  brightness;                        //  亮度
    uint16_t led_num ;                          //  灯珠数量
    uint16_t scene_now ;                        //  当前场景id
    uint16_t last_id;                           //  上次分配的id
    ls_color_seg_t  color;                      //  单色模式、白光模式时亮度和颜色信息
    ls_scene_t   multiple;                      //  多段模式
    ls_scene_t * scene_list;                    //  场景列表
} ls_info_t;

typedef enum {
    DISPLAY_HORIZONTALLY = 0,
    DISPLAY_VERTICAL,
} display_scene_t;

/**
 * @brief  获取灯带参数初始化
 * @return     ls_info_t *             [灯带信息结构体指针]
 */
ls_info_t * led_strip_get_info(void);

/**
 * @brief  设置配网灯效标记位，配网状态下切换场景后，重新配网需要将type变成UNKOWN,进行开始配网灯效
 * @param[in]     type                                   [配网灯效类型]
 */
void led_strip_set_cfgnet_scene(uint8_t type);

/**
 * @brief  灯带参数初始化
 * @return     int              [成功：APP_OK，失败：APP_FAIL]
 */
int led_strip_parameter_init(void);

/**
 * @brief  灯带参数重置
 */
void led_strip_parameter_deinit(void);
/**
 * @brief  新增场景
 * @param[out]    id                                     [场景id ]
 * @param[in]     type                                   [分段类型]
 * @param[in]     num                                    [分段数量]
 * @param[in]     color                                  [分段颜色数组]
 * @return     int              [成功：APP_OK，失败：APP_FAIL]
 */
int led_strip_scene_add(uint16_t* id , uint8_t type ,uint8_t num , ls_color_seg_t * color);

/**
 * @brief  更新场景
 * @param[out]    id                                     [场景id ]
 * @param[in]     type                                   [分段类型]
 * @param[in]     num                                    [分段数量]
 * @param[in]     color                                  [分段颜色数组]
 * @return     int              [成功：APP_OK，失败：APP_FAIL]
 */
 int led_strip_scene_update(uint16_t id , uint8_t type, uint8_t num , ls_color_seg_t * color);

/**
 * @brief  删除场景
 * @param[in]     id                                    [场景id]
 * @return     int              [成功：APP_OK，失败：APP_FAIL]
 */
int led_strip_scene_delete(uint16_t id);

/**
 * @brief  验证场景ID是否存在,存在则赋值给新的存储空间
 * @param[in]     id                                    [待验证场景id]
 * @param[out]    data                                  [待赋值的场景存储]
 * @return     int              [成功：APP_OK，失败：else]
 */
int led_strip_scene_id_check(uint16_t id, uint16_t * data);

/**
 * @brief 时域音频归一化数据按频率大小快速排序
 * @param[in out] freq_normal                            [归一化频率 分量 ]
 * @param[in]     begin                                  [起始坐标]
 * @param[in]     end                                    [终止坐标]
 * @note
 */
void led_strip_frequency_fast_sort(freq_normal_t *freq_normal, int32_t begin, int32_t end);

/**
 * @brief 场景数据转化
 * @param[in]      p_info                                 [灯带状态参数结构体]
 * @param[out]     signal                                 [灯带灯效控制参数结构体指针]
 * @param[in]      mode                                   [工作模式]
 * @note
 */
void led_strip_scene_data_transform(ls_color_seg_t *p_color, led_strip_signal_hsv_t *signal, uint8_t mode);
///**
// * @brief 根据工作场景生成hsv颜色空间信息
// * @param[in]     hue_period                             [hue信号周期]
// * @param[in]     value_period                           [vaue信号周期]
// * @param[in out] led_strip_signal_hsv_t                 [hsv 颜色空间数据信息]
// * @note
// */
//int led_strip_hsv_genneration(uint8_t hue_period, uint8_t value_period, led_strip_signal_hsv_t *signal);

/**
 * @brief      产测灯效
 *
 * @param[in]  strip                [灯带结构体指针]
 * @param[in]  rgb                  [灯带灯珠颜色参数结构体指针]
 * @param[in]  signal               [灯带灯效控制参数结构体指针]
 * @return     uint32_t             [灯效延时时间]
 */
uint32_t led_strip_production_scene(led_strip_t *strip, rgb_parameters_t *rgb, \
                                                           led_strip_signal_hsv_t *signal);
/**
 * @brief      配网灯效
 *
 * @param[in]  strip                [灯带结构体指针]
 * @param[in]  rgb                  [灯带灯珠颜色参数结构体指针]
 * @param[in]  signal               [灯带灯效控制参数结构体指针]
 * @return     uint32_t             [灯效延时时间]
 */
uint32_t led_strip_cfgnet_scene(led_strip_t *strip, rgb_parameters_t *rgb, \
                                                           led_strip_signal_hsv_t *signal);
/**
 * @brief      默认场景显示
 *
 * @param[in]  handle                The pointer of led strip
 * @param[in]  signal               the signals that generate rgb data buffer
 * @return     uint32_t             [灯效延时时间]
 */
uint32_t led_strip_default_scene(led_rgb_handle_t *handle, led_strip_signal_hsv_t *signal);

/**
 * @brief      复位场景灯效
 *
 * @param[in]  strip                [灯带结构体指针]
 * @param[in]  rgb                  [灯带灯珠颜色参数结构体指针]
 * @param[in]  signal               [灯带灯效控制参数结构体指针]
 * @return     uint32_t             [灯效延时时间]
 */

uint32_t led_strip_reset_scene(led_strip_t *strip, rgb_parameters_t *rgb, \
                                                           led_strip_signal_hsv_t *signal);

/**
 * @brief      自定义场景灯效
 *
 * @param[in]  strip                [灯带结构体指针]
 * @param[in]  rgb                  [灯带灯珠颜色参数结构体指针]
 * @param[in]  signal               [灯带灯效控制参数结构体指针]
 * @return     uint32_t             [灯效延时时间]
 */
uint32_t led_strip_custom_scene(led_strip_t *strip, rgb_parameters_t *rgb, \
                                                           led_strip_signal_hsv_t *signal);

/**
 * @brief      实时控制灯效
 *
 * @param[in]  strip                [灯带结构体指针]
 * @param[in]  rgb                  [灯带灯珠颜色参数结构体指针]
 * @param[in]  signal               [灯带灯效控制参数结构体指针]
 * @return     uint32_t             [灯效延时时间]
 */
uint32_t led_strip_realtime_scene(led_strip_t *strip, rgb_parameters_t *rgb, \
                                                           led_strip_signal_hsv_t *signal);

/**
 * @brief      关闭灯效
 *
 * @param[in]  strip                [灯带结构体指针]
 * @param[in]  rgb                  [灯带灯珠颜色参数结构体指针]
 * @param[in]  signal               [灯带灯效控制参数结构体指针]
 * @return     uint32_t             [灯效延时时间]
 */
uint32_t led_strip_off_scene(led_strip_t *strip, rgb_parameters_t *rgb, \
                                                           led_strip_signal_hsv_t *signal);

#ifdef __cplusplus
}
#endif

#endif