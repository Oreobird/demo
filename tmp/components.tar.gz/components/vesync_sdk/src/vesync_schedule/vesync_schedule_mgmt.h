/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_schedule_mgmt.h
 * @brief       Schedule模块对象相关定义
 * @author      Herve.lin,Niki
 * @date        2021-06-22
 */

#ifndef __VESYNC_SCHEDULE_MGMT_H__
#define __VESYNC_SCHEDULE_MGMT_H__

#include <stdint.h>
#include <stdbool.h>

#include "vesync_list.h"
#include "vesync_timer.h"
#include "vesync_mutex.h"
#include "vesync_schedule_internal.h"

#ifdef __cplusplus
extern "C"
{
#endif

/**
 * @brief Schedule 管理器
 */
typedef struct
{
    bool is_init;             // Schedule管理器初始化标志
    vesync_mutex_t mutex;     // Schedule实例互斥量
    uint8_t obj_nbr;          // Schedule实例数量
    struct list_head objects; // Schedule实例链表
} schedule_mgt_t;

/**
 * @brief Schedule 实例
 */
typedef struct
{
    bool is_init;                  // Schedule实例初始化标志
    bool is_running;               // Schedule实例运行状态
    bool is_check_time_out;        // Schedule实例是否已检查过超时，同步时区时调用
    vesync_timer_t *timer;         // Schedule实例定时器句柄
    uint32_t last_loop_min;        // Schedule实例定时器进行上一次调度的分钟数
    vesync_mutex_t mutex;          // Schedule实例互斥量
    vesync_schedule_param_t param; // Schedule实例的参数
    uint8_t schedule_nbr;          // 当前的Schedule配置项数量
    struct list_head schedules;    // Schedule配置项链表
} schedule_obj_t;

/**
 * @brief  Schedule 对象节点结构体
*/
typedef struct
{
    schedule_obj_t data;   // Schedule实例对象
    uint32_t handle;       // Schedule句柄存放对象ID
    struct list_head list; // 链表节点
} schedule_obj_node_t;

/**
 * @brief Schedule 初始化
 * @todo 跳秒检测的逻辑待实现与替换
 * @attention 需要确保系统时间不会出现倒流
 * @attention 需要确保系统时间不会有大于一分钟的跳变
 * @param[in] obj                   [Schedule实例对象]
 * @param[in] p_sch_param           [初始化参数]
 * @return int                      [SCHE_RESULT_E]
 */
int sche_obj_init(schedule_obj_t *p_obj, vesync_schedule_param_t *p_sch_param);

/**
 * @brief Schedule 反初始化
 * @param[in] p_obj                 [Schedule实例对象]
 * @return int                      [SCHE_RESULT_E]
 */
int sche_obj_deinit(schedule_obj_t *p_obj);

/**
 * @brief Schedule 添加配置项
 * @param[in] p_obj                 [Schedule实例对象]
 * @param[in] p_sch_cfg             [指向应添加的Schedule配置项]
 * @param[in] p_app_cfg             [指向应添加的APP配置]
 * @param[in] is_gen_id             [true - 模块自动生成ID； false - 方法调用方指定ID]
 * @return int                      [SCHE_RESULT_E]
 */
int sche_obj_add(schedule_obj_t *p_obj, vesync_schedule_t *p_sch_cfg, vesync_buf_t *p_app_cfg, bool is_gen_id);

/**
 * @brief Schedule 修改配置项
 * @param[in] p_obj                 [Schedule实例对象]
 * @param[in] p_sch_cfg             [指向新的Schedule配置项]
 * @param[in] p_app_cfg             [指向新的APP配置]
 * @return int                      [SCHE_RESULT_E]
 */
int sche_obj_upd(schedule_obj_t *p_obj, vesync_schedule_t *p_sch_cfg, vesync_buf_t *p_app_cfg);

/**
 * @brief Schedule 删除配置项
 * @param[in] p_obj                 [Schedule实例对象]
 * @param[in] sch_id                [要删除的Schedule ID]
 * @return int                      [SCHE_RESULT_E]
 */
int sche_obj_del(schedule_obj_t *p_obj, uint32_t sch_id);

/**
 * @brief Schedule 读取配置项
 * @param[in]  p_obj                [Schedule实例对象]
 * @param[in]  sch_id               [要读取的Schedule ID]
 * @param[out] p_sch_cfg            [指向读取Schedule配置项的缓存]
 * @param[out] p_app_cfg            [指向读取APP配置的缓存]
 * @return int                      [SCHE_RESULT_E]
 */
int sche_obj_get_by_id(schedule_obj_t *p_obj, uint32_t sch_id, vesync_schedule_t *p_sch_cfg, vesync_buf_t *p_app_cfg);

/**
 * @brief Schedule 获取距下一个schedule执行的时间（一天内）
 * @param[in]  p_obj                [Schedule实例对象]
 * @param[out] sec                  [距下个schedule执行的秒数，精度为一分钟]
 * @return int                      [SCHE_RESULT_E]
 */
int sche_obj_get_next_exc_sec(schedule_obj_t *p_obj, uint32_t *sec);

/**
 * @brief Schedule 按照顺序读取配置项
 * @param[in]  p_obj                [Schedule实例对象]
 * @param[in]  idx                  [需要读取的配置项开始的Schedule序号，注意和Schedule ID不一样]
 * @param[in]  nbr                  [需要读取的最大配置项数量]
 * @param[out] p_total_num          [指向输出配置项总数的缓存]
 * @param[out] p_sch_cfg_list       [指向读取Schedule配置项列表的缓存]
 * @param[out] p_app_cfg_list       [指向读取APP配置列表的缓存]
 * @param[out] p_out_len            [指向输出最终读取到配置项数量的缓存]
 * @return int                      [SCHE_RESULT_E]
 */
int sche_obj_get_by_index(schedule_obj_t *p_obj, uint32_t idx, uint32_t nbr, uint32_t *p_total_num,
                          vesync_schedule_t *p_sch_cfg_list, vesync_buf_t *p_app_cfg_list, uint32_t *p_out_len);

/**
 * @brief Schedule 清除所有配置项
 * @param[in] p_obj                 [Schedule实例对象]
 * @return int                      [SCHE_RESULT_E]
 */
int sche_obj_clear(schedule_obj_t *p_obj);

/**
 * @brief Schedule 读取配置项的执行次数
 * @param[in]  p_obj                [Schedule实例对象]
 * @param[in]  sch_id               [要读取的Schedule ID]
 * @param[out] p_exec_cnt           [指向输出Schedule配置项执行计数的缓存]
 * @return int                      [SCHE_RESULT_E]
 */
int sche_obj_get_exec_cnt(schedule_obj_t *p_obj, uint32_t sch_id, uint32_t *p_exec_cnt);

/**
 * @brief Schedule 读取配置项的总数
 * @param[in]  p_obj                [Schedule实例对象]
 * @param[out] p_nbr                [指向输出Schedule配置项总数的缓存]
 * @return int                      [SCHE_RESULT_E]
 */
int sche_obj_get_total_num(schedule_obj_t *p_obj, uint32_t *p_nbr);

#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_SCHEDULE_MGMT_H__ */
