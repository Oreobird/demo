/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_srpc_send.c
 * @brief       vesync SRPC模块的发送实现
 * @author      Herve
 * @date        2021-12-28
 */
#include <string.h>

#include "vesync_srpc_private.h"
#include "vesync_log_internal.h"
#include "vesync_json_internal.h"

#include "vesync_tl_payload_parse.h"

#include "vesync_common.h"
#include "vesync_memory.h"
#include "vesync_ble.h"
#include "vesync_utils.h"
#include "vesync_base64.h"

/**
 * @brief SRPC传输层发送ACK
 * @param[in]   p_data          [传输层透传数据]
 * @param[in]   len             [数据长度]
 * @param[in]   err_flag        [是否设置错误指示位]
 */
static void srpc_tl_send_ack(uint8_t *p_data, uint32_t len, bool err_flag)
{
    vesync_ble_send_cmd_ack(p_data, len, err_flag);
}

/**
 * @brief SRPC传输层发送普通数据包
 * @param[in]   p_data          [传输层透传数据]
 * @param[in]   len             [数据长度]
 * @param[in]   request_flag    [是否设置请求指示位（决定是否需要响应）]
 */
static void srpc_tl_send_data(uint8_t *p_data, uint32_t len, bool request_flag)
{
    vesync_ble_send_cmd_data(p_data, len, request_flag);
}

void srpc_tl_send_error_ack(uint16_t opcode, uint16_t status_code)
{
    uint16_t tl_pl_len = TL_PAYLOAD_PROTOCOL_HEAD_LEN;
    uint8_t *p_tl_pl = (uint8_t *)vesync_malloc(tl_pl_len);
    if (NULL == p_tl_pl)
    {
        SDK_LOG(LOG_ERROR, "malloc tl_payload fail\n");
        return;
    }
    if (SDK_OK != vesync_tl_payload_encode(opcode, status_code, NULL, 0, p_tl_pl, &tl_pl_len))
    {
        SDK_LOG(LOG_ERROR, "encode tl_payload fail\n");
        return;
    }
    srpc_tl_send_ack(p_tl_pl, tl_pl_len, true);
    vesync_free(p_tl_pl);
}

int vesync_srpc_send_response(const char *p_method, cJSON *p_resp)
{
    if ((NULL == p_resp) || (NULL == p_method))
    {
        return SDK_FAIL;
    }

    int ret = SDK_FAIL;
    uint32_t srpc_data_len;
    uint8_t *p_srpc_data = NULL;
    uint16_t tl_pl_len;
    uint8_t *p_tl_pl = NULL;

    cJSON_AddStringToObject(p_resp, "method", p_method);

    p_srpc_data = srpc_response_marshal(p_resp, &srpc_data_len);
    if (NULL == p_srpc_data)
    {
        SDK_LOG(LOG_ERROR, "srpc marshal fail\n");
        srpc_tl_send_error_ack(SRPC_OPCODE_RESPONSE, TL_FRAME_INTERNAL_ERR);
        goto EXIT;
    }
    tl_pl_len = srpc_data_len + TL_PAYLOAD_PROTOCOL_HEAD_LEN;
    p_tl_pl = (uint8_t *)vesync_malloc(tl_pl_len);
    if (NULL == p_tl_pl)
    {
        srpc_tl_send_error_ack(SRPC_OPCODE_RESPONSE, TL_FRAME_INTERNAL_ERR);
        goto EXIT;
    }
    ret = vesync_tl_payload_encode(SRPC_OPCODE_RESPONSE, 0, p_srpc_data, srpc_data_len, p_tl_pl, &tl_pl_len);
    if (ret != SDK_OK)
    {
        srpc_tl_send_error_ack(SRPC_OPCODE_RESPONSE, TL_FRAME_INTERNAL_ERR);
        goto EXIT;
    }
    // 通过传输层把SRPC响应发送回去
    srpc_tl_send_ack((uint8_t *)p_tl_pl, tl_pl_len, false);

#if 0
    LOG_RAW_HEX(LOG_INFO, "protobuf:", p_srpc_data, srpc_data_len);
    LOG_RAW_HEX(LOG_INFO, "ble_data:", p_tl_pl, tl_pl_len);
    uint8_t *base64 = vesync_malloc(1024);
    if (base64 != NULL)
    {
        size_t out_len;
        vesync_base64_encode(base64, 1024, &out_len, p_srpc_data, srpc_data_len);
        SDK_LOG(LOG_DEBUG, "protobuf_base64:%s\n", base64);
        vesync_free(base64);
    }
#endif

    ret = SDK_OK;
EXIT:
    vesync_free(p_srpc_data);
    vesync_free(p_tl_pl);
    return ret;
}

void srpc_send_report(cJSON *p_json)
{
    if (NULL == p_json)
    {
        return;
    }

    char *p_tx = cJSON_PrintUnformatted(p_json);
    uint32_t tx_len = strlen(p_tx);

    uint16_t tl_pl_len = tx_len + TL_PAYLOAD_PROTOCOL_HEAD_LEN;
    uint8_t *p_tl_pl = (uint8_t *)vesync_malloc(tl_pl_len);
    if (NULL == p_tl_pl)
    {
        SDK_LOG(LOG_ERROR, "tl_payload malloc fail\n");
        goto EXIT;
    }
    if (SDK_OK != vesync_tl_payload_encode(SRPC_OPCODE_REPORT, 0, (uint8_t *)p_tx, tx_len, p_tl_pl, &tl_pl_len))
    {
        SDK_LOG(LOG_ERROR, "tl_payload encode fail\n");
        goto EXIT;
    }
    srpc_tl_send_data(p_tl_pl, tl_pl_len, true);

EXIT:
    vesync_free(p_tx);
    vesync_free(p_tl_pl);
}

void srpc_send_log(cJSON *p_json)
{
    if (NULL == p_json)
    {
        return;
    }
    char *p_tx = cJSON_PrintUnformatted(p_json);
    uint32_t tx_len = strlen(p_tx);

    uint16_t tl_pl_len = tx_len + TL_PAYLOAD_PROTOCOL_HEAD_LEN;
    uint8_t *p_tl_pl = (uint8_t *)vesync_malloc(tl_pl_len);
    if (NULL == p_tl_pl)
    {
        SDK_LOG(LOG_ERROR, "tl_payload malloc fail\n");
        goto EXIT;
    }
    if (SDK_OK != vesync_tl_payload_encode(SRPC_OPCODE_LOG, 0, (uint8_t *)p_tx, tx_len, p_tl_pl, &tl_pl_len))
    {
        SDK_LOG(LOG_ERROR, "tl_payload encode fail\n");
        goto EXIT;
    }
    srpc_tl_send_data(p_tl_pl, tl_pl_len, true);

EXIT:
    vesync_free(p_tx);
    vesync_free(p_tl_pl);
}
