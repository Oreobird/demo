/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_log.h
 * @brief       log模块接口定义
 * @date        2021-04-20
 */

#ifndef __VESYNC_LOG_H__
#define __VESYNC_LOG_H__

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief 日志级别
 */
typedef enum
{
    LOG_INVALID = 0,
    LOG_DEBUG   = 1,
    LOG_INFO    = 2,
    LOG_WARN    = 3,
    LOG_ERROR   = 4,
    LOG_DISABLE = 5,    /* disable log */
} LOG_LEVEL_E;

/**
 * @brief Log component flag
 */
typedef enum
{
    COMP_HAL = 0,
    COMP_OS,
    COMP_SDK,
    COMP_APP,
} TYPE_COMPONENT_E;


/**
 * @brief  日志打印回调
 * @param[in]  *format       [打印格式]
 * @param[in]  ...           [可变参数]
 * @return  int              [成功：SDK_OK，失败：SDK_FAIL]
 */
typedef int (*print_cb_t)(const char *format, ...);


/**
 * @brief  日志转存回调
 * @param[in]  p_data        [日志数据指针]
 * @param[in]  len           [数据长度]
 * @return  int              [成功：SDK_OK，失败：SDK_FAIL]
 */
typedef int (*log_transfer_cb_t)(char *p_data, int len);


/**
 * @brief  日志初始化
 * @return  int              [成功：SDK_OK, 失败：SDK_FAIL]
 */
int vesync_log_init(void);


/**
 * @brief  日志资源释放
 * @return void
 */
void vesync_log_deinit(void);


/**
 * @brief 注册日志转存的回调函数
 * @param[in]  cb            [转存的回调函数]
 */
void vesync_log_reg_transfer_cb(log_transfer_cb_t cb);


/**
 * @brief 设置普通日志打印级别
 * @param[in]  level         [日志级别]
 */
void vesync_log_level_set(LOG_LEVEL_E level);


/**
 * @brief 设置十六进制数据日志打印级别
 * @param[in]  level         [日志级别]
 */
void vesync_log_raw_level_set(LOG_LEVEL_E level);


/**
 * @brief 普通日志打印
 * @param[in]  comp          [打印tag]
 * @param[in]  level         [等级]
 * @param[in]  anchor        [函数名或者文件名]
 * @param[in]  line          [行数]
 * @param[in]  format        [格式化字符串]
 */
#if CONFIG_VESYNC_LOG_PREFIX_NONE_ENABLE
void vesync_log_print(TYPE_COMPONENT_E comp, LOG_LEVEL_E level, int line, const char *format, ...);
#else
void vesync_log_print(TYPE_COMPONENT_E comp, LOG_LEVEL_E level, const char *func, int line, const char *format, ...);
#endif

/**
 * @brief 十六进制数据日志打印级别
 * @param[in] level          [打印等级]
 * @param[in] p_prefix       [字符前缀]
 * @param[in] p_data         [打印数据]
 * @param[in] length         [打印数据长度]
 */
void vesync_log_hex_print(LOG_LEVEL_E level, const char *p_prefix, void *p_data, unsigned short length);


#ifdef CONFIG_VESYNC_LOG_MINI_LEVEL
/**
 * @brief  十六进制数据日志打印
 */
#define LOG_RAW_HEX(level, prefix, buf, len)           \
    do                                                 \
    {                                                  \
        if (level < CONFIG_VESYNC_LOG_MINI_LEVEL)      \
        {                                              \
            break;                                     \
        }                                              \
        vesync_log_hex_print(level, prefix, buf, len); \
    } while (0)
#if CONFIG_VESYNC_LOG_PREFIX_FILENAME_ENABLE
#define LOG_IMPL(flag, level, format, ...)                                            \
    do                                                                                \
    {                                                                                 \
        if (level < CONFIG_VESYNC_LOG_MINI_LEVEL)                                     \
        {                                                                             \
            break;                                                                    \
        }                                                                             \
        vesync_log_print(flag, level, __FILE__, __LINE__, format, ##__VA_ARGS__); \
    } while (0)
#elif CONFIG_VESYNC_LOG_PREFIX_NONE_ENABLE
#define LOG_IMPL(flag, level, format, ...)                                            \
    do                                                                                \
    {                                                                                 \
        if (level < CONFIG_VESYNC_LOG_MINI_LEVEL)                                     \
        {                                                                             \
            break;                                                                    \
        }                                                                             \
        vesync_log_print(flag, level, __LINE__, format, ##__VA_ARGS__); \
    } while (0)
#else
#define LOG_IMPL(flag, level, format, ...)                                            \
    do                                                                                \
    {                                                                                 \
        if (level < CONFIG_VESYNC_LOG_MINI_LEVEL)                                     \
        {                                                                             \
            break;                                                                    \
        }                                                                             \
        vesync_log_print(flag, level, __FUNCTION__, __LINE__, format, ##__VA_ARGS__); \
    } while (0)
#endif
#else
/**
 * @brief  十六进制数据日志打印
 */
#define LOG_RAW_HEX(level, prefix, buf, len)           \
    do                                                 \
    {                                                  \
        vesync_log_hex_print(level, prefix, buf, len); \
    } while (0)
#if CONFIG_VESYNC_LOG_PREFIX_FILENAME_ENABLE
#define LOG_IMPL(flag, level, format, ...)                                            \
    do                                                                                \
    {                                                                                 \
        vesync_log_print(flag, level, __FILE__, __LINE__, format, ##__VA_ARGS__); \
    } while (0)
#elif CONFIG_VESYNC_LOG_PREFIX_NONE_ENABLE
#define LOG_IMPL(flag, level, format, ...)                                            \
    do                                                                                \
    {                                                                                 \
        vesync_log_print(flag, level, __LINE__, format, ##__VA_ARGS__); \
    } while (0)
#else
#define LOG_IMPL(flag, level, format, ...)                                            \
    do                                                                                \
    {                                                                                 \
        vesync_log_print(flag, level, __FUNCTION__, __LINE__, format, ##__VA_ARGS__); \
    } while (0)
#endif
#endif /* CONFIG_VESYNC_LOG_MINI_LEVEL */

/**
 * @brief  HAL Adapter日志打印
 */
#define HAL_LOG(level, format, ...) LOG_IMPL(COMP_HAL, level, format, ##__VA_ARGS__)

/**
 * @brief  OS Adapter日志打印
 */
#define OS_LOG(level, format, ...) LOG_IMPL(COMP_OS, level, format, ##__VA_ARGS__)

/**
 * @brief  APP日志打印
 */
#define APP_LOG(level, format, ...) LOG_IMPL(COMP_APP, level, format, ##__VA_ARGS__)

#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_LOG_H__ */

