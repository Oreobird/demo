/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_schedule.h
 * @brief       倒计时模块接口定义
 * @date        2021-05-27
 */

#ifndef __VESYNC_SCHEDULE_H__
#define __VESYNC_SCHEDULE_H__

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif


/**
@brief away结果类型
*/
typedef enum
{
    SCHE_RESULT_OK = 0,
    SCHE_RESULT_NOEXEC = 1,
    SCHE_RESULT_FAIL = 2,
    SCHE_RESULT_CONFLICT = 3,     //schedule 时间冲突
} SCHE_RESULT_E;

/**
@brief schedule 对比结果类型
*/
typedef enum
{
    SCH_NOT_EXE,
    SCH_EXE_ONCE,
    SCH_EXE_WEEKLY,
    SCH_EXE_ERR
} SCHE_COMPARE_RESULT_E;

/**
@brief away属性类型
*/
typedef enum
{
    SCHE_ONCE,
    SCHE_WEEKLY
} SCHE_ATTRIBUTE_E;

/**
 * @brief schedule 回调函数定义
 * @param[in]  pSch_data            [指向schedule应用程序配置数据结构]
 * @param[in]  timestamp　              [schedule执行的时间点]
 */
typedef SCHE_RESULT_E (*schedule_cb_t)(void *pSch_data, uint32_t timestamp);

/**
* @brief schedule 模块数据结构
*/
typedef struct
{
    uint32_t schId;         //schedule　id　应用层传递进来
    uint8_t loop;           //循环周循环loop
    uint32_t timestamp;     //schedule定时的时间点
    int32_t exec_cnt;       //schedule执行次数
    void *pSchData;         //指向应用层配置数据
    schedule_cb_t schCb;    //schedule 回调函数
} schedule_data_t;


/**
 * @brief 删除schedule cycle 任务
 * @param[in] schid             [需要删除的schedule id]
 * @return int                  [成功：SDK_OK, 失败：SDK_FAIL]
 */
int vesync_schedule_list_del(uint32_t schid);


/**
 * @brief 应用层增加schedule 任务
 * @param[in] pSchData          [schedule 的数据结构]
 * @return  int                 [成功：SDK_OK, 失败：SDK_FAIL]
 */
int vesync_schedule_add(schedule_data_t *pSchData);

/**
 * @brief 移除schedule 中的任务
 * @param[in] schid             [schedule id]
 * @return                      [成功：SDK_OK, 失败：SDK_FAIL]
 */
int vesync_schedule_remove(uint32_t schid);

/**
 * @brief 传入时间戳计算星期
 * @param[in] ts                [需要计算的时间戳]
 * @return uint8_t              [1-7 周一到周日]
 */
uint8_t vesync_schedule_loop_calc(uint8_t repeat, SCHE_ATTRIBUTE_E attr);


/**
 * @brief       schedule repeat 计算api
 * @param[in]   repeat          [原始配置repeat]
 * @param[in]   ts              [原始配置的UTC时间]
 * @param[in]   shift_ts        [偏移后的UTC时间]
 * @return      loop 的数值
 */
uint8_t vesync_schedule_repeat_calc(uint8_t repeat,uint32_t ts, uint32_t shift_ts);

/**
 * @brief 获取当天是星期几
 * @param[in]   ts              [原始配置的UTC时间]
 * @return uint8_t              [1-7 周一到周日]
 */
uint8_t vesync_schedule_get_timestamp_weekday(uint32_t ts);

/**
 * @brief schedule cycle任务链表释放
 */
void vesync_schedule_list_destroy(void);

/**
 * @brief 获取当前schedule cycle 任务数量
 * @return  uint8_t             [schedule cycle 的数量]
 */
uint8_t vesync_schedule_get_num(void);

/**
 * @brief schedule 冲突判断
 * @param[in] pSchData          [schedule cycle数据结构]
 * @return SCHE_RESULT_E        [判断结果]
 */
SCHE_RESULT_E vesync_schedule_conflict_check(schedule_data_t *pSchData);

/**
 * @brief  判断schedule单次执行时，下发的时间比当前时间早，则进行调整
 * @param[in] ts                [schedule时间戳]
 * @param[in] repeat            [schedule是否重复执行]
 * @return uint32_t 更新后的时间戳
 */
uint32_t vesync_schedule_ts_check(uint32_t ts, uint8_t repeat);

/**
 * @brief  根据schedule ID查询schedule执行的次数
 * @param[in]  uint32_t         [schedule ID]
 * @return  int32_t             [对应schedule执行的次数]
 */
int32_t vesync_schedule_get_exec_cnt(uint32_t schd_id);

/**
 * @brief schedule初始化
 */
void vesync_schedule_init(void);

#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_SCHEDULE_H__ */



