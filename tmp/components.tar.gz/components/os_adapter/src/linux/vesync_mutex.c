/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_mutex.c
 * @brief       mutex抽象层，封装linux posix互斥量相关接口
 * @author      Joshua
 * @date        2021-04-20
 */

#include <stdlib.h>
#include <pthread.h>

#include "vesync_common.h"
#include "vesync_mutex.h"

static pthread_mutexattr_t s_attr;

vesync_mutex_t vesync_mutex_new(void)
{
    pthread_mutex_t *pmtx = malloc(sizeof(pthread_mutex_t));
    if (pmtx == NULL)
    {
        return NULL;
    }

    pthread_mutex_init(pmtx, NULL);
    return (vesync_mutex_t)pmtx;
}

int vesync_mutex_lock(vesync_mutex_t mtx)
{
    VCOM_NULL_PARAM_CHK(mtx, return VOS_FAIL);
    pthread_mutex_lock((pthread_mutex_t*)mtx);
    return VOS_OK;
}

int vesync_mutex_try_lock(vesync_mutex_t mtx)
{
    VCOM_NULL_PARAM_CHK(mtx, return VOS_FAIL);
    pthread_mutex_trylock((pthread_mutex_t*)mtx);
    return VOS_OK;
}

int vesync_mutex_unlock(vesync_mutex_t mtx)
{
    VCOM_NULL_PARAM_CHK(mtx, return VOS_FAIL);
    pthread_mutex_unlock((pthread_mutex_t*)mtx);
    return VOS_OK;
}

int vesync_mutex_free(vesync_mutex_t mtx)
{
    VCOM_NULL_PARAM_CHK(mtx, return VOS_FAIL);
    pthread_mutex_destroy((pthread_mutex_t*)mtx);
    free(mtx);
    return VOS_OK;
}

vesync_mutex_t vesync_recursive_mutex_new(void)
{
    pthread_mutex_t *pmtx = malloc(sizeof(pthread_mutex_t));
    if (pmtx == NULL)
    {
        return NULL;
    }

    pthread_mutexattr_init(&s_attr);
    pthread_mutexattr_settype(&s_attr, PTHREAD_MUTEX_RECURSIVE);
    pthread_mutex_init(pmtx, &s_attr);

    return (vesync_mutex_t)pmtx;
}

int vesync_recursive_mutex_lock(vesync_mutex_t mtx)
{
    VCOM_NULL_PARAM_CHK(mtx, return VOS_FAIL);
    pthread_mutex_lock((pthread_mutex_t*)mtx);
    return VOS_OK;
}

int vesync_recursive_mutex_try_lock(vesync_mutex_t mtx)
{
    VCOM_NULL_PARAM_CHK(mtx, return VOS_FAIL);
    pthread_mutex_trylock((pthread_mutex_t*)mtx);
    return VOS_OK;
}

int vesync_recursive_mutex_unlock(vesync_mutex_t mtx)
{
    VCOM_NULL_PARAM_CHK(mtx, return VOS_FAIL);
    pthread_mutex_unlock((pthread_mutex_t*)mtx);
    return VOS_OK;
}

int vesync_recursive_mutex_free(vesync_mutex_t mtx)
{
    VCOM_NULL_PARAM_CHK(mtx, return VOS_FAIL);
    pthread_mutex_destroy((pthread_mutex_t*)mtx);
    pthread_mutexattr_destroy(&s_attr);
    free(mtx);
    return VOS_OK;
}
