/*
 * Copyright © Vesync Technologies Co.Ltd. 2019-2021. All rights reserved.
 * @file    vesync_https.c
 * @brief   https模块
 * @author  CharlesMei
 * @date    2021-05-24
 */


#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <netdb.h>
#include <sys/socket.h>

#include "mbedtls/platform.h"
#include "mbedtls/net_sockets.h"
#include "mbedtls/ssl.h"
#include "mbedtls/entropy.h"
#include "mbedtls/ctr_drbg.h"
#include "mbedtls/error.h"
#include "mbedtls/certs.h"
#include "mbedtls/debug.h"
#include "mbedtls/x509_crt.h"
#include "mbedtls/x509_csr.h"

#include "sdkconfig.h"
#include "vesync_memory.h"
#include "vhal_wifi.h"
#include "vesync_https_private.h"


static const char *HTTPS_REQUEST = "%s " "%s" " HTTP/1.1\r\n"
                                   "Host: %s \r\n"
                                   "Accept: */*\r\n"
                                   "Content-Type:application/json\r\n"
                                   "%s"
                                   "Content-Length:%d\r\n"
                                   "\r\n"
                                   "%s";

static const char* KEEPALIVE_STRING = "Connection:keep-alive\r\n"
                                      "Keep-Alive：150\r\n";

static const char* ANTI_KEEPALIVE_STRING = "Connection:close\r\n";

static mbedtls_entropy_context  s_entropy;
static mbedtls_ctr_drbg_context s_ctr_drbg;
static mbedtls_ssl_context      s_ssl_context;
static mbedtls_x509_crt         s_cacert;
static mbedtls_ssl_config       s_ssl_conf;
static mbedtls_net_context      s_server_fd;

//双向认证定义
static mbedtls_x509_crt client_cert;
static mbedtls_pk_context pk_ctx;

static char s_https_host[HTTPS_HOST_LEN];
static char s_https_path[HTTPS_PATH_LEN];
static uint16_t s_https_port = HTTPS_DEFAULT_PORT;
static bool s_keep_alive_enable = true;        // true时，http头部填充keepalive字段
static bool s_is_keep_alive = false;           // true时，不需要再初始化mbedtls接口


/**
 * @brief           从http的URL中提取host和port
 * @param[in]       url         [入参，完整的URL]
 * @return          int         [成功/失败]
 */
 static int vesync_https_parse_url(const char *url)
{
    const char *ptr1 = url;
    char *ptr2 = NULL;
    int len = 0;

    // 删除"http://"
    if (0 == strncmp(ptr1, "http://", strlen("http://")))
    {
        ptr1 += strlen("http://");
    }
    else
    {
        return VERR_FAIL;
    }

    // 提取path
    ptr2 = strchr(ptr1,'/');    // 查找第一个‘/’所在位置
    if (ptr2)
    {
        len = strlen(ptr1) - strlen(ptr2);
        if (len >= HTTPS_HOST_LEN)
        {
            HTTPS_LOG(LOG_WARN, "http host is too long\r\n");
            return VERR_FAIL;
        }
        if (*(ptr2 + 1))
        {
            if (strlen(ptr2) >= HTTPS_PATH_LEN)
            {
                HTTPS_LOG(LOG_WARN, "http path is too long\r\n");
                return VERR_FAIL;
            }
            memcpy(s_https_path, ptr2, strlen(ptr2));
            s_https_path[strlen(ptr2)] = '\0';
        }
        else
        {
            memcpy(s_https_path, "/", 1);
            *(s_https_path + 1) = '\0';
        }
        HTTPS_LOG(LOG_DEBUG, "http path: %s\n", s_https_path);
    }

    // 提取host

    memcpy(s_https_host, ptr1, len);
    s_https_host[len] = '\0';
    HTTPS_LOG(LOG_DEBUG, "http host: %s\n", s_https_host);

    // 提取port
    ptr2 = strchr(s_https_host,':');
    if (ptr2)
    {
        *ptr2++ = '\0';
        if (atoi(ptr2) > 0xffff)
        {
            HTTPS_LOG(LOG_WARN, "http port is too large\r\n");
            return VERR_FAIL;
        }
        s_https_port = atoi(ptr2);
    }
    HTTPS_LOG(LOG_DEBUG, "http port: %s\n", s_https_port);

    return VERR_OK;
}

 /**
  * @brief        mbedtls 释放空间
  */
 void vesync_mbedtls_module_destroy(void)
 {
     mbedtls_net_free(&s_server_fd);
     mbedtls_x509_crt_free(&s_cacert);
     mbedtls_ssl_config_free(&s_ssl_conf);
     mbedtls_ctr_drbg_free(&s_ctr_drbg);
     mbedtls_entropy_free(&s_entropy);

     //双向认证 - client认证
     mbedtls_x509_crt_free(&client_cert);
     mbedtls_pk_free(&pk_ctx);

     mbedtls_ssl_free(&s_ssl_context);

     VESYNC_PRINTF_FREE_HEAP();
 }

/**
 * @brief         初始化mbedtls模块
 * @param[in]     config        [初始化配置，详见vesync_https_client_config_t]
 * @return        int           [成功或失败]
 */
static int vesync_mbedtls_module_init(vesync_https_client_config_t *config)
{
    int ret = VERR_FAIL;
    char port_string[8];

    memset(port_string, 0, sizeof(port_string));

    mbedtls_ssl_init(&s_ssl_context);
    mbedtls_x509_crt_init(&s_cacert);

    //双向认证 -- client认证
    mbedtls_x509_crt_init(&client_cert);
    mbedtls_pk_init( &pk_ctx );

    mbedtls_ctr_drbg_init(&s_ctr_drbg);
    mbedtls_ssl_config_init(&s_ssl_conf);
    mbedtls_entropy_init(&s_entropy);

    HTTPS_LOG(LOG_DEBUG, "Seeding the random number generator\n");

    ret = mbedtls_ctr_drbg_seed(&s_ctr_drbg, mbedtls_entropy_func, &s_entropy, NULL, 0);
    if (ret != 0)
    {
        HTTPS_LOG(LOG_ERROR, "mbedtls_ctr_drbg_seed returned %d\n", ret);
        goto exit;
    }

    //CA认证 -- CA证书
    HTTPS_LOG(LOG_DEBUG, "Loading the CA root certificate...\n");

    if ((NULL != config->ca_pem) && (strlen(config->ca_pem) != 0 ))
    {
        HTTPS_LOG(LOG_DEBUG,"ca_pem [%p] len: %d\n", config->ca_pem, strlen(config->ca_pem));
        ret = mbedtls_x509_crt_parse(&s_cacert, (const unsigned char*)config->ca_pem, strlen(config->ca_pem) + 1);
        if (ret < 0)
        {
            HTTPS_LOG(LOG_ERROR, "mbedtls_x509_crt_parse returned -0x%x\n\n", -ret);
            goto exit;
        }
    }

     HTTPS_LOG(LOG_DEBUG, "Setting hostname for TLS session...\n");
    /* Hostname set here should match CN in server certificate */
    if ((ret = mbedtls_ssl_set_hostname(&s_ssl_context, s_https_host)) != 0)
    {
        HTTPS_LOG(LOG_ERROR, "mbedtls_ssl_set_hostname returned -0x%x\n", -ret);
        goto exit;
    }

    HTTPS_LOG(LOG_DEBUG, "Setting up the SSL/TLS structure...\n");
    ret = mbedtls_ssl_config_defaults(&s_ssl_conf,
                                      MBEDTLS_SSL_IS_CLIENT,
                                      MBEDTLS_SSL_TRANSPORT_STREAM,
                                      MBEDTLS_SSL_PRESET_DEFAULT);
    if (ret != 0)
    {
        HTTPS_LOG(LOG_ERROR, "mbedtls_ssl_config_defaults returned %d\n", ret);
        goto exit;
    }

    /**********************************************************************************
       MBEDTLS_SSL_VERIFY_OPTIONAL is bad for security, in this example it will print
       a warning if CA verification fails but it will continue to connect.
       You should consider using MBEDTLS_SSL_VERIFY_REQUIRED in your own code.
    ***********************************************************************************/
    mbedtls_ssl_conf_authmode(&s_ssl_conf, MBEDTLS_SSL_VERIFY_REQUIRED ); //
    //服务器认证
    mbedtls_ssl_conf_ca_chain(&s_ssl_conf, &s_cacert, NULL);

    //双向认证 -- client证书
    if ((NULL != config->client_pem) && (strlen(config->client_pem) != 0)
        && (NULL != config->client_key) && (strlen(config->client_key) != 0))
    {
        ret = mbedtls_x509_crt_parse(&client_cert, (const unsigned char *)config->client_pem, strlen(config->client_pem) + 1);
        if (ret != 0)
        {
            HTTPS_LOG(LOG_ERROR, " failed\n  !  mbedtls_x509_crt_parse returned -0x%x\n\n", -ret);
            goto exit;
        }

        ret = mbedtls_pk_parse_key( &pk_ctx, (const unsigned char *)config->client_key, strlen(config->client_key) + 1, NULL, 0);
        if ( ret != 0)
        {
            HTTPS_LOG(LOG_ERROR, " failed\n  !  mbedtls_pk_parse_key returned -0x%x\n\n", -ret);
            goto exit;
        }

        HTTPS_LOG(LOG_DEBUG, "mbedtls_ssl_conf_own_cert config client_cert...\n");
        if ((ret = mbedtls_ssl_conf_own_cert(&s_ssl_conf, &client_cert, &pk_ctx)) != 0)
        {
            HTTPS_LOG(LOG_ERROR," failed\n  ! mbedtls_ssl_conf_own_cert returned %d\n\n", ret);
            goto exit;
        }
    }

    mbedtls_ssl_conf_rng(&s_ssl_conf, mbedtls_ctr_drbg_random, &s_ctr_drbg);

#ifdef CONFIG_MBEDTLS_DEBUG
    mbedtls_esp_enable_debug_log(&s_ssl_conf, 4);
#endif /* CONFIG_MBEDTLS_DEBUG */

    if ((ret = mbedtls_ssl_setup(&s_ssl_context, &s_ssl_conf)) != 0)
    {
        HTTPS_LOG(LOG_ERROR, "mbedtls_ssl_setup returned -0x%x\n\n", -ret);
        mbedtls_ssl_session_reset(&s_ssl_context);
        goto exit;
    }

    // 判断Wi-Fi网络是否连接成功
    HTTPS_LOG(LOG_INFO, "Waiting for AP connected...\n");
    if (!vhal_wifi_get_link_status((int)HTTPS_WAIT_TIME_MS))
    {
        HTTPS_LOG(LOG_ERROR, "Network was disconnect!\n");
        goto exit;
    }
    HTTPS_LOG(LOG_INFO, "Connect to AP.\n");

    // 建立连接
    mbedtls_net_init(&s_server_fd);
    snprintf(port_string, sizeof(port_string), "%d", s_https_port);
    HTTPS_LOG(LOG_DEBUG, "port len %d \n", strlen(port_string));
    HTTPS_LOG(LOG_INFO, "Connecting to %s:%s\n", s_https_host, port_string);
    ret = mbedtls_net_connect(&s_server_fd, s_https_host, port_string, MBEDTLS_NET_PROTO_TCP);
    if (ret != 0)
    {
        HTTPS_LOG(LOG_ERROR, "mbedtls_net_connect returned -0x%x\n", -ret);
        goto exit;
    }
    HTTPS_LOG(LOG_DEBUG, "Connected.\n");

    // send/recv 回调
    mbedtls_ssl_set_bio(&s_ssl_context, &s_server_fd, mbedtls_net_send, mbedtls_net_recv, NULL);

    // 握手
    HTTPS_LOG(LOG_DEBUG, "Performing the SSL/TLS handshake...\n");

    VESYNC_PRINTF_FREE_HEAP();

    while ((ret = mbedtls_ssl_handshake(&s_ssl_context)) != 0)
    {
        HTTPS_LOG(LOG_DEBUG, "mbedtls_ssl_handshake  = -0x%x\n", -ret);
        if (ret != MBEDTLS_ERR_SSL_WANT_READ && ret != MBEDTLS_ERR_SSL_WANT_WRITE)
        {
            VESYNC_PRINTF_FREE_HEAP();
            HTTPS_LOG(LOG_ERROR, "mbedtls_ssl_handshake returned -0x%x\n", -ret);
            goto exit;
        }
    }

    HTTPS_LOG(LOG_DEBUG, "Verifying peer X.509 certificate...\n");
    if (0 != mbedtls_ssl_get_verify_result(&s_ssl_context))
    {
        /* In real life, we probably want to close connection if ret != 0 */
        HTTPS_LOG(LOG_ERROR, "Failed to verify peer certificate!\n");
        goto exit;
    }
    else
    {
        HTTPS_LOG(LOG_INFO, "Certificate verified.\n");
    }

    HTTPS_LOG(LOG_DEBUG, "Cipher suite is %s\n", mbedtls_ssl_get_ciphersuite(&s_ssl_context));

    return VERR_OK;

exit:
    vesync_mbedtls_module_destroy();
    return VERR_FAIL;
}

/**
 * @brief         https send request
 * @param[in]     method        [请求的方法]
 * @param[in]     https_buffer  [https通信的数据交互缓存区，大小为HTTPS_BUFFER_SIZE]
 * @param[in]     send_buf      [请求的数据内容]
 * @return        int           [成功或失败]
 */
static int vesync_https_send_request(HTTPS_METHOD_TYPE_E method, char *https_buffer, char *send_buf)
{
    int ret;
    char https_method[][8] = {"GET", "POST"};
    char keep_alive_string[100];
    size_t written_bytes = 0;

    memset(keep_alive_string, 0, sizeof(keep_alive_string));

    if (s_keep_alive_enable)
    {
        snprintf(keep_alive_string, sizeof(keep_alive_string), "%s", KEEPALIVE_STRING);
    }
    else
    {
        snprintf(keep_alive_string, sizeof(keep_alive_string), "%s", ANTI_KEEPALIVE_STRING);
    }
    memset(https_buffer, 0, HTTPS_BUFFER_SIZE);
    snprintf(https_buffer, HTTPS_BUFFER_SIZE, HTTPS_REQUEST, https_method[method], s_https_path, s_https_host,
            keep_alive_string, strlen(send_buf), send_buf);
    HTTPS_LOG(LOG_DEBUG, "\n%s\n", https_buffer);

    do
    {
        ret = mbedtls_ssl_write(&s_ssl_context, (const unsigned char *)https_buffer + written_bytes,
                                strlen(https_buffer) - written_bytes);
        if (ret >= 0)
        {
            HTTPS_LOG(LOG_INFO, "%d bytes written\n", ret);
            written_bytes += ret;
        }
        else if (ret != MBEDTLS_ERR_SSL_WANT_WRITE && ret != MBEDTLS_ERR_SSL_WANT_READ)
        {
            HTTPS_LOG(LOG_ERROR, "mbedtls_ssl_write returned -0x%x\n", -ret);
            return VERR_FAIL;
        }
    } while (written_bytes < strlen(https_buffer));

    return VERR_OK;
}

/**
 * @brief         从https的响应中提取消息内容，需要手动释放内存
 * @param[in/out] p_buf         [输入为接收到的消息，输出为去掉头部的payload]
 * @param[in/out] p_buf_len     [输入为接收到的消息的长度，输出为payload的长度]
 * @param[out]    p_ctx_len     [http内容长度]
 * @return        int           [成功/失败]
 */
static int vesync_https_parse_head(char *p_buf, int *p_buf_len, int *p_ctx_len)
{
    int content_len = 0;
    char *ptmp = NULL;
    char *response = NULL;
    int head_len = 0;

/* 接收到的消息格式如下：
HTTP/1.1 200 OK
Accept-Ranges: bytes
Content-Length: 10363
Content-Type: text/plain; charset=utf-8
Last-Modified: Wed, 18 Sep 2019 12:04:16 GMT
Date: Thu, 19 Sep 2019 07:12:02 GMT


*/

    ptmp = (char*)strstr(p_buf, "HTTP/1.1");
    if (!ptmp)
    {
        HTTPS_LOG(LOG_ERROR,"http/1.1 not faind\n");
        return VERR_FAIL;
    }
    if (atoi(ptmp + 9) != 200)
    {
        HTTPS_LOG(LOG_ERROR, "result:\n%s\n", p_buf);
        return VERR_FAIL;
    }
    ptmp = (char*)strstr(p_buf, "Content-Length:");   // 内容长度
    if (!ptmp)
    {
        HTTPS_LOG(LOG_ERROR, "http header does not contain Content-Length!!\n");
        return VERR_FAIL;
    }
    else
    {
        *p_ctx_len = atoi(ptmp + strlen("Content-Length:") + 1);   // 有一个空格
    }

    ptmp = (char*)strstr(p_buf,"\r\n\r\n");
    if (!ptmp)
    {
        HTTPS_LOG(LOG_ERROR, "Not found the end of http head!\n");
        return VERR_FAIL;
    }

    ptmp = ptmp + 4;    //指针偏移到内容
    head_len = ptmp - p_buf;
    HTTPS_LOG(LOG_DEBUG, "head_len = %d\n", head_len);
    if (head_len > *p_buf_len)
    {
        HTTPS_LOG(LOG_ERROR, " http head err!\n");
        return VERR_FAIL;
    }
    content_len = *p_buf_len - head_len;

    response = (char *)vesync_malloc(content_len + 1);
    if (!response)
    {
        HTTPS_LOG(LOG_ERROR, "vesync_malloc failed!\n");
        return VERR_FAIL;
    }
    memset(response, 0, content_len + 1);

    HTTPS_LOG(LOG_DEBUG, "content_len = %d\n", content_len);
    memcpy(response, ptmp, content_len);
    memset(p_buf, 0, *p_buf_len);
    *p_buf_len = content_len;
    memcpy(p_buf, response, *p_buf_len);
    HTTPS_UTIL_SAFE_FREE(response);

    return VERR_OK;
}

/**
 * @brief         接受并处理回复
 * @param[in]     https_buffer  [https通信的数据交互缓存区，大小为HTTPS_BUFFER_SIZE]
 * @param[out]    recv_buf      [返回的数据内容缓存buffer]
 * @param[in/out] recv_len      [返回的数据内容长度指针，传入时为缓存buffer的长度，供内部判断buffer大小是否足够，足够时内部把返回的数据拷贝至buffer，并赋值该值为数据长度]
 * @return        int           [成功或失败]
 */
static int vesync_https_receive_respond(char *https_buffer, char *recv_buf, int *recv_len, HTTPS_GET_MODE_E mode)
{
    int ret;
    bool is_first_pkt = true;   // 第1个http response需要去掉头部
    int rd_len = 0;
    const int in_recv_len = *recv_len;
    int ctx_len = 0;    // https头部内容长度
    uint8_t s_receive_state = 0;

    UNUSED(mode);
    *recv_len = 0;    // 接收累计长度，最终为总数据长度
    // 接收
    HTTPS_LOG(LOG_INFO, "Reading HTTPS response...\n");
    do
    {
        memset(https_buffer, 0, HTTPS_BUFFER_SIZE);
        ret = mbedtls_ssl_read(&s_ssl_context, (unsigned char *)https_buffer, HTTPS_BUFFER_SIZE - 1);

        if (ret == MBEDTLS_ERR_SSL_WANT_READ || ret == MBEDTLS_ERR_SSL_WANT_WRITE)
        {
            continue;
        }

        if (ret == MBEDTLS_ERR_SSL_PEER_CLOSE_NOTIFY)
        {
            ret = 0;
            HTTPS_LOG(LOG_DEBUG, "MBEDTLS_ERR_SSL_PEER_CLOSE_NOTIFY.\n");
            s_is_keep_alive = false;
            return VERR_FAIL;
        }

        if (ret < 0)
        {
            HTTPS_LOG(LOG_ERROR, "mbedtls_ssl_read returned -0x%x\n", -ret);
            s_is_keep_alive = false;
            return VERR_FAIL;
        }

        if (ret == 0)
        {
            HTTPS_LOG(LOG_INFO, "connection closed\n");
            s_is_keep_alive = false;
            return VERR_FAIL;
        }

        // 保存接收到的内容
        rd_len = ret;
        HTTPS_LOG(LOG_DEBUG, "%d bytes read.\n", rd_len);

        HTTPS_LOG(LOG_DEBUG, "https_receive : %s \n", https_buffer);

        if (is_first_pkt)
        {
            if (VERR_OK == vesync_https_parse_head(https_buffer, &rd_len, &ctx_len))
            {
                HTTPS_LOG(LOG_INFO, "https parse head success, total %d\n", ctx_len);
            }
        }

        if ((rd_len + *recv_len) < in_recv_len)
        {
            memcpy(&recv_buf[*recv_len], https_buffer, rd_len);
            *recv_len += rd_len;
            recv_buf[*recv_len] = '\0';
        }
        else
        {
            HTTPS_LOG(LOG_ERROR, "Recv buffer length is too short!\n");
            *recv_len = -1;
            recv_buf[0] = '\0';
            return VERR_FAIL;
        }

        s_receive_state++;  //1 head , 2 data
        if (s_receive_state >= 2)
        {
            s_is_keep_alive = s_keep_alive_enable;
        }

        if (ctx_len == *recv_len)      //如果接受文件长度达到,则断开连接
        {
            HTTPS_LOG(LOG_INFO, "https receive respond finish\n");
            return VERR_OK;
        }
    } while(1);

    return VERR_FAIL;
}

/**
 * @brief         https客户端初始化
 * @param[in]     config        [初始化配置，详见vesync_https_client_config_t]
 * @return        int           [成功或失败]
 */
int vesync_https_client_init(vesync_https_client_config_t *config)
{
    HTTPS_UTIL_MEM_CHECK(config, return VERR_FAIL);

    memset(s_https_host, 0, sizeof(s_https_host));
    memset(s_https_path, 0, sizeof(s_https_path));
    s_https_port = HTTPS_DEFAULT_PORT;

    if (config->url)
    {
        vesync_https_parse_url(config->url);
    }
    else
    {
        HTTPS_UTIL_MEM_CHECK(config->host, return VERR_FAIL);

        if (strlen(config->host) >= HTTPS_HOST_LEN)
        {
            HTTPS_LOG(LOG_WARN, "https host is too long\r\n");
            return VERR_FAIL;
        }
        else
        {
            snprintf(s_https_host, sizeof(s_https_host), "%s", config->host);
        }

        if (strlen(config->path) >= HTTPS_PATH_LEN)
        {
            HTTPS_LOG(LOG_WARN, "https path is too long\r\n");
            return VERR_FAIL;
        }
        else
        {
            snprintf(s_https_path, sizeof(s_https_path), "%s", config->path);
        }

        if (config->port)
        {
            s_https_port = config->port;
        }
    }

    s_keep_alive_enable = config->keep_alive;

    VESYNC_PRINTF_FREE_HEAP();

    if (s_is_keep_alive)
    {
        return VERR_OK;
    }

    return vesync_mbedtls_module_init(config);
}

/**
 * @brief         https request
 * @param[in]     method        [请求的方法]
 * @param[in]     send_buf      [请求的数据内容]
 * @param[out]    recv_buf      [返回的数据内容缓存buffer]
 * @param[in/out] recv_len      [返回的数据内容长度指针，传入时为缓存buffer的长度，供内部判断buffer大小是否足够，足够时内部把返回的数据拷贝至buffer，并赋值该值为数据长度]
 * @param[in]     mode          [https工作模式，目前只支持常规模式，即数据一次性放入内存]
 * @return        int           [成功或失败]
 */
int vesync_https_request(HTTPS_METHOD_TYPE_E method, char *send_buf, char *recv_buf, int *recv_len, HTTPS_GET_MODE_E mode)
{
    int ret = -1;
    char *https_buffer = NULL;

    HTTPS_UTIL_MEM_CHECK(send_buf, return VERR_FAIL);
    HTTPS_UTIL_MEM_CHECK(recv_buf, return VERR_FAIL);
    HTTPS_UTIL_MEM_CHECK(recv_len, return VERR_FAIL);
    UNUSED(mode);

    if (HTTPS_METHOD_GET != method && HTTPS_METHOD_POST != method)
    {
        HTTPS_LOG(LOG_ERROR, "Unknow https method type(%d)!\n", method);
        return VERR_FAIL;
    }

    // 判断Wi-Fi网络是否连接成功
    HTTPS_LOG(LOG_INFO, "Waiting for network connected...\n");
    if (!vhal_wifi_get_link_status(HTTPS_WAIT_TIME_MS))
    {
        HTTPS_LOG(LOG_ERROR, "Network was disconnect!\n");
        return VERR_FAIL;
    }
    HTTPS_LOG(LOG_INFO, "Network connected.\n");

    https_buffer = vesync_malloc(HTTPS_BUFFER_SIZE);
    HTTPS_UTIL_MEM_CHECK(https_buffer, return VERR_FAIL);

    if (VERR_OK != vesync_https_send_request(method, https_buffer, send_buf))
    {
        goto exit;
    }

    ret = vesync_https_receive_respond(https_buffer, recv_buf, recv_len, mode);

    HTTPS_LOG(LOG_DEBUG, "recv %d bytes read; \n\nrecv_buf:\n %s \n", *recv_len, recv_buf);

    HTTPS_LOG(LOG_DEBUG, "https receive succeed ! \n");

    if (s_is_keep_alive)
    {
        goto keepalive;
    }
    // 通知服务器关闭
    mbedtls_ssl_close_notify(&s_ssl_context);

exit:
    s_is_keep_alive = false;
    mbedtls_ssl_session_reset(&s_ssl_context);

    vesync_mbedtls_module_destroy();

keepalive:

    HTTPS_UTIL_SAFE_FREE(https_buffer);
    if (ret != VERR_OK)
    {
        return VERR_FAIL;
    }

    return VERR_OK;
}

/**
 * @brief         https通知服务器关闭，并释放空间
 */
void vesync_https_finish_and_destroy(void)
{
    if (s_is_keep_alive)
    {
        // 通知服务器关闭
        mbedtls_ssl_close_notify(&s_ssl_context);
        mbedtls_ssl_session_reset(&s_ssl_context);
        vesync_mbedtls_module_destroy();
        s_is_keep_alive = false;
    }
}

