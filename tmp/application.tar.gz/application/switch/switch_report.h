/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        switch_report.h
 * @brief       switch上报头文件
 * @author      Charles.Mei
 * @date        2021-08-03
 */


#ifndef __SWITCH_REPORT_H__
#define __SWITCH_REPORT_H__


#include <stdint.h>

#include "vesync_schedule.h"

#include "switch_app.h"


#ifdef __cplusplus
     extern "C" {
#endif


/**
 * @brief 设备状态变化，通知云端
 * @param[in]  status            [开关状态]
 * @return     int               [成功/失败]
 */
int switch_report_status_change(const switch_status_t* status);

/**
 * @brief timer执行结果上报(http://34.194.32.46:8080/doc/BVH3a8uib)， deviceLogReport
 * @param[in]  dev_id           [设备id]
 * @param[in]  action           [动作]
 * @param[in]  ret              [timer执行结果]
 * @param[in]  p_err_msg        [开timer执行失败原因]
 * @return     int              [成功/失败]
 */
int switch_report_timing_exec(DEVICE_ID_E dev_id, void *action, uint8_t ret, char *p_err_msg);

/**
 * @brief schedule执行结果上报(http://34.194.32.46:8080/doc/BVH3a8uib)， deviceLogReport
 * @param[in]  dev_id           [设备id]
 * @param[in]  sch_cfg          [schedule配置]
 * @param[in]  action           [动作]
 * @param[in]  ret              [schedule执行结果]
 * @param[in]  p_err_msg        [schedule执行失败原因]
 * @return     int              [成功/失败]
 */
int switch_report_schedule_exec(DEVICE_ID_E dev_id, vesync_schedule_t *sch_cfg, void *action, uint8_t ret, char *p_err_msg);


#ifdef __cplusplus
}
#endif

#endif

