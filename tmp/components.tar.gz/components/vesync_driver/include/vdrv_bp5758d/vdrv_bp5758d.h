/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
 * @file        vdrv_bp5758d.h
 * @brief       bp5758d驱动接口
 * @date        2021-09-14
 */

#ifndef __VDRV_BP5758D_H__
#define __VDRV_BP5758D_H__

#include <stdint.h>


#ifdef __cplusplus
extern "C"
{
#endif

#define BP5758D_MAX_OUT_NUM         5       // BP5758D最大输出路数

/**
 * @brief  bp5758d 电流量程数据结构体
 */
typedef struct
{
    uint8_t out_num;
    uint8_t outs[BP5758D_MAX_OUT_NUM];      // 第i路输出
    uint8_t data[BP5758D_MAX_OUT_NUM];      // 输出的电流量程
} bp5758d_range_t;

/**
 * @brief  bp5758d 灰度数据结构体
 */
typedef struct
{
    uint8_t out_num;
    uint8_t outs[BP5758D_MAX_OUT_NUM];      // 第i路输出
    uint16_t data[BP5758D_MAX_OUT_NUM];     // 输出的灰度数据
} bp5758d_gray_t;

/**
 * @brief 初始化调光控制芯片
 * @param[in] sda_io        [sda输入引脚]
 * @param[in] scl_io        [scl输入引脚]
 * @return int              [成功：SDK_OK，失败：SDK_FAIL]
 */
int vdrv_bp5758d_init(uint8_t sda_io, uint8_t scl_io);

/**
 * @brief 关断输出
 * @return int              [成功：SDK_OK，失败：SDK_FAIL]
 */
int vdrv_bp5758d_out_disable(void);

/**
 * @brief 设置睡眠模式
 * @return int              [成功：SDK_OK，失败：SDK_FAIL]
 */
int vdrv_bp5758d_sleep_mode_set(void);

/**
 * @brief 配置电流量程
 * @param[in]  p_range          [设置的电流量程命令结构体指针]
 * @return int                  [成功:SDK_OK，失败：SDK_FAIL]
 */
int vdrv_bp5758d_range_cfg(bp5758d_range_t *p_range);

/**
 * @brief 配置灰度
 * @param[in]  p_gray           [设置的灰度命令结构体指针]
 * @return int                  [成功:SDK_OK，失败：SDK_FAIL]
 */
int vdrv_bp5758d_gray_cfg(bp5758d_gray_t *p_gray);

/**
 * @brief 写入配置
 * @return int                  [成功:SDK_OK，失败：SDK_FAIL]
 */
int vdrv_bp5758d_cfg_write(void);


#ifdef __cplusplus
}
#endif

#endif
