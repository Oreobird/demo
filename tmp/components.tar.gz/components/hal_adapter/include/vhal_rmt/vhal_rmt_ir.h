/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file    vhal_rmt_ir.h
* @brief   红外控制接口
* @author  Lind
* @date     2021-11-18
*/

#ifndef __VHAL_RMT_IR_H__
#define __VHAL_RMT_IR_H__

#include <stdbool.h>

#include "vhal_rmt.h"

#ifdef __cplusplus
extern "C"
{
#endif

#define RMT_IR_TASK_NAME                "ir_task"                   // 红外控制任务，只有在接收初始化后才会建立
#define RMT_IR_TASK_STACK_SIZE          (1024 * 2)
#define RMT_IR_TASK_PRIO                TASK_PRIORITY_ABOVE_NORMAL
#define RMT_IR_TASK_PERIOD_MS           (50)                    // 红外控制任务周期

/**
* @brief 红外控制协议
*/
typedef enum
{
    IR_PROTOCOL_NEC = 0,
    IR_PROTOCOL_RC5,
    IR_PROTOCOL_MAX
} IR_PROTOCOL_E;

/**
* @brief 红外接收回调函数
*/
typedef void (*ir_rx_cb_t)(uint32_t addr, uint32_t cmd, bool repeat_flag);

/**
* @brief 红外控制数据发送
* @param[in]  addr          [用户地址数据]
* @param[in]  cmd           [键值数据]
* @param[in]  repeat_flag   [是否重复数据]
* @return  int              [VHAL_OK/VHAL_FAIL]
*/
int vhal_rmt_ir_send(uint32_t addr, uint32_t cmd, bool repeat_flag);

/**
* @brief 注册红外接收回调函数
* @param[in]  cb        [回调函数]
*/
void vhal_rmt_ir_reg_rx_cb(ir_rx_cb_t cb);

/**
* @brief 红外发送初始化
* @param[in]  ir_channel      [通道]
* @param[in]  gpio_num        [IO]
* @param[in]  ir_protocol     [红外协议]
* @param[in]  EXT_PROTO_FLAG  [是否允许扩展（非标准）协议]
* @return  int                [VHAL_OK/VHAL_FAIL]
*/
int vhal_rmt_ir_tx_init(RMT_CH_E ir_channel, uint16_t gpio_num, IR_PROTOCOL_E ir_protocol, bool EXT_PROTO_FLAG);

/**
* @brief 红外接收初始化
* @param[in]  ir_channel      [通道]
* @param[in]  gpio_num        [IO]
* @param[in]  ir_protocol     [红外协议]
* @param[in]  rx_buf_size     [底层接收buffer，建议1k]
* @param[in]  EXT_PROTO_FLAG  [是否允许扩展（非标准）协议]
* @return  int                [VHAL_OK/VHAL_FAIL]
*/
int vhal_rmt_ir_rx_init(RMT_CH_E ir_channel, uint16_t gpio_num, IR_PROTOCOL_E ir_protocol, uint32_t rx_buf_size, bool EXT_PROTO_FLAG);

/**
* @brief 关闭红外发送
* @param[in]  ir_channel    [通道]
*/
void vhal_rmt_ir_tx_deinit(RMT_CH_E ir_channel);

/**
* @brief 关闭红外接收
* @param[in]  ir_channel    [通道]
*/
void vhal_rmt_ir_rx_deinit(RMT_CH_E ir_channel);


#ifdef __cplusplus
}
#endif

#endif /* __VHAL_RMT_IR_H__ */


