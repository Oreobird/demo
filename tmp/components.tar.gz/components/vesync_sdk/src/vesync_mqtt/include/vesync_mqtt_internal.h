/*
 * Copyright © Vesync Technologies Co.Ltd. 2019-2021. All rights reserved.
 *
 * This file is subject to the terms and conditions defined in
 * file 'LICENSE', which is part of this source code package.
 * Tuan PM <tuanpm at live dot com>
 */


#ifndef __VESYNC_MQTT_INTERNAL_H__
#define __VESYNC_MQTT_INTERNAL_H__


#include <stdint.h>
#include <stdbool.h>
#include <string.h>

#include "vesync_mqtt_config.h"


#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief MQTT QoS
 */
typedef enum
{
    MQTT_QOS0 = 0,
    MQTT_QOS1 = 1,
    MQTT_QOS2 = 2
} MQTT_QOS_E;

/**
 * @brief MQTT event types.
 *
 * User event handler receives context data in `vesync_mqtt_event_t` structure with
 *  - `client` - mqtt client handle
 *  - various other data depending on event type
 *
 */
typedef enum {
    MQTT_EVENT_ERROR = 0,
    MQTT_EVENT_CONNECTED,          /*!< connected event, additional context: session_present flag */
    MQTT_EVENT_DISCONNECTED,       /*!< disconnected event */
    MQTT_EVENT_SUBSCRIBED,         /*!< subscribed event, additional context: msg_id */
    MQTT_EVENT_UNSUBSCRIBED,       /*!< unsubscribed event */
    MQTT_EVENT_PUBLISHED,          /*!< published event, additional context:  msg_id */
    MQTT_EVENT_DATA,               /*!< data event, additional context:
                                        - msg_id               message id
                                        - topic                pointer to the received topic
                                        - topic_len            length of the topic
                                        - data                 pointer to the received data
                                        - data_len             length of the data for this event
                                        - current_data_offset  offset of the current data for this event
                                        - total_data_len       total length of the data received
                                         */
    MQTT_EVENT_DNS_RESOLVED,
    MQTT_EVENT_DNS_RESOLVE_FAILED,
} VESYNC_MQTT_EVENT_ID_E;


/**
 * @brief MQTT event configuration structure
 */
typedef struct {
    VESYNC_MQTT_EVENT_ID_E event_id;    /*!< MQTT event type */
    char *data;                         /*!< Data associated with this event */
    int data_len;                       /*!< Length of the data for this event */
    char *topic;                        /*!< Topic associated with this event */
    int topic_len;                      /*!< Length of the topic for this event associated with this event */
    int msg_id;                         /*!< MQTT messaged id of message */
    int session_present;                /*!< MQTT session_present flag for connection event */
} vesync_mqtt_event_t;

typedef vesync_mqtt_event_t* vesync_mqtt_event_handle_t;

typedef int (* mqtt_event_callback_t)(vesync_mqtt_event_handle_t event);

/**
 * @brief TLS证书选项
 */
typedef enum
{
    MQTT_TLS_DSIABLE      = 0,  // 关闭tls
    MQTT_TLS_CA_NONE      = 1,  // 不校验CA证书
    MQTT_TLS_CA_SERVER    = 2,  // 校验MQTT服务器CA证书
    MQTT_TLS_CA_PRODUTION = 3,  // 校验产测服务器CA证书
} MQTT_TLS_CA_E;


/**
 * @brief       mqtt task init
 * @return      int                  [success or fail]
 */
int vesync_mqtt_init(void);

int vesync_mqtt_config(char *client_id, mqtt_event_callback_t event_cb);

/**
 * @brief       set mqtt connect param and connect auto
 * @param[in]   host                 [mqtt server host name]
 * @param[in]   ip                   [mqtt server ip]
 * @param[in]   port                 [mqtt server port]
 * @param[in]   username             [username]
 * @param[in]   password             [password]
 * @param[in]   event_cb             [event callback]
 * @param[in]   tls                  [tls type]
 * @return      int                  [success or fail]
 */
int vesync_mqtt_connect(char *host, char *ip, uint16_t port, 
                        char *username, char *password,
                        int tls);

/**
 * @brief       disconnect mqtt connection
 * @return      int                  [success or fail]
 */
int vesync_mqtt_disconnect(void);

/**
 * @brief       Client to send a publish message to the broker
 * @param[in]   topic                       [topic string]
 * @param[in]   data                        [payload string (set to NULL, sending empty payload message)]
 * @param[in]   len                         [data length, if set to 0, length is calculated from payload string]
 * @param[in]   qos                         [qos of publish message]
 * @param[in]   retain                      [retain flag]
 * @return      int                         [message_id of the publish message(for QoS 0 message_id will always be zero) on success; -1 on failure]
 * @Notes:
 *              - Client doesn't have to be connected to send publish message
 *              (although it would drop all qos=0 messages, qos>1 messages would be enqueued)
 *              - It is thread safe, please refer to `vesync_mqtt_client_subscribe` for details
 */
int vesync_mqtt_publish(const char *topic, const char *data, int len, int qos, int retain, void(*ack_cb)(void));


int vesync_mqtt_subscribe(const char *topic, int qos, void(*ack_cb)(void));


#ifdef __cplusplus
}
#endif


#endif /* __VESYNC_MQTT_INTERNAL_H__ */
