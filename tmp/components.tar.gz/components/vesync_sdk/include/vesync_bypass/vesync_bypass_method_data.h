/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file       vesync_bypass_method_data.h
* @brief      vesync device config information.
* @date       2022-03-03
* @note       File auto generated, DO NOT edit.
*/

#ifndef __VESYNC_METHOD_DATA_H__
#define __VESYNC_METHOD_DATA_H__

#ifdef __cplusplus
extern "C" {
#endif

/**
* @brief bypass method id 定义
*/
typedef enum
{
    BYPASS_METHOD_ID_UPD_TIMEBASE_INFO,     // 更新时基信息
    BYPASS_METHOD_ID_GET_TIMEBASE_INFO,     // 查询时基信息
    BYPASS_METHOD_ID_SET_TIMEBASE_UPD,      // 设置时基信息自动更新
    BYPASS_METHOD_ID_UP_FIRMWARE,           // 固件升级
    BYPASS_METHOD_ID_RESET_DEVICE,          // 重置设备
    BYPASS_METHOD_ID_GET_DEV_INFO,          // 获取设备信息(非设备状态)
    BYPASS_METHOD_ID_GET_WORKING_STATE,     // 获取设备工作状态
    BYPASS_METHOD_ID_SET_CID,               // 设置CID
    BYPASS_METHOD_ID_SET_COMPLETE,          // 设置产测结束标志位
    BYPASS_METHOD_ID_SET_DEVELOPER,         // 开发者模式
    BYPASS_METHOD_ID_SET_LOG_LEVEL,         // 设置日志级别
    BYPASS_METHOD_ID_SET_TS,                // 设置设备时间(UTC时间)
    BYPASS_METHOD_ID_DEBUG_CMD,             // 测试命令
    BYPASS_METHOD_ID_SET_MAC,               // 设置设备MAC地址
    BYPASS_METHOD_ID_MAX
} BYPASS_METHOD_ID_E;

/**
 * @brief 工作状态枚举类型
 */
typedef enum
{
    BP_DEVICE_STANDBY = 0,      //待机状态
    BP_DEVICE_WORKING = 1       //工作状态
} BP_DEVICE_STATUS_E;

#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_METHOD_DATA_H__ */
