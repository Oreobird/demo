/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_ffs_usre_context.c
 * @brief       ffs SDK用户上下文声明及相关处理
 * @author      Dongri.Su
 * @date        20120-02-28
 */

// 头文件
#include <stdlib.h>
#include "mbedtls/x509_crt.h"
#include "mbedtls/x509_csr.h"
#include "ffs/common/ffs_result.h"
#include "ffs/common/ffs_stream.h"
#include "ffs/common/ffs_wifi.h"
#include "ffs/common/ffs_check_result.h"
#include "ffs/common/ffs_log_level.h"
#include "vesync_ffs_user_context.h"
#include "ffs_rtos_configuration_map.h"
#include "ffs_wifi_context.h"
#include "ffs_wifi_connection_attempt_list.h"
#include "ffs_wifi_configuration_list.h"
#include "ffs_pem_file.h"
#include "vesync_ffs_crypto.h"

#include "ffs_flash.h"

#include "vesync_common.h"
#include "vesync_memory.h"
#include "vesync_log_internal.h"


//#define ENTRY_MAP_SIZE               16
//#define MAXIMUM_SSID_SIZE            32
#define MAXIMUM_KEY_SIZE 64

//char FFS_CONFIGURATION_ENTRY_DSS[] =                   "192.168.0.105";
//#define  FFS_CONFIGURATION_ENTRY_DSS_PORT               443

/**
 * @brief: Initialize a Ffs Wi-Fi context.
 * @param FfsWifiContext_t*
 * @return FFS_RESULT
 */
FFS_RESULT ffsInitializeWifiContext(FfsWifiContext_t *wifiContext)
{
    if (!wifiContext)
    {
        ffsLogError("input params find NULL");
        FFS_FAIL(FFS_OVERRUN);
    }

    wifiContext->state = FFS_WIFI_CONNECTION_STATE_DISCONNECTED;
    FFS_CHECK_RESULT(ffsLinkedListInitialize(&wifiContext->connectionAttemptList));
    FFS_CHECK_RESULT(ffsLinkedListInitialize(&wifiContext->connectionAttemptList));

    return FFS_SUCCESS;
}

/**
 * @brief: einitialize a Ffs Wi-Fi context.
 * @param FfsWifiContext_t*
 * @return FFS_RESULT
 */
FFS_RESULT ffsDeinitializeWifiContext(FfsWifiContext_t *wifiContext)
{
    if (!wifiContext)
    {
        ffsLogError("input params find NULL");
        FFS_FAIL(FFS_OVERRUN);
    }

    // Deinitialize the linked lists.
    wifiContext->state = FFS_WIFI_CONNECTION_STATE_IDLE;
    FFS_CHECK_RESULT(ffsWifiConnectionAttemptListClear(wifiContext));
    FFS_CHECK_RESULT(ffsWifiConfigurationListClear(wifiContext));
    return FFS_SUCCESS;
}

/**
 * @brief: Initialize a Ffs Wi-Fi context.
 * @param FfsRegistrationRequest_t*
 * @return FFS_RESULT
 */
FFS_RESULT ffsInitializeRegistrationRequest(FfsRegistrationRequest_t *registrationRequest)
{
    if (!registrationRequest)
    {
        ffsLogError("input params find NULL");
        FFS_FAIL(FFS_OVERRUN);
    }

    FFS_CHECK_RESULT(ffsInitializeEntryStream(&registrationRequest->tokenStream, NULL, MAXIMUM_KEY_SIZE));
    registrationRequest->expiration = 0;

    return FFS_SUCCESS;
}

/**
 * @brief: IDeinitialize a Ffs Wi-Fi context.
 * @param FfsRegistrationRequest_t*
 * @return FFS_RESULT
 */
FFS_RESULT ffsDeitializeRegistrationRequest(FfsRegistrationRequest_t *registrationRequest)
{
    if (!registrationRequest)
    {
        ffsLogError("input params find NULL");
        FFS_FAIL(FFS_OVERRUN);
    }

    // Deinitialize the linked lists.
    FFS_CHECK_RESULT(ffsDeinitializeEntryStream(&registrationRequest->tokenStream));
    return FFS_SUCCESS;
}

/**
 * @brief   通过http获取client CA证书 测试用例
 *
 * 示例：url = "http://192.168.15.106:8888/firmware-debug/test/dss/certificate.pem"; mode = HTTP_GET_CLI_CA;
 *
 * @param[in]      char *u
 * @param[in]      HTTP_GET_MODE_E mode
 * @return         int: SDK_OK 获取成功        SDK_FAIL获取失败
 */
int vesync_ffs_get_generate_ca_files_api(char *url, HTTP_GET_MODE_E mode)
{
    if (!url)
    {
        return SDK_FAIL;
    }

    int read_len = 0;
    vesync_http_client_config_t http_cfg;
    http_cfg.url = url;

    vesync_http_client_init(&http_cfg);

    int ret = vesync_http_request(HTTP_METHOD_GET, "send_buf", NULL, &read_len, mode);
    if (ret == SDK_OK)
    {
        SDK_LOG(LOG_INFO, "\nrecv_buf len %d \n", read_len);
    }

    return ret;
}

/**
 * @brief read files and get string's pointer.
 * @param FFS_KEY_TYPE_E type
 * @return  const char*
 */
const char *getCertKeyString(FfsUserContext_t *userContext, FFS_KEY_TYPE_E type)
{
#if (FFS_CA_DEBUG == 0)
    if (!userContext)
    {
        return NULL;
    }
#endif
    switch (type)
    {
    case FFS_KEY_CLIENT_PUBLIC:
#if (FFS_CA_DEBUG == 0)
        return (const char *)userContext->client_pem;
#else
        return client_cert;
#endif
        break;

    case FFS_KEY_CLOUD_PUBLIC:
        return cloud_public_cert;
        break;

    case FFS_KEY_PRIVATE:
#if (FFS_CA_DEBUG == 0)
        return (const char *)userContext->private_pem;
#else
        return private_cert;
#endif

        break;

    case FFS_KEY_CA_KEY:
        return ca_cert;
        break;

    default:
        break;
    }
    return NULL;
}

/**
 * @brief Extracts device private key from a file containing the device certificate or certificate chain.
 * @param FfsWifiContext_t*
 * @return FFS_RESULT
 */
static FFS_RESULT ffsInitializeDevicePrivateKey(struct FfsUserContext_s *userContext)
{
    if (!userContext)
    {
        ffsLogError("input params find NULL");
        FFS_FAIL(FFS_OVERRUN);
    }
#if (FFS_CA_DEBUG == 0)
    int read_len = 0;
    char *ca_buff = NULL;
    userContext->private_pem = NULL;

    if (vesync_ffs_flash_read_dha_private_key(NULL, &read_len) == SDK_OK)
    {
        SDK_LOG(LOG_DEBUG, "\n read private key len %d \n", read_len);
        if (read_len)
        {
            ca_buff = (char *)vesync_malloc(read_len + 1);
        }
        if (!ca_buff)
        {
            SDK_LOG(LOG_ERROR, "\n malloc failed\n");
            FFS_FAIL(FFS_ERROR);
        }
    }
    else
    {
        FFS_FAIL(FFS_ERROR);
    }

    userContext->private_pem = ca_buff;
    if (vesync_ffs_flash_read_dha_private_key(userContext->private_pem, &read_len) == SDK_OK)
    {
        //userContext->client_pem[read_len] = '\0';
    }
    else
    {
        SDK_LOG(LOG_ERROR, "\n read private key failed\n");
        FFS_FAIL(FFS_ERROR);
    }
#endif
    parsePrivateKeyToHex(&userContext->devicePrivateKey, getCertKeyString(userContext, FFS_KEY_PRIVATE));
    if (!userContext->devicePrivateKey.buf)
    {
        FFS_CHECK_RESULT(ffsDeinitializeUserContext(userContext));
        FFS_FAIL(FFS_ERROR);
    }
    return FFS_SUCCESS;
}

/**
 * @brief Extracts device public key from a file containing the device certificate or certificate chain.
 * @param FfsWifiContext_t*
 * @return FFS_RESULT
 */
static FFS_RESULT ffsInitializeDevicePublicKey(struct FfsUserContext_s *userContext)
{
    if (!userContext)
    {
        ffsLogError("input params find NULL");
        FFS_FAIL(FFS_OVERRUN);
    }
    // Try to open the certificate chain file.
#if (FFS_CA_DEBUG == 0)
    int read_len = 0;
    char *ca_buff = NULL;
    userContext->client_pem = NULL;

    if (vesync_ffs_flash_read_cert_chain(NULL, &read_len) == SDK_OK)
    {
        SDK_LOG(LOG_DEBUG, "\n read_cert_chain len %d \n", read_len);
        if (read_len)
        {
            ca_buff = (char *)vesync_malloc(read_len + 1);
        }
        if (!ca_buff)
        {
            SDK_LOG(LOG_ERROR, "\n malloc failed\n");
            FFS_FAIL(FFS_ERROR);
        }
    }
    else
    {
        FFS_FAIL(FFS_ERROR);
    }

    userContext->client_pem = ca_buff;
    if (vesync_ffs_flash_read_cert_chain(userContext->client_pem, &read_len) == SDK_OK)
    {
        //userContext->client_pem[read_len] = '\0';
    }
    else
    {
        SDK_LOG(LOG_ERROR, "\n read_cert_chain failed\n");
        FFS_FAIL(FFS_ERROR);
    }
#endif

    parsePublicKeyToHex(&userContext->devicePublicKey, getCertKeyString(userContext, FFS_KEY_CLIENT_PUBLIC));
    if (!userContext->devicePublicKey.buf)
    {
        FFS_CHECK_RESULT(ffsDeinitializeUserContext(userContext));
        FFS_FAIL(FFS_ERROR);
    }

    //兼容PI，需准备多余的字符串
    parsePublicKeyExtToHex(&userContext->devicePublicKeyExt, getCertKeyString(userContext, FFS_KEY_CLIENT_PUBLIC));
    if (!userContext->devicePublicKeyExt.buf)
    {
        FFS_CHECK_RESULT(ffsDeinitializeUserContext(userContext));
        FFS_FAIL(FFS_ERROR);
    }
    return FFS_SUCCESS;
}

/**
 * @brief Read the public key into user context. If the passed path is NULL,
 * we will use the default public key path.
 * @param FfsWifiContext_t*
 * @return FFS_RESULT
 */
FFS_RESULT ffsInitializeCloudPublicKey(struct FfsUserContext_s *userContext)
{
    if (!userContext)
    {
        ffsLogError("input params find NULL");
        FFS_FAIL(FFS_OVERRUN);
    }
    parseCloudPublicKeyToHex(&userContext->cloudPublicKey, getCertKeyString(userContext, FFS_KEY_CLOUD_PUBLIC));
    //Success?
    if (!userContext->cloudPublicKey.buf)
    {
        FFS_CHECK_RESULT(ffsDeinitializeUserContext(userContext));
        FFS_FAIL(FFS_ERROR);
    }

    return FFS_SUCCESS;
}

/**
 * @brief:Initialize the ffs DeviceKey.
 * @param FfsUserContext_t*
 * @return FFS_RESULT
 */
FFS_RESULT ffsInitializeDeviceKey(FfsUserContext_t *userContext)
{
    if (!userContext)
    {
        ffsLogError("input params find NULL");
        FFS_FAIL(FFS_OVERRUN);
    }
    userContext->cloudPublicKey.buf = NULL;
    userContext->cloudPublicKey.len = 0;
    userContext->devicePrivateKey.buf = NULL;
    userContext->devicePrivateKey.len = 0;
    userContext->devicePublicKey.buf = NULL;
    userContext->devicePublicKey.len = 0;
    userContext->devicePublicKeyExt.buf = NULL;
    userContext->devicePublicKeyExt.len = 0;
    return FFS_SUCCESS;
}

/**
 * @brief: DeInitialize the ffs DeviceKey.
 * @param FfsWifiContext_t*
 * @return FFS_RESULT
 */
FFS_RESULT ffsDeitializeDeviceKey(FfsUserContext_t *userContext)
{
    if (!userContext)
    {
        ffsLogError("input params find NULL");
        FFS_FAIL(FFS_OVERRUN);
    }
    VCOM_SAFE_FREE(userContext->cloudPublicKey.buf);
    userContext->cloudPublicKey.len = 0;

    VCOM_SAFE_FREE(userContext->devicePrivateKey.buf);
    userContext->devicePrivateKey.len = 0;

    VCOM_SAFE_FREE(userContext->devicePublicKey.buf);
    userContext->devicePublicKey.len = 0;

    VCOM_SAFE_FREE(userContext->devicePublicKeyExt.buf);
    userContext->devicePublicKeyExt.len = 0;

    return FFS_SUCCESS;
}

/**
 * @brief  Initialize the Ffs Wi-Fi freeRTOS user context.
 * @param[out] FfsUserContext_t*    [用户上下文定义]
 * @return     FFS_RESULT          [成功/失败]
 */
FFS_RESULT ffsInitializeUserContext(FfsUserContext_t *userContext)
{
    if (!userContext)
    {
        ffsLogError("input params find NULL");
        FFS_FAIL(FFS_OVERRUN);
    }
    // Initialize the configuration map.
    if (ffsInitializeConfigurationMap(&userContext->configMap))
    {
        FFS_CHECK_RESULT(ffsDeinitializeUserContext(userContext));
        FFS_FAIL(FFS_ERROR);
    }
    // Initialize the configuration map.
    if (ffsInitializeWifiContext(&userContext->wifiContext))
    {
        FFS_CHECK_RESULT(ffsDeinitializeUserContext(userContext));
        FFS_FAIL(FFS_ERROR);
    }

    // Initialize the registration request.
    if (ffsInitializeRegistrationRequest(&userContext->registrationRequest))
    {
        FFS_CHECK_RESULT(ffsDeinitializeUserContext(userContext));
        FFS_FAIL(FFS_ERROR);
    }

    userContext->cancel = false;
    userContext->CanPostWifiScanData = false;
    userContext->CanGetWifiCredentials = false;

    // Default to no custom setup network SSID / PSK or DSS host.
    userContext->setupNetworkSsid = NULL;
    userContext->setupNetworkPsk = NULL;
    userContext->userNetworkSsid = NULL;
    userContext->userNetworkPsk = NULL;
    userContext->dssHost = NULL;
    // userContext->dssPort = FFS_CONFIGURATION_ENTRY_DSS_PORT;
    // userContext->hasDssPort = true;
    userContext->dssPort = 0;
    userContext->hasDssPort = false;
    userContext->provisioneeState = FFS_WIFI_PROVISIONEE_STATE_NOT_PROVISIONED;

    userContext->sessoinToken = NULL;
    userContext->lang = NULL;
    userContext->market = NULL;
    userContext->alexaEvtGwEp = NULL;
    userContext->utc = NULL;

    ffsInitializeDeviceKey(userContext);

    //init the private + public key
    //  TODO

    SDK_LOG(LOG_DEBUG, "ffsInitializeDeviceKeys!\n");

    FFS_CHECK_RESULT(ffsInitializeDevicePublicKey(userContext));
    FFS_CHECK_RESULT(ffsInitializeCloudPublicKey(userContext));
    FFS_CHECK_RESULT(ffsInitializeDevicePrivateKey(userContext));

    // Allocate DSS buffers.
    userContext->hostNameBuffer = (uint8_t *)vesync_malloc(sizeof(uint8_t) * DSS_HOST_NAME_BUFFER_SIZE);
    if (!userContext->hostNameBuffer)
    {
        FFS_CHECK_RESULT(ffsDeinitializeUserContext(userContext));
        FFS_FAIL(FFS_ERROR);
    }
    userContext->sessionIdBuffer = (uint8_t *)vesync_malloc(sizeof(uint8_t) * DSS_SESSION_ID_BUFFER_SIZE);
    if (!userContext->sessionIdBuffer)
    {
        FFS_CHECK_RESULT(ffsDeinitializeUserContext(userContext));
        FFS_FAIL(FFS_ERROR);
    }
    userContext->nonceBuffer = (uint8_t *)vesync_malloc(sizeof(uint8_t) * DSS_NONCE_BUFFER_SIZE);
    if (!userContext->nonceBuffer)
    {
        FFS_CHECK_RESULT(ffsDeinitializeUserContext(userContext));
        FFS_FAIL(FFS_ERROR);
    }
    userContext->bodyBuffer = (uint8_t *)vesync_malloc(sizeof(uint8_t) * DSS_BODY_BUFFER_SIZE);
    if (!userContext->bodyBuffer)
    {
        FFS_CHECK_RESULT(ffsDeinitializeUserContext(userContext));
        FFS_FAIL(FFS_ERROR);
    }

    SDK_LOG(LOG_DEBUG, "==ffsInitializeFinish!==\n");
    return FFS_SUCCESS;
}

/**
 * @brief  Deinitialize the Ffs Wi-Fi Linux user context.
 * @param[out] FfsUserContext_t    [用户上下文定义]
 * @return     FFS_RESULT          [成功/失败]
 */
FFS_RESULT ffsDeinitializeUserContext(FfsUserContext_t *userContext)
{
    if (!userContext)
    {
        ffsLogError("input params find NULL");
        FFS_FAIL(FFS_OVERRUN);
    }
    // Deinitialize the configuration map.
    if (ffsDeinitializeConfigurationMap(&userContext->configMap))
    {
        ffsLogWarning("Failed to deinitialize configuration map");
    }

    // Deinitialize the configuration map.
    if (ffsDeinitializeWifiContext(&userContext->wifiContext))
    {
        ffsLogWarning("Failed to deinitialize wifiConfig");
    }

    // Deinitialize the registration request.
    if (ffsDeitializeRegistrationRequest(&userContext->registrationRequest))
    {
        ffsLogWarning("Failed to deinitialize Registration Request");
    }
    // Free wifi ssid / key arguments.
    VCOM_SAFE_FREE(userContext->setupNetworkSsid);
    VCOM_SAFE_FREE(userContext->setupNetworkPsk);
    VCOM_SAFE_FREE(userContext->userNetworkSsid);
    VCOM_SAFE_FREE(userContext->userNetworkPsk);
    VCOM_SAFE_FREE(userContext->dssHost);

    VCOM_SAFE_FREE(userContext->sessoinToken);
    VCOM_SAFE_FREE(userContext->lang);
    VCOM_SAFE_FREE(userContext->market);
    VCOM_SAFE_FREE(userContext->alexaEvtGwEp);
    VCOM_SAFE_FREE(userContext->utc);

    // Free DSS buffers.
    VCOM_SAFE_FREE(userContext->hostNameBuffer);
    VCOM_SAFE_FREE(userContext->sessionIdBuffer);
    VCOM_SAFE_FREE(userContext->nonceBuffer);
    VCOM_SAFE_FREE(userContext->bodyBuffer);
#if (FFS_CA_DEBUG == 0)
    VCOM_SAFE_FREE(userContext->client_pem);
    VCOM_SAFE_FREE(userContext->private_pem);
#endif
    //Free the DHA structures
    ffsDeitializeDeviceKey(userContext);
    return FFS_SUCCESS;
}
