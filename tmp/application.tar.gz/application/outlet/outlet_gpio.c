/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file        outlet_gpio.c
* @brief       outlet gpio配置
* @author      Joshua
* @date        2021-06-18
*/


#include <string.h>
#include <stdlib.h>
#include <stdbool.h>

#include "vhal_gpio.h"

#include "vesync_common.h"
#include "vesync_log.h"
#include "vesync_production.h"
#include "outlet_flash.h"
#include "outlet_inching.h"
#include "outlet_gpio.h"
#include "outlet_board.h"
#if defined(OUTLET_ELEC_METERING) && (OUTLET_ELEC_METERING == 1)
#include "outlet_metering.h"
#endif


static bool s_switch_status = false;  // 开关状态，true为开启，false为关闭
static bool s_switch_protect_enable = false;   // 硬件保护，true为开启，禁止控制开关

static bool s_switch_indicator_enable = true;   // 指示灯所在IO口使能状态
static bool s_switch_indicator = false; // 指示灯状态，true为亮起，false为关闭


/**
 * @brief 初始化GPIO
 */
void outlet_init_gpio(void)
{
    // 初始化继电器输出控制信号相连的GPIO
    vhal_gpio_config_t relay_io;
    relay_io.pin_bit_mask = (1ULL << OUTLET_RELAY_GPIO_NUM);
    relay_io.mode = GPIO_MODE_OUT;
    relay_io.pull_up_en = GPIO_PULLUP_DIS;
    relay_io.pull_down_en = GPIO_PULLDOWN_DIS;
    relay_io.intr_type = GPIO_INTR_DIS;
    vhal_gpio_init(relay_io);
    vhal_gpio_set_output(OUTLET_RELAY_GPIO_NUM, VHAL_GPIO_DATA_LOW);

    // 初始化Wi-Fi灯的GPIO
    vhal_gpio_config_t wifi_led_io;
    wifi_led_io.pin_bit_mask = (1ULL << OUTLET_WIFI_GPIO_NUM);
    wifi_led_io.mode = GPIO_MODE_OUT;
    wifi_led_io.pull_up_en = GPIO_PULLUP_DIS;
    wifi_led_io.pull_down_en = GPIO_PULLDOWN_DIS;
    wifi_led_io.intr_type = GPIO_INTR_DIS;
    vhal_gpio_init(wifi_led_io);
    vhal_gpio_set_output(OUTLET_WIFI_GPIO_NUM, OUTLET_INDICATOR_GPIO_OFF);

    // 初始化继电器指示灯GPIO
#if (OUTLET_INDICATOR_GPIO_NUM != OUTLET_WIFI_GPIO_NUM)
    vhal_gpio_config_t indicator_io;
    indicator_io.pin_bit_mask = (1ULL << OUTLET_INDICATOR_GPIO_NUM);
    indicator_io.mode = GPIO_MODE_OUT;
    indicator_io.pull_up_en = GPIO_PULLUP_DIS;
    indicator_io.pull_down_en = GPIO_PULLDOWN_DIS;
    indicator_io.intr_type = GPIO_INTR_DIS;
    vhal_gpio_init(indicator_io);
    vhal_gpio_set_output(OUTLET_INDICATOR_GPIO_NUM, OUTLET_INDICATOR_GPIO_OFF);
#endif

    // 初始化触摸按键信号接入GPIO
    vhal_gpio_config_t button_io;
    button_io.pin_bit_mask = (1ULL << OUTLET_BUTTON_GPIO_NUM);
    button_io.mode = GPIO_MODE_IN;
    button_io.pull_up_en = GPIO_PULLUP_EN;
    button_io.pull_down_en = GPIO_PULLDOWN_DIS;
    button_io.intr_type = GPIO_INTR_DIS;
    vhal_gpio_init(button_io);
}

/**
 * @brief Wi-Fi灯开启/关闭
 * @param[in]   bool            [true时，指示灯开关；false时，指示灯关闭]
 */
void outlet_set_wifi_led_onoff(bool on)
{
    if (on)
    {
        vhal_gpio_set_output(OUTLET_WIFI_GPIO_NUM, OUTLET_INDICATOR_GPIO_ON);
    }
    else
    {
        vhal_gpio_set_output(OUTLET_WIFI_GPIO_NUM, OUTLET_INDICATOR_GPIO_OFF);
    }
}

/**
 * @brief 获取开关状态(开启/关闭)
 */
bool outlet_get_switch_onoff(void)
{
    return s_switch_status;
}

/**
 * @brief 开关翻转
 */
void outlet_set_switch_toggle()
{
    outlet_set_switch_onoff(!s_switch_status);
}

/**
 * @brief 指示灯开启/关闭
 * @param[in]   bool            [true时，指示灯开关；false时，指示灯关闭]
 */
static void outlet_set_indicator_onoff(bool on)
{
    s_switch_indicator = on;
    if (s_switch_indicator_enable)
    {
        if (s_switch_indicator)
        {
            vhal_gpio_set_output(OUTLET_INDICATOR_GPIO_NUM, OUTLET_INDICATOR_GPIO_ON);
        }
        else
        {
            vhal_gpio_set_output(OUTLET_INDICATOR_GPIO_NUM, OUTLET_INDICATOR_GPIO_OFF);
        }
    }
}

/**
 * @brief 开关开启/关闭
 * @param[in]   bool            [true时，开启开关；false时，关闭开关]
 */
void outlet_set_switch_onoff(bool on)
{
    uint8_t cur_switch_status = 0x0;

    if (s_switch_protect_enable)    // 硬件保护激活，禁用开关
    {
        return;
    }

    outlet_set_indicator_onoff(on);

    // 执行开关动作
    s_switch_status = on;
    if (on)
    {
        vhal_gpio_set_output(OUTLET_RELAY_GPIO_NUM, VHAL_GPIO_DATA_HIGH);
        cur_switch_status = 0x1;    // 开
    }
    else
    {
        vhal_gpio_set_output(OUTLET_RELAY_GPIO_NUM, VHAL_GPIO_DATA_LOW);
        cur_switch_status = 0x0;    // 关
    }

    if (PRODUCTION_EXIT == vesync_production_get_status() &&
        APP_OK != switch_update_config(SWITCH_CFG_ONOFF, &cur_switch_status))
    {
        APP_LOG(LOG_ERROR, "Switch update config fail.\n");
    }
}

/**
 * @brief 禁用开关
 */
void outlet_disable_switch(void)
{
    vhal_gpio_config_t relay_io;

    outlet_set_switch_onoff(false);
    s_switch_protect_enable = true;

    relay_io.pin_bit_mask = (1ULL << OUTLET_RELAY_GPIO_NUM);
    relay_io.mode = GPIO_MODE_DIS;
    relay_io.pull_up_en = GPIO_PULLUP_DIS;
    relay_io.pull_down_en = GPIO_PULLDOWN_DIS;
    relay_io.intr_type = GPIO_INTR_DIS;
    vhal_gpio_init(relay_io);
}

/**
 * @brief 获取硬件保护状态(开启/关闭)
 */
bool outlet_get_protect_status(void)
{
    return s_switch_protect_enable;
}

/**
 * @brief 使能指示灯
 */
void outlet_enable_indicator(void)
{
    if (!s_switch_indicator_enable)
    {
        s_switch_indicator_enable = true;
        if (s_switch_indicator)
        {
            vhal_gpio_set_output(OUTLET_INDICATOR_GPIO_NUM, OUTLET_INDICATOR_GPIO_ON);
        }
        else
        {
            vhal_gpio_set_output(OUTLET_INDICATOR_GPIO_NUM, OUTLET_INDICATOR_GPIO_OFF);
        }
    }

}

/**
 * @brief 禁用指示灯
 */
void outlet_disable_indicator(void)
{
    if (s_switch_indicator_enable)
    {
        s_switch_indicator_enable = false;
        vhal_gpio_set_output(OUTLET_INDICATOR_GPIO_NUM, OUTLET_INDICATOR_GPIO_OFF);
    }
}

/**
 * @brief 获取指示灯状态(亮/灭)
 * @return      bool            [true为开关开启，false为开关关闭]
 */
bool outlet_get_indicator_onoff(void)
{
    return s_switch_indicator;
}

