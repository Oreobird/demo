/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_mutex.h
 * @brief       mutex抽象层，封装互斥量相关接口
 * @date        2021-04-20
 */

#ifndef __VESYNC_MUTEX_H__
#define __VESYNC_MUTEX_H__

#include "vesync_os.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef vesync_handle_t *vesync_mutex_t;

/**
 * @brief  创建mutex
 * @return vesync_mutex_t              [互斥量结构体指针]
 */
vesync_mutex_t vesync_mutex_new(void);

/**
 * @brief  mutex上锁
 * @param[in]  mtx                     [互斥量结构体指针]
 * @return int                         [成功：VOS_OK；失败：VOS_FAIL]
 */
int vesync_mutex_lock(vesync_mutex_t mtx);

/**
 * @brief  mutex尝试获得锁
 * @param[in]  mtx                     [互斥量结构体指针]
 * @return int                         [成功：VOS_OK；失败：VOS_FAIL]
 */
int vesync_mutex_try_lock(vesync_mutex_t mtx);

/**
 * @brief  mutex解锁
 * @param[in]  mtx                     [互斥量结构体指针]
 * @return int                         [成功：VOS_OK；失败：VOS_FAIL]
 */
int vesync_mutex_unlock(vesync_mutex_t mtx);

/**
 * @brief  销毁mutex
 * @param[in]  mtx                     [互斥量结构体指针]
 * @return int                         [成功：VOS_OK；失败：VOS_FAIL]
 */
int vesync_mutex_free(vesync_mutex_t mtx);

/**
 * @brief  创建递归锁
 * @return vesync_mutex_t              [互斥量结构体指针]
 */
vesync_mutex_t vesync_recursive_mutex_new(void);

/**
 * @brief  recursive mutex上锁
 * @param[in]  mtx                     [互斥量结构体指针]
 * @return int                         [成功：VOS_OK；失败：VOS_FAIL]
 */
int vesync_recursive_mutex_lock(vesync_mutex_t mtx);

/**
 * @brief  recursive mutex尝试获得锁
 * @param[in]  mtx                     [互斥量结构体指针]
 * @return int                         [成功：VOS_OK；失败：VOS_FAIL]
 */
int vesync_recursive_mutex_try_lock(vesync_mutex_t mtx);

/**
 * @brief recursive mutex解锁
 * @param[in]  mtx                     [互斥量结构体指针]
 * @return int                         [成功：VOS_OK；失败：VOS_FAIL]
 */
int vesync_recursive_mutex_unlock(vesync_mutex_t mtx);

/**
 * @brief  销毁recursive mutex
 * @param[in]  mtx                     [互斥量结构体指针]
 * @return int                         [成功：VOS_OK；失败：VOS_FAIL]
 */
int vesync_recursive_mutex_free(vesync_mutex_t mtx);


#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_MUTEX_H__ */

