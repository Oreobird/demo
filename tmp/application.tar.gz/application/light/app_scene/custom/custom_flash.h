/**
* Copyright © Vesync Technologies Co.Ltd. 2022. All rights reserved
* @file         scene_flash.c
* @brief        场景存储
* @author       Joshua
* @date         2022-3-3
*/

#include <stdint.h>
#include <stdbool.h>
#include "scene.h"

#ifndef __CUSTOM_FLASH_H__
#define __CUSTOM_FLASH_H__

#ifdef __cplusplus
extern "C" {
#endif

#define CUSTOM_SCENE_CFG_KEY_DATA "custom_scene"
/**
 * @brief 配置数据key 定义
 */
typedef enum
{
    CS_KEY_VERSION = 0,   // 版本
    CS_KEY_NUM = 1,       // 场景个数
    CS_KEY_ARR = 0xF0,    // 场景数组
    CS_KEY_MAX
} CUSTUM_SCENE_KEY_E;

typedef enum
{
    CS_CFG_KEY_ID,              // 场景ID
    CS_CFG_KEY_REF,             // 场景被引用次数
    CS_CFG_KEY_COLOR_MODE,      // 色彩模式
    CS_CFG_KEY_SEG_NUM,         // 分段数
    CS_CFG_KEY_SEG_PARAM,       // 彩色参数
} CUSTOM_SCENE_CFG_KEY_E;

/**
 * @brief 保存自定义场景数据
 * @return int      [成功：APP_OK，失败：APP_FAIL]
 */
int custom_scene_flash_write(void);

/**
 * @brief 读取自定义场景数据
 * @return int      [成功：APP_OK，失败：APP_FAIL]
 */
int custom_scene_flash_read(void);

/**
 * @brief 清除自定义场景数据
 * @return int      [成功：APP_OK，失败：APP_FAIL]
 */
int custom_scene_flash_clear(void);

#ifdef __cplusplus
}
#endif

#endif