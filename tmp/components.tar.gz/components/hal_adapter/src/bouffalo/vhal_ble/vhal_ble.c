/**
 * Copyright © Vesync Technologies Co.Ltd. 2019-2021. All rights reserved.
 * @file    vhal_ble.c
 * @brief   蓝牙hal配置ble服务属性接口
 * @author  Louis
 * @date    2019-03-24
 */

#include "FreeRTOS.h"
#include "event_groups.h"
#include "semphr.h"
#include "bluetooth.h"
#include "hci_driver.h"
#include "ble_lib_api.h"
#include "conn.h"
#include "gatt.h"
#include "hci_core.h"
#include "uuid.h"

#include "vesync_common.h"
#include "vesync_log.h"
#include "vhal_ble.h"
#include "vhal_ble_internal.h"


static void ble_connected(struct bt_conn *conn, uint8_t err);
static void ble_disconnected(struct bt_conn *conn, uint8_t reason);
static int ble_recv_cmd(struct bt_conn *conn, const struct bt_gatt_attr *attr,
            const void *buf, u16_t len, u16_t offset, u8_t flags);
static int ble_recv_update(struct bt_conn *conn, const struct bt_gatt_attr *attr,
            const void *buf, u16_t len, u16_t offset, u8_t flags);
static int ble_recv_netcfg(struct bt_conn *conn, const struct bt_gatt_attr *attr,
            const void *buf, u16_t len, u16_t offset, u8_t flags);
static void ble_ccc_cfg_changed(const struct bt_gatt_attr *attr, u16_t vblfue);

static vhal_ble_evt_cb_t  hal_ble_evt_cb            = NULL;
static vhal_ble_recv_cb_t hal_ble_cmd_recv_cb       = NULL;
static vhal_ble_recv_cb_t hal_ble_netcfg_recv_cb   = NULL;


static char adv_name[ADV_NAME_MAX_LEN + 1] = {0};  //字符串多一个字符‘\0’
// 厂商自定义信息，协议参考蓝牙协议接口规范:http://wiki.vesync.com:8090/pages/viewpage.action?pageId=14254597
static uint8_t adv_mfr[26] ={0xd0,0x06,0x01,0x36,0x35,0x34,0x33,0x32,0x31,0xe0,0xa0,0x0,0x0,0x0};
static uint8_t sw_version[]  = "R0000V0001";
static ble_runnint_stat_t ble_running_stat = {0};


static struct bt_gatt_exchange_params bl_exchg_mtu;

static struct bt_data ad[] = {
    BT_DATA_BYTES(BT_DATA_FLAGS, (BT_LE_AD_GENERAL | BT_LE_AD_NO_BREDR)),
    BT_DATA(BT_DATA_MANUFACTURER_DATA, adv_mfr, MFR_DEFAULT_DATA_LEN),
};

static struct bt_data sd[] = {
    BT_DATA(BT_DATA_NAME_COMPLETE, adv_name, sizeof(adv_name)),
};

static struct bt_le_adv_param adv_params = {
    .id                   = 0,
    .options              = BT_LE_ADV_OPT_CONNECTABLE,
    .interval_min         = APP_ADV_INTERVAL_MIN,
    .interval_max         = APP_ADV_INTERVAL_MAX,
};

static struct bt_conn_cb conn_callbacks = {
    .connected = ble_connected,
    .disconnected = ble_disconnected,
};

static struct bt_gatt_attr cmd_attrs[]= {
    BT_GATT_PRIMARY_SERVICE(GATTS_SERVICE_CMD_UUID),

    BT_GATT_CHARACTERISTIC(GATTS_CHAR_CMD_NOTIFY_UUID,
                            BT_GATT_CHRC_NOTIFY,
                            BT_GATT_PERM_READ,
                            NULL,
                            NULL,
                            NULL),

    BT_GATT_CCC(ble_ccc_cfg_changed, BT_GATT_PERM_READ | BT_GATT_PERM_WRITE),

    BT_GATT_CHARACTERISTIC(GATTS_CHAR_CMD_WRITE_UUID,
                            BT_GATT_CHRC_WRITE | BT_GATT_CHRC_WRITE_WITHOUT_RESP,
                            BT_GATT_PERM_WRITE,
                            NULL,
                            ble_recv_cmd,
                            NULL),
};

static struct bt_gatt_attr update_attrs[]= {
    BT_GATT_PRIMARY_SERVICE(GATTS_UPDATE_SERVICE_UUID),

    BT_GATT_CHARACTERISTIC(GATTS_UPDATE_CHAR_NOTIFY_UUID,
                            BT_GATT_CHRC_NOTIFY | BT_GATT_CHRC_WRITE | BT_GATT_CHRC_WRITE_WITHOUT_RESP,
                            BT_GATT_PERM_READ,
                            NULL,
                            NULL,
                            NULL),

    BT_GATT_CCC(ble_ccc_cfg_changed, BT_GATT_PERM_READ | BT_GATT_PERM_WRITE),

    BT_GATT_CHARACTERISTIC(GATTS_UPDATE_CHAR_WRITE_UUID,
                            BT_GATT_CHRC_NOTIFY | BT_GATT_CHRC_WRITE | BT_GATT_CHRC_WRITE_WITHOUT_RESP,
                            BT_GATT_PERM_WRITE,
                            NULL,
                            ble_recv_update,
                            NULL),
};

static struct bt_gatt_attr netcfg_attrs[]= {
    BT_GATT_PRIMARY_SERVICE(GATTS_SERVICE_NET_CFG_UUID),

    BT_GATT_CHARACTERISTIC(GATTS_CHAR_NET_CFG_NOTIFY_UUID,
                            BT_GATT_CHRC_READ | BT_GATT_CHRC_NOTIFY,
                            BT_GATT_PERM_READ,
                            NULL,
                            NULL,
                            NULL),

    BT_GATT_CCC(ble_ccc_cfg_changed, BT_GATT_PERM_READ | BT_GATT_PERM_WRITE),

    BT_GATT_CHARACTERISTIC(GATTS_CHAR_NET_CFG_WRITE_UUID,
                            BT_GATT_CHRC_WRITE | BT_GATT_CHRC_WRITE_WITHOUT_RESP,
                            BT_GATT_PERM_WRITE,
                            NULL,
                            ble_recv_netcfg,
                            NULL),
};

static struct bt_gatt_service cmd_svc    = BT_GATT_SERVICE(cmd_attrs);
static struct bt_gatt_service update_svc = BT_GATT_SERVICE(update_attrs);
static struct bt_gatt_service netcfg_svc = BT_GATT_SERVICE(netcfg_attrs);



/**
 * @brief 上报蓝牙事件
 * @param[in] ev            [BLE event]
 */
static void ble_report_event(VHAL_BLE_EVT_E ev)
{
    if(NULL != hal_ble_evt_cb)
    {
        hal_ble_evt_cb(ev);
    }
}


/**
 * @brief mtu协商
 */
static void ble_exchange_func(struct bt_conn *conn, u8_t err,
                struct bt_gatt_exchange_params *params)
{
   if(!err)
   {
        ble_running_stat.tx_mtu = bt_gatt_get_mtu(ble_running_stat.conn) - ATT_OPCODE_HANDLE_LEN;
        HAL_LOG(LOG_DEBUG, "ble tp echange mtu size success, mtu size: %d\n", ble_running_stat.tx_mtu);
   }
   else
   {
        HAL_LOG(LOG_ERROR, "ble tp echange mtu size failure, err: %d\n", err);
   }
}


/**
 * @brief BLE连接事件回调
 */
static void ble_connected(struct bt_conn *conn, uint8_t err)
{
    int tx_octets = 0x00fb;
    int tx_time = 0x0848;
    int ret = -1;
    if (err) {
        HAL_LOG(LOG_ERROR, "Connection failed (err 0x%02x)\n", err);
        return;
    }

    HAL_LOG(LOG_DEBUG, "Connected\n");
    ble_running_stat.conn = conn;

    //set data length after connected.
    ret = bt_le_set_data_len(ble_running_stat.conn, tx_octets, tx_time);
    if(!ret)
    {
        HAL_LOG(LOG_DEBUG, "ble tp set data length success.\n");
    }
    else
    {
        HAL_LOG(LOG_ERROR, "ble tp set data length failure, err: %d\n", ret);
    }

    // exchange mtu size after connected.
    bl_exchg_mtu.func = ble_exchange_func;
    ret = bt_gatt_exchange_mtu(ble_running_stat.conn, &bl_exchg_mtu);
    if (!ret) {
        HAL_LOG(LOG_DEBUG, "Exchange mtu size success.\n");
    } else {
        HAL_LOG(LOG_ERROR, "Exchange mtu size failure, err: %d\n", ret);
    }

    // 蓝牙连接后关闭广播
    if(BLE_ADV_WORK_NORMAL == ble_running_stat.ble_adv_work)
    {
        vhal_ble_advertising_stop();
    }

    ble_report_event(HB_EVT_CONNECTED);
}


/**
 * @brief BLE断开事件回调
 */
static void ble_disconnected(struct bt_conn *conn, uint8_t reason)
{
    HAL_LOG(LOG_DEBUG, "Disconnected (reason 0x%02x)\n", reason);

    ble_running_stat.conn = NULL;

    vhal_ble_advertising_start();

    ble_report_event(HB_EVT_DISCONNECTED);
}


/**
 * @brief 服务开启/关闭回调
 */
static void ble_ccc_cfg_changed(const struct bt_gatt_attr *attr, u16_t vblfue)
{
    if(vblfue == BT_GATT_CCC_NOTIFY)
    {
        HAL_LOG(LOG_DEBUG, "enable notify.\n");
        ble_running_stat.notify_flag=true;
    }
    else
    {
        HAL_LOG(LOG_DEBUG, "disable notify.\n");
        ble_running_stat.notify_flag=false;
    }
}


/**
 * @brief BLE enable回调
 */
static void bt_enable_cb(int err)
{
    if (!err) {
        HAL_LOG(LOG_DEBUG, "%s bt enable ok\r\n", __func__);
        ble_report_event(HB_EVT_INIT_COMPLETE);
    }
}


/**
 * @brief BLE发送数据
 * @param[in] data          [发送数据指针]
 * @param[in] len           [发送数据长度]
 * @return int32_t          [VHAL_OK/VHAL_FAIL]
 */
static int32_t vhal_ble_data_send(struct bt_gatt_attr *attr,uint8_t *data,uint16_t len)
{
    uint32_t ret = -1;
    uint16_t offset = 0;
    uint16_t tx_len = 0;

    if(NULL == ble_running_stat.conn)
    {
        return VHAL_FAIL;
    }

    while (offset < len)
    {
        tx_len = ((len - offset) > ble_running_stat.tx_mtu ? ble_running_stat.tx_mtu : (len - offset));

        HAL_LOG(LOG_INFO,"hal ble send start,offset=%d,tx_len=%d\r\n",offset,tx_len);
        ret = bt_gatt_notify(ble_running_stat.conn, attr, data+offset, tx_len);
        HAL_LOG(LOG_INFO,"hal ble send complete\r\n");

        if(0 != ret)
        {
            break;
        }

        offset  += tx_len;
    }

    if (0 == ret)
    {
        return VHAL_OK;
    }
    return VHAL_FAIL;
}


/**
 * @brief 接收CMD数据
 */
static int ble_recv_cmd(struct bt_conn *conn, const struct bt_gatt_attr *attr,
                const void *buf, u16_t len, u16_t offset, u8_t flags)
{
    if(NULL != hal_ble_cmd_recv_cb)
    {
        hal_ble_cmd_recv_cb((uint8_t *)buf, len);
        HAL_LOG(LOG_INFO,"recv cmd complete\n");
    }
    return 0;
}

/**
 * @brief 接收update数据
 */
static int ble_recv_update(struct bt_conn *conn, const struct bt_gatt_attr *attr,
                const void *buf, u16_t len, u16_t offset, u8_t flags)
{
    //TODO:
    return 0;
}

/**
 * @brief 接收配网数据
 */
static int ble_recv_netcfg(struct bt_conn *conn,
              const struct bt_gatt_attr *attr, const void *buf,
              u16_t len, u16_t offset, u8_t flags)
{
    if(NULL != hal_ble_netcfg_recv_cb)
    {
        hal_ble_netcfg_recv_cb((uint8_t *)buf, len);
        HAL_LOG(LOG_INFO,"recv net cfg complete\n");
    }
    return 0;
}



/**
 * @brief 注册蓝牙事件函数
 */
void vhal_ble_reg_evt_cb(vhal_ble_evt_cb_t cb)
{
    hal_ble_evt_cb = cb;
}


/**
 * @brief 注册cmd接口接收回调
 */
void vhal_ble_reg_cmd_recv_cb(vhal_ble_recv_cb_t cb)
{
    hal_ble_cmd_recv_cb = cb;
}

/**
 * @brief 注册配网接口接收回调
 */
void vhal_ble_reg_netcfg_recv_cb(vhal_ble_recv_cb_t cb)
{
    hal_ble_netcfg_recv_cb = cb;
}


/**
 * @brief cmd接口发送数据
 * @param[in] data          [发送数据指针]
 * @param[in] len           [发送数据长度]
 * @return int32_t          [VHAL_OK/VHAL_FAIL]
 */
int32_t vhal_ble_cmd_data_send(uint8_t *data, uint16_t len)
{
    if(NULL == data || 0 == len || len > 1500)
    {
        return VHAL_FAIL;
    }

    return vhal_ble_data_send(&cmd_attrs[ATTR_IDX_CHAR_NOTIFY], data, len);
}

/**
 * @brief update接口发送数据
 * @param[in] data          [发送数据指针]
 * @param[in] len           [发送数据长度]
 * @return int32_t          [VHAL_OK/VHAL_FAIL]
 */
int32_t vhal_ble_update_data_send(uint8_t *data, uint16_t len)
{
    if(NULL == data || 0 == len || len > 1500)
    {
        return VHAL_FAIL;
    }

    return vhal_ble_data_send(&update_attrs[ATTR_IDX_CHAR_NOTIFY], data, len);
}

/**
 * @brief 配网接口发送数据
 * @param[in] data          [发送数据指针]
 * @param[in] len           [发送数据长度]
 * @return int32_t          [VHAL_OK/VHAL_FAIL]
 */
int32_t vhal_ble_netcfg_data_send(uint8_t *data ,uint16_t len)
{
    if(NULL == data || 0 >= len || len > 1500)
    {
        return VHAL_FAIL;
    }

    return vhal_ble_data_send(&netcfg_attrs[ATTR_IDX_CHAR_NOTIFY], data, len);
}


/**
 * @brief 启动广播
 * @return int32_t      [VHAL_OK/VHAL_FAIL]
 */
int32_t vhal_ble_advertising_start(void)
{
    HAL_LOG(LOG_DEBUG, "BLE ADV START\r\n");
    ble_running_stat.adv_start = true;
    return bt_le_adv_start(&adv_params, ad, ARRAY_SIZE(ad), sd, ARRAY_SIZE(sd));
}

/**
 * @brief 停止广播
 * @return int32_t      [VHAL_OK/VHAL_FAIL]
 */
int32_t vhal_ble_advertising_stop(void)
{
    HAL_LOG(LOG_DEBUG, "BLE ADV STOP\n");
    ble_running_stat.adv_start = false;
    return bt_le_adv_stop();
}


/**
 * @brief 主动断开当前的蓝牙连接
 * @return int32_t      [VHAL_OK/VHAL_FAIL]
 */
int32_t vhal_ble_disconnect(void)
{
    if (NULL == ble_running_stat.conn)
    {
        return VHAL_OK;
    }

    if (0 == bt_conn_disconnect(ble_running_stat.conn, BT_HCI_ERR_REMOTE_USER_TERM_CONN))
    {
        return VHAL_OK;
    }

    return VHAL_FAIL;
}

/**
 * @brief 动态修改蓝牙广播名称
 * @param name
 * @return int32_t 0：成功，非零失败
 */
int32_t vhal_ble_set_device_name(char *p_name)
{
    int32_t ret;
    if (NULL == p_name)
    {
        return VHAL_FAIL;
    }

    strncpy(adv_name, p_name, ADV_NAME_MAX_LEN);

    bt_set_name(adv_name);
    if (ble_running_stat.adv_start != true)
    {
        return VHAL_OK;
    }

    ret = bt_le_adv_update_data(ad, ARRAY_SIZE(ad), sd, ARRAY_SIZE(sd));
    if (ret)
    {
        HAL_LOG(LOG_ERROR, "set device name failed, error code = %d\n", ret);
        return VHAL_FAIL;
    }

    return VHAL_OK;
}

/**
 * @brief 动态修改广播参数
 * @param product_type
 * @param product_model
 * @return int32_t 0：成功，非零失败
 */
int32_t vhal_ble_set_adv_product_info(uint8_t product_type,uint8_t product_model)
{
    int32_t ret;

    adv_mfr[9] = product_type;
    adv_mfr[10] = product_model;

    if (ble_running_stat.adv_start != true)
    {
        return VHAL_OK;
    }

    ret = bt_le_adv_update_data(ad, ARRAY_SIZE(ad), sd, ARRAY_SIZE(sd));
    if (ret)
    {
        HAL_LOG(LOG_ERROR, "config adv data failed, error code = %d\n", ret);
    }
    return ret;
}

/**
 * @brief 动态修改广播命令字段
 * @param[in] cmd_data           [命令数据段]
 * @param[in] cmd_len            [命令数据长度]
 * @param[in] up_flag            [是否更新广播包长度]
 * @return  int32_t              [成功：VHAL_OK，失败：VHAL_FAIL]
 */
int32_t vhal_ble_set_adv_cmd_data(uint8_t * cmd_data, uint8_t cmd_len, bool up_flag)
{
    int32_t ret;

    if ((NULL == cmd_data) || (MFR_MAX_CMD_DATA_LEN < cmd_len))
    {
        return VHAL_FAIL;
    }

    memcpy(&adv_mfr[11], cmd_data, cmd_len);

    if (ble_running_stat.adv_start != true)
    {
        return VHAL_OK;
    }

    if (true == up_flag)
    {
       ad[1].data_len = MFR_DEFAULT_DATA_LEN + cmd_len - 3;
    }


    ret = bt_le_adv_update_data(ad, ARRAY_SIZE(ad), sd, ARRAY_SIZE(sd));
    if (ret)
    {
        HAL_LOG(LOG_ERROR, "config adv data failed, error code = %d\n", ret);
    }
    return ret;

}


/**
 * @brief 蓝牙广播动态修改配网状态
 * @param netcfg_status 设备配网状态
 * @return int32_t 0：成功，非零失败
 */
int32_t vhal_ble_set_adv_netcfg_status(uint8_t netcfg_status)
{
    int32_t ret;

    adv_mfr[13] = netcfg_status;

    if (ble_running_stat.adv_start != true)
    {
        return VHAL_OK;
    }

    ret = bt_le_adv_update_data(ad, ARRAY_SIZE(ad), sd, ARRAY_SIZE(sd));
    if (ret)
    {
        HAL_LOG(LOG_ERROR, "config adv data failed, error code = %d\n", ret);
    }
    return ret;
}



/**
 * @brief 更新蓝牙连接间隔
 * @param min_interval min_interval = x*1.25ms
 * @param max_interval max_interval = x*1.25ms
 * @param time_out     timeout = x*10ms
 * @return int32_t 0：成功，非零失败
 *
 * interval Max*(slave latency+1)<=2s
 * interval min>=20ms
 * interval min+20ms<=interval max
 * slve latency<=4
 * connsupervisiontimeout <= 6s
 * interval max*(slave latency+1)*3 < connsupervisiontimeout
 */
int32_t vhal_ble_update_connect_interval(uint16_t min_interval,uint16_t max_interval,uint16_t timeout)
{
    int32_t ret = -1;
    struct bt_le_conn_param conn_params = {0};

    if(NULL != ble_running_stat.conn)
    {
        conn_params.interval_min = min_interval;
        conn_params.interval_max = max_interval;
        conn_params.latency = 0;
        conn_params.timeout = timeout;

        ret = bt_conn_le_param_update(ble_running_stat.conn, &conn_params);

        HAL_LOG(LOG_INFO,"update_connect_interval min:%d ms,max:%d ms,timeout:%d ms\n" ,(int)(min_interval*1.25),(int)(max_interval*1.25),(int)(timeout*10));
    }
    else
    {
        HAL_LOG(LOG_ERROR,"invlid state\n");
    }

    return ret;
}


/**
 * @brief 蓝牙是否连接成功？
 * @return bool         [true 连接 false 未连接]
 */
bool vhal_ble_is_connected(void)
{
    return (NULL != ble_running_stat.conn);
}


/**
 * @brief 关闭蓝牙功能
 * @return int32_t      [VHAL_OK/VHAL_FAIL]
 */
int32_t vhal_ble_disable(void)
{
    int32_t ret;

    ble_running_stat.adv_start = false;

    if(vhal_ble_is_connected())
    {
        ret = vhal_ble_disconnect();
    }

    ret = vhal_ble_advertising_stop();

    return ret;
}


/**
 * @brief 关闭蓝牙协议栈，释放蓝牙资源
 */
void vhal_ble_deinit(void)
{
//TODO:
    ble_running_stat.ble_init = false;

    HAL_LOG(LOG_INFO,"vhal_ble_deinit\n");
}


/**
 * @brief 蓝牙是否已经初始化
 * @return bool             [true:已经初始化; false:未初始化]
 */
bool vhal_ble_is_init(void)
{
    return ble_running_stat.ble_init;
}

/**
 * @brief  初始化蓝牙协议栈及配置蓝牙广播参数
 * @param[in]  dev_name         [蓝牙设备名称]
 * @param[in]  prj_version      [软件版本号，必须是“1.0.00”的格式]
 * @param[in]  mfr_data         [厂商定义数据]
 * @return     int32_t          [执行结果 VHAL_OK/VHAL_FAIL]
 */
int32_t vhal_ble_init(char *dev_name, char *prj_version, ble_adv_mfr_data_t mfr_data)
{
    int32_t ret =0;

    if(ble_running_stat.ble_init)
    {
        HAL_LOG(LOG_DEBUG, "BLE init already.\n");
        return VHAL_FAIL;
    }

    if((NULL == dev_name) || (strlen(dev_name) > ADV_NAME_MAX_LEN) ||
       (6 != strlen(prj_version)))  //prj_version格式必须是“1.0.00”，所以长度必须是6
    {
        HAL_LOG(LOG_ERROR, "param error.\n");
        return VHAL_FAIL;
    }

    ble_report_event(HB_EVT_INIT);

    ble_running_stat.tx_mtu = 23 - ATT_OPCODE_HANDLE_LEN; // BT_ATT_DEFAULT_LE_MTU=23

    /* 软件版本号格式转换 */
    sw_version[6] = prj_version[0];
    sw_version[7] = prj_version[2];
    sw_version[8] = prj_version[4];
    sw_version[9] = prj_version[5];

    strncpy(adv_name, dev_name, ADV_NAME_MAX_LEN);

    bt_addr_le_t adv_addr;
    ret = bt_get_local_public_address(&adv_addr);
    if (ret)
    {
        HAL_LOG(LOG_ERROR, "%s get mac failed\n", __func__);
        return ret;
    }

    for(uint8_t i = 0;i < 6; i++)
    {
        adv_mfr[3 + i] = adv_addr.a.val[5-i];
    }

    adv_mfr[9]  = mfr_data.product_type;
    adv_mfr[10] = mfr_data.product_model;
    adv_mfr[11] = mfr_data.cmd_code;         // 配网新需求新增，2020-03-17
    adv_mfr[12] = mfr_data.netcfg_ver;
    adv_mfr[13] = mfr_data.netcfg_status;

    ble_running_stat.ble_adv_work = mfr_data.ble_adv_work;

     // Initialize BLE controller
    ble_controller_init(configMAX_PRIORITIES - 1);
    // Initialize BLE Host stack
    hci_driver_init();
    bt_enable(bt_enable_cb);

    bt_conn_cb_register(&conn_callbacks);
    bt_gatt_service_register(&cmd_svc);
    bt_gatt_service_register(&update_svc);
    bt_gatt_service_register(&netcfg_svc);

    ble_running_stat.ble_init = true;

    return ret;
}

/**
 * @brief  获取BLE MAC
 * @param[out] dev_mac      [输出蓝牙MAC buffer]
 * @param[in]  max_len      [buffer 长度]
 * @return     int32_t      [执行结果 VHAL_OK/VHAL_FAIL]
 */
int32_t vhal_ble_get_mac(char *dev_mac, uint32_t max_len)
{
    int ret = VHAL_FAIL;
    bt_addr_le_t adv_addr;

    if (NULL == dev_mac)
    {
        HAL_LOG(LOG_ERROR, "Input param is a null pointer!\n");
        return VHAL_FAIL;
    }
    if (max_len < MAC_ADDR_STR_MAX_LEN)
    {
        HAL_LOG(LOG_ERROR, "Buf len(=%d) is too small!\n", max_len);
        return VHAL_FAIL;
    }


    ret = bt_get_local_public_address(&adv_addr);
    if (ret)
    {
        HAL_LOG(LOG_ERROR, "%s get mac failed\n", __func__);
        return ret;
    }

    snprintf(dev_mac, max_len, MACSTR, MAC2STR(adv_addr.a.val));

    return VHAL_OK;
}


