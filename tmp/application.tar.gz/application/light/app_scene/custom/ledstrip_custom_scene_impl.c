/**
* Copyright © Vesync Technologies Co.Ltd. 2022. All rights reserved
* @file         ledstrip_custom_scene_impl.c
* @brief        自定义场景回调业务实现
* @author       Joshua
* @date         2022-1-14
*/

#include <string.h>
#include "vesync_log.h"
#include "vesync_common.h"
#include "custom.h"
#include "light.h"


int custom_light_scene_impl_init(void)
{
    return APP_OK;
}


