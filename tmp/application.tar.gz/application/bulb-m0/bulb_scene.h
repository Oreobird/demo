/**
 * Copyright © Vesync Technologies Co.Ltd. 2022. All rights reserved.
 * @file        bulb_scene.h
 * @brief       bulb场景功能接口声明
 * @author      Herve.Lin
 * @date        2022-01-19
 */
#ifndef __BULB_SCENE_H__
#define __BULB_SCENE_H__

#include <stdint.h>

#include "bulb_status.h"

#define BULB_SCENE_CUSTOM_ID_OFFSET (1025)
#define BULB_SCENE_CUSTOM_MAX_NUM (16)
#define BULB_SCENE_DEFAULT_MAX_NUM (12)
#define BULB_SCENE_GET_MAX_NUM (6)

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief Bulb 场景类型定义
 */
typedef enum
{
    SCENE_TYPE_WHITE,   // 静态白光场景
    SCENE_TYPE_COLOR,   // 静态彩光场景
    SCENE_TYPE_DYNAMIC, // 动态场景
} SCENE_TYPE_E;

/**
 * @brief Bulb 场景参数定义
 */
typedef struct
{
    uint16_t id;    // 场景ID
    uint8_t type;   // 场景类型
    union
    {
        bulb_status_white_t white;
        bulb_status_hsv_t hsv;
        void (*dynamic_cb)(void *);
    } param;
} bulb_scene_t;

/**
 * @brief Bulb 场景模块初始化
 * @return      int                 [成功：APP_OK， 失败：APP_FAIL]
 */
int bulb_scene_init(void);

/**
 * @brief Bulb 场景模块获取场景列表
 * @param[in]   index               [场景页读取偏移]
 * @param[out]  p_list              [输出场景列表]
 * @param[out]  p_list_len          [输出场景列表长度]
 * @param[out]  p_total             [输出场景总数]
 * @return      int                 [成功：APP_OK， 失败：APP_FAIL]
 */
int bulb_scenes_list_get(uint8_t index, bulb_scene_t *p_list, uint8_t *p_list_len, uint8_t *p_total);

/**
 * @brief Bulb 场景模块删除指定场景
 * @param[in]   id                  [应删除场景ID]
 * @return      int                 [成功：APP_OK， 失败：APP_FAIL]
 */
int bulb_scene_del(uint16_t id);

/**
 * @brief Bulb 场景模块增加场景
 * @param[in]   p_scene             [场景参数]
 * @param[out]  p_id_out            [输出为该新场景分配的ID]
 * @return      int                 [成功：APP_OK， 失败：APP_FAIL]
 */
int bulb_scene_add(bulb_scene_t *p_scene, uint16_t *p_id_out);

/**
 * @brief Bulb 场景模块读取指定场景
 * @param[in]   id                  [应读取场景ID]
 * @param[out]  p_scene             [输出相应的场景参数]
 * @return      int                 [成功：APP_OK， 失败：APP_FAIL]
 */
int bulb_scene_restore(uint16_t id, bulb_scene_t *p_scene);

/**
 * @brief Bulb 场景模块清除所有自定义数据
 * @return      int                 [成功：APP_OK， 失败：APP_FAIL]
 */
int bulb_scene_clear(void);

/**
 * @brief Bulb 场景模块查询该场景ID是否存在
 * @param[in]   id                  [应查询场景ID]
 * @param[out]  p_is_exist          [指向输出查询结果的缓存]
 * @return      int                 [成功：APP_OK， 失败：APP_FAIL]
 */
int bulb_scene_exist(uint16_t id, bool *p_is_exist);

#ifdef __cplusplus
}
#endif

#endif /* __BULB_SCENE_H__ */