/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file        vesync_ota.c
* @brief       OTA模块接口实现
* @date        2021-05-19
*/

#include <string.h>
#include "mbedtls/md.h"
#include "mbedtls/md5.h"

#include "vesync_cfg_internal.h"
#include "vesync_task.h"
#include "vesync_common.h"
#include "vesync_memory.h"
#include "vesync_log_internal.h"
#include "vesync_ca_cert.h"

#if CONFIG_VESYNC_HAL_BLE_ENABLE
#include "vhal_ble.h"
#endif
#include "vhal_ota.h"
#include "vhal_wifi.h"
#include "vesync_report_internal.h"
#include "vesync_ota_internal.h"
#include "vesync_ota_mcu_internal.h"

#if CONFIG_VESYNC_SDK_HTTP_ENABLE
#include "vesync_http_internal.h"
#endif

static vesync_ota_t s_ota;
static uint8_t s_ota_aes_key[AES_KEY_LEN];                       // ota头部解密密钥
static uint8_t s_ota_aes_iv[AES_KEY_LEN];                        // ota头部解密向量

/*-----------------------------------------------------------------------------*
 *                                 内部函数实现                                  *
 *-----------------------------------------------------------------------------*/

/**
 * @brief 版本号(x.x.x)转十六进制
 * @param[in] ver
 * @return uint32_t             [版本号十六进制]
 */
static uint32_t version_to_hex(char *ver)
{
    uint32_t acc = 0, ret = 0;

    if(NULL == ver)
    {
        return 0;
    }

    do {
        char cc = *ver;
        switch (cc)
        {
            case '0':
            case '1':
            case '2':
            case '3':
            case '4':
            case '5':
            case '6':
            case '7':
            case '8':
            case '9':
                acc = acc * 10 + (cc - '0');
                break;
            case '.':
                ret = ret << 8 | acc;
                acc = 0;
                break;
            case '\0':
                ret = ret << 8 | acc;
                break;
            default:
                return 0;
        }
    } while (*ver++) ;

    return ret;
}

/**
 * @brief OTA清除标志位
 */
static void vesync_ota_clear(void)
{
    memset(&s_ota.upg_info, 0, sizeof(upgrade_info_t));
    s_ota.upg_info.upg_state = UPG_IDLE;
}

/**
* @brief 检测当前设备是否满足升级需求
* @return bool                   [可以升级，返回true；不可以升级，返回false]
*/
static bool vesync_ota_req_check(void)
{
    /// TODO: 1、电池设备电量检测
    /// TODO: 2、设备是否在工作

    return true;
}

/**
* @brief  回复固件升级状态及进度
* @param[in] state                [固件升级状态或错误码]
* @param[in] dl_percent           [固件升级进度，在固件升级状态为升级中时才是有效值]
*/
static void vesync_ota_response_upgrade_status(UPGRADE_STATE_E state, uint8_t dl_percent)
{
    int ret = 0;
    static UPGRADE_STATE_E upg_state = UPG_IDLE;

    // 状态发生改变，上报
    if (state != upg_state)
    {
        if ((s_ota.upg_info.upg_entry == UPG_EN_WIFI) /*&& (vesync_mqtt_client_get_status() == MQTT_ONLINE)*/) // Wi-Fi通道升级，从Wi-Fi通道上报状态
        {
            ret = vesync_report_firm_up(s_ota.upg_info.upg_type, s_ota.upg_info.fw_ver, s_ota.upg_info.fw_url, (uint8_t)state, dl_percent);
            SDK_LOG(LOG_DEBUG, "upload ota state, return val = %d.\n", ret);
        }
        else
        {
            /// TODO: BLE通道升级，从BLE通道上报状态
        }
    }
}

/**
* @brief OTA升级状态处理回调函数
* @param[in] status                [ota状态]
* @param[in] progress              [固件下载进度]
*/
static void vesync_ota_status_cb(VHAL_OTA_STATE_E status, uint8_t progress)
{
    switch (status)
    {
        case VHAL_OTA_ST_PROCESS:
#if CONFIG_VESYNC_SDK_PRODUCTION_ENABLE
        if(vesync_production_get_status() == PRODUCTION_RUNNING)
        {
            if ((50 == progress)&&(progress != s_ota.upg_info.upg_progress))
            {
                vesync_ota_response_upgrade_status(UPG_DOWNLOADING, progress);
                s_ota.upg_info.upg_progress = progress;
            }
        }
        else
#endif
        {
            if (progress - s_ota.upg_info.upg_progress >= 10) // 按10%的刻度进行上报，要不然上报太频繁了
            {
                vesync_ota_response_upgrade_status(UPG_DOWNLOADING, progress);
                s_ota.upg_info.upg_progress = progress;
            }
        }
            break;
        case VHAL_OTA_ST_DL_COMP:
            vesync_ota_response_upgrade_status(UPG_UPGRADING, progress);
            break;
        case VHAL_OTA_ST_SUCCESS:
            // Wi-Fi固件OTA升级成功，设备重启再上报成功的状态；MCU和BLE升级成功，直接通过接口上报
            if (s_ota.upg_info.upg_entry != UPG_EN_WIFI)
            {
                vesync_ota_response_upgrade_status(UPG_SUCCESS, progress);
                s_ota.upg_code = UPG_SUCCESS;
            }
            break;
        case VHAL_OTA_ST_TIME_OUT:
            vesync_ota_response_upgrade_status(UPG_TIME_OUT, progress);
            s_ota.upg_code = UPG_TIME_OUT;
            break;
        case VHAL_OTA_ST_URL_ERR:
            vesync_ota_response_upgrade_status(UPG_URL_ERR, progress);
            s_ota.upg_code = UPG_URL_ERR;
            break;
        case VHAL_OTA_ST_HTTP_CONN_FAIL:
            vesync_ota_response_upgrade_status(UPG_CONN_FAIL, progress);
            s_ota.upg_code = UPG_CONN_FAIL;
            break;
        case VHAL_OTA_ST_DL_FAIL:
            vesync_ota_response_upgrade_status(UPG_DL_FAIL, progress);
            s_ota.upg_code = UPG_DL_FAIL;
            break;
        case VHAL_OTA_ST_OUT_MEM:
        case VHAL_OTA_ST_FLASH_ERR:
        case VHAL_OTA_ST_FAIL:
            vesync_ota_response_upgrade_status(UPG_FAIL, progress);
            s_ota.upg_code = UPG_FAIL;
            break;
        default:
            break;
    }
}

#if (CONFIG_VESYNC_SDK_HTTP_ENABLE)&& (PR_OTA_TYPE_MCU > 0)

/**
 * @brief mcu 固件升级处理
 * @return  bool         [true：需要mcu升级，false：不需要mcu升级]
*/
static bool mcu_need_ota(void)
{
#if (PR_OTA_TYPE_MCU > 0)
    if ((UPG_TP_MCU == s_ota.upg_info.upg_type)
#if (PR_OTA_TYPE_MCU > 1)
        || (UPG_TP_MCU2 == s_ota.upg_info.upg_type)
#endif
#if (PR_OTA_TYPE_MCU > 2)
        || (UPG_TP_MCU3 == s_ota.upg_info.upg_type)
#endif
    )
    return true;
#endif
    return false;
}

/**
 * @brief MCU进行ota时状态回调函数
 * @param[in] state             [ota状态]
 * @param[in] param             [固件下载状态]
 * @return void
 */
static void vesync_ota_mcu_state_cb(OTA_MCU_STATE_E state, ota_mcu_state_param_u *param)
{
    SDK_LOG(LOG_INFO, "vesync_ota_mcu_state_cb %d\n",state);

    vesync_timer_change_period(s_ota.timeout_timer, VESYNC_OTA_MCU_TIMEOUT_TIME);

    switch (state)
    {
        case OTA_MCU_STATE_DOWNLOAD_RESULT:
            SDK_LOG(LOG_INFO, "OTA_MCU_STATE_DOWNLOAD_RESULT %d\n", param->download_result);
            break;
        case OTA_MCU_STATE_RESULT:
            SDK_LOG(LOG_INFO, "OTA_MCU_STATE_RESULT %d\n", param->ota_mcu_result);
            break;
        default:
            break;
    }
}
#endif


/**
 * @brief  头部解密
 * @param[in]  crypto_type          [头部加密方式]
 * @param[in]  p_in                 [待解密数据指针]
 * @param[in]  p_len                [待解密码数据长度]
 * @param[out]  p_out               [解密后数据指针]
 * @return  uint8_t                 [解密后数据长度，为0则解密失败]
 */
static uint32_t vesync_ota_header_decrypt(uint8_t crypto_type, uint8_t *p_in, int in_len, uint8_t **p_out)
{
    int decrypt_len = 0;

    if (crypto_type == OTA_CRYPT_AES)
    {
        decrypt_len = vesync_aes_decrypt_with_key(NO_PADDING, p_in, in_len, p_out, s_ota_aes_key, s_ota_aes_iv);
        if (0 == decrypt_len || NULL == p_out)
        {
            return 0;
        }
    }
    else
    {
        SDK_LOG(LOG_ERROR, "crypto type not support yet\n");
        return 0;
    }

    return decrypt_len;
}


/**
* @brief  校验vesync添加的头部
* @param[in]  header             [vesync添加的头部, 128bytes长度]
* @param[in]  len                [vesync添加的头部长度]
* @return     int                [0表示成功，其他值表示失败]
*/
static int vesync_ota_check_header(uint8_t *p_header, int len)
{
    vesync_ota_header_t header;
    uint8_t percent = 0;
    uint8_t *p_data = p_header;

    if (NULL == p_data)
    {
        SDK_LOG(LOG_ERROR, "Invalid header!!\n");
        return SDK_FAIL;
    }

    if (sizeof(vesync_ota_header_t) + 1 != len)
    {
        SDK_LOG(LOG_ERROR, "Header len is %d, invalid!!\n", len);
        return SDK_FAIL;
    }

    uint8_t crypto_type = *p_data;
    SDK_LOG(LOG_DEBUG, "crypto_type=%d, PR_OTA_CRYPTO_TYPE=%d\n", crypto_type, PR_OTA_CRYPTO_TYPE);
    if (crypto_type != PR_OTA_CRYPTO_TYPE)
    {
        SDK_LOG(LOG_ERROR, "Crypto type not match\n");
        return SDK_FAIL;
    }

    p_data++;
    int encrypt_len = sizeof(vesync_ota_header_t);
    uint8_t *decrypt_data = NULL;
    int decrypt_len = vesync_ota_header_decrypt(crypto_type, p_data, encrypt_len, &decrypt_data);
    if (decrypt_data == NULL || decrypt_len != encrypt_len)
    {
        SDK_LOG(LOG_ERROR, "Header decrypt fail\n");
        return SDK_FAIL;
    }

    memset(&header, 0, sizeof(vesync_ota_header_t));
    memcpy(&header, decrypt_data, sizeof(vesync_ota_header_t));
    VCOM_SAFE_FREE(decrypt_data);

    //LOG_RAW_HEX(LOG_DEBUG, "OTA head:", (uint8_t *)&header, len);

    //LOG_RAW_HEX(LOG_DEBUG, NULL, header.md5, sizeof(header->md5));
    //LOG_RAW_HEX(LOG_DEBUG, NULL, header.model, sizeof(header->model));
    //LOG_RAW_HEX(LOG_DEBUG, NULL, header.sw_ver, sizeof(header->sw_ver));
    //LOG_RAW_HEX(LOG_DEBUG, NULL, header.hw_ver, sizeof(header->hw_ver));
    //LOG_RAW_HEX(LOG_DEBUG, NULL, header.country_list, sizeof(header->country_list));

    SDK_LOG(LOG_DEBUG, "Vesync header len is %d.\n", sizeof(vesync_ota_header_t));
    SDK_LOG(LOG_DEBUG, "Vesync header ver is %d.\n", header.ver);
    SDK_LOG(LOG_DEBUG, "Vesync header md5 is %s.\n", header.md5);
    SDK_LOG(LOG_DEBUG, "Vesync header model is %s.\n", header.model);
    SDK_LOG(LOG_DEBUG, "Vesync header sw_ver is %s.\n", header.sw_ver);
    SDK_LOG(LOG_DEBUG, "Vesync header hw_ve is %s.\n", header.hw_ver);
    SDK_LOG(LOG_DEBUG, "Vesync header country_list is %s.\n", header.country_list);

    if (header.ver != PR_OTA_HEADER_VER)
    {
        vesync_ota_response_upgrade_status(UPG_HEADER_VER_ERR, percent);   // ota头部版本不匹配
        return SDK_FAIL;
    }


    if (0 != strcmp((char *)header.model, vesync_cfg_get_model()) &&
        0 != strcmp((char *)header.model, vesync_cfg_get_alias_model()))
    {
        vesync_ota_response_upgrade_status(UPG_MODEL_ILLEGAL, percent);   // 产品不匹配
        return SDK_FAIL;
    }

    if (0 != strcmp((char *)header.sw_ver, (char *)s_ota.upg_info.fw_ver))
    {
        vesync_ota_response_upgrade_status(UPG_SW_VER_ERR, percent);   // 软件版本不匹配
        return SDK_FAIL;
    }

    if (0 != strcmp((char *)header.hw_ver, vesync_cfg_get_hw_version()))
    {   // Wi-Fi模块硬件版本号(非产品硬件版本号)
        vesync_ota_response_upgrade_status(UPG_HW_VER_ERR, percent);   // 硬件版本不匹配
        return SDK_FAIL;
    }

    if (NULL == strstr((char *)header.country_list, vesync_cfg_get_country_code()))
    {
        vesync_ota_response_upgrade_status(UPG_COUNTRY_CODE_ERR, percent);   // 国家码不支持
        return SDK_FAIL;
    }

    if (strlen((char *)header.md5) > 0)
    {
        if (NULL == s_ota.p_head_md5)
        {
            s_ota.p_head_md5 = (uint8_t *)vesync_malloc(MAX_MD5_LEN);
            if (NULL != s_ota.p_head_md5)
            {
                memset((char *)s_ota.p_head_md5, 0, MAX_MD5_LEN);
                snprintf((char *)s_ota.p_head_md5, MAX_MD5_LEN, "%s", header.md5);
            }
        }
    }

    return SDK_OK;
}

/**
 * @brief 版本号比较
 * @param[in]  char *               [字符串形式的版本号x.x.xx]
 * @param[in]  char *               [字符串形式的版本号x.x.xx]
 * @return int                      [ver1大于ver2，返回1；ver1小于ver2，返回-1；相等返回0]
 */
static int vesync_ota_version_cmp(char *p_ver1, char *p_ver2)
{
    if (NULL == p_ver1 || NULL == p_ver2)
    {
        return 0;
    }

    uint32_t ver1_hex = version_to_hex(p_ver1);
    uint32_t ver2_hex = version_to_hex(p_ver2);
    int ret = 0;

    if (ver1_hex > ver2_hex)
    {
        ret = 1;
    }
    else if (ver1_hex < ver2_hex)
    {
        ret = -1;
    }

    return ret;
}

/**
* @brief 固件md5校验回调函数指针
* @param[in]  p_md5               [固件实际md5]
* @return     int                 [0表示校验通过，其他值表示校验失败]
*/
static int vesync_ota_check_md5(uint8_t *p_md5)
{
    if (NULL == p_md5 || NULL == s_ota.p_head_md5 || strlen((char *)s_ota.p_head_md5) <= 0)
    {
        vesync_ota_response_upgrade_status(UPG_MD5_FAIL, 100);   // MD5校验失败
        return SDK_FAIL;
    }

    if (0 != strcmp((char *)p_md5, (char *)s_ota.p_head_md5))
    {
        vesync_ota_response_upgrade_status(UPG_MD5_FAIL, 100);   // MD5校验失败
        SDK_LOG(LOG_ERROR, "md5 check fail, p_md5:%s, header.md5:%s.\n", p_md5, s_ota.p_head_md5);
        return SDK_FAIL;
    }

    return SDK_OK;
}

/**
* @brief ota超时处理
* @param[in] arg              [超时回调参数]
*/
static void vesync_ota_timeout_cb(void *arg)
{
    //vesync_response_upgrade_status(UPG_TIME_OUT, 0);
    if (s_ota.upg_info.upg_type == UPG_TP_WIFI)
    { // 停止WiFi模块的升级
        vhal_ota_set_timeout_flag(true);
    }
    else
    {
#if (PR_OTA_TYPE_MCU > 0)
        vesync_ota_mcu_timeout_set();
#endif
        // stop mcu/ble ota process
    }

    SDK_LOG(LOG_INFO, "OTA timeout cb, type = %d\n", s_ota.upg_info.upg_type);
}

/**
 * @brief wifi 固件升级处理
 * @param[in]  url      [固件下载url]
 * @return  int         [成功：SDK_OK，失败：SDK_FAIL]
*/
static int vesync_ota_wifi_upgrade(char *url)
{
    // Wi-Fi固件升级前准备，回调给应用层进行特殊处理
    if (s_ota.upgrade_pre_cb)
    {
        s_ota.upgrade_pre_cb(false);
    }

    // 版本比较，判断是升级or降级
    bool dg_flag = false;
    if (vesync_ota_version_cmp(s_ota.upg_info.fw_ver, vesync_cfg_get_fw_version()) < 0) // 待升级的版本号 < 固件当前版本号
    {
        dg_flag = true;
        SDK_LOG(LOG_INFO, "Wi-Fi firmware downgrade\n");
    }

    int ret = vhal_ota_start(url, dg_flag); // 升级过程状态，在回调函数中进行更新
    if (VHAL_OK != ret)
    {
        SDK_LOG(LOG_ERROR, "OTA failed!\n");
        if (s_ota.upgrade_post_cb)          // 升级失败，回调给应用层处理
        {
            s_ota.upgrade_post_cb(false);
        }

        return SDK_FAIL;
    }

    SDK_LOG(LOG_INFO, "OTA success.\n");

    // 网络断开原因保存到flash
    if (s_ota.save_reconn_reason)
    {
#if CONFIG_VESYNC_SDK_PRODUCTION_ENABLE
        if (vesync_production_get_status() == PRODUCTION_RUNNING)
        {
            s_ota.save_reconn_reason(PRODUCTION_REASON);
        }
        else
        {
            s_ota.save_reconn_reason(UPGRADE_REASON);
        }
#else
        s_ota.save_reconn_reason(UPGRADE_REASON);
#endif
    }

    // 升级成功，回调给应用层处理
    if (s_ota.upgrade_post_cb)
    {
        s_ota.upgrade_post_cb(true);
    }

    // OTA成功，重启设备切换固件分区
    vesync_device_reboot();

    return SDK_OK;
}

#if CONFIG_VESYNC_SDK_HTTP_ENABLE
/**
 * @brief mcu 固件升级处理
 * @param[in]  url      [固件下载url]
 * @return  int         [成功：SDK_OK，失败：SDK_FAIL]
*/
static int vesync_ota_sub_device_upgrade(char *url)
{
    // 固件下载到flash
    int ret = -1;
    int recv_len = 10;
    char send_buf[10] = {0};
    char recv_buf[10] = {0};
    vesync_http_client_config_t http_cfg;
    http_cfg.url = url;
    vesync_http_client_init(&http_cfg);

    vesync_ota_response_upgrade_status(UPG_DOWNLOADING, 0);

    ret = vesync_http_request(HTTP_METHOD_GET, send_buf, recv_buf, &recv_len, HTTP_GET_OTA);
    if (ret != SDK_OK)
    {
        SDK_LOG(LOG_ERROR, "OTA http download fail.\n");
        vesync_ota_response_upgrade_status(UPG_DL_FAIL, 0);
        return SDK_FAIL;
    }

    SDK_LOG(LOG_DEBUG, "OTA http get firm len = %d.\n", recv_len);
    vesync_ota_response_upgrade_status(UPG_UPGRADING, 100); // 固件下载完成上报

#if PR_OTA_TYPE_BLE
    if (UPG_TP_BLE == s_ota.upg_info.upg_type)  // 升级BLE固件
    {
        SDK_LOG(LOG_DEBUG, "BLE ota.\n");
    }
#endif

#if (PR_OTA_TYPE_MCU > 0)
    if (mcu_need_ota()) // 升级MCU固件
    {
        if (s_ota.mcu_upgrade_pre_cb)
        {
            s_ota.mcu_upgrade_pre_cb();
        }

        uint8_t sw_ver[FW_VER_HEX_LEN]={3,2,1};
        uint32_t ver_val = version_to_hex(s_ota.upg_info.fw_ver);
        sw_ver[2] = (ver_val >> 16) & 0x00ff;
        sw_ver[1] = (ver_val >> 8) & 0x00ff;
        sw_ver[0] = ver_val & 0x00ff;

        //memcpy(sw_ver, s_upg_stat.fw_ver, FW_VERSION_HEX_LEN);
        vesync_ota_mcu_reg_state_cb(vesync_ota_mcu_state_cb);

        uint32_t err_code = vesync_ota_mcu_start(sw_ver,recv_len);
        if (0 != err_code)
        {
            SDK_LOG(LOG_ERROR, "OTA MCU fail.\n");
            vesync_ota_response_upgrade_status(err_code, 0);
        }
        else
        {
            SDK_LOG(LOG_INFO, "OTA MCU success.\n");
            vesync_ota_response_upgrade_status(UPG_SUCCESS, 100);
        }

        if (s_ota.mcu_upgrade_post_cb)  //调用回调函数，通知应用层
        {
            s_ota.mcu_upgrade_post_cb(err_code);
        }
    }
#endif

    return SDK_OK;
}
#endif

/**
 * @brief 检查网络状态
 * @return int      [成功：SDK_OK，失败：SDK_FAIL]
*/
static int vesync_ota_check_link_status(void)
{
    SDK_LOG(LOG_INFO, "Waiting Wi-Fi connected......\n");
    if (!vhal_wifi_get_link_status(5000))
    {
        SDK_LOG(LOG_INFO, "Wi-Fi connecte fail!\n");
        vesync_ota_response_upgrade_status(UPG_CONN_FAIL, 0);

#if (CONFIG_VESYNC_HAL_BLE_ENABLE && PR_OTA_TYPE_MCU > 0)
        SDK_LOG(LOG_INFO, "Try to use the ble....\n");
        if (vhal_ble_is_connected())
        {
            SDK_LOG(LOG_INFO, "OTA connect BLE success!\n");
            return SDK_OK;
        }
        else
        {
            SDK_LOG(LOG_ERROR, "OTA connect BLE failed!\n");
            vesync_ota_response_upgrade_status(UPG_FAIL, 0); // 上报BLE连接失败状态
        }
#endif
        return SDK_FAIL;
    }

    return SDK_OK;
}

/**
 * @brief ota任务处理
 * @param pvParameters   任务创建时传递的参数
 */
static void vesync_ota_task_handler(void *arg)
{
    int ret = -1;
    char url[MAX_URL_LEN] = {0};

    s_ota.timeout_timer = vesync_timer_new("ota_timer",
                                           vesync_ota_timeout_cb,
                                           NULL,
                                           OTA_TIMEOUT_TIME,
                                           false);
    if (s_ota.timeout_timer == NULL)
    {
        SDK_LOG(LOG_ERROR, "create ota timeout timer fail!!!\n");
        vesync_ota_response_upgrade_status(UPG_FAIL, 0);
        //VERR_UPLOAD(VERR_LINK_MOD_COM(VERR_TIMER_CREATE_FAIL), vhal_get_free_heap_size());
        goto exit;
    }

    ret = vesync_timer_start(s_ota.timeout_timer);
    if (ret != VOS_OK)
    {
        SDK_LOG(LOG_ERROR, "start ota timeout timer fail!!!\n");
        vesync_ota_response_upgrade_status(UPG_FAIL, 0);
        //VERR_UPLOAD(VERR_LINK_MOD_COM(VERR_TIMER_START_FAIL), UPG_FAIL);
        goto exit;
    }

    ret = vesync_ota_check_link_status();
    if (ret != SDK_OK)
    {
        goto exit;
    }

    snprintf(url, sizeof(url), "%s", (char *)arg); // 固件下载链接

    if (UPG_TP_WIFI == s_ota.upg_info.upg_type) // 升级Wi-Fi模块的固件
    {
        ret = vesync_ota_wifi_upgrade(url);
        if (ret == SDK_FAIL)
        {
            goto exit;
        }
    }
    else // 升级MCU/BLE的固件
    {
#if CONFIG_VESYNC_SDK_HTTP_ENABLE
        ret = vesync_ota_sub_device_upgrade(url);
        if (ret == SDK_FAIL)
        {
            goto exit;
        }
#endif
    }

exit:
    SDK_LOG(LOG_INFO, "vesync_ota_task delete....\n");
    vesync_timer_free(s_ota.timeout_timer);
    VCOM_SAFE_FREE(s_ota.p_head_md5);
    vesync_ota_clear(); // 清除标志位
}


/**
 * @brief  flash 密钥初始化
 * @return     int32_t              [错误码]
 */
static int32_t vesync_ota_security_init(void)
{
    mbedtls_md5_context *p_md5 = NULL;
    char *brand = (char *)brand_aes_key;

    p_md5 = (mbedtls_md5_context*)vesync_malloc(sizeof(mbedtls_md5_context) +1);
    if (NULL == p_md5)
    {
        return SDK_FAIL;
    }

    memset(s_ota_aes_key, 0, AES_KEY_LEN);
    memset(p_md5, 0, sizeof(mbedtls_md5_context) + 1);
    mbedtls_md5_init(p_md5);
#if !defined(MBEDTLS_DEPRECATED_REMOVED)
    mbedtls_md5_starts(p_md5);
#else
    mbedtls_md5_starts_ret(p_md5);
#endif
    mbedtls_md5_update(p_md5, (unsigned char *)brand, strlen(brand));
    mbedtls_md5_finish(p_md5, s_ota_aes_key);
    mbedtls_md5_free(p_md5);
    //LOG_RAW_HEX(LOG_INFO, "ota AES Key:", s_ota.aes_key, AES_KEY_LEN);
    VCOM_SAFE_FREE(p_md5);

    memcpy(s_ota_aes_iv, s_ota_aes_key, AES_KEY_LEN);
    return SDK_OK;
}

/*-----------------------------------------------------------------------------*
 *                                 外部函数实现                                  *
 *-----------------------------------------------------------------------------*/

/**
 * @brief OTA初始化
 */
void vesync_ota_init(void)
{
    memset(&s_ota, 0, sizeof(vesync_ota_t));
    s_ota.upg_info.upg_state = UPG_IDLE;
    s_ota.save_reconn_reason = vesync_net_flash_write_reconnect_reason;

    vesync_ota_security_init();

#if (CONFIG_VESYNC_SDK_HTTP_ENABLE && PR_OTA_TYPE_MCU > 0)
    vesync_ota_mcu_init();
#endif
}

/**
 * @brief 注册获取工作状态回调函数
 * @param[in] cb              [应用层获取工作状态回调函数]
 */
void vesync_ota_reg_get_status_cb(vesync_ota_get_status_cb_t cb)
{
    s_ota.get_status_cb = cb;
}

/**
 * @brief 注册升级前与升级后处理回调函数
 * @param[in] pre_cb          [升级前回调函数]
 * @param[in] post_cb         [升级失败后回调函数]
 */
void vesync_ota_reg_pre_post_cb(vesync_ota_pre_cb_t pre_cb, vesync_ota_post_cb_t post_cb)
{
    s_ota.upgrade_pre_cb= pre_cb;
    s_ota.upgrade_post_cb = post_cb;
}

#if (CONFIG_VESYNC_SDK_HTTP_ENABLE && PR_OTA_TYPE_MCU > 0)
/**
 * @brief 注册mcu固件升级结果回调函数
 * @param[in]                 [mcu固件升级结果回调函数]
 */
void vesync_ota_reg_mcu_pre_post_cb(vesync_ota_mcu_pre_cb_t pre_cb, vesync_ota_mcu_post_cb_t post_cb)
{
    s_ota.mcu_upgrade_pre_cb = pre_cb;
    s_ota.mcu_upgrade_post_cb = post_cb;
}
#endif


/**
 * @brief 获取升级错误码
 * @return uint8_t            [升级错误码]
 */
uint8_t vesync_ota_get_upgrade_code(void)
{
    return s_ota.upg_code;
}


/**
 * @brief 检测当前设备是否正在升级
 * @return bool                [正在升级，返回true；不在升级，返回false]
 */
bool vesync_ota_is_upgrading(void)
{
    return UPG_IDLE != s_ota.upg_info.upg_state;
}

/**
 * @brief 获取设备ota升级前的工作状态
 * @return  bool               [true:设备处于工作状态, false:设备不处于工作状态，或者OTA时不关心设备工作状态]
 */
bool vesync_ota_get_device_work_status(void)
{
    bool ret = false;

    if (s_ota.get_status_cb)
    {
        ret = s_ota.get_status_cb();
    }

    return ret;
}

/**
 * @brief 启动OTA
 * @param[in] upg_info              [升级信息]
 * @return int                      [成功/失败]
 */
int vesync_ota_start(upgrade_info_t upg_info)
{
    // 如果当前正处于升级过程，直接退出
    if (UPG_IDLE != s_ota.upg_info.upg_state)
    {
        SDK_LOG(LOG_ERROR, "Firmware is being upgraded!\n");
        return SDK_FAIL;
    }

    memset(&s_ota.upg_info, 0, sizeof(upgrade_info_t));
    s_ota.upg_info.upg_entry = upg_info.upg_entry;
    s_ota.upg_info.upg_type = upg_info.upg_type;
    s_ota.upg_info.upg_mode = upg_info.upg_mode;
    snprintf(s_ota.upg_info.fw_ver, sizeof(s_ota.upg_info.fw_ver), "%s", upg_info.fw_ver);
    snprintf(s_ota.upg_info.fw_url, sizeof(s_ota.upg_info.fw_url), "%s", upg_info.fw_url);

    // 判断当前设备是否支持OTA
    if (!vesync_ota_req_check())
    {
        SDK_LOG(LOG_ERROR, "This device is currently not upgradeable!!\n");
        // 通过ble/WiFi反馈不可升级状态。
        vesync_ota_response_upgrade_status(UPG_NOT_SUPT, 0);
        goto exit;
    }

    uint32_t  stop_work_tmout = 0;

    //设备工作中并且强制升级
    if ((UPG_MODE_HIGH == s_ota.upg_info.upg_mode) && (true == vesync_ota_get_device_work_status()))
    {
        if (s_ota.upgrade_pre_cb)
        {
            s_ota.upgrade_pre_cb(true);

            while (true == vesync_ota_get_device_work_status() && (stop_work_tmout < OTA_STOP_WORK_TIMEOUT/100))
            {
                vesync_sleep(100);
                stop_work_tmout++;
            }

            if (stop_work_tmout >= OTA_STOP_WORK_TIMEOUT/100)      //停止设备工作超时
            {
                vesync_ota_response_upgrade_status(UPG_NOT_SUPT, 0);
                goto  exit;
            }
        }
        else
        {
            SDK_LOG(LOG_INFO, "ota stop work cb not register!\n");
        }
    }

    // 注册HAL层OTA升级状态回调函数
    vhal_ota_status_reg_cb(vesync_ota_status_cb);              // 升级状态
    vhal_ota_check_header_reg_cb(vesync_ota_check_header, sizeof(vesync_ota_header_t) + 1);     // vesync固件头部校验(不包含md5校验)
    vhal_ota_check_md5_reg_cb(vesync_ota_check_md5);           // vesync固件头部md5与实际md5对比

    int ret = vesync_task_new(OTA_TASK_NAME, vesync_ota_clear, vesync_ota_task_handler, s_ota.upg_info.fw_url, OTA_TASK_STACKSIZE, OTA_TASK_PRIO, NULL);
    if (ret != VOS_OK)
    {
        SDK_LOG(LOG_ERROR, "create OTA task fail!\n");
        //TODO:FIXME
        //VERR_UPLOAD(VERR_TASK_CREATE_FAIL, vhal_get_free_heap_size());
        goto exit;
    }

    return SDK_OK;

exit:
    VCOM_SAFE_FREE(s_ota.p_head_md5);
    // 清除标志位
    vesync_ota_clear();
    return SDK_FAIL;
}


