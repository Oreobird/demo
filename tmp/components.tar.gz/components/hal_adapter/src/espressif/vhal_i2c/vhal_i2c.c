/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file       vhal_i2c.c
 * @brief      乐鑫平台的i2c读写接口
 * @author     Dongri.Su
 * @date       2021-04-22
 */

#include <stdio.h>

#include "driver/i2c.h"

#include "vesync_log.h"
#include "vesync_common.h"

#include "vhal_i2c.h"
#include "vhal_i2c_internal.h"

int32_t vhal_i2c_master_init(uint8_t i2c_num, uint8_t sda_io, uint8_t scl_io, uint32_t speed)
{
    uint8_t i2c_master_port = i2c_num;
    i2c_config_t conf;
    int32_t ret = VHAL_FAIL;

    conf.mode = I2C_MODE_MASTER;
    conf.sda_io_num = sda_io;
    conf.sda_pullup_en = GPIO_PULLUP_ENABLE;
    conf.scl_io_num = scl_io;
    conf.scl_pullup_en = GPIO_PULLUP_ENABLE;
#if !defined(CONFIG_IDF_TARGET_ESP8266)
    conf.master.clk_speed = speed;
#endif
    conf.clk_flags = I2C_SCLK_SRC_FLAG_FOR_NOMAL;

    if (i2c_param_config(i2c_master_port, &conf) != ESP_OK)
    {
        return VHAL_FAIL;
    }

#if defined(CONFIG_IDF_TARGET_ESP8266)
    ret = i2c_driver_install(i2c_master_port, conf.mode);
#else
    ret = i2c_driver_install(i2c_master_port, conf.mode,
                             I2C_MASTER_RX_BUF_DISABLE,
                             I2C_MASTER_TX_BUF_DISABLE, 0);
#endif
    return (ret != ESP_OK) ? VHAL_FAIL : VHAL_OK;
}

int32_t vhal_i2c_master_read(uint8_t i2c_num, bool check_ack, uint8_t addr, uint8_t *p_data, int32_t len)
{
    int32_t ret = ESP_FAIL;
    i2c_cmd_handle_t cmd = i2c_cmd_link_create();

    if ((0 == len) || (p_data == NULL))
    {
        goto exit;
    }

    if (i2c_master_start(cmd) != ESP_OK)
    {
        goto exit;
    }

    if (i2c_master_write_byte(cmd, addr, (true == check_ack) ? ACK_CHECK_EN : ACK_CHECK_DIS) != ESP_OK)
    {
        goto exit;
    }

    if (len > 1)
    {
        if (i2c_master_read(cmd, p_data, len - 1, ACK_VAL) != ESP_OK)
        {
            goto exit;
        }
    }

    if (i2c_master_read_byte(cmd, p_data + len - 1, NACK_VAL) != ESP_OK)
    {
        goto exit;
    }

    if (i2c_master_stop(cmd) != ESP_OK)
    {
        goto exit;
    }

    ret = i2c_master_cmd_begin(i2c_num, cmd, 1000 / portTICK_RATE_MS);
    
exit:
    i2c_cmd_link_delete(cmd);

    return (ret != ESP_OK) ? VHAL_FAIL : VHAL_OK;
}

int32_t vhal_i2c_master_write(uint8_t i2c_num, bool check_ack, uint8_t addr, uint8_t *p_data, int32_t len)
{
    int32_t ret = ESP_FAIL;

    i2c_cmd_handle_t cmd = i2c_cmd_link_create();

    if (i2c_master_start(cmd) != ESP_OK)
    {
        goto exit;
    }

    if (i2c_master_write_byte(cmd, addr, (true == check_ack) ? ACK_CHECK_EN : ACK_CHECK_DIS) != ESP_OK)
    {
        goto exit;
    }

    if (len > 0)
    {
        if (i2c_master_write(cmd, p_data, len, (true == check_ack) ? ACK_CHECK_EN : ACK_CHECK_DIS) != ESP_OK)
        {
            goto exit;
        }
    }

    if (i2c_master_stop(cmd) != ESP_OK)
    {
        goto exit;
    }

    ret = i2c_master_cmd_begin(i2c_num, cmd, 1000 / portTICK_RATE_MS);
    
exit:
    i2c_cmd_link_delete(cmd);

    return (ret != ESP_OK) ? VHAL_FAIL : VHAL_OK;
}

int32_t vhal_i2c_master_write_stop_condition(uint8_t i2c_num)
{
    int32_t ret = VHAL_FAIL;
    i2c_cmd_handle_t cmd = i2c_cmd_link_create();

    i2c_master_stop(cmd);
    i2c_master_stop(cmd); // 必须连续两个
    ret = i2c_master_cmd_begin(i2c_num, cmd, 1000 / portTICK_RATE_MS);
    i2c_cmd_link_delete(cmd);

    return (ret != ESP_OK) ? VHAL_FAIL : VHAL_OK;
}
