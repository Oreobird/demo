/**
 * Copyright © Vesync Technologies Co.Ltd. 2019-2021. All rights reserved.
 * @file    vesync_ffs.c
 * @brief   vesync平台与ffs SDK通信接口
 * @author  Dongri.Su
 * @date    20120-02-28
 */

#include "ffs/common/ffs_result.h"
#include "ffs/common/ffs_check_result.h"
#include "ffs/common/ffs_log_level.h"
#include "ffs/wifi_provisionee/ffs_wifi_provisionee_task.h"

#include "vesync_common.h"
#include "vesync_log_internal.h"
#include "vesync_task.h"
#include "vesync_sem.h"
#include "vesync_timer.h"
#include "vesync_memory.h"
#include "vhal_utils.h"

#include "vesync_ffs_internal.h"
#include "vesync_ffs_user_context.h"
#include "vesync_ffs_event.h"

#if CONFIG_VESYNC_SDK_HTTPS_ENABLE
#include "vesync_https_internal.h"
#endif
#include "vesync_net_mqtt_internal.h"
#include "vesync_wifi_led.h"
#include "ffs_flash.h"

//#if CONFIG_VESYNC_PLAT_BLE_SERVICE_ENABLE
//#include "vesync_ble_service.h"
//#endif
#include "ffs_pem_file.h"


// 全局变量/静态变量
static FfsUserContext_t s_user_ctx;
static FfsResultString_t s_ffs_result_str;

// 内部函数/静态函数声明
static vesync_timer_t *s_ffs_main_timer = NULL;          // 配网超时判断定时器

static net_info_t *p_ffs_cfg = NULL;                     // 配网数据(FFS配网)
static VESYNC_FFS_STATE_E s_ffs_state = VESYNC_FFS_INIT; // FFS状态

static bool s_ffs_running = false;                    // FFS 配网任务运行标志
static bool s_ffs_provisionee_running = false;           // FFS wifi provisionee运行标志


/*-----------------------------------------------------------------------------*
 *                                 内部函数实现                          *
 *-----------------------------------------------------------------------------*/

/**
 * @brief   取消FFS配网
 * @param[in]   manual_cancel               [true为手动取消；false为超时取消]
 */
static void vesync_ffs_cancel(bool manual_cancel)
{
    // 停止FFS状态机
    s_user_ctx.cancel = true;

    // 手动取消
    if (manual_cancel)
    {
        vesync_ffs_event_notify(EVENT_NETCFG_FORCE_EXIT);
    }
}

/**
 * @brief  FFS配网超时判断定时器回调函数
 * @param[in]  arg          [回调函数参数]
 * @return     [无]
 */
static void vesync_ffs_monitor_timeout_cb(void *arg)
{
    UNUSED(arg);
    vesync_ffs_cancel(false);
    vesync_ffs_event_notify(EVENT_NETCFG_TIMEOUT);
    vesync_timer_stop(s_ffs_main_timer);
}

/**
 * @brief 创建并启动FFS配网监控定时器
 * @param[in] out_time      [设置定时器超时时间，单位毫秒]
 * @return  int             [成功：SDK_OK，失败：SDK_FAIL]
 */
static int vesync_ffs_monitor_timer_start(uint32_t out_time)
{
    // 创建配FFS网超时定时器，单次模式
    s_ffs_main_timer = vesync_timer_new("ffs_main_timer",
                                        vesync_ffs_monitor_timeout_cb,
                                        NULL,
                                        1000,
                                        false);
    if (s_ffs_main_timer == NULL)
    {
        SDK_LOG(LOG_ERROR, "ffs timer create fail!!\n");
        return SDK_FAIL;
    }

    vesync_timer_change_period(s_ffs_main_timer, out_time);

    return SDK_OK;
}

/**
 * @brief 停止并删除FFS配网监控定时器
 */
static void vesync_ffs_monitor_timer_stop(void)
{
    vesync_timer_free(s_ffs_main_timer);
}


/**
 * @brief   设置sessionToken
 * @param[in]  userContext     用户定义数据
 * @return  none
 */
static void vesync_ffs_set_session_token(FfsUserContext_t *userContext)
{
    if (!userContext)
    {
        ffsLogError("input params find NULL");
        return;
    }
    uint32_t len = 0;
    char *pString = NULL;

    if (s_ffs_result_str.sessionToken)
    {
        VCOM_SAFE_FREE(s_ffs_result_str.sessionToken);
    }

    len = strlen(userContext->sessoinToken);
    if (len)
    {
        pString = (char *)vesync_malloc(len + 1);
        if (pString)
        {
            s_ffs_result_str.sessionToken = pString;
            memcpy(s_ffs_result_str.sessionToken, userContext->sessoinToken, len);
            s_ffs_result_str.sessionToken[len] = 0;
        }

        SDK_LOG(LOG_DEBUG, "sessionToken: %s ", userContext->sessoinToken);
    }
}

/**
 * @brief   设置sessionId
 * @param   char* session   sessionID字符串
 * @param   uint8_t len     字符串长度
 * @return  none
 */
static void vesync_ffs_make_signature(FfsUserContext_t *userContext)
{
    if (!userContext)
    {
        ffsLogError("input params find NULL");
        return;
    }

    unsigned char buf[128] = {0};
    unsigned char len = 0;

    if (s_ffs_result_str.sessionToken)
    {
        len = vesync_ffs_sign_from_sessionToken(&userContext->devicePrivateKey,
                                                &userContext->devicePublicKey,
                                                s_ffs_result_str.sessionToken,
                                                buf);
        if (len)
        {
            char *pString = (char *)vesync_malloc(len + 1);
            if (pString)
            {
                s_ffs_result_str.signature = pString;
                memcpy(s_ffs_result_str.signature, buf, len);
                s_ffs_result_str.signature[len] = 0;
            }
        }
    }
}

/**
 * @brief   保存AlexaEventGatewayEndpoint(区分不同地区)
 * @param[in]  userContext   用户定义数据
 * @return  none
 * @note (1) LanguageLocale:"en_GB" AlexaEventGatewayEndpoint":"api.eu.amazonalexa.com";
 *       (2) LanguageLocale:"en_JP" AlexaEventGatewayEndpoint":"api.fe.amazonalexa.com"
 *       (3) LanguageLocale:"en_US" AlexaEventGatewayEndpoint":"api.amazonalexa.com"
 */
static void vesync_ffs_set_alexaEvtGwEp(FfsUserContext_t *userContext)
{
    if (!userContext)
    {
        ffsLogError("input params find NULL");
        return;
    }
    uint32_t len = 0;
    char *pString = NULL;

    if (s_ffs_result_str.alexaEvtGwEp)
    {
        VCOM_SAFE_FREE(s_ffs_result_str.alexaEvtGwEp);
    }

    len = strlen(userContext->alexaEvtGwEp);
    if (len)
    {
        pString = (char *)vesync_malloc(len + 1);
        if (pString)
        {
            s_ffs_result_str.alexaEvtGwEp = pString;
            memcpy(s_ffs_result_str.alexaEvtGwEp, userContext->alexaEvtGwEp, len);
            s_ffs_result_str.alexaEvtGwEp[len] = 0;
        }
        SDK_LOG(LOG_DEBUG, "alexaEvtGwEp = %s.\n", userContext->alexaEvtGwEp);
    }
}

/**
 * @brief  FFS扫描wifi列表
 * @return VESYNC_FFS_STATE_E       [ffs配网状态]
 */
static void vesync_ffs_wifi_aplist_scan(void)
{
    vhal_wifi_reg_netcfg_cb(vesync_ffs_aplist_add_hal_cb, NULL);
    vesync_ffs_aplist_scan();
}

/*-----------------------------------------------------------------------------*
 *                                 外部函数实现                          *
 *-----------------------------------------------------------------------------*/
/**
 * @brief  FFS获取配网信息指针
 * @return net_info_t *         [配网信息指针]
 */
net_info_t *vesync_ffs_get_cfg(void)
{
    return p_ffs_cfg;
}

/**
 * @brief  FFS获取配网状态
 * @return VESYNC_FFS_STATE_E       [ffs配网状态]
 */
VESYNC_FFS_STATE_E vesync_ffs_get_state(void)
{
    return s_ffs_state;
}

/**
 * @brief  FFS设置配网状态
 * @param[in]  state      [ffs配网状态]
 */
void vesync_ffs_set_state(VESYNC_FFS_STATE_E state)
{
    s_ffs_state = state;
}

/**
 * @brief  获取FFS Result string
 * @return FfsResultString_t       [ffs result string]
 */
FfsResultString_t vesync_ffs_get_result_string(void)
{
    return s_ffs_result_str;
}

/**
 * @brief   是否处于ffs配网
 * @return  bool                 [true：FFS配网中；false：非FFS配网中]
 */
bool vesync_ffs_is_running(void)
{
    return s_ffs_running;
}

/**
 * @brief 结束FFS配网时清理和重置
 */
void vesync_ffs_exit(void)
{
    VCOM_SAFE_FREE(p_ffs_cfg);
    VCOM_SAFE_FREE(s_ffs_result_str.signature);
    VCOM_SAFE_FREE(s_ffs_result_str.sessionToken);
    VCOM_SAFE_FREE(s_ffs_result_str.alexaEvtGwEp);

    vhal_wifi_unreg_netcfg_cb();
    vesync_ffs_aplist_clear();
    vesync_ffs_monitor_timer_stop();

    // 之前这段时间窗口期间产生的MQTT重连消息会传递到vesync_event_center_thread().
    s_ffs_running = false;
}

/**
 * @brief   进入FFS配网模式，并进行MQTT连接、订阅
 * @return  int                 [成功/失败]
 */
int vesync_ffs_start_netcfg(void)
{
    int ret = FFS_ERROR;

    SDK_LOG(LOG_INFO, "start ffs netcfg.\n");

    FFS_PRINT_FREE_HEAP();

    // 读取FFS产测标志位，及是否已使用过的标志位，判断是否继续FFS配网
    ffs_result_flash_data_t fss_result;

    // Initialize the user context.
    ret = ffsInitializeUserContext(&s_user_ctx);
    if (FFS_SUCCESS != ret)
    {
        SDK_LOG(LOG_ERROR, "Init FFS user context fail!!!\n");
        return SDK_FAIL;
    }

    s_ffs_running = true;

    // 初始化配网结构体
    p_ffs_cfg = vesync_malloc(sizeof(net_info_t));
    if (NULL == p_ffs_cfg)
    {
        SDK_LOG(LOG_ERROR, "No memory for ffs netcfg task!\n");
        ffsDeinitializeUserContext(&s_user_ctx);
        return SDK_FAIL;
    }

    memset(p_ffs_cfg, 0, sizeof(net_info_t));

    // 创建定时器
    if (SDK_OK != vesync_ffs_monitor_timer_start(MAX_FFS_NETCFG_TIME_MS))
    {
        SDK_LOG(LOG_ERROR, "Create FFS timer monitor fail!!!\n");
        VCOM_SAFE_FREE(p_ffs_cfg);
        ffsDeinitializeUserContext(&s_user_ctx);
        return SDK_FAIL;
    }

    // 订阅事件
    ret = vesync_ffs_event_init();
    if (ret != SDK_OK)
    {
        SDK_LOG(LOG_ERROR, "Subscribe FFS events fail!\n");
        vesync_ffs_monitor_timer_stop();
        VCOM_SAFE_FREE(p_ffs_cfg);
        ffsDeinitializeUserContext(&s_user_ctx);
        return SDK_FAIL;
    }

    // 扫描Wi-Fi列表
    vesync_ffs_wifi_aplist_scan();

    // 记录状态
    vesync_net_mgmt_set_reconnect_reason(CONFIG_NET_REASON);

    SDK_LOG(LOG_DEBUG, "Waiting for FFS WiFi list scan done!!!\n");
    vesync_ffs_event_wait_for_wifi_scan();

    vesync_ffs_set_state(VESYNC_FFS_INIT);
    vesync_wifi_led_set_behavior(WIFI_LED_FFS_CONFIGING); // Wi-Fi灯效

    // Execute the Wi-Fi provisionee task.
    s_ffs_provisionee_running = true; //设ffs流程开始标志
    ret = ffsWifiProvisioneeTask(&s_user_ctx);
    s_ffs_provisionee_running = false; //设ffs流程结束标志

    if ((FFS_SUCCESS != ret) || (s_user_ctx.cancel) ||
        (!s_user_ctx.setupNetworkSsid) || (!s_user_ctx.userNetworkSsid) ||
        (0 == strcmp(s_user_ctx.setupNetworkSsid, s_user_ctx.userNetworkSsid)))
    {
        SDK_LOG(LOG_ERROR, "FFS fail!!!\n");
        vesync_ffs_event_notify(EVENT_NETCFG_TIMEOUT); // FFS失败，退出任务
        vesync_ffs_monitor_timer_stop();

        ffsDeinitializeUserContext(&s_user_ctx);  // Deinitialize the user context.
        vesync_https_finish_and_destroy();  //https release after keep-alive action
        vesync_ffs_event_deinit();
        return SDK_FAIL;
    }

    // 保存配置，用于MQTT连接
    vesync_ffs_set_session_token(&s_user_ctx);
    vesync_ffs_set_alexaEvtGwEp(&s_user_ctx);
    vesync_ffs_make_signature(&s_user_ctx);

    SDK_LOG(LOG_DEBUG, "FFS backup serverDN %s \n", VESYNC_FFS_SERV_NAME);

    // FFS成功，保存Wi-Fi信息和MQTT信息到结构体中
    p_ffs_cfg->serverPort = MQTT_DEFAULT_PORT;
    snprintf((char *)p_ffs_cfg->serverDN, 64, "%s", VESYNC_FFS_SERV_NAME); // MQTT

    if (s_user_ctx.userNetworkSsid)
    {
        snprintf((char *)p_ffs_cfg->wifiSSID, WIFI_SSID_MAX_LEN, "%s", s_user_ctx.userNetworkSsid); // Wi-Fi ssid
        SDK_LOG(LOG_DEBUG, "FFS backup ssid:  %s \n", p_ffs_cfg->wifiSSID);
    }

    if (s_user_ctx.userNetworkPsk && strlen(s_user_ctx.userNetworkPsk))
    {
        snprintf((char *)p_ffs_cfg->wifiPassword, WIFI_PWD_MAX_LEN, "%s", s_user_ctx.userNetworkPsk); //Wi-Fi password
        SDK_LOG(LOG_DEBUG, "FFS backup password:  %s \n", p_ffs_cfg->wifiPassword);
    }

    // 释放空间
    ffsDeinitializeUserContext(&s_user_ctx); // Deinitialize the user context.

    vesync_https_finish_and_destroy(); //https release after keep-alive action

    // 通知ffs进行MQTT连接
    vesync_ffs_event_notify(EVENT_NETCFG_RECEIVE_CONFIG);


    // 等待MQTT连接，最长等待时间由MAX_FFS_NETCFG_TIME_MS确定
    while (1)
    {
        if (VESYNC_FFS_SUCC == vesync_ffs_get_state())
        {
            SDK_LOG(LOG_DEBUG, "vesync_ffs_get_state_SUCC \n");
            ret = SDK_OK;
            fss_result.magic = FFS_RESULT_MAGIC;
            fss_result.result = true;
            vesync_ffs_flash_write_result_data(&fss_result);
            vesync_ffs_event_deinit();
            break;
        }
        else if (VESYNC_FFS_FAIL == vesync_ffs_get_state())
        {
            SDK_LOG(LOG_DEBUG, "vesync_ffs_get_state_FAIL \n");
            vesync_ffs_event_deinit();
            ret = SDK_FAIL;
            break;
        }

        vesync_sleep(250);
    }

    FFS_PRINT_FREE_HEAP();
    return ret;
}


/**
 * @brief   清除ffs配网及APP配网结果，使设备可以重复进入ffs
 */
void vesync_ffs_result_clean(void)
{
    vesync_ffs_flash_clear_result_data();
    vesync_ffs_delete_net_cfg_data();
}

/**
 * @brief   结束FFS配网并关闭配网进程, 此接口开放给应用层调用
 * @return  int    [SDK_OK    停止配网成功
 *                  SDK_FAIL  停止配网失败，但也可能配网进程修改状态延时，可再尝试调用]
 */
int vesync_ffs_stop(void)
{
    vesync_ffs_cancel(true);
    uint32_t wait_cnt = 0;

    SDK_LOG(LOG_DEBUG, " stop ffs task.\n");

    /* wait for ffs STOP and netcfg task exit. */
    while (s_ffs_provisionee_running || s_ffs_running)
    {
        vesync_sleep(100);
        wait_cnt++;
        if (wait_cnt > 100) //最长等待10秒
            break;
    }
    return s_ffs_running ? SDK_OK : SDK_FAIL;
}

/**
 * @brief  检查ffs配网功能是否有效, 配网成功后即失效
 * @return  int  SDK_OK FFS配网功能有效, SDK_FAIL FFS配网功能失效
 */
int vesync_ffs_is_active(void)
{
    int ret = SDK_OK;
    uint32_t len = 0;

    ffs_result_flash_data_t fss_result;

    len = sizeof(ffs_result_flash_data_t);
    if (vesync_ffs_flash_read_result_data(&fss_result, &len) == SDK_OK)
    {
        if ((FFS_RESULT_MAGIC == fss_result.magic) && (true == fss_result.result))
        {
            ret = SDK_FAIL;
        }
    }

    SDK_LOG(LOG_DEBUG, "FFS is %s\n", ret == SDK_OK ? "active" : "not active");

#if (FFS_CA_DEBUG == 0)
    int read_len = 0;
    if (vesync_ffs_flash_read_cert_chain(NULL, &read_len) == SDK_FAIL) //FFS证书不存在
    {
        SDK_LOG(LOG_DEBUG, "ffs cert chain not exist\n");
        return SDK_FAIL;
    }

    if (vesync_ffs_flash_read_dha_private_key(NULL, &read_len) == SDK_FAIL) //FFS私钥不存在
    {
        SDK_LOG(LOG_DEBUG, "ffs dha private key not exist\n");
        return SDK_FAIL;
    }
#endif

    return ret;
}

/**
 * @brief  ffs配网功能失能
 * @return  int  SDK_OK 成功, SDK_FAIL 失败
 */
int vesync_ffs_disable(void)
{
    ffs_result_flash_data_t fss_result;
    fss_result.magic = FFS_RESULT_MAGIC;
    fss_result.result = true;
    int ret = vesync_ffs_flash_write_result_data(&fss_result);
    return ret;
}
