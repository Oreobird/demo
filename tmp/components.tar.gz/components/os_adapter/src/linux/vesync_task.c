/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_task.c
 * @brief       task抽象层，封装linux posix任务相关接口
 * @author      Joshua
 * @date        2021-04-20
 */

#include <string.h>
#include <unistd.h>
#include <stdbool.h>
#include <stdlib.h>
#include <signal.h>
#include <pthread.h>
#include <sys/prctl.h>
#include <stdio.h>
#include "vesync_memory.h"
#include "vesync_common.h"
#include "vesync_os.h"
#include "vesync_task.h"
#include <time.h>
#include "vesync_list.h"

#define VESYNC_TASK_NAME_MAX_LEN (16) //PR_SET_NAME最长支持16bytes的名称

/*
 * @brief  任务管理链表节点
 */
typedef struct
{
    void (*exit_fn)(void);
    struct list_head list;
} task_node_t;

/*
 * @brief  任务管理结构体
 */
typedef struct
{
    bool inited;
    pthread_mutex_t mutex;
    struct list_head list;
} task_mgmt_t;

static task_mgmt_t s_task_mgmt;

/*
 * @brief  任务入口函数参数结构体
 */
typedef struct
{
    char name[VESYNC_TASK_NAME_MAX_LEN];
    void (*exit_fn)(void);
    void (*fn)(void *);
    void *arg;
} targ_t;

/*
 * @brief  运行退出函数
 */
static void task_exit_fn_run(void (*exit_fn)(void))
{
    task_node_t *pos, *n;
    struct list_head *head = &s_task_mgmt.list;

    pthread_mutex_lock(&s_task_mgmt.mutex);
    list_for_each_entry_safe(pos, n, head, list)
    {
        if (pos->exit_fn == exit_fn)
        {
            pos->exit_fn();
            list_del(&pos->list);
            INIT_LIST_HEAD(&pos->list);
            VCOM_SAFE_FREE(pos);
        }
    }
    pthread_mutex_unlock(&s_task_mgmt.mutex);
}

/*
 * @brief  任务函数执行入口
 */
static void *task_entry(void *arg)
{
    targ_t *targ = arg;
    void (*exit_fn)(void) = targ->exit_fn;
    void (*fn)(void *) = targ->fn;
    void *farg = targ->arg;

    if (targ->name != NULL)
    {
        prctl(PR_SET_NAME, (unsigned long)targ->name, 0, 0, 0);
    }

    fn(farg);

    if (exit_fn)
    {
        task_exit_fn_run(exit_fn);
    }

    VCOM_SAFE_FREE(targ);

    return 0;
}


/*
 * @brief  信号处理函数
 * @param[in] signal        [信号码]
 */
static void task_signal_handle(int signal)
{
    UNUSED(signal);

    task_node_t *pos, *n;
    struct list_head *head = &s_task_mgmt.list;
    list_for_each_entry_safe(pos, n, head, list)
    {
        if (pos->exit_fn)
        {
            pos->exit_fn();
            list_del(&pos->list);
            INIT_LIST_HEAD(&pos->list);
            VCOM_SAFE_FREE(pos);
        }
    }

    exit(0);
}

/*
 * @brief  信号处理初始化
 * @param[in] exit_fnl        [退出回调指针]
 */
static void task_signal_init(void (*exit_fn)(void))
{
    if (exit_fn == NULL)
    {
        return;
    }

    if (!s_task_mgmt.inited)
    {
        memset(&s_task_mgmt, 0, sizeof(task_mgmt_t));
        INIT_LIST_HEAD(&s_task_mgmt.list);
        s_task_mgmt.inited = true;
        pthread_mutex_init(&s_task_mgmt.mutex, NULL);
    }

    task_node_t *node = (task_node_t *)vesync_malloc(sizeof(task_node_t));
    if (node == NULL)
    {
        return;
    }

    node->exit_fn = exit_fn;
    pthread_mutex_lock(&s_task_mgmt.mutex);
    list_add_tail(&node->list, &(s_task_mgmt.list));
    pthread_mutex_unlock(&s_task_mgmt.mutex);

    struct sigaction act;
    act.sa_handler = task_signal_handle;
    sigemptyset(&act.sa_mask);
    act.sa_flags = 0;

    sigaction(SIGINT, &act, NULL);
    sigaction(SIGTERM, &act, NULL);
}


int vesync_task_new(const char *name,
                          void (*exit_fn)(void),
                          void (*fn)(void *),
                          void *arg,
                          int stack_size,
                          int prio,
                          vesync_task_t *task)
{
    UNUSED(stack_size);
    UNUSED(prio);

    VCOM_NULL_PARAM_CHK(fn, return VOS_FAIL);

    int ret = VOS_OK;
    pthread_t task_id;

    if (fn == NULL)
    {
        return VOS_FAIL;
    }

    targ_t *targ = (targ_t *)vesync_calloc(1, sizeof(targ_t));
    if (targ == NULL)
    {
        return VOS_FAIL;
    }

    if (name != NULL)
    {
        strncpy(targ->name, name, sizeof(targ->name) - 1);
    }

    targ->exit_fn = exit_fn;
    targ->fn = fn;
    targ->arg = arg;

    task_signal_init(exit_fn);

    ret = pthread_create(&task_id, NULL, task_entry, targ);
    if (ret != 0)
    {
        VCOM_SAFE_FREE(targ);
        return VOS_FAIL;
    }

    pthread_detach(task_id);

    if (task)
    {
        *task = (vesync_task_t)task_id;
    }

    return ret;
}


const char *vesync_task_name(void)
{
    static char name[VESYNC_TASK_NAME_MAX_LEN];
    prctl(PR_GET_NAME, (unsigned long)name, 0, 0, 0);
    return name;
}

uint64_t vesync_task_get_max_tick_ms(void)
{
    uint64_t max_tick_ms = 0xFFFFFFFF * 1000 / sysconf(_SC_CLK_TCK);
    return max_tick_ms;
}

uint64_t vesync_task_get_tick_ms(void)
{
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (uint64_t)(ts.tv_nsec / 1000000) + ((uint64_t)ts.tv_sec * 1000);
}

vesync_task_t vesync_task_get_curr_handle(void)
{
    return NULL;
}