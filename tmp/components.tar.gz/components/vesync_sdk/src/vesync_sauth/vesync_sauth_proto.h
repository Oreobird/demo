/**
 * Copyright © Vesync Technologies Co.Ltd. 2022. All rights reserved.
 * @file        vesync_sauth_proto.h
 * @brief       Vesync SAUTH模块的协议定义
 * @author      Herve
 * @date        2022-01-07
 */
#ifndef __VESYNC_SAUTH_PROTO_H__
#define __VESYNC_SAUTH_PROTO_H__

#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>

#include "vesync_sauth_private.h"

#ifdef __cplusplus
extern "C"
{
#endif

#define SAUTH_PROTOCOL_VERSION (0x0100)                      // Vesync Sauth协议版本
#define SAUTH_CMD_HELLO (0x10)                               // 命令码：HELLO
#define SAUTH_CMD_REG_TYPE (0x20)                            // 注册类型命令Base
#define SAUTH_CMD_REG_START (SAUTH_CMD_REG_TYPE + 1)         // 命令码：REG_START
#define SAUTH_CMD_REG_SUCCESS (SAUTH_CMD_REG_TYPE + 2)       // 命令码：REG_SUCCESS
#define SAUTH_CMD_REG_FAIL (SAUTH_CMD_REG_TYPE + 3)          // 命令码：REG_FAIL
#define SAUTH_CMD_REG_INVLD_CERT (SAUTH_CMD_REG_TYPE + 4)    // 命令码：REG_INVLD_CERT
#define SAUTH_CMD_REG_VERIFY_FAIL (SAUTH_CMD_REG_TYPE + 5)   // 命令码：REG_VERIFY_FAIL
#define SAUTH_CMD_LOGIN_TYPE (0x30)                          // 登录类型命令Base
#define SAUTH_CMD_LOGIN_START (SAUTH_CMD_LOGIN_TYPE + 1)     // 命令码：LOGIN_START
#define SAUTH_CMD_LOGIN_SUCCESS (SAUTH_CMD_LOGIN_TYPE + 2)   // 命令码：LOGIN_SUCCESS
#define SAUTH_CMD_LOGIN_FAIL (SAUTH_CMD_LOGIN_TYPE + 3)      // 命令码：LOGIN_FAIL
#define SAUTH_CMD_LOGIN_ALREADY (SAUTH_CMD_LOGIN_TYPE + 4)   // 命令码：LOGIN_ALREADY
#define SAUTH_CMD_LOGIN_LTK_RJT (SAUTH_CMD_LOGIN_TYPE + 5)   // 命令码：LOGIN_LTK_RJT
#define SAUTH_CMD_INFO_TYPE (0x40)                           // 信息数据类型命令Base
#define SAUTH_CMD_INFO_DEV (SAUTH_CMD_INFO_TYPE + 1)         // 命令码：INFO_DEV
#define SAUTH_CMD_INFO_DEV_CERT (SAUTH_CMD_INFO_TYPE + 2)    // 命令码：INFO_DEV_CERT
#define SAUTH_CMD_INFO_APP_CERT (SAUTH_CMD_INFO_TYPE + 3)    // 命令码：INFO_APP_CERT
#define SAUTH_CMD_INFO_DEV_PK (SAUTH_CMD_INFO_TYPE + 4)      // 命令码：INFO_DEV_PK
#define SAUTH_CMD_INFO_APP_PK (SAUTH_CMD_INFO_TYPE + 5)      // 命令码：INFO_APP_PK
#define SAUTH_CMD_INFO_DEV_SIGN (SAUTH_CMD_INFO_TYPE + 6)    // 命令码：INFO_DEV_SIGN
#define SAUTH_CMD_INFO_APP_SIGN (SAUTH_CMD_INFO_TYPE + 7)    // 命令码：INFO_APP_SIGN
#define SAUTH_CMD_INFO_LOGIN_TOKEN (SAUTH_CMD_INFO_TYPE + 8) // 命令码：INFO_LOGIN_TOKEN

/**
 * @brief SAUTH加密套件列表
 * @note    1、SAUTH_CIPER_SUIT_XXX_REG_ECDSA_LOG_AES_128_CBC_SHA256
 *              XXX: 密钥交换算法
 *          2、SAUTH_CIPER_SUIT_ECDHE_REG_XXX_LOG_AES_128_CBC_SHA256
 *              XXX: 身份验证算法
 *          3、SAUTH_CIPER_SUIT_ECDHE_REG_ECDSA_LOG_XXX_SHA256
 *              XXX: 对称加密算法
 *          4、SAUTH_CIPER_SUIT_ECDHE_REG_ECDSA_LOG_AES_128_CBC_XXX
 *              XXX: 信息摘要算法
 */
// 空加密套件，意味着不做任何的加密认证
#define SAUTH_CIPER_SUIT_NONE_REG_NONE_LOG_NONE_NONE (0x00)
// 用ECDHE和ECDSA完成注册流程，不支持登录流程，意味着注册通过后，不进行后继加密流程
#define SAUTH_CIPER_SUIT_ECDHE_REG_ECDSA_LOG_NONE_SHA256 (0x01)
// 不支持注册流程，直接用ECDHE完成登录流程获得会话密钥，用AES128-CCM进行后继的加密认证。该方式需要有默认长期密钥。
#define SAUTH_CIPER_SUIT_ECDHE_REG_NONE_LOG_AES_128_CCM_SHA256 (0x02)
// 用ECDHE和ECDSA完成注册流程，后用ECDHE完成登录流程获得会话密钥，用AES128-CCM进行后继的加密认证
#define SAUTH_CIPER_SUIT_ECDHE_REG_ECDSA_LOG_AES_128_CCM_SHA256 (0x03)

#define SAUTH_OOB_CAPABILITY_NO_WAY (0x00)           // 不支持任何OOB的方式
#define SAUTH_OOB_CAPABILITY_DISPLAY_ONLY (0x01)     // 支持只显示数值OOB信息的方式
#define SAUTH_OOB_CAPABILITY_DISPLAY_YES_NO (0x02)   // 支持只显示是否二值OOB信息的方式
#define SAUTH_OOB_CAPABILITY_KEYBOARD_ONLY (0x03)    // 支持只输入数值OOB信息的方式
#define SAUTH_OOB_CAPABILITY_KEYBOARD_DISPLAY (0x04) // 支持输入数值OOB信息并且显示出来的方式

#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_SAUTH_PROTO_H__ */