/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_bypass_cooking.c
 * @brief       bypass处理接口
 * @date        2021-05-17
 */
#include <string.h>

#include "vesync_common.h"
#include "vesync_memory.h"

#include "vesync_log_internal.h"
#include "vesync_bypass_internal.h"

/**
 * @brief 获取烤箱状态函数
 * @param p_trace_msg trace message
 * @param json数据指针
 * @return BYPASS_ERR_E
 */
static BYPASS_ERR_E bypass_method_get_oven_status_handle(bypass_trace_msg_t *p_trace_msg, cJSON *json)
{
    UNUSED(json);
    if (NULL == p_trace_msg)   return BP_ERROR;
    BYPASS_ERR_E ret = BP_OK;
    //查询无需解析json
    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_GET_OVEN_STATUS);
    if (method_cb)
    {
        bool new_mothad = false;        //false 表示原接口，非V2 "getOvenStatus"
        method_cb(p_trace_msg, (void*)&new_mothad, sizeof(bool));
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

    return ret;
}

/**
 * @brief 获取烤箱状态函数(多段烹饪)
 * @param p_trace_msg trace message
 * @param json数据指针
 * @return BYPASS_ERR_E
 */
static BYPASS_ERR_E bypass_method_get_oven_status_v2_handle(bypass_trace_msg_t *p_trace_msg, cJSON *json)
{
    UNUSED(json);
    if (NULL == p_trace_msg)   return BP_ERROR;
    BYPASS_ERR_E ret = BP_OK;
    //查询无需解析json
    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_GET_OVEN_STATUS_V2);
    if (method_cb)
    {
        bool new_mothad = true;     //true 表示V2新接口 "getOvenStatusV2"
        SDK_LOG(LOG_DEBUG,"getOvenStatusV2 method_cb true\r\n");
        method_cb(p_trace_msg, (void*)&new_mothad, sizeof(bool));
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

    return ret;
}

/**
 * @brief 确认烹饪结束
 * @param p_trace_msg trace message
 * @param json数据指针
 * @return BYPASS_ERR_E
 */
static BYPASS_ERR_E bypass_method_confirm_cook_end_handle(bypass_trace_msg_t *p_trace_msg, cJSON *json)
{
    UNUSED(json);
    if (NULL == p_trace_msg)   return BP_ERROR;
    BYPASS_ERR_E ret = BP_OK;
    //查询无需解析json
    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_CONFIRM_COOK_END);
    if (method_cb)
    {
        method_cb(p_trace_msg, NULL, 0);
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

    return ret;
}

/**
 * @brief 获取烹饪模式的值
 * @param valuestring  模式字符
 * @param mode 获取到的模式状态
 * @return BYPASS_ERR_E
 */
BYPASS_ERR_E bypass_mode_string_handle(char* valuestring, BP_OVEN_MODE_E* mode)
{
    BYPASS_ERR_E ret = BP_OK;
    if (!valuestring || !mode)
    {
        return BP_ERR_ARG;
    }

    if (strcmp(valuestring, "Toast") == 0)
    {
        *mode = BP_OVEN_MODE_TOAST;
    }
    else if (strcmp(valuestring, "Bagel") == 0)
    {
        *mode = BP_OVEN_MODE_BAGEL;
    }
    else if (strcmp(valuestring, "Pizza") == 0)
    {
        *mode = BP_OVEN_MODE_PIZZA;
    }
    else if (strcmp(valuestring, "Bake") == 0)
    {
        *mode = BP_OVEN_MODE_BAKE;
    }
    else if (strcmp(valuestring, "Roast") == 0)
    {
        *mode = BP_OVEN_MODE_ROAST;
    }
    else if (strcmp(valuestring, "Broil") == 0)
    {
        *mode = BP_OVEN_MODE_BROIL;
    }
    else if (strcmp(valuestring, "Cookies") == 0)
    {
        *mode = BP_OVEN_MODE_COOKIES;
    }
    else if (strcmp(valuestring, "Rotisserie") == 0)
    {
        *mode = BP_OVEN_MODE_ROTISSERIE;
    }
    else if (strcmp(valuestring, "Fermentation") == 0)
    {
        *mode = BP_OVEN_MODE_FERMENTATION;
    }
    else if (strcmp(valuestring, "Warm") == 0)
    {
        *mode = BP_OVEN_MODE_WARM;
    }
    else if (strcmp(valuestring, "Dehydrate") == 0)
    {
        *mode = BP_OVEN_MODE_DEHYDRATE;
    }
    else if (strcmp(valuestring, "AirFry") == 0)
    {
        *mode = BP_OVEN_MODE_AIRFRY;
    }
    else if (strcmp(valuestring, "Steak") == 0)
    {
        *mode = BP_OVEN_MODE_STEAK;
    }
    else if (strcmp(valuestring, "Chicken") == 0)
    {
        *mode = BP_OVEN_MODE_CHICKEN;
    }
    else if (strcmp(valuestring, "Seafood") == 0)
    {
        *mode = BP_OVEN_MODE_SEAFOOD;
    }
    else if (strcmp(valuestring, "Bacon") == 0)
    {
        *mode = BP_OVEN_MODE_BACON;
    }
    else if (strcmp(valuestring, "Frozen") == 0)
    {
        *mode = BP_OVEN_MODE_FROZEN;
    }
    else if (strcmp(valuestring, "French fries") == 0)
    {
        *mode = BP_OVEN_MODE_FRENCH_FRIES;
    }
    else if (strcmp(valuestring, "Vegetables") == 0)
    {
        *mode = BP_OVEN_MODE_VEGETABLES;
    }
    else if (strcmp(valuestring, "Shrimp") == 0)
    {
        *mode = BP_OVEN_MODE_SHRIMP;
    }
    else if (strcmp(valuestring, "Custom") == 0)
    {
        *mode = BP_OVEN_CUSTOM;
    }
    else if (strcmp(valuestring, "Poultry") == 0)
    {
        *mode = BP_OVEN_MODE_POULTRY;
    }
    else if (strcmp(valuestring, "Desserts") == 0)
    {
        *mode = BP_OVEN_MODE_DESSERTS;
    }
    else if (strcmp(valuestring, "Bread") == 0)
    {
        *mode = BP_OVEN_MODE_BREAD;
    }
    else if (strcmp(valuestring, "RootVeggies") == 0)
    {
        *mode = BP_OVEN_MODE_ROOTVEGGIES;
    }
    else if (strcmp(valuestring, "CoolDown") == 0)
    {
        *mode = BP_OVEN_MODE_COOLDOWN;
    }
    else if (strcmp(valuestring, "SlowCook") == 0)
    {
        *mode = BP_OVEN_MODE_SLOWCOOK;
    }
    else if (strcmp(valuestring, "Defrost") == 0)
    {
        *mode = BP_OVEN_MODE_DEFROST;
    }
    else if (strcmp(valuestring, "Sweetpotato") == 0)
    {
        *mode = BP_OVEN_MODE_SWEETPOTATO;
    }
    else if (strcmp(valuestring, "Whole chicken") == 0)
    {
        *mode = BP_OVEN_MODE_WHOLE_CHICKEN;
    }
    else if (strcmp(valuestring, "Eggtart") == 0)
    {
        *mode = BP_OVEN_MODE_EGG_TART;
    }
    else if (strcmp(valuestring , "AirGrill") == 0)
    {
        *mode = BP_OVEN_MODE_AIRGRILL;
    }
	else
    {
        ret = BP_ERR_ARG;
    }
    return ret;
}

/**
 * @brief 开始烹饪
 * @param p_trace_msg  trace message
 * @param json数据指针
 * @return BYPASS_ERR_E
 */
static BYPASS_ERR_E bypass_method_start_cook_handle(bypass_trace_msg_t *p_trace_msg, cJSON *json)
{
    BYPASS_ERR_E ret = BP_OK;

    if ((NULL == json)||(NULL == p_trace_msg))    return BP_ERROR;

    bypass_oven_cooking_t *pCook = (bypass_oven_cooking_t *)vesync_malloc(sizeof(bypass_oven_cooking_t));

    if (NULL == pCook)
    {
        return BP_ERR_NOMEM;
    }

    memset(pCook, 0, sizeof(bypass_oven_cooking_t));

    cJSON *json_data = cJSON_GetObjectItemCaseSensitive(json, "mode");
    if (cJSON_IsString(json_data))
    {
        ret =bypass_mode_string_handle(json_data->valuestring, &pCook->mode);
        if (ret != BP_OK)
        {
            goto _exit;
        }
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "accountId");
    if (cJSON_IsString(json_data))
    {
        strncpy(pCook->account_id, json_data->valuestring, sizeof(pCook->account_id) - 1);
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "recipeId");
    if (cJSON_IsNumber(json_data))
    {
        pCook->recipe_id = json_data->valueint;
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "recipeName");
    if (cJSON_IsString(json_data))
    {
        strncpy(pCook->recipe_name, json_data->valuestring, sizeof(pCook->recipe_name) - 1);
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "recipeType");
    if (cJSON_IsNumber(json_data))
    {
        pCook->recipe_type = json_data->valueint;
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "hasPreheat");
    if (cJSON_IsNumber(json_data))
    {
        pCook->preheat = json_data->valueint;
        if ((BP_PREHEAT_CONGIG_NO != json_data->valueint) && (BP_PREHEAT_CONGIG_YES != json_data->valueint))
        {
            ret = BP_ERR_ARG;
            goto _exit;
        }
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "readyStart");
    if (cJSON_IsBool(json_data))
    {
        pCook->ready = json_data->valueint;
        SDK_LOG(LOG_DEBUG, "readyStart : %s\r\n", (pCook->ready) ? "true":"false" );
    }
    else
    {
        pCook->ready = false;      //默认是false: 直接启动烹饪
        SDK_LOG(LOG_DEBUG, "readyStart default: flase\r\n" );
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "hasWarm");
    if (cJSON_IsBool(json_data))
    {
        pCook->keepwarm = json_data->valueint;
    }
    else
    {
        pCook->keepwarm = false;      //默认是false
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "tempUnit");    //温度单位
    if (cJSON_IsString(json_data))
    {
        if (strncmp(json_data->valuestring, "f", 1) == 0)
        {
            pCook->temp_unit = BP_TEMP_FAHRENHEIT;
        }
        else if (strncmp(json_data->valuestring, "c", 1) == 0)
        {
            pCook->temp_unit = BP_TEMP_CENTIGRADE;
        }
        else
        {
            ret = BP_ERR_ARG;
            goto _exit;
        }
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "startAct");
    if (cJSON_IsObject(json_data))
    {
        pCook->json_start_act = json_data;

        cJSON *pAction = cJSON_GetObjectItemCaseSensitive(json_data, "level");
        if (cJSON_IsNumber(pAction))
        {
            pCook->action.cooking_act.cook_level = pAction->valueint&0xFF;
        }
        else
        {
            pCook->action.cooking_act.cook_level = BP_COOK_LEVEL_INVALID;
        }

        pAction = cJSON_GetObjectItemCaseSensitive(json_data, "cookSetTime");
        if (cJSON_IsNumber(pAction))
        {
            pCook->action.cooking_act.cook_set_time = pAction->valueint;
        }
        else
        {
            ret = BP_ERR_ARG;
            goto _exit;
        }

        pAction = cJSON_GetObjectItemCaseSensitive(json_data, "cookTemp");    //烹饪温度
        if (cJSON_IsNumber(pAction))
        {
            pCook->action.cooking_act.cook_temp = pAction->valueint & 0xFFFF;
        }
        else
        {
            pAction = cJSON_GetObjectItemCaseSensitive(json_data, "targetTemp");
            if (cJSON_IsNumber(pAction))
            {
                pCook->action.cooking_act.cook_temp = pAction->valueint & 0xFFFF;
            }
            else
            {
                pCook->action.cooking_act.cook_temp = BP_COOK_TEMP_INVALID;
            }
        }


        pAction = cJSON_GetObjectItemCaseSensitive(json_data, "preheatTemp");
        if (cJSON_IsNumber(pAction))
        {
            pCook->action.cooking_act.preheat_temp = pAction->valueint & 0xFFFF;
        }
        else
        {
            pCook->action.cooking_act.preheat_temp = BP_COOK_TEMP_INVALID;
        }

        pAction = cJSON_GetObjectItemCaseSensitive(json_data, "shakeTime");
        if (cJSON_IsNumber(pAction))
        {
            pCook->action.cooking_act.shake_time = pAction->valueint & 0xFFFFFFFF;
        }
        else
        {
            pCook->action.cooking_act.shake_time = BP_SHAKE_TIME_INVALID;
        }

        pAction = cJSON_GetObjectItemCaseSensitive(json_data, "windMode");//新增//风扇状态
        if (cJSON_IsNumber(pAction))
        {
            pCook->action.cooking_act.wind_mode = pAction->valueint & 0xFF;
        }
        else
        {
            pCook->action.cooking_act.wind_mode = BP_WIND_MODE_INVALID;
        }


        pAction = cJSON_GetObjectItemCaseSensitive(json_data, "customExpand");//分上下管温
        if (cJSON_IsObject(pAction))
        {
            cJSON *pCustom = cJSON_GetObjectItemCaseSensitive(pAction, "heatingType");
            if (cJSON_IsNumber(pCustom))
            {
                pCook->action.cooking_act.heating_type = pCustom->valueint & 0xFF;
            }
            else
            {
                pCook->action.cooking_act.heating_type = BP_COOK_HEATING_TYPE_INVALID;
            }

            pCustom = cJSON_GetObjectItemCaseSensitive(pAction, "upTubeTemp");
            if (cJSON_IsNumber(pCustom))
            {
                pCook->action.cooking_act.up_tube_temp = pCustom->valueint & 0xFFFF;
            }
            else
            {
                pCook->action.cooking_act.up_tube_temp = BP_COOK_TEMP_INVALID;
            }

            pCustom = cJSON_GetObjectItemCaseSensitive(pAction, "downTubeTemp");
            if (cJSON_IsNumber(pCustom))
            {
                pCook->action.cooking_act.down_tube_temp = pCustom->valueint & 0xFFFF;
            }
            else
            {
                pCook->action.cooking_act.down_tube_temp = BP_COOK_TEMP_INVALID;
            }
        }
        else
        {
            pCook->action.cooking_act.heating_type = BP_COOK_HEATING_TYPE_INVALID;
            pCook->action.cooking_act.up_tube_temp = BP_COOK_TEMP_INVALID;
            pCook->action.cooking_act.down_tube_temp = BP_COOK_TEMP_INVALID;
        }
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_START_COOK);
    if (method_cb)
    {
        method_cb(p_trace_msg, (void*)pCook, sizeof(bypass_oven_cooking_t));
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

_exit:
    vesync_free(pCook);
    return ret;
}

/**
 * @brief 开始预设菜单烹饪接口(第三方)
 * @param p_trace_msg trace message
 * @param json数据指针
 * @return BYPASS_ERR_E
 */
static BYPASS_ERR_E bypass_method_start_preset_cook_handle(bypass_trace_msg_t *p_trace_msg, cJSON *json)
{
    BYPASS_ERR_E ret = BP_OK;

    if ((NULL == json)||(NULL == p_trace_msg))    return BP_ERROR;

    bypass_preset_cooking_t *pCook = (bypass_preset_cooking_t *)vesync_malloc(sizeof(bypass_preset_cooking_t));

    if (NULL == pCook)
    {
        return BP_ERR_NOMEM;
    }

    memset(pCook, 0, sizeof(bypass_preset_cooking_t));

    cJSON *json_data = cJSON_GetObjectItemCaseSensitive(json, "mode");
    if (cJSON_IsString(json_data))
    {
        ret =bypass_mode_string_handle(json_data->valuestring, &pCook->mode);
        if (ret != BP_OK)
        {
            goto _exit;
        }
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "accountId");
    if (cJSON_IsString(json_data))
    {
        strncpy(pCook->account_id, json_data->valuestring, sizeof(pCook->account_id) - 1);
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "recipeId");
    if (cJSON_IsNumber(json_data))
    {
        pCook->recipe_id = json_data->valueint;
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "recipeName");
    if (cJSON_IsString(json_data))
    {
        strncpy(pCook->recipe_name, json_data->valuestring, sizeof(pCook->recipe_name) - 1);
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "recipeType");
    if (cJSON_IsNumber(json_data))
    {
        pCook->recipe_type = json_data->valueint;
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "tempUnit");    //温度单位
    if (cJSON_IsString(json_data))
    {
        if (strncmp(json_data->valuestring, "f", 1) == 0)
        {
            pCook->temp_unit = BP_TEMP_FAHRENHEIT;
        }
        else if (strncmp(json_data->valuestring, "c", 1) == 0)
        {
            pCook->temp_unit = BP_TEMP_CENTIGRADE;
        }
        else
        {
            ret = BP_ERR_ARG;
            goto _exit;
        }
    }
    else
    {
        pCook->temp_unit = BP_TEMP_INVALID;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "readyStart");
    if (cJSON_IsBool(json_data))
    {
        pCook->ready = json_data->valueint;
        SDK_LOG(LOG_DEBUG, "readyStart : %s\r\n", (pCook->ready) ? "true":"false" );
    }
    else
    {
        pCook->ready = false;      //默认是false: 直接启动烹饪
        SDK_LOG(LOG_DEBUG, "readyStart default: flase\r\n" );
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "startAct");
    if (cJSON_IsObject(json_data))
    {

        cJSON *pAction = cJSON_GetObjectItemCaseSensitive(json_data, "level");
        if (cJSON_IsNumber(pAction))
        {
            pCook->action.cooking_act.cook_level = pAction->valueint&0xFF;
        }
        else
        {
            pCook->action.cooking_act.cook_level = BP_COOK_LEVEL_INVALID;
        }

        pAction = cJSON_GetObjectItemCaseSensitive(json_data, "cookSetTime");
        if (cJSON_IsNumber(pAction))
        {
            pCook->action.cooking_act.cook_set_time = pAction->valueint;
        }
        else
        {
            pCook->action.cooking_act.cook_set_time =  BP_COOK_TIME_INVALID;
        }

        pAction = cJSON_GetObjectItemCaseSensitive(json_data, "cookTemp");    //烹饪温度
        if (cJSON_IsNumber(pAction))
        {
            pCook->action.cooking_act.cook_temp = pAction->valueint & 0xFFFF;
        }
        else
        {
            pCook->action.cooking_act.cook_temp = BP_COOK_TEMP_INVALID;
        }

        pAction = cJSON_GetObjectItemCaseSensitive(json_data, "preheatTemp");
        if (cJSON_IsNumber(pAction))
        {
            pCook->action.cooking_act.preheat_temp = pAction->valueint&0xFFFF;
        }
        else
        {
            pCook->action.cooking_act.preheat_temp = BP_COOK_TEMP_INVALID;
        }

        pAction = cJSON_GetObjectItemCaseSensitive(json_data, "shakeTime");
        if (cJSON_IsNumber(pAction))
        {
            pCook->action.cooking_act.shake_time = pAction->valueint;
        }
        else
        {
            pCook->action.cooking_act.shake_time = BP_COOK_TIME_INVALID;
        }
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_START_PRESET_COOK);
    if (method_cb)
    {
        method_cb(p_trace_msg, (void*)pCook, sizeof(bypass_preset_cooking_t));
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

_exit:
    vesync_free(pCook);
    return ret;
}

/**
 * @brief 开始预热接口
 * @param p_trace_msg trace message
 * @param json数据指针
 * @return BYPASS_ERR_E
 */
static BYPASS_ERR_E bypass_method_preheat_cook_handle(bypass_trace_msg_t *p_trace_msg, cJSON *json)
{
    UNUSED(json);
    if (NULL == p_trace_msg)   return BP_ERROR;
    BYPASS_ERR_E ret = BP_OK;

    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_PREHEAT_COOK);
    if (method_cb)
    {
        method_cb(p_trace_msg, NULL, 0);
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

    return ret;
}


/**
 * @brief 结束烹饪接口
 * @param p_trace_msg trace message
 * @param json数据指针
 * @return BYPASS_ERR_E
 */
static BYPASS_ERR_E bypass_method_end_cook_handle(bypass_trace_msg_t *p_trace_msg, cJSON *json)
{
    UNUSED(json);
    if (NULL == p_trace_msg)   return BP_ERROR;
    BYPASS_ERR_E ret = BP_OK;

    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_END_COOK);
    if (method_cb)
    {
        method_cb(p_trace_msg, NULL, 0);
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

    return ret;
}

/**
 * @brief 设置烹饪时间和温度
 * @param p_trace_msg trace message
 * @param json数据指针
 * @return BYPASS_ERR_E
 */
static BYPASS_ERR_E bypass_method_set_time_and_temp_handle(bypass_trace_msg_t *p_trace_msg, cJSON *json)
{
    BYPASS_ERR_E ret = BP_OK;
    if ((NULL == json)||(NULL == p_trace_msg))    return BP_ERROR;

    bypass_cooking_time_and_temp_t *pCook = (bypass_cooking_time_and_temp_t *)vesync_malloc(sizeof(bypass_cooking_time_and_temp_t));

    if (NULL == pCook)
    {
        return BP_ERR_NOMEM;
    }

    memset(pCook, 0, sizeof(bypass_cooking_time_and_temp_t));

    cJSON *json_data = cJSON_GetObjectItemCaseSensitive(json, "cookSetTime");     //烹饪时间
    if (cJSON_IsNumber(json_data))
    {
        pCook->cook_set_time = json_data->valueint;
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "cookTemp");    //烹饪温度
    if (cJSON_IsNumber(json_data))
    {
        pCook->cook_temp = json_data->valueint & 0xFFFF;
    }
    else
    {
        json_data = cJSON_GetObjectItemCaseSensitive(json, "targetTemp");
        if (cJSON_IsNumber(json_data))
        {
            pCook->cook_temp = json_data->valueint & 0xFFFF;
        }
        else
        {
            ret = BP_ERR_ARG;
            goto _exit;
        }
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "tempUnit");    //温度单位
    if (cJSON_IsString(json_data))
    {
        if (strncmp(json_data->valuestring, "f", 1) == 0)
        {
            pCook->temp_unit = BP_TEMP_FAHRENHEIT;
        }
        else if (strncmp(json_data->valuestring, "c", 1) == 0)
        {
            pCook->temp_unit = BP_TEMP_CENTIGRADE;
        }
        else
        {
            ret = BP_ERR_ARG;
            goto _exit;
        }
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_SET_TIME_AND_TEMP);
    if (method_cb)
    {
        method_cb(p_trace_msg, pCook, sizeof(bypass_cooking_time_and_temp_t));
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

_exit:
    vesync_free(pCook);
    return ret;
}



/**
 * @brief 设置烹饪时间或温度
 * @param p_trace_msg trace message
 * @param json数据指针
 * @return BYPASS_ERR_E
 */
static BYPASS_ERR_E bypass_method_set_time_or_temp_handle(bypass_trace_msg_t *p_trace_msg, cJSON *json)
{
    BYPASS_ERR_E ret = BP_OK;
    if ((NULL == json)||(NULL == p_trace_msg))    return BP_ERROR;

    bypass_cooking_time_and_temp_t *pCook = (bypass_cooking_time_and_temp_t *)vesync_malloc(sizeof(bypass_cooking_time_and_temp_t));

    if (NULL == pCook)
    {
        return BP_ERR_NOMEM;
    }
    uint8_t temp_unit_flag = 0;
    memset(pCook, 0, sizeof(bypass_cooking_time_and_temp_t));

    cJSON *json_data = cJSON_GetObjectItemCaseSensitive(json, "cookSetTime");     //烹饪时间
    if (cJSON_IsNumber(json_data))
    {
        pCook->cook_set_time = json_data->valueint;
    }
    else
    {
        pCook->cook_set_time = BP_COOK_TIME_INVALID;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "cookTemp");    //烹饪温度
    if (cJSON_IsNumber(json_data))
    {
        pCook->cook_temp = json_data->valueint & 0xFFFF;
    }
    else
    {
        pCook->cook_temp = BP_COOK_TEMP_INVALID;
        temp_unit_flag ^= 1;        //缺少温度值标志
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "tempUnit");    //温度单位
    if (cJSON_IsString(json_data))
    {
        if (strncmp(json_data->valuestring, "f", 1) == 0)
        {
            pCook->temp_unit = BP_TEMP_FAHRENHEIT;
        }
        else if (strncmp(json_data->valuestring, "c", 1) == 0)
        {
            pCook->temp_unit = BP_TEMP_CENTIGRADE;
        }
        else
        {
            pCook->temp_unit = BP_TEMP_INVALID;
            temp_unit_flag = 2;    // 温度单位标志错误
        }
    }
    else
    {
        pCook->temp_unit = BP_TEMP_INVALID;
        temp_unit_flag ^= 1;    //缺少温度单位标志
    }
    //约束条件: 当传递cookTemp时候，tempUnit为必传字段 (即二者必须同时出现)
    // if (((BP_COOK_TEMP_INVALID != pCook->cook_temp ) && (BP_TEMP_INVALID == pCook->temp_unit))
    //   || ((BP_COOK_TEMP_INVALID == pCook->cook_temp ) && (BP_TEMP_INVALID != pCook->temp_unit)))
    if (temp_unit_flag)  //包含了上面的条件
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_SET_TIME_OR_TEMP);
    if (method_cb)
    {
        method_cb(p_trace_msg, pCook, sizeof(bypass_cooking_time_and_temp_t));
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

_exit:
    vesync_free(pCook);
    return ret;
}


/**
* @brief 设置ready 烹饪状态
* @param p_trace_msg trace message
* @param json数据指针
* @param src_type 消息来源
* @return BYPASS_ERR_E
*/
static BYPASS_ERR_E bypass_method_ready_cook_handle(bypass_trace_msg_t *p_trace_msg, cJSON *json)
{
    BYPASS_ERR_E ret = BP_OK;

    if ((NULL == json)||(NULL == p_trace_msg))    return BP_ERROR;

    bypass_oven_cooking_t *pCook = (bypass_oven_cooking_t *)vesync_malloc(sizeof(bypass_oven_cooking_t));

    if (NULL == pCook)
    {
        return BP_ERR_NOMEM;
    }

    memset(pCook, 0, sizeof(bypass_oven_cooking_t));
    pCook->ready = true;

    cJSON *json_data = cJSON_GetObjectItemCaseSensitive(json, "mode");
    if (cJSON_IsString(json_data))
    {
        ret =bypass_mode_string_handle(json_data->valuestring, &pCook->mode);
        if (ret != BP_OK)
        {
            goto _exit;
        }
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "accountId");
    if (cJSON_IsString(json_data))
    {
        strncpy(pCook->account_id, json_data->valuestring, sizeof(pCook->account_id) - 1);
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "recipeId");
    if (cJSON_IsNumber(json_data))
    {
        pCook->recipe_id = json_data->valueint;
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "recipeName");
    if (cJSON_IsString(json_data))
    {
        strncpy(pCook->recipe_name, json_data->valuestring, sizeof(pCook->recipe_name) - 1);
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "recipeType");
    if (cJSON_IsNumber(json_data))
    {
        pCook->recipe_type = json_data->valueint;
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "hasPreheat");
    if (cJSON_IsNumber(json_data))
    {
        pCook->preheat = json_data->valueint;
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "tempUnit");    //温度单位
    if (cJSON_IsString(json_data))
    {
        if (strncmp(json_data->valuestring, "f", 1) == 0)
        {
            pCook->temp_unit = BP_TEMP_FAHRENHEIT;
        }
        else if (strncmp(json_data->valuestring, "c", 1) == 0)
        {
            pCook->temp_unit = BP_TEMP_CENTIGRADE;
        }
        else
        {
            ret = BP_ERR_ARG;
            goto _exit;
        }
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "startAct");
    if (cJSON_IsObject(json_data))
    {
        cJSON *pAction = cJSON_GetObjectItemCaseSensitive(json_data, "level");
        if (cJSON_IsNumber(pAction))
        {
            pCook->action.cooking_act.cook_level = pAction->valueint&0xFF;
        }
        else
        {
            pCook->action.cooking_act.cook_level = BP_COOK_LEVEL_INVALID;
        }

        pAction = cJSON_GetObjectItemCaseSensitive(json_data, "cookSetTime");
        if (cJSON_IsNumber(pAction))
        {
            pCook->action.cooking_act.cook_set_time = pAction->valueint;
        }
        else
        {
            pCook->action.cooking_act.cook_set_time = BP_COOK_TIME_INVALID;
        }

        pAction = cJSON_GetObjectItemCaseSensitive(json, "cookTemp");    //烹饪温度
        if (cJSON_IsNumber(pAction))
        {
            pCook->action.cooking_act.cook_temp = pAction->valueint & 0xFFFF;
        }
        else
        {
            pAction = cJSON_GetObjectItemCaseSensitive(json_data, "targetTemp");
            if (cJSON_IsNumber(pAction))
            {
                pCook->action.cooking_act.cook_temp = pAction->valueint&0xFFFF;
            }
            else
            {
                pCook->action.cooking_act.cook_temp = BP_COOK_TEMP_INVALID;
            }
        }
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_READY_COOK);
    if (method_cb)
    {
        method_cb(p_trace_msg, (void*)pCook, sizeof(bypass_oven_cooking_t));
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

_exit:
    vesync_free(pCook);
    return ret;

}

/**
* @brief 调整烹饪时间
* @param p_trace_msg trace message
* @param json数据指针
* @param src_type 消息来源
* @return BYPASS_ERR_E
*/
static BYPASS_ERR_E bypass_method_adjust_cook_time_handle(bypass_trace_msg_t *p_trace_msg, cJSON *json)
{
    BYPASS_ERR_E ret = BP_OK;

    if ((NULL == json)||(NULL == p_trace_msg))    return BP_ERROR;

    bypass_oven_adjust_time_t *p_adjust = (bypass_oven_adjust_time_t *)vesync_malloc(sizeof(bypass_oven_adjust_time_t));

    if (NULL == p_adjust)
    {
        return BP_ERR_NOMEM;
    }

    memset(p_adjust, 0, sizeof(bypass_oven_adjust_time_t));

    cJSON *json_data = cJSON_GetObjectItemCaseSensitive(json, "adjustTime");
    if (cJSON_IsNumber(json_data))
    {
        p_adjust->adjust_time = json_data->valueint;
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_ADJUST_COOK_TIME);
    if (method_cb)
    {
        method_cb(p_trace_msg, p_adjust, sizeof(bypass_oven_adjust_time_t));
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

_exit:
    vesync_free(p_adjust);
    return ret;

}


/**
* @brief 烤箱预热处理
* @param p_trace_msg trace message
* @param json数据指针
* @param src_type 消息来源
* @return BYPASS_ERR_E
*/
static BYPASS_ERR_E bypass_method_oven_preheat_handle(bypass_trace_msg_t *p_trace_msg, cJSON *json)
{
    BYPASS_ERR_E ret = BP_OK;

    if ((NULL == json)||(NULL == p_trace_msg))    return BP_ERROR;

    bypass_oven_preheat_para_t *p_preheat = (bypass_oven_preheat_para_t *)vesync_malloc(sizeof(bypass_oven_preheat_para_t));
    if (NULL == p_preheat)
    {
        return BP_ERR_NOMEM;
    }

    memset(p_preheat, 0, sizeof(bypass_oven_preheat_para_t));

    cJSON *json_data = cJSON_GetObjectItemCaseSensitive(json, "preheatTemp");
    if (cJSON_IsNumber(json_data))
    {
        p_preheat->preheat_temp = json_data->valueint&0xFFFF;
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "preheatTempUnit");
    if (cJSON_IsString(json_data))
    {
        if (strncmp(json_data->valuestring, "f", 1) == 0)
        {
            p_preheat->temp_unit = BP_TEMP_FAHRENHEIT;
        }
        else if (strncmp(json_data->valuestring, "c", 1) == 0)
        {
            p_preheat->temp_unit = BP_TEMP_CENTIGRADE;
        }
        else
        {
            ret = BP_ERR_ARG;
            goto _exit;
        }

    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    //readuStart
    json_data = cJSON_GetObjectItemCaseSensitive(json, "readyStart");
    if (cJSON_IsBool(json_data))
    {
        p_preheat->ready = json_data->valueint;
        SDK_LOG(LOG_DEBUG, "readyStart : %s\r\n", (p_preheat->ready) ? "true":"false" );
    }
    else
    {
        p_preheat->ready = false;      //默认是false: 直接启动烹饪
        SDK_LOG(LOG_DEBUG, "readyStart default: flase\r\n" );
    }

    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_OVEN_PREHEAT);
    if (method_cb)
    {
        method_cb(p_trace_msg, p_preheat, sizeof(bypass_oven_preheat_para_t));
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

_exit:
    vesync_free(p_preheat);
    return ret;
}

/**
 * @brief 结束预热命令处理
 * @param p_trace_msg trace message
 * @param json数据指针
 * @return BYPASS_ERR_E
 */
static BYPASS_ERR_E bypass_method_end_preheat_handle(bypass_trace_msg_t *p_trace_msg, cJSON *json)
{
    UNUSED(json);
    SDK_LOG(LOG_DEBUG, "bypass_method_end_preheat_handle\r\n");
    if (NULL == p_trace_msg)   return BP_ERROR;
    BYPASS_ERR_E ret = BP_OK;
    //查询无需解析json
    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_END_PREHEAT);
    if (method_cb)
    {
        SDK_LOG(LOG_DEBUG, "method_cb preheat\r\n");
        method_cb(p_trace_msg, NULL, 0);
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

    return ret;
}


/**
 * @brief 获取空气炸锅状态函数
 * @param p_trace_msg trace message
 * @param json数据指针
 * @return BYPASS_ERR_E
 */
static BYPASS_ERR_E bypass_method_get_airfryer_status_handle(bypass_trace_msg_t *p_trace_msg, cJSON *json)
{
    UNUSED(json);
    if (NULL == p_trace_msg)   return BP_ERROR;
    BYPASS_ERR_E ret = BP_OK;

    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_GET_AIRFRYER_STATUS);

    if (method_cb)
    {
        method_cb(p_trace_msg, NULL, 0);
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

    return ret;
}

/**
 * @brief 开始预约
 * @param p_trace_msg trace message
 * @param json数据指针
 * @return BYPASS_ERR_E
 */
static BYPASS_ERR_E bypass_method_start_appoint_handle(bypass_trace_msg_t *p_trace_msg, cJSON *json)
{
    BYPASS_ERR_E ret = BP_OK;

    if ((NULL == json)||(NULL == p_trace_msg))    return BP_ERROR;

    bypass_cook_start_appoint_t *p_appoint = (bypass_cook_start_appoint_t *)vesync_malloc(sizeof(bypass_cook_start_appoint_t));
    if (NULL == p_appoint)
    {
        return BP_ERR_NOMEM;
    }

    memset(p_appoint, 0, sizeof(bypass_cook_start_appoint_t));


    cJSON *json_data = cJSON_GetObjectItemCaseSensitive(json, "mode");
    if (cJSON_IsString(json_data))
    {
        ret = bypass_mode_string_handle(json_data->valuestring, &p_appoint->mode);
        SDK_LOG(LOG_INFO,"p_appoint mode : %x\r\n",p_appoint->mode);
        if (ret != BP_OK)
        {
            goto _exit;
        }
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "accountId");
    if (cJSON_IsString(json_data))
    {
        strncpy(p_appoint->account_id, json_data->valuestring, sizeof(p_appoint->account_id) - 1);
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "recipeId");
    if (cJSON_IsNumber(json_data))
    {
        p_appoint->recipe_id = json_data->valueint;
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }
    SDK_LOG(LOG_INFO,"recipeId : %x\r\n",p_appoint->recipe_id);
    json_data = cJSON_GetObjectItemCaseSensitive(json, "recipeName");
    if (cJSON_IsString(json_data))
    {
        strncpy(p_appoint->recipe_name, json_data->valuestring, sizeof(p_appoint->recipe_name) - 1);
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "recipeType");
    if (cJSON_IsNumber(json_data))
    {
        p_appoint->recipe_type = json_data->valueint;
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "tempUnit");    //温度单位
    if (cJSON_IsString(json_data))
    {
        if (strncmp(json_data->valuestring, "f", 1) == 0)
        {
            p_appoint->temp_unit = BP_TEMP_FAHRENHEIT;
        }
        else if (strncmp(json_data->valuestring, "c", 1) == 0)
        {
            p_appoint->temp_unit = BP_TEMP_CENTIGRADE;
        }
        else
        {
            ret = BP_ERR_ARG;
            goto _exit;
        }
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "cookSetTime");     //烹饪时间
    if (cJSON_IsNumber(json_data))
    {
        p_appoint->cook_set_time = json_data->valueint;
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }
    SDK_LOG(LOG_INFO,"cook_set_time : %x\r\n",p_appoint->cook_set_time);
    json_data = cJSON_GetObjectItemCaseSensitive(json, "cookTemp");    //烹饪温度
    if (cJSON_IsNumber(json_data))
    {
        p_appoint->cook_temp = json_data->valueint&0xFFFF;
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }
    SDK_LOG(LOG_INFO,"cook_temp : %x\r\n",p_appoint->cook_temp);
    json_data = cJSON_GetObjectItemCaseSensitive(json, "shakeTime");
    if (cJSON_IsNumber(json_data))
    {
        p_appoint->shake_time = json_data->valueint & 0xFFFFFFFF;
        SDK_LOG(LOG_INFO,"shake_time : %x\r\n",p_appoint->shake_time);
    }
    else
    {
        p_appoint->shake_time = BP_SHAKE_TIME_INVALID;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "appointmentTs");
    if (cJSON_IsNumber(json_data))
    {
        p_appoint->appointment_ts = json_data->valueint;
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }
    SDK_LOG(LOG_INFO,"appointment_ts : %x\r\n",p_appoint->appointment_ts);

    json_data = cJSON_GetObjectItemCaseSensitive(json, "windMode");//新增//风扇状态
    if (cJSON_IsNumber(json_data))
    {
        p_appoint->wind_mode = json_data->valueint & 0xFF;
    }
    else
    {
        p_appoint->wind_mode = BP_WIND_MODE_INVALID;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "customExpand");//分上下管温
    if (cJSON_IsObject(json_data))
    {
        cJSON *pCustom = cJSON_GetObjectItemCaseSensitive(json_data, "heatingType");
        if (cJSON_IsNumber(pCustom))
        {
            p_appoint->heating_type = pCustom->valueint & 0xFF;
        }
        else
        {
            p_appoint->heating_type = BP_COOK_HEATING_TYPE_INVALID;
        }

        pCustom = cJSON_GetObjectItemCaseSensitive(json_data, "upTubeTemp");
        if (cJSON_IsNumber(pCustom))
        {
            p_appoint->up_tube_temp = pCustom->valueint & 0xFFFF;
        }
        else
        {
            p_appoint->up_tube_temp = BP_COOK_TEMP_INVALID;
        }

        pCustom = cJSON_GetObjectItemCaseSensitive(json_data, "downTubeTemp");
        if (cJSON_IsNumber(pCustom))
        {
            p_appoint->down_tube_temp = pCustom->valueint & 0xFFFF;
        }
        else
        {
            p_appoint->down_tube_temp = BP_COOK_TEMP_INVALID;
        }

    }
    else
    {
        p_appoint->heating_type = BP_COOK_HEATING_TYPE_INVALID;
        p_appoint->up_tube_temp = BP_COOK_TEMP_INVALID;
        p_appoint->down_tube_temp = BP_COOK_TEMP_INVALID;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "readyStart");
    if (cJSON_IsBool(json_data))
    {
        p_appoint->ready = json_data->valueint;
        SDK_LOG(LOG_DEBUG, "readyStart : %s\r\n", (p_appoint->ready) ? "true":"false" );
    }
    else
    {
        p_appoint->ready = false;      //默认是false: 直接启动烹饪
        SDK_LOG(LOG_DEBUG, "readyStart default: flase\r\n" );
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "level");
    if (cJSON_IsNumber(json_data))
    {
        p_appoint->cook_level = json_data->valueint & 0xFF;
        SDK_LOG(LOG_INFO,"cook_level : %x\r\n",p_appoint->cook_level);
    }
    else
    {
        p_appoint->cook_level = BP_COOK_LEVEL_INVALID;
    }

    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_START_APPOINT);
    if (method_cb)
    {
        method_cb(p_trace_msg, (void*)p_appoint, sizeof(bypass_cook_start_appoint_t));
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

_exit:
    vesync_free(p_appoint);
    return ret;
}

/**
 * @brief 开始多段烹饪
 * @param p_trace_msg  trace message
 * @param json数据指针
 * @return BYPASS_ERR_E
 */
static BYPASS_ERR_E bypass_method_start_step_cook_handle(bypass_trace_msg_t *p_trace_msg, cJSON *json)
{
    BYPASS_ERR_E ret = BP_OK;

    if ((NULL == json)||(NULL == p_trace_msg))    return BP_ERROR;

    bypass_step_cook_t *pCook = (bypass_step_cook_t *)vesync_malloc(sizeof(bypass_step_cook_t));

    if (NULL == pCook)
    {
        return BP_ERR_NOMEM;
    }

    memset(pCook, 0, sizeof(bypass_step_cook_t));

    cJSON * json_data = cJSON_GetObjectItemCaseSensitive(json, "accountId");
    if (cJSON_IsString(json_data))
    {
        strncpy(pCook->account_id, json_data->valuestring, sizeof(pCook->account_id) - 1);
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "hasPreheat");
    if (cJSON_IsNumber(json_data))
    {
        pCook->has_preheat = json_data->valueint;
        if ((BP_PREHEAT_CONGIG_NO != json_data->valueint) && (BP_PREHEAT_CONGIG_YES != json_data->valueint))
        {
            ret = BP_ERR_ARG;
            goto _exit;
        }
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "preheatTemp");
    if (cJSON_IsNumber(json_data))
    {
        pCook->preheat_temp = json_data->valueint;
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "tempUnit");    //温度单位
    if (cJSON_IsString(json_data))
    {
        if (strncmp(json_data->valuestring, "f", 1) == 0)
        {
            pCook->temp_unit = BP_TEMP_FAHRENHEIT;
        }
        else if (strncmp(json_data->valuestring, "c", 1) == 0)
        {
            pCook->temp_unit = BP_TEMP_CENTIGRADE;
        }
        else
        {
            ret = BP_ERR_ARG;
            goto _exit;
        }
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }
    json_data = cJSON_GetObjectItemCaseSensitive(json, "readyStart");
    if (cJSON_IsBool(json_data))
    {
        pCook->ready = json_data->valueint;
    }
    else
    {
        pCook->ready = false;      //直接启动烹饪
    }
    json_data = cJSON_GetObjectItemCaseSensitive(json, "stepArray");
    if (cJSON_IsArray(json_data) && cJSON_GetArraySize(json_data))
    {
        pCook->json_step = json_data;
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_START_STEP_COOK);
    if (method_cb)
    {
        method_cb(p_trace_msg, (void*)pCook, sizeof(bypass_step_cook_t));
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

_exit:
    vesync_free(pCook);
    return ret;
}

/**
 * @brief 暂停
 * @param p_trace_msg trace message
 * @param json数据指针
 * @return BYPASS_ERR_E
 */
static BYPASS_ERR_E bypass_method_pause_work_handle(bypass_trace_msg_t *p_trace_msg, cJSON *json)
{
    UNUSED(json);
    if (NULL == p_trace_msg)   return BP_ERROR;
    BYPASS_ERR_E ret = BP_OK;

    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_PAUSE_WORK);
    if (method_cb)
    {
        method_cb(p_trace_msg, NULL, 0);
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

    return ret;
}

/**
 * @brief 恢复
 * @param p_trace_msg trace message
 * @param json数据指针
 * @return BYPASS_ERR_E
 */
static BYPASS_ERR_E bypass_method_resume_work_handle(bypass_trace_msg_t *p_trace_msg, cJSON *json)
{
    UNUSED(json);
    if (NULL == p_trace_msg)   return BP_ERROR;
    BYPASS_ERR_E ret = BP_OK;

    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_RESUME_WORK);
    if (method_cb)
    {
        method_cb(p_trace_msg, NULL, 0);
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

    return ret;
}

/**
 * @brief 跳过当前步骤
 * @param p_trace_msg trace message
 * @param json数据指针
 * @return BYPASS_ERR_E
 */
static BYPASS_ERR_E bypass_method_skip_step_handle(bypass_trace_msg_t *p_trace_msg, cJSON *json)
{
    BYPASS_ERR_E ret = BP_OK;
    if ((NULL == json)||(NULL == p_trace_msg))    return BP_ERROR;

    bypass_skip_step_t *para = (bypass_skip_step_t *)vesync_malloc(sizeof(bypass_skip_step_t));
    if (NULL == para)
    {
        return BP_ERR_NOMEM;
    }

    memset(para, 0, sizeof(bypass_skip_step_t));

    cJSON *json_data = cJSON_GetObjectItemCaseSensitive(json, "type");
    if (cJSON_IsString(json_data))
    {
        if (strcmp(json_data->valuestring, "preheat") == 0)
        {
            para->step = BP_COOK_STEP_PREHEAT;
        }
        else if (strcmp(json_data->valuestring, "cook") == 0)
        {
            para->step = BP_COOK_STEP_COOK;
        }
        else if (strcmp(json_data->valuestring, "shake") == 0)
        {
            para->step = BP_COOK_STEP_SHAKE;
        }
        else if (strcmp(json_data->valuestring, "appoint") == 0)
        {
            para->step = BP_COOK_APPOINT;
        }
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_SKIP_STEP);
    if (method_cb)
    {
        method_cb(p_trace_msg, para, sizeof(bypass_skip_step_t));
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

_exit:
    vesync_free(para);
    return ret;
}

/**
 * @brief 获取设备预设菜谱
 * @param p_trace_msg trace message
 * @param json数据指针
 * @return BYPASS_ERR_E
 */
static BYPASS_ERR_E bypass_method_get_preset_recipe_handle(bypass_trace_msg_t *p_trace_msg, cJSON *json)
{
    UNUSED(json);
    if (NULL == p_trace_msg)   return BP_ERROR;

    BYPASS_ERR_E ret = BP_OK;

    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_GET_PRESET_RECIPE);
    if (method_cb)
    {
        method_cb(p_trace_msg, NULL, 0);
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

    return ret;
}

/**
 * @brief 重置设备所有设备预设菜谱
 * @param p_trace_msg trace message
 * @param json数据指针
 * @return BYPASS_ERR_E
 */
static BYPASS_ERR_E bypass_method_reset_all_preset_recipe_handle(bypass_trace_msg_t *p_trace_msg, cJSON *json)
{
    UNUSED(json);
    if (NULL == p_trace_msg)   return BP_ERROR;
    BYPASS_ERR_E ret = BP_OK;

    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_RESET_ALL_PRESET_RECIPE);
    if (method_cb)
    {
        method_cb(p_trace_msg, NULL, 0);
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

    return ret;
}

/**
 * @brief 修改单个预设菜谱
 * @param p_trace_msg trace message
 * @param json数据指针
 * @return BYPASS_ERR_E
 */
static BYPASS_ERR_E bypass_method_update_preset_recipe_handle(bypass_trace_msg_t *p_trace_msg, cJSON *json)
{
    BYPASS_ERR_E ret = BP_OK;

    if ((NULL == json)||(NULL == p_trace_msg))    return BP_ERROR;

    bypass_update_preset_recipe_t *p_data = (bypass_update_preset_recipe_t *)vesync_malloc(sizeof(bypass_update_preset_recipe_t));
    if (NULL == p_data)
    {
        return BP_ERR_NOMEM;
    }

    memset(p_data, 0, sizeof(bypass_update_preset_recipe_t));


    cJSON *json_data = cJSON_GetObjectItemCaseSensitive(json, "mode");
    if (cJSON_IsString(json_data))
    {
        ret =bypass_mode_string_handle(json_data->valuestring, &p_data->mode);
        if (ret != BP_OK)
        {
            goto _exit;
        }
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "tempUnit");    //温度单位
    if (cJSON_IsString(json_data))
    {
        if (strncmp(json_data->valuestring, "f", 1) == 0)
        {
            p_data->temp_unit = BP_TEMP_FAHRENHEIT;
        }
        else if (strncmp(json_data->valuestring, "c", 1) == 0)
        {
            p_data->temp_unit = BP_TEMP_CENTIGRADE;
        }
        else
        {
            ret = BP_ERR_ARG;
            goto _exit;
        }
    }


    json_data = cJSON_GetObjectItemCaseSensitive(json, "cookSetTime");     //烹饪时间
    if (cJSON_IsNumber(json_data))
    {
        p_data->cook_set_time = json_data->valueint;
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "cookTemp");    //烹饪温度
    if (cJSON_IsNumber(json_data))
    {
        p_data->cook_temp = json_data->valueint&0xFFFF;
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "shakeTime");
    if (cJSON_IsNumber(json_data))
    {
        p_data->shake_time = json_data->valueint;
    }
    else
    {
        p_data->shake_time = 0;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "level");
    if (cJSON_IsNumber(json_data))
    {
        p_data->cook_level = json_data->valueint;
    }
    else
    {
        p_data->cook_level = BP_COOK_LEVEL_INVALID;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "hasWarm");
    if (cJSON_IsBool(json_data))
    {
        p_data->has_warm = json_data->valueint;
    }
    else
    {
        p_data->has_warm = false;      //默认是false
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "hasPreheat");
    if (cJSON_IsBool(json_data))
    {
        p_data->has_preheat = json_data->valueint;
    }
    else
    {
        p_data->has_preheat = false;      //默认是false
    }

    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_UPDATE_PRESET_RECIPE);
    if (method_cb)
    {
        method_cb(p_trace_msg, (void*)p_data, sizeof(bypass_update_preset_recipe_t));
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

_exit:
    vesync_free(p_data);
    return ret;
}

/**
 * @brief 重置单个预设菜谱
 * @param p_trace_msg trace message
 * @param json数据指针
 * @return BYPASS_ERR_E
 */
static BYPASS_ERR_E bypass_method_reset_preset_recipe_handle(bypass_trace_msg_t *p_trace_msg, cJSON *json)
{
    BYPASS_ERR_E ret = BP_OK;

    if ((NULL == json)||(NULL == p_trace_msg))    return BP_ERROR;

    bypass_reset_preset_recipe_t *p_data = (bypass_reset_preset_recipe_t *)vesync_malloc(sizeof(bypass_reset_preset_recipe_t));
    if (NULL == p_data)
    {
        return BP_ERR_NOMEM;
    }

    memset(p_data, 0, sizeof(bypass_reset_preset_recipe_t));


    cJSON *json_data = cJSON_GetObjectItemCaseSensitive(json, "mode");
    if (cJSON_IsString(json_data))
    {
        ret =bypass_mode_string_handle(json_data->valuestring, &p_data->mode);
        if (ret != BP_OK)
        {
            goto _exit;
        }
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "level");
    if (cJSON_IsNumber(json_data))
    {
        p_data->cook_level = json_data->valueint&0xFF;
    }
    else
    {
        p_data->cook_level = BP_COOK_LEVEL_INVALID;
    }


    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_RESET_PRESET_RECIPE);
    if (method_cb)
    {
        method_cb(p_trace_msg, (void*)p_data, sizeof(bypass_reset_preset_recipe_t));
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

_exit:
    vesync_free(p_data);
    return ret;
}


static bypass_item_data_t cooking_method_tbl[] = {
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_GET_OVEN_STATUS,         "getOvenStatus",        bypass_method_get_oven_status_handle, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_CONFIRM_COOK_END,        "confirmCookEnd",       bypass_method_confirm_cook_end_handle, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_START_COOK,              "startCook",            bypass_method_start_cook_handle, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_PREHEAT_COOK,            "preheatCook",          bypass_method_preheat_cook_handle, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_END_COOK,                "endCook",              bypass_method_end_cook_handle, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_SET_TIME_AND_TEMP,       "setTimeAndTemp",       bypass_method_set_time_and_temp_handle, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_READY_COOK,              "readyCook",            bypass_method_ready_cook_handle, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_ADJUST_COOK_TIME,        "adjustCookTime",       bypass_method_adjust_cook_time_handle, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_OVEN_PREHEAT,            "preheat",              bypass_method_oven_preheat_handle, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_END_PREHEAT,             "endPreheat",           bypass_method_end_preheat_handle, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_GET_AIRFRYER_STATUS,     "getAirfryerStatus",    bypass_method_get_airfryer_status_handle, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_START_APPOINT,           "startAppoint",         bypass_method_start_appoint_handle, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_START_STEP_COOK,         "startStepCook",        bypass_method_start_step_cook_handle, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_PAUSE_WORK,              "pauseWork",            bypass_method_pause_work_handle, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_RESUME_WORK,             "resumeWork",           bypass_method_resume_work_handle, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_SKIP_STEP,               "skipStep",             bypass_method_skip_step_handle, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_GET_PRESET_RECIPE,       "getPresetRecipe",      bypass_method_get_preset_recipe_handle, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_RESET_ALL_PRESET_RECIPE, "resetAllPresetRecipe", bypass_method_reset_all_preset_recipe_handle, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_UPDATE_PRESET_RECIPE,    "updatePresetRecipe",   bypass_method_update_preset_recipe_handle, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_RESET_PRESET_RECIPE,     "resetPresetRecipe",    bypass_method_reset_preset_recipe_handle, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_GET_OVEN_STATUS_V2,      "getOvenStatusV2",      bypass_method_get_oven_status_v2_handle, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_START_PRESET_COOK,       "startPresetCook",      bypass_method_start_preset_cook_handle, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_SET_TIME_OR_TEMP,        "setTimeOrTemp",        bypass_method_set_time_or_temp_handle, NULL},
};

void vesync_bypass_cooking_init(void)
{
    for (int i = 0; i < SIZEOF_ARRAY(cooking_method_tbl); i++)
    {
        bypass_item_t *item = vesync_bypass_init_item(&cooking_method_tbl[i]);
        if (item != NULL)
        {
            vesync_bypass_add_item(item);
        }
    }
}
