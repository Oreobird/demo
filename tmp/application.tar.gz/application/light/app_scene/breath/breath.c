/**
* Copyright © Vesync Technologies Co.Ltd. 2022. All rights reserved
* @file         breath.c
* @brief        呼吸灯效控制
* @author       Joshua
* @date         2022-1-7
*/


#include <string.h>
#include <stdint.h>
#include "vesync_common.h"
#include "vesync_memory.h"
#include "vesync_log.h"
#include "reset_light.h"

int breath_light_scene_reg(breath_light_scene_t *light_scene)
{
    VCOM_NULL_PARAM_CHK(light_scene, return APP_FAIL);

    scene_t *thiz = (scene_t *) vesync_malloc(sizeof(scene_t) + sizeof(breath_light_scene_t));
    if (thiz == NULL)
    {
        APP_LOG(LOG_ERROR, "production light scenee reg fail\n");
        return APP_FAIL;
    }

    memset(thiz, 0, sizeof(scene_t) + sizeof(breath_light_scene_t));

    breath_light_scene_t *ctx = (breath_light_scene_t *)thiz->ctx;

    // TODO
    // ctx->


    thiz->type = SCENE_LIGHT;
    thiz->id = SCENE_BREATH;

    scene_registry_add(thiz);

    return APP_OK;
}

int breath_light_scene_unreg(void)
{
    return scene_registry_del(SCENE_LIGHT, SCENE_BREATH);
}



