/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_init_internal.h
 * @brief       SDK初始化
 * @date        2021-05-06
 */

#ifndef __VESYNC_INIT_INTERNAL_H__
#define __VESYNC_INIT_INTERNAL_H__

#ifdef __cplusplus
extern "C" {
#endif

#define VESYNC_TASK_NAME                "vesync"
#define VESYNC_TASK_STACKSIZE           (1024*6)
#define VESYNC_TASK_PRIO                TASK_PRIORITY_NORMAL

#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_INIT_INTERNAL_H__ */


