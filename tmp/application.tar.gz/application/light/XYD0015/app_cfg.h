/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
* @file         app_cfg.h
* @brief        应用功能配置
* @author       Joshua
* @date         2021-11-23
*/

#include <stdint.h>
#include <stdbool.h>
#include "vesync_common.h"

#ifndef __APP_CFG_H__
#define __APP_CFG_H__

#ifdef __cplusplus
extern "C" {
#endif


// 通用配置
#define LIGHT_NODE_NUM          (50)        // 灯珠数量
#define LIGHT_FADE_ENABLE       (1)         // 灯效是否渐变
#define LIGHT_SEGMENT_MAX_NUM   (15)        // 最大分段数

// 灯光控制IO配置
#define RMT_CTRL_IO              (9)         // RMT控制IO
#define LIGHT_WARM_OUT_IO        (3)         // PWM控制IO号


// 灯光驱动配置
#define LIGHT_WHITE_DRV_TYPE     (1)         // 白光驱动方式：0-i2c，1-pwm，2-rmt
#define LIGHT_COLOR_DRV_TYPE     (2)         // 彩光驱动方式：0-i2c，1-pwm，2-rmt

// RMT驱动参数
#define RMT_TX_CHANNEL           (0)
#define RMT_T0H_NS               (350)
#define RMT_T0L_NS               (1000)
#define RMT_T1H_NS               (1000)
#define RMT_T1L_NS               (350)
#define RMT_RESET_US             (280)
#define RMT_CH_NUM               (3)
#define RMT_CH_DATA_0            (LIGHT_CH_IDX_G)
#define RMT_CH_DATA_1            (LIGHT_CH_IDX_R)
#define RMT_CH_DATA_2            (LIGHT_CH_IDX_B)

// PWM驱动参数
#define PWM_WW_CH                (LED_CH1)   // 暖光的led通道
#define PWM_CH_NUM               (1)         // 配置的led数量
#define LIGHT_LEDC_DUTY_RST_BIT  (LED_DUTY_RST_11_BIT)  // LEDC 占空比分辨率设置（10位对应1024）
#define LIGHT_LEDC_PWM_FREQ      (5000)      // LEDC PWM控制频率
#define LIGHT_WHITE_CW           (0)


// 灯光参数量程配置
#define LIGHT_W_MIN_PERCENT      (1)         // 白光模式的实际最小亮度百分数，这个数值是为了防止设置最低亮度出现近似关断的情况
#define LIGHT_W_MAX_PERCENT      (100)       // 白光模式的实际最小亮度百分数，这个数值是为了防止设置最低亮度出现近似关断的情况
#define LIGHT_RGB_MIN_PERCENT    (5)         // 彩光模式的实际最小明度百分数，这个数值是为了防止灯泡在超低电流下出现偏色做的限制
#define LIGHT_COLOR_TEMP_MAX     (100)       // 色温值上限
#define LIGHT_BRIGHTNESS_MAX     (100)       // 亮度值最大值
#define LIGHT_BRIGHTNESS_MIN     (0)         // 亮度值最小值
#define LIGHT_PWM_MAX_SCALE      (256)       // PWM数字输出最大量程，十位分辨率

// 设备配置默认初值
#define LIGHT_DEFAULT_H          (6666)      // 默认hue值
#define LIGHT_DEFAULT_S          (10000)     // 默认saturation值
#define LIGHT_DEFAULT_V          (100)       // 默认value值
#define LIGHT_DEFAULT_BRIGHTNESS (100)        // 默认brightness值
#define LIGHT_DEFAULT_COLOR_TEMP (50)       // 默认colorTemp值

// 存储配置
#define APP_USER_CFG_KEY_DATA    "XYD0015"   // 配置标识符
#define APP_FLASH_DATA_LEN       (100)       // 写flash数据预分配长度
#define APP_FLASH_CFG_VERSION    (1)         // 配置版本

// 按键配置
#define APP_BUTTON_NUM           (1)
#define APP_BUTTON0_CFG          {7, 0, 3, 1},  // {GPIO, 使能电平, 短按功能类型(BTN_SHORT_PRESS_TYPE_E), 长按功能类型(BTN_LONG_PRESS_TYPE_E)}

#ifdef __cplusplus
}
#endif

#endif



