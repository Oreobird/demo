/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_light_internal.h
 * @brief       灯光照明控制模块内部接口定义
 * @author      Herve
 * @date        2021-11-09
 */
#ifndef __VESYNC_LIGHT_INTERNAL_H__
#define __VESYNC_LIGHT_INTERNAL_H__

#include "stdbool.h"
#include "stdint.h"

#include "vesync_mutex.h"
#include "vesync_list.h"
#include "vesync_light.h"

#ifdef __cplusplus
extern "C" {
#endif

#define LIGHT_CHECK(a, ret)  if(!(a)) { \
        return (ret);                   \
    }

#define LIGHT_CHECK_ACTION(a, action) if (!(a)) { \
        action; \
    }

/**
 * @brief 空指针断言，断言失败返回LIGHT_N_PTR错误
 * @param[in] ptr           [被断言指针]
 */
#define PTR_ASSERT(ptr) LIGHT_CHECK((ptr) != NULL, LIGHT_N_PTR)

/**
 * @brief 空指针断言跳转
 * @param[in] ptr           [被断言指针]
 * @param[in] label         [goto跳转标签]
 */
#define PTR_ASSERT_EXIT(ptr, label)  if(NULL == (ptr)) { \
        goto label;                                      \
    }

#define LIGHT_NUM_MAX (10)     // 灯光控制器实例数量上限
#define LIGHT_CH_NUM_MAX (5 * 200)   // 单个灯光控制器实例的通道数量上限

// 灯光模块控制器初始化值
#define LIGHT_MGMT_INIT_VAL {is_init:false}
#define LIGHT_NEW_LOCK() vesync_mutex_new()
#define LIGHT_DEL_LOCK(m)     \
    do                        \
    {                         \
        vesync_mutex_free(m); \
        m = NULL;             \
    } while (0)

#define LIGHT_LOCK(m) LIGHT_CHECK(VOS_OK == vesync_mutex_lock(m), LIGHT_ERR)
#define LIGHT_CB_LOCK(m)                    \
    do                                      \
    {                                       \
        if (VOS_OK != vesync_mutex_lock(m)) \
        {                                   \
            return;                         \
        }                                   \
    } while (0)
#define LIGHT_UNLOCK(m) vesync_mutex_unlock(m)

/**
 * @brief 通道PWM控制量输出回调函数类型定义
 * @param[in] opt           [可选的回调参数]
 * @param[in] ch_num        [回调的通道号]
 * @param[in] p_ch_duty     [回调的个通道的PWM控制量]
 */
typedef void (*ch_ctrl_cb_t)(void *opt, uint8_t ch_num, uint32_t *p_ch_duty);

/**
 * @brief 灯光控制器通道定义
 */
typedef struct
{
    float gamma;            // 通道的伽马校正参数
    bool fade_start;        // 是否渐变流程开始
    bool fade_up;           // 是否向上渐变
    bool is_rpt;            // 渐变流程是否一直持续执行
    uint32_t semicycle_cnt; // 半周期倒计数。对于闪烁和呼吸，2个计数为1个周期
    uint32_t fade_step_num; // 渐变步数总数
    uint32_t *fade_steps;   // 渐变步集，缓存着每一步渐变对应的PWM控制量
    uint32_t fade_cnt;      // 渐变步数计数
    bool delay_timer_start; // 延时定时器启动标志
    void *delay_timer;      // 延时定时器实例
} light_ch_t;

/**
 * @brief 灯光控制器定义
 */
typedef struct
{
    vesync_mutex_t mutex;    // 灯光控制器的互斥量
    bool timer_start;        // 定时器启动标志
    uint32_t timer_intvl;    // 定时器轮询间隔（毫秒）
    void *timer;             // 指向定时器实例
    void *cb_arg;            // 缓存的回调参数
    ch_ctrl_cb_t ch_ctrl_cb; // 灯光控制器的通道PWM控制量输出回调
    uint32_t max_duty;       // 最大占空比数值
    uint32_t *curr_duty;     // 各通道目前的占空比
    uint16_t ch_num;         // 灯光控制器的通道数量
    light_ch_t *ch_grp[0];   // 灯光控制器下的通道组
} light_t;

/**
 * @brief 灯效配置结构体
 */
typedef struct light_effect_cfg
{
    light_t *light;     // 灯光控制器实例指针
    uint16_t ch_idx;    // 目标通道号
    uint32_t period;    // 闪烁/呼吸周期 或 渐变时长（毫秒）
    uint32_t sc_num;    // 持续半周期数，0为持续
    uint32_t delay;     // 启动延时（毫秒）
    float bright;       // 最亮状态对应的亮度，取值范围为[0,1]
    float scale;        // 渐变步速，表示单步会改变多少的亮度，取值范围为[0,1]
    int (*cfg_action_cb)(struct light_effect_cfg *cfg); // 配置执行回调
} light_effect_cfg_t;

/**
 * @brief 灯光模块管理器定义
 */
typedef struct
{
    bool is_init;               // 灯光控制模块是否初始化标志
    vesync_mutex_t mutex;       // 灯光控制模块互斥量
    uint8_t light_num;          // 灯光控制器数量
    struct list_head light_grp; // 灯光控制器组
} light_mgmt_t;

/**
 * @brief 灯光模块灯光控制器链表节点定义
 */
typedef struct
{
    light_t *light;        // 指向灯光控制器实例
    struct list_head list; // 链表节点
} light_node_t;


/**
 * @brief 清除通道渐变流程的上下文
 * @param[in] p_l_chn       [指向目标通道]
 * @return int              [LIGHT_RESULT_E]
 */
int light_ch_fade_clr(light_ch_t *p_l_chn);


/**
 * @brief 创建一个灯光控制器实例，灯光控制器的创建数量不能超过LIGHT_NUM_MAX
 * @param[in] ch_num        [控制器的通道数量，通道数量不能超过LIGHT_CH_NUM_MAX]
 * @param[in] step_intvl    [PWM刷新单步的间隔，也就是定时器的Timeout，单位为毫秒]
 * @param[in] max_duty      [占空比的最大值]
 * @param[in] ch_ctrl_cb    [通道PWM控制量输出回调函数]
 * @param[in] cb_arg        [可选的自定义回调参数]
 * @return light_t          [返回创建的灯光控制器]
 * @return NULL             [创建失败]
 */
light_t *light_obj_create(uint16_t ch_num, uint32_t step_intvl, uint32_t max_duty, vesync_light_ctrl_cb_t ch_ctrl_cb, void *cb_arg);

/**
 * @brief 销毁一个灯光控制器实例
 * @param[in] p_obj         [灯光控制器对象]
 * @return int              [LIGHT_RESULT_E]
 */
int light_obj_destroy(light_t *p_obj);

/**
 * @brief 获取该灯光控制器的特定通道号的当前PWM控制量
 * @param[in] p_obj         [灯光控制器对象]
 * @param[in] ch_idx        [目标通道号]
 * @param[out] p_duty       [指向输出占空比的缓存]
 * @return int              [LIGHT_RESULT_E]
 */
int light_obj_get_duty(light_t *p_obj, uint16_t ch_idx, uint32_t *p_duty);

/**
 * @brief 设置该灯光控制器的特定通道号的伽马校正参数
 * @param[in] p_obj         [灯光控制器对象]
 * @param[in] ch_idx        [目标通道号]
 * @param[in] gamma         [新的伽马校正参数]
 * @return int              [LIGHT_RESULT_E]
 */
int light_obj_set_gamma(light_t *p_obj, uint16_t ch_idx, float gamma);

/**
 * @brief 配置该灯光控制器的特定通道号的PWM控制量，按照规定时长进行渐变的模式
 * @param[in] p_obj         [灯光控制器对象]
 * @param[in] ch_idx        [目标通道号]
 * @param[in] bright        [设置的目标亮度，取值范围为[0,1]]
 * @param[in] period        [渐变时长（毫秒），将影响内存占用]
 * @param[in] delay         [启动延时（毫秒）]
 * @return int              [LIGHT_RESULT_E]
 */
int light_obj_fade_with_time_cfg(light_t *p_obj, uint16_t ch_idx, float bright, uint32_t period, uint32_t delay);

/**
 * @brief 配置该灯光控制器的特定通道号的PWM控制量，按照规定步速进行渐变的模式
 * @param[in] p_obj         [灯光控制器对象]
 * @param[in] ch_idx        [目标通道号]
 * @param[in] bright        [设置的目标亮度，取值范围为[0,1]]
 * @param[in] scale         [渐变步速，表示单步会改变多少的亮度，取值范围为[0,1]。将影响内存占用]
 * @param[in] delay         [启动延时（毫秒）]
 * @return int              [LIGHT_RESULT_E]
 */
int light_obj_fade_with_step_cfg(light_t *p_obj, uint16_t ch_idx, float bright, float scale, uint32_t delay);

/**
 * @brief 配置该灯光控制器的特定通道号为均匀亮灭的闪烁模式
 * @param[in] p_obj         [灯光控制器对象]
 * @param[in] ch_idx        [目标通道号，通道需要已注册]
 * @param[in] bright        [闪烁中的亮状态的对应亮度，取值范围为[0,1]]
 * @param[in] period        [闪烁周期（毫秒），将影响内存占用]
 * @param[in] delay         [启动延时（毫秒）]
 * @param[in] sc_num        [持续半周期数，0为持续]
 * @return int              [LIGHT_RESULT_E]
 */
int light_obj_blink_cfg(light_t *p_obj, uint16_t ch_idx, float bright, uint32_t period, uint32_t delay, uint32_t sc_num);

/**
 * @brief 配置该灯光控制器的特定通道号为均匀亮灭的呼吸模式
 * @param[in] p_obj         [灯光控制器对象]
 * @param[in] ch_idx        [目标通道号，通道需要已注册]
 * @param[in] bright        [呼吸模式中最亮状态对应的亮度，取值范围为[0,1]]
 * @param[in] period        [呼吸周期（毫秒），将影响内存占用]
 * @param[in] delay         [启动延时（毫秒）]
 * @param[in] sc_num        [持续半周期数，0为持续]
 * @return int              [LIGHT_RESULT_E]

 */
int light_obj_breath_cfg(light_t *p_obj, uint16_t ch_idx, float bright, uint32_t period, uint32_t delay, uint32_t sc_num);

/**
 * @brief 启动该通道的渐变、闪烁或者呼吸模式
 * @param[in] p_obj         [灯光控制器对象]
 * @param[in] ch_idx        [目标通道号，通道需要已注册]
 * @return int              [LIGHT_RESULT_E]
 */
int light_obj_start(light_t *p_obj, uint16_t ch_idx);

/**
 * @brief 停止该通道的渐变、闪烁或者呼吸模式
 * @param[in] p_obj         [灯光控制器对象]
 * @param[in] ch_idx        [目标通道号，通道需要已注册]
 * @return int              [LIGHT_RESULT_E]
 */
int light_obj_stop(light_t *p_obj, uint16_t ch_idx);

#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_LIGHT_INTERNAL_H__ */
