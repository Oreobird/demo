/**
 * Copyright © Vesync Technologies Co.Ltd. 2022. All rights reserved.
 * @file        vesync_ble_muxer.c
 * @brief       BLE模块数据复用器的实现
 * @author      Herve
 * @date        2022-01-12
 */
#include <stdbool.h>
#include <string.h>

#include "vesync_ble_internal.h"
#include "vesync_log_internal.h"
#include "vesync_tl_payload_parse.h"
#include "vesync_common.h"
#include "vesync_list.h"
#include "vesync_memory.h"

typedef vesync_ble_mux_rx_cb_t rxer_cb_t;

// 接收者的链表节点定义
typedef struct
{
    rxer_cb_t rxer_cb;
    struct list_head list;
} rxer_t;

// 注册的接收者的链表头
static struct list_head s_rxers;

/**
 * @brief 根据接收者的回调函数寻找相应注册的接收者
 * @param[in]   rxer_cb         [接收者的回调函数]
 * @return      rxer_t*         [相应的接收者节点]
 * @return      NULL            [该回调函数未注册]
 */
static rxer_t *find_rxer(rxer_cb_t rxer_cb)
{
    rxer_t *p_pos, *p_n;
    list_for_each_entry_safe(p_pos, p_n, &s_rxers, list)
    {
        if (p_pos->rxer_cb == rxer_cb)
        {
            return p_pos;
        }
    }
    return NULL;
}

int32_t vesync_ble_muxer_init(void)
{
    memset(&s_rxers, 0, sizeof(s_rxers));
    INIT_LIST_HEAD(&s_rxers);

    SDK_LOG(LOG_INFO, "init success\n");
    return SDK_OK;
}

void vesync_ble_muxer_rx_cb(uint8_t *p_data, uint16_t len, bool need_ack)
{
    rxer_t *p_pos, *p_n;
    list_for_each_entry_safe(p_pos, p_n, &s_rxers, list)
    {
        if (true == p_pos->rxer_cb(p_data, len, need_ack))
        {
            return;     // 数据已经被消费，返回
        }
    }
}

int32_t vesync_ble_muxer_add_rxer(vesync_ble_mux_rx_cb_t rxer)
{
    if (NULL == rxer)
    {
        return SDK_FAIL;
    }
    rxer_t *p_exist = find_rxer(rxer);
    if (NULL == p_exist)
    {
        rxer_t *p_new_rxer = (rxer_t *)vesync_malloc(sizeof(rxer_t));
        if (NULL == p_new_rxer)
        {
            return SDK_FAIL;
        }
        memset(p_new_rxer, 0, sizeof(rxer_t));
        p_new_rxer->rxer_cb = rxer;
        list_add(&p_new_rxer->list, &s_rxers);

        SDK_LOG(LOG_INFO, "add rxer fn[%p]\n", rxer);
        return SDK_OK;
    }
    return SDK_FAIL;
}

int32_t vesync_ble_muxer_rm_rxer(vesync_ble_mux_rx_cb_t rxer)
{
    rxer_t *p_exist = find_rxer(rxer);
    if (NULL != p_exist)
    {
        list_del_init(&p_exist->list);
        vesync_free(p_exist);
        return SDK_OK;
    }
    return SDK_FAIL;
}
