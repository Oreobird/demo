/**
 * Copyright © Etekcity Technologies Co., Ltd. 2019-2099. All rights reserved.
 * @file ffs_rtos_configuration_map.c
 * @brief Ffs rtos configuration map
 *
 * @author  Owen.zhang
 * @date    2020-04-22
 */

#include <stdlib.h>
#include "ffs/common/ffs_result.h"
#include "ffs/common/ffs_check_result.h"
#include "ffs/common/ffs_stream.h"
#include "ffs/common/ffs_configuration_map.h"
#include "ffs_rtos_configuration_map.h"
#include "vesync_ffs_user_context.h"
#include "vesync_build_cfg.h"

#define CONFIGURATION_MAP_ENTRY_BUFFER_SIZE (64)

#define TEST_MANUFACTURER_NAME PR_BRAND //"ETEKCITY"
#define TEST_MODEL_NUMBER PR_MODEL      //"ESP32"
#define TEST_SERIAL_NUMBER "11412882"
#define TEST_PIN "H1Lo5YnC"
#define TEST_HARDWARE_REVISION PR_HW_VERSION //"0.0.0"
#define TEST_FIRMWARE_REVISION PR_FW_VERSION //"0.0.0"
#define TEST_CPU_ID "606699D00033"
#define TEST_DEVICE_NAME PR_MODEL            //"ESP32_DEMO"
#define TEST_PRODUCT_INDEX "rTvs"            //"Q9pp" //
#define TEST_SOFTWARE_REVISION PR_FW_VERSION //"0.0.0"

/**
 * @brief: Initialize EntryStream
 * @param FfsStream_t*
 * @param const char *
 * @param uint8_t
 * @return FFS_RESULT
 */
FFS_RESULT ffsInitializeEntryStream(FfsStream_t *stream, const char *entry, uint8_t buffSize)
{
    if (!stream)
    {
        ffsLogError("input params find NULL");
        FFS_FAIL(FFS_OVERRUN);
    }

    uint8_t *buffer = (uint8_t *)malloc(sizeof(uint8_t) * buffSize);
    if (!buffer)
        return FFS_ERROR;

    *stream = ffsCreateOutputStream(buffer, buffSize);

    if (entry)
    {
        FFS_CHECK_RESULT(ffsWriteStringToStream(entry, stream));
    }
    return FFS_SUCCESS;
}

/**
 * @brief: DeInitialize EntryStream
 * @param FfsStream_t*
 * @return FFS_RESULT
 */
FFS_RESULT ffsDeinitializeEntryStream(FfsStream_t *stream)
{
    if (!stream)
    {
        ffsLogError("input params find NULL");
        FFS_FAIL(FFS_OVERRUN);
    }

    if (FFS_STREAM_BUFFER(*stream))
        free(FFS_STREAM_BUFFER(*stream));
    FFS_CHECK_RESULT(ffsSetStreamToNull(stream));
    return FFS_SUCCESS;
}

/*
 * Initialize the Ffs Wi-Fi Linux configuration map.
 */
/**
 * @brief: DeInitialize EntryStream
 * @param FfsStream_t*
 * @return FFS_RESULT
 */
FFS_RESULT ffsInitializeConfigurationMap(FfsRTOSConfigMap_t *configurationMap)
{
    if (!configurationMap)
    {
        ffsLogError("input params find NULL");
        FFS_FAIL(FFS_OVERRUN);
    }

    FFS_CHECK_RESULT(ffsInitializeEntryStream(&configurationMap->manufacturerStream,
                                              TEST_MANUFACTURER_NAME, CONFIGURATION_MAP_ENTRY_BUFFER_SIZE));
    FFS_CHECK_RESULT(ffsInitializeEntryStream(&configurationMap->modelNumberStream,
                                              TEST_MODEL_NUMBER, CONFIGURATION_MAP_ENTRY_BUFFER_SIZE));
    FFS_CHECK_RESULT(ffsInitializeEntryStream(&configurationMap->serialNumberStream,
                                              TEST_SERIAL_NUMBER, CONFIGURATION_MAP_ENTRY_BUFFER_SIZE));
    FFS_CHECK_RESULT(ffsInitializeEntryStream(&configurationMap->pinStream,
                                              TEST_PIN, CONFIGURATION_MAP_ENTRY_BUFFER_SIZE));
    FFS_CHECK_RESULT(ffsInitializeEntryStream(&configurationMap->hardwareRevisionStream,
                                              TEST_HARDWARE_REVISION, CONFIGURATION_MAP_ENTRY_BUFFER_SIZE));
    FFS_CHECK_RESULT(ffsInitializeEntryStream(&configurationMap->softwareVersionIndexStream,
                                              TEST_SOFTWARE_REVISION, CONFIGURATION_MAP_ENTRY_BUFFER_SIZE));
    FFS_CHECK_RESULT(ffsInitializeEntryStream(&configurationMap->firmwareRevisionStream,
                                              TEST_FIRMWARE_REVISION, CONFIGURATION_MAP_ENTRY_BUFFER_SIZE));
    FFS_CHECK_RESULT(ffsInitializeEntryStream(&configurationMap->cpuIdStream,
                                              TEST_CPU_ID, CONFIGURATION_MAP_ENTRY_BUFFER_SIZE));
    FFS_CHECK_RESULT(ffsInitializeEntryStream(&configurationMap->deviceNameStream,
                                              TEST_DEVICE_NAME, CONFIGURATION_MAP_ENTRY_BUFFER_SIZE));

    FFS_CHECK_RESULT(ffsInitializeEntryStream(&configurationMap->productIndexStream,
                                              TEST_PRODUCT_INDEX, CONFIGURATION_MAP_ENTRY_BUFFER_SIZE));

    return FFS_SUCCESS;
}

/**
 * @brief: Deinitialize the Ffs Wi-Fi configuration map.
 * @param FfsRTOSConfigMap_t*
 * @return FFS_RESULT
 */
FFS_RESULT ffsDeinitializeConfigurationMap(FfsRTOSConfigMap_t *configurationMap)
{
    if (!configurationMap)
    {
        ffsLogError("input params find NULL");
        FFS_FAIL(FFS_OVERRUN);
    }

    FFS_CHECK_RESULT(ffsDeinitializeEntryStream(&configurationMap->manufacturerStream));
    FFS_CHECK_RESULT(ffsDeinitializeEntryStream(&configurationMap->modelNumberStream));
    FFS_CHECK_RESULT(ffsDeinitializeEntryStream(&configurationMap->serialNumberStream));
    FFS_CHECK_RESULT(ffsDeinitializeEntryStream(&configurationMap->pinStream));
    FFS_CHECK_RESULT(ffsDeinitializeEntryStream(&configurationMap->hardwareRevisionStream));
    FFS_CHECK_RESULT(ffsDeinitializeEntryStream(&configurationMap->firmwareRevisionStream));
    FFS_CHECK_RESULT(ffsDeinitializeEntryStream(&configurationMap->cpuIdStream));
    FFS_CHECK_RESULT(ffsDeinitializeEntryStream(&configurationMap->deviceNameStream));
    FFS_CHECK_RESULT(ffsDeinitializeEntryStream(&configurationMap->softwareVersionIndexStream));
    FFS_CHECK_RESULT(ffsDeinitializeEntryStream(&configurationMap->productIndexStream));
    return FFS_SUCCESS;
}

/**
 * @brief: Set a configuration value (\a e.g., country code).
 * @param FfsUserContext_s *
 * @param const char *
 * @param FfsMapValue_t *
 * @return FFS_RESULT
 */
FFS_RESULT ffsSetConfigurationMapValue(struct FfsUserContext_s *userContext, const char *configurationKey,
                                       FfsMapValue_t *configurationValue)
{
    if (!userContext || !configurationKey || !configurationValue)
    {
        ffsLogError("input params find NULL");
        FFS_FAIL(FFS_OVERRUN);
    }

    size_t len = 0;
    char *pBuf = NULL;
    FfsRTOSConfigMap_t *configurationMap = &userContext->configMap;

    ffsLogDebug("Storing configuration entry with key: %s", configurationKey);
    FfsStream_t *configurationEntryStream = NULL; //!< Destination configuration entry.

    switch (configurationValue->type)
    {
    case FFS_MAP_VALUE_TYPE_BOOLEAN:
        ffsLogInfo("Boolean value: %d", configurationValue->booleanValue);
        break;
    case FFS_MAP_VALUE_TYPE_INTEGER:
        ffsLogInfo("Integer value: %d", configurationValue->integerValue);
        break;
    case FFS_MAP_VALUE_TYPE_BYTES:
        ffsLogStream("Bytes value:", &configurationValue->bytesStream);
        break;
    case FFS_MAP_VALUE_TYPE_STRING:
        ffsLogStream("String value:", &configurationValue->stringStream);
        break;
    default:
        FFS_FAIL(FFS_ERROR);
    }

    if (!strcmp(configurationKey, FFS_CONFIGURATION_ENTRY_KEY_MANUFACTURER_NAME) && configurationValue->type == FFS_MAP_VALUE_TYPE_STRING)
    {
        configurationEntryStream = &configurationMap->manufacturerStream;
    }
    else if (!strcmp(configurationKey, FFS_CONFIGURATION_ENTRY_KEY_MODEL_NUMBER) && configurationValue->type == FFS_MAP_VALUE_TYPE_STRING)
    {
        configurationEntryStream = &configurationMap->modelNumberStream;
    }
    else if (!strcmp(configurationKey, FFS_CONFIGURATION_ENTRY_KEY_SERIAL_NUMBER) && configurationValue->type == FFS_MAP_VALUE_TYPE_STRING)
    {
        configurationEntryStream = &configurationMap->serialNumberStream;
    }
    else if (!strcmp(configurationKey, FFS_CONFIGURATION_ENTRY_KEY_HARDWARE_VERSION) && configurationValue->type == FFS_MAP_VALUE_TYPE_STRING)
    {
        configurationEntryStream = &configurationMap->hardwareRevisionStream;
    }
    else if (!strcmp(configurationKey, FFS_CONFIGURATION_ENTRY_KEY_FIRMWARE_VERSION) && configurationValue->type == FFS_MAP_VALUE_TYPE_STRING)
    {
        configurationEntryStream = &configurationMap->firmwareRevisionStream;
    }
    else if (!strcmp(configurationKey, FFS_CONFIGURATION_ENTRY_KEY_CPU_ID) && configurationValue->type == FFS_MAP_VALUE_TYPE_STRING)
    {
        configurationEntryStream = &configurationMap->cpuIdStream;
    }
    else if (!strcmp(configurationKey, FFS_CONFIGURATION_ENTRY_KEY_BLE_DEVICE_NAME) && configurationValue->type == FFS_MAP_VALUE_TYPE_STRING)
    {
        configurationEntryStream = &configurationMap->deviceNameStream;
    }
    else if (!strcmp(configurationKey, FFS_CONFIGURATION_ENTRY_KEY_PIN) && configurationValue->type == FFS_MAP_VALUE_TYPE_STRING)
    {
        configurationEntryStream = &configurationMap->pinStream;
    }
    else if (!strcmp(configurationKey, FFS_CONFIGURATION_ENTRY_KEY_SOFTWARE_VERSION_INDEX))
    {
        configurationValue->type = FFS_MAP_VALUE_TYPE_STRING;
        configurationEntryStream = &configurationMap->softwareVersionIndexStream;
    }
    else if (!strcmp(configurationKey, FFS_CONFIGURATION_ENTRY_KEY_DSS_SESSION_TOKEN) && configurationValue->type == FFS_MAP_VALUE_TYPE_STRING)
    {
        len = FFS_STREAM_DATA_SIZE(configurationValue->stringStream);
        pBuf = (char *)malloc(len + 1);
        if (NULL != pBuf)
        {
            userContext->sessoinToken = pBuf;
            memcpy(userContext->sessoinToken, FFS_STREAM_NEXT_READ(configurationValue->stringStream), len);
            userContext->sessoinToken[len] = 0;
            configurationEntryStream = &configurationValue->stringStream;
        }
    }
    else if (!strcmp(configurationKey, FFS_CONFIGURATION_ENTRY_KEY_LANGUAGE_LOCALE) && configurationValue->type == FFS_MAP_VALUE_TYPE_STRING)
    {
        len = FFS_STREAM_DATA_SIZE(configurationValue->stringStream);
        pBuf = (char *)malloc(len + 1);
        if (NULL != pBuf)
        {
            userContext->lang = pBuf;
            memcpy(userContext->lang, FFS_STREAM_NEXT_READ(configurationValue->stringStream), len);
            userContext->lang[len] = 0;
            configurationEntryStream = &configurationValue->stringStream;
        }
    }
    else if (!strcmp(configurationKey, FFS_CONFIGURATION_ENTRY_KEY_MARKETPLACE) && configurationValue->type == FFS_MAP_VALUE_TYPE_STRING)
    {
        len = FFS_STREAM_DATA_SIZE(configurationValue->stringStream);
        pBuf = (char *)malloc(len + 1);
        if (NULL != pBuf)
        {
            userContext->market = pBuf;
            memcpy(userContext->market, FFS_STREAM_NEXT_READ(configurationValue->stringStream), len);
            userContext->market[len] = 0;
            configurationEntryStream = &configurationValue->stringStream;
        }
    }
    else if (!strcmp(configurationKey, FFS_CONFIGURATION_ENTRY_KEY_ALEXA_EVENT_GATEWAY_ENDPOINT) && configurationValue->type == FFS_MAP_VALUE_TYPE_STRING)
    {
        len = FFS_STREAM_DATA_SIZE(configurationValue->stringStream);
        pBuf = (char *)malloc(len + 1);
        if (NULL != pBuf)
        {
            userContext->alexaEvtGwEp = pBuf;
            memcpy(userContext->alexaEvtGwEp, FFS_STREAM_NEXT_READ(configurationValue->stringStream), len);
            userContext->alexaEvtGwEp[len] = 0;
            configurationEntryStream = &configurationValue->stringStream;
        }
    }
    else if (!strcmp(configurationKey, FFS_CONFIGURATION_ENTRY_KEY_UTC_TIME) && configurationValue->type == FFS_MAP_VALUE_TYPE_STRING)
    {
        len = FFS_STREAM_DATA_SIZE(configurationValue->stringStream);
        pBuf = (char *)malloc(len + 1);
        if (NULL != pBuf)
        {
            userContext->utc = pBuf;
            memcpy(userContext->utc, FFS_STREAM_NEXT_READ(configurationValue->stringStream), len);
            userContext->utc[len] = 0;
            configurationEntryStream = &configurationValue->stringStream;
        }
    }

    if (!configurationEntryStream)
    {
        ffsLogWarning("Client does not support storing this configuration(%s)", configurationValue->stringStream.data);
        return FFS_NOT_IMPLEMENTED;
    }

    FFS_CHECK_RESULT(ffsFlushStream(configurationEntryStream));
    FFS_CHECK_RESULT(ffsAppendStream(&configurationValue->stringStream, configurationEntryStream));

    return FFS_SUCCESS;
}

/**
 * @brief: Get a configuration value (\a e.g., country code).
 * @param const char *
 * @param FfsMapValue_t *
 * @return FFS_RESULT
 */
FFS_RESULT ffsGetConfigurationMapValue(struct FfsUserContext_s *userContext, const char *configurationKey,
                                       FfsMapValue_t *configurationValue)
{
    if (!userContext || !configurationKey || !configurationValue)
    {
        ffsLogError("input params find NULL");
        FFS_FAIL(FFS_OVERRUN);
    }

    FfsRTOSConfigMap_t *configurationMap = &userContext->configMap;
    FfsStream_t configurationEntryStream = FFS_NULL_STREAM; //!< Copy of configuration entry stream.

    if (!strcmp(FFS_CONFIGURATION_ENTRY_KEY_MANUFACTURER_NAME, configurationKey))
    {
        configurationValue->type = FFS_MAP_VALUE_TYPE_STRING;
        configurationEntryStream = configurationMap->manufacturerStream;
    }
    else if (!strcmp(FFS_CONFIGURATION_ENTRY_KEY_MODEL_NUMBER, configurationKey))
    {
        configurationValue->type = FFS_MAP_VALUE_TYPE_STRING;
        configurationEntryStream = configurationMap->modelNumberStream;
    }
    else if (!strcmp(FFS_CONFIGURATION_ENTRY_KEY_SERIAL_NUMBER, configurationKey))
    {
        configurationValue->type = FFS_MAP_VALUE_TYPE_STRING;
        configurationEntryStream = configurationMap->serialNumberStream;
    }
    else if (!strcmp(FFS_CONFIGURATION_ENTRY_KEY_HARDWARE_VERSION, configurationKey))
    {
        configurationValue->type = FFS_MAP_VALUE_TYPE_STRING;
        configurationEntryStream = configurationMap->hardwareRevisionStream;
    }
    else if (!strcmp(FFS_CONFIGURATION_ENTRY_KEY_FIRMWARE_VERSION, configurationKey))
    {
        configurationValue->type = FFS_MAP_VALUE_TYPE_STRING;
        configurationEntryStream = configurationMap->firmwareRevisionStream;
    }
    else if (!strcmp(FFS_CONFIGURATION_ENTRY_KEY_CPU_ID, configurationKey))
    {
        configurationValue->type = FFS_MAP_VALUE_TYPE_STRING;
        configurationEntryStream = configurationMap->cpuIdStream;
    }
    else if (!strcmp(FFS_CONFIGURATION_ENTRY_KEY_BLE_DEVICE_NAME, configurationKey))
    {
        configurationValue->type = FFS_MAP_VALUE_TYPE_STRING;
        configurationEntryStream = configurationMap->deviceNameStream;
    }
    else if (!strcmp(FFS_CONFIGURATION_ENTRY_KEY_PIN, configurationKey))
    {
        configurationValue->type = FFS_MAP_VALUE_TYPE_STRING;
        configurationEntryStream = configurationMap->pinStream;
    }
    else if (!strcmp(FFS_CONFIGURATION_ENTRY_KEY_SOFTWARE_VERSION_INDEX, configurationKey))
    {
        configurationValue->type = FFS_MAP_VALUE_TYPE_STRING;
        configurationEntryStream = configurationMap->softwareVersionIndexStream;
    }
    else if (!strcmp(FFS_CONFIGURATION_ENTRY_KEY_PRODUCT_INDEX, configurationKey))
    {
        configurationValue->type = FFS_MAP_VALUE_TYPE_STRING;
        configurationEntryStream = configurationMap->productIndexStream;
    }
    else if (!strcmp(FFS_CONFIGURATION_ENTRY_KEY_DSS_HOST, configurationKey))
    {
        if (userContext->dssHost)
        {
            configurationValue->type = FFS_MAP_VALUE_TYPE_STRING;
            configurationEntryStream = FFS_STRING_INPUT_STREAM(userContext->dssHost);
        }
        else
        {
            ffsLogDebug("No custom DSS host provided.");
            return FFS_NOT_IMPLEMENTED;
        }
    }
    else if (!strcmp(FFS_CONFIGURATION_ENTRY_KEY_DSS_PORT, configurationKey))
    {
        if (userContext->hasDssPort)
        {
            configurationValue->type = FFS_MAP_VALUE_TYPE_INTEGER;
            configurationValue->integerValue = userContext->dssPort;
            return FFS_SUCCESS;
        }
        else
        {
            ffsLogDebug("No custom DSS port provided");
            return FFS_NOT_IMPLEMENTED;
        }
    }
    else if (!strcmp(FFS_CONFIGURATION_ENTRY_KEY_DEVICE_EC_PUBLIC_KEY_DER, configurationKey))
    {
        if (userContext->devicePublicKeyExt.buf && userContext->devicePublicKeyExt.len)
        {
            ffsLogDebug("Device public key is present.");
            configurationValue->type = FFS_MAP_VALUE_TYPE_BYTES;
            ffsLogDebug("devicePublicKey len is %d.", userContext->devicePublicKeyExt.len);
            FFS_CHECK_RESULT(ffsWriteStream((uint8_t *)userContext->devicePublicKeyExt.buf, userContext->devicePublicKeyExt.len, &configurationValue->bytesStream));
            return FFS_SUCCESS;
        }
        else
        {
            ffsLogError("Device public key not initialized.");
            return FFS_NOT_IMPLEMENTED;
        }
    }
    else if (!strcmp(FFS_CONFIGURATION_ENTRY_KEY_CLOUD_EC_PUBLIC_KEY_DER, configurationKey))
    {
        if (userContext->cloudPublicKey.buf && userContext->cloudPublicKey.len)
        {
            ffsLogDebug("Cloud public key is present.");
            configurationValue->type = FFS_MAP_VALUE_TYPE_BYTES;
            FFS_CHECK_RESULT(ffsWriteStream((uint8_t *)userContext->cloudPublicKey.buf, userContext->cloudPublicKey.len, &configurationValue->bytesStream));
            return FFS_SUCCESS;
        }
        else
        {
            ffsLogWarning("Cloud public key not initialized.");
            return FFS_NOT_IMPLEMENTED;
        }
    }
    else if (!strcmp(FFS_CONFIGURATION_ENTRY_KEY_DSS_SESSION_TOKEN, configurationKey))
    {
        if (userContext->sessoinToken)
        {
            configurationValue->type = FFS_MAP_VALUE_TYPE_STRING;
            configurationEntryStream = FFS_STRING_INPUT_STREAM(userContext->sessoinToken);
        }
        else
        {
            ffsLogDebug("No session token provided.");
            return FFS_NOT_IMPLEMENTED;
        }
    }
    else if (!strcmp(FFS_CONFIGURATION_ENTRY_KEY_LANGUAGE_LOCALE, configurationKey))
    {
        if (userContext->lang)
        {
            configurationValue->type = FFS_MAP_VALUE_TYPE_STRING;
            configurationEntryStream = FFS_STRING_INPUT_STREAM(userContext->lang);
        }
        else
        {
            ffsLogDebug("No Language Locale provided.");
            return FFS_NOT_IMPLEMENTED;
        }
    }
    else if (!strcmp(FFS_CONFIGURATION_ENTRY_KEY_MARKETPLACE, configurationKey))
    {
        if (userContext->market)
        {
            configurationValue->type = FFS_MAP_VALUE_TYPE_STRING;
            configurationEntryStream = FFS_STRING_INPUT_STREAM(userContext->market);
        }
        else
        {
            ffsLogDebug("No Market place provided.");
            return FFS_NOT_IMPLEMENTED;
        }
    }
    else if (!strcmp(FFS_CONFIGURATION_ENTRY_KEY_ALEXA_EVENT_GATEWAY_ENDPOINT, configurationKey))
    {
        if (userContext->alexaEvtGwEp)
        {
            configurationValue->type = FFS_MAP_VALUE_TYPE_STRING;
            configurationEntryStream = FFS_STRING_INPUT_STREAM(userContext->alexaEvtGwEp);
        }
        else
        {
            ffsLogDebug("No Alexa Event Gateway Endpoint provided.");
            return FFS_NOT_IMPLEMENTED;
        }
    }
    else if (!strcmp(FFS_CONFIGURATION_ENTRY_KEY_UTC_TIME, configurationKey))
    {
        if (userContext->utc)
        {
            configurationValue->type = FFS_MAP_VALUE_TYPE_STRING;
            configurationEntryStream = FFS_STRING_INPUT_STREAM(userContext->utc);
        }
        else
        {
            ffsLogDebug("No time UTC provided.");
            return FFS_NOT_IMPLEMENTED;
        }
    }
    else
    {
        ffsLogWarning("Unknown configuration key \"%s\"", configurationKey);

        // Don't check this since it may not be an error.
        return FFS_NOT_IMPLEMENTED;
    }

    FFS_CHECK_RESULT(ffsAppendStream(&configurationEntryStream, &configurationValue->stringStream));

    return FFS_SUCCESS;
}
