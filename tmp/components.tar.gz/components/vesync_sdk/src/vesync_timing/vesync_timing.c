/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_timing.c
 * @brief       倒计时处理
 * @author      Joshua
 * @date        2021-05-27
 */

#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#include "vesync_common.h"
#include "vesync_timer.h"
#include "vesync_log_internal.h"

#include "vesync_timing_internal.h"

static timing_data_t s_timing_arr[VESYNC_TIMING_NUM_MAX];
static vesync_timer_t *s_count_down_timer = NULL;

static timing_finish_cb_t s_timing_finish_cb = NULL;
static bool s_timing_start_finish = false;


/*-----------------------------------------------------------------------------*
 *                                 内部函数实现                          *
 *-----------------------------------------------------------------------------*/

/**
 * @brief 停止倒计时
 */
static void vesync_timing_stop(void)
{
    vesync_timer_stop(s_count_down_timer);
    s_timing_start_finish = false;
}


/**
 * @brief 倒计时滴答函数，每 DELAY_TICK_PERIOD 执行一次，该函数与时间戳无关
 */
static void vesync_timing_tick(void *arg)
{
    uint8_t i = 0;
    bool timing_remain = false;

    for (i = 0; i < VESYNC_TIMING_NUM_MAX; i++)
    {
        if (s_timing_arr[i].remain_second > 0)
        {
            s_timing_arr[i].remain_second--;
            timing_remain = true;
            //SDK_LOG(LOG_DEBUG, "timer%d second near %d s.\n",i+1,vesync_timer[i].second);
            if (0 == s_timing_arr[i].remain_second)
            {
                if (s_timing_finish_cb)
                {
                    s_timing_finish_cb(s_timing_arr[i].timing_id);
                }
            }
        }
    }

    if (!timing_remain)
    {
        vesync_timing_stop();
    }
}

/**
 * @brief 启动倒计时
 */
static void vesync_timing_start(void)
{
    if (s_timing_start_finish)
    {
        SDK_LOG(LOG_INFO, "vesync_timer_start repeat.\r\n");
        return;
    }

    s_count_down_timer = vesync_timer_new("count_down_timer",
                                          vesync_timing_tick,
                                          NULL,
                                          DELAY_TICK_PERIOD,
                                          true);
    if (s_count_down_timer == NULL)
    {
        SDK_LOG(LOG_ERROR, "Create count down timer fail!!!");
        return;
    }

    int ret = vesync_timer_start(s_count_down_timer);
    if (ret != VOS_OK)
    {
        SDK_LOG(LOG_ERROR, "Start count down timer fail!!!");
        return;
    }

    s_timing_start_finish = true;
}


/*-----------------------------------------------------------------------------*
 *                                 外部函数实现                          *
 *-----------------------------------------------------------------------------*/

/**
* @brief  vesync 倒计时初始化
*/
void vesync_timing_init(void)
{
    memset(s_timing_arr, 0, sizeof(s_timing_arr));
    vesync_timing_reg_cb(NULL);
    s_timing_start_finish = false;
}

/**
 * @brief  清空timer内容并停止执行, APP删除设备或设备手动复位时清空timer内容并停止
 */
void vesync_timing_clear(void)
{
    memset(s_timing_arr, 0, sizeof(s_timing_arr));
    vesync_timing_stop();
}


/**
 * @brief  清空当前ID的倒计时
 * @param[in] timing_id           [倒计时id]
 */
void vesync_timing_remove(uint16_t timing_id)
{
    uint16_t cnt = 0;

    for (cnt = 0; cnt < VESYNC_TIMING_NUM_MAX; cnt++)
    {
        if (s_timing_arr[cnt].timing_id == timing_id)
        {
            memset(&s_timing_arr[cnt], 0, sizeof(timing_data_t));
        }
    }
}


/**
 * @brief vesync timer注册回调函数
 * @param[in] time_update_cb      [回调函数]
 */
void vesync_timing_reg_cb(timing_finish_cb_t cb)
{
    s_timing_finish_cb = cb;
}

/**
 * @brief 获取倒计时剩余秒数
 * @param[in]  timing_id          [倒计时id]
 * @return uint32_t               [剩余秒数]
 */
uint32_t vesync_timing_get_remain_sec(uint16_t timing_id)
{
    uint32_t ret = 0;
    uint16_t cnt = 0;

    for (cnt = 0; cnt < VESYNC_TIMING_NUM_MAX; cnt++)
    {
        timing_data_t *p_timing = &s_timing_arr[cnt];
        if (p_timing->timing_id == timing_id)
        {
            ret = p_timing->remain_second;
        }
    }

    return ret;
}



/**
 * @brief vesync 添加倒计时业务
 * @param[in]  timing_id          [倒计时id，取值范围：1~VESYNC_TIMING_NUM_MAX]
 * @param[in]  second             [倒计时时间，单位秒]
 * @return  int                   [成功:SDK_OK, 失败:SDK_FAIL]
 */
int vesync_timing_add(uint16_t timing_id, uint32_t second)
{
    int ret = SDK_FAIL;
    uint16_t cnt = 0;
    bool timing_id_exist = false;

    if (0 == timing_id)
    {
        SDK_LOG(LOG_ERROR, "timing id invalid, should be 1 ~ %d\n", VESYNC_TIMING_NUM_MAX);
        return SDK_FAIL;
    }

    // 如果timing id已经存在，则更新对应的倒计时数据
    for (cnt = 0; cnt < VESYNC_TIMING_NUM_MAX; cnt++)
    {
        timing_data_t *p_timing = &s_timing_arr[cnt];
        if (timing_id == p_timing->timing_id)
        {
            p_timing->remain_second = second;
            p_timing->total_second = second;
            ret = SDK_OK;
            timing_id_exist = true;
            break;
        }
    }

    // timing_id不存在，添加到数组
    if (!timing_id_exist)
    {
        for (cnt = 0; cnt < VESYNC_TIMING_NUM_MAX; cnt++)
        {
            timing_data_t *p_timing = &s_timing_arr[cnt];

            if (p_timing->timing_id == 0)
            {
                p_timing->timing_id = timing_id;
                p_timing->remain_second = second;
                p_timing->total_second = second;
                ret = SDK_OK;
                break;
            }
        }
    }

    if ((SDK_OK == ret) && (false == s_timing_start_finish))
    {
        vesync_timing_start();
    }

    return ret;
}


/**
 * @brief 获取timer所有参数
 * @param[in]  timing_id          [倒计时id]
 * @param[out]  p_timing          [读取倒计时参数缓存指针]
 * @return int                    [成功:SDK_OK, 失败:SDK_FAIL]
 */
int vesync_timing_get(uint16_t timing_id ,timing_data_t *p_timing)
{
    int32_t  ret = SDK_FAIL;
    uint16_t cnt = 0;

    if (NULL == p_timing)
    {
        SDK_LOG(LOG_ERROR, "p_timing is NULL!");
        return ret;
    }

    for (cnt = 0; cnt < VESYNC_TIMING_NUM_MAX; cnt++)
    {
        timing_data_t *p_item = &s_timing_arr[cnt];
        if (p_item->timing_id == timing_id)
        {
            *p_timing = *p_item;
            ret = SDK_OK;
            break;
        }
    }

    return ret;
}

