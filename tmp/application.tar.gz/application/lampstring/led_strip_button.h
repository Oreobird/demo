/**
* Copyright © Vesync Technologies Co.Ltd. 2022. All rights reserved.
* @file    led_strip_button.h
* @brief   按键功能
* @author  Lind
* @date    2022-01-01
*/

#ifndef __LED_STRIP_BUTTON_H__
#define __LED_STRIP_BUTTON_H__

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

/**
 * @brief ledstrip button初始化
 */
int ls_button_init(void);

/**
 * @brief ledstrip button反初始化
 */
int ls_button_deinit(void);


#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* __LED_STRIP_BUTTON_H__ */
