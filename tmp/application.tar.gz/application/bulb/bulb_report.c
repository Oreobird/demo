/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        bulb_report.h
 * @brief       bulb状态上报
 * @author      Dave
 * @date        2021-09-09
 */


#include <string.h>

#include "cJSON.h"

#include "vesync_common.h"
#include "vesync_log.h"
#include "vesync_device.h"
#include "vesync_report.h"

#include "bulb_report.h"
#include "bulb_flash.h"


/**
 * @brief 设备状态变化，通知云端
 * @param[in]  status            [灯泡状态]
 * @return     int               [成功：APP_OK， 失败：APP_FAIL]
 */
int bulb_report_status_change(bulb_status_t* status)
{
    int ret = APP_FAIL;
    cJSON *json_data = NULL;
    cJSON *json_chg_stat = NULL;
    cJSON *json_unchg_stat = NULL;
    cJSON *json_hsvMode_stat = NULL;
    json_data = cJSON_CreateObject();
    if(NULL == json_data)
    {
        APP_LOG(LOG_ERROR, "Create data object fail");
        return APP_FAIL;
    }

    cJSON_AddItemToObject(json_data, "changedStatus", json_chg_stat = cJSON_CreateObject());
    cJSON_AddItemToObject(json_data, "unchangedStatus", json_unchg_stat = cJSON_CreateObject());
    cJSON_AddStringToObject(json_data, "changeReason", (char*)status->chg_rsn);

    if (NULL == json_chg_stat || NULL == json_unchg_stat)
    {
        APP_LOG(LOG_ERROR, "Create data object fail");
        ret = APP_FAIL;
        goto exit;
    }
    // 当changeReason为Setup/Reconnect/Unknown时，所有状态放在 unchangedStatus
    if (0 == strcmp((char*)status->chg_rsn, STAT_CHG_RSN_NONE_STR) ||
        0 == strcmp((char*)status->chg_rsn, STAT_CHG_RSN_CONFIG_NET_STR) ||
        0 == strcmp((char*)status->chg_rsn, STAT_CHG_RSN_RECONNECT_STR))
    {
        if(false == bulb_get_config(BULB_CFG_ONOFF))
        {
            cJSON_AddStringToObject(json_unchg_stat, "action", "off");
        }
        else
        {
            cJSON_AddStringToObject(json_unchg_stat, "action", bulb_get_config(BULB_CFG_ONOFF) ? "on" : "off");
            cJSON_AddStringToObject(json_unchg_stat, "mode",bulb_get_config(BULB_CFG_COLOR_MODE) ? "color":"white");
            //0为白色模式，1为彩色模式
            if( 0 == bulb_get_config(BULB_CFG_COLOR_MODE))
            {
                cJSON_AddNumberToObject(json_unchg_stat, "colorTempe",bulb_get_config(BULB_CFG_COLOR_TEMP));
                cJSON_AddNumberToObject(json_unchg_stat, "brightness", bulb_get_config(BULB_CFG_COLOR_BRIGHT));
            }
            else
            {
                cJSON_AddItemToObject(json_unchg_stat, "hsvMode", json_hsvMode_stat = cJSON_CreateObject());
                cJSON_AddNumberToObject(json_hsvMode_stat, "hue", bulb_get_config(BULB_CFG_COLOR_HUE));
                cJSON_AddNumberToObject(json_hsvMode_stat, "saturation", bulb_get_config(BULB_CFG_COLOR_SATURATION));
                cJSON_AddNumberToObject(json_hsvMode_stat, "value", bulb_get_config(BULB_CFG_COLOR_VALUE));
            }
        }
    }
    else
    {
        // 没有状态改变，无需上报
        if (0 == status->changeflag)
        {
            ret = APP_OK;
            goto exit;
        }
        else
        {
            switch(status->changeflag)
            {
                case BULB_ONOFF_CHANGE_FLAG:
                if(false == bulb_get_config(BULB_CFG_ONOFF))
                {
                    cJSON_AddStringToObject(json_chg_stat, "action", "off");
                }
                else
                {
                    cJSON_AddStringToObject(json_chg_stat, "action", bulb_get_config(BULB_CFG_ONOFF) ? "on" : "off");
                    cJSON_AddStringToObject(json_chg_stat, "mode",bulb_get_config(BULB_CFG_COLOR_MODE) ? "color":"white");
                    if(0 == bulb_get_config(BULB_CFG_COLOR_MODE))
                    {
                        cJSON_AddNumberToObject(json_chg_stat, "colorTempe", bulb_get_config(BULB_CFG_COLOR_TEMP));
                        cJSON_AddNumberToObject(json_chg_stat, "brightness", bulb_get_config(BULB_CFG_COLOR_BRIGHT));
                    }
                    else
                    {
                         cJSON_AddItemToObject(json_chg_stat, "hsvMode", json_hsvMode_stat = cJSON_CreateObject());
                         cJSON_AddNumberToObject(json_hsvMode_stat, "hue", bulb_get_config(BULB_CFG_COLOR_HUE));
                         cJSON_AddNumberToObject(json_hsvMode_stat, "saturation", bulb_get_config(BULB_CFG_COLOR_SATURATION));
                         cJSON_AddNumberToObject(json_hsvMode_stat, "value", bulb_get_config(BULB_CFG_COLOR_VALUE));

                    }
                }
                break;
                case BULB_MODE_CHANGE_FLAG:
                cJSON_AddStringToObject(json_unchg_stat, "action", "on");
                cJSON_AddStringToObject(json_chg_stat, "mode",bulb_get_config(BULB_CFG_COLOR_MODE) ? "color":"white");
                if( 0 == bulb_get_config(BULB_CFG_COLOR_MODE))
                {
                    cJSON_AddNumberToObject(json_chg_stat, "colorTempe", bulb_get_config(BULB_CFG_COLOR_TEMP));
                    cJSON_AddNumberToObject(json_chg_stat, "brightness", bulb_get_config(BULB_CFG_COLOR_BRIGHT));
                }
                else
                {
                     cJSON_AddItemToObject(json_chg_stat, "hsvMode", json_hsvMode_stat = cJSON_CreateObject());
                     cJSON_AddNumberToObject(json_hsvMode_stat, "hue", bulb_get_config(BULB_CFG_COLOR_HUE));
                     cJSON_AddNumberToObject(json_hsvMode_stat, "saturation", bulb_get_config(BULB_CFG_COLOR_SATURATION));
                     cJSON_AddNumberToObject(json_hsvMode_stat, "value", bulb_get_config(BULB_CFG_COLOR_VALUE));

                }
                break;
                case BULB_TEMP_CHANGE_FLAG:
                cJSON_AddStringToObject(json_unchg_stat, "action", "on");
                cJSON_AddStringToObject(json_unchg_stat, "mode","white");
                cJSON_AddNumberToObject(json_chg_stat, "colorTempe", bulb_get_config(BULB_CFG_COLOR_TEMP));
                cJSON_AddNumberToObject(json_unchg_stat, "brightness", bulb_get_config(BULB_CFG_COLOR_BRIGHT));
                break;
                case BULB_BRIGHT_CHANGE_FLAG:
                cJSON_AddStringToObject(json_unchg_stat, "action", "on");
                cJSON_AddStringToObject(json_unchg_stat, "mode","white");
                cJSON_AddNumberToObject(json_unchg_stat, "colorTempe", bulb_get_config(BULB_CFG_COLOR_TEMP));
                cJSON_AddNumberToObject(json_chg_stat, "brightness", bulb_get_config(BULB_CFG_COLOR_BRIGHT));
                break;
                case BULB_HSV_CHANGE_FLAG:
                cJSON_AddStringToObject(json_unchg_stat, "action", "on");
                cJSON_AddStringToObject(json_unchg_stat, "mode","color");
                cJSON_AddItemToObject(json_chg_stat, "hsvMode", json_hsvMode_stat = cJSON_CreateObject());
                cJSON_AddNumberToObject(json_hsvMode_stat, "hue", bulb_get_config(BULB_CFG_COLOR_HUE));
                cJSON_AddNumberToObject(json_hsvMode_stat, "saturation", bulb_get_config(BULB_CFG_COLOR_SATURATION));
                cJSON_AddNumberToObject(json_hsvMode_stat, "value", bulb_get_config(BULB_CFG_COLOR_VALUE));
                break;
                default:
                APP_LOG(LOG_DEBUG,"unkonwn change\n");
                break;
            }
        }
    }
    //上报设备的状态改变
    if (SDK_OK != vesync_report_status_change_nty(json_data))
    {
        return APP_FAIL;
    }
    return APP_OK;
exit:
    cJSON_Delete(json_data);
    return ret;
}


/**
 * @brief timer执行结果上报， deviceLogReport
 * @param[in]  action           [动作]
 * @param[in]  ret              [timer执行结果]
 * @param[in]  p_err_msg        [开timer执行失败原因]
 * @return     int              [成功：APP_OK， 失败：APP_FAIL]
 */
int bulb_report_timing_exec( void *action, uint8_t ret, char *p_err_msg)
{
    cJSON *json_data = NULL;

    // 参数判断
    if ( NULL == action || NULL == p_err_msg)
    {
        APP_LOG(LOG_ERROR, "invalid parameter!!\n");
        return APP_FAIL;
    }
    json_data = cJSON_CreateObject();
    if (NULL == json_data)
    {
        APP_LOG(LOG_ERROR, "Create object fail\n");
        return APP_FAIL;
    }
    cJSON_AddStringToObject(json_data, "subDeviceType", "bulb");
    if (false == ((bulb_action_t*)action)->onoff)
    {
        cJSON_AddStringToObject(json_data, "act", "timer exec: switch=off");
    }
    else
    {
        cJSON_AddStringToObject(json_data, "act", "timer exec: switch=on");
        if (0 != ((bulb_action_t*)action)->mode)
        {
            cJSON_AddStringToObject(json_data, "colormode", "color");
            cJSON_AddNumberToObject(json_data, "hue", ((bulb_action_t*)action)->hue);
            cJSON_AddNumberToObject(json_data, "saturation", ((bulb_action_t*)action)->saturation);
            cJSON_AddNumberToObject(json_data, "value", ((bulb_action_t*)action)->value);
        }
        else
        {
            cJSON_AddStringToObject(json_data, "colormode", "white");
            cJSON_AddNumberToObject(json_data, "temp", ((bulb_action_t*)action)->temp);
            cJSON_AddNumberToObject(json_data, "bright", ((bulb_action_t*)action)->bright);
        }
    }
    if (APP_OK == ret)
    {
        cJSON_AddStringToObject(json_data, "result", "success");
    }
    else
    {
        cJSON_AddStringToObject(json_data, "result", "fail");
        cJSON_AddStringToObject(json_data, "reason", p_err_msg);
    }
    //上报设备的运行日志
    if (SDK_OK != vesync_report_device_log(json_data))
    {
        return APP_FAIL;
    }
    return APP_OK;
}



/**
 * @brief schedule执行结果上报， deviceLogReport
 * @param[in]  sch_cfg          [schedule配置]
 * @param[in]  action           [动作]
 * @param[in]  ret              [schedule执行结果]
 * @param[in]  p_err_msg        [schedule执行失败原因]
 * @return     int              [成功：APP_OK， 失败：APP_FAIL]
 */
int bulb_report_schedule_exec(vesync_schedule_t *sch_cfg, void *action, uint8_t ret, char *p_err_msg)
{
    cJSON *json_data = NULL;

    // 参数判断
    if ( NULL == action || NULL == p_err_msg)
    {
        APP_LOG(LOG_ERROR, "invalid parameter!!\n");
        return APP_FAIL;
    }
    json_data = cJSON_CreateObject();
    if (NULL == json_data)
    {
        APP_LOG(LOG_ERROR, "Create object fail\n");
        return APP_FAIL;
    }
    cJSON_AddNumberToObject(json_data, "schID", sch_cfg->id);
    cJSON_AddNumberToObject(json_data, "type", sch_cfg->type);
    cJSON_AddNumberToObject(json_data, "repeat", sch_cfg->repeat_config);
    if (false == ((bulb_action_t*)action)->onoff)
    {
        cJSON_AddStringToObject(json_data, "act", "timer exec: switch=off");
    }
    else
    {
        cJSON_AddStringToObject(json_data, "act", "timer exec: switch=on");
        if (0 != ((bulb_action_t*)action)->mode)
        {
            cJSON_AddStringToObject(json_data, "colormode", "color");
            cJSON_AddNumberToObject(json_data, "hue", ((bulb_action_t*)action)->hue);
            cJSON_AddNumberToObject(json_data, "saturation", ((bulb_action_t*)action)->saturation);
            cJSON_AddNumberToObject(json_data, "value", ((bulb_action_t*)action)->value);
        }
        else
        {
            cJSON_AddStringToObject(json_data, "colormode", "white");
            cJSON_AddNumberToObject(json_data, "temp", ((bulb_action_t*)action)->temp);
            cJSON_AddNumberToObject(json_data, "bright", ((bulb_action_t*)action)->bright);
        }
    }
    if (APP_OK == ret)
    {
        cJSON_AddStringToObject(json_data, "result", "success");
    }
    else
    {
        cJSON_AddStringToObject(json_data, "result", "fail");
        cJSON_AddStringToObject(json_data, "reason", p_err_msg);
    }
    if (SDK_OK != vesync_report_device_log(json_data))
    {
        return APP_FAIL;
    }
    return APP_OK;
}

