/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_tcp.c
 * @brief       局域网通信-TCP初始化、TCP数据接收、TCP连接监听、TCP socket 关闭等接口
 * @author      henrikzhou
 * @date        2020-9-21
 */

#include <string.h>

#if defined(CONFIG_TARGET_LINUX)
#include <sys/types.h>
#include <sys/socket.h>
#include <unistd.h>
#include <errno.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#else
#include "lwip/netif.h"
#include "lwip/tcpip.h"
#include "netif/etharp.h"
//#include "netinet/tcp.h"
#endif

#include "vesync_common.h"
#include "vesync_log_internal.h"
#include "vesync_lan_comm_tcp.h"

/**
 * @brief 初始化TCP server
 * @param[in] addr              [tcp server socket 结构体地址]
 * @param[in] fd                [tcp sever socket 句柄指针]
 * @param[in] port              [tcp sever 端口]
 * @param[in] listen_num        [tcp sever 监听未连接队列长度]
 * @return int                  [成功/失败]
 */
int vesync_tcp_sever_init(struct sockaddr_in* addr, int* fd,uint32_t port,int listen_num)
{
    int ret = -1;
    int reuse = 1;

    if ((NULL == addr)||(NULL == fd))
    {
        return ret;
    }

    if (0 <= (*fd) )
    {
        SDK_LOG(LOG_ERROR, "tcp server already started.\n");
        return 0;
    }

    memset(addr, 0, sizeof(struct  sockaddr_in));
    //addr->sin_len = sizeof(struct sockaddr_in);
    addr->sin_family = AF_INET;
    addr->sin_port = htons(port);
    addr->sin_addr.s_addr = htonl(INADDR_ANY);

    *fd = socket(AF_INET, SOCK_STREAM, 0);
    if (0 > (*fd))
    {
        SDK_LOG(LOG_ERROR, "TCP server create failed.\n");
        return -1;
    }

    SDK_LOG(LOG_DEBUG, "TCP server create successful.\n");

    setsockopt(*fd, SOL_SOCKET, SO_REUSEADDR, &reuse, sizeof(reuse));
    //setsockopt(*fd, SOL_SOCKET, SO_REUSEPORT, &reuse, sizeof(reuse));

    ret = bind(*fd, (struct sockaddr*)addr, sizeof(struct sockaddr_in));
    if (ret < 0)
    {
        SDK_LOG(LOG_ERROR, "TCP server bind failed.\n");
        vesync_tcp_stop(fd);
        return -1;
    }

    ret = listen(*fd, listen_num);
    if (ret < 0)
    {
        SDK_LOG(LOG_ERROR, "TCP server listen failed.\n");
        vesync_tcp_stop(fd);
        return -1;
    }

    SDK_LOG(LOG_DEBUG, "TCP server listen successful.\n");
    return 0;
}

/**
 * @brief TCP server 连接监听接口
 * @param[in] fd                [tcp sever socket 句柄指针]
 * @param[in] accept_fd         [tcp 连接句柄指针]
 * @param[in] tcp_addr          [tcp server socket 结构体地址]
 * @param[in] timeout_ms        [tcp server 连接监听超时时间，单位毫秒]
 * @return int                  [成功/失败]
 */
int vesync_tcp_sever_accept( int fd,int *accept_fd,struct sockaddr_in* tcp_addr,int timeout_ms)
{
    int keep_alive = VESYNC_TCP_SERVER_KEEPALIVE; // 非0值，开启keepalive属性
    int keep_idle = VESYNC_TCP_SERVER_KEEPIDLE;// 如该连接在5秒内没有任何数据往来,则进行此TCP层的探测
    int keep_interval = VESYNC_TCP_SERVER_KEEPINTV;// 探测发包间隔为1秒
    int keep_count = VESYNC_TCP_SERVER_KEEPCNT; // 尝试探测的最多次数

    if ((NULL == accept_fd)||(NULL == tcp_addr))
    {
        return -1;
    }

    int ret = 0;
    struct timeval timeout;
    fd_set fdset;
    socklen_t sockaddr_len = sizeof(struct sockaddr_in);

    FD_ZERO(&fdset);
    FD_SET(fd, &fdset);

    timeout.tv_sec = 0;
    timeout.tv_usec = timeout_ms * 1000;

    ret = select(fd + 1, &fdset, 0, 0, &timeout);
    if (ret == 0)
    {
        return ret;
    }
    else if (ret < 0)
    {
        SDK_LOG(LOG_ERROR, "select error .\n");
        return ret;
    }

    if (FD_ISSET(fd, &fdset))
    {
        *accept_fd = accept(fd,(struct sockaddr *)tcp_addr,&sockaddr_len);
        if (0 > (*accept_fd))
        {
            SDK_LOG(LOG_ERROR, "TCP server accept error : %d, sock_id = %d.\n", *accept_fd, fd);
            return -1;
        }

        SDK_LOG(LOG_INFO, "TCP client connected, socket_fd = %d.\n",fd);
        setsockopt(*accept_fd, SOL_SOCKET, SO_KEEPALIVE, (void *)&keep_alive, sizeof(int));
        setsockopt(*accept_fd, IPPROTO_TCP, TCP_KEEPIDLE, (void*)&keep_idle, sizeof(int));
        setsockopt(*accept_fd, IPPROTO_TCP, TCP_KEEPINTVL, (void *)&keep_interval, sizeof(int));
        setsockopt(*accept_fd, IPPROTO_TCP, TCP_KEEPCNT, (void *)&keep_count, sizeof(int));
    }

    SDK_LOG(LOG_INFO, "TCP server accept exit.\n");
    return 0;
}

/**
 * @brief TCP server 数据接收监听接口
 * @param[in] fd                [tcp 连接句柄指针]
 * @param[in] timeout_ms        [tcp server 数据接收监听超时时间，单位毫秒]
 * @param[out] buffer           [tcp 数据接收缓存起始地址]
 * @param[in]  len              [数据接收缓存的最大长度]
 * @return int                  [成功/失败/实际接收数据长度]
 */
int vesync_tcp_recv(int fd, int timeout_ms, char *buffer, int len)
{
    if (NULL == buffer)
    {
        return -1;
    }

    int recv_len = 0, rc = 0, ret = 0,erro = 0;
    uint32_t err_len = sizeof(int);
    struct timeval timeout;
    fd_set fdset;

    FD_ZERO(&fdset);
    FD_SET(fd, &fdset);

    timeout.tv_sec = 0;
    timeout.tv_usec = timeout_ms * 1000;

    ret = select(fd + 1, &fdset, 0, 0, &timeout);
    if (ret == 0)
    {
        return ret;
    }
    else if (ret < 0)
    {
        SDK_LOG(LOG_ERROR, "select error\n");
        return ret;
    }

    if (FD_ISSET(fd, &fdset))
    {
        rc = recv(fd, buffer, len, MSG_DONTWAIT);
        if (rc > 0)
        {
            recv_len = rc;
        }
        else
        {
            recv_len = (rc < 0) ? rc : -1;

            getsockopt(fd, SOL_SOCKET, SO_ERROR, (void *)&erro, &err_len);
            SDK_LOG(LOG_WARN, "tcp recv return:%d, errno:%d\n", rc, erro);
        }
    }

    return recv_len;
}

/**
 * @brief 关闭TCP 连接或者 tcp server
 * @param[in] fd             [tcp 句柄指针]
 */
void vesync_tcp_stop(int* fd)
{
    if ((NULL != fd)&&(0 <= (*fd)))
    {
        close(*fd);
        *fd = -1;
    }
}

/**
 * @brief 获取TCP server  连接状态
 * @param[in] fd             [tcp sever 句柄]
 * @return int               [连接/断开，0:连接/-1:断开]
 */
int vesync_get_tcp_conn_state(int fd)
{
//    struct tcp_info info;
//    int len = sizeof(info);

//    getsockopt(fd,IPPROTO_TCP, TCP_INFO, &info, (socklen_t *)&len);
//    if (TCP_ESTABLISHED == info.tcpi_state)
//    {
//        return 0;
//    }

    return -1;
}


