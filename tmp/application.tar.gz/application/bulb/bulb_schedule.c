/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        bulb_schedule.c
 * @brief       bulb schedule
 * @author      Dave
 * @date        2021-09-02
 */

#include <string.h>
#include <stdio.h>
#include <stdbool.h>

#include "vesync_common.h"
#include "vesync_log.h"
#include "vesync_memory.h"
#include "vesync_schedule.h"
#include "vesync_device.h"
#include "vesync_klv.h"

#include "vhal_flash.h"

#include "bulb.h"
#include "bulb_report.h"
#include "bulb_schedule.h"
#include "bulb_status.h"

static bulb_status_t s_bulb_status;

/**
 * @brief  Schedule模块action数据KLV组装
 * @param[in]   app_cfg_buf     [Schedule配置存储buff]
 * @param[in]   action          [Schedule动作]
 * @return int                  [成功：APP_OK， 失败：APP_FAIL]
 */
static int bulb_pack_schedule_action(vesync_buf_t *app_cfg_buf,bulb_action_t *action)
{
    uint8_t *p_buf= NULL;
    int offset = 0;

    if(NULL == (p_buf = (uint8_t *)vesync_malloc(BULB_KLV_DATA_LEN)))
    {
        return APP_FAIL;
    }

    memset(p_buf, 0, BULB_KLV_DATA_LEN);

    //组装KLV数据
    offset +=  vesync_klv_set(p_buf+offset, BULB_KLV_DATA_LEN-offset, BULB_KEY_ONOFF, sizeof(action->onoff), &action->onoff);
    offset +=  vesync_klv_set(p_buf+offset, BULB_KLV_DATA_LEN-offset, BULB_KEY_COLOR_MODE, sizeof(action->mode), &action->mode);
    offset +=  vesync_klv_set(p_buf+offset, BULB_KLV_DATA_LEN-offset, BULB_KEY_COLOR_TEMP, sizeof(action->temp), &action->temp);
    offset +=  vesync_klv_set(p_buf+offset, BULB_KLV_DATA_LEN-offset, BULB_KEY_COLOR_BRIGHT, sizeof(action->bright), &action->bright);
    offset +=  vesync_klv_set(p_buf+offset, BULB_KLV_DATA_LEN-offset, BULB_KEY_COLOR_HUE, sizeof(action->hue), (uint8_t*)&action->hue);
    offset +=  vesync_klv_set(p_buf+offset, BULB_KLV_DATA_LEN-offset, BULB_KEY_COLOR_SATURATION, sizeof(action->saturation), (uint8_t*)&action->saturation);
    offset +=  vesync_klv_set(p_buf+offset, BULB_KLV_DATA_LEN-offset, BULB_KEY_COLOR_VALUE, sizeof(action->value), &action->value);
    vesync_buf_set(app_cfg_buf, (void*)p_buf, offset);
    vesync_free(p_buf);
    return APP_OK;

}

/**
* @brief  Schedule模块action数据KLV组装
* @param[in]   app_cfg_buf     [Schedule配置获取buff]
* @param[in]   action          [Schedule动作]
* @return int                  [成功：APP_OK， 失败：APP_FAIL]
*/
static int bulb_read_scedule_data(vesync_buf_t* app_cfg_buf,bulb_action_t *action)
{
    if (NULL == action)
    {
        return APP_FAIL;
    }
    vesync_klv_get(app_cfg_buf->buf, app_cfg_buf->len, BULB_KEY_ONOFF, sizeof(action->onoff), &action->onoff);
    vesync_klv_get(app_cfg_buf->buf, app_cfg_buf->len, BULB_KEY_COLOR_MODE, sizeof(action->mode), &action->mode);
    vesync_klv_get(app_cfg_buf->buf, app_cfg_buf->len, BULB_KEY_COLOR_BRIGHT, sizeof(action->bright), &action->bright);
    vesync_klv_get(app_cfg_buf->buf, app_cfg_buf->len, BULB_KEY_COLOR_TEMP, sizeof(action->temp), &action->temp);
    vesync_klv_get(app_cfg_buf->buf, app_cfg_buf->len, BULB_KEY_COLOR_HUE, sizeof(action->hue), (uint8_t*)&action->hue);
    vesync_klv_get(app_cfg_buf->buf, app_cfg_buf->len, BULB_KEY_COLOR_SATURATION, sizeof(action->saturation), (uint8_t*)&action->saturation);
    vesync_klv_get(app_cfg_buf->buf, app_cfg_buf->len, BULB_KEY_COLOR_VALUE, sizeof(action->value), (uint8_t*)&action->value);
    return APP_OK;
}

/**
 * @brief  Schedule模块配置写入回调
 * @param[in]   p_wr_buf    [Schedule配置保存buff]
 * @param[in]   len         [Schedule保存buff长度]
 * @return int              [返回Schedule配置写入结果]
 */
static int bulb_sche_wr_cfg_cb(uint8_t *p_wr_buf, uint32_t len)
{
    if (NULL == p_wr_buf || len == 0)
    {
        return SCHE_ERR;
    }

    int ret = vhal_flash_write(PARTITION_CFG, BULB_SCHEDULE_MOD_CFG_KEY, p_wr_buf, len);
    if (VHAL_OK != ret)
    {
        APP_LOG(LOG_WARN, "flash write fail[%d]\n", ret);

        return SCHE_ERR;
    }

    return SCHE_OK;
}

/**
 * @brief   Schedule模块配置读取回调
 * @param[in]   p_rd_buf         [Schedule配置保存buff]
 * @param[in]   p_rd_len         [Schedule配置读取长度]
 * @return int                   [返回Schedule配置读取结果]
 */
static int bulb_sche_rd_cfg_cb(uint8_t *p_rd_buf, uint32_t buf_len, uint32_t *p_rd_len)
{
    UNUSED(buf_len);

    if (NULL == p_rd_len)
    {
        return SCHE_ERR;
    }

    /// @attention: p_rd_buf为NULL，返回存储数据的长度
    int ret = vhal_flash_read(PARTITION_CFG, BULB_SCHEDULE_MOD_CFG_KEY, p_rd_buf, p_rd_len);
    if (VHAL_OK != ret)
    {
        APP_LOG(LOG_WARN, "flash read fail[%d]\n", ret);

        // 将读取长度设为0，当作配置不存在
        *p_rd_len = 0;
    }
    return SCHE_OK;
}


/**
 * @brief 灯schedule执行回调
 * @param[in]   sch_cfg     [Schedule配置]
 * @param[in]   app_cfg     [Schedule动作]
 * @return int              [[返回Schedule执行结果]
 */
static int bulb_schedule_exec_cb(vesync_schedule_t sch_cfg, vesync_buf_t app_cfg)
{
    int ret = APP_OK;
    s_bulb_status.changeflag = 0;
    strncpy(s_bulb_status.chg_rsn, STAT_CHG_RSN_SCHD_STR, sizeof(s_bulb_status.chg_rsn) - 1);
    if (app_cfg.len < sizeof(bulb_action_t))
    {
        return SCHE_ERR;
    }
    bulb_action_t bulb_action;
    memset(&bulb_action, 0, sizeof(bulb_action_t));
    bulb_read_scedule_data(&app_cfg,&bulb_action);
    APP_LOG(LOG_INFO, "Schedule task executes. sche_id:[%ld]\n", sch_cfg.id);
    if (bulb_get_config(BULB_CFG_ONOFF) != bulb_action.onoff)
    {
        bulb_update_config(BULB_CFG_ONOFF, bulb_action.onoff);
        s_bulb_status.changeflag = BULB_ONOFF_CHANGE_FLAG;
    }
    if (1 == bulb_action.onoff)
    {
        if (bulb_get_config(BULB_CFG_COLOR_MODE) != bulb_action.mode)
        {
            s_bulb_status.changeflag = (s_bulb_status.changeflag > 0) ? s_bulb_status.changeflag : BULB_MODE_CHANGE_FLAG;
        }
        if(0 == bulb_action.mode)
        {
            bulb_update_config(BULB_CFG_COLOR_MODE, 0);
            bulb_update_config(BULB_CFG_COLOR_BRIGHT, bulb_action.bright);
            if (bulb_get_config(BULB_CFG_COLOR_BRIGHT) != bulb_action.bright)
            {
                s_bulb_status.changeflag = (s_bulb_status.changeflag > 0) ? s_bulb_status.changeflag : BULB_BRIGHT_CHANGE_FLAG;
            }
            bulb_update_config(BULB_CFG_COLOR_TEMP, bulb_action.temp);
            if (bulb_get_config(BULB_CFG_COLOR_TEMP) != bulb_action.temp)
            {
                s_bulb_status.changeflag = (s_bulb_status.changeflag > 0) ? s_bulb_status.changeflag : BULB_TEMP_CHANGE_FLAG;
            }
        }
        else
        {
            bulb_update_config(BULB_CFG_COLOR_MODE, 1);
            if (bulb_get_config(BULB_CFG_COLOR_HUE) != bulb_action.hue || bulb_get_config(BULB_CFG_COLOR_SATURATION) != bulb_action.saturation
                || bulb_get_config(BULB_CFG_COLOR_VALUE) != bulb_action.value)
            {
                s_bulb_status.changeflag = (s_bulb_status.changeflag > 0) ? s_bulb_status.changeflag : BULB_HSV_CHANGE_FLAG;
            }
            bulb_update_config(BULB_CFG_COLOR_HUE, bulb_action.hue);
            bulb_update_config(BULB_CFG_COLOR_SATURATION, bulb_action.saturation);
            bulb_update_config(BULB_CFG_COLOR_VALUE, bulb_action.value);
        }
    }
    bulb_open();
    bulb_report_status_change(&s_bulb_status);
    if (APP_OK != ret)
    {
        bulb_report_schedule_exec( &sch_cfg, &bulb_action, ret, "status change fail\n");
    }
    else
    {
        bulb_report_schedule_exec( &sch_cfg, &bulb_action, ret, "status change success\n");
    }
    return SCHE_OK;

}


/**
 * @brief Bypass添加Schedule配置项
 * @param[in]   sch_cfg     [Schedule配置]
 * @param[in]   action      [Schedule动作]
 * @param[out]  p_out_id    [添加成功后，返回生成的ID]
 * @return int              [返回BYPASS的错误定义]
 */
int bulb_schedule_add(vesync_schedule_t *sch_cfg, void *action, uint32_t *p_out_id)
{
    int err_code = BP_ERR_NO_ERR;
    int ret = SCHE_ERR;

    if (NULL == sch_cfg || NULL == action || NULL == p_out_id)
    {
        return BP_ERR_CMD_EXECUTE_FAIL;
    }
    // 缓存应用层的配置
    vesync_buf_t app_cfg_buf = vesync_buf_new();
    ret = bulb_pack_schedule_action(&app_cfg_buf,action);
    if (ret == APP_FAIL)
    {
        err_code = BP_ERR_OUT_OF_MEMORY;
        goto exit;
    }
    ret = vesync_schedule_add(BULB_SCHE_INS_ID, sch_cfg, &app_cfg_buf, true);
    if (ret != SCHE_OK)
    {
        APP_LOG(LOG_WARN, "Schedule added fail: %d\n", ret);
        if (ret == SCHE_CFLT_ERR)
        {
            err_code = BP_ERR_SCHEDULE_CONFLICT;
            goto exit;
        }
        if (ret == SCHE_EXCEED_MAX)
        {
            err_code = BP_ERR_SCHEDULE_EXCEED_MAX;
            goto exit;
        }
        err_code = BP_ERR_CMD_EXECUTE_FAIL;
        goto exit;
    }
    // 添加的配置项ID返回给BP调用端
    *p_out_id = sch_cfg->id;

exit:
    vesync_buf_clr(&app_cfg_buf);
    return err_code;

}

/**
 * @brief Bypass更新Schedule配置项
 * @param[in]   sch_cfg     [Schedule配置]
 * @param[in]   action      [Schedule动作]
 * @param[out]  p_out_id    [添加成功后，返回生成的ID]
 * @return int              [返回BYPASS的错误定义]
 */
int bulb_schedule_upd( vesync_schedule_t *sch_cfg, void *action, uint32_t *p_out_id)
{
    int err_code = BP_ERR_NO_ERR;
    int ret = SCHE_ERR;

    if (NULL == sch_cfg || NULL == p_out_id)
    {
        return BP_ERR_CMD_EXECUTE_FAIL;
    }
    // ID 是必选项
    if (0 == sch_cfg->id || BULB_SCHEDULE_MIN_ID > sch_cfg->id)
    {
        return BP_ERR_PARA_ILLEGAL;
    }
    // 缓存应用层的配置
    vesync_buf_t app_cfg_buf = vesync_buf_new();
    vesync_schedule_t old_sch_cfg;
    // 使用旧action
    ret = vesync_schedule_get_by_id(BULB_SCHE_INS_ID, sch_cfg->id, &old_sch_cfg, &app_cfg_buf);
    if (NULL == action)
    {
        vesync_schedule_t old_sch_cfg;
        // 使用旧action
        ret = vesync_schedule_get_by_id(BULB_SCHE_INS_ID, sch_cfg->id, &old_sch_cfg, &app_cfg_buf);
        if (ret != SCHE_OK)
        {
            if (ret != SCHE_INV_ID_ERR)
            {
                err_code = BP_ERR_UNDEFINE;
                goto exit;
            }
            err_code = BP_ERR_SCHEDULE_NOT_FOUND;
            goto exit;
        }
        ret = vesync_schedule_upd(BULB_SCHE_INS_ID, sch_cfg, &app_cfg_buf);
    }
    else
    {
        ret = bulb_pack_schedule_action(&app_cfg_buf, action);
        if (ret == APP_FAIL)
        {
            err_code = BP_ERR_OUT_OF_MEMORY;
            goto exit;
        }
        ret = vesync_schedule_upd(BULB_SCHE_INS_ID, sch_cfg, &app_cfg_buf);
    }
    if (ret != SCHE_OK)
    {
        if (ret != SCHE_CFLT_ERR)
        {
            err_code = BP_ERR_CMD_EXECUTE_FAIL;
            goto exit;
        }

        err_code = BP_ERR_SCHEDULE_CONFLICT;
        goto exit;
    }
        // 添加的配置项ID返回给BP调用端
        *p_out_id = sch_cfg->id;

exit:
        vesync_buf_clr(&app_cfg_buf);
        return err_code;


}


/**
 * @brief Bypass按顺序获取Schedule多个配置项
 * @note  返回多少个连续的配置项是由Schedule模块决定
 *
 * @param[in]  index        [要获取的Schedule配置项的初始序号]
 * @param[in]  p_buf        [用于读取Schedule配置项的缓存，函数内会作缓存的分配,调用结束后需要释放]
 * @param[out] p_out_list   [指向输出读取结果的列表]
 * @param[in]  total_num    [配置项总数]
 * @return int              [返回BYPASS的错误定义]
 */
int bulb_schedule_get_mult( uint32_t index, vesync_schedule_t *sche_cfg, void *action, uint32_t *cur_num, uint32_t *total_num)
{
    int ret = SCHE_ERR;
    int err_code = BP_ERR_NO_ERR;
    vesync_buf_t app_cfg_buf[BULB_SCHEDULE_GET_MAX_NUM];

    if (NULL == sche_cfg || NULL == action || NULL == cur_num || NULL == total_num)
    {
        return BP_ERR_CMD_EXECUTE_FAIL;
    }
    for (uint32_t i = 0; i < BULB_SCHEDULE_GET_MAX_NUM; i++)
    {
        app_cfg_buf[i] = vesync_buf_new();
    }
    ret = vesync_schedule_get_by_index(BULB_SCHE_INS_ID, index, BULB_SCHEDULE_GET_MAX_NUM,
        total_num, sche_cfg, app_cfg_buf, cur_num);
    for (uint32_t i = 0; i < *cur_num ; i++)
    {
        bulb_read_scedule_data(&app_cfg_buf[i],(bulb_action_t *)action + i);
    }
    if (ret != SCHE_OK)
    {
        if (ret == SCHE_INV_IDX_ERR)
        {
            err_code = BP_ERR_SCHEDULE_NOT_FOUND;
            goto exit;
        }

        ret = BP_ERR_CMD_EXECUTE_FAIL;
        goto exit;
    }

exit:
    // 销毁APP配置读取缓存
    for (uint32_t i = 0; i < BULB_SCHEDULE_GET_MAX_NUM; i++)
    {
        vesync_buf_clr(&app_cfg_buf[i]);
    }
    return err_code;

}

/**
 * @brief Bypass删除指定ID的Schedule配置项
 *
 * @param[in]  id_to_del    [要删除的Schedule配置项ID]
 * @return int              [返回BYPASS的错误定义]
 */
int bulb_schedule_del(uint32_t id_to_del)
{
    int ret = SCHE_ERR;
    ret = vesync_schedule_del(BULB_SCHE_INS_ID, id_to_del);
    if (ret != SCHE_OK)
    {
        if (ret != SCHE_INV_ID_ERR)
        {
            return BP_ERR_CMD_EXECUTE_FAIL;
        }
        return BP_ERR_SCHEDULE_NOT_FOUND;
    }
    return BP_ERR_NO_ERR;
}

/**
 * @brief 初始化Schedule功能
 * @return      int         [成功：APP_OK， 失败：APP_FAIL]
 */
int bulb_schedule_init(void)
{
    int ret = 0;

    // 初始化Schedule模块
    if (SCHE_OK != vesync_schedule_main_init())
    {
        APP_LOG(LOG_ERROR, "Schedule module init fail\n");

        return APP_FAIL;
    }

    vesync_schedule_param_t schedule_param;
    schedule_param.rd_cfg_cb = bulb_sche_rd_cfg_cb;
    schedule_param.wr_cfg_cb = bulb_sche_wr_cfg_cb;
    schedule_param.exec_app_task_cb = bulb_schedule_exec_cb;
    schedule_param.max_app_cfg_size = BULB_SCHEDULE_MAX_APP_CFG_SIZE;
    schedule_param.max_sche_nbr = BULB_SCHEDULE_MAX_NUM;
    schedule_param.min_id_limit = BULB_SCHEDULE_MIN_ID;
    ret = vesync_schedule_new_instance(BULB_SCHE_INS_ID, &schedule_param);
    if (ret != SCHE_OK)
    {
        APP_LOG(LOG_ERROR, "Schedule instance init error: [%ld]\n", ret);

        return APP_FAIL;
    }

    APP_LOG(LOG_INFO, "Schedule initialized\n");
    return APP_OK;
}

/**
* @brief App层调用，复位Schedule的所有配置信息
* @return      int         [成功：APP_OK， 失败：APP_FAIL]
*/

int bulb_schedule_clear(void)
{
    vesync_schedule_clear(BULB_SCHE_INS_ID);
    return APP_OK;
}

