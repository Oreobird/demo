/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        bulb_flash.h
 * @brief       灯泡的提示光效
 * @author      Dave.Ming
 * @date        2021-09-02
 */

#ifndef __BULB_WIFI_LED_H__
#define __BULB_WIFI_LED_H__

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief  产测开始时灯效
 * @param[in]   flag        [false为开始，true为停止]
 */
void bulb_wifi_led_pdt_output_test(bool stop);

/**
 * @brief  未配网时的提示灯效
 */
void bulb_wifi_led_before_netcfg(void);

/**
 * @brief  配网中时的提示灯效
 */
void bulb_wifi_led_nefcfg(void);

/**
 * @brief  设备重置提示灯效
 */
void bulb_wifi_led_device_reset(void);


#ifdef __cplusplus
}
#endif

#endif

