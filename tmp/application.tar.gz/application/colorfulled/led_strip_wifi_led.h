/**
*Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file    led_strip_wifi_led.h
* @brief   Wi-Fi指示灯配置
* @author  henrik
*@date     2021-10-25
*/


#ifndef __LED_STRIP_WIFI_LED_H__
#define __LED_STRIP_WIFI_LED_H__

#ifdef __cplusplus
extern "C" {
#endif

/**
* @brief    设置配网标志位
* @param[in]  flag          [true:未配网/等待配网；false:配网结束/已配网]
*/
void led_strip_wifi_set_netcfg_flag(bool flag);


/**
* @brief  灯效配置
* @return     int             [成功/失败]
*/
int led_strip_reg_wifi_led(void);

#ifdef __cplusplus
}
#endif

#endif
