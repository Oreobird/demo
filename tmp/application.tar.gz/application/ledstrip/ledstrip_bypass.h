/**
*Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file    ledstrip_bypass.h
* @brief   应用层bypass接口
* @author  Lind
*@date     2021-09-12
*/

#ifndef __LEDSTRIP_BYPASS_H__
#define __LEDSTRIP_BYPASS_H__

#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

#define TIMER_SEC_MAX           86399   // timing 最大倒计时时间23h 59min 59s
#define TIMER_SEC_MIN           1       // timing 最小倒计时时间1s
#define LED_COLORTEMP_MAX       100     // 色温最大值100
#define LED_BRIGHTNESS_MAX      100     // 亮度最大值100
#define LED_HS_PARAM_MAX        10000   // hue、saturation最大值10000

/**
* @brief 设置语音关闭标志位，
* @param[in]  flag          [true:语音导致灯带关闭;false:当前状态不是语音关闭]
*/
void ls_set_voice_off_flag(bool flag);

/**
* @brief 注册bypass回调函数
*/
void ls_bypass_reg_cb(void);


#ifdef __cplusplus
}
#endif

#endif /* __LEDSTRIP_BYPASS_H__ */

