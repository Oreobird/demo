/**
*Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file    led_strip_timing.h
* @brief   倒计时接口
* @author  henrik
* @date     2021-10-29
*/

#ifndef __LEDSTRIP_TIMING_H__
#define __LEDSTRIP_TIMING_H__

#include <stdint.h>
#include <stdbool.h>

#include "led_strip.h"

#ifdef __cplusplus
extern "C" {
#endif

#define MAX_LS_TIMER_NUM            1       // timing最大数量
#define MIN_LS_TIMER_ID             1       // itmer最小ID

/**
 * @brief 开关timer定时配置
 */
typedef struct
{
    uint16_t id;            // timer id，最多5个，范围为1~5
    uint32_t total_sec;     // 时间，单位：秒
    ls_ctrl_t ctrl;         // 颜色
} ls_timing_t;

/**
* @brief 新增一个timer
* @param[in]   mode        [timer执行模式]
* @param[in]   total_sec   [timer定时时间]
* @param[out]  p_id        [timer id]
* @param[in]  *hsv_color   [颜色]
* @return     int          [错误码]
*/
int led_strip_timing_add(uint32_t total_sec, uint16_t *p_id, ls_ctrl_t ctrl);


/**
* @brief 删除一个timer
* @param[in]  uint16_t                 [timer id]
* @return     int_t                    [成功/失败]
*/
int led_strip_timing_remove(uint16_t timer_id);

/**
* @brief 删除imer
*/
void led_strip_timing_clear(void);


/**
* @brief 获取timer执行的动作
*/
ls_timing_t *led_strip_timing_get_act(void);


/**
* @brief 初始化timer
*/
void led_strip_timing_init(void);



#ifdef __cplusplus
}
#endif

#endif /* __LEDSTRIP_TIMING_H__ */

