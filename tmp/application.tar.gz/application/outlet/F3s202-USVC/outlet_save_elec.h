/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        outlet_save_elec.h
 * @brief       outlet电量存储
 * @author      Charles.Mei
 * @date        2021-12-17
 */


#ifndef __OUTLET_SAVE_ELEC_H__
#define __OUTLET_SAVE_ELEC_H__


#include <stdint.h>


#ifdef __cplusplus
extern "C" {
#endif


#define SECONDS_PER_HOUR        (3600)              // 每小时3600秒
#define HOURS_PER_DAY           (24)                // 每天24小时
#define SECONDS_PER_DAY         (SECONDS_PER_HOUR * HOURS_PER_DAY)
#define HISTORY_DAY_MAX         (30)                // 历史数据最大天数为30

#define ELEC_TEMP_STO_MAX       (16)              // 临时数据最大存储量
#define ELEC_TODAY_STO_SIZE     HOURS_PER_DAY       // 当天数据存储量
#define ELEC_HIST_STO_MAX       HISTORY_DAY_MAX     // 历史数据最大存储量

/*
 * @brief 电量暂存数据
 */
typedef struct
{
    float elec_per_hour[ELEC_TEMP_STO_MAX];
    uint64_t record_tick; // 最后一次记录的系统tick(毫秒)
    uint16_t index;     // 下标
} elec_temp_t;

/*
 * @brief 当天电量存储数据
 */
typedef struct
{
    float elec_per_hour[ELEC_TODAY_STO_SIZE];
    uint32_t today_ts;  // 当天零点时间戳
    uint16_t index;     // 下标
} elec_today_t;

/*
 * @brief 历史电量存储数据
 */
typedef struct
{
    float elec_per_day[ELEC_HIST_STO_MAX];
    uint32_t record_ts; // 最后一次记录的时间戳
    uint16_t index;     // 下标
} elec_history_t;

/*
 * @brief 记录的每天的用电量
 */
typedef struct
{
    float elec_per_day;
    uint32_t record_ts;
} elec_per_day_t;


/**
 * @brief 当天电量存储数据key定义
 */
typedef enum
{
    ELEC_TODAY_KEY_ARRAY        = 0,
    ELEC_TODAY_KEY_TS           = 1,
    ELEC_TODAY_KEY_INDEX        = 2
} ELEC_TODAY_KEY_E;

/**
 * @brief 历史电量存储数据key定义
 */
typedef enum
{
    ELEC_HIST_KEY_ARRY          = 0,
    ELEC_HIST_KEY_TS            = 1,
    ELEC_HIST_KEY_INDEX         = 2
} ELEC_HIST_KEY_E;

/**
 * @brief 电量存储触发类型
 */
typedef enum
{
    ELEC_SAVE_TRIG_TICK         = 0,        // 未同步时间戳时，每小时触发电量存储
    ELEC_SAVE_TRIG_CLOCK        = 1,        // 每小时最后一刻触发存储
    ELEC_SAVE_TRIG_UPD_TS       = 2,        // 时间戳更新触发存储
} ELEC_SAVE_TRIG_TYPE_E;


/**
 * @brief 电量保存模块初始化
 * @return      int             [错误码，成功/失败]
 */
int outlet_save_elec_init(void);

/**
 * @brief 获取历史电量
 * @param[in]   p_arry          [历史电量数组]
 * @param[in]   len             [数组长度]
 * @return      int             [错误码，成功/失败]
 * @note  电量数据以时间戳从大到小排列
 */
int outlet_get_history_elec(elec_per_day_t *p_arry, uint8_t len);

/**
 * @brief 执行电量存储
 * @param[in]   trig_type       [触发类型]
 */
void outlet_save_elec_exec(ELEC_SAVE_TRIG_TYPE_E trig_type);

/**
 * @brief 上报历史电量
 */
void outlet_save_elec_report(void);

/**
 * @brief 重报历史电量
 */
void outlet_retry_report_history_elec(void);

/**
 * @brief 清除历史电量
 * @return      int             [错误码，成功/失败]
 */
int outlet_clear_history_elec(void);

#if defined(PR_FW_TYPE) && (PR_FW_TYPE == 0)
/**
 * @brief 设置一小时的秒数和一天的小时数
 * @param[in]   secs_per_hour   [一小时的秒数[60,3600]]
 * @param[in]   hrs_per_day     [一天的小时数[3,24]]
 * @return      int             [错误码，成功/失败]
 */
int outlet_set_debug_secs_hrs(uint16_t secs_per_hour, uint8_t hrs_per_day);
/**
 * @brief 获取一天的秒数
 * @return      uint32_t        [一天的秒数]
 */
uint32_t outlet_get_debug_secs_per_day(void);
#endif


#ifdef __cplusplus
}
#endif

#endif


