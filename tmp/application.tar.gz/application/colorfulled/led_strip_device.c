/**
*Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file    led_strip_device.c
* @brief   设备重置
* @author  henrik
*@date     2021-11-22
*/
#include "vesync_device.h"

#include "led_strip_device.h"
#include "led_strip_scene.h"
#include "led_strip_report.h"
#include "led_strip_schedule.h"
#include "led_strip_flash.h"
#include "led_strip_timing.h"


/**
 * @brief 清除开关应用层数据
 * @param[in]  rsn              [消息来源]
 * @param[in]  rst_type         [删除用户数据的类型]
 */
static void led_strip_device_clear_all_data(const char* rsn, DEV_RESET_TYPE_E rst_type)
{
     if (rst_type == DEV_DEL_USER_CFG || rst_type == DEV_DEL_DEVICE)
     {
         led_strip_schedule_clear();
         led_strip_timing_clear();
         led_strip_clear_scene();
         led_strip_clear_info();
         led_strip_parameter_deinit();
     }

     led_strip_report_set_chg_rsn(STAT_CHG_RSN_NONE_STR);
     led_strip_report_status();
}


/**
* @brief ledstrip设备管理初始化
*/
void led_strip_device_init(void)
{
    // 注册缓存数据清除函数(恢复出厂/删除设备时调用)
    vesync_device_reg_clear_data_cb(led_strip_device_clear_all_data);
}


