/**
* Copyright © Vesync Technologies Co.Ltd. 2022. All rights reserved
* @file         app_rmt.c
* @brief        rmt驱动器创建接口
* @author       Joshua
* @date         2022-1-11
*/
#include <stdint.h>
#include <string.h>
#include "vesync_common.h"
#include "vesync_log.h"
#include "vesync_memory.h"
#include "vhal_rmt_1_wire.h"
#include "light_drv.h"
#include "device.h"
#include "app_cfg.h"

typedef struct
{
    uint16_t node_num;      // 节点总数
} privinfo_t;

static int destroy(light_drv_t *thiz)
{
    VCOM_SAFE_FREE(thiz);
    return APP_OK;
}

static int setup(light_drv_t *thiz)
{
    UNUSED(thiz);

    privinfo_t *priv = (privinfo_t *)thiz->priv;
    VCOM_NULL_PARAM_CHK(priv, return APP_FAIL);

    priv->node_num = app_device_bead_num();

    one_wire_tx_cfg_t cfg = {
        .rmt_tx_gpio = RMT_CTRL_IO,
        .clk_div = 1,
        .pixel_data_len = RMT_CH_NUM,
        .pixel_num = priv->node_num,
        .idle_level = RMT_IDLE_LEVEL_L,
        .T0H_NS = RMT_T0H_NS,
        .T0L_NS = RMT_T0L_NS,
        .T1H_NS = RMT_T1H_NS,
        .T1L_NS = RMT_T1L_NS,
    };

    int ret = vhal_1_wire_tx_init(&cfg);
    if (ret != VHAL_OK)
    {
        APP_LOG(LOG_ERROR, "rmt init failed\n");
        return APP_FAIL;
    }

    return APP_OK;
}

static void output(light_drv_t *thiz, uint16_t ch_num, uint32_t *p_ch_duty)
{
    privinfo_t *priv = (privinfo_t *)thiz->priv;
    VCOM_NULL_PARAM_CHK(priv, return);

    uint8_t data[RMT_CH_NUM] = {0};
    int ofs = 0;

    for (int i = 0; i < priv->node_num; i++)
    {
        ofs = LIGHT_CH_IDX_MAX * i;
#if RMT_CH_NUM == 3
        data[0] = p_ch_duty[ofs + RMT_CH_DATA_0];
        data[1] = p_ch_duty[ofs + RMT_CH_DATA_1];
        data[2] = p_ch_duty[ofs + RMT_CH_DATA_2];
#elif RMT_CH_NUM == 4
        data[0] = p_ch_duty[ofs + RMT_CH_DATA_0];
        data[1] = p_ch_duty[ofs + RMT_CH_DATA_1];
        data[2] = p_ch_duty[ofs + RMT_CH_DATA_2];
        data[3] = p_ch_duty[ofs + RMT_CH_DATA_3];
#elif RMT_CH_NUM == 5
        data[0] = p_ch_duty[ofs + RMT_CH_DATA_0];
        data[1] = p_ch_duty[ofs + RMT_CH_DATA_1];
        data[2] = p_ch_duty[ofs + RMT_CH_DATA_2];
        data[3] = p_ch_duty[ofs + RMT_CH_DATA_3];
        data[4] = p_ch_duty[ofs + RMT_CH_DATA_4];
#else
        #error "Error: Invalid RMT_CH_NUM!!!"
#endif
        if (VHAL_OK != vhal_1_wire_tx_set_pixels(i, data, sizeof(data)))
        {
            APP_LOG(LOG_ERROR, "tx set error \n");
        }
    }

    if (VHAL_OK != vhal_1_wire_tx_refresh(0))
    {
        APP_LOG(LOG_ERROR, "tx refresh error \n");
    }
}

light_drv_t *light_rmt_drv_create(void)
{
    light_drv_t *thiz = (light_drv_t *)vesync_malloc(sizeof(light_drv_t) + sizeof(privinfo_t));
    if (thiz != NULL)
    {
        privinfo_t *priv = (privinfo_t *)thiz->priv;
        memset(priv, 0, sizeof(privinfo_t));

        thiz->destroy = destroy;
        thiz->setup = setup;
        thiz->output = output;
    }

    return thiz;
}


