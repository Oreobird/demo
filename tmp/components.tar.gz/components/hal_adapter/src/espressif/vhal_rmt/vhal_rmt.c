/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file    vhal_rmt.c
* @brief   rmt 接口
* @author  Lind
* @date     2021-11-12
*/


#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <sys/cdefs.h>
#include <freertos/FreeRTOS.h>
#include "freertos/ringbuf.h"

#include "driver/rmt.h"

#include "vhal_rmt.h"
#include "vesync_common.h"
#include "vesync_log.h"

static rmt_item32_t s_logic0;
static rmt_item32_t s_logic1;
static RingbufHandle_t s_read_buffer = NULL;

/**
* @brief rmt发送默认初始化函数
* @param[in]  gpio          [io]
* @param[in]  channel_id    [发送通道]
* @return  rmt_cfg_t        [发送配置]
*/
rmt_cfg_t vhal_rmt_default_cfg_tx(uint16_t gpio, RMT_CH_E channel_id)
{

/*
{                                                \
    .rmt_mode = RMT_MODE_SEND,                   \
    .channel = channel_id,                       \
    .gpio_num = gpio,                            \
    .clk_div = 80,                               \
    .mem_block_num = 1,                          \
    .flags = 0,                                  \
    .tx_config =                                 \
    {                                            \
        .carrier_freq_hz = 38000,                \
        .carrier_level = RMT_CARRIER_LEVEL_H,    \
        .idle_level = RMT_IDLE_LEVEL_L,          \
        .carrier_duty_percent = 33,              \
        .carrier_en = false,                     \
        .loop_en = false,                        \
        .idle_output_en = true,                  \
    }                                            \
};
*/
    return (rmt_cfg_t)RMT_DEFAULT_CONFIG_TX(gpio, channel_id);
}

/**
* @brief rmt接收默认初始化函数
* @param[in]  gpio          [io]
* @param[in]  channel_id    [接收通道]
* @return  rmt_cfg_t        [接收配置]
*/
rmt_cfg_t vhal_rmt_default_cfg_rx(uint16_t gpio, RMT_CH_E channel_id)
{
/*
{                                           \
    .rmt_mode = RMT_MODE_REC,               \
    .channel = channel_id,                  \
    .gpio_num = gpio,                       \
    .clk_div = 80,                          \
    .mem_block_num = 1,                     \
    .flags = 0,                             \
    .rx_config =                            \
    {                                       \
        .idle_threshold = 12000,            \
        .filter_ticks_thresh = 100,         \
        .filter_en = true,                  \
    }                                       \
};
*/
    return (rmt_cfg_t)RMT_DEFAULT_CONFIG_RX(gpio, channel_id);
}


/**
* @brief 获取通道的时钟频率
* @param[in]  channel   [通道]
* @return  uint32_t     [频率]
*/
uint32_t vhal_rmt_get_counter_clock(RMT_CH_E channel)
{
    uint32_t clk_hz;
    rmt_get_counter_clock(channel, &clk_hz);

    return clk_hz;
}


/**
* @brief rmt 初始化
* @param[in]  *rmt_param    [配置]
* @param[in]  rx_buf_size   [底层接收buf大小，建议1k]
* @return  int              [VHAL_OK/VHAL_FAIL]
*/
int vhal_rmt_init(rmt_cfg_t *rmt_param, uint32_t rx_buf_size)
{
    if (NULL == rmt_param)
    {
        return VHAL_FAIL;
    }

    ESP_ERROR_CHECK(rmt_config((rmt_config_t*)rmt_param));
    ESP_ERROR_CHECK(rmt_driver_install(rmt_param->channel, rx_buf_size, 0));

    return VHAL_OK;
}

/**
* @brief 卸载rmt通道
* @param[in]  channel     [通道]
*/
void vhal_rmt_deinit(RMT_CH_E channel)
{
    rmt_driver_uninstall(channel);
}


/**
* @brief 设置发送逻辑波形
* @param[in]  tx_channel    [发送通道]
* @param[in]  logic0        [logic0参数]
* @param[in]  logic1        [logic1参数]
*/
void vhal_rmt_set_item_sample(RMT_CH_E tx_channel, rmt_item_t logic0, rmt_item_t logic1)
{
    uint32_t counter_clk_hz = vhal_rmt_get_counter_clock(tx_channel);
    float ratio = (float)counter_clk_hz / 1e9;
    s_logic0 = (rmt_item32_t){{{(uint32_t)(ratio * logic0.duration0), logic0.level0,
                  (uint32_t)(ratio * logic0.duration1), logic0.level1}}};
    s_logic1 = (rmt_item32_t){{{(uint32_t)(ratio * logic1.duration0), logic1.level0,
                  (uint32_t)(ratio * logic1.duration1), logic1.level1}}};
//    s_margin_ticks = (uint32_t)(ratio * margin_ns);, uint32_t margin_ns
}

/**
* @brief 发送rmt信号，任意波形
* @param[in]  tx_channel    [发送通道]
* @param[in]  *p_buf        [发送数据buf]
* @param[in]  data_num      [数据数量]
* @param[in]  wait_tx_done  [是否阻塞发送]
* @return  int              [VHAL_OK/VHAL_FAIL]
*/
int vhal_rmt_write_items(RMT_CH_E tx_channel,rmt_item_t *p_buf, uint32_t data_num, bool wait_tx_done)
{
    if (NULL == p_buf)
    {
        return VHAL_FAIL;
    }

    if (ESP_OK != rmt_write_items(tx_channel, (rmt_item32_t*)p_buf, data_num, wait_tx_done))
    {
        return VHAL_FAIL;
    }

    return VHAL_OK;
}


/**
* @brief 发送逻辑信号
* @param[in]  tx_channel    [发送通道]
* @param[in]  *p_buf        [发送数据buf]
* @param[in]  buf_len_bits  [数据位数]
* @param[in]  wait_tx_done  [是否阻塞发送]
* @return  int              [VHAL_OK/VHAL_FAIL]
*/
int vhal_rmt_send_logic(RMT_CH_E tx_channel,uint8_t *p_buf, uint32_t buf_len_bits, bool wait_tx_done)
{
    if (NULL == p_buf || buf_len_bits < 1)
    {
        return VHAL_FAIL;
    }

    rmt_item32_t data[buf_len_bits];
    memset(data, 0, sizeof(data));

    rmt_item32_t *p_data = data;
    uint32_t byte_len = buf_len_bits / 8;
    if (buf_len_bits % 8 > 0)
    {
        byte_len += 1;
    }

    for (uint32_t i = 0; i < byte_len; i++)
    {
        for (int n = 0; n < 8; n++, p_data++)
        {
            if ((i * 8 + n) >= buf_len_bits)
            {
                break;
            }

            if (*(p_buf + i) & (1 << (7 - n)))
            {
                p_data->val = s_logic1.val;
            }
            else
            {
                p_data->val = s_logic0.val;
            }
        }
    }

    if (ESP_OK != rmt_write_items(tx_channel, data, sizeof(data) / sizeof(data[0]), wait_tx_done))
    {
        return VHAL_FAIL;
    }

    return VHAL_OK;
}


/**
* @brief 修改rmt gpio配置
* @param[in]  channel     [通道]
* @param[in]  mode        [RMT模式]
* @param[in]  gpio_num    [gpio]
* @return  int            [VHAL_OK/VHAL_FAIL]
*/
int vhal_rmt_set_gpio(RMT_CH_E channel, RMT_MODE_E mode, uint8_t gpio_num)
{
    if (ESP_OK != rmt_set_pin(channel, mode, gpio_num))
    {
        return VHAL_FAIL;
    }

    return VHAL_OK;
}


/**
* @brief 开始rmt接收
* @param[in]  channel       [接收通道]
* @param[in]  rx_idx_rst    [接收后是否重置buf，默认为true]
* @return  int              [VHAL_OK/VHAL_FAIL]
*/
int vhal_rmt_rx_start(RMT_CH_E channel, bool rx_idx_rst)
{
    if (ESP_OK != rmt_get_ringbuf_handle(channel, &s_read_buffer) || s_read_buffer == NULL)
    {
        return VHAL_FAIL;
    }

    if (ESP_OK != rmt_rx_start(channel, rx_idx_rst))
    {
        return VHAL_FAIL;
    }

    return VHAL_OK;
}


/**
* @brief 停止rmt接收
* @param[in]  channel   [接收通道]
* @return  int          [VHAL_OK/VHAL_FAIL]
*/
int vhal_rmt_rx_stop(RMT_CH_E channel)
{
    if (ESP_OK != rmt_rx_stop(channel))
    {
        return VHAL_FAIL;
    }

    return VHAL_OK;
}


/**
* @brief 获取接收到的脉冲数据
* @param[out]  *data_num    [数据数量]
* @param[in]  time_out_ms   [阻塞接收时间]
* @return  rmt_item_t      [接收到的数据指针]
*/
rmt_item_t* vhal_rmt_rx_get(uint16_t *data_num, uint32_t time_out_ms)

{
//    if (s_rx_items == NULL || NULL == data_num )
//    {
//        return;
//    }
    if (NULL == data_num)
    {
        return NULL;
    }

    rmt_item_t *items = NULL;
    uint16_t length = 0;
    items = (rmt_item_t*)xRingbufferReceive(s_read_buffer, (size_t*)&length, time_out_ms);
    *data_num = length / 4;
//    memset(s_rx_items, 0, sizeof(rmt_item_t) * s_max_item_num);
    return items;
}

/**
* @brief 解析收到的数据后需要将空间释放
* @param[in]  *items        [接收到的数据指针]
*/
void vhal_rmt_rx_mem_release(rmt_item_t *items)
{
    vRingbufferReturnItem(s_read_buffer, (void *)items);
}

/**
* @brief 注册发送结束回调
* @param[in]  *tx_end_cb_setting    [注册配置]
*/
void vhal_rmt_reg_tx_end_cb(rmt_tx_end_cb_t *tx_end_cb_setting)
{
    if (NULL == tx_end_cb_setting->function)
    {
        HAL_LOG(LOG_ERROR, "rmt tx end callback function is NULL! \n");
    }
    rmt_register_tx_end_callback((rmt_tx_end_fn_t)tx_end_cb_setting->function, tx_end_cb_setting->arg);
}

