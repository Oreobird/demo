/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
* @file         scene.h
* @brief        场景处理接口
* @author       Joshua
* @date         2021-11-18
*/

#include <stdint.h>
#include <stdbool.h>
#include "vesync_common.h"
#include "scene_registry.h"


#ifndef __SCENE_H__
#define __SCENE_H__

#ifdef __cplusplus
extern "C" {
#endif

#define SCENE_INVALID_ID    (-1)

typedef enum
{
    SCENE_PRD = 0,
    SCENE_NETCFG,
    SCENE_RESET,
    SCENE_ONOFF,
    SCENE_SEGMENT,
    SCENE_LIGHT,
    SCENE_TYPE_MAX
} SCENE_TYPE_E;

typedef enum
{
    SCENE_ONOFF_ID_MIN = 0,
    SCENE_WHITE_ON,
    SCENE_WHITE_OFF,
    SCENE_COLOR_ON,
    SCENE_COLOR_OFF,
    SCENE_ONOFF_ID_MAX
} SCENE_ONOFF_ID_E;

typedef enum
{
    SCENE_DEFAULT_ID_MIN = 0,
    SCENE_OCEAN,
    SCENE_FOREST,
    SCENE_SUNSET,
    SCENE_STARRY,
    SCENE_RAINBOW,
    SCENE_DAYLIGHT,
    SCENE_BREATH,
    SCENE_BLINK,
    SCENE_MUSIC,
    SCENE_DEFAULT_ID_MAX
} SCENE_DEFAULT_ID_E;


/**
 * @brief 通用场景灯效回调
 * @param[in] *param        [场景参数]
 * @return  int             [成功：APP_OK，失败：APP_FAIL]
 */
typedef int (*scene_light_cb_t)(void *param);

/**
 * @brief  场景灯效结构体
 */
typedef struct
{
   scene_light_cb_t light_cb;
} light_scene_t;


/**
 * @brief 场景灯效应用
 * @param[in] *thiz         [场景实例指针]
 * @param[in] *param        [场景参数]
 * @return  int             [成功：APP_OK，失败：APP_FAIL]
 */
int app_scene_light_apply(scene_t *thiz, void *param);

/**
 * @brief 由模式获取场景标识
 * @param[in] *scene_type         [场景类型]
 * @param[in] *scene_id           [场景ID]
 * @return  int                   [成功：APP_OK，失败：APP_FAIL]
 */
int app_scene_info_get_from_mode(uint8_t *scene_type, uint16_t *scene_id);

/**
 * @brief  场景初始化
 * @return int           [成功：APP_OK， 失败：APP_FAIL]
 */
int app_scene_init(void);

/**
 * @brief  场景资源释放
 * @return int           [成功：APP_OK， 失败：APP_FAIL]
 */
int app_scene_deinit(void);

#if CONFIG_VESYNC_APP_SCENE_PRODUCTION_LIGHT
#include "production_light.h"
#endif

#if CONFIG_VESYNC_APP_SCENE_NETCFG_LIGHT
#include "netcfg_light.h"
#endif

#if CONFIG_VESYNC_APP_SCENE_RESET_LIGHT
#include "reset_light.h"
#endif

#if CONFIG_VESYNC_APP_SCENE_CUSTOM_LIGHT
#include "custom.h"
#endif

#ifdef __cplusplus
}
#endif

#endif

