/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_klv.c
 * @brief       vesync klv格式接口功能实现
 * @author      Joshua
 * @date        2021-04-23
*/

#include <stdint.h>
#include <string.h>
#include <stdio.h>

#include "vesync_common.h"
#include "vesync_memory.h"
#include "vesync_log_internal.h"
#include "vesync_klv_internal.h"
#include "vesync_klv.h"


/**
 * @brief  解析klv头部
 * @param[in]  pdata            [指向头部数据的指针]
 * @param[out] klv              [解析后的klv头部]
 * @return     uint32_t         [头部长度，key长度固定1byte，len为1byte或者2byte]
 * @note  内部调用函数，不做入参判断，调用处保证
 */
static uint32_t vesync_klv_decode(const uint8_t *pdata, klv_t *klv)
{
    klv->key = (*pdata++);
    if (((*pdata) & 128) == 0)
    {
        klv->len = (*pdata++);
        if (klv->len)
        {
            klv->value = (uint8_t *)pdata;
        }
        else
        {
            klv->value = NULL;
        }
        return 2;
    }
    else
    {
        uint8_t high = (*pdata++) & 127;
        uint8_t low = (*pdata++);
        klv->len = (high << 8) | low;
        klv->value = (uint8_t *)pdata;
        return 3;
    }
}


/**
 * @brief  klv组装
 * @param[out] p_buf            [接收klv组装后数据的Buffer, 如果Buffer为NULL，则该函数会返回最终KLV组装完成的大小]
 * @param[in]  buf_len          [Buffer的长度，当p_buf不为NULL，会校验Buffer长度是否合法]
 * @param[in]  key              [KLV数据的Key值]
 * @param[in]  len              [KLV数据的长度]
 * @param[in]  p_val            [KLV数据Value值]
 * @return     uint32_t         [KLV组装后的总长度]
 */
uint32_t vesync_klv_set(uint8_t *p_buf, uint32_t buf_len, uint8_t key, uint16_t len, uint8_t *p_val)
{
    uint32_t header_len;

    if (!CHECK_KEY_KLV(key) || len >= (1 << 15) || ((len != 0) && (NULL == p_val)))
    {
        SDK_LOG(LOG_ERROR, "Invalid param!!!\n");
        return 0;
    }

    header_len = (len < (1 << 7)) ? 2 : 3;

    if (NULL == p_buf)
    {
        // 直接返回长度
        goto EXIT;
    }

    if (buf_len < (header_len + len))
    {
        SDK_LOG(LOG_ERROR, "Invalid buffer size!\n");
        return 0;
    }

    (*p_buf++) = (uint8_t)key;

    if (len < (1 << 7))
    {
        (*p_buf++) = (uint8_t)len;
    }
    else
    {
        (*p_buf++) = (uint8_t)(VCOM_HIGH_BYTE(len) | 128);
        (*p_buf++) = (uint8_t)VCOM_LOW_BYTE(len);
    }

    if (len > 0)
    {
        memcpy(p_buf, p_val, len);
    }

EXIT:
    return (header_len + len);
}

/**
 * @brief  往klv中添加数组
 * @param[out] p_buf            [接收klv组装后数据的Buffer, 如果Buffer为NULL，则该函数会返回最终KLV组装完成的大小]
 * @param[in]  buf_len          [Buffer长度，当p_buf不为NULL，会校验Buffer长度是否合法]
 * @param[in]  key              [数组KLV所用的Key]
 * @param[in]  count            [数组元素的总个数]
 * @param[in]  item_cb          [填充数组元素的回调函数]
 * @return     uint32_t         [KLV组装后的总长度]
 */
uint32_t vesync_klv_set_arr(uint8_t *p_buf, uint32_t buf_len, uint8_t key, uint32_t count, vesync_klv_arr_item_cb_t item_cb)
{
    uint32_t header_len = sizeof(uint8_t) + sizeof(uint16_t);
    uint8_t *p_wr = NULL;

    if (!CHECK_KEY_ARR(key) || NULL == item_cb)
    {
        SDK_LOG(LOG_ERROR, "Invalid param!!!\n");
        return 0;
    }

    if (NULL != p_buf)
    {
        VCOM_LEN_IS_TOO_SMALL(buf_len, header_len, SDK_LOG(LOG_ERROR, "Invalid buffer size!\n"); return 0);

        p_wr = p_buf + header_len;
        buf_len = buf_len - header_len;
    }

    // 初始化数组Value长度
    uint32_t total_len = 0;
    for (uint32_t i = 0; i < count; i++)
    {
        uint32_t item_len;

        if (NULL != p_buf)
        {
            VCOM_LEN_IS_TOO_SMALL(buf_len, header_len, return 0);
            item_len = item_cb(i, p_wr + header_len, buf_len - header_len);
        }
        else
        {
            item_len = item_cb(i, NULL, 0);
        }

        if(0 == item_len || item_len >= (1 << 15))
        {
            SDK_LOG(LOG_ERROR, "invalid item_len=%u, i=%u\n", item_len, i);
            return 0;
        }

        if (NULL != p_buf)
        {
            (*p_wr++) = (uint8_t)KEY_ARR_ITEM;
            (*p_wr++) = (uint8_t)(VCOM_HIGH_BYTE(item_len) | 128);
            (*p_wr++) = (uint8_t)VCOM_LOW_BYTE(item_len);

            p_wr = p_wr + item_len;
            buf_len = buf_len - header_len - item_len;
        }

        total_len = total_len + item_len + header_len;
    }

    if (total_len < (1 << 15))
    {
        if (NULL != p_buf)
        {
            (*p_buf++) = (uint8_t)key;
            (*p_buf++) = (uint8_t)(VCOM_HIGH_BYTE(total_len) | 128);
            (*p_buf++) = (uint8_t)VCOM_LOW_BYTE(total_len);
        }
    }
    else
    {
        SDK_LOG(LOG_ERROR, "Invalid buffer size!\n");
        return 0;
    }

    return (total_len + header_len);
}

/**
* @brief  通过key值获取klv节点指针，适合非末端节点的klv节点,其中value是一个指针
* @param[in]       pdata            [klv数据头部的指针]
* @param[in]       len              [pdata缓存的长度]
* @param[in]       key              [要获取的klv或数组的key值]
* @param[out]      klv              [获取到的klv节点]
* @return          int              [SDK_OK获取成功，SDK_FAIL失败]
*/
int vesync_klv_get_ptr(uint8_t *pdata, uint32_t len, uint8_t key, klv_t *klv)
{
    uint32_t left_len;
    uint32_t header_len;
    klv_t klv_tmp;

    if (NULL == pdata || 0 == len || KEY_ARR_ITEM == key || NULL == klv)
    {
        SDK_LOG(LOG_ERROR, "Invalid param!!!\n");
        return SDK_FAIL;
    }

    left_len = len;
    while (left_len)
    {
        header_len = vesync_klv_decode(pdata, &klv_tmp);

        if (left_len < (header_len + klv_tmp.len) || KEY_ARR_ITEM == klv_tmp.key)
        {
            SDK_LOG(LOG_ERROR, "Invalid KLV data, decode failed!!!\n");
            break;
        }

        if (key == klv_tmp.key)
        {
            memcpy(klv, &klv_tmp, sizeof(klv_t));
            return SDK_OK;
        }
        left_len = left_len - header_len - klv_tmp.len;
        pdata = pdata + header_len + klv_tmp.len;
    }

    return SDK_FAIL;

}


/**
 * @brief  通过key值获取klv或者数组
 * @param[in]       pdata            [klv数据头部的指针]
 * @param[in]       len              [pdata缓存的长度]
 * @param[in]       key              [要获取的klv或数组的key值]
 * @param[in]       value_len        [value缓存长度]
 * @param[out]      value            [key取值]
 * @return          int              [SDK_OK获取成功，SDK_FAIL失败]
 */
int vesync_klv_get(uint8_t *pdata, uint32_t len, uint8_t key, uint16_t value_len,uint8_t *value)
{
    klv_t klv_data;
    memset(&klv_data,0,sizeof(klv_data));

    if(SDK_OK == vesync_klv_get_ptr(pdata,len,key,&klv_data))
    {
        memset(value,0,value_len);
        memcpy(value,klv_data.value,VCOM_MIN(value_len,klv_data.len));
        return  SDK_OK;
    }
    return  SDK_FAIL;
}


/**
 * @brief  通过index获取数组的一个元素
 * @param[in]  pdata            [数组数据头部的指针]
 * @param[in]  len              [数组数据的长度]
 * @param[in]  index            [要获取数组中的第几个元素]
 * @param[out] klv              [获取到的klv内容]
 * @return     int              [获取成功或者失败]
 * @note
 */
int vesync_klv_get_item(uint8_t *pdata, uint32_t len, uint32_t index, klv_t *klv)
{
    uint32_t left_len;
    uint32_t header_len;
    uint32_t count;
    klv_t klv_tmp;

    if (NULL == pdata || 0 == len || NULL == klv)
    {
        SDK_LOG(LOG_ERROR, "Invalid param!!!\n");
        return SDK_FAIL;
    }

    count = 0;
    left_len = len;
    while(left_len)
    {
        header_len = vesync_klv_decode(pdata, &klv_tmp);

        if (left_len < (header_len + klv_tmp.len) || KEY_ARR_ITEM != klv_tmp.key)
        {
            SDK_LOG(LOG_ERROR, "Invalid KLV data, decode failed!!!\n");
            break;
        }

        if (index == count)
        {
            memcpy(klv, &klv_tmp, sizeof(klv_t));
            return SDK_OK;
        }

        left_len = left_len - header_len - klv_tmp.len;
        pdata = pdata + header_len + klv_tmp.len;
        count++;
    }

    return SDK_FAIL;
}


/**
 * @brief  以迭代器的方式组装klv数组或者返回组装的klv数组的总大小
 * @param[out] p_buf            [接收klv组装后数据的Buffer]
 * @param[in]  buf_len          [Buffer长度]
 * @param[in]  key              [数组所用的key]
 * @param[in]  count            [迭代次数]
 * @param[in]  p_data           [迭代数据]
 * @param[in]  iterator         [填充数组元素的迭代器回调函数]
 * @return     uint32_t         [klv组装后的总长度]
 */
uint32_t vesync_klv_set_arr_iter(uint8_t *p_buf, uint32_t buf_len, uint8_t key, uint32_t count, void *p_data, vesync_klv_arr_iterator_t iterator)
{
    uint32_t header_len = sizeof(uint8_t) + sizeof(uint16_t);
    uint8_t *p_wr = NULL;

    if (!CHECK_KEY_ARR(key) || NULL == iterator || NULL == p_data)
    {
        SDK_LOG(LOG_ERROR, "Invalid param!!!\n");
        return 0;
    }

    if (NULL != p_buf)
    {
        VCOM_LEN_IS_TOO_SMALL(buf_len, header_len, SDK_LOG(LOG_ERROR, "Invalid buffer size!\n"); return 0);

        p_wr = p_buf + header_len;
        buf_len = buf_len - header_len;
    }

    // 缓存迭代器的初始输入
    void *p_iter = p_data;
    // 初始化数组Value长度
    uint32_t total_len = 0;
    for (uint32_t i = 0; i < count; i++)
    {
        uint32_t item_len;

        if (NULL != p_buf)
        {
            VCOM_LEN_IS_TOO_SMALL(buf_len, header_len, return 0);
            item_len = iterator(&p_iter, i, p_wr + header_len, buf_len - header_len);
        }
        else
        {
            item_len = iterator(&p_iter, i, NULL, 0);
        }

        if(0 == item_len || item_len >= (1 << 15))
        {
            SDK_LOG(LOG_ERROR, "invalid item_len=%u, i=%u\n", item_len, i);
            return 0;
        }

        if (NULL != p_buf)
        {
            (*p_wr++) = (uint8_t)KEY_ARR_ITEM;
            (*p_wr++) = (uint8_t)(VCOM_HIGH_BYTE(item_len) | 128);
            (*p_wr++) = (uint8_t)VCOM_LOW_BYTE(item_len);

            p_wr = p_wr + item_len;
            buf_len = buf_len - header_len - item_len;
        }

        total_len = total_len + item_len + header_len;
    }

    if (total_len < (1 << 15))
    {
        if (NULL != p_buf)
        {
            (*p_buf++) = (uint8_t)key;
            (*p_buf++) = (uint8_t)(VCOM_HIGH_BYTE(total_len) | 128);
            (*p_buf++) = (uint8_t)VCOM_LOW_BYTE(total_len);
        }
    }
    else
    {
        SDK_LOG(LOG_ERROR, "Invalid buffer size!\n");
        return 0;
    }

    return (total_len + header_len);
}

#if defined(CONFIG_VESYNC_BUFFER_ENABLE)
/**
 * @brief  klv组装Vesync buffer
 * @param[out] buf              [接收klv组装后数据的buf]
 * @param[in]  buf_len          [buf长度]
 * @param[in]  key              [数据key值]
 * @param[in]  p_in             [Vesync Buffer]
 * @return     uint32_t         [klv组装后的总长度]
 * @note  组装总长度返回后用于指针后移
 */
uint32_t vesync_klv_set_buf(uint8_t *buf, uint32_t buf_len, uint8_t key, vesync_buf_t *p_in)
{
    uint32_t header_len;

    if (!CHECK_KEY_KLV(key) || p_in->len >= (1 << 15) || ((p_in->len != 0) && (NULL == p_in->buf)))
    {
        SDK_LOG(LOG_ERROR, "Invalid param!!!\n");
        return 0;
    }

    header_len = (p_in->len < (1 << 7)) ? 2 : 3;

    if (NULL == buf)
    {
        goto EXIT;
    }

    if (buf_len < (header_len + p_in->len))
    {
        SDK_LOG(LOG_ERROR, "Invalid buffer size!\n");
        return 0;
    }

    (*buf++) = (uint8_t)key;

    if (p_in->len < (1 << 7))
    {
        (*buf++) = (uint8_t)p_in->len;
    }
    else
    {
        (*buf++) = (uint8_t)(VCOM_HIGH_BYTE(p_in->len) | 128);
        (*buf++) = (uint8_t)VCOM_LOW_BYTE(p_in->len);
    }

    if (p_in->len > 0)
    {
        memcpy(buf, p_in->buf, p_in->len);
    }

EXIT:
    return (header_len + p_in->len);
}

/**
 * @brief  获取klv中的vesync buffer
 * @param[in]   p_data  [klv数据头部的指针]
 * @param[in]   len     [p_data缓存的长度]
 * @param[in]   key     [要获取的klv或数组的key值]
 * @param[out]  p_out   [Vesync Buffer]
 * @return  int         [SDK_OK获取成功，SDK_FAIL失败]
 */
int vesync_klv_get_buf(uint8_t *p_data, uint32_t len, uint8_t key, vesync_buf_t *p_out)
{
    klv_t klv_data;
    memset(&klv_data, 0, sizeof(klv_data));

    if (SDK_OK == vesync_klv_get_ptr(p_data, len, key, &klv_data))
    {
        vesync_buf_set(p_out, (void *)klv_data.value, klv_data.len);

        return SDK_OK;
    }

    return SDK_FAIL;
}
#endif  /* CONFIG_VESYNC_BUFFER_ENABLE */