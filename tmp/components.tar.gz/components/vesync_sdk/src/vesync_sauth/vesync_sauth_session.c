/**
 * Copyright © Vesync Technologies Co.Ltd. 2022. All rights reserved.
 * @file        vesync_sauth_session.c
 * @brief       Vesync SAUTH模块的会话加密流程实现
 * @author      Herve.Lin
 * @date        2022-01-10
 */
#include <string.h>

#include "vesync_sauth_private.h"
#include "vesync_sauth_port.h"
#include "vesync_sauth_crypto.h"

#include "vesync_common.h"
#include "vesync_log_internal.h"

static uint32_t s_sess_dev_cnt = 0;
static uint32_t s_sess_app_cnt = 0;

static bool s_is_proc = false;
static bool s_is_init = false;

static sauth_sess_ctx_t *p_sess_key = NULL;

/**
 * @brief 更新计数，检测到新的上计数进位操作会向高16位进位
 * @note  严格来说16位的上计数并不安全，有更高安全需求的时候，
 *        更需要APP来控制本次会话的时效性。周期性的刷新会话。
 * @param[in]   p_cnt       [上次的向上计数]
 * @param[in]   cnt_low     [当前的低16位向上计数值]
 */
static void update_cnt(uint32_t *p_cnt, uint16_t cnt_low)
{
    uint16_t last_cnt_low = *p_cnt;

    if ((last_cnt_low > 0x7FFF) && (cnt_low < 0x8000))
    {
        *p_cnt += 0x10000UL;
    }
    *p_cnt = (*p_cnt & 0xffff0000) | (uint32_t)cnt_low;
}

int sauth_session_init(sauth_sess_ctx_t *p_ctx)
{
    if (NULL == p_ctx)
    {
        return SDK_FAIL;
    }
    p_sess_key = p_ctx;

    s_sess_dev_cnt = 0;
    s_sess_app_cnt = 0;
    s_is_proc = false;
    s_is_init = true;
    return SDK_OK;
}

int sauth_session_deinit(void)
{
    s_is_init = false;
    return SDK_OK;
}

int vesync_sauth_session_encrypt(const uint8_t *p_in, uint16_t in_len, uint8_t *p_out, uint16_t out_len)
{
    if (NULL == p_in || NULL == p_out)
    {
        return SDK_FAIL;
    }
    if (out_len < (in_len + SAUTH_SESSION_UPCNT_SIZE + SAUTH_SESSION_ENC_DEC_TAG_SIZE))
    {
        return SDK_FAIL;
    }
    if ((true == s_is_proc) || (false == s_is_init))
    {
        return SDK_FAIL;
    }

    sauth_port_enter_critical();
    s_is_proc = true;
    sauth_port_exit_critical();

    sauth_sess_nonce_t nonce = {0};
    memcpy(nonce.iv, p_sess_key->dev_iv, SAUTH_SESSION_NONCE_IV_SIZE);
    uint16_t cnt_low = (uint16_t)s_sess_dev_cnt + 1;
    update_cnt(&s_sess_dev_cnt, cnt_low);

    nonce.counter = s_sess_dev_cnt;
    p_out[0] = (uint8_t)s_sess_dev_cnt;
    p_out[1] = (uint8_t)(s_sess_dev_cnt >> 8);
    int ret = sauth_crypto_ccm_encrypt(p_sess_key->dev_key,
                                       (uint8_t *)&nonce, sizeof(nonce),
                                       NULL, 0,
                                       p_in, in_len,
                                       p_out + SAUTH_SESSION_UPCNT_SIZE,
                                       p_out + SAUTH_SESSION_UPCNT_SIZE + in_len,
                                       SAUTH_SESSION_ENC_DEC_TAG_SIZE);
    s_is_proc = false;
    if (ret != CRYPTO_OK)
    {
        return SDK_FAIL;
    }
#if SAUTH_DEBUG_PRINT_ENABLE
    LOG_RAW_HEX(LOG_INFO, "enc tag:", p_out + SAUTH_SESSION_UPCNT_SIZE + in_len, SAUTH_SESSION_ENC_DEC_TAG_SIZE);
    LOG_RAW_HEX(LOG_INFO, "enc nonce:", (uint8_t *)&nonce, sizeof(nonce));
    LOG_RAW_HEX(LOG_INFO, "enc key:", p_sess_key->dev_key, sizeof(p_sess_key->dev_key));
#endif
    return SDK_OK;
}

int vesync_sauth_session_decrypt(const uint8_t *p_in, uint16_t in_len, uint8_t *p_out, uint16_t out_len)
{
    if (NULL == p_in || NULL == p_out)
    {
        return SDK_FAIL;
    }
    if (out_len < (in_len - SAUTH_SESSION_UPCNT_SIZE - SAUTH_SESSION_ENC_DEC_TAG_SIZE))
    {
        return SDK_FAIL;
    }
    if ((true == s_is_proc) || (false == s_is_init))
    {
        return SDK_FAIL;
    }

    sauth_port_enter_critical();
    s_is_proc = true;
    sauth_port_exit_critical();

    uint32_t curr_cnt = s_sess_app_cnt;
    sauth_sess_nonce_t nonce = {0};
    memcpy(nonce.iv, p_sess_key->app_iv, SAUTH_SESSION_NONCE_IV_SIZE);
    uint16_t cnt_low = (uint16_t)p_in[1] << 8 | p_in[0];
#if SAUTH_DEBUG_PRINT_ENABLE
    SDK_LOG(LOG_DEBUG, "before, sess_app_cnt:%d, cnt_low:%d\n", curr_cnt, cnt_low);
#endif
    update_cnt(&curr_cnt, cnt_low);
#if SAUTH_DEBUG_PRINT_ENABLE
    SDK_LOG(LOG_DEBUG, "after, sess_app_cnt:%d, cnt_low:%d\n", curr_cnt, cnt_low);
#endif
    // 会话开始的0号包是无法防止重放的，原则上双方第一包从1开始
    if ((curr_cnt <= s_sess_app_cnt) && (curr_cnt != 0))
    {
        SDK_LOG(LOG_WARN, "invalid nonce\n");
        s_is_proc = false;
        return SDK_FAIL;
    }
    s_sess_app_cnt = curr_cnt;

    nonce.counter = s_sess_app_cnt;
    int ret = sauth_crypto_ccm_decrypt(p_sess_key->app_key,
                                       (uint8_t *)&nonce, sizeof(nonce),
                                       NULL, 0,
                                       p_in + SAUTH_SESSION_UPCNT_SIZE,
                                       in_len - SAUTH_SESSION_UPCNT_SIZE - SAUTH_SESSION_ENC_DEC_TAG_SIZE,
                                       p_out,
                                       p_in + in_len - 4,
                                       SAUTH_SESSION_ENC_DEC_TAG_SIZE);
    s_is_proc = false;
    if (ret != CRYPTO_OK)
    {
        return SDK_FAIL;
    }
    return SDK_OK;
}
