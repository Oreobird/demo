/**
*Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file    ledstrip_button.h
* @brief   ledstrip
* @author  Lind
*@date     2021-08-25
*/

#ifndef __LEDSTRIP_BUTTON_H__
#define __LEDSTRIP_BUTTON_H__

#include "vesync_task.h"

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */


// 按键IO
#define LEDSTRIP_BUTTON_GPIO_NUM      (7)

// 按键消抖，按键计数最大值
#define KEY_SCAN_VALUE_MAX_NUM      (5)

// 判断松开或按下按键的阈值
#define KEY_RELEASED_THRESHOLD      (1)
#define KEY_PRESSED_THRESHOLD       (KEY_SCAN_VALUE_MAX_NUM - KEY_RELEASED_THRESHOLD)


// 按键扫描任务的参数
#define LEDSTRIP_BUTTON_TASK_NAME       ("button_task")
#define LEDSTRIP_BUTTON_TASK_STACKSIZE  (1024 * 3)
#define LEDSTRIP_BUTTON_TASK_PRIO       TASK_PRIORITY_HIGH

/**
 * @brief 设置扫描到的瞬时按键值
 * @param[in]   scan_value      [瞬时按键值]
 */
typedef void(*key_set_scan_value_t)(int8_t scan_value);


/**
 * @brief 按键状态
 */
typedef enum
{
    KEY_RELEASED_1S_MORE = 0,
    KEY_PRESSED_1S_LESS,
    KEY_PRESSED_1S_TO_5S,
    KEY_PRESSED_5S_TO_15S,
    KEY_PRESSED_15S_MORE,
    KEY_RELEASED_1S_LESS,
} KEY_STATE_E;

/**
 * @brief 按键参数
 */
typedef struct
{
    uint64_t key_upturn_ts;
    KEY_STATE_E key_status;
    key_set_scan_value_t key_set_scan_value;
    int8_t key_scan_value[KEY_SCAN_VALUE_MAX_NUM]; // 单个按键扫描到的电平状态
    uint8_t key_scan_value_index;                  // 当前状态序号
    uint8_t key_pressed_num;
} key_status_t;


/**
 * @brief 产测时，强制退出按键扫描任务
 */
void ls_button_task_exit(void);

///**
// * @brief 产测中，开启按键扫描任务
// */
//void ls_button_task_enable(void);


/**
* @brief 获取按键次数
* @return  uint8_t   按键短按次数
*/
uint8_t ls_get_button_cnt(void);

/**
* @brief 设置当前按键次数
* @param[in]  cnt   [按键短按次数]
*/
void ls_set_button_cnt(uint8_t cnt);


/**
 * @brief ledstrip button初始化
 */
void ls_button_init(void);


#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* __LEDSTRIP_BUTTON_H__ */

