/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
* @file         event_handle.h
* @brief        应用事件处理业务实现
* @author       Joshua
* @date         2021-12-1
*/

#include <stdint.h>
#include <stdbool.h>

#ifndef __EVENT_HANDLE_H__
#define __EVENT_HANDLE_H__

#ifdef __cplusplus
extern "C" {
#endif


/**
 * @brief  应用事件类型
 */
typedef enum
{
    EV_POWERON = 0,
    EV_PRODUCTION,
    EV_PRE_NETCFG,
    EV_NETCFG,
    EV_NETCFG_SUCCESS,
    EV_NWK_RECONNECT,
    EV_RESET,
    EV_SCENE_SWITCH,
    EV_UNKNOWN,
} APP_EVENT_ID_E;

/**
 * @brief  动作来源
 */
typedef enum
{
    ACT_SRC_INIT = 0,        // 初始化
    ACT_SRC_BTN,             // 按键执行
    ACT_SRC_APP,             // APP、第三方控制
    ACT_SRC_TASK,            // schedule、timer、away
    ACT_SRC_RESET,           // 删除设备、恢复出厂
    ACT_SRC_UNKNOWN,         // 未知
} ACT_SRC_E;

/**
 * @brief  事件处理结果
 */
typedef enum
{
    EV_HANDLE_OK = 0,       // 事件处理完成
    EV_HANDLE_FAIL,         // 事件处理失败
    EV_HANDLE_LOOP,         // 事件需要循环处理
} EV_HANDLE_RET;

/**
 * @brief  应用事件结构体
 */
typedef struct
{
    APP_EVENT_ID_E id;               // 事件id
    ACT_SRC_E act_src;               // 动作来源
    uint8_t scene_type;              // 场景类型
    uint16_t scene_id;               // 场景id
    void *data;                      // 应用数据
} app_event_t;

/**
 * @brief  事件处理回调
 * @param[in]  *ev          [事件指针]
 * @return  EV_HANDLE_RET   [参看enum EV_HANDLE_RET]
 */
typedef EV_HANDLE_RET (*app_event_handle_fn_t)(app_event_t *ev);

/**
 * @brief  事件ID与回调映射结构体
 */
typedef struct
{
    APP_EVENT_ID_E id;
    app_event_handle_fn_t handle;
} event_handle_t;

/**
 * @brief  事件处理
 * @param[in]  *ev          [事件指针]
 * @return  EV_HANDLE_RET   [参看enum EV_HANDLE_RET]
 */
EV_HANDLE_RET app_event_handle(app_event_t *ev);


#ifdef __cplusplus
}
#endif

#endif



