/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
 * @file        vdrv_fm11081dx_internal.h
 * @brief       复旦FM11NT081Dx芯片驱动内部宏定义
 * @date        2021-11-15
 */

#ifndef __VDRV_FM11NT081DX_INTERNAL_H__
#define __VDRV_FM11NT081DX_INTERNAL_H__

#ifdef __cplusplus
extern "C"
{
#endif

#define NFC_CFG_I2C_PORT 0               //i2c 端口，0表示是主机
#define FM11_E2_BLOCK_SIZE 16            //nfc卡每次连续读写块大小
#define FM11_E2_INIT_INFO_ADDR 0x000C    //卡片初始化信息地址，不能修改
#define FM11_E2_USER_DATA_ADDR 0x0018    //用户数据地址
#define FM11_E2_SYS_CFG_ADDR 0x0388      //系统配置信息地址，用户数据不能大于此地址
#define FM11_E2_STATIC_LOCK_ADDR 0x000A  //静态锁定位信息地址
#define FM11_E2_DYNAMIC_LOCK_ADDR 0x0388 //动态锁定位信息地址
#define FM11_E2_FDP_MIRROR_ADDR 0x038C   //FDP、Mirror功能配置地址

#define NFC_CFG_I2C_SPEED 100000 //i2c 读写速率
#define NFC_CARD_ADDR_WRITE 0xAE //i2c 写数据地址
#define NFC_CARD_ADDR_READ 0xAF  //i2c 读数据地址

#define FM11_UID_LEN 9    //卡片UID长度
#define FM11_UID_ADDR 0x0 //卡片UID地址

//FDP &Mirror 功能相关定义
#define FM11_FDP_MIRROR_ADDR 0x038C                //寄存器地址
#define FDP_MIRROR_MIRROR_CONF_BIT_MASK 0x11000000 //mirror CONF 配置位
#define FDP_MIRROR_MIRROR_BYTE_BIT_MASK 0x00110000 //mirror byte 配置位
#define FDP_MIRROR_SLEEP_EN_BIT_MASK 0x00001000    //sleep en 配置位
#define FDP_MIRROR_STRG_MODE_BIT_MASK 0x00000100   //strg mode配置位
#define FDP_MIRROR_FDP_CONF_BIT_MASK 0x00000011    //fdp_conf 配置位



#ifdef __cplusplus
}
#endif


#endif /* __VDRV_FM11NT081DX_INTERNAL_H__ */
