/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_bypass_plasma.c
 * @brief       bypass处理接口
 * @date        2021-05-17
 */
#include <string.h>

#include "vesync_common.h"
#include "vesync_memory.h"
#include "vesync_log_internal.h"
#include "vesync_bypass_internal.h"

/**
 * @brief 设置等离子
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  json                     [json数据指针]
 * @return BYPASS_ERR_E                 [错误码]
 */
static BYPASS_ERR_E bypass_method_set_plasma_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    BYPASS_ERR_E ret = BP_OK;
    cJSON* json_data = NULL;

    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    bypass_plasma_t * p_plasma = (bypass_plasma_t *)vesync_malloc(sizeof(bypass_plasma_t));
    if(NULL == p_plasma)
    {
        return BP_ERR_NOMEM;
    }

    memset(p_plasma, 0, sizeof(bypass_plasma_t));

    json_data = cJSON_GetObjectItemCaseSensitive(json, "plasma_state");
    if (cJSON_IsBool(json_data))
    {
        p_plasma->plasma = json_data->valueint;

        SDK_LOG(LOG_DEBUG,"plasma_state: %d\r\n", p_plasma->plasma);
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_SET_PLASMA);
    if (method_cb)
    {
        method_cb(p_msg_ctx, (void*)p_plasma);
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

_exit:
    vesync_free(p_plasma);
    return ret;
}


static bypass_item_data_t plasma_method_tbl[] = {
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_SET_PLASMA, "setPlasma", bypass_method_set_plasma_handle, NULL},
};

void vesync_bypass_plasma_init(void)
{
    for (int i = 0; i < SIZEOF_ARRAY(plasma_method_tbl); i++)
    {
        bypass_item_t *item = vesync_bypass_init_item(&plasma_method_tbl[i]);
        if (item != NULL)
        {
            vesync_bypass_add_item(item);
        }
    }
}
