/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_sem.h
 * @brief       semaphore抽象层，封装信号量相关接口
 * @date        2021-04-20
 */

#ifndef __VESYNC_SEM_H__
#define __VESYNC_SEM_H__

#include "vesync_os.h"

#ifdef __cplusplus
extern "C" {
#endif


/**
* @brief  信号量结构体
*/
typedef struct
{
    int max_count;   //信号量的最大计数
    void *handle;    //信号量指针
} vesync_sem_t;



/**
 * @brief  创建二值信号量
 * @return vesync_sem_t                [信号量结构体指针]
 */
vesync_sem_t *vesync_sem_binary_new(void);

/**
 * @brief  创建计数信号量
 * @param[in]  max_count               [信号量最大计数]
 * @return vesync_sem_t                [信号量结构体指针]
 */
vesync_sem_t *vesync_sem_count_new(unsigned int max_count);

/**
 * @brief  等待信号量
 * @param[in]  sem                     [信号量结构体指针]
 * @param[in]  timeout_ms              [等待时间：
 *                                      VESYNC_OS_NO_WAIT: 不等待
 *                                      VESYNC_OS_WAIT_FOREVER: 等待信号量]
 * @return int                         [成功：VOS_OK；失败：返回VOS_FAIL]
 */
int vesync_sem_wait(vesync_sem_t *sem, unsigned int timeout_ms);

/**
 * @brief  释放信号量
 * @param[in]  sem                     [信号量结构体指针]
 * @return int                         [成功：VOS_OK；失败：返回VOS_FAIL]
 */
int vesync_sem_signal(vesync_sem_t *sem);

/**
 * @brief  销毁信号量
 * @param[in]  sem                     [信号量结构体指针]
 * @return int                         [成功：VOS_OK；失败：返回VOS_FAIL]
 */
int vesync_sem_free(vesync_sem_t *sem);

#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_SEM_H__ */

