/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
 * @file        switch_device.h
 * @brief       产测功能
 * @author      Charles.Mei
 * @date        2021-07-30
 */



#ifndef __SWITCH_DEVICE_H__
#define __SWITCH_DEVICE_H__

#ifdef __cplusplus
     extern "C" {
#endif


/**
* @brief switch设备管理初始化
*/
void switch_device_init(void);


#ifdef __cplusplus
}
#endif

#endif

