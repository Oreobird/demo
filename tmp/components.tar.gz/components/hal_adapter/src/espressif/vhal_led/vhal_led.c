/**
*Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file    vhal_led.c
* @brief   led接口封装
* @author  Lind
*@date     2021-08-30
*/

#include <stdio.h>
#include "driver/ledc.h"
#include "esp_err.h"
#include "hal/gpio_ll.h"

#include "vhal_led.h"

#include "vesync_log.h"
#include "vesync_common.h"

#if defined(CONFIG_IDF_TARGET_ESP32) || defined(CONFIG_IDF_TARGET_ESP8266)
#define LEDC_TIMER          LEDC_TIMER_0
#define LEDC_MODE           LEDC_HIGH_SPEED_MODE
#else
#define LEDC_TIMER          LEDC_TIMER_1
#define LEDC_MODE           LEDC_LOW_SPEED_MODE
#endif

#define LEDC_DEFAULT_INT_ALLC_FLAG (0) // 渐变功能默认的中断分配号

static uint32_t s_duty_resolution = 256;  // 初始化后最大占空比分辨率

/*-----------------------------------------------------------------------------*
 *                           内部函数API实现                                         *
 *-----------------------------------------------------------------------------*/


/**
* @brief 占空比分辨率转换
* @param[in]  duty_resolution      [hal层封装的占空比分辨率]
* @return     ledc_timer_bit_t     [SDK定义的占空比分辨率]
*/
static ledc_timer_bit_t vhal_led_conv_duty_rst(LED_DUTY_RST_E e_duty_resolution)
{
    switch (e_duty_resolution)
    {
        case LED_DUTY_RST_1_BIT:
            s_duty_resolution = 2;
            return LEDC_TIMER_1_BIT;
        case LED_DUTY_RST_2_BIT:
            s_duty_resolution = 4;
            return LEDC_TIMER_2_BIT;
        case LED_DUTY_RST_3_BIT:
            s_duty_resolution = 8;
            return LEDC_TIMER_3_BIT;
        case LED_DUTY_RST_4_BIT:
            s_duty_resolution = 16;
            return LEDC_TIMER_4_BIT;
        case LED_DUTY_RST_5_BIT:
            s_duty_resolution = 32;
            return LEDC_TIMER_5_BIT;
        case LED_DUTY_RST_6_BIT:
            s_duty_resolution = 64;
            return LEDC_TIMER_6_BIT;
        case LED_DUTY_RST_7_BIT:
            s_duty_resolution = 128;
            return LEDC_TIMER_7_BIT;
        case LED_DUTY_RST_8_BIT:
            s_duty_resolution = 256;
            return LEDC_TIMER_8_BIT;
        case LED_DUTY_RST_9_BIT:
            s_duty_resolution = 512;
            return LEDC_TIMER_9_BIT;
        case LED_DUTY_RST_10_BIT:
            s_duty_resolution = 1024;
            return LEDC_TIMER_10_BIT;
        case LED_DUTY_RST_11_BIT:
            s_duty_resolution = 2048;
            return LEDC_TIMER_11_BIT;
        case LED_DUTY_RST_12_BIT:
            s_duty_resolution = 4096;
            return LEDC_TIMER_12_BIT;
        case LED_DUTY_RST_13_BIT:
            s_duty_resolution = 8192;
            return LEDC_TIMER_13_BIT;
        default:
            s_duty_resolution = 8192;
            return LEDC_TIMER_13_BIT;
    }
}


/**
* @brief LED通道转换
* @param[in]  e_led_channel     [hal层封装的LED通道]
* @return  ledc_channel_t       [SDK定义的LED通道]
*/
static ledc_channel_t vhal_led_conv_channel(LED_CHANNEL_E e_led_channel)
{
    switch (e_led_channel)
    {
        case LED_CH0:
            return LEDC_CHANNEL_0;
        case LED_CH1:
            return LEDC_CHANNEL_1;
        case LED_CH2:
            return LEDC_CHANNEL_2;
        case LED_CH3:
            return LEDC_CHANNEL_3;
        case LED_CH4:
            return LEDC_CHANNEL_4;
        case LED_CH5:
            return LEDC_CHANNEL_5;
        default:
            return LED_CH0;
    }
}

/**
* @brief 占空比转换：转换为实际占空比
* @param[in]  duty          [占空比]
* @param[in]  duty_rst      [占空比分辨率]
* @return  uint16_t         [实际占空比]
*/
static uint16_t vhal_led_conv_duty(uint16_t duty, uint16_t duty_rst)
{
    return s_duty_resolution * duty / duty_rst;
}



/**
* @brief 设置gpio输出反向
* @param[in]  gpio_num  [io]
*/
static void gpio_out_inv_enable(gpio_num_t gpio_num)
{
    REG_SET_BIT(GPIO_FUNC0_OUT_SEL_CFG_REG + (gpio_num * 4), GPIO_FUNC0_OUT_INV_SEL);
}

/*-----------------------------------------------------------------------------*
 *                           外部函数API实现                                         *
 *-----------------------------------------------------------------------------*/


/**
* @brief led的timer配置
* @param[in]  pst_led_timer          [timer配置参数]
* @return  uint32_t                  [配置结果 VHAL_OK/VHAL_FAIL]
*/
uint32_t vhal_led_timer_cfg(vhal_led_timer_cfg_t *pst_led_timer)
{
    if (NULL == pst_led_timer)
    {
        HAL_LOG(LOG_ERROR, "invalid timer_cfg\n");
        return VHAL_FAIL;
    }

    ledc_timer_config_t ledc_timer;
    ledc_timer.duty_resolution  = vhal_led_conv_duty_rst(pst_led_timer->duty_resolution);
    ledc_timer.freq_hz          = pst_led_timer->freq_hz;
    ledc_timer.clk_cfg          = LEDC_AUTO_CLK;
    ledc_timer.speed_mode       = LEDC_MODE;
    ledc_timer.timer_num        = LEDC_TIMER;

    esp_err_t err = ledc_timer_config(&ledc_timer);
    if (ESP_OK != err)
    {
        return VHAL_FAIL;
    }

    return VHAL_OK;
}


/**
* @brief 初始化配置led gpio
* @param[in]  pin_num           [初始化配置的LED gpio个数]
* @param[in]  *pst_gpio_cfg     [gpio配置结构体数组]
* @return  uint32_t             [VHAL_OK/VHAL_FAIL]
*/
uint32_t vhal_led_gpio_cfg(uint8_t pin_num, vhal_led_gpio_cfg_t *pst_gpio_cfg)
{
    if (0 == pin_num || NULL == pst_gpio_cfg)
    {
        HAL_LOG(LOG_ERROR, "invalid led gpio_cfg\n");
        return VHAL_FAIL;
    }

    ledc_channel_config_t ledc_channel;
    ledc_channel.speed_mode = LEDC_MODE;
    ledc_channel.timer_sel = LEDC_TIMER;
    ledc_channel.intr_type = LEDC_INTR_DISABLE;
    ledc_channel.hpoint = 0;

    for (int i = 0; i < pin_num; i++)
    {
        ledc_channel.channel    = vhal_led_conv_channel(pst_gpio_cfg->channel);
        ledc_channel.duty       = pst_gpio_cfg->duty;
        ledc_channel.gpio_num   = pst_gpio_cfg->gpio_num;

        esp_err_t err = ledc_channel_config(&ledc_channel);
        if (ESP_OK != err)
        {
            return VHAL_FAIL;
        }
        // pwm输出电平翻转
        if (pst_gpio_cfg->invert_flag)
        {
            gpio_out_inv_enable(ledc_channel.gpio_num);
        }

        pst_gpio_cfg++;
    }

    return VHAL_OK;
}


/**
* @brief  设置LED通道占空比(100分辨率)
* @param[in]  e_channel     [led通道枚举变量]
* @param[in]  duty          [100分辨率的占空比]
*/
void vhal_led_set_duty(LED_CHANNEL_E e_channel, uint16_t duty)
{
    if (100 < duty)
    {
        HAL_LOG(LOG_WARN, "invalid duty[%d]\n", duty);
        duty = s_duty_resolution;
    }
    else
    {
        duty = vhal_led_conv_duty(duty, 100);
    }

    ledc_channel_t led_channel = vhal_led_conv_channel(e_channel);
    ledc_set_duty(LEDC_MODE, led_channel, duty);
    ledc_update_duty(LEDC_MODE, led_channel);
}

/**
* @brief  设置LED通道占空比(指定分辨率)
* @param[in]  e_channel     [led通道枚举变量]
* @param[in]  duty          [实际分辨率的占空比]
* @param[in]  duty_rst      [占空比分辨率]
*/
void vhal_led_set_duty_bits(LED_CHANNEL_E e_channel, uint16_t duty, uint16_t duty_rst)
{
    if (duty_rst < duty || 0 == duty_rst || s_duty_resolution < duty_rst)
    {
        HAL_LOG(LOG_WARN, "invalid led params %d \n", duty);
        duty = s_duty_resolution;
    }
    else
    {
        duty = vhal_led_conv_duty(duty, duty_rst);
    }

    ledc_channel_t led_channel = vhal_led_conv_channel(e_channel);
    ledc_set_duty(LEDC_MODE, led_channel, duty);
    ledc_update_duty(LEDC_MODE, led_channel);
}

/**
* @brief 使能渐变功能
*/
void vhal_led_fade_enable(void)
{
    esp_err_t ret = ledc_fade_func_install(LEDC_DEFAULT_INT_ALLC_FLAG);
    if (ret != ESP_OK)
    {
        HAL_LOG(LOG_WARN, "ledc fade_func install error[%d]\n", ret);
    }
}

/**
* @brief 失能渐变功能
*/
void vhal_led_fade_disable(void)
{
    ledc_fade_func_uninstall();
}

/**
* @brief 按渐变步长渐变，设置后，该通道不能中途停止
* @param[in]  e_channel         [渐变通道]
* @param[in]  target_duty       [目标占空比，实际占空比]
* @param[in]  scale             [渐变步长]
* @param[in]  cycle_num         [每次改变占空比的周期数，越大渐变速度越慢]
* @return     int               [VHAL_OK/VHAL_FAIL]
*/
int vhal_led_fade_by_step(LED_CHANNEL_E e_channel, uint32_t target_duty, uint32_t scale, uint32_t cycle_num)
{
    esp_err_t ret = ledc_set_fade_with_step(LEDC_MODE, e_channel, target_duty, scale, cycle_num);

    if (ret != ESP_OK || ESP_OK != ledc_fade_start(LEDC_MODE,e_channel, LEDC_FADE_NO_WAIT))
    {
        return VHAL_FAIL;
    }

    return VHAL_OK;
}

/**
* @brief 在设定时间内完成渐变，设置后，该通道不能中途停止
* @param[in]  e_channel         [渐变通道]
* @param[in]  target_duty       [目标占空比，实际占空比]
* @param[in]  max_fade_time     [最大渐变时间,毫秒]
* @return  int                  [VHAL_OK/VHAL_FAIL]
*/
int vhal_led_fade_by_time(LED_CHANNEL_E e_channel, uint32_t target_duty, uint32_t max_fade_time)
{
    esp_err_t ret = ledc_set_fade_with_time(LEDC_MODE, e_channel, target_duty, max_fade_time);

    if (ret != ESP_OK || ESP_OK != ledc_fade_start(LEDC_MODE,e_channel, LEDC_FADE_NO_WAIT))
    {
        return VHAL_FAIL;
    }

    return VHAL_OK;
}

/**
 * @brief 设置LED控制器频率
 * @param[in] pst_led_timer     [timer配置参数]
 * @return int                  [VHAL_OK/VHAL_FAIL]
 */
int vhal_led_set_freq(vhal_led_timer_cfg_t *pst_led_timer)
{
#if defined(CONFIG_IDF_TARGET_ESP8266)
    ledc_timer_config_t ledc_timer;
    ledc_timer.duty_resolution  = vhal_led_conv_duty_rst(pst_led_timer->duty_resolution);
    ledc_timer.freq_hz          = pst_led_timer->freq_hz;
    ledc_timer.clk_cfg          = LEDC_AUTO_CLK;
    ledc_timer.speed_mode       = LEDC_MODE;
    ledc_timer.timer_num        = LEDC_TIMER;

    esp_err_t err = ledc_timer_config(&ledc_timer);
    if (ESP_OK != err)
    {
        return VHAL_FAIL;
    }
#else
    ledc_set_freq(LEDC_MODE, LEDC_TIMER, pst_led_timer->freq_hz);
#endif
    return VHAL_OK;
}

