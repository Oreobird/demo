/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        demo.c
 * @brief       sm2235egh驱动使用例程
 * @author      Herve
 * @date        2021-12-01
 */
#include <stddef.h>

#include "vesync_init.h"
#include "vesync_log.h"
#include "vesync_cfg.h"

#include "vesync_common.h"
#include "vesync_light.h"
#include "vesync_timer.h"

#include "vdrv_sm2235egh.h"

// 通道编号枚举
enum
{
    LIGHT_CH_IDX_0 = 0,
    LIGHT_CH_IDX_1 = 1,
    LIGHT_CH_IDX_2 = 2,
    LIGHT_CH_IDX_3 = 3,
    LIGHT_CH_IDX_4 = 4,
    LIGHT_CH_IDX_MAX = 5,
};

#define SM2235EGH_SDA_IO (5)    // 配置IIC的SDA端口为5号IO
#define SM2235EGH_SCL_IO (4)    // 配置IIC的SCL端口为4号IO
#define LIGHT_FRAME_PERIOD (20) // 灯光控制器单帧周期（毫秒）
#define LIGHT_MAX_DUTY (1023)   // 灯光控制器的最大输出占空比

static vesync_light_t s_light = NULL;
static vesync_timer_t *s_light_timer = NULL;

static void demo_pre_cb(void)
{
    APP_LOG(LOG_DEBUG, "This is a sm2235egh example\n");
}

/**
 * @brief vesync_light的PWM刷新回调
 * @param[in] opt               [可选回调参数]
 * @param[in] ch_num            [刷新的通道数量]
 * @param[in] duty              [通道PWM控制量数组]
 */
static void light_pwm_ctrl(void *opt, uint8_t ch_num, uint32_t *duty)
{
    UNUSED(opt);

    sm2235egh_gray_t rgb, cw;
    rgb.rgb.out_1r = duty[0];
    rgb.rgb.out_2g = duty[1];
    rgb.rgb.out_3b = duty[2];
    cw.cw.out_4c = duty[3];
    cw.cw.out_5w = duty[4];
    // 刷新RGB灯路和CW灯路
    int ret = vdrv_sm2235egh_set_output(&rgb, &cw);
    if (ret != SDK_OK)
    {
        APP_LOG(LOG_WARN, "sm2235egh_set_output fail\n");
    }

#if 0
    APP_LOG(LOG_INFO, "pwm: %d, %d, %d, %d, %d\n",
            rgb.rgb.out_1r,
            rgb.rgb.out_2g,
            rgb.rgb.out_3b,
            cw.cw.out_4c,
            cw.cw.out_5w);
#endif
}

/**
 * @brief 灯光控制器定时设置回调
 * @param[in] arg               [定时器回调参数]
 */
static void light_set_timer_cb(void *arg)
{
    UNUSED(arg);

    if (NULL == s_light)
    {
        return;
    }

    // 配置通道1为50%亮度上限，1000ms的呼吸周期，延时0ms执行的呼吸模式，持续两个半周期
    vesync_light_breath_cfg(s_light, LIGHT_CH_IDX_0, 0.5, 1000, 0, 2);
    // 配置通道2为50%亮度上限，1000ms的呼吸周期，延时1000ms执行的呼吸模式，持续两个半周期
    vesync_light_breath_cfg(s_light, LIGHT_CH_IDX_1, 0.5, 1000, 1000, 2);
    // 配置通道3为50%亮度上限，1000ms的呼吸周期，延时2000ms执行的呼吸模式，持续两个半周期
    vesync_light_breath_cfg(s_light, LIGHT_CH_IDX_2, 0.5, 1000, 2000, 2);
    // 配置通道4为50%亮度上限，1000ms的呼吸周期，延时3000ms执行的呼吸模式，持续两个半周期
    vesync_light_breath_cfg(s_light, LIGHT_CH_IDX_3, 0.5, 1000, 3000, 2);
    // 配置通道5为50%亮度上限，1000ms的呼吸周期，延时4000ms执行的呼吸模式，持续两个半周期
    vesync_light_breath_cfg(s_light, LIGHT_CH_IDX_4, 0.5, 1000, 4000, 2);

    // 开始所有通道的控制
    vesync_light_start(s_light, LIGHT_CH_IDX_0);
    vesync_light_start(s_light, LIGHT_CH_IDX_1);
    vesync_light_start(s_light, LIGHT_CH_IDX_2);
    vesync_light_start(s_light, LIGHT_CH_IDX_3);
    vesync_light_start(s_light, LIGHT_CH_IDX_4);
}

static void demo_app_run(void)
{
    APP_LOG(LOG_INFO, "Vesync APP Demo start\n");

    int ret;

    // 初始化SM2235EGH所依赖的IIC外设
    ret = vdrv_sm2235egh_init(SM2235EGH_SDA_IO, SM2235EGH_SCL_IO);
    if (ret != SDK_OK)
    {
        APP_LOG(LOG_ERROR, "sm2235egh init fail\n");
        return;
    }

    // 设置SM2235EGH为RGBCW五路模式
    vdrv_sm2235egh_set_mode(RGBCW_MODE);
    // 设置SM2235EGH的电流量程分别为64mA和80mA
    uint8_t rgb_cr = 0x0f, cw_cr = 0x0f;
    vdrv_sm2235egh_set_cr(&rgb_cr, &cw_cr);

    // 初始化vesync_light模块
    ret = vesync_light_init();
    if (ret != SDK_OK)
    {
        APP_LOG(LOG_ERROR, "vesync_light init fail\n");
        return;
    }

    // 创建5通道，刷新步长为20ms，PWM控制量上限为1023的灯光控制器
    s_light = vesync_light_create(LIGHT_CH_IDX_MAX,
                                  LIGHT_FRAME_PERIOD,
                                  LIGHT_MAX_DUTY,
                                  light_pwm_ctrl,
                                  NULL);
    if (NULL == s_light)
    {
        APP_LOG(LOG_ERROR, "create light fail\n");
        return;
    }

    // 统一设置各通道的伽马校正值为0.6
    vesync_light_set_gamma(s_light, LIGHT_CH_IDX_0, 0.6);
    vesync_light_set_gamma(s_light, LIGHT_CH_IDX_1, 0.6);
    vesync_light_set_gamma(s_light, LIGHT_CH_IDX_2, 0.6);
    vesync_light_set_gamma(s_light, LIGHT_CH_IDX_3, 0.6);
    vesync_light_set_gamma(s_light, LIGHT_CH_IDX_4, 0.6);

    // 创建一个5秒钟周期的定时器设置灯光控制器的灯光模式
    s_light_timer = vesync_timer_new("light_timer",
                                     light_set_timer_cb,
                                     NULL,
                                     5500,
                                     true);
    if (NULL == s_light_timer)
    {
        APP_LOG(LOG_ERROR, "create light_timer fail\n");
        return;
    }
    // 正式开始例程的输出演示
    vesync_timer_start(s_light_timer);
}

void app_main(void)
{
    vesync_sdk_reg_pre_run_cb(demo_pre_cb);
    vesync_sdk_reg_post_run_cb(demo_app_run);

    vesync_sdk_run();
}
