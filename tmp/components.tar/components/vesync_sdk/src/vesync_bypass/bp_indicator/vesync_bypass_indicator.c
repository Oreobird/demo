/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_bypass_indicator.c
 * @brief       bypass处理接口
 * @date        2021-05-14
 */
#include <string.h>
#include "vesync_common.h"
#include "vesync_memory.h"
#include "vesync_bypass_internal.h"

/**
 * @brief "setIndicatorLightSwitch"  method数据解析
 * @param p_trace_msg trace message
 * @param json json数据指针
 * @return bypass_err_t
 */
static BYPASS_ERR_E bypass_method_set_indicator_handle(bypass_trace_msg_t *p_trace_msg, cJSON *json)
{
    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_trace_msg, return BP_ERROR);

    BYPASS_ERR_E ret = BP_OK;
    bypass_indicator_data_t *p_ind_sw = vesync_malloc(sizeof(bypass_indicator_data_t));
    if (NULL == p_ind_sw)
    {
        return BP_ERR_NOMEM;
    }

    memset(p_ind_sw, 0, sizeof(bypass_indicator_data_t));

    cJSON* json_data = cJSON_GetObjectItemCaseSensitive(json, "id");
    if (cJSON_IsNumber(json_data))
    {
        p_ind_sw->id = json_data->valueint&0xFF;
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "enabled");
    if (cJSON_IsBool(json_data))
    {
        p_ind_sw->enable = json_data->valueint;
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_SET_INDICATOR);
    if (method_cb)
    {
        method_cb(p_trace_msg, (void*)p_ind_sw, sizeof(bypass_indicator_data_t));
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

_exit:
    vesync_free(p_ind_sw);

    return ret;
}


static bypass_item_data_t method_tbl[] = {
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_SET_INDICATOR, "setIndicatorLightSwitch", bypass_method_set_indicator_handle, NULL},
};

void vesync_bypass_indicator_init(void)
{
    for (int i = 0; i < SIZEOF_ARRAY(method_tbl); i++)
    {
        bypass_item_t *item = vesync_bypass_init_item(&method_tbl[i]);
        if (item != NULL)
        {
            vesync_bypass_add_item(item);
        }
    }
}

