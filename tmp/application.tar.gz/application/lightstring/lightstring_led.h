/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file    lightstring_led.h
* @brief   灯效控制
* @author  Lind
* @date     2021-12-13
*/

#ifndef __LIGHTSTRING_LED_H__
#define __LIGHTSTRING_LED_H__

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

// LED 控制任务的参数
#define LS_LED_TASK_NAME                ("LED_task")
#define LS_LED_TASK_STACKSIZE           (1024 * 4)
#define LS_LED_TASK_PRIO                TASK_PRIORITY_HIGH
#define LS_LED_EVENT_QUEUE_MAX_NUM      (8)     // LED控制任务消息队列数
#define LS_ADC_DATA_NUM                 (512)   // ADC采样数量
#define LS_VOICE_CTRL_THRESHOLD         (1800)
#define LS_SOUND_THRESHOLD              (1600)
#define LS_ADC_PROTECT_TIME             (2000) // ADC上电保护时间
#define LS_ADC_FILTER_COEF              (50)   // 滤波系数

#define DELAY_500US {asm("nop");asm("nop"); asm("nop");asm("nop"); asm("nop");asm("nop"); asm("nop");asm("nop");asm("nop");asm("nop");}  // 延迟

/*
 * @brief Lightstring led控制事件类型
 */
typedef enum
{
    LS_LED_EV_OFF = 0,          // 关闭
    LS_LED_EV_ON,               // 开启
    LS_LED_EV_VOICE_CTRL,       // 声控模式开关
    LS_LED_EV_PRODUCTION,       // 产测独有灯效
} LS_LED_EV_E;

/*
 * @brief Lightstring led模式类型
 */
typedef enum
{
    LS_LED_BREATHING = 0,       // 呼吸
    LS_LED_SWITCH,          // 跳变，常亮其中一种配置
} LS_LED_MODE_E;

/*
 * @brief Lightstring 模式
 */
typedef enum
{
    LS_MODE_OFF = 0,         // 关闭
    LS_MODE_SCENE,
    LS_MODE_MUSIC,
} LS_MODE_E;

/*
 * @brief Lightstring 两路led灯效模式
 */
typedef enum
{
    MODE_TYPE_CH0 = 0,      // 单通道
    MODE_TYPE_CH1,          // 单通道
    MODE_TYPE_ALL,          // 双通道
    MODE_TYPE_ALTERNATE,    // 交替
} LS_LED_MODE_TYPE_E;

/**
 * @brief  lightstring动态灯效模式参数
 */
typedef struct
{
    LS_MODE_E mode;
    uint8_t scene_id;
    uint8_t brightness;
    uint8_t speed;
} ls_mode_param_t;

/*
 * @brief Lightstring led控制事件
 */
typedef struct
{
    LS_LED_EV_E id;
    union
    {
        bool voice_ctrl;
        ls_mode_param_t mode_param;
    } param;
} ls_led_ev_t;

/*
 * @brief Lightstring 灯效节点结构体
 */
typedef struct
{
    uint16_t output1;        // 占空比
    uint16_t output2;        // 占空比
    uint16_t step_num;      // 保持时间/渐变时间
} ls_led_node_t;

/*
 * @brief Lightstring 动态灯效参数
 */
typedef struct
{
    uint8_t node_num;
    LS_LED_MODE_E mode;
    LS_LED_MODE_TYPE_E type;
    ls_led_node_t *node_head;
} ls_led_dynamic_params;

/*
 * @brief LedStrip 变化灯效状态记录
 */
typedef struct
{
    ls_led_dynamic_params *last_mode;   // 场景id
    LS_LED_MODE_E mode;                 // 灯效模式
    LS_LED_MODE_TYPE_E type;            // 两路led灯效模式
    uint8_t cur_node;                   // 模式当前的灯效节点1->2 为1
    uint16_t remain_step;               // 灯效节点完全切换的剩余步数，等于时间
    uint8_t times;                      // 循环周期次数
    uint8_t remain_times;               // 剩余周期次数
} ls_led_changing_status_t;

/**
 * @brief  给lightstring  led任务发通知
 * @param[in]   ev              [通知消息]
 * @return     int              [成功：APP_OK，失败：APP_FAIL]
 */
int ls_led_task_notify(ls_led_ev_t *ev);

/**
* @brief 灯效控制任务参数初始化
* @param[in]  voice_ctrl    [声控标志位]
* @param[in]  speed         [速度]
* @param[in]  brightness    [亮度]
*/
void ls_led_params_init(bool voice_ctrl, uint8_t speed, float brightness);

/**
* @brief  led 控制初始化
*/
void ls_led_init(void);

#ifdef __cplusplus
 }
#endif /* __cplusplus */

#endif /* __LIGHTSTRING_LED_H__ */

