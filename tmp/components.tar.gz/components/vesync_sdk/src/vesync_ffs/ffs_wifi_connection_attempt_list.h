/**
* Copyright © Etekcity Technologies Co., Ltd. 2021. All rights reserved.
* @file         ffs_wifi_connection_attempt_list.h
* @brief        Ffs Wi-Fi connection attempt list
* @author       Owen.zhang
* @date         2020-04-22
*/
#ifndef FFS_WIFI_CONNECTION_ATTEMPT_LIST_H_
#define FFS_WIFI_CONNECTION_ATTEMPT_LIST_H_

#include "ffs_wifi_context.h"
#include <stddef.h>

#ifdef __cplusplus
extern "C"
{
#endif

/** @brief Store the Wi-Fi connection attempt in the list by copy.
* @param[in] wifiContext Wi-Fi context
* @param[in] connectionAttempt The Wi-Fi connection attempt
* @returns Enumerated [result](@ref FFS_RESULT)
*/
FFS_RESULT ffsWifiConnectionAttemptListPush(FfsWifiContext_t *wifiContext, FfsWifiConnectionAttempt_t *connectionAttempt);

/** @brief Retrieves the next Wi-Fi connection attempt in the list, without removing it.
* @param[in] wifiContext Wi-Fi context
* @param[out] connectionAttempt The next Wi-Fi connection attempt
* @returns Enumerated [result](@ref FFS_RESULT)
*/
FFS_RESULT ffsWifiConnectionAttemptListPeek(FfsWifiContext_t *wifiContext, FfsWifiConnectionAttempt_t **connectionAttempt);

/** @brief Removes the next Wi-Fi connection attempt from the list and frees the resources.
* @param[in] wifiContext Wi-Fi context
* @returns Enumerated [result](@ref FFS_RESULT)
*/
FFS_RESULT ffsWifiConnectionAttemptListPop(FfsWifiContext_t *wifiContext);

/** @brief Removes all the Wi-Fi connection attempts from the list and frees the resources.
* @param[in] wifiContext Wi-Fi context
* @returns Enumerated [result](@ref FFS_RESULT)
*/
FFS_RESULT ffsWifiConnectionAttemptListClear(FfsWifiContext_t *wifiContext);

/** @brief Checks if the Wi-Fi connection attempt list is empty.
* @param[in] wifiContext Wi-Fi context
* @param[in] isEmpty The result - true if empty; false otherwise
* @returns Enumerated [result](@ref FFS_RESULT)
*/
FFS_RESULT ffsWifiConnectionAttemptListIsEmpty(FfsWifiContext_t *wifiContext, bool *isEmpty);

#ifdef __cplusplus
}
#endif

#endif /* FFS_WIFI_CONNECTION_ATTEMPT_LIST_H_ */
