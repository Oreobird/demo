/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file        outlet_timing.c
* @brief       outlet timing配置
* @author      Joshua
* @date        2021-06-15
*/


#include <string.h>
#include <stdio.h>
#include <time.h>

#include "cJSON.h"

#include "vesync_common.h"
#include "vesync_log.h"
#include "vesync_device.h"
#include "vesync_report.h"
#include "vesync_production.h"
#include "vesync_netcfg.h"

#include "outlet_report.h"
#if defined(OUTLET_ELEC_METERING) && (OUTLET_ELEC_METERING == 1)
#include "outlet_metering.h"
#endif
#include "outlet.h"

static char s_on_off_chg_rsn[MAX_STAT_CHG_RSN_STR_LEN];         // 记录开关开启/关闭的原因


/**
 * @brief 上报第三方接口(http://34.194.32.46:8080/doc/POOTQH6Bs)，方法名：statusChangeNtyV2
 *
 * @deprecated 设备开关状态变化，通知云端(http://34.194.32.46:8080/doc/POgSBTDFF)，方法名：updateOnOffV2
 *
 * @param[in]  p_dev_status      [设备开关状态]
 * @param[in]  len               [开关数量]
 * @return     int               [成功/失败]
 */
static int report_on_off_status(onoff_status_t *p_dev_status, uint8_t len)
{
    int idx = 0;
    char tmp_buf[16] = {0};
    cJSON *data = NULL;

    // 参数判断
    if (NULL == p_dev_status)
    {
        APP_LOG(LOG_ERROR, "The parameter contains a null pointer!!\n");
        return APP_FAIL;
    }

    // json组装
    data = cJSON_CreateObject();
    if(NULL == data)
    {
        APP_LOG(LOG_ERROR, "Create object fail\n");
        return APP_FAIL;
    }

    cJSON *chg_stat = cJSON_AddObjectToObject(data, "changedStatus");
    cJSON *unchg_stat = cJSON_AddObjectToObject(data, "unchangedStatus");
    if(NULL == chg_stat || NULL == unchg_stat)
    {
        APP_LOG(LOG_ERROR, "Create object fail\n");
        goto EXIT;
    }

    // 根据协议，当changeReason为setup/reconnect时，所有状态放在 unchangedStatus
    cJSON *obj_sel = (0 == strcmp(p_dev_status->rsn, STAT_CHG_RSN_CONFIG_NET_STR) ||
                      0 == strcmp(p_dev_status->rsn, STAT_CHG_RSN_RECONNECT_STR))
                         ? unchg_stat
                         : chg_stat;

    for (idx = 0; idx < len; idx++)
    {
        memset(tmp_buf, 0, sizeof(tmp_buf));
        snprintf(tmp_buf, sizeof(tmp_buf), "switch%d", p_dev_status->switch_idx);
        if (p_dev_status->is_on)
        {
            cJSON_AddStringToObject(obj_sel, tmp_buf, "on");
        }
        else
        {
            cJSON_AddStringToObject(obj_sel, tmp_buf, "off");
        }
    }

    cJSON_AddStringToObject(data, "changeReason", p_dev_status->rsn);

    // 发送
    int ret = vesync_report_status_change_nty(data);
    return ret == SDK_OK ? APP_OK : APP_FAIL;

EXIT:
    cJSON_Delete(data);
    return APP_FAIL;
}


// 网络连接成功后上报设备开关状态
static void report_status_for_nwk_connected(void)
{
    outlet_ev_t ev = {
        id: OUTLET_EV_NET_CONNETED,
        act_src: OUTLET_ACT_SRC_UNKNOW,
        rsn: ""
    };
    // 上报一般网络重连的状态
    strncpy(s_on_off_chg_rsn, STAT_CHG_RSN_RECONNECT_STR, sizeof(s_on_off_chg_rsn));

    outlet_report_on_off(outlet_get_switch_onoff());
    outlet_app_task_notify(&ev);
}


// 配网成功后上报设备开关状态
static void report_status_for_net_cfg_success(void)
{
    outlet_ev_t ev = {
        id: OUTLET_EV_NET_CONNETED,
        act_src: OUTLET_ACT_SRC_UNKNOW,
        rsn: ""
    };
    // 上报配网成功重连的状态
    strncpy(s_on_off_chg_rsn, STAT_CHG_RSN_CONFIG_NET_STR, sizeof(s_on_off_chg_rsn));

    outlet_report_on_off(outlet_get_switch_onoff());
    outlet_app_task_notify(&ev);
}


/**
 * @brief   上报模块初始化
 * @param   无
 * @return  void
 */
void outlet_report_init(void)
{
    // 初始化设备状态改变原因
    memset(s_on_off_chg_rsn, 0, sizeof(s_on_off_chg_rsn));

    vesync_net_event_reg_nwk_conn_cb(report_status_for_nwk_connected);
    vesync_net_cfg_reg_success_cb(report_status_for_net_cfg_success);
}


/**
 * @brief 获取开关变化的原因
 * @param      void
 * @return     const char*          [开关开启/关闭的原因]
 */
const char* outlet_get_switch_change_reason(void)
{
    if (0 == strlen(s_on_off_chg_rsn))
    {
        return STAT_CHG_RSN_BTN_STR;
    }

    return s_on_off_chg_rsn;
}

/**
 * @brief 开关变化的原因
 * @param[in]  rsn          [开关开启/关闭的原因]
 * @return     void         [none]
 */
void outlet_set_switch_change_reason(const char* rsn)
{
    VCOM_NULL_PARAM_CHK(rsn, return);

    APP_LOG(LOG_DEBUG, "Outlet change reason(%s).\n", rsn);

    // 开关变化的原因：按键、bypass、schedule、timer
    if (0 != strlen(s_on_off_chg_rsn))
    {
        APP_LOG(LOG_DEBUG, "Switch change reason is overwritten.\n");
    }

    strncpy(s_on_off_chg_rsn, rsn, sizeof(s_on_off_chg_rsn) - 1);
}

/**
 * @brief 设备开关状态变化，通知云端(http://34.194.32.46:8080/doc/POgSBTDFF)，方法名：updateOnOffV2
 * @param[in]  on               [开启(true)/关闭(false)]
 * @return     int              [成功/失败]
 */
int outlet_report_on_off(bool on)
{
    int ret = APP_FAIL;
    onoff_status_t on_off;

    if (PRODUCTION_EXIT != vesync_production_get_status())
    {
        APP_LOG(LOG_WARN, "Proudction test, skip!!\n");
        return ret;
    }

    memset(&on_off, 0, sizeof(onoff_status_t));
    on_off.switch_idx = 1;      // 只有一个开关
    on_off.is_on = on;
    strncpy(on_off.rsn, s_on_off_chg_rsn, sizeof(on_off.rsn) - 1);
    APP_LOG(LOG_DEBUG, "s_on_off_chg_rsn = %s\n", s_on_off_chg_rsn);

    ret = report_on_off_status(&on_off, 1);
    memset(s_on_off_chg_rsn, 0, sizeof(s_on_off_chg_rsn));         // 清除标志位

    return ret;
}

/**
 * @brief timer执行结果上报(http://34.194.32.46:8080/doc/BVH3a8uib)， deviceLogReport
 * @param[in]  switch_timer_t   [开关timer结构体]
 * @param[in]  ret              [开关timer执行结果]
 * @param[in]  p_err_msg        [开关timer执行失败原因]
 * @return     int              [成功/失败]
 */
int outlet_report_timing_exec(outlet_timing_t *p_timer, uint8_t ret, char *p_err_msg)
{
    char buf[32] = {0};
    cJSON *json_dat = NULL;

    // 参数判断
    if (NULL == p_timer || NULL == p_err_msg)
    {
        APP_LOG(LOG_ERROR, "The parameter contains a null pointer!!\n");
        return APP_FAIL;
    }

    json_dat = cJSON_CreateObject();
    if (NULL == json_dat)
    {
        APP_LOG(LOG_ERROR, "Create data object fail\n");
        return APP_FAIL;
    }

    if (p_timer->on_off)
    {
        snprintf(buf, sizeof(buf), "switch=on");
    }
    else
    {
        snprintf(buf, sizeof(buf), "switch=off");
    }

    cJSON_AddNumberToObject(json_dat, "timerID", p_timer->id);
    cJSON_AddStringToObject(json_dat, "act", buf);
    if (APP_OK == ret)
    {
        cJSON_AddStringToObject(json_dat, "result", "succ");
    }
    else
    {
        cJSON_AddStringToObject(json_dat, "result", "fail");
        cJSON_AddStringToObject(json_dat, "reason", p_err_msg);
    }

    return vesync_report_device_log(json_dat);
}

/**
 * @brief Schedule执行结果上报(http://34.194.32.46:8080/doc/BVH3a8uib)， deviceLogReport
 *
 * @param[in] sche_id   [Schedule配置项ID]
 * @param[in] type      [Schedule类型]
 * @param[in] repeat    [重复配置]
 * @param[in] p_app_cfg [APP的Action相关配置]
 * @param[in] ret       [执行的返回码]
 * @param[in] p_err_msg [指向失败的原因字符串]
 * @return int          [成功/失败]
 */
int outlet_report_schedule_exec(uint32_t sche_id, uint8_t type, uint8_t repeat,
                                outlet_sche_app_cfg_t *p_app_cfg, uint8_t ret, char *p_err_msg)
{
    // Action描述字符串Buffer
    char buf[32] = {0};

    if (NULL == p_app_cfg || NULL == p_err_msg)
    {
        APP_LOG(LOG_ERROR, "The parameter contains a null pointer!\n");
        return APP_FAIL;
    }

    cJSON *json = cJSON_CreateObject();
    if (!cJSON_IsObject(json))
    {
        APP_LOG(LOG_ERROR, "Create data object fail\n");
        return APP_FAIL;
    }

    if (p_app_cfg->act_on_off)
    {
        snprintf(buf, sizeof(buf), "switch=on");
    }
    else
    {
        snprintf(buf, sizeof(buf), "switch=off");
    }

    cJSON_AddNumberToObject(json, "schID", sche_id);
    cJSON_AddNumberToObject(json, "type", type);
    cJSON_AddNumberToObject(json, "repeat", repeat);
    cJSON_AddStringToObject(json, "act", buf);

    if (APP_OK == ret)
    {
        cJSON_AddStringToObject(json, "result", "succ");
    }
    else
    {
        cJSON_AddStringToObject(json, "result", "fail");
        cJSON_AddStringToObject(json, "reason", p_err_msg);
    }

   return vesync_report_device_log(json);
}

/**
 * @brief Away执行结果上报(http://34.194.32.46:8080/doc/BVH3a8uib)， deviceLogReport
 *
 * @param[in] p_rand_time_points [当前执行的随机时间点表]
 * @param[in] time_point_num     [随机时间点的数量]
 * @param[in] repeat             [重复配置]
 * @param[in] exec_cnt           [执行次数]
 * @param[in] p_action           [执行事件动作描述]
 * @param[in] result             [执行结果]
 * @param[in] p_err_msg          [执行错误的描述信息]
 * @return int                   [成功/失败]
 */
int outlet_report_away_exec(uint32_t *p_rand_time_points, uint32_t time_point_num, uint8_t repeat,
                            uint32_t exec_cnt, char *p_action, uint8_t result, char *p_err_msg)
{
    if (NULL == p_action || NULL == p_err_msg)
    {
        APP_LOG(LOG_ERROR, "The parameter contains a null pointer!\n");
        return APP_FAIL;
    }

    cJSON *json = cJSON_CreateObject();
    if (!cJSON_IsObject(json))
    {
        APP_LOG(LOG_ERROR, "Create data object fail\n");
        return APP_FAIL;
    }

    cJSON *json_runtime_arr = cJSON_CreateArray();
    if (cJSON_IsArray(json_runtime_arr))
    {
        for (uint32_t idx = 0; idx < time_point_num; idx++)
        {
            cJSON_AddItemToArray(json_runtime_arr, cJSON_CreateNumber(p_rand_time_points[idx]));
        }
    }
    cJSON_AddItemToObject(json, "runtime",  json_runtime_arr);
    cJSON_AddStringToObject(json, "act", p_action);
    if (repeat)
    {
        cJSON_AddNumberToObject(json, "counter", exec_cnt);
    }

    if (APP_OK == result)
    {
        cJSON_AddStringToObject(json, "result", "succ");
    }
    else
    {
        cJSON_AddStringToObject(json, "result", "fail");
        cJSON_AddStringToObject(json, "reason", p_err_msg);
    }

    return vesync_report_device_log(json);
}

#if defined(OUTLET_ELEC_METERING) && (OUTLET_ELEC_METERING == 1)
/**
 * @brief 插座异常上报(https://yapi.vesync.com/project/222/interface/api/4185)， outletFaultReport
 * @return     int              [成功/失败]
 */
int outlet_report_exception(void)
{
    static unsigned char s_report_exeception = 0;   // 记录设备故障上报标志，0表示未上报，1表示已上报
    cJSON *json_data = NULL;

    if (s_report_exeception)    // 已上报，不再重复上报
    {
        return APP_OK;
    }

    if (PRODUCTION_EXIT != vesync_production_get_status())
    {
        APP_LOG(LOG_WARN, "Proudction test, skip!!\n");
        return APP_FAIL;
    }

    json_data = cJSON_CreateObject();
    if (!cJSON_IsObject(json_data))
    {
        APP_LOG(LOG_ERROR, "Create data object fail\n");
        return APP_FAIL;
    }

    cJSON_AddStringToObject(json_data, "accountId", vesync_device_get_account_id());

    if (SDK_OK == vesync_report_cloud(NET_DATA_TOPIC_STATUS, "outletFaultReport", json_data, CAUSE_CHANGE))
    {
        s_report_exeception = 1;    // 已上报
        return APP_OK;
    }
    return APP_FAIL;
}

/**
 * @brief 插座省电断开上报(https://yapi.vesync.com/project/222/interface/api/4092)， ELECConsumeProtectReport
 * @return     int              [成功/失败]
 */
int outlet_report_elec_save_exec(void)
{
    cJSON *json_data = NULL;

    if (PRODUCTION_EXIT != vesync_production_get_status())
    {
        APP_LOG(LOG_WARN, "Proudction test, skip!!\n");
        return APP_FAIL;
    }

    json_data = cJSON_CreateObject();
    if (!cJSON_IsObject(json_data))
    {
        APP_LOG(LOG_ERROR, "Create data object fail\n");
        return APP_FAIL;
    }

    cJSON_AddStringToObject(json_data, "accountId", vesync_device_get_account_id());

    if (SDK_OK == vesync_report_cloud(NET_DATA_TOPIC_STATUS, "ELECConsumeProtectReport", json_data, CAUSE_CHANGE))
    {
        return APP_OK;
    }
    return APP_FAIL;
}

/**
 * @brief 插座功率触发断开上报(https://yapi.vesync.com/project/222/interface/api/4093)， powerThresholdProtectReport
 * @param[in]  type             [触发类型，0——大于最大功率触发，1——小于最小功率触发]
 * @return     int              [成功/失败]
 */
int outlet_report_pow_trig_exec(uint8_t type)
{
    cJSON *json_data = NULL;

    if (PRODUCTION_EXIT != vesync_production_get_status())
    {
        APP_LOG(LOG_WARN, "Proudction test, skip!!\n");
        return APP_FAIL;
    }

    json_data = cJSON_CreateObject();
    if (!cJSON_IsObject(json_data))
    {
        APP_LOG(LOG_ERROR, "Create data object fail\n");
        return APP_FAIL;
    }

    cJSON_AddStringToObject(json_data, "accountId", vesync_device_get_account_id());
    cJSON_AddNumberToObject(json_data, "protectType", type);

    if (SDK_OK == vesync_report_cloud(NET_DATA_TOPIC_STATUS, "powerThresholdProtectReport", json_data, CAUSE_CHANGE))
    {
        return APP_OK;
    }
    return APP_FAIL;
}

/**
 * @brief 时间戳转格式“YYYY-MM-DD”
 * @param[in]  record_ts        [统计当天零点时间戳]
 * @return     int              [成功/失败]
 */
static void ts_trans_str(uint32_t ts, char *str, uint8_t len)
{
    struct tm ts_tm;
    time_t ts_tt = (time_t)ts;

    gmtime_r(&ts_tt, &ts_tm);
    strftime(str, len, "%Y-%m-%d", &ts_tm);
}

/**
 * @brief 插座电量统计上报(https://yapi.vesync.com/project/222/interface/api/4091)， reportELECConsumePerDay
 * @param[in]  elec             [用电量]
 * @param[in]  record_ts        [统计当天零点时间戳]
 * @return     int              [成功/失败]
 */
int outlet_report_elec_metering(float elec, uint32_t record_ts)
{
    cJSON *json_data = NULL;
    char ts_str[] = "YYYY-MM-DD";

    if (PRODUCTION_EXIT != vesync_production_get_status())
    {
        APP_LOG(LOG_WARN, "Proudction test, skip!!\n");
        return APP_FAIL;
    }
    if (record_ts < VCOM_SYSTEM_MIN_TS)
    {
        APP_LOG(LOG_ERROR, "record_ts error\n");
        return APP_FAIL;
    }
    if (elec < 0)
    {
        APP_LOG(LOG_ERROR, "elec error\n");
        return APP_FAIL;
    }

    json_data = cJSON_CreateObject();

    if (!cJSON_IsObject(json_data))
    {
        APP_LOG(LOG_ERROR, "Create data object fail\n");
        return APP_FAIL;
    }
    ts_trans_str(record_ts, ts_str, sizeof(ts_str));
    cJSON_AddStringToObject(json_data, "accountId", vesync_device_get_account_id());
    cJSON_AddNumberToObject(json_data, "KWHPerDay", elec / 1000);
    cJSON_AddStringToObject(json_data, "recordDate", ts_str);

    if (SDK_OK == vesync_report_cloud(NET_DATA_TOPIC_DATA, "reportELECConsumePerDay", json_data, CAUSE_TIME))
    {
        return APP_OK;
    }
    return APP_FAIL;
}

#if defined(OUTLET_METERING_PRO_REPORT) && (OUTLET_METERING_PRO_REPORT == 1)
/**
 * @brief 插座统计上报(http://54.172.13.146:8080/doc/S9FWJuxcu/edit)， reportMeasuredPUI
 * @return     int              [成功/失败]
 */
int outlet_report_measured_pui(void)
{
    metering_data_t metering_data;
    cJSON *json_data = NULL;

    if (APP_OK != outlet_metering_get_metering_data(&metering_data))
    {
        return APP_FAIL;
    }

    if (0 >= metering_data.power)   // 功率为零，不上报
    {
        return APP_OK;
    }

    json_data = cJSON_CreateObject();

    if (!cJSON_IsObject(json_data))
    {
        APP_LOG(LOG_ERROR, "Create data object fail\n");
        return APP_FAIL;
    }


    cJSON_AddNumberToObject(json_data, "power", metering_data.power);
    cJSON_AddNumberToObject(json_data, "voltage", metering_data.voltage);
    cJSON_AddNumberToObject(json_data, "current", metering_data.current);

    if (SDK_OK == vesync_report_cloud(NET_DATA_TOPIC_STATUS, "reportMeasuredPUI", json_data, CAUSE_CHANGE))
    {
        return APP_OK;
    }
    return APP_FAIL;
}
#endif

#endif

