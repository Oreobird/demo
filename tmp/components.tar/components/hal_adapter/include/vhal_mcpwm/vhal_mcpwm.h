/**
 *  Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vhal_mcpwm.h
 * @brief       Motor Control PWM驱动接口封装
 * @date        2021-04-22
 */

#ifndef __VHAL_MCPWM_H__
#define __VHAL_MCPWM_H__

#include <stdint.h>


#ifdef __cplusplus
extern "C"
{
#endif

#define CAP_SIG_NUM     3               // Three capture signals
#define CAP0_INT_EN     BIT(27)         // Capture 0 interrupt bit

/*
 * @brief PWM io signals
 */
typedef enum
{
    PWM_0A = 0,                         // PWM0A output pin
    PWM_0B,                             // PWM0B output pin
    PWM_1A,                             // PWM1A output pin
    PWM_1B,                             // PWM1B output pin
    PWM_2A,                             // PWM2A output pin
    PWM_2B,                             // PWM2B output pin
    PWM_SYNC_0,                         // SYNC0  input pin
    PWM_SYNC_1,                         // SYNC1  input pin
    PWM_SYNC_2,                         // SYNC2  input pin
    PWM_FAULT_0,                        // FAULT0 input pin
    PWM_FAULT_1,                        // FAULT1 input pin
    PWM_FAULT_2,                        // FAULT2 input pin
    PWM_CAP_0 = 84,                     // CAP0   input pin
    PWM_CAP_1,                          // CAP1   input pin
    PWM_CAP_2,                          // CAP2   input pin
} PWM_IO_SIGNALS_E;

/*
 * @brief PWM unit
 */
typedef enum
{
    PWM_UNIT_0 = 0,                     // PWM unit0 selected
    PWM_UNIT_1,                         // PWM unit1 selected
    PWM_UNIT_MAX,                       // Num of PWM units
} PWM_UNIT_E;

/**
 * @brief PWM timer
 */
typedef enum
{
    PWM_TIMER_0 = 0,                    //Select PWM timer0
    PWM_TIMER_1,                        // Select PWM timer1
    PWM_TIMER_2,                        // Select PWM timer2
    PWM_TIMER_MAX,                      // Num of PWM timers
} PWM_TIMER_E;

/**
 * @brief PWM operator
 */
typedef enum
{
    PWM_OPR_A = 0,                      // Select PWMXA, where 'X' is timer number
    PWM_OPR_B,                          // Select PWMXB, where 'X' is timer number
    PWM_OPR_MAX,                        // Num of operators to each timer of PWM
} PWM_OPERATOR_E;

/**
 * @brief Select type of MCPWM counter
 */
typedef enum
{
    PWM_UP_COUNTER = 1,                 // For asymmetric MCPWM
    PWM_DOWN_COUNTER,                   // For asymmetric MCPWM
    PWM_UP_DOWN_COUNTER,                // For symmetric MCPWM, frequency is half of MCPWM frequency set
    PWM_COUNTER_MAX,                    // Maximum counter mode
} PWM_COUNTER_TYPE_E;

/**
 * @brief Select type of MCPWM duty cycle mode
 */
typedef enum
{
    PWM_DUTY_MODE_0 = 0,                // Active high duty, i.e. duty cycle proportional to high time for asymmetric MCPWM
    PWM_DUTY_MODE_1,                    // Active low duty,  i.e. duty cycle proportional to low  time for asymmetric MCPWM, out of phase(inverted) MCPWM
    PWM_DUTY_MODE_MAX,                  // Num of duty cycle modes
} PWM_DUTY_TYPE_E;

/**
 * @brief MCPWM select capture signal input
 */
typedef enum
{
    PWM_SELECT_CAP0 = 0,                // Select CAP0 as input
    PWM_SELECT_CAP1,                    // Select CAP1 as input
    PWM_SELECT_CAP2,                    // Select CAP2 as input
} PWM_CAPTURE_SIGNAL_E;

/**
 * @brief MCPWM select capture starts from which edge
 */
typedef enum
{
    PWM_NEG_EDGE = 0,                   // Capture starts from negative edge
    PWM_POS_EDGE,                       // Capture starts from positive edge
} PWM_CAPTURE_ON_EDGE_E;

/**
 * @brief MCPWM config structure
 */
typedef struct
{
    uint32_t frequency;                 // Set frequency of MCPWM in Hz
    float cmpr_a;                       // Set % duty cycle for operator a(MCPWMXA), i.e for 62.3% duty cycle, duty_a = 62.3
    float cmpr_b;                       // Set % duty cycle for operator b(MCPWMXB), i.e for 48% duty cycle, duty_b = 48.0
    PWM_DUTY_TYPE_E duty_mode;          // Set type of duty cycle
    PWM_COUNTER_TYPE_E counter_mode;    // Set  type of MCPWM counter
} pwm_config_t;

/**
 * @brief MCPWM capture structure
 */
typedef struct
{
    uint32_t capture_signal;            // The value of capture signal
    PWM_CAPTURE_SIGNAL_E sel_cap_signal;// Number of capture signal input
} pwm_capture_t;

/**
 * @brief  pwm gpio 初始化函数
 * @param[in]  pwm_unit                 [设置MCPWM单元(0-1)]
 * @param[in]  pwm_io_signal            [设置MCPWM信号]
 * @param[in]  gpio_num                 [MCPWM配置GPIO]
 * @return     int32_t                  [操作结果, 0为成功，其他值表示失败]
 */
int32_t vhal_pwm_gpio_init(PWM_UNIT_E pwm_unit, PWM_IO_SIGNALS_E pwm_io_signal, int gpio_num);

/**
 * @brief  pwm 功能初始化函数
 * @param[in]  pwm_unit                 [设置MCPWM单元(0-1)]
 * @param[in]  pwm_timer                [设置MCPWM timer]
 * @param[in]  pwm_cfg                  [MCPWM配置]
 * @return     int32_t                  [操作结果, 0为成功，其他值表示失败]
 */
int32_t vhal_pwm_init(PWM_UNIT_E pwm_unit, PWM_TIMER_E pwm_timer, pwm_config_t *pwm_cfg);

/**
 * @brief  pwm 功能开启函数
 * @param[in]  pwm_unit                 [设置MCPWM单元(0-1)]
 * @param[in]  pwm_timer                [设置MCPWM timer]
 * @return     int32_t                  [操作结果, 0为成功，其他值表示失败]
 */
int32_t vhal_pwm_start(PWM_UNIT_E pwm_unit, PWM_TIMER_E pwm_timer);

/**
 * @brief  pwm 功能关闭函数
 * @param[in]  pwm_unit                 [设置MCPWM单元(0-1)]
 * @param[in]  pwm_timer                [设置MCPWM timer]
 * @return     int32_t                  [操作结果, 0为成功，其他值表示失败]
 */
int32_t vhal_pwm_stop(PWM_UNIT_E pwm_unit, PWM_TIMER_E pwm_timer);

/**
 * @brief  设置pwm 频率
 * @param[in]  pwm_unit                 [设置MCPWM单元(0-1)]
 * @param[in]  pwm_timer                [设置MCPWM timer]
 * @param[in]  frequency                [设置MCPWM 频率]
 * @return     int32_t                  [操作结果, 0为成功，其他值表示失败]
 */
int32_t vhal_pwm_set_frequency(PWM_UNIT_E pwm_unit, PWM_TIMER_E pwm_timer, uint32_t frequency);

/**
 * @brief  设置pwm 占空比
 * @param[in]  pwm_unit                 [设置MCPWM单元(0-1)]
 * @param[in]  pwm_timer                [设置MCPWM timer]
 * @param[in]  pwm_operator             [设置MCPWM operator]
 * @param[in]  duty                     [设置MCPWM 占空比]
 * @return     int32_t                  [操作结果, 0为成功，其他值表示失败]
 */
int32_t vhal_pwm_set_duty(PWM_UNIT_E pwm_unit, PWM_TIMER_E pwm_timer, PWM_OPERATOR_E pwm_operator, float duty);

/**
 * @brief  设置pwm 占空比类型
 * @param[in]  pwm_unit                 [设置MCPWM单元(0-1)]
 * @param[in]  pwm_timer                [设置MCPWM timer]
 * @param[in]  pwm_operator             [设置MCPWM operator]
 * @param[in]  duty_type                [设置MCPWM 占空比类型]
 * @return     int32_t                  [操作结果, 0为成功，其他值表示失败]
 */
int32_t vhal_pwm_set_duty_type(PWM_UNIT_E pwm_unit, PWM_TIMER_E pwm_timer, PWM_OPERATOR_E pwm_operator,
                                    PWM_DUTY_TYPE_E duty_type);

/**
* @brief  获取pwm 频率
* @param[in]   pwm_unit                 [设置MCPWM单元(0-1)]
* @param[in]   pwm_timer                [设置MCPWM timer]
* @return      uint32_t                 [获取频率]
*/
uint32_t vhal_pwm_get_frequency(PWM_UNIT_E pwm_unit, PWM_TIMER_E pwm_timer);

/**
 * @brief   获取pwm 占空比
 * @param[in]   pwm_unit                [设置MCPWM单元(0-1)]
 * @param[in]   pwm_timer               [设置MCPWM timer]
 * @param[in]   pwm_operator            [设置MCPWM operator]
 * @return      float                   [获取占空比]
 */
float vhal_pwm_get_duty(PWM_UNIT_E pwm_unit, PWM_TIMER_E pwm_timer, PWM_OPERATOR_E pwm_operator);

/**
 * @brief  使能pwm capture功能
 * @param[in]  pwm_unit                 [设置MCPWM单元(0-1)]
 * @param[in]  cap_sig                  [捕获通道]
 * @param[in]  cap_edge                 [设置捕获边沿]
 * @param[in]  num_of_pulse             [脉冲数]
 * @return     int32_t                  [操作结果, 0为成功，其他值表示失败]
 */
int32_t vhal_pwm_enable_capture(PWM_UNIT_E pwm_unit, PWM_CAPTURE_SIGNAL_E cap_sig, PWM_CAPTURE_ON_EDGE_E cap_edge,
                                uint32_t num_of_pulse);

/**
* @brief  除能pwm capture 功能
* @param[in]  mcpwm_num                 [MCPWM单元(0-1)]
* @param[in]  cap_sig                   [捕获通道]
 * @return     int32_t                  [操作结果, 0为成功，其他值表示失败]
*/
int32_t vhal_pwm_disable_capture(PWM_UNIT_E pwm_unit, PWM_CAPTURE_SIGNAL_E cap_sig);

/**
 * @brief  获取 pwm capture value
 * @param[in]   pwm_unit                [MCPWM单元(0-1)]
 * @param[in]   cap_sig                 [捕获通道]
 * @return      uint32_t                [捕获值]
 */
uint32_t vhal_pwm_get_capture_signal_value(PWM_UNIT_E pwm_unit, PWM_CAPTURE_SIGNAL_E cap_sig);

/**
 * @brief  pwm 中断函数注册
 * @param[in]  pwm_unit                 [设置MCPWM单元(0-1)]
 * @param[in]  fn                       [中断处理函数]
 * @param[in]  arg                      [中断处理函数传参(无则填NULL)]
 * @param[in]  intr_alloc_flags         [中断分配标志]
 * @param[in]  handle                   [中断返回函数处理]
 * @return     int32_t                  [操作结果, 0为成功，其他值表示失败]
 */
int32_t vhal_pwm_reg_isr(PWM_UNIT_E pwm_unit, void (*fn)(void *), void *arg, int intr_alloc_flags, intr_handle_t *handle);

#ifdef __cplusplus
}
#endif

#endif /* __VHAL_MCPWM_H__ */

