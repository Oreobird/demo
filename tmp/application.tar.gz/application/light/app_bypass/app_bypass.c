/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        app_bypass.c
 * @brief       bypass处理接口
 * @date        2022-03-04
 */
#include <stdio.h>
#include <string.h>
#include "vesync_common.h"
#include "vesync_log.h"
#include "vesync_memory.h"
#include "app_bypass.h"

static BYPASS_ERR_E bypass_set_switch_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    int err_code = BP_ERR_NO_ERR;
    int ret = APP_OK;
    cJSON *reply_json = NULL;
    char err_msg[BP_ERR_MSG_LEN] = {0};
    void *extra = NULL;

    memset(err_msg, 0, sizeof(err_msg));
    cJSON *json_data = NULL;
    bp_set_switch_request_t *request_data = (bp_set_switch_request_t *) vesync_malloc(sizeof(bp_set_switch_request_t));
    if (request_data == NULL)
    {
        err_code = BP_ERR_OUT_OF_MEMORY;
        snprintf(err_msg, sizeof(err_msg), "out of memory");
        goto EXIT;
    }

    memset(request_data, BP_NO_VALUE, sizeof(bp_set_switch_request_t));
    
    json_data = cJSON_GetObjectItemCaseSensitive(json, "powerSwitch");
    if (cJSON_IsNumber(json_data))
    {
        request_data->power_switch = (int)(json_data->valueint);
        
    }
    
    json_data = cJSON_GetObjectItemCaseSensitive(json, "switchIdx");
    if (cJSON_IsNumber(json_data))
    {
        request_data->switch_idx = (int)(json_data->valueint);
        
        if (request_data->switch_idx < 0 || request_data->switch_idx > 256)
        {
            reply_json = NULL;
            err_code = BP_ERR_VALUE_OUT_OF_RANGE;
            snprintf(err_msg, sizeof(err_msg), "switch_idx out of range");
            goto EXIT;
        }
    }
    
    ret = request_data_handle_for_set_switch(request_data, &err_code, err_msg, &extra);
    if (ret != APP_OK)
    {
        reply_json = NULL;
        goto EXIT;
    }

EXIT:
    VCOM_SAFE_FREE(request_data);
    p_msg_ctx->resp_error_code = err_code;
    p_msg_ctx->p_resp_error_msg = err_msg;
    p_msg_ctx->p_response = reply_json;

    return BP_OK;
}

static BYPASS_ERR_E bypass_toggle_switch_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    int err_code = BP_ERR_NO_ERR;
    int ret = APP_OK;
    cJSON *reply_json = NULL;
    char err_msg[BP_ERR_MSG_LEN] = {0};
    void *extra = NULL;

    memset(err_msg, 0, sizeof(err_msg));
    cJSON *json_data = NULL;
    bp_toggle_switch_request_t *request_data = (bp_toggle_switch_request_t *) vesync_malloc(sizeof(bp_toggle_switch_request_t));
    if (request_data == NULL)
    {
        err_code = BP_ERR_OUT_OF_MEMORY;
        snprintf(err_msg, sizeof(err_msg), "out of memory");
        goto EXIT;
    }

    memset(request_data, BP_NO_VALUE, sizeof(bp_toggle_switch_request_t));
    
    json_data = cJSON_GetObjectItemCaseSensitive(json, "switchIdx");
    if (cJSON_IsNumber(json_data))
    {
        request_data->switch_idx = (int)(json_data->valueint);
        
        if (request_data->switch_idx < 0 || request_data->switch_idx > 256)
        {
            reply_json = NULL;
            err_code = BP_ERR_VALUE_OUT_OF_RANGE;
            snprintf(err_msg, sizeof(err_msg), "switch_idx out of range");
            goto EXIT;
        }
    }
    
    ret = request_data_handle_for_toggle_switch(request_data, &err_code, err_msg, &extra);
    if (ret != APP_OK)
    {
        reply_json = NULL;
        goto EXIT;
    }

EXIT:
    VCOM_SAFE_FREE(request_data);
    p_msg_ctx->resp_error_code = err_code;
    p_msg_ctx->p_resp_error_msg = err_msg;
    p_msg_ctx->p_response = reply_json;

    return BP_OK;
}

static BYPASS_ERR_E bypass_set_status_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    int err_code = BP_ERR_NO_ERR;
    int ret = APP_OK;
    cJSON *reply_json = NULL;
    char err_msg[BP_ERR_MSG_LEN] = {0};
    void *extra = NULL;

    memset(err_msg, 0, sizeof(err_msg));
    cJSON *json_data = NULL;
    bp_set_status_request_t *request_data = (bp_set_status_request_t *) vesync_malloc(sizeof(bp_set_status_request_t));
    if (request_data == NULL)
    {
        err_code = BP_ERR_OUT_OF_MEMORY;
        snprintf(err_msg, sizeof(err_msg), "out of memory");
        goto EXIT;
    }

    memset(request_data, BP_NO_VALUE, sizeof(bp_set_status_request_t));
    
    json_data = cJSON_GetObjectItemCaseSensitive(json, "workMode");
    if (cJSON_IsNumber(json_data))
    {
        request_data->work_mode = (int)(json_data->valueint);
        
    }
    
    json_data = cJSON_GetObjectItemCaseSensitive(json, "colorTemp");
    if (cJSON_IsNumber(json_data))
    {
        request_data->color_temp = (int)(json_data->valueint);
        
        if (request_data->color_temp < 0 || request_data->color_temp > 100)
        {
            reply_json = NULL;
            err_code = BP_ERR_VALUE_OUT_OF_RANGE;
            snprintf(err_msg, sizeof(err_msg), "color_temp out of range");
            goto EXIT;
        }
    }
    
    json_data = cJSON_GetObjectItemCaseSensitive(json, "brightness");
    if (cJSON_IsNumber(json_data))
    {
        request_data->brightness = (int)(json_data->valueint);
        
        if (request_data->brightness < 0 || request_data->brightness > 100)
        {
            reply_json = NULL;
            err_code = BP_ERR_VALUE_OUT_OF_RANGE;
            snprintf(err_msg, sizeof(err_msg), "brightness out of range");
            goto EXIT;
        }
    }
    
    json_data = cJSON_GetObjectItemCaseSensitive(json, "hue");
    if (cJSON_IsNumber(json_data))
    {
        request_data->hue = (int)(json_data->valueint);
        
        if (request_data->hue < 0 || request_data->hue > 10000)
        {
            reply_json = NULL;
            err_code = BP_ERR_VALUE_OUT_OF_RANGE;
            snprintf(err_msg, sizeof(err_msg), "hue out of range");
            goto EXIT;
        }
    }
    
    json_data = cJSON_GetObjectItemCaseSensitive(json, "saturation");
    if (cJSON_IsNumber(json_data))
    {
        request_data->saturation = (int)(json_data->valueint);
        
        if (request_data->saturation < 0 || request_data->saturation > 10000)
        {
            reply_json = NULL;
            err_code = BP_ERR_VALUE_OUT_OF_RANGE;
            snprintf(err_msg, sizeof(err_msg), "saturation out of range");
            goto EXIT;
        }
    }
    
    json_data = cJSON_GetObjectItemCaseSensitive(json, "value");
    if (cJSON_IsNumber(json_data))
    {
        request_data->value = (int)(json_data->valueint);
        
        if (request_data->value < 0 || request_data->value > 100)
        {
            reply_json = NULL;
            err_code = BP_ERR_VALUE_OUT_OF_RANGE;
            snprintf(err_msg, sizeof(err_msg), "value out of range");
            goto EXIT;
        }
    }
    
    json_data = cJSON_GetObjectItemCaseSensitive(json, "force");
    if (cJSON_IsNumber(json_data))
    {
        request_data->force = (int)(json_data->valueint);
        
    }
    
    json_data = cJSON_GetObjectItemCaseSensitive(json, "sceneId");
    if (cJSON_IsNumber(json_data))
    {
        request_data->scene_id = (int)(json_data->valueint);
        
        if (request_data->scene_id < 1 || request_data->scene_id > 65535)
        {
            reply_json = NULL;
            err_code = BP_ERR_VALUE_OUT_OF_RANGE;
            snprintf(err_msg, sizeof(err_msg), "scene_id out of range");
            goto EXIT;
        }
    }
    
    json_data = cJSON_GetObjectItemCaseSensitive(json, "segNum");
    if (cJSON_IsNumber(json_data))
    {
        request_data->seg_num = (int)(json_data->valueint);
        
        if (request_data->seg_num < 1 || request_data->seg_num > 255)
        {
            reply_json = NULL;
            err_code = BP_ERR_VALUE_OUT_OF_RANGE;
            snprintf(err_msg, sizeof(err_msg), "seg_num out of range");
            goto EXIT;
        }
    }
    
    
    json_data = cJSON_GetObjectItemCaseSensitive(json, "segHsv");
    if (cJSON_IsArray(json_data))
    {
        cJSON *json_arr = NULL;
        int arr_size = cJSON_GetArraySize(json_data);
        request_data->seg_hsv_num = arr_size;
        for (int i = 0; i < arr_size; i++)
        {
            json_arr = cJSON_GetArrayItem(json_data, i);
            if (json_arr != NULL)
            {
                cJSON *json_item = NULL;
                json_item = cJSON_GetArrayItem(json_arr, 0);
                request_data->seg_hsv[i].hue = (int)(json_item->valueint);
                
                if (request_data->seg_hsv[i].hue < 0 || request_data->seg_hsv[i].hue > 10000)
                {
                    reply_json = NULL;
                    err_code = BP_ERR_VALUE_OUT_OF_RANGE;
                    snprintf(err_msg, sizeof(err_msg), "hue out of range");
                    goto EXIT;
                }

                json_item = cJSON_GetArrayItem(json_arr, 1);
                request_data->seg_hsv[i].saturation = (int)(json_item->valueint);
                
                if (request_data->seg_hsv[i].saturation < 0 || request_data->seg_hsv[i].saturation > 10000)
                {
                    reply_json = NULL;
                    err_code = BP_ERR_VALUE_OUT_OF_RANGE;
                    snprintf(err_msg, sizeof(err_msg), "saturation out of range");
                    goto EXIT;
                }

                json_item = cJSON_GetArrayItem(json_arr, 2);
                request_data->seg_hsv[i].value = (int)(json_item->valueint);
                
                if (request_data->seg_hsv[i].value < 0 || request_data->seg_hsv[i].value > 100)
                {
                    reply_json = NULL;
                    err_code = BP_ERR_VALUE_OUT_OF_RANGE;
                    snprintf(err_msg, sizeof(err_msg), "value out of range");
                    goto EXIT;
                }

            }
        }
    }
    else
    {
        request_data->seg_hsv_num = 0;
    }

    
    ret = request_data_handle_for_set_status(request_data, &err_code, err_msg, &extra);
    if (ret != APP_OK)
    {
        reply_json = NULL;
        goto EXIT;
    }

    if (ret == APP_OK)
    {
        bp_set_status_reply_t *reply_data = (bp_set_status_reply_t *) vesync_malloc(sizeof(bp_set_status_reply_t));
        if (reply_data == NULL)
        {
            err_code = BP_ERR_OUT_OF_MEMORY;
            snprintf(err_msg, sizeof(err_msg), "out of memory");
            VCOM_SAFE_FREE(reply_data);
            goto EXIT;
        }

        memset(reply_data, BP_NO_VALUE, sizeof(bp_set_status_reply_t));

        ret = reply_data_get_for_set_status(reply_data, &err_code, err_msg, extra);
        if (ret != APP_OK)
        {
            VCOM_SAFE_FREE(reply_data);
            goto EXIT;
        }

        reply_json = cJSON_CreateObject();
        if (NULL == reply_json)
        {
            err_code = BP_ERR_OUT_OF_MEMORY;
            snprintf(err_msg, sizeof(err_msg), "out of memory");
            VCOM_SAFE_FREE(reply_data);
            goto EXIT;
        }
        
        if (reply_data->power_switch != BP_NO_VALUE)
        {
            cJSON_AddNumberToObject(reply_json, "powerSwitch", (int)(reply_data->power_switch));
        }

        if (reply_data->work_mode != BP_NO_VALUE)
        {
            cJSON_AddNumberToObject(reply_json, "workMode", (int)(reply_data->work_mode));
        }

        if (reply_data->color_temp != BP_NO_VALUE)
        {
            cJSON_AddNumberToObject(reply_json, "colorTemp", (int)(reply_data->color_temp));
        }

        if (reply_data->brightness != BP_NO_VALUE)
        {
            cJSON_AddNumberToObject(reply_json, "brightness", (int)(reply_data->brightness));
        }

        if (reply_data->hue != BP_NO_VALUE)
        {
            cJSON_AddNumberToObject(reply_json, "hue", (int)(reply_data->hue));
        }

        if (reply_data->saturation != BP_NO_VALUE)
        {
            cJSON_AddNumberToObject(reply_json, "saturation", (int)(reply_data->saturation));
        }

        if (reply_data->value != BP_NO_VALUE)
        {
            cJSON_AddNumberToObject(reply_json, "value", (int)(reply_data->value));
        }

        if (reply_data->scene_id != BP_NO_VALUE)
        {
            cJSON_AddNumberToObject(reply_json, "sceneId", (int)(reply_data->scene_id));
        }

        if (reply_data->seg_num != BP_NO_VALUE)
        {
            cJSON_AddNumberToObject(reply_json, "segNum", (int)(reply_data->seg_num));
        }

        
        cJSON *json_seg_hsv = cJSON_AddArrayToObject(reply_json, "segHsv");
        if (json_seg_hsv != NULL)
        {
            for (int i = 0; i < reply_data->seg_hsv_num; i++)
            {
                int *item = (int *)(&reply_data->seg_hsv[i]);
                cJSON *json_item0 = cJSON_CreateIntArray(item, 3);
                cJSON_AddItemToArray(json_seg_hsv, json_item0);
            }
        }

        VCOM_SAFE_FREE(reply_data);
    }
EXIT:
    VCOM_SAFE_FREE(request_data);
    p_msg_ctx->resp_error_code = err_code;
    p_msg_ctx->p_resp_error_msg = err_msg;
    p_msg_ctx->p_response = reply_json;

    return BP_OK;
}

static BYPASS_ERR_E bypass_get_status_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    int err_code = BP_ERR_NO_ERR;
    int ret = APP_OK;
    cJSON *reply_json = NULL;
    char err_msg[BP_ERR_MSG_LEN] = {0};
    void *extra = NULL;

    memset(err_msg, 0, sizeof(err_msg));

    if (ret == APP_OK)
    {
        bp_get_status_reply_t *reply_data = (bp_get_status_reply_t *) vesync_malloc(sizeof(bp_get_status_reply_t));
        if (reply_data == NULL)
        {
            err_code = BP_ERR_OUT_OF_MEMORY;
            snprintf(err_msg, sizeof(err_msg), "out of memory");
            VCOM_SAFE_FREE(reply_data);
            goto EXIT;
        }

        memset(reply_data, BP_NO_VALUE, sizeof(bp_get_status_reply_t));

        ret = reply_data_get_for_get_status(reply_data, &err_code, err_msg, extra);
        if (ret != APP_OK)
        {
            VCOM_SAFE_FREE(reply_data);
            goto EXIT;
        }

        reply_json = cJSON_CreateObject();
        if (NULL == reply_json)
        {
            err_code = BP_ERR_OUT_OF_MEMORY;
            snprintf(err_msg, sizeof(err_msg), "out of memory");
            VCOM_SAFE_FREE(reply_data);
            goto EXIT;
        }
        
        if (reply_data->power_switch != BP_NO_VALUE)
        {
            cJSON_AddNumberToObject(reply_json, "powerSwitch", (int)(reply_data->power_switch));
        }

        if (reply_data->work_mode != BP_NO_VALUE)
        {
            cJSON_AddNumberToObject(reply_json, "workMode", (int)(reply_data->work_mode));
        }

        if (reply_data->color_temp != BP_NO_VALUE)
        {
            cJSON_AddNumberToObject(reply_json, "colorTemp", (int)(reply_data->color_temp));
        }

        if (reply_data->brightness != BP_NO_VALUE)
        {
            cJSON_AddNumberToObject(reply_json, "brightness", (int)(reply_data->brightness));
        }

        if (reply_data->hue != BP_NO_VALUE)
        {
            cJSON_AddNumberToObject(reply_json, "hue", (int)(reply_data->hue));
        }

        if (reply_data->saturation != BP_NO_VALUE)
        {
            cJSON_AddNumberToObject(reply_json, "saturation", (int)(reply_data->saturation));
        }

        if (reply_data->value != BP_NO_VALUE)
        {
            cJSON_AddNumberToObject(reply_json, "value", (int)(reply_data->value));
        }

        if (reply_data->scene_id != BP_NO_VALUE)
        {
            cJSON_AddNumberToObject(reply_json, "sceneId", (int)(reply_data->scene_id));
        }

        if (reply_data->seg_num != BP_NO_VALUE)
        {
            cJSON_AddNumberToObject(reply_json, "segNum", (int)(reply_data->seg_num));
        }

        
        cJSON *json_seg_hsv = cJSON_AddArrayToObject(reply_json, "segHsv");
        if (json_seg_hsv != NULL)
        {
            for (int i = 0; i < reply_data->seg_hsv_num; i++)
            {
                int *item = (int *)(&reply_data->seg_hsv[i]);
                cJSON *json_item0 = cJSON_CreateIntArray(item, 3);
                cJSON_AddItemToArray(json_seg_hsv, json_item0);
            }
        }

        VCOM_SAFE_FREE(reply_data);
    }
EXIT:
    p_msg_ctx->resp_error_code = err_code;
    p_msg_ctx->p_resp_error_msg = err_msg;
    p_msg_ctx->p_response = reply_json;

    return BP_OK;
}

static BYPASS_ERR_E bypass_adjust_percent_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    int err_code = BP_ERR_NO_ERR;
    int ret = APP_OK;
    cJSON *reply_json = NULL;
    char err_msg[BP_ERR_MSG_LEN] = {0};
    void *extra = NULL;

    memset(err_msg, 0, sizeof(err_msg));
    cJSON *json_data = NULL;
    bp_adjust_percent_request_t *request_data = (bp_adjust_percent_request_t *) vesync_malloc(sizeof(bp_adjust_percent_request_t));
    if (request_data == NULL)
    {
        err_code = BP_ERR_OUT_OF_MEMORY;
        snprintf(err_msg, sizeof(err_msg), "out of memory");
        goto EXIT;
    }

    memset(request_data, BP_NO_VALUE, sizeof(bp_adjust_percent_request_t));
    
    json_data = cJSON_GetObjectItemCaseSensitive(json, "adjustRule");
    if (cJSON_IsNumber(json_data))
    {
        request_data->adjust_rule = (int)(json_data->valueint);
        
    }
    
    json_data = cJSON_GetObjectItemCaseSensitive(json, "adjustType");
    if (cJSON_IsNumber(json_data))
    {
        request_data->adjust_type = (int)(json_data->valueint);
        
    }
    
    json_data = cJSON_GetObjectItemCaseSensitive(json, "step");
    if (cJSON_IsNumber(json_data))
    {
        request_data->step = (int)(json_data->valueint);
        
        if (request_data->step < -100 || request_data->step > 100)
        {
            reply_json = NULL;
            err_code = BP_ERR_VALUE_OUT_OF_RANGE;
            snprintf(err_msg, sizeof(err_msg), "step out of range");
            goto EXIT;
        }
    }
    
    ret = request_data_handle_for_adjust_percent(request_data, &err_code, err_msg, &extra);
    if (ret != APP_OK)
    {
        reply_json = NULL;
        goto EXIT;
    }

    if (ret == APP_OK)
    {
        bp_adjust_percent_reply_t *reply_data = (bp_adjust_percent_reply_t *) vesync_malloc(sizeof(bp_adjust_percent_reply_t));
        if (reply_data == NULL)
        {
            err_code = BP_ERR_OUT_OF_MEMORY;
            snprintf(err_msg, sizeof(err_msg), "out of memory");
            VCOM_SAFE_FREE(reply_data);
            goto EXIT;
        }

        memset(reply_data, BP_NO_VALUE, sizeof(bp_adjust_percent_reply_t));

        ret = reply_data_get_for_adjust_percent(reply_data, &err_code, err_msg, extra);
        if (ret != APP_OK)
        {
            VCOM_SAFE_FREE(reply_data);
            goto EXIT;
        }

        reply_json = cJSON_CreateObject();
        if (NULL == reply_json)
        {
            err_code = BP_ERR_OUT_OF_MEMORY;
            snprintf(err_msg, sizeof(err_msg), "out of memory");
            VCOM_SAFE_FREE(reply_data);
            goto EXIT;
        }
        
        if (reply_data->percent != BP_NO_VALUE)
        {
            cJSON_AddNumberToObject(reply_json, "percent", (int)(reply_data->percent));
        }

        VCOM_SAFE_FREE(reply_data);
    }
EXIT:
    VCOM_SAFE_FREE(request_data);
    p_msg_ctx->resp_error_code = err_code;
    p_msg_ctx->p_resp_error_msg = err_msg;
    p_msg_ctx->p_response = reply_json;

    return BP_OK;
}

static BYPASS_ERR_E bypass_set_bead_size_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    int err_code = BP_ERR_NO_ERR;
    int ret = APP_OK;
    cJSON *reply_json = NULL;
    char err_msg[BP_ERR_MSG_LEN] = {0};
    void *extra = NULL;

    memset(err_msg, 0, sizeof(err_msg));
    cJSON *json_data = NULL;
    bp_set_bead_size_request_t *request_data = (bp_set_bead_size_request_t *) vesync_malloc(sizeof(bp_set_bead_size_request_t));
    if (request_data == NULL)
    {
        err_code = BP_ERR_OUT_OF_MEMORY;
        snprintf(err_msg, sizeof(err_msg), "out of memory");
        goto EXIT;
    }

    memset(request_data, BP_NO_VALUE, sizeof(bp_set_bead_size_request_t));
    
    json_data = cJSON_GetObjectItemCaseSensitive(json, "beadSize");
    if (cJSON_IsNumber(json_data))
    {
        request_data->bead_size = (int)(json_data->valueint);
        
        if (request_data->bead_size < 1 || request_data->bead_size > 300)
        {
            reply_json = NULL;
            err_code = BP_ERR_VALUE_OUT_OF_RANGE;
            snprintf(err_msg, sizeof(err_msg), "bead_size out of range");
            goto EXIT;
        }
    }
    
    ret = request_data_handle_for_set_bead_size(request_data, &err_code, err_msg, &extra);
    if (ret != APP_OK)
    {
        reply_json = NULL;
        goto EXIT;
    }

EXIT:
    VCOM_SAFE_FREE(request_data);
    p_msg_ctx->resp_error_code = err_code;
    p_msg_ctx->p_resp_error_msg = err_msg;
    p_msg_ctx->p_response = reply_json;

    return BP_OK;
}

static BYPASS_ERR_E bypass_get_bead_size_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    int err_code = BP_ERR_NO_ERR;
    int ret = APP_OK;
    cJSON *reply_json = NULL;
    char err_msg[BP_ERR_MSG_LEN] = {0};
    void *extra = NULL;

    memset(err_msg, 0, sizeof(err_msg));

    if (ret == APP_OK)
    {
        bp_get_bead_size_reply_t *reply_data = (bp_get_bead_size_reply_t *) vesync_malloc(sizeof(bp_get_bead_size_reply_t));
        if (reply_data == NULL)
        {
            err_code = BP_ERR_OUT_OF_MEMORY;
            snprintf(err_msg, sizeof(err_msg), "out of memory");
            VCOM_SAFE_FREE(reply_data);
            goto EXIT;
        }

        memset(reply_data, BP_NO_VALUE, sizeof(bp_get_bead_size_reply_t));

        ret = reply_data_get_for_get_bead_size(reply_data, &err_code, err_msg, extra);
        if (ret != APP_OK)
        {
            VCOM_SAFE_FREE(reply_data);
            goto EXIT;
        }

        reply_json = cJSON_CreateObject();
        if (NULL == reply_json)
        {
            err_code = BP_ERR_OUT_OF_MEMORY;
            snprintf(err_msg, sizeof(err_msg), "out of memory");
            VCOM_SAFE_FREE(reply_data);
            goto EXIT;
        }
        
        if (reply_data->bead_size != BP_NO_VALUE)
        {
            cJSON_AddNumberToObject(reply_json, "beadSize", (int)(reply_data->bead_size));
        }

        VCOM_SAFE_FREE(reply_data);
    }
EXIT:
    p_msg_ctx->resp_error_code = err_code;
    p_msg_ctx->p_resp_error_msg = err_msg;
    p_msg_ctx->p_response = reply_json;

    return BP_OK;
}

static BYPASS_ERR_E bypass_reset_aging_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    int err_code = BP_ERR_NO_ERR;
    int ret = APP_OK;
    cJSON *reply_json = NULL;
    char err_msg[BP_ERR_MSG_LEN] = {0};

    memset(err_msg, 0, sizeof(err_msg));

    ret = handle_for_reset_aging(&err_code, err_msg);
    if (ret != APP_OK)
    {
        reply_json = NULL;
    }

    p_msg_ctx->resp_error_code = err_code;
    p_msg_ctx->p_resp_error_msg = err_msg;
    p_msg_ctx->p_response = reply_json;

    return BP_OK;
}

static BYPASS_ERR_E bypass_add_scene_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    int err_code = BP_ERR_NO_ERR;
    int ret = APP_OK;
    cJSON *reply_json = NULL;
    char err_msg[BP_ERR_MSG_LEN] = {0};
    void *extra = NULL;

    memset(err_msg, 0, sizeof(err_msg));

    if (ret == APP_OK)
    {
        bp_add_scene_reply_t *reply_data = (bp_add_scene_reply_t *) vesync_malloc(sizeof(bp_add_scene_reply_t));
        if (reply_data == NULL)
        {
            err_code = BP_ERR_OUT_OF_MEMORY;
            snprintf(err_msg, sizeof(err_msg), "out of memory");
            VCOM_SAFE_FREE(reply_data);
            goto EXIT;
        }

        memset(reply_data, BP_NO_VALUE, sizeof(bp_add_scene_reply_t));

        ret = reply_data_get_for_add_scene(reply_data, &err_code, err_msg, extra);
        if (ret != APP_OK)
        {
            VCOM_SAFE_FREE(reply_data);
            goto EXIT;
        }

        reply_json = cJSON_CreateObject();
        if (NULL == reply_json)
        {
            err_code = BP_ERR_OUT_OF_MEMORY;
            snprintf(err_msg, sizeof(err_msg), "out of memory");
            VCOM_SAFE_FREE(reply_data);
            goto EXIT;
        }
        
        if (reply_data->scene_id != BP_NO_VALUE)
        {
            cJSON_AddNumberToObject(reply_json, "sceneId", (int)(reply_data->scene_id));
        }

        VCOM_SAFE_FREE(reply_data);
    }
EXIT:
    p_msg_ctx->resp_error_code = err_code;
    p_msg_ctx->p_resp_error_msg = err_msg;
    p_msg_ctx->p_response = reply_json;

    return BP_OK;
}

static BYPASS_ERR_E bypass_get_scenes_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    int err_code = BP_ERR_NO_ERR;
    int ret = APP_OK;
    cJSON *reply_json = NULL;
    char err_msg[BP_ERR_MSG_LEN] = {0};
    void *extra = NULL;

    memset(err_msg, 0, sizeof(err_msg));
    cJSON *json_data = NULL;
    bp_get_scenes_request_t *request_data = (bp_get_scenes_request_t *) vesync_malloc(sizeof(bp_get_scenes_request_t));
    if (request_data == NULL)
    {
        err_code = BP_ERR_OUT_OF_MEMORY;
        snprintf(err_msg, sizeof(err_msg), "out of memory");
        goto EXIT;
    }

    memset(request_data, BP_NO_VALUE, sizeof(bp_get_scenes_request_t));
    
    json_data = cJSON_GetObjectItemCaseSensitive(json, "idx");
    if (cJSON_IsNumber(json_data))
    {
        request_data->idx = (int)(json_data->valueint);
        
        if (request_data->idx < 0 || request_data->idx > 256)
        {
            reply_json = NULL;
            err_code = BP_ERR_VALUE_OUT_OF_RANGE;
            snprintf(err_msg, sizeof(err_msg), "idx out of range");
            goto EXIT;
        }
    }
    
    ret = request_data_handle_for_get_scenes(request_data, &err_code, err_msg, &extra);
    if (ret != APP_OK)
    {
        reply_json = NULL;
        goto EXIT;
    }

    if (ret == APP_OK)
    {
        bp_get_scenes_reply_t *reply_data = (bp_get_scenes_reply_t *) vesync_malloc(sizeof(bp_get_scenes_reply_t));
        if (reply_data == NULL)
        {
            err_code = BP_ERR_OUT_OF_MEMORY;
            snprintf(err_msg, sizeof(err_msg), "out of memory");
            VCOM_SAFE_FREE(reply_data);
            goto EXIT;
        }

        memset(reply_data, BP_NO_VALUE, sizeof(bp_get_scenes_reply_t));

        ret = reply_data_get_for_get_scenes(reply_data, &err_code, err_msg, extra);
        if (ret != APP_OK)
        {
            VCOM_SAFE_FREE(reply_data);
            goto EXIT;
        }

        reply_json = cJSON_CreateObject();
        if (NULL == reply_json)
        {
            err_code = BP_ERR_OUT_OF_MEMORY;
            snprintf(err_msg, sizeof(err_msg), "out of memory");
            VCOM_SAFE_FREE(reply_data);
            goto EXIT;
        }
        
        if (reply_data->total_num != BP_NO_VALUE)
        {
            cJSON_AddNumberToObject(reply_json, "totalNum", (int)(reply_data->total_num));
        }

        
        cJSON *json_scene_ids = cJSON_AddArrayToObject(reply_json, "sceneIds");
        if (json_scene_ids != NULL)
        {
            for (int i = 0; i < reply_data->scene_ids_num; i++)
            {
                int *item = (int *)(&reply_data->scene_ids[i]);
                cJSON *json_item0 = cJSON_CreateIntArray(item, 1);
                cJSON_AddItemToArray(json_scene_ids, json_item0);
            }
        }

        VCOM_SAFE_FREE(reply_data);
    }
EXIT:
    VCOM_SAFE_FREE(request_data);
    p_msg_ctx->resp_error_code = err_code;
    p_msg_ctx->p_resp_error_msg = err_msg;
    p_msg_ctx->p_response = reply_json;

    return BP_OK;
}

static BYPASS_ERR_E bypass_del_scene_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    int err_code = BP_ERR_NO_ERR;
    int ret = APP_OK;
    cJSON *reply_json = NULL;
    char err_msg[BP_ERR_MSG_LEN] = {0};
    void *extra = NULL;

    memset(err_msg, 0, sizeof(err_msg));
    cJSON *json_data = NULL;
    bp_del_scene_request_t *request_data = (bp_del_scene_request_t *) vesync_malloc(sizeof(bp_del_scene_request_t));
    if (request_data == NULL)
    {
        err_code = BP_ERR_OUT_OF_MEMORY;
        snprintf(err_msg, sizeof(err_msg), "out of memory");
        goto EXIT;
    }

    memset(request_data, BP_NO_VALUE, sizeof(bp_del_scene_request_t));
    
    json_data = cJSON_GetObjectItemCaseSensitive(json, "sceneId");
    if (cJSON_IsNumber(json_data))
    {
        request_data->scene_id = (int)(json_data->valueint);
        
        if (request_data->scene_id < 1 || request_data->scene_id > 65535)
        {
            reply_json = NULL;
            err_code = BP_ERR_VALUE_OUT_OF_RANGE;
            snprintf(err_msg, sizeof(err_msg), "scene_id out of range");
            goto EXIT;
        }
    }
    
    ret = request_data_handle_for_del_scene(request_data, &err_code, err_msg, &extra);
    if (ret != APP_OK)
    {
        reply_json = NULL;
        goto EXIT;
    }

EXIT:
    VCOM_SAFE_FREE(request_data);
    p_msg_ctx->resp_error_code = err_code;
    p_msg_ctx->p_resp_error_msg = err_msg;
    p_msg_ctx->p_response = reply_json;

    return BP_OK;
}

static BYPASS_ERR_E bypass_add_timer_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    int err_code = BP_ERR_NO_ERR;
    int ret = APP_OK;
    cJSON *reply_json = NULL;
    char err_msg[BP_ERR_MSG_LEN] = {0};
    void *extra = NULL;

    memset(err_msg, 0, sizeof(err_msg));
    cJSON *json_data = NULL;
    bp_add_timer_request_t *request_data = (bp_add_timer_request_t *) vesync_malloc(sizeof(bp_add_timer_request_t));
    if (request_data == NULL)
    {
        err_code = BP_ERR_OUT_OF_MEMORY;
        snprintf(err_msg, sizeof(err_msg), "out of memory");
        goto EXIT;
    }

    memset(request_data, BP_NO_VALUE, sizeof(bp_add_timer_request_t));
    
    json_data = cJSON_GetObjectItemCaseSensitive(json, "totalTime");
    if (cJSON_IsNumber(json_data))
    {
        request_data->total_time = (int)(json_data->valueint);
        
        if (request_data->total_time < 0 || request_data->total_time > 86400)
        {
            reply_json = NULL;
            err_code = BP_ERR_VALUE_OUT_OF_RANGE;
            snprintf(err_msg, sizeof(err_msg), "total_time out of range");
            goto EXIT;
        }
    }
    
    
    json_data = cJSON_GetObjectItemCaseSensitive(json, "startAct");
    if (cJSON_IsArray(json_data))
    {
        cJSON *json_arr = NULL;
        int arr_size = cJSON_GetArraySize(json_data);
        request_data->start_act_num = arr_size;
        for (int i = 0; i < arr_size; i++)
        {
            json_arr = cJSON_GetArrayItem(json_data, i);
            if (json_arr != NULL)
            {
                cJSON *json_item = NULL;
                
                json_item = cJSON_GetObjectItemCaseSensitive(json_arr, "num");
                if (cJSON_IsNumber(json_item))
                {
                    request_data->start_act[i].num = (int)(json_item->valueint);
                    
                    if (request_data->start_act[i].num < 0 || request_data->start_act[i].num > 255)
                    {
                        reply_json = NULL;
                        err_code = BP_ERR_VALUE_OUT_OF_RANGE;
                        snprintf(err_msg, sizeof(err_msg), "num out of range");
                        goto EXIT;
                    }
                }

                json_item = cJSON_GetObjectItemCaseSensitive(json_arr, "actType");
                if (cJSON_IsNumber(json_item))
                {
                    request_data->start_act[i].act_type = (int)(json_item->valueint);
                    
                }

                json_item = cJSON_GetObjectItemCaseSensitive(json_arr, "act");
                if (cJSON_IsNumber(json_item))
                {
                    request_data->start_act[i].act = (int)(json_item->valueint);
                    
                }

                json_item = cJSON_GetObjectItemCaseSensitive(json_arr, "params");
                if (cJSON_IsObject(json_item))
                {
                    cJSON *json_item0 = NULL;
        
                    json_item0 = cJSON_GetObjectItemCaseSensitive(json_item, "brightness");
                    if (cJSON_IsNumber(json_item0))
                    {
                        request_data->start_act[i].params.brightness = (int)(json_item0->valueint);
                        
                        if (request_data->start_act[i].params.brightness < 0 || request_data->start_act[i].params.brightness > 100)
                        {
                            reply_json = NULL;
                            err_code = BP_ERR_VALUE_OUT_OF_RANGE;
                            snprintf(err_msg, sizeof(err_msg), "brightness out of range");
                            goto EXIT;
                        }
                    }

                    json_item0 = cJSON_GetObjectItemCaseSensitive(json_item, "hue");
                    if (cJSON_IsNumber(json_item0))
                    {
                        request_data->start_act[i].params.hue = (int)(json_item0->valueint);
                        
                        if (request_data->start_act[i].params.hue < 0 || request_data->start_act[i].params.hue > 10000)
                        {
                            reply_json = NULL;
                            err_code = BP_ERR_VALUE_OUT_OF_RANGE;
                            snprintf(err_msg, sizeof(err_msg), "hue out of range");
                            goto EXIT;
                        }
                    }

                    json_item0 = cJSON_GetObjectItemCaseSensitive(json_item, "saturation");
                    if (cJSON_IsNumber(json_item0))
                    {
                        request_data->start_act[i].params.saturation = (int)(json_item0->valueint);
                        
                        if (request_data->start_act[i].params.saturation < 0 || request_data->start_act[i].params.saturation > 10000)
                        {
                            reply_json = NULL;
                            err_code = BP_ERR_VALUE_OUT_OF_RANGE;
                            snprintf(err_msg, sizeof(err_msg), "saturation out of range");
                            goto EXIT;
                        }
                    }

                    json_item0 = cJSON_GetObjectItemCaseSensitive(json_item, "value");
                    if (cJSON_IsNumber(json_item0))
                    {
                        request_data->start_act[i].params.value = (int)(json_item0->valueint);
                        
                        if (request_data->start_act[i].params.value < 0 || request_data->start_act[i].params.value > 100)
                        {
                            reply_json = NULL;
                            err_code = BP_ERR_VALUE_OUT_OF_RANGE;
                            snprintf(err_msg, sizeof(err_msg), "value out of range");
                            goto EXIT;
                        }
                    }

                    json_item0 = cJSON_GetObjectItemCaseSensitive(json_item, "colorTemp");
                    if (cJSON_IsNumber(json_item0))
                    {
                        request_data->start_act[i].params.color_temp = (int)(json_item0->valueint);
                        
                        if (request_data->start_act[i].params.color_temp < 0 || request_data->start_act[i].params.color_temp > 100)
                        {
                            reply_json = NULL;
                            err_code = BP_ERR_VALUE_OUT_OF_RANGE;
                            snprintf(err_msg, sizeof(err_msg), "color_temp out of range");
                            goto EXIT;
                        }
                    }

                    json_item0 = cJSON_GetObjectItemCaseSensitive(json_item, "sceneId");
                    if (cJSON_IsNumber(json_item0))
                    {
                        request_data->start_act[i].params.scene_id = (int)(json_item0->valueint);
                        
                        if (request_data->start_act[i].params.scene_id < 1 || request_data->start_act[i].params.scene_id > 65535)
                        {
                            reply_json = NULL;
                            err_code = BP_ERR_VALUE_OUT_OF_RANGE;
                            snprintf(err_msg, sizeof(err_msg), "scene_id out of range");
                            goto EXIT;
                        }
                    }

                    json_item0 = cJSON_GetObjectItemCaseSensitive(json_item, "musicId");
                    if (cJSON_IsNumber(json_item0))
                    {
                        request_data->start_act[i].params.music_id = (int)(json_item0->valueint);
                        
                        if (request_data->start_act[i].params.music_id < 1 || request_data->start_act[i].params.music_id > 65535)
                        {
                            reply_json = NULL;
                            err_code = BP_ERR_VALUE_OUT_OF_RANGE;
                            snprintf(err_msg, sizeof(err_msg), "music_id out of range");
                            goto EXIT;
                        }
                    }


                }


            }
        }
    }
    else
    {
        request_data->start_act_num = 0;
    }

    
    ret = request_data_handle_for_add_timer(request_data, &err_code, err_msg, &extra);
    if (ret != APP_OK)
    {
        reply_json = NULL;
        goto EXIT;
    }

EXIT:
    VCOM_SAFE_FREE(request_data);
    p_msg_ctx->resp_error_code = err_code;
    p_msg_ctx->p_resp_error_msg = err_msg;
    p_msg_ctx->p_response = reply_json;

    return BP_OK;
}

static BYPASS_ERR_E bypass_get_timer_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    int err_code = BP_ERR_NO_ERR;
    int ret = APP_OK;
    cJSON *reply_json = NULL;
    char err_msg[BP_ERR_MSG_LEN] = {0};
    void *extra = NULL;

    memset(err_msg, 0, sizeof(err_msg));

    if (ret == APP_OK)
    {
        bp_get_timer_reply_t *reply_data = (bp_get_timer_reply_t *) vesync_malloc(sizeof(bp_get_timer_reply_t));
        if (reply_data == NULL)
        {
            err_code = BP_ERR_OUT_OF_MEMORY;
            snprintf(err_msg, sizeof(err_msg), "out of memory");
            VCOM_SAFE_FREE(reply_data);
            goto EXIT;
        }

        memset(reply_data, BP_NO_VALUE, sizeof(bp_get_timer_reply_t));

        ret = reply_data_get_for_get_timer(reply_data, &err_code, err_msg, extra);
        if (ret != APP_OK)
        {
            VCOM_SAFE_FREE(reply_data);
            goto EXIT;
        }

        reply_json = cJSON_CreateObject();
        if (NULL == reply_json)
        {
            err_code = BP_ERR_OUT_OF_MEMORY;
            snprintf(err_msg, sizeof(err_msg), "out of memory");
            VCOM_SAFE_FREE(reply_data);
            goto EXIT;
        }
        
        
        cJSON *json_timers = cJSON_AddArrayToObject(reply_json, "timers");
        if (json_timers != NULL)
        {
            for (int i = 0; i < reply_data->timers_num; i++)
            {
                cJSON *json_item0 = cJSON_CreateObject();
                if (json_item0 != NULL)
                {
                    if (reply_data->timers[i].uid != BP_NO_VALUE)
                    {
                        cJSON_AddNumberToObject(json_item0, "uid", (int)(reply_data->timers[i].uid));
                    }

                    if (reply_data->timers[i].total_time != BP_NO_VALUE)
                    {
                        cJSON_AddNumberToObject(json_item0, "totalTime", (int)(reply_data->timers[i].total_time));
                    }

                    if (reply_data->timers[i].remain_time != BP_NO_VALUE)
                    {
                        cJSON_AddNumberToObject(json_item0, "remainTime", (int)(reply_data->timers[i].remain_time));
                    }

                    
                    cJSON *json_start_act = cJSON_AddArrayToObject(json_item0, "startAct");
                    if (json_start_act != NULL)
                    {
                        for (int j = 0; j < reply_data->timers[i].start_act_num; j++)
                        {
                            cJSON *json_item1 = cJSON_CreateObject();
                            if (json_item1 != NULL)
                            {
                                if (reply_data->timers[i].start_act[j].num != BP_NO_VALUE)
                                {
                                    cJSON_AddNumberToObject(json_item1, "num", (int)(reply_data->timers[i].start_act[j].num));
                                }

                                if (reply_data->timers[i].start_act[j].act_type != BP_NO_VALUE)
                                {
                                    cJSON_AddNumberToObject(json_item1, "actType", (int)(reply_data->timers[i].start_act[j].act_type));
                                }

                                if (reply_data->timers[i].start_act[j].act != BP_NO_VALUE)
                                {
                                    cJSON_AddNumberToObject(json_item1, "act", (int)(reply_data->timers[i].start_act[j].act));
                                }

                                cJSON *json_params = cJSON_AddObjectToObject(json_item1, "params");
                                if (json_params != NULL)
                                {
                                    if (reply_data->timers[i].start_act[j].params.brightness != BP_NO_VALUE)
                                    {
                                        cJSON_AddNumberToObject(json_params, "brightness", (int)(reply_data->timers[i].start_act[j].params.brightness));
                                    }

                                    if (reply_data->timers[i].start_act[j].params.hue != BP_NO_VALUE)
                                    {
                                        cJSON_AddNumberToObject(json_params, "hue", (int)(reply_data->timers[i].start_act[j].params.hue));
                                    }

                                    if (reply_data->timers[i].start_act[j].params.saturation != BP_NO_VALUE)
                                    {
                                        cJSON_AddNumberToObject(json_params, "saturation", (int)(reply_data->timers[i].start_act[j].params.saturation));
                                    }

                                    if (reply_data->timers[i].start_act[j].params.value != BP_NO_VALUE)
                                    {
                                        cJSON_AddNumberToObject(json_params, "value", (int)(reply_data->timers[i].start_act[j].params.value));
                                    }

                                    if (reply_data->timers[i].start_act[j].params.color_temp != BP_NO_VALUE)
                                    {
                                        cJSON_AddNumberToObject(json_params, "colorTemp", (int)(reply_data->timers[i].start_act[j].params.color_temp));
                                    }

                                    if (reply_data->timers[i].start_act[j].params.scene_id != BP_NO_VALUE)
                                    {
                                        cJSON_AddNumberToObject(json_params, "sceneId", (int)(reply_data->timers[i].start_act[j].params.scene_id));
                                    }

                                    if (reply_data->timers[i].start_act[j].params.music_id != BP_NO_VALUE)
                                    {
                                        cJSON_AddNumberToObject(json_params, "musicId", (int)(reply_data->timers[i].start_act[j].params.music_id));
                                    }

                                }

                            }
                            cJSON_AddItemToArray(json_start_act, json_item1);
                        }
                    }

                }
                cJSON_AddItemToArray(json_timers, json_item0);
            }
        }

        VCOM_SAFE_FREE(reply_data);
    }
EXIT:
    p_msg_ctx->resp_error_code = err_code;
    p_msg_ctx->p_resp_error_msg = err_msg;
    p_msg_ctx->p_response = reply_json;

    return BP_OK;
}

static BYPASS_ERR_E bypass_del_timer_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    int err_code = BP_ERR_NO_ERR;
    int ret = APP_OK;
    cJSON *reply_json = NULL;
    char err_msg[BP_ERR_MSG_LEN] = {0};
    void *extra = NULL;

    memset(err_msg, 0, sizeof(err_msg));
    cJSON *json_data = NULL;
    bp_del_timer_request_t *request_data = (bp_del_timer_request_t *) vesync_malloc(sizeof(bp_del_timer_request_t));
    if (request_data == NULL)
    {
        err_code = BP_ERR_OUT_OF_MEMORY;
        snprintf(err_msg, sizeof(err_msg), "out of memory");
        goto EXIT;
    }

    memset(request_data, BP_NO_VALUE, sizeof(bp_del_timer_request_t));
    
    json_data = cJSON_GetObjectItemCaseSensitive(json, "uid");
    if (cJSON_IsNumber(json_data))
    {
        request_data->uid = (int)(json_data->valueint);
        
        if (request_data->uid < 0 || request_data->uid > 256)
        {
            reply_json = NULL;
            err_code = BP_ERR_VALUE_OUT_OF_RANGE;
            snprintf(err_msg, sizeof(err_msg), "uid out of range");
            goto EXIT;
        }
    }
    
    ret = request_data_handle_for_del_timer(request_data, &err_code, err_msg, &extra);
    if (ret != APP_OK)
    {
        reply_json = NULL;
        goto EXIT;
    }

EXIT:
    VCOM_SAFE_FREE(request_data);
    p_msg_ctx->resp_error_code = err_code;
    p_msg_ctx->p_resp_error_msg = err_msg;
    p_msg_ctx->p_response = reply_json;

    return BP_OK;
}

static BYPASS_ERR_E bypass_add_schedule_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    int err_code = BP_ERR_NO_ERR;
    int ret = APP_OK;
    cJSON *reply_json = NULL;
    char err_msg[BP_ERR_MSG_LEN] = {0};
    void *extra = NULL;

    memset(err_msg, 0, sizeof(err_msg));
    cJSON *json_data = NULL;
    bp_add_schedule_request_t *request_data = (bp_add_schedule_request_t *) vesync_malloc(sizeof(bp_add_schedule_request_t));
    if (request_data == NULL)
    {
        err_code = BP_ERR_OUT_OF_MEMORY;
        snprintf(err_msg, sizeof(err_msg), "out of memory");
        goto EXIT;
    }

    memset(request_data, BP_NO_VALUE, sizeof(bp_add_schedule_request_t));
    
    
    json_data = cJSON_GetObjectItemCaseSensitive(json, "enabled");
    if (cJSON_IsNumber(json_data))
    {
        request_data->enabled = (int)(json_data->valueint);
        
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "repeat");
    if (cJSON_IsNumber(json_data))
    {
        request_data->repeat = (int)(json_data->valueint);
        
        if (request_data->repeat < 0 || request_data->repeat > 255)
        {
            reply_json = NULL;
            err_code = BP_ERR_VALUE_OUT_OF_RANGE;
            snprintf(err_msg, sizeof(err_msg), "repeat out of range");
            goto EXIT;
        }
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "schType");
    if (cJSON_IsNumber(json_data))
    {
        request_data->sch_type = (int)(json_data->valueint);
        
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "sunEvt");
    if (cJSON_IsObject(json_data))
    {
        cJSON *json_item0 = NULL;
        
        json_item0 = cJSON_GetObjectItemCaseSensitive(json_data, "isRise");
        if (cJSON_IsNumber(json_item0))
        {
            request_data->sun_evt.is_rise = (int)(json_item0->valueint);
            
        }

        json_item0 = cJSON_GetObjectItemCaseSensitive(json_data, "ofsSec");
        if (cJSON_IsNumber(json_item0))
        {
            request_data->sun_evt.ofs_sec = (int)(json_item0->valueint);
            
            if (request_data->sun_evt.ofs_sec < -3600 || request_data->sun_evt.ofs_sec > 3600)
            {
                reply_json = NULL;
                err_code = BP_ERR_VALUE_OUT_OF_RANGE;
                snprintf(err_msg, sizeof(err_msg), "ofs_sec out of range");
                goto EXIT;
            }
        }


    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "tmgEvt");
    if (cJSON_IsObject(json_data))
    {
        cJSON *json_item0 = NULL;
        
        json_item0 = cJSON_GetObjectItemCaseSensitive(json_data, "clkSec");
        if (cJSON_IsNumber(json_item0))
        {
            request_data->tmg_evt.clk_sec = (int)(json_item0->valueint);
            
            if (request_data->tmg_evt.clk_sec < 0 || request_data->tmg_evt.clk_sec > 86399)
            {
                reply_json = NULL;
                err_code = BP_ERR_VALUE_OUT_OF_RANGE;
                snprintf(err_msg, sizeof(err_msg), "clk_sec out of range");
                goto EXIT;
            }
        }


    }

    
    json_data = cJSON_GetObjectItemCaseSensitive(json, "startAct");
    if (cJSON_IsArray(json_data))
    {
        cJSON *json_arr = NULL;
        int arr_size = cJSON_GetArraySize(json_data);
        request_data->start_act_num = arr_size;
        for (int i = 0; i < arr_size; i++)
        {
            json_arr = cJSON_GetArrayItem(json_data, i);
            if (json_arr != NULL)
            {
                cJSON *json_item = NULL;
                
                json_item = cJSON_GetObjectItemCaseSensitive(json_arr, "num");
                if (cJSON_IsNumber(json_item))
                {
                    request_data->start_act[i].num = (int)(json_item->valueint);
                    
                    if (request_data->start_act[i].num < 0 || request_data->start_act[i].num > 255)
                    {
                        reply_json = NULL;
                        err_code = BP_ERR_VALUE_OUT_OF_RANGE;
                        snprintf(err_msg, sizeof(err_msg), "num out of range");
                        goto EXIT;
                    }
                }

                json_item = cJSON_GetObjectItemCaseSensitive(json_arr, "actType");
                if (cJSON_IsNumber(json_item))
                {
                    request_data->start_act[i].act_type = (int)(json_item->valueint);
                    
                }

                json_item = cJSON_GetObjectItemCaseSensitive(json_arr, "act");
                if (cJSON_IsNumber(json_item))
                {
                    request_data->start_act[i].act = (int)(json_item->valueint);
                    
                }

                json_item = cJSON_GetObjectItemCaseSensitive(json_arr, "params");
                if (cJSON_IsObject(json_item))
                {
                    cJSON *json_item0 = NULL;
        
                    json_item0 = cJSON_GetObjectItemCaseSensitive(json_item, "brightness");
                    if (cJSON_IsNumber(json_item0))
                    {
                        request_data->start_act[i].params.brightness = (int)(json_item0->valueint);
                        
                        if (request_data->start_act[i].params.brightness < 0 || request_data->start_act[i].params.brightness > 100)
                        {
                            reply_json = NULL;
                            err_code = BP_ERR_VALUE_OUT_OF_RANGE;
                            snprintf(err_msg, sizeof(err_msg), "brightness out of range");
                            goto EXIT;
                        }
                    }

                    json_item0 = cJSON_GetObjectItemCaseSensitive(json_item, "hue");
                    if (cJSON_IsNumber(json_item0))
                    {
                        request_data->start_act[i].params.hue = (int)(json_item0->valueint);
                        
                        if (request_data->start_act[i].params.hue < 0 || request_data->start_act[i].params.hue > 10000)
                        {
                            reply_json = NULL;
                            err_code = BP_ERR_VALUE_OUT_OF_RANGE;
                            snprintf(err_msg, sizeof(err_msg), "hue out of range");
                            goto EXIT;
                        }
                    }

                    json_item0 = cJSON_GetObjectItemCaseSensitive(json_item, "saturation");
                    if (cJSON_IsNumber(json_item0))
                    {
                        request_data->start_act[i].params.saturation = (int)(json_item0->valueint);
                        
                        if (request_data->start_act[i].params.saturation < 0 || request_data->start_act[i].params.saturation > 10000)
                        {
                            reply_json = NULL;
                            err_code = BP_ERR_VALUE_OUT_OF_RANGE;
                            snprintf(err_msg, sizeof(err_msg), "saturation out of range");
                            goto EXIT;
                        }
                    }

                    json_item0 = cJSON_GetObjectItemCaseSensitive(json_item, "value");
                    if (cJSON_IsNumber(json_item0))
                    {
                        request_data->start_act[i].params.value = (int)(json_item0->valueint);
                        
                        if (request_data->start_act[i].params.value < 0 || request_data->start_act[i].params.value > 100)
                        {
                            reply_json = NULL;
                            err_code = BP_ERR_VALUE_OUT_OF_RANGE;
                            snprintf(err_msg, sizeof(err_msg), "value out of range");
                            goto EXIT;
                        }
                    }

                    json_item0 = cJSON_GetObjectItemCaseSensitive(json_item, "colorTemp");
                    if (cJSON_IsNumber(json_item0))
                    {
                        request_data->start_act[i].params.color_temp = (int)(json_item0->valueint);
                        
                        if (request_data->start_act[i].params.color_temp < 0 || request_data->start_act[i].params.color_temp > 100)
                        {
                            reply_json = NULL;
                            err_code = BP_ERR_VALUE_OUT_OF_RANGE;
                            snprintf(err_msg, sizeof(err_msg), "color_temp out of range");
                            goto EXIT;
                        }
                    }

                    json_item0 = cJSON_GetObjectItemCaseSensitive(json_item, "sceneId");
                    if (cJSON_IsNumber(json_item0))
                    {
                        request_data->start_act[i].params.scene_id = (int)(json_item0->valueint);
                        
                        if (request_data->start_act[i].params.scene_id < 1 || request_data->start_act[i].params.scene_id > 65535)
                        {
                            reply_json = NULL;
                            err_code = BP_ERR_VALUE_OUT_OF_RANGE;
                            snprintf(err_msg, sizeof(err_msg), "scene_id out of range");
                            goto EXIT;
                        }
                    }

                    json_item0 = cJSON_GetObjectItemCaseSensitive(json_item, "musicId");
                    if (cJSON_IsNumber(json_item0))
                    {
                        request_data->start_act[i].params.music_id = (int)(json_item0->valueint);
                        
                        if (request_data->start_act[i].params.music_id < 1 || request_data->start_act[i].params.music_id > 65535)
                        {
                            reply_json = NULL;
                            err_code = BP_ERR_VALUE_OUT_OF_RANGE;
                            snprintf(err_msg, sizeof(err_msg), "music_id out of range");
                            goto EXIT;
                        }
                    }


                }


            }
        }
    }
    else
    {
        request_data->start_act_num = 0;
    }


    
    ret = request_data_handle_for_add_schedule(request_data, &err_code, err_msg, &extra);
    if (ret != APP_OK)
    {
        reply_json = NULL;
        goto EXIT;
    }

    if (ret == APP_OK)
    {
        bp_add_schedule_reply_t *reply_data = (bp_add_schedule_reply_t *) vesync_malloc(sizeof(bp_add_schedule_reply_t));
        if (reply_data == NULL)
        {
            err_code = BP_ERR_OUT_OF_MEMORY;
            snprintf(err_msg, sizeof(err_msg), "out of memory");
            VCOM_SAFE_FREE(reply_data);
            goto EXIT;
        }

        memset(reply_data, BP_NO_VALUE, sizeof(bp_add_schedule_reply_t));

        ret = reply_data_get_for_add_schedule(reply_data, &err_code, err_msg, extra);
        if (ret != APP_OK)
        {
            VCOM_SAFE_FREE(reply_data);
            goto EXIT;
        }

        reply_json = cJSON_CreateObject();
        if (NULL == reply_json)
        {
            err_code = BP_ERR_OUT_OF_MEMORY;
            snprintf(err_msg, sizeof(err_msg), "out of memory");
            VCOM_SAFE_FREE(reply_data);
            goto EXIT;
        }
        
        if (reply_data->uid != BP_NO_VALUE)
        {
            cJSON_AddNumberToObject(reply_json, "uid", (int)(reply_data->uid));
        }

        VCOM_SAFE_FREE(reply_data);
    }
EXIT:
    VCOM_SAFE_FREE(request_data);
    p_msg_ctx->resp_error_code = err_code;
    p_msg_ctx->p_resp_error_msg = err_msg;
    p_msg_ctx->p_response = reply_json;

    return BP_OK;
}

static BYPASS_ERR_E bypass_upd_schedule_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    int err_code = BP_ERR_NO_ERR;
    int ret = APP_OK;
    cJSON *reply_json = NULL;
    char err_msg[BP_ERR_MSG_LEN] = {0};
    void *extra = NULL;

    memset(err_msg, 0, sizeof(err_msg));
    cJSON *json_data = NULL;
    bp_upd_schedule_request_t *request_data = (bp_upd_schedule_request_t *) vesync_malloc(sizeof(bp_upd_schedule_request_t));
    if (request_data == NULL)
    {
        err_code = BP_ERR_OUT_OF_MEMORY;
        snprintf(err_msg, sizeof(err_msg), "out of memory");
        goto EXIT;
    }

    memset(request_data, BP_NO_VALUE, sizeof(bp_upd_schedule_request_t));
    
    json_data = cJSON_GetObjectItemCaseSensitive(json, "uid");
    if (cJSON_IsNumber(json_data))
    {
        request_data->uid = (int)(json_data->valueint);
        
        if (request_data->uid < 0 || request_data->uid > 256)
        {
            reply_json = NULL;
            err_code = BP_ERR_VALUE_OUT_OF_RANGE;
            snprintf(err_msg, sizeof(err_msg), "uid out of range");
            goto EXIT;
        }
    }
    
    
    json_data = cJSON_GetObjectItemCaseSensitive(json, "enabled");
    if (cJSON_IsNumber(json_data))
    {
        request_data->enabled = (int)(json_data->valueint);
        
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "repeat");
    if (cJSON_IsNumber(json_data))
    {
        request_data->repeat = (int)(json_data->valueint);
        
        if (request_data->repeat < 0 || request_data->repeat > 255)
        {
            reply_json = NULL;
            err_code = BP_ERR_VALUE_OUT_OF_RANGE;
            snprintf(err_msg, sizeof(err_msg), "repeat out of range");
            goto EXIT;
        }
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "schType");
    if (cJSON_IsNumber(json_data))
    {
        request_data->sch_type = (int)(json_data->valueint);
        
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "sunEvt");
    if (cJSON_IsObject(json_data))
    {
        cJSON *json_item0 = NULL;
        
        json_item0 = cJSON_GetObjectItemCaseSensitive(json_data, "isRise");
        if (cJSON_IsNumber(json_item0))
        {
            request_data->sun_evt.is_rise = (int)(json_item0->valueint);
            
        }

        json_item0 = cJSON_GetObjectItemCaseSensitive(json_data, "ofsSec");
        if (cJSON_IsNumber(json_item0))
        {
            request_data->sun_evt.ofs_sec = (int)(json_item0->valueint);
            
            if (request_data->sun_evt.ofs_sec < -3600 || request_data->sun_evt.ofs_sec > 3600)
            {
                reply_json = NULL;
                err_code = BP_ERR_VALUE_OUT_OF_RANGE;
                snprintf(err_msg, sizeof(err_msg), "ofs_sec out of range");
                goto EXIT;
            }
        }


    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "tmgEvt");
    if (cJSON_IsObject(json_data))
    {
        cJSON *json_item0 = NULL;
        
        json_item0 = cJSON_GetObjectItemCaseSensitive(json_data, "clkSec");
        if (cJSON_IsNumber(json_item0))
        {
            request_data->tmg_evt.clk_sec = (int)(json_item0->valueint);
            
            if (request_data->tmg_evt.clk_sec < 0 || request_data->tmg_evt.clk_sec > 86399)
            {
                reply_json = NULL;
                err_code = BP_ERR_VALUE_OUT_OF_RANGE;
                snprintf(err_msg, sizeof(err_msg), "clk_sec out of range");
                goto EXIT;
            }
        }


    }

    
    json_data = cJSON_GetObjectItemCaseSensitive(json, "startAct");
    if (cJSON_IsArray(json_data))
    {
        cJSON *json_arr = NULL;
        int arr_size = cJSON_GetArraySize(json_data);
        request_data->start_act_num = arr_size;
        for (int i = 0; i < arr_size; i++)
        {
            json_arr = cJSON_GetArrayItem(json_data, i);
            if (json_arr != NULL)
            {
                cJSON *json_item = NULL;
                
                json_item = cJSON_GetObjectItemCaseSensitive(json_arr, "num");
                if (cJSON_IsNumber(json_item))
                {
                    request_data->start_act[i].num = (int)(json_item->valueint);
                    
                    if (request_data->start_act[i].num < 0 || request_data->start_act[i].num > 255)
                    {
                        reply_json = NULL;
                        err_code = BP_ERR_VALUE_OUT_OF_RANGE;
                        snprintf(err_msg, sizeof(err_msg), "num out of range");
                        goto EXIT;
                    }
                }

                json_item = cJSON_GetObjectItemCaseSensitive(json_arr, "actType");
                if (cJSON_IsNumber(json_item))
                {
                    request_data->start_act[i].act_type = (int)(json_item->valueint);
                    
                }

                json_item = cJSON_GetObjectItemCaseSensitive(json_arr, "act");
                if (cJSON_IsNumber(json_item))
                {
                    request_data->start_act[i].act = (int)(json_item->valueint);
                    
                }

                json_item = cJSON_GetObjectItemCaseSensitive(json_arr, "params");
                if (cJSON_IsObject(json_item))
                {
                    cJSON *json_item0 = NULL;
        
                    json_item0 = cJSON_GetObjectItemCaseSensitive(json_item, "brightness");
                    if (cJSON_IsNumber(json_item0))
                    {
                        request_data->start_act[i].params.brightness = (int)(json_item0->valueint);
                        
                        if (request_data->start_act[i].params.brightness < 0 || request_data->start_act[i].params.brightness > 100)
                        {
                            reply_json = NULL;
                            err_code = BP_ERR_VALUE_OUT_OF_RANGE;
                            snprintf(err_msg, sizeof(err_msg), "brightness out of range");
                            goto EXIT;
                        }
                    }

                    json_item0 = cJSON_GetObjectItemCaseSensitive(json_item, "hue");
                    if (cJSON_IsNumber(json_item0))
                    {
                        request_data->start_act[i].params.hue = (int)(json_item0->valueint);
                        
                        if (request_data->start_act[i].params.hue < 0 || request_data->start_act[i].params.hue > 10000)
                        {
                            reply_json = NULL;
                            err_code = BP_ERR_VALUE_OUT_OF_RANGE;
                            snprintf(err_msg, sizeof(err_msg), "hue out of range");
                            goto EXIT;
                        }
                    }

                    json_item0 = cJSON_GetObjectItemCaseSensitive(json_item, "saturation");
                    if (cJSON_IsNumber(json_item0))
                    {
                        request_data->start_act[i].params.saturation = (int)(json_item0->valueint);
                        
                        if (request_data->start_act[i].params.saturation < 0 || request_data->start_act[i].params.saturation > 10000)
                        {
                            reply_json = NULL;
                            err_code = BP_ERR_VALUE_OUT_OF_RANGE;
                            snprintf(err_msg, sizeof(err_msg), "saturation out of range");
                            goto EXIT;
                        }
                    }

                    json_item0 = cJSON_GetObjectItemCaseSensitive(json_item, "value");
                    if (cJSON_IsNumber(json_item0))
                    {
                        request_data->start_act[i].params.value = (int)(json_item0->valueint);
                        
                        if (request_data->start_act[i].params.value < 0 || request_data->start_act[i].params.value > 100)
                        {
                            reply_json = NULL;
                            err_code = BP_ERR_VALUE_OUT_OF_RANGE;
                            snprintf(err_msg, sizeof(err_msg), "value out of range");
                            goto EXIT;
                        }
                    }

                    json_item0 = cJSON_GetObjectItemCaseSensitive(json_item, "colorTemp");
                    if (cJSON_IsNumber(json_item0))
                    {
                        request_data->start_act[i].params.color_temp = (int)(json_item0->valueint);
                        
                        if (request_data->start_act[i].params.color_temp < 0 || request_data->start_act[i].params.color_temp > 100)
                        {
                            reply_json = NULL;
                            err_code = BP_ERR_VALUE_OUT_OF_RANGE;
                            snprintf(err_msg, sizeof(err_msg), "color_temp out of range");
                            goto EXIT;
                        }
                    }

                    json_item0 = cJSON_GetObjectItemCaseSensitive(json_item, "sceneId");
                    if (cJSON_IsNumber(json_item0))
                    {
                        request_data->start_act[i].params.scene_id = (int)(json_item0->valueint);
                        
                        if (request_data->start_act[i].params.scene_id < 1 || request_data->start_act[i].params.scene_id > 65535)
                        {
                            reply_json = NULL;
                            err_code = BP_ERR_VALUE_OUT_OF_RANGE;
                            snprintf(err_msg, sizeof(err_msg), "scene_id out of range");
                            goto EXIT;
                        }
                    }

                    json_item0 = cJSON_GetObjectItemCaseSensitive(json_item, "musicId");
                    if (cJSON_IsNumber(json_item0))
                    {
                        request_data->start_act[i].params.music_id = (int)(json_item0->valueint);
                        
                        if (request_data->start_act[i].params.music_id < 1 || request_data->start_act[i].params.music_id > 65535)
                        {
                            reply_json = NULL;
                            err_code = BP_ERR_VALUE_OUT_OF_RANGE;
                            snprintf(err_msg, sizeof(err_msg), "music_id out of range");
                            goto EXIT;
                        }
                    }


                }


            }
        }
    }
    else
    {
        request_data->start_act_num = 0;
    }


    
    ret = request_data_handle_for_upd_schedule(request_data, &err_code, err_msg, &extra);
    if (ret != APP_OK)
    {
        reply_json = NULL;
        goto EXIT;
    }

    if (ret == APP_OK)
    {
        bp_upd_schedule_reply_t *reply_data = (bp_upd_schedule_reply_t *) vesync_malloc(sizeof(bp_upd_schedule_reply_t));
        if (reply_data == NULL)
        {
            err_code = BP_ERR_OUT_OF_MEMORY;
            snprintf(err_msg, sizeof(err_msg), "out of memory");
            VCOM_SAFE_FREE(reply_data);
            goto EXIT;
        }

        memset(reply_data, BP_NO_VALUE, sizeof(bp_upd_schedule_reply_t));

        ret = reply_data_get_for_upd_schedule(reply_data, &err_code, err_msg, extra);
        if (ret != APP_OK)
        {
            VCOM_SAFE_FREE(reply_data);
            goto EXIT;
        }

        reply_json = cJSON_CreateObject();
        if (NULL == reply_json)
        {
            err_code = BP_ERR_OUT_OF_MEMORY;
            snprintf(err_msg, sizeof(err_msg), "out of memory");
            VCOM_SAFE_FREE(reply_data);
            goto EXIT;
        }
        
        if (reply_data->uid != BP_NO_VALUE)
        {
            cJSON_AddNumberToObject(reply_json, "uid", (int)(reply_data->uid));
        }

        VCOM_SAFE_FREE(reply_data);
    }
EXIT:
    VCOM_SAFE_FREE(request_data);
    p_msg_ctx->resp_error_code = err_code;
    p_msg_ctx->p_resp_error_msg = err_msg;
    p_msg_ctx->p_response = reply_json;

    return BP_OK;
}

static BYPASS_ERR_E bypass_get_schedules_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    int err_code = BP_ERR_NO_ERR;
    int ret = APP_OK;
    cJSON *reply_json = NULL;
    char err_msg[BP_ERR_MSG_LEN] = {0};
    void *extra = NULL;

    memset(err_msg, 0, sizeof(err_msg));
    cJSON *json_data = NULL;
    bp_get_schedules_request_t *request_data = (bp_get_schedules_request_t *) vesync_malloc(sizeof(bp_get_schedules_request_t));
    if (request_data == NULL)
    {
        err_code = BP_ERR_OUT_OF_MEMORY;
        snprintf(err_msg, sizeof(err_msg), "out of memory");
        goto EXIT;
    }

    memset(request_data, BP_NO_VALUE, sizeof(bp_get_schedules_request_t));
    
    json_data = cJSON_GetObjectItemCaseSensitive(json, "idx");
    if (cJSON_IsNumber(json_data))
    {
        request_data->idx = (int)(json_data->valueint);
        
        if (request_data->idx < 0 || request_data->idx > 256)
        {
            reply_json = NULL;
            err_code = BP_ERR_VALUE_OUT_OF_RANGE;
            snprintf(err_msg, sizeof(err_msg), "idx out of range");
            goto EXIT;
        }
    }
    
    ret = request_data_handle_for_get_schedules(request_data, &err_code, err_msg, &extra);
    if (ret != APP_OK)
    {
        reply_json = NULL;
        goto EXIT;
    }

    if (ret == APP_OK)
    {
        bp_get_schedules_reply_t *reply_data = (bp_get_schedules_reply_t *) vesync_malloc(sizeof(bp_get_schedules_reply_t));
        if (reply_data == NULL)
        {
            err_code = BP_ERR_OUT_OF_MEMORY;
            snprintf(err_msg, sizeof(err_msg), "out of memory");
            VCOM_SAFE_FREE(reply_data);
            goto EXIT;
        }

        memset(reply_data, BP_NO_VALUE, sizeof(bp_get_schedules_reply_t));

        ret = reply_data_get_for_get_schedules(reply_data, &err_code, err_msg, extra);
        if (ret != APP_OK)
        {
            VCOM_SAFE_FREE(reply_data);
            goto EXIT;
        }

        reply_json = cJSON_CreateObject();
        if (NULL == reply_json)
        {
            err_code = BP_ERR_OUT_OF_MEMORY;
            snprintf(err_msg, sizeof(err_msg), "out of memory");
            VCOM_SAFE_FREE(reply_data);
            goto EXIT;
        }
        
        if (reply_data->total_num != BP_NO_VALUE)
        {
            cJSON_AddNumberToObject(reply_json, "totalNum", (int)(reply_data->total_num));
        }

        
        cJSON *json_schedules = cJSON_AddArrayToObject(reply_json, "schedules");
        if (json_schedules != NULL)
        {
            for (int i = 0; i < reply_data->schedules_num; i++)
            {
                cJSON *json_item0 = cJSON_CreateObject();
                if (json_item0 != NULL)
                {
                    if (reply_data->schedules[i].uid != BP_NO_VALUE)
                    {
                        cJSON_AddNumberToObject(json_item0, "uid", (int)(reply_data->schedules[i].uid));
                    }

                    if (reply_data->schedules[i].enabled != BP_NO_VALUE)
                    {
                        cJSON_AddNumberToObject(json_item0, "enabled", (int)(reply_data->schedules[i].enabled));
                    }

                    if (reply_data->schedules[i].repeat != BP_NO_VALUE)
                    {
                        cJSON_AddNumberToObject(json_item0, "repeat", (int)(reply_data->schedules[i].repeat));
                    }

                    if (reply_data->schedules[i].sch_type != BP_NO_VALUE)
                    {
                        cJSON_AddNumberToObject(json_item0, "schType", (int)(reply_data->schedules[i].sch_type));
                    }

                    cJSON *json_sun_evt = cJSON_AddObjectToObject(json_item0, "sunEvt");
                    if (json_sun_evt != NULL)
                    {
                        if (reply_data->schedules[i].sun_evt.is_rise != BP_NO_VALUE)
                        {
                            cJSON_AddNumberToObject(json_sun_evt, "isRise", (int)(reply_data->schedules[i].sun_evt.is_rise));
                        }

                        if (reply_data->schedules[i].sun_evt.ofs_sec != BP_NO_VALUE)
                        {
                            cJSON_AddNumberToObject(json_sun_evt, "ofsSec", (int)(reply_data->schedules[i].sun_evt.ofs_sec));
                        }

                    }

                    cJSON *json_tmg_evt = cJSON_AddObjectToObject(json_item0, "tmgEvt");
                    if (json_tmg_evt != NULL)
                    {
                        if (reply_data->schedules[i].tmg_evt.clk_sec != BP_NO_VALUE)
                        {
                            cJSON_AddNumberToObject(json_tmg_evt, "clkSec", (int)(reply_data->schedules[i].tmg_evt.clk_sec));
                        }

                    }

                    
                    cJSON *json_start_act = cJSON_AddArrayToObject(json_item0, "startAct");
                    if (json_start_act != NULL)
                    {
                        for (int j = 0; j < reply_data->schedules[i].start_act_num; j++)
                        {
                            cJSON *json_item1 = cJSON_CreateObject();
                            if (json_item1 != NULL)
                            {
                                if (reply_data->schedules[i].start_act[j].num != BP_NO_VALUE)
                                {
                                    cJSON_AddNumberToObject(json_item1, "num", (int)(reply_data->schedules[i].start_act[j].num));
                                }

                                if (reply_data->schedules[i].start_act[j].act_type != BP_NO_VALUE)
                                {
                                    cJSON_AddNumberToObject(json_item1, "actType", (int)(reply_data->schedules[i].start_act[j].act_type));
                                }

                                if (reply_data->schedules[i].start_act[j].act != BP_NO_VALUE)
                                {
                                    cJSON_AddNumberToObject(json_item1, "act", (int)(reply_data->schedules[i].start_act[j].act));
                                }

                                cJSON *json_params = cJSON_AddObjectToObject(json_item1, "params");
                                if (json_params != NULL)
                                {
                                    if (reply_data->schedules[i].start_act[j].params.brightness != BP_NO_VALUE)
                                    {
                                        cJSON_AddNumberToObject(json_params, "brightness", (int)(reply_data->schedules[i].start_act[j].params.brightness));
                                    }

                                    if (reply_data->schedules[i].start_act[j].params.hue != BP_NO_VALUE)
                                    {
                                        cJSON_AddNumberToObject(json_params, "hue", (int)(reply_data->schedules[i].start_act[j].params.hue));
                                    }

                                    if (reply_data->schedules[i].start_act[j].params.saturation != BP_NO_VALUE)
                                    {
                                        cJSON_AddNumberToObject(json_params, "saturation", (int)(reply_data->schedules[i].start_act[j].params.saturation));
                                    }

                                    if (reply_data->schedules[i].start_act[j].params.value != BP_NO_VALUE)
                                    {
                                        cJSON_AddNumberToObject(json_params, "value", (int)(reply_data->schedules[i].start_act[j].params.value));
                                    }

                                    if (reply_data->schedules[i].start_act[j].params.color_temp != BP_NO_VALUE)
                                    {
                                        cJSON_AddNumberToObject(json_params, "colorTemp", (int)(reply_data->schedules[i].start_act[j].params.color_temp));
                                    }

                                    if (reply_data->schedules[i].start_act[j].params.scene_id != BP_NO_VALUE)
                                    {
                                        cJSON_AddNumberToObject(json_params, "sceneId", (int)(reply_data->schedules[i].start_act[j].params.scene_id));
                                    }

                                    if (reply_data->schedules[i].start_act[j].params.music_id != BP_NO_VALUE)
                                    {
                                        cJSON_AddNumberToObject(json_params, "musicId", (int)(reply_data->schedules[i].start_act[j].params.music_id));
                                    }

                                }

                            }
                            cJSON_AddItemToArray(json_start_act, json_item1);
                        }
                    }

                }
                cJSON_AddItemToArray(json_schedules, json_item0);
            }
        }

        VCOM_SAFE_FREE(reply_data);
    }
EXIT:
    VCOM_SAFE_FREE(request_data);
    p_msg_ctx->resp_error_code = err_code;
    p_msg_ctx->p_resp_error_msg = err_msg;
    p_msg_ctx->p_response = reply_json;

    return BP_OK;
}

static BYPASS_ERR_E bypass_del_schedule_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    int err_code = BP_ERR_NO_ERR;
    int ret = APP_OK;
    cJSON *reply_json = NULL;
    char err_msg[BP_ERR_MSG_LEN] = {0};
    void *extra = NULL;

    memset(err_msg, 0, sizeof(err_msg));
    cJSON *json_data = NULL;
    bp_del_schedule_request_t *request_data = (bp_del_schedule_request_t *) vesync_malloc(sizeof(bp_del_schedule_request_t));
    if (request_data == NULL)
    {
        err_code = BP_ERR_OUT_OF_MEMORY;
        snprintf(err_msg, sizeof(err_msg), "out of memory");
        goto EXIT;
    }

    memset(request_data, BP_NO_VALUE, sizeof(bp_del_schedule_request_t));
    
    json_data = cJSON_GetObjectItemCaseSensitive(json, "uid");
    if (cJSON_IsNumber(json_data))
    {
        request_data->uid = (int)(json_data->valueint);
        
        if (request_data->uid < 0 || request_data->uid > 256)
        {
            reply_json = NULL;
            err_code = BP_ERR_VALUE_OUT_OF_RANGE;
            snprintf(err_msg, sizeof(err_msg), "uid out of range");
            goto EXIT;
        }
    }
    
    ret = request_data_handle_for_del_schedule(request_data, &err_code, err_msg, &extra);
    if (ret != APP_OK)
    {
        reply_json = NULL;
        goto EXIT;
    }

    if (ret == APP_OK)
    {
        bp_del_schedule_reply_t *reply_data = (bp_del_schedule_reply_t *) vesync_malloc(sizeof(bp_del_schedule_reply_t));
        if (reply_data == NULL)
        {
            err_code = BP_ERR_OUT_OF_MEMORY;
            snprintf(err_msg, sizeof(err_msg), "out of memory");
            VCOM_SAFE_FREE(reply_data);
            goto EXIT;
        }

        memset(reply_data, BP_NO_VALUE, sizeof(bp_del_schedule_reply_t));

        ret = reply_data_get_for_del_schedule(reply_data, &err_code, err_msg, extra);
        if (ret != APP_OK)
        {
            VCOM_SAFE_FREE(reply_data);
            goto EXIT;
        }

        reply_json = cJSON_CreateObject();
        if (NULL == reply_json)
        {
            err_code = BP_ERR_OUT_OF_MEMORY;
            snprintf(err_msg, sizeof(err_msg), "out of memory");
            VCOM_SAFE_FREE(reply_data);
            goto EXIT;
        }
        
        if (reply_data->uid != BP_NO_VALUE)
        {
            cJSON_AddNumberToObject(reply_json, "uid", (int)(reply_data->uid));
        }

        VCOM_SAFE_FREE(reply_data);
    }
EXIT:
    VCOM_SAFE_FREE(request_data);
    p_msg_ctx->resp_error_code = err_code;
    p_msg_ctx->p_resp_error_msg = err_msg;
    p_msg_ctx->p_response = reply_json;

    return BP_OK;
}


/**
 * @brief bypass_method及其执行函数
 */
static bypass_user_data_t s_bypass_method_tbl[] = {
    {"setSwitch", bypass_set_switch_handle},
    {"toggleSwitch", bypass_toggle_switch_handle},
    {"setStatus", bypass_set_status_handle},
    {"getStatus", bypass_get_status_handle},
    {"adjustPercent", bypass_adjust_percent_handle},
    {"setBeadSize", bypass_set_bead_size_handle},
    {"getBeadSize", bypass_get_bead_size_handle},
    {"resetAging", bypass_reset_aging_handle},
    {"addScene", bypass_add_scene_handle},
    {"getScenes", bypass_get_scenes_handle},
    {"delScene", bypass_del_scene_handle},
    {"addTimer", bypass_add_timer_handle},
    {"getTimer", bypass_get_timer_handle},
    {"delTimer", bypass_del_timer_handle},
    {"addSchedule", bypass_add_schedule_handle},
    {"updSchedule", bypass_upd_schedule_handle},
    {"getSchedules", bypass_get_schedules_handle},
    {"delSchedule", bypass_del_schedule_handle},
};

/**
 * @brief 注册bypass回调函数
 */
void app_bypass_init()
{
    for (int i = 0; i < SIZEOF_ARRAY(s_bypass_method_tbl); i++)
    {
        vesync_bypass_add_user_item(&s_bypass_method_tbl[i]);
    }
}

