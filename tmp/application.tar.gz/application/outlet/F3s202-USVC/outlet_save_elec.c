/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        outlet_save_elec.c
 * @brief       outlet电量存储
 * @author      Charles.Mei
 * @date        2021-12-17
 * @note        本模块电量记录的时刻为一段时间间隔的结束时刻，也即下一段时间间隔的开始时刻
                为方便计算，并将一段时间间隔的结束时刻计入该时刻，对结束时刻“-1S“进行计算
 */


#include <stdint.h>
#include <string.h>

#include "vesync_common.h"
#include "vesync_log.h"
#include "vesync_memory.h"
#include "vesync_timer.h"
#include "vesync_task.h"
#include "vesync_mutex.h"

#include "vhal_utils.h"

#include "vesync_flash.h"
#include "vesync_klv.h"
#include "vesync_timebase.h"
#include "vesync_net_service.h"

#include "outlet.h"
#include "outlet_report.h"
#include "outlet_metering.h"
#include "outlet_save_elec.h"


/* 以下是测试宏 */
#define SAVE_ELEC_DEBUG_LEVLE    LOG_DISABLE

#define ELEC_DEBUG_LEVLE(level, ...)   \
    do                                          \
    {                                           \
        if (level >= SAVE_ELEC_DEBUG_LEVLE)     \
        {                                       \
            APP_LOG(level, ##__VA_ARGS__);      \
        }                                       \
    } while (0)

#define ELEC_DEBUG_E(...)    ELEC_DEBUG_LEVLE(LOG_ERROR, ##__VA_ARGS__)
#define ELEC_DEBUG_W(...)    ELEC_DEBUG_LEVLE(LOG_WARN, ##__VA_ARGS__)
#define ELEC_DEBUG_I(...)    ELEC_DEBUG_LEVLE(LOG_INFO, ##__VA_ARGS__)
#define ELEC_DEBUG_D(...)    ELEC_DEBUG_LEVLE(LOG_DEBUG, ##__VA_ARGS__)
/* 以上是测试宏 */


#define OUTLET_SAVE_ELEC_USED_ELEC_UNIT  OUTLET_METERING_ELEC_UNIT0

#define ELEC_HIST_DATA                  ("elec_hist_data")
#define ELEC_TODAY_DATA                 ("elec_today_data")
#define ELEC_REPORT_DATA                ("elec_prt_data")
#define ELEC_DATA_BUF_LEN               (512)

#define ELEC_TIMER_NAME                 ("elec_timer")
#define ELEC_DELAY_TIMER_NAME           ("delay_timer")
#define ELEC_UPD_TS_TIMER_NAME          ("upd_ts_timer")
#define ELEC_TIMER_START_WAIT           (20 * 1000) // timer启动延时20s
#define ELEC_TIMER_ERRORS               (36)         // 定时器允许误差36s
#define ELEC_DELAY_TIME_MIN_SEC         (6)         // 上报延时最小时间

#define ELEC_ABS(a, b)          (((a) > (b)) ? ((a) - (b)) : ((b) - (a)))


/**
 * @brief 需上报的电量存储数据key定义
 */
typedef enum
{
    ELEC_REPORT_KEY_ELEC_ARRY       = 0,
    ELEC_REPORT_KEY_TS_ARRY         = 1,
    ELEC_REPORT_KEY_LEN             = 2
} ELEC_REPORT_KEY_E;

/**
 * @brief 保存旧的时区时间戳
 */
typedef struct
{
    uint64_t old_tick;
    uint32_t old_ts;    // 时间戳
} elec_old_ts_t;

/**
 * @brief 保存电量的定时器回调
 */
typedef struct
{
    uint32_t record_ts; // 记录时间
    float elec;         // 电量
    uint8_t type;       // 上报类型，0——可以延时上报，1——立即上报
} elec_report_data_t;

/**
 * @brief 需要重发的电量
 */
typedef struct
{
    float elec_per_day[ELEC_HIST_STO_MAX];
    uint32_t record_ts[ELEC_HIST_STO_MAX];
    uint16_t len;
} elec_delay_report_data_t;


// 为测试接口新增
#if defined(PR_FW_TYPE) && (PR_FW_TYPE == 0)
static vesync_mutex_t s_debug_lock; // 测试参数锁
static uint32_t s_secs_per_hour = SECONDS_PER_HOUR;
static uint32_t s_secs_per_day = SECONDS_PER_DAY;
#else
static const uint32_t s_secs_per_hour = SECONDS_PER_HOUR;
static const uint32_t s_secs_per_day = SECONDS_PER_DAY;
#endif
static vesync_mutex_t s_elec_lock;      // 电量数据锁
static elec_temp_t s_elec_temp;         // 临时数据存储
static elec_today_t s_elec_today;       // 当天数据存储
static elec_history_t s_elec_history;   // 历史数据存储
static elec_old_ts_t s_elec_old_ts;     // 旧的时间戳
static elec_delay_report_data_t s_elec_delay_report_data;    // 延时上报数据
static vesync_timer_t *s_delay_report_timer = NULL;         // 延时上报timer
static uint32_t s_delay_report_timer_period_ms = 0;         // 延时上报周期


/**
 * @brief 保存需要重报数据到flash
 */
static void save_flash_report(void)
{
    uint8_t *elec_report_buf = NULL;
    uint32_t  offset = 0;

    elec_report_buf = vesync_malloc(ELEC_DATA_BUF_LEN);
    if (NULL == elec_report_buf)
    {
        APP_LOG(LOG_ERROR, "malloc fail\n");
        return;
    }
    memset(elec_report_buf, 0, ELEC_DATA_BUF_LEN);
    offset += vesync_klv_set(elec_report_buf + offset, ELEC_DATA_BUF_LEN - offset,
        ELEC_REPORT_KEY_ELEC_ARRY, sizeof(s_elec_delay_report_data.elec_per_day), (uint8_t *)s_elec_delay_report_data.elec_per_day);
    offset += vesync_klv_set(elec_report_buf + offset, ELEC_DATA_BUF_LEN - offset,
        ELEC_REPORT_KEY_TS_ARRY, sizeof(s_elec_delay_report_data.record_ts), (uint8_t *)s_elec_delay_report_data.record_ts);
    offset += vesync_klv_set(elec_report_buf + offset, ELEC_DATA_BUF_LEN - offset,
        ELEC_REPORT_KEY_LEN, sizeof(s_elec_delay_report_data.len), (uint8_t *)&s_elec_delay_report_data.len);
    vesync_flash_aes_crypto_write(PARTITION_CFG, ELEC_REPORT_DATA, elec_report_buf, offset);
    vesync_free(elec_report_buf);
}

/**
 * @brief 上报历史电量
 */
void outlet_save_elec_report(void)
{
    uint16_t len = s_elec_delay_report_data.len;
    if (0 == len)
    {
        memset(&s_elec_delay_report_data, 0, sizeof(s_elec_delay_report_data));
        vesync_flash_erase_key(PARTITION_CFG, ELEC_REPORT_DATA);
        if (NULL != s_delay_report_timer && 0 != s_delay_report_timer_period_ms)
        {
            if (VOS_OK == vesync_timer_stop(s_delay_report_timer))
            {
                s_delay_report_timer_period_ms = 0;
            }
        }
        return;
    }
    --len;
    if (APP_OK == outlet_report_elec_metering(s_elec_delay_report_data.elec_per_day[len],
        s_elec_delay_report_data.record_ts[len]))
    {
        s_elec_delay_report_data.elec_per_day[len] = 0;
        s_elec_delay_report_data.record_ts[len] = 0;
        s_elec_delay_report_data.len = len;
    }
    else
    {
        if (NULL != s_delay_report_timer && 0 != s_delay_report_timer_period_ms)
        {
            if (VOS_OK == vesync_timer_stop(s_delay_report_timer))
            {
                s_delay_report_timer_period_ms = 0;
            }
        }
        return;
    }
    if (0 != len)
    {
        if (NULL != s_delay_report_timer && ELEC_DELAY_TIME_MIN_SEC * 1000 != s_delay_report_timer_period_ms)
        {
            if (VOS_OK == vesync_timer_change_period(s_delay_report_timer, ELEC_DELAY_TIME_MIN_SEC * 1000))
            {
                s_delay_report_timer_period_ms = ELEC_DELAY_TIME_MIN_SEC * 1000;
            }
        }
    }
}

/**
 * @brief 上报电量的定时器回调
 * @param[in]   arg
 * @note  在能够获取到当前时区时，此定时器自动校准，在每个小时的最后一刻执行，
 *        允许存在偏差ELEC_TIMER_ERRORS；若不能获得当前时区，固定一个小时执行一次
 */
static void delay_to_report_timer_cb(void *arg)
{
    outlet_ev_t ev = {
        id: OUTLET_EV_REPORT_ELEC,
        act_src: OUTLET_ACT_SRC_UNKNOW,
        rsn: ""
    };
    UNUSED(arg);
    outlet_app_task_notify(&ev);
}

/**
 * @brief 保存计量校准系数
 * @param[in]   report_data     [上报数据]
 * @note  可以延时上报时，判断是否在零点到一点，否则立刻上报
 */
static void set_ready_to_report(elec_report_data_t report_data)
{
    timebase_info_t timebase_now;
    uint32_t delay_time_ms = ELEC_DELAY_TIME_MIN_SEC * 1000;
    uint16_t delay_report_len = 0;
    uint16_t idx = 0;

    if (report_data.record_ts < VCOM_SYSTEM_MIN_TS || report_data.elec < 0)
    {
        APP_LOG(LOG_WARN, "report error\n");
        return;
    }
    delay_report_len = s_elec_delay_report_data.len;
    if (ELEC_HIST_STO_MAX <= delay_report_len)
    {
        for (idx = 0; idx < ELEC_HIST_STO_MAX - 1; ++idx)
        {
            s_elec_delay_report_data.elec_per_day[idx] = s_elec_delay_report_data.elec_per_day[idx + 1];
            s_elec_delay_report_data.record_ts[idx] = s_elec_delay_report_data.record_ts[idx + 1];
        }
        s_elec_delay_report_data.elec_per_day[idx] = report_data.elec;
        s_elec_delay_report_data.record_ts[idx] = report_data.record_ts;
        s_elec_delay_report_data.len = ELEC_HIST_STO_MAX;
    }
    else
    {
        s_elec_delay_report_data.elec_per_day[delay_report_len] = report_data.elec;
        s_elec_delay_report_data.record_ts[delay_report_len] = report_data.record_ts;
        s_elec_delay_report_data.len = delay_report_len + 1;
    }
    save_flash_report();
    if (0 == report_data.type)
    {

        if (TMBS_OK == vesync_timebase_get_cur_info(&timebase_now) && timebase_now.local_ts % s_secs_per_day <= s_secs_per_hour)
        {
            ELEC_DEBUG_D("in first hour\n");
            vhal_utils_get_random((uint8_t *)&delay_time_ms, sizeof(delay_time_ms));
            delay_time_ms = (delay_time_ms % (s_secs_per_hour - ELEC_DELAY_TIME_MIN_SEC) + ELEC_DELAY_TIME_MIN_SEC) * 1000;   // 确保最小上报延时
        }
    }

    ELEC_DEBUG_D("delay reprot ms: %ld\n", delay_time_ms);
    if (NULL == s_delay_report_timer)
    {
        s_delay_report_timer_period_ms = 0;
        s_delay_report_timer = vesync_timer_new(ELEC_DELAY_TIMER_NAME,
            delay_to_report_timer_cb, NULL, delay_time_ms, true);
        if (NULL != s_delay_report_timer)
        {
            if (VOS_OK == vesync_timer_start(s_delay_report_timer))
            {
                s_delay_report_timer_period_ms = delay_time_ms;
            }
        }
        else
        {
            APP_LOG(LOG_ERROR, "create timer fail\n");
        }
    }
    else
    {
        if (delay_time_ms != s_delay_report_timer_period_ms)
        {
            if (VOS_OK == vesync_timer_change_period(s_delay_report_timer, delay_time_ms))
            {
                s_delay_report_timer_period_ms = delay_time_ms;
            }
        }
    }
}

/**
 * @brief 保存历史数据到flash
 */
static void save_flash_history(void)
{
    uint8_t *elec_hist_buf = NULL;
    uint32_t  offset = 0;

    elec_hist_buf = vesync_malloc(ELEC_DATA_BUF_LEN);
    if (NULL == elec_hist_buf)
    {
        APP_LOG(LOG_ERROR, "malloc fail\n");
        return;
    }
    memset(elec_hist_buf, 0, ELEC_DATA_BUF_LEN);
    offset += vesync_klv_set(elec_hist_buf + offset, ELEC_DATA_BUF_LEN - offset,
        ELEC_HIST_KEY_ARRY, sizeof(s_elec_history.elec_per_day), (uint8_t *)s_elec_history.elec_per_day);
    offset += vesync_klv_set(elec_hist_buf + offset, ELEC_DATA_BUF_LEN - offset,
        ELEC_HIST_KEY_TS, sizeof(s_elec_history.record_ts), (uint8_t *)&s_elec_history.record_ts);
    offset += vesync_klv_set(elec_hist_buf + offset, ELEC_DATA_BUF_LEN - offset,
        ELEC_HIST_KEY_INDEX, sizeof(s_elec_history.index), (uint8_t *)&s_elec_history.index);
    vesync_flash_aes_crypto_write(PARTITION_CFG, ELEC_HIST_DATA, elec_hist_buf, offset);
    vesync_free(elec_hist_buf);
}

/**
 * @brief 保存每天的电量
 * @param[in]   electricity     [电量]
 * @param[in]   record_ts       [记录时间]
 */
static void save_elec_per_day(float electricity, uint32_t record_ts)
{
    elec_report_data_t report_data;

    if (record_ts < VCOM_SYSTEM_MIN_TS) // 小于系统最小时间，时间戳未同步，数据无效
    {
        return;
    }

    memset(&report_data, 0, sizeof(report_data));

    // 时间偏移超过存储的最大历史天数，清空历史数据重新记录
    if (ELEC_ABS(record_ts, s_elec_history.record_ts) >= s_secs_per_day * HISTORY_DAY_MAX)
    {
        memset(&s_elec_history, 0, sizeof(s_elec_history));
        // 在每天的最后一刻，也是后一天的开始
        s_elec_history.record_ts = ((record_ts - 1) / s_secs_per_day + 1) * s_secs_per_day;
        s_elec_history.elec_per_day[s_elec_history.index] = electricity;
        report_data.record_ts = s_elec_history.record_ts - 1;   // 记录时间为当晚24点整，上报会转换为第二天零点的时间，所以需要减去1~s_secs_per_day
        report_data.elec = electricity;
        ELEC_DEBUG_D("clear history, hist_ts = %ld\n", s_elec_history.record_ts);
    }
    else if (record_ts > s_elec_history.record_ts)
    {
        while (record_ts > s_elec_history.record_ts + s_secs_per_day)
        {
            s_elec_history.record_ts += s_secs_per_day;
            s_elec_history.index = (s_elec_history.index + 1) % ELEC_HIST_STO_MAX;
            s_elec_history.elec_per_day[s_elec_history.index] = 0;
            ELEC_DEBUG_D("restore 0, hist_ts = %ld\n", s_elec_history.record_ts);
        }
        if (record_ts == s_elec_history.record_ts + s_secs_per_day)
        {
            s_elec_history.record_ts = record_ts;
            s_elec_history.index = (s_elec_history.index + 1) % ELEC_HIST_STO_MAX;
            s_elec_history.elec_per_day[s_elec_history.index] = electricity;
            ELEC_DEBUG_D("restore elec[%d] = %8f, hist_ts = %ld\n",
                s_elec_history.index, s_elec_history.elec_per_day[s_elec_history.index], s_elec_history.record_ts);
        }
        else
        {
            APP_LOG(LOG_WARN, "save history at the last second of the day!\n");
        }
        report_data.record_ts = record_ts - 1;
        report_data.elec = electricity;
    }
    else    // 时间戳前移，直接在对应历史数据中累加
    {
        report_data.record_ts = record_ts - 1;
        report_data.elec = (s_elec_history.elec_per_day[(ELEC_HIST_STO_MAX + s_elec_history.index -
            (s_elec_history.record_ts - record_ts) / s_secs_per_day) % ELEC_HIST_STO_MAX] += electricity);
        report_data.type = 1; // 立即上报
        ELEC_DEBUG_D("add old elec[%d] = %8f, record_ts = %ld\n",
            (ELEC_HIST_STO_MAX + s_elec_history.index - (s_elec_history.record_ts - record_ts) / s_secs_per_day) % ELEC_HIST_STO_MAX,
            s_elec_history.elec_per_day[(ELEC_HIST_STO_MAX + s_elec_history.index - (s_elec_history.record_ts - record_ts) / s_secs_per_day) % ELEC_HIST_STO_MAX],
            record_ts);
    }

    ELEC_DEBUG_D("history_ts: %ld\n", s_elec_history.record_ts);
    for (uint8_t idx = 0; idx <= s_elec_history.index; ++idx)
    {
        ELEC_DEBUG_D("elec_per_day[%d]: %8f\n", idx, s_elec_history.elec_per_day[idx]);
    }

    save_flash_history();

    set_ready_to_report(report_data);
}

/**
 * @brief 保存当天数据到flash
 */
static void save_flash_today(void)
{
    uint8_t *elec_today_buf = NULL;
    uint32_t  offset = 0;

    elec_today_buf = vesync_malloc(ELEC_DATA_BUF_LEN);
    if (NULL == elec_today_buf)
    {
        APP_LOG(LOG_ERROR, "malloc fail\n");
        return;
    }
    memset(elec_today_buf, 0, ELEC_DATA_BUF_LEN);
    offset += vesync_klv_set(elec_today_buf + offset, ELEC_DATA_BUF_LEN - offset,
        ELEC_TODAY_KEY_ARRAY, sizeof(s_elec_today.elec_per_hour), (uint8_t *)s_elec_today.elec_per_hour);
    offset += vesync_klv_set(elec_today_buf + offset, ELEC_DATA_BUF_LEN - offset,
        ELEC_TODAY_KEY_TS, sizeof(s_elec_today.today_ts), (uint8_t *)&s_elec_today.today_ts);
    offset += vesync_klv_set(elec_today_buf + offset, ELEC_DATA_BUF_LEN - offset,
        ELEC_TODAY_KEY_INDEX, sizeof(s_elec_today.index), (uint8_t *)&s_elec_today.index);
    vesync_flash_aes_crypto_write(PARTITION_CFG, ELEC_TODAY_DATA, elec_today_buf, offset);
    vesync_free(elec_today_buf);
}

/**
 * @brief 保存每小时的电量
 * @param[in]   electricity     [电量]
 * @param[in]   record_ts       [记录时间]
 */
static void save_elec_per_hour(float electricity, uint32_t record_ts)
{
    uint32_t record_clk_sec = record_ts % s_secs_per_day;
    float elec_sum = 0;
    uint8_t idx = 0;

    if (record_ts < VCOM_SYSTEM_MIN_TS) // 小于系统最小时间，时间戳未同步，数据无效
    {
        return;
    }

    if (record_ts <= s_elec_today.today_ts)   // 时间戳前移，清除未来数据
    {
        s_elec_today.index = 0;
        memset(&s_elec_today.elec_per_hour, 0, sizeof(s_elec_today.elec_per_hour));
        ELEC_DEBUG_D("add hist elec direct, record_ts = %ld\n", record_ts);
        save_elec_per_day(electricity, record_ts);
        return;
    }
    else if (record_ts - s_elec_today.today_ts > s_secs_per_day)
    {
        elec_sum = 0;
        for (idx = 0; idx < ELEC_TODAY_STO_SIZE; ++idx)
        {
            elec_sum += s_elec_today.elec_per_hour[idx];
        }
        ELEC_DEBUG_D("clear old hours, elec_sum = %8f, today_ts = %ld\n", elec_sum, s_elec_today.today_ts);
        save_elec_per_day(elec_sum, s_elec_today.today_ts + s_secs_per_day);
        memset(&s_elec_today, 0, sizeof(s_elec_today));
        // 记录当天零点
        s_elec_today.today_ts = record_ts - (record_clk_sec == 0 ? s_secs_per_day : record_clk_sec);
        ELEC_DEBUG_D("new today_ts = %ld\n", s_elec_today.today_ts);
    }
    if (0 == record_clk_sec)    // 如果为当天24点，即累计电量为当天最后一小时
    {
        elec_sum = electricity;
        for (idx = 0; idx < ELEC_TODAY_STO_SIZE; ++idx)
        {
            elec_sum += s_elec_today.elec_per_hour[idx];
        }
        ELEC_DEBUG_D("last hour, elec_sum = %8f, record_ts = %ld\n", elec_sum, record_ts);
        save_elec_per_day(elec_sum, record_ts);
        memset(&s_elec_today, 0, sizeof(s_elec_today));
        s_elec_today.today_ts = record_ts;
    }
    else
    {
        // 在每个小时的最后一刻，也是后一小时的开始
        s_elec_today.index = (record_clk_sec - 1) / s_secs_per_hour;
        s_elec_today.elec_per_hour[s_elec_today.index] += electricity;
        // 清除未来数据
        if (s_elec_today.index < ELEC_TODAY_STO_SIZE - 1)
        {
            memset(&s_elec_today.elec_per_hour[s_elec_today.index + 1], 0,
                sizeof(s_elec_today.elec_per_hour) - (1 + s_elec_today.index) * sizeof(s_elec_today.elec_per_hour[0]));
        }
        ELEC_DEBUG_D("record per hour, elec_per_hour[%d] = %8f\n", s_elec_today.index, s_elec_today.elec_per_hour[s_elec_today.index]);
    }
    ELEC_DEBUG_D("today_ts: %ld\n", s_elec_today.today_ts);
    for (idx = 0; idx <= s_elec_today.index; ++idx)
    {
        ELEC_DEBUG_D("elec_per_hour[%d]: %8f\n", idx, s_elec_today.elec_per_hour[idx]);
    }
}

/**
 * @brief 校准临时数据的时间戳并保存
 * @param[in]   now_ts          [当前时间]
 */
static void calibrate_record_time_to_save(uint32_t now_ts)
{
    uint64_t diff_tick = vesync_task_get_tick_ms() - s_elec_temp.record_tick;
    uint32_t record_ts = now_ts - diff_tick / 1000;
    uint32_t start_ts = record_ts - s_secs_per_hour * ELEC_TEMP_STO_MAX;
    uint16_t index = s_elec_temp.index;
    uint16_t total_record = ELEC_TEMP_STO_MAX;
    uint32_t last_hour_times = record_ts % s_secs_per_hour;
    float last_hour_percent = (record_ts % s_secs_per_hour) / s_secs_per_hour;
    float one_hour_elec = 0;    // 一个小时的电量

    if (diff_tick > (s_secs_per_hour + ELEC_TIMER_ERRORS) * 2 * 1000)     // 时差超过2小时视为异常，丢弃数据
    {
        ELEC_DEBUG_E("temp elec err\n");
        memset(&s_elec_temp, 0, sizeof(s_elec_temp));
        return;
    }

    start_ts -= last_hour_times;   // 初始化，为了循环先减再处理
    while(total_record--)
    {
        index = (index + 1) % ELEC_TEMP_STO_MAX;    // 从第一个记录的数据开始
        start_ts += s_secs_per_hour;
        if (0 == one_hour_elec && 0 == s_elec_temp.elec_per_hour[index])
        {
            continue;
        }
        one_hour_elec += s_elec_temp.elec_per_hour[index] -
            s_elec_temp.elec_per_hour[index] * last_hour_percent;
        ELEC_DEBUG_D("temp to save, elec = %8f, ts = %ld\n", one_hour_elec, start_ts);
        if (start_ts > s_elec_today.today_ts)   // 时间戳前移则丢弃数据
        {
            save_elec_per_hour(one_hour_elec, start_ts);
        }
        one_hour_elec = s_elec_temp.elec_per_hour[index] * last_hour_percent;
    }
    // 处理最后一个小时的后半部分
    start_ts += last_hour_times;
    if (0 != one_hour_elec)
    {
        ELEC_DEBUG_D("temp to save, elec = %8f, ts = %ld\n", one_hour_elec, start_ts);
        save_elec_per_hour(one_hour_elec, start_ts);
    }
    memset(&s_elec_temp, 0, sizeof(s_elec_temp));
}

/**
 * @brief 时基变更回调处理
 * @param[in]   type            [时基类型]
 */
static void timebase_info_upd_handle(TMBS_INFO_TYPE_E type)
{
    outlet_ev_t ev = {
        id: OUTLET_EV_SAVE_ELEC
    };

    switch (type)
    {
        case TMBS_ALL:
        case TMBS_TZ:
        case TMBS_DST:
            if (0 != s_elec_temp.record_tick || s_elec_old_ts.old_ts <= VCOM_SYSTEM_MIN_TS) // 时间校准，非时区变更
            {
                ELEC_DEBUG_D("time calibration\n");
                return;
            }
            ELEC_DEBUG_D("timezone upd\n");
            ev.act_src = OUTLET_ACT_SRC_ELEC_SAVE_UPD_TS;
            memset(ev.rsn, 0, sizeof(ev.rsn));
            outlet_app_task_notify(&ev);
            break;
        default:
            return;
    }
}

/**
 * @brief 执行电量存储
 * @param[in]   trig_type       [触发类型]
 */
void outlet_save_elec_exec(ELEC_SAVE_TRIG_TYPE_E trig_type)
{
    timebase_info_t timebase_now;
    uint64_t cur_tick = 0;
    uint32_t record_ts = 0;
    float electricity = 0;

#if defined(PR_FW_TYPE) && (PR_FW_TYPE == 0)
    vesync_mutex_lock(s_debug_lock);
#endif
    switch (trig_type)
    {
        case ELEC_SAVE_TRIG_TICK:
            ELEC_DEBUG_D("save temp elec\n");
            if (APP_OK != outlet_metering_get_electricity(OUTLET_SAVE_ELEC_USED_ELEC_UNIT, &electricity))
            {
                break;
            }
            outlet_metering_clear_electricity(OUTLET_SAVE_ELEC_USED_ELEC_UNIT);
            vesync_mutex_lock(s_elec_lock);
            s_elec_temp.record_tick = vesync_task_get_tick_ms();
            s_elec_temp.elec_per_hour[s_elec_temp.index] = electricity;
            s_elec_temp.index = (s_elec_temp.index + 1) % ELEC_TEMP_STO_MAX;
            vesync_mutex_unlock(s_elec_lock);
            break;
        case ELEC_SAVE_TRIG_UPD_TS:
            cur_tick = vesync_task_get_tick_ms();
            vesync_mutex_lock(s_elec_lock);
            if (s_elec_old_ts.old_ts > VCOM_SYSTEM_MIN_TS)
            {
                if (cur_tick - s_elec_old_ts.old_tick < (2 * ELEC_TIMER_ERRORS + s_secs_per_hour) * 1000)
                {
                    s_elec_old_ts.old_ts += (cur_tick - s_elec_old_ts.old_tick) / 1000;
                    s_elec_old_ts.old_tick = cur_tick;
                    if (APP_OK == outlet_metering_get_electricity(OUTLET_SAVE_ELEC_USED_ELEC_UNIT, &electricity))
                    {
                        outlet_metering_clear_electricity(OUTLET_SAVE_ELEC_USED_ELEC_UNIT);
                        save_elec_per_hour(electricity, s_elec_old_ts.old_ts);
                        save_flash_today();
                    }
                }
                else
                {
                    memset(&s_elec_old_ts, 0, sizeof(s_elec_old_ts));
                }
            }
            if (TMBS_OK == vesync_timebase_get_cur_info(&timebase_now))
            {
                s_elec_old_ts.old_tick = vesync_task_get_tick_ms();
                s_elec_old_ts.old_ts = timebase_now.local_ts;
            }
            vesync_mutex_unlock(s_elec_lock);
            break;
        case ELEC_SAVE_TRIG_CLOCK:
            if (TMBS_OK != vesync_timebase_get_cur_info(&timebase_now))
            {
                ELEC_DEBUG_E("get ts fail\n");
                break;
            }
            vesync_mutex_lock(s_elec_lock);
            s_elec_old_ts.old_tick = vesync_task_get_tick_ms();
            s_elec_old_ts.old_ts = timebase_now.local_ts;
            // 校准定时器误差
            record_ts = timebase_now.local_ts / s_secs_per_hour * s_secs_per_hour;
            if (timebase_now.local_ts - record_ts > ELEC_TIMER_ERRORS)
            {
                record_ts = ((timebase_now.local_ts - 1) / s_secs_per_hour + 1) * s_secs_per_hour;
            }
            if (0 != s_elec_temp.record_tick) // 存在临时存储数据，校准时间后存储
            {
                calibrate_record_time_to_save(record_ts);
            }
            if (APP_OK != outlet_metering_get_electricity(OUTLET_SAVE_ELEC_USED_ELEC_UNIT, &electricity))
            {
                vesync_mutex_unlock(s_elec_lock);
                break;
            }
            outlet_metering_clear_electricity(OUTLET_SAVE_ELEC_USED_ELEC_UNIT);
            save_elec_per_hour(electricity, record_ts);
            save_flash_today();
            vesync_mutex_unlock(s_elec_lock);
            break;
    }
#if defined(PR_FW_TYPE) && (PR_FW_TYPE == 0)
    vesync_mutex_unlock(s_debug_lock);
#endif

}

/**
 * @brief 保存电量的定时器回调
 * @param[in]   arg
 * @note  在能够获取到当前时区时，此定时器自动校准，在每个小时的最后一刻执行，
 *        允许存在偏差ELEC_TIMER_ERRORS；若不能获得当前时区，固定一个小时执行一次
 */
static void save_elec_timer_cb(void *arg)
{
    static vesync_timer_t *s_save_elec_timer = NULL;
    timebase_info_t timebase_now;
    outlet_ev_t ev = {
        id: OUTLET_EV_SAVE_ELEC,
        rsn: ""
    };
    uint64_t record_tick = 0;
    uint32_t record_ts = 0;
    uint32_t new_period_ms = s_secs_per_hour * 1000;

    UNUSED(arg);

    if (NULL == s_save_elec_timer)
    {
        s_save_elec_timer = vesync_timer_new(ELEC_TIMER_NAME,
            save_elec_timer_cb, NULL, ELEC_TIMER_START_WAIT, true);
        if (NULL != s_save_elec_timer)
        {
            vesync_timer_start(s_save_elec_timer);
        }
        else
        {
            APP_LOG(LOG_ERROR, "create timer fail\n");
        }
        return;
    }

#if defined(PR_FW_TYPE) && (PR_FW_TYPE == 0)
    if (VOS_OK != vesync_mutex_try_lock(s_debug_lock))
    {
        return;
    }
#endif
    if (TMBS_OK != vesync_timebase_get_cur_info(&timebase_now))
    {
        record_tick = vesync_task_get_tick_ms();
        if (record_tick < s_secs_per_hour * 1000)
        {
            new_period_ms = s_secs_per_hour * 1000 - record_tick;
            goto RETRY;
        }
        ev.act_src = OUTLET_ACT_SRC_ELEC_SAVE_TICK;
        outlet_app_task_notify(&ev);
        goto RETRY;
    }

    // 校准定时器误差
    record_ts = timebase_now.local_ts / s_secs_per_hour * s_secs_per_hour;
    if (timebase_now.local_ts - record_ts > ELEC_TIMER_ERRORS)
    {
        record_ts = ((timebase_now.local_ts - 1) / s_secs_per_hour + 1) * s_secs_per_hour;
        new_period_ms = (record_ts - timebase_now.local_ts) * 1000;
        if (record_ts - timebase_now.local_ts > ELEC_TIMER_ERRORS)
        {
            goto RETRY;
        }
    }
    else
    {
        new_period_ms = (record_ts + s_secs_per_hour - timebase_now.local_ts) * 1000;
    }
    ev.act_src = OUTLET_ACT_SRC_ELEC_SAVE_CLOCK;
    outlet_app_task_notify(&ev);

RETRY:
#if defined(PR_FW_TYPE) && (PR_FW_TYPE == 0)
    vesync_mutex_unlock(s_debug_lock);
#endif
    vesync_timer_change_period(s_save_elec_timer, new_period_ms);
}

/**
 * @brief 加载电量数据
 * @return      int             [错误码，成功/失败]
 */
static int load_elec(void)
{
    uint8_t *elec_buf = vesync_malloc(ELEC_DATA_BUF_LEN);
    uint32_t buf_len = ELEC_DATA_BUF_LEN;
    int ret = APP_FAIL;

    memset(&s_elec_today, 0, sizeof(s_elec_today));
    memset(&s_elec_history, 0, sizeof(s_elec_history));
    memset(&s_elec_delay_report_data, 0, sizeof(s_elec_delay_report_data));

    if (NULL == elec_buf)
    {
        APP_LOG(LOG_ERROR, "malloc fail\n");
        return APP_FAIL;
    }
    if (SDK_OK != vesync_flash_aes_crypto_read(PARTITION_CFG, ELEC_TODAY_DATA, elec_buf, &buf_len) || 0 == buf_len)
    {
        APP_LOG(LOG_INFO, "read flash err\n");
        goto EXIT;
    }
    if(SDK_OK != vesync_klv_get(elec_buf, ELEC_DATA_BUF_LEN, ELEC_TODAY_KEY_ARRAY,
        sizeof(s_elec_today.elec_per_hour), (uint8_t *)s_elec_today.elec_per_hour))
    {
         APP_LOG(LOG_ERROR, "read elec_per_hour err\n");
    }
    if(SDK_OK != vesync_klv_get(elec_buf, ELEC_DATA_BUF_LEN, ELEC_TODAY_KEY_TS,
        sizeof(s_elec_today.today_ts), (uint8_t *)&s_elec_today.today_ts))
    {
         APP_LOG(LOG_ERROR, "read today_ts err\n");
    }
    if(SDK_OK != vesync_klv_get(elec_buf, ELEC_DATA_BUF_LEN, ELEC_TODAY_KEY_INDEX,
        sizeof(s_elec_today.index), (uint8_t *)&s_elec_today.index))
    {
         APP_LOG(LOG_ERROR, "read index err\n");
    }

    buf_len = ELEC_DATA_BUF_LEN;
    if (SDK_OK != vesync_flash_aes_crypto_read(PARTITION_CFG, ELEC_HIST_DATA, elec_buf, &buf_len) || 0 == buf_len)
    {
        APP_LOG(LOG_INFO, "read flash err\n");
        goto EXIT;
    }
    if(SDK_OK != vesync_klv_get(elec_buf, ELEC_DATA_BUF_LEN, ELEC_HIST_KEY_ARRY,
        sizeof(s_elec_history.elec_per_day), (uint8_t *)s_elec_history.elec_per_day))
    {
         APP_LOG(LOG_ERROR, "read elec_history err\n");
    }
    if(SDK_OK != vesync_klv_get(elec_buf, ELEC_DATA_BUF_LEN, ELEC_HIST_KEY_TS,
        sizeof(s_elec_history.record_ts), (uint8_t *)&s_elec_history.record_ts))
    {
         APP_LOG(LOG_ERROR, "read today_ts err\n");
    }
    if(SDK_OK != vesync_klv_get(elec_buf, ELEC_DATA_BUF_LEN, ELEC_HIST_KEY_INDEX,
        sizeof(s_elec_history.index), (uint8_t *)&s_elec_history.index))
    {
         APP_LOG(LOG_ERROR, "read index err\n");
    }

    if (s_elec_today.today_ts < s_elec_history.record_ts)
    {
        APP_LOG(LOG_ERROR, "today_ts err\n");
        memset(&s_elec_today, 0, sizeof(s_elec_today));
        s_elec_today.today_ts = s_elec_history.record_ts;
    }

    buf_len = ELEC_DATA_BUF_LEN;
    if (SDK_OK != vesync_flash_aes_crypto_read(PARTITION_CFG, ELEC_REPORT_DATA, elec_buf, &buf_len) || 0 == buf_len)
    {
        APP_LOG(LOG_INFO, "read flash err\n");
        goto EXIT;
    }
    if(SDK_OK != vesync_klv_get(elec_buf, ELEC_DATA_BUF_LEN, ELEC_REPORT_KEY_ELEC_ARRY,
        sizeof(s_elec_delay_report_data.elec_per_day), (uint8_t *)s_elec_delay_report_data.elec_per_day))
    {
         APP_LOG(LOG_ERROR, "read elec_history err\n");
    }
    if(SDK_OK != vesync_klv_get(elec_buf, ELEC_DATA_BUF_LEN, ELEC_REPORT_KEY_TS_ARRY,
        sizeof(s_elec_delay_report_data.record_ts), (uint8_t *)s_elec_delay_report_data.record_ts))
    {
         APP_LOG(LOG_ERROR, "read today_ts err\n");
    }
    if(SDK_OK != vesync_klv_get(elec_buf, ELEC_DATA_BUF_LEN, ELEC_REPORT_KEY_LEN,
        sizeof(s_elec_delay_report_data.len), (uint8_t *)&s_elec_delay_report_data.len))
    {
         APP_LOG(LOG_ERROR, "read index err\n");
    }

    ret = APP_OK;

EXIT:
    vesync_free(elec_buf);
    return ret;
}

/**
 * @brief 重报历史电量
 */
void outlet_retry_report_history_elec(void)
{
    if (0 == s_elec_delay_report_data.len)
    {
        return;
    }
    if (NULL == s_delay_report_timer)
    {
        s_delay_report_timer_period_ms = 0;
        s_delay_report_timer = vesync_timer_new(ELEC_DELAY_TIMER_NAME,
            delay_to_report_timer_cb, NULL, ELEC_DELAY_TIME_MIN_SEC * 1000, true);
        if (NULL != s_delay_report_timer)
        {
            if (VOS_OK == vesync_timer_start(s_delay_report_timer))
            {
                s_delay_report_timer_period_ms = ELEC_DELAY_TIME_MIN_SEC * 1000;
            }
        }
        else
        {
            APP_LOG(LOG_ERROR, "create timer fail\n");
        }
    }
    else
    {
        if (ELEC_DELAY_TIME_MIN_SEC * 1000 != s_delay_report_timer_period_ms)
        {
            if (VOS_OK == vesync_timer_change_period(s_delay_report_timer, ELEC_DELAY_TIME_MIN_SEC * 1000))
            {
                s_delay_report_timer_period_ms = ELEC_DELAY_TIME_MIN_SEC * 1000;
            }
        }
    }
}

/**
 * @brief 电量保存模块初始化
 * @return      int             [错误码，成功/失败]
 */
int outlet_save_elec_init(void)
{
    s_elec_lock = vesync_mutex_new();
    if (NULL == s_elec_lock)
    {
        APP_LOG(LOG_ERROR, "create lock fail\n");
        return APP_FAIL;
    }
#if defined(PR_FW_TYPE) && (PR_FW_TYPE == 0)
    s_debug_lock = vesync_mutex_new();
    if (NULL == s_debug_lock)
    {
        APP_LOG(LOG_ERROR, "create lock fail\n");
        return APP_FAIL;
    }
#endif
    memset(&s_elec_temp, 0, sizeof(s_elec_temp));
    memset(&s_elec_old_ts, 0, sizeof(s_elec_old_ts));
    load_elec();
    vesync_timebase_reg_info_upd_cb(timebase_info_upd_handle);
    save_elec_timer_cb(NULL);
    return APP_OK;
}

/**
 * @brief 获取历史电量
 * @param[in]   p_arry          [历史电量数组]
 * @param[in]   len             [数组长度]
 * @return      int             [错误码，成功/失败]
 * @note  电量数据以时间戳从大到小排列
 */
int outlet_get_history_elec(elec_per_day_t *p_arry, uint8_t len)
{
    timebase_info_t timebase_now;
    uint32_t last_history_ts = 0;
    uint32_t today_ts = 0;
    uint16_t index = 0;
    uint16_t today_hrs = ELEC_TODAY_STO_SIZE - 1;
    float today_elec = 0;
    float sum_elec = 0;

    VCOM_ERR_RET_CHK(p_arry, return APP_FAIL);
    VCOM_LEN_IS_TOO_LARGE(len, ELEC_HIST_STO_MAX + 1, return APP_FAIL); // 历史数据加上当天数据

    if (0 == len)
    {
        return APP_FAIL;
    }
    memset(p_arry, 0, len * sizeof(elec_per_day_t));

    if (TMBS_OK != vesync_timebase_get_cur_info(&timebase_now))
    {
        APP_LOG(LOG_WARN, "get timebase fail\n");
    }
    else
    {
        if (APP_OK == outlet_metering_get_electricity(OUTLET_SAVE_ELEC_USED_ELEC_UNIT, &today_elec))
        {
            today_ts = (timebase_now.local_ts - 1) / s_secs_per_day * s_secs_per_day;
            ELEC_DEBUG_D("today_ts = %ld, today_elec = %8f\n", today_ts, today_elec);
        }
        if (today_ts > s_elec_today.today_ts)
        {
            p_arry->record_ts = today_ts;
            p_arry->elec_per_day = today_elec;
            today_ts = 0;
            today_elec = 0;
            if (s_elec_today.today_ts > VCOM_SYSTEM_MIN_TS && s_elec_today.today_ts >= s_elec_history.record_ts)
            {
                --len;
                ++p_arry;
            }
        }
    }

    if (s_elec_today.today_ts > VCOM_SYSTEM_MIN_TS && s_elec_today.today_ts >= s_elec_history.record_ts)
    {
        if (today_ts == s_elec_today.today_ts)
        {
            sum_elec += today_elec;
            today_hrs = timebase_now.local_clk_sec / s_secs_per_hour;
            ELEC_DEBUG_D("today_hrs = %d\n", today_hrs);
            if (today_hrs >= ELEC_TODAY_STO_SIZE)    // 异常处理
            {
                today_hrs = ELEC_TODAY_STO_SIZE - 1;
            }
        }
        p_arry->record_ts = s_elec_today.today_ts;
        for (index = 0; index <= today_hrs; ++index)
        {
            sum_elec += s_elec_today.elec_per_hour[index];
        }
        p_arry->elec_per_day = sum_elec;
        ELEC_DEBUG_D("s_elec_today.today_ts = %ld, sum_elec = %8f\n", s_elec_today.today_ts, sum_elec);
    }

    if (s_elec_history.record_ts < VCOM_SYSTEM_MIN_TS)
    {
        if (p_arry->record_ts < VCOM_SYSTEM_MIN_TS)
        {
            return APP_FAIL;
        }
        // 历史数据填0
        while(--len)
        {
            ++p_arry;
            p_arry->record_ts = p_arry[-1].record_ts - s_secs_per_day;
            if (today_ts == p_arry->record_ts)
            {
                p_arry->elec_per_day = today_elec;
            }
            else
            {
                p_arry->elec_per_day = 0;
            }
        }
        return APP_OK;
    }

    last_history_ts = s_elec_history.record_ts - s_secs_per_day;  // 取最后一次记录当天的零点
    index = s_elec_history.index;
    while(--len)
    {
        ++p_arry;
        p_arry->elec_per_day = s_elec_history.elec_per_day[index];
        p_arry->record_ts = last_history_ts;
        if (last_history_ts == today_ts)
        {
            p_arry->elec_per_day += today_elec;
        }
        if (last_history_ts == s_elec_today.today_ts)
        {
            p_arry->elec_per_day += sum_elec;
        }
        index = (ELEC_HIST_STO_MAX + index - 1) % ELEC_HIST_STO_MAX;
        last_history_ts -= s_secs_per_day;
    }

    return APP_OK;
}

/**
 * @brief 清除历史电量
 * @return      int             [错误码，成功/失败]
 */
int outlet_clear_history_elec(void)
{
    int ret = APP_OK;
    if (VOS_OK == vesync_timer_stop(s_delay_report_timer))
    {
        s_delay_report_timer_period_ms = 0;
    }
    outlet_metering_clear_electricity(OUTLET_SAVE_ELEC_USED_ELEC_UNIT);
    vesync_mutex_lock(s_elec_lock);
    memset(&s_elec_today, 0, sizeof(s_elec_today));
    memset(&s_elec_history, 0, sizeof(s_elec_history));
    memset(&s_elec_temp, 0, sizeof(s_elec_temp));
    memset(&s_elec_delay_report_data, 0, sizeof(s_elec_delay_report_data));
    vesync_mutex_unlock(s_elec_lock);
    if (SDK_OK != vesync_flash_erase_key(PARTITION_CFG, ELEC_TODAY_DATA))
    {
        ret = APP_FAIL;
        APP_LOG(LOG_INFO, "erase flash err\n");
    }
    if (SDK_OK != vesync_flash_erase_key(PARTITION_CFG, ELEC_HIST_DATA))
    {
        ret = APP_FAIL;
        APP_LOG(LOG_INFO, "erase flash err\n");
    }
    if (SDK_OK != vesync_flash_erase_key(PARTITION_CFG, ELEC_REPORT_DATA))
    {
        ret = APP_FAIL;
        APP_LOG(LOG_INFO, "erase flash err\n");
    }
    return ret;
}

#if defined(PR_FW_TYPE) && (PR_FW_TYPE == 0)
#define ELEC_DEBUG_SECS_PER_HOUR_MIN        (60)
#define ELEC_DEBUG_SECS_PER_HOUR_MAX        (SECONDS_PER_HOUR)
#define ELEC_DEBUG_HRS_PER_DAY_MIN          (3)
#define ELEC_DEBUG_HRS_PER_DAY_MAX          (HOURS_PER_DAY)

int outlet_set_debug_secs_hrs(uint16_t secs_per_hour, uint8_t hrs_per_day)
{
    if (secs_per_hour < ELEC_DEBUG_SECS_PER_HOUR_MIN || secs_per_hour > ELEC_DEBUG_SECS_PER_HOUR_MAX ||
        hrs_per_day < ELEC_DEBUG_HRS_PER_DAY_MIN || hrs_per_day > ELEC_DEBUG_HRS_PER_DAY_MAX)
    {
        APP_LOG(LOG_ERROR, "out of range\n");
        return APP_FAIL;
    }
    vesync_mutex_lock(s_debug_lock);
    s_secs_per_hour = secs_per_hour;
    s_secs_per_day = secs_per_hour * hrs_per_day;
    vesync_mutex_unlock(s_debug_lock);
    return APP_OK;
}

uint32_t outlet_get_debug_secs_per_day(void)
{
    return s_secs_per_day;
}

#endif

