/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file    vesync_light.c
* @brief   灯光照明控制模块实现
* @author  Herve
* @date    2021-11-09
*/
#include <stdio.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <math.h>

#include "vesync_memory.h"
#include "vesync_common.h"
#include "vesync_log_internal.h"

#include "vesync_light_internal.h"
#include "vesync_light_timer.h"

/**
 * @brief 底层获取通道PWM控制量的封装
 * @param[in] p_light       [指向目标灯光控制器]
 * @param[in] ch_idx        [目标通道号]
 * @return uint32_t         [通道当前的PWM控制量]
 */
static uint32_t light_ch_ll_get(light_t *p_light, uint8_t ch_idx)
{
    return p_light->curr_duty[ch_idx];
}

/**
 * @brief 底层设置通道PWM控制量的封装
 * @param[in] p_light       [指向目标灯光控制器]
 * @param[in] ch_idx        [目标通道号]
 * @param[in] duty          [输出的PWM控制量]
 */
static void light_ch_ll_set(light_t *p_light, int ch_idx, uint32_t duty)
{
    p_light->curr_duty[ch_idx] = duty;
}

/**
 * @brief 将缓存的占空比刷入所有通道
 * @param[in] p_light       [指向目标灯光控制器]
 */
static void light_ch_burst(light_t *p_light)
{
    p_light->ch_ctrl_cb(p_light->cb_arg, p_light->ch_num, p_light->curr_duty);
}

/**
 * @brief 灯光控制器的定时调度主体函数
 * @param[in] arg           [回调的灯光控制器对象]
 */
static void heartbeat_timer_cb(void *arg)
{
    light_t *p_light = (light_t *)arg;
    if (NULL == p_light)
    {
        return;
    }

    LIGHT_CB_LOCK(p_light->mutex);

    bool is_all_ch_stop = true;
    bool should_flush = false;
    for (int ch_idx = 0; ch_idx < p_light->ch_num; ch_idx++)
    {
        if (NULL == p_light->ch_grp[ch_idx])
        {
            continue;
        }

        light_ch_t *p_l_chn = p_light->ch_grp[ch_idx];
        if (false == p_l_chn->fade_start)
        {
            continue;
        }
        is_all_ch_stop = false;

        if ((p_l_chn->fade_cnt >= 0) && (p_l_chn->fade_cnt < p_l_chn->fade_step_num))
        {
            should_flush = true;
            p_light->curr_duty[ch_idx] = p_l_chn->fade_steps[p_l_chn->fade_cnt];
        }
        else
        {
            if (p_l_chn->semicycle_cnt != 0)
            {
                p_l_chn->semicycle_cnt--;
            }

            if ((false == p_l_chn->is_rpt) && (p_l_chn->semicycle_cnt == 0))
            {
                p_l_chn->fade_start = false;
            }
            else
            {
                if (false == p_l_chn->fade_up)
                {
                    // 去除顶重叠
                    p_l_chn->fade_cnt++;
                }
                else
                {
                    // 去除底重叠
                    p_l_chn->fade_cnt--;
                }
                // 半周期结束，如果是渐变或者呼吸模式将反转渐变方向
                p_l_chn->fade_up = !p_l_chn->fade_up;
            }
        }
        if (true == p_l_chn->fade_up)
        {
            p_l_chn->fade_cnt++;
        }
        else
        {
            p_l_chn->fade_cnt--;
        }
    }

    if (true == should_flush)
    {
        light_ch_burst(p_light);
    }
    if (true == is_all_ch_stop)
    {
        light_timer_stop(p_light->timer);
        p_light->timer_start = false;
    }
    LIGHT_UNLOCK(p_light->mutex);
}

/**
 * @brief 销毁一个通道
 * @param[in] p_l_chn       [指向应销毁通道]
 * @return int              [LIGHT_RESULT_E]
 */
static int light_ch_destroy(light_ch_t *p_l_chn)
{
    if (p_l_chn->fade_steps != NULL)
    {
        vesync_free(p_l_chn->fade_steps);
        p_l_chn->fade_steps = NULL;
    }

    vesync_free(p_l_chn);
    return LIGHT_OK;
}

/**
 * @brief 创建一个通道
 * @return light_ch_t*      [返回创建的通道引用]
 * @return NULL             [创建失败]
 */
static light_ch_t *light_ch_create(void)
{
    light_ch_t *p_l_chn = (light_ch_t *)vesync_calloc(1, sizeof(light_ch_t));
    LIGHT_CHECK(p_l_chn != NULL, NULL);

    p_l_chn->gamma = 1.0;
    p_l_chn->fade_step_num = 0;
    p_l_chn->fade_steps = NULL;
    p_l_chn->fade_cnt = 0;
    p_l_chn->fade_up = true;
    p_l_chn->is_rpt = false;
    p_l_chn->fade_start = false;
    return p_l_chn;
}


/**
 * @brief 直接对该灯光控制器的响应通道输出PWM控制量
 * @note 该函数会停止渐变流程并清除渐变流程的上下文
 * @param[in] p_light       [指向目标灯光控制器]
 * @param[in] ch_idx        [目标通道号]
 * @param[in] duty          [应输出PWM控制量]
 * @return int              [LIGHT_RESULT_E]
 */
static int light_duty_direct_set(light_t *p_light, uint8_t ch_idx, uint32_t duty)
{
    light_ch_fade_clr(p_light->ch_grp[ch_idx]);
    light_ch_ll_set(p_light, ch_idx, duty);
    return LIGHT_OK;
}


int light_ch_fade_clr(light_ch_t *p_l_chn)
{
    p_l_chn->fade_start = false;
    p_l_chn->fade_step_num = 0;
    p_l_chn->fade_cnt = 0;
    p_l_chn->fade_up = true;
    p_l_chn->is_rpt = false;

    if (p_l_chn->fade_steps != NULL)
    {
        vesync_free(p_l_chn->fade_steps);
        p_l_chn->fade_steps = NULL;
    }

    return LIGHT_OK;
}

light_t *light_obj_create(uint16_t ch_num, uint32_t step_intvl, uint32_t max_duty, vesync_light_ctrl_cb_t ch_ctrl_cb, void *cb_arg)
{
    light_t *p_light = (light_t *)vesync_calloc(1, sizeof(light_t) + sizeof(light_ch_t *) * ch_num);
    LIGHT_CHECK(p_light != NULL, NULL);

    p_light->curr_duty = (uint32_t *)vesync_calloc(1, ch_num * sizeof(uint32_t));
    if (p_light->curr_duty == NULL)
    {
        VCOM_SAFE_FREE(p_light);
        return NULL;
    }

    p_light->max_duty = max_duty;
    p_light->ch_num = ch_num;
    p_light->ch_ctrl_cb = (ch_ctrl_cb_t)ch_ctrl_cb;
    p_light->cb_arg = cb_arg;

    p_light->timer_intvl = step_intvl;
    p_light->timer_start = false;
    p_light->timer = light_timer_new(true,
                                     p_light->timer_intvl,
                                     heartbeat_timer_cb,
                                     p_light);
    if (NULL == p_light->timer)
    {
        SDK_LOG(LOG_ERROR, "timer_create fail\n");
        goto EXIT;
    }

    p_light->mutex = LIGHT_NEW_LOCK();
    if (NULL == p_light->mutex)
    {
        SDK_LOG(LOG_ERROR, "mutex_new fail\n");
        goto EXIT;
    }

    for (int i = 0; i < ch_num; i++)
    {
        p_light->ch_grp[i] = light_ch_create();
        if (NULL == p_light->ch_grp[i])
        {
            SDK_LOG(LOG_ERROR, "create ch[%d] fail\n", i);
            goto EXIT;
        }
    }
    return p_light;

EXIT:
    light_timer_del(p_light->timer);
    vesync_mutex_free(p_light->mutex);

    vesync_free(p_light->curr_duty);
    vesync_free(p_light);
    return NULL;
}

int light_obj_destroy(light_t *p_obj)
{
    LIGHT_LOCK(p_obj->mutex);

    int ret = LIGHT_OK;
    if (true == p_obj->timer_start)
    {
        ret = light_timer_stop(p_obj->timer);
        if (ret != LIGHT_OK)
        {
            goto EXIT;
        }
        p_obj->timer_start = false;
    }

    ret = light_timer_del(p_obj->timer);
    if (ret != LIGHT_OK)
    {
        goto EXIT;
    }

    for (int i = 0; i < p_obj->ch_num; i++)
    {
        if (NULL != p_obj->ch_grp[i])
        {
            // 将通道PWM输出置零
            light_duty_direct_set(p_obj, i, 0);
            // 逐一销毁PWM通道
            ret = light_ch_destroy(p_obj->ch_grp[i]);
            if (ret != LIGHT_OK)
            {
                goto EXIT;
            }
            p_obj->ch_grp[i] = NULL;
        }
    }
    light_ch_burst(p_obj);

    // 释放通道PWM控制量缓存
    vesync_free(p_obj->curr_duty);

EXIT:
    LIGHT_UNLOCK(p_obj->mutex);
    if (LIGHT_OK == ret)
    {
        LIGHT_DEL_LOCK(p_obj->mutex);
        vesync_free(p_obj);
    }
    return ret;
}

int light_obj_get_duty(light_t *p_obj, uint16_t ch_idx, uint32_t *p_duty)
{
    LIGHT_LOCK(p_obj->mutex);
    LIGHT_CHECK_ACTION(ch_idx < p_obj->ch_num, LIGHT_UNLOCK(p_obj->mutex); return LIGHT_INV_CH);

    *p_duty = light_ch_ll_get(p_obj, ch_idx);
    LIGHT_UNLOCK(p_obj->mutex);
    return LIGHT_OK;
}

int light_obj_set_gamma(light_t *p_obj, uint16_t ch_idx, float gamma)
{
    LIGHT_LOCK(p_obj->mutex);
    LIGHT_CHECK_ACTION(ch_idx < p_obj->ch_num, LIGHT_UNLOCK(p_obj->mutex); return LIGHT_INV_CH);

    p_obj->ch_grp[ch_idx]->gamma = gamma;
    LIGHT_UNLOCK(p_obj->mutex);
    return LIGHT_OK;
}

int light_obj_start(light_t *p_obj, uint16_t ch_idx)
{
    LIGHT_LOCK(p_obj->mutex);
    LIGHT_CHECK_ACTION(ch_idx < p_obj->ch_num, LIGHT_UNLOCK(p_obj->mutex); return LIGHT_INV_CH);

    light_ch_t *p_l_chn = p_obj->ch_grp[ch_idx];
    p_l_chn->fade_start = true;

    if (false == p_obj->timer_start)
    {
        light_timer_start(p_obj->timer);
        p_obj->timer_start = true;
    }

    LIGHT_UNLOCK(p_obj->mutex);
    return LIGHT_OK;
}

int light_obj_stop(light_t *p_obj, uint16_t ch_idx)
{
    LIGHT_LOCK(p_obj->mutex);
    LIGHT_CHECK_ACTION(ch_idx < p_obj->ch_num, LIGHT_UNLOCK(p_obj->mutex); return LIGHT_INV_CH);

    bool is_all_ch_stop = true;
    for (int i = 0; i < p_obj->ch_num; i++)
    {
        light_ch_t *p_l_chn = p_obj->ch_grp[i];
        if (true == p_l_chn->fade_start)
        {
            if (i == ch_idx)
            {
                p_l_chn->fade_start = false;
            }
            else
            {
                is_all_ch_stop = false;
            }
        }
    }

    if (true == is_all_ch_stop && true == p_obj->timer_start)
    {
        light_timer_stop(p_obj->timer);
        p_obj->timer_start = false;
    }

    LIGHT_UNLOCK(p_obj->mutex);
    return LIGHT_OK;
}
