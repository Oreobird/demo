/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_away.c
 * @brief       Away 模块实现
 * @author      Herve.Lin
 * @date        2021-06-28
 */
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#include "vhal_utils.h"

#include "vesync_timer.h"
#include "vesync_memory.h"
#include "vesync_common.h"
#include "vesync_timebase_internal.h"
#include "vesync_log_internal.h"
#include "vesync_away_internal.h"


#define AWAY_SECONDS_OF_TEN_MIN (600)   // 十分钟的秒数

// 检查输入回调函数参数是否为空。非空则返回原输入回调函数，空则返回相应的缺省回调函数
#define CHECK_AND_GET_CB(cb, default) ((NULL == (cb)) ? (default) : (cb))

// 全局Away管理变量
static away_mgt_t s_away_mgt = AWAY_MGT_INIT_VAL;
// 全局Away参数缓存
static vesync_away_param_t s_away_param;

#if AWAY_DEBUG_PRINT == 1
/**
 * @brief 打印Away配置
 * @param[in] p_away_cfg    [指向Away配置]
 */
static void print_away_cfg(vesync_away_t *p_away_cfg)
{
    SDK_LOG(LOG_DEBUG, "start_clk_sec: %ld, end_clk_sec: %ld, repeat_config: %d.\n",
            p_away_cfg->start_clk_sec, p_away_cfg->end_clk_sec, p_away_cfg->repeat_config);
}

/**
 * @brief 打印Away时间表
 * @param[in] p_rt          [指向Away时间表]
 */
static void print_away_rnd_times(vesync_away_tp_t *p_rt)
{
    char buffer[64];
    char num[12];

    memset(buffer, 0, 64);

    for (uint32_t cnt = 0; cnt < p_rt->point_num; cnt++)
    {
        snprintf(num, 12, "%d ", (int)p_rt->points[cnt]);
        strncat(buffer, num, 64 - strlen(buffer));
    }

    SDK_LOG(LOG_DEBUG, "exec_cnt: %d, tp_num:%d, tps: %s\n",
            p_rt->exec_cnt, p_rt->point_num, buffer);
}

/**
 * @brief 打印Away管理器数据
 * @param[in] p_mgt         [指向Away管理器]
 */
static void print_away_mgt(away_mgt_t *p_mgt)
{
    SDK_LOG(LOG_DEBUG, "enable: %d, cfg_mod_local_ts: %d, tp_gen_local_ts: %d\n",
            p_mgt->enable, p_mgt->modify_local_ts, p_mgt->generated_local_ts);

    print_away_cfg(&p_mgt->config);
    print_away_rnd_times(&p_mgt->rnd_times);
}
#endif /* AWAY_DEBUG_PRINT == 1 */

/**
 * @brief 生成随机时间表
 * @param[in]  p_away_cfg   [输入的Away配置]
 * @param[out] p_rnd_times  [输出生成的时间表]
 */
static void away_random_times_generate(vesync_away_t *p_away_cfg, vesync_away_tp_t *p_rnd_times)
{
    // 生成的随机时间间隔缓存
    uint32_t rt_temp_points[AWAY_RANDOM_TIME_MAX_NUM] = {0};

    uint32_t time_point_num = 0, count = 0;
    uint32_t old_tick_second = 0, tick_second = 0, tick_random = 0;
    uint32_t interval = 0;

    interval = p_away_cfg->end_clk_sec - p_away_cfg->start_clk_sec;

    // 大于10分钟才开关3次
    if (interval > AWAY_SECONDS_OF_TEN_MIN)
    {
        time_point_num = AWAY_RANDOM_TIME_MAX_NUM;
    }
    else
    {
        time_point_num = AWAY_RANDOM_TIME_MIN_NUM;
    }

    for (count = 0; count < time_point_num; count++)
    {
        tick_second = interval / 7;
        tick_random = rand() % (tick_second / 2 + 1) + 1;
        if (count % 2)
        {
            tick_second += tick_random;
        }
        else
        {
            tick_second -= tick_random;
        }

        if ((1 == count) && (AWAY_RANDOM_TIME_MIN_NUM == time_point_num))
        {
            rt_temp_points[count] = interval - tick_second - old_tick_second;
        }
        else
        {
            rt_temp_points[count] = tick_second;
        }
        old_tick_second = tick_second;
    }

    // 确保间隔不会小于 1 分钟
    for (count = 0; count < time_point_num; count++)
    {
        if (rt_temp_points[count] < VCOM_SECOND_PER_MIN)
        {
            rt_temp_points[count] = VCOM_SECOND_PER_MIN;
        }
    }

    // 保存6个(/2个)执行时间点
    p_rnd_times->point_num = time_point_num;

    // 把生成的随机时间间隔换算成时刻值
    // 第1个点，后续的进行累加
    p_rnd_times->points[0] = p_away_cfg->start_clk_sec + rt_temp_points[0];
    for (count = 1; count < time_point_num; count++)
    {
        p_rnd_times->points[count] = p_rnd_times->points[count - 1] + rt_temp_points[count];
    }
}

/**
 * @brief 基于分钟比较两个时间戳
 * @param[in] ts_a
 * @param[in] ts_b
 * @return int32_t  [返回值>0 - ts_a > ts_b；
 *                   返回值=0 - ts_a = ts_b；
 *                   返回值<0 - ts_a < ts_b]
 */
static inline int32_t ts_min_cmp(uint32_t ts_a, uint32_t ts_b)
{
    uint32_t ts_a_min = ts_a / (uint32_t)VCOM_SECOND_PER_MIN;
    uint32_t ts_b_min = ts_b / (uint32_t)VCOM_SECOND_PER_MIN;

    return (int32_t)ts_a_min - (int32_t)ts_b_min;
}

/**
 * @brief 把序列化的配置信息读取到Away实例中
 * @return int  [AWAY_RESULT_E]
 */
static int rd_nvm_cfg_to_away_mgt(void)
{
    int ret = AWAY_OK;

    // 读取配置长度
    uint32_t cfg_len;
    ret = s_away_param.rd_cfg_cb(NULL, 0, &cfg_len);
    if (AWAY_OK != ret)
    {
        return AWAY_CFG_ERR;
    }
    if (0 == cfg_len)
    {
        return AWAY_CFG_NO_EXIST;
    }
#if AWAY_DEBUG_PRINT == 1
    SDK_LOG(LOG_DEBUG, "config len:[%ld]\r\n", cfg_len);
#endif

    // 申请缓存
    uint8_t *p_buf = (uint8_t *)vesync_malloc(cfg_len);
    if (NULL == p_buf)
    {
        SDK_LOG(LOG_ERROR, "config buffer malloc fail\n");
        return AWAY_MEM_ERR;
    }

    // 读取配置信息
    uint32_t rd_len;
    ret = s_away_param.rd_cfg_cb(p_buf, cfg_len, &rd_len);
    if (AWAY_OK != ret)
    {
        goto EXIT;
    }
#if AWAY_DEBUG_PRINT == 1
    SDK_LOG(LOG_DEBUG, "config read, size[%ld]\n", cfg_len);
#endif
    if (rd_len != cfg_len)
    {
        ret = AWAY_CFG_NO_EXIST;
        goto EXIT;
    }
    // 将配置应用到 Away 实例
    ret = away_cfg_unmarshal(p_buf, cfg_len, &s_away_mgt);
    if (AWAY_OK != ret)
    {
        goto EXIT;
    }

EXIT:
    vesync_free(p_buf);
    return ret;
}

/**
 * @brief 把Away实例中的配置信息序列化
 * @return int  [AWAY_RESULT_E]
 */
static int wr_away_mgt_cfg_to_nvm(void)
{
    int ret = AWAY_OK;

    // 计算Buffer
    uint32_t cfg_len;
    ret = away_cfg_marshal(&s_away_mgt, NULL, 0, &cfg_len);
    if (AWAY_OK != ret)
    {
        return AWAY_CFG_ERR;
    }
#if AWAY_DEBUG_PRINT == 1
    SDK_LOG(LOG_DEBUG, "config len:[%ld]\r\n", cfg_len);
#endif

    // 申请缓存
    uint8_t *p_buf = (uint8_t *)vesync_malloc(cfg_len);
    if (NULL == p_buf)
    {
        SDK_LOG(LOG_ERROR, "config buffer malloc fail\n");
        return AWAY_MEM_ERR;
    }

    // 序列化 Away 实例中的配置信息
    uint32_t wr_len = 0;
    ret = away_cfg_marshal(&s_away_mgt, p_buf, cfg_len, &wr_len);
    if (AWAY_OK != ret)
    {
        goto EXIT;
    }
#if AWAY_DEBUG_PRINT == 1
    SDK_LOG(LOG_DEBUG, "config wrote, size[%ld]\n", cfg_len);
#endif
    if (wr_len != cfg_len)
    {
        ret = AWAY_CFG_ERR;
        goto EXIT;
    }

    // 写入配置
    ret = s_away_param.wr_cfg_cb(p_buf, cfg_len);
    if (AWAY_OK != ret)
    {
        goto EXIT;
    }

EXIT:
    vesync_free(p_buf);
    return ret;
}

/**
 * @brief Away调度器Timer Callback Function
 * @param[in] arg [回调参数]
 */
static void away_cycle_loop(void *arg)
{
    UNUSED(arg);

    // 读取系统UTC时间
    uint32_t now_utc = vhal_utils_get_system_time_sec();

    // 确保一分钟只执行一次的定时任务
    static uint32_t last_loop_min = 0;
    if (now_utc / VCOM_SECOND_PER_MIN == last_loop_min)
    {
        return;
    }
    else
    {
        // 更新分钟计数
        last_loop_min = now_utc / VCOM_SECOND_PER_MIN;
    }

    timebase_info_t tb_info;
    if (TMBS_OK != vesync_timebase_get_info(now_utc, &tb_info))
    {
#if AWAY_DEBUG_PRINT == 1
        SDK_LOG(LOG_WARN, "get timebase fail\n");
#endif
        return;
    }

    if (VOS_OK != vesync_mutex_lock(s_away_mgt.mutex))
    {
        return;
    }

    // 实例中的配置内容是否变更的标志位
    bool cfg_changed = false;

    // 判断Away的配置是否有效
    if (!s_away_mgt.enable)
    {
        goto SKIP_THIS_LOOP;
    }

    uint32_t now_local_ts = tb_info.local_ts;
    uint32_t now_local_clk_sec = now_local_ts % VCOM_SECOND_PER_DAY;
    uint32_t now_local_day = now_local_ts / VCOM_SECOND_PER_DAY;
    uint8_t now_local_weekday = vesync_timebase_ts_to_weekday(tb_info.local_ts, 0);

#if AWAY_DEBUG_PRINT == 1
    SDK_LOG(LOG_DEBUG, "local_clock_sec: %ld, local_day: %ld, local_weekday=%d\n",
            now_local_clk_sec, now_local_day, now_local_weekday);
#endif

    // 如果是Once的Away，判断是否过期失效了
    if (!s_away_mgt.config.repeat_config)
    {
        if (s_away_mgt.modify_local_ts + VCOM_SECOND_PER_DAY < now_local_ts)
        {
            // 使配置无效
            s_away_mgt.enable = false;
            cfg_changed = true;

            SDK_LOG(LOG_WARN, "task expired. away_mod_local_ts:%ld, now_local_ts:%ld\n", \
                    s_away_mgt.modify_local_ts, now_local_ts);

            // 过期任务不执行
            goto SKIP_THIS_LOOP;
        }
    }

    // 计算随机时间表创建的第几天数
    uint32_t rt_gen_day = s_away_mgt.generated_local_ts / VCOM_SECOND_PER_DAY;
    // 判断随机时间表是不是过期失效了
    if (rt_gen_day < now_local_day)
    {
        /// @todo: 随机数部分接口 to be wrapped
        // 设置随机数种子
        srand((unsigned int)now_utc);
        // 时间表过期，重新生成时间表
        away_random_times_generate(&s_away_mgt.config, &s_away_mgt.rnd_times);
        // 更新时间记录
        s_away_mgt.generated_local_ts = now_local_ts;

        cfg_changed = true;

#if AWAY_DEBUG_PRINT == 1
        SDK_LOG(LOG_DEBUG, "new rand times generates. rt_point_nbr: %ld:\n", s_away_mgt.rnd_times.point_num);
        for (uint32_t cnt = 0; cnt < s_away_mgt.rnd_times.point_num; cnt++)
        {
            SDK_LOG(LOG_DEBUG, "new rand times - point[%ld]-clk_sec: %ld\n",
                    cnt, s_away_mgt.rnd_times.points[cnt]);
        }
#endif
    }

    if (now_local_clk_sec < s_away_mgt.config.start_clk_sec)
    {
        goto SKIP_THIS_LOOP;
    }

    if (now_local_clk_sec > s_away_mgt.config.end_clk_sec)
    {
        goto SKIP_THIS_LOOP;
    }

    // Weekly的任务要判断星期
    if (s_away_mgt.config.repeat_config)
    {
        // 判断星期是否触发
        if (!(s_away_mgt.config.repeat_config & now_local_weekday))
        {
            goto SKIP_THIS_LOOP;
        }
    }

    AWAY_EVENT_E event = AWAY_START_ACTION;
    // 遍历随机时间表
    for (uint32_t cnt = 0; cnt < s_away_mgt.rnd_times.point_num; cnt++)
    {
        // 偶数为开，奇数为关
        if (0 == (cnt % 2))
        {
            event = AWAY_RANDOM_ON;
        }
        else
        {
            event = AWAY_RANDOM_OFF;
        }

        if (0 == cnt)
        {
            // 开始动作
            event = AWAY_START_ACTION;
        }
        else if ((s_away_mgt.rnd_times.point_num - 1) == cnt)
        {
            // 结束动作
            event = AWAY_END_ACTION;
        }

        // 对比时间点
        if (0 == ts_min_cmp(s_away_mgt.rnd_times.points[cnt], now_local_clk_sec))
        {
            s_away_param.exec_app_task_cb(&s_away_mgt.config, &s_away_mgt.rnd_times, event);

            // Once类型的Away最后一个任务执行完会失能任务
            if (event == AWAY_END_ACTION)
            {
                if (!s_away_mgt.config.repeat_config)
                {
                    s_away_mgt.enable = false;
                }
                s_away_mgt.rnd_times.exec_cnt++;
                cfg_changed = true;
            }

#if AWAY_DEBUG_PRINT == 1
            SDK_LOG(LOG_DEBUG, "task executed. event:[%d], point[%ld]-clk_sec: %ld\n",
                    event, cnt, s_away_mgt.rnd_times.points[cnt]);
#endif
            // 已经执行了任务，跳出遍历
            break;
        }
    }

SKIP_THIS_LOOP:
    if (cfg_changed)
    {
        wr_away_mgt_cfg_to_nvm();
    }
    vesync_mutex_unlock(s_away_mgt.mutex);
}

/**
 * @brief 启动Away调度器
 */
static void away_cycle_start(void)
{
    if (s_away_mgt.is_running)
    {
        return;
    }

    s_away_mgt.timer = vesync_timer_new("timer",
                                        away_cycle_loop,
                                        NULL,
                                        AWAY_CYCLE_TIMER_INTERVAL,
                                        true);
    if (NULL == s_away_mgt.timer)
    {
        SDK_LOG(LOG_ERROR, "creat timer fail\n");
        return;
    }
    if (VOS_OK != vesync_timer_start(s_away_mgt.timer))
    {
        SDK_LOG(LOG_ERROR, "start timer fail\n");
        vesync_timer_free(s_away_mgt.timer);
        s_away_mgt.timer = NULL;
        return;
    }

    s_away_mgt.is_running = true;
}

/**
 * @brief 停止Away调度器
 */
static void away_cycle_stop(void)
{
    if (!s_away_mgt.is_running)
    {
        return;
    }

    if (VOS_OK != vesync_timer_free(s_away_mgt.timer))
    {
        SDK_LOG(LOG_ERROR, "stop timer fail\n");
        return;
    }
    s_away_mgt.timer = NULL;

    s_away_mgt.is_running = false;
}

/**
 * @brief Away 初始化
 * @param[in] p_away_cbs    [Away 初始化注册的回调函数]
 * @return int              [AWAY_RESULT_E]
 */
int vesync_away_init(vesync_away_param_t *p_away_cbs)
{
    if (s_away_mgt.is_init)
    {
        return AWAY_ERR;
    }

    memset(&s_away_param, 0, sizeof(vesync_away_param_t));
    s_away_param.rd_cfg_cb = CHECK_AND_GET_CB(p_away_cbs->rd_cfg_cb, away_default_rd_cfg_cb);
    s_away_param.wr_cfg_cb = CHECK_AND_GET_CB(p_away_cbs->wr_cfg_cb, away_default_wr_cfg_cb);

    if (p_away_cbs->exec_app_task_cb == NULL)
    {
        return AWAY_ERR;
    }
    s_away_param.exec_app_task_cb = p_away_cbs->exec_app_task_cb;

    memset(&s_away_mgt, 0, sizeof(away_mgt_t));
    s_away_mgt.is_init = false;
    s_away_mgt.is_running = false;

    // 读取配置并应用到 Away 实例
    int ret = rd_nvm_cfg_to_away_mgt();
    if (AWAY_OK != ret)
    {
        if (AWAY_CFG_NO_EXIST != ret)
        {
            return ret;
        }

        SDK_LOG(LOG_INFO, "config no found\n");

        // 处理配置不存在的情况
        s_away_mgt.enable = false;
        s_away_mgt.modify_local_ts = 0;
        s_away_mgt.generated_local_ts = 0;
    }

    s_away_mgt.mutex = vesync_mutex_new();
    if (NULL == s_away_mgt.mutex)
    {
        return AWAY_ERR;
    }
    //
    s_away_mgt.is_init = true;

    // 启动调度器
    away_cycle_start();

    UNUSED(away_cycle_stop);

#if AWAY_DEBUG_PRINT == 1
    print_away_mgt(&s_away_mgt);
#endif

    return AWAY_OK;
}

/**
 * @brief Away 添加设置
 * @param[in] p_away_cfg    [输入的 Away 配置]
 * @return int              [AWAY_RESULT_E]
 */
int vesync_away_add(vesync_away_t *p_away_cfg)
{
    if (NULL == p_away_cfg)
    {
        return AWAY_ERR;
    }

    uint32_t now_utc = vhal_utils_get_system_time_sec();
    timebase_info_t tb_info;
    if (TMBS_OK != vesync_timebase_get_info(now_utc, &tb_info) || VOS_OK != vesync_mutex_lock(s_away_mgt.mutex))
    {
        return AWAY_ERR;
    }

    int ret = AWAY_OK;
    if (s_away_mgt.enable)
    {
        ret = AWAY_EXIST_ERR;
        goto EXIT;
    }

    // 结束时间一定要大于开始时间
    if (0 >= ts_min_cmp(p_away_cfg->end_clk_sec, p_away_cfg->start_clk_sec))
    {
        ret = AWAY_PAR_INV;
        goto EXIT;
    }

    s_away_mgt.config.repeat_config = p_away_cfg->repeat_config;
    s_away_mgt.config.start_clk_sec = p_away_cfg->start_clk_sec;
    s_away_mgt.config.end_clk_sec = p_away_cfg->end_clk_sec;

    // 初始化上下文缓存
    s_away_mgt.rnd_times.exec_cnt = 0;
    s_away_mgt.modify_local_ts = tb_info.local_ts;
    s_away_mgt.enable = true;

    // 复位随机时间表的生成记录
    s_away_mgt.generated_local_ts = 0;

    // 持久化
    ret = wr_away_mgt_cfg_to_nvm();
    if (AWAY_OK != ret)
    {
        goto EXIT;
    }

EXIT:
    vesync_mutex_unlock(s_away_mgt.mutex);
    return ret;
}

/**
 * @brief Away 删除配置
 * @return int  [AWAY_RESULT_E]
 */
int vesync_away_del(void)
{
    int ret = AWAY_OK;

    if (VOS_OK != vesync_mutex_lock(s_away_mgt.mutex))
    {
        return AWAY_ERR;
    }

    // 检查有没有使能
    if (!s_away_mgt.enable)
    {
        ret = AWAY_NO_EXIST;
        goto EXIT;
    }

    // 失能配置
    s_away_mgt.enable = false;

    // 持久化
    ret = wr_away_mgt_cfg_to_nvm();
    if (AWAY_OK != ret)
    {
        goto EXIT;
    }

EXIT:
    vesync_mutex_unlock(s_away_mgt.mutex);
    return ret;
}

/**
 * @brief Away 读取配置
 * @param[out] p_away_cfg     [读取出来的Away配置]
 * @param[out] p_rt_clock_sec [读取出来的Away目前使用的随机时间表]
 * @return int                [AWAY_RESULT_E， AWAY_NO_EXIST：读取失败，没有Away配置]
 */
int vesync_away_get(vesync_away_t *p_away_cfg, vesync_away_tp_t *p_rt_clock_sec)
{
    int ret = AWAY_OK;

    if (VOS_OK != vesync_mutex_lock(s_away_mgt.mutex))
    {
        return AWAY_ERR;
    }

    if (!s_away_mgt.enable)
    {
        ret = AWAY_NO_EXIST;
        goto EXIT;
    }

    if (NULL != p_away_cfg)
    {
        // 读Away配置
        p_away_cfg->repeat_config = s_away_mgt.config.repeat_config;
        p_away_cfg->start_clk_sec = s_away_mgt.config.start_clk_sec;
        p_away_cfg->end_clk_sec = s_away_mgt.config.end_clk_sec;
    }

    if (NULL != p_rt_clock_sec)
    {
        // 读Away执行的随机时间表
        p_rt_clock_sec->point_num = s_away_mgt.rnd_times.point_num;
        for (uint8_t cnt = 0; cnt < p_rt_clock_sec->point_num; cnt ++)
        {
            p_rt_clock_sec->points[cnt] = s_away_mgt.rnd_times.points[cnt];
        }
    }

#if AWAY_DEBUG_PRINT == 1
    print_away_cfg(&s_away_mgt.config);
#else
    SDK_LOG(LOG_INFO, "away gets done\n");
#endif

EXIT:
    vesync_mutex_unlock(s_away_mgt.mutex);
    return ret;
}

int vesync_away_clear(void)
{
    int ret = AWAY_OK;

    if (VOS_OK != vesync_mutex_lock(s_away_mgt.mutex))
    {
        return AWAY_ERR;
    }

    s_away_mgt.enable = false;
    s_away_mgt.generated_local_ts = 0;
    s_away_mgt.modify_local_ts = 0;
    memset(&s_away_mgt.config, 0, sizeof(vesync_away_t));
    memset(&s_away_mgt.rnd_times, 0, sizeof(vesync_away_tp_t));

    // 持久化
    ret = wr_away_mgt_cfg_to_nvm();
    if (AWAY_OK != ret)
    {
        goto EXIT;
    }

#if AWAY_DEBUG_PRINT == 1
    SDK_LOG(LOG_DEBUG, "away clear all\n");
#else
    SDK_LOG(LOG_INFO, "away clear all\n");
#endif

EXIT:
    vesync_mutex_unlock(s_away_mgt.mutex);
    return ret;
}
