/**
 * Copyright © Etekcity Technologies Co., Ltd. 2021. All rights reserved.
 * @file        vesync_flash.c
 * @brief       处理ffs flash读写
 * @author      Joshua
 * @date        2021-05-28
 */

#include "vesync_common.h"
#include "vhal_flash.h"
#include "vesync_log_internal.h"
#include "vesync_net_service_internal.h"
#include "vesync_ffs_internal.h"
#include "ffs_flash.h"

/**
 * @brief 读取"DHA private key"
 * @param[out] char            [保存private key的缓存]
 * @param[in]  int             [缓存长度]
 * @return     int             [成功/失败]
 */
int vesync_ffs_flash_read_dha_private_key(char *p_key, int* buf_len)
{
    //note : p_key 为null，代表仅读取长度
    int ret = 0;
    VCOM_NULL_PARAM_CHK(buf_len, return SDK_FAIL);

    ret = vhal_flash_read(PARTITION_CFG, USER_CFG_KEY_FFS_PRIVATE_KEY, (uint8_t *)p_key, (uint32_t *)buf_len);
    if (ret != VHAL_OK)
    {
        return SDK_FAIL;
    }

    return SDK_OK;
}

/**
 * @brief 写"DHA private key"
 * @param[in]  char            [待写入的private key]
 * @param[in]  int             [长度]
 * @return     int             [成功/失败]
 */
int vesync_ffs_flash_write_dha_private_key(char *p_key, int buf_len)
{
    int ret = 0;
    VCOM_NULL_PARAM_CHK(p_key, return SDK_FAIL);

    ret = vhal_flash_write(PARTITION_CFG, USER_CFG_KEY_FFS_PRIVATE_KEY, (uint8_t *)p_key, buf_len);
    if (VHAL_OK != ret)
    {
        VERR_UPLOAD(VERR_FLASH_WRITE_FAIL, 0);
        return SDK_FAIL;
    }

    return SDK_OK;
}

/**
 * @brief 读取"certificate chain"
 * @param[out] char            [保存certificate chain的缓存]
 * @param[in]  int             [缓存长度]
 * @return     int             [成功/失败]
 */
int vesync_ffs_flash_read_cert_chain(char *p_key, int *buf_len)
{
    //note : p_key 为null，代表仅读取长度
    int ret = 0;
    VCOM_NULL_PARAM_CHK(buf_len, return SDK_FAIL);

    ret = vhal_flash_read(PARTITION_CFG, USER_CFG_KEY_FFS_CLIENT_CHAIN, (uint8_t *)p_key, (uint32_t *)buf_len);
    if (ret != VHAL_OK)
    {
        return SDK_FAIL;
    }

    return SDK_OK;

}

/**
 * @brief 写"certificate chain"
 * @param[in]  char            [待写入的certificate chain]
 * @param[in]  int             [长度]
 * @return     int             [成功/失败]
 */
int vesync_ffs_flash_write_cert_chain(char *p_key, int buf_len)
{
    int ret = 0;
    if (NULL == p_key)
    {
        SDK_LOG(LOG_ERROR, "Input parameters contain null pointers!\n");
        return VHAL_FAIL;
    }

    ret = vhal_flash_write(PARTITION_CFG, USER_CFG_KEY_FFS_CLIENT_CHAIN, (uint8_t *)p_key, buf_len);
    if (VHAL_OK != ret)
    {
        VERR_UPLOAD(VERR_FLASH_WRITE_FAIL, 0);
        return SDK_FAIL;
    }

    return SDK_OK;
}

/**
 * @brief 写读取ffs配网结果到flash中
 * @param[in]  ffs_result_flash_data_t [待写入的ffs配网结果]
 * @param[in]  int             [长度]
 * @return     int             [成功/失败]
 */
int vesync_ffs_flash_write_result_data(ffs_result_flash_data_t *p_data)
{
    int ret = 0;
    uint32_t len = sizeof(ffs_result_flash_data_t);
    if (NULL == p_data)
    {
        SDK_LOG(LOG_ERROR, "Input parameters contain null pointers!\n");
        return VHAL_FAIL;
    }

    ret = vhal_flash_write(PARTITION_CFG, USER_CFG_KEY_FFS_FFS_RESULT, (uint8_t*)&p_data, len);
    if (VHAL_OK != ret)
    {
        VERR_UPLOAD(VERR_FLASH_WRITE_FAIL, 0);
        return SDK_FAIL;
    }

    return SDK_OK;
}

/**
 * @brief 从flash中读取ffs配网结果数据到内存
 * @param[out] ffs_result_flash_data_t  [配网结果]
 * @param[out] len                      [长度]
 * @return     int               [成功/失败]
 */
int vesync_ffs_flash_read_result_data(ffs_result_flash_data_t *p_data , uint32_t *len)
{
    int ret = 0;
    if (NULL == p_data || NULL == len )
    {
        SDK_LOG(LOG_ERROR, "Input parameters contain null pointers!\n");
        return VHAL_FAIL;
    }

    ret = vhal_flash_read(PARTITION_CFG, USER_CFG_KEY_FFS_FFS_RESULT, (uint8_t*)p_data, len);
    if (VHAL_OK != ret)
    {
        return SDK_FAIL;
    }

    return SDK_OK;
}

/**
 * @brief 清除ffs配网结果
 * @return int
 */
int vesync_ffs_flash_clear_result_data(void)
{
    int ret = VHAL_FAIL;

    ret = vhal_flash_erase_key(PARTITION_CFG, USER_CFG_KEY_FFS_FFS_RESULT);
    if (VHAL_OK != ret)
    {
        VERR_UPLOAD(VERR_FLASH_ERASE_FAIL, 0);
        return SDK_FAIL;
    }

    SDK_LOG(LOG_DEBUG, "Clear ffs result data success...\n");

    return SDK_OK;
}

