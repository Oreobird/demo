/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_event.h
 * @brief       事件处理接口
 * @date        2021-05-10
 */

#ifndef __VESYNC_EVENT_H__
#define __VESYNC_EVENT_H__

#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include "vesync_cfg.h"
#include "vesync_list.h"

#ifdef __cplusplus
extern "C" {
#endif

#define EVENT_TASK_STACKSIZE      (PR_EVENT_TASK_STACKSIZE)
#define EVENT_QUEUE_MAX_NUM       (PR_EVENT_QUEUE_MAX_NUM)
#define EVENT_QUEUE_MSG_MAX_LEN   (PR_EVENT_QUEUE_MSG_MAX_LEN)

// 事件处理中心任务的事件定义
typedef enum
{
    EVENT_WIFI_CONNECTED = 0,
    EVENT_WIFI_DISCONNECTED,
    EVENT_WIFI_SCANDONE,

    EVENT_BLE_CONNECTED,
    EVENT_BLE_DISCONNECTED,
    EVENT_ROUTER_GOT_IP,

    EVENT_MQTT_READY,
    EVENT_MQTT_CONNECTED,
    EVENT_MQTT_DISCONNECTED,
    EVENT_MQTT_SUBSCRIBED,
    EVENT_MQTT_RESET,
    EVENT_DNS_RESOLVED,
    EVENT_DEL_USER_DATA,                          //删除应用层用户数据
    EVENT_FFS_CLOUD_RSP,                          // FFS配网时，云回复信息才是成功的

    EVENT_CFGNET_SUCCEED,
    EVENT_CFGNET_APP_CONNECTED,
    EVENT_CFGNET_RECEIVE_CONFIG,
    EVENT_CFGNET_APP_DISCONNECTED,

    EVENT_CFGNET_STEP_TIMEOUT,                    // timeout for each step after receive the configuration
    EVENT_CFGNET_TIMEOUT,                         // 10mins timeout
    EVENT_CFGNET_APP_CANCEL,                      // user cancel cfgnet process from the APP
    EVENT_CFGNET_FORCE_EXIT,                       // exit cfgnet task
    EVENT_UNKNOWN
} EVENT_ID_E;

/**
* @brief 事件订阅回调函数类型
*/
typedef int (*event_subscribe_cb)(void *data);

/**
* @brief 事件结构体
*/
typedef struct
{
    EVENT_ID_E event_id;
    int pub_id;
    int len;
    char buf[0];
} vesync_ev_t;


/**
* @brief 初始化事件处理中心
* @return  int                   [成功/失败]
*/
int vesync_event_init(void);

/**
* @brief 释放事件处理中心资源
*/
void vesync_event_deinit(void);

/**
* @brief 发布事件通知
*/
int vesync_event_publish(vesync_ev_t *event);

/**
* @brief 订阅事件通知
* @param
* @return int
*/
int vesync_event_subscribe(EVENT_ID_E event_id, int sub_id, event_subscribe_cb cb);

/**
* @brief 取消订阅事件通知
* @param
* @return int
*/
int vesync_event_unsubscribe(EVENT_ID_E event_id, int sub_id);


#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_EVENT_H__ */


