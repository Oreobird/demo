/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file    lightstring_ir.h
* @brief   红外遥控接口
* @author  Lind
* @date    2021-12-24
*/

#ifndef __LIGHTSTRING_IR__
#define __LIGHTSTRING_IR__

#ifdef __cplusplus
extern "C" {
#endif


/**
* @brief 红外接收初始化
*/
void ls_ir_rx_init(void);


#ifdef __cplusplus
}
#endif

#endif /* __LIGHTSTRING_IR__ */

