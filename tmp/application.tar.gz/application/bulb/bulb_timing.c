/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file        bulb_timing.c
* @brief       bulb_timing配置
* @author      Dave
* @date        2021-09-09
*/


#include <string.h>
#include <stdio.h>

#include "vesync_common.h"
#include "vesync_log.h"
#include "vesync_timing.h"
#include "vesync_device.h"

#include "bulb.h"
#include "bulb_flash.h"
#include "bulb_status.h"
#include "bulb_report.h"
#include "bulb_timing.h"

#define BULB_TIMER_ID_MIN     0   // timer 最小di
#define BULB_TIMER_NUM_MAX    1   // 每个设备最多的timer数量

static bulb_timing_t s_bulb_timing;       // 保存timer
static bulb_status_t s_bulb_status;

/**
 * @brief timer时间到时执行的动作
 * @param[in]  uint16_t                 [timer id]
 * @return     void                     [none]
 */
static void bulb_timing_act(uint16_t id)
{
    s_bulb_status.changeflag = 0;
    strncpy(s_bulb_status.chg_rsn, STAT_CHG_RSN_TIMER_STR, sizeof(s_bulb_status.chg_rsn) - 1);
    int ret = APP_OK;
    if (id != s_bulb_timing.id)
    {
         return;
    }
    if (bulb_get_config(BULB_CFG_ONOFF) != s_bulb_timing.action.onoff)
    {
        bulb_update_config(BULB_CFG_ONOFF, s_bulb_timing.action.onoff);
        s_bulb_status.changeflag = BULB_ONOFF_CHANGE_FLAG;
    }
    if (1 == s_bulb_timing.action.onoff)
    {
        if (bulb_get_config(BULB_CFG_COLOR_MODE) != s_bulb_timing.action.mode)
        {
            bulb_update_config(BULB_CFG_COLOR_MODE, s_bulb_timing.action.mode);
            s_bulb_status.changeflag = (s_bulb_status.changeflag > 0) ? s_bulb_status.changeflag : BULB_MODE_CHANGE_FLAG;
        }
        if(0 == s_bulb_timing.action.mode)
        {
            if (bulb_get_config(BULB_CFG_COLOR_BRIGHT) != s_bulb_timing.action.bright)
            {
                bulb_update_config(BULB_CFG_COLOR_BRIGHT, s_bulb_timing.action.bright);
                s_bulb_status.changeflag = (s_bulb_status.changeflag > 0) ? s_bulb_status.changeflag : BULB_BRIGHT_CHANGE_FLAG;
            }
            if (bulb_get_config(BULB_CFG_COLOR_TEMP) != s_bulb_timing.action.temp)
            {
                bulb_update_config(BULB_CFG_COLOR_TEMP, s_bulb_timing.action.temp);
                s_bulb_status.changeflag = (s_bulb_status.changeflag > 0) ? s_bulb_status.changeflag : BULB_TEMP_CHANGE_FLAG;
            }
        }
        else
        {
            if (bulb_get_config(BULB_CFG_COLOR_HUE) != s_bulb_timing.action.hue || bulb_get_config(BULB_CFG_COLOR_SATURATION) != s_bulb_timing.action.saturation
                || bulb_get_config(BULB_CFG_COLOR_VALUE) != s_bulb_timing.action.value)
            {
                s_bulb_status.changeflag = (s_bulb_status.changeflag > 0) ? s_bulb_status.changeflag : BULB_HSV_CHANGE_FLAG;
            }
            bulb_update_config(BULB_CFG_COLOR_MODE, 1);
            bulb_update_config(BULB_CFG_COLOR_HUE, s_bulb_timing.action.hue);
            bulb_update_config(BULB_CFG_COLOR_SATURATION, s_bulb_timing.action.saturation);
            bulb_update_config(BULB_CFG_COLOR_VALUE, s_bulb_timing.action.value);
        }
    }
    bulb_open();
    bulb_report_status_change(&s_bulb_status);
    // timer执行结果上报服务器做记录
    bulb_report_timing_exec(&s_bulb_timing.action, ret, "");
    bulb_timing_remove(id);

}

/**
 * @brief 新增timer
 * @param[in]   action                  [timer执行动作]
 * @param[in]   total_sec               [timer定时时间]
 * @param[out]  p_id                    [timer id]
 * @return      int_t                   [成功：APP_OK， 失败：APP_FAIL]
 */
int bulb_timing_add(void* action, uint32_t total_sec, uint16_t *p_id)
{
    VCOM_NULL_PARAM_CHK(action, return APP_FAIL);
    VCOM_NULL_PARAM_CHK(p_id, return APP_FAIL);
    if (0 != s_bulb_timing.id)
    {
        APP_LOG(LOG_ERROR, "Timing exist\n");
        return APP_FAIL;
    }
    s_bulb_timing.id = *p_id;
    memcpy(&s_bulb_timing.action, (bulb_action_t*)action, sizeof(s_bulb_timing.action));
    if (SDK_OK != vesync_timing_add(s_bulb_timing.id, total_sec))
    {
        return APP_FAIL;
    }
    return APP_OK;
}

/**
 * @brief 获取timer执行的动作
 * @param[in]  action                   [timer执行的动作]
 * @return     int_t                    [成功：APP_OK， 失败：APP_FAIL]
 */
int bulb_timing_get_act(const void **action)
{
    *action = (const void*)&s_bulb_timing;
    return APP_OK;
}

/**
 * @brief 删除一个timer
 * @param[in]  uint16_t                 [timer id]
 * @return     int_t                    [成功：APP_OK， 失败：APP_FAIL]
 */
int bulb_timing_remove(uint16_t timer_id)
{
    if (s_bulb_timing.id != timer_id)
    {
        APP_LOG(LOG_ERROR, "Input ID is %d, not equal %d!\n", timer_id, s_bulb_timing.id);
        return APP_FAIL;
    }

    // 从队列中删除
    vesync_timing_remove(timer_id);

    // 清除缓存
    memset((uint8_t *)&s_bulb_timing, 0, sizeof(bulb_timing_t));

    return APP_OK;
}

/**
 * @brief 清空timer
 * @param void
 */
int bulb_timing_clear(void)
{
    // 清除timer队列
    vesync_timing_clear();

    // 清除缓存
    memset(&s_bulb_timing, 0, sizeof(s_bulb_timing));

    return APP_OK;
}

/**
 * @brief 初始化timer
 * @param void
 */
void bulb_timing_init(void)
{
    // 注册定时器动作回调
    vesync_timing_reg_cb(bulb_timing_act);
}

