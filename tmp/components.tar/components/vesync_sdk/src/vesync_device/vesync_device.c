/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_device.c
 * @brief       设备初始化、配置属性及操作接口
 * @date        2021-05-06
 */

#include <string.h>
#include <stdio.h>

#include "vhal_flash.h"
#include "vhal_utils.h"
#include "vesync_common.h"
#include "vesync_log_internal.h"
#include "vesync_os.h"
#include "vesync_timer.h"
#include "vesync_memory.h"
#include "vesync_device_internal.h"

#if CONFIG_VESYNC_SDK_WIFI_LED_ENABLE
#include "vesync_wifi_led.h"
#endif

static vesync_dev_t *s_dev = NULL;

static vesync_timer_t s_reboot_tmr_hd;   // 重启倒计时定时器



/*-----------------------------------------------------------------------------*
 *                                 内部函数实现                          *
 *-----------------------------------------------------------------------------*/

/**
* @brief   设备重启定时器
* @return  bool            [创建并启动定时器成功，返回true，否则返回false]
*/
static int vesync_device_reboot_tmr_start(void)
{
    // 创建单次执行定时器，2秒后执行
    int ret = vesync_timer_new(&s_reboot_tmr_hd, "device_reboot_timer", vhal_utils_restart, NULL, 2*1000, false);
    if (ret != VOS_OK)
    {
        SDK_LOG(LOG_ERROR, "Create reboot timer fail!!!\n");
        return SDK_FAIL;
    }

    ret = vesync_timer_start(&s_reboot_tmr_hd);
    if (ret != VOS_OK)
    {
        SDK_LOG(LOG_ERROR, "Start reboot timer fail!!!\n");
        return SDK_FAIL;
    }

    return SDK_OK;
}


/**
 * @brief 删除用户（应用层）数据
 * @param[in]  src_type             [消息(动作)来源]
 * @param[in]  rst_type             [删除用户数据的类型]
 */
static void vesync_device_clear_user_data(const char* src_type, DEV_RESET_TYPE_E rst_type)
{
    // 删除用户数据(有些产品并没有schedule，因此放到应用层进行处理)
    vhal_flash_erase_key(PARTITION_CFG, USER_CFG_KEY_DBG_CONFIG);
    SDK_LOG(LOG_INFO, "Delete user data.\n");

    // 删除历史数据和缓存数据，设备运行在默认状态
    if (s_dev && s_dev->dev_clear_data_cb)
    {
        s_dev->dev_clear_data_cb(src_type, rst_type);
        SDK_LOG(LOG_INFO, "Delete history data.\n");
    }
}


/**
* @brief 从flash中读取设备的cid参数
* @param[out] p_cid            [flash中存储的cid]
* @param[in]  buf_len          [buf的最小长度,需要是CID长度+1个字节]
* @return     int              [成功/失败]
*/
static int vesync_device_flash_read_cid(uint8_t *p_cid, int buf_len)
{
    int ret = VHAL_FAIL;

    // 参数检验
    VCOM_NULL_PARAM_CHK(p_cid, return SDK_FAIL);
    VCOM_LEN_IS_TOO_SMALL(buf_len, DEVICE_CID_LEN, return SDK_FAIL);

    // 读取cid
    uint32_t cid_len = DEVICE_CID_LEN;
    uint8_t buf[64] = {0,};

    ret = vhal_flash_read(PARTITION_CFG, USER_CFG_KEY_CID, buf, &cid_len);
    if (ret != VHAL_OK)
    {
        SDK_LOG(LOG_ERROR, "device read cid fail\n");
        return SDK_FAIL;
    }

    snprintf((char *)p_cid, buf_len, "%s", buf);

    return SDK_OK;
}


/*-----------------------------------------------------------------------------*
 *                           外部函数API实现                                         *
 *-----------------------------------------------------------------------------*/

/**
* @brief  初始化设备信息
* @return     int                  [成功/失败]
*/
int vesync_device_init(void)
{
    int ota_num = 0;
    uint32_t idx = 0;

    // 设备OTA个数
#if defined(PR_OTA_TYPE_WIFI) && PR_OTA_TYPE_WIFI
    ota_num += PR_OTA_TYPE_WIFI;
#endif
#if defined(PR_OTA_TYPE_BLE) && PR_OTA_TYPE_BLE
    ota_num += PR_OTA_TYPE_BLE;
#endif
#if defined(PR_TOTAL_MCU_NUM) && PR_TOTAL_MCU_NUM
    ota_num += PR_TOTAL_MCU_NUM;
#endif

    if (ota_num <= 0)
    {
        SDK_LOG(LOG_ERROR, "device ota number error\n");
        return SDK_FAIL;
    }

    SDK_LOG(LOG_INFO, "device num is %d \n", ota_num);

    int dev_len = sizeof(vesync_dev_t) + sizeof(dev_fw_info_t)*ota_num;
    s_dev = (vesync_dev_t *)vesync_malloc(dev_len);
    if (s_dev == NULL)
    {
        SDK_LOG(LOG_ERROR, "Malloc fail for device init\n");
        return SDK_FAIL;
    }

    memset(s_dev, 0, dev_len);
    s_dev->total_ota_num = ota_num;

    // 根据宏定义，预先指定类型
#if defined(PR_OTA_TYPE_BLE) && PR_OTA_TYPE_BLE
    snprintf(s_dev->fw_info[idx].plugin_name, sizeof(s_dev->fw_info[idx].plugin_name), VESYNC_BLE_DEFAULT_FLUGIN_NAME);
    s_dev->fw_info[idx].main_fw = false;
    s_dev->fw_info[idx].is_upgrade = true;
    s_dev->fw_info[idx].priority = idx;
    s_dev->fw_info[idx++].type = UPG_TP_BLE;
#endif
#if defined(PR_TOTAL_MCU_NUM) && (PR_TOTAL_MCU_NUM >= 1)
    snprintf(s_dev->fw_info[idx].plugin_name, sizeof(s_dev->fw_info[idx].plugin_name), VESYNC_MCU_DEFAULT_FLUGIN_NAME);
    s_dev->fw_info[idx].main_fw = false;
    s_dev->fw_info[idx].is_upgrade = (PR_OTA_TYPE_MCU&0x1) > 0 ? true:false;    // bit0
    s_dev->fw_info[idx].priority = idx;
    s_dev->fw_info[idx++].type = UPG_TP_MCU;
#endif
#if defined(PR_TOTAL_MCU_NUM) && (PR_TOTAL_MCU_NUM >= 2)
    snprintf(s_dev->fw_info[idx].plugin_name, sizeof(s_dev->fw_info[idx].plugin_name), VESYNC_MCU2_DEFAULT_FLUGIN_NAME);
    s_dev->fw_info[idx].main_fw = false;
    s_dev->fw_info[idx].is_upgrade = (PR_OTA_TYPE_MCU&0x2) > 0 ? true:false;    // bit1
    s_dev->fw_info[idx].priority = idx;
    s_dev->fw_info[idx++].type = UPG_TP_MCU2;
#endif
#if defined(PR_TOTAL_MCU_NUM) && (PR_TOTAL_MCU_NUM >= 3)
    snprintf(s_dev->fw_info[idx].plugin_name, sizeof(s_dev->fw_info[idx].plugin_name), VESYNC_MCU3_DEFAULT_FLUGIN_NAME);
    s_dev->fw_info[idx].main_fw = false;
    s_dev->fw_info[idx].is_upgrade = (PR_OTA_TYPE_MCU&0x4) > 0 ? true:false;    // bit2
    s_dev->fw_info[idx].priority = idx;
    s_dev->fw_info[idx++].type = UPG_TP_MCU3;
#endif
#if defined(PR_OTA_TYPE_WIFI) && PR_OTA_TYPE_WIFI
    snprintf(s_dev->fw_info[idx].plugin_name, sizeof(s_dev->fw_info[idx].plugin_name), VESYNC_WIFI_DEFAULT_FLUGIN_NAME);
    s_dev->fw_info[idx].main_fw = true;
    s_dev->fw_info[idx].is_upgrade = true;
    s_dev->fw_info[idx].priority = idx;
    s_dev->fw_info[idx++].type = UPG_TP_WIFI;
#endif

    // 更新Wi-Fi固件的版本信息
    vesync_device_update_fw_ver(UPG_TP_WIFI, PR_FW_VERSION);

    // 读取产品CID
    uint8_t cid[36] = {0};
    int ret = vesync_device_flash_read_cid(cid, sizeof(cid));
    if (ret != SDK_OK)
    {
        vesync_free(s_dev);
        SDK_LOG(LOG_ERROR, "device cid read fail\n");
        return SDK_FAIL;
    }

    snprintf(s_dev->cid, sizeof(s_dev->cid), "%s", cid);

    s_dev->dev_clear_data_cb = NULL;

    return SDK_OK;
}

/**
* @brief  释放设备资源
* @return  none
*/
void vesync_device_deinit(void)
{
    if (s_dev)
    {
        vesync_free(s_dev);
        s_dev = NULL;
    }
}

/**
* @brief 获取产品ota类型配置信息
* @return char     [获取数据内容]
*/
uint8_t vesync_device_get_ota_num(void)
{
    VCOM_NULL_PARAM_CHK(s_dev, return 0);
    return s_dev->total_ota_num;
}


/**
* @brief 更新各固件版本信息
* @param[in]  type                 [固件类型]
* @param[in]  p_ver                [固件版本]
* @return     int                  [成功/失败]
*/
int vesync_device_update_fw_ver(FW_TYPE_E type, char *p_ver)
{
    uint8_t idx = 0;
    VCOM_NULL_PARAM_CHK(p_ver, return SDK_FAIL);
    VCOM_NULL_PARAM_CHK(s_dev, return SDK_FAIL);

    SDK_LOG(LOG_DEBUG, "type: %d, p_ver: %s\n", type, p_ver);

    for (idx = 0; idx < s_dev->total_ota_num; idx++)
    {
        if (type == s_dev->fw_info[idx].type)
        {
            snprintf(s_dev->fw_info[idx].cur_firm_ver, sizeof(s_dev->fw_info[idx].cur_firm_ver), "%s", p_ver);
            break;
        }
    }

    if (idx >= s_dev->total_ota_num)
    {
        SDK_LOG(LOG_ERROR, "Unknown OTA type(0x%x)!!\n", type);
        return SDK_FAIL;
    }

    return SDK_OK;
}


/**
* @brief 更新各固件升级优先顺序
* @param[in]  type                 [固件类型]
* @param[in]  priority             [优先级，数值越小优先级越高]
* @return     int                  [成功/失败]
*/
int vesync_device_update_fw_priority(FW_TYPE_E type, uint8_t priority)
{
    VCOM_NULL_PARAM_CHK(s_dev, return SDK_FAIL);
    uint8_t idx = 0;

    for (idx = 0; idx < s_dev->total_ota_num; idx++)
    {
        if (type == s_dev->fw_info[idx].type)
        {
            s_dev->fw_info[idx].priority = priority;
            break;
        }
    }

    if (idx >= s_dev->total_ota_num)
    {
        SDK_LOG(LOG_ERROR, "Unknow OTA type(0x%x)!!\n", type);
        return SDK_FAIL;
    }

    return SDK_OK;
}


/**
* @brief 更新固件的插件名(plugin_name)，在默认基础上添加后缀
* @param[in]  type                 [固件类型]
* @param[in]  p_suffix             [插件名后缀]
* @return     int                  [成功/失败]
*/
int vesync_device_add_plugin_name_suffix(FW_TYPE_E type, const char *p_suffix)
{
    VCOM_NULL_PARAM_CHK(p_suffix, return SDK_FAIL);
    VCOM_NULL_PARAM_CHK(s_dev, return SDK_FAIL);

    uint8_t idx = 0;
    char plugin_name[MAX_PLUGIN_NAME_STR_LEN];

    for (idx = 0; idx < s_dev->total_ota_num; idx++)
    {
        if (type == s_dev->fw_info[idx].type)
        {
            memset(plugin_name, 0, sizeof(plugin_name));
            switch (type)
            {
#if defined(PR_OTA_TYPE_WIFI) && PR_OTA_TYPE_WIFI
                case UPG_TP_WIFI:
                    snprintf(plugin_name, sizeof(plugin_name), "%s-C%s", VESYNC_WIFI_DEFAULT_FLUGIN_NAME, p_suffix);
                    break;
#endif

#if defined(PR_OTA_TYPE_BLE) && PR_OTA_TYPE_BLE
                case UPG_TP_BLE:
                    snprintf(plugin_name, sizeof(plugin_name), "%s-C%s", VESYNC_BLE_DEFAULT_FLUGIN_NAME, p_suffix);
                    break;
#endif

#if defined(PR_TOTAL_MCU_NUM) && (PR_TOTAL_MCU_NUM >= 1)
                case UPG_TP_MCU:
                    snprintf(plugin_name, sizeof(plugin_name), "%s-C%s", VESYNC_MCU_DEFAULT_FLUGIN_NAME, p_suffix);
                    break;
#endif

#if defined(PR_TOTAL_MCU_NUM) && (PR_TOTAL_MCU_NUM >= 2)
                case UPG_TP_MCU2:
                    snprintf(plugin_name, sizeof(plugin_name), "%s-C%s", VESYNC_MCU2_DEFAULT_FLUGIN_NAME, p_suffix);
                    break;
#endif

#if defined(PR_TOTAL_MCU_NUM) && (PR_TOTAL_MCU_NUM >= 3)
                case UPG_TP_MCU3:
                    snprintf(plugin_name, sizeof(plugin_name), "%s-C%s", VESYNC_MCU3_DEFAULT_FLUGIN_NAME, p_suffix);
                    break;
#endif
            }

            memset(s_dev->fw_info[idx].plugin_name, 0, sizeof(s_dev->fw_info[idx].plugin_name));
            snprintf(s_dev->fw_info[idx].plugin_name, sizeof(s_dev->fw_info[idx].plugin_name), "%s", plugin_name);
            break;
        }
    }

    if (idx >= s_dev->total_ota_num)
    {
        SDK_LOG(LOG_ERROR, "Unknow FW type(0x%x)!!\n", type);
        return SDK_FAIL;
    }

    return SDK_OK;
}

/**
* @brief 获取固件的插件名(plugin_name)信息
* @param[in]  type                 [固件类型]
* @return     int                  [成功/失败]
*/
char *vesync_device_get_plugin_name_by_type(FW_TYPE_E type)
{
    VCOM_NULL_PARAM_CHK(s_dev, return NULL);

    uint8_t idx = 0;
    for (idx = 0; idx < s_dev->total_ota_num; idx++)
    {
        if (type == s_dev->fw_info[idx].type)
        {
            return s_dev->fw_info[idx].plugin_name;
        }
    }

    return NULL;
}

/**
* @brief 根据下标获取各固件的信息
* @param[in]  idx                  [下标]
* @param[out] p_firw_info          [返回固件信息]
* @return     int                  [成功/失败]
*/
int vesync_device_get_fw_info_by_idx(uint8_t idx, dev_fw_info_t *p_fw_info)
{
    VCOM_NULL_PARAM_CHK(p_fw_info, return SDK_FAIL);
    VCOM_NULL_PARAM_CHK(s_dev, return SDK_FAIL);

    VCOM_LEN_IS_TOO_LARGE(idx, s_dev->total_ota_num - 1, return SDK_FAIL);

    snprintf(p_fw_info->cur_firm_ver, sizeof(p_fw_info->cur_firm_ver), "%s", s_dev->fw_info[idx].cur_firm_ver);
    snprintf(p_fw_info->plugin_name, sizeof(p_fw_info->plugin_name), "%s", s_dev->fw_info[idx].plugin_name);
    p_fw_info->main_fw = s_dev->fw_info[idx].main_fw;
    p_fw_info->priority = s_dev->fw_info[idx].priority;
    p_fw_info->is_upgrade = s_dev->fw_info[idx].is_upgrade;

    return SDK_OK;
}

/**
* @brief 获取各固件的信息
* @param[in]  type                 [固件类型]
* @param[out] p_firw_info          [返回固件信息]
* @return     int                  [成功/失败]
*/
int vesync_device_get_fw_info_by_type(FW_TYPE_E type, dev_fw_info_t *p_fw_info)
{
    VCOM_NULL_PARAM_CHK(p_fw_info, return SDK_FAIL);
    VCOM_NULL_PARAM_CHK(s_dev, return SDK_FAIL);

    uint8_t idx = 0;

    for (idx = 0; idx < s_dev->total_ota_num; idx++)
    {
        if (type == s_dev->fw_info[idx].type)
        {
            snprintf(p_fw_info->cur_firm_ver, sizeof(p_fw_info->cur_firm_ver), "%s", s_dev->fw_info[idx].cur_firm_ver);
            snprintf(p_fw_info->plugin_name, sizeof(p_fw_info->plugin_name), "%s", s_dev->fw_info[idx].plugin_name);
            p_fw_info->main_fw = s_dev->fw_info[idx].main_fw;
            p_fw_info->priority = s_dev->fw_info[idx].priority;
            p_fw_info->is_upgrade = s_dev->fw_info[idx].is_upgrade;
            break;
        }
    }

    if (idx >= s_dev->total_ota_num)
    {
        SDK_LOG(LOG_ERROR, "Unknow OTA type(0x%x)!!\n", type);
        return SDK_FAIL;
    }

    SDK_LOG(LOG_DEBUG, "main_fw: %d, priority: %d, cur_firm_ver: %s, plugin_name: %s\n",
    p_fw_info->main_fw, p_fw_info->priority, p_fw_info->cur_firm_ver, p_fw_info->plugin_name);

    return SDK_OK;
}

/**
 * @brief 向device_info 结构体内填充cid
 * @param[in]  cid                  [设备cid]
 * @return     int                  [成功/失败]
 */
int vesync_device_set_cid(char *cid)
{
    VCOM_NULL_PARAM_CHK(cid, return SDK_FAIL);
    VCOM_NULL_PARAM_CHK(s_dev, return SDK_FAIL);

    snprintf(s_dev->cid, sizeof(s_dev->cid), "%s", cid);

    return SDK_OK;
}

/**
* @brief 获取设备cid
* @return  int                   [设备cid]
*/
char *vesync_device_get_cid(void)
{
    VCOM_NULL_PARAM_CHK(s_dev, return NULL);
    return (char *)s_dev->cid;
}


/**
 * @brief 设置account id
 * @param[in]  account_id           [用户ID]
 * @return     int                  [设置成功/失败]
 */
int vesync_device_set_account_id(char *account_id)
{
    VCOM_NULL_PARAM_CHK(account_id, return SDK_FAIL);
    VCOM_NULL_PARAM_CHK(s_dev, return SDK_FAIL);

    strncpy(s_dev->account_id, account_id, ACCOUNT_ID_STR_LEN);

    return SDK_OK;
}

/**
 * @brief 获取account id
 * @return     char*                [账号id]
 */
char *vesync_device_get_account_id(void)
{
    VCOM_NULL_PARAM_CHK(s_dev, return NULL);
    return (char *)s_dev->account_id;
}

/**
* @brief 重启设备
* @return     none
*/
void vesync_device_reboot(void)
{
    // 采用定时器实现重启，确保调用该接口的任务(也包括其他任务)处理完所有的事情。
    int ret = vesync_device_reboot_tmr_start();
    if (ret != SDK_OK)
    {
        // 创建定时器失败，延时2s重启(保证消息传输到云端)，重启设备
        vesync_sleep(2000);
        vhal_utils_restart(NULL);
    }
}


/**
 * @brief 清除设备数据回调
 *
 * @param cb                      [清除historydata分区数据接收回调函数]
 * @return int                    [成功/失败]
 */
int vesync_device_reg_clear_data_cb(vesync_device_clear_data_cb_t cb)
{
    VCOM_NULL_PARAM_CHK(s_dev, return SDK_FAIL);
    s_dev->dev_clear_data_cb = cb;
    return SDK_OK;
}


/*
 * @brief  设备恢复出厂，删除所有配置信息
 * @param[in]  src_type             [消息(动作)来源]
 * @param[in]  cb                   [恢复出厂重启前其它事务处理回调函数]
 * @return     none
 */
void vesync_device_factory_reset(const char* src_type, vesync_device_pre_reset_cb_t cb)
{
#if CONFIG_VESYNC_SDK_WIFI_LED_ENABLE
    // 恢复出厂，灯效修改
    vesync_wifi_led_set_behavior(WIFI_LED_RESET_DEVICE);
    SDK_LOG(LOG_DEBUG, "Reset Wi-Fi led.\n");
#endif

    // 删除用户数据
    vesync_device_clear_user_data(src_type, DEV_DEL_DEVICE);
    SDK_LOG(LOG_DEBUG, "Delete user data.\n");

    // 清除配网数据
    //vesync_netcfg_clear_net_info(); //TODO:Fix me
    //SDK_LOG(LOG_INFO, "Delete config net info.\n");

    if (cb)
    { //处理其它事务
        cb(NULL);
    }

    // 重启
    vesync_device_reboot();
}

/**
 * @brief  获取配置信息保存扇区，打印固件及设备相关信息等
 */
void vesync_device_print_info(void)
{
    //设备MAC地址
    char wifi_mac_str[MAC_ADDR_STR_MAX_LEN] = {0};
#if defined(PR_FW_TYPE) && (PR_FW_TYPE == 0)
    char sdk_ver[8] = {0};
#endif

    SDK_LOG(LOG_WARN, "---------------Device Info---------------\n");
    if (VHAL_OK == vhal_utils_get_dev_mac(VHAL_MAC_WIFI_STA, wifi_mac_str, sizeof(wifi_mac_str)))
    {
        SDK_LOG(LOG_WARN, "Device MAC: %s \n", wifi_mac_str);
    }

    SDK_LOG(LOG_WARN, "Device CID: %s\n", vesync_device_get_cid());
    SDK_LOG(LOG_WARN, "Device type: %s\n", PR_TYPE);
    SDK_LOG(LOG_WARN, "Device model: %s\n", PR_MODEL);
    SDK_LOG(LOG_WARN, "Hardware version: %s\n", PR_HW_VERSION); // Wi-Fi模块硬件版本号(非产品硬件版本号)
    SDK_LOG(LOG_WARN, "Firmware version: %s\n", PR_FW_VERSION);
    SDK_LOG(LOG_WARN, "Country code: %s\n", PR_COUNTRY_CODE);
#if defined(PR_FW_TYPE) && (PR_FW_TYPE == 0)
    SDK_LOG(LOG_WARN, "Firmware type: debug\n");
    SDK_LOG(LOG_DEBUG, "SDK version: %s-%s\n", vhal_utils_get_chip_name(), vhal_utils_get_sdk_version(sdk_ver, sizeof(sdk_ver)));
#else
    SDK_LOG(LOG_WARN, "Firmware type: release\n");
#endif
    SDK_LOG(LOG_WARN, "----------------------------------------\n");
}

