/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file       vesync_cfg.h
* @brief      vesync device config information.
* @date       2021-05-28
* @note       File auto generated, DO NOT edit.
*/

#ifndef __VESYNC_CFG_H__
#define __VESYNC_CFG_H__

#ifdef __cplusplus
extern "C" {
#endif

// product_cfg
#define PR_FW_VERSION                      ("1.1.01")
#define PR_HW_VERSION                      ("1.0")
#define PR_BRAND                           ("Levoit")
#define PR_TYPE                            ("purifier")
#define PR_MODEL                           ("Core400s")
#define PR_ALIAS_MODEL                     ("Core400s")
#define PR_COUNTRY_CODE                    ("US")
#define SUPPORT_CTRY_CODE                  ("US")
#define PR_CONFIG_MODEL                    ("WiFiBTOnboardingNotify_AirPurifier_Core400S_US")
#define PR_PID                             ("nb22mzgsx4fm48xh")
#define PR_AUTHKEY                         ("ww6zvzwtaa6hqjl991g0w1obkeo0sd44")

// event_cfg
#define PR_EVENT_TASK_STACKSIZE            (2048)
#define PR_EVENT_QUEUE_MAX_NUM             (32)
#define PR_EVENT_QUEUE_MSG_MAX_LEN         (1024)

// net_cfg
#define PR_CFGNET_MODE                     ("ble_cfg_net")
#define PR_SSID_PREFIX                     ("vesync")
#define PR_BAN_BLE_BROADCAST               (1)
#define PR_PROT_HEADER_VER                 (0x2)
#define PR_PROT_PAYLOAD_VER                (0x1)

// ble_cfg
#define PR_BLE_TYPE                        (0xc6)
#define PR_BLE_MODEL                       (0x2c)
#define PR_BLE_CMD                         (0x2)
#define PR_BLE_CFGNET_VER                  (0x2)
#define PR_BLE_NAME                        ("Core400s")

// protocol_cfg
#define PR_REPORT_PROCOTOL_VER             (3)
#define PR_BYPASS_PROCOTOL_VER             ("v2")

// mcu_cfg
#define PR_TOTAL_MCU_NUM                   (1)

// ota_cfg
#define PR_OTA_TYPE_WIFI                   (1)
#define PR_OTA_TYPE_BLE                    (0)
#define PR_OTA_TYPE_MCU                    (1)
#define PR_OTA_TIMEOUT_TIME                (285000)              // OTA超时时间
#define PR_OTA_TASK_STACKSIZE              ((1024*4))

// wifi_cfg
#define PR_WIFI_PS_TYPE                    (1)

// uart_cfg
#define PR_UART_NUM                        (0)
#define PR_UART_TX_PIN                     (17)
#define PR_UART_RX_PIN                     (16)
#define PR_UART_BAUD_RATE                  (115200)
#define PR_UART_PAYLOAD_MAX_LEN            (1500)
#define PR_UART_MAX_RESEND_CNT             (3)
#define PR_UART_SEND_RSP_TIMEOUT_MS        (2000)
#define PR_UART_SEND_NO_RSP_TIMEOUT_MS     (10)
#define PR_UART_SEND_USE_TIMER             (0)                   // 1表示发送使用定时器轮询，0表示使用任务轮询
#define PR_UART_SEND_INTTERVAL_MS          (50)                  // 串口发送最新间隔
#define PR_UART_SEND_ACK_QUEUE_LEN         (10)                  // 串口ACK队列长度
#define PR_UART_SEND_DATA_QUEUE_LEN        (30)                  // 串口数据队列长度

// production_cfg
#define PRODUCTION_WIFI_SSID               ("VeSync_Pruduction_AP") // 产测Wi-Fi的SSID
#define PRODUCTION_WIFI_PWD                ("VeSync2018@etekcity.com.cn") // 产测Wi-Fi的密码
#define PRODUCTION_SERVER_ADDR             ("purifierCore400s.us.factory.vesync.cn") // 产测服务器域名
#define PRODUCTION_AUTO_ENTER              (1)

#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_CFG_H__ */
