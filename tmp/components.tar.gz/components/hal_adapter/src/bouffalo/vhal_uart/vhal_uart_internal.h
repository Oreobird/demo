/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vhal_uart.c
 * @brief       vesync串口相关功能
 * @author      Louis
 * @date        2021-03-23
 */

#ifndef __VHAL_UART_INTERNAL_H__
#define __VHAL_UART_INTERNAL_H__

#include <stdint.h>
#include <stdbool.h>

#include "vesync_task.h"
#include "vesync_cfg_internal.h"

#ifdef __cplusplus
extern "C"
{
#endif

#define VHAL_UART_NUM_MAX       (PR_UART_NUM_MAX)

// uart_event任务
#define UART_TASK_NAME          "uart_event"
#define UART_TASK_STACSIZE      (1024*2)
#define UART_TASK_PRIO          TASK_PRIORITY_HARD_REALTIME

#define UART_BUF_SIZE           (1024)
#define UART_RECV_BUF_SIZE      (UART_BUF_SIZE)


/*
 * @brief  串口收发状态
 */
typedef struct
{
    bool cfg_flag;                          // 配置（初始化）标志位，true表示该串口已被配置
    int fd;                                 // 串口文件描述符
    vhal_uart_recv_cb_t recv_cb;            // 接收回调
} vhal_bl_uart_status_t;

#ifdef __cplusplus
}
#endif

#endif /* __VHAL_UART_INTERNAL_H__ */
