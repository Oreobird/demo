/**
*Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file    ledstrip_device.c
* @brief   设备重置
* @author  Lind
*@date     2021-09-30
*/
#include "vesync_device.h"

#include "ledstrip_device.h"
#include "ledstrip_report.h"
#include "ledstrip_schedule.h"
#include "ledstrip_flash.h"
#include "ledstrip_timing.h"



/**
 * @brief 清除开关应用层数据
 * @param[in]  rsn              [消息来源]
 * @param[in]  rst_type         [删除用户数据的类型]
 */
static void ls_device_clear_all_data(const char* rsn, DEV_RESET_TYPE_E rst_type)
{
    if (rst_type == DEV_DEL_USER_CFG || rst_type == DEV_DEL_DEVICE)
    {
        ls_schedule_clear();
        ls_timing_clear();
        ls_clear_config();
    }

    ls_report_set_chg_rsn(STAT_CHG_RSN_NONE_STR);
    report_ls_status();
}


/**
* @brief ledstrip设备管理初始化
*/
void ls_device_init(void)
{
    // 注册缓存数据清除函数(恢复出厂/删除设备时调用)
    vesync_device_reg_clear_data_cb(ls_device_clear_all_data);
}


