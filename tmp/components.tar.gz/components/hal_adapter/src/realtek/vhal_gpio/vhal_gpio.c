/**
 * Copyright © Vesync Technologies Co.Ltd. 2019-2021. All rights reserved.
 * @file    vhal_gpio.c
 * @brief   vesync设备硬件GPIO硬件抽象层
 * @author  Dongri.Su
 * @date    2019-12-06
 */

#include <string.h>
#include "gpio_api.h"
#include "gpio_ex_api.h"

#include "vesync_log.h"
#include "vesync_common.h"


#include "vhal_gpio.h"
#include "vhal_gpio_internal.h"


static rtl_gpio_cfg_t *s_rtl_gpio_cfg = NULL;           // GPIO配置
static uint8_t rtl_gpio_num = 0;                        // 记录GPIO数量



/*-----------------------------------------------------------------------------*
 *                           内部函数API实现                                         *
 *-----------------------------------------------------------------------------*/

/**
 * @brief 获取GPIO管脚名字
 * @param[in]  gpio_num             [GPIO编号]
 * @return     int                  [pin名称]
 * @note 该接口仅用于Realtek平台，不可以为上层提供服务，rtl-amebaz2_v7.1c\component\common\mbed\targets\hal\rtl8710c\PinNames.h
 */
PinName vhal_rtl_giop_get_pin_name(uint8_t gpio_num)
{
    switch (gpio_num)
    {
    case 0:return PA_0;     // for TAG/SWD
    case 1:return PA_1;     // for TAG/SWD
    case 2:return PA_2;     // for TAG/SWD
    case 3:return PA_3;     // for TAG/SWD
    case 4:return PA_4;     // for TAG/SWD
    case 5:return PA_5;
    case 6:return PA_6;
    case 7:return PA_7;     // only available on RTL8720CF.
    case 8:return PA_8;     // only available on RTL8720CF.
    case 9:return PA_9;     // only available on RTL8720CF.
    case 10:return PA_10;   // only available on RTL8720CF.
    case 11:return PA_11;   // only available on RTL8720CF.
    case 12:return PA_12;   // only available on RTL8720CF.
    case 13:return PA_13;
    case 14:return PA_14;
    case 15:return PA_15;   // log UART
    case 16:return PA_16;   // log UART
    case 17:return PA_17;
    case 18:return PA_18;
    case 19:return PA_19;
    case 20:return PA_20;
    case 21:return PA_21;
    case 22:return PA_22;
    case 23:return PA_23;
    case 32:return PB_0;
    case 33:return PB_1;
    case 34:return PB_2;
    case 35:return PB_3;
    case 36:return PB_4;
    case 37:return PB_5;
    case 38:return PB_6;
    case 39:return PB_7;
    case 40:return PB_8;
    case 41:return PB_9;
    case 42:return PB_10;
    case 43:return PB_11;
    case 44:return PB_12;
    default:return NC;
    }
/*    // 0~31编号的管脚是定义给PA_x
    if (gpio_num < 31)
        return RTL_GPIO_PIN_NAME_PA(gpio_num);
    // 32~63编号的管脚是定义给PB_x
    else if (gpio_num < 64)
    {
        gpio_num -= 32;
        return RTL_GPIO_PIN_NAME_PB(gpio_num);
    }
    else
        return NC;
*/
}

/**
 * @brief  GPIO方向数据转换(应用层->驱动)
 * @param[in]  dir                  [应用层定义的GPIO dir]
 * @return     PinDirection         [驱动中声明的GPIO dir，-1表示非法]
 */
static PinDirection vhal_rtl_giop_convert_dir(GPIO_MODE_E dir)
{
    // 8710cx只支持两种
    if (GPIO_MODE_IN == dir)
    {
        return PIN_INPUT;
    }
    else if (GPIO_MODE_OUT == dir)
    {
        return PIN_OUTPUT;
    }
    else
    {
        HAL_LOG(LOG_ERROR, "Unsupport GPIO dir(%d)!!\n", dir);
        return -1;
    }
}

/**
 * @brief  GPIO pull方式转换(应用层->驱动)
 * @param[in]  pullup               [应用层定义的pullup方式]
 * @param[in]  pulldown             [应用层定义的pulldown方式]
 * @return     PinMode              [驱动中声明的pull方式]
 */
static PinMode vhal_rtl_giop_convert_pull_mode(GPIO_PULLUP_E pullup, GPIO_PULLDOWN_E pulldown)
{
    // 8710cx只支持两种
    if (GPIO_PULLUP_DIS == pullup && GPIO_PULLDOWN_DIS == pulldown)
        return PullNone;    // 0
    else if (GPIO_PULLUP_EN == pullup && GPIO_PULLDOWN_DIS == pulldown)
        return PullUp;      // 1
    else if (GPIO_PULLUP_DIS == pullup && GPIO_PULLDOWN_EN == pulldown)
        return PullDown;    // 2
    else if (GPIO_PULLUP_EN == pullup && GPIO_PULLDOWN_EN == pulldown)
        return OpenDrain;   // 3
    else
    {
        HAL_LOG(LOG_ERROR, "Unsupport GPIO pull mode(%d:%d)!!\n", pullup,pulldown);
        return -1;
    }
}

/**
 * @brief  获取GPIO句柄
 * @param[in]  gpio_num             [GPIO编号]
 * @return     gpio_t               [pin名称]
 */
static gpio_t *vhal_rtl_giop_get_gpio_obj(uint8_t gpio_num)
{
    uint8_t idx = 0;

    if (NULL != s_rtl_gpio_cfg)
    {
        for (idx = 0; idx < rtl_gpio_num; idx ++)
        {
            if (s_rtl_gpio_cfg[idx].gpio_num == gpio_num)
                return &s_rtl_gpio_cfg[idx].gpio_obj;
        }
    }

    return NULL;
}


/*-----------------------------------------------------------------------------*
 *                           外部函数API实现                                         *
 *-----------------------------------------------------------------------------*/

/**
 * @brief  GPIO初始化
 * @param[in]  io_conf              [GPIO配置]
 * @return     void
 */
void vhal_gpio_init(vhal_gpio_config_t io_conf)
{
    bool init_flag = FALSE;
    uint8_t idx = 0;
    //gpio_t gpio;
    HAL_LOG(LOG_DEBUG, "gpio init ...\n");

    if (io_conf.pin_bit_mask >= RTL_GPIO_MAX_NUM)
    {
        HAL_LOG(LOG_ERROR, "gpio number(%d) is invaild!!\n", io_conf.pin_bit_mask);
        return;
    }

    // 已经有GPIO初始化了
    if (rtl_gpio_num > 0)
    {
        for (idx = 0; idx < rtl_gpio_num; idx++)
        {
            if (NULL != s_rtl_gpio_cfg && io_conf.pin_bit_mask == s_rtl_gpio_cfg[idx].gpio_num)
            { // 同一个GPIO已经初始化过了
                break;
            }
        }

        if (idx >= rtl_gpio_num)
        {
            init_flag = TRUE;
            rtl_gpio_num += 1;
        }
    }
    else
    {
        init_flag = TRUE;
        rtl_gpio_num += 1;
    }

    if (init_flag)
    {
        rtl_gpio_cfg_t *p_gpio_cfg = (rtl_gpio_cfg_t *)malloc(sizeof(rtl_gpio_cfg_t)*rtl_gpio_num);
        if (NULL == p_gpio_cfg)
        {
            HAL_LOG(LOG_ERROR, "Malloc fail!!\n");
            rtl_gpio_num -= 1;      // 前面进行了加1，这里需要减掉
            return;
        }
        memset(p_gpio_cfg, 0, sizeof(rtl_gpio_cfg_t)*rtl_gpio_num);

        if (NULL != s_rtl_gpio_cfg && rtl_gpio_num > 1)
            memcpy((uint8_t *)p_gpio_cfg, (uint8_t *)s_rtl_gpio_cfg, sizeof(rtl_gpio_cfg_t)*(rtl_gpio_num-1));

        p_gpio_cfg[rtl_gpio_num-1].gpio_num = io_conf.pin_bit_mask;

        gpio_init(&p_gpio_cfg[rtl_gpio_num-1].gpio_obj, vhal_rtl_giop_get_pin_name(io_conf.pin_bit_mask));
        // Direction
        PinDirection dir = vhal_rtl_giop_convert_dir(io_conf.mode);
        if (dir >= 0)
        {
            gpio_dir(&p_gpio_cfg[rtl_gpio_num-1].gpio_obj, dir);
        }
        else
        {
            rtl_gpio_num -= 1;      // 前面进行了加1，这里需要减掉
            return;
        }

        // pull
        PinMode pull_mode = vhal_rtl_giop_convert_pull_mode(io_conf.pull_up_en, io_conf.pull_down_en);
        if (pull_mode >= 0)
        {
            gpio_mode(&p_gpio_cfg[rtl_gpio_num-1].gpio_obj, pull_mode);
        }
        else
        {
            rtl_gpio_num -= 1;      // 前面进行了加1，这里需要减掉
            return;
        }

        // 更新指针，先释放旧的指针指向的空间，然后指向新的空间
        if (NULL != s_rtl_gpio_cfg)
        {
            free(s_rtl_gpio_cfg);
        }
        s_rtl_gpio_cfg = p_gpio_cfg;
    }
}

/**
 * @brief  GPIO电平获取函数
 * @param[in]  gpio_num             [GPIO编号]
 * @return     int                  [输出电平(0为低电平，1为高电平)]
 */
int32_t vhal_gpio_get_output(uint8_t gpio_num)
{
    int32_t val = 0;
    gpio_t *p_gpio = NULL;

    p_gpio = vhal_rtl_giop_get_gpio_obj(gpio_num);
    if (NULL != p_gpio)
    {
        val = gpio_read(p_gpio);
        //HAL_LOG(LOG_DEBUG, "gpio[%d] get output %d.\n", gpio_num, val);
    }
    else
    {
        HAL_LOG(LOG_ERROR, "gpio obj is null!!\n");
        return -1;
    }

    return val;
}

/**
 * @brief  设置GPIO输出电平函数
 * @param[in]  gpio_num             [GPIO编号]
 * @param[in]  level                [输出电平，0: low ; 1: high]
 * @return     int                  [成功/失败]
 */
int32_t vhal_gpio_set_output(uint8_t gpio_num, uint32_t level)
{
    gpio_t *p_gpio = NULL;

    if (level > 1)
    {
        HAL_LOG(LOG_ERROR, "gpio level(%d) is invaild!!\n", level);
        return VHAL_FAIL;
    }

    p_gpio = vhal_rtl_giop_get_gpio_obj(gpio_num);
    if (NULL != p_gpio)
    {
        gpio_write(p_gpio, level);
        //gpio_direct_write(p_gpio, level);
        //HAL_LOG(LOG_DEBUG, "gpio[%d] set output %d\n", gpio_num, level);
    }
    else
    {
        HAL_LOG(LOG_ERROR, "gpio obj is null!!\n");
        return VHAL_FAIL;
    }

    return VHAL_OK;
}

/**
 * @brief  GPIO状态变更
 * @param[in]  gpio_num             [GPIO编号]
 * @param[in]  pullup               [true时表示GPIO需要pullup；false时表示GPIO需要pulldown]
 * @param[in]  enable               [true表示使能pullup/pulldown；false表示禁用pullup/pulldown]
 * @return     void
 */
void vhal_gpio_change_pull_status(uint8_t gpio_num, bool pullup, bool enable)
{
    gpio_t *p_gpio = NULL;

    p_gpio = vhal_rtl_giop_get_gpio_obj(gpio_num);
    if (NULL != p_gpio)
    {
        if (pullup)
        {
            gpio_pull_ctrl(p_gpio, PullUp);
        }
        else
        {
            gpio_pull_ctrl(p_gpio, PullDown);
        }
    }
    else
    {
        HAL_LOG(LOG_ERROR, "gpio obj is null!!\n");
    }
}

/**
 * @brief  GPIO设置方向
 * @param[in]  gpio_num             [GPIO编号]
 * @param[in]  mode                 [GPIO方向]
 * @return     void
 */
void vhal_gpio_set_direction(uint8_t gpio_num, GPIO_MODE_E mode)
{
    gpio_t *p_gpio = NULL;

    p_gpio = vhal_rtl_giop_get_gpio_obj(gpio_num);
    if (NULL != p_gpio)
    {
        PinDirection dir = vhal_rtl_giop_convert_dir(mode);
        if (dir >= 0)
        {
            gpio_dir(p_gpio, dir);
            HAL_LOG(LOG_DEBUG, "gpio[%d] set direction %d.\n", gpio_num, mode);
        }
    }
    else
    {
        HAL_LOG(LOG_ERROR, "gpio obj is null!!\n");
        return;
    }
}

void vhal_gpio_register_intr_cb(uint8_t gpio_num, GPIO_INTR_TYPE_E intr_type, vhal_gpio_int_cb_t cb_func, void *arg)
{

}

