/**
*Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file    lightstring_production.h
* @brief   灯串产测模块
* @author  Lind
*@date     2021-12-20
*/

#ifndef __LIGHTSTRING_PRODUCTION_H__
#define __LIGHTSTRING_PRODUCTION_H__

#ifdef __cplusplus
extern "C" {
#endif


/**
* @brief lightstring产测功能初始化
*/
void ls_production_init(void);

#ifdef __cplusplus
}
#endif

#endif

