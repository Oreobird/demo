/***
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file    vhal_wifi.c
 * @brief   bl602 Wi-Fi驱动硬件抽象层
 * @author  Charles.Mei
 * @date    2021-3-8
 */


#include <string.h>
#include <stdlib.h>
#include <FreeRTOS.h>
#include <event_groups.h>
#include <bl60x_wifi_driver/bl_main.h>
#include <aos/kernel.h>
#include <aos/yloop.h>
#include <bl60x_fw_api.h>
#include <bl60x_wifi_driver/wifi_mgmr.h>
#include <wifi_mgmr_ext.h>
#include <hal_sys.h>
#include <hal_wifi.h>
#include "lwip/dns.h"

#include "vesync_log.h"
#include "vhal_wifi.h"
#include "vhal_wifi_internal.h"


// wifi连接状态回调函数指针, vesync_connect_wifi_callback()
static vhal_wifi_status_cb_t s_vhal_wifi_status_cb = NULL;

// 保存扫描结果到WiFi扫描列表管理模块回调函数
static vhal_wifi_scan_cb_t s_vhal_wifi_scan_cb = NULL;

// WIFI断开连接时传递错误码和错误描述的callback
static vhal_wifi_disc_log_cb_t s_vhal_wifi_disc_log_cb = NULL;


static EventGroupHandle_t s_bl_wifi_event_group = NULL;     //网络事件标志组，从右往左，0位表示wifi状态，1位表示网络状态，置位代表连接成功
static uint8_t s_wifi_scan_status = 0;                      // 扫描WiFi列表状态,0表示不在扫描状态，1表示正在扫描
static uint8_t s_wifi_stopping = 0;                         // wifi停止标志位，用于忽略stop后产生的disconnect事件

static VHAL_WIFI_MODE_E s_wifi_mode = VHAL_WIFI_MODE_NULL;      // Wi-Fi工作模式
static VHAL_WIFI_STATUS_E s_wifi_status = VHAL_WIFI_INIT;       // Wi-Fi连接状态
static VHAL_WIFI_PS_TYPE_E s_wifi_ps_type = VHAL_WIFI_PS_NONE;  // Wi-Fi节能模式



/* Wi-Fi配置 */
wifi_conf_t s_wifi_conf =
{
    .country_code = "CN",
    .channel_nums = 0
};

static vhal_wifi_sta_cfg_t s_wifi_conn;                 // 保存连接参数


/**
 * @brief Wi-Fi连接
 */
static void vhal_bl_connect_wifi(void)
{
    wifi_interface_t wifi_interface;

    //wifi_interface = wifi_mgmr_sta_enable();
    if (!s_wifi_conn.ssid[0])
    {
        /* Won't connect, since ssid config is empty */
        return;
    }
    s_wifi_stopping = 0;

    /* We believe that when ssid is set, wifi_confi is OK */
    wifi_interface = wifi_mgmr_sta_enable();
    HAL_LOG(LOG_INFO, "Wi-Fi start connect...........\r\n");
    HAL_LOG(LOG_DEBUG,
            "SSID: %s\r\n",
            "PWD: %s\r\n",
            "channel band: %d\r\n",
            s_wifi_conn.ssid,
            s_wifi_conn.pwd,
            s_wifi_conf.channel_nums
    );
    wifi_mgmr_sta_connect(wifi_interface, s_wifi_conn.ssid, s_wifi_conn.pwd, NULL, NULL, s_wifi_conf.channel_nums, 0);
}


/**
 * @brief stop wifi station
 */
static void vhal_wifi_stop_sta(void)
{
    if (s_wifi_stopping)
    {
        return;
    }

    s_wifi_stopping = 1;
    wifi_mgmr_sta_disconnect();
    /* XXX Must make sure sta is already disconnect, otherwise sta disable won't work */
    vTaskDelay(1000);
    wifi_mgmr_sta_disable(NULL);
    HAL_LOG(LOG_DEBUG, "Wi-Fi sta stop.\n");
}


/**
 * @brief  认证方式转换
 * @param[in]  auth_mode                [驱动返回的auth mode]
 * @return int                          [转换后的auth mode]
 */
static inline VHAL_WIFI_AUTH_MODE_E vhal_wifi_conv_auth_mode(uint16_t auth_mode)
{
    switch (auth_mode)
    {
    case WIFI_EVENT_BEACON_IND_AUTH_OPEN:
        return VHAL_WIFI_AUTH_OPEN;
    case WIFI_EVENT_BEACON_IND_AUTH_WEP:
        return VHAL_WIFI_AUTH_WEP;
    case WIFI_EVENT_BEACON_IND_AUTH_WPA_PSK:
        return VHAL_WIFI_AUTH_WPA_PSK;
    case WIFI_EVENT_BEACON_IND_AUTH_WPA2_PSK:
        return VHAL_WIFI_AUTH_WPA2_PSK;
    case WIFI_EVENT_BEACON_IND_AUTH_WPA_WPA2_PSK:
        return VHAL_WIFI_AUTH_WPA_WPA2_PSK;
    case WIFI_EVENT_BEACON_IND_AUTH_WPA_ENT:
        return VHAL_WIFI_AUTH_WPA2_ENTERPRISE;
    case WIFI_EVENT_BEACON_IND_AUTH_WPA3_SAE:
        return VHAL_WIFI_AUTH_WPA3_PSK;
    case WIFI_EVENT_BEACON_IND_AUTH_WPA2_PSK_WPA3_SAE:
        return VHAL_WIFI_AUTH_WPA2_WPA3_PSK;
    //case WIFI_EVENT_BEACON_IND_AUTH_UNKNOWN:
    default:
        return VHAL_WIFI_AUTH_MAX;
    }
}


/**
 * @brief  设置Wi-Fi节能模式
 * @param[in]  power_save               [Wi-Fi节能模式]
 */
static inline void vhal_wifi_set_ps_type(VHAL_WIFI_PS_TYPE_E power_save)
{
    switch (power_save)
    {
    case VHAL_WIFI_PS_NONE:
        wifi_mgmr_sta_powersaving(PS_MODE_OFF);
        break;
    case VHAL_WIFI_PS_LOW:
        wifi_mgmr_sta_powersaving(PS_MODE_ON);
        break;
    case VHAL_WIFI_PS_ULTRA_LOW:
        wifi_mgmr_sta_powersaving(PS_MODE_ON_DYN);
        break;
    default:
        HAL_LOG(LOG_ERROR, "invalid power mode!!!\r\n");
    }
}


/**
 * @brief  设置Wi-Fi状态，当状态发生改变时通知上层
 * @param[in]  new_status               [Wi-Fi状态]
 */
static inline void vhal_wifi_set_status(VHAL_WIFI_STATUS_E new_status)
{
    /* 网络状态发生改变，主动通知上一层(消息处理中心)     */
    s_wifi_status = new_status;
    HAL_LOG(LOG_DEBUG, "Wi-Fi new status is %d\n", new_status);
    // 定义：vesync_connect_wifi_callback()
    if(NULL != s_vhal_wifi_status_cb)
    {
        s_vhal_wifi_status_cb(new_status);
    }
}


/**
 * @brief  对比rssi值
 * @param[in]  new_status               [Wi-Fi状态]
 * @param[in]  p1                       [第一个rssi值]
 * @param[in]  p2                       [第二个rssi值]
 * @return  int                         [1大于，-1小于，0等于]
 */
static inline int rssi_compare(const void *p1, const void *p2)
{
    if (((wifi_mgmr_ap_item_t *)p1)->rssi < ((wifi_mgmr_ap_item_t *)p2)->rssi) {
        return 1;
    }
    if (((wifi_mgmr_ap_item_t *)p1)->rssi > ((wifi_mgmr_ap_item_t *)p2)->rssi) {
        return -1;
    }
    return 0;
}


/**
 * @brief 扫描AP命令
 */
static void wifiprov_scan()
{
    wifi_mgmr_ap_item_t *ap_ary = NULL, *pcur = NULL;
    uint32_t num = 0, i = 0;

    HAL_LOG(LOG_INFO, "Wi-Fi scan start......\r\n");
    wifi_mgmr_all_ap_scan(&ap_ary, &num);
    HAL_LOG(LOG_DEBUG, "Wi-Fi scan num:%d\r\n", num);

    qsort((void*)ap_ary, (size_t)num, sizeof(wifi_mgmr_ap_item_t), rssi_compare);
    pcur = ap_ary;
    for (i = 0; i < num; i++)
    {
        if (NULL == s_vhal_wifi_scan_cb)
        {
            continue;
        }
        s_vhal_wifi_scan_cb(pcur->bssid, (uint8_t *)pcur->ssid,
                    pcur->rssi, vhal_wifi_conv_auth_mode(pcur->auth), num);
        pcur = pcur+1;
    }

    if (ap_ary)
    {
        vPortFree(ap_ary);
    }

    vhal_wifi_set_status(VHAL_WIFI_SCAN_DONE);
}


/**
 * @brief  Wi-Fi连接事件应用程序任务回调函数
 * @param[in]  event                [wifi event callback]
 * @param[in]  private              [data past to cb]
 * @return     void                 [none]
 */
static void vhal_wifi_event_handler(input_event_t *event, void *private_data)
{
    switch (event->code) {
    case CODE_WIFI_ON_INIT_DONE:
    {
        wifi_mgmr_start_background(&s_wifi_conf);
    }
    break;
    case CODE_WIFI_ON_MGMR_DONE:
    {
        vhal_bl_connect_wifi();
    }
    break;
    case CODE_WIFI_ON_SCAN_DONE:
    {
        HAL_LOG(LOG_DEBUG,
                "Wi-Fi SCAN Done %lld, SCAN Result: %s\r\n",
                aos_now_ms(),
                WIFI_SCAN_DONE_EVENT_OK == event->value ? "OK" : "Busy now");
        s_wifi_scan_status = 0;
        s_wifi_status = VHAL_WIFI_SCAN_DONE;
        return;
    }
    break;
    case CODE_WIFI_ON_DISCONNECT:
    {
        xEventGroupClearBits(s_bl_wifi_event_group, EVENT_BIT_NETWORK_STATUS);
        xEventGroupClearBits(s_bl_wifi_event_group, EVENT_BIT_WIFI_STATUS);
        if (1 == s_wifi_stopping)
        {
            vTaskDelay(1000);
            wifi_mgmr_sta_disable(NULL);
        }
        switch(event->value)
        {
        case WLAN_FW_SUCCESSFUL:
        case WLAN_FW_TX_AUTH_FRAME_ALLOCATE_FAIILURE:
        case WLAN_FW_AUTHENTICATION_FAIILURE:
        case WLAN_FW_AUTH_ALGO_FAIILURE:
        case WLAN_FW_TX_ASSOC_FRAME_ALLOCATE_FAIILURE:
        case WLAN_FW_ASSOCIATE_FAIILURE:
        case WLAN_FW_DEAUTH_BY_AP_WHEN_NOT_CONNECTION:
        case WLAN_FW_DEAUTH_BY_AP_WHEN_CONNECTION:
        case WLAN_FW_TX_AUTH_OR_ASSOC_FRAME_TRANSMIT_FAILURE:
        case WLAN_FW_CREATE_CHANNEL_CTX_FAILURE_WHEN_JOIN_NETWORK:
        case WLAN_FW_JOIN_NETWORK_FAILURE:
        case WLAN_FW_ADD_STA_FAILURE:
        case WLAN_FW_BEACON_LOSS:
            s_wifi_status = VHAL_WIFI_CONNECT_FAIL;
            HAL_LOG(LOG_ERROR, "Wi-Fi connect failed: %s!!!\r\n", wifi_mgmr_status_code_str(event->value));
            break;
        case WLAN_FW_4WAY_HANDSHAKE_ERROR_PSK_TIMEOUT_FAILURE:
        case WLAN_FW_4WAY_HANDSHAKE_TX_DEAUTH_FRAME_TRANSMIT_FAILURE:
        case WLAN_FW_4WAY_HANDSHAKE_TX_DEAUTH_FRAME_ALLOCATE_FAIILURE:
            s_wifi_status = VHAL_WIFI_WRONG_PWD;
            HAL_LOG(LOG_ERROR, "Wi-Fi connect failed: %s!!!\r\n", wifi_mgmr_status_code_str(event->value));
            break;
        case WLAN_FW_SCAN_NO_BSSID_AND_CHANNEL:
            s_wifi_status = VHAL_WIFI_NO_AP_FOUND;
            HAL_LOG(LOG_ERROR, "Wi-Fi connect failed: %s!!!\r\n", wifi_mgmr_status_code_str(event->value));
            break;
        default:
            s_wifi_status = VHAL_WIFI_CONNECT_FAIL;
            HAL_LOG(LOG_ERROR, "Wi-Fi connect failed: %s!!!\r\n", wifi_mgmr_status_code_str(event->value));
        }
        if(NULL != s_vhal_wifi_disc_log_cb)
        {
            s_vhal_wifi_disc_log_cb(wifi_mgmr_status_code_str(event->value));
        }
    }
    break;
    case CODE_WIFI_ON_CONNECTING:
    {
        s_wifi_status = VHAL_WIFI_CONNECTING;
    }
    break;
    case CODE_WIFI_CMD_RECONNECT:
    {
        HAL_LOG(LOG_INFO, "Wi-Fi Reconnect %lld.\r\n", aos_now_ms());
    }
    break;
    case CODE_WIFI_ON_CONNECTED:
    {
        xEventGroupSetBits(s_bl_wifi_event_group, EVENT_BIT_WIFI_STATUS);
        s_wifi_status = VHAL_WIFI_CONNECTED;
        /* 非sta模式下，提前设置节能可能导致软件重启后卡死 */
        //vhal_wifi_set_ps_type(s_wifi_ps_type);
        HAL_LOG(LOG_INFO, "Wi-Fi connected %lld.\r\n", aos_now_ms());
    }
    break;
    case CODE_WIFI_ON_PRE_GOT_IP:
    {
        //printf("[APP] [EVT] connected %lld\r\n", aos_now_ms());
    }
    break;
    case CODE_WIFI_ON_GOT_IP:
    {
        xEventGroupSetBits(s_bl_wifi_event_group, EVENT_BIT_NETWORK_STATUS);
        s_wifi_status =VHAL_WIFI_GOT_IP;
        HAL_LOG(LOG_INFO, "Wi-Fi GOT IP %lld.\r\n", aos_now_ms());
        HAL_LOG(LOG_INFO, "[SYS] Memory left is %d Bytes.\r\n", xPortGetFreeHeapSize());
    }
    break;
    case CODE_WIFI_ON_AP_STARTED:
    {
        HAL_LOG(LOG_INFO, "Wi-Fi AP STARTED %lld.\r\n", aos_now_ms());
    }
    break;
    case CODE_WIFI_ON_AP_STOPPED:
    {
        HAL_LOG(LOG_INFO, "Wi-Fi AP STOPPED %lld.\r\n", aos_now_ms());
    }
    break;
    case CODE_WIFI_ON_PROV_SSID:
    {
        /* nothing */
    }
    break;
    case CODE_WIFI_ON_PROV_BSSID:
    {
        /* nothing */
    }
    break;
    case CODE_WIFI_ON_PROV_PASSWD:
    {
        /* nothing */
    }
    break;
    case CODE_WIFI_ON_PROV_CONNECT:
    {
        vhal_bl_connect_wifi();
    }
    break;
    case CODE_WIFI_ON_PROV_DISCONNECT:
    {
        wifi_mgmr_sta_disconnect();
        /* XXX Must make sure sta is already disconnect, otherwise sta disable won't work */
        vTaskDelay(1000);
        wifi_mgmr_sta_disable(NULL);
        HAL_LOG(LOG_INFO, "wifi sta stop.\r\n");
    }
    break;
    case CODE_WIFI_ON_PROV_SCAN_START:
    {
        //printf("[APP] [EVT] [PROV] [SCAN] %lld\r\n", aos_now_ms());
        wifiprov_scan();
    }
    break;
    case CODE_WIFI_ON_PROV_STATE_GET:
    {
        //printf("[APP] [EVT] [PROV] [STATE] %lld\r\n", aos_now_ms());
        //wifiprov_wifi_state_get((void *)event->value);
    }
    break;
    case CODE_WIFI_ON_AP_STA_ADD:
    {
        HAL_LOG(LOG_INFO, "%lld, sta idx is %lu.\r\n", aos_now_ms(), (uint32_t)event->value);
    }
    break;
    case CODE_WIFI_ON_AP_STA_DEL:
    {
        HAL_LOG(LOG_INFO, "%lld, sta idx is %lu.\r\n", aos_now_ms(), (uint32_t)event->value);
    }
    break;
    case CODE_WIFI_ON_MGMR_DENOISE:
    {
        /* nothing */
    }
    break;
    /*case CODE_WIFI_ON_EMERGENCY_MAC:
    {
        printf("[APP] [EVT] EMERGENCY MAC %lld\r\n", aos_now_ms());
        hal_reboot();// one way of handling emergency is reboot. Maybe we should also consider solutions
    }
    break;*/
    default:
    {
        HAL_LOG(LOG_ERROR, "[APP] [EVT] Unknown code %u, %lld.\r\n", event->code, aos_now_ms());
        /* nothing */
    }
    }
    vhal_wifi_set_status(s_wifi_status);
}



/**
 * @brief  注册配网时需要的Wi-Fi回调函数
 * @param[in]  scan_cb                  [Wi-Fi列表扫描结果回调]
 * @param[in]  disconn_cb               [Wi-Fi断开连接时回调]
 * @return void
 */
void vhal_wifi_reg_netcfg_cb(vhal_wifi_scan_cb_t scan_cb, vhal_wifi_disc_log_cb_t disconn_cb)
{
    s_vhal_wifi_scan_cb = scan_cb;
    s_vhal_wifi_disc_log_cb = disconn_cb;
}

/**
 * @brief 撤销注册配网时需要的Wi-Fi回调函数
 */
void vhal_wifi_unreg_netcfg_cb(void)
{
    s_vhal_wifi_scan_cb = NULL;
    s_vhal_wifi_disc_log_cb = NULL;
}


/**
 * @brief  初始化Wi-Fi模块
 * @param[in]  status_cb                [Wi-Fi的连接状态回调函数]
 * @param[in]  power_save               [Wi-Fi节能模式标志位]
 * @param[in]  p_hostname               [DHCP hostname]
 * @param[in]  p_country_code           [长度为2byte的国家码，如：US、EU、CN]
 * @return void
 */
void vhal_wifi_init(vhal_wifi_status_cb_t status_cb, VHAL_WIFI_PS_TYPE_E power_save, char *p_hostname, char *p_country_code)
{
    static uint8_t stack_wifi_init  = 0;

    if (NULL != p_country_code)
    {
        memset(s_wifi_conf.country_code, 0, sizeof(s_wifi_conf.country_code));
        snprintf(s_wifi_conf.country_code, sizeof(s_wifi_conf.country_code), "%s", p_country_code);
    }

    if (NULL != p_hostname)
    {
        memset(s_wifi_conf.hostname, 0, sizeof(s_wifi_conf.hostname));
        snprintf(s_wifi_conf.hostname, sizeof(s_wifi_conf.hostname), "%s", p_hostname);
    }

    memset((uint8_t *)&s_wifi_conn, 0, sizeof(s_wifi_conn));

    // 创建网络事件标志组，网络状态发生变化时及时通知上层
    s_bl_wifi_event_group = xEventGroupCreate();
    if (NULL == s_bl_wifi_event_group)
    {
        HAL_LOG(LOG_ERROR, "Create network event group fail!!!\r\n");
        /* how to deal? reboot? */
    }

    s_wifi_ps_type = power_save;
    s_vhal_wifi_status_cb = status_cb;
    aos_register_event_filter(EV_WIFI, vhal_wifi_event_handler, NULL);

    /*wifi fw stack and thread stuff*/
    if (0 == stack_wifi_init)
    {
        stack_wifi_init = 1;
        hal_wifi_start_firmware_task();
        //aos_post_event(EV_WIFI, CODE_WIFI_ON_INIT_DONE, 0);
        wifi_mgmr_start_background(&s_wifi_conf);
    }
    //vhal_change_dhcp_hostname(s_bl_hostname);

    HAL_LOG(LOG_INFO, "Wi-Fi init done\r\n");
}


/**
 * @brief  卸载Wi-Fi驱动
 * @return void
 */
void vhal_wifi_deinit(void)
{
    s_vhal_wifi_status_cb = NULL;
    vhal_wifi_stop();
    vTaskDelay(pdMS_TO_TICKS(3000));
    s_wifi_mode = VHAL_WIFI_MODE_NULL;
    vEventGroupDelete(s_bl_wifi_event_group);
    s_bl_wifi_event_group = NULL;
    aos_unregister_event_filter(EV_WIFI, vhal_wifi_event_handler, NULL);
}


/**
 * @brief  Wi-Fi运行在STA模式时，与router AP的连接状态
 * @param[in]  wait_time_ms             [最大阻塞等待时间]
 * @return     bool                     [关联AP成功且获取IP成功，返回true；否则返回false]
 */
bool vhal_wifi_get_link_status(int32_t wait_time_ms)
{

    uint32_t event_bits;

    if (NULL == s_bl_wifi_event_group)
    {
        HAL_LOG(LOG_ERROR, "s_bl_wifi_event_group is null!!!\n");
        return false;
    }

    event_bits = xEventGroupWaitBits(s_bl_wifi_event_group,
                              EVENT_BIT_NETWORK_STATUS,
                              pdFALSE,
                              pdTRUE,
                              (TickType_t)wait_time_ms / portTICK_RATE_MS);

    return ((event_bits & EVENT_BIT_NETWORK_STATUS) ? true : false);
}


/**
 * @brief 设备作为STA时，与AP关联成功，检测到AP的接收信号强度
 * @param[in]  points                   [循环检测的次数]
 * @return     int                      [平均rssi(连续point个测试数据取平均)]
 */
int vhal_wifi_get_router_rssi(int points)
{
    int avg_rssi = 0;

    UNUSED(points);

    wifi_mgmr_rssi_get(&avg_rssi);
    HAL_LOG(LOG_DEBUG, "Router AP rssi strength is %d.\r\n", avg_rssi);

    return avg_rssi;
}

/**
 * @brief 获取当前Wi-Fi信道
 * @return     int                      [Wi-Fi工作信道]
 */
int vhal_wifi_get_channel(void)
{
    int chan = 0;
    wifi_mgmr_sta_connect_ind_stat_info_t wifi_mgmr_ind_stat;

    wifi_mgmr_sta_connect_ind_stat_get(&wifi_mgmr_ind_stat);

    //TODO: for band 5g
    if (wifi_mgmr_ind_stat.chan_freq >=2412 && wifi_mgmr_ind_stat.chan_freq <=2472)
    {
        chan = (wifi_mgmr_ind_stat.chan_freq - 2407)/5;
    }
    else if (wifi_mgmr_ind_stat.chan_freq == 2484)
    {
        chan = 14;
    }

    HAL_LOG(LOG_DEBUG, "current channel is %d(%d).\r\n", chan, wifi_mgmr_ind_stat.chan_freq);
    if (chan > 0 && chan <= 14)
    {
        s_wifi_conf.channel_nums = chan;
    }
    return chan;
}

/**
 * @brief 设备作为STA时，获取当前连接路由器成功所使用的ssid和密码。
 * @param[out] p_sta_cfg                [保存Wi-Fi连接使用的ssid和密码]
 * @return     int                      [执行成功，返回OK；执行失败，返回FAIL]
 */
int vhal_wifi_get_sta_cfg(vhal_wifi_sta_cfg_t *p_sta_cfg)
{
    wifi_mgmr_sta_connect_ind_stat_info_t wifi_mgmr_ind_stat;

    VCOM_NULL_PARAM_CHK(p_sta_cfg, return VHAL_FAIL);

    memset((uint8_t *)p_sta_cfg, 0, sizeof(vhal_wifi_sta_cfg_t));
    memset((uint8_t *)&wifi_mgmr_ind_stat, 0, sizeof(wifi_mgmr_ind_stat));

    wifi_mgmr_sta_connect_ind_stat_get(&wifi_mgmr_ind_stat);
    strncpy(p_sta_cfg->ssid, wifi_mgmr_ind_stat.ssid, strlen(wifi_mgmr_ind_stat.ssid));
    strncpy(p_sta_cfg->pwd, wifi_mgmr_ind_stat.psk, strlen(wifi_mgmr_ind_stat.psk));
    //p_sta_cfg->auth_mode = VHAL_WIFI_AUTH_OPEN;

    return VHAL_OK;
}


/**
 * @brief  设备作为STA，主动发起关联AP
 * @param[in]  p_ssid                   [Wi-Fi的名称]
 * @param[in]  p_pwd                    [Wi-Fi的密码]
 * @param[in]  auth_mode                [Wi-Fi加密模式]
 * @return     int                      [执行成功，返回OK；执行失败，返回FAIL]
 */
int vhal_wifi_connect(const char *p_ssid, const char *p_pwd, VHAL_WIFI_AUTH_MODE_E auth_mode)
{
    vhal_wifi_sta_cfg_t wifi_cfg;

    HAL_LOG(LOG_DEBUG, "Wi-Fi connect\r\n");
    VCOM_NULL_PARAM_CHK(p_ssid, return VHAL_FAIL);

    UNUSED(auth_mode);

    if (VHAL_WIFI_GOT_IP == s_wifi_status)
    {
        vhal_wifi_get_sta_cfg(&wifi_cfg);
        if ((0 == strcmp(wifi_cfg.ssid, p_ssid)) && (0 == strcmp(wifi_cfg.pwd, p_pwd)))
        {
            HAL_LOG(LOG_INFO, "Wi-Fi sta has been associated(%s/%s).\r\n", p_ssid, p_pwd);
            return VHAL_OK;
        }
    }

    if ((VHAL_WIFI_GOT_IP == s_wifi_status) || (VHAL_WIFI_CONNECTED == s_wifi_status))
    {
        //HAL_LOG(LOG_INFO, "Wi-Fi disconnect......\r\n");
        //vhal_wifi_stop_sta();
    }

    strncpy(s_wifi_conn.ssid, p_ssid, sizeof(s_wifi_conn.ssid));
    if (NULL == p_pwd)
    {
        memset(s_wifi_conn.pwd, 0, sizeof(s_wifi_conn.pwd));
    }
    else
    {
        strncpy(s_wifi_conn.pwd, p_pwd, sizeof(s_wifi_conn.pwd));
    }

    if (VHAL_WIFI_MODE_AP == s_wifi_mode)
    {
        s_wifi_mode = VHAL_WIFI_MODE_APSTA;
    }
    else
    {
        s_wifi_mode = VHAL_WIFI_MODE_STA;
    }
    //aos_post_event(EV_WIFI, CODE_WIFI_ON_PROV_CONNECT, 0);
    vhal_bl_connect_wifi();

    return VHAL_OK;
}

/**
 * @brief Wi-Fi启动
 * @return void
 */
void vhal_wifi_start(void)
{
    if (VHAL_WIFI_MODE_NULL == s_wifi_mode)
    {
        HAL_LOG(LOG_ERROR, "Wi-Fi run no mode.\r\n");

    }
    else if (VHAL_WIFI_MODE_STA == s_wifi_mode)
    {
        //aos_post_event(EV_WIFI, CODE_WIFI_ON_PROV_CONNECT, 0);
        vhal_bl_connect_wifi();
    }
    else if (VHAL_WIFI_MODE_AP == s_wifi_mode)
    {
        /* nothing */
    }
    else if (VHAL_WIFI_MODE_APSTA == s_wifi_mode)
    {
        s_wifi_mode = VHAL_WIFI_MODE_STA;
        //aos_post_event(EV_WIFI, CODE_WIFI_ON_PROV_CONNECT, 0);
        vhal_bl_connect_wifi();
    }
    else
    {
        /* start other mode */
    }
}

/**
 * @brief Wi-Fi停止
 * @return void
 */
void vhal_wifi_stop(void)
{
    if (VHAL_WIFI_MODE_NULL == s_wifi_mode)
    {
        HAL_LOG(LOG_INFO, " wifi stop already.\r\n");
        return;
    }
    else if (VHAL_WIFI_MODE_STA == s_wifi_mode)
    {
        vhal_wifi_stop_sta();
    }
    else if (VHAL_WIFI_MODE_AP == s_wifi_mode)
    {
        //s_wifi_mode = VHAL_WIFI_MODE_NULL;
        s_wifi_mode = VHAL_WIFI_MODE_STA;
        wifi_mgmr_ap_stop(NULL);
        HAL_LOG(LOG_DEBUG, "wifi ap stop.\r\n");
    }
    else if (VHAL_WIFI_MODE_APSTA == s_wifi_mode)
    {
        vhal_wifi_stop_sta();
        wifi_mgmr_ap_stop(NULL);
        HAL_LOG(LOG_DEBUG, "wifi stop.\r\n");
    }
    else
    {
        /* stop other mode */
    }
    s_wifi_status = VHAL_WIFI_INIT;
}


/**
 * @brief  Wi-Fi开始扫描周围的AP热点
 * @return      int                     [执行成功，返回OK；执行失败，返回FAIL]
 */
int vhal_wifi_scan_start(void)
{
    s_wifi_scan_status = 1;
    wifiprov_scan();
    return VHAL_OK;
}


/**
 * @brief  Wi-Fi停止扫描AP热点
 * @return      int                     [执行成功，返回OK；执行失败，返回FAIL]
 */
int vhal_wifi_scan_stop(void)
{
    s_wifi_scan_status = 0;
    /* nothing to do or delay to wait scan end */
    return VHAL_OK;
}

/**
 * @brief 获取Wi-Fi扫描AP热点的状态
 * @return bool  正在扫描，返回true；否则返回false
 */
bool vhal_wifi_get_scan_status(void)
{
    return (s_wifi_scan_status == 1);
}

/**
 * @brief 关闭Wi-Fi的AP模式，不影响STA接口
 * @return     void            [none]
 */
void vhal_wifi_stop_ap_mode(void)
{
    if (VHAL_WIFI_MODE_AP == s_wifi_mode || VHAL_WIFI_MODE_APSTA == s_wifi_mode)
    {
        /*if (VHAL_WIFI_MODE_APSTA == s_wifi_mode)
        {
            s_wifi_mode = VHAL_WIFI_MODE_STA;
        }
        else
        {
            s_wifi_mode = VHAL_WIFI_MODE_NULL;
        }*/
        s_wifi_mode = VHAL_WIFI_MODE_STA;
        wifi_mgmr_ap_stop(NULL);
        HAL_LOG(LOG_DEBUG, "wifi ap stop.\r\n");
    }
}

/**
 * @brief 切换Wi-Fi运行模式
 * @param[in]  VHAL_WIFI_MODE_E         [Wi-Fi模式(AP/APSTA)]
 * @return     int                      [执行成功，返回OK；执行失败，返回FAIL]
 */
int vhal_wifi_change_wifi_mode(VHAL_WIFI_MODE_E wifi_mode)
{
    if (wifi_mode == s_wifi_mode)
    {
        return VHAL_OK;
    }
    vhal_wifi_stop();
    vTaskDelay(pdMS_TO_TICKS(3000));
    switch (wifi_mode)
    {
        case VHAL_WIFI_MODE_STA:
        case VHAL_WIFI_MODE_AP:
        case VHAL_WIFI_MODE_APSTA:
        default:
            /* nothing */
            break;
    }
    s_wifi_mode = wifi_mode;
    vhal_wifi_start();
    return VHAL_OK;
}

/**
 * @brief 硬件抽象层设置设备为WiFi热点
 * @param[in]  wifi_mode  Wi-Fi模式(AP/APSTA)
 * @param[in]  ssid                     [ssid名称]
 * @param[in]  pwd                      [Wi-Fi密码]
 * @param[in]  chan                     [Wi-Fi信道]
 * @param[in]  auth_mode                [加密方式]
 * @return     int                      [执行成功，返回OK；执行失败，返回FAIL]
 */
int vhal_wifi_setup_ap_cfg(VHAL_WIFI_MODE_E wifi_mode, char *ssid, char* pwd, uint8_t chan, uint8_t auth_mode)
{
    wifi_interface_t wifi_interface;

    UNUSED(auth_mode);

    if (VHAL_WIFI_MODE_AP != wifi_mode && VHAL_WIFI_MODE_APSTA != wifi_mode)
    {
        HAL_LOG(LOG_ERROR, "Unknown Wi-Fi mode (%d)!!!\r\n", wifi_mode);
        return VHAL_FAIL;
    }

    if (NULL == ssid)
    {
        HAL_LOG(LOG_ERROR, "ssid null!!!\r\n");
        return VHAL_FAIL;
    }

    if (chan < VHAL_WIFI_2G4_CHAN1 && chan > VHAL_WIFI_2G4_CHAN13)
    {
        if (s_wifi_conf.channel_nums >= VHAL_WIFI_2G4_CHAN1 && s_wifi_conf.channel_nums <= VHAL_WIFI_2G4_CHAN13)
        {
            chan = s_wifi_conf.channel_nums;
        }
        else
        {
            chan = VHAL_WIFI_2G4_CHAN1;// 参数错误的情况下换用合法值
        }
    }

    vhal_wifi_stop();
    vTaskDelay(pdMS_TO_TICKS(3000));
    s_wifi_mode = wifi_mode;
    if (VHAL_WIFI_MODE_APSTA == s_wifi_mode)
    {
        /* start不会启动ap模式 */
        vhal_wifi_start();
    }
    wifi_interface = wifi_mgmr_ap_enable();
    wifi_mgmr_ap_start(wifi_interface, ssid, 0, pwd, chan);
    return VHAL_OK;
}

int vhal_wifi_dns_setserver(uint8_t idx, char *ip_str)
{
    ip4_addr_t server_ip;
    if (NULL == ip_str)
    {
        return VHAL_FAIL;
    }

    if (ip4addr_aton(ip_str, &server_ip))
    {
        dns_setserver(idx, &server_ip);
        return VHAL_OK;
    }

    return VHAL_FAIL;
}

