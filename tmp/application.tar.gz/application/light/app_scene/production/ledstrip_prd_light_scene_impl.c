/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
* @file         prd_scene_impl.c
* @brief        产测场景回调业务实现
* @author       Joshua
* @date         2021-11-23
*/

#include <string.h>
#include "vesync_log.h"
#include "vesync_common.h"
#include "production_light.h"

static int ledstrip_production_pre_age_test(void)
{
    APP_LOG(LOG_DEBUG, "pre age test\n");
    return APP_OK;
}

static int ledstrip_production_age_testing(void)
{
    APP_LOG(LOG_DEBUG, "age testing\n");

    return APP_OK;
}

static int ledstrip_production_post_age_test(void)
{
    APP_LOG(LOG_DEBUG, "post age test\n");

    return APP_OK;
}

static int ledstrip_production_start(void)
{
    APP_LOG(LOG_DEBUG, "production start\n");

    return APP_OK;
}

static int ledstrip_production_running(void)
{
    APP_LOG(LOG_DEBUG, "production running\n");

    return APP_OK;
}

static int ledstrip_production_pass(void)
{
    APP_LOG(LOG_DEBUG, "production pass\n");

    return APP_OK;
}

static int ledstrip_production_fail(void)
{
    APP_LOG(LOG_DEBUG, "production fail\n");

    return APP_OK;
}

int prd_light_scene_impl_init(void)
{
    prd_light_scene_t light_scene;
    memset(&light_scene, 0, sizeof(prd_light_scene_t));
    light_scene.prd_age_test_pre_light = ledstrip_production_pre_age_test;
    light_scene.prd_age_testing_light = ledstrip_production_age_testing;
    light_scene.prd_age_test_post_light = ledstrip_production_post_age_test;
    light_scene.prd_start_light = ledstrip_production_start;
    light_scene.prd_running_light = ledstrip_production_running;
    light_scene.prd_pass_light = ledstrip_production_pass;
    light_scene.prd_fail_light = ledstrip_production_fail;

    return prd_light_scene_reg(&light_scene);
}
