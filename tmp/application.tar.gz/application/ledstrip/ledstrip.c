/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        ledstrip.c
 * @brief       Application入口函数
 * @author      Lind
 * @date        2021-08-25
 */
#include <stdio.h>

#include "vesync_init.h"
#include "vesync_common.h"
#include "vesync_init.h"
#include "vesync_log.h"
#include "vesync_queue.h"
#include "vesync_device.h"
#include "vesync_flash.h"
#include "vesync_production.h"
#include "vesync_netcfg.h"
#include "vesync_wifi_led.h"

#include "ledstrip.h"
#include "ledstrip_wifi_led.h"
#include "ledstrip_led.h"
#include "ledstrip_button.h"
#include "ledstrip_schedule.h"
#include "ledstrip_timing.h"
#include "ledstrip_production.h"
#include "ledstrip_bypass.h"
#include "ledstrip_report.h"
#include "ledstrip_flash.h"
#include "ledstrip_device.h"


// 应用层事件队列消息
static vesync_queue_t *s_event_queue = NULL;

static ls_led_rgb_t ls_led_mode_reset[2] = {{0, 0, 50, 0, 0}, {0, 0, 0, 0,0}};
// Reset设备灯效，红光慢闪5次，而后常亮
static ls_led_diverse_param_t s_ls_led_reset =
{
    .mode = LS_SCENE_SWITCH,
    .node_num = 2,
    .first_node = 0,
    .step_num = 25,
    .times = 5,
    .mode_head = ls_led_mode_reset,
};

/**
* @brief SDK层初始化前回调函数
*/
static void ledstrip_pre_cb(void)
{
    APP_LOG(LOG_DEBUG, " pre init callback\n");
}

/**
 * @brief  app任务事件处理
 * @param[in]    ev     [主任务事件结构体]
 */
static void app_event_handle(ls_ev_t ev)
{
    switch (ev.id)
    {
        case LS_EV_RESET:
            ls_led_set_led((void*)&s_ls_led_reset, LS_LED_ACT_SRC_RESET);
            ls_schedule_clear();
            vesync_sleep(3000);  // 为了重置灯效能够完成
            vesync_device_factory_reset(true, STAT_CHG_RSN_BTN_STR);
            break;
        case LS_EV_BEFORE_NETCFG:
            ls_wifi_set_netcfg_flag(true);
            vesync_wifi_led_set_behavior(WIFI_LED_NOT_CONFIG);
            break;
        case LS_EV_NETCFG:
            APP_LOG(LOG_INFO, "start netcfg\n");
            if (vesync_netcfg_is_running())
            {
                vesync_netcfg_stop();
            }

            vesync_netcfg_start();
            break;
        case LS_EV_PRODUCTION:
            APP_LOG(LOG_INFO, "enter production test mode !!\n");
            ls_clear_config();
            vesync_production_enter_testmode(true);
            break;
        default:
            APP_LOG(LOG_WARN, "Unknown event\n");
            break;
    }
}

/**
* @brief  app应用任务
*/
static void app_task(void *arg)
{
    UNUSED(arg);
    APP_LOG(LOG_DEBUG, "-------app task running--------\n");
    ls_ev_t ev;

    while(1)
    {
        int ret = vesync_queue_recv(s_event_queue, &ev, VESYNC_OS_WAIT_FOREVER);
        if (ret != VOS_OK)
        {
            APP_LOG(LOG_ERROR, "Event queue recv fail\n");
            return;
        }

        app_event_handle(ev);
    }

}

/**
* @brief SDK初始化结束后回调函数
*/
static void ledstrip_app_run(void)
{
    APP_LOG(LOG_DEBUG, " APP init start \n");
    ls_bypass_reg_cb();
    ls_button_init();
    ls_schedule_init();
    ls_timing_init();
    ls_report_init();
    ls_reg_wifi_led();
    ls_led_init();
    ls_production_init();
    ls_device_init();

    s_event_queue = vesync_queue_new(LS_EVENT_QUEUE_MAX_NUM * sizeof(ls_ev_t), sizeof(ls_ev_t));
    if (s_event_queue == NULL)
    {
        APP_LOG(LOG_ERROR, "App event queue create failed\n");
        return;
    }

    int ret = vesync_task_new(LS_APP_TASK_NAME, NULL, app_task, NULL, LS_APP_TASK_STACSIZE, LS_APP_TASK_PRIO, NULL);
    if (ret != VOS_OK)
    {
        APP_LOG(LOG_ERROR, "App task create failed\n");
        vesync_queue_free(s_event_queue);
        s_event_queue = NULL;
        return;
    }
}

/**
 * @brief  给ledstrip应用任务发通知
 * @param[in]   ev              [通知消息]
 * @return     int              [成功：APP_OK，失败：APP_FAIL]
 */
int ls_app_task_notify(ls_ev_t *ev)
{
    int ret = vesync_queue_send(s_event_queue, ev, VESYNC_OS_NO_WAIT);
    if (ret != VOS_OK)
    {
        APP_LOG(LOG_ERROR, "Event publish failed\n");
        return APP_FAIL;
    }

    return APP_OK;
}


/**
* @brief 应用入口
*/
void app_main()
{
    vesync_sdk_reg_pre_run_cb(ledstrip_pre_cb);
    vesync_sdk_reg_post_run_cb(ledstrip_app_run);

    vesync_sdk_run();

    APP_LOG(LOG_INFO, "Ledstrip app init\n");
}

