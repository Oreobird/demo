/**
* Copyright © Vesync Technologies Co.Ltd. 2022. All rights reserved.
* @file    led_strip_scene.c
* @brief   灯效模式参数
* @author  Lind
* @date     2021-12-19
*/

#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <stdio.h>

#include "vesync_log.h"
#include "vesync_common.h"
#include "vesync_bypass.h"
#include "vesync_memory.h"

#include "led_strip_scene.h"
#include "led_strip_board.h"
#include "led_strip_flash.h"

// 默认场景灯效
static ls_hsv_t breathing_all[14] = {{10000, 10000, 0}, {10000, 10000, 255}, {900, 10000, 0},
                                                        {900, 10000, 255}, {1668, 10000, 0},
                                                        {1668, 10000, 255}, {3334, 10000, 0},
                                                        {3334, 10000, 255}, {5001, 10000, 0},
                                                        {5001, 10000, 255}, {6668, 10000, 0},
                                                        {6668, 10000, 255}, {8333, 10000, 0},
                                                        {8333, 10000, 255}};
static ls_hsv_t gradient_flow[20] = {{0, 10000, 255},
                                     {1000, 10000, 255},
                                     {2000, 10000, 255},
                                     {3000, 10000, 255},
                                     {4000, 10000, 255},
                                     {5000, 10000, 255},
                                     {6000, 10000, 255},
                                     {7000, 10000, 255},
                                     {8000, 10000, 255},
                                     {9000, 10000, 255},
                                     {10000, 10000, 255},
                                     {9000, 10000, 255},
                                     {8000, 10000, 255},
                                     {7000, 10000, 255},
                                     {6000, 10000, 255},
                                     {5000, 10000, 255},
                                     {4000, 10000, 255},
                                     {3000, 10000, 255},
                                     {2000, 10000, 255},
                                     {1000, 10000, 255}};

static ls_hsv_t gradient_random[10] = {{1300, 10000, 255},
                                       {7300, 10000, 255},
                                       {2200, 10000, 255},
                                       {6000, 10000, 255},
                                       {8000, 10000, 255},
                                       {5500, 10000, 255},
                                       {6000, 10000, 255},
                                       {800, 10000, 255},
                                       {2000, 10000, 255},
                                       {9500, 10000, 255}};

static ls_hsv_t switch_jump[21] = {{0, 10000, 255}, {0, 10000, 255}, {0, 10000, 255},
                                   {900, 10000, 255}, {900, 10000, 255}, {900, 10000, 255},
                                   {1660, 10000, 255}, {1660, 10000, 255}, {1660, 10000, 255},
                                   {3333, 10000, 255}, {3333, 10000, 255}, {3333, 10000, 255},
                                   {4993, 10000, 255}, {4993, 10000, 255}, {4993, 10000, 255},
                                   {6667, 10000, 255}, {6667, 10000, 255}, {6667, 10000, 255},
                                   {8327, 10000, 255}, {8327, 10000, 255}, {8327, 10000, 255}};


static ls_hsv_t switch_step[4] = {{1200, 10000, 255},
                                  {5001, 10000, 255},
                                  {8333, 10000, 255},
                                  {3000, 8000, 255}};

static ls_hsv_t gradient_ocean[4] = {{4500, 5700, 255},
                                     {2780, 5600, 255},
                                     {4500, 5700, 255},
                                     {6000, 10000, 255}};
static ls_hsv_t gradient_forest[2] = {{1900, 8000, 255}, {2500, 10000, 255}};
static ls_hsv_t gradient_romantic[2] = {{9800, 8000, 255}, {9000, 10000, 255}};
static ls_hsv_t gradient_sunset[3] = {{450, 10000, 255},
                                      {600, 10000, 255},
                                      {800, 10000, 255}};
static ls_hsv_t gradient_star[12] = {{0, 0, 255}, {0, 0, 0}, {0, 0, 150}, {0, 0, 100},
                                     {0, 0, 255}, {0, 0, 0}, {0, 0, 255}, {0, 0, 0},
                                     {0, 0, 255}, {0, 0, 150}, {0, 0, 20}, {0, 0, 150}};

static ls_hsv_t switch_christmas[3] = {{0, 10000, 255},
                                       {920, 9000, 150},
                                       {3000, 10000, 255}};

static ls_hsv_t breathing_flow[42] = {{0, 10000, 0}, {0, 10000, 80}, {0, 10000, 150}, {0, 10000, 255}, {0, 10000, 150}, {0, 10000, 80},
                                      {900, 10000, 0}, {900, 10000, 80}, {900, 10000, 150}, {900, 10000, 255}, {900, 10000, 150}, {900, 10000, 80},
                                      {1660, 10000, 0}, {1660, 10000, 80}, {1660, 10000, 150}, {1660, 10000, 255}, {1660, 10000, 150}, {1660, 10000, 80},
                                      {3333, 10000, 0}, {3333, 10000, 80}, {3333, 10000, 150}, {3333, 10000, 255}, {3333, 10000, 150}, {3333, 10000, 80},
                                      {4993, 10000, 0}, {4993, 10000, 80}, {4993, 10000, 150}, {4993, 10000, 255}, {4993, 10000, 150}, {4993, 10000, 80},
                                      {6667, 10000, 0}, {6667, 10000, 80}, {6667, 10000, 150}, {6667, 10000, 255}, {6667, 10000, 150}, {6667, 10000, 80},
                                      {8327, 10000, 0}, {8327, 10000, 80}, {8327, 10000, 150}, {8327, 10000, 255}, {8327, 10000, 150}, {8327, 10000, 80}};

static ls_hsv_t s_brighten = {0, 0, 0, 100};

// 白光 模式1
static ls_static_param_t s_white =
{
    .mode = LS_LED_WHITE,
    .node_num = 1,
    .color_head = &s_brighten,
};

// 大海 模式2
static ls_dynamic_param_t s_ocean =
{
    .node_num = 4,
    .step_num = 150,
    .mode = LS_LED_GRADIENT,
    .diff_num = 0,
    .times = 0,
    .mode_head = gradient_ocean,
};

// 森林 模式3
static ls_dynamic_param_t s_forest =
{
    .node_num = 2,
    .step_num = 150,
    .mode = LS_LED_GRADIENT,
    .diff_num = 0,
    .times = 0,
    .mode_head = gradient_forest,
};

// 星夜 模式4
static ls_dynamic_param_t s_star =
{
    .node_num = 12,
    .step_num = 90,
    .mode = LS_LED_GRADIENT,
    .diff_num = 5,
    .times = 0,
    .mode_head = gradient_star,
};

// 日落 模式5
static ls_dynamic_param_t s_sunset =
{
    .node_num = 3,
    .step_num = 150,
    .mode = LS_LED_GRADIENT,
    .diff_num = 0,
    .times = 0,
    .mode_head = gradient_sunset,
};

// 浪漫 模式6
static ls_dynamic_param_t s_roman =
{
    .node_num = 2,
    .step_num = 150,
    .mode = LS_LED_GRADIENT,
    .diff_num = 0,
    .times = 0,
    .mode_head = gradient_romantic,
};

// 圣诞 模式7
static ls_dynamic_param_t s_christmas =
{
    .node_num = 3,
    .step_num = 50,
    .mode = LS_LED_SWITCH,
    .diff_num = 1,
    .times = 0,
    .mode_head = switch_christmas,
};

// 彩虹 模式8
static ls_dynamic_param_t s_gradient_rainbow =
{
    .node_num = 20,
    .step_num = 10,
    .mode = LS_LED_GRADIENT,
    .diff_num = 1,
    .times = 0,
    .mode_head = gradient_flow,
};

// 炫彩 模式9
static ls_dynamic_param_t s_gradient_random =
{
    .node_num = 10,
    .step_num = 400,
    .mode = LS_LED_GRADIENT,
    .diff_num = 7,
    .times = 0,
    .mode_head = gradient_random,
};

// 呼吸 模式10
static ls_dynamic_param_t s_breathing =
{
    .node_num = 14,
    .step_num = 100,
    .diff_num = 0,
    .mode = LS_LED_BREATHING,
    .times = 0,
    .mode_head = breathing_all,
};

// 闪烁 模式11
static ls_dynamic_param_t s_blink =
{
    .node_num = 14,
    .step_num = 40,
    .mode = LS_LED_SWITCH,
    .diff_num = 0,
    .times = 0,
    .mode_head = breathing_all,
};

// 渐变 模式12
static ls_dynamic_param_t s_gradient =
{
    .node_num = 20,
    .step_num = 80,
    .mode = LS_LED_GRADIENT,
    .diff_num = 0,
    .times = 0,
    .mode_head = gradient_flow,
};


// 流光 模式 13
static ls_dynamic_param_t s_flow_light =
{
    .node_num = 42,
    .step_num = 20,
    .mode = LS_LED_BREATHING,
    .diff_num = 1,
    .times = 0,
    .mode_head = breathing_flow,
};

// 追光 模式14
static ls_dynamic_param_t s_switch_step =
{
    .node_num = 4,
    .step_num = 20,
    .mode = LS_LED_SWITCH_STEP,
    .times = 0,
    .mode_head = switch_step,
};

// 跳变 模式15
static ls_dynamic_param_t s_jump =
{
    .node_num = 21,
    .step_num = 50,
    .mode = LS_LED_SWITCH,
    .diff_num = 3,
    .times = 0,
    .mode_head = switch_jump,
};

// 产测灯效
static ls_hsv_t switch_all[4] = {{0, 10000, 255, 0}, {3334, 10000, 255, 0}, {6667, 10000, 255, 0}, {0, 0, 0, 255}};

static ls_hsv_t s_green = {3334, 10000, 255, 0};

static ls_hsv_t s_red = {0, 10000, 255, 0};

// 进入产测
static ls_dynamic_param_t s_production0 =
{
    .node_num = 4,
    .step_num = 50,
    .mode = LS_LED_SWITCH,
    .diff_num = 0,
    .times = 0,
    .mode_head = switch_all,
};

// 连上产测服务器
static ls_static_param_t s_production1 =
{
    .mode = LS_LED_WHITE,
    .node_num = 1,
    .color_head = &s_brighten,
};

// 产测通过
static ls_static_param_t s_production2 =
{
    .mode = LS_LED_HSV,
    .node_num = 1,
    .color_head = &s_green,
};

// 产测失败
static ls_static_param_t s_production3 =
{
    .mode = LS_LED_HSV,
    .node_num = 1,
    .color_head = &s_red,
};

// wifi led
static ls_hsv_t switch_3[6] = {{0, 0, 0, 0}, {0, 0, 0, 255}};

static ls_dynamic_param_t s_befor_netcfg =
{
    .node_num = 2,
    .step_num = 25,
    .mode = LS_LED_SWITCH,
    .diff_num = 0,
    .times = 3,
    .mode_head = switch_3,
};

// reset
static ls_hsv_t reset_3[2] = {{0, 10000, 0, 0}, {0, 10000, 255, 0}};

static ls_dynamic_param_t s_reset =
{
    .node_num = 2,
    .step_num = 20,
    .mode = LS_LED_BREATHING,
    .diff_num = 0,
    .times = 3,
    .mode_head = reset_3,
};

static ls_static_param_t *s_custom_scene_list[LS_CUSTOM_SCENE_MAX_NUM];    // 自定义场景列表
static uint16_t s_id_list[LS_DEFAULT_SCENE_NUM + LS_CUSTOM_SCENE_MAX_NUM]; // 场景id 数组

// APP主控显示数据
static ls_scene_t s_scene;
static ls_static_param_t s_static_scene;


/**
* @brief 清除应用层保存的场景数据
*/
void ls_scene_clear(void)
{
    memset(s_id_list, 0, (LS_DEFAULT_SCENE_NUM + LS_CUSTOM_SCENE_MAX_NUM) * sizeof(s_id_list[0]));
    for (uint8_t i = 0; i < LS_CUSTOM_SCENE_MAX_NUM; i++)
    {
        if (s_custom_scene_list[i] != NULL)
        {
            VCOM_SAFE_FREE(s_custom_scene_list[i]->color_head);
        }
        VCOM_SAFE_FREE(s_custom_scene_list[i]);
    }
}

/**
* @brief 获取默认场景参数
* @param[in]  id        [id]
* @return  ls_scene_t*  [场景指针]
*/
ls_scene_t *ls_get_default_scene(uint16_t id)
{
    switch (id)
    {
        case 1:
            s_scene.light_mode = LS_LED_MODE_STATIC;
            s_scene.param.static_param = &s_white;
            break;
        case 2:
            s_scene.light_mode = LS_LED_MODE_DYNAMIC;
            s_scene.param.dynamic_param = &s_ocean;
            break;
        case 3:
            s_scene.light_mode = LS_LED_MODE_DYNAMIC;
            s_scene.param.dynamic_param = &s_forest;
            break;
        case 4:
            s_scene.light_mode = LS_LED_MODE_DYNAMIC;
            s_scene.param.dynamic_param = &s_sunset;
            break;
        case 5:
            s_scene.light_mode = LS_LED_MODE_DYNAMIC;
            s_scene.param.dynamic_param = &s_roman;
            break;
        case 6:
            s_scene.light_mode = LS_LED_MODE_DYNAMIC;
            s_scene.param.dynamic_param = &s_breathing;
            break;
        case 7:
            s_scene.light_mode = LS_LED_MODE_DYNAMIC;
            s_scene.param.dynamic_param = &s_blink;
            break;
        case 8:
            s_scene.light_mode = LS_LED_MODE_DYNAMIC;
            s_scene.param.dynamic_param = &s_gradient;
            break;
        case 9:
            s_scene.light_mode = LS_LED_MODE_DYNAMIC;
            s_scene.param.dynamic_param = &s_star;
            break;
        case 10:
            s_scene.light_mode = LS_LED_MODE_DYNAMIC;
            s_scene.param.dynamic_param = &s_christmas;
            break;
        case 11:
            s_scene.light_mode = LS_LED_MODE_DYNAMIC;
            s_scene.param.dynamic_param = &s_gradient_rainbow;
            break;
        case 12:
            s_scene.light_mode = LS_LED_MODE_DYNAMIC;
            s_scene.param.dynamic_param = &s_gradient_random;
            break;
        case 13:
            s_scene.light_mode = LS_LED_MODE_DYNAMIC;
            s_scene.param.dynamic_param = &s_flow_light;
            break;
        case 14:
            s_scene.light_mode = LS_LED_MODE_DYNAMIC;
            s_scene.param.dynamic_param = &s_switch_step;
            break;
        case 15:
            s_scene.light_mode = LS_LED_MODE_DYNAMIC;
            s_scene.param.dynamic_param = &s_jump;
            break;
        case 20:
            // 未配网灯效
            s_scene.light_mode = LS_LED_MODE_DYNAMIC;
            s_scene.param.dynamic_param = &s_befor_netcfg;
            break;
        case 30:
            // 30以上为产测灯效
            s_scene.light_mode = LS_LED_MODE_DYNAMIC;
            s_scene.param.dynamic_param = &s_production0;
            break;
        case 31:
            s_scene.light_mode = LS_LED_MODE_STATIC;
            s_scene.param.static_param = &s_production1;
            break;
        case 32:
            s_scene.light_mode = LS_LED_MODE_STATIC;
            s_scene.param.static_param = &s_production2;
            break;
        case 33:
            s_scene.light_mode = LS_LED_MODE_STATIC;
            s_scene.param.static_param = &s_production3;
            break;
        case 50:
            s_scene.light_mode = LS_LED_MODE_DYNAMIC;
            s_scene.param.dynamic_param = &s_reset;
            break;
        default:
            APP_LOG(LOG_ERROR, "Wrong id ! \n");
            break;
    }

    return &s_scene;
}

/**
* @brief 获取sceneId对应的场景序号
* @param[in]  id                [id]
* @param[in]  custom_scene_num  [自定义场景数量]
* @param[out]  *index           [序号]
* @return  int                  [APP_OK/APP_FAIL]
*/
int ls_get_id_index(uint16_t id, uint8_t custom_scene_num, uint8_t *index)
{
    VCOM_NULL_PARAM_CHK(index, return APP_FAIL);
    uint8_t i;
    for (i = 0; i < (LS_DEFAULT_SCENE_NUM + custom_scene_num); i++)
    {
        if (s_id_list[i] == id)
        {
            *index = i;
            return APP_OK;
        }
    }

    return APP_FAIL;
}

/**
* @brief 获取场景Id对应的参数指针
* @param[in/out]  *scene_id     [场景id]
* @param[in]  custom_scene_num  [自定义场景数量]
* @param[in]  next_flag         [是否获取下一个场景id的参数]
* @param[out] **p_scene         [场景参数]
* @return     int               [APP_OK/APP_FAIL]
*/
int ls_get_scene_pointer(uint16_t *scene_id, uint8_t custom_scene_num, bool next_flag, ls_scene_t **p_scene)
{
    VCOM_NULL_PARAM_CHK(scene_id , return APP_FAIL);
    VCOM_NULL_PARAM_CHK(p_scene , return APP_FAIL);
    uint8_t i = 0;
    if (APP_FAIL == ls_get_id_index(*scene_id, custom_scene_num, &i))
    {
        APP_LOG(LOG_ERROR, "Invalid scene id \n");
    }

    i = next_flag == true ? (i + 1) % (LS_DEFAULT_SCENE_NUM + custom_scene_num) : i;
    *scene_id = s_id_list[i];
    APP_LOG(LOG_DEBUG, "scene_id %d ! \n", *scene_id);
    if (LS_SCENE_DEFAULT_MAX_ID >= *scene_id)
    {
        *p_scene = ls_get_default_scene(*scene_id);
        return APP_OK;
    }
    else
    {
        s_scene.light_mode = LS_LED_MODE_STATIC;
        s_scene.param.static_param = s_custom_scene_list[i];
        *p_scene = &s_scene;
        return APP_OK;
    }
}

/**
* @brief 设置静态场景参数(来源于bypass)
* @param[out]  **p_scene        [场景参数指针]
* @param[in]  led_mode          [led模式]
* @return     int               [APP_OK/APP_FAIL]
*/
int ls_set_static_scene(ls_scene_t **p_scene, LS_LED_MODE_E led_mode)
{
    VCOM_NULL_PARAM_CHK(p_scene , return APP_FAIL);
    ls_status_t *ls_status = NULL;
    ls_status = ls_get_status_pointer();
    s_static_scene.mode = ls_status->mode;
    s_static_scene.node_num = (ls_status->mode == LS_MODE_MULTI_SEG) ? ls_status->node_num : 1;
    s_static_scene.color_head = (ls_status->mode == LS_MODE_MULTI_SEG) ? ls_status->multi_hsv : &ls_status->hsvw;
    s_scene.param.static_param = &s_static_scene;
    s_scene.light_mode = led_mode;
    *p_scene = &s_scene;
    return APP_OK;
}

/**
* @brief 读取flash中的自定义场景数据
* @param[in]  custom_scene_num      [自定义场景数量]
* @return     int                   [APP_OK/APP_FAIL]
*/
int ls_get_scene(uint8_t custom_scene_num)
{
    return ls_read_scene(s_custom_scene_list, custom_scene_num, s_id_list);
}

/**
* @brief 模式变量初始化
*/
void ls_scene_init(void)
{
    ls_status_t ls_status;
    ls_get_status(&ls_status);
    // scene id list 初始化
    for(uint8_t n = 0; n < LS_DEFAULT_SCENE_NUM; n++)
    {
        s_id_list[n + ls_status.custom_scene_num] = n + 1;
    }
    // 应用层静态灯效模式初始化
    s_static_scene.mode = LS_LED_WHITE;
    s_static_scene.node_num = ls_status.node_num;
    s_static_scene.color_head = &ls_status.hsvw;
    // 应用层场景模式初始化
    s_scene.light_mode = LS_LED_MODE_STATIC;
    s_scene.mutex = vesync_mutex_new();
    s_scene.param.static_param = &s_static_scene;
}

/**
* @brief 对静态灯效显示buf上锁or释放锁
* @param[in]  lock_flag     [true上锁/false释放锁]
*/
void ls_get_scene_lock(bool lock_flag)
{
    if (true == lock_flag)
    {
        vesync_mutex_lock(s_scene.mutex);
    }
    else
    {
        vesync_mutex_unlock(s_scene.mutex);
    }
}

/**
* @brief 检查id是否存在
* @param[in]  id                    [id]
* @return  int                      [错误码]
*/
int ls_scene_id_check(uint16_t id)
{
    for (uint8_t i = 0; i < (LS_CUSTOM_SCENE_MAX_NUM + LS_DEFAULT_SCENE_NUM); i++)
    {
        if (id == s_id_list[i])
        {
            return APP_OK;
        }
    }

    if ((LS_SCENE_DEFAULT_MIN_ID <= id)&&(LS_SCENE_DEFAULT_MAX_ID >= id))
    {
        return BP_ERR_DEFAULT_SCENE_NON_EXISTENT;
    }
    else
    {
        return BP_ERR_CUSTOM_SCENE_NON_EXISTENT;
    }
}

/**
* @brief 获取id数组
* @return  uint16_t*    [数组指针]
*/
uint16_t* ls_get_id_list(void)
{
    return s_id_list;
}

/**
* @brief 生成新的scene id
* @param[in]  custom_scene_num      [自定义场景数量]
* @return  uint16_t                 [新id，0为失败]
*/
uint16_t ls_gen_new_scene_id(uint8_t custom_scene_num)
{
    uint16_t temp_id = LS_SCENE_CUSTOM_MIN_ID - 1;
    ls_status_t ls_status;
    ls_get_status(&ls_status);
    temp_id = (ls_status.last_gen_id == 0 ? temp_id : ls_status.last_gen_id);
    for (uint8_t i = 0; i < LS_CUSTOM_SCENE_MAX_NUM; i++)
    {
        temp_id = temp_id == LS_SCENE_CUSTOM_MAX_ID ? LS_SCENE_CUSTOM_MIN_ID : (temp_id + 1);
        if (BP_ERR_CUSTOM_SCENE_NON_EXISTENT == ls_scene_id_check(temp_id))
        {
            return temp_id;
        }

    }

    return 0;
}

/**
* @brief 通过序号获取场景id
* @param[in]  index     [场景序号]
* @return  uint16_t     [id]
*/
uint16_t ls_get_id_by_index(uint8_t index)
{
    return s_id_list[index];
}

/**
* @brief    添加自定义场景
* @param[in]  scene_id      [id]
* @return  int              [APP_OK/APP_FAIL]
*/
int ls_add_scene(uint16_t scene_id)
{
    ls_status_t ls_status;
    ls_get_status(&ls_status);
    ls_static_param_t *temp_param;
    uint16_t temp_list[LS_DEFAULT_SCENE_NUM + LS_CUSTOM_SCENE_MAX_NUM];
    ls_static_param_t *temp_scene_list[LS_CUSTOM_SCENE_MAX_NUM];
    temp_param = (ls_static_param_t*)vesync_malloc(sizeof(ls_static_param_t));
    if (temp_param == NULL)
    {
        APP_LOG(LOG_ERROR, "Out of memory\n");
        return APP_FAIL;
    }

    memset(temp_param, 0, sizeof(ls_static_param_t));

    temp_param->mode = (LS_LED_STATIC_E)ls_status.mode;
    temp_param->node_num = (ls_status.mode == LS_MODE_MULTI_SEG) ? ls_status.node_num : 1;
    temp_param->color_head = (ls_hsv_t*)vesync_malloc(sizeof(ls_hsv_t) * temp_param->node_num);
    if (temp_param->color_head == NULL)
    {
        APP_LOG(LOG_ERROR, "Out of memory\n");
        vesync_free(temp_param);
        return APP_FAIL;
    }

    memset(temp_param->color_head, 0, sizeof(ls_hsv_t) * temp_param->node_num);
    if (temp_param->mode == LS_LED_MULTI_SEG)
    {
        memcpy(temp_param->color_head, ls_status.multi_hsv, sizeof(ls_hsv_t) * temp_param->node_num);
    }
    else
    {
        *(temp_param->color_head) = ls_status.hsvw;
    }
    // 新的保存在前
    memcpy(temp_scene_list, &s_custom_scene_list[0], sizeof(s_custom_scene_list[0]) * ls_status.custom_scene_num);
    memcpy(&s_custom_scene_list[1], temp_scene_list, sizeof(s_custom_scene_list[0]) * ls_status.custom_scene_num);
    s_custom_scene_list[0] = temp_param;
    memcpy(temp_list, &s_id_list[0], 2 * (LS_DEFAULT_SCENE_NUM + ls_status.custom_scene_num));
    memcpy(&s_id_list[1], temp_list, 2 * (LS_DEFAULT_SCENE_NUM + ls_status.custom_scene_num));
    s_id_list[0] = scene_id;
    // save to flash
    ls_save_config(ls_status);
    ls_save_scene(s_custom_scene_list, (ls_status.custom_scene_num + 1), s_id_list);

    return APP_OK;
}

/**
* @brief    删除自定义场景
* @param[in]  scene_id      [id]
* @return  int              [APP_OK/APP_FAIL]
*/
int ls_del_scene(uint16_t scene_id)
{
    uint8_t index = 0;
    uint16_t temp_list[LS_DEFAULT_SCENE_NUM + LS_CUSTOM_SCENE_MAX_NUM];
    ls_status_t ls_status;
    ls_get_status(&ls_status);
    ls_static_param_t *temp_scene_list[LS_CUSTOM_SCENE_MAX_NUM];
    if (APP_OK != ls_get_id_index(scene_id, ls_status.custom_scene_num, &index))
    {
        APP_LOG(LOG_DEBUG, "not find id\n");
        return APP_FAIL;
    }

    APP_LOG(LOG_DEBUG, "del scene id index %d \n", index);
    memcpy(temp_list, &s_id_list[index + 1], 2 * (LS_DEFAULT_SCENE_NUM + ls_status.custom_scene_num - index - 1));
    memcpy(&s_id_list[index], temp_list, 2 * (LS_DEFAULT_SCENE_NUM + ls_status.custom_scene_num - index - 1));

    VCOM_SAFE_FREE(s_custom_scene_list[index]->color_head);
    VCOM_SAFE_FREE(s_custom_scene_list[index]);
    memcpy(temp_scene_list, &s_custom_scene_list[index + 1], sizeof(s_custom_scene_list[0]) * (ls_status.custom_scene_num - index - 1));
    memcpy(&s_custom_scene_list[index], temp_scene_list, sizeof(s_custom_scene_list[0]) * (ls_status.custom_scene_num - index - 1));
    // save to flash
    ls_save_config(ls_status);
    ls_save_scene(s_custom_scene_list, (ls_status.custom_scene_num - 1), s_id_list);
    return APP_OK;
}

