#ifndef __BULB_LED_H__
#define __BULB_LED_H__


#include <stdint.h>

#include "bulb_flash.h"
#include "bulb.h"

#ifdef __cplusplus
     extern "C" {
#endif

#define BULB_LED_TASK_NAME            "bulb_led_task"
#define BULB_LED_TASK_PRIO            TASK_PRIORITY_HIGH

/**
* @brief  释放信号量，通知收发任务处理
* @return     int32_t          [成功：APP_OK， 失败：APP_FAIL]
*/
int32_t bulb_led_sem_signal(void);

/**
 * @brief 灯泡led渐变任务初始化
 * @return int32_t          [成功：APP_OK， 失败：APP_FAIL]
 */
int32_t bulb_led_task_init(void);

/**
 * @brief  获取状态改变标识
 * @param[in]  status          [状态改变标识]
 */
void bulb_set_report_status_change(bulb_status_t* status);


#ifdef __cplusplus
}
#endif

#endif

