/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_button_hold.h
 * @brief       按键模块接口定义
 * @date        2021-12-8
 */

#ifndef __VESYNC_BUTTON_INTERNAL_H__
#define __VESYNC_BUTTON_INTERNAL_H__


#include "stdint.h"
#include "stdbool.h"
#include "vesync_list.h"
#include "vesync_mutex.h"
#include "vesync_button.h"

#ifdef __cplusplus
extern "C" {
#endif

#define VESYNC_BUTTON_TASK_NAME       ("button_task")
#define VESYNC_BUTTON_TASK_STACKSIZE  (1024 * 2)
#define VESYNC_BUTTON_TASK_PRIO       TASK_PRIORITY_HIGH

#define TICKS_INTERVAL_MS (10)  // 10ms一个tick
#define DEBOUNCE_TICKS    (3)   // 消抖判断阈值
#define SHORT_PRESS_THRESHOLD_TICKS  (30)  // 短按时长判断阈值

#define LONG_PRESS_THRESHOLD_TICKS  (50)  // 最小长按判断阈值
#define LONG_PRESS_THRESHOLD_MS     (LONG_PRESS_THRESHOLD_TICKS * TICKS_INTERVAL_MS)

#define DEFAULT_LONG_PRESS_THRESHOLD_TICKS  (80)  // 默认长按判断阈值
#define DEFAULT_LONG_PRESS_THRESHOLD_MS (DEFAULT_LONG_PRESS_THRESHOLD_TICKS * TICKS_INTERVAL_MS)


/**
 *@brief 按键状态
 */
typedef enum
{
    STATE_DOWN = 0,
    STATE_UP,
    STATE_REPEAT,
    STATE_SHORT,
    STATE_RESET
} BTN_STATE_E;


/**
 * @brief 按键结构体
 */
typedef struct
{
    struct list_head list;
    uint8_t gpio;           // 按键引脚
    uint8_t repeat;         // 重复按次数
    uint8_t state;          // 按键状态
    uint8_t debounce_cnt;   // 抖动计数
    uint8_t active_level;   // 使能电平
    uint8_t button_level;   // 按键电平
    uint16_t ticks;         // 按键计时, 一个tick时间为 TICKS_INTERVAL_MS
    uint16_t long_press_threshold_ticks;    // 长按开始时间阈值
    uint16_t long_press_cb_interval_ticks;  // 长按期间回调间隔
    int32_t (*hal_gpio_level_get)(uint8_t gpio);  // 获取GPIO电平回调

    BTN_EVENT_E event;          // 按键事件
    vesync_btn_cb_t cb[EV_NUM];  // 事件回调
} vesync_btn_t;

/**
 *@brief 状态回调函数
 *@param[in] *btn               [按键结构体指针]
 */
typedef void (*state_handle_fn_t)(vesync_btn_t *btn);

/**
 *@brief 状态与回调表驱动结构体
 */
typedef struct
{
    BTN_STATE_E state;
    state_handle_fn_t fn;
} state_handle_t;


/**
 *@brief 按键状态处理回调
 *@param[in] *btn           [按键结构体指针]
 */
typedef void (*btn_handle_fn_t)(vesync_btn_t *btn);

/**
 *@brief 按键管理器结构体
 */
typedef struct
{
    bool init;
    int num;
    vesync_mutex_t mutex;
    struct list_head list;
} vbtn_mgt_t;

/**
 * @brief       按键管理器初始化
 * @return  int                     [成功：SDK_OK，失败：SDK_FAIL]
 */
int vesync_btn_mgt_init(void);

/**
 * @brief       按键管理器反初始化
 * @return  int                     [成功：SDK_OK，失败：SDK_FAIL]
 */
int vesync_btn_mgt_deinit(void);

/**
 * @brief       添加按键
 * @param[in] btn                   [按键结构体]
 * @return  int                     [成功：SDK_OK，失败：SDK_FAIL]
 */
int vesync_btn_mgt_add(vesync_btn_t *btn);

/**
 * @brief       删除按键
 * @param[in] gpio                  [按键gpio]
 * @return  int                     [成功：SDK_OK，失败：SDK_FAIL]
 */
int vesync_btn_mgt_del(uint8_t gpio);

/**
 * @brief       按键回调处理
 * @param[in] btn_handle            [回调函数]
 * @return  int                     [成功：SDK_OK，失败：SDK_FAIL]
 */
int vesync_btn_event_handle(btn_handle_fn_t btn_handle);

/**
 * @brief       获取按键对象
 * @param[in] gpio                  [按键gpio]
 * @return  vesync_btn_t            [成功：按键结构体指针，失败：NULL]
 */
vesync_btn_t *vesync_btn_mgt_get(uint8_t gpio);

/**
 * @brief       按键模块初始化
 */
int vesync_button_init(void);


#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_BUTTON_INTERNAL_H__ */



