/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_init.h
 * @brief       初始化模块接口定义
 * @date        2021-04-22
 */

#ifndef __VESYNC_INIT_H__
#define __VESYNC_INIT_H__

#ifdef __cplusplus
extern "C" {
#endif


/**
 * @brief  vesync sdk 注册初始化前操作回调
 * @param[in] sdk_pre_run_cb    [初始化前操作回调函数指针]
 */
void vesync_sdk_reg_pre_run_cb(void (*sdk_pre_run_cb)(void));


/**
 * @brief  vesync sdk 注册初始化后操作回调
 * @param[in] sdk_post_run_cb   [初始化后操作回调函数指针]
 */
void vesync_sdk_reg_post_run_cb(void (*sdk_post_run_cb)(void));


/**
 * @brief  vesync sdk 运行
 * @return  int                 [成功：SDK_OK；失败：SDK_FAIL]
 */
int vesync_sdk_run(void);


#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_INIT_H__ */

