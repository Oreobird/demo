/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file    lightstring_device.h
* @brief   设备重置
* @author  Lind
* @date    2021-12-20
*/

#ifndef __LIGHTSTRING_DEVICE_H__
#define __LIGHTSTRING_DEVICE_H__

#ifdef __cplusplus
extern "C" {
#endif


/**
* @brief ledstrip设备管理初始化
*/
void ls_device_init(void);

#ifdef __cplusplus
}
#endif

#endif

