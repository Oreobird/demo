/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file    vhal_adc.c
* @brief   adc接口
* @author  Lind
* @date     2021-11-30
*/

#include <string.h>
#include <stdio.h>

#include "esp_log.h"
#include "driver/adc.h"

#include "vhal_adc.h"

#include "vesync_log.h"
#include "vesync_common.h"
#include "vesync_memory.h"

#if CONFIG_IDF_TARGET_ESP32
#define ADC_CH_MAX    (8)

#elif CONFIG_IDF_TARGET_ESP32S2 || CONFIG_IDF_TARGET_ESP32S3
#define ADC_CH_MAX    (10)

#elif CONFIG_IDF_TARGET_ESP32C3
#define ADC_CH_MAX    (5)

#elif CONFIG_IDF_TARGET_ESP8266
#define ADC_CH_MAX    (1)

#endif // CONFIG_IDF_TARGET_*s

static bool s_adc_dma_enable = false;
static bool s_adc_srm_enable = false;

#if CONFIG_IDF_TARGET_ESP8266
/**
* @brief adc单读数据获取
* @param[in]  adc_io    [adc gpio]
* @param[out]  *p_data  [获取的数据]
* @return  int          [VHAL_OK/VHAL_FAIL]
*/
int vhal_adc_single_read_get_data(uint8_t adc_io, uint32_t *p_data)
{
    UNUSED(adc_io);
    if (NULL == p_data || false == s_adc_srm_enable)
    {
        return VHAL_FAIL;
    }

    uint16_t data_temp = 0;
    adc_read(&data_temp);
    *p_data = (uint32_t)data_temp;

    return VHAL_OK;
}


/**
* @brief adc连读模式数据获取
* @param[out]  *p_buf           [外部提供缓存数据的buf，用于接口缓存数据]
* @param[in]  data_num          [可存储的数据数量,每次最多读取512个数据]
* @param[out]  *p_data_num      [实际获取到的数据数量]
* @param[in]  max_delay         [最大阻塞读取时间]
* @return  int                  [VHAL_OK/VHAL_FAIL]
*/
int vhal_adc_dma_get_data(adc_data_t *p_buf, uint16_t data_num, uint16_t *p_data_num, uint32_t max_delay)
{
    UNUSED(max_delay);
    if (NULL == p_buf || NULL == p_data_num || false == s_adc_dma_enable
        || 0 == data_num || ADC_MAX_STORE_DATA_NUM < data_num)
    {
        return VHAL_FAIL;
    }

    int ret = ESP_OK;
    uint16_t data_temp[data_num];
    ret = adc_read_fast(data_temp, data_num); // 精度为10位
    if (ret != ESP_OK)
    {
        return VHAL_FAIL;
    }

    for (uint16_t i = 0; i < data_num; i++)
    {
        p_buf[i].data = data_temp[i];
    }

    return VHAL_OK;
}

/**
* @brief adc连读模式初始化
* @param[in]  *adc_io           [adc gpio]
* @param[in]  io_num            [io数量]
* @param[in]  sample_freq       [采样频率/Hz]
* @return  int                  [VHAL_OK/VHAL_FAIL]
*/
int vhal_adc_dma_init(uint8_t *adc_io, uint16_t io_num, uint16_t sample_freq)
{
    UNUSED(sample_freq);
    int ret = ESP_OK;
    if (ADC_CH_MAX < io_num || 0 == io_num || NULL == adc_io)
    {
        return VHAL_FAIL;
    }

    adc_config_t adc_cfg =
    {
        .mode = ADC_READ_TOUT_MODE,
        .clk_div = 8,
    };
    ret= adc_init(&adc_cfg);
    if (ret != ESP_OK)
    {
        return VHAL_FAIL;
    }

    s_adc_dma_enable = true;
    return VHAL_OK;
}

/**
* @brief adc单读模式初始化
* @param[in]  adc_io        [adc gpio]
* @return  int              [VHAL_OK/VHAL_FAIL]
*/
int vhal_adc_single_read_init(uint8_t adc_io)
{
    UNUSED(adc_io);
    adc_config_t adc_cfg =
    {
        .mode = ADC_READ_TOUT_MODE,
        .clk_div = 8,
    };
    int ret = adc_init(&adc_cfg);
    if (ret != ESP_OK)
    {
        return VHAL_FAIL;
    }

    s_adc_srm_enable = true;
    return VHAL_OK;
}

/**
* @brief adc驱动卸载，卸载所有adc，由于wifi模块会使用adc2，因此影响较大，不建议调用
*/
void vhal_adc_deinit(void)
{
    s_adc_dma_enable = false;
    s_adc_srm_enable = false;
    adc_deinit();
}

#else
/**
* @brief 检查是否为有效数据
* @param[in]  *data     [数据]
* @return  bool         [有效/无效]
*/
static bool check_valid_data(const adc_digi_output_data_t *data)
{
    const unsigned int unit = data->type2.unit;
    if (unit > 2 || data->type2.channel >= SOC_ADC_CHANNEL_NUM(unit))
    {
        return false;
    }

    return true;
}


/**
* @brief adc单读数据获取
* @param[in]  adc_io    [adc gpio]
* @param[out]  *p_data  [获取的数据]
* @return  int          [VHAL_OK/VHAL_FAIL]
*/
int vhal_adc_single_read_get_data(uint8_t adc_io, uint32_t *p_data)
{
    if (NULL == p_data || false == s_adc_srm_enable)
    {
        return VHAL_FAIL;
    }

    *p_data = adc1_get_raw(adc_io);

    return VHAL_OK;
}


/**
* @brief adc连读模式数据获取
* @param[out]  *p_buf           [外部提供缓存数据的buf，用于接口缓存数据]
* @param[in]  data_num          [可存储的数据数量,每次最多读取512个数据]
* @param[out]  *p_data_num      [实际获取到的数据数量]
* @param[in]  max_delay         [最大阻塞读取时间]
* @return  int                  [VHAL_OK/VHAL_FAIL]
*/
int vhal_adc_dma_get_data(adc_data_t *p_buf, uint16_t data_num, uint16_t *p_data_num, uint32_t max_delay)
{
    if (NULL == p_buf || NULL == p_data_num || false == s_adc_dma_enable
        || 0 == data_num || ADC_MAX_STORE_DATA_NUM < data_num)
    {
        return VHAL_FAIL;
    }

    uint8_t *result = (uint8_t*)vesync_malloc(data_num * 4);
    if (result == NULL)
    {
        return VHAL_FAIL;
    }
    memset(result, 0xcc, data_num * 4); // 乐鑫adc相关demo里默认赋值
    uint32_t temp_num = 0;
    int ret = adc_digi_read_bytes(result, data_num * 4, &temp_num, max_delay);  // 精度为12
    if (ret == ESP_ERR_TIMEOUT)
    {
        HAL_LOG(LOG_ERROR, "ADC read timeout \n");
        VCOM_SAFE_FREE(result);
        return VHAL_FAIL;
    }

    *p_data_num = (uint16_t)temp_num;
    *p_data_num = (*p_data_num / 4 > data_num) ? data_num : *p_data_num / 4;
    uint16_t temp_data_num = 0;
    for (int i = 0; i < *p_data_num; i++)
    {
        adc_digi_output_data_t *p = (void*)&result[i * 4];
        if (check_valid_data(p))
        {
            p_buf[temp_data_num].channel = p->type2.channel;
            p_buf[temp_data_num].data = p->type2.data;
            temp_data_num++;
        }
    }

    *p_data_num = temp_data_num;
    VCOM_SAFE_FREE(result);

    return VHAL_OK;
}

/**
* @brief adc连读模式初始化
* @param[in]  *adc_io           [adc gpio]
* @param[in]  io_num            [io数量]
* @param[in]  sample_freq       [采样频率/Hz]
* @return  int                  [VHAL_OK/VHAL_FAIL]
*/
int vhal_adc_dma_init(uint8_t *adc_io, uint16_t io_num, uint16_t sample_freq)
{
    int ret = ESP_OK;
    if (ADC_CH_MAX < io_num || 0 == io_num || NULL == adc_io)
    {
        return VHAL_FAIL;
    }

    uint16_t channel_mask = 0;
    adc_digi_pattern_table_t adc_pattern[ADC_CH_MAX] = {0};
    for (uint8_t i = 0; i < io_num; i++)
    {
        channel_mask |= (1 << adc_io[i]);
    }

    adc_digi_init_config_t adc_dma_config =
    {
        .max_store_buf_size = ADC_MAX_STORE_DATA_NUM * 4,
        .conv_num_each_intr = 256,
        .adc1_chan_mask = channel_mask,
    };

    ret = adc_digi_initialize(&adc_dma_config);
    if (ret != ESP_OK)
    {
        return VHAL_FAIL;
    }

    adc_digi_config_t dig_cfg =
    {
        .conv_limit_en = 0,
        .conv_limit_num = 250,
        .sample_freq_hz = sample_freq,
    };

    for (int i = 0; i < io_num; i++)
    {
        uint8_t unit = ((adc_io[i] >> 3) & 0x1);
        uint8_t ch = adc_io[i] & 0x7;
        adc_pattern[i].atten = ADC_ATTEN_DB_11;
        adc_pattern[i].channel = ch;
        adc_pattern[i].unit = unit;
    }

    dig_cfg.adc_pattern_len = io_num;
    dig_cfg.adc_pattern = adc_pattern;
    ret = adc_digi_controller_config(&dig_cfg);
    if (ret != ESP_OK)
    {
        return VHAL_FAIL;
    }

    adc_digi_start();

    s_adc_dma_enable = true;
    return VHAL_OK;
}

/**
* @brief adc单读模式初始化
* @param[in]  adc_io        [adc gpio]
* @return  int              [VHAL_OK/VHAL_FAIL]
*/
int vhal_adc_single_read_init(uint8_t adc_io)
{
    if (ADC_CH_MAX <= adc_io)
    {
        return VHAL_FAIL;
    }

    adc1_config_width(ADC_WIDTH_BIT_DEFAULT);
    int ret = adc1_config_channel_atten(adc_io, ADC_ATTEN_DB_11);
    if (ret != ESP_OK)
    {
        return VHAL_FAIL;
    }

    s_adc_srm_enable = true;
    return VHAL_OK;
}

/**
* @brief adc驱动卸载，卸载所有adc，由于wifi模块会使用adc2，因此影响较大，不建议调用
*/
void vhal_adc_deinit(void)
{
    s_adc_dma_enable = false;
    s_adc_srm_enable = false;

    adc_digi_stop();
    adc_digi_deinitialize();

}

#endif


