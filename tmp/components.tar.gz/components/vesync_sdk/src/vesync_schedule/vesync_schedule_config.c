/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_schedule_config.c
 * @brief       Schedule 模块配置相关接口实现
 * @author      Niki
 * @date        2021-07-19
 */
#include <string.h>

#include "vesync_schedule_internal.h"
#include "vesync_klv.h"
#include "vesync_log_internal.h"
#include "vesync_common.h"

#include "vhal_flash.h"

#include "pp_iterate/local.h"

/**
 * @brief 检查缓存是否为零并且序列化KLV数据
 * @note  该函数是为了适配空KLV写入Buffer和非空KLV写入Buffer两种情况，
 *          空KLV写入Buffer往往是为了计算KLV序列化数据的大小
 * @param[in,out] p_buf             [KLV写入Buffer]
 * @param[in]     buf_len           [KLV写入Buffer的长度]
 * @param[in]     wr_len            [KLV写入Buffer的已经写入长度]
 * @param[in]     key               [K]
 * @param[in]     len               [L]
 * @param[in]     value             [V]
 * @return uint32_t                 [返回刚刚写入的KLV系列化数据长度]
 */
static uint32_t schedule_klv_set(uint8_t *p_buf, uint32_t buf_len, uint32_t wr_len, uint8_t key, uint16_t len, uint8_t *value)
{
    if (NULL != p_buf)
    {
        p_buf = p_buf + wr_len;
        buf_len = buf_len - wr_len;
    }

    return vesync_klv_set(p_buf, buf_len, key, len, value);
}

/**
 * @brief 检查缓存是否为零并且序列化vesync_buffer数据结构的KLV数据
 * @note  该函数是为了适配空KLV写入Buffer和非空KLV写入Buffer两种情况，
 *          空KLV写入Buffer往往是为了计算KLV序列化数据的大小
 * @param[in,out] p_buf             [KLV写入Buffer]
 * @param[in]     buf_len           [KLV写入Buffer的长度]
 * @param[in]     wr_len            [KLV写入Buffer的已经写入长度]
 * @param[in]     key               [K]
 * @param[in]     p_in              [LV，指向vesync_buffer数据]
 * @return uint32_t                 [返回刚刚写入的KLV系列化数据长度]
 */
static uint32_t schedule_klv_set_buf(uint8_t *p_buf, uint32_t buf_len, uint32_t wr_len, uint8_t key, vesync_buf_t *p_in)
{
    if (NULL != p_buf)
    {
        p_buf = p_buf + wr_len;
        buf_len = buf_len - wr_len;
    }

    return vesync_klv_set_buf(p_buf, buf_len, key, p_in);
}

#define SCHEDULE_KLV_SET_ERR_CHECK(offset, p_buf, buf_len, total_wr, key, len, val) \
    do                                                                              \
    {                                                                               \
        uint32_t out = schedule_klv_set(p_buf, buf_len, total_wr, key, len, val);   \
        if (0 == out)                                                               \
        {                                                                           \
            return SCHE_BUF_ERR;                                                    \
        }                                                                           \
        offset += out;                                                              \
    } while (0)

#define SCHEDULE_KLV_SET_FAIL_CHECK(offset, p_buf, buf_len, total_wr, key, len, val) \
    do                                                                               \
    {                                                                                \
        uint32_t out = schedule_klv_set(p_buf, buf_len, total_wr, key, len, val);    \
        if (0 == out)                                                                \
        {                                                                            \
            return 0;                                                                \
        }                                                                            \
        offset += out;                                                               \
    } while (0)

#define SCHEDULE_KLV_SET_BUF_ERR_CHECK(offset, p_buf, buf_len, total_wr, key, p_in) \
    do                                                                              \
    {                                                                               \
        uint32_t out = schedule_klv_set_buf(p_buf, buf_len, total_wr, key, p_in);   \
        if (0 == out)                                                               \
        {                                                                           \
            return SCHE_BUF_ERR;                                                    \
        }                                                                           \
        offset += out;                                                              \
    } while (0)

#define SCHEDULE_KLV_SET_BUF_FAIL_CHECK(offset, p_buf, buf_len, total_wr, key, p_in) \
    do                                                                               \
    {                                                                                \
        uint32_t out = schedule_klv_set_buf(p_buf, buf_len, total_wr, key, p_in);    \
        if (0 == out)                                                                \
        {                                                                            \
            return 0;                                                                \
        }                                                                            \
        offset += out;                                                               \
    } while (0)

/**
 * @brief KLV数组组装迭代器
 * @param[in]  p_iter               [迭代算子]
 * @param[in]  iter_cnt             [迭代次数]
 * @param[out] p_buf                [KLV写入Buffer]
 * @param[in]  len                  [Buffer长度]
 * @return uint32_t                 [KLV写入长度]
 */
static uint32_t klv_arr_item_iterator(void **p_iter, uint32_t iter_cnt, uint8_t *p_buf, uint32_t len)
{
    UNUSED(iter_cnt);

    schedule_node_t *p_prst = (schedule_node_t *)*p_iter;
    if (NULL == p_prst)
    {
        return 0;
    }
    // 组装数据
    uint32_t offset = 0;
    schedule_ctx_t *p_sch_ctx = &p_prst->data;
    SCHEDULE_KLV_SET_FAIL_CHECK(offset, p_buf, len, offset, ACTION_KEY_ID, sizeof(p_sch_ctx->config.id), (uint8_t *)&p_sch_ctx->config.id);
    SCHEDULE_KLV_SET_FAIL_CHECK(offset, p_buf, len, offset, ACTION_KEY_EABLED, sizeof(p_sch_ctx->config.enabled), (uint8_t *)&p_sch_ctx->config.enabled);
    SCHEDULE_KLV_SET_FAIL_CHECK(offset, p_buf, len, offset, ACTION_KEY_TYPE, sizeof(p_sch_ctx->config.type), (uint8_t *)&p_sch_ctx->config.type);
    SCHEDULE_KLV_SET_FAIL_CHECK(offset, p_buf, len, offset, ACTION_KEY_EVENT_CFG, sizeof(p_sch_ctx->config.event_config), (uint8_t *)&p_sch_ctx->config.event_config);
    SCHEDULE_KLV_SET_FAIL_CHECK(offset, p_buf, len, offset, ACTION_KEY_REPEAT_FLAG, sizeof(p_sch_ctx->config.repeat_config), (uint8_t *)&p_sch_ctx->config.repeat_config);
    SCHEDULE_KLV_SET_FAIL_CHECK(offset, p_buf, len, offset, ACTION_KEY_MODIFY_LOCAL_TS, sizeof(p_sch_ctx->modify_local_ts), (uint8_t *)&p_sch_ctx->modify_local_ts);
    SCHEDULE_KLV_SET_FAIL_CHECK(offset, p_buf, len, offset, ACTION_KEY_EXEC_CNT, sizeof(p_sch_ctx->exec_cnt), (uint8_t *)&p_sch_ctx->exec_cnt);
    SCHEDULE_KLV_SET_BUF_FAIL_CHECK(offset, p_buf, len, offset, ACTION_KEY_APP_CFG, &p_sch_ctx->app_cfg);
    // 更新迭代算子
    *p_iter = list_next_entry(p_prst, list);
    return offset;
}

int sche_cfg_marshal(uint8_t sch_nbr, struct list_head *p_sch_head, uint8_t *p_buf, uint32_t buf_len, uint32_t *p_out_size)
{
    uint32_t offset = 0;
    uint8_t version = SCHEDULE_CFG_VERSION;

    // 输出长度初始化
    *p_out_size = 0;
    if (p_buf != NULL)
    {
        memset(p_buf, 0, buf_len);
    }

    // 组装版本信息
    SCHEDULE_KLV_SET_ERR_CHECK(offset, p_buf, buf_len, offset, SCHEDULE_KEY_VERSION, sizeof(version), &version);
    // 组装个数信息
    SCHEDULE_KLV_SET_ERR_CHECK(offset, p_buf, buf_len, offset, SCHEDULE_KEY_NUMBER, sizeof(sch_nbr), &sch_nbr);

    // 组装Schedule配置项，把链表的哨兵节点去掉后再迭代
    schedule_node_t *p_first = list_first_entry(p_sch_head, typeof(*p_first), list);
    if (NULL != p_buf)
    {
        p_buf = p_buf + offset;
        buf_len = buf_len - offset;
    }
    offset += vesync_klv_set_arr_iter(p_buf, buf_len, SCHEDULE_KEY_ACTION_ARR, sch_nbr, p_first, klv_arr_item_iterator);
    if (offset == 0)
    {
        return SCHE_BUF_ERR;
    }

    // 更新输出KLV大小
    *p_out_size = offset;

    return SCHE_OK;
}

int sche_cfg_unmarshal(uint8_t *p_buf, uint32_t data_len, struct list_head *p_sch_head, uint8_t *p_schedule_nbr)
{
    uint8_t version = 0;
    if (SDK_FAIL == vesync_klv_get(p_buf, data_len, SCHEDULE_KEY_VERSION, sizeof(uint8_t), &version))
    {
#if SCHEDULE_DEBUG_PRINT == 1
        SDK_LOG(LOG_ERROR, "get cfg_version error\r\n");
#endif
        return SCHE_CFG_ERR;
    }
#if SCHEDULE_DEBUG_PRINT == 1
    SDK_LOG(LOG_ERROR, "get cfg_version: %d\n", version);
#endif

    vesync_klv_get(p_buf, data_len, SCHEDULE_KEY_NUMBER, sizeof(uint8_t), p_schedule_nbr);
#if 0
    SDK_LOG(LOG_INFO,"get schedule cnt=%d\n", *p_schedule_nbr);
#endif

    klv_t klv_node, klv_root;
    memset(&klv_node, 0, sizeof(klv_node));
    memset(&klv_root, 0, sizeof(klv_root));

    if (SDK_FAIL == vesync_klv_get_ptr(p_buf, data_len, SCHEDULE_KEY_ACTION_ARR, &klv_root))
    {
#if SCHEDULE_DEBUG_PRINT == 1
        SDK_LOG(LOG_ERROR, "get action data error\r\n");
#endif
        return SCHE_CFG_ERR;
    }

    uint32_t cnt;
    for (cnt = 0; cnt < *p_schedule_nbr; cnt++)
    {
        memset(&klv_node, 0, sizeof(klv_node));

        if (SDK_OK == vesync_klv_get_item(klv_root.value, klv_root.len, cnt, &klv_node))
        {
            schedule_node_t *p_sch_node = sche_node_new(p_sch_head);
            if (p_sch_node != NULL)
            {
                vesync_klv_get(klv_node.value, klv_node.len, ACTION_KEY_ID, sizeof(p_sch_node->data.config.id), (uint8_t *)&p_sch_node->data.config.id);
                vesync_klv_get(klv_node.value, klv_node.len, ACTION_KEY_TYPE, sizeof(p_sch_node->data.config.type), &p_sch_node->data.config.type);
                vesync_klv_get(klv_node.value, klv_node.len, ACTION_KEY_EABLED, sizeof(p_sch_node->data.config.enabled), (uint8_t *)&p_sch_node->data.config.enabled);
                vesync_klv_get(klv_node.value, klv_node.len, ACTION_KEY_EVENT_CFG, sizeof(p_sch_node->data.config.event_config), (uint8_t *)&p_sch_node->data.config.event_config);
                vesync_klv_get(klv_node.value, klv_node.len, ACTION_KEY_REPEAT_FLAG, sizeof(p_sch_node->data.config.repeat_config), (uint8_t *)&p_sch_node->data.config.repeat_config);
                vesync_klv_get(klv_node.value, klv_node.len, ACTION_KEY_MODIFY_LOCAL_TS, sizeof(p_sch_node->data.modify_local_ts), (uint8_t *)&p_sch_node->data.modify_local_ts);
                vesync_klv_get(klv_node.value, klv_node.len, ACTION_KEY_EXEC_CNT, sizeof(p_sch_node->data.exec_cnt), (uint8_t *)&p_sch_node->data.exec_cnt);
                vesync_klv_get_buf(klv_node.value, klv_node.len, ACTION_KEY_APP_CFG, &p_sch_node->data.app_cfg);
            }
        }
    }

    // 更新实际读取的配置项数量
    *p_schedule_nbr = cnt;

    return SCHE_OK;
}

/**
 * @brief 底层的Flash读公共函数
 * @param[in]       key             [KEY]
 * @param[in]       p_data          [Value]
 * @param[in, out]  p_len           [指向最终的读取长度]
 * @return int                      [SCHE_RESULT_E]
 */
static int sche_flash_rd_itf(const char *key, uint8_t *p_data, uint32_t *p_len)
{
    if (NULL == p_len)
    {
        return SCHE_ERR;
    }
    /// @attention p_rd_buf为NULL，返回存储数据的长度
    /// @todo vhal_flash还需要进一步的优化错误处理
    int ret = vhal_flash_read(PARTITION_CFG, key, p_data, p_len);
    if (VHAL_OK != ret)
    {
        SDK_LOG(LOG_WARN, "read flash fail[%d], key[%s]\n", ret, key);
        /// @note 将读取长度设为0，当作配置不存在
        *p_len = 0;
    }
    return SCHE_OK;
}

/**
 * @brief 底层的Flash写公共函数
 * @param[in] key                   [KEY]
 * @param[in] p_data                [Value]
 * @param[in] len                   [将写入长度]
 * @return int                      [SCHE_RESULT_E]
 */
static int sche_flash_wr_itf(const char *key, uint8_t *p_data, uint32_t len)
{
    if (NULL == p_data || len == 0)
    {
        return SCHE_ERR;
    }
    int ret = vhal_flash_write(PARTITION_CFG, key, p_data, len);
    if (VHAL_OK != ret)
    {
        SDK_LOG(LOG_ERROR, "write flash fail[%d], key[%s]\n", ret, key);
        return SCHE_ERR;
    }
    return SCHE_OK;
}

// 定义相应实例序号的生成的默认读配置回调函数名
#define DEFAULT_RD_CFG_CB(seq) sche_default_rd_cfg_cb_ ## seq
// 定义相应实例序号的生成的默认读配置回调函数的模板
#define DECLARE_SCHE_DEFAULT_RD_CFG_CB(seq)                                                    \
    static int DEFAULT_RD_CFG_CB(seq)(uint8_t *p_rd_buf, uint32_t buf_len, uint32_t *p_rd_len) \
    {                                                                                          \
        UNUSED(buf_len);                                                                       \
        return sche_flash_rd_itf(SCHEDULE_DEFAULT_USER_CFG_KEY "_" #seq, p_rd_buf, p_rd_len);  \
    }

// 定义相应实例序号的生成的默认写配置回调函数名
#define DEFAULT_WR_CFG_CB(seq) sche_default_wr_cfg_cb_ ## seq
// 定义相应实例序号的生成的默认写配置回调函数的模板
#define DECLARE_SCHE_DEFAULT_WR_CFG_CB(seq)                                              \
    static int DEFAULT_WR_CFG_CB(seq)(uint8_t *p_wr_buf, uint32_t len)                   \
    {                                                                                    \
        return sche_flash_wr_itf(SCHEDULE_DEFAULT_USER_CFG_KEY "_" #seq, p_wr_buf, len); \
    }

// 设置Schedule默认读写函数的生成序号范围
#define DEFAULT_CBS_GENERATE_MARGIN (0, SCHEDULE_MAX_INSTANCES_NBR - 1)
// 按序号宏展开Schedule默认读函数
#define PP_ITERATE_LOCAL_MACRO(n) DECLARE_SCHE_DEFAULT_RD_CFG_CB(n)
#define PP_ITERATE_LOCAL_LIMIT DEFAULT_CBS_GENERATE_MARGIN
#include PP_ITERATE_LOCAL()
// 将Schedule默认读函数的引用按照序号宏展开
static sche_rd_cfg_cb_t sche_default_rd_cfg_cbs[] = {
#define PP_ITERATE_LOCAL_MACRO(n) DEFAULT_RD_CFG_CB(n),
#define PP_ITERATE_LOCAL_LIMIT DEFAULT_CBS_GENERATE_MARGIN
#include PP_ITERATE_LOCAL()
};
// 按序号宏展开Schedule默认写函数
#define PP_ITERATE_LOCAL_MACRO(n) DECLARE_SCHE_DEFAULT_WR_CFG_CB(n)
#define PP_ITERATE_LOCAL_LIMIT DEFAULT_CBS_GENERATE_MARGIN
#include PP_ITERATE_LOCAL()
// 将Schedule默认写函数的引用按照序号宏展开
static sche_wr_cfg_cb_t sche_default_wr_cfg_cbs[] = {
#define PP_ITERATE_LOCAL_MACRO(n) DEFAULT_WR_CFG_CB(n),
#define PP_ITERATE_LOCAL_LIMIT DEFAULT_CBS_GENERATE_MARGIN
#include PP_ITERATE_LOCAL()
};

sche_rd_cfg_cb_t sche_get_default_rd_cfg_cb(int handle_id)
{
#if 0
    SDK_LOG(LOG_DEBUG, "length of sche_default_rd_cfg_cbs:%d\n",
        sizeof(sche_default_rd_cfg_cbs)/sizeof(sche_default_rd_cfg_cbs[0]));
#endif
    if (handle_id < SCHEDULE_MAX_INSTANCES_NBR)
    {
        return sche_default_rd_cfg_cbs[handle_id];
    }
    return NULL;
}

sche_wr_cfg_cb_t sche_get_default_wr_cfg_cb(int handle_id)
{
#if 0
    SDK_LOG(LOG_DEBUG, "length of sche_default_wr_cfg_cbs:%d\n",
        sizeof(sche_default_wr_cfg_cbs)/sizeof(sche_default_wr_cfg_cbs[0]));
#endif
    if (handle_id < SCHEDULE_MAX_INSTANCES_NBR)
    {
        return sche_default_wr_cfg_cbs[handle_id];
    }
    return NULL;
}
