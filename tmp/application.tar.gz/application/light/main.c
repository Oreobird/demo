/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        main.c
 * @brief       应用入口
 * @author      Joshua
 * @date        2021-11-20
 */

#include <stdio.h>

#include "vesync_common.h"
#include "vesync_init.h"
#include "vesync_log.h"
#include "vesync_queue.h"
#include "vesync_device.h"
#include "vesync_flash.h"
#include "vesync_production.h"
#include "vesync_netcfg.h"
#include "vesync_wifi_led.h"
#include "vesync_net_service.h"
#include "vesync_task.h"

#include "device.h"
#include "light.h"
#include "scene.h"
#include "event.h"
#include "production.h"
#if CONFIG_VESYNC_APP_BUTTON
#include "button.h"
#endif
#include "app_bypass.h"
#include "netcfg.h"
#include "schedule.h"

#define APP_TASK_NAME                   "app_task"
#ifndef APP_TASK_STACSIZE
#define APP_TASK_STACSIZE               (1024*4)
#endif
#ifndef APP_TASK_PRIO
#define APP_TASK_PRIO                   TASK_PRIORITY_NORMAL
#endif

/**
 * @brief  vesync sdk初始化前回调
 */
static void app_pre_cb(void)
{
    app_event_init();
    app_device_init();
    
    app_light_init();
    app_scene_init();
}

/**
 * @brief  app应用任务
 */
static void app_task(void *arg)
{
    UNUSED(arg);
    app_event_loop_run();
}

/**
 * @brief  app应用入口
 */
static void app_run(void)
{
    APP_LOG(LOG_INFO, "Vesync Light APP start\n");

    app_production_init();
    app_netcfg_init();

#if CONFIG_VESYNC_APP_BUTTON
    app_button_init();
#endif
    app_bypass_init();
    app_schedule_init();

    app_device_startup();

    int ret = vesync_task_new(APP_TASK_NAME, NULL, app_task, NULL, APP_TASK_STACSIZE, APP_TASK_PRIO, NULL);
    if (ret != VOS_OK)
    {
        APP_LOG(LOG_ERROR, "App task create failed\n");
        app_event_deinit();
        app_scene_deinit();
        return;
    }
}

/**
 * @brief  入口
 */
void app_main(void)
{
    vesync_sdk_reg_pre_run_cb(app_pre_cb);
    vesync_sdk_reg_post_run_cb(app_run);
    vesync_sdk_run();
}

