/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_uart.c
 * @brief       UART通信模块
 * @author      Louis
 * @date        2021-08-17
 */

#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#include "vhal_uart.h"
#include "vesync_common.h"
#include "vesync_log_internal.h"
#include "vesync_sem.h"
#include "vesync_uart_private.h"


static vesync_sem_t *s_vesync_uart_sem = NULL;

/**
 * @brief   UART收发任务
 */
static void vesync_uart_task(void *args)
{
    while (1)
    {
        if (VOS_OK != vesync_sem_wait(s_vesync_uart_sem, vesync_uart_process_expired_timer()))
        {
            continue;   // 未等到信号量，超时处理定时器
        }

        // 等到信号量，开始处理队列中的消息
        vesync_uart_parse_recv_data();
        vesync_uart_parse_send_data();
    }
}


/**
 * @brief  消息入队之后释放信号量，通知收发任务处理
 * @return     int32_t          [SDK_OK/SDK_FAIL]
 */
int32_t vesync_uart_sem_signal(void)
{
    return (VOS_OK == vesync_sem_signal(s_vesync_uart_sem)) ? SDK_OK : SDK_FAIL;
}


/**
 * @brief  vesync串口初始化
 * @return     uint32_t         [SDK_OK成功，SDK_FAIL失败]
 */
uint32_t vesync_uart_init(void)
{
    uint32_t *p_tx_pin = (uint32_t*)vesync_cfg_get_uart_tx_pin_arr();
    uint32_t *p_rx_pin = (uint32_t*)vesync_cfg_get_uart_rx_pin_arr();
    uint32_t *p_baud_rate = (uint32_t*)vesync_cfg_get_uart_baud_rate_arr();

    // 配置多路串口
    for (int i = 0; i < VESYNC_UART_NUM; i++)
    {
        SDK_LOG(LOG_DEBUG, "idx:%d, rx_pin:%d, tx_pin:%d, rate:%d\r\n", i, p_rx_pin[i], p_tx_pin[i], p_baud_rate[i]);
        vhal_uart_config(i, p_rx_pin[i], p_tx_pin[i], p_baud_rate[i]);
    }

    // 创建收发任务通知信号量
    s_vesync_uart_sem = vesync_sem_binary_new();
    if (NULL == s_vesync_uart_sem)
    {
        goto EXIT;
    }

    // 初始化发送队列
    if (SDK_OK != vesync_uart_send_init())
    {
        goto EXIT;
    }

    // 初始化接收队列
    if (SDK_OK != vesync_uart_recv_init())
    {
        goto EXIT;
    }

    // 创建UART收发任务
    if (VOS_OK != vesync_task_new(VESYNC_UART_TASK_NAME,
                                  NULL,
                                  vesync_uart_task,
                                  NULL,
                                  VESYNC_UART_TASK_STACSIZE,
                                  VESYNC_UART_TASK_PRIO,
                                  NULL))
    {
        SDK_LOG(LOG_ERROR, "Create task fail!\r\n");
        goto EXIT;
    }

    // 开启vhal的接收任务
    vhal_uart_start();

    return  SDK_OK;

EXIT:   // 初始化失败，退出
    if (NULL != s_vesync_uart_sem)
    {
        vesync_sem_free(s_vesync_uart_sem);
        s_vesync_uart_sem = NULL;
    }
    vesync_uart_send_deinit();
    vesync_uart_recv_deinit();
    return SDK_FAIL;
}

