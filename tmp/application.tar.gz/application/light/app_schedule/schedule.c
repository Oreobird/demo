/**
* Copyright © Vesync Technologies Co.Ltd. 2022. All rights reserved
* @file         schedule.c
* @brief        schedule处理接口
* @author       Joshua
* @date         2022-2-24
*/
#include <stdlib.h>
#include "vesync_memory.h"
#include "vesync_klv.h"
#include "vesync_common.h"
#include "vesync_log.h"
#include "vesync_schedule.h"
#include "schedule.h"
#include "device.h"
#include "scene.h"
#include "event.h"
#include "app_bypass.h"

/**
* @brief Schedule模块任务执行回调
* @param[in]  sch_cfg   [schedule配置]
* @param[in]  app_cfg   [schedule应用层配置]
* @return     int       [APP_OK/APP_FAIL]
*/
static int schd_exec_cb(vesync_schedule_t sch_cfg, vesync_buf_t app_cfg)
{
    action_cfg_t act_cfg;
    dev_cfg_t *p_dev_cfg = app_device_cfg_get();

    memset(&act_cfg, 0, sizeof(action_cfg_t));
    light_sche_klv_buf_get(&app_cfg, &act_cfg);

    if (act_cfg.onoff == LIGHT_STATUS_OFF)
    {
        p_dev_cfg->flash->cfg.onoff = LIGHT_STATUS_OFF;
    }
    else
    {
        p_dev_cfg->flash->cfg.onoff = LIGHT_STATUS_ON;
        switch (act_cfg.color_mode)
        {
            case LIGHT_MODE_WHITE:
                p_dev_cfg->flash->cfg.mode = LIGHT_MODE_WHITE;
                p_dev_cfg->flash->cfg.light_param.brightness = act_cfg.light_param.brightness;
                p_dev_cfg->flash->cfg.light_param.color_temp = act_cfg.light_param.color_temp;
                break;
            case LIGHT_MODE_COLOR:
                p_dev_cfg->flash->cfg.mode = LIGHT_MODE_COLOR;
                p_dev_cfg->flash->cfg.light_param.H = act_cfg.light_param.H;
                p_dev_cfg->flash->cfg.light_param.S = act_cfg.light_param.S;
                p_dev_cfg->flash->cfg.light_param.V = act_cfg.light_param.V;
                break;
            case LIGHT_MODE_SCENE:
                p_dev_cfg->flash->cfg.mode = LIGHT_MODE_SCENE;
                p_dev_cfg->flash->cfg.scene_id = act_cfg.scene_id;
                break;
            default:
                break;
        }
    }

    APP_LOG(LOG_DEBUG, "----schedule exec cb----onoff=%d, color_mode=%d\n", act_cfg.onoff, act_cfg.color_mode);
    uint8_t scene_type = SCENE_ONOFF;
    uint16_t scene_id = SCENE_COLOR_OFF;
    app_scene_info_get_from_mode(&scene_type, &scene_id);
    app_device_cfg_save(p_dev_cfg);
    SCENE_SWITCH_NOTIFY(ACT_SRC_TASK, scene_type, scene_id);
    return APP_OK;
}

int app_schedule_init(void)
{
    int ret = vesync_schedule_main_init();
    if (ret != SCHE_OK)
    {
        APP_LOG(LOG_ERROR, "Schd init fail\n");
        return APP_FAIL;
    }

    vesync_schedule_param_t schedule_param;
    schedule_param.rd_cfg_cb = NULL;
    schedule_param.wr_cfg_cb = NULL;
    schedule_param.exec_app_task_cb = schd_exec_cb;
    schedule_param.max_app_cfg_size = LIGHT_SCHE_MAX_APP_CFG_SIZE;
    schedule_param.max_sche_nbr = LIGHT_SCHE_MAX_NUM;
    schedule_param.min_id_limit = LIGHT_SCHE_MIN_ID;

    ret = vesync_schedule_new_instance(LIGHT_SCHE_INS_ID, &schedule_param);
    if (ret != SCHE_OK)
    {
        APP_LOG(LOG_ERROR, "Schd instance init error: [%ld]\n", ret);
        return APP_FAIL;
    }

    return APP_OK;
}

int app_schedule_clear(void)
{
    vesync_schedule_clear(LIGHT_SCHE_INS_ID);
    return APP_OK;
}

int light_sche_klv_buf_set(vesync_buf_t *p_cfg_buf, action_cfg_t *p_cfg)
{
    uint16_t ofs = 0;
    uint8_t version = 0;
    int buf_len = sizeof(action_cfg_t) + sizeof(version) + 40;
    uint8_t *p_buf = (uint8_t*)vesync_malloc(buf_len);
    if (p_buf == NULL)
    {
        return APP_FAIL;
    }

    APP_LOG(LOG_DEBUG, "act set: onoff=%d, brightness=%d, color_temp=%d, h=%d, s=%d, v=%d, scend_id=%d, color_mode=%d\n",
        p_cfg->onoff, p_cfg->light_param.brightness, p_cfg->light_param.color_temp,
        p_cfg->light_param.H, p_cfg->light_param.S, p_cfg->light_param.V, p_cfg->scene_id, p_cfg->color_mode);

    memset(p_buf, 0, buf_len);

    version = APP_FLASH_CFG_VERSION;
    ofs += vesync_klv_set(p_buf + ofs, buf_len - ofs, SCHE_KEY_VERSION, sizeof(version), (uint8_t*)&version);
    if (p_cfg->onoff != (uint8_t)BP_NO_VALUE)
    {
        ofs += vesync_klv_set(p_buf + ofs, buf_len - ofs, SCHE_KEY_ONOFF, sizeof(p_cfg->onoff), (uint8_t*)&p_cfg->onoff);
    }
    if (p_cfg->color_mode != (uint8_t)BP_NO_VALUE)
    { 
        ofs += vesync_klv_set(p_buf + ofs, buf_len - ofs, SCHE_KEY_COLOR_MODE, sizeof(p_cfg->color_mode), (uint8_t*)&p_cfg->color_mode);
    }
    if ((p_cfg->light_param.brightness != (uint8_t)BP_NO_VALUE 
        && p_cfg->light_param.color_temp != (uint8_t)BP_NO_VALUE)
        || (p_cfg->light_param.H != (uint16_t)BP_NO_VALUE 
        && p_cfg->light_param.S != (uint16_t)BP_NO_VALUE 
        && p_cfg->light_param.V != (uint8_t)BP_NO_VALUE))
    {
        ofs += vesync_klv_set(p_buf + ofs, buf_len - ofs, SCHE_KEY_COLOR_PARAM, sizeof(p_cfg->light_param), (uint8_t*)&p_cfg->light_param);
    }
    if (p_cfg->scene_id != (uint16_t)BP_NO_VALUE)
    {
        ofs += vesync_klv_set(p_buf + ofs, buf_len - ofs, SCHE_KEY_SCENE_ID, sizeof(p_cfg->scene_id), (uint8_t*)&p_cfg->scene_id);
    }

    vesync_buf_set(p_cfg_buf, (void *)p_buf, ofs);
    VCOM_SAFE_FREE(p_buf);
    APP_LOG(LOG_DEBUG, "Schedule p_cfg buffer len: %d\n", ofs);
    return APP_OK;
}

void light_sche_klv_buf_get(vesync_buf_t *p_app_buf, action_cfg_t *p_cfg)
{
    vesync_klv_get((uint8_t*)p_app_buf->buf, p_app_buf->len, SCHE_KEY_ONOFF, sizeof(p_cfg->onoff), (uint8_t*)&p_cfg->onoff);
    vesync_klv_get((uint8_t*)p_app_buf->buf, p_app_buf->len, SCHE_KEY_COLOR_MODE, sizeof(p_cfg->color_mode), (uint8_t*)&p_cfg->color_mode);
    vesync_klv_get((uint8_t*)p_app_buf->buf, p_app_buf->len, SCHE_KEY_COLOR_PARAM, sizeof(p_cfg->light_param), (uint8_t*)&p_cfg->light_param);
    vesync_klv_get((uint8_t*)p_app_buf->buf, p_app_buf->len, SCHE_KEY_SCENE_ID, sizeof(p_cfg->scene_id), (uint8_t*)&p_cfg->scene_id);
}