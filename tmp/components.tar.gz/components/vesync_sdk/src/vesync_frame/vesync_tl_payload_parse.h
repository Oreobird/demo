/**
 *  Copyright © Vesync Technologies Co.Ltd. 2019-2021. All rights reserved.
 * @file        vesync_tl_payload_parse.h
 * @brief       数据帧解析和封装
 * @author      zhenlang
 * @date        2019-09-24
 */

#ifndef __VESYNC_TL_PAYLOAD_PARSE_H__
#define __VESYNC_TL_PAYLOAD_PARSE_H__

#include "vesync_cfg_internal.h"
#include "vesync_frame.h"

#ifdef __cplusplus
extern "C"
{
#endif

/* playload版本 */
#ifdef PR_TL_PAYLOAD_PROTOCOL_VER
#define TL_PAYLOAD_PROTOCOL_VERSION     PR_TL_PAYLOAD_PROTOCOL_VER
#else
#define TL_PAYLOAD_PROTOCOL_VERSION     (2)     // payload默认采用KLV格式，对应版本号为2
#endif
#define TL_PAYLOAD_PROTOCOL_HEAD_LEN    (4)     // payload协议头部长度为4bytes

/**
 * @brief  Vesync Frame数据帧的载荷封装
 * @param[in]   op                      [操作码]
 * @param[in]   sc                      [状态码]
 * @param[in]   p_pl                    [指向应用数据的缓存，这里的payload是Vesync Frame的Payload中的Payload]
 * @param[in]   pl_len                  [应用数据的长度]
 * @param[out]  out_data                [指向封装完成的Vesync Frame的载荷输出缓存]
 * @param[out]  out_len                 [指向输出封装完成的载荷长度的缓存]
 * @return      int32_t                 [成功：SDK_OK，失败：SDK_FAIL]
 */
int32_t vesync_tl_payload_encode(uint16_t op, uint8_t sc, uint8_t *p_pl, uint16_t pl_len, uint8_t *p_out, uint16_t *p_out_len);

/**
 * @brief Vesync Frame数据帧的载荷解析
 * @param[in]   p_in                    [指向Vesync Frame的载荷数据缓存]
 * @param[in]   in_len                  [输入的长度]
 * @param[in]   p_op                    [指向输出操作码的缓存]
 * @param[in]   p_sc                    [指向输出状态码的缓存]
 * @param[in]   p_pl_len                [指向输出应用数据长度的缓存]
 * @return      uint8_t *               [指向解析成功的应用数据，opcode携带的数据]
 * @return      NULL                    [非法的Vesync Frame载荷数据]
 */
uint8_t *vesync_tl_payload_decode(uint8_t *p_in, uint16_t in_len, uint16_t *p_op, uint8_t *p_sc, uint16_t *p_pl_len);

#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_TL_PAYLOAD_PARSE_H__ */
