/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_wifi.c
 * @brief       Wi-Fi模块接口定义
 * @author      Joshua
 * @date        2021-05-26
 */

#include <stdio.h>
#include <string.h>

#include "vesync_wifi_internal.h"
#include "vhal_utils.h"
#include "vhal_wifi.h"
#include "vesync_event.h"
#include "vesync_common.h"
#include "vesync_cfg.h"
#include "vesync_log_internal.h"


// TODO:FixME
#include "vesync_report_internal.h"

// End TODO

static vesync_wifi_t s_wifi;

/*-----------------------------------------------------------------------------*
 *                                 内部函数实现                          *
 *-----------------------------------------------------------------------------*/
/**
 * @brief 设置重连原因
 * @param[in]  reason       [重连原因]
 */
static void vesync_wifi_set_reconnect_reason(int reason)
{
    if (s_wifi.set_reconnect_reason)
    {
        s_wifi.set_reconnect_reason(reason);
    }
}

/**
 * @brief 设置重连次数
 * @param[in]  fail_type              [失败类型]
 */
static void vesync_wifi_set_reconnect_count(int fail_type)
{
    if (s_wifi.set_reconnect_count)
    {
        s_wifi.set_reconnect_count(fail_type);
    }
}

/**
 * @brief 设置dhcp的hostname
 * @param[in]  p_hostname       [保存hostname]
 * @param[in]  buf_len          [p_hostname空间大小]
 * @return    char *            [dhcp主机名]
 */
static char *vesync_wifi_set_dhcp_hostname(char *p_hostname, int buf_len)
{
    if (NULL == p_hostname)
    {
        return NULL;
    }

    snprintf(p_hostname, buf_len, "%s-%s", PR_BRAND, PR_TYPE);
    SDK_LOG(LOG_DEBUG, "New hostname is %s\n", p_hostname);

    return p_hostname;
}


/**
 * @brief 连接WiFi的结果回调
 * @param status                 [WiFi连接状态，包括连接成功和连接掉线，以及连接失败时的错误原因]
 */
static void vesync_wifi_connect_cb(VHAL_WIFI_STATUS_E status)
{
    vesync_ev_t ev;
    memset(&ev, 0, sizeof(vesync_ev_t));
    s_wifi.link_status = status;

    switch (s_wifi.link_status)
    {
        case VHAL_WIFI_CONNECTED:
            ev.event_id = EVENT_WIFI_CONNECTED;
            vesync_event_publish(&ev);
            break;
        case VHAL_WIFI_GOT_IP:
            s_wifi.connect_fail_reason = VHAL_WIFI_INIT;
            ev.event_id = EVENT_ROUTER_GOT_IP;
            vesync_event_publish(&ev);
            break;
        case VHAL_WIFI_LOST_IP:
        case VHAL_WIFI_WRONG_PWD:
        case VHAL_WIFI_NO_AP_FOUND:
        case VHAL_WIFI_CONNECT_FAIL:
        {
            // 配网Wi-Fi错误原因
            s_wifi.connect_fail_reason = status;

            // 离线统计分析
            vesync_wifi_set_reconnect_reason(WIFI_REASON);
            if (VHAL_WIFI_NO_AP_FOUND == status)
            {
                vesync_wifi_set_reconnect_count(WIFI_RETRY_NO_AP_FOUND);
            }
            else if (VHAL_WIFI_WRONG_PWD == status)
            {
                vesync_wifi_set_reconnect_count(WIFI_RETRY_INVALID_PWD);
            }
            else if (VHAL_WIFI_CONNECT_FAIL == status)
            {
                vesync_wifi_set_reconnect_count(WIFI_RETRY_CONNECT_FAIL);
            }

            ev.event_id = EVENT_WIFI_DISCONNECTED;
            vesync_event_publish(&ev);
            VERR_UPLOAD(VERR_WIFI_CONNECT_FAIL, status);

            break;
        }
        case VHAL_WIFI_SCAN_DONE:
            ev.event_id = EVENT_WIFI_SCANDONE;
            vesync_event_publish(&ev);
            break;
        case VHAL_WIFI_STA_CONNECT_SOFTAP:
            ev.event_id = EVENT_CFGNET_APP_CONNECTED;
            vesync_event_publish(&ev);
            break;
        case VHAL_WIFI_STA_DISCONNECT_SOFTAP:
            ev.event_id = EVENT_CFGNET_APP_DISCONNECTED;
            vesync_event_publish(&ev);
            break;
        default:
            break;
    }

}


/*-----------------------------------------------------------------------------*
 *                                 外部函数实现                          *
 *-----------------------------------------------------------------------------*/

/**
* @brief 用户调用初始化wifi模块
*/
void vesync_wifi_init(void)
{
    char hostname[32] = {0,};
    VHAL_WIFI_PS_TYPE_E ps_mode = VHAL_WIFI_PS_NONE;

    memset(&s_wifi, 0, sizeof(vesync_wifi_t));

    // Wi-Fi连接状态，默认为断开状态
    s_wifi.link_status = VHAL_WIFI_INIT;
    s_wifi.connect_fail_reason = VHAL_WIFI_INIT;

    s_wifi.set_reconnect_reason = vesync_net_set_reconnect_reason;
    s_wifi.set_reconnect_count = vesync_net_set_reconnect_count;

    if (PR_WIFI_PS_TYPE >= VHAL_WIFI_PS_NONE && PR_WIFI_PS_TYPE <= VHAL_WIFI_PS_ULTRA_LOW)
    {
        ps_mode = PR_WIFI_PS_TYPE;
    }

    vhal_wifi_init(vesync_wifi_connect_cb, ps_mode,
        vesync_wifi_set_dhcp_hostname(hostname, sizeof(hostname)), PR_COUNTRY_CODE);
}

/**
* @brief 用户调用关闭wifi模块
*/
void vesync_wifi_deinit(void)
{
    vhal_wifi_deinit();
}

/**
* @brief vesync客户端连接WiFi
* @param[in]  p_wifi_ssid       [WiFi账号]
* @param[in]  p_wifi_pwd        [WiFi密码]
* @param[in]  auth_mode         [WiFi加密模式]
*/
void vesync_wifi_connect(char *p_wifi_ssid, char *p_wifi_pwd, VHAL_WIFI_AUTH_MODE_E auth_mode)
{
    vhal_wifi_connect(p_wifi_ssid, p_wifi_pwd, auth_mode);
}

/**
* @brief vesync客户端断开重连WiFi
*/
void vesync_wifi_reconnect(void)
{
    vhal_wifi_stop();
    vesync_sleep(20);// 延时
    vhal_wifi_start();
    SDK_LOG(LOG_DEBUG, "Reconnect Wi-Fi.\n");
}

/**
* @brief 获取Wi-Fi连接状态
* @return VHAL_WIFI_STATUS_E          [与HAL相同定义的wifi连接状态]
*/
VHAL_WIFI_STATUS_E vesync_wifi_get_link_status(void)
{
    return s_wifi.link_status;
}

/**
* @brief 获取Wi-Fi连接失败原因
* @return VHAL_WIFI_STATUS_E          [与HAL相同定义的wifi连接失败原因]
*/
VHAL_WIFI_STATUS_E vesync_wifi_get_connect_fail_reason(void)
{
    return s_wifi.connect_fail_reason;
}

