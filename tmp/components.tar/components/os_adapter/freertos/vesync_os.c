/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_os.c
 * @brief       os系统函数抽象层，封装freertos系统相关接口
 * @author      Joshua
 * @date        2021-05-07
 */

#include <freertos/FreeRTOS.h>
#include <freertos/task.h>

#include "vesync_os_internal.h"

/*
 * @brief  延时函数
 * @param[in]  ms                     [延时时间，毫秒]
 * @return none
 */
void vesync_sleep(int ms)
{
    vTaskDelay(VESYNC_MS_TO_TICKS(ms));
}

