/**
 *  Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vhal_uart.c
 * @brief       乐鑫平台串口收发接口封装
 * @author      Dongri.Su
 * @date        2021-04-28
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/queue.h"
#include "driver/uart.h"

#include "vesync_log.h"
#include "vesync_common.h"

#include "vhal_uart_internal.h"



// 串口配置


static TaskHandle_t s_uart_taskhd = NULL;;       // UART数据接收任务句柄


/*-----------------------------------------------------------------------------*
 *                           内部函数API实现                                         *
 *-----------------------------------------------------------------------------*/

#if defined(ENABLE_MULTI_UART) && ENABLE_MULTI_UART

static vhal_esp_uart_status_t s_uart_status[VHAL_UART_NUM_MAX];

/**
 * @brief 串口事件任务
 * @param[in]  pvParameters             [未使用]
 */
static void vhal_esp_uart_evt_task(void *pvParameters)
{
    uint8_t idx = 0;
    int32_t ret = 0;
    size_t length = 0;
    uint8_t *p_buf = (uint8_t *) malloc(UART_RECV_BUF_SIZE);

    while (1)
    {
        for (idx = 0; idx < VHAL_UART_NUM_MAX; idx++)
        {
            if (s_uart_status[idx].cfg_flag)
            {
                uart_get_buffered_data_len(s_uart_status[idx].uart_num, (size_t*)&length);
                if (length > 0)
                {
                    memset(p_buf, 0, UART_RECV_BUF_SIZE);
                    ret = uart_read_bytes(s_uart_status[idx].uart_num, p_buf, length, 100);     // 读取100ms，根据实际情况进行调整
                    if (ret > 0)
                    {
                        // 接收到数据，回调给应用层
                        if (NULL != s_uart_status[idx].recv_cb)
                        {
                            s_uart_status[idx].recv_cb(s_uart_status[idx].uart_num, p_buf, length);
                        }
                    }
                }
            }
        }

        vTaskDelay(pdMS_TO_TICKS(20));      // Delay 20ms，不能去掉，否则上电串口还没初始化完，该任务可能会进入死循环
    }

    free(p_buf);
    p_buf = NULL;
    vTaskDelete(NULL);
}
#else
static vhal_esp_uart_status_t s_uart_status;

/**
 * @brief 串口事件任务
 * @param[in]  pvParameters             [未使用]
 */
static void vhal_esp_uart_evt_task(void *pvParameters)
{
    uart_event_t event;
    uint8_t *p_buf = (uint8_t *) malloc(UART_RECV_BUF_SIZE);

    for (;;)
    {
        // Waiting for UART event.
        if (xQueueReceive(s_uart_status.uart_queue, (void *)&event, (portTickType)portMAX_DELAY))
        {
            bzero(p_buf, UART_RECV_BUF_SIZE);
            //HAL_LOG(LOG_DEBUG, "uart[%d] event:\n", s_uart_num);

            switch (event.type)
            {
                // Event of UART receving data
                // We'd better handler data event fast, there would be much more data events than
                // other types of events. If we take too much time on data event, the queue might be full.
                case UART_DATA:
                    //HAL_LOG(LOG_INFO, "[UART DATA]: %d\n", event.size);
                    uart_read_bytes(s_uart_status.uart_num, p_buf, event.size, portMAX_DELAY);
                    if(s_uart_status.recv_cb)
                    {
                        s_uart_status.recv_cb(s_uart_status.uart_num, p_buf, event.size);
                    }
                    break;

                // Event of HW FIFO overflow detected
                case UART_FIFO_OVF:
                    HAL_LOG(LOG_INFO, "hw fifo overflow\n");
                    // If fifo overflow happened, you should consider adding flow control for your application.
                    // The ISR has already reset the rx FIFO,
                    // As an example, we directly flush the rx buffer here in order to read more data.
                    uart_flush_input(s_uart_status.uart_num);
                    xQueueReset(s_uart_status.uart_queue);
                    break;

                // Event of UART ring buffer full
                case UART_BUFFER_FULL:
                    HAL_LOG(LOG_INFO, "ring buffer full\n");
                    // If buffer full happened, you should consider encreasing your buffer size
                    // As an example, we directly flush the rx buffer here in order to read more data.
                    uart_flush_input(s_uart_status.uart_num);
                    xQueueReset(s_uart_status.uart_queue);
                    break;

#ifdef CONFIG_IDF_TARGET_ESP32
                //Event of UART RX break detected
                case UART_BREAK:
                    HAL_LOG(LOG_INFO, "uart rx break\n");
                    break;
#endif

                case UART_PARITY_ERR:
                    HAL_LOG(LOG_INFO, "uart parity error\n");
                    break;

                // Event of UART frame error
                case UART_FRAME_ERR:
                    HAL_LOG(LOG_INFO, "uart frame error\n");
                    break;

                // Others
                default:
                    HAL_LOG(LOG_INFO, "uart event type: %d\n", event.type);
                    break;
            }
        }
    }

    free(p_buf);
    p_buf = NULL;
    vTaskDelete(NULL);
}
#endif /* defined(ENABLE_MULTI_UART) && ENABLE_MULTI_UART */


/*-----------------------------------------------------------------------------*
 *                           外部函数API实现                                         *
 *-----------------------------------------------------------------------------*/

/**
 * @brief  串口初始化
 * @return     void
 */
void vhal_uart_init(void)
{
    // Create a task to handler UART event from ISR
    if (NULL == s_uart_taskhd)
    {
#if defined(ENABLE_MULTI_UART) && ENABLE_MULTI_UART
        memset(&s_uart_status[0], 0, sizeof(s_uart_status));
#else
        memset(&s_uart_status, 0, sizeof(s_uart_status));
#endif

        if (pdPASS != xTaskCreate(vhal_esp_uart_evt_task, UART_TASK_NAME, UART_TASK_STACK_SIZE, NULL, UART_TASK_PRIO, &s_uart_taskhd))
        {
            HAL_LOG(LOG_ERROR, "Create UART event task fail!!!\n");
        }
    }
}

/**
 * @brief  串口参数配置
 * @param[in]  rx_pin               [串口rx引脚]
 * @param[in]  rx_pin               [串口tx引脚]
 * @param[in]  uart_num             [串口编号]
 * @param[in]  baudrate             [串口波特率]
 * @return     void
 */
void vhal_uart_config(uint32_t rx_pin, uint32_t tx_pin, VHAL_UART_PORT_E uart_num, uint32_t baudrate)
{
    QueueHandle_t uart_queue;           // typedef void * QueueHandle_t
    uart_config_t uart_config = {
        .baud_rate = baudrate,
        .data_bits = UART_DATA_8_BITS,
        .parity = UART_PARITY_DISABLE,
        .stop_bits = UART_STOP_BITS_1,
        .flow_ctrl = UART_HW_FLOWCTRL_DISABLE
    };

    if (uart_num >= VHAL_UART_NUM_MAX)
    {
        HAL_LOG(LOG_ERROR, "UART number(%d) is error!!\n", uart_num);
        return;
    }

#if defined(ENABLE_MULTI_UART) && ENABLE_MULTI_UART
    s_uart_status[uart_num].uart_num = uart_num;
    uart_queue = s_uart_status[uart_num].uart_queue;
    s_uart_status[uart_num].cfg_flag = true;
#else
    s_uart_status.uart_num = uart_num;
    uart_queue = s_uart_status.uart_queue;
#endif

    // 配置uart协议
    uart_param_config(uart_num, &uart_config);

    // Install UART driver, and get the queue.
#ifdef CONFIG_IDF_TARGET_ESP8266
    uart_driver_install(uart_num, UART_BUF_SIZE, UART_BUF_SIZE, 10, &uart_queue, 0);
#elif defined(CONFIG_IDF_TARGET_ESP32)
    // 设置引脚,ESP8266不支持设置业务串口
    uart_set_pin(uart_num, tx_pin, rx_pin, UART_PIN_NO_CHANGE, UART_PIN_NO_CHANGE);
    uart_driver_install(uart_num, UART_BUF_SIZE, UART_BUF_SIZE, 20, &uart_queue, 0);
    //uart_enable_pattern_det_intr(s_uart_num, '+', PATTERN_CHR_NUM, 10000, 10, 10);
    //uart_pattern_queue_reset(s_uart_num, 20);
#endif
}

/**
 * @brief 注册串口接收数据回调
 * @param[in]  uart_num             [串口编号]
 * @param[in]  cb                   [串口数据接收回调函数]
 * @return     void
 */
void vhal_uart_reg_recv_cb(VHAL_UART_PORT_E uart_num, vhal_uart_recv_cb_t cb)
{
    if (uart_num >= VHAL_UART_NUM_MAX)
    {
        HAL_LOG(LOG_ERROR, "UART number(%d) is error!!\n", uart_num);
        return;
    }

#if defined(ENABLE_MULTI_UART) && ENABLE_MULTI_UART
    s_uart_status[uart_num].recv_cb = cb;
#else
    s_uart_status.recv_cb = cb;
#endif
}

/**
 * @brief  串口发送数据
 * @param[in]  uart_num             [串口编号]
 * @param[in]  p_buf                [待发送数据]
 * @param[in]  buf_len              [待发送数据长度]
 * @return     int                  [执行结果，0表示成功，其他值表示失败]
 */
int vhal_uart_send(VHAL_UART_PORT_E uart_num, uint8_t *p_buf, uint16_t buf_len)
{
    int send_bytes = -1;

    if (NULL == p_buf)
    {
        return VHAL_FAIL;
    }
    if (uart_num >= VHAL_UART_NUM_MAX)
    {
        return VHAL_FAIL;
    }

    if (buf_len != 0)
    {
        /* @return
         * - (-1) Parameter error
         * - OTHERS (>=0) The number of bytes pushed to the TX FIFO
         */
        send_bytes = uart_write_bytes(uart_num, (const char *)p_buf, buf_len);
    }

    if (send_bytes < 0)
    {
        return VHAL_FAIL;
    }

    return VHAL_OK;
}

