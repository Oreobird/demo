/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        led_strip_flash.h
 * @brief       led_strip flash读写
 * @author      Lind
 * @date        2021-12-20
 */

#ifndef __LED_STRIP_FLASH_H__
#define __LED_STRIP_FLASH_H__

#include "led_strip.h"
#include "led_strip_board.h"

#ifdef __cplusplus
extern "C" {
#endif

#define LS_KLV_DATA_LEN             (40)                                // klv 状态数据固有长度
#define LS_KLV_MULTI_HSV_DATA_LEN   (8 * LED_NODE_MAX_NUM)              // 多段模式数据最大长度
#define LS_USER_CFG_KEY_DATA        "led_strip"                         // NVS采用key:value格式进行存储
#define LS_USER_SCENE_KEY_DATA      "scene_param"                       // 自定义场景数据 klv格式
#define LSP_APP_DATA_VERSION    (1)                                     // APP数据的配置版本

/*
 * @brief 配置数据key 定义
 */
typedef enum
{
    LS_KEY_VERSION = 0,         //版本
    LS_KEY_STATUS,
    LS_KEY_MODEL,
    LS_KEY_NODE_NUM,
    LS_KEY_CUSTOM_SCENE_NUM,
    LS_KEY_HSVW,
    LS_KEY_SCENE_ID,
    LS_KEY_MULTI_HSV,
    LS_KEY_LAST_GEN_ID,
} LS_CFG_KEY_E;

/*
 * @brief 自定义场景数据key 定义
 */
typedef enum
{
    LS_KEY_SCENE_MODE = 0,
    LS_KEY_SCENE_NODE_NUM,
    LS_KEY_SCENE_ID_LIST,
    LS_KEY_SCENE_MULTI_HSV,
} LS_SCENE_KEY_E;

/**
 * @brief 保存数据到flash
 * @param[in]  data              [开关配置]
 * @return     int               [成功：APP_OK， 失败：APP_FAIL]
 */
int ls_save_config(ls_status_t data);

/**
 * @brief 从flash中读取数据到内存
 * @param[out] p_data            [开关配置]
 * @return     int               [成功：APP_OK， 失败：APP_FAIL]
 */
int ls_read_config(ls_status_t *p_data);

/**
 * @brief 保存场景信息
 * @param[in]  **pst_data               [场景信息]
 * @param[in]  num                      [自定义场景数量]
  * @param[in]  *p_id_list              [场景ID]
 * @return     int                      [成功：APP_OK， 失败：APP_FAIL]
 */
int  ls_save_scene(ls_static_param_t **pst_data, uint8_t num, uint16_t *p_id_list);

/**
 * @brief 从flash中读取场景信息到内存
 * @param[out]  **pst_data              [场景信息]
 * @param[in]   num                     [自定义场景数量]
 * @param[out]  *p_id_list              [场景ID]
 * @return     int                      [成功：APP_OK， 失败：APP_FAIL]
 */
int ls_read_scene(ls_static_param_t **pst_data, uint8_t num, uint16_t *p_id_list);

/**
 * @brief 清除配置
 * @return int          [成功：APP_OK， 失败：APP_FAIL]
 */
int ls_clear_config(void);


#ifdef __cplusplus
}
#endif

#endif

