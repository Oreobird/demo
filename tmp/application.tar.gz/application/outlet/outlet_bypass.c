/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file        outlet_wifi_led.c
* @brief       outlet bypass
* @author      Joshua
* @date        2021-06-04
*/
#include <string.h>
#include <stdio.h>
#include "cJSON.h"

#include "vesync_common.h"
#include "vesync_log.h"
#include "vesync_timing.h"
#include "vesync_memory.h"

#include "outlet_board.h"
#include "outlet.h"
#include "outlet_bypass.h"
#include "outlet_production.h"
#include "outlet_timing.h"
#include "outlet_inching.h"
#include "outlet_schedule.h"
#include "outlet_away.h"
#if defined(OUTLET_ELEC_METERING) && (OUTLET_ELEC_METERING == 1)
#include "outlet_flash.h"
#include "outlet_metering.h"
#include "outlet_save_elec.h"
#endif


//#define FLOAT_TO_DOT_02_FLOAT(f) ((float)((int)((f) * 100)) / 100)
//#define FLOAT_TO_DOT_04_FLOAT(f) ((float)((int)((f) * 10000)) / 10000)
#define FLOAT_TO_DOT_02_FLOAT(f) (f)
#define FLOAT_TO_DOT_04_FLOAT(f) (f)


/**
 * @brief 开关添加timer
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  p_data                   [回调函数传入数据]
 */
static void outlet_bp_add_timer(bypass_msg_ctx_t *p_msg_ctx, void *p_data)
{
    uint16_t timer_id = 0;
    int ret = APP_FAIL;
    bool action = false;
    bypass_timer_data_t *pTimer = NULL;
    cJSON *json_data = NULL;

    if(NULL == p_data)
    {
        vesync_bypass_reply_pkg_err_msg(BP_ERR_PARA_ILLEGAL, p_msg_ctx->p_trace_msg, BP_ERR_PARAM_CONV(p_data, BP_ERR_PARAM_NULL_PTR));
        return;
    }

    pTimer = (bypass_timer_data_t *)p_data;
    if (TIMER_ACTION_ON == pTimer->action)
        action = true;

    APP_LOG(LOG_DEBUG,"pTimer->action = %d \r\n", pTimer->action);
    ret = outlet_timing_add(action, pTimer->total_sec, &timer_id);      // 最多5个
    if (APP_OK != ret)
    {
        if (timer_id >= MAX_OUTLET_TIMER_NUM)
            ret = BP_ERR_TIMER_EXCEED_MAX;
        else
            ret = BP_ERR_CMD_EXECUTE_FAIL;
    }
    else
    {
        ret = BP_ERR_NO_ERR;

        json_data = cJSON_CreateObject();
        if(json_data != NULL)
        {
            cJSON_AddNumberToObject(json_data,"id", timer_id);
        }
    }

    vesync_bypass_reply_noqos(ret, p_msg_ctx->p_trace_msg, json_data);
}

/**
 * @brief 开关删除timer
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  p_data                   [回调函数传入数据]
 */
static void outlet_bp_del_timer(bypass_msg_ctx_t *p_msg_ctx,void *p_data)
{
    uint32_t *p_id = NULL;

    if(NULL == p_data)
    {
        vesync_bypass_reply_pkg_err_msg(BP_ERR_PARA_ILLEGAL, p_msg_ctx->p_trace_msg, BP_ERR_PARAM_CONV(p_data, BP_ERR_PARAM_NULL_PTR));
        return;
    }

    p_id =(uint32_t *)p_data;
    if (*p_id > MAX_OUTLET_TIMER_NUM)
    {
        vesync_bypass_reply_pkg_err_msg(BP_ERR_PARA_ILLEGAL, p_msg_ctx->p_trace_msg, "Timer ID illegal");
    }
    if (APP_OK != outlet_timing_remove((uint16_t)*p_id))
    {
        vesync_bypass_reply_pkg_err_msg(BP_ERR_TIMER_NOT_FOUND, p_msg_ctx->p_trace_msg, "Timer remove fail");
    }
    else
        vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, NULL);
}


/**
 * @brief  timer数据封装json格式
 * @param[in] id                [timer 的id]
 * @param[in] remain_sec        [剩余秒数]
 * @param[in] total_sec         [总的秒数]
 * @param[in] act               [true为开启，false为关闭]
 * @return cJSON* 封装好的json数据指针
 */
static cJSON* vesync_bypass_timer_pack_json(uint16_t id, uint32_t remain_sec, uint32_t total_sec, bool act)
{
    cJSON *json = cJSON_CreateObject();
    if(NULL == json)
    {
        return NULL;
    }

    cJSON_AddNumberToObject(json,"id", id);
    cJSON_AddNumberToObject(json, "remain", remain_sec);
    cJSON_AddNumberToObject(json, "total", total_sec);

    if (act)
    {
        cJSON_AddStringToObject(json, "action", "on");
    }
    else
    {
        cJSON_AddStringToObject(json, "action", "off");
    }

    return  json;
}

/**
 * @brief 查询开关timer
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  p_data                   [回调函数传入数据]
 */
static void outlet_bp_get_timer(bypass_msg_ctx_t *p_msg_ctx,void *p_data)
{
    int ret = -1, ret1 = APP_FAIL;
    timing_data_t tm;
    bool act = false;
    cJSON *json_data = NULL;
    cJSON *json_tm_arr = NULL;
    cJSON *json_timer = NULL;

    json_data =  cJSON_CreateObject();
    if(json_data != NULL)
    {
        ret1 = outlet_timing_get_act(MIN_OUTLET_TIMER_ID, &act);
        ret = vesync_timing_get(MIN_OUTLET_TIMER_ID, &tm);
        if (SDK_OK == ret && APP_OK == ret1)
        {
            json_timer = vesync_bypass_timer_pack_json(tm.timing_id, tm.remain_second, tm.total_second, act);
            if (NULL != json_timer)
                ret = BP_ERR_NO_ERR;
            else
                ret = BP_ERR_OUT_OF_MEMORY;     // 内存不足时才会返回失败
        }
        else
        {
            ret = BP_ERR_NO_ERR;        // 无timer
        }

        cJSON_AddItemToObject(json_data, "timers", json_tm_arr =  cJSON_CreateArray());
        if (NULL != json_tm_arr)
        {
            cJSON_AddItemToArray(json_tm_arr,  json_timer);
        }
    }

    vesync_bypass_reply_noqos(ret, p_msg_ctx->p_trace_msg, json_data);
}

/**
 * @brief 开关添加timerV2
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  p_data                   [回调函数传入数据]
 */
static void outlet_bp_add_timerV2(bypass_msg_ctx_t *p_msg_ctx, void *p_data)
{
    uint16_t timer_id = 0;
    int err_code = BP_ERR_NO_ERR;
    const char* err_msg = NULL;
    bool action = false;
    bypass_timerV2_data_t *pTimer = NULL;
    cJSON *json_data = NULL;
    cJSON *json_result = NULL;

    if(NULL == p_data)
    {
        vesync_bypass_reply_pkg_err_msg(BP_ERR_PARA_ILLEGAL, p_msg_ctx->p_trace_msg, BP_ERR_PARAM_CONV(p_data, BP_ERR_PARAM_NULL_PTR));
        return;
    }

    pTimer = (bypass_timerV2_data_t *)p_data;
    json_data = pTimer->json_action;

    if (cJSON_IsArray(json_data))
    {
        int arr_size = cJSON_GetArraySize(json_data);
        for (int idx = 0; idx < arr_size; idx++)
        {
            cJSON *json_obj = cJSON_GetArrayItem(json_data, idx);

            if (NULL == json_obj)
            {
                APP_LOG(LOG_ERROR, "JSON parse error.\n");
                err_code = BP_ERR_PARA_ILLEGAL;
                err_msg = BP_ERR_PARAM_CONV(array, BP_ERR_PARAM_NULL_PTR);
                goto EXIT;
            }

            cJSON *json_type = cJSON_GetObjectItemCaseSensitive(json_obj, "type");
            cJSON *json_act = cJSON_GetObjectItemCaseSensitive(json_obj, "act");
            if(cJSON_IsString(json_type) && cJSON_IsString(json_act))
            {
                if (0 != strcmp(json_type->valuestring, "switch"))
                {
                    APP_LOG(LOG_ERROR, "Unknow switch type(%s).\n", json_type->valuestring);
                    err_code = BP_ERR_PARA_ILLEGAL;
                    err_msg = BP_ERR_PARAM_CONV(type, BP_ERR_PARAM_NULL_PTR);
                    goto EXIT;
                }
                if (0 == strcmp(json_act->valuestring, "on"))
                {
                    action = true;
                }
                else if (0 == strcmp(json_act->valuestring, "off"))
                {
                    action = false;
                }
                else
                {
                    APP_LOG(LOG_ERROR, "Unknow switch act(%s).\n", json_act->valuestring);
                    err_code = BP_ERR_PARA_ILLEGAL;
                    err_msg = BP_ERR_PARAM_CONV(act, BP_ERR_PARAM_NULL_PTR);
                    goto EXIT;
                }
            }
            else
            {
                err_code = BP_ERR_PARA_ILLEGAL;
                err_msg = BP_ERR_PARAM_CONV(startAct, BP_ERR_PARAM_NULL_PTR);
                goto EXIT;
            }
        }
    }
    else
    {
        err_code = BP_ERR_PARA_ILLEGAL;
        err_msg = BP_ERR_PARAM_CONV(startAct, BP_ERR_PARAM_NULL_PTR);
        goto EXIT;
    }

    APP_LOG(LOG_DEBUG,"action = %d \r\n", action);
    if (APP_OK != outlet_timing_add(action, pTimer->total_sec, &timer_id))  // 最多5个
    {
        if (timer_id >= MAX_OUTLET_TIMER_NUM)
            err_code = BP_ERR_TIMER_EXCEED_MAX;
        else
            err_code = BP_ERR_CMD_EXECUTE_FAIL;
    }
    else
    {
        json_result = cJSON_CreateObject();
        if(json_result != NULL)
        {
            cJSON_AddNumberToObject(json_result, "id", timer_id);
        }
    }

EXIT:
    if (BP_ERR_NO_ERR == err_code)
    {
        vesync_bypass_reply_noqos(err_code, p_msg_ctx->p_trace_msg, json_result);
    }
    else
    {
        vesync_bypass_reply_pkg_err_msg(err_code, p_msg_ctx->p_trace_msg, err_msg);
    }
}

/**
 * @brief 开关删除timer
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  p_data                   [回调函数传入数据]
 */
static void outlet_bp_del_timerV2(bypass_msg_ctx_t *p_msg_ctx,void *p_data)
{
    uint32_t *p_id = NULL;
    cJSON *json_result = NULL;

    if(NULL == p_data)
    {
        vesync_bypass_reply_pkg_err_msg(BP_ERR_PARA_ILLEGAL, p_msg_ctx->p_trace_msg, BP_ERR_PARAM_CONV(p_data, BP_ERR_PARAM_NULL_PTR));
        return;
    }

    p_id =(uint32_t *)p_data;
    if (*p_id > MAX_OUTLET_TIMER_NUM)
    {
        vesync_bypass_reply_pkg_err_msg(BP_ERR_PARA_ILLEGAL, p_msg_ctx->p_trace_msg, "Timer ID illegal");
        return;
    }
    if (APP_OK != outlet_timing_remove((uint16_t)*p_id))
    {
        vesync_bypass_reply_pkg_err_msg(BP_ERR_TIMER_NOT_FOUND, p_msg_ctx->p_trace_msg, "Timer remove fail");
    }
    else
    {
        json_result = cJSON_CreateObject();
        if(json_result != NULL)
        {
            cJSON_AddNumberToObject(json_result, "id", *p_id);
            vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, json_result);
        }
    }
}


/**
 * @brief  timer数据封装json格式
 * @param[in] id                [timer 的id]
 * @param[in] remain_sec        [剩余秒数]
 * @param[in] total_sec         [总的秒数]
 * @param[in] act               [true为开启，false为关闭]
 * @return cJSON* 封装好的json数据指针
 */
static cJSON* vesync_bypass_timerV2_pack_json(uint16_t id, uint32_t remain_sec, uint32_t total_sec, bool act)
{
    cJSON *json = cJSON_CreateObject();
    cJSON *json_arry = NULL;
    cJSON *json_sub = NULL;
    if(NULL == json)
    {
        return NULL;
    }

    cJSON_AddNumberToObject(json,"id", id);
    cJSON_AddNumberToObject(json, "remain", remain_sec);
    cJSON_AddNumberToObject(json, "total", total_sec);
    json_arry = cJSON_AddArrayToObject(json, "startAct");
    if (NULL == json_arry)
    {
        cJSON_free(json);
        return NULL;
    }
    cJSON_AddItemToArray(json_arry, json_sub = cJSON_CreateObject());
    if (NULL == json_sub)
    {
        cJSON_free(json);
        return NULL;
    }
    cJSON_AddStringToObject(json_sub, "type", "switch");
    cJSON_AddNumberToObject(json_sub, "num", 0);

    if (act)
    {
        cJSON_AddStringToObject(json_sub, "act", "on");
    }
    else
    {
        cJSON_AddStringToObject(json_sub, "act", "off");
    }

    return json;
}

/**
 * @brief 查询开关timer
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  p_data                   [回调函数传入数据]
 */
static void outlet_bp_get_timerV2(bypass_msg_ctx_t *p_msg_ctx,void *p_data)
{
    int ret = -1, ret1 = APP_FAIL;
    timing_data_t tm;
    bool act = false;
    cJSON *json_data = NULL;
    cJSON *json_tm_arr = NULL;
    cJSON *json_timer = NULL;

    json_data =  cJSON_CreateObject();
    if(NULL != json_data)
    {
        ret1 = outlet_timing_get_act(MIN_OUTLET_TIMER_ID, &act);
        ret = vesync_timing_get(MIN_OUTLET_TIMER_ID, &tm);
        if (SDK_OK == ret && APP_OK == ret1)
        {
            json_timer = vesync_bypass_timerV2_pack_json(tm.timing_id, tm.remain_second, tm.total_second, act);
            if (NULL != json_timer)
                ret = BP_ERR_NO_ERR;
            else
                ret = BP_ERR_OUT_OF_MEMORY;     // 内存不足时才会返回失败
        }
        else
        {
            ret = BP_ERR_NO_ERR;        // 无timer
        }

        cJSON_AddItemToObject(json_data, "timers", json_tm_arr =  cJSON_CreateArray());
        if (NULL != json_tm_arr)
        {
            cJSON_AddItemToArray(json_tm_arr,  json_timer);
        }
    }

    vesync_bypass_reply_noqos(ret, p_msg_ctx->p_trace_msg, json_data);
}


/**
 * @brief 开关添加inching
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  p_data                   [回调函数传入数据]
 */
static void outlet_bp_add_inching(bypass_msg_ctx_t *p_msg_ctx, void *p_data)
{
    uint32_t *p_total_sec = (uint32_t*)p_data;
    int ret = APP_FAIL;
    int err_code = BP_ERR_NO_ERR;
    char* err_msg = NULL;

    if (NULL == p_data)
    {
        err_code = BP_ERR_PARA_ILLEGAL;
        err_msg = BP_ERR_PARAM_CONV(p_data, BP_ERR_PARAM_TYPE);
        goto exit;
    }

    ret = outlet_inching_add_cfg(*p_total_sec);
    if (APP_FAIL == ret)
    {
        err_code = BP_ERR_CMD_EXECUTE_FAIL;
        goto exit;
    }

exit:
    if (BP_ERR_NO_ERR != err_code)
    {
        vesync_bypass_reply_pkg_err_msg(err_code, p_msg_ctx->p_trace_msg, err_msg);
    }
    else
    {
        vesync_bypass_reply_noqos(err_code, p_msg_ctx->p_trace_msg, NULL);
    }
}

/**
 * @brief 开关删除inching
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  p_data                   [回调函数传入数据]
 */
static void outlet_bp_del_inching(bypass_msg_ctx_t *p_msg_ctx,void *p_data)
{
    int ret = APP_FAIL;
    int err_code = BP_ERR_NO_ERR;
    char* err_msg = NULL;

    ret = outlet_inching_delete_cfg();
    if (APP_FAIL == ret)
    {
        err_code = BP_ERR_CMD_EXECUTE_FAIL;
        goto exit;
    }

exit:
    if (BP_ERR_NO_ERR != err_code)
    {
        vesync_bypass_reply_pkg_err_msg(err_code, p_msg_ctx->p_trace_msg, err_msg);
    }
    else
    {
        vesync_bypass_reply_noqos(err_code, p_msg_ctx->p_trace_msg, NULL);
    }
}

/**
 * @brief 开关查询inching
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  p_data                   [回调函数传入数据]
 */
static void outlet_bp_get_inching(bypass_msg_ctx_t *p_msg_ctx,void *p_data)
{
    int err_code = BP_ERR_NO_ERR;
    char* err_msg = NULL;
    const inching_status_t* inching_status = NULL;
    cJSON *json_data = NULL;

    inching_status = outlet_inching_get_status();
    if (NULL == inching_status)
    {
        err_code = BP_ERR_CMD_EXECUTE_FAIL;
        goto exit;
    }

    json_data =  cJSON_CreateObject();
    if(NULL == json_data)
    {
        err_code = BP_ERR_OUT_OF_MEMORY;
        goto exit;
    }

    cJSON *inchings = cJSON_AddArrayToObject(json_data, "inchings");
    if (NULL == inchings)
    {
        err_code = BP_ERR_OUT_OF_MEMORY;
        goto exit;
    }

    // 判断是不是被删除的Inching
    if (inching_status->total_sec != 0)
    {
        cJSON *inching =  cJSON_CreateObject();
        if(NULL == json_data)
        {
            err_code = BP_ERR_OUT_OF_MEMORY;
            goto exit;
        }

        cJSON_AddNumberToObject(inching, "state", inching_status->state);
        cJSON_AddNumberToObject(inching, "remainSec", inching_status->remain_sec);
        cJSON_AddNumberToObject(inching, "totalSec", inching_status->total_sec);
        cJSON_AddItemToArray(inchings, inching);
    }

exit:
    if (BP_ERR_NO_ERR != err_code)
    {
        cJSON_Delete(json_data);

        vesync_bypass_reply_pkg_err_msg(err_code, p_msg_ctx->p_trace_msg, err_msg);
    }
    else
    {
        vesync_bypass_reply_noqos(err_code, p_msg_ctx->p_trace_msg, json_data);
    }
}

/**
 * @brief 继电器测试
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  p_data                   [回调函数传入数据]
 */
static void outlet_bp_test_relay(bypass_msg_ctx_t *p_msg_ctx, void *p_data)
{
    if(NULL == p_data)
    {
        vesync_bypass_reply_pkg_err_msg(BP_ERR_PARA_ILLEGAL, p_msg_ctx->p_trace_msg, BP_ERR_PARAM_CONV(p_data, BP_ERR_PARAM_NULL_PTR));
        return;
    }

    // 执行开关开启/关闭，指示灯亮灭动作(定时器循环执行)
    outlet_production_test_relay();

    vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, NULL);
}

/**
 * @brief 生成Schedule配置项列表的JSON
 *
 * @param[in] json_array    [JSON数组根对象]
 * @param[in] p_list        [Schedule配置项列表]
 * @param[in] list_len      [列表的最大长度,注意大于等于列表内的配置项数量]
 * @return int              [Bypass定义的错误]
 */
static int schedule_list_json_marshal(void *json_array, bypass_schedule_base_t *p_list, uint32_t list_len)
{
    cJSON *p_out = (cJSON *)json_array;

    if (!cJSON_IsArray(p_out))
    {
        return BP_ERR_PARA_ILLEGAL;
    }

    for (uint32_t cnt = 0; cnt < list_len; cnt++)
    {
        // 判断列表结束
        if (0 == p_list[cnt].id)
        {
            break;
        }

        cJSON *sch_obj = cJSON_CreateObject();
        cJSON *sub_obj = NULL;
        uint8_t type = *((uint8_t *)p_list[cnt].type);

        cJSON_AddNumberToObject(sch_obj, "id", p_list[cnt].id);
        cJSON_AddBoolToObject(sch_obj, "enabled", *((bool *)p_list[cnt].enabled));
        cJSON_AddItemToObject(sch_obj, "startAct", (cJSON*)p_list[cnt].json_action);
        cJSON_AddNumberToObject(sch_obj, "type", type);
        if (BYPASS_SCHEDULE_JSON_TYPE_TMG_EVT == type)
        {
            sub_obj = cJSON_AddObjectToObject(sch_obj, "tmgEvt");

            cJSON_AddNumberToObject(sub_obj, "clkSec", *p_list[cnt].clock_sec);
        }
        else if (BYPASS_SCHEDULE_JSON_TYPE_SUN_EVT == type)
        {
            sub_obj = cJSON_AddObjectToObject(sch_obj, "sunEvt");

            cJSON_AddBoolToObject(sub_obj, "isRise", *((bool *)p_list[cnt].is_sunrise));
            cJSON_AddNumberToObject(sub_obj, "ofsSec", *p_list[cnt].offset_sec);
        }

        cJSON_AddNumberToObject(sch_obj, "repeat", *((uint8_t *)p_list[cnt].repeat_config));
        cJSON_AddItemToArray(p_out, sch_obj);
    }

    return BP_ERR_NO_ERR;
}

/**
 * @brief Outlet bypass 添加Schedule回调接口
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  p_data                   [回调函数传入数据]
 */
static void outlet_bp_add_schedule(bypass_msg_ctx_t *p_msg_ctx, void *p_data)
{
    int error_code = BP_ERR_PARA_ILLEGAL;

    if(NULL == p_data)
    {
        vesync_bypass_reply_pkg_err_msg(BP_ERR_PARA_ILLEGAL, p_msg_ctx->p_trace_msg, BP_ERR_PARAM_CONV(p_data, BP_ERR_PARAM_NULL_PTR));
        return;
    }

    uint32_t out_id = 0;
    cJSON *json_sch_ret = NULL;
    bypass_schedule_base_t *p_bp_sch = (bypass_schedule_base_t *)p_data;

    error_code = outlet_schedule_add(p_bp_sch, &out_id);
    APP_LOG(LOG_DEBUG, "error_code = %d \n", error_code);
    if (BP_ERR_NO_ERR == error_code)
    {
        // 添加成功，生成回应
        json_sch_ret = cJSON_CreateObject();
        if (NULL != json_sch_ret)
        {
            cJSON_AddNumberToObject(json_sch_ret, "id", out_id);
        }
    }

	vesync_bypass_reply_noqos(error_code, p_msg_ctx->p_trace_msg, json_sch_ret);
}

/**
 * @brief Outlet bypass 更新Schedule回调接口
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  p_data                   [回调函数传入数据]
 */
static void outlet_bp_upd_schedule(bypass_msg_ctx_t *p_msg_ctx, void *p_data)
{
    int error_code = BP_ERR_PARA_ILLEGAL;

    if(NULL == p_data)
    {
        vesync_bypass_reply_pkg_err_msg(BP_ERR_PARA_ILLEGAL, p_msg_ctx->p_trace_msg, BP_ERR_PARAM_CONV(p_data, BP_ERR_PARAM_NULL_PTR));
        return;
    }

    uint32_t out_id = 0;
    cJSON *json_sch_ret = NULL;
    bypass_schedule_base_t *p_bp_sch = (bypass_schedule_base_t *)p_data;

    error_code = outlet_schedule_upd(p_bp_sch, &out_id);
    APP_LOG(LOG_DEBUG, "error_code = %d \n", error_code);
    if (BP_ERR_NO_ERR == error_code)
    {
        // 更新成功，生成回应
        json_sch_ret = cJSON_CreateObject();
        if (NULL != json_sch_ret)
        {
            cJSON_AddNumberToObject(json_sch_ret, "id", out_id);
        }
    }

    vesync_bypass_reply_noqos(error_code, p_msg_ctx->p_trace_msg, json_sch_ret);
}

/**
 * @brief Outlet bypass 删除Schedule回调接口
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  p_data                   [回调函数传入数据]
 */
static void outlet_bp_del_schedule(bypass_msg_ctx_t *p_msg_ctx, void *p_data)
{
    int error_code = BP_ERR_PARA_ILLEGAL;

    if(NULL == p_data)
    {
        vesync_bypass_reply_pkg_err_msg(BP_ERR_PARA_ILLEGAL, p_msg_ctx->p_trace_msg, BP_ERR_PARAM_CONV(p_data, BP_ERR_PARAM_NULL_PTR));
        return;
    }

    uint32_t sch_id = *((uint32_t *)p_data);
    cJSON *json_sch_ret = NULL;

    error_code = outlet_schedule_del(sch_id);
    APP_LOG(LOG_DEBUG, "error_code = %d \n", error_code);
    if (BP_ERR_NO_ERR == error_code)
    {
        // 删除成功，生成回应
        json_sch_ret = cJSON_CreateObject();
        if (NULL != json_sch_ret)
        {
            cJSON_AddNumberToObject(json_sch_ret, "id", sch_id);
        }
    }

    vesync_bypass_reply_noqos(error_code, p_msg_ctx->p_trace_msg, json_sch_ret);
}

/**
 * @brief Outlet bypass 查询Schedule回调接口
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  p_data                   [回调函数传入数据]
 */
static void outlet_bp_get_schedules(bypass_msg_ctx_t *p_msg_ctx, void *p_data)
{
    int error_code = BP_ERR_PARA_ILLEGAL;

    if(NULL == p_data)
    {
        vesync_bypass_reply_pkg_err_msg(BP_ERR_PARA_ILLEGAL, p_msg_ctx->p_trace_msg, BP_ERR_PARAM_CONV(p_data, BP_ERR_PARAM_NULL_PTR));
        return;
    }

    uint32_t index = *((uint32_t *)p_data);
    cJSON *json_sch_ret = NULL;
    cJSON *json_array = NULL;
    // 配置项总数
    uint32_t total_num = 0;
    void *mult_sche_buf = NULL;

    // 输出列表
    bypass_schedule_base_t sch_bp_list[OUTLET_SCHEDULE_GET_MAX_NUM];
    // 初始化输出列表
    memset(sch_bp_list, 0, sizeof(bypass_schedule_base_t) * OUTLET_SCHEDULE_GET_MAX_NUM);
    // 读取配置项
    error_code = outlet_schedule_get_mult(index, &mult_sche_buf, sch_bp_list, &total_num);
    APP_LOG(LOG_DEBUG, "error_code = %d \n", error_code);
    if (BP_ERR_NO_ERR == error_code)
    {
        // 查询成功，生成回应
        json_sch_ret = cJSON_CreateObject();
        if (NULL != json_sch_ret)
        {
            cJSON_AddNumberToObject(json_sch_ret, "total", total_num);
            json_array = cJSON_AddArrayToObject(json_sch_ret, "schedules");
            // 把配置项列表生成JSON添加到回应的JSON
            schedule_list_json_marshal(json_array, sch_bp_list, OUTLET_SCHEDULE_GET_MAX_NUM);
        }
    }

    if (BP_ERR_SCHEDULE_NOT_FOUND == error_code)
    {
        error_code = BP_ERR_NO_ERR;

        // 生成空回应
        json_sch_ret = cJSON_CreateObject();
        if (NULL != json_sch_ret)
        {
            cJSON_AddNumberToObject(json_sch_ret, "total", total_num);
            cJSON_AddArrayToObject(json_sch_ret, "schedules");
        }
    }

    // 释放配置读取内存
    vesync_free(mult_sche_buf);

    vesync_bypass_reply_noqos(error_code, p_msg_ctx->p_trace_msg, json_sch_ret);
}

/**
 * @brief 由Away配置项的生成对应的JSON
 *
 * @param[in] json_obj      [JSON根对象]
 * @param[in] p_cfg         [Away配置项]
 * @param[in] p_rtp         [一组随机时间点]
 * @param[in] rtp_num       [随机时间点数量]
 * @return int              [Bypass定义的错误]
 */
static int away_cfg_json_marshal(void *json_obj, bypass_away_base_t *p_cfg, uint32_t *p_rtp, uint32_t rtp_num)
{
    cJSON *p_out = (cJSON *)json_obj;

    if (!cJSON_IsObject(p_out) || NULL == p_rtp || NULL == p_cfg)
    {
        return BP_ERR_PARA_ILLEGAL;
    }

    cJSON_AddNumberToObject(p_out, "repeat", p_cfg->repeat_config);
    cJSON_AddNumberToObject(p_out, "startClkSec", p_cfg->start_clk_sec);
    cJSON_AddNumberToObject(p_out, "endClkSec", p_cfg->end_clk_sec);

    cJSON_AddNumberToObject(p_out, "actsNum", rtp_num);
    cJSON *p_json_array = NULL;
    p_json_array = cJSON_AddArrayToObject(p_out, "rtClkSec");
    if (cJSON_IsArray(p_json_array))
    {
        for (uint32_t cnt = 0; cnt < rtp_num; cnt++)
        {
            cJSON *p_rtp_item = cJSON_CreateNumber(p_rtp[cnt]);
            if (cJSON_IsNumber(p_rtp_item))
            {
                cJSON_AddItemToArray(p_json_array, p_rtp_item);
            }
        }
    }

    return BP_ERR_NO_ERR;
}

/**
 * @brief Outlet bypass 添加Away回调接口
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  p_data                   [回调函数传入数据]
 */
static void outlet_bp_add_away(bypass_msg_ctx_t *p_msg_ctx, void *p_data)
{
    int error_code = BP_ERR_PARA_ILLEGAL;

    if(NULL == p_data)
    {
        vesync_bypass_reply_pkg_err_msg(BP_ERR_PARA_ILLEGAL, p_msg_ctx->p_trace_msg, BP_ERR_PARAM_CONV(p_data, BP_ERR_PARAM_NULL_PTR));
        return;
    }

    bypass_away_base_t *p_bp_away = (bypass_away_base_t *)p_data;

    if (p_bp_away->start_clk_sec < 0 || p_bp_away->start_clk_sec >= VCOM_SECOND_PER_DAY ||
        p_bp_away->end_clk_sec < 0 || p_bp_away->end_clk_sec >= VCOM_SECOND_PER_DAY)
    {
        vesync_bypass_reply_pkg_err_msg(BP_ERR_PARA_ILLEGAL, p_msg_ctx->p_trace_msg, BP_ERR_PARAM_CONV(p_data, BP_ERR_PARAM_VAL_INVALID));
        return;
    }

    // Away Add
    error_code = outlet_away_add(p_bp_away);
    APP_LOG(LOG_DEBUG, "error_code = %d \n", error_code);
    //
    vesync_bypass_reply_noqos(error_code, p_msg_ctx->p_trace_msg, NULL);
}

/**
 * @brief Outlet bypass 删除Schedule回调接口
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  p_data                   [回调函数传入数据]
 */
static void outlet_bp_del_away(bypass_msg_ctx_t *p_msg_ctx, void *p_data)
{
    int error_code = BP_ERR_PARA_ILLEGAL;

    UNUSED(p_data);

    error_code = outlet_away_del();
    APP_LOG(LOG_DEBUG, "error_code = %d \n", error_code);
    //
    vesync_bypass_reply_noqos(error_code, p_msg_ctx->p_trace_msg, NULL);
}

/**
 * @brief Outlet bypass 查询Schedule回调接口
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  p_data                   [回调函数传入数据]
 */
static void outlet_bp_get_away(bypass_msg_ctx_t *p_msg_ctx, void *p_data)
{
    int error_code = BP_ERR_PARA_ILLEGAL;

    UNUSED(p_data);

    bypass_away_base_t away_cfg;
    uint32_t rtp_num = 0, rtp_max_num = 0;
    uint32_t *rtp = NULL;

    outlet_away_get_max_min_rnd_times_point_num(&rtp_max_num, NULL);
    rtp = vesync_malloc(rtp_max_num * sizeof(uint32_t));
    if (NULL == rtp)
    {
        vesync_bypass_reply_pkg_err_msg(BP_ERR_OUT_OF_MEMORY, p_msg_ctx->p_trace_msg, NULL);
        return;
    }

    cJSON *json_away_ret = cJSON_CreateObject();
    if(NULL == json_away_ret)
    {
        error_code = BP_ERR_OUT_OF_MEMORY;
        goto EXIT;
    }

    // 查询AWAY
    error_code = outlet_away_get(&away_cfg, rtp, &rtp_num);

    cJSON *aways = cJSON_AddArrayToObject(json_away_ret, "aways");
    if(NULL == aways)
    {
        error_code = BP_ERR_OUT_OF_MEMORY;
        goto EXIT;
    }

    if (BP_ERR_NO_ERR == error_code)
    {
        cJSON *away = cJSON_CreateObject();
        if (NULL != json_away_ret)
        {
            away_cfg_json_marshal(away, &away_cfg, rtp, rtp_num);
        }

        cJSON_AddItemToArray(aways, away);
    }
    else if (BP_ERR_AWAY_NOT_FOUND == error_code)
    {
        // 生成空回应
        error_code = BP_ERR_NO_ERR;
    }

EXIT:
    // 释放时间点缓存
    vesync_free(rtp);

    if (BP_ERR_NO_ERR != error_code)
    {
        cJSON_Delete(json_away_ret);

        vesync_bypass_reply_pkg_err_msg(error_code, p_msg_ctx->p_trace_msg, NULL);
    }
    else
    {
        vesync_bypass_reply_noqos(error_code, p_msg_ctx->p_trace_msg, json_away_ret);
    }
}

/**
 * @brief 设置开关开启/关闭
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  p_data                   [回调函数传入数据]
 */
static void outlet_bp_set_switch_onoff(bypass_msg_ctx_t *p_msg_ctx, void *p_data)
{
    bypass_switch_data_t *p_sw = NULL;
    outlet_ev_t ev = {
        id: OUTLET_EV_UNKNOWN,
        act_src: OUTLET_ACT_SRC_APP
    };

    if(NULL == p_data)
    {
        vesync_bypass_reply_pkg_err_msg(BP_ERR_PARA_ILLEGAL, p_msg_ctx->p_trace_msg, BP_ERR_PARAM_CONV(p_data, BP_ERR_PARAM_NULL_PTR));
        return;
    }

    p_sw = (bypass_switch_data_t*)p_data;

    // 先响应，再执行动作
    if (p_sw->id > 1)   // 开关只有1路
    {
        vesync_bypass_reply_pkg_err_msg(BP_ERR_PARA_ILLEGAL, p_msg_ctx->p_trace_msg, "id is invaild");
    }
    else
    {
        if (outlet_get_protect_status())
        {
            vesync_bypass_reply_noqos(BP_ERR_CMD_EXECUTE_FAIL, p_msg_ctx->p_trace_msg, NULL);
            return;
        }
        vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, NULL);
    }

    if (p_sw->enable)
    {
        ev.id = OUTLET_EV_ON;
    }
    else
    {
        ev.id = OUTLET_EV_OFF;
    }

    snprintf(ev.rsn, sizeof(ev.rsn), "%s", p_msg_ctx->p_trace_msg->src_type);

    outlet_app_task_notify(&ev);
}

/**
 * @brief 获取开关开启/关闭状态
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  p_data                   [回调函数传入数据]
 */
static void outlet_bp_get_switch_onoff(bypass_msg_ctx_t *p_msg_ctx, void *p_data)
{
    cJSON *json_data = NULL;

    json_data = cJSON_CreateObject();
    if (NULL == json_data)
    {
        vesync_bypass_reply_pkg_err_msg(BP_ERR_OUT_OF_MEMORY, p_msg_ctx->p_trace_msg, "Create cjson object fail!");
        return;
    }

    cJSON_AddNumberToObject(json_data, "id", 0);
    cJSON_AddBoolToObject(json_data, "enabled", outlet_get_switch_onoff());

    vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, json_data);
}

/**
 * @brief 反转开关的开启/关闭状态
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  p_data                   [回调函数传入数据]
 */
static void outlet_bp_toggle_switch_onoff(bypass_msg_ctx_t *p_msg_ctx, void *p_data)
{
    bypass_toggle_switch_data_t *p_sw = NULL;
    outlet_ev_t ev;

    if(NULL == p_data)
    {
        vesync_bypass_reply_pkg_err_msg(BP_ERR_PARA_ILLEGAL, p_msg_ctx->p_trace_msg, BP_ERR_PARAM_CONV(p_data, BP_ERR_PARAM_NULL_PTR));
        return;
    }

    p_sw = (bypass_toggle_switch_data_t*)p_data;

    // 先响应，再执行动作
    if (p_sw->id > 1)   // 开关只有1路
    {
        vesync_bypass_reply_pkg_err_msg(BP_ERR_PARA_ILLEGAL, p_msg_ctx->p_trace_msg, "id is invaild");
    }
    else
    {
        vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, NULL);
    }

    ev.id = OUTLET_EV_TOGGLE;
    ev.act_src = OUTLET_ACT_SRC_APP;
    snprintf(ev.rsn, sizeof(ev.rsn), "%s", p_msg_ctx->p_trace_msg->src_type);
    outlet_app_task_notify(&ev);
}

#if defined(OUTLET_ELEC_METERING) && (OUTLET_ELEC_METERING == 1)
/**
 * @brief 获取设备状态
 * @note  新增bypass method "getOutletStatus"
 * @param[in]        p_msg_ctx       [bypass上下文]
 * @param[in]        json            [传入json]
 * @return           BYPASS_ERR_E
 */
static BYPASS_ERR_E outlet_bypass_method_get_status_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    BYPASS_ERR_E ret = BP_OK;
    cJSON *json_data = NULL;
    metering_data_t metering_data;
    float electricity;
    bool switch_onoff;

    UNUSED(json);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    json_data = cJSON_CreateObject();
    if (NULL == json_data)
    {
        return BP_ERR_NOMEM;
    }

    if (APP_OK != outlet_metering_get_metering_data(&metering_data) ||
        APP_OK != outlet_metering_get_electricity(OUTLET_SWITCH_USED_ELEC_UNIT, &electricity))
    {
        vesync_bypass_reply_pkg_err_msg(BP_ERR_CMD_EXECUTE_FAIL, p_msg_ctx->p_trace_msg, NULL);
        goto EXIT;
    }
    switch_onoff = outlet_get_switch_onoff();
    cJSON_AddBoolToObject(json_data, "enabled", switch_onoff);
    cJSON_AddNumberToObject(json_data, "voltage", FLOAT_TO_DOT_02_FLOAT(metering_data.voltage));
    // 继电器关闭后，清空电量，但是扫描到的频率还没有立即归零，所有还会累计少量用电量，此处继电器为关则返回0
    cJSON_AddNumberToObject(json_data, "energy", switch_onoff ? FLOAT_TO_DOT_04_FLOAT(electricity / 1000) : 0); // 单位千瓦时
    cJSON_AddNumberToObject(json_data, "power", FLOAT_TO_DOT_02_FLOAT(metering_data.power));
    cJSON_AddNumberToObject(json_data, "current", FLOAT_TO_DOT_02_FLOAT(metering_data.current));

    vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, json_data);
    return ret;

EXIT:
    cJSON_Delete(json_data);
    return ret;
}

/**
 * @brief 设置功率监测
 * @note  新增bypass method "setPowerMonitor"
 * @param[in]        save_elec       [省电模式配置]
 * @param[in]        pow_trig        [功率触发模式配置]
 * @return           int             [成功/失败]
 */
static int outlet_bp_set_power_monitor(switch_save_elec_mode_t *save_elec, switch_pow_trig_mode_t *pow_trig)
{
    metering_mgmt_conf_t conf;
    double temp_elec = 0;
    float temp_max_power = OUTLET_METERING_MAX_POW;

    memset(&conf, 0, sizeof(conf));
    if (save_elec->enable)
    {
        temp_elec = save_elec->max_elec * 1000;  // 单位从KWH转换为WH
    }
    conf.max_electrictiy[OUTLET_SWITCH_USED_ELEC_UNIT] = &temp_elec;

    if (pow_trig->enable)
    {
        if (0 == pow_trig->type)
        {
            conf.min_power = &temp_max_power;       // 使用最大功率为下限，确保回调函数一直调用，则不会触发关机
            conf.max_power = &pow_trig->power;
        }
        else
        {
            conf.min_power = &pow_trig->power;
            conf.max_power = &temp_max_power;       // 使用最大功率为上限，确保回调函数不被调用，则不会触发关机
        }
    }
    else
    {
        conf.min_power = &temp_max_power;
        conf.max_power = &temp_max_power;
    }
    if (APP_OK == outlet_metering_set_mgmt(&conf) && APP_OK == switch_update_config(SWITCH_CFG_SAVE_ELEC_MODE, (void*)save_elec) &&
        APP_OK == switch_update_config(SWITCH_CFG_POW_TRIG_MODE, (void*)pow_trig))
    {
        return APP_OK;
    }

    return APP_FAIL;
}

/**
 * @brief 设置功率监测
 * @note  新增bypass method "setPowerMonitor"
 * @param[in]        p_msg_ctx       [bypass上下文]
 * @param[in]        json            [传入json]
 * @return           BYPASS_ERR_E
 */
static BYPASS_ERR_E outlet_bypass_method_set_power_monitor_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    BYPASS_ERR_E ret = BP_OK;
    cJSON *json_data = NULL;
    cJSON *json_sub = NULL;
    switch_save_elec_mode_t save_elec;
    switch_pow_trig_mode_t pow_trig;

    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    json_data = cJSON_GetObjectItemCaseSensitive(json, "saveEnergyMode");
    if (cJSON_IsObject(json_data))
    {
        json_sub = cJSON_GetObjectItemCaseSensitive(json_data, "enabled");
        if (cJSON_IsBool(json_sub))
        {
            save_elec.enable = (uint8_t)json_sub->valueint;
        }
        else
        {
            ret = BP_ERR_ARG;
            goto EXIT;
        }

        json_sub = cJSON_GetObjectItemCaseSensitive(json_data, "maxEnergy");
        if (cJSON_IsNumber(json_sub))
        {
            save_elec.max_elec = json_sub->valuedouble;
        }
        else
        {
            ret = BP_ERR_ARG;
            goto EXIT;
        }
    }
    else
    {
        ret = BP_ERR_ARG;
        goto EXIT;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "powerTriggerMode");
    if (cJSON_IsObject(json_data))
    {
        json_sub = cJSON_GetObjectItemCaseSensitive(json_data, "enabled");
        if (cJSON_IsBool(json_sub))
        {
            pow_trig.enable = (uint8_t)json_sub->valueint;
        }
        else
        {
            ret = BP_ERR_ARG;
            goto EXIT;
        }

        json_sub = cJSON_GetObjectItemCaseSensitive(json_data, "type");
        if (cJSON_IsNumber(json_sub))
        {
            pow_trig.type = (uint8_t)json_sub->valueint;
        }
        else
        {
            ret = BP_ERR_ARG;
            goto EXIT;
        }

        json_sub = cJSON_GetObjectItemCaseSensitive(json_data, "power");
        if (cJSON_IsNumber(json_sub))
        {
            pow_trig.power = json_sub->valuedouble;
        }
        else
        {
            ret = BP_ERR_ARG;
            goto EXIT;
        }
    }
    else
    {
        ret = BP_ERR_ARG;
        goto EXIT;
    }

    if (APP_OK != outlet_bp_set_power_monitor(&save_elec, &pow_trig))
    {
        vesync_bypass_reply_noqos(BP_ERR_CMD_EXECUTE_FAIL, p_msg_ctx->p_trace_msg, NULL);
        goto EXIT;
    }

    vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, NULL);
    return ret;

EXIT:
    return ret;
}

/**
 * @brief 获取功率监测
 * @note  新增bypass method "getPowerMonitor"
 * @param[in]        p_msg_ctx       [bypass上下文]
 * @param[in]        json            [传入json]
 * @return           BYPASS_ERR_E
 */
static BYPASS_ERR_E outlet_bypass_method_get_power_monitor_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    BYPASS_ERR_E ret = BP_OK;
    cJSON *json_data = NULL;
    cJSON *json_sub = NULL;
    const switch_save_elec_mode_t *p_save_elec = NULL;
    const switch_pow_trig_mode_t *p_pow_trig = NULL;

    UNUSED(json);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    p_save_elec = (const switch_save_elec_mode_t *)switch_get_config(SWITCH_CFG_SAVE_ELEC_MODE);
    p_pow_trig = (const switch_pow_trig_mode_t *)switch_get_config(SWITCH_CFG_POW_TRIG_MODE);

    json_data = cJSON_CreateObject();
    if (NULL == json_data)
    {
        return BP_ERR_NOMEM;
    }
    json_sub = cJSON_AddObjectToObject(json_data, "saveEnergyMode");
    if (NULL == json_sub)
    {
        ret = BP_ERR_NOMEM;
        goto EXIT;
    }
    cJSON_AddBoolToObject(json_sub, "enabled", p_save_elec->enable);
    cJSON_AddNumberToObject(json_sub, "maxEnergy", p_save_elec->max_elec);

    json_sub = NULL;
    json_sub = cJSON_AddObjectToObject(json_data, "powerTriggerMode");
    if (NULL == json_sub)
    {
        ret = BP_ERR_NOMEM;
        goto EXIT;
    }
    cJSON_AddBoolToObject(json_sub, "enabled", p_pow_trig->enable);
    cJSON_AddNumberToObject(json_sub, "type", p_pow_trig->type);
    cJSON_AddNumberToObject(json_sub, "power", p_pow_trig->power);

    vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, json_data);
    return ret;

EXIT:
    cJSON_Delete(json_data);
    return ret;
}

/**
 * @brief 获取电量历史数据
 * @note  新增bypass method "getEnergyHistory"
 * @param[in]        p_msg_ctx       [bypass上下文]
 * @param[in]        json            [传入json]
 * @return           BYPASS_ERR_E
 */
static BYPASS_ERR_E outlet_bypass_method_get_elec_history_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    BYPASS_ERR_E ret = BP_OK;
    cJSON *json_data = NULL;
    cJSON *json_result = NULL;
    cJSON *json_arry = NULL;
    cJSON *json_sub = NULL;
    uint32_t start_ts = 0;
    uint32_t end_ts = 0;
    uint16_t index = 0;
    uint16_t total_item = 0;

    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    json_data = cJSON_GetObjectItemCaseSensitive(json, "fromDay");
    if (cJSON_IsNumber(json_data))
    {
        start_ts = json_data->valueint;
    }
    else
    {
        return BP_ERR_ARG;
    }
    json_data = cJSON_GetObjectItemCaseSensitive(json, "toDay");
    if (cJSON_IsNumber(json_data))
    {
        end_ts = json_data->valueint;
    }
    else
    {
        return BP_ERR_ARG;
    }

    // 取出所有历史数据
    elec_per_day_t *p_arry = (elec_per_day_t *)vesync_malloc((ELEC_HIST_STO_MAX + 1) * sizeof(elec_per_day_t));
    if (NULL == p_arry)
    {
        return BP_ERR_NOMEM;
    }
    if (APP_OK != outlet_get_history_elec(p_arry, ELEC_HIST_STO_MAX + 1))
    {
        vesync_bypass_reply_pkg_err_msg(BP_ERR_CMD_EXECUTE_FAIL, p_msg_ctx->p_trace_msg, NULL);
        vesync_free(p_arry);
        return ret;
    }

    json_result = cJSON_CreateObject();
    if (NULL == json_result)
    {
        ret = BP_ERR_NOMEM;
        goto EXIT;
    }
    json_arry = cJSON_AddArrayToObject(json_result, "energyInfos");
    if (NULL == json_arry)
    {
        ret = BP_ERR_NOMEM;
        goto EXIT;
    }

#if 1
#if defined(PR_FW_TYPE) && (PR_FW_TYPE == 0)
    uint32_t secs_per_day = outlet_get_debug_secs_per_day();
#else
    uint32_t secs_per_day = SECONDS_PER_DAY;
#endif
    end_ts -= end_ts % secs_per_day;
    while (start_ts <= end_ts && total_item < ELEC_HIST_STO_MAX)
    {
        json_sub = NULL;
        cJSON_AddItemToArray(json_arry, json_sub = cJSON_CreateObject());
        if (NULL == json_sub)
        {
            APP_LOG(LOG_ERROR, "create item fail\n");
            break;
        }
        ++total_item;
        cJSON_AddNumberToObject(json_sub, "timestamp", end_ts);
        if (end_ts > p_arry[index].record_ts)
        {
            cJSON_AddNumberToObject(json_sub, "energy", 0);
        }
        else if (end_ts == p_arry[index].record_ts)
        {
            cJSON_AddNumberToObject(json_sub, "energy", FLOAT_TO_DOT_04_FLOAT(p_arry[index].elec_per_day / 1000));  // 单位千瓦时
            if (index < ELEC_HIST_STO_MAX)
            {
                ++index;
            }
        }
        else
        {
            while (index < ELEC_HIST_STO_MAX && end_ts < p_arry[index].record_ts)
            {
                ++index;
            }
            if (end_ts == p_arry[index].record_ts)
            {
                cJSON_AddNumberToObject(json_sub, "energy", FLOAT_TO_DOT_04_FLOAT(p_arry[index].elec_per_day / 1000));  // 单位千瓦时
            }
            else
            {
                cJSON_AddNumberToObject(json_sub, "energy", 0);
            }
        }
        end_ts -= secs_per_day;
    }
#else
    for (index = 0; index < ELEC_HIST_STO_MAX + 1; ++index)
    {
        if (p_arry[index].record_ts > end_ts)
        {
            continue;
        }
        if (p_arry[index].record_ts < start_ts)
        {
            break;
        }
        json_sub = NULL;
        cJSON_AddItemToArray(json_arry, json_sub = cJSON_CreateObject());
        if (NULL != json_sub)
        {
            ++total_item;
            cJSON_AddNumberToObject(json_sub, "timestamp", p_arry[index].record_ts);
            cJSON_AddNumberToObject(json_sub, "energy", FLOAT_TO_DOT_04_FLOAT(p_arry[index].elec_per_day / 1000)); // 单位千瓦时
        }
    }
#endif
    cJSON_AddNumberToObject(json_result, "total", total_item);

    vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, json_result);
    vesync_free(p_arry);
    return ret;

EXIT:
    vesync_free(p_arry);
    cJSON_Delete(json_result);
    return ret;
}

/**
 * @brief 设置功率监测
 * @note  新增bypass method "setRatedPUI"
 * @param[in]        p_msg_ctx       [bypass上下文]
 * @param[in]        json            [传入json]
 * @return           BYPASS_ERR_E
 */
static BYPASS_ERR_E outlet_bypass_method_set_rated_PUI_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    BYPASS_ERR_E ret = BP_OK;
    cJSON *json_data = NULL;
    metering_rated_t rated_data;

    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    if (PRODUCTION_RUNNING != vesync_production_get_status())
    {
        APP_LOG(LOG_WARN, "proudction not running!!\n");
        return BP_ERR_UN_AUTH;
    }

    memset(&rated_data, 0, sizeof(rated_data));

    json_data = cJSON_GetObjectItemCaseSensitive(json, "power");
    if (cJSON_IsNumber(json_data))
    {
        rated_data.Power0 = json_data->valuedouble;
    }
    else
    {
        ret = BP_ERR_ARG;
        goto EXIT;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "voltage");
    if (cJSON_IsNumber(json_data))
    {
        rated_data.Voltage0 = json_data->valuedouble;
    }
    else
    {
        ret = BP_ERR_ARG;
        goto EXIT;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "current");
    if (cJSON_IsNumber(json_data))
    {
        rated_data.Current0 = json_data->valuedouble;
    }
    else
    {
        ret = BP_ERR_ARG;
        goto EXIT;
    }

    if (APP_OK != outlet_metering_set_rated_data(&rated_data))
    {
        vesync_bypass_reply_noqos(BP_ERR_CMD_EXECUTE_FAIL, p_msg_ctx->p_trace_msg, NULL);
        goto EXIT;
    }

    vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, NULL);
    return ret;

EXIT:
    return ret;
}

#if defined(PR_FW_TYPE) && (PR_FW_TYPE == 0)
/**
* @brief 设置电量存储模块，一天的小时数和一小时的秒数
* @note  调试接口 bypass method "setElecSavePeriod"
* @param[in]        p_msg_ctx       [bypass上下文]
* @param[in]        json            [传入json]
* @return           BYPASS_ERR_E
*/
static BYPASS_ERR_E outlet_bypass_method_set_debug_secs_hrs_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    BYPASS_ERR_E ret = BP_OK;
    cJSON *json_data = NULL;
    uint16_t secs_per_hour = 0;
    uint8_t hrs_per_day = 0;

    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    json_data = cJSON_GetObjectItemCaseSensitive(json, "secs_per_h");
    if (cJSON_IsNumber(json_data))
    {
        secs_per_hour = json_data->valueint;
    }
    else
    {
        ret = BP_ERR_ARG;
        goto EXIT;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "hrs_per_d");
    if (cJSON_IsNumber(json_data))
    {
        hrs_per_day = json_data->valueint;
    }
    else
    {
        ret = BP_ERR_ARG;
        goto EXIT;
    }

    if (APP_OK != outlet_set_debug_secs_hrs(secs_per_hour, hrs_per_day))
    {
        vesync_bypass_reply_noqos(BP_ERR_CMD_EXECUTE_FAIL, p_msg_ctx->p_trace_msg, NULL);
        goto EXIT;
    }

    vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, NULL);
    return ret;

EXIT:
    return ret;
}
#endif
#endif

static bypass_user_data_t outlet_method_tbl[] = {
#if defined(OUTLET_ELEC_METERING) && (OUTLET_ELEC_METERING == 1)
    {"getOutletStatus", outlet_bypass_method_get_status_handle},
    {"setPowerMonitor", outlet_bypass_method_set_power_monitor_handle},
    {"getPowerMonitor", outlet_bypass_method_get_power_monitor_handle},
    {"getEnergyHistory", outlet_bypass_method_get_elec_history_handle},
    {"setRatedPUI", outlet_bypass_method_set_rated_PUI_handle},
#if defined(PR_FW_TYPE) && (PR_FW_TYPE == 0)
    {"setElecSavePeriod", outlet_bypass_method_set_debug_secs_hrs_handle},
#endif
#endif
    {"unknowMethod", NULL}
};


/**
 * @brief 注册bypass回调函数
 */
void outlet_bypass_reg_cb(void)
{
    // Switch
    vesync_bypass_reg_method_cb(BYPASS_METHOD_ID_SET_SWITCH, outlet_bp_set_switch_onoff);
    vesync_bypass_reg_method_cb(BYPASS_METHOD_ID_GET_SWITCH, outlet_bp_get_switch_onoff);
    vesync_bypass_reg_method_cb(BYPASS_METHOD_ID_TOGGLE_SWITCH, outlet_bp_toggle_switch_onoff);

    // timing
    vesync_bypass_reg_method_cb(BYPASS_METHOD_ID_ADD_TIMER, outlet_bp_add_timer);
    vesync_bypass_reg_method_cb(BYPASS_METHOD_ID_DEL_TIMER, outlet_bp_del_timer);
    vesync_bypass_reg_method_cb(BYPASS_METHOD_ID_GET_TIMER, outlet_bp_get_timer);
    // timingV2
    vesync_bypass_reg_method_cb(BYPASS_METHOD_ID_ADD_TIMER_V2, outlet_bp_add_timerV2);
    vesync_bypass_reg_method_cb(BYPASS_METHOD_ID_DEL_TIMER_V2, outlet_bp_del_timerV2);
    vesync_bypass_reg_method_cb(BYPASS_METHOD_ID_GET_TIMER_V2, outlet_bp_get_timerV2);

    // inching
    vesync_bypass_reg_method_cb(BYPASS_METHOD_ID_ADD_INCHING, outlet_bp_add_inching);
    vesync_bypass_reg_method_cb(BYPASS_METHOD_ID_DEL_INCHING, outlet_bp_del_inching);
    vesync_bypass_reg_method_cb(BYPASS_METHOD_ID_GET_INCHING, outlet_bp_get_inching);

    // 产测
    vesync_bypass_reg_method_cb(BYPASS_METHOD_ID_TEST_RELAY, outlet_bp_test_relay);

    // Schedule
    vesync_bypass_reg_method_cb(BYPASS_METHOD_ID_ADD_SCHEDULE_V3, outlet_bp_add_schedule);
    vesync_bypass_reg_method_cb(BYPASS_METHOD_ID_UPD_SCHEDULE_V3, outlet_bp_upd_schedule);
    vesync_bypass_reg_method_cb(BYPASS_METHOD_ID_DEL_SCHEDULE_V3, outlet_bp_del_schedule);
    vesync_bypass_reg_method_cb(BYPASS_METHOD_ID_GET_SCHEDULES_V3, outlet_bp_get_schedules);

    // Away
    vesync_bypass_reg_method_cb(BYPASS_METHOD_ID_ADD_AWAY_V2, outlet_bp_add_away);
    vesync_bypass_reg_method_cb(BYPASS_METHOD_ID_DEL_AWAY_V2, outlet_bp_del_away);
    vesync_bypass_reg_method_cb(BYPASS_METHOD_ID_GET_AWAY_V2, outlet_bp_get_away);

    for (int i = 0; i < SIZEOF_ARRAY(outlet_method_tbl); i++)
    {
        vesync_bypass_add_user_item(&outlet_method_tbl[i]);
    }
}


