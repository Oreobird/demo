/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        bulb_bypass.c
 * @brief       bulb bypass
 * @author      Dave
 * @date        2021-08-31
 */

#include <string.h>
#include <stdio.h>
#include <string.h>

#include "vesync_common.h"
#include "vesync_log.h"
#include "vesync_timing.h"
#include "vesync_memory.h"
#include "vesync_task.h"

#include "bulb.h"
#include "bulb_flash.h"
#include "bulb_status.h"
#include "bulb_timing.h"
#include "bulb_schedule.h"
#include "bulb_status.h"
#include "bulb_bypass.h"
#include "bulb_report.h"
#include "bulb_scene.h"
#include "bulb_pwr_mem.h"

#define BULB_SUBDEVICE_TYPE_STR "bulb"
#define BULB_SUBDEVICE_NO (0)
#define BRIGHT_MAX (100)
#define COLOR_TEMP_MAX (100)
#define HSV_PARAM_MAX (10000)
#define PARAM_MIN (0)

// 以下定义见透传接口设计
// https://wiki.vesync.cn/pages/viewpage.action?pageId=259358915#id-%E5%BC%80%E6%94%BE%E5%B9%B3%E5%8F%B0-%E7%81%AF%E6%B3%A1&%E7%81%AF%E5%B8%A6-A19&8B1005-%E9%80%8F%E4%BC%A0%E8%8D%89%E7%A8%BF-3.5.4%E8%AE%BE%E7%BD%AE%E7%81%AF%E6%B3%A1%E7%8A%B6%E6%80%81V2

// 第三方语音设置亮度为0，标志位（认证需求）
static bool s_voice_off_flag = false;

/**
 * @brief 将color_mode的字符串值解析成相应的枚举值
 * @param[in]       str             [color_mode的字符串值]
 * @return          int             [输出的枚举值]
 */
static int bulb_bp_parse_color_mode_str(const char *str)
{
    if (0 == strcmp(str, "white"))
    {
        return BULB_CFG_COLOR_MODE_WHITE;
    }
    else if (0 == strcmp(str, "hsv"))
    {
        return BULB_CFG_COLOR_MODE_HSV;
    }
    else if (0 == strcmp(str, "phoneMusic"))
    {
        return BULB_CFG_COLOR_MODE_PHONE_MUSIC;
    }
    else if (0 == strcmp(str, "phoneMic"))
    {
        return BULB_CFG_COLOR_MODE_PHONE_MIC;
    }
    else if (0 == strcmp(str, "scenario"))
    {
        return BULB_CFG_COLOR_MODE_SCENARIO;
    }

    return BULB_CFG_COLOR_MODE_INVALID;
}

const char *bulb_bp_get_color_mode_str(int color_mode)
{
    switch (color_mode)
    {
    case BULB_CFG_COLOR_MODE_WHITE:
        return "white";
    case BULB_CFG_COLOR_MODE_HSV:
        return "hsv";
    case BULB_CFG_COLOR_MODE_PHONE_MUSIC:
        return "phoneMusic";
    case BULB_CFG_COLOR_MODE_PHONE_MIC:
        return "phoneMic";
    case BULB_CFG_COLOR_MODE_SCENARIO:
        return "scenario";
    default:
        return "invalid";
    }
}

/**
 * @brief 打包将上报的bulb状态
 */
static cJSON *bulb_bp_pack_status(void)
{
    cJSON *json = cJSON_CreateObject();
    if (NULL == json)
    {
        APP_LOG(LOG_ERROR, "create_object fail\n");
        return NULL;
    }

    bulb_status_t bulb_status;
    bulb_status_fetch(&bulb_status);

    cJSON_AddStringToObject(json, "enabled", bulb_status.enable ? "on" : "off");
    cJSON_AddStringToObject(json, "colorMode", bulb_bp_get_color_mode_str(bulb_status.mode));
    cJSON_AddNumberToObject(json, "brightness", bulb_status.white.brightness);
    cJSON_AddNumberToObject(json, "colorTemp", bulb_status.white.color_temp);
    cJSON_AddNumberToObject(json, "hue", bulb_status.hsv.hue);
    cJSON_AddNumberToObject(json, "saturation", bulb_status.hsv.saturation);
    cJSON_AddNumberToObject(json, "value", bulb_status.hsv.value);
    cJSON_AddNumberToObject(json, "sceneId", bulb_status.scene_id);
    cJSON *sensitive = cJSON_CreateObject();
    if (sensitive != NULL)
    {
        cJSON_AddItemToObject(json, "sensitive", sensitive);
        cJSON_AddNumberToObject(sensitive, "type", bulb_status.sensitive.type);
        cJSON_AddNumberToObject(sensitive, "sensitive", bulb_status.sensitive.value);
    }
    else
    {
        APP_LOG(LOG_ERROR, "create_object fail\n");
    }
    cJSON_AddNumberToObject(json, "effect", bulb_status.effect);
    return json;
}

/**
 * @brief 打包bulb动作组
 * @param[in,out]   json_arr        [参数组]
 * @param[in]       action          [动作]
 * @return          int             [通用错误码]
 */
static int bulb_bp_pack_action(cJSON **json_arr, bulb_action_t *action)
{
    int err_code = BP_ERR_NO_ERR;

    cJSON *json_act = NULL;
    cJSON *json_acts = cJSON_CreateArray();
    if (NULL == json_acts)
    {
        return BP_ERR_OUT_OF_MEMORY;
    }

    json_act = cJSON_CreateObject();
    if (NULL == json_act)
    {
        err_code = BP_ERR_OUT_OF_MEMORY;
        goto exit;
    }
    cJSON_AddItemToArray(json_acts, json_act);

    cJSON_AddStringToObject(json_act, "type", "switch");
    if (true == action->onoff)
    {
        cJSON_AddStringToObject(json_act, "act", "on");
    }
    else
    {
        cJSON_AddStringToObject(json_act, "act", "off");
    }
    cJSON_AddNumberToObject(json_act, "num", 0);

    if (0 != action->onoff)
    {
        json_act = cJSON_CreateObject();
        if (NULL == json_act)
        {
            err_code = BP_ERR_OUT_OF_MEMORY;
            goto exit;
        }
        cJSON_AddItemToArray(json_acts, json_act);

        cJSON_AddStringToObject(json_act, "type", "color_mode");
        cJSON_AddNumberToObject(json_act, "num", 0);
        cJSON *json_params = cJSON_CreateObject();
        if (NULL == json_params)
        {
            err_code = BP_ERR_OUT_OF_MEMORY;
            goto exit;
        }
        cJSON_AddItemToObject(json_act, "params", json_params);

        if (BULB_CFG_COLOR_MODE_HSV == action->mode)
        {
            cJSON_AddStringToObject(json_act, "act", "hsv");
            cJSON_AddNumberToObject(json_params, "hue", action->hue);
            cJSON_AddNumberToObject(json_params, "saturation", action->saturation);
            cJSON_AddNumberToObject(json_params, "value", action->value);
        }
        else if (BULB_CFG_COLOR_MODE_WHITE == action->mode)
        {
            cJSON_AddStringToObject(json_act, "act", "white");
            cJSON_AddNumberToObject(json_params, "brightness", action->bright);
            cJSON_AddNumberToObject(json_params, "colorTemp", action->temp);
        }
        else if (BULB_CFG_COLOR_MODE_SCENARIO == action->mode)
        {
            cJSON_AddStringToObject(json_act, "act", "scenario");
            cJSON_AddNumberToObject(json_params, "sceneId", action->scene_id);
        }
        else
        {
            APP_LOG(LOG_ERROR, "color mode error\n");
        }
    }
exit:
    if (BP_ERR_NO_ERR == err_code)
    {
        *json_arr = json_acts;
    }
    else
    {
        cJSON_Delete(json_acts);
    }
    return err_code;
}

/**
 * @brief 获取设备状态
 * @param[in]        p_msg_ctx       [bypass上下文]
 * @param[in]        json            [传入json]
 * @return           BYPASS_ERR_E
 */
static BYPASS_ERR_E bulb_bypass_method_get_status_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    cJSON *json_reply = bulb_bp_pack_status();
    if (NULL == json_reply)
    {
        p_msg_ctx->resp_error_code = BP_ERR_OUT_OF_MEMORY;
        goto EXIT;
    }
    p_msg_ctx->p_response = json_reply;
EXIT:
    return BP_OK;
}

/**
 * @brief setLightStatusV2接口解析
 * @param[in]        p_msg_ctx       [bypass上下文]
 * @param[in]        json            [传入json]
 * @return           BYPASS_ERR_E
 */
static BYPASS_ERR_E bulb_bypass_method_set_status_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    bypass_set_light_status_base_t bp_status;
    memset(&bp_status, 0, sizeof(bp_status));
    bulb_status_fft_info_t *p_bp_fft_info = NULL;
    bulb_status_rms_info_t *p_bp_rms_info = NULL;

    cJSON *json_data = NULL;

    json_data = cJSON_GetObjectItemCaseSensitive(json, "force");
    if (cJSON_IsNumber(json_data))
    {
        bp_status.force = &json_data->valueint;
    }
    else
    {
        bp_status.force = 0;
    }
    json_data = cJSON_GetObjectItemCaseSensitive(json, "colorMode");
    if (cJSON_IsString(json_data))
    {
        bp_status.color_mode = json_data->valuestring;
    }
    json_data = cJSON_GetObjectItemCaseSensitive(json, "colorTemp");
    if (cJSON_IsNumber(json_data))
    {
        if ((PARAM_MIN > json_data->valueint) || (COLOR_TEMP_MAX < json_data->valueint))
        {
            p_msg_ctx->resp_error_code = BP_ERR_PARA_ILLEGAL;
            goto EXIT;
        }
        bp_status.color_temp = &json_data->valueint;
    }
    json_data = cJSON_GetObjectItemCaseSensitive(json, "brightness");
    if (cJSON_IsNumber(json_data))
    {
        if ((PARAM_MIN > json_data->valueint) || (BRIGHT_MAX < json_data->valueint))
        {
            p_msg_ctx->resp_error_code = BP_ERR_PARA_ILLEGAL;
            goto EXIT;
        }
        bp_status.brightness = &json_data->valueint;
    }
    json_data = cJSON_GetObjectItemCaseSensitive(json, "hue");
    if (cJSON_IsNumber(json_data))
    {
        if ((PARAM_MIN > json_data->valueint) || (HSV_PARAM_MAX < json_data->valueint))
        {
            p_msg_ctx->resp_error_code = BP_ERR_PARA_ILLEGAL;
            goto EXIT;
        }
        bp_status.hue = &json_data->valueint;
    }
    json_data = cJSON_GetObjectItemCaseSensitive(json, "saturation");
    if (cJSON_IsNumber(json_data))
    {
        if ((PARAM_MIN > json_data->valueint) || (HSV_PARAM_MAX < json_data->valueint))
        {
            p_msg_ctx->resp_error_code = BP_ERR_PARA_ILLEGAL;
            goto EXIT;
        }
        bp_status.saturation = &json_data->valueint;
    }
    json_data = cJSON_GetObjectItemCaseSensitive(json, "sceneId");
    if (cJSON_IsNumber(json_data))
    {
        bp_status.scene_id = &json_data->valueint;
    }
    json_data = cJSON_GetObjectItemCaseSensitive(json, "rms");
    if (cJSON_IsNumber(json_data))
    {
        p_bp_rms_info = vesync_calloc(1, sizeof(bulb_status_rms_info_t));
        if (NULL == p_bp_rms_info)
        {
            p_msg_ctx->resp_error_code = BP_ERR_OUT_OF_MEMORY;
            goto EXIT;
        }
        p_bp_rms_info->rms = json_data->valueint;
    }
    json_data = cJSON_GetObjectItemCaseSensitive(json, "frqAmpArray");
    if (cJSON_IsArray(json_data))
    {
        p_bp_fft_info = vesync_calloc(1, sizeof(bulb_status_fft_info_t));
        if (NULL == p_bp_fft_info)
        {
            p_msg_ctx->resp_error_code = BP_ERR_OUT_OF_MEMORY;
            goto EXIT;
        }
        cJSON *freq_and_amp;
        int freq_seg = 0;
        cJSON_ArrayForEach(freq_and_amp, json_data)
        {
            if (freq_seg < BULB_MUSIC_FREQ_SEG_NBR)
            {
                cJSON *freq = cJSON_GetObjectItemCaseSensitive(freq_and_amp, "f");
                if (cJSON_IsNumber(freq))
                {
                    p_bp_fft_info->freq[freq_seg] = (uint16_t)freq->valueint;
                }
                cJSON *amp = cJSON_GetObjectItemCaseSensitive(freq_and_amp, "a");
                if (cJSON_IsNumber(freq))
                {
                    p_bp_fft_info->amp[freq_seg] = (uint32_t)amp->valueint;
                }
            }
            freq_seg++;
        }
    }
    json_data = cJSON_GetObjectItemCaseSensitive(json, "sensitive");
    if (cJSON_IsObject(json_data))
    {
        cJSON *st_json = cJSON_GetObjectItemCaseSensitive(json_data, "type");
        if (cJSON_IsNumber(st_json))
        {
            if ((st_json->valueint < 1) || (st_json->valueint > 255))
            {
                p_msg_ctx->resp_error_code = BP_ERR_PARA_ILLEGAL;
                goto EXIT;
            }
            bp_status.sensitive_type = &st_json->valueint;
        }
        cJSON *sv_json = cJSON_GetObjectItemCaseSensitive(json_data, "sensitive");
        if (cJSON_IsNumber(sv_json))
        {
            if ((sv_json->valueint < 1) || (sv_json->valueint > 100))
            {
                p_msg_ctx->resp_error_code = BP_ERR_PARA_ILLEGAL;
                goto EXIT;
            }
            bp_status.sensitive_value = &sv_json->valueint;
        }
    }
    json_data = cJSON_GetObjectItemCaseSensitive(json, "effect");
    if (cJSON_IsNumber(json_data))
    {
        if ((json_data->valueint < BULB_CFG_EFFECT_MODE_1) || (json_data->valueint > BULB_CFG_EFFECT_MODE_3))
        {
            p_msg_ctx->resp_error_code = BP_ERR_PARA_ILLEGAL;
            goto EXIT;
        }
        bp_status.effect = &json_data->valueint;
    }

    bulb_status_t bulb_status;
    // Read out the current bulb status
    bulb_status_fetch(&bulb_status);

    switch (*bp_status.force)
    {
    case 0:
        // fallthrough
    case 1:
    {
        uint8_t mode_to_be = bulb_status.mode;
        if (bp_status.color_mode != NULL)
        {
            mode_to_be = bulb_bp_parse_color_mode_str(bp_status.color_mode);
        }
        else
        {
            // 根据其他的参数进行模式推断
            if (bp_status.color_temp != NULL)
            {
                mode_to_be = BULB_CFG_COLOR_MODE_WHITE;
            }
            else if ((bp_status.hue != NULL) || (bp_status.saturation != NULL))
            {
                mode_to_be = BULB_CFG_COLOR_MODE_HSV;
            }
            else if (bp_status.scene_id != NULL)
            {
                mode_to_be = BULB_CFG_COLOR_MODE_SCENARIO;
            }
        }

        if ((bulb_status.mode != mode_to_be) && (0 == *bp_status.force))
        {
            p_msg_ctx->resp_error_code = BP_ERR_NOT_EXEC_IN_CUR_MODE;
            goto EXIT;
        }
        bulb_status.mode = mode_to_be;
        bulb_status.enable = true;
        switch (bulb_status.mode)
        {
        case BULB_CFG_COLOR_MODE_WHITE:
            if (bp_status.color_temp != NULL)
            {
                bulb_status.white.color_temp = (uint8_t)*bp_status.color_temp;
            }
            if (bp_status.brightness != NULL)
            {
                if (0 == (uint8_t)*bp_status.brightness)
                {
                    p_msg_ctx->resp_error_code = BP_ERR_PARA_ILLEGAL;
                    goto EXIT;
                }
                bulb_status.white.brightness = (uint8_t)*bp_status.brightness;
            }
            break;
        case BULB_CFG_COLOR_MODE_HSV:
            if (bp_status.hue != NULL)
            {
                bulb_status.hsv.hue = (uint16_t)*bp_status.hue;
            }
            if (bp_status.saturation != NULL)
            {
                bulb_status.hsv.saturation = (uint16_t)*bp_status.saturation;
            }
            if (bp_status.brightness != NULL)
            {
                if (0 == (uint8_t)*bp_status.brightness)
                {
                    p_msg_ctx->resp_error_code = BP_ERR_PARA_ILLEGAL;
                    goto EXIT;
                }
                bulb_status.hsv.value = (uint8_t)*bp_status.brightness;
            }
            break;
        case BULB_CFG_COLOR_MODE_PHONE_MUSIC:
            // fallthrough
        case BULB_CFG_COLOR_MODE_PHONE_MIC:
            if ((p_bp_fft_info != NULL) || (p_bp_rms_info != NULL))
            {
                bulb_status_update_music_param(p_bp_fft_info, p_bp_rms_info);
                goto EXIT;
            }
            if (bp_status.sensitive_type != NULL)
            {
                bulb_status.sensitive.type = (uint8_t)*bp_status.sensitive_type;
            }
            if (bp_status.sensitive_value != NULL)
            {
                bulb_status.sensitive.value = (uint8_t)*bp_status.sensitive_value;
            }
            if (bp_status.effect != NULL)
            {
                bulb_status.effect = (uint8_t)*bp_status.effect;
            }
            break;
        case BULB_CFG_COLOR_MODE_SCENARIO:
            if (bp_status.scene_id != NULL)
            {
                bulb_status.scene_id = (uint16_t)*bp_status.scene_id;
            }
            break;
        default:
            p_msg_ctx->resp_error_code = BP_ERR_PARA_ILLEGAL;
            goto EXIT;
        }
        break;
    }
    case 2:
        if (NULL == bp_status.brightness)
        {
            p_msg_ctx->resp_error_code = BP_ERR_PARA_ILLEGAL;
            goto EXIT;
        }
        if (100 == *bp_status.brightness)
        {
            bulb_status.enable = true;
            if (s_voice_off_flag)
            {
                switch (bulb_status.mode)
                {
                case BULB_CFG_COLOR_MODE_WHITE:
                    bulb_status.white.brightness = (uint8_t)*bp_status.brightness;
                    break;
                case BULB_CFG_COLOR_MODE_HSV:
                    bulb_status.hsv.value = (uint8_t)*bp_status.brightness;
                    break;
                default:
                    break;
                }
            }
            s_voice_off_flag = false;
        }
        else if (0 == *bp_status.brightness)
        {
            bulb_status.enable = false;
            s_voice_off_flag = true;
        }
        else
        {
            p_msg_ctx->resp_error_code = BP_ERR_PARA_ILLEGAL;
            goto EXIT;
        }
        break;
    default:
        p_msg_ctx->resp_error_code = BP_ERR_PARA_ILLEGAL;
        goto EXIT;
    }

    if (bulb_status_update_and_report(&bulb_status, p_msg_ctx->p_trace_msg->src_type) != APP_OK)
    {
        p_msg_ctx->resp_error_code = BP_ERR_CMD_EXECUTE_FAIL;
        p_msg_ctx->p_resp_error_msg = "apply status error";
    }
    else
    {
        p_msg_ctx->p_response = bulb_bp_pack_status();
    }
EXIT:
    vesync_free(p_bp_rms_info);
    vesync_free(p_bp_fft_info);
    return BP_OK;
}

/**
 * @brief 调节灯泡亮度百分比
 * @param[in]        p_msg_ctx       [bypass上下文]
 * @param[in]        json            [传入json]
 * @return           BYPASS_ERR_E
 */
static BYPASS_ERR_E bulb_bypass_method_adjust_percent_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    cJSON *json_data = NULL;
    cJSON *json_reply = NULL;

    bypass_adjust_percent_base_t bp_data;
    memset(&bp_data, 0, sizeof(bp_data));

    json_data = cJSON_GetObjectItemCaseSensitive(json, "type");
    if (cJSON_IsString(json_data))
    {
        bp_data.type = json_data->valuestring;
    }
    else
    {
        p_msg_ctx->resp_error_code = BP_ERR_PARA_ILLEGAL;
        goto EXIT;
    }
    json_data = cJSON_GetObjectItemCaseSensitive(json, "step");
    if (cJSON_IsNumber(json_data))
    {
        bp_data.step = &json_data->valueint;
    }
    else
    {
        p_msg_ctx->resp_error_code = BP_ERR_PARA_ILLEGAL;
        goto EXIT;
    }

    uint8_t actual_percent = 0;
    bulb_status_t bulb_status;

    bulb_status_fetch(&bulb_status);
    if (false == bulb_status.enable)
    {
        // 增加亮度时，若设备关闭以25亮度按上次模式开启
        if ((0 == strcmp("brightness", bp_data.type)) && (*bp_data.step > 0))
        {
            bulb_status.enable = true;
            switch (bulb_status.mode)
            {
            case BULB_CFG_COLOR_MODE_WHITE:
                bulb_status.white.brightness = 25;
                actual_percent = 25;
                break;
            case BULB_CFG_COLOR_MODE_HSV:
                bulb_status.hsv.value = 25;
                actual_percent = 25;
                break;
            default:
                APP_LOG(LOG_INFO, "the last mode isn't color or white\n");
                break;
            }
        }
        else if (0 == strcmp("colorTemp", bp_data.type))
        {
            bulb_status.enable = true;
            bulb_status.mode = BULB_CFG_COLOR_MODE_WHITE;
            // *bp_data.step 是有符号数
            bulb_status.white.color_temp += (int8_t)*bp_data.step;
            if (100 < bulb_status.white.color_temp)
            {
                bulb_status.white.color_temp = 100;
            }
            else if (0 >= bulb_status.white.color_temp)
            {
                bulb_status.white.color_temp = 0;
            }
            actual_percent = bulb_status.white.color_temp;
        }
        else
        {
            actual_percent = 0;
        }
    }
    else
    {
        if (0 == strcmp("brightness", bp_data.type))
        {
            switch (bulb_status.mode)
            {
            case BULB_CFG_COLOR_MODE_WHITE:
                // *bp_data.step 是有符号数
                bulb_status.white.brightness += (int8_t)*bp_data.step;
                if (100 < bulb_status.white.brightness)
                {
                    bulb_status.white.brightness = 100;
                    actual_percent = 100;
                }
                else if (0 >= bulb_status.white.brightness)
                {
                    bulb_status.enable = false;
                    actual_percent = 0;
                }
                break;
            case BULB_CFG_COLOR_MODE_HSV:
                // *bp_data.step 是有符号数
                bulb_status.hsv.value += (int8_t)*bp_data.step;
                if (100 < bulb_status.hsv.value)
                {
                    bulb_status.hsv.value = 100;
                    actual_percent = 100;
                }
                else if (0 >= bulb_status.hsv.value)
                {
                    bulb_status.enable = false;
                    actual_percent = 0;
                }
                break;
            default:
                APP_LOG(LOG_INFO, "current mode isn't color or white\n");
                break;
            }
        }
        else if (0 == strcmp("colorTemp", bp_data.type))
        {
            switch (bulb_status.mode)
            {
            case BULB_CFG_COLOR_MODE_WHITE:
                // *bp_data.step 是有符号数
                bulb_status.white.color_temp += (int8_t)*bp_data.step;
                if (100 < bulb_status.white.color_temp)
                {
                    bulb_status.white.color_temp = 100;
                }
                else if (0 >= bulb_status.white.color_temp)
                {
                    bulb_status.white.color_temp = 0;
                }
                actual_percent = bulb_status.white.color_temp;
                break;
            default:
                p_msg_ctx->resp_error_code = BP_ERR_NOT_EXEC_IN_CUR_MODE;
                goto EXIT;
            }
        }
        else
        {
            p_msg_ctx->resp_error_code = BP_ERR_PARA_ILLEGAL;
            goto EXIT;
        }
    }

    if (bulb_status_update_and_report(&bulb_status, p_msg_ctx->p_trace_msg->src_type) != APP_OK)
    {
        p_msg_ctx->resp_error_code = BP_ERR_UNDEFINE;
        p_msg_ctx->p_resp_error_msg = "adjust percent error";
    }
    json_reply = cJSON_CreateObject();
    if (NULL == json_reply)
    {
        p_msg_ctx->resp_error_code = BP_ERR_OUT_OF_MEMORY;
        goto EXIT;
    }
    cJSON_AddNumberToObject(json_reply, "percent", actual_percent);
    p_msg_ctx->p_response = json_reply;

EXIT:
    return BP_OK;
}

/**
 * @brief 新增timer
 * @param[in]        p_msg_ctx       [bypass上下文]
 * @param[in]        json            [传入json]
 * @return           BYPASS_ERR_E
 */
static BYPASS_ERR_E bulb_bypass_method_add_timer_v2_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    uint32_t total_sec = 0;
    uint16_t timer_id = 1;

    cJSON *json_data = NULL;
    cJSON *json_timer = NULL;

    bulb_action_t action = {0};

    APP_LOG(LOG_DEBUG, "-------addTimerV2 handle--------\n");

    json_data = cJSON_GetObjectItemCaseSensitive(json, "total");
    if (cJSON_IsNumber(json_data))
    {
        total_sec = json_data->valueint;
        // timer设置的最大时长不超过24h
        if (86400 <= total_sec || 1 > total_sec)
        {
            p_msg_ctx->resp_error_code = BP_ERR_PARA_ILLEGAL;
            goto EXIT;
        }
        APP_LOG(LOG_DEBUG, "total_sec %d\n", total_sec);
    }
    else
    {
        p_msg_ctx->resp_error_code = BP_ERR_PARA_ILLEGAL;
        goto EXIT;
    }
    json_data = cJSON_GetObjectItemCaseSensitive(json, "startAct");
    if (cJSON_IsArray(json_data))
    {
        p_msg_ctx->resp_error_code = bulb_bp_parse_action(json_data, &action);
        if (BP_ERR_NO_ERR != p_msg_ctx->resp_error_code)
        {
            APP_LOG(LOG_DEBUG, "err_code %d\n", p_msg_ctx->resp_error_code);
            goto EXIT;
        }
    }
    else
    {
        p_msg_ctx->resp_error_code = BP_ERR_PARA_ILLEGAL;
        goto EXIT;
    }

    if (APP_OK == bulb_timing_add(&action, total_sec, &timer_id) && 0 != timer_id)
    {
        json_timer = cJSON_CreateObject();
        if (NULL != json_timer)
        {
            cJSON_AddNumberToObject(json_timer, "id", timer_id);
            APP_LOG(LOG_DEBUG, "add timer %d\n", timer_id);
        }
        else
        {
            p_msg_ctx->resp_error_code = BP_ERR_CMD_EXECUTE_FAIL;
        }
        p_msg_ctx->p_response = json_timer;
    }
    else
    {
        p_msg_ctx->resp_error_code = BP_ERR_CMD_EXECUTE_FAIL;
    }

EXIT:
    return BP_OK;
}

/**
 * @brief 获取timer
 * @param[in]        p_msg_ctx       [bypass上下文]
 * @param[in]        json            [传入json]
 * @return           BYPASS_ERR_E
 */
static BYPASS_ERR_E bulb_bypass_method_get_timer_v2_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    UNUSED(json);

    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    uint16_t timer_id = 0;
    timing_data_t tm;

    const void *timing = NULL;

    cJSON *json_data = NULL;
    cJSON *json_timers = NULL;
    cJSON *json_timer = NULL;
    cJSON *json_arr = NULL;

    json_data = cJSON_CreateObject();
    if (NULL == json_data)
    {
        return BP_ERR_NOMEM;
    }
    cJSON_AddItemToObject(json_data, "timers", json_timers = cJSON_CreateArray());
    if (APP_OK == bulb_timing_get_act(&timing) && NULL != timing)
    {
        timer_id = ((bulb_timing_t *)timing)->id;
    }
    else
    {
        p_msg_ctx->resp_error_code = BP_ERR_CMD_EXECUTE_FAIL;
        goto EXIT;
    }
    if (0 != timer_id && SDK_OK == vesync_timing_get(timer_id, &tm))
    {
        cJSON_AddItemToArray(json_timers, json_timer = cJSON_CreateObject());
        if (NULL == json_timer)
        {
            p_msg_ctx->resp_error_code = BP_ERR_OUT_OF_MEMORY;
            goto EXIT;
        }
        cJSON_AddNumberToObject(json_timer, "id", tm.timing_id);
        cJSON_AddNumberToObject(json_timer, "total", tm.total_second);
        cJSON_AddNumberToObject(json_timer, "remain", tm.remain_second);
        if (APP_OK == bulb_timing_get_act(&timing) && NULL != timing)
        {
            bulb_timing_t *timing_cfg = (bulb_timing_t *)timing;
            p_msg_ctx->resp_error_code = bulb_bp_pack_action(&json_arr, &timing_cfg->action);
            if (BP_ERR_NO_ERR == p_msg_ctx->resp_error_code)
            {
                cJSON_AddItemToObject(json_timer, "startAct", json_arr);
            }
            else
            {
                goto EXIT;
            }
        }
        else
        {
            p_msg_ctx->resp_error_code = BP_ERR_CMD_EXECUTE_FAIL;
            return BP_OK;
        }
    }

    p_msg_ctx->p_response = json_data;
    return BP_OK;
EXIT:
    cJSON_Delete(json_data);
    return BP_OK;
}

/**
 * @brief 删除timer
 * @param[in]        p_msg_ctx       [bypass上下文]
 * @param[in]        json            [传入json]
 * @return           BYPASS_ERR_E
 */
static BYPASS_ERR_E bulb_bypass_method_del_timer_v2_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    cJSON *json_data = cJSON_GetObjectItemCaseSensitive(json, "id");
    if (cJSON_IsNumber(json_data))
    {
        if (APP_OK == bulb_timing_remove(json_data->valueint))
        {
            cJSON *json_ret = cJSON_CreateObject();
            if (NULL != json_ret)
            {
                cJSON_AddNumberToObject(json_ret, "id", json_data->valueint);
            }
            p_msg_ctx->p_response = json_ret;
        }
        else
        {
            p_msg_ctx->resp_error_code = BP_ERR_TIMER_NOT_FOUND;
            p_msg_ctx->p_resp_error_msg = "Timer remove fail";
        }
    }
    else
    {
        p_msg_ctx->resp_error_code = BP_ERR_PARA_ILLEGAL;
    }
    return BP_OK;
}

/**
 * @brief 设置开关
 * @param[in]        p_msg_ctx       [bypass上下文]
 * @param[in]        p_data          [传入data]
 */
static void bulb_bp_set_switch(bypass_msg_ctx_t *p_msg_ctx, void *p_data)
{
    if (NULL == p_data)
    {
        p_msg_ctx->resp_error_code = BP_ERR_PARA_ILLEGAL;
        return;
    }

    bulb_status_t bulb_status;
    bulb_status_fetch(&bulb_status);

    bypass_switch_data_t *p_bp_switch = (bypass_switch_data_t *)p_data;
    if (true == p_bp_switch->enable)
    {
        if (false == bulb_status.enable)
        {
            bulb_status.enable = true;
        }
    }
    else
    {
        if (true == bulb_status.enable)
        {
            bulb_status.enable = false;
        }
    }

    if (bulb_status_update_and_report(&bulb_status, p_msg_ctx->p_trace_msg->src_type) != APP_OK)
    {
        p_msg_ctx->resp_error_code = BP_ERR_UNDEFINE;
        goto EXIT;
    }

EXIT:
    if (p_msg_ctx->resp_error_code != BP_ERR_NO_ERR)
    {
        p_msg_ctx->p_resp_error_msg = "internal error";
    }
}

/**
 * @brief 翻转开关
 * @param[in]        p_msg_ctx       [bypass上下文]
 * @param[in]        p_data          [传入data]
 */
static void bulb_bp_toggle_switch(bypass_msg_ctx_t *p_msg_ctx, void *p_data)
{
    UNUSED(p_data);

    bulb_status_t bulb_status;
    bulb_status_fetch(&bulb_status);
    bulb_status.enable = bulb_status.enable ? false : true;

    int ret = bulb_status_update_and_report(&bulb_status, p_msg_ctx->p_trace_msg->src_type);
    if (ret != APP_OK)
    {
        p_msg_ctx->resp_error_code = BP_ERR_UNDEFINE;
        p_msg_ctx->p_resp_error_msg = "internal error";
    }
}

/**
 * @brief 重置老化
 * @param[in]        p_msg_ctx       [bypass上下文]
 * @param[in]        json            [传入json]
 * @return           BYPASS_ERR_E
 */
static BYPASS_ERR_E bulb_bypass_method_reset_aging_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    bulb_flash_upd_cfg(BULB_CFG_AGING_TEST_TIME, 0);
    bulb_flash_upd_cfg(BULB_CFG_AGING_TEST, 0);
    bulb_flash_flush_cfg();
    return BP_OK;
}

/**
 * @brief 读取场景
 * @param[in]        p_msg_ctx       [bypass上下文]
 * @param[in]        json            [传入json]
 * @return           BYPASS_ERR_E
 */
static BYPASS_ERR_E bulb_bypass_method_get_scenes_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    cJSON *resp_scenes = NULL;
    cJSON *resp = cJSON_CreateObject();
    if (NULL == resp)
    {
        p_msg_ctx->resp_error_code = BP_ERR_OUT_OF_MEMORY;
        goto EXIT;
    }

    uint8_t index;
    cJSON *json_data = cJSON_GetObjectItemCaseSensitive(json, "index");
    if (cJSON_IsNumber(json_data))
    {
        index = json_data->valueint;
    }
    else
    {
        p_msg_ctx->resp_error_code = BP_ERR_PARA_ILLEGAL;
        goto EXIT;
    }

    uint8_t list_len, total;
    bulb_scene_t scenes[BULB_SCENE_GET_MAX_NUM];
    int ret = bulb_scenes_list_get(index, scenes, &list_len, &total);
    if (ret != APP_OK)
    {
        p_msg_ctx->resp_error_code = BP_ERR_CMD_EXECUTE_FAIL;
        goto EXIT;
    }

    cJSON_AddNumberToObject(resp, "total", total);
    resp_scenes = cJSON_AddArrayToObject(resp, "sceneModels");
    if (NULL == resp_scenes)
    {
        p_msg_ctx->resp_error_code = BP_ERR_OUT_OF_MEMORY;
        goto EXIT;
    }
    for (uint8_t cnt = 0; cnt < list_len; cnt++)
    {
        cJSON *obj = cJSON_CreateObject();
        if (obj != NULL)
        {
            cJSON_AddNumberToObject(obj, "sceneId", scenes[cnt].id);
        }
        cJSON_AddItemToArray(resp_scenes, obj);
    }
    p_msg_ctx->p_response = resp;
    return BP_OK;
EXIT:
    cJSON_Delete(resp);
    return BP_OK;
}

/**
 * @brief 添加场景
 * @param[in]        p_msg_ctx       [bypass上下文]
 * @param[in]        json            [传入json]
 * @return           BYPASS_ERR_E
 */
static BYPASS_ERR_E bulb_bypass_method_add_scene_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    cJSON *resp = cJSON_CreateObject();
    if (NULL == resp)
    {
        p_msg_ctx->resp_error_code = BP_ERR_OUT_OF_MEMORY;
        goto EXIT;
    }

    bulb_scene_t scene;
    bulb_status_t bulb_status;
    bulb_status_fetch(&bulb_status);
    switch (bulb_status.mode)
    {
    case BULB_CFG_COLOR_MODE_WHITE:
        scene.type = SCENE_TYPE_WHITE;
        scene.param.white.brightness = bulb_status.white.brightness;
        scene.param.white.color_temp = bulb_status.white.color_temp;
        break;
    case BULB_CFG_COLOR_MODE_HSV:
        scene.type = SCENE_TYPE_COLOR;
        scene.param.hsv.hue = bulb_status.hsv.hue;
        scene.param.hsv.saturation = bulb_status.hsv.saturation;
        scene.param.hsv.value = bulb_status.hsv.value;
        break;
    default:
        p_msg_ctx->resp_error_code = BP_ERR_CMD_EXECUTE_FAIL;
        goto EXIT;
    }

    uint16_t new_id;
    int ret = bulb_scene_add(&scene, &new_id);
    if (ret != APP_OK)
    {
        p_msg_ctx->resp_error_code = BP_ERR_CMD_EXECUTE_FAIL;
        goto EXIT;
    }
    cJSON_AddNumberToObject(resp, "sceneId", new_id);
    p_msg_ctx->p_response = resp;
    return BP_OK;
EXIT:
    cJSON_Delete(resp);
    return BP_OK;
}

/**
 * @brief 删除场景
 * @param[in]        p_msg_ctx       [bypass上下文]
 * @param[in]        json            [传入json]
 * @return           BYPASS_ERR_E
 */
static BYPASS_ERR_E bulb_bypass_method_del_scene_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    uint16_t id_to_del;
    cJSON *json_data = cJSON_GetObjectItemCaseSensitive(json, "sceneId");
    if (cJSON_IsNumber(json_data))
    {
        id_to_del = json_data->valueint;
    }
    else
    {
        p_msg_ctx->resp_error_code = BP_ERR_PARA_ILLEGAL;
        goto EXIT;
    }
    int ret = bulb_scene_del(id_to_del);
    if (ret != APP_OK)
    {
        p_msg_ctx->resp_error_code = BP_ERR_CMD_EXECUTE_FAIL;
        goto EXIT;
    }
EXIT:
    return BP_OK;
}

/**
 * @brief 获取断电记忆配置
 * @param[in]        p_msg_ctx       [bypass上下文]
 * @param[in]        json            [传入json]
 * @return           BYPASS_ERR_E
 */
static BYPASS_ERR_E bulb_bypass_method_get_power_off_memory_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    uint8_t mode;
    bulb_action_t action;

    bulb_pwr_mem_get(&mode, &action);

    cJSON *resp = cJSON_CreateObject();
    if (NULL == resp)
    {
        p_msg_ctx->resp_error_code = BP_ERR_OUT_OF_MEMORY;
        goto EXIT;
    }
    cJSON_AddNumberToObject(resp, "type", mode);

    if (mode == BULB_CFG_POWEROFF_MEMORY_MODE_3)
    {
        cJSON *json_arr = NULL;
        p_msg_ctx->resp_error_code = bulb_bp_pack_action(&json_arr, &action);
        if (BP_ERR_NO_ERR == p_msg_ctx->resp_error_code)
        {
            cJSON_AddItemToObject(resp, "startAct", json_arr);
        }
        else
        {
            goto EXIT;
        }
    }
    p_msg_ctx->p_response = resp;
    return BP_OK;
EXIT:
    cJSON_Delete(resp);
    return BP_OK;
}

/**
 * @brief 设置断电记忆配置
 * @param[in]        p_msg_ctx       [bypass上下文]
 * @param[in]        json            [传入json]
 * @return           BYPASS_ERR_E
 */
static BYPASS_ERR_E bulb_bypass_method_set_power_off_memory_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    uint8_t mode;
    bulb_action_t action;

    bulb_pwr_mem_get(&mode, &action);

    cJSON *json_data = cJSON_GetObjectItemCaseSensitive(json, "type");
    if (cJSON_IsNumber(json_data))
    {
        mode = json_data->valueint;
    }
    else
    {
        p_msg_ctx->resp_error_code = BP_ERR_PARA_ILLEGAL;
        goto EXIT;
    }

    switch (mode)
    {
    case BULB_CFG_POWEROFF_MEMORY_MODE_1:
        // fall-through
    case BULB_CFG_POWEROFF_MEMORY_MODE_2:
        break;
    case BULB_CFG_POWEROFF_MEMORY_MODE_3:
    {
        cJSON *json_data = cJSON_GetObjectItemCaseSensitive(json, "startAct");
        if (cJSON_IsArray(json_data))
        {
            p_msg_ctx->resp_error_code = bulb_bp_parse_action(json_data, &action);
            if (BP_ERR_NO_ERR != p_msg_ctx->resp_error_code)
            {
                goto EXIT;
            }
        }
        else
        {
            p_msg_ctx->resp_error_code = BP_ERR_PARA_ILLEGAL;
            goto EXIT;
        }
        break;
    }
    default:
        p_msg_ctx->resp_error_code = BP_ERR_PARA_ILLEGAL;
        goto EXIT;
    }
    bulb_pwr_mem_set(&mode, &action);
EXIT:
    return BP_OK;
}

/**
 * @brief 获取开关灯渐变时间的配置
 * @param[in]        p_msg_ctx       [bypass上下文]
 * @param[in]        json            [传入json]
 * @return           BYPASS_ERR_E
 */
static BYPASS_ERR_E bulb_bypass_method_get_light_duration_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    cJSON *resp = cJSON_CreateObject();
    if (NULL == resp)
    {
        p_msg_ctx->resp_error_code = BP_ERR_OUT_OF_MEMORY;
        goto EXIT;
    }

    uint8_t fade_enable;
    uint16_t fade_speed_ms;
    bulb_status_get_fade_speed(&fade_enable, &fade_speed_ms);
    if (fade_enable != 1)
    {
        cJSON_AddNumberToObject(resp, "enable", 0);
    }
    else
    {
        cJSON_AddNumberToObject(resp, "enable", 1);
        cJSON_AddNumberToObject(resp, "duration", fade_speed_ms);
    }
    p_msg_ctx->p_response = resp;
EXIT:
    return BP_OK;
}

/**
 * @brief 设置开关灯渐变时间的配置
 * @param[in]        p_msg_ctx       [bypass上下文]
 * @param[in]        json            [传入json]
 * @return           BYPASS_ERR_E
 */
static BYPASS_ERR_E bulb_bypass_method_set_light_duration_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    uint8_t fade_enable;
    uint16_t fade_speed_ms;
    bulb_status_get_fade_speed(&fade_enable, &fade_speed_ms);

    cJSON *enable = cJSON_GetObjectItemCaseSensitive(json, "enable");
    if (cJSON_IsNumber(enable))
    {
        fade_enable = (uint8_t)enable->valueint;
    }
    cJSON *duration = cJSON_GetObjectItemCaseSensitive(json, "duration");
    if (cJSON_IsNumber(duration))
    {
        fade_speed_ms = (uint16_t)duration->valueint;
    }
    bulb_status_set_fade_speed(fade_enable, fade_speed_ms);
    return BP_OK;
}

/**
 * @brief bypass 添加Schedule
 * @param[in]       p_msg_ctx       [msg context]
 * @param[in]       p_data          [回调函数传入数据]
 */
static void bulb_bp_add_schedule(bypass_msg_ctx_t *p_msg_ctx, void *p_data)
{
    if (NULL == p_data)
    {
        p_msg_ctx->resp_error_code = BP_ERR_PARA_ILLEGAL;
        return;
    }

    bypass_schedule_base_t *p_bp_sch = (bypass_schedule_base_t *)p_data;
    vesync_schedule_t sch_cfg;

    bulb_action_t *action = NULL;
    uint32_t sch_id = 0;

    cJSON *json_sch_ret = NULL;

    if ((NULL == p_bp_sch->enabled) || (NULL == p_bp_sch->repeat_config) || (NULL == p_bp_sch->type) || (NULL == p_bp_sch->json_action))
    {
        p_msg_ctx->resp_error_code = BP_ERR_PARA_ILLEGAL;
        goto EXIT;
    }
    sch_cfg.enabled = (bool)*p_bp_sch->enabled;
    sch_cfg.repeat_config = (uint8_t)*p_bp_sch->repeat_config;

    switch (*p_bp_sch->type)
    {
    case BYPASS_SCHEDULE_JSON_TYPE_TMG_EVT:
        sch_cfg.type = SCHE_TMG_EVT;
        if (NULL == p_bp_sch->clock_sec)
        {
            p_msg_ctx->resp_error_code = BP_ERR_PARA_ILLEGAL;
            goto EXIT;
        }
        sch_cfg.event_config.timing.clock_sec = (uint32_t)*p_bp_sch->clock_sec;
        break;
    case BYPASS_SCHEDULE_JSON_TYPE_SUN_EVT:
        sch_cfg.type = SCHE_SUN_EVT;
        if (NULL == p_bp_sch->is_sunrise)
        {
            p_msg_ctx->resp_error_code = BP_ERR_PARA_ILLEGAL;
            goto EXIT;
        }
        if (NULL == p_bp_sch->offset_sec)
        {
            p_msg_ctx->resp_error_code = BP_ERR_PARA_ILLEGAL;
            goto EXIT;
        }
        //日出和日落时schedule时长60min
        if ((BULB_SCHE_SUN_EVT_TIME_MAX < (int32_t)*p_bp_sch->offset_sec) ||
            (BULB_SCHE_SUN_EVT_TIME_MIN > (int32_t)*p_bp_sch->offset_sec))
        {
            p_msg_ctx->resp_error_code = BP_ERR_PARA_ILLEGAL;
            goto EXIT;
        }
        sch_cfg.event_config.timing.clock_sec = 0;
        sch_cfg.event_config.sun.is_sunrise = (bool)*p_bp_sch->is_sunrise;
        sch_cfg.event_config.sun.offset_sec = (int32_t)*p_bp_sch->offset_sec;
        break;
    default:
        p_msg_ctx->resp_error_code = BP_ERR_PARA_ILLEGAL;
        goto EXIT;
    }
    action = (bulb_action_t *)vesync_calloc(1, sizeof(bulb_action_t));
    if (NULL == action)
    {
        p_msg_ctx->resp_error_code = BP_ERR_OUT_OF_MEMORY;
        goto EXIT;
    }
    p_msg_ctx->resp_error_code = bulb_bp_parse_action(p_bp_sch->json_action, action);
    if (BP_ERR_NO_ERR != p_msg_ctx->resp_error_code)
    {
        goto EXIT;
    }
    p_msg_ctx->resp_error_code = bulb_schedule_add(&sch_cfg, action, &sch_id);
    if (BP_ERR_NO_ERR != p_msg_ctx->resp_error_code)
    {
        goto EXIT;
    }

    // 添加成功，生成回应
    json_sch_ret = cJSON_CreateObject();
    if (NULL != json_sch_ret)
    {
        cJSON_AddNumberToObject(json_sch_ret, "id", sch_id);
    }

    p_msg_ctx->p_response = json_sch_ret;
EXIT:
    vesync_free(action);
}

/**
 * @brief bypass 更新Schedule
 * @param[in]       p_msg_ctx       [msg context]
 * @param[in]       p_data          [回调函数传入数据]
 */
static void bulb_bp_upd_schedule(bypass_msg_ctx_t *p_msg_ctx, void *p_data)
{
    if (NULL == p_data)
    {
        p_msg_ctx->resp_error_code = BP_ERR_PARA_ILLEGAL;
        return;
    }

    bypass_schedule_base_t *p_bp_sch = (bypass_schedule_base_t *)p_data;
    uint32_t sch_id;

    p_msg_ctx->resp_error_code = bulb_schedule_upd(p_bp_sch, &sch_id);
    if (p_msg_ctx->resp_error_code != BP_ERR_NO_ERR)
    {
        return;
    }

    cJSON *json_sch_ret = cJSON_CreateObject();
    if (NULL != json_sch_ret)
    {
        cJSON_AddNumberToObject(json_sch_ret, "id", sch_id);
    }
    p_msg_ctx->p_response = json_sch_ret;
}

/**
 * @brief bypass 删除Schedule
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  p_data                   [回调函数传入数据]
 */
static void bulb_bp_del_schedule(bypass_msg_ctx_t *p_msg_ctx, void *p_data)
{
    if (NULL == p_data)
    {
        p_msg_ctx->resp_error_code = BP_ERR_PARA_ILLEGAL;
        return;
    }

    uint32_t sch_id = *((uint32_t *)p_data);
    cJSON *json_sch_ret = NULL;

    p_msg_ctx->resp_error_code = bulb_schedule_del(sch_id);
    if (p_msg_ctx->resp_error_code != BP_ERR_NO_ERR)
    {
        return;
    }
    json_sch_ret = cJSON_CreateObject();
    if (NULL != json_sch_ret)
    {
        cJSON_AddNumberToObject(json_sch_ret, "id", sch_id);
    }
    p_msg_ctx->p_response = json_sch_ret;
}

/**
 * @brief 生成Schedule配置项的JSON
 * @param[in]       json_data       [JSON]
 * @param[in]       sch_cfg         [Schedule配置]
 * @return          int             [Bypass定义的错误]
 */
static int bulb_bp_pack_sch_cfg_json(cJSON **json_data, vesync_schedule_t *sch_cfg)
{
    int err_code = BP_ERR_NO_ERR;
    cJSON *sub_obj = NULL;
    uint8_t type = sch_cfg->type;

    *json_data = cJSON_CreateObject();
    if (NULL == *json_data)
    {
        return BP_ERR_OUT_OF_MEMORY;
    }

    cJSON_AddNumberToObject(*json_data, "id", sch_cfg->id);
    cJSON_AddBoolToObject(*json_data, "enabled", sch_cfg->enabled);
    cJSON_AddNumberToObject(*json_data, "type", type);
    if (BYPASS_SCHEDULE_JSON_TYPE_TMG_EVT == type)
    {
        sub_obj = cJSON_AddObjectToObject(*json_data, "tmgEvt");
        if (NULL == sub_obj)
        {
            err_code = BP_ERR_OUT_OF_MEMORY;
            goto exit;
        }
        cJSON_AddNumberToObject(sub_obj, "clkSec", sch_cfg->event_config.timing.clock_sec);
    }
    else if (BYPASS_SCHEDULE_JSON_TYPE_SUN_EVT == type)
    {
        sub_obj = cJSON_AddObjectToObject(*json_data, "sunEvt");
        if (NULL == sub_obj)
        {
            err_code = BP_ERR_OUT_OF_MEMORY;
            goto exit;
        }
        cJSON_AddBoolToObject(sub_obj, "isRise", sch_cfg->event_config.sun.is_sunrise);
        cJSON_AddNumberToObject(sub_obj, "ofsSec", sch_cfg->event_config.sun.offset_sec);
    }

    cJSON_AddNumberToObject(*json_data, "repeat", sch_cfg->repeat_config);

exit:
    if (BP_ERR_NO_ERR != err_code)
    {
        cJSON_Delete(*json_data);
    }
    return err_code;
}

/**
 * @brief bypass 获取Schedule
 * @param[in]       p_msg_ctx       [msg context]
 * @param[in]       p_data          [回调函数传入数据]
 */
static void bulb_bp_get_schedule(bypass_msg_ctx_t *p_msg_ctx, void *p_data)
{
    if (NULL == p_data)
    {
        p_msg_ctx->resp_error_code = BP_ERR_PARA_ILLEGAL;
        return;
    }

    uint32_t index = *((uint32_t *)p_data);
    uint32_t cur_num = 0;
    uint32_t total_num = 0;

    cJSON *json_sch_ret = NULL;
    cJSON *json_array = NULL;
    cJSON *json_sche = NULL;
    cJSON *json_acts = NULL;

    vesync_schedule_t *sche_cfg = NULL;
    bulb_action_t *action = NULL;

    sche_cfg = (vesync_schedule_t *)vesync_malloc(BULB_SCHEDULE_GET_MAX_NUM * sizeof(vesync_schedule_t));
    if (NULL == sche_cfg)
    {
        p_msg_ctx->resp_error_code = BP_ERR_OUT_OF_MEMORY;
        return;
    }
    action = (bulb_action_t *)vesync_malloc(BULB_SCHEDULE_GET_MAX_NUM * sizeof(bulb_action_t));
    if (NULL == action)
    {
        p_msg_ctx->resp_error_code = BP_ERR_OUT_OF_MEMORY;
        goto EXIT;
    }
    p_msg_ctx->resp_error_code = bulb_schedule_get_mult(index, sche_cfg, action, &cur_num, &total_num);
    if (BP_ERR_NO_ERR == p_msg_ctx->resp_error_code)
    {
        json_sch_ret = cJSON_CreateObject();
        if (NULL == json_sch_ret)
        {
            p_msg_ctx->resp_error_code = BP_ERR_OUT_OF_MEMORY;
            goto EXIT;
        }
        cJSON_AddNumberToObject(json_sch_ret, "total", total_num);
        json_array = cJSON_AddArrayToObject(json_sch_ret, "schedules");
        if (NULL == json_array)
        {
            p_msg_ctx->resp_error_code = BP_ERR_OUT_OF_MEMORY;
            goto EXIT;
        }
        for (int i = 0; i < cur_num; ++i)
        {
            p_msg_ctx->resp_error_code = bulb_bp_pack_sch_cfg_json(&json_sche, &sche_cfg[i]);
            if (BP_ERR_NO_ERR != p_msg_ctx->resp_error_code || NULL == json_sche)
            {
                goto EXIT;
            }
            p_msg_ctx->resp_error_code = bulb_bp_pack_action(&json_acts, (bulb_action_t *)action + i);
            if (BP_ERR_NO_ERR != p_msg_ctx->resp_error_code || NULL == json_acts)
            {
                goto EXIT;
            }
            cJSON_AddItemToObject(json_sche, "startAct", json_acts);
            cJSON_AddItemToArray(json_array, json_sche);
        }
    }
    else if (BP_ERR_SCHEDULE_NOT_FOUND == p_msg_ctx->resp_error_code)
    {
        p_msg_ctx->resp_error_code = BP_ERR_NO_ERR;

        // 生成空回应
        json_sch_ret = cJSON_CreateObject();
        if (NULL != json_sch_ret)
        {
            cJSON_AddNumberToObject(json_sch_ret, "total", total_num);
            cJSON_AddArrayToObject(json_sch_ret, "schedules");
        }
    }
    else
    {
        goto EXIT;
    }

    p_msg_ctx->p_response = json_sch_ret;

    VCOM_SAFE_FREE(sche_cfg);
    VCOM_SAFE_FREE(action);
    return;
EXIT:
    VCOM_SAFE_FREE(sche_cfg);
    VCOM_SAFE_FREE(action);
    cJSON_Delete(json_sch_ret);
}

// bulb应用自定义bypass_method及其执行函数
static bypass_user_data_t bulb_method_tbl[] = {
    {"getLightStatusV2", bulb_bypass_method_get_status_handle},
    {"setLightStatusV2", bulb_bypass_method_set_status_handle},
    {"adjustPercent", bulb_bypass_method_adjust_percent_handle},
    {"resetAging", bulb_bypass_method_reset_aging_handle},
    {"getScenes", bulb_bypass_method_get_scenes_handle},
    {"addScene", bulb_bypass_method_add_scene_handle},
    {"delScene", bulb_bypass_method_del_scene_handle},
    {"getPowerOffMemory", bulb_bypass_method_get_power_off_memory_handle},
    {"setPowerOffMemory", bulb_bypass_method_set_power_off_memory_handle},
    {"getLightDurationInfo", bulb_bypass_method_get_light_duration_handle},
    {"setLightDurationInfo", bulb_bypass_method_set_light_duration_handle},
    // timer
    {"addTimerV2", bulb_bypass_method_add_timer_v2_handle},
    {"getTimerV2", bulb_bypass_method_get_timer_v2_handle},
    {"delTimerV2", bulb_bypass_method_del_timer_v2_handle}};

int bulb_bp_parse_action(cJSON *json_arr, bulb_action_t *action)
{
    cJSON *json_obj = NULL;
    cJSON *json_type = NULL;
    cJSON *json_act = NULL;
    cJSON *json_params = NULL;

    bool is_valid = false;
    int arr_size = cJSON_GetArraySize(json_arr);
    // bulb timer最多2个参数组
    if (arr_size <= 0 || arr_size > 2)
    {
        return BP_ERR_PARA_ILLEGAL;
    }
    for (int arr_idx = 0; arr_idx < arr_size; ++arr_idx)
    {
        json_obj = cJSON_GetArrayItem(json_arr, arr_idx);
        if (NULL == json_obj)
        {
            return BP_ERR_PARA_ILLEGAL;
        }
        json_type = cJSON_GetObjectItemCaseSensitive(json_obj, "type");
        json_act = cJSON_GetObjectItemCaseSensitive(json_obj, "act");
        if ((false == cJSON_IsString(json_type)) || (false == cJSON_IsString(json_act)))
        {
            return BP_ERR_PARA_ILLEGAL;
        }
        if (0 == strcmp(json_type->valuestring, "switch"))
        {
            if (0 == strcmp(json_act->valuestring, "on"))
            {
                action->onoff = true;
            }
            else if (0 == strcmp(json_act->valuestring, "off"))
            {
                action->onoff = false;
            }
            else
            {
                return BP_ERR_PARA_ILLEGAL;
            }
            // 必须要有type switch，否则非法
            is_valid = true;
            continue;
        }
        if (0 == strcmp(json_type->valuestring, "color_mode"))
        {
            int mode = bulb_bp_parse_color_mode_str(json_act->valuestring);
            switch (mode)
            {
                case BULB_CFG_COLOR_MODE_WHITE:
                {
                    action->mode = BULB_CFG_COLOR_MODE_WHITE;
                    json_params = cJSON_GetObjectItemCaseSensitive(json_obj, "params");
                    if (NULL == json_params)
                    {
                        return BP_ERR_PARA_ILLEGAL;
                    }
                    cJSON *json_bright = cJSON_GetObjectItemCaseSensitive(json_params, "brightness");
                    cJSON *json_temp = cJSON_GetObjectItemCaseSensitive(json_params, "colorTemp");
                    if (cJSON_IsNumber(json_bright) && cJSON_IsNumber(json_temp))
                    {
                        // 白光模式亮度不可为0
                        if ((PARAM_MIN >= json_bright->valueint) || (BRIGHT_MAX < json_bright->valueint) ||
                            (COLOR_TEMP_MAX < json_temp->valueint) || (PARAM_MIN > json_temp->valueint))
                        {
                            return BP_ERR_PARA_ILLEGAL;
                        }
                        action->bright = json_bright->valueint;
                        action->temp = json_temp->valueint;
                    }
                    else
                    {
                        return BP_ERR_PARA_ILLEGAL;
                    }
                    break;
                }
                case BULB_CFG_COLOR_MODE_HSV:
                {
                    action->mode = BULB_CFG_COLOR_MODE_HSV;
                    json_params = cJSON_GetObjectItemCaseSensitive(json_obj, "params");
                    if (NULL == json_params)
                    {
                        return BP_ERR_PARA_ILLEGAL;
                    }
                    cJSON *json_hue = cJSON_GetObjectItemCaseSensitive(json_params, "hue");
                    cJSON *json_saturation = cJSON_GetObjectItemCaseSensitive(json_params, "saturation");
                    cJSON *json_value = cJSON_GetObjectItemCaseSensitive(json_params, "value");
                    if ((false == cJSON_IsNumber(json_hue)) || (false == cJSON_IsNumber(json_saturation)) || (false == cJSON_IsNumber(json_value)))
                    {
                        return BP_ERR_PARA_ILLEGAL;
                    }
                    // 彩光模式亮度不可为0
                    if ((PARAM_MIN >= json_value->valueint) || (BRIGHT_MAX < json_value->valueint) || (HSV_PARAM_MAX < json_hue->valueint) ||
                        (PARAM_MIN > json_hue->valueint) || (HSV_PARAM_MAX < json_saturation->valueint) || (PARAM_MIN > json_saturation->valueint))
                    {
                        return BP_ERR_PARA_ILLEGAL;
                    }
                    action->hue = json_hue->valueint;
                    action->saturation = json_saturation->valueint;
                    action->value = json_value->valueint;
                    break;
                }
                case BULB_CFG_COLOR_MODE_SCENARIO:
                {
                    action->mode = BULB_CFG_COLOR_MODE_SCENARIO;
                    json_params = cJSON_GetObjectItemCaseSensitive(json_obj, "params");
                    if (NULL == json_params)
                    {
                        return BP_ERR_PARA_ILLEGAL;
                    }
                    cJSON *json_scene_id = cJSON_GetObjectItemCaseSensitive(json_params, "sceneId");
                    if (false == cJSON_IsNumber(json_scene_id))
                    {
                        return BP_ERR_PARA_ILLEGAL;
                    }
                    action->scene_id = json_scene_id->valueint;

                    bool is_exist = false;
                    bulb_scene_exist(action->scene_id, &is_exist);
                    if (false == is_exist)
                    {
                        APP_LOG(LOG_INFO, "scene_id doesn't exist\n");
                        return BP_ERR_PARA_ILLEGAL;
                    }
                    break;
                }
                default:
                    return BP_ERR_PARA_ILLEGAL;
            }
            continue;
        }
        return BP_ERR_PARA_ILLEGAL;
    }

    if (is_valid)
    {
        return BP_ERR_NO_ERR;
    }
    return BP_ERR_PARA_ILLEGAL;
}

/**
 * @brief 注册bypass回调函数
 */
void bulb_bypass_reg_cb()
{
    // 注册平台公共自bypass_method的回调
    vesync_bypass_reg_method_cb(BYPASS_METHOD_ID_SET_SWITCH, bulb_bp_set_switch);
    vesync_bypass_reg_method_cb(BYPASS_METHOD_ID_TOGGLE_SWITCH, bulb_bp_toggle_switch);

    // Schedule
    vesync_bypass_reg_method_cb(BYPASS_METHOD_ID_ADD_SCHEDULE_V3, bulb_bp_add_schedule);
    vesync_bypass_reg_method_cb(BYPASS_METHOD_ID_UPD_SCHEDULE_V3, bulb_bp_upd_schedule);
    vesync_bypass_reg_method_cb(BYPASS_METHOD_ID_DEL_SCHEDULE_V3, bulb_bp_del_schedule);
    vesync_bypass_reg_method_cb(BYPASS_METHOD_ID_GET_SCHEDULES_V3, bulb_bp_get_schedule);

    // 注册bulb应用自定义bypass_method
    for (int i = 0; i < SIZEOF_ARRAY(bulb_method_tbl); i++)
    {
        vesync_bypass_add_user_item(&bulb_method_tbl[i]);
    }
}
