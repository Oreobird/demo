/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file    lightstring_scene.c
* @brief   场景参数
* @author  Lind
* @date    2021-12-22
*/

#include <stdbool.h>
#include <stddef.h>

#include "lightstring_led.h"
#include "lightstring_scene.h"
#include "lightstring_board.h"

// 场景灯效参数
static ls_led_node_t node_ch0_brighten = {1024, 0, 300};
static ls_led_node_t node_ch1_brighten = {0, 1024, 300};
static ls_led_node_t node_mixed0 = {256, 1024, 300};
static ls_led_node_t node_mixed1 = {1024, 256, 300};
static ls_led_node_t node_reverse_breathing_slow[2] = {{0, 1024,1500}, {1024, 0, 1500}};
static ls_led_node_t node_reverse_breathing_fast[2] = {{0, 1024,150}, {1024, 0, 150}};
static ls_led_node_t node_gradient_switch[8] = {{0, 1024, 150}, {256, 768, 150}, {512, 512, 150}, {768, 256, 150}, {1024, 0, 150}, {768, 256, 150}, {512, 512, 150}, {256, 768, 150}};
static ls_led_node_t node_ch0_flash[34] = {{0, 0, 150}, {1024, 0, 150}, {0, 0, 150}, {1024, 0, 150}, {0, 0, 150}, {1024, 0, 150}, {0, 0, 150}, {1024, 0, 150}, {0, 0, 150}, {1024, 0, 150},
                                          {0, 0, 80}, {1024, 0, 80},{0, 0, 80}, {1024, 0, 80}, {0, 0, 80}, {1024, 0, 80}, {0, 0, 80}, {1024, 0, 80}, {0, 0, 80}, {1024, 0, 80},
                                          {0, 0, 80}, {1024, 0, 80},{0, 0, 80}, {1024, 0, 80}, {0, 0, 80}, {1024, 0, 80}, {0, 0, 80}, {1024, 0, 80}, {0, 0, 80}, {1024, 0, 80},
                                          {0, 0, 80}, {1024, 0, 80}, {0, 0, 80}, {1024, 0, 80}};
static ls_led_node_t node_ch1_flash[34] = {{0, 0, 150}, {0, 1024, 150}, {0, 0, 150}, {0, 1024, 150}, {0, 0, 150}, {0, 1024, 150}, {0, 0, 150}, {0, 1024, 150}, {0, 0, 150}, {0, 1024, 150},
                                           {0, 0, 80}, {0, 1024, 80}, {0, 0, 80}, {0, 1024, 80}, {0, 0, 80}, {0, 1024, 80}, {0, 0, 80}, {0, 1024, 80}, {0, 0, 80}, {0, 1024, 80},
                                           {0, 0, 80}, {0, 1024, 80}, {0, 0, 80}, {0, 1024, 80}, {0, 0, 80}, {0, 1024, 80}, {0, 0, 80}, {0, 1024, 80}, {0, 0, 80}, {0, 1024, 80},
                                           {0, 0, 80}, {0, 1024, 80}, {0, 0, 80}, {0, 1024, 80}};
static ls_led_node_t node_alternate_breathing[6] = {{0, 0, 450}, {1024, 0, 900}, {1024, 0, 450}, {0, 0, 450}, {0, 1024, 900}, {0, 1024, 450}};
static ls_led_node_t node_reverse_breathing_changing[16] = {{0, 1024, 300}, {1024, 0, 300}, {0, 1024, 300}, {1024, 0, 300}, {0, 1024, 300}, {1024, 0, 300}, {0, 1024, 300}, {1024, 0, 300},
                                                           {0, 1024, 150}, {1024, 0, 150}, {0, 1024, 150}, {1024, 0, 150}, {0, 1024, 150}, {1024, 0, 150}, {0, 1024, 150}, {1024, 0, 150}};

// 模式2
static ls_led_dynamic_params ch0_brighten =
{
    .node_num = 1,
    .mode = LS_LED_SWITCH,
    .type = MODE_TYPE_CH0,
    .node_head = &node_ch0_brighten,
};

// 模式3
static ls_led_dynamic_params ch1_brighten =
{
    .node_num = 1,
    .mode = LS_LED_SWITCH,
    .type = MODE_TYPE_CH1,
    .node_head = &node_ch1_brighten,
};

// 模式4
static ls_led_dynamic_params mixed0 =
{
    .node_num = 1,
    .mode = LS_LED_SWITCH,
    .type = MODE_TYPE_ALL,
    .node_head = &node_mixed0,
};

// 模式5
static ls_led_dynamic_params mixed1 =
{
    .node_num = 1,
    .mode = LS_LED_SWITCH,
    .type = MODE_TYPE_ALL,
    .node_head = &node_mixed1,
};

// 模式6
static ls_led_dynamic_params reverse_breathing =
{
    .node_num = 2,
    .mode = LS_LED_BREATHING,
    .type = MODE_TYPE_ALL,
    .node_head = node_reverse_breathing_slow,
};

// 模式7
static ls_led_dynamic_params gradient_switch =
{
    .node_num = 8,
    .mode = LS_LED_SWITCH,
    .type = MODE_TYPE_ALL,
    .node_head = node_gradient_switch,
};

// 模式8
static ls_led_dynamic_params ch0_flash =
{
    .node_num = 34,
    .mode = LS_LED_SWITCH,
    .type = MODE_TYPE_CH0,
    .node_head = node_ch0_flash,
};

// 模式9
static ls_led_dynamic_params ch1_flash =
{
    .node_num = 34,
    .mode = LS_LED_SWITCH,
    .type = MODE_TYPE_CH1,
    .node_head = node_ch1_flash,
};

// 模式10
static ls_led_dynamic_params alternate_breathing =
{
    .node_num = 6,
    .mode = LS_LED_BREATHING,
    .type = MODE_TYPE_ALTERNATE,
    .node_head = node_alternate_breathing,
};

// 模式11
static ls_led_dynamic_params reverse_breathing_changing =
{
    .node_num = 16,
    .mode = LS_LED_BREATHING,
    .type = MODE_TYPE_ALL,
    .node_head = node_reverse_breathing_changing,
};

// 产测连接
static ls_led_dynamic_params production_switch =
{
    .node_num = 2,
    .mode = LS_LED_SWITCH,
    .type = MODE_TYPE_ALL,
    .node_head = node_reverse_breathing_fast,
};


static ls_led_dynamic_params *mode_list[10] = {&ch0_brighten, &ch1_brighten, &mixed0, &mixed1, &reverse_breathing, &gradient_switch,
                                               &ch0_flash, &ch1_flash, &alternate_breathing, &reverse_breathing_changing};
static uint8_t mode_cycle_times[LS_MODE_NUM - 1] = {10, 10, 10, 10, 1, 3, 1, 1, 1, 1};

/**
* @brief 获取场景模式参数指针
* @param[in]  **mode_head   [指针]
*/
void ls_get_scene_head(void **mode_head)
{
    if (NULL == mode_head)
    {
        return;
    }

    *mode_head = (void *)mode_list;
}


/**
* @brief 获取产测灯效
* @param[out]  **pst_scene      [产测灯效指针]
*/
void ls_get_production_scene(ls_led_dynamic_params **pst_scene)
{
    *pst_scene = &production_switch;
}

/**
* @brief 是否可调速检查
* @param[in]  id    [scene id]
* @return  bool     [true/false]
*/
bool ls_scene_id_speed_check(uint8_t id)
{
    if (id < 6)
    {
        return false;
    }

    return true;
}

/**
* @brief 获取循环模式每个模式循环次数
* @param[in]  **arry_head       [指针]
*/
void ls_get_comb_cycle_times(uint8_t **arry_head)
{
    if (NULL == arry_head)
    {
        return;
    }

    *arry_head = mode_cycle_times;
}

