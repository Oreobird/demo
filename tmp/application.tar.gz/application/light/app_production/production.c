/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
* @file         production.c
* @brief        产测业务逻辑接口
* @author       Joshua
* @date         2021-11-23
*/

#include <string.h>

#include "vhal_wifi.h"

#include "vesync_log.h"
#include "vesync_device.h"
#include "vesync_production.h"
#include "vesync_common.h"
#include "scene.h"
#include "production.h"

/**
 * @brief 老化测试回调
 */
static void app_production_pre_test_cb(void)
{
    scene_t *prd_scene = scene_registry_get(SCENE_PRD, 0);
    if (prd_scene == NULL)
    {
        APP_LOG(LOG_ERROR, "Scene not reg\n");
        return;
    }

    prd_light_scene_pre_age_test(prd_scene);
    prd_light_scene_age_testing(prd_scene);
    prd_light_scene_post_age_test(prd_scene);
}

/**
 * @brief 产测状态回调函数
 * @param[in]  status          [产测状态码]
 */
static void app_production_status_cb(PRODUCTION_STATUS_E status)
{
    scene_t *prd_scene = scene_registry_get(SCENE_PRD, 0);
    if (prd_scene == NULL)
    {
        APP_LOG(LOG_ERROR, "Scene not reg\n");
        return;
    }

    switch (status)
    {
        case PRODUCTION_START:
            prd_light_scene_start(prd_scene);
            break;
        case PRODUCTION_RUNNING:
            prd_light_scene_running(prd_scene);
            break;
        case PRODUCTION_TEST_PASS:
            prd_light_scene_pass(prd_scene);
            break;
        case PRODUCTION_TEST_FAIL:
            prd_light_scene_fail(prd_scene);
            break;
        default:
            break;
    }
}

/**
* @brief 产测结果回调函数
* @param[in]  err_code          [产测状态码]
*/
static void app_production_result_cb(PRODUCTION_ERROR_E err_code)
{
    if (PRD_NO_ERR == err_code)
    {
        APP_LOG(LOG_INFO, "production success\n");
    }
    else
    {
        APP_LOG(LOG_INFO, "production error %d\n", err_code);
    }
}


void app_production_init(void)
{
    // 产测前的老化测试回调，产测状态回调及结果回调
    vesync_production_reg_pre_test_cb(app_production_pre_test_cb);
    vesync_production_reg_status_cb(app_production_status_cb);
    vesync_production_reg_result_cb(app_production_result_cb);
}

