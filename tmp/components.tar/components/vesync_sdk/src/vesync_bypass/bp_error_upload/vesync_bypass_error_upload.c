/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_bypass_error_upload.c
 * @brief       bypass处理接口
 * @date        2021-05-17
 */
#include <string.h>

#include "vesync_common.h"
#include "vesync_memory.h"
#include "vesync_bypass_internal.h"


#define vesync_error_bp_add_data(x, y, z) void; //TODO:Fixme
#define vesync_error_bp_get_data(x, y, z) void; //TODO:Fixme

#if defined(PR_FW_TYPE) && (PR_FW_TYPE == 0)
/**
 * @brief 添加异常历史数据
 * @param p_trace_msg trace message
 * @param json数据指针
 * @return BYPASS_ERR_E
 */
static BYPASS_ERR_E bypass_method_add_ulerror_data_handle(bypass_trace_msg_t *p_trace_msg, cJSON *json)
{
    BYPASS_ERR_E ret = BP_OK;

    if ((NULL == json)||(NULL == p_trace_msg))
        return BP_ERROR;

    bypass_ulerror_data_t *p_data = (bypass_ulerror_data_t *)vesync_malloc(sizeof(bypass_ulerror_data_t));
    if (NULL == p_data)
    {
        return BP_ERR_NOMEM;
    }

    memset(p_data, 0, sizeof(bypass_ulerror_data_t));

    cJSON *json_err = cJSON_GetObjectItemCaseSensitive(json, "error");
    if (cJSON_IsNumber(json_err))
    {
        p_data->rc = json_err->valueint;
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    cJSON *json_addlmsg = cJSON_GetObjectItemCaseSensitive(json, "addl_msg");
    if (cJSON_IsNumber(json_addlmsg))
    {
        p_data->addl_msg = json_addlmsg->valueint;
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    cJSON *json_line = cJSON_GetObjectItemCaseSensitive(json, "line");
    if (cJSON_IsNumber(json_line))
    {
        p_data->line = json_line->valueint;
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    SDK_LOG(LOG_DEBUG,"error: %ld, line: %d\r\n", p_data->rc, p_data->line);
//    bypass_method_cb_t method_cb = get_method_callback_by_id(BYPASS_METHOD_ID_ADD_HERROR);
//    if (method_cb)
//    {
//        method_cb(p_trace_msg, (void*)p_data, sizeof(bypass_ulerror_data_t));
//    }

    vesync_error_bp_add_data(p_trace_msg, (void*)p_data, sizeof(bypass_ulerror_data_t));

_exit:
    vesync_free(p_data);
    return ret;
}

/*
 * @brief 获取异常历史数据
 * @param p_trace_msg trace message
 * @param json数据指针
 * @return BYPASS_ERR_E
 */
static BYPASS_ERR_E bypass_method_get_ulerror_data_handle(bypass_trace_msg_t *p_trace_msg, cJSON *json)
{
    UNUSED(json);
    if (NULL == p_trace_msg)
        return BP_ERROR;

//    //查询无需解析json
//    bypass_method_cb_t method_cb = get_method_callback_by_id(BYPASS_METHOD_ID_GET_HERROR);
//    if (method_cb)
//    {
//        method_cb(p_trace_msg, NULL, 0);
//    }
    vesync_error_bp_get_data(p_trace_msg, NULL, 0);

    return BP_OK;
}
#endif

static bypass_item_data_t error_upload_method_tbl[] = {
#if defined(PR_FW_TYPE) && (PR_FW_TYPE == 0)
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_ADD_HERROR, "addErrorData", bypass_method_add_ulerror_data_handle, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_GET_HERROR, "getErrorData", bypass_method_get_ulerror_data_handle, NULL},
#endif
};

void vesync_bypass_error_upload_init(void)
{
    for (int i = 0; i < SIZEOF_ARRAY(error_upload_method_tbl); i++)
    {
        bypass_item_t *item = vesync_bypass_init_item(&error_upload_method_tbl[i]);
        if (item != NULL)
        {
            vesync_bypass_add_item(item);
        }
    }
}
