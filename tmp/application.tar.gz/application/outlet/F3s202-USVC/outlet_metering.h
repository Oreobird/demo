/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        outlet_metering.h
 * @brief       outlet电量计量
 * @author      Charles.Mei
 * @date        2021-12-15
 */


#ifndef __OUTLET_METERING_H__
#define __OUTLET_METERING_H__


#include <stdint.h>

#include "vesync_mutex.h"


#ifdef __cplusplus
extern "C" {
#endif


#define OUTLET_METERING_ELEC_UNIT_NUM   (2)
#define OUTLET_METERING_ELEC_UNIT0      (0)
#define OUTLET_METERING_ELEC_UNIT1      (1)

#define OUTLET_MTR_SELF_CAL_POWER0      (100.0)   // 自校准额定功率
#define OUTLET_MTR_SELF_CAL_VOLTAGE0    (120.0)   // 自校准额定电压
#define OUTLET_MTR_SELF_CAL_CURRENT0    (OUTLET_MTR_SELF_CAL_POWER0 / OUTLET_MTR_SELF_CAL_VOLTAGE0)   // 自校准额定电压


/*
 * @brief 计量类型
 */
typedef enum
{
    METERING_ELE        = 0,
    METERING_LOW_POW    = 1,
    METERING_HIGH_POW   = 2,
    METERING_LOW_VOL    = 3,
    METERING_HIGH_VOL   = 4,
    METERING_LOW_CUR    = 5,
    METERING_HIGH_CUR   = 6
} METERING_TYPE_E;

/**
 * @brief 计量校准key定义
 */
typedef enum
{
    FACTOR_KEY_ELE_PER_PULSE        = 0,
    FACTOR_KEY_POW_FACTOR           = 1,
    FACTOR_KEY_VOL_FACTOR           = 2,
    FACTOR_KEY_CUR_FACTOR           = 3,
} METERING_FACTOR_KEY_E;

/*
 * @brief 计量校准额定功率、电压和电流
 */
typedef struct
{
    uint8_t flag;
    float Power0;
    float Voltage0;
    float Current0;
} metering_rated_t;

/*
 * @brief 计量校准因子
 */
typedef struct
{
    double ele_per_pulse;
    float pow_factor;
    float vol_factor;
    float cur_factor;
} metering_factor_t;

/*
 * @brief 计量用电量
 */
typedef struct
{
    vesync_mutex_t ele_lock;
    double electricity;
} metering_elec_t;


/*
 * @brief 计量状态
 * @note elec_arry保存每个电量计量通道的电量数据
 */
typedef struct
{
    float power;
    float voltage;
    float current;
    metering_elec_t elec_arry[OUTLET_METERING_ELEC_UNIT_NUM];
} metering_status_t;

/*
 * @brief 计量GPIO
 * @note 详见电流计量芯片的应用指南
 */
typedef struct
{
    uint8_t sel_gpio;
    uint8_t cf_gpio;
    uint8_t cfi_gpio;
} metering_gpio_t;

/*
 * @brief 硬件保护回调
 */
typedef void(*metering_hardware_exception_cb_t)(void);

/*
 * @brief 软件预警回调
 */
typedef void(*metering_event_cb_t)(uint8_t, METERING_TYPE_E, float);

/*
 * @brief 计量配置
 * @note  初始化配置，配置硬件参数
 *        由于计量数据有下降和上升过程，请勿设置下限，否则易误触
 */
typedef struct
{
    metering_gpio_t gpios;
    float min_power;    // 默认置0，无效
    float max_power;    // 默认置硬件承受上限
    float min_voltage;  // 默认置0，无效
    float max_voltage;  // 默认置硬件承受上限
    float min_current;  // 默认置0，无效
    float max_current;  // 默认置硬件承受上限
    metering_hardware_exception_cb_t exception_cb;
    metering_event_cb_t event_cb;
} metering_conf_t;

/*
 * @brief 计量管理
 * @note  软件保护配置管理
 */
typedef struct
{
    vesync_mutex_t mgmt_lock;
    double max_electrictiy[OUTLET_METERING_ELEC_UNIT_NUM];   // 默认置0，无效
    float min_power;
    float max_power;
    float min_voltage;
    float max_voltage;
    float min_current;
    float max_current;
    struct
    {
        uint32_t min_pow : 1;
        uint32_t max_pow : 1;
        uint32_t min_vol : 1;
        uint32_t max_vol : 1;
        uint32_t min_cur : 1;
        uint32_t max_cur : 1;
    } chg_flag;
} metering_mgmt_t;

/*
 * @brief 计量管理配置
 */
typedef struct
{
    double *max_electrictiy[OUTLET_METERING_ELEC_UNIT_NUM];
    float *min_power;
    float *max_power;
    float *min_voltage;
    float *max_voltage;
    float *min_current;
    float *max_current;
} metering_mgmt_conf_t;

/*
 * @brief 计量数据
 */
typedef struct
{
    float power;
    float voltage;
    float current;
} metering_data_t;


/**
 * @brief 电量计量功能初始化
 * @param[out]  conf            [配置]
 * @return      int             [错误码，成功/失败]
 */
int outlet_metering_init(metering_conf_t *conf);

/**
 * @brief 校准额定数据设置
 * @param[out]  rated_data      [校准额定数据]
 * @return      int             [错误码，成功/失败]
 */
int outlet_metering_set_rated_data(metering_rated_t *rated_data);

/**
 * @brief 获取计量数据
 * @param[out]  metering_data   [计量数据]
 * @return      int             [错误码，成功/失败]
 */
int outlet_metering_get_metering_data(metering_data_t *metering_data);

/**
 * @brief 获取累计用电量
 * @param[in]   index           [通道]
 * @param[out]  electricity     [累计用电量，单位WH]
 * @return      int             [错误码，成功/失败]
 */
int outlet_metering_get_electricity(uint8_t index, float *electricity);

/**
 * @brief 清除累计用电量
 * @param[in]   index           [通道]
 * @return      int             [错误码，成功/失败]
 */
int outlet_metering_clear_electricity(uint8_t index);

/**
 * @brief 校准额定数据设置
 * @param[out]  conf            [管理配置]
 * @return      int             [错误码，成功/失败]
 */
int outlet_metering_set_mgmt(metering_mgmt_conf_t *conf);


#ifdef __cplusplus
}
#endif

#endif

