/**
 *  Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
 * @file        vhal_utils.c
 * @brief       厂家乐鑫 SDK提供的通用接口封装
 * @author      Dongri.Su
 * @date        2021-04-22
 */

#include <string.h>
#include <sys/time.h>

#include "esp_system.h"
#include "esp_wifi.h"
#include "esp_sntp.h"
#include "esp_idf_version.h"

#include "vesync_common.h"
#include "vesync_log.h"
#include "vhal_utils_internal.h"
#include "vhal_wifi_internal.h"

// 缓存上次SNTP的更新时间点
static time_t s_last_snpt_updated_time = 0;

/**
 * @brief 重启系统
 * @param[in]  arg                  [定时器参数，未使用]
 * @return     void
 */
void vhal_utils_restart(void *arg)
{
    HAL_LOG(LOG_INFO, "Prepare to restart system!\n");
    esp_restart();
}

/**
 * @brief 通过硬件RNG获取随机数
 * @param[in]  p_buf                [用于存储随机数的缓存空间]
 * @param[in]  buf_len              [缓存空间大小]
 * @return     void
 */
void vhal_utils_get_random(uint8_t *p_buf, int32_t buf_len)
{
    esp_fill_random(p_buf, buf_len);
}

/**
 * @brief  获取剩余heap大小.
 * @return     uint32_t             [heap空间大小]
 */
uint32_t vhal_utils_get_free_heap_size(void)
{
    return esp_get_free_heap_size();
}

/**
 * @brief 修改dhcp的hostname
 * @param[in]  p_hostname            [新的hostname]
 * @return     void
 */
void vhal_utils_chg_dhcp_hostname(const char *p_hostname)
{
    vhal_wifi_chg_dhcp_hostname(p_hostname);
}

/**
 * @brief  获取Wi-Fi模组芯片名称
 * @return     char *               [字符串格式芯片名称]
 */
char *vhal_utils_get_chip_name(void)
{
#if defined(CONFIG_IDF_TARGET_ESP32)
    return "ESP32";
#elif defined(CONFIG_IDF_TARGET_ESP32C3)
    return "ESP32C3";
#elif defined(CONFIG_IDF_TARGET_ESP32S2)
    return "ESP32S2";
#elif defined(CONFIG_IDF_TARGET_ESP8266)
    return "ESP8266";
#else
    return "Unknown";
#endif
}

/**
 * @brief  获取SDK版本信息
 * @param[out] p_buf              [缓存空间]
 * @param[in]  buf_len            [缓存大小]
 * @return     char *             [字符串格式SDK版本信息]
 */
char *vhal_utils_get_sdk_version(char *p_buf, uint32_t buf_len)
{
    if (NULL == p_buf || 0 == buf_len)
    {
        return "N/A";
    }

#ifdef ESP_IDF_VERSION
    snprintf(p_buf, buf_len, "v%d.%d.%d", ESP_IDF_VERSION_MAJOR, ESP_IDF_VERSION_MINOR, ESP_IDF_VERSION_PATCH);
#else
    snprintf(p_buf, buf_len, "%s", "N/A");
#endif

    return p_buf;
}

/*
 * @brief 获取设备的MAC地址
 * @param[in]  type                 [详见DEVICE_TYPE_MAC_E定义]
 * @param[out] p_buf                [获取到的MAC地址]
 * @param[in]  buf_len              [缓存大小]
 * @return     int                  [执行成功，返回OK；执行失败，返回FAIL]
 */
int vhal_utils_get_dev_mac(VHAL_MAC_TYPE_E type, char *p_buf, int32_t buf_len)
{
    int ret = VHAL_FAIL;
    uint8_t mac_addr[MAC_ADDR_STR_MAX_LEN] = {0, };
    wifi_ap_record_t ap_info;
    memset(&ap_info, 0, sizeof(wifi_ap_record_t));

    if (NULL == p_buf)
    {
        HAL_LOG(LOG_ERROR, "Input param is a null pointer!\n");
        return VHAL_FAIL;
    }
    if (buf_len < MAC_ADDR_STR_MAX_LEN)
    {
        HAL_LOG(LOG_ERROR, "Buf len(=%d) is too small!\n", buf_len);
        return VHAL_FAIL;
    }

    if (VHAL_MAC_WIFI_STA == type)
    {
        ret = esp_wifi_get_mac(ESP_MAC_WIFI_STA, mac_addr);
    }
    else if (VHAL_MAC_WIFI_SOFTAP == type)
    {
        ret = esp_wifi_get_mac(ESP_MAC_WIFI_SOFTAP, mac_addr);
    }
    else if (VHAL_MAC_ROUTER == type)
    {
        ret = esp_wifi_sta_get_ap_info(&ap_info);
    }
    else
    {
        HAL_LOG(LOG_ERROR, "Unknow device type = %d!\n", type);
        return VHAL_FAIL;
    }

    if (ESP_OK == ret)
    {
        if (VHAL_MAC_ROUTER == type)
        {
            snprintf(p_buf, buf_len, MACSTR, MAC2STR(ap_info.bssid));
        }
        else
        {
            snprintf(p_buf, buf_len, MACSTR, MAC2STR(mac_addr));
        }
    }
    else
    {
        HAL_LOG(LOG_ERROR, "Get router mac fail, errCode = 0x%x!\n", ret);
        return VHAL_FAIL;
    }

    return VHAL_OK;
}

/**
 * @brief  设置设备MAC地址
 * @param[in]  p_mac               [MAC地址，使用":"分隔，如：00:01:02:03:04:05]
 * @return     uint32_t             [成功/失败]
 */
int32_t vhal_utils_set_wifi_mac(char *p_mac)
{
    return VHAL_OK;
}

/*
 * @brief 设备作为STA时，获取分配到的IP。
 * @param[in]  char *               [保存IP的缓存]
 * @param[in]  int                  [缓存大小]
 * @return     char*                [IP地址]
 */
char* vhal_utils_get_sta_ip(char *p_buf, int32_t buf_len)
{
    return vhal_wifi_get_sta_ip(p_buf, buf_len);
}

/**
 * @brief 获取utc时间戳
 * @param[out]  p_ms                [保存精度到毫秒的时间戳]
 * @param[in]  buf_len              [p_ms大小]
 * @return     int                  [执行成功，返回OK；执行失败，返回FAIL]
 */
int vhal_utils_get_system_time_ms_str(char *p_ms, int buf_len)
{
    if (NULL == p_ms)
    {
        HAL_LOG(LOG_ERROR, "Input parameter contains null pointer!!\n");
        return VHAL_FAIL;
    }

    time_t seconds;
    seconds = time((time_t *)NULL);

    struct timeval te;
    gettimeofday(&te, NULL); // get current time

    uint32_t milliseconds = te.tv_usec/1000;
    snprintf(p_ms, buf_len, "%u%03u", (unsigned int)seconds, (unsigned int)milliseconds);

    return VHAL_OK;
}

/**
 * @brief 获取utc时间戳
 * @return     uint32_t              [utc时间戳,单位：秒]
 */
uint32_t vhal_utils_get_system_time_sec(void)
{
    uint32_t ts_sec = 0;

    time_t seconds;
    seconds = time((time_t *)NULL);
    ts_sec = (uint32_t)seconds;

    return ts_sec;
}

/**
* @brief 获取utc时间戳
 * @return     long long            [utc时间戳]
 */
long long vhal_utils_get_system_time_ms_int(void)
{
    long long milliseconds = 0;
    struct timeval te;

    gettimeofday(&te, NULL); // get current time

    milliseconds = te.tv_sec*1000LL + te.tv_usec/1000;

    return milliseconds;
}

/**
 * @brief SNTP同步时间后的通知回调，将记录这个时间点
 * @param[in] tv    [SNTP的时间信息] 
 */
static void sntp_sync_done_cb(struct timeval *tv)
{
    s_last_snpt_updated_time = tv->tv_sec;
}

/**
 * @brief 初始化sntp
 */
void vhal_utils_start_sntp(void)
{
    HAL_LOG(LOG_DEBUG, "Initializing SNTP...\n");
    sntp_setoperatingmode(SNTP_OPMODE_POLL);

    sntp_set_time_sync_notification_cb(sntp_sync_done_cb);

    sntp_setservername(0, SNTP_SERVER_ADDR);
    sntp_init();

    // Set timezone to China Standard Time
    setenv("TZ", "CST-8", 1);
    tzset();
    HAL_LOG(LOG_DEBUG, "Initialized successfully\n");
}

/**
 * @brief 停止sntp服务
 */
void vhal_utils_stop_sntp(void)
{
    HAL_LOG(LOG_DEBUG, "stop SNTP!!!\n");
    sntp_stop();
}

/**
 * @brief 获得上次SNTP更新的时间点
 * @return uint32_t [返回的秒时间戳]
 */
uint32_t vhal_utils_get_sntp_last_sync(void)
{
    return (uint32_t)s_last_snpt_updated_time;
}

/**
 * @brief 设置本地utc时间
 * @param[in]  utc_time     [utc时间戳]
 * @param[in]  time_zone    [时区]
 * @return     void         [无]
 */
void vhal_utils_update_system_time(uint32_t utc_time, int8_t time_zone)
{
    UNUSED(time_zone);
    struct timeval tv ={0, 0};
    struct timezone tz = {0, 0};

    tv.tv_sec = utc_time;
    settimeofday(&tv, &tz);

    struct timeval tv_start;
    gettimeofday(&tv_start, NULL);
    HAL_LOG(LOG_DEBUG, "Update utc time to %ld\n", tv_start.tv_sec);
}

