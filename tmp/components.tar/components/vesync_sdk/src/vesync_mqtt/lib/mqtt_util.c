/*
 * This file is subject to the terms and conditions defined in
 * file 'LICENSE', which is part of this source code package.
 * Tuan PM <tuanpm at live dot com>
 */


#include <string.h>
#include <sys/time.h>

#include "vesync_common.h"
#include "vesync_task.h"
#include "vesync_memory.h"
#include "vhal_utils.h"
#include "mqtt_util.h"


#define MAX_ID_STRING (32)

char *mqtt_util_create_id_string(void)
{
    uint8_t mac[6] = {0, };
    char *id_string = vesync_calloc(1, MAX_ID_STRING);
    MQTT_UTIL_MEM_CHECK(id_string, return NULL);

    char mac_str[MAC_ADDR_STR_MAX_LEN] = {0,};
    vhal_utils_get_dev_mac(VHAL_MAC_WIFI_STA, mac_str, sizeof(mac_str));
    sscanf(mac_str, STRMAC, STR2MAC(mac));

    snprintf(id_string, MAX_ID_STRING, "%s-%02x%02x%02X", vhal_utils_get_chip_name(), mac[3], mac[4], mac[5]);

    return id_string;
}

int mqtt_util_random(int max)
{
    uint32_t rand_val = 0;
    vhal_utils_get_random((uint8_t *)&rand_val, sizeof(rand_val)/sizeof(uint8_t));
    return rand_val%max;
}

long long mqtt_util_tick_get_ms(void)
{
    return vesync_task_get_tick_ms();
}

void mqtt_util_ms_to_timeval(int timeout_ms, struct timeval *tv)
{
    tv->tv_sec = timeout_ms / 1000;
    tv->tv_usec = (timeout_ms - (tv->tv_sec * 1000)) * 1000;
}


