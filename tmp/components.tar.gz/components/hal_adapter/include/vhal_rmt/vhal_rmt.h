/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file    vhal_rmt.h
* @brief   rmt接口
* @author  Lind
* @date     2021-11-17
*/

#ifndef __VHAL_RMT_H__
#define __VHAL_RMT_H__

#include <stdbool.h>

#ifdef __cplusplus
extern "C"
{
#endif

/**
 * @brief rmt通道
 */
typedef enum
{
    RMT_TX_CH_0 = 0,    /* RMT channel number 0 */
    RMT_TX_CH_1 = 1,    /* RMT channel number 1 */
    RMT_RX_CH_0 = 2,    /* RMT channel number 2 */
    RMT_RX_CH_1 = 3     /* RMT channel number 3 */
} RMT_CH_E;

typedef enum {
    RMT_MODE_SEND = 0, /* RMT TX mode */
    RMT_MODE_REC = 1,  /* RMT RX mode */
} RMT_MODE_E;

/**
 * @brief rmt发送空闲电平
 */
typedef enum
{
    RMT_IDLE_LEVEL_L = 0, // 低电平
    RMT_IDLE_LEVEL_H,     // 高电平
} RMT_IDLE_LEVEL_E;

/**
 * @brief rmt发送载波电平
 */
typedef enum
{
    RMT_CARRIER_LEVEL_L = 0, // 低电平
    RMT_CARRIER_LEVEL_H,     // 高电平
} RMT_CARRIER_LEVEL_E;

/**
 * @brief rmt发送脉冲配置
 */
typedef struct
{
    uint32_t duration0:15;             // 第1个电平时间/ns
    uint32_t level0:1;                 // 第1个电平值
    uint32_t duration1:15;             // 第2个电平时间/ns
    uint32_t level1:1;                 // 第2个电平值
} rmt_item_t;

/**
 * @brief rmt发送配置
 */
typedef struct
{
    uint32_t carrier_freq_hz;           // 载波频率
    RMT_CARRIER_LEVEL_E carrier_level;
    RMT_IDLE_LEVEL_E idle_level;
    uint8_t carrier_duty_percent;
    uint32_t loop_count;               /* Maximum loop count */
    bool carrier_en;
    bool loop_en;
    bool idle_output_en;
} rmt_tx_cfg_t;

/**
 * @brief rmt接收配置
 */
typedef struct {
    uint16_t idle_threshold;            /* RMT RX idle threshold */
    uint8_t filter_ticks_thresh;        /* RMT filter tick number */
    bool filter_en;                     /* RMT receiver filter enable */
    bool rm_carrier;                    /* RMT receiver remove carrier enable */
    uint32_t carrier_freq_hz;           /* RMT carrier frequency */
    uint8_t carrier_duty_percent;       /* RMT carrier duty (%) */
    RMT_CARRIER_LEVEL_E carrier_level;  /* The level to remove the carrier */
} rmt_rx_cfg_t;

/**
 * @brief rmt配置
 */
typedef struct {
    RMT_MODE_E rmt_mode;    /* RMT mode: transmitter or receiver */
    RMT_CH_E channel;       /* RMT channel */
    uint32_t gpio_num;      /* RMT GPIO number */
    uint8_t clk_div;        /* RMT channel counter divider */
    uint8_t mem_block_num;  /* RMT memory block number */
    uint32_t flags;         /* RMT channel extra configurations, OR'd with RMT_CHANNEL_FLAGS_[*] */
    union
    {
        rmt_tx_cfg_t tx_config; /* RMT TX parameter */
        rmt_rx_cfg_t rx_config; /* RMT RX parameter */
    };
} rmt_cfg_t;

/**
 * @brief rmt发送结束回调
 */
typedef void (*rmt_tx_end_function_t)(RMT_CH_E channel, void *arg);

/**
 * @brief rmt发送结束回调结构体
 */
typedef struct
{
    rmt_tx_end_function_t function; /* Function which is called on RMT TX end */
    void *arg;                /* Optional argument passed to function */
} rmt_tx_end_cb_t;

/**
* @brief rmt发送默认初始化函数
* @param[in]  gpio          [io]
* @param[in]  channel_id    [发送通道]
* @return  rmt_cfg_t        [发送配置]
*/
rmt_cfg_t vhal_rmt_default_cfg_tx(uint16_t gpio, RMT_CH_E channel_id);


/**
* @brief rmt接收默认初始化函数
* @param[in]  gpio          [io]
* @param[in]  channel_id    [接收通道]
* @return  rmt_cfg_t        [接收配置]
*/
rmt_cfg_t vhal_rmt_default_cfg_rx(uint16_t gpio, RMT_CH_E channel_id);

/**
* @brief 获取通道的时钟频率
* @param[in]  channel   [通道]
* @return  uint32_t     [频率]
*/
uint32_t vhal_rmt_get_counter_clock(RMT_CH_E channel);

/**
* @brief rmt 初始化
* @param[in]  *rmt_param    [配置]
* @param[in]  rx_buf_size   [底层接收buf大小，建议1k]
* @return  int              [VHAL_OK/VHAL_FAIL]
*/
int vhal_rmt_init(rmt_cfg_t *rmt_param, uint32_t rx_buf_size);

/**
* @brief 卸载rmt通道
* @param[in]  channel     [通道]
*/
void vhal_rmt_deinit(RMT_CH_E channel);

/**
* @brief 设置发送逻辑波形
* @param[in]  tx_channel    [发送通道]
* @param[in]  logic0        [logic0参数]
* @param[in]  logic1        [logic1参数]
*/
void vhal_rmt_set_item_sample(RMT_CH_E tx_channel, rmt_item_t logic0, rmt_item_t logic1);

/**
* @brief 发送rmt信号，任意波形
* @param[in]  tx_channel    [发送通道]
* @param[in]  *p_buf        [发送数据buf]
* @param[in]  data_num      [数据数量]
* @param[in]  wait_tx_done  [是否阻塞发送]
* @return  int              [VHAL_OK/VHAL_FAIL]
*/
int vhal_rmt_write_items(RMT_CH_E tx_channel,rmt_item_t *p_buf, uint32_t data_num, bool wait_tx_done);


/**
* @brief 发送逻辑信号，只有0和1组成
* @param[in]  tx_channel    [发送通道]
* @param[in]  *p_buf        [发送数据buf]
* @param[in]  buf_len_bits  [数据位数]
* @param[in]  wait_tx_done  [是否阻塞发送]
* @return  int              [VHAL_OK/VHAL_FAIL]
*/
int vhal_rmt_send_logic(RMT_CH_E tx_channel,uint8_t *p_buf, uint32_t buf_len_bits, bool wait_tx_done);

/**
* @brief 修改rmt gpio配置
* @param[in]  channel     [通道]
* @param[in]  mode        [RMT模式]
* @param[in]  gpio_num    [gpio]
* @return  int            [VHAL_OK/VHAL_FAIL]
*/
int vhal_rmt_set_gpio(RMT_CH_E channel, RMT_MODE_E mode, uint8_t gpio_num);

/**
* @brief 开始rmt接收
* @param[in]  channel       [接收通道]
* @param[in]  rx_idx_rst    [接收后是否重置buf，默认为true]
* @return  int              [VHAL_OK/VHAL_FAIL]
*/
int vhal_rmt_rx_start(RMT_CH_E channel, bool rx_idx_rst);

/**
* @brief 获取接收到的脉冲数据
* @param[out]  *data_num    [数据数量]
* @param[in]  time_out_ms   [阻塞接收时间]
* @return  rmt_item_t      [接收到的数据指针]
*/
rmt_item_t* vhal_rmt_rx_get(uint16_t *data_num, uint32_t time_out_ms);

/**
* @brief 解析收到的数据后需要将空间释放
* @param[in]  *items        [接收到的数据指针]
*/
void vhal_rmt_rx_mem_release(rmt_item_t *items);


/**
* @brief 注册发送结束回调
* @param[in]  *tx_end_cb_setting    [注册配置]
*/
void vhal_rmt_reg_tx_end_cb(rmt_tx_end_cb_t *tx_end_cb_setting);


#ifdef __cplusplus
}
#endif

#endif /* __VHAL_RMT_H__ */

