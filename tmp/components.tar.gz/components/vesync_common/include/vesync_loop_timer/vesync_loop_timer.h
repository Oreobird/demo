/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
 * @file        vesync_loop_timer.h
 * @brief       基于内部定时器封装的事件与定时器处理任务接口声明
 * @date        2021-05-21
 */
#ifndef __VESYNC_LOOP_TIMER_H__
#define __VESYNC_LOOP_TIMER_H__

#include <stdint.h>
#include <stdbool.h>

#include "vesync_timer.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief vloop实例句柄类型定义
 */
typedef void *vloop_hdl_t;

/**
 * @brief vloop事件定义
 */
typedef struct
{
    int id;       // 事件ID
    uint8_t *buf; // 事件随行数据缓存
    uint16_t len; // 数据缓存的大小
} vloop_ev_t;

/**
 * @brief 创建一个vloop实例
 * @param[in]   task_name           [系统任务名称]
 * @param[in]   stack_size          [任务栈的大小]
 * @param[in]   prio                [任务的优先级]
 * @param[in]   event_queue_size    [事件队列大小]
 * @return      vloop_hdl_t         [返回创建成功的vloop实例句柄]
 * @return      NULL                [创建失败]
 */
vloop_hdl_t vloop_create(const char *task_name, int stack_size, int prio, int event_queue_size);

/**
 * @brief 销毁一个vloop实例
 * @param[in]   hdl                 [vloop实例句柄]
 * @return      int                 [SDK_OK; SDK_FAIL]
 */
int vloop_destroy(vloop_hdl_t hdl);

/**
 * @brief 为vloop实例新建一个定时器
 * @param[in]   hdl                 [vloop实例句柄]
 * @param[in]   name                [定时器名称]
 * @param[in]   cb                  [timout回调函数]
 * @param[in]   cb_arg              [回调函数输入参数]
 * @param[in]   timeout_ms          [超时时间，单位毫秒]
 * @param[in]   reload              [定时类型:
 *                                   false：一次
 *                                   true：周期性]
 * @return vesync_timer_t *         [定时器结构体指针]
 */
vesync_timer_t *vloop_timer_new(vloop_hdl_t hdl,
                                const char *name,
                                void (*cb)(void*),
                                void *cb_arg,
                                long timeout_ms,
                                bool reload);

/**
 * @brief 为vloop实例启动定时器
 * @param[in]   hdl                 [vloop实例句柄]
 * @param[in]   timer               [定时器结构体指针]
 * @return      int                 [SDK_OK； SDK_FAIL]
 */
int vloop_timer_start(vloop_hdl_t hdl, vesync_timer_t *timer);

/**
 * @brief 为vloop实例停止定时器
 * @param[in]   hdl                 [vloop实例句柄]
 * @param[in]   timer               [定时器结构体指针]
 * @return      int                 [SDK_OK； SDK_FAIL]
 */
int vloop_timer_stop(vloop_hdl_t hdl, vesync_timer_t *timer);

/**
 * @brief 为vloop实例修改定时器计时周期
 * @param[in]   hdl                 [vloop实例句柄]
 * @param[in]   timer               [定时器结构体指针]
 * @param[in]   timeout_ms          [超时时间]
 * @return      int                 [SDK_OK； SDK_FAIL]
 */
int vloop_timer_change_period(vloop_hdl_t hdl, vesync_timer_t *timer, long timeout_ms);

/**
 * @brief 为vloop实例删除定时器
 * @param[in]   hdl                 [vloop实例句柄]
 * @param[in]   timer               [定时器结构体指针]
 * @return      int                 [SDK_OK； SDK_FAIL]
 */
int vloop_timer_free(vloop_hdl_t hdl, vesync_timer_t *timer);

/**
 * @brief 为vloop实例订阅事件
 * @param[in]   hdl                 [vloop实例句柄]
 * @param[in]   id                  [事件ID，注意与内部定时器事件ID有冲突时会返回失败]
 * @param[in]   handle_cb           [事件处理回调]
 * @return      int                 [SDK_OK； SDK_FAIL]
 */
int vloop_event_subscribe(vloop_hdl_t hdl, int id, void (*handle_cb)(void *arg));

/**
 * @brief 为vloop实例推送事件
 * @param[in]   hdl                 [vloop实例句柄]
 * @param[in]   id                  [事件ID，注意与内部定时器事件ID有冲突时会返回失败]
 * @param[in]   data                [必要的事件随行数据，会被做拷贝而不是引用]
 * @param[in]   len                 [数据缓存的大小]
 * @return      int                 [SDK_OK； SDK_FAIL]
 */
int vloop_event_publish(vloop_hdl_t hdl, int id, const uint8_t *data, uint16_t len);

#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_LOOP_TIMER_H__ */
