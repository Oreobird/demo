/**
 *  Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vhal_watchdog.c
 * @brief       开门狗开启和关闭
 * @author      DongriSu
 * @date        2021-04-22
 */

#include "freertos/FreeRTOS.h"
//#include "freertos/task.h"
#include "freertos/timers.h"

#include "vesync_log.h"
#include "vesync_common.h"


#include "wdt_api.h"

#include "vhal_watchdog.h"


static TimerHandle_t s_rtl_wdt_timerhd = NULL;                 // 喂狗定时器



/**
 * @brief 更新schedule和away配置定时器回调
 * @param void
 */
static void vhal_rtl_wdt_bark(void *p_msg)
{
    (void)p_msg;

    //HAL_LOG(LOG_DEBUG, "Refresh watchdog.\n");
    watchdog_refresh();
}


/**
 * @brief 创建并启动喂狗定时器
 * @param[in]  uint32_t         [看门狗周期]
 * @param int                   [成功/失败]
 */
static int vhal_rtl_wdt_timer_start(uint32_t timeout_ms)
{
    int ret = VHAL_FAIL;
    int period = timeout_ms/2;      // 喂狗周期是看门狗超时时间的2倍

    if (NULL == s_rtl_wdt_timerhd)
    {
        // 创建重复执行定时器，5秒后执行
        s_rtl_wdt_timerhd = xTimerCreate("wdt", pdMS_TO_TICKS(period), pdTRUE, NULL, vhal_rtl_wdt_bark);
    }

    if (NULL != s_rtl_wdt_timerhd)
    {
        if (xTimerStart(s_rtl_wdt_timerhd, portMAX_DELAY) != pdPASS)
        {
            HAL_LOG(LOG_ERROR, "Timer start fail!!\n");
        }
        else
        {
            ret = VHAL_OK;
            HAL_LOG(LOG_DEBUG, "Timer start successful...\n");
        }
    }
    else
    {
        HAL_LOG(LOG_ERROR, "Timer create fail!!\n");
    }

    return ret;
}

/**
 * @brief 停止数据记录定时器
 * @return  void
 */
static void vhal_rtl_wdt_timer_stop(void)
{
    if (NULL != s_rtl_wdt_timerhd)
    {
        if (xTimerStop(s_rtl_wdt_timerhd, portMAX_DELAY) == pdPASS)
        {
            if (xTimerDelete(s_rtl_wdt_timerhd, portMAX_DELAY) == pdPASS)
            {
                s_rtl_wdt_timerhd = NULL;
            }
        }
    }
}

/**
 * @brief   初始化并启动看门狗
 * @param[in]  uint32_t         [看门狗周期]
 * @return  void
 * @note 只能启动1次
 */
void vhal_watchdog_start(uint32_t timeout_ms)
{
    int ret = VHAL_FAIL;

    // 创建喂狗定时器
    ret = vhal_rtl_wdt_timer_start(timeout_ms);
    if (VHAL_OK == ret)
    {
        HAL_LOG(LOG_DEBUG, "Cycle is %dms.\n", timeout_ms);
        watchdog_init(timeout_ms);  // init xxms watchdog
        watchdog_start();           // start
    }
    else
    {
        HAL_LOG(LOG_ERROR, "Start fail\n");
    }
}

/**
 * @brief   停止看门狗
 * @return  void
 */
void vhal_watchdog_stop(void)
{
    HAL_LOG(LOG_DEBUG, "watchdog stop.\n");
    watchdog_stop();

    vhal_rtl_wdt_timer_stop();
}

