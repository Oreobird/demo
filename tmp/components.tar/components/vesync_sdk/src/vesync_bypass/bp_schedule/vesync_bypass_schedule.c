/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_bypass_schedule.c
 * @brief       bypass处理接口
 * @date        2021-05-17
 */
#include <string.h>

#include "vesync_common.h"
#include "vesync_memory.h"

#include "vesync_bypass_internal.h"

#define USER_CFG_KEY_TIMEZONE_RANDOM        0x5A5A   // 随机数

/**
 * @brief "addSchedule" method数据解析
 * @param p_trace_msg trace message
 * @param json数据指针
 * @return bypass_err_t
 */
static BYPASS_ERR_E bypass_method_add_schedule_handle(bypass_trace_msg_t *p_trace_msg, cJSON *json)
{
    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_trace_msg, return BP_ERROR);

    BYPASS_ERR_E ret = BP_OK;

    bypass_schedule_base_t *psch_base = (bypass_schedule_base_t *)vesync_malloc(sizeof(bypass_schedule_base_t));
    if (NULL == psch_base)
    {
        return BP_ERR_NOMEM;
    }

    memset(psch_base, 0, sizeof(bypass_schedule_base_t));

    cJSON* json_data = cJSON_GetObjectItemCaseSensitive(json, "enabled");
    if (cJSON_IsBool(json_data))
    {
        psch_base->enable = json_data->valueint;
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "startTs");
    if (cJSON_IsNumber(json_data))
    {
        // 开始执行时间必须大于0
        if (json_data->valueint <= 0)
        {
            ret = BP_ERR_ARG;
            goto _exit;
        }

        psch_base->start_ts = json_data->valueint;
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "sunrise");
    if (cJSON_IsNumber(json_data))
    {
        // 1代表日出 2代表日落 0代表Schedule，超出范围不合法
        if (json_data->valueint < 0 || json_data->valueint > 2)
        {
            ret = BP_ERR_ARG;
            goto _exit;
        }

        psch_base->sun_rise = json_data->valueint;
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "repeat");    //每周循环
    if (cJSON_IsNumber(json_data))
    {
        psch_base->repeat = json_data->valueint&0xFF;
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "timeZone");     //时区解析
    if (cJSON_IsString(json_data))
    {
        memcpy(psch_base->time_zone, json_data->valuestring, sizeof(psch_base->time_zone) - 1);
    }
    else/* if (psch_base->sun_rise)*/
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "longitude");    //经度
    if (cJSON_IsString(json_data))
    {
        memcpy(psch_base->longitude, json_data->valuestring, sizeof(psch_base->longitude) - 1);
    }
    else/* if (psch_base->sun_rise)*/
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "latitude");     //纬度
    if (cJSON_IsString(json_data))
    {
        memcpy(psch_base->latitude, json_data->valuestring, sizeof(psch_base->latitude) - 1);
    }
    else/* if (psch_base->sun_rise)*/
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "startAct");
    if (cJSON_IsArray(json_data) && cJSON_GetArraySize(json_data))
    {
        psch_base->json_action = json_data;     //startAct 指针传给应用层处理
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }
    psch_base->id = 0;

    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_ADD_SCHEDULE);
    if (method_cb)
    {
        method_cb(p_trace_msg, (void*)psch_base, sizeof(bypass_schedule_base_t));
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

_exit:
    vesync_free(psch_base);
    return ret;
}

/**
 * @brief "upSchedule" method数据解析
 * @param p_trace_msg trace message
 * @param json数据指针
 * @return bypass_err_t
 */
static BYPASS_ERR_E bypass_method_up_schedule_handle(bypass_trace_msg_t *p_trace_msg, cJSON *json)
{
    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_trace_msg, return BP_ERROR);

    BYPASS_ERR_E ret = BP_OK;
    bypass_schedule_base_t *psch_base = (bypass_schedule_base_t *)vesync_malloc(sizeof(bypass_schedule_base_t));
    if (NULL == psch_base)
    {
        return BP_ERR_NOMEM;
    }

    memset(psch_base, 0, sizeof(bypass_schedule_base_t));

    cJSON* json_data = cJSON_GetObjectItemCaseSensitive(json, "enabled");
    if (cJSON_IsBool(json_data))
    {
        psch_base->enable = json_data->valueint;
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "startTs");
    if (cJSON_IsNumber(json_data))
    {
        // 开始执行时间必须大于0
        if (json_data->valueint <= 0)
        {
            ret = BP_ERR_ARG;
            goto _exit;
        }

        psch_base->start_ts = json_data->valueint;
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "sunrise");
    if (cJSON_IsNumber(json_data))
    {
        // 1代表日出 2代表日落 0代表Schedule，超出范围不合法
        if (json_data->valueint < 0 || json_data->valueint > 2)
        {
            ret = BP_ERR_ARG;
            goto _exit;
        }

        psch_base->sun_rise = json_data->valueint;
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "repeat");    //每周循环
    if (cJSON_IsNumber(json_data))
    {
        psch_base->repeat = json_data->valueint&0xFF;
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "timeZone");     //时区解析
    if (cJSON_IsString(json_data))
    {
        memcpy(psch_base->time_zone, json_data->valuestring, sizeof(psch_base->time_zone) - 1);
    }
    //else/* if (psch_base->sun_rise)*/      // 时区修改为可选字段，2020-04-28
    //{
    //    ret = BP_ERR_ARG;
    //    goto _exit;
    //}

    json_data = cJSON_GetObjectItemCaseSensitive(json, "longitude");    //经度
    if (cJSON_IsString(json_data))
    {
        memcpy(psch_base->longitude, json_data->valuestring, sizeof(psch_base->longitude)- 1);
    }
    //else/* if (psch_base->sun_rise)*/      // 经度修改为可选字段，2020-04-28
    //{
    //    ret = BP_ERR_ARG;
    //    goto _exit;
    //}

    json_data = cJSON_GetObjectItemCaseSensitive(json, "latitude");     //纬度
    if (cJSON_IsString(json_data))
    {
        memcpy(psch_base->latitude, json_data->valuestring, sizeof(psch_base->latitude)- 1);
    }
    //else/* if (psch_base->sun_rise)*/      // 纬度修改为可选字段，2020-04-28
    //{
    //    ret = BP_ERR_ARG;
    //    goto _exit;
    //}

    json_data = cJSON_GetObjectItemCaseSensitive(json, "startAct");
    if (cJSON_IsArray(json_data) && cJSON_GetArraySize(json_data))
    {
        psch_base->json_action = json_data;     //startAct 指针传给应用层处理
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "id");
    if (cJSON_IsNumber(json_data))
    {
        psch_base->id = json_data->valueint;;     //update id
    }

    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_UP_SCHEDULE);
    if (method_cb)
    {
        method_cb(p_trace_msg, (void*)psch_base, sizeof(bypass_schedule_base_t));
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

_exit:
    vesync_free(psch_base);
    return ret;
}

/**
 * @brief "delSchedule" method数据解析
 * @param p_trace_msg trace message
 * @param json数据指针
 * @return bypass_err_t
 */
static BYPASS_ERR_E bypass_method_del_schedule_handle(bypass_trace_msg_t *p_trace_msg, cJSON *json)
{
    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_trace_msg, return BP_ERROR);

    int *pId = (int*)vesync_malloc(sizeof(int));
    if (NULL == pId)
    {
        return BP_ERR_NOMEM;
    }

    BYPASS_ERR_E ret = BP_OK;

    cJSON* json_data = cJSON_GetObjectItemCaseSensitive(json, "id");
    if (cJSON_IsNumber(json_data))
    {
        *pId = json_data->valueint;
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_DEL_SCHEDULE);
    if (method_cb)
    {
        method_cb(p_trace_msg, (void*)pId, sizeof(int));
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

_exit:
    vesync_free(pId);
    return ret;
}

/**
 * @param json数据指针
 * @param p_trace_msg trace message
 * @param json数据指针
 * @return bypass_err_t
 */
static BYPASS_ERR_E bypass_method_get_schedule_handle(bypass_trace_msg_t *p_trace_msg, cJSON *json)
{
    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_trace_msg, return BP_ERROR);

    int *pMax_id = (int*)vesync_malloc(sizeof(int));
    if (NULL == pMax_id)
    {
        return BP_ERR_NOMEM;
    }

    BYPASS_ERR_E ret = BP_OK;

    cJSON* json_data = cJSON_GetObjectItemCaseSensitive(json, "maxId");
    if (cJSON_IsNumber(json_data))
    {
        *pMax_id = json_data->valueint;
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_GET_SCHEDULE);
    if (method_cb)
    {
        method_cb(p_trace_msg, (void*)pMax_id, sizeof(int));
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

_exit:
    vesync_free(pMax_id);
    return ret;
}

/**
 * @brief     更新schedule 时区偏差值bypass指令处理接口
 * @param[in] p_trace_msg           trace message
 * @param[in] json数据指针              待解析处理的数据
 * @return bypass_err_t             执行结果
 */
static BYPASS_ERR_E bypass_method_update_timediffer_handle(bypass_trace_msg_t *p_trace_msg, cJSON *json)
{
    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_trace_msg, return BP_ERROR);

    timezone_info_t timeinfo ;

    BYPASS_ERR_E ret = BP_OK;
    timeinfo.rand_key = USER_CFG_KEY_TIMEZONE_RANDOM;

    cJSON* json_data = cJSON_GetObjectItemCaseSensitive(json, "offsetInSec");
    if (cJSON_IsNumber(json_data))
    {
        timeinfo.time_deviation = json_data->valueint;
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    cJSON* json_str = cJSON_GetObjectItemCaseSensitive(json, "timeZone");
    if (cJSON_IsString(json_str))
    {
        memcpy(timeinfo.timezone,json_str->valuestring,TIMETZONE_STRING_LENGTH);
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_UPDATE_TIMEZONE);
    if (method_cb)
    {
        method_cb(p_trace_msg, (void*)(&timeinfo), sizeof(timezone_info_t));
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

_exit:
    return ret;
}

static bypass_item_data_t schedule_method_tbl[] = {
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_ADD_SCHEDULE,    "addSchedule",    bypass_method_add_schedule_handle, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_UP_SCHEDULE,     "upSchedule",     bypass_method_up_schedule_handle, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_DEL_SCHEDULE,    "delSchedule",    bypass_method_del_schedule_handle, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_GET_SCHEDULE,    "getSchedule",    bypass_method_get_schedule_handle, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_UPDATE_TIMEZONE, "updateTzOffset", bypass_method_update_timediffer_handle, NULL},
};

void vesync_bypass_schedule_init(void)
{
    for (int i = 0; i < SIZEOF_ARRAY(schedule_method_tbl); i++)
    {
        bypass_item_t *item = vesync_bypass_init_item(&schedule_method_tbl[i]);
        if (item != NULL)
        {
            vesync_bypass_add_item(item);
        }
    }
}
