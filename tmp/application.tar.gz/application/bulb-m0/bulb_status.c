/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        bulb_status.c
 * @brief       灯泡色彩控制
 * @author      Dave.Ming
 * @date        2021-08-31
 */

#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdbool.h>

#include "vesync_log.h"
#include "vesync_common.h"
#include "vesync_light.h"
#include "vesync_task.h"
#include "vesync_device.h"

#include "bulb_flash.h"
#include "bulb_status.h"
#include "bulb_bypass.h"
#include "bulb_scene.h"
#include "bulb_report.h"

#include "bulb_def.h"
#include "bulb_board.h"
#include "bulb_color_tbl.h"

#define LIGHT_FRAME_PERIOD_MS (20)      // 灯光控制器单帧周期（毫秒）
#define STATUS_REPORT_DELAY_MS (1000)   // 状态变化上报延时
#define STATUS_UPDATE_FADE_SPEED (0.02) // 调光的渐变步速

/**
 * @brief vesync_light针对五路通道的枚举
 */
enum
{
    LIGHT_CH_IDX_C = 0,
    LIGHT_CH_IDX_W = 1,
    LIGHT_CH_IDX_R = 2,
    LIGHT_CH_IDX_G = 3,
    LIGHT_CH_IDX_B = 4,
    LIGHT_CH_IDX_MAX = 5,
};

/**
 * @brief LED PWM控制量定义
 */
typedef struct
{
    uint16_t r;
    uint16_t g;
    uint16_t b;
    uint16_t c;
    uint16_t w;
} pwm_data_t;

// PWM控制量的初始化值
#define STATUS_PWM_INIT_VALUE {r:0, g:0, b:0, c:0, w:0}

// 灯光控制器实例
static vesync_light_t s_light;
// 音乐模式的灯效定时器
static vesync_timer_t *s_dynamic_effect_timer = NULL;
// 音乐模式2、3的更新标志
static bool s_is_music_m2_3_yield = false;
// 音乐模式的灯效速度
static uint16_t s_music_speed_ms = BULB_MUSIC_SPEED_SLOWEST_MS;
// 开关灯的渐变步速
static float s_fade_step_speed = (float)LIGHT_FRAME_PERIOD_MS / (float)BULB_CFG_DEFAULT_FADE_SPEED_MS;
// 灯的实际开关状态，上电的时候是被置为关
static bool s_is_open_actually = false;
// 内置灯效定时器的vloop实例
static vloop_hdl_t s_vloop_ins;
// 状态上报定时器
static vesync_timer_t *s_report_timer = NULL;
// 状态来源缓存
static char s_report_src_buf[MAX_STAT_CHG_RSN_STR_LEN] = {0};

#if BULB_DRIVER_TYPE == BULB_DRV_BY_BP5758
#include "vdrv_bp5758d.h"
static bp5758d_range_t s_bp5758d_range;
#elif BULB_DRIVER_TYPE == BULB_DRV_BY_LEDC
#include "vhal_led.h"
#define VLED_CW_CH (LED_CH0) // 冷光的led通道
#define VLED_WW_CH (LED_CH1) // 暖光的led通道
#define VLED_R_CH (LED_CH2)  // 红光的led通道
#define VLED_G_CH (LED_CH3)  // 绿光的led通道
#define VLED_B_CH (LED_CH4)  // 蓝光的led通道
#define VLED_NUM (5)         // 配置的led数量
#elif BULB_DRIVER_TYPE == BULB_DRV_BY_SM2235
#include "vdrv_sm2235egh.h"
#else
#error "BULB_DRIVER_TYPE is invalid"
#endif /* BULB_DRIVER_TYPE */

#if BULB_DRIVER_TYPE == BULB_DRV_BY_BP5758
/**
 * @brief BP5758D设置量程
 */
static void bp5758_update_range_cfg(void)
{
    s_bp5758d_range.out_num = 5;
    s_bp5758d_range.outs[0] = BULB_BULE_OUT_IO;
    s_bp5758d_range.outs[1] = BULB_WARM_OUT_IO;
    s_bp5758d_range.outs[2] = BULB_COLD_OUT_IO;
    s_bp5758d_range.outs[3] = BULB_GREEN_OUT_IO;
    s_bp5758d_range.outs[4] = BULB_RED_OUT_IO;
    s_bp5758d_range.data[0] = BULB_BULE_MAX;
    s_bp5758d_range.data[1] = BULB_WARM_MAX;
    s_bp5758d_range.data[2] = BULB_COLD_MAX;
    s_bp5758d_range.data[3] = BULB_GREEN_MAX;
    s_bp5758d_range.data[4] = BULB_RED_MAX;
}

/**
 * @brief vesync_light的PWM刷新回调
 * @param[in] opt               [可选回调参数]
 * @param[in] ch_num            [刷新的通道数量]
 * @param[in] duty              [通道PWM控制量数组]
 */
static void set_driver_output(void *opt, uint16_t ch_num, uint32_t *duty)
{
    if (ch_num < 5)
    {
        return;
    }

    bp5758d_gray_t bp5758d_gray;
    bp5758d_gray.out_num = 5;
    bp5758d_gray.outs[0] = BULB_BULE_OUT_IO;
    bp5758d_gray.outs[1] = BULB_WARM_OUT_IO;
    bp5758d_gray.outs[2] = BULB_COLD_OUT_IO;
    bp5758d_gray.outs[3] = BULB_GREEN_OUT_IO;
    bp5758d_gray.outs[4] = BULB_RED_OUT_IO;
    bp5758d_gray.data[0] = duty[LIGHT_CH_IDX_B];
    bp5758d_gray.data[1] = duty[LIGHT_CH_IDX_W];
    bp5758d_gray.data[2] = duty[LIGHT_CH_IDX_C];
    bp5758d_gray.data[3] = duty[LIGHT_CH_IDX_G];
    bp5758d_gray.data[4] = duty[LIGHT_CH_IDX_R];

    if (SDK_OK != vdrv_bp5758d_range_cfg(&s_bp5758d_range))
    {
        APP_LOG(LOG_ERROR, "set bp5758 range fail\n");
    }
    if (SDK_OK != vdrv_bp5758d_gray_cfg(&bp5758d_gray))
    {
        APP_LOG(LOG_ERROR, "set bp5758 gray fail\n");
    }
    if (SDK_OK != vdrv_bp5758d_cfg_write())
    {
        APP_LOG(LOG_ERROR, "write bp5758 cfg fail\n");
    }
}
#elif BULB_DRIVER_TYPE == BULB_DRV_BY_LEDC
/**
 * @brief vesync_light的PWM刷新回调
 * @param[in] opt               [可选回调参数]
 * @param[in] ch_num            [刷新的通道数量]
 * @param[in] duty              [通道PWM控制量数组]
 */
static void set_driver_output(void *opt, uint16_t ch_num, uint32_t *duty)
{
    if (ch_num < 5)
    {
        return;
    }

    vhal_led_set_duty_bits(VLED_CW_CH, duty[LIGHT_CH_IDX_C], BULB_PWM_MAX_SCALE);
    vhal_led_set_duty_bits(VLED_WW_CH, duty[LIGHT_CH_IDX_W], BULB_PWM_MAX_SCALE);
    vhal_led_set_duty_bits(VLED_R_CH, duty[LIGHT_CH_IDX_R], BULB_PWM_MAX_SCALE);
    vhal_led_set_duty_bits(VLED_G_CH, duty[LIGHT_CH_IDX_G], BULB_PWM_MAX_SCALE);
    vhal_led_set_duty_bits(VLED_B_CH, duty[LIGHT_CH_IDX_B], BULB_PWM_MAX_SCALE);
}
#elif BULB_DRIVER_TYPE == BULB_DRV_BY_SM2235
/**
 * @brief vesync_light的PWM刷新回调
 * @param[in] opt               [可选回调参数]
 * @param[in] ch_num            [刷新的通道数量]
 * @param[in] duty              [通道PWM控制量数组]
 */
static void set_driver_output(void *opt, uint16_t ch_num, uint32_t *duty)
{
    if (ch_num < 5)
    {
        return;
    }

    uint16_t ch_remap[5];
    ch_remap[BULB_RED_OUT_IO - 1] = duty[LIGHT_CH_IDX_R];
    ch_remap[BULB_GREEN_OUT_IO - 1] = duty[LIGHT_CH_IDX_G];
    ch_remap[BULB_BULE_OUT_IO - 1] = duty[LIGHT_CH_IDX_B];
    ch_remap[BULB_COLD_OUT_IO - 1] = duty[LIGHT_CH_IDX_C];
    ch_remap[BULB_WARM_OUT_IO - 1] = duty[LIGHT_CH_IDX_W];

    sm2235egh_gray_t rgb, cw;
    rgb.rgb.out_1r = ch_remap[0];
    rgb.rgb.out_2g = ch_remap[1];
    rgb.rgb.out_3b = ch_remap[2];
    cw.cw.out_4c = ch_remap[3];
    cw.cw.out_5w = ch_remap[4];
    int ret = vdrv_sm2235egh_set_output(&rgb, &cw);
    if (ret != SDK_OK)
    {
        APP_LOG(LOG_WARN, "sm2235egh_set_output fail\n");
    }
}
#else
#error "BULB_DRIVER_TYPE is invalid"
#endif /* BULB_DRIVER_TYPE */

/**
 * @brief HSV to RGB的色域参数转换为PWM控制量
 * @param[in,out] p_led     [输出的LED PWM控制量]
 * @param[in]     H         [色相]
 * @param[in]     S         [饱和度]
 * @param[in]     V         [明度]
 */
static void set_led_hsv_to_rgb(pwm_data_t *p_led, uint16_t H, uint16_t S, uint8_t V)
{
    if (0 == V)
    {
        p_led->r = 0;
        p_led->g = 0;
        p_led->b = 0;
        p_led->w = 0;
        p_led->c = 0;
        return;
    }

    uint16_t hi = (H / 1667) % 6;
    float F = (float)H / 1667.0f * 100.0f - 100.0f * (float)hi;
    // 给明度做相应的偏置，消除超低亮度下混光偏色的问题
    float ofs_v = ((float)V / 100.0f) * (100.0f - BULB_RGB_MIN_PERCENT) + BULB_RGB_MIN_PERCENT;

    float P = ofs_v * (10000.0f - (float)S) / 10000.0f;
    float Q = ofs_v * (1000000.0f - F * (float)S) / 1000000.0f;
    float T = ofs_v * (1000000.0f - (float)S * (100.0f - F)) / 1000000.0f;
    float red, green, blue;

    switch (hi)
    {
    case 0:
        red = ofs_v;
        green = T;
        blue = P;
        break;
    case 1:
        red = Q;
        green = ofs_v;
        blue = P;
        break;
    case 2:
        red = P;
        green = ofs_v;
        blue = T;
        break;
    case 3:
        red = P;
        green = Q;
        blue = ofs_v;
        break;
    case 4:
        red = T;
        green = P;
        blue = ofs_v;
        break;
    case 5:
        red = ofs_v;
        green = P;
        blue = Q;
        break;
    default:
        APP_LOG(LOG_WARN, "invalid hsv args\n");
        return;
    }
    float red_ratio = red / (red + green + blue);
    float green_ratio = green / (red + green + blue);
    float blue_ratio = blue / (red + green + blue);
    float scaling = ofs_v / 100.0f;

    uint16_t pwm_red = (uint16_t)(red_ratio * BULB_PWM_MAX_SCALE * scaling);
    uint16_t pwm_green = (uint16_t)(green_ratio * BULB_PWM_MAX_SCALE * scaling);
    uint16_t pwm_blue = (uint16_t)(blue_ratio * BULB_PWM_MAX_SCALE * scaling);

    // 最大量程限制
    p_led->r = (pwm_red >= BULB_PWM_MAX_SCALE) ? (BULB_PWM_MAX_SCALE - 1) : pwm_red;
    p_led->g = (pwm_green >= BULB_PWM_MAX_SCALE) ? (BULB_PWM_MAX_SCALE - 1) : pwm_green;
    p_led->b = (pwm_blue >= BULB_PWM_MAX_SCALE) ? (BULB_PWM_MAX_SCALE - 1) : pwm_blue;
    p_led->w = 0;
    p_led->c = 0;
#if 0
    APP_LOG(LOG_DEBUG, "RGB calculate result: R[%f], G[%f], B[%f]; Scaling[%f]\n",
            red, green, blue, ofs_v);
    APP_LOG(LOG_DEBUG, "PWM calculate result: R[%d], G[%d], B[%d], sum[%d]\n",
            p_led->r, p_led->g, p_led->b, p_led->r + p_led->g + p_led->b);
#endif
}

/**
 * @brief 白光模式色温与亮度转换为PWM控制量
 * @param[in,out] p_led     [输出的LED PWM控制量]
 * @param[in]     temp      [色温]
 * @param[in]     bright    [亮度]
 */
static void set_led_kl_to_pwm(pwm_data_t *p_led, uint8_t temp, uint8_t bright)
{
    float ofs_b;
    if (0 == bright)
    {
        ofs_b = 0.0f;
    }
    else
    {
        ofs_b = ((float)bright / 100.0f) * (BULB_W_MAX_PERCENT - BULB_W_MIN_PERCENT) + BULB_W_MIN_PERCENT;
    }

#if BULB_WHITE_IS_CW == 1
    uint16_t pwm_cold = temp * ofs_b * BULB_PWM_MAX_SCALE / 10000;
    uint16_t pwm_warm = (BULB_TEMP_MAX - temp) * ofs_b * BULB_PWM_MAX_SCALE / 10000;
#elif BULB_WHITE_IS_CW == 0
    // CCT控制亮度的PWM路
    uint16_t pwm_cold = ofs_b / 100 * BULB_PWM_MAX_SCALE;
    // CCT控制色温的PWM路
#if BULB_CCT_TEMP_INVERT == 0
    uint16_t pwm_warm = temp * BULB_PWM_MAX_SCALE / 100;
#elif BULB_CCT_TEMP_INVERT == 1
    uint16_t pwm_warm = (BULB_TEMP_MAX - temp) * BULB_PWM_MAX_SCALE / 100;
#else
#error "BULB_CCT_TEMP_INVERT is invalid"
#endif /* BULB_CCT_TEMP_INVERT */
#else
#error "BULB_WHITE_IS_CW is invalid"
#endif /* BULB_WHITE_IS_CW */

    // 最大量程限制
    p_led->r = 0;
    p_led->g = 0;
    p_led->b = 0;
    p_led->c = (pwm_cold >= BULB_PWM_MAX_SCALE) ? (BULB_PWM_MAX_SCALE - 1) : pwm_cold;
    p_led->w = (pwm_warm >= BULB_PWM_MAX_SCALE) ? (BULB_PWM_MAX_SCALE - 1) : pwm_warm;
#if 0
    APP_LOG(LOG_DEBUG, "CWW: bright[%d], ofs_bright[%d]\n", bright, (uint8_t)ofs_b);
    APP_LOG(LOG_DEBUG, "PWM calculate result: C[%d], W[%d]\n", p_led->cold, p_led->warm);
#endif
}

/**
 * @brief 状态上报定时器
 * @param[in]   arg         [传入的状态变更原因字符串]
 */
static void status_report_timer_cb(void *arg)
{
    const char *src_type = (const char *)arg;
    bulb_report_status_change(src_type);
}

void bulb_status_init(void)
{
    int ret;

#if BULB_DRIVER_TYPE == BULB_DRV_BY_BP5758
    ret = vdrv_bp5758d_init(BULB_I2C_SDA_IO, BULB_I2C_SCL_IO);
    if (SDK_OK != ret)
    {
        APP_LOG(LOG_WARN, "bp5758d init fail[%d]\n", ret);
    }
    bp5758_update_range_cfg();
#elif BULB_DRIVER_TYPE == BULB_DRV_BY_LEDC
    vhal_led_timer_cfg_t led_timer_cfg =
        {
            .duty_resolution = (LED_DUTY_RST_E)BULB_LEDC_DUTY_RST_BIT,
            .freq_hz = BULB_LEDC_PWM_FREQ,
        };
    ret = vhal_led_timer_cfg(&led_timer_cfg);
    if (VHAL_OK != ret)
    {
        APP_LOG(LOG_WARN, "led timer cfg fail[%d]\n", ret);
    }

    vhal_led_gpio_cfg_t gpio_cfg[5] =
        {
            {
                .gpio_num = BULB_COLD_OUT_IO,
                .channel = VLED_CW_CH,
                .duty = 0,
            },
            {
                .gpio_num = BULB_WARM_OUT_IO,
                .channel = VLED_WW_CH,
                .duty = 0,
            },
            {
                .gpio_num = BULB_RED_OUT_IO,
                .channel = VLED_R_CH,
                .duty = 0,
            },
            {
                .gpio_num = BULB_GREEN_OUT_IO,
                .channel = VLED_G_CH,
                .duty = 0,
            },
            {
                .gpio_num = BULB_BULE_OUT_IO,
                .channel = VLED_B_CH,
                .duty = 0,
            },
        };
    ret = vhal_led_gpio_cfg(VLED_NUM, gpio_cfg);
    if (VHAL_OK != ret)
    {
        APP_LOG(LOG_WARN, "led gpio cfg fail[%d]\n", ret);
    }
#elif BULB_DRIVER_TYPE == BULB_DRV_BY_SM2235
    // 这个打印是为了增加延迟IIC上电初始化的时间防止初始化失败
    APP_LOG(LOG_INFO, "powered by sm2234egh\n");

    ret = vdrv_sm2235egh_init(BULB_I2C_SDA_IO, BULB_I2C_SCL_IO);
    if (SDK_OK != ret)
    {
        APP_LOG(LOG_WARN, "sm2234egh init fail[%d]\n", ret);
    }
    ret = vdrv_sm2235egh_set_mode(RGBCW_MODE);
    if (SDK_OK != ret)
    {
        APP_LOG(LOG_WARN, "sm2234egh set mode fail[%d]\n", ret);
    }

    uint8_t rgb_cr = BULB_RED_MAX, cw_cr = BULB_COLD_MAX;
    ret = vdrv_sm2235egh_set_cr(&rgb_cr, &cw_cr);
    if (SDK_OK != ret)
    {
        APP_LOG(LOG_WARN, "sm2234egh set cr fail[%d]\n", ret);
    }
#else
#error "BULB_DRIVER_TYPE is invalid"
#endif /* BULB_DRIVER_TYPE */

    ret = vesync_light_init();
    if (ret != SDK_OK)
    {
        APP_LOG(LOG_ERROR, "vesync_light init fail\n");
        return;
    }

    s_light = vesync_light_create(LIGHT_CH_IDX_MAX,
                                  LIGHT_FRAME_PERIOD_MS,
                                  BULB_PWM_MAX_SCALE,
                                  set_driver_output,
                                  NULL);
    if (NULL == s_light)
    {
        APP_LOG(LOG_ERROR, "create light fail\n");
        return;
    }

    vesync_light_set_gamma(s_light, LIGHT_CH_IDX_C, 1);
    vesync_light_set_gamma(s_light, LIGHT_CH_IDX_W, 1);
    vesync_light_set_gamma(s_light, LIGHT_CH_IDX_R, 0.8);
    vesync_light_set_gamma(s_light, LIGHT_CH_IDX_G, 0.6);
    vesync_light_set_gamma(s_light, LIGHT_CH_IDX_B, 0.6);

    uint8_t fade_enable;
    uint16_t fade_speed_ms;
    bulb_status_get_fade_speed(&fade_enable, &fade_speed_ms);
    if (fade_enable != 1)
    {
        s_fade_step_speed = 1.0;
    }
    else
    {
        s_fade_step_speed = (float)LIGHT_FRAME_PERIOD_MS / (float)fade_speed_ms;
    }

    s_vloop_ins = vloop_create("bulb_status", 1024 * 4, TASK_PRIORITY_LOW, 10);
    if (NULL == s_vloop_ins)
    {
        APP_LOG(LOG_ERROR, "create vloop fail\n");
        return;
    }

    s_report_timer = vloop_timer_new(s_vloop_ins,
                                    "up_stat_time",
                                    status_report_timer_cb,
                                    s_report_src_buf,
                                    STATUS_REPORT_DELAY_MS,
                                    false);
    if (NULL == s_report_timer)
    {
        APP_LOG(LOG_ERROR, "create timer fail\n");
        return;
    }
}

static void status_set_led_output(pwm_data_t *led_pwm, float speed)
{
    vesync_light_fade_with_step_cfg(s_light, LIGHT_CH_IDX_C, ((float)led_pwm->c) / BULB_PWM_MAX_SCALE, speed, 0);
    vesync_light_fade_with_step_cfg(s_light, LIGHT_CH_IDX_W, ((float)led_pwm->w) / BULB_PWM_MAX_SCALE, speed, 0);
    vesync_light_fade_with_step_cfg(s_light, LIGHT_CH_IDX_R, ((float)led_pwm->r) / BULB_PWM_MAX_SCALE, speed, 0);
    vesync_light_fade_with_step_cfg(s_light, LIGHT_CH_IDX_G, ((float)led_pwm->g) / BULB_PWM_MAX_SCALE, speed, 0);
    vesync_light_fade_with_step_cfg(s_light, LIGHT_CH_IDX_B, ((float)led_pwm->b) / BULB_PWM_MAX_SCALE, speed, 0);

    vesync_light_start(s_light, LIGHT_CH_IDX_C);
    vesync_light_start(s_light, LIGHT_CH_IDX_W);
    vesync_light_start(s_light, LIGHT_CH_IDX_R);
    vesync_light_start(s_light, LIGHT_CH_IDX_G);
    vesync_light_start(s_light, LIGHT_CH_IDX_B);
}

static void status_set_led_blink(pwm_data_t *led_pwm, uint32_t period, uint32_t period_nbr)
{
    vesync_light_blink_cfg(s_light, LIGHT_CH_IDX_C, ((float)led_pwm->c) / BULB_PWM_MAX_SCALE, period, 0, period_nbr * 2);
    vesync_light_blink_cfg(s_light, LIGHT_CH_IDX_W, ((float)led_pwm->w) / BULB_PWM_MAX_SCALE, period, 0, period_nbr * 2);
    vesync_light_blink_cfg(s_light, LIGHT_CH_IDX_R, ((float)led_pwm->r) / BULB_PWM_MAX_SCALE, period, 0, period_nbr * 2);
    vesync_light_blink_cfg(s_light, LIGHT_CH_IDX_G, ((float)led_pwm->g) / BULB_PWM_MAX_SCALE, period, 0, period_nbr * 2);
    vesync_light_blink_cfg(s_light, LIGHT_CH_IDX_B, ((float)led_pwm->b) / BULB_PWM_MAX_SCALE, period, 0, period_nbr * 2);

    vesync_light_start(s_light, LIGHT_CH_IDX_C);
    vesync_light_start(s_light, LIGHT_CH_IDX_W);
    vesync_light_start(s_light, LIGHT_CH_IDX_R);
    vesync_light_start(s_light, LIGHT_CH_IDX_G);
    vesync_light_start(s_light, LIGHT_CH_IDX_B);
}

static void status_set_led_breath(pwm_data_t *led_pwm, uint32_t period, uint32_t period_nbr)
{
    vesync_light_breath_cfg(s_light, LIGHT_CH_IDX_C, ((float)led_pwm->c) / BULB_PWM_MAX_SCALE, period, 0, period_nbr * 2);
    vesync_light_breath_cfg(s_light, LIGHT_CH_IDX_W, ((float)led_pwm->w) / BULB_PWM_MAX_SCALE, period, 0, period_nbr * 2);
    vesync_light_breath_cfg(s_light, LIGHT_CH_IDX_R, ((float)led_pwm->r) / BULB_PWM_MAX_SCALE, period, 0, period_nbr * 2);
    vesync_light_breath_cfg(s_light, LIGHT_CH_IDX_G, ((float)led_pwm->g) / BULB_PWM_MAX_SCALE, period, 0, period_nbr * 2);
    vesync_light_breath_cfg(s_light, LIGHT_CH_IDX_B, ((float)led_pwm->b) / BULB_PWM_MAX_SCALE, period, 0, period_nbr * 2);

    vesync_light_start(s_light, LIGHT_CH_IDX_C);
    vesync_light_start(s_light, LIGHT_CH_IDX_W);
    vesync_light_start(s_light, LIGHT_CH_IDX_R);
    vesync_light_start(s_light, LIGHT_CH_IDX_G);
    vesync_light_start(s_light, LIGHT_CH_IDX_B);
}

/**
 * @brief 音乐模式1的帧更新回调
 * @param[in] arg           [当arg为NULL时，通常是一次初始化调用]
 */
static void music_m1_frame_update_cb(void *arg)
{
    pwm_data_t led_pwm;
#if 0
    uint32_t frame = 0;
    if (arg != NULL)
    {
        float rms_ratio = *(float *)arg;

        frame = rms_ratio * (BULB_HSV_GRAD_WHITE_TBL_LEN - 1);
        if (frame > (BULB_HSV_GRAD_WHITE_TBL_LEN - 1))
        {
            frame = BULB_HSV_GRAD_WHITE_TBL_LEN - 1;
        }
    }

    set_led_hsv_to_rgb(&led_pwm,
                       g_hsv_grad_white_tbl[frame]->hue,
                       g_hsv_grad_white_tbl[frame]->saturation,
                       g_hsv_grad_white_tbl[frame]->value);
#else
    float rms_ratio = BULB_W_HALF_BRIGHT;
    if (arg != NULL)
    {
        rms_ratio = (*(float *)arg * 100);
    }

    set_led_kl_to_pwm(&led_pwm, BULB_W_MODEST, (uint8_t)rms_ratio);
#endif
    status_set_led_output(&led_pwm, 0.1);
}

/**
 * @brief 音乐模式2、3的帧更新回调
 * @param[in] arg           [当arg非NULL时，通常是一次初始化调用，将传入初始化的音效模式参数]
 */
static void music_m2_3_frame_update_cb(void *arg)
{
    static uint8_t frame_cnt = 0;

    s_is_music_m2_3_yield = true;

    uint8_t effect;
    if (arg != NULL)
    {
        effect = *((uint8_t *)arg);
    }
    else
    {
        effect = bulb_flash_get_cfg(BULB_CFG_EFFECT);
    }

    pwm_data_t led_pwm;
    switch (effect)
    {
    case BULB_CFG_EFFECT_MODE_2:
        // fall-through
    case BULB_CFG_EFFECT_MODE_3:
        if (frame_cnt >= (BULB_HSV_RAINBOW_TBL_LEN))
        {
            frame_cnt = 0;
        }
        set_led_hsv_to_rgb(&led_pwm,
                           g_hsv_rainbow_tbl[frame_cnt]->hue,
                           g_hsv_rainbow_tbl[frame_cnt]->saturation,
                           g_hsv_rainbow_tbl[frame_cnt]->value);
        frame_cnt++;
        break;
    default:
        break;
    }
    status_set_led_output(&led_pwm, 0.1);
}

/**
 * @brief 将status应用到灯光控制中
 * @param[in]   p_data      [指向输入的LED状态参数]
 * @return      int         [成功：APP_OK， 失败：APP_FAIL]
 */
static int status_apply(bulb_status_t *p_data)
{
    if (NULL != s_dynamic_effect_timer)
    {
        vloop_timer_free(s_vloop_ins, s_dynamic_effect_timer);
        s_dynamic_effect_timer = NULL;
    }

    pwm_data_t led_pwm = STATUS_PWM_INIT_VALUE;
    float fade_speed = STATUS_UPDATE_FADE_SPEED;
    if (false == s_is_open_actually)
    {
        fade_speed = s_fade_step_speed;
    }
    s_is_open_actually = p_data->enable;

    if (false == p_data->enable)
    {
        status_set_led_output(&led_pwm, s_fade_step_speed);
        return APP_OK;
    }

    switch (p_data->mode)
    {
    case BULB_CFG_COLOR_MODE_WHITE:
        set_led_kl_to_pwm(&led_pwm, p_data->white.color_temp, p_data->white.brightness);
        status_set_led_output(&led_pwm, fade_speed);
        break;
    case BULB_CFG_COLOR_MODE_HSV:
        set_led_hsv_to_rgb(&led_pwm, p_data->hsv.hue, p_data->hsv.saturation, p_data->hsv.value);
        status_set_led_output(&led_pwm, fade_speed);
        break;
    case BULB_CFG_COLOR_MODE_PHONE_MUSIC:
        // fall-through
    case BULB_CFG_COLOR_MODE_PHONE_MIC:
        switch (p_data->effect)
        {
        case BULB_CFG_EFFECT_MODE_1:
            music_m1_frame_update_cb(NULL);
            break;
        case BULB_CFG_EFFECT_MODE_2:
            // fall-through
        case BULB_CFG_EFFECT_MODE_3:
            // 先把灯效切换过来
            music_m2_3_frame_update_cb(&p_data->effect);
            // 启动后继灯效循环切换的定时器
            s_dynamic_effect_timer = vloop_timer_new(s_vloop_ins,
                                                     "music_timer",
                                                     music_m2_3_frame_update_cb,
                                                     NULL,
                                                     s_music_speed_ms,
                                                     true);
            if (NULL == s_dynamic_effect_timer)
            {
                APP_LOG(LOG_ERROR, "create music timer fail\n");
                return APP_FAIL;
            }
            vloop_timer_start(s_vloop_ins, s_dynamic_effect_timer);
            break;
        default:
            break;
        }
        break;
    case BULB_CFG_COLOR_MODE_SCENARIO:
    {
        bulb_scene_t scene;
        int ret = bulb_scene_restore(p_data->scene_id, &scene);
        if (ret != APP_OK)
        {
            APP_LOG(LOG_ERROR, "restore scene fail\n");
            return APP_FAIL;
        }
        switch (scene.type)
        {
        case SCENE_TYPE_WHITE:
            set_led_kl_to_pwm(&led_pwm, scene.param.white.color_temp, scene.param.white.brightness);
            status_set_led_output(&led_pwm, fade_speed);
            break;
        case SCENE_TYPE_COLOR:
            set_led_hsv_to_rgb(&led_pwm, scene.param.hsv.hue, scene.param.hsv.saturation, scene.param.hsv.value);
            status_set_led_output(&led_pwm, fade_speed);
            break;
        case SCENE_TYPE_DYNAMIC:
            s_dynamic_effect_timer = vloop_timer_new(s_vloop_ins,
                                                     "scene_timer",
                                                     scene.param.dynamic_cb,
                                                     &s_dynamic_effect_timer,
                                                     50,
                                                     false);
            if (NULL == s_dynamic_effect_timer)
            {
                APP_LOG(LOG_ERROR, "create scene timer fail\n");
                return APP_FAIL;
            }
            vloop_timer_start(s_vloop_ins, s_dynamic_effect_timer);
            break;
        default:
            return APP_FAIL;
        }
        break;
    }
    default:
        return APP_FAIL;
    }
    return APP_OK;
}

int bulb_status_fetch(bulb_status_t *p_data)
{
    if (NULL == p_data)
    {
        return APP_FAIL;
    }

    p_data->enable = bulb_flash_get_cfg(BULB_CFG_ONOFF);
    p_data->mode = bulb_flash_get_cfg(BULB_CFG_COLOR_MODE);
    p_data->white.brightness = bulb_flash_get_cfg(BULB_CFG_COLOR_BRIGHT);
    p_data->white.color_temp = bulb_flash_get_cfg(BULB_CFG_COLOR_TEMP);
    p_data->hsv.hue = bulb_flash_get_cfg(BULB_CFG_COLOR_HUE);
    p_data->hsv.saturation = bulb_flash_get_cfg(BULB_CFG_COLOR_SATURATION);
    p_data->hsv.value = bulb_flash_get_cfg(BULB_CFG_COLOR_VALUE);
    p_data->sensitive.type = bulb_flash_get_cfg(BULB_CFG_SENSITIVE_TYPE);
    p_data->sensitive.value = bulb_flash_get_cfg(BULB_CFG_SENSITIVE_VALUE);
    p_data->effect = bulb_flash_get_cfg(BULB_CFG_EFFECT);
    p_data->scene_id = bulb_flash_get_cfg(BULB_CFG_SCENE_ID);
    return APP_OK;
}

int bulb_status_update(bulb_status_t *p_data)
{
    if (NULL == p_data)
    {
        return APP_FAIL;
    }
    if (APP_OK != status_apply(p_data))
    {
        return APP_FAIL;
    }
    bulb_flash_upd_cfg(BULB_CFG_ONOFF, p_data->enable);
    bulb_flash_upd_cfg(BULB_CFG_COLOR_MODE, p_data->mode);
    bulb_flash_upd_cfg(BULB_CFG_COLOR_BRIGHT, p_data->white.brightness);
    bulb_flash_upd_cfg(BULB_CFG_COLOR_TEMP, p_data->white.color_temp);
    bulb_flash_upd_cfg(BULB_CFG_COLOR_HUE, p_data->hsv.hue);
    bulb_flash_upd_cfg(BULB_CFG_COLOR_SATURATION, p_data->hsv.saturation);
    bulb_flash_upd_cfg(BULB_CFG_COLOR_VALUE, p_data->hsv.value);
    bulb_flash_upd_cfg(BULB_CFG_SENSITIVE_TYPE, p_data->sensitive.type);
    bulb_flash_upd_cfg(BULB_CFG_SENSITIVE_VALUE, p_data->sensitive.value);
    bulb_flash_upd_cfg(BULB_CFG_EFFECT, p_data->effect);
    bulb_flash_upd_cfg(BULB_CFG_SCENE_ID, p_data->scene_id);
    // Flush the updated config to flash
    bulb_flash_flush_cfg();
    return APP_OK;
}

int bulb_status_update_and_report(bulb_status_t *p_data, const char *src_type)
{
    if (APP_OK != bulb_status_update(p_data))
    {
        return APP_FAIL;
    }

    if (strlen(src_type) > 0)
    {
        // Buffer the source type string
        snprintf(s_report_src_buf, MAX_STAT_CHG_RSN_STR_LEN, "%s", src_type);
        // Report status change
        vloop_timer_change_period(s_vloop_ins,
                                  s_report_timer,
                                  STATUS_REPORT_DELAY_MS);
    }
    return APP_OK;
}

int bulb_status_set_fade_speed(uint8_t enable, uint16_t ms_100_percent)
{
    if (enable != 1)
    {
        bulb_flash_upd_cfg(BULB_CFG_FADE_ENABLE, 0);
        s_fade_step_speed = 1.0;
    }
    else
    {
        // 0 < fade_ms_100_percent < 60s
        if (ms_100_percent > 60000)
        {
            return APP_FAIL;
        }
        bulb_flash_upd_cfg(BULB_CFG_FADE_ENABLE, 1);
        bulb_flash_upd_cfg(BULB_CFG_FADE_SPEED_MS, ms_100_percent);
        s_fade_step_speed = (float)LIGHT_FRAME_PERIOD_MS / (float)ms_100_percent;
        APP_LOG(LOG_DEBUG, "update fade step speed:%f\n", s_fade_step_speed);
    }
    bulb_flash_flush_cfg();
    return APP_OK;
}

int bulb_status_get_fade_speed(uint8_t *p_enable, uint16_t *p_ms_100_percent)
{
    if (NULL == p_enable || NULL == p_ms_100_percent)
    {
        return APP_FAIL;
    }
    *p_enable = bulb_flash_get_cfg(BULB_CFG_FADE_ENABLE);
    *p_ms_100_percent = bulb_flash_get_cfg(BULB_CFG_FADE_SPEED_MS);
    return APP_OK;
}

/**
 * @brief 更新音乐模式定时器的速度
 * @param[in]   rms         [控制速度的音乐强度]
 * @param[in]   sensitive   [灵敏度参数]
 */
static void status_update_music_speed(float rms, float sensitive)
{
    float rms_thrd_up = BULB_MUSIC_RMS_THRESHOLD_UP_MAX;
    float rms_thrd_dn = BULB_MUSIC_RMS_THRESHOLD_DN_MAX;

    float ratio = (rms - rms_thrd_dn) / (rms_thrd_up - rms_thrd_dn);
    if (ratio > 1)
    {
        ratio = 1;
    }
    else if (ratio < 0)
    {
        ratio = 0;
    }

    // Offset by sensitive
    float ofs_ratio = sensitive / 100.0 * (1 - ratio);

    uint16_t new_speed;
    new_speed = (BULB_MUSIC_SPEED_SLOWEST_MS - BULB_MUSIC_SPEED_FASTEST_MS) * ofs_ratio;
    new_speed += BULB_MUSIC_SPEED_FASTEST_MS;

#if 0
    APP_LOG(LOG_DEBUG, "ratio:%f, ofs_ratio:%f\n", ratio, ofs_ratio);
    APP_LOG(LOG_DEBUG, "sensitive(offset):%f, rms:%f, music_speed:%d\n", sensitive, rms, new_speed);
#endif

    if ((new_speed != s_music_speed_ms) && (true == s_is_music_m2_3_yield))
    {
        s_is_music_m2_3_yield = false;
        s_music_speed_ms = new_speed;
        vloop_timer_change_period(s_vloop_ins, s_dynamic_effect_timer, s_music_speed_ms);
    }
}

int bulb_status_update_music_param(bulb_status_fft_info_t *p_fft, bulb_status_rms_info_t *p_rms)
{
    // APP下发的sensitive参数属于[1, 100]
    float sensitive = 101.0 - (float)bulb_flash_get_cfg(BULB_CFG_SENSITIVE_VALUE);

    switch (bulb_flash_get_cfg(BULB_CFG_EFFECT))
    {
    case BULB_CFG_EFFECT_MODE_1:
        if (p_rms != NULL)
        {
            float rms_ratio = (float)p_rms->rms / (sensitive * BULB_MUSIC_RMS_THRESHOLD_UP_MAX / 100);
            music_m1_frame_update_cb(&rms_ratio);
#if 0
            APP_LOG(LOG_DEBUG, "rms_ratio:%f\n", rms_ratio);
#endif
        }
        break;
    case BULB_CFG_EFFECT_MODE_2:
        if (p_rms != NULL)
        {
            status_update_music_speed((float)p_rms->rms, sensitive);
        }
        break;
    case BULB_CFG_EFFECT_MODE_3:
        if (p_fft != NULL)
        {
            uint32_t pick_cnt = 0;
            uint32_t amp_sum = 0;
            for (int i = 0; i < BULB_MUSIC_FREQ_SEG_NBR; i++)
            {
                if (p_fft->freq[i] > BULB_MUSIC_FREQ_HIGH_RANGE)
                {
                    amp_sum += p_fft->amp[i];
                    pick_cnt++;
                }
            }
            amp_sum /= pick_cnt;
#if 0
            APP_LOG(LOG_DEBUG, "high_area avg. amp:%u\n", amp_sum);
#endif
            status_update_music_speed((float)amp_sum, sensitive);
        }
        break;
    default:
        break;
    }
    return APP_OK;
}

int bulb_status_timer_change_period(vesync_timer_t *timer, long timeout_ms)
{
    if (SDK_OK == vloop_timer_change_period(s_vloop_ins, timer, timeout_ms))
    {
        return APP_OK;
    }
    return APP_FAIL;
}

int bulb_status_direct_set_hsv(const bulb_status_hsv_t *p_hsv, float step_speed)
{
    pwm_data_t led_pwm;
    set_led_hsv_to_rgb(&led_pwm, p_hsv->hue, p_hsv->saturation, p_hsv->value);
    status_set_led_output(&led_pwm, step_speed);
    return APP_OK;
}

int bulb_status_direct_set_white(const bulb_status_white_t *p_white, float step_speed)
{
    pwm_data_t led_pwm;
    set_led_kl_to_pwm(&led_pwm, p_white->color_temp, p_white->brightness);
    status_set_led_output(&led_pwm, step_speed);
    return APP_OK;
}

int bulb_status_direct_set_hsv_blink(const bulb_status_hsv_t *p_hsv, uint32_t period, uint32_t period_nbr)
{
    pwm_data_t led_pwm;
    set_led_hsv_to_rgb(&led_pwm, p_hsv->hue, p_hsv->saturation, p_hsv->value);
    status_set_led_blink(&led_pwm, period, period_nbr);
    return APP_OK;
}

int bulb_status_direct_set_white_blink(const bulb_status_white_t *p_white, uint32_t period, uint32_t period_nbr)
{
    pwm_data_t led_pwm;
    set_led_kl_to_pwm(&led_pwm, p_white->color_temp, p_white->brightness);
    status_set_led_blink(&led_pwm, period, period_nbr);
    return APP_OK;
}

int bulb_status_direct_set_hsv_breath(const bulb_status_hsv_t *p_hsv, uint32_t period, uint32_t period_nbr)
{
    pwm_data_t led_pwm;
    set_led_hsv_to_rgb(&led_pwm, p_hsv->hue, p_hsv->saturation, p_hsv->value);
    status_set_led_breath(&led_pwm, period, period_nbr);
    return APP_OK;
}

int bulb_status_direct_set_white_breath(const bulb_status_white_t *p_white, uint32_t period, uint32_t period_nbr)
{
    pwm_data_t led_pwm;
    set_led_kl_to_pwm(&led_pwm, p_white->color_temp, p_white->brightness);
    status_set_led_breath(&led_pwm, period, period_nbr);
    return APP_OK;
}