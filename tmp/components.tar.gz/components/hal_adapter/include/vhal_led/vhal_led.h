/**
*Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file    vhal_led.h
* @brief   led接口封装
* @author  Lind
*@date     2021-08-30
*/

#ifndef _VHAL_LED_H_
#define _VHAL_LED_H_

#include <stdint.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C"
{
#endif


/**
 * @brief PWM占空比分辨率
 */
typedef enum
{
    LED_DUTY_RST_1_BIT = 1,   /*!< LED PWM duty resolution of  1 bits */
    LED_DUTY_RST_2_BIT,       /*!< LED PWM duty resolution of  2 bits */
    LED_DUTY_RST_3_BIT,       /*!< LED PWM duty resolution of  3 bits */
    LED_DUTY_RST_4_BIT,       /*!< LED PWM duty resolution of  4 bits */
    LED_DUTY_RST_5_BIT,       /*!< LED PWM duty resolution of  5 bits */
    LED_DUTY_RST_6_BIT,       /*!< LED PWM duty resolution of  6 bits */
    LED_DUTY_RST_7_BIT,       /*!< LED PWM duty resolution of  7 bits */
    LED_DUTY_RST_8_BIT,       /*!< LED PWM duty resolution of  8 bits */
    LED_DUTY_RST_9_BIT,       /*!< LED PWM duty resolution of  9 bits */
    LED_DUTY_RST_10_BIT,      /*!< LED PWM duty resolution of 10 bits */
    LED_DUTY_RST_11_BIT,      /*!< LED PWM duty resolution of 11 bits */
    LED_DUTY_RST_12_BIT,      /*!< LED PWM duty resolution of 12 bits */
    LED_DUTY_RST_13_BIT,      /*!< LED PWM duty resolution of 13 bits */
} LED_DUTY_RST_E;

/**
 * @brief LED PWM控制通道
 */
typedef enum
{
    LED_CH0 = 0,
    LED_CH1,
    LED_CH2,
    LED_CH3,
    LED_CH4,
    LED_CH5,
} LED_CHANNEL_E;

/**
 * @brief pwm的timer配置
 */
typedef struct
{
    LED_DUTY_RST_E duty_resolution;  // pwm占空比分辨率
    uint32_t freq_hz;                // pwm频率
} vhal_led_timer_cfg_t;

/**
 * @brief PWM占空比分辨率
 */
typedef struct
{
    uint8_t gpio_num;           // 输出管脚
    LED_CHANNEL_E channel;      // pwm通道
    uint16_t duty;              // 占空比
    bool invert_flag;           // 输出翻转使能
} vhal_led_gpio_cfg_t;

/**
* @brief led的timer配置
* @param[in]  pst_led_timer     [timer配置参数]
* @return  uint32_t             [配置结果 VHAL_OK/VHAL_FAIL]
*/
uint32_t vhal_led_timer_cfg(vhal_led_timer_cfg_t *pst_led_timer);

/**
* @brief 初始化配置led gpio
* @param[in]  pin_num           [初始化配置的LED gpio个数]
* @param[in]  *pst_gpio_cfg     [gpio配置结构体数组]
* @return  uint32_t             [VHAL_OK/VHAL_FAIL]
*/
uint32_t vhal_led_gpio_cfg(uint8_t pin_num, vhal_led_gpio_cfg_t *pst_gpio_cfg);

/**
* @brief  设置LED通道占空比(100分辨率)
* @param[in]  e_channel         [led通道枚举变量]
* @param[in]  duty              [100分辨率的占空比]
*/
void vhal_led_set_duty(LED_CHANNEL_E e_channel, uint16_t duty);

/**
* @brief  设置LED通道占空比(指定分辨率)
* @param[in]  e_channel     [led通道枚举变量]
* @param[in]  duty          [实际分辨率的占空比]
* @param[in]  duty_rst      [占空比分辨率]
*/
void vhal_led_set_duty_bits(LED_CHANNEL_E e_channel, uint16_t duty, uint16_t duty_rst);

/**
* @brief 使能渐变功能
*/
void vhal_led_fade_enable(void);

/**
* @brief 失能渐变功能
*/
void vhal_led_fade_disable(void);

/**
* @brief 按渐变步长渐变
* @param[in]  e_channel         [渐变通道]
* @param[in]  target_duty       [目标占空比，实际占空比]
* @param[in]  scale             [渐变步长]
* @param[in]  cycle_num         [每次改变占空比的周期数，越大渐变速度越慢]
* @return     int               [VHAL_OK/VHAL_FAIL]
*/
int vhal_led_fade_by_step(LED_CHANNEL_E e_channel, uint32_t target_duty, uint32_t scale, uint32_t cycle_num);

/**
* @brief 在设定时间内完成渐变，设置后，该通道不能中途停止
* @param[in]  e_channel         [渐变通道]
* @param[in]  target_duty       [目标占空比，实际占空比]
* @param[in]  max_fade_time     [最大渐变时间,毫秒]
* @return  int                  [VHAL_OK/VHAL_FAIL]
*/
int vhal_led_fade_by_time(LED_CHANNEL_E e_channel, uint32_t target_duty, uint32_t max_fade_time);

/**
 * @brief 设置LED控制器频率
 * @param[in] pst_led_timer     [timer配置参数]
 * @return int                  [VHAL_OK/VHAL_FAIL]
 */
int vhal_led_set_freq(vhal_led_timer_cfg_t *pst_led_timer);

#ifdef __cplusplus
}
#endif

#endif /* _VHAL_LED_H_ */

