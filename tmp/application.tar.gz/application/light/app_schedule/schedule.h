/**
* Copyright © Vesync Technologies Co.Ltd. 2022. All rights reserved
* @file         schedule.h
* @brief        schedule处理接口
* @author       Joshua
* @date         2022-2-24
*/

#include <stdint.h>
#include "vesync_common.h"
#include "vesync_buffer.h"
#include "light.h"

#ifndef __APP_SCHEDULE_H__
#define __APP_SCHEDULE_H__

#ifdef __cplusplus
extern "C" {
#endif

#define LIGHT_SCHE_MIN_ID (100)             // Schedule最小ID
#define LIGHT_SCHE_MAX_NUM (26)             // Schedule最大条目数
#define LIGHT_SCHE_GET_MAX_NUM (6)          // 一次Schedule查询最大的返回数量
#define LIGHT_SCHE_MAX_APP_CFG_SIZE (64)    // 配置读取Buffer大小
#define LIGHT_SCHE_INS_ID (0)               // Schedule实例ID

typedef enum
{
    SCHE_KEY_VERSION = 0,         // 版本
    SCHE_KEY_ONOFF,               // 开关状态
    SCHE_KEY_COLOR_MODE,          // 色彩模式
    SCHE_KEY_COLOR_PARAM,         // 彩色参数
    SCHE_KEY_SCENE_ID,            // 场景ID
} SCHE_CFG_KEY_E;


typedef struct
{
    uint8_t onoff;
    uint8_t color_mode;
    light_param_t light_param;
    uint16_t scene_id;
    uint16_t music_id;
} action_cfg_t;

/**
* @brief 初始化Schedule功能
* @return int  [返回APP的错误定义： APP_OK, APP_FAIL]
*/
int app_schedule_init(void);

/**
* @brief Bypass删除指定ID的Schedule配置项
* @param[in]  id        [要删除的Schedule配置项ID]
* @return int           [返回BYPASS的错误定义]
*/
int app_schedule_del(uint32_t id);

/**
* @brief App层调用，复位Schedule的所有配置信息
* @return int [返回APP的错误定义： APP_OK, APP_FAIL]
*/
int app_schedule_clear(void);

/**
* @brief 将schedule应用层数据转为klv格式
* @param[out]  *p_buf       [存入的buf]
* @param[in]  p_cfg       [应用层数据]
*/
int light_sche_klv_buf_set(vesync_buf_t *p_cfg_buf, action_cfg_t *p_cfg);

/**
* @brief 将klv格式的schedule应用层数据读出
* @param[in]  *p_app_buf    [要读取的buf]
* @param[out]  *p_p_cfg   [应用层数据]
*/
void light_sche_klv_buf_get(vesync_buf_t *p_app_buf, action_cfg_t *p_cfg);
#ifdef __cplusplus
}
#endif

#endif

