/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_timebase_private.h
 * @brief       Timebase模块内部接口定义
 * @author      Herve.lin, Niki
 * @date        2021-08-18
 */

#ifndef __VESYNC_TIMEBASE_PRIVATE_H__
#define __VESYNC_TIMEBASE_PRIVATE_H__

#include <stdint.h>
#include <stdbool.h>

#include "vesync_list.h"
#include "vesync_timer.h"
#include "vesync_mutex.h"

#include "vesync_timebase_internal.h"
#include "vesync_cfg_internal.h"

#ifdef __cplusplus
extern "C"
{
#endif

#define TIMEBASE_DEBUG_PRINT 0                                         // Timebase 模块内部调试打印开关宏
#define TIMEBASE_CFG_VERSION (PR_TIMEBASE_CFG_VERSION)                 // Timebase 配置版本定义
#define TIMEBASE_SUNTIME_EXPIRE_PERIOD_SEC (172800)                    // 当前时间戳比缓存的太阳日出或日落时间大多少秒就发起更新请求
#define TIMEBASE_DST_REQ_AFTER_SW_SEC (86400)                          // 当前时间戳比缓存的DST切换时间大多少秒就发起更新请求
#define TIMEBASE_NO_BYPASS_MSG_MAX_STR_LEN (512)                       // 允许处理的最大No Bypass消息长度
#define TIMEBASE_CYCLE_TIMER_INTERVAL (10000)                          // 定时器轮询间隔
#define TIMEBASE_INVALID_MINUTE (0xFF)                                 // 非法的分钟数定义，用于分钟类计数的初始化
#define TIMEBASE_UPDATE_UTC_PERIOD (PR_TIMEBASE_UPDATE_UTC_PERIOD)     // Timebase发起时间校准的最小周期设置，不同的SOC有不同的要求
#define TIMEBASE_REQUEST_UTC_PERIOD (PR_TIMEBASE_REQUEST_UTC_PERIOD)   // 如果连续向云端请求时间戳，这是最小周期的限制
#define TIMEBASE_SNTP_EXPIRED_DURING (PR_TIMEBASE_SNTP_EXPIRED_DURING) // 判断SNTP校时已经失效的时间间隔
#define TIMEBASE_MGT_INIT_VAL {is_init:false, mutex:NULL}              // Timebase管理结构体初始化值
#define TIMEBASE_DEFAULT_USER_CFG_KEY "sche_tb_mod"                    // Timebase模块配置存储KEY

// 时基信息请求的最小周期限制（控制请求重试的频率）
#ifdef PR_TIMEBASE_INFO_MIN_REQ_PERIOD_SEC
#define TIMEBASE_INFO_MIN_REQ_PERIOD_SEC (PR_TIMEBASE_INFO_MIN_REQ_PERIOD_SEC)
#else
#define TIMEBASE_INFO_MIN_REQ_PERIOD_SEC (120)
#endif /* PR_TIMEBASE_INFO_MIN_REQ_PERIOD_SEC */

// 检查Repeat是否置位，如果是则返回true
#define CHECK_REPEAT_BIT_SET(repeat, bit_enum) \
    do                                         \
    {                                          \
        if (repeat & bit_enum)                 \
        {                                      \
            return true;                       \
        }                                      \
    } while (0)

/**
 * @brief 时基配置信息key定义
 */
typedef enum
{
    TIME_BASE_VERSION = 0,                       // 配置数据版本
    TIME_ZONE_KEY_NAME = 1,                      // 时区名字
    TIME_ZONE_KEY_OFFSET = 2,                    // 时区偏移值
    TIME_SUN_RISE_SET_KEY_LONGITUDE = 3,         // 经度
    TIME_SUN_RISE_SET_KEY_LATITUDE = 4,          // 纬度
    TIME_SUN_RISE_SET_KEY_ALTITUDE = 5,          // 高度
    TIME_SUN_RISE_SET_KEY_RISE_TIME = 6,         // 日出时间
    TIME_SUN_RISE_SET_KEY_SET_TIME = 7,          // 日落时间
    TIME_WINTER_SUMMER_KEY_ENABLED = 8,          // 冬夏令时是否有效
    TIME_WINTER_SUMMER_KEY_CUR_OFFSET_SEC = 9,   // 当前本地区冬夏令时的基于秒的偏移参数
    TIME_WINTER_SUMMER_KEY_NEXT_OFFSET_SEC = 10, // 下一期本地区冬夏令时的基于秒的偏移参数
    TIME_WINTER_SUMMER_KEY_SW_UTC = 11,          // 接下来的本地区冬夏令时切换的UTC时间
    TIME_BASE_KEY_MAX
} TIME_BASE_CFG_KEY_E;

/**
 * @brief Timebase 实例
 */
typedef struct
{
    vesync_timer_t *timer;      // Timebase 定时器句柄
    vesync_mutex_t mutex;       // Timebase 实例互斥量
    vesync_timebase_t timebase; // Timebase 数据缓存

    bool is_init;               // Timebase 初始化标志
    bool is_running;            // Timebase 运行状态
} timebase_mgt_t;

/**
 * @brief Timebase内部函数，配置序列化
 * @param[in]  p_timebase           [输入的时间数据]
 * @param[out] p_buf                [输出的Buffer]
 * @param[in]  buf_len              [输出的Buffer的长度]
 * @param[out] p_out_size           [序列化的二进制流的长度]
 * @return int                      [TMBS_RESULT_E]
 */
int tb_cfg_marshal(vesync_timebase_t *p_timebase, uint8_t *p_buf, uint32_t buf_len, uint32_t *p_out_size);

/**
 * @brief Timebase内部函数，配置反序列化
 * @param[in]  p_buf                [输入的二进制流数据]
 * @param[in]  data_len             [输入的二进制流数据的长度]
 * @param[out] p_timebase           [输出的时基数据]
 * @return int                      [TMBS_RESULT_E]
 */
int tb_cfg_unmarshal(uint8_t *p_buf, uint32_t data_len, vesync_timebase_t *p_timebase);

/**
 * @brief Timebase内部函数，订阅Timebase模块依赖的事件
 */
void tb_ev_subscribe_all(void);

/**
 * @brief Timebase模块请求服务器同步时间回调
 * @return int      [TMBS_RESULT_E]
 */
int tb_ev_req_sync_ts_cb(void);

/**
 * @brief Timebase内部函数，时基信息更新请求处理回调
 * @param[in] req_type  [请求的时基类型]
 * @return int          [TMBS_RESULT_E]
 */
int tb_ev_req_upd_tb_info_cb(TMBS_INFO_TYPE_E req_type);

/**
 * @brief Timebase内部函数，解析时基更新回应的JSON，并且更新时基信息
 * @param[in]  json_str [云端消息的Result字段JSON字符串]
 * @param[out] p_tb     [指向要更新的时基数据]
 * @return int          [TMBS_RESULT_E]
 */
int tb_ev_no_bp_tb_info_parse_cb(char *json_str, vesync_timebase_t *p_tb);

/**
 * @brief Timebase内部函数，获取no bypass消息缓存指针的指针
 * @return char **  [指向no bypass消息缓存的指针]
 */
char **tb_get_no_bp_msg_buf_ptr_ref(void);

/**
 * @brief Timebase内部函数，申请时基更新
 * @param[in] type  [申请更新的类型]
 * @return int      [TMBS_RESULT_E]
 */
int tb_req_upd_and_set_flag(TMBS_INFO_TYPE_E type);

/**
 * @brief 比较服务器下发的时间戳，判断是否更新本地时间
 * @param[in]   uint32_t         [时间戳]
 */
void tb_check_or_update_server_ts(uint32_t ts);

/**
 * @brief Timebase内部函数，默认的读取配置回调
 * @param[out] p_rd_buf      [指向数据读取的Buffer]
 * @param[in]  buf_len       [Buffer的长度]
 * @param[out] p_rd_len      [指向储存读取的长度]
 * @return int               [TMBS_RESULT_E]
 */
int tb_default_rd_cfg_cb(uint8_t *p_rd_buf, uint32_t buf_len, uint32_t *p_rd_len);

/**
 * @brief Timebase内部函数，默认的写入配置回调
 * @param[in]  p_wr_buf      [指向被写入的Buffer]
 * @param[in]  len           [将被写入的数据长度]
 * @return int               [TMBS_RESULT_E]
 */
int tb_default_wr_cfg_cb(uint8_t *p_wr_buf, uint32_t len);

#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_TIMEBASE_PRIVATE_H__ */
