/**
 *  Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        hal_ota.c
 * @brief       amebaZ2的ota功能实现
 * @author      Dongri.Su
 * @date        2021-04-23
 */

#include "freertos/FreeRTOS.h"
//#include "freertos/task.h"
#include <netdb.h>
#include "mbedtls/md5.h"
#include <osdep_service.h>
#include "ota_8710c.h"
#include "sys_api.h"

#include "vesync_log.h"
#include "vesync_def.h"

#include "vhal_ota.h"
#include "vhal_ota_internal.h"
#include "vhal_wifi.h"


static vhal_rtl_ota_status_t s_ota_status;          // ota升级进行状态


/*-----------------------------------------------------------------------------*
 *                           内部函数API实现                                         *
 *-----------------------------------------------------------------------------*/

/**
 * @brief  更新OTA升级状态
 * @param[in] status            [ota状态]
 * @param[in] prog              [固件下载进度]
 * @return    void
 */
static void vhal_ota_update_status(VHAL_OTA_STAT_E status, uint8_t prog)
{
    s_ota_status.status = status;
    if (NULL != s_ota_status.status_cb)
    {
        s_ota_status.status_cb(status, prog);
    }
}

/**
 * @brief  更新OTA升级状态
 * @param[in] status            [ota状态]
 * @param[in] prog              [固件下载进度]
 * @return    void
 */
static void vhal_rtl_ota_update_status(uint8_t status, uint8_t prog)
{
    static uint8_t dl_percent = 0;

    if (prog != dl_percent)
    {
        dl_percent = prog;
        if (0 == status)
            vhal_ota_update_status(VHAL_OTA_ST_PROCESS, prog);
    }
    else if (100 == prog)   // 下载完成
    {
        vhal_ota_update_status(VHAL_OTA_ST_DL_COMP, prog);
    }
}

/**
 * @brief  RTL sdk校验vesync添加的头部回调
 * @param[in]  p_header         [vesync添加的头部]
 * @param[in]  len              [vesync添加的头部长度]
 * @return     int              [0表示成功，其他值表示失败]
 */
static int rtl_vhal_ota_check_header_cb(uint8_t *p_header, int len)
{
    //LOG_RAW_HEX(LOG_DEBUG, "RTL OTA:", (uint8_t *)&header, len);
    if (NULL != s_ota_status.header_check_cb)
    {
        return s_ota_status.header_check_cb(p_header, len);
    }
    else
    {
        return -1;
    }
}


/**
 * @brief 从http的URL中提取host和port
 * @param[in]  url              [入参，完整的URL]
 * @param[out] host             [保存host地址]
 * @param[out] file             [保存目录文件]
 * @param[out] port             [保持port]
 * @return     int              [0表示成功，其他值表示失败]
 */
 static int vhal_rtl_ota_parse_url(const char *url, char *host, char *file, char *port)
{
    char *ptr1 = NULL, *ptr2 = NULL;
    int len = 0;

    if(!url || !host || !port || !file)
    {
        PLAT_LOG(LOG_ERROR, "The parameter contains a null pointer!\n");
        return VHAL_FAIL;
    }

    ptr1 = (char *)url;
    // 删除"http://"
    if(!strncmp(ptr1,"http://",strlen("http://")))
    {
        ptr1 += strlen("http://");
    }
    else
    {
        return VHAL_FAIL;
    }

    // 提取host
    ptr2 = strchr(ptr1,'/');    // 查找第一个‘/’所在位置
    if(ptr2)
    {
        len = strlen(ptr1) - strlen(ptr2);
        if(*(ptr2 + 1))
        {
            // 提取file
            memcpy(file, ptr2, strlen(ptr2));
            file[strlen(ptr2)] = '\0';
        }
        else
        {
            memcpy(file, "/", 1);
            *(file + 1) = '\0';
        }
        PLAT_LOG(LOG_DEBUG, "http file: %s\n", file);
    }
    else
    {
        len = strlen(ptr1);
    }
    memcpy(host, ptr1, len);
    host[len] = '\0';
    //PLAT_LOG(LOG_DEBUG, "http host: %s\n", host);

    // 提取port
    ptr1 = strchr(host,':');
    if(ptr1)
    {
        *ptr1++ = '\0';
        memcpy(port, ptr1, strlen(ptr1));
    }
    else
    {
        strncpy(port, "80", strlen("80"));
    }
    PLAT_LOG(LOG_DEBUG, "http port: %s\n", port);
    PLAT_LOG(LOG_DEBUG, "http host: %s\n", host);

    return VHAL_OK;
}

 /**
  * @brief  ota降级处理
  * @return     void
  */
static void vhal_rtl_ota_downgrade(void)
{
    PLAT_LOG(LOG_DEBUG, "amebaZ2 downgrade firm\n");
    //sys_recover_ota_signature();    // 先恢复旧版本的serial号
    sys_clear_ota_signature();      // 清除当前的序列号
}


/*-----------------------------------------------------------------------------*
 *                           外部函数API实现                                         *
 *-----------------------------------------------------------------------------*/

/**
 * @brief  开始OTA升级
 * @param[in]  p_url            [固件下载URL]
 * @param[in]  dg_flag          [true表示进行降级；false表示进行升级]
 * @return     int              [成功返回0，其他值表示失败]
 */
int vhal_ota_start(char *p_url, bool dg_flag)
{
    int ret = VHAL_FAIL, ota_ret = OTA_STAT_FAIL;
    int cnt = 0;
    uint32_t percent = 0;
    char port[8] = {0};
    char host[64] = {0};
    char file[128] = {0};

    // ota状态判断，若为忙的状态，则直接返回
    if (VHAL_OTA_ST_IDLE != s_ota_status.status)
    {
        HAL_LOG(LOG_ERROR, "OTA is busy now, skip!!\n");
        vhal_ota_update_status(VHAL_OTA_ST_PROCESS, percent);
        return VHAL_OK;
    }

    if (NULL == p_url)
    {
        HAL_LOG(LOG_ERROR, "p_url is an null pointer, return!!\n");
        vhal_ota_update_status(VHAL_OTA_ST_FAIL, percent);
        return VHAL_FAIL;
    }
    memset(&s_ota_status, 0, sizeof(vhal_rtl_ota_status_t));

    // 注册头部校验函数
    rtl_ota_check_header_register_cb(rtl_vhal_ota_check_header_cb);      // \sdk\rtl-amebaz2_v7.1c\component\soc\realtek\8710c\misc\platform\ota_8710c.c
    rtl_ota_status_register_cb(vhal_rtl_ota_update_status);

    ret = vhal_rtl_ota_parse_url(p_url, host, file, port);
    if (VHAL_OK == ret)
    {
        while (cnt < 3)    // 最多重复尝试3次
        {
            if (s_ota_status.timeout_flag)      // 超时
            {
                ota_ret = OTA_STAT_TIME_OUT;
                break;
            }

            ota_ret = http_update_ota(host, atoi(port), file);    // 需要修改SDK来支持不同错误类型
            if (ota_ret >= 0)
                break;      // 成功

            vTaskDelay(pdMS_TO_TICKS(50));         // 延时50ms再启动
            cnt += 1;
        }

        if (ota_ret < 0)
        {
            switch(ota_ret)
            {
            case OTA_STAT_ERROR:// 不上报
                break;
            case OTA_STAT_URL_ERR:
                vhal_ota_update_status(VHAL_OTA_ST_URL_ERR, percent);
                break;
            case OTA_STAT_OUT_MEM:
                vhal_ota_update_status(VHAL_OTA_ST_OUT_MEM, percent);
                break;
            case OTA_STAT_TIME_OUT:
                vhal_ota_update_status(VHAL_OTA_ST_TIME_OUT, percent);
                break;
            //case OTA_STAT_MODEL_ILLEGAL:
            //    vhal_ota_update_status(VHAL_OTA_ST_MODEL_ILLEGAL, percent);
            //    break;
            //case OTA_STAT_SW_VER_ERR:
            //    vhal_ota_update_status(VHAL_OTA_ST_SW_VER_ERR, percent);
            //    break;
            //case OTA_STAT_HW_VER_ERR:
            //    vhal_ota_update_status(VHAL_OTA_ST_HW_VER_ERR, percent);
            //    break;
            //case OTA_STAT_COUNTRY_CODE_ERR:
            //    vhal_ota_update_status(VHAL_OTA_ST_COUNTRY_CODE_ERR, percent);
            //    break;
            //case OTA_STAT_MD5_FAIL:
            //    vhal_ota_update_status(VHAL_OTA_ST_MD5_FAIL, percent);
            //    break;
            case OTA_STAT_FLASH_ERR:
                vhal_ota_update_status(VHAL_OTA_ST_FLASH_ERR, percent);
                break;
            case OTA_STAT_HTTP_CONN_FAIL:
                vhal_ota_update_status(VHAL_OTA_ST_HTTP_CONN_FAIL, percent);
                break;
            case OTA_STAT_DL_FAIL:
                vhal_ota_update_status(VHAL_OTA_ST_DL_FAIL, percent);
                break;
            case OTA_STAT_FAIL:
                vhal_ota_update_status(VHAL_OTA_ST_FAIL, percent);
                break;
            default:
                vhal_ota_update_status(VHAL_OTA_ST_FAIL, percent);
                break;
            }
        }
        else
        {
            // vhal_ota_update_status(VHAL_OTA_ST_SUCCESS, 100);   // 升级完成
            vhal_rtl_ota_update_status(0, 100);

            // 如果是固件进行降级，则进行处理
            if (dg_flag)
            {
                vhal_rtl_ota_downgrade();
            }
        }
    }
    else
    {
        vhal_ota_update_status(VHAL_OTA_ST_URL_ERR, percent);
    }

    // 无论最终升级状态是成功还是失败，都需要修改为可升级状态
    s_ota_status.status = VHAL_OTA_ST_IDLE;
    s_ota_status.timeout_flag = false;

    if (ota_ret >= 0)
    {
        ret = VHAL_OK;
        HAL_LOG(LOG_INFO, "amebaZ2 OTA successed, exit\n");
    }
    else
    {
        ret = VHAL_FAIL;
        HAL_LOG(LOG_ERROR, "amebaZ2 OTA fail, exit\n");
    }

    return ret;
}

/**
 * @brief  注册ota升级状态数据回调
 * @param[in]  cb               [ota升级状态回调函数]
 * @return     void
 */
void vhal_ota_status_reg_cb(vhal_ota_status_cb_t cb)
{
    s_ota_status.status_cb = cb;
}

/**
 * @brief 注册ota升级头部校验回调
 * @param[in]  cb               [ota头部校验回调函数]
 * @return     void
 */
void vhal_ota_check_header_reg_cb(vhal_ota_check_header_cb_t cb, int32_t head_len)
{
    s_ota_status.header_check_cb = cb;
    s_ota_status.header_len = head_len;
}

/**
 * @brief 注册ota升级md5校验回调
 * @param[in]  cb               [ota头部校验回调函数]
 * @return     void
 */
void vhal_ota_check_md5_reg_cb(vhal_ota_check_md5_cb_t cb)
{
    s_ota_status.md5_check_cb = cb;
}

/*
 * @brief  设置OTA超时标志位
 * @param[in]  flag             [true表示升级超时，false表示未超时]
 * @return     void
 */
void vhal_ota_set_timeout_flag(bool flag)
{
    s_ota_status.timeout_flag = flag;
    rtl_ota_set_timeout_flag(flag);
}

/**
 * @brief 保存文件到flash
 * @param[in]  offset       [偏移地址]
 * @param[out] p_data       [待保存的数据]
 * @param[in]  data_len     [待保存数据的长度]
 * @return     int          [成功/失败]
 */
int vhal_ota_save_bin_file(int offset, char *p_data, int data_len)
{
    if (NULL == p_data)
        return VHAL_FAIL;


    return VHAL_OK;
}

/**
 * @brief 从flash中读出文件
 * @param[in]  offset       [偏移地址]
 * @param[out] p_data       [待保存的数据]
 * @param[in]  data_len     [待读取数据的长度]
 * @return     int          [成功/失败]
 */
int vhal_ota_read_bin_file(int offset, char *p_data, int data_len)
{
    if (NULL == p_data)
        return VHAL_FAIL;


    return VHAL_OK;
}


