/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        bulb_device.h
 * @brief       灯泡设备操作
 * @author      Dave.Ming
 * @date        2021-09-08
 */

#ifndef __BULB_DEVICE_H__
#define __BULB_DEVICE_H__

#ifdef __cplusplus
extern "C" {
#endif

/**
* @brief 设备上电时的初始化
*/
void bulb_device_init(void);



#ifdef __cplusplus
}
#endif

#endif

