/*
 * Copyright © Vesync Technologies Co.Ltd. 2022. All rights reserved.
 * @file        status.c
 * @brief       setStatus处理接口
 * @date        2022-01-24
 */

#include <stdio.h>

#include "vesync_common.h"
#include "vesync_log.h"
#include "vesync_memory.h"
#include "app_bypass.h"
#include "event.h"
#include "device.h"
#include "scene.h"

/**
 * @brief 白光模式强制响应指令
 * @param[in] *request_data         [指令数据]
 * @param[out] *p_dev_cfg           [设备配置]
 * @return int                      [成功：APP_OK，失败：APP_FAIL]
*/
static void set_white_status_forced(bp_set_status_request_t *request_data, dev_cfg_t *p_dev_cfg)
{
    int status = LIGHT_STATUS_ON;
    if (request_data->color_temp != BP_NO_VALUE) // 白光模式下，下发的指令有白光参数
    {
        p_dev_cfg->flash->cfg.light_param.color_temp = request_data->color_temp;
    }
    else // 白光模式下，下发的指令只有彩光参数
    {
        if (request_data->hue != BP_NO_VALUE)
        {
            p_dev_cfg->flash->cfg.light_param.H = request_data->hue;
            p_dev_cfg->flash->cfg.mode = LIGHT_MODE_COLOR; // 切换模式
        }

        if (request_data->saturation != BP_NO_VALUE)
        {
            p_dev_cfg->flash->cfg.light_param.S = request_data->saturation;
            p_dev_cfg->flash->cfg.mode = LIGHT_MODE_COLOR;
        }
    }

    if (request_data->brightness != BP_NO_VALUE)
    {
        // brightness同时表示了白光的亮度和彩光的透明度，参数的不同会引起模式切换，需要做区分
        if (p_dev_cfg->flash->cfg.mode == LIGHT_MODE_WHITE)
        {
            if (request_data->brightness == LIGHT_BRIGHTNESS_MIN)
            {
                status = LIGHT_STATUS_OFF;
            }
            else
            {
                p_dev_cfg->flash->cfg.light_param.brightness = request_data->brightness;
            }
        }
        else
        {
            if (request_data->brightness == LIGHT_VALUE_MIN)
            {
                status = LIGHT_STATUS_OFF;
            }
            else
            {
                p_dev_cfg->flash->cfg.light_param.V = request_data->brightness;
            }
        }
    }

    p_dev_cfg->flash->cfg.onoff = status; // 修改状态
}

/**
 * @brief 彩光模式强制响应指令
 * @param[in] *request_data         [指令数据]
 * @param[out] *p_dev_cfg           [设备配置]
 * @return int                      [成功：APP_OK，失败：APP_FAIL]
*/
static void set_color_status_forced(bp_set_status_request_t *request_data, dev_cfg_t *p_dev_cfg)
{
    int status = LIGHT_STATUS_ON;
    if (request_data->hue != BP_NO_VALUE) // 彩光模式下，下发的指令有彩光参数
    {
        p_dev_cfg->flash->cfg.light_param.H = request_data->hue;
    }
    else if (request_data->saturation != BP_NO_VALUE)
    {
        p_dev_cfg->flash->cfg.light_param.S = request_data->saturation;
    }
    else // 彩光模式下，下发的指令只有白光参数
    {
        if (request_data->color_temp != BP_NO_VALUE)
        {
            p_dev_cfg->flash->cfg.light_param.color_temp = request_data->color_temp;
            p_dev_cfg->flash->cfg.mode = LIGHT_MODE_WHITE; // 切换模式
        }
    }

    if (request_data->brightness != BP_NO_VALUE)
    {
        // brightness同时表示了白光的亮度和彩光的透明度，参数的不同会引起模式切换，需要做区分
        if (p_dev_cfg->flash->cfg.mode == LIGHT_MODE_WHITE)
        {
            if (request_data->brightness == LIGHT_BRIGHTNESS_MIN)
            {
                status = LIGHT_STATUS_OFF;
            }
            else
            {
                p_dev_cfg->flash->cfg.light_param.brightness = request_data->brightness;
            }
        }
        else
        {
            if (request_data->brightness == LIGHT_VALUE_MIN)
            {
                status = LIGHT_STATUS_OFF;
            }
            else
            {
                p_dev_cfg->flash->cfg.light_param.V = request_data->brightness;
            }
        }
    }

    p_dev_cfg->flash->cfg.onoff = status; // 修改为开启状态
}

int request_data_handle_for_set_status(bp_set_status_request_t *request_data, int *err_code, char *err_msg, void **extra)
{
    UNUSED(extra);
    dev_cfg_t *p_dev_cfg = app_device_cfg_get();
    if (p_dev_cfg == NULL)
    {
        *err_code = BP_ERR_PARA_ILLEGAL;
        snprintf(err_msg, BP_ERR_MSG_LEN, "device abnormal");
        return APP_FAIL;
    }

    int ret = APP_OK;
    uint8_t scene_type = SCENE_LIGHT;
    uint16_t scene_id = p_dev_cfg->flash->cfg.scene_id;

    if ((request_data->brightness != BP_NO_VALUE)
        && (request_data->brightness < LIGHT_BRIGHTNESS_MIN || request_data->brightness > LIGHT_BRIGHTNESS_MAX))
    {
        ret = APP_FAIL;
        *err_code = BP_ERR_ARG;
        snprintf(err_msg, BP_ERR_MSG_LEN, BP_ERR_PARAM_CONV(brightness, BP_ERR_PARAM_VAL_INVALID));
        goto EXIT;
    }

    if ((request_data->hue != BP_NO_VALUE)
        && (request_data->hue < LIGHT_HUE_MIN || request_data->hue > LIGHT_HUE_MAX))
    {
        ret = APP_FAIL;
        *err_code = BP_ERR_ARG;
        snprintf(err_msg, BP_ERR_MSG_LEN, BP_ERR_PARAM_CONV(hue, BP_ERR_PARAM_VAL_INVALID));
        goto EXIT;
    }

    if ((request_data->saturation != BP_NO_VALUE)
        && (request_data->saturation < LIGHT_SATURATION_MIN || request_data->saturation > LIGHT_SATURATION_MAX))
    {
        ret = APP_FAIL;
        *err_code = BP_ERR_ARG;
        snprintf(err_msg, BP_ERR_MSG_LEN, BP_ERR_PARAM_CONV(saturation, BP_ERR_PARAM_VAL_INVALID));
        goto EXIT;
    }

    if (request_data->scene_id != BP_NO_VALUE)
    {
        scene_t *scene = scene_registry_get(SCENE_LIGHT, request_data->scene_id);
        if (scene == NULL)  // 场景不存在
        {
            ret = APP_FAIL;
            *err_code = BP_ERR_ARG;
            snprintf(err_msg, BP_ERR_MSG_LEN, BP_ERR_PARAM_CONV(scene_id, BP_ERR_PARAM_VAL_INVALID));
            goto EXIT;
        }

        p_dev_cfg->flash->cfg.scene_id = request_data->scene_id;
    }

    request_data->force = (request_data->force== BP_NO_VALUE) ? 0 : request_data->force;

    if (request_data->work_mode != BP_NO_VALUE) // 指定模式
    {
        switch (request_data->work_mode)
        {
            case LIGHT_MODE_WHITE:
                if (request_data->color_temp != BP_NO_VALUE)
                {
                    p_dev_cfg->flash->cfg.light_param.color_temp = request_data->color_temp;
                }
                if (request_data->brightness != BP_NO_VALUE)
                {
                    if (request_data->brightness == LIGHT_BRIGHTNESS_MIN)
                    {
                        p_dev_cfg->flash->cfg.onoff = LIGHT_STATUS_OFF;
                    }
                    else
                    {
                        p_dev_cfg->flash->cfg.light_param.brightness = request_data->brightness;
                    }
                }
                break;
            case LIGHT_MODE_COLOR:
                if (request_data->hue != BP_NO_VALUE)
                {
                    p_dev_cfg->flash->cfg.light_param.H = request_data->hue;
                }
                if (request_data->saturation != BP_NO_VALUE)
                {
                    p_dev_cfg->flash->cfg.light_param.S = request_data->saturation;
                }
                if (request_data->brightness != BP_NO_VALUE)
                {
                    if (request_data->brightness == LIGHT_BRIGHTNESS_MIN)
                    {
                        p_dev_cfg->flash->cfg.onoff = LIGHT_STATUS_OFF;
                    }
                    else
                    {
                        p_dev_cfg->flash->cfg.light_param.V = request_data->brightness;
                    }
                }
                break;
            case LIGHT_MODE_MULTI:
                if (request_data->seg_num > request_data->seg_hsv_num
                    || request_data->seg_num > (int)SIZEOF_ARRAY(request_data->seg_hsv)
                    || (p_dev_cfg->flash->cfg.seg_num == 0 && request_data->seg_num == BP_NO_VALUE))
                {
                    ret = APP_FAIL;
                    *err_code = BP_ERR_ARG;
                    snprintf(err_msg, BP_ERR_MSG_LEN, BP_ERR_PARAM_CONV(seg_num, BP_ERR_PARAM_VAL_INVALID));
                    goto EXIT;
                }

                if (request_data->seg_num != BP_NO_VALUE && request_data->seg_hsv_num != 0)
                {
                    p_dev_cfg->flash->cfg.seg_num = request_data->seg_num;
                    for (int i = 0; i < request_data->seg_num; i++)
                    {
                        p_dev_cfg->flash->cfg.extra.seg_param[i].H = (uint16_t)request_data->seg_hsv[i].hue;
                        p_dev_cfg->flash->cfg.extra.seg_param[i].S = (uint16_t)request_data->seg_hsv[i].saturation;
                        p_dev_cfg->flash->cfg.extra.seg_param[i].V = (uint8_t)request_data->seg_hsv[i].value;
                    }
                }
                break;
            case LIGHT_MODE_MUSIC:
                break;
            case LIGHT_MODE_SCENE:
                break;
            default:
                ret = APP_FAIL;
                *err_code = BP_ERR_ARG;
                snprintf(err_msg, BP_ERR_MSG_LEN, BP_ERR_PARAM_CONV(work_mode, BP_ERR_PARAM_VAL_INVALID));
                goto EXIT;
        }

        p_dev_cfg->flash->cfg.mode = (uint8_t)(request_data->work_mode);
        p_dev_cfg->flash->cfg.onoff = LIGHT_STATUS_ON;
    }
    else // 未指定模式，根据当前模式、开关状态、force值以及颜色参数进行处理
    {
        // 白光参数color_temp与彩光参数hue、saturation不能同时出现
        if (request_data->color_temp != BP_NO_VALUE && (request_data->hue != BP_NO_VALUE || request_data->saturation != BP_NO_VALUE))
        {
            ret = APP_FAIL;
            *err_code = BP_ERR_ARG;
            snprintf(err_msg, BP_ERR_MSG_LEN, BP_ERR_PARAM_CONV(param, BP_ERR_PARAM_VAL_INVALID));
            goto EXIT;
        }

        if (p_dev_cfg->flash->cfg.mode != LIGHT_MODE_WHITE && p_dev_cfg->flash->cfg.mode != LIGHT_MODE_COLOR)
        {
            ret = APP_FAIL;
            *err_code =  BP_ERR_NOT_EXEC_IN_CUR_MODE;
            snprintf(err_msg, BP_ERR_MSG_LEN, BP_ERR_PARAM_CONV(param, BP_ERR_PARAM_VAL_INVALID));
            goto EXIT;
        }

        switch (request_data->force)
        {
            case BP_FORCE_SILENT:
                switch (p_dev_cfg->flash->cfg.mode)
                {
                    case LIGHT_MODE_WHITE:
                        if (p_dev_cfg->flash->cfg.onoff == LIGHT_STATUS_OFF) // 关闭状态
                        {
                            set_white_status_forced(request_data, p_dev_cfg);
                        }
                        else // 开启状态
                        {
                            // 白光模式下，下发的指令没有白光参数
                            if (request_data->color_temp == BP_NO_VALUE && request_data->brightness == BP_NO_VALUE)
                            {
                                ret = APP_FAIL;
                                *err_code = BP_ERR_ARG;
                                snprintf(err_msg, BP_ERR_MSG_LEN, BP_ERR_PARAM_CONV(param, BP_ERR_PARAM_VAL_INVALID));
                                goto EXIT;
                            }

                            if (request_data->color_temp != BP_NO_VALUE)
                            {
                                p_dev_cfg->flash->cfg.light_param.color_temp = request_data->color_temp;
                            }

                            if (request_data->brightness != BP_NO_VALUE)
                            {
                                if (request_data->brightness == LIGHT_BRIGHTNESS_MIN)
                                {
                                    p_dev_cfg->flash->cfg.onoff = LIGHT_STATUS_OFF;
                                }
                                else
                                {
                                    p_dev_cfg->flash->cfg.light_param.brightness = request_data->brightness;
                                }
                            }
                        }
                        break;
                    case LIGHT_MODE_COLOR:
                        if (p_dev_cfg->flash->cfg.onoff == LIGHT_STATUS_OFF) // 关闭状态
                        {
                            set_color_status_forced(request_data, p_dev_cfg);
                        }
                        else
                        {
                            // 彩光模式下，下发的指令没有彩光参数
                            if (request_data->hue == BP_NO_VALUE && request_data->saturation == BP_NO_VALUE && request_data->brightness == BP_NO_VALUE)
                            {
                                ret = APP_FAIL;
                                *err_code = BP_ERR_ARG;
                                snprintf(err_msg, BP_ERR_MSG_LEN, BP_ERR_PARAM_CONV(param, BP_ERR_PARAM_VAL_INVALID));
                                goto EXIT;
                            }

                            if (request_data->hue != BP_NO_VALUE)
                            {
                                p_dev_cfg->flash->cfg.light_param.H = request_data->hue;
                            }

                            if (request_data->saturation != BP_NO_VALUE)
                            {
                                p_dev_cfg->flash->cfg.light_param.S = request_data->saturation;
                            }

                            if (request_data->brightness != BP_NO_VALUE)
                            {
                                if (request_data->brightness == LIGHT_VALUE_MIN)
                                {
                                    p_dev_cfg->flash->cfg.onoff = LIGHT_STATUS_OFF;
                                }
                                else
                                {
                                    p_dev_cfg->flash->cfg.light_param.V = request_data->brightness;
                                }
                            }
                        }
                        break;
                    default:
                        break;
                }

                break;
            case BP_FORCE_RESPONSE:
                switch (p_dev_cfg->flash->cfg.mode)
                {
                    case LIGHT_MODE_WHITE:
                        set_white_status_forced(request_data, p_dev_cfg);
                        break;
                    case LIGHT_MODE_COLOR:
                        set_color_status_forced(request_data, p_dev_cfg);
                        break;
                    default:
                        break;
                }

                break;
            case BP_FORCE_WWA:
                if (0 == request_data->brightness) // 第三方语音关闭，不更新设备的亮度值
                {
                    p_dev_cfg->flash->cfg.onoff = LIGHT_STATUS_OFF;
                    p_dev_cfg->voice_off = true;
                }
                else if (100 == request_data->brightness) // 第三方语音开启
                {
                    if (p_dev_cfg->voice_off)
                    {
                        // 如果之前的关闭动作是第三方语音触发的，则开启时以100%亮度打开
                        p_dev_cfg->voice_off = false;
                        if (p_dev_cfg->flash->cfg.mode == LIGHT_MODE_WHITE)
                        {
                            p_dev_cfg->flash->cfg.light_param.brightness = request_data->brightness;
                        }
                        else
                        {
                            p_dev_cfg->flash->cfg.light_param.V = request_data->brightness;
                        }
                    }
                    else
                    {
                        // 如果之前的关闭动作不是由第三方语音触发的（如APP、按键等），则语音开启时以之前亮度打开
                        // Nothing to do
                    }

                    p_dev_cfg->flash->cfg.onoff = LIGHT_STATUS_ON;
                }
                break;
            default:
                *err_code = BP_ERR_ARG;
                ret = APP_FAIL;
                goto EXIT;
        }
    }

    app_device_cfg_save(p_dev_cfg);

    app_scene_info_get_from_mode(&scene_type, &scene_id);

EXIT:
    if (ret == APP_OK)
    {
        BYPASS_NOTIFY(scene_type, scene_id);
    }
    return ret;
}

int reply_data_get_for_set_status(bp_set_status_reply_t *reply_data, int *err_code, char *err_msg, void *extra)
{
    UNUSED(extra);
    int ret = APP_OK;
    dev_cfg_t *p_dev_cfg = app_device_cfg_get();
    if (p_dev_cfg == NULL)
    {
        *err_code = BP_ERR_PARA_ILLEGAL;
        snprintf(err_msg, BP_ERR_MSG_LEN, "device abnormal");
        return APP_FAIL;
    }

    memset(reply_data, BP_NO_VALUE, sizeof(bp_get_status_reply_t));
    reply_data->power_switch = (int)(p_dev_cfg->flash->cfg.onoff);
    reply_data->work_mode = (int)(p_dev_cfg->flash->cfg.mode);
    reply_data->brightness = (int)(p_dev_cfg->flash->cfg.light_param.brightness);
    reply_data->color_temp = (int)(p_dev_cfg->flash->cfg.light_param.color_temp);
    reply_data->hue = (int)(p_dev_cfg->flash->cfg.light_param.H);
    reply_data->saturation = (int)(p_dev_cfg->flash->cfg.light_param.S);
    reply_data->value = (int)(p_dev_cfg->flash->cfg.light_param.V);
    reply_data->scene_id = (int)(p_dev_cfg->flash->cfg.scene_id);
    reply_data->seg_num = (int)(p_dev_cfg->flash->cfg.seg_num);
    reply_data->seg_hsv_num = reply_data->seg_num;
    for (int i = 0; i < reply_data->seg_hsv_num; i++)
    {
        reply_data->seg_hsv[i].hue = (int)(p_dev_cfg->flash->cfg.extra.seg_param[i].H);
        reply_data->seg_hsv[i].saturation = (int)(p_dev_cfg->flash->cfg.extra.seg_param[i].S);
        reply_data->seg_hsv[i].value = (int)(p_dev_cfg->flash->cfg.extra.seg_param[i].V);
    }
    return ret;
}

int reply_data_get_for_get_status(bp_get_status_reply_t *reply_data, int *err_code, char *err_msg, void *extra)
{
    UNUSED(extra);
    int ret = APP_OK;
    dev_cfg_t *p_dev_cfg = app_device_cfg_get();
    if (p_dev_cfg == NULL)
    {
        *err_code = BP_ERR_PARA_ILLEGAL;
        snprintf(err_msg, BP_ERR_MSG_LEN, "device abnormal");
        return APP_FAIL;
    }

    memset(reply_data, BP_NO_VALUE, sizeof(bp_get_status_reply_t));
    reply_data->power_switch = (int)(p_dev_cfg->flash->cfg.onoff);
    reply_data->work_mode = (int)(p_dev_cfg->flash->cfg.mode);
    reply_data->brightness = (int)(p_dev_cfg->flash->cfg.light_param.brightness);
    reply_data->color_temp = (int)(p_dev_cfg->flash->cfg.light_param.color_temp);
    reply_data->hue = (int)(p_dev_cfg->flash->cfg.light_param.H);
    reply_data->saturation = (int)(p_dev_cfg->flash->cfg.light_param.S);
    reply_data->value = (int)(p_dev_cfg->flash->cfg.light_param.V);
    reply_data->scene_id = (int)(p_dev_cfg->flash->cfg.scene_id);
    reply_data->seg_num = (int)(p_dev_cfg->flash->cfg.seg_num);
    reply_data->seg_hsv_num = reply_data->seg_num;
    for (int i = 0; i < reply_data->seg_hsv_num; i++)
    {
        reply_data->seg_hsv[i].hue = (int)(p_dev_cfg->flash->cfg.extra.seg_param[i].H);
        reply_data->seg_hsv[i].saturation = (int)(p_dev_cfg->flash->cfg.extra.seg_param[i].S);
        reply_data->seg_hsv[i].value = (int)(p_dev_cfg->flash->cfg.extra.seg_param[i].V);
    }
    return ret;
}


