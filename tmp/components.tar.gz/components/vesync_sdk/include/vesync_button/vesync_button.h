/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_button.h
 * @brief       按键模块接口定义
 * @date        2021-12-8
 */

#ifndef __VESYNC_BUTTON_H__
#define __VESYNC_BUTTON_H__


#include "stdint.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief 按键事件处理回调
 */
typedef void (*vesync_btn_cb_t)(void);

/**
 * @brief 按键事件类型
 */
typedef enum
{
    EV_NONE_PRESS = 0,
    EV_PRESS_DOWN,          // 按键按下，每次按下都触发
    EV_PRESS_UP,            // 按键弹起，每次松开都触发
    EV_SINGLE_CLICK,        // 单击按键事件
    EV_DOUBLE_CLICK,        // 双击按键事件
    EV_LONG_PRESS_START,    // 达到长按时间阈值时触发一次，由long_press_threshold_ticks决定
    EV_LONG_PRESS_HOLD,     // 长按期间一直触发，回调间隔由long_press_trigger_interval决定
    EV_NUM
} BTN_EVENT_E;

/**
 * @brief 按键电平激活类型
 */
typedef enum
{
    ACTIVE_LOW = 0,
    ACTIVE_HIGH = 1
} BTN_ACTIVE_LEVEL_E;

/**
 *@brief 事件回调映射结构体
 */
typedef struct
{
    BTN_EVENT_E ev;
    vesync_btn_cb_t cb;
} btn_ev_cb_t;

/**
 *@brief 按键配置结构体
 */
typedef struct
{
    uint8_t gpio;
    uint8_t active_level;
    uint32_t long_press_threshold_ms;    // 长按开始时间阈值，默认为800ms
    uint32_t long_press_cb_interval_ms;  // 长按期间回调间隔，默认为10ms
} btn_cfg_t;

/**
 * @brief       添加按键对象
 * @param[in] *btn_cfg              [按键配置]
 * @return  int                     [成功：SDK_OK，失败：SDK_FAIL]
 */
int vesync_button_add(btn_cfg_t *btn_cfg);


/**
 * @brief       按键事件回调批量注册
 * @param[in] gpio                  [按键gpio]
 * @param[in] ev_cb[]               [按键事件回调数组指针]
 * @param[in] num                   [事件回调数组长度，当长度大于EV_NUM时，只注册前EV_NUM个回调]
 * @return  int                     [成功：SDK_OK，失败：SDK_FAIL]
 */
int vesync_button_reg_cb_arr(uint8_t gpio, btn_ev_cb_t ev_cb_arr[], int num);

/**
 * @brief       按键事件回调注册
 * @param[in] gpio                  [按键gpio]
 * @param[in] BTN_EVENT_E           [按键事件]
 * @param[in] cb                    [事件处理回调函数]
 * @return  int                     [成功：SDK_OK，失败：SDK_FAIL]
 */
int vesync_button_reg_cb(uint8_t gpio, BTN_EVENT_E event, vesync_btn_cb_t cb);


/**
 * @brief       删除按键对象
 * @param[in] gpio                  [按键gpio]
 * @return  int                     [成功：SDK_OK，失败：SDK_FAIL]
 */
int vesync_button_del(uint8_t gpio);


/**
* @brief       按键模块反初始化
*/
int vesync_button_deinit(void);

#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_BUTTON_H__ */


