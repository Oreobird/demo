/**
 * Copyright © Vesync Technologies Co.Ltd. 3031. All rights reserved.
 * @file        vesync_cfg.c
 * @brief       Vesync SDK配置接口
 * @date        2022-03-03
 * @note        File auto generated, DO NOT edit.
 */

#include <stdio.h>
#include <string.h>
#include "vesync_common.h"
#include "vesync_log_internal.h"
#include "vesync_cfg.h"

static char s_fw_version[6 + 1] = "1.0.06"; // 本产品固件版本号,格式为“1.0.00”
static char s_hw_version[8 + 1] = "1.0"; // 本产品硬件版本号
static char s_brand[16 + 1] = "Valceno"; // 本产品品牌标识
static char s_type[16 + 1] = "light"; // 本产品类目标识
static char s_model[16 + 1] = "XYD0015"; // 本产品型号标识
static char s_alias_model[16 + 1] = "XYD0015"; // 本产品型号别名
static char s_country_code[3 + 1] = "US"; // 本产品国家代码
static char s_support_ctry_code[32 + 1] = "US"; // 本产品国家代码（OTA）
static char s_config_model[32 + 1] = "VC_WFON_BLB_XYD0015_US"; // 本产品配置模型
static char s_authkey[33 + 1] = "tewe6uodhtvhpxpxhicxfljdvpowedwr"; // MQTT连接认证密钥
static int s_init_task_stacksize = 1024*4; // Vesync SDK 初始化任务堆栈大小
static char s_netcfg_mode[10 + 1] = "cfg_by_ble"; // 配网模式："cfg_by_ble" - 蓝牙配网； "cfg_by_ap" - AP配网
static char s_ssid_prefix[27 + 1] = "Valceno_Colorful_Led"; // WiFi配网AP SSID名称前缀字符串设置
static char s_ble_name[29 + 1] = "Valceno_XYD0015"; // 蓝牙设备名称
static uint8_t s_ble_type = 0x0f; // 蓝牙广播产品类型标识
static uint8_t s_ble_model = 0x02; // 蓝牙广播产品型号标识
static uint8_t s_ble_cmd = 0x2; // 蓝牙广播命令码
static int s_total_mcu_num = 0; // 外挂MCU总数
static int s_ota_type_wifi = 1; // WiFi OTA使能
static int s_ota_type_ble = 0; // 蓝牙 OTA使能
static int s_ota_type_mcu = 0; // MCU OTA使能, 0表示不使能MCU的OTA，>0表示使能第n路MCU的OTA
static int s_ota_timeout_time = 285000; // OTA超时时间（秒）
static int s_wifi_ps_type = 1; // WiFi节能模式设置
static int s_uart0_idx = 0; // 串口UART0的索引号
static int s_uart_tx_pin_arr[1] = {17}; // 串口TX脚设置数组
static int s_uart_rx_pin_arr[1] = {16}; // 串口RX脚设置数组
static int s_uart_baud_rate_arr[1] = {9600}; // 串口波特率设置数组
static int s_uart_resend_cnt = 3; // 串口重发次数设置
static int s_uart_send_timeout_ms = 2000; // 串口发送超时（毫秒）
static int s_uart_payload_max_len = 1000; // 串口收发单个包的最大长度

/**
 * @brief 设置本产品固件版本号,格式为“1.0.00”
 * @param[in]  data          [设置的配置]
 * @return  int              [成功：SDK_OK，失败：SDK_FAIL]
 * @note  字符长度范围: [6, 6]
 */
int vesync_cfg_set_fw_version(char * data)
{
    if (data == NULL || strlen(data) < 6)
    {
        SDK_LOG(LOG_ERROR, "data len should be in range [%d, %d]\n", 6, 6);
        return SDK_FAIL;
    }

    if (strlen(data) > 6)
    {
        SDK_LOG(LOG_WARN, "data range exceeded, will truncated in %d\n", 6);
    }

    memset(s_fw_version, 0, sizeof(s_fw_version));
    snprintf(s_fw_version, sizeof(s_fw_version), "%s", data);
    return SDK_OK;
}

/**
 * @brief 获取本产品固件版本号,格式为“1.0.00”
 * @return  char *              [获取的配置]
 */
char * vesync_cfg_get_fw_version(void)
{
    return s_fw_version;
}

/**
 * @brief 设置本产品硬件版本号
 * @param[in]  data          [设置的配置]
 * @return  int              [成功：SDK_OK，失败：SDK_FAIL]
 * @note  字符长度范围: [1, 8]
 */
int vesync_cfg_set_hw_version(char * data)
{
    if (data == NULL || strlen(data) < 1)
    {
        SDK_LOG(LOG_ERROR, "data len should be in range [%d, %d]\n", 1, 8);
        return SDK_FAIL;
    }

    if (strlen(data) > 8)
    {
        SDK_LOG(LOG_WARN, "data range exceeded, will truncated in %d\n", 8);
    }

    memset(s_hw_version, 0, sizeof(s_hw_version));
    snprintf(s_hw_version, sizeof(s_hw_version), "%s", data);
    return SDK_OK;
}

/**
 * @brief 获取本产品硬件版本号
 * @return  char *              [获取的配置]
 */
char * vesync_cfg_get_hw_version(void)
{
    return s_hw_version;
}

/**
 * @brief 设置本产品品牌标识
 * @param[in]  data          [设置的配置]
 * @return  int              [成功：SDK_OK，失败：SDK_FAIL]
 * @note  字符长度范围: [1, 16]
 */
int vesync_cfg_set_brand(char * data)
{
    if (data == NULL || strlen(data) < 1)
    {
        SDK_LOG(LOG_ERROR, "data len should be in range [%d, %d]\n", 1, 16);
        return SDK_FAIL;
    }

    if (strlen(data) > 16)
    {
        SDK_LOG(LOG_WARN, "data range exceeded, will truncated in %d\n", 16);
    }

    memset(s_brand, 0, sizeof(s_brand));
    snprintf(s_brand, sizeof(s_brand), "%s", data);
    return SDK_OK;
}

/**
 * @brief 获取本产品品牌标识
 * @return  char *              [获取的配置]
 */
char * vesync_cfg_get_brand(void)
{
    return s_brand;
}

/**
 * @brief 设置本产品类目标识
 * @param[in]  data          [设置的配置]
 * @return  int              [成功：SDK_OK，失败：SDK_FAIL]
 * @note  字符长度范围: [1, 16]
 */
int vesync_cfg_set_type(char * data)
{
    if (data == NULL || strlen(data) < 1)
    {
        SDK_LOG(LOG_ERROR, "data len should be in range [%d, %d]\n", 1, 16);
        return SDK_FAIL;
    }

    if (strlen(data) > 16)
    {
        SDK_LOG(LOG_WARN, "data range exceeded, will truncated in %d\n", 16);
    }

    memset(s_type, 0, sizeof(s_type));
    snprintf(s_type, sizeof(s_type), "%s", data);
    return SDK_OK;
}

/**
 * @brief 获取本产品类目标识
 * @return  char *              [获取的配置]
 */
char * vesync_cfg_get_type(void)
{
    return s_type;
}

/**
 * @brief 设置本产品型号标识
 * @param[in]  data          [设置的配置]
 * @return  int              [成功：SDK_OK，失败：SDK_FAIL]
 * @note  字符长度范围: [1, 16]
 */
int vesync_cfg_set_model(char * data)
{
    if (data == NULL || strlen(data) < 1)
    {
        SDK_LOG(LOG_ERROR, "data len should be in range [%d, %d]\n", 1, 16);
        return SDK_FAIL;
    }

    if (strlen(data) > 16)
    {
        SDK_LOG(LOG_WARN, "data range exceeded, will truncated in %d\n", 16);
    }

    memset(s_model, 0, sizeof(s_model));
    snprintf(s_model, sizeof(s_model), "%s", data);
    return SDK_OK;
}

/**
 * @brief 获取本产品型号标识
 * @return  char *              [获取的配置]
 */
char * vesync_cfg_get_model(void)
{
    return s_model;
}

/**
 * @brief 设置本产品型号别名
 * @param[in]  data          [设置的配置]
 * @return  int              [成功：SDK_OK，失败：SDK_FAIL]
 * @note  字符长度范围: [1, 16]
 */
int vesync_cfg_set_alias_model(char * data)
{
    if (data == NULL || strlen(data) < 1)
    {
        SDK_LOG(LOG_ERROR, "data len should be in range [%d, %d]\n", 1, 16);
        return SDK_FAIL;
    }

    if (strlen(data) > 16)
    {
        SDK_LOG(LOG_WARN, "data range exceeded, will truncated in %d\n", 16);
    }

    memset(s_alias_model, 0, sizeof(s_alias_model));
    snprintf(s_alias_model, sizeof(s_alias_model), "%s", data);
    return SDK_OK;
}

/**
 * @brief 获取本产品型号别名
 * @return  char *              [获取的配置]
 */
char * vesync_cfg_get_alias_model(void)
{
    return s_alias_model;
}

/**
 * @brief 设置本产品国家代码
 * @param[in]  data          [设置的配置]
 * @return  int              [成功：SDK_OK，失败：SDK_FAIL]
 * @note  字符长度范围: [1, 3]
 */
int vesync_cfg_set_country_code(char * data)
{
    if (data == NULL || strlen(data) < 1)
    {
        SDK_LOG(LOG_ERROR, "data len should be in range [%d, %d]\n", 1, 3);
        return SDK_FAIL;
    }

    if (strlen(data) > 3)
    {
        SDK_LOG(LOG_WARN, "data range exceeded, will truncated in %d\n", 3);
    }

    memset(s_country_code, 0, sizeof(s_country_code));
    snprintf(s_country_code, sizeof(s_country_code), "%s", data);
    return SDK_OK;
}

/**
 * @brief 获取本产品国家代码
 * @return  char *              [获取的配置]
 */
char * vesync_cfg_get_country_code(void)
{
    return s_country_code;
}

/**
 * @brief 设置本产品国家代码（OTA）
 * @param[in]  data          [设置的配置]
 * @return  int              [成功：SDK_OK，失败：SDK_FAIL]
 * @note  字符长度范围: [1, 32]
 */
int vesync_cfg_set_support_ctry_code(char * data)
{
    if (data == NULL || strlen(data) < 1)
    {
        SDK_LOG(LOG_ERROR, "data len should be in range [%d, %d]\n", 1, 32);
        return SDK_FAIL;
    }

    if (strlen(data) > 32)
    {
        SDK_LOG(LOG_WARN, "data range exceeded, will truncated in %d\n", 32);
    }

    memset(s_support_ctry_code, 0, sizeof(s_support_ctry_code));
    snprintf(s_support_ctry_code, sizeof(s_support_ctry_code), "%s", data);
    return SDK_OK;
}

/**
 * @brief 获取本产品国家代码（OTA）
 * @return  char *              [获取的配置]
 */
char * vesync_cfg_get_support_ctry_code(void)
{
    return s_support_ctry_code;
}

/**
 * @brief 设置本产品配置模型
 * @param[in]  data          [设置的配置]
 * @return  int              [成功：SDK_OK，失败：SDK_FAIL]
 * @note  字符长度范围: [1, 32]
 */
int vesync_cfg_set_config_model(char * data)
{
    if (data == NULL || strlen(data) < 1)
    {
        SDK_LOG(LOG_ERROR, "data len should be in range [%d, %d]\n", 1, 32);
        return SDK_FAIL;
    }

    if (strlen(data) > 32)
    {
        SDK_LOG(LOG_WARN, "data range exceeded, will truncated in %d\n", 32);
    }

    memset(s_config_model, 0, sizeof(s_config_model));
    snprintf(s_config_model, sizeof(s_config_model), "%s", data);
    return SDK_OK;
}

/**
 * @brief 获取本产品配置模型
 * @return  char *              [获取的配置]
 */
char * vesync_cfg_get_config_model(void)
{
    return s_config_model;
}

/**
 * @brief 设置MQTT连接认证密钥
 * @param[in]  data          [设置的配置]
 * @return  int              [成功：SDK_OK，失败：SDK_FAIL]
 * @note  字符长度范围: [1, 33]
 */
int vesync_cfg_set_authkey(char * data)
{
    if (data == NULL || strlen(data) < 1)
    {
        SDK_LOG(LOG_ERROR, "data len should be in range [%d, %d]\n", 1, 33);
        return SDK_FAIL;
    }

    if (strlen(data) > 33)
    {
        SDK_LOG(LOG_WARN, "data range exceeded, will truncated in %d\n", 33);
    }

    memset(s_authkey, 0, sizeof(s_authkey));
    snprintf(s_authkey, sizeof(s_authkey), "%s", data);
    return SDK_OK;
}

/**
 * @brief 获取MQTT连接认证密钥
 * @return  char *              [获取的配置]
 */
char * vesync_cfg_get_authkey(void)
{
    return s_authkey;
}

/**
 * @brief 设置Vesync SDK 初始化任务堆栈大小
 * @param[in]  data          [设置的配置]
 * @return  int              [成功：SDK_OK，失败：SDK_FAIL]
 * @note  数值范围:[1024*2, 1024*8]
 */
int vesync_cfg_set_init_task_stacksize(int data)
{
    if (data < 1024*2 || data > 1024*8)
    {
        SDK_LOG(LOG_ERROR, "data should be in range [%d, %d]\n", 1024*2, 1024*8);
        return SDK_FAIL;
    }

    s_init_task_stacksize = data;
    return SDK_OK;
}

/**
 * @brief 获取Vesync SDK 初始化任务堆栈大小
 * @return  int              [获取的配置]
 */
int vesync_cfg_get_init_task_stacksize(void)
{
    return s_init_task_stacksize;
}

/**
 * @brief 设置配网模式："cfg_by_ble" - 蓝牙配网； "cfg_by_ap" - AP配网
 * @param[in]  data          [设置的配置]
 * @return  int              [成功：SDK_OK，失败：SDK_FAIL]
 * @note  字符长度范围: [9, 10]
 */
int vesync_cfg_set_netcfg_mode(char * data)
{
    if (data == NULL || strlen(data) < 9)
    {
        SDK_LOG(LOG_ERROR, "data len should be in range [%d, %d]\n", 9, 10);
        return SDK_FAIL;
    }

    if (strlen(data) > 10)
    {
        SDK_LOG(LOG_WARN, "data range exceeded, will truncated in %d\n", 10);
    }

    memset(s_netcfg_mode, 0, sizeof(s_netcfg_mode));
    snprintf(s_netcfg_mode, sizeof(s_netcfg_mode), "%s", data);
    return SDK_OK;
}

/**
 * @brief 获取配网模式："cfg_by_ble" - 蓝牙配网； "cfg_by_ap" - AP配网
 * @return  char *              [获取的配置]
 */
char * vesync_cfg_get_netcfg_mode(void)
{
    return s_netcfg_mode;
}

/**
 * @brief 设置WiFi配网AP SSID名称前缀字符串设置
 * @param[in]  data          [设置的配置]
 * @return  int              [成功：SDK_OK，失败：SDK_FAIL]
 * @note  字符长度范围: [1, 27]
 */
int vesync_cfg_set_ssid_prefix(char * data)
{
    if (data == NULL || strlen(data) < 1)
    {
        SDK_LOG(LOG_ERROR, "data len should be in range [%d, %d]\n", 1, 27);
        return SDK_FAIL;
    }

    if (strlen(data) > 27)
    {
        SDK_LOG(LOG_WARN, "data range exceeded, will truncated in %d\n", 27);
    }

    memset(s_ssid_prefix, 0, sizeof(s_ssid_prefix));
    snprintf(s_ssid_prefix, sizeof(s_ssid_prefix), "%s", data);
    return SDK_OK;
}

/**
 * @brief 获取WiFi配网AP SSID名称前缀字符串设置
 * @return  char *              [获取的配置]
 */
char * vesync_cfg_get_ssid_prefix(void)
{
    return s_ssid_prefix;
}

/**
 * @brief 设置蓝牙设备名称
 * @param[in]  data          [设置的配置]
 * @return  int              [成功：SDK_OK，失败：SDK_FAIL]
 * @note  字符长度范围: [1, 29]
 */
int vesync_cfg_set_ble_name(char * data)
{
    if (data == NULL || strlen(data) < 1)
    {
        SDK_LOG(LOG_ERROR, "data len should be in range [%d, %d]\n", 1, 29);
        return SDK_FAIL;
    }

    if (strlen(data) > 29)
    {
        SDK_LOG(LOG_WARN, "data range exceeded, will truncated in %d\n", 29);
    }

    memset(s_ble_name, 0, sizeof(s_ble_name));
    snprintf(s_ble_name, sizeof(s_ble_name), "%s", data);
    return SDK_OK;
}

/**
 * @brief 获取蓝牙设备名称
 * @return  char *              [获取的配置]
 */
char * vesync_cfg_get_ble_name(void)
{
    return s_ble_name;
}

/**
 * @brief 设置蓝牙广播产品类型标识
 * @param[in]  data          [设置的配置]
 * @return  int              [成功：SDK_OK，失败：SDK_FAIL]
 * @note  数值范围:[0x0, 0xFF]
 */
int vesync_cfg_set_ble_type(uint8_t data)
{
    if (data < 0x0 || data > 0xFF)
    {
        SDK_LOG(LOG_ERROR, "data should be in range [%d, %d]\n", 0x0, 0xFF);
        return SDK_FAIL;
    }

    s_ble_type = data;
    return SDK_OK;
}

/**
 * @brief 获取蓝牙广播产品类型标识
 * @return  uint8_t              [获取的配置]
 */
uint8_t vesync_cfg_get_ble_type(void)
{
    return s_ble_type;
}

/**
 * @brief 设置蓝牙广播产品型号标识
 * @param[in]  data          [设置的配置]
 * @return  int              [成功：SDK_OK，失败：SDK_FAIL]
 * @note  数值范围:[0x0, 0xFF]
 */
int vesync_cfg_set_ble_model(uint8_t data)
{
    if (data < 0x0 || data > 0xFF)
    {
        SDK_LOG(LOG_ERROR, "data should be in range [%d, %d]\n", 0x0, 0xFF);
        return SDK_FAIL;
    }

    s_ble_model = data;
    return SDK_OK;
}

/**
 * @brief 获取蓝牙广播产品型号标识
 * @return  uint8_t              [获取的配置]
 */
uint8_t vesync_cfg_get_ble_model(void)
{
    return s_ble_model;
}

/**
 * @brief 设置蓝牙广播命令码
 * @param[in]  data          [设置的配置]
 * @return  int              [成功：SDK_OK，失败：SDK_FAIL]
 * @note  数值范围:[0x0, 0xFF]
 */
int vesync_cfg_set_ble_cmd(uint8_t data)
{
    if (data < 0x0 || data > 0xFF)
    {
        SDK_LOG(LOG_ERROR, "data should be in range [%d, %d]\n", 0x0, 0xFF);
        return SDK_FAIL;
    }

    s_ble_cmd = data;
    return SDK_OK;
}

/**
 * @brief 获取蓝牙广播命令码
 * @return  uint8_t              [获取的配置]
 */
uint8_t vesync_cfg_get_ble_cmd(void)
{
    return s_ble_cmd;
}

/**
 * @brief 设置外挂MCU总数
 * @param[in]  data          [设置的配置]
 * @return  int              [成功：SDK_OK，失败：SDK_FAIL]
 * @note  数值范围:[0, 1]
 */
int vesync_cfg_set_total_mcu_num(int data)
{
    if (data < 0 || data > 1)
    {
        SDK_LOG(LOG_ERROR, "data should be in range [%d, %d]\n", 0, 1);
        return SDK_FAIL;
    }

    s_total_mcu_num = data;
    return SDK_OK;
}

/**
 * @brief 获取外挂MCU总数
 * @return  int              [获取的配置]
 */
int vesync_cfg_get_total_mcu_num(void)
{
    return s_total_mcu_num;
}

/**
 * @brief 设置WiFi OTA使能
 * @param[in]  data          [设置的配置]
 * @return  int              [成功：SDK_OK，失败：SDK_FAIL]
 * @note  数值范围:[0, 1]
 */
int vesync_cfg_set_ota_type_wifi(int data)
{
    if (data < 0 || data > 1)
    {
        SDK_LOG(LOG_ERROR, "data should be in range [%d, %d]\n", 0, 1);
        return SDK_FAIL;
    }

    s_ota_type_wifi = data;
    return SDK_OK;
}

/**
 * @brief 获取WiFi OTA使能
 * @return  int              [获取的配置]
 */
int vesync_cfg_get_ota_type_wifi(void)
{
    return s_ota_type_wifi;
}

/**
 * @brief 设置蓝牙 OTA使能
 * @param[in]  data          [设置的配置]
 * @return  int              [成功：SDK_OK，失败：SDK_FAIL]
 * @note  数值范围:[0, 1]
 */
int vesync_cfg_set_ota_type_ble(int data)
{
    if (data < 0 || data > 1)
    {
        SDK_LOG(LOG_ERROR, "data should be in range [%d, %d]\n", 0, 1);
        return SDK_FAIL;
    }

    s_ota_type_ble = data;
    return SDK_OK;
}

/**
 * @brief 获取蓝牙 OTA使能
 * @return  int              [获取的配置]
 */
int vesync_cfg_get_ota_type_ble(void)
{
    return s_ota_type_ble;
}

/**
 * @brief 设置MCU OTA使能, 0表示不使能MCU的OTA，>0表示使能第n路MCU的OTA
 * @param[in]  data          [设置的配置]
 * @return  int              [成功：SDK_OK，失败：SDK_FAIL]
 * @note  数值范围:[0, 1]
 */
int vesync_cfg_set_ota_type_mcu(int data)
{
    if (data < 0 || data > 1)
    {
        SDK_LOG(LOG_ERROR, "data should be in range [%d, %d]\n", 0, 1);
        return SDK_FAIL;
    }

    s_ota_type_mcu = data;
    return SDK_OK;
}

/**
 * @brief 获取MCU OTA使能, 0表示不使能MCU的OTA，>0表示使能第n路MCU的OTA
 * @return  int              [获取的配置]
 */
int vesync_cfg_get_ota_type_mcu(void)
{
    return s_ota_type_mcu;
}

/**
 * @brief 设置OTA超时时间（秒）
 * @param[in]  data          [设置的配置]
 * @return  int              [成功：SDK_OK，失败：SDK_FAIL]
 * @note  数值范围:[1, 285000]
 */
int vesync_cfg_set_ota_timeout_time(int data)
{
    if (data < 1 || data > 285000)
    {
        SDK_LOG(LOG_ERROR, "data should be in range [%d, %d]\n", 1, 285000);
        return SDK_FAIL;
    }

    s_ota_timeout_time = data;
    return SDK_OK;
}

/**
 * @brief 获取OTA超时时间（秒）
 * @return  int              [获取的配置]
 */
int vesync_cfg_get_ota_timeout_time(void)
{
    return s_ota_timeout_time;
}

/**
 * @brief 设置WiFi节能模式设置
 * @param[in]  data          [设置的配置]
 * @return  int              [成功：SDK_OK，失败：SDK_FAIL]
 * @note  数值范围:[0, 1]
 */
int vesync_cfg_set_wifi_ps_type(int data)
{
    if (data < 0 || data > 1)
    {
        SDK_LOG(LOG_ERROR, "data should be in range [%d, %d]\n", 0, 1);
        return SDK_FAIL;
    }

    s_wifi_ps_type = data;
    return SDK_OK;
}

/**
 * @brief 获取WiFi节能模式设置
 * @return  int              [获取的配置]
 */
int vesync_cfg_get_wifi_ps_type(void)
{
    return s_wifi_ps_type;
}

/**
 * @brief 设置串口UART0的索引号
 * @param[in]  data          [设置的配置]
 * @return  int              [成功：SDK_OK，失败：SDK_FAIL]
 * @note  数值范围:[0, 1]
 */
int vesync_cfg_set_uart0_idx(int data)
{
    if (data < 0 || data > 1)
    {
        SDK_LOG(LOG_ERROR, "data should be in range [%d, %d]\n", 0, 1);
        return SDK_FAIL;
    }

    s_uart0_idx = data;
    return SDK_OK;
}

/**
 * @brief 获取串口UART0的索引号
 * @return  int              [获取的配置]
 */
int vesync_cfg_get_uart0_idx(void)
{
    return s_uart0_idx;
}

/**
 * @brief 设置串口TX脚设置数组
 * @param[in]  data          [设置的配置]
 * @return  int              [成功：SDK_OK，失败：SDK_FAIL]
 * @note  处理的最大个数为1，超出部分将不处理
 */
int vesync_cfg_set_uart_tx_pin_arr(int * data)
{
    if (data == NULL)
    {
        SDK_LOG(LOG_ERROR, "data error\n");
        return SDK_FAIL;
    }

    memcpy(s_uart_tx_pin_arr, data, sizeof(s_uart_tx_pin_arr));
    return SDK_OK;
}

/**
 * @brief 获取串口TX脚设置数组
 * @return  int *              [获取的配置]
 */
int * vesync_cfg_get_uart_tx_pin_arr(void)
{
    return s_uart_tx_pin_arr;
}

/**
 * @brief 设置串口RX脚设置数组
 * @param[in]  data          [设置的配置]
 * @return  int              [成功：SDK_OK，失败：SDK_FAIL]
 * @note  处理的最大个数为1，超出部分将不处理
 */
int vesync_cfg_set_uart_rx_pin_arr(int * data)
{
    if (data == NULL)
    {
        SDK_LOG(LOG_ERROR, "data error\n");
        return SDK_FAIL;
    }

    memcpy(s_uart_rx_pin_arr, data, sizeof(s_uart_rx_pin_arr));
    return SDK_OK;
}

/**
 * @brief 获取串口RX脚设置数组
 * @return  int *              [获取的配置]
 */
int * vesync_cfg_get_uart_rx_pin_arr(void)
{
    return s_uart_rx_pin_arr;
}

/**
 * @brief 设置串口波特率设置数组
 * @param[in]  data          [设置的配置]
 * @return  int              [成功：SDK_OK，失败：SDK_FAIL]
 * @note  处理的最大个数为1，超出部分将不处理
 */
int vesync_cfg_set_uart_baud_rate_arr(int * data)
{
    if (data == NULL)
    {
        SDK_LOG(LOG_ERROR, "data error\n");
        return SDK_FAIL;
    }

    memcpy(s_uart_baud_rate_arr, data, sizeof(s_uart_baud_rate_arr));
    return SDK_OK;
}

/**
 * @brief 获取串口波特率设置数组
 * @return  int *              [获取的配置]
 */
int * vesync_cfg_get_uart_baud_rate_arr(void)
{
    return s_uart_baud_rate_arr;
}

/**
 * @brief 设置串口重发次数设置
 * @param[in]  data          [设置的配置]
 * @return  int              [成功：SDK_OK，失败：SDK_FAIL]
 * @note  数值范围:[0, 10]
 */
int vesync_cfg_set_uart_resend_cnt(int data)
{
    if (data < 0 || data > 10)
    {
        SDK_LOG(LOG_ERROR, "data should be in range [%d, %d]\n", 0, 10);
        return SDK_FAIL;
    }

    s_uart_resend_cnt = data;
    return SDK_OK;
}

/**
 * @brief 获取串口重发次数设置
 * @return  int              [获取的配置]
 */
int vesync_cfg_get_uart_resend_cnt(void)
{
    return s_uart_resend_cnt;
}

/**
 * @brief 设置串口发送超时（毫秒）
 * @param[in]  data          [设置的配置]
 * @return  int              [成功：SDK_OK，失败：SDK_FAIL]
 * @note  数值范围:[1, 10000]
 */
int vesync_cfg_set_uart_send_timeout_ms(int data)
{
    if (data < 1 || data > 10000)
    {
        SDK_LOG(LOG_ERROR, "data should be in range [%d, %d]\n", 1, 10000);
        return SDK_FAIL;
    }

    s_uart_send_timeout_ms = data;
    return SDK_OK;
}

/**
 * @brief 获取串口发送超时（毫秒）
 * @return  int              [获取的配置]
 */
int vesync_cfg_get_uart_send_timeout_ms(void)
{
    return s_uart_send_timeout_ms;
}

/**
 * @brief 设置串口收发单个包的最大长度
 * @param[in]  data          [设置的配置]
 * @return  int              [成功：SDK_OK，失败：SDK_FAIL]
 * @note  数值范围:[1, 1000]
 */
int vesync_cfg_set_uart_payload_max_len(int data)
{
    if (data < 1 || data > 1000)
    {
        SDK_LOG(LOG_ERROR, "data should be in range [%d, %d]\n", 1, 1000);
        return SDK_FAIL;
    }

    s_uart_payload_max_len = data;
    return SDK_OK;
}

/**
 * @brief 获取串口收发单个包的最大长度
 * @return  int              [获取的配置]
 */
int vesync_cfg_get_uart_payload_max_len(void)
{
    return s_uart_payload_max_len;
}


