from cryptography import x509
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives import serialization
import hashlib
from ecdsa import SigningKey, VerifyingKey, NIST256p
from ecdsa.util import sigdecode_der

f = open('test_dev.cst', 'rb')
pem_data = f.read()
cert = x509.load_pem_x509_certificate(pem_data, default_backend())

rf = open('test_root.crt', 'rb')
root_cert_pem = rf.read()
root_cert = x509.load_pem_x509_certificate(root_cert_pem, default_backend())
root_pk = root_cert.public_key()

print("root pk", root_pk.public_bytes(serialization.Encoding.DER, serialization.PublicFormat.SubjectPublicKeyInfo).hex())
print("sig from dev cert", cert.signature.hex())
sig_mock = bytes.fromhex('3045022100FB5179B183ADB0FB322A946DD4DC93EE56D9ABECE3CBEE61B337599AFE54FB55022022C9F5A05A0E555FAE12C11E901EE99F1947A4BF8A9C3AA9CEC02CDC7C6BC25D')
root_pk.verify(sig_mock, cert.tbs_certificate_bytes, ec.ECDSA(cert.signature_hash_algorithm))

print("-------------------------------------------------------------")

pk_3rd = 'E07B2B36BB86E4FEC1256AD6754BEDA61DCFD54AA86DF3ED8ADFDDCCA4CAC99E0FEE145FDF597231BBB9C1BEA12B841CFB86B8D4138526CBB93D285A7B82D0FE'
pk_3rd = bytes.fromhex(pk_3rd)
sig_3rd = 'FB5179B183ADB0FB322A946DD4DC93EE56D9ABECE3CBEE61B337599AFE54FB5522C9F5A05A0E555FAE12C11E901EE99F1947A4BF8A9C3AA9CEC02CDC7C6BC25D'
sig_3rd = bytes.fromhex(sig_3rd)
print("pk_3rd", pk_3rd.hex())
print("sig_3rd", sig_3rd.hex())

print("tbs_raw", cert.tbs_certificate_bytes.hex())
tbs_hash_b = hashlib.sha256(cert.tbs_certificate_bytes).digest()
print("tbs_hash_b", tbs_hash_b.hex())
tbs_hash = hashlib.sha256(cert.tbs_certificate_bytes).hexdigest()
print("tbs_hash", tbs_hash)

def hash_stub(data):
    digest = hashlib.sha256(data)
    #print("data", data.hex())
    print("data_digest", digest.digest().hex())
    return digest

#pk_3rd = VerifyingKey.from_string(pk_3rd, curve=NIST256p, hashfunc=hashlib.sha256)
pk_3rd = VerifyingKey.from_string(pk_3rd, curve=NIST256p, hashfunc=hash_stub)
pk_3rd.verify(cert.signature, cert.tbs_certificate_bytes, sigdecode=sigdecode_der)
pk_3rd.verify(sig_3rd, cert.tbs_certificate_bytes)

sk_3rd = 'ad9011814a56ad107b6756832dfb3e47b7dda9471cecd42b078790db5f9b159f'
sk_3rd = bytes.fromhex(sk_3rd)
sk_3rd = SigningKey.from_string(sk_3rd, curve=NIST256p, hashfunc=hash_stub)
re_sig = sk_3rd.sign(cert.tbs_certificate_bytes)
print("re_sig", re_sig.hex())
pk_3rd.verify(re_sig, cert.tbs_certificate_bytes)
