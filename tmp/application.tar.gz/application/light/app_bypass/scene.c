/*
 * Copyright © Vesync Technologies Co.Ltd. 2022. All rights reserved.
 * @file        scene.c
 * @brief       add/get/delScene处理接口
 * @date        2022-01-24
 */

#include <stdio.h>

#include "vesync_common.h"
#include "vesync_log.h"
#include "vesync_memory.h"
#include "app_bypass.h"
#include "event.h"
#include "device.h"
#include "scene.h"

int reply_data_get_for_add_scene(bp_add_scene_reply_t *reply_data, int *err_code, char *err_msg, void *extra)
{
    UNUSED(extra);
    dev_cfg_t *p_dev_cfg = app_device_cfg_get();
    if (p_dev_cfg == NULL)
    {
        *err_code = BP_ERR_PARA_ILLEGAL;
        snprintf(err_msg, BP_ERR_MSG_LEN, "device abnormal");
        return APP_FAIL;
    }

    int scene_id = 0;
    int ret = custom_scene_add(&scene_id);
    if (ret != APP_OK || scene_id == SCENE_INVALID_ID)
    {
        *err_code = BP_ERR_CMD_EXECUTE_FAIL;
        snprintf(err_msg, BP_ERR_MSG_LEN, "add scene fail");
        return APP_FAIL;
    }

    reply_data->scene_id = scene_id;
    return APP_OK;
}

int request_data_handle_for_get_scenes(bp_get_scenes_request_t *request_data, int *err_code, char *err_msg, void **extra)
{
    return APP_OK;
}

int reply_data_get_for_get_scenes(bp_get_scenes_reply_t *reply_data, int *err_code, char *err_msg, void *extra)
{
    reply_data->total_num = scene_registry_get_custom_num();
    reply_data->scene_ids_num = total_num;
    reply_data->scene_ids =;
    return APP_OK;
}

int request_data_handle_for_del_scene(bp_del_scene_request_t *request_data, int *err_code, char *err_msg, void **extra)
{
    int ret = custom_scene_del(request_data->scene_id);
    if (ret != APP_OK)
    {
        *err_code = BP_ERR_CMD_EXECUTE_FAIL;
        snprintf(err_msg, BP_ERR_MSG_LEN, "del scene fail");
        return APP_FAIL;
    }

    return APP_OK;
}

