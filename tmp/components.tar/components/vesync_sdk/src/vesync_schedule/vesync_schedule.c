/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_schedule.c
 * @brief       schedule的定时功能抽象，形成schedule_cycle模块
 * @author      Patrick.Wu
 * @date        2019-06-26
 */
#include <time.h>
#include <string.h>

#include "vhal_utils.h"
#include "vesync_memory.h"
#include "vesync_timer.h"
#include "vesync_common.h"
#include "vesync_log_internal.h"
#include "vesync_schedule_internal.h"


static schedule_mgt_t s_sche_mgt;
/*-----------------------------------------------------------------------------*
 *                           内部函数API实现                                         *
 *-----------------------------------------------------------------------------*/
/**
 * @brief schedule 时间戳和当前比较并执行
 * @param[in] cur_tm                [当前时间结构体]
 * @param[in] pSch_data             [schedule数据结构指针]
 * @return  SCHE_COMPARE_RESULT_E   [返回比较的结果]
 */
static SCHE_COMPARE_RESULT_E schedule_time_compare_and_execute(struct tm cur_tm, schedule_data_t *pSch_data)
{
    SCHE_COMPARE_RESULT_E ret = SCH_NOT_EXE;

    if (NULL == pSch_data)
    {
        return SCH_EXE_ERR;
    }

    uint8_t thisWeekday = cur_tm.tm_wday;

    if (0 == cur_tm.tm_wday)     //0 表示星期天
    {
        thisWeekday = 7;
    }

    struct tm schedule_tm;
    time_t ts = (time_t)(pSch_data->timestamp);
    gmtime_r(&ts, &schedule_tm);    //schedule时间戳转成时分

    if ((schedule_tm.tm_hour == cur_tm.tm_hour)
        &&(schedule_tm.tm_min == cur_tm.tm_min)
        &&(((pSch_data->loop) & 0xfe) & (1 << thisWeekday)))
    {
        if (pSch_data->schCb)
        {
            // 周期性的schedule，执行次数先加1，应用层执行后直接读取该执行次数
            if (((pSch_data->loop) & (uint8_t)0x01))
            {
                pSch_data->exec_cnt += 1;
                SDK_LOG(LOG_DEBUG,"exec_cnt = %d.\n", pSch_data->exec_cnt);
            }

            if (pSch_data->schCb(pSch_data->pSchData, pSch_data->timestamp) != SCHE_RESULT_OK)
            {
                SDK_LOG(LOG_ERROR, "schedule exe fail...\r\n");
                ret = SCH_EXE_ERR;
            }
            else
            {
                ret = SCH_EXE_WEEKLY;

                if (!((pSch_data->loop) & (uint8_t)0x01))   //loop bit0=0 只执行一次
                {
                    return SCH_EXE_ONCE;
                }
            }
        }
    }
    return ret;
}


/**
 * @brief away cycle　定时轮询函数 10秒执行一次
 * @param[in] *arg
 */
static void schedule_cycle_loop(void *arg)
{
    static uint8_t old_min = SCHEDULE_INVALID_MINUTE;
    struct tm cur_tm;
    time_t cur_ts;

    cur_ts = vhal_utils_get_system_time_sec();

    gmtime_r(&cur_ts, &cur_tm); //时间戳转成时分秒

    //SDK_LOG(LOG_DEBUG,"away cycle loop  %d-%d-%d %d:%d:%d, week=%d\r\n",
    //      cur_tm.tm_year, cur_tm.tm_mon, cur_tm.tm_mday, cur_tm.tm_hour,
    //      cur_tm.tm_min,cur_tm.tm_sec, cur_tm.tm_wday);
    SDK_LOG(LOG_DEBUG, "Local time is %s, week=%d\n", ctime(&cur_ts), cur_tm.tm_wday);

    if (old_min == SCHEDULE_INVALID_MINUTE)
    {
        old_min = cur_tm.tm_min;
    }

    if (old_min == cur_tm.tm_min)
    {
        return;
    }

    old_min = cur_tm.tm_min;

    bool sch_remove_flag = false;
    schedule_t *pos, *n;
    struct list_head *head = &(s_sche_mgt.cycle_list);
    schedule_data_t *pSch_data = NULL;

    list_for_each_entry_safe(pos, n, head, list)
    {
        pSch_data = &(pos->data);
        if (pSch_data->schId > 0)
        {
            sch_remove_flag = false;
            SCHE_COMPARE_RESULT_E compare_ret = SCH_NOT_EXE;

            if (pSch_data->timestamp > 1)       //服务器下发时间戳0或者1表示无效
            {
                compare_ret = schedule_time_compare_and_execute(cur_tm, pSch_data);  //比较时间戳
                if (SCH_EXE_ONCE == compare_ret)
                {
                    sch_remove_flag = true;
                }
                else if (SCH_EXE_ERR == compare_ret)
                {
                    SDK_LOG(LOG_ERROR,"schedule cycle execute error\r\n");
                }
            }

            if (true == sch_remove_flag)
            {
                SDK_LOG(LOG_DEBUG,"remove schedule data id= %d\r\n", pSch_data->schId);
                list_del(&pos->list);   //移除schedule cycle任务节点
                s_sche_mgt.sche_num--;
                INIT_LIST_HEAD(&pos->list);
                vesync_free(pos);
                continue;
            }
        }
    }
}


/**
 * @brief 开启schedule 轮询定时器
 */
static void schedule_cycle_start(void)
{
    if (s_sche_mgt.schedule_running)
    {
        return;
    }

    s_sche_mgt.schedule_running = true;

    int ret = vesync_timer_new(&s_sche_mgt.schedule_timer, "schedule_timer", schedule_cycle_loop, NULL, SCHEDULE_CYCLE_TIMER_INTERVAL, true);
    if (VOS_OK == ret)
    {
        ret = vesync_timer_start(&s_sche_mgt.schedule_timer);
        if (VOS_OK != ret)
        {
            SDK_LOG(LOG_ERROR, "Start schedule timer fail!!!\n");
        }
    }
    else
    {
        SDK_LOG(LOG_ERROR, "Create schedule timer fail!!!\n");
    }

}

/**
 * @brief 停止schedule cycle 轮询定时器
 */
static void schedule_cycle_stop(void)
{
    vesync_timer_stop(&s_sche_mgt.schedule_timer);
    s_sche_mgt.schedule_running = false;
}

/**
 * @brief 添加schedule cycle数据到链表
 * @param[in] pSchData              [schedule cycle数据结构]
 * @return  int                     [SCH_CYCLE_OK 添加成功、SCH_CYCLE_FAIL 添加失败]
 */
static int schedule_list_add(schedule_data_t *pSchData)
{
    if(NULL == pSchData)
    {
        return SCH_CYCLE_FAIL;
    }

    schedule_t *pSch_node = (schedule_t *)vesync_malloc(sizeof(schedule_t));
    if (pSch_node == NULL)
    {
        SDK_LOG(LOG_ERROR, "schcycle_list_add malloc fail\r\n");
        return SCH_CYCLE_FAIL;
    }

    memcpy(&pSch_node->data, pSchData, sizeof(schedule_data_t));
    list_add(&(pSch_node->list), &(s_sche_mgt.cycle_list));
    s_sche_mgt.sche_num++;

    return SCH_CYCLE_OK;
}

/*-----------------------------------------------------------------------------*
 *                           外部函数API实现                                         *
 *-----------------------------------------------------------------------------*/

/**
* @brief 删除schedule cycle 任务
* @param[in] schid             [需要删除的schedule id]
* @return int                  [成功：SDK_OK, 失败：SDK_FAIL]
*/
int vesync_schedule_list_del(uint32_t schid)
{
    int ret = SCH_CYCLE_FAIL;
    schedule_t *pos, *n;
    struct list_head *head = &(s_sche_mgt.cycle_list);

    list_for_each_entry_safe(pos, n, head, list)
    {
        if (schid == pos->data.schId)
        {
            list_del(&pos->list);
            s_sche_mgt.sche_num--;
            INIT_LIST_HEAD(&pos->list);
            vesync_free(pos);
            ret = SCH_CYCLE_OK;
        }
    }

    return ret;

}


/**
* @brief 应用层增加schedule 任务
* @param[in] pSchData          [schedule 的数据结构]
* @return  int                 [成功：SDK_OK, 失败：SDK_FAIL]
*/
int vesync_schedule_add(schedule_data_t *pSchData)
{
    if (NULL == pSchData)
    {
        return SCH_CYCLE_FAIL;
    }

    schedule_cycle_stop();
    vesync_schedule_list_del(pSchData->schId);
    int ret = schedule_list_add(pSchData);
    schedule_cycle_start();

    return ret;

}

/**
* @brief 移除schedule 中的任务
* @param[in] schid             [schedule id]
* @return                      [成功：SDK_OK, 失败：SDK_FAIL]
*/
int vesync_schedule_remove(uint32_t schid)
{
    schedule_cycle_stop();
    int ret = vesync_schedule_list_del(schid);
    schedule_cycle_start();
    return ret;
}

/**
* @brief 传入时间戳计算星期
* @param[in] ts                [需要计算的时间戳]
* @return uint8_t              [1-7 周一到周日]
*/
uint8_t vesync_schedule_loop_calc(uint8_t repeat, SCHE_ATTRIBUTE_E attr)
{
    uint8_t loop = repeat & 0xfe;
    if (SCHE_WEEKLY == attr)
    {
        loop |= 0x01;
    }

    return loop;
}


/**
* @brief       schedule repeat 计算api
* @param[in]   repeat          [原始配置repeat]
* @param[in]   ts              [原始配置的UTC时间]
* @param[in]   shift_ts        [偏移后的UTC时间]
* @return      loop 的数值
*/
uint8_t vesync_schedule_repeat_calc(uint8_t repeat, uint32_t ts, uint32_t shift_ts)
{
    uint8_t loop = repeat & 0xfe;
    int wday_differ = 0;
    time_t original_time  = ts;
    time_t shift_time = shift_ts;
    struct tm original_tm;
    struct tm shift_tm;

    gmtime_r(&original_time, &original_tm); // 新建时的时间戳转成时分秒
    gmtime_r(&shift_time, &shift_tm);       // 偏移后的时间戳转成时分秒

    wday_differ = shift_tm.tm_wday - original_tm.tm_wday;

    SDK_LOG(LOG_DEBUG, "original_tm.tm_hour is %d, original_tm.tm_min is %d . \n", shift_tm.tm_hour, original_tm.tm_min);
    SDK_LOG(LOG_DEBUG, "shift_tm.tm_hour is %d, shift_tm.tm_min is %d . \n", shift_tm.tm_hour, original_tm.tm_min);
    SDK_LOG(LOG_DEBUG, "shift_tm.tm_wday is %d, original_tm.tm_wday is %d . \n", shift_tm.tm_wday, original_tm.tm_wday);

    //时区偏差值做差只会存在四种情况，1、-1、6、-6
    switch (wday_differ)
    {
        case -1:
        case 6:
            loop = loop >> 1;
            if (loop&0x01)
            {
                loop = loop | 0x80;
            }
            else
            {
                loop = loop & 0x7f;
            }
            SDK_LOG(LOG_DEBUG, "repeat is %d, wday reduce 1 day after shift. \n", loop);
            break;
        case 1:
        case -6:
            if (loop&0x80)
            {
                loop = loop | 0x01;
            }
            loop = loop << 1;
            SDK_LOG(LOG_DEBUG, "repeat is %d, wday add 1 day after shift. \n", loop);
            break;
        default:
            SDK_LOG(LOG_ERROR, "repeat_calc failed. \n");
            break;
    }

    return loop;
}

/**
* @brief 获取当天是星期几
* @param[in]   ts              [原始配置的UTC时间]
* @return uint8_t              [1-7 周一到周日]
*/
uint8_t vesync_schedule_get_timestamp_weekday(uint32_t ts)
{
    struct tm cur_tm;
    time_t tmp = (time_t)ts;    // time_t = long

    gmtime_r(&tmp, &cur_tm);    //时间戳转成时分秒
    uint8_t thisWeekday = cur_tm.tm_wday;

    if (0 == cur_tm.tm_wday) //0 表示星期天
    {
        thisWeekday = 7;
    }

    return thisWeekday;
}

/**
* @brief schedule cycle任务链表释放
*/
void vesync_schedule_list_destroy(void)
{
    schedule_t *pos;
    struct list_head *head = &(s_sche_mgt.cycle_list);

    if (list_empty(head))
    {
        return;
    }

    while (head->next != head)
    {
        pos = list_entry(head->next, schedule_t, list);
        list_del( &pos->list);
        INIT_LIST_HEAD( &pos->list );
        vesync_free(pos);
    }
}

/**
* @brief 获取当前schedule cycle 任务数量
* @return  uint8_t             [schedule 的数量]
*/
uint8_t vesync_schedule_get_num(void)
{
    return s_sche_mgt.sche_num;
}

/**
* @brief schedule 冲突判断
* @param[in] pSchData          [schedule cycle数据结构]
* @return SCHE_RESULT_E        [判断结果]
*/
SCHE_RESULT_E vesync_schedule_conflict_check(schedule_data_t *pSchData)
{
    SCHE_RESULT_E ret = SCHE_RESULT_OK;

    if (NULL == pSchData)
    {
        return SCHE_RESULT_OK;
    }

    struct tm new_sch_tm = {0}, sch_tm = {0};
    time_t ts = (time_t)pSchData->timestamp;
    gmtime_r(&ts, &new_sch_tm); //schedule时间戳转成时分

    schedule_t *pos = NULL;
    schedule_t *n = NULL;
    struct list_head *head = &(s_sche_mgt.cycle_list);
    schedule_data_t *pSch_data = NULL;

    list_for_each_entry_safe(pos, n, head, list)
    {
        pSch_data = &(pos->data);
        if ((pSch_data->schId > 0) && (pSch_data->schId != pSchData->schId))
        {
            ts = (time_t)pSch_data->timestamp;
            gmtime_r(&ts, &sch_tm); //schedule时间戳转成时分

            if ((sch_tm.tm_hour == new_sch_tm.tm_hour) && (sch_tm.tm_min == new_sch_tm.tm_min))
            {
                if (pSch_data->loop & pSchData->loop & 0xfe)   //loop 有重叠表示有冲突,清零weekly标志位
                {
                    ret = SCHE_RESULT_CONFLICT;
                    break;
                }
            }
        }
    }

    return ret;
}

/**
* @brief  判断schedule单次执行时，下发的时间比当前时间早，则进行调整
* @param[in] ts                [schedule时间戳]
* @param[in] repeat            [schedule是否重复执行]
* @return uint32_t 更新后的时间戳
*/
uint32_t vesync_schedule_ts_check(uint32_t ts, uint8_t repeat)
{
    time_t cur_ts = 0;
    uint32_t new_ts = ts;

    cur_ts = vhal_utils_get_system_time_sec();
    SDK_LOG(LOG_DEBUG, "repeat is %d, current ts is %ld, setting ts: %d.\n", repeat, cur_ts, ts);

    if ((!repeat) && ((ts / 60) <= (cur_ts / 60)))      //分钟小于等于当前时间，则加一天
    {
        //单次执行，如果下发时间比当前时间早，则设为第二天执行
        uint32_t day = (cur_ts / SENCONDS_PER_DAY) - (ts / SENCONDS_PER_DAY);
        if((ts % SENCONDS_PER_DAY) / 60 <= (cur_ts % SENCONDS_PER_DAY) / 60)
        {
            day++;
        }

        new_ts += SENCONDS_PER_DAY * day;
        SDK_LOG(LOG_DEBUG, "pass %d day, new ts: %d \n", day, new_ts);
    }

    return new_ts;
}

/**
* @brief  根据schedule ID查询schedule执行的次数
* @param[in]  uint32_t         [schedule ID]
* @return  int32_t             [对应schedule执行的次数]
*/
int32_t vesync_schedule_get_exec_cnt(uint32_t schd_id)
{
    int32_t exec_cnt = -1;
    schedule_t *pos, *n;
    struct list_head *head = &(s_sche_mgt.cycle_list);

    list_for_each_entry_safe(pos, n, head, list)
    {
        if (pos->data.schId == schd_id)
        {
            exec_cnt = pos->data.exec_cnt;
            break;
        }
    }

    return exec_cnt;
}


/**
 * @brief schedule初始化
 */
void vesync_schedule_init(void)
{
    memset(&s_sche_mgt, 0, sizeof(schedule_mgt_t));
    s_sche_mgt.schedule_running = false;
    INIT_LIST_HEAD(&(s_sche_mgt.cycle_list));
}

