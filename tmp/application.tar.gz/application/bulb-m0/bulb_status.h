/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
* @file        bulb_status.h
* @brief       灯泡状态控制
* @author      Dave
* @date        2021-09-1
*/
#include <stdint.h>
#include <stdbool.h>

#include "vesync_loop_timer.h"

#ifndef __BULB_STATUS_H__
#define __BULB_STATUS_H__

#ifdef __cplusplus
extern "C" {
#endif

#define BULB_TEMP_MAX (100)       // 色温值上限
#define BULB_W_WARMEST (0)        // 白光模式最暖色温值
#define BULB_W_MODEST (50)        // 白光模式中间色温
#define BULB_W_COLDEST (100)      // 白光模式最冷色温值
#define BULB_W_FULL_BRIGHT (100)  // 白光模式满亮度值
#define BULB_W_HALF_BRIGHT (50)   // 白光模式半亮度值

#define BULB_MUSIC_FREQ_SEG_NBR (16)            // 音乐模式频率数据段数
#define BULB_MUSIC_FREQ_HIGH_RANGE (4000)       // 区分高音的频率点
#define BULB_MUSIC_SPEED_SLOWEST_MS (3000)      // 音乐模式最慢速度定义，3秒一帧
#define BULB_MUSIC_SPEED_FASTEST_MS (100)       // 音乐模式最快速度定义，100毫秒一帧
#define BULB_MUSIC_RMS_THRESHOLD_UP_MAX (10000) // 音乐模式的RMS上阈值
#define BULB_MUSIC_RMS_THRESHOLD_DN_MAX (100)   // 音乐模式的RMS下阈值

typedef struct
{
    uint16_t freq[BULB_MUSIC_FREQ_SEG_NBR];
    uint32_t amp[BULB_MUSIC_FREQ_SEG_NBR];
} bulb_status_fft_info_t;

typedef struct
{
    uint32_t rms;
} bulb_status_rms_info_t;

typedef struct
{
    uint8_t color_temp;
    uint8_t brightness;
} bulb_status_white_t;

typedef struct
{
    uint16_t hue;
    uint16_t saturation;
    uint8_t value;
} bulb_status_hsv_t;

typedef struct
{
    bool enable;
    uint8_t mode;
    bulb_status_white_t white;
    bulb_status_hsv_t hsv;
    struct {
        uint8_t type;
        uint8_t value;
    } sensitive;
    uint8_t effect;
    uint16_t scene_id;
} bulb_status_t;

/**
 * @brief Bulb 获取LED当前状态
 * @param[out]  p_data          [指向输出的LED状态参数]
 * @return      int             [成功：APP_OK， 失败：APP_FAIL]
 */
int bulb_status_fetch(bulb_status_t *p_data);

/**
 * @brief Bulb 更新LED当前状态
 * @param[in]   p_data          [指向输入的LED状态参数]
 * @return      int             [成功：APP_OK， 失败：APP_FAIL]
 */
int bulb_status_update(bulb_status_t *p_data);

/**
 * @brief Bulb 更新LED当前状态并延迟上报更新状态
 * @param[in]   p_data          [指向输入的LED状态参数]
 * @param[in]   src_type        [状态更新来源的类型字符串]
 * @return      int             [成功：APP_OK， 失败：APP_FAIL]
 */
int bulb_status_update_and_report(bulb_status_t *p_data, const char *src_type);

/**
 * @brief Bulb 设置0-100%亮度渐变的时间
 * @param[in]   enable          [是否使能]
 * @param[in]   ms_100_percent  [毫秒参数]
 * @return      int             [成功：APP_OK， 失败：APP_FAIL]
 */
int bulb_status_set_fade_speed(uint8_t enable, uint16_t ms_100_percent);

/**
 * @brief Bulb 获取0-100%亮度渐变的时间
 * @param[out]  p_enable            [指向输出是否使能参数的缓存]
 * @param[out]  p_ms_100_percent    [指向输出毫秒参数的缓存]
 * @return      int                 [成功：APP_OK， 失败：APP_FAIL]
 */
int bulb_status_get_fade_speed(uint8_t *p_enable, uint16_t *p_ms_100_percent);

/**
 * @brief Bulb 直接设置HSV的输出
 * @param[in]   p_hsv           [指向HSV参数]
 * @param[in]   step_speed      [渐变的步速]
 * @return      int             [成功：APP_OK， 失败：APP_FAIL]
 */
int bulb_status_direct_set_hsv(const bulb_status_hsv_t *p_hsv, float step_speed);

/**
 * @brief Bulb 直接设置白光的输出
 * @param[in]   p_white         [指向白光参数]
 * @param[in]   step_speed      [渐变的步速]
 * @return      int             [成功：APP_OK， 失败：APP_FAIL]
 */
int bulb_status_direct_set_white(const bulb_status_white_t *p_white, float step_speed);

/**
 * @brief Bulb 直接设置HSV闪烁
 * @param[in]   p_hsv           [亮状态的HSV值]
 * @param[in]   period          [闪烁周期]
 * @param[in]   period_nbr      [持续的时间（毫秒）]
 * @return      int             [成功：APP_OK， 失败：APP_FAIL]
 */
int bulb_status_direct_set_hsv_blink(const bulb_status_hsv_t *p_hsv, uint32_t period, uint32_t period_nbr);

/**
 * @brief Bulb 直接设置白光闪烁
 * @param[in]   p_hsv           [亮状态的白光值]
 * @param[in]   period          [闪烁周期]
 * @param[in]   period_nbr      [持续的时间（毫秒）]
 * @return      int             [成功：APP_OK， 失败：APP_FAIL]
 */
int bulb_status_direct_set_white_blink(const bulb_status_white_t *p_white, uint32_t period, uint32_t period_nbr);

/**
 * @brief Bulb 直接设置HSV呼吸
 * @param[in]   p_hsv           [呼吸顶点的HSV值]
 * @param[in]   period          [呼吸周期]
 * @param[in]   period_nbr      [持续的时间（毫秒）]
 * @return      int             [成功：APP_OK， 失败：APP_FAIL]
 */
int bulb_status_direct_set_hsv_breath(const bulb_status_hsv_t *p_hsv, uint32_t period, uint32_t period_nbr);

/**
 * @brief Bulb 直接设置白光呼吸
 * @param[in]   p_hsv           [呼吸顶点的白光值]
 * @param[in]   period          [呼吸周期]
 * @param[in]   period_nbr      [持续的时间（毫秒）]
 * @return      int             [成功：APP_OK， 失败：APP_FAIL]
 */
int bulb_status_direct_set_white_breath(const bulb_status_white_t *p_white, uint32_t period, uint32_t period_nbr);

/**
 * @brief Bulb 更新音乐模式参数
 * @param[in]   p_fft           [指向FFT数据缓存]
 * @param[in]   p_rms           [指向RMS数据缓存]
 * @return      int             [成功：APP_OK， 失败：APP_FAIL]
 */
int bulb_status_update_music_param(bulb_status_fft_info_t *p_fft, bulb_status_rms_info_t *p_rms);

/**
 * @brief Bulb LED驱动的初始化
 */
void bulb_status_init(void);

/**
 * @brief Bulb 更新status内置灯效定时器的周期
 * @param[in]   timer           [指向相应的定时器]
 * @param[in]   timeout_ms      [新的定时器周期]
 * @return      int             [成功：APP_OK， 失败：APP_FAIL]
 */
int bulb_status_timer_change_period(vesync_timer_t *timer, long timeout_ms);

#ifdef __cplusplus
}
#endif

#endif

