/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
* @file         scene_registry.c
* @brief        场景注册中心
* @author       Joshua
* @date         2021-11-17
*/

#include <stdint.h>
#include <stdbool.h>
#include "vesync_common.h"
#include "vesync_log.h"
#include "vesync_memory.h"
#include "scene.h"

scene_registry_t *s_scene_rgst = NULL;

int scene_registry_init(void)
{
    if (s_scene_rgst != NULL)
    {
        APP_LOG(LOG_INFO, "Scene registry already init\n");
        return APP_OK;
    }

    s_scene_rgst = (scene_registry_t *)vesync_malloc(sizeof(scene_registry_t));
    if (s_scene_rgst == NULL)
    {
        APP_LOG(LOG_ERROR, "Scene registry init fail\n");
        return APP_FAIL;
    }

    s_scene_rgst->mutex = vesync_mutex_new();
    if (s_scene_rgst->mutex == NULL)
    {
        APP_LOG(LOG_ERROR, "Scene mutex create fail\n");
        VCOM_SAFE_FREE(s_scene_rgst);
        return APP_FAIL;
    }

    INIT_LIST_HEAD(&s_scene_rgst->list);
    INIT_LIST_HEAD(&s_scene_rgst->light_list);
    return APP_OK;
}

int scene_registry_deinit(void)
{
    scene_t *pos = NULL, *n = NULL;
    struct list_head *head = NULL;

    vesync_mutex_lock(s_scene_rgst->mutex);
    head = &s_scene_rgst->list;
    if (!list_empty(head))
    {
        list_for_each_entry_safe(pos, n, head, list)
        {
            list_del(&pos->list);
            INIT_LIST_HEAD(&s_scene_rgst->list);
            VCOM_SAFE_FREE(pos);
            s_scene_rgst->build_in_num--;
        }
    }

    head = &s_scene_rgst->light_list;
    if (!list_empty(head))
    {
        list_for_each_entry_safe(pos, n, head, list)
        {
            list_del(&pos->list);
            INIT_LIST_HEAD(&s_scene_rgst->light_list);
            VCOM_SAFE_FREE(pos);
            s_scene_rgst->custom_num--;
        }
    }

    vesync_mutex_unlock(s_scene_rgst->mutex);
    vesync_mutex_free(s_scene_rgst->mutex);
    VCOM_SAFE_FREE(s_scene_rgst);
    return APP_OK;
}

int scene_registry_add(scene_t *p_scene)
{
    VCOM_NULL_PARAM_CHK(p_scene, return APP_FAIL);

    scene_t *pos = scene_registry_get(p_scene->type, p_scene->id);
    if (pos != NULL)
    {
        APP_LOG(LOG_INFO, "scene already exist\n");
        return APP_FAIL;
    }

    int *p_num = NULL;
    struct list_head *head = NULL;
    vesync_mutex_lock(s_scene_rgst->mutex);
    head = (p_scene->type == SCENE_LIGHT) ? &s_scene_rgst->light_list : &s_scene_rgst->list;
    p_num = (p_scene->type == SCENE_LIGHT) ? &s_scene_rgst->custom_num : &s_scene_rgst->build_in_num;
    list_add(&p_scene->list, head);
    *p_num = *p_num + 1;
    vesync_mutex_unlock(s_scene_rgst->mutex);

    return APP_OK;
}

scene_t *scene_registry_get(int type, int id)
{
    scene_t *pos = NULL, *n = NULL;
    struct list_head *head = NULL;

    vesync_mutex_lock(s_scene_rgst->mutex);
    head = (type == SCENE_LIGHT) ? &s_scene_rgst->light_list : &s_scene_rgst->list;
    list_for_each_entry_safe(pos, n, head, list)
    {
        if (pos->type == type && pos->id == id)
        {
            vesync_mutex_unlock(s_scene_rgst->mutex);
            return pos;
        }
    }
    vesync_mutex_unlock(s_scene_rgst->mutex);
    return NULL;
}

int scene_registry_del(int type, int id)
{
    scene_t *pos = NULL, *n = NULL;
    struct list_head *head = NULL;
    bool deleted = false;
    int *p_num = NULL;

    vesync_mutex_lock(s_scene_rgst->mutex);
    head = (type == SCENE_LIGHT) ? &s_scene_rgst->light_list : &s_scene_rgst->list;
    p_num = (type == SCENE_LIGHT) ? &s_scene_rgst->custom_num : &s_scene_rgst->build_in_num;
    if (list_empty(head))
    {
        APP_LOG(LOG_INFO, "registry empty\n");
        return APP_FAIL;
    }

    list_for_each_entry_safe(pos, n, head, list)
    {
        if (pos->type == type && pos->id == id)
        {
            list_del(&pos->list);
            INIT_LIST_HEAD(&pos->list);
            VCOM_SAFE_FREE(pos);
            (*p_num)--;
            deleted = true;
            break;
        }
    }
    vesync_mutex_unlock(s_scene_rgst->mutex);

    if (!deleted)
    {
        APP_LOG(LOG_INFO, "deleted fail\n");
        return APP_FAIL;
    }

    return APP_OK;
}

scene_t *scene_registry_get_next(int type, int id)
{
    scene_t *next_pos = NULL;
    scene_t *pos = NULL, *n = NULL;
    struct list_head *head = NULL;

    vesync_mutex_lock(s_scene_rgst->mutex);
    head = (type == SCENE_LIGHT) ? &s_scene_rgst->light_list : &s_scene_rgst->list;
    list_for_each_entry_safe(pos, n, head, list)
    {
        if (pos->type == type && pos->id == id)
        {
            break;
        }
    }

    next_pos = list_next_entry(pos, list);
    if (&next_pos->list == head)
    {
        next_pos = list_next_entry(next_pos, list);
    }
    vesync_mutex_unlock(s_scene_rgst->mutex);
    return next_pos;
}

int scene_registry_get_custom_num(void)
{
    return s_scene_rgst->custom_num;
}

void scene_registry_for_each(int type, int (*cb)(int id))
{
    scene_t *pos = NULL, *n = NULL;
    struct list_head *head = NULL;

    vesync_mutex_lock(s_scene_rgst->mutex);
    head = (type == SCENE_LIGHT) ? &s_scene_rgst->light_list : &s_scene_rgst->list;
    list_for_each_entry_safe(pos, n, head, list)
    {
        if (pos->type == type && cb)
        {
            cb(pos->id);
        }
    }
    vesync_mutex_unlock(s_scene_rgst->mutex);
    return NULL;
}