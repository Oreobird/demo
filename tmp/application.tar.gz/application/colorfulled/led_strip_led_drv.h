/**
*Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file    led_strip_pwm.h
* @brief   白灯配置
* @author  henrik
*@date     2021-10-25
*/


#ifndef __LED_STRIP_PWM_H__
#define __LED_STRIP_PWM_H__

#include "led_display.h"

#ifdef __cplusplus
extern "C" {
#endif

#define DEFAULT_PULSE     50         // 默认状态下的脉宽
#define MAX_PULSE         100        // 最大脉宽

/**
* @brief  灯效配置
* @return     int             [成功/失败]
*/
int  led_strip_white_ctrl_init(void);

/**
* @brief  灯带电源配置
* @return     int             [成功/失败]
*/
void  led_strip_power_ctrl_init(void);

/**
* @brief  设置灯带电源IO电平
* @param[in]  level           [IO电平]
* @return     int             [成功/失败]
*/
void  led_strip_set_power_io(uint8_t level);

/**
* @brief  RGB灯驱动初始化
* @return     led_rgb_handle_t             [驱动控制结构体指针]
*/
led_rgb_handle_t * led_strip_rgb_ctrl_init(void);


/**
* @brief  白灯脉宽设置
* @param[in]  pulse           [脉冲宽度]
* @return     int             [成功/失败]
*/
int  led_strip_set_white_pulse(uint8_t pulse);

#ifdef __cplusplus
}
#endif

#endif

