/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_ota_mcu_internal.h
 * @brief       ota模块内部接口定义
 * @date        2021-05-19
 */

#ifndef __VESYNC_OTA_MCU_INTERNAL_H__
#define __VESYNC_OTA_MCU_INTERNAL_H__

#include <stdint.h>

#include <stdint.h>
#include "vesync_ota_internal.h"
#include "vesync_sem.h"

#ifdef __cplusplus
extern "C" {
#endif

#define OTA_MCU_MAX_PACKET_LEN      (1024)    // MCU数据包最大长度
#define VESYNC_OTA_MCU_HEADER_LEN   (7)       // MCU固件请求头部长度(不包含数据)

/*
 * @brief 通过串口升级MCU固件的opcode
 */
typedef enum
{
    OPC_OTA_MCU_START           = 0x8030,  // 开始升级
    OPC_OTA_MCU_BIN_REQ         = 0x8031,  // 请求固件
    OPC_OTA_MCU_DOWNLOAD_RESULT = 0x8032,  // 下载结果
    OPC_OTA_MCU_RESULT          = 0x8033   // 升级结果
} OTA_MCU_OPCODE_E;

/*
 * @brief MCU升级状态
 */
typedef enum
{
    OTA_MCU_STATE_START,             // 开始升级
    OTA_MCU_STATE_BIN_REQ,           // 请求固件
    OTA_MCU_STATE_DOWNLOAD_RESULT,   // 下载结果
    OTA_MCU_STATE_RESULT             // 升级结果
} OTA_MCU_STATE_E;

/*
 * @brief MCU升级信息确认
 */
typedef enum
{
    OTA_MCU_OTA_CONFIRM = 0X00,     // 升级信息正常
    OTA_MCU_NOT_SUPPORT,            // 不支持OTA
    OTA_MCU_UNABLE_OTA,             // 无法升级
    OTA_MCU_ERROR                   // 升级信息异常
} OTA_MCU_CONFIRM_E;

/*
 * @brief MCU升级请求包id
 */
typedef enum
{
    OTA_MCU_PACKET_ID_NORMAL = 0x00,  // 升级包正常
    OTA_MCU_PACKET_ID_END,            // 升级包结束
    OTA_MCU_PACKET_ID_OTA_OVER        // 升级包
} OTA_MCU_ACK_PACKET_ID_E;

/*
 * @brief MCU升级下载结果
 */
typedef enum
{
    DOWNLOAD_SUCCESS =0x00,  // 下载成功
    DOWNLOAD_FAIL,           // 下载失败
    DOWNLOAD_TIMEOUT         // 下载超时
} OTA_MCU_DOWNLOAD_RESULT_E;

/*
 * @brief MCU升级结果
 */
typedef enum
{
    OTA_MCU_SUCCESS = 0x00,  // 升级成功
    OTA_MCU_FAIL,            // 升级失败
    OTA_MCU_CHECK_FAIL       // 升级检查错误
} OTA_MCU_RESULT_E;

/*
 * @brief MCU升级/下载结果
 */
typedef union
{
    OTA_MCU_DOWNLOAD_RESULT_E   download_result;
    OTA_MCU_RESULT_E            ota_mcu_result;
} ota_mcu_state_param_u;

#pragma pack(1)
/*
 * @brief MCU升级信息组装协议信息
 */
typedef struct
{
    uint16_t mtu;               // 固件传输方所支持的单包固件数据最大长度
    uint8_t  sw_version[3];     // 0x010101 表示 v1.1.1
    uint32_t bin_size;          // 升级固件文件的大小， 单位字节
    uint16_t reserve;           // 0xFFFF 填充
} ota_mcu_start_prot_t;

/*
 * @brief MCU升级信息回复协议信息
 */
typedef struct
{
    uint8_t  ota_confirm;
    uint16_t mtu;
} ota_mcu_start_ack_prot_t;

/*
 * @brief MCU升级固件偏移地址
 */
typedef struct
{
    uint32_t addr_offset;
} ota_mcu_bin_req_prot_t;

/*
 * @brief MCU升级，Wi-Fi每次发送给MCU的信息
 */
typedef struct
{
    uint8_t  packet_id;
    uint32_t addr_offset;
    uint16_t data_len;
    uint8_t  data[0];
} ota_mcu_bin_req_ack_prot_t;


/*
 * @brief MCU升级，Wi-Fi发送MCU固件的回复
 */
typedef struct
{
    uint8_t result;
} ota_mcu_dl_result_prot_t;

/*
 * @brief MCU升级上报的结果
 */
typedef struct
{
    uint8_t result;
} ota_mcu_result_prot_t;

#pragma pack()

/*
 * @brief MCU升级信息
 */
typedef struct
{
    uint8_t sw_version[3];
    uint16_t bin_size;
    uint16_t mtu;
} ota_mcu_info_t;

/**
 * @brief 升级状态通知回调函数
 * @param[in]  state                [MCU升级状态]
 * @param[in]  param                [MCU升级/下载结果]
 */
typedef void (* vesync_ota_mcu_state_cb_t)(OTA_MCU_STATE_E state ,ota_mcu_state_param_u *param);

/*
 * @brief MCU升级结构体
 */
typedef struct
{
    uint8_t uart_num;
    ota_mcu_info_t upg_info;
    OTA_MCU_STATE_E upg_state;
    UPGRADE_STATE_E upg_err_code;

    vesync_sem_t *mcu_upgrade_sem;
    vesync_ota_mcu_state_cb_t ota_mcu_state_cb;
} vesync_ota_mcu_t;

/**
 * @brief ota超时设置
 *
 */
void vesync_ota_mcu_timeout_set(void);


/**
 * @brief 注册升级状态通知回调函数
 * @param[in] cb            [回调函数]
 */
void vesync_ota_mcu_reg_state_cb(vesync_ota_mcu_state_cb_t cb);


/**
 * @brief ota mcu处理函数
 *
 * @param[in] sw_version        [mcu固件版本 三个字节（0x010109 表示 v1.1.9）]
 * @param[in] bin_size          [mcu固件大小]
 * @return    int32_t           [返回0表示成功，否则失败]
 */
uint32_t vesync_ota_mcu_start(uint8_t *sw_version, uint32_t bin_size);

/**
 * @brief OTA mcu初始化
 */
void vesync_ota_mcu_init(void);


#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_OTA_MCU_INTERNAL_H__ */



