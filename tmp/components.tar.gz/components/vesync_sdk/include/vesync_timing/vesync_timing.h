/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_timing.h
 * @brief       倒计时模块接口定义
 * @date        2021-05-27
 */

#ifndef __VESYNC_TIMING_H__
#define __VESYNC_TIMING_H__

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif


/**
 * @brief vesync 倒计时结构体
 */
typedef struct
{
    uint16_t timing_id;      // 倒计时计数器ID
    uint32_t remain_second;  // 倒计时剩余秒数
    uint32_t total_second;   // 倒计时总秒数
} timing_data_t;


/**
 * @brief  vesync 倒计时初始化
 */
void vesync_timing_init(void);


/**
 * @brief  倒计时结束回调
 * @param[in]  timing_id          [倒计时id]
 */
typedef void (*timing_finish_cb_t)(uint16_t timing_id);


/**
 *@brief 清空timer内容并停止执行, APP删除设备或设备手动复位时清空timer内容并停止
 */
void vesync_timing_clear(void);


/**
 *@brief  清空当前ID的倒计时
 *@param[in]  timing_id           [倒计时id]
 */
void vesync_timing_remove(uint16_t timing_id);


/**
 * @brief  注册倒计时结束回调函数
 * @param[in]  cb        [倒计时结束回调函数指针]
 */
void vesync_timing_reg_cb(timing_finish_cb_t cb);


/**
 * @brief 获取倒计时剩余秒数
 * @param[in]  timing_id          [倒计时id]
 * @return uint32_t               [剩余秒数]
 */
uint32_t vesync_timing_get_remain_sec(uint16_t timing_id);


/**
 * @brief vesync 添加倒计时业务
 * @param[in]  timing_id          [倒计时id，取值范围：1~5]
 * @param[in]  second             [倒计时时间，单位秒]
 * @return  int                   [成功:SDK_OK, 失败:SDK_FAIL]
 */
int vesync_timing_add(uint16_t timing_id, uint32_t second);


/**
 * @brief 获取timer所有参数
 * @param[in]  timing_id          [倒计时id]
 * @param[out]  p_timing          [读取倒计时参数缓存指针]
 * @return int                    [成功:SDK_OK, 失败:SDK_FAIL]
 */
int vesync_timing_get(uint16_t timing_id ,timing_data_t *p_timing);


#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_TIMING_H__ */


