/**
* Copyright © Vesync Technologies Co.Ltd. 2022. All rights reserved.
* @file       vesync_sauth_cert.h
* @brief      Vesync Sauth Certificate declaration.
* @date       2022-03-03
* @note       File auto generated, DO NOT edit.
*/

#ifndef __VESYNC_SAUTH_CERT_H__
#define __VESYNC_SAUTH_CERT_H__

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#if CONFIG_VERYNS_SDK_SAUTH_UNSAFE_CERT
#define SAUTH_ROOT_CERT_PUB_SIZE (64)
#define SAUTH_DEV_CERT_PRI_SIZE (32)
#define SAUTH_DEV_CERTIFICATE_SIZE (421)

extern const uint8_t sauth_root_cert_pub[];
extern const uint8_t sauth_dev_cert_pri[];
extern const uint8_t sauth_dev_certificate[];
#endif

#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_SAUTH_CERT_H__ */
