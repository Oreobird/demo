/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_developer_internal.h
 * @brief       开发者模式接口
 * @date        2021-06-22
 */

#ifndef __VESYNC_DEVELOPER_INTERNAL_H__
#define __VESYNC_DEVELOPER_INTERNAL_H__

#include <stdbool.h>
#include <stdint.h>
#include "vesync_task.h"
#include "vesync_cfg_internal.h"

#ifdef __cplusplus
extern "C" {
#endif

#define VERR_UPLOAD(x, y)


//开发者模式的TCP服务器监听端口
#define DEVELOPER_LISTEN_PORT           55555
#define DEVELOPER_INVALID_SOCK          (-1)

// 调试任务(开发者模式)
#define DEVELOPER_TASK_NAME             "developer"
//
#if defined(PR_DEVELOPER_TASK_STACSIZE)
#define DEVELOPER_TASK_STACSIZE         (PR_DEVELOPER_TASK_STACSIZE)
#else
#define DEVELOPER_TASK_STACSIZE         (1024*2)
#endif
//
#define DEVELOPER_TASK_PRIO             TASK_PRIORITY_BELOW_NORMAL

// Close client socket, max wait 31(10+7*3) sec
#define VESYNC_DEVELOPER_KEEPALIVE     (1)     // enable/disable keepalive
#define VESYNC_DEVELOPER_KEEPIDLE      (10)    // if 10s no data recv from client, send keep-alive probe packet
#define VESYNC_DEVELOPER_KEEPINTV      (7)     // every 7s to send keep-alive probe packet
#define VESYNC_DEVELOPER_KEEPCNT       (3)     // send 3 times keep-alive probe packet

#define DEVELOPER_BUFFER_SIZE       (1024)

// 调试方法修改标识
#define DBG_CFG_CHANGE_DEVELOPER_FLAG       0x1
#define DBG_CFG_CHANGE_LOG_LVL_FLAG         0x2
#define DBG_CFG_CHANGE_LOG_RAW_LVL_FLAG     0x4

#define USER_CFG_KEY_DBG_CONFIG             "dbg_cfg"      // 调试标志位，详见dbg_cfg_t结构体定义

#ifndef PR_DEVELOPER_CFG_VERSION
#define PR_DEVELOPER_CFG_VERSION (1)
#endif

/**
 * @brief 调试方法配置
 */
typedef struct
{
    bool enable_developer;  // release固件，是否开启开发者模式
    uint8_t log_level;      // 控制日志打印级别
    uint8_t log_raw_level;  // 控制日志十六进制打印级别
    uint8_t data_version;
} dbg_cfg_t;

/**
 * @brief   启动开发者模式
 * @return    int           [启动结果，0为成功，其他值为失败]
 */
int vesync_developer_start(void);

/**
 * @brief 开发者模式停止
 * @return    void          [无]
 */
void vesync_developer_stop(void);

/**
 * @brief 清除调试方式配置
 * @param[in]  dbg_cfg_t   [保存调试方式配置]
 * @return int              [成功：SDK_OK，失败：SDK_FAIL]
 */
int vesync_developer_flash_clear_dbg_cfg(void);

/**
 * @brief 读取调试方式配置
 * @param[out]  dbg_cfg_t*   [保存调试方式配置]
 * @return int              [成功：SDK_OK，失败：SDK_FAIL]
 */
int vesync_developer_flash_read_dbg_cfg(dbg_cfg_t *p_dbg_cfg);

/**
 * @brief 调试方式设置，保存到用户分区，恢复出厂需要清除
 * @param[in]  dbg_cfg_t*        [调试方式配置]
 * @param[in]  uint8_t          [调试方式配置修改的变量]
 * @return int                  [成功：SDK_OK，失败：SDK_FAIL]
 */
int vesync_developer_flash_update_dbg_cfg(dbg_cfg_t *p_dbg_cfg, uint8_t flag);

/**
 * @brief   开发者模式初始化
 * @return    int           [启动结果，0为成功，其他值为失败]
 */
int vesync_developer_init(void);


/**
 * @brief   开发者模式退出
 */
void vesync_developer_deinit(void);

#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_DEVELOPER_INTERNAL_H__ */


