/**
 *  Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
 * @file        vhal_ble.c
 * @brief       蓝牙hal配置ble服务属性接口
 * @date        2021-09-01
 */

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#include "gap_adv.h"
#include "gap_bond_le.h"
#include "gap_msg.h"
#include "wifi_constants.h"
#include "app_msg.h"
#include "FreeRTOS.h"
#include "semphr.h"
#include "task.h"
#include "os_msg.h"
#include "app_msg.h"
#include "os_task.h"
#include "gap_conn_le.h"
#include "wifi_conf.h"
#include "hci_board.h"
#include "trace_app.h"
#include "gap_config.h"
#include "bte.h"
#include "rtk_coex.h"

#include "vesync_log.h"
#include "vesync_common.h"

#include "vhal_ble.h"
#include "vhal_ble_internal.h"
#include "vhal_ble_cmd_service.h"
#include "vhal_ble_netcfg_service.h"


extern void gap_config_hci_task_secure_context(uint32_t size);  // 此api必须extern定义

static uint8_t s_scan_rsp_data_len = 0;
static uint8_t s_adv_data_len = 0;


/**
 * @brief 广播扫描
 */
static uint8_t s_scan_rsp_data[GAP_MAX_ADV_LEN] =
{
    0x03,
    GAP_ADTYPE_LOCAL_NAME_COMPLETE,
};

/**
 * @brief 广播数据，协议参考蓝牙协议接口规范:http://wiki.vesync.com:8090/pages/viewpage.action?pageId=14254597
 */
static uint8_t s_adv_data[31] =
{
    /* Flags */
    0x02,             /* length */
    GAP_ADTYPE_FLAGS, /* type="Flags" */
    GAP_ADTYPE_FLAGS_GENERAL | GAP_ADTYPE_FLAGS_BREDR_NOT_SUPPORTED,
    /* Service */
    0x0f,             /* length */
    GAP_ADTYPE_MANUFACTURER_SPECIFIC,
    0xd0,0x06,
    0x01,0x36,0x35,0x34,0x33,0x32,0x31,0xe0,0xa0, 0x0, 0x0, 0x0
};

static void *vhal_ble_msg_task_handle = NULL; // Task handle
static void *evt_queue_handle = NULL;         // !< Event queue handle
static void *io_queue_handle = NULL;          // !< IO queue handle

static T_GAP_DEV_STATE vhal_ble_gap_dev_state = {0, 0, 0, 0, 0};               /**< GAP device state */
static T_GAP_CONN_STATE vhal_ble_gap_conn_state = GAP_CONN_STATE_DISCONNECTED; /**< GAP connection state */

static vhal_ble_evt_cb_t vhal_ble_evt_cb = NULL;
static vhal_ble_recv_cb_t vhal_ble_cmd_recv_cb = NULL;
static vhal_ble_recv_cb_t vhal_ble_netcfg_recv_cb = NULL;

static char s_adv_name[ADV_NAME_MAX_LEN + 1] = {0}; // 字符串多一个字符‘\0’
static VHAL_BLE_ADV_WORK_E s_ble_adv_work = BLE_ADV_WORK_NORMAL;
static uint16_t s_ble_max_send_length = BLE_SEND_LENTH_DEFAULT;
static SemaphoreHandle_t s_ble_send_xSemaphore = NULL;

static vhal_ble_status_t s_ble_status = {false, false, false, CONN_ID_INVALID};

/**
 * @brief 设置蓝牙事件
 * @param[in] evt       [蓝牙事件]
 */
static void vhal_ble_evt_set(VHAL_BLE_EVT_E evt)
{
    if(NULL != vhal_ble_evt_cb)
    {
        vhal_ble_evt_cb(evt);
    }
}

/**
  * @brief Callback for gap le to notify app
  * @param[in] cb_type          [callback msy type]
  * @param[in] p_cb_data        [point to callback data]
  * @return T_APP_RESULT
  */
static T_APP_RESULT vhal_ble_gap_callback(uint8_t cb_type, void *p_cb_data)
{
    T_APP_RESULT result = APP_RESULT_SUCCESS;

    if (NULL == p_cb_data)
    {
        return result;
    }

    T_LE_CB_DATA *p_data = (T_LE_CB_DATA *)p_cb_data;

    switch (cb_type)
    {
    case GAP_MSG_LE_MODIFY_WHITE_LIST:
        HAL_LOG(LOG_DEBUG, "GAP_MSG_LE_MODIFY_WHITE_LIST: operation %d, cause 0x%x\n",
                p_data->p_le_modify_white_list_rsp->operation,
                p_data->p_le_modify_white_list_rsp->cause);
        break;
    case GAP_MSG_LE_ADV_UPDATE_PARAM:
        HAL_LOG(LOG_DEBUG, "GAP_MSG_LE_ADV_UPDATE_PARAM: cause 0x%x\n", p_data->p_le_adv_update_param_rsp->cause);
        break;
    default:
        HAL_LOG(LOG_DEBUG, "vhal_ble_gap_callback: unhandled cb_type 0x%x\n", cb_type);
        break;
    }
    return result;
}

/**
 * @brief 蓝牙gap层初始化
 */
static void vhal_ble_gap_init(void)
{
    uint16_t appearance = GAP_GATT_APPEARANCE_UNKNOWN;
    uint8_t  slave_init_mtu_req = true;

    /* Advertising parameters */
    uint8_t  adv_evt_type = GAP_ADTYPE_ADV_IND;
    uint8_t  adv_direct_type = GAP_REMOTE_ADDR_LE_PUBLIC;
    uint8_t  adv_direct_addr[GAP_BD_ADDR_LEN] = {0};
    uint8_t  adv_chann_map = GAP_ADVCHAN_ALL;
    uint8_t  adv_filter_policy = GAP_ADV_FILTER_ANY;
    uint16_t adv_int_min = DEFAULT_ADVERTISING_INTERVAL_MIN;
    uint16_t adv_int_max = DEFAULT_ADVERTISING_INTERVAL_MIN;

    /* GAP Bond Manager parameters */
    uint8_t  auth_pair_mode = GAP_PAIRING_MODE_PAIRABLE;
    uint16_t auth_flags = GAP_AUTHEN_BIT_BONDING_FLAG;
    uint8_t  auth_io_cap = GAP_IO_CAP_NO_INPUT_NO_OUTPUT;

    uint8_t  auth_use_fix_passkey = false;
    uint32_t auth_fix_passkey = 0;
    uint8_t  auth_sec_req_enable = false;
    uint16_t auth_sec_req_flags = GAP_AUTHEN_BIT_BONDING_FLAG;

    /* Set device name and device appearance */
    le_set_gap_param(GAP_PARAM_DEVICE_NAME, strlen(s_adv_name), s_adv_name);
    le_set_gap_param(GAP_PARAM_APPEARANCE, sizeof(appearance), &appearance);
    le_set_gap_param(GAP_PARAM_SLAVE_INIT_GATT_MTU_REQ, sizeof(slave_init_mtu_req),
                     &slave_init_mtu_req);

    /* Set advertising parameters */
    le_adv_set_param(GAP_PARAM_ADV_EVENT_TYPE, sizeof(adv_evt_type), &adv_evt_type);
    le_adv_set_param(GAP_PARAM_ADV_DIRECT_ADDR_TYPE, sizeof(adv_direct_type), &adv_direct_type);
    le_adv_set_param(GAP_PARAM_ADV_DIRECT_ADDR, sizeof(adv_direct_addr), adv_direct_addr);
    le_adv_set_param(GAP_PARAM_ADV_CHANNEL_MAP, sizeof(adv_chann_map), &adv_chann_map);
    le_adv_set_param(GAP_PARAM_ADV_FILTER_POLICY, sizeof(adv_filter_policy), &adv_filter_policy);
    le_adv_set_param(GAP_PARAM_ADV_INTERVAL_MIN, sizeof(adv_int_min), &adv_int_min);
    le_adv_set_param(GAP_PARAM_ADV_INTERVAL_MAX, sizeof(adv_int_max), &adv_int_max);
    le_adv_set_param(GAP_PARAM_ADV_DATA, s_adv_data_len, (void *)s_adv_data);
    le_adv_set_param(GAP_PARAM_SCAN_RSP_DATA, s_scan_rsp_data_len, (void *)s_scan_rsp_data);

    /* Setup the GAP Bond Manager */
    gap_set_param(GAP_PARAM_BOND_PAIRING_MODE, sizeof(auth_pair_mode), &auth_pair_mode);
    gap_set_param(GAP_PARAM_BOND_AUTHEN_REQUIREMENTS_FLAGS, sizeof(auth_flags), &auth_flags);
    gap_set_param(GAP_PARAM_BOND_IO_CAPABILITIES, sizeof(auth_io_cap), &auth_io_cap);

    le_bond_set_param(GAP_PARAM_BOND_FIXED_PASSKEY, sizeof(auth_fix_passkey), &auth_fix_passkey);
    le_bond_set_param(GAP_PARAM_BOND_FIXED_PASSKEY_ENABLE, sizeof(auth_use_fix_passkey),
                      &auth_use_fix_passkey);
    le_bond_set_param(GAP_PARAM_BOND_SEC_REQ_ENABLE, sizeof(auth_sec_req_enable), &auth_sec_req_enable);
    le_bond_set_param(GAP_PARAM_BOND_SEC_REQ_REQUIREMENT, sizeof(auth_sec_req_flags),
                      &auth_sec_req_flags);

    /* register gap message callback */
    le_register_app_cb(vhal_ble_gap_callback);
}

/**
 * @brief All the BT Profile service callback events are handled in this function
 * @note  Then the event handling function shall be called according to the service_id
 * @param[in] service_id        [Profile service ID]
 * @param[in] p_data            [Pointer to callback data]
 * @return T_APP_RESULT         [which indicates the function call is successful or not]
 */
static T_APP_RESULT vhal_ble_gatt_callback(T_SERVER_ID service_id, void *p_data)
{
    T_APP_RESULT app_result = APP_RESULT_SUCCESS;

    if(NULL == p_data)
    {
        return app_result;
    }

    if (service_id == SERVICE_PROFILE_GENERAL_ID)
    {
        T_SERVER_APP_CB_DATA *p_param = (T_SERVER_APP_CB_DATA *)p_data;
        switch (p_param->eventId)
        {
        case PROFILE_EVT_SRV_REG_COMPLETE:// srv register result event.
            HAL_LOG(LOG_DEBUG,"PROFILE_EVT_SRV_REG_COMPLETE: result %d\n",p_param->event_data.service_reg_result);

            if(s_ble_status.stack_inited)
            {
                vhal_ble_evt_set(HB_EVT_INIT_COMPLETE);
            }
            else
            {
                s_ble_status.stack_inited = true;
            }
            break;
        case PROFILE_EVT_SEND_DATA_COMPLETE:

            if(pdTRUE != xSemaphoreGive(s_ble_send_xSemaphore))
            {
                HAL_LOG(LOG_ERROR, "xSemaphoreGive failed\n");
            }
            else
            {
                HAL_LOG(LOG_DEBUG,"xSemaphoreGive success\n");
            }
            // HAL_LOG(LOG_DEBUG,"PROFILE_EVT_SEND_DATA_COMPLETE: conn_id %d, cause 0x%x, service_id %d, attrib_idx 0x%x, credits %d\n",
            //                 p_param->event_data.send_data_result.conn_id,
            //                 p_param->event_data.send_data_result.cause,
            //                 p_param->event_data.send_data_result.service_id,
            //                 p_param->event_data.send_data_result.attrib_idx,
            //                 p_param->event_data.send_data_result.credits);
            if (p_param->event_data.send_data_result.cause == GAP_SUCCESS)
            {
                HAL_LOG(LOG_DEBUG,"PROFILE_EVT_SEND_DATA_COMPLETE success\n");
            }
            else
            {
                HAL_LOG(LOG_DEBUG,"PROFILE_EVT_SEND_DATA_COMPLETE failed\n");
            }
            break;

        default:
            break;
        }
    }

    return app_result;
}

/**
 * @brief All the BT Profile service callback events are handled in this function
 * @note  Then the event handling function shall be called according to the service_id
 * @param[in] service_id        [Profile service ID]
 * @param[in] p_data            [Pointer to callback data]
 * @return T_APP_RESULT         [which indicates the function call is successful or not]
 */
static T_APP_RESULT vhal_ble_cmd_service_callback(T_SERVER_ID service_id, void *p_data)
{
    T_APP_RESULT app_result = APP_RESULT_SUCCESS;

    if(NULL == p_data)
    {
        return app_result;
    }

    vhal_ble_service_cb_data_t *p_dat = (vhal_ble_service_cb_data_t *)p_data;

    if(SERVICE_CALLBACK_TYPE_WRITE_CHAR_VALUE == p_dat->msg_type)
    {
        if(NULL != vhal_ble_cmd_recv_cb)
        {
            vhal_ble_cmd_recv_cb(p_dat->msg_data.write.p_value , p_dat->msg_data.write.len);
        }

        // HAL_LOG(LOG_DEBUG, "ble cmd rx len: %d\n", p_dat->msg_data.write.len);
        // LOG_RAW_HEX(LOG_DEBUG,"ble cmd rx:" ,p_dat->msg_data.write.p_value , p_dat->msg_data.write.len);
    }
    else if(SERVICE_CALLBACK_TYPE_INDIFICATION_NOTIFICATION == p_dat->msg_type)
    {
        HAL_LOG(LOG_DEBUG, "cmd cccd 0x%04X\n",p_dat->msg_data.cccd.cccd_val);
    }

    return app_result;
}

/**
 * @brief All the BT Profile service callback events are handled in this function
 * @note  Then the event handling function shall be called according to the service_id
 * @param[in] service_id        [Profile service ID]
 * @param[in] p_data            [Pointer to callback data]
 * @return T_APP_RESULT         [which indicates the function call is successful or not]
 */
static T_APP_RESULT vhal_ble_net_cfg_service_callback(T_SERVER_ID service_id, void *p_data)
{
    T_APP_RESULT app_result = APP_RESULT_SUCCESS;

    if(NULL == p_data)
    {
        return app_result;
    }

    vhal_ble_service_cb_data_t *p_dat = (vhal_ble_service_cb_data_t *)p_data;

    if(SERVICE_CALLBACK_TYPE_WRITE_CHAR_VALUE == p_dat->msg_type)
    {
        if(NULL != vhal_ble_netcfg_recv_cb)
        {
            vhal_ble_netcfg_recv_cb(p_dat->msg_data.write.p_value , p_dat->msg_data.write.len);
        }

        // HAL_LOG(LOG_DEBUG, "ble net cfg rx len: %d\n", p_dat->msg_data.write.len);
        // LOG_RAW_HEX(LOG_DEBUG,"ble net cfg rx:" ,p_dat->msg_data.write.p_value , p_dat->msg_data.write.len);
    }
    else if(SERVICE_CALLBACK_TYPE_INDIFICATION_NOTIFICATION == p_dat->msg_type)
    {
        HAL_LOG(LOG_DEBUG, "net cfg cccd 0x%04X\n",p_dat->msg_data.cccd.cccd_val);
    }

    return app_result;
}

/**
 * @brief 蓝牙gatt层初始化
 */
static void vhal_ble_gatt_init(void)
{
    server_init(BLE_SERVICE_ADD_NUM);

    if(!vhal_ble_cmd_service_add((void *)vhal_ble_cmd_service_callback))
    {
        HAL_LOG(LOG_DEBUG,"add cmd service fail\n");
    }

    if(!vhal_ble_net_cfg_service_add((void *)vhal_ble_net_cfg_service_callback))
    {
        HAL_LOG(LOG_DEBUG,"add net cfg service fail\n");
    }

    server_register_app_cb(vhal_ble_gatt_callback);
}

/**
 * @brief Handle msg GAP_MSG_LE_DEV_STATE_CHANGE
 * @note  All the gap device state events are pre-handled in this function.
 *        Then the event handling function shall be called according to the new_state
 * @param[in] new_state         [New gap device state]
 * @param[in] cause             [GAP device state change cause]
 */
static void vhal_ble_gab_dev_state_evt(T_GAP_DEV_STATE new_state, uint16_t cause)
{
     HAL_LOG(LOG_DEBUG,": init state %d, adv state %d, cause 0x%x\n",new_state.gap_init_state, new_state.gap_adv_state, cause);

    if(vhal_ble_gap_dev_state.gap_init_state != new_state.gap_init_state)
    {
        if(new_state.gap_init_state == GAP_INIT_STATE_STACK_READY)
        {
             HAL_LOG(LOG_DEBUG,"GAP stack ready\n");

            if(s_ble_status.stack_inited)
            {
                vhal_ble_evt_set(HB_EVT_INIT_COMPLETE);
            }
            else
            {
                s_ble_status.stack_inited = true;
            }
        }
    }

    if(vhal_ble_gap_dev_state.gap_adv_state != new_state.gap_adv_state)
    {
        if(new_state.gap_adv_state == GAP_ADV_STATE_IDLE)
        {
            if(new_state.gap_adv_sub_state == GAP_ADV_TO_IDLE_CAUSE_CONN)
            {
                 HAL_LOG(LOG_DEBUG,"GAP adv stoped: because connection created\n");
            }
            else
            {
                HAL_LOG(LOG_DEBUG,"GAP adv stopped\n");
            }
        }
        else if(new_state.gap_adv_state == GAP_ADV_STATE_ADVERTISING)
        {
            HAL_LOG(LOG_DEBUG,"GAP adv start\n");
        }
    }

    vhal_ble_gap_dev_state = new_state;
}


/**
 * @brief Handle msg GAP_MSG_LE_CONN_STATE_CHANGE
 * @note  All the gap conn state events are pre-handled in this function.
 *        Then the event handling function shall be called according to the new_state
 * @param[in] conn_id           [Connection ID]
 * @param[in] new_state         [New gap connection state]
 * @param[in] disc_cause        [Use this cause when new_state is GAP_CONN_STATE_DISCONNECTED]
 */
static void vhal_ble_gap_conn_state_evt(uint8_t conn_id, T_GAP_CONN_STATE new_state, uint16_t disc_cause)
{
   HAL_LOG(LOG_DEBUG,"conn_id %d old_state %d new_state %d, disc_cause 0x%x\n",conn_id, vhal_ble_gap_conn_state, new_state, disc_cause);

    switch (new_state)
    {
    case GAP_CONN_STATE_DISCONNECTED:
        {
            if ((disc_cause != (HCI_ERR | HCI_ERR_REMOTE_USER_TERMINATE))
                && (disc_cause != (HCI_ERR | HCI_ERR_LOCAL_HOST_TERMINATE)))
            {
                HAL_LOG(LOG_DEBUG," connection lost cause 0x%x\n", disc_cause);
            }

            s_ble_status.conn_id = CONN_ID_INVALID;

            s_ble_max_send_length = BLE_SEND_LENTH_DEFAULT;
            HAL_LOG(LOG_DEBUG, "s_ble_max_send_length %d\n",s_ble_max_send_length);

            if(true == s_ble_status.adv_started)
            {
                vhal_ble_advertising_start();
            }
        }
        break;
    case GAP_CONN_STATE_CONNECTED:
        {
            uint16_t conn_interval;
            uint16_t conn_latency;
            uint16_t conn_supervision_timeout;
            uint8_t  remote_bd[6];
            T_GAP_REMOTE_ADDR_TYPE remote_bd_type;

            le_get_conn_param(GAP_PARAM_CONN_INTERVAL, &conn_interval, conn_id);
            le_get_conn_param(GAP_PARAM_CONN_LATENCY, &conn_latency, conn_id);
            le_get_conn_param(GAP_PARAM_CONN_TIMEOUT, &conn_supervision_timeout, conn_id);
            le_get_conn_addr(conn_id, remote_bd, (void *)&remote_bd_type);

            HAL_LOG(LOG_DEBUG," GAP_CONN_STATE_CONNECTED:conn_interval %d,%d ms conn_slave_latency 0x%X, conn_supervision_timeout %d,%d ms\n",
                            conn_interval,(int)(conn_interval * 1.25), (int)conn_latency, conn_supervision_timeout,(int)(conn_supervision_timeout *10));

            HAL_LOG(LOG_DEBUG, "remote_device_addr=%02X:%02X:%02X:%02X:%02X:%02X\n",
                    remote_bd[0], remote_bd[1], remote_bd[2],
                    remote_bd[3], remote_bd[4], remote_bd[5]);

            s_ble_status.conn_id = conn_id;
        }
        break;
    default:
        break;
    }
    vhal_ble_gap_conn_state = new_state;
}

/**
 * @brief Handle msg GAP_MSG_LE_CONN_MTU_INFO
 * @note  This msg is used to inform APP that exchange mtu procedure is completed.
 * @param[in] conn_id           [Connection ID]
 * @param[in] mtu_size          [New mtu size]
 */
static void vhal_ble_gap_mtu_info_evt(uint8_t conn_id, uint16_t mtu_size)
{
    HAL_LOG(LOG_DEBUG,"conn_id %d, mtu_size %d\n", conn_id, mtu_size);

    s_ble_max_send_length  = (mtu_size > (BLE_SEND_LENTH_DEFAULT + ATT_OPCODE_HANDLE_LEN)) ? (mtu_size - ATT_OPCODE_HANDLE_LEN) : BLE_SEND_LENTH_DEFAULT;

    HAL_LOG(LOG_DEBUG, "s_ble_max_send_length %d\n",s_ble_max_send_length);
}

/**
 * @brief Handle msg GAP_MSG_LE_CONN_PARAM_UPDATE
 * @note  All the connection parameter update change  events are pre-handled in this function.
 * @param[in] conn_id           [Connection ID]
 * @param[in] status            [New update state]
 * @param[in] cause             [Use this cause when status is GAP_CONN_PARAM_UPDATE_STATUS_FAIL]
 */
static void vhal_ble_gap_conn_param_update_evt(uint8_t conn_id, uint8_t status, uint16_t cause)
{
    switch(status)
    {
    case GAP_CONN_PARAM_UPDATE_STATUS_SUCCESS:
        {
            uint16_t conn_interval;
            uint16_t conn_slave_latency;
            uint16_t conn_supervision_timeout;

            le_get_conn_param(GAP_PARAM_CONN_INTERVAL, &conn_interval, conn_id);
            le_get_conn_param(GAP_PARAM_CONN_LATENCY, &conn_slave_latency, conn_id);
            le_get_conn_param(GAP_PARAM_CONN_TIMEOUT, &conn_supervision_timeout, conn_id);
            HAL_LOG(LOG_DEBUG," update success:conn_interval %d,%d ms conn_slave_latency 0x%X, conn_supervision_timeout %d,%d ms\n",
                            conn_interval,(int)(conn_interval * 1.25), (int)conn_slave_latency, conn_supervision_timeout,(int)(conn_supervision_timeout *10));
        }
        break;
    case GAP_CONN_PARAM_UPDATE_STATUS_FAIL:
        {
            HAL_LOG(LOG_DEBUG," update failed: cause 0x%x\n", cause);
        }
        break;
    case GAP_CONN_PARAM_UPDATE_STATUS_PENDING:
        {
            HAL_LOG(LOG_DEBUG," update pending.\n");
        }
        break;
    default:
        break;
    }
}

/**
 * @brief Handle msg GAP_MSG_LE_AUTHEN_STATE_CHANGE
 * @note  All the gap authentication state events are pre-handled in this function.
 *        Then the event handling function shall be called according to the new_state
 * @param[in] conn_id           [Connection ID]
 * @param[in] new_state         [New authentication state]
 * @param[in] cause             [Use this cause when new_state is GAP_AUTHEN_STATE_COMPLETE]
 */
static void vhal_ble_gap_authen_state_evt(uint8_t conn_id, uint8_t new_state, uint16_t cause)
{
    HAL_LOG(LOG_DEBUG,":conn_id %d, cause 0x%x", conn_id, cause);

    switch (new_state)
    {
    case GAP_AUTHEN_STATE_STARTED:
        {
            HAL_LOG(LOG_DEBUG,": GAP_AUTHEN_STATE_STARTED\n");
        }
        break;
    case GAP_AUTHEN_STATE_COMPLETE:
        {
            if (cause == GAP_SUCCESS)
            {
                HAL_LOG(LOG_DEBUG,": GAP_AUTHEN_STATE_COMPLETE pair success\n");
            }
            else
            {
                HAL_LOG(LOG_DEBUG,": GAP_AUTHEN_STATE_COMPLETE pair failed\n");
            }
        }
        break;
    default:
        {
            HAL_LOG(LOG_DEBUG,": unknown newstate %d\n", new_state);
        }
        break;
    }
}

/**
 * @brief gap消息处理
 * @param[in] p_gap_msg         [消息指针]
 */
static void vhal_ble_gap_msg_handle(T_IO_MSG *p_gap_msg)
{

    if(NULL == p_gap_msg)
    {
        return;
    }

    T_LE_GAP_MSG gap_msg;
    uint8_t conn_id;

    memcpy(&gap_msg, &p_gap_msg->u.param, sizeof(p_gap_msg->u.param));

   // HAL_LOG(LOG_DEBUG,"vhal_ble_gap_msg_handle: subtype %d\n", p_gap_msg->subtype);
    switch (p_gap_msg->subtype)
    {
    case GAP_MSG_LE_DEV_STATE_CHANGE:
        {
            vhal_ble_gab_dev_state_evt(gap_msg.msg_data.gap_dev_state_change.new_state,
                                    gap_msg.msg_data.gap_dev_state_change.cause);
        }
        break;
    case GAP_MSG_LE_CONN_STATE_CHANGE:
        {
            vhal_ble_gap_conn_state_evt(gap_msg.msg_data.gap_conn_state_change.conn_id,
                                    (T_GAP_CONN_STATE)gap_msg.msg_data.gap_conn_state_change.new_state,
                                    gap_msg.msg_data.gap_conn_state_change.disc_cause);
        }
        break;
    case GAP_MSG_LE_CONN_MTU_INFO:
        {
            vhal_ble_gap_mtu_info_evt(gap_msg.msg_data.gap_conn_mtu_info.conn_id,
                                        gap_msg.msg_data.gap_conn_mtu_info.mtu_size);
        }
        break;
    case GAP_MSG_LE_CONN_PARAM_UPDATE:
        {
            vhal_ble_gap_conn_param_update_evt(gap_msg.msg_data.gap_conn_param_update.conn_id,
                                            gap_msg.msg_data.gap_conn_param_update.status,
                                            gap_msg.msg_data.gap_conn_param_update.cause);
        }
        break;
    case GAP_MSG_LE_AUTHEN_STATE_CHANGE:
        {
            vhal_ble_gap_authen_state_evt(gap_msg.msg_data.gap_authen_state.conn_id,
                                        gap_msg.msg_data.gap_authen_state.new_state,
                                        gap_msg.msg_data.gap_authen_state.status);
        }
        break;
    case GAP_MSG_LE_BOND_JUST_WORK:
        {
            conn_id = gap_msg.msg_data.gap_bond_just_work_conf.conn_id;
            le_bond_just_work_confirm(conn_id, GAP_CFM_CAUSE_ACCEPT);
            HAL_LOG(LOG_DEBUG,"GAP_MSG_LE_BOND_JUST_WORK\n");
        }
        break;
    case GAP_MSG_LE_BOND_PASSKEY_DISPLAY:
        {
            uint32_t display_value = 0;
            conn_id = gap_msg.msg_data.gap_bond_passkey_display.conn_id;
            le_bond_get_display_key(conn_id, &display_value);
            HAL_LOG(LOG_DEBUG,"GAP_MSG_LE_BOND_PASSKEY_DISPLAY:passkey %d\n", display_value);
            le_bond_passkey_display_confirm(conn_id, GAP_CFM_CAUSE_ACCEPT);
        }
        break;
    case GAP_MSG_LE_BOND_USER_CONFIRMATION:
        {
            uint32_t display_value = 0;
            conn_id = gap_msg.msg_data.gap_bond_user_conf.conn_id;
            le_bond_get_display_key(conn_id, &display_value);
            HAL_LOG(LOG_DEBUG,"GAP_MSG_LE_BOND_USER_CONFIRMATION: passkey %d\n", display_value);
            le_bond_user_confirm(conn_id, GAP_CFM_CAUSE_ACCEPT);
        }
        break;
    case GAP_MSG_LE_BOND_PASSKEY_INPUT:
        {
            uint32_t passkey = 888888;
            conn_id = gap_msg.msg_data.gap_bond_passkey_input.conn_id;
            HAL_LOG(LOG_DEBUG,"GAP_MSG_LE_BOND_PASSKEY_INPUT: conn_id %d\n", conn_id);
            le_bond_passkey_input_confirm(conn_id, passkey, GAP_CFM_CAUSE_ACCEPT);
        }
        break;
    default:
        HAL_LOG(LOG_DEBUG,": unknown subtype %d\n", p_gap_msg->subtype);
        break;
    }
}


/**
 * @brief 消息处理
 *
 * @param[in] io_msg        [消息]
 */
static void vhal_ble_io_msg_handle(T_IO_MSG  io_msg)
{
    uint16_t msg_type = io_msg.type;

    switch(msg_type)
    {
    case IO_MSG_TYPE_BT_STATUS:
        {
            vhal_ble_gap_msg_handle(&io_msg);
        }
        break;
    case IO_MSG_TYPE_QDECODE:
        break;
    default:
        break;
    }
}

/**
 * @brief 蓝牙消息处理任务
 * @param[in] p_param       [入参]
 */
static void vhal_ble_msg_task(void *p_param)
{
    (void) p_param;
    uint8_t event;

#if defined(configENABLE_TRUSTZONE) && (configENABLE_TRUSTZONE == 1)
    rtw_create_secure_context(configMINIMAL_SECURE_STACK_SIZE + 256);
#endif

    if(!os_msg_queue_create(&io_queue_handle, MAX_NUMBER_OF_IO_MESSAGE, sizeof(T_IO_MSG)))
    {
        HAL_LOG(LOG_ERROR,"os_msg_queue_create fail\n");
    }
    if(!os_msg_queue_create(&evt_queue_handle, MAX_NUMBER_OF_EVENT_MESSAGE, sizeof(uint8_t)))
    {
        HAL_LOG(LOG_ERROR,"os_msg_queue_create fail\n");
    }

    if(!gap_start_bt_stack(evt_queue_handle, io_queue_handle, MAX_NUMBER_OF_GAP_MESSAGE))
    {
        HAL_LOG(LOG_ERROR,"gap_start_bt_stack fail\n");
    }

    while(1)
    {
        if(os_msg_recv(evt_queue_handle, &event, 0xFFFFFFFF) == true)
        {
            if(event == EVENT_IO_TO_APP)
            {
                T_IO_MSG io_msg;
                if(os_msg_recv(io_queue_handle, &io_msg, 0) == true)
                {
                    vhal_ble_io_msg_handle(io_msg);
                }
            }
            else
            {
                gap_handle_msg(event);
            }
        }
    }
}


/**
 * @brief cmd接口发送数据
 * @param[in] type          [发送数据类型]
 * @param[in] p_data        [发送数据指针]
 * @param[in] length        [发送数据长度]
 * @return int32_t          [VHAL_OK/VHAL_FAIL]
 */
static int32_t vhal_ble_data_send(VHAL_BLE_DATA_TYPE_E type, uint8_t *p_data, uint16_t length)
{
    int32_t ret = VHAL_OK;
    uint16_t offset = 0;
    uint16_t temp_len;
    uint8_t i;

    //HAL_LOG(LOG_DEBUG,"uxSemaphoreGetCount:%d\n",uxSemaphoreGetCount(s_ble_send_xSemaphore));

    for(i = 0; i < BLE_SEND_SEMAPHORE_MAX_CNT; i++)
    {
        if(pdTRUE != xSemaphoreGive(s_ble_send_xSemaphore))
        {
            HAL_LOG(LOG_ERROR, "xSemaphoreGive failed\n");
            break;
        }
        else
        {
            HAL_LOG(LOG_DEBUG, "xSemaphoreGive success\n");
        }
    }

    while(offset < length)
    {
        if(pdTRUE != xSemaphoreTake(s_ble_send_xSemaphore, 100 / portTICK_RATE_MS))
        {
            HAL_LOG(LOG_ERROR, "xSemaphoreTake failed\n");
        }
        else
        {
            HAL_LOG(LOG_DEBUG, "xSemaphoreTake success\n");
        }

        temp_len = ((length - offset) > s_ble_max_send_length ? s_ble_max_send_length : (length - offset));

        HAL_LOG(LOG_DEBUG, "hal ble cmd send start, offset=%d, temp_len=%d\n", offset, temp_len);

        if(VHAL_BLE_DATA_TYPE_CMD_SEND == type && false == vhal_ble_cmd_service_notify(s_ble_status.conn_id, p_data + offset, temp_len))
        {
            HAL_LOG(LOG_ERROR, "hal ble net cfg send failed\n");
            ret = VHAL_FAIL;
            break;
        }

        if(VHAL_BLE_DATA_TYPE_NET_CFG_SEND == type && false == vhal_ble_net_cfg_service_notify(s_ble_status.conn_id, p_data + offset, temp_len))
        {
            HAL_LOG(LOG_ERROR, "hal ble net cfg send failed\n");
            ret = VHAL_FAIL;
            break;
        }

        offset += temp_len;
    }

    return ret;
}

/**
 * @brief  初始化蓝牙协议栈及配置蓝牙广播参数
 * @param[in]  dev_name         [蓝牙设备名称]
 * @param[in]  soft_vesion      [软件版本号，必须是“1.0.00”的格式]
 * @param[in]  mfr_data         [厂商定义数据]
 * @return     int32_t          [执行结果 VHAL_OK/VHAL_FAIL]
 */
int32_t vhal_ble_init(char *dev_name, char *soft_vesion, ble_adv_mfr_data_t mfr_data)
{

    if((NULL == dev_name) || (strlen(dev_name) > ADV_NAME_MAX_LEN) ||
       (NULL == soft_vesion) || (6 != strlen(soft_vesion)))  //prj_version格式必须是“1.0.00”，所以长度必须是6
    {
        return VHAL_FAIL;
    }

    if(s_ble_status.init_flag)
    {
        return VHAL_FAIL;
    }

    vhal_ble_evt_set(HB_EVT_INIT);

    s_ble_status.stack_inited = false;

    strncpy(s_adv_name, dev_name, ADV_NAME_MAX_LEN);

    //格式参考http://wiki.vesync.com:8090/pages/viewpage.action?pageId=14254597
    s_scan_rsp_data[0] = strlen(dev_name) + 1;
    s_scan_rsp_data[1] = GAP_ADTYPE_LOCAL_NAME_COMPLETE;
    memcpy(&s_scan_rsp_data[2] ,  dev_name, strlen(dev_name));
    s_scan_rsp_data_len = strlen(dev_name) + 2;
    s_adv_data_len = MFR_DEFAULT_DATA_LEN + 5;

    uint8_t mac_addr[GAP_BD_ADDR_LEN] ={0x78, 0xd5, 0x38, 0x12, 0x34, 0x56};

    if(0 != bt_get_mac_address(mac_addr))
    {
        HAL_LOG(LOG_ERROR, "get mac failed\n");
    }

    HAL_LOG(LOG_DEBUG,"bt_get_mac_address:%02x:%02x:%02x:%02x:%02x:%02x\n",
            mac_addr[0], mac_addr[1], mac_addr[2], mac_addr[3], mac_addr[4], mac_addr[5]);

    for(uint8_t i = 0; i < sizeof(mac_addr); i++)
    {
        s_adv_data[8 + i] = mac_addr[GAP_BD_ADDR_LEN - 1 - i];
    }

    s_adv_data[14]  = mfr_data.product_type;
    s_adv_data[15] = mfr_data.product_model;
    s_adv_data[16] = mfr_data.cmd_code;         // 配网新需求新增，2020-03-17
    s_adv_data[17] = mfr_data.netcfg_ver;
    s_adv_data[18] = mfr_data.netcfg_status;

    s_ble_adv_work = mfr_data.ble_adv_work;

    T_GAP_DEV_STATE new_state;

    /*Wait WIFI init complete*/
    while(!(wifi_is_up(RTW_STA_INTERFACE) || wifi_is_up(RTW_AP_INTERFACE)))
    {
        vTaskDelay(1000 / portTICK_RATE_MS);
    }

    //judge BLE central is already on
    le_get_gap_param(GAP_PARAM_DEV_STATE , &new_state);
    if (new_state.gap_init_state == GAP_INIT_STATE_STACK_READY)
    {
        HAL_LOG(LOG_ERROR,"BT Stack already on\n");
        return VHAL_FAIL;
    }

    bt_trace_init();    //目前不调用此函数，原厂sdk的log有问题

    gap_config_max_le_link_num(BLE_MAX_LINKS);
    gap_config_max_le_paired_device(BLE_MAX_LINKS);
    gap_config_hci_task_secure_context (280);   //demo初始化为280，暂时没有说明
    bte_init();
    le_gap_init(BLE_MAX_LINKS);
    vhal_ble_gap_init();
    vhal_ble_gatt_init();

    if (vhal_ble_msg_task_handle == NULL)
    {
        if(!os_task_create(&vhal_ble_msg_task_handle, "vhal_ble_msg_task", vhal_ble_msg_task, 0, 1024*1, 3))
        {
            HAL_LOG(LOG_ERROR,"os_task_create fail \n");
            return VHAL_FAIL;
        }
    }
    else
    {
        HAL_LOG(LOG_ERROR,"vhal_ble_msg_task_handle is null\n");
        return VHAL_FAIL;
    }

    bt_coex_init();

    /*Wait BT init complete*/
    do
    {
        vTaskDelay(100 / portTICK_RATE_MS);
        le_get_gap_param(GAP_PARAM_DEV_STATE, &new_state);
    }while(new_state.gap_init_state != GAP_INIT_STATE_STACK_READY);

    /*Start BT WIFI coexistence*/
    extern void wifi_btcoex_set_bt_on(void);
    wifi_btcoex_set_bt_on();

    s_ble_send_xSemaphore = xSemaphoreCreateCounting(BLE_SEND_SEMAPHORE_MAX_CNT, BLE_SEND_SEMAPHORE_MAX_CNT);

    if(NULL == s_ble_send_xSemaphore)
    {
        APP_LOG(LOG_DEBUG, "xSemaphoreCreateMutex error \r\n");
    }

    s_ble_status.init_flag = true;

    HAL_LOG(LOG_DEBUG,"vhal ble init ok....\n");

    return VHAL_OK;
}

/**
 * @brief 注册蓝牙事件函数
 */
void vhal_ble_reg_evt_cb(vhal_ble_evt_cb_t cb)
{
    vhal_ble_evt_cb = cb;  //cb可以为NULL
}

/**
 * @brief 注册cmd接口接收回调
 */
void vhal_ble_reg_cmd_recv_cb(vhal_ble_recv_cb_t cb)
{
    vhal_ble_cmd_recv_cb = cb;  //cb可以为NULL
}

/**
 * @brief 注册配网接口接收回调
 */
void vhal_ble_reg_netcfg_recv_cb(vhal_ble_recv_cb_t cb)
{
    vhal_ble_netcfg_recv_cb = cb; //cb可以为NULL
}


/**
 * @brief 启动广播
 * @return int32_t      [VHAL_OK/VHAL_FAIL]
 */
int32_t vhal_ble_advertising_start(void)
{
    s_ble_status.adv_started = true;

    if(GAP_CAUSE_SUCCESS != le_adv_start())
    {
        return VHAL_FAIL;
    }

    return VHAL_OK;
}

/**
 * @brief 停止广播
 * @return int32_t      [VHAL_OK/VHAL_FAIL]
 */
int32_t vhal_ble_advertising_stop(void)
{
    s_ble_status.adv_started = false;

    if(GAP_CAUSE_SUCCESS != le_adv_stop())
    {
        return VHAL_FAIL;
    }

    return VHAL_OK;
}

/**
 * @brief 主动断开当前的蓝牙连接
 * @return int32_t      [VHAL_OK/VHAL_FAIL]
 */
int32_t vhal_ble_disconnect(void)
{
    if(GAP_CAUSE_SUCCESS != le_disconnect(s_ble_status.conn_id))
    {
        return VHAL_FAIL;
    }

    return VHAL_OK;
}

/**
 * @brief 蓝牙广播动态修改配网状态
 * @param[in] netcfg_status     [设备配网状态]
 * @return int32_t              [VHAL_OK/VHAL_FAIL]
 */
int32_t vhal_ble_set_adv_netcfg_status(uint8_t netcfg_status)
{
    if(GAP_ADV_STATE_ADVERTISING == vhal_ble_gap_dev_state.gap_adv_state)
    {
        if(GAP_CAUSE_SUCCESS == le_adv_stop())
        {
            while(GAP_ADV_STATE_IDLE != vhal_ble_gap_dev_state.gap_adv_state)
            {
                vTaskDelay(20 / portTICK_RATE_MS);
            }
        }
        else
        {
            HAL_LOG(LOG_ERROR, "le_adv_stop failed \n");
            return VHAL_FAIL;
        }
    }

    s_adv_data[18] = netcfg_status;

    if(GAP_CAUSE_SUCCESS != le_adv_set_param(GAP_PARAM_ADV_DATA, sizeof(s_adv_data), (void *)s_adv_data))
    {
        return VHAL_FAIL;
    }

    // if(GAP_CAUSE_SUCCESS != le_adv_update_param())
    // {
    //     HAL_LOG(LOG_ERROR, "le_adv_update_param failed \n");
    //     return VHAL_FAIL;
    // }

    if(s_ble_status.adv_started)
    {
        if(GAP_CAUSE_SUCCESS != le_adv_start())
        {
            HAL_LOG(LOG_ERROR, "le_adv_start failed \n");
            return VHAL_FAIL;
        }
    }

    return VHAL_OK;
}

/**
 * @brief 动态修改广播参数
 * @param[in] product_type
 * @param[in] product_model
 * @return int32_t              [VHAL_OK/VHAL_FAIL]
 */
int32_t vhal_ble_set_adv_product_info(uint8_t product_type, uint8_t product_model)
{
    if(GAP_ADV_STATE_ADVERTISING == vhal_ble_gap_dev_state.gap_adv_state)
    {
        if(GAP_CAUSE_SUCCESS == le_adv_stop())
        {
            while(GAP_ADV_STATE_IDLE != vhal_ble_gap_dev_state.gap_adv_state)
            {
                vTaskDelay(20 / portTICK_RATE_MS);
            }
        }
        else
        {
            HAL_LOG(LOG_ERROR, "le_adv_stop failed \n");
            return VHAL_FAIL;
        }
    }

    s_adv_data[14] = product_type;
    s_adv_data[15] = product_model;

    if(GAP_CAUSE_SUCCESS != le_adv_set_param(GAP_PARAM_ADV_DATA, sizeof(s_adv_data), (void *)s_adv_data))
    {
        return VHAL_FAIL;
    }

    // if(GAP_CAUSE_SUCCESS != le_adv_update_param())
    // {
    //     HAL_LOG(LOG_ERROR, "le_adv_update_param failed \n");
    //     return VHAL_FAIL;
    // }

    if(s_ble_status.adv_started)
    {
        if(GAP_CAUSE_SUCCESS != le_adv_start())
        {
            HAL_LOG(LOG_ERROR, "le_adv_start failed \n");
            return VHAL_FAIL;
        }
    }

    return VHAL_OK;
}


/**
 * @brief 动态修改广播命令字段
 * @param[in] cmd_data           [命令数据段]
 * @param[in] cmd_len            [命令数据长度]
 * @param[in] up_flag            [是否更新广播包长度]
 * @return  int32_t              [成功：VHAL_OK，失败：VHAL_FAIL]
 */
int32_t vhal_ble_set_adv_cmd_data(uint8_t * cmd_data, uint8_t cmd_len, bool up_flag)

{
    if ((NULL == cmd_data) || (MFR_MAX_CMD_DATA_LEN < cmd_len))
    {
        return VHAL_FAIL;
    }

    if(GAP_ADV_STATE_ADVERTISING == vhal_ble_gap_dev_state.gap_adv_state)
    {
        if(GAP_CAUSE_SUCCESS == le_adv_stop())
        {
            while(GAP_ADV_STATE_IDLE != vhal_ble_gap_dev_state.gap_adv_state)
            {
                vTaskDelay(20 / portTICK_RATE_MS);
            }
        }
        else
        {
            HAL_LOG(LOG_ERROR, "le_adv_stop failed \n");
            return VHAL_FAIL;
        }
    }

    memcpy(&s_adv_data[16], cmd_data, cmd_len);
    if (true == up_flag )
    {
        s_adv_data_len = s_adv_data_len + cmd_len - 3;
    }
    if(GAP_CAUSE_SUCCESS != le_adv_set_param(GAP_PARAM_ADV_DATA, s_adv_data_len, (void *)s_adv_data))
    {
        HAL_LOG(LOG_ERROR, "update adv data failed \n");
    }

    if(s_ble_status.adv_started)
    {
        if(GAP_CAUSE_SUCCESS != le_adv_start())
        {
            HAL_LOG(LOG_ERROR, "le_adv_start failed \n");
            return VHAL_FAIL;
        }
    }

    return VHAL_OK;

}


/**
 * @brief cmd接口发送数据
 * @param[in] p_data        [发送数据指针]
 * @param[in] len           [发送数据长度]
 * @return int32_t          [VHAL_OK/VHAL_FAIL]
 */
int32_t vhal_ble_cmd_data_send(uint8_t *p_data, uint16_t len)
{
    if(NULL == p_data || 0 == len)
    {
        return VHAL_FAIL;
    }

    return vhal_ble_data_send(VHAL_BLE_DATA_TYPE_CMD_SEND, p_data, len);
}

/**
 * @brief update接口发送数据
 * @param[in] p_data        [发送数据指针]
 * @param[in] len           [发送数据长度]
 * @return int32_t          [VHAL_OK/VHAL_FAIL]
 */
int32_t vhal_ble_update_data_send(uint8_t *p_data, uint16_t len)
{
    return VHAL_OK;
}

/**
 * @brief 配网接口发送数据
 * @param[in] p_data        [发送数据指针]
 * @param[in] len           [发送数据长度]
 * @return int32_t          [VHAL_OK/VHAL_FAIL]
 */
int32_t vhal_ble_netcfg_data_send(uint8_t *p_data, uint16_t len)
{
    if(NULL == p_data || 0 == len)
    {
        return VHAL_FAIL;
    }

    return vhal_ble_data_send(VHAL_BLE_DATA_TYPE_NET_CFG_SEND, p_data, len);
}


/**
 * @brief 蓝牙是否连接成功
 * @return true 连接 false 未连接
 */
bool vhal_ble_is_connected(void)
{
    return (CONN_ID_INVALID != s_ble_status.conn_id);
}

/**
 * @brief 关闭蓝牙功能
 * @return int32_t      [VHAL_OK/VHAL_FAIL]
 */
int32_t vhal_ble_disable(void)
{
    int32_t ret;

    s_ble_status.adv_started = false;

    if(vhal_ble_is_connected())
    {
        ret = vhal_ble_disconnect();
    }
    else
    {
        ret = vhal_ble_advertising_stop();
    }

    return ret;
}

/**
 * @brief 用于判断蓝牙是否已经初始化
 * @return bool   [true 已经初始化; false 未初始化]
 */
bool vhal_ble_is_init(void)
{
    return s_ble_status.init_flag;
}

/**
 * @brief  获取BLE MAC
 * @param[out] dev_mac      [输出蓝牙MAC buffer]
 * @param[in]  max_len      [buffer 长度]
 * @return     int32_t      [执行结果 VHAL_OK/VHAL_FAIL]
 */
int32_t vhal_ble_get_mac(char *dev_mac, uint32_t max_len)
{
    uint8_t mac_addr[MAC_ADDR_HEX_LEN] = {0};

    if(NULL == dev_mac || max_len < MAC_ADDR_STR_MAX_LEN)
    {
        HAL_LOG(LOG_ERROR, "param invalid\n");
        return VHAL_FAIL;
    }

    if(0 != bt_get_mac_address(mac_addr))
    {
        HAL_LOG(LOG_ERROR, "get mac failed\n");
        return VHAL_FAIL;
    }

    snprintf(dev_mac, max_len, "%02x:%02x:%02x:%02x:%02x:%02x",
             mac_addr[0], mac_addr[1], mac_addr[2],
             mac_addr[3], mac_addr[4], mac_addr[5]);

    return VHAL_OK;
}
