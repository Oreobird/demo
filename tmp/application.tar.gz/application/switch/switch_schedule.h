/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        switch_schedule.h
 * @brief       switch schedule头文件
 * @author      Charles.Mei
 * @date        2021-08-05
 */


#include <stdint.h>

#include "vesync_schedule.h"
#include "vesync_buffer.h"
#include "vesync_bypass.h"

#include "switch_app.h"

#ifndef __SWITCH_SCHEDULE_H__
#define __SWITCH_SCHEDULE_H__

#ifdef __cplusplus
extern "C" {
#endif

#define SWITCH_SCHEDULE_MIN_ID (100)         // Schedule最小ID
#define SWITCH_SCHEDULE_MAX_NUM (26)         // Schedule最大条目数
#define SWITCH_SCHEDULE_GET_MAX_NUM (6)      // 一次Schedule查询最大的返回数量
#define SWITCH_SCHEDULE_MAX_APP_CFG_SIZE (8) // 配置读取Buffer大小

#define SWITCH_SCHE_INS_LIGHT_ID    (1)         // light Schedule实例ID
#define SWITCH_SCHE_INS_FAN_ID      (2)         // fan Schedule实例ID


/**
 * @brief Bypass添加Schedule配置项
 * @param[in]   dev_id      [设备id]
 * @param[in]   sch_cfg     [Schedule配置]
 * @param[in]   action      [Schedule动作]
 * @param[out]  p_out_id    [添加成功后，返回生成的ID]
 * @return int              [返回BYPASS的错误定义]
 */
int switch_schedule_add(DEVICE_ID_E dev_id, vesync_schedule_t *sch_cfg, void *action, uint32_t *p_out_id);

/**
 * @brief Bypass更新Schedule配置项
 * @param[in]   dev_id      [设备id]
 * @param[in]   sch_cfg     [Schedule配置]
 * @param[in]   action      [Schedule动作]
 * @param[out]  p_out_id    [添加成功后，返回生成的ID]
 * @return int              [返回BYPASS的错误定义]
 */
int switch_schedule_upd(DEVICE_ID_E dev_id, vesync_schedule_t *sch_cfg, void *action, uint32_t *p_out_id);

/**
 * @brief Bypass按顺序获取Schedule多个配置项
 * @note  返回多少个连续的配置项是由Schedule模块决定
 * @param[in]  dev_id       [设备id]
 * @param[in]  index        [要获取的Schedule配置项的初始序号]
 * @param[in]  sche_cfg     [schedule配置数组]
 * @param[in]  action       [schedule动作数组]
 * @param[in]  cur_num      [返回的schedule数]
 * @param[in]  total_num    [配置项总数]
 * @return int              [返回BYPASS的错误定义]
 */
int switch_schedule_get_mult(DEVICE_ID_E dev_id, uint32_t index, vesync_schedule_t *sche_cfg, void *action, uint32_t *cur_num, uint32_t *total_num);

/**
 * @brief Bypass删除指定ID的Schedule配置项
 * @param[in]   dev_id      [设备id]
 * @param[in]   id_to_del   [要删除的Schedule配置项ID]
 * @return      int         [返回BYPASS的错误定义]
 */
int switch_schedule_del(DEVICE_ID_E dev_id, uint32_t id_to_del);

/**
 * @brief App层调用，复位Schedule的所有配置信息
 * @return      int         [返回APP的错误定义： APP_OK, APP_FAIL]
 */
int switch_schedule_clear(void);

/**
 * @brief 初始化Schedule功能
 * @return      int         [返回APP的错误定义： APP_OK, APP_FAIL]
 */
int switch_schedule_init(void);


#ifdef __cplusplus
}
#endif

#endif


