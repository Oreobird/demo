/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        bulb_status.c
 * @brief       灯泡色彩控制
 * @author      Dave.Ming
 * @date        2021-08-31
 */

#include <stdint.h>
#include <string.h>
#include <stdbool.h>

#include "vesync_log.h"
#include "vesync_common.h"
#include "vesync_task.h"

#include "bulb_flash.h"
#include "bulb_status.h"
#include "bulb_bypass.h"

#include "bulb_def.h"
#include "bulb_board.h"

static bulb_led_data_t s_tgt_led_data;
static bulb_led_data_t s_cur_led_data;
static bulb_led_data_t s_tmp_led_data;

static bool s_new_tgt_flag = false;

#if BULB_DRIVER_TYPE == BULB_DRV_BY_BP5758
#include "vdrv_bp5758d.h"
static bp5758d_range_t s_bp5758d_range;
#elif BULB_DRIVER_TYPE == BULB_DRV_BY_LEDC
#include "vhal_led.h"
#define VLED_CW_CH (LED_CH0) // 冷光的led通道
#define VLED_WW_CH (LED_CH1) // 暖光的led通道
#define VLED_R_CH (LED_CH2)  // 红光的led通道
#define VLED_G_CH (LED_CH3)  // 绿光的led通道
#define VLED_B_CH (LED_CH4)  // 蓝光的led通道
#define VLED_NUM (5)         // 配置的led数量
#elif BULB_DRIVER_TYPE == BULB_DRV_BY_SM2235
#include "vdrv_sm2235egh.h"
#else
#error "BULB_DRIVER_TYPE is invalid"
#endif /* BULB_DRIVER_TYPE */

#if BULB_DRIVER_TYPE == BULB_DRV_BY_BP5758
/**
 * @brief BP5758D设置量程
 */
static void bp5758_update_range_cfg(void)
{
    s_bp5758d_range.out_num = 5;
    s_bp5758d_range.outs[0] = BULB_BULE_OUT_IO;
    s_bp5758d_range.outs[1] = BULB_WARM_OUT_IO;
    s_bp5758d_range.outs[2] = BULB_COLD_OUT_IO;
    s_bp5758d_range.outs[3] = BULB_GREEN_OUT_IO;
    s_bp5758d_range.outs[4] = BULB_RED_OUT_IO;
    s_bp5758d_range.data[0] = BULB_BULE_MAX;
    s_bp5758d_range.data[1] = BULB_WARM_MAX;
    s_bp5758d_range.data[2] = BULB_COLD_MAX;
    s_bp5758d_range.data[3] = BULB_GREEN_MAX;
    s_bp5758d_range.data[4] = BULB_RED_MAX;
}

/**
 * @brief BP5758D配置更新与设置
 * @param[in] p_led     [输入的五路LED PWM量]
 */
static void set_driver_output(bulb_led_data_t *p_led)
{
    bp5758d_gray_t bp5758d_gray;
    bp5758d_gray.out_num = 5;
    bp5758d_gray.outs[0] = BULB_BULE_OUT_IO;
    bp5758d_gray.outs[1] = BULB_WARM_OUT_IO;
    bp5758d_gray.outs[2] = BULB_COLD_OUT_IO;
    bp5758d_gray.outs[3] = BULB_GREEN_OUT_IO;
    bp5758d_gray.outs[4] = BULB_RED_OUT_IO;
    bp5758d_gray.data[0] = p_led->blue;
    bp5758d_gray.data[1] = p_led->warm;
    bp5758d_gray.data[2] = p_led->cold;
    bp5758d_gray.data[3] = p_led->green;
    bp5758d_gray.data[4] = p_led->red;

    if (SDK_OK != vdrv_bp5758d_range_cfg(&s_bp5758d_range))
    {
        APP_LOG(LOG_ERROR, "set bp5758 range fail\n");
    }
    if (SDK_OK != vdrv_bp5758d_gray_cfg(&bp5758d_gray))
    {
        APP_LOG(LOG_ERROR, "set bp5758 gray fail\n");
    }
    if (SDK_OK != vdrv_bp5758d_cfg_write())
    {
        APP_LOG(LOG_ERROR, "write bp5758 cfg fail\n");
    }
}
#elif BULB_DRIVER_TYPE == BULB_DRV_BY_LEDC
/**
 * @brief 设置VHAL_LED输出
 * @param[in] p_led     [输入的五路LED PWM量]
 */
static void set_driver_output(bulb_led_data_t *p_led)
{
    vhal_led_set_duty_bits(VLED_CW_CH, p_led->cold, BULB_PWM_MAX_SCALE);
    vhal_led_set_duty_bits(VLED_WW_CH, p_led->warm, BULB_PWM_MAX_SCALE);
    vhal_led_set_duty_bits(VLED_R_CH, p_led->red, BULB_PWM_MAX_SCALE);
    vhal_led_set_duty_bits(VLED_G_CH, p_led->green, BULB_PWM_MAX_SCALE);
    vhal_led_set_duty_bits(VLED_B_CH, p_led->blue, BULB_PWM_MAX_SCALE);
}
#elif BULB_DRIVER_TYPE == BULB_DRV_BY_SM2235
/**
 * @brief 设置VHAL_LED输出
 * @param[in] p_led     [输入的五路LED PWM量]
 */
static void set_driver_output(bulb_led_data_t *p_led)
{
    uint16_t ch_remap[5];
    ch_remap[BULB_RED_OUT_IO - 1] = p_led->red;
    ch_remap[BULB_GREEN_OUT_IO - 1] = p_led->green;
    ch_remap[BULB_BULE_OUT_IO - 1] = p_led->blue;
    ch_remap[BULB_COLD_OUT_IO - 1] = p_led->cold;
    ch_remap[BULB_WARM_OUT_IO - 1] = p_led->warm;

    sm2235egh_gray_t rgb, cw;
    rgb.rgb.out_1r = ch_remap[0];
    rgb.rgb.out_2g = ch_remap[1];
    rgb.rgb.out_3b = ch_remap[2];
    cw.cw.out_4c = ch_remap[3];
    cw.cw.out_5w = ch_remap[4];
    int ret = vdrv_sm2235egh_set_output(&rgb, &cw);
    if (ret != SDK_OK)
    {
        APP_LOG(LOG_WARN, "sm2235egh_set_output fail\n");
    }
}
#else
#error "BULB_DRIVER_TYPE is invalid"
#endif /* BULB_DRIVER_TYPE */

/**
 * @brief HSV to RGB的色域参数转换为PWM控制量
 * @param[in,out] p_led     [输出的LED PWM控制量]
 * @param[in]     H         [色相]
 * @param[in]     S         [饱和度]
 * @param[in]     V         [明度]
 */
static void set_led_hsv_to_rgb(bulb_led_data_t *p_led, uint16_t H, uint16_t S, uint8_t V)
{
    uint16_t hi = (H / 1667) % 6;
    double F = (double)H / 1667 * 100 - 100 * (double)hi;

    // 给明度做相应的偏置，消除超低亮度下混光偏色的问题
    double ofs_v = ((double)V / 100) * (100 - BULB_RGB_MIN_PERCENT) + BULB_RGB_MIN_PERCENT;

    double P = ofs_v * (10000 - (double)S) / 10000;
    double Q = ofs_v * (1000000 - F * (double)S) / 1000000;
    double T = ofs_v * (1000000 - (double)S * (100 - F)) / 1000000;
    double red, green, blue;

    switch (hi)
    {
    case 0:
        red = ofs_v;
        green = T;
        blue = P;
        break;
    case 1:
        red = Q;
        green = ofs_v;
        blue = P;
        break;
    case 2:
        red = P;
        green = ofs_v;
        blue = T;
        break;
    case 3:
        red = P;
        green = Q;
        blue = ofs_v;
        break;
    case 4:
        red = T;
        green = P;
        blue = ofs_v;
        break;
    case 5:
        red = ofs_v;
        green = P;
        blue = Q;
        break;
    default:
        APP_LOG(LOG_WARN, "invalid hsv args\n");
        return;
    }
    double red_ratio = red / (red + green + blue);
    double green_ratio = green / (red + green + blue);
    double blue_ratio = blue / (red + green + blue);
    double scaling = ofs_v / 100;

    uint16_t pwm_red = (uint16_t)(red_ratio * BULB_PWM_MAX_SCALE * scaling);
    uint16_t pwm_green = (uint16_t)(green_ratio * BULB_PWM_MAX_SCALE * scaling);
    uint16_t pwm_blue = (uint16_t)(blue_ratio * BULB_PWM_MAX_SCALE * scaling);

    // 最大量程限制
    p_led->red = (pwm_red >= BULB_PWM_MAX_SCALE) ? (BULB_PWM_MAX_SCALE - 1) : pwm_red;
    p_led->green = (pwm_green >= BULB_PWM_MAX_SCALE) ? (BULB_PWM_MAX_SCALE - 1) : pwm_green;
    p_led->blue = (pwm_blue >= BULB_PWM_MAX_SCALE) ? (BULB_PWM_MAX_SCALE - 1) : pwm_blue;
    p_led->warm = 0;
    p_led->cold = 0;
#if 0
    APP_LOG(LOG_DEBUG, "RGB calculate result: R[%f], G[%f], B[%f]; Scaling[%f]\n",
            red, green, blue, ofs_v);
    APP_LOG(LOG_DEBUG, "PWM calculate result: R[%d], G[%d], B[%d], sum[%d]\n",
            p_led->red, p_led->green, p_led->blue, p_led->red + p_led->green + p_led->blue);
#endif
}

/**
 * @brief 白光模式色温与亮度转换为PWM控制量
 * @param[in,out] p_led     [输出的LED PWM控制量]
 * @param[in]     temp      [色温]
 * @param[in]     bright    [亮度]
 */
static void set_led_kl_to_pwm(bulb_led_data_t *p_led, uint8_t temp, uint8_t bright)
{
    double ofs_b = ((double)bright / 100) * (BULB_W_MAX_PERCENT - BULB_W_MIN_PERCENT) + BULB_W_MIN_PERCENT;

#if BULB_WHITE_IS_CW == 1
    uint16_t pwm_cold = temp * ofs_b * BULB_PWM_MAX_SCALE / 10000;
    uint16_t pwm_warm = (BULB_TEMP_MAX - temp) * ofs_b * BULB_PWM_MAX_SCALE / 10000;
#elif BULB_WHITE_IS_CW == 0
    // CCT控制亮度的PWM路
    uint16_t pwm_cold = ofs_b / 100 * BULB_PWM_MAX_SCALE;
    // CCT控制色温的PWM路
#if BULB_CCT_TEMP_INVERT == 0
    uint16_t pwm_warm = temp * BULB_PWM_MAX_SCALE / 100;
#elif BULB_CCT_TEMP_INVERT == 1
    uint16_t pwm_warm = (BULB_TEMP_MAX - temp) * BULB_PWM_MAX_SCALE / 100;
#else
#error "BULB_CCT_TEMP_INVERT is invalid"
#endif /* BULB_CCT_TEMP_INVERT */
#else
#error "BULB_WHITE_IS_CW is invalid"
#endif /* BULB_WHITE_IS_CW */

    // 最大量程限制
    p_led->red = 0;
    p_led->green = 0;
    p_led->blue = 0;
    p_led->cold = (pwm_cold >= BULB_PWM_MAX_SCALE) ? (BULB_PWM_MAX_SCALE - 1) : pwm_cold;
    p_led->warm = (pwm_warm >= BULB_PWM_MAX_SCALE) ? (BULB_PWM_MAX_SCALE - 1) : pwm_warm;
#if 0
    APP_LOG(LOG_DEBUG, "CWW: bright[%d], ofs_bright[%d]\n", bright, (uint8_t)ofs_b);
    APP_LOG(LOG_DEBUG, "PWM calculate result: C[%d], W[%d]\n", p_led->cold, p_led->warm);
#endif
}

/**
 * @brief 设置所有LED PWM控制量为零
 * @param[in,out] p_led     [输出的LED PWM控制量]
 */
static void set_led_down(bulb_led_data_t *p_led)
{
    p_led->red = 0;
    p_led->green = 0;
    p_led->blue = 0;
    p_led->cold = 0;
    p_led->warm = 0;
}

/**
 * @brief 灯效渐变下一步参数计算
 * @param[in]  remind_step        [剩下转换步数]
 * @param[in]  cur_param          [当前参数值]
 * @param[in]  tgt_param          [目标参数值]
 * @return int                    [下一步参数值]
 */
static uint16_t bulb_led_next_param(uint8_t remind_step, uint16_t cur_param, uint16_t tgt_param)
{
    if ((BULB_GRADIENT_STEP - 1) <= remind_step || cur_param == tgt_param)
    {
        return tgt_param;
    }

    if (tgt_param >= cur_param)
    {
        return cur_param + (tgt_param - cur_param) * (remind_step + 1) / BULB_GRADIENT_STEP;
    }
    else
    {
        return cur_param - (cur_param - tgt_param) * (remind_step + 1) / BULB_GRADIENT_STEP;
    }
}

/**
 * @brief  设备颜色切换时的渐变
 */
static void bulb_open_gradient(void)
{
    memcpy(&s_tmp_led_data, &s_cur_led_data, sizeof(s_cur_led_data));
    for (int i = 0; i < BULB_GRADIENT_STEP; i++)
    {
        if (s_new_tgt_flag)
        {
            i = 0;
            s_new_tgt_flag = false;
        }
        s_cur_led_data.blue = bulb_led_next_param(i, s_tmp_led_data.blue, s_tgt_led_data.blue);
        s_cur_led_data.warm = bulb_led_next_param(i, s_tmp_led_data.warm, s_tgt_led_data.warm);
        s_cur_led_data.cold = bulb_led_next_param(i, s_tmp_led_data.cold, s_tgt_led_data.cold);
        s_cur_led_data.red = bulb_led_next_param(i, s_tmp_led_data.red, s_tgt_led_data.red);
        s_cur_led_data.green = bulb_led_next_param(i, s_tmp_led_data.green, s_tgt_led_data.green);
        set_driver_output(&s_cur_led_data);

        vesync_sleep(BULB_GRADIENT_TIME / BULB_GRADIENT_STEP);
    }
}

/**
 * @brief 检查渐变目标是否与当前相同
 * @param[in]  bulb_led_data_t      [下一目标数据]
 * @return int                      [相同：false， 不同：true]
 */
static int bulb_gradient_tgt_check(bulb_led_data_t data)
{
    int ret = false;
    if ((data.blue != s_tgt_led_data.blue) ||
        (data.red != s_tgt_led_data.red) ||
        (data.cold != s_tgt_led_data.cold) ||
        (data.warm != s_tgt_led_data.warm) ||
        (data.green != s_tgt_led_data.green))
    {
        s_tgt_led_data.blue = data.blue;
        s_tgt_led_data.red = data.red;
        s_tgt_led_data.cold = data.cold;
        s_tgt_led_data.warm = data.warm;
        s_tgt_led_data.green = data.green;
        ret = true;
    }
    return ret;
}

/**
 * @brief 更新渐变目标
 */
void bulb_gradient_new_tgt_set(void)
{
    bulb_led_data_t new_tgt_led_data;
    if (bulb_get_config(BULB_CFG_COLOR_MODE))
    {
        set_led_hsv_to_rgb(&new_tgt_led_data,
                           bulb_get_config(BULB_CFG_COLOR_HUE),
                           bulb_get_config(BULB_CFG_COLOR_SATURATION),
                           bulb_get_config(BULB_CFG_COLOR_VALUE));
    }
    else
    {
        set_led_kl_to_pwm(&new_tgt_led_data,
                          bulb_get_config(BULB_CFG_COLOR_TEMP),
                          bulb_get_config(BULB_CFG_COLOR_BRIGHT));
    }
    s_new_tgt_flag = bulb_gradient_tgt_check(new_tgt_led_data);
}

/**
 * @brief 白光模式数据写入和直接设置输出
 * @param[in]  temp      [色温]
 * @param[in]  bright    [亮度]
 * @return int           [成功：APP_OK， 失败：APP_FAIL]
 */
int bulb_white_mode_write(uint8_t temp, uint8_t bright)
{
    set_led_kl_to_pwm(&s_cur_led_data, temp, bright);
    set_driver_output(&s_cur_led_data);
    return APP_OK;
}

/**
 * @brief 彩光模式数据写入和直接设置输出
 * @param[in]  H         [色相]
 * @param[in]  S         [饱和度]
 * @param[in]  V         [明度]
 * @return int           [成功：APP_OK， 失败：APP_FAIL]
 */
int bulb_color_mode_write(uint16_t H, uint16_t S, uint8_t V)
{
    set_led_hsv_to_rgb(&s_cur_led_data, H, S, V);
    set_driver_output(&s_cur_led_data);
    return APP_OK;
}

/**
 * @brief  关断灯泡所有输出
 * @return int           [成功：APP_OK， 失败：APP_FAIL]
 */
int bulb_sleep_mode_write(void)
{
    set_led_down(&s_cur_led_data);
    set_driver_output(&s_cur_led_data);
    return APP_OK;
}

/**
 * @brief  从flash中保存的配置开启灯泡
 */
void bulb_open(void)
{
    bulb_set_could_zero_flag(false);
    switch (bulb_get_config(BULB_CFG_ONOFF))
    {
    case 1:
        if (bulb_get_config(BULB_CFG_COLOR_MODE))
        {
            set_led_hsv_to_rgb(&s_tgt_led_data,
                               bulb_get_config(BULB_CFG_COLOR_HUE),
                               bulb_get_config(BULB_CFG_COLOR_SATURATION),
                               bulb_get_config(BULB_CFG_COLOR_VALUE));
        }
        else
        {
            set_led_kl_to_pwm(&s_tgt_led_data,
                              bulb_get_config(BULB_CFG_COLOR_TEMP),
                              bulb_get_config(BULB_CFG_COLOR_BRIGHT));
        }
        break;
    case 0:
        s_tgt_led_data.blue = 0;
        s_tgt_led_data.red = 0;
        s_tgt_led_data.green = 0;
        s_tgt_led_data.cold = 0;
        s_tgt_led_data.warm = 0;
        break;
    default:
        APP_LOG(LOG_WARN, "get switch_cfg error\n");
    }
    bulb_open_gradient();
    bulb_resave_config();
}

/**
 * @brief Bulb LED驱动的初始化
 */
void bulb_led_init(void)
{
    int ret;

#if BULB_DRIVER_TYPE == BULB_DRV_BY_BP5758
    ret = vdrv_bp5758d_init(BULB_I2C_SDA_IO, BULB_I2C_SCL_IO);
    if (SDK_OK != ret)
    {
        APP_LOG(LOG_WARN, "bp5758d init fail[%d]\n", ret);
    }
    bp5758_update_range_cfg();
#elif BULB_DRIVER_TYPE == BULB_DRV_BY_LEDC
    vhal_led_timer_cfg_t led_timer_cfg =
        {
            .duty_resolution = (LED_DUTY_RST_E)BULB_LEDC_DUTY_RST_BIT,
            .freq_hz = BULB_LEDC_PWM_FREQ,
        };
    ret = vhal_led_timer_cfg(&led_timer_cfg);
    if (VHAL_OK != ret)
    {
        APP_LOG(LOG_WARN, "led timer cfg fail[%d]\n", ret);
    }

    vhal_led_gpio_cfg_t gpio_cfg[5] =
        {
            {
                .gpio_num = BULB_COLD_OUT_IO,
                .channel = VLED_CW_CH,
                .duty = 0,
            },
            {
                .gpio_num = BULB_WARM_OUT_IO,
                .channel = VLED_WW_CH,
                .duty = 0,
            },
            {
                .gpio_num = BULB_RED_OUT_IO,
                .channel = VLED_R_CH,
                .duty = 0,
            },
            {
                .gpio_num = BULB_GREEN_OUT_IO,
                .channel = VLED_G_CH,
                .duty = 0,
            },
            {
                .gpio_num = BULB_BULE_OUT_IO,
                .channel = VLED_B_CH,
                .duty = 0,
            },
        };
    ret = vhal_led_gpio_cfg(VLED_NUM, gpio_cfg);
    if (VHAL_OK != ret)
    {
        APP_LOG(LOG_WARN, "led gpio cfg fail[%d]\n", ret);
    }
#elif BULB_DRIVER_TYPE == BULB_DRV_BY_SM2235
    // 这个打印是为了增加延迟IIC上电初始化的时间防止初始化失败
    APP_LOG(LOG_INFO, "powered by sm2234egh\n");

    ret = vdrv_sm2235egh_init(BULB_I2C_SDA_IO, BULB_I2C_SCL_IO);
    if (SDK_OK != ret)
    {
        APP_LOG(LOG_WARN, "sm2234egh init fail[%d]\n", ret);
    }
    ret = vdrv_sm2235egh_set_mode(RGBCW_MODE);
    if (SDK_OK != ret)
    {
        APP_LOG(LOG_WARN, "sm2234egh set mode fail[%d]\n", ret);
    }

    uint8_t rgb_cr = BULB_RED_MAX, cw_cr = BULB_COLD_MAX;
    ret = vdrv_sm2235egh_set_cr(&rgb_cr, &cw_cr);
    if (SDK_OK != ret)
    {
        APP_LOG(LOG_WARN, "sm2234egh set cr fail[%d]\n", ret);
    }
#else
#error "BULB_DRIVER_TYPE is invalid"
#endif /* BULB_DRIVER_TYPE */
}

/**
 * @brief  设备重新上电时的开启状态
 */
void bulb_poweron(void)
{
    bulb_update_config(BULB_CFG_ONOFF, 1);
    bulb_open();
}
