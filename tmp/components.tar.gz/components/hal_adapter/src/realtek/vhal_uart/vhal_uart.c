/**
 *  Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vhal_uart.c
 * @brief       Realtek平台串口收发接口封装
 * @author      Dongri.Su
 * @date        2021-04-28
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/queue.h"
#include "serial_api.h"
#include "serial_ex_api.h"

#include "vesync_log.h"

#include "vhal_uart_internal.h"
#include "vhal_gpio_internal.h"
#include "vesync_common.h"

static TaskHandle_t s_uart_taskhd = NULL;      // UART数据接收任务句柄
static vhal_rtl_uart_status_t s_rtl_uart_status[VHAL_UART_NUM_MAX] = {0};

// 信号量
static SemaphoreHandle_t s_uart_hw_sem;    // Uart HW resource
static SemaphoreHandle_t s_uart_rx_sem;    // RX done
static SemaphoreHandle_t s_uart_tx_sem;    // TX ready, also use as TX done

//volatile uint32_t tx_bytes = 0;
//volatile uint32_t rx_bytes = 0;
//unsigned int tx_size;


/*-----------------------------------------------------------------------------*
 *                           内部函数API实现                                         *
 *-----------------------------------------------------------------------------*/

/**
 * @brief 串口发送成功处理程序
 * @param id    TX complete callback function parameter.
 * @return void
 */
static void vhal_uart_send_done (uint32_t id)
{
    signed portBASE_TYPE xHigherPriorityTaskWoken;

    //tx_bytes += tx_size;
    xSemaphoreGiveFromISR(s_uart_tx_sem, &xHigherPriorityTaskWoken);
    portYIELD_FROM_ISR(xHigherPriorityTaskWoken);
}


/**
 * @brief 串口接收成功处理程序
 * @param id    RX complete callback function parameter.
 * @return void
 */
static void vhal_uart_recv_done (uint32_t id)
{
    //serial_t *sobj = (void*)id;
    signed portBASE_TYPE xHigherPriorityTaskWoken;

    //rx_bytes += sobj->uart_adp.rx_count;
    //HAL_LOG(LOG_DEBUG, "UART Rx count is %d.\n", sobj->uart_adp.rx_count);
    xSemaphoreGiveFromISR(s_uart_rx_sem, &xHigherPriorityTaskWoken);
    portYIELD_FROM_ISR(xHigherPriorityTaskWoken);
}


/**
 * @brief 串口事件任务
 *
 * @param pvParameters
 */
static void vhal_uart_event_task(void *pvParameters)
{
    int ret = -1;
    uint32_t rx_size = UART_RECV_BUF_SIZE - 1;
    int rx_byte = 0;
    uint8_t idx = 0;

    uint8_t *rx_buf = (uint8_t *)malloc(UART_RECV_BUF_SIZE);
    if (NULL == rx_buf)
    {
        HAL_LOG(LOG_ERROR, "malloc fail!!\n");
        return;
    }
    memset(rx_buf, 0, UART_RECV_BUF_SIZE);

    while (1)
    {
        for (idx = 0; idx < VHAL_UART_NUM_MAX; idx++)
        {
            if (s_rtl_uart_status[idx].cfg_flag)
            {
                xSemaphoreTake(s_uart_hw_sem, portMAX_DELAY);    // get the semaphore before access the HW
                ret = serial_recv_stream(&s_rtl_uart_status[idx].uart_obj, (char *)rx_buf, rx_size); // TODO:rx_size如何确定，还是说用最大长度？？
                xSemaphoreGive(s_uart_hw_sem);    // return the semaphore after access the HW

                if (ret != HAL_OK)
                {
                    HAL_LOG(LOG_ERROR, "Uart recv fail, recv error is %d!\n", ret);
                    xSemaphoreGive(s_uart_rx_sem);    // Ready to RX
                    //return VHAL_FAIL;
                }
                else
                {
                    // Wait RX done
                    if (xSemaphoreTake(s_uart_rx_sem, ((TickType_t)UART_TIMEOUT_MS / portTICK_RATE_MS)) != pdTRUE)
                    {
                        xSemaphoreTake(s_uart_hw_sem, portMAX_DELAY);    // get the semaphore before access the HW
                        rx_byte = serial_recv_stream_abort(&s_rtl_uart_status[idx].uart_obj);
                        xSemaphoreGive(s_uart_hw_sem);    // return the semaphore after access the HW
                        //if (rx_byte > 0) {
                        //    rx_bytes += rx_byte;
                        //}
                    }
                    //else
                    //{
                        //HAL_LOG(LOG_DEBUG, "rx_size = %d, rx_byte = %d!\n", rx_size, rx_byte);
                        if (rx_byte > 0)
                        {
                            // 回调给上层
                            if (s_rtl_uart_status[idx].recv_cb)
                            {
                                s_rtl_uart_status[idx].recv_cb(s_rtl_uart_status[idx].uart_num, rx_buf, rx_byte);
                            }
                            memset(rx_buf, 0, UART_RECV_BUF_SIZE);  // clear
                        }
                    //}
                }
            }
        }
    }

    free(rx_buf);
    rx_buf = NULL;
    vTaskDelete(NULL);
}


/*-----------------------------------------------------------------------------*
 *                           外部函数API实现                                         *
 *-----------------------------------------------------------------------------*/

/**
 * @brief  启动串口接收任务
 * @return     void
 */
void vhal_uart_start(void)
{
    if (NULL != s_uart_taskhd)
    {
        return;
    }

    // Create semaphore for UART HW resource
    s_uart_hw_sem = xSemaphoreCreateBinary();
    if (NULL == s_uart_hw_sem)
    {
        HAL_LOG(LOG_ERROR, "Create uart_hw_sem fail!!\n");
        return;
    }
    xSemaphoreGive(s_uart_hw_sem);

    // Create semaphore for UART RX done(received espected bytes or timeout)
    s_uart_rx_sem = xSemaphoreCreateBinary();
    if (NULL == s_uart_rx_sem)
    {
        HAL_LOG(LOG_ERROR, "Create uart_rx_sem fail!!\n");
        vSemaphoreDelete(s_uart_hw_sem);
        return;
    }

    // Create semaphore for UART TX done
    s_uart_tx_sem = xSemaphoreCreateBinary();
    if (NULL == s_uart_tx_sem)
    {
        HAL_LOG(LOG_ERROR, "Create uart_tx_sem fail!!\n");
        vSemaphoreDelete(s_uart_hw_sem);
        vSemaphoreDelete(s_uart_rx_sem);
        return;
    }
    xSemaphoreGive(s_uart_tx_sem);    // Ready to TX

    // Create a task to handler UART event from ISR
    if (xTaskCreate(vhal_uart_event_task, UART_TASK_NAME, UART_TASK_STACK_SIZE, NULL, UART_TASK_PRIO, &s_uart_taskhd) != pdPASS)
    {
        HAL_LOG(LOG_ERROR, "Create UART event task fail!!!\n");
        vSemaphoreDelete(s_uart_hw_sem);
        vSemaphoreDelete(s_uart_rx_sem);
        vSemaphoreDelete(s_uart_tx_sem);
    }
}

/**
 * @brief  串口参数配置
 * @param[in]  idx                  [串口编号]
 * @param[in]  rx_pin               [串口rx引脚]
 * @param[in]  rx_pin               [串口tx引脚]
 * @param[in]  baudrate             [串口波特率]
 * @return     void
 */
void vhal_uart_config(uint8_t idx, uint32_t rx_pin, uint32_t tx_pin, uint32_t baudrate)
{
    if (idx >= VHAL_UART_NUM_MAX)
    {
        HAL_LOG(LOG_ERROR, "UART number(%d) is error!!\n", idx);
        return;
    }

    serial_init(&s_rtl_uart_status[idx].uart_obj, vhal_rtl_giop_get_pin_name(tx_pin), vhal_rtl_giop_get_pin_name(rx_pin));
    serial_baud(&s_rtl_uart_status[idx].uart_obj, baudrate);
    serial_format(&s_rtl_uart_status[idx].uart_obj, 8, ParityNone, 1);     // 8bits, no parity, stop

    serial_send_comp_handler(&s_rtl_uart_status[idx].uart_obj, (void*)vhal_uart_send_done, (uint32_t)&s_rtl_uart_status[idx].uart_obj);
    serial_recv_comp_handler(&s_rtl_uart_status[idx].uart_obj, (void*)vhal_uart_recv_done, (uint32_t)&s_rtl_uart_status[idx].uart_obj);

    s_rtl_uart_status[idx].cfg_flag = true;
    s_rtl_uart_status[idx].uart_num = idx;
}

/**
 * @brief 注册串口接收数据回调
 * @param[in]  idx                  [串口编号]
 * @param[in]  cb                   [串口数据接收回调函数]
 * @return     void
 */
void vhal_uart_reg_recv_cb(uint8_t idx, vhal_uart_recv_cb_t cb)
{
    if (idx >= VHAL_UART_NUM_MAX)
    {
        HAL_LOG(LOG_ERROR, "UART number(%d) is error!!\n", idx);
        return;
    }

    s_rtl_uart_status[idx].recv_cb = cb;
}

/**
 * @brief  串口发送数据
 * @param[in]  idx             [串口编号]
 * @param[in]  p_buf                [待发送数据]
 * @param[in]  buf_len              [待发送数据长度]
 * @return     int                  [执行结果，0表示成功，其他值表示失败]
 */
int vhal_uart_send(uint8_t idx, uint8_t *p_buf, uint16_t buf_len)
{
    int ret = -1;
    int tx_byte_timeout = 0;

    if (NULL == p_buf || buf_len <= 0)
    {
        return VHAL_FAIL;
    }

    xSemaphoreTake(s_uart_hw_sem, portMAX_DELAY);    // get the semaphore before access the HW
    ret = serial_send_stream(&s_rtl_uart_status[idx].uart_obj, (char *)p_buf, buf_len);
    xSemaphoreGive(s_uart_hw_sem);    // return the semaphore after access the HW

    if (ret != HAL_OK)
    {
        HAL_LOG(LOG_ERROR, "Uart send fail, send error is %d!\n", ret);
        xSemaphoreGive(s_uart_tx_sem);    // Ready to TX
        return VHAL_FAIL;
    }
    else
    {
        // Wait TX done
        if (xSemaphoreTake(s_uart_tx_sem, ((TickType_t)UART_TIMEOUT_MS / portTICK_RATE_MS)) != pdTRUE)
        {
            xSemaphoreTake(s_uart_hw_sem, portMAX_DELAY);    // get the semaphore before access the HW
            tx_byte_timeout = serial_send_stream_abort(&s_rtl_uart_status[idx].uart_obj);
            HAL_LOG(LOG_ERROR, "%s: send timeout, tx_byte_timeout = %d!!\n", tx_byte_timeout);
            xSemaphoreGive(s_uart_hw_sem);    // return the semaphore after access the HW
            //if (tx_byte_timeout > 0) {
            //    tx_bytes += tx_byte_timeout;
            //}
            xSemaphoreGive(s_uart_tx_sem);    // Ready to TX, also ready by send_done
        }

        return VHAL_OK;
    }
}

