/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_schedule_mgmt.c
 * @brief       Schedule 模块实现
 * @author      Herve.Lin
 * @date        2021-06-22
 */
#include <time.h>
#include <string.h>

#include "vesync_timer.h"
#include "vesync_memory.h"
#include "vesync_common.h"
#include "vesync_log_internal.h"
#include "vesync_schedule_mgmt.h"

// Schedule Management内部创建锁宏
#define SCHEDULE_MGMT_NEW_LOCK(m, err)  \
    do {                                \
        m = vesync_mutex_new();         \
        SCHEDULE_CHECK(m != NULL, err); \
    } while(0)
// Schedule Management内部销毁锁宏
#define SCHEDULE_MGMT_DEL_LOCK(m) \
    do {                          \
        vesync_mutex_free(m);     \
        m = NULL;                 \
    } while(0)
// Schedule Management内部请求锁宏
#define SCHEDULE_MGMT_LOCK(m, err) SCHEDULE_CHECK(VOS_OK == vesync_mutex_try_lock(m), err)
// Schedule Management内部释放锁宏
#define SCHEDULE_MGMT_UNLOCK(m) vesync_mutex_unlock(m)

// 检查输入回调函数参数是否为空。非空则返回原输入回调函数，空则返回相应的缺省回调函数
#define CHECK_AND_GET_CB(cb, default) ((NULL == (cb)) ? (default) : (cb))

// Schedule管理器，管理所有的实例
static schedule_mgt_t s_schedule_mgt = SCHEDULE_MGT_INIT_VAL;

/**
 * @brief 根据Schedule实例句柄ID查找实例对象节点
 * @param[in] handle_id             [实例句柄ID]
 * @return
 *      schedule_obj_node_t*        [返回指向对象节点指针]
 *      NULL                        [该句柄ID无效]
 */
static schedule_obj_node_t *get_schedule_obj_node(uint32_t handle_id)
{
    if (s_schedule_mgt.obj_nbr > 0)
    {
        schedule_obj_node_t *p_pos, *p_n;
        struct list_head *p_head = &s_schedule_mgt.objects;
        list_for_each_entry_safe(p_pos, p_n, p_head, list)
        {
            if (p_pos->handle == handle_id)
            {
                return p_pos;
            }
        }
    }

    return NULL;
}

/**
 * @brief 根据Schedule实例句柄ID查找实例对象
 * @param[in] handle_id             [实例句柄ID]
 * @return
 *      schedule_obj_t*             [返回指向对象指针]
 *      NULL                        [该句柄ID无效]
 */
static schedule_obj_t *get_schedule_obj(uint32_t handle_id)
{
    schedule_obj_node_t *p_node = NULL;

    p_node = get_schedule_obj_node(handle_id);
    if (NULL == p_node)
    {
        return NULL;
    }

    return &p_node->data;
}

int vesync_schedule_main_init(void)
{
    SCHEDULE_CHECK(s_schedule_mgt.is_init == false, return SCHE_ERR);

    memset(&s_schedule_mgt, 0, sizeof(schedule_mgt_t));
    INIT_LIST_HEAD(&s_schedule_mgt.objects);

    SCHEDULE_MGMT_NEW_LOCK(s_schedule_mgt.mutex, return SCHE_ERR);
    s_schedule_mgt.is_init = true;
    return SCHE_OK;
}

int vesync_schedule_main_deinit(void)
{
    SCHEDULE_CHECK(s_schedule_mgt.is_init == true, return SCHE_ERR);

    SCHEDULE_MGMT_LOCK(s_schedule_mgt.mutex, return SCHE_ERR);

    int ret = SCHE_OK;
    if (s_schedule_mgt.obj_nbr > 0)
    {
        schedule_obj_node_t *p_pos, *p_n;
        struct list_head *p_head = &s_schedule_mgt.objects;
        list_for_each_entry_safe(p_pos, p_n, p_head, list)
        {
            ret = sche_obj_deinit(&p_pos->data);
            if (SCHE_OK == ret)
            {
                list_del_init(&p_pos->list);
                vesync_free(p_pos);
                s_schedule_mgt.obj_nbr--;
                continue;
            }
            SDK_LOG(LOG_ERROR, "sche_obj deinit fail[%d]", ret);
            break;
        }
    }
    SCHEDULE_MGMT_UNLOCK(s_schedule_mgt.mutex);
    if (SCHE_OK == ret)
    {
        SCHEDULE_MGMT_DEL_LOCK(s_schedule_mgt.mutex);
        s_schedule_mgt.is_init = false;
    }
    return ret;
}

int vesync_schedule_new_instance(uint32_t handle_id, vesync_schedule_param_t *p_sch_param)
{
    SCHEDULE_CHECK(p_sch_param != NULL, return SCHE_ERR);

    if (handle_id >= SCHEDULE_MAX_INSTANCES_NBR)
    {
        SDK_LOG(LOG_ERROR, "invalid handle_id\n");
        return SCHE_ERR;
    }

    // Schedule的默认配置读写回调在编译阶段生成，上层指定空的回调，则注册默认的读写函数
    p_sch_param->rd_cfg_cb = CHECK_AND_GET_CB(p_sch_param->rd_cfg_cb, sche_get_default_rd_cfg_cb(handle_id));
    p_sch_param->wr_cfg_cb = CHECK_AND_GET_CB(p_sch_param->wr_cfg_cb, sche_get_default_wr_cfg_cb(handle_id));

    SCHEDULE_MGMT_LOCK(s_schedule_mgt.mutex, return SCHE_ERR);

    int ret = SCHE_ERR;
    if (s_schedule_mgt.obj_nbr >= SCHEDULE_MAX_INSTANCES_NBR)
    {
        SDK_LOG(LOG_ERROR, "too many instances\n");
        goto EXIT;
    }

    schedule_obj_node_t *p_node = NULL;
    // 检查ID冲突
    p_node = get_schedule_obj_node(handle_id);
    if (NULL != p_node)
    {
        SDK_LOG(LOG_ERROR, "instance existes\n");
        goto EXIT;
    }

    p_node = (schedule_obj_node_t *)vesync_malloc(sizeof(schedule_obj_node_t));
    if (NULL == p_node)
    {
        SDK_LOG(LOG_ERROR, "node malloc fail\n");
        goto EXIT;
    }
    /// @note: 初始化节点内存
    memset(p_node, 0, sizeof(schedule_obj_node_t));

    ret = sche_obj_init(&p_node->data, p_sch_param);
    if (ret != SCHE_OK)
    {
        vesync_free(p_node);
        goto EXIT;
    }

    p_node->handle = handle_id;
    list_add(&p_node->list, &s_schedule_mgt.objects);
    // 实例计数累加
    s_schedule_mgt.obj_nbr++;

EXIT:
    SCHEDULE_MGMT_UNLOCK(s_schedule_mgt.mutex);
    return ret;
}

int vesync_schedule_destroy_instance(uint32_t handle_id)
{
    SCHEDULE_MGMT_LOCK(s_schedule_mgt.mutex, return SCHE_ERR);

    int ret = SCHE_ERR;
    if (s_schedule_mgt.obj_nbr == 0)
    {
        goto EXIT;
    }

    schedule_obj_node_t *p_node = NULL;
    // 查找ID
    p_node = get_schedule_obj_node(handle_id);
    if (NULL == p_node)
    {
        goto EXIT;
    }

    ret = sche_obj_deinit(&p_node->data);
    if (ret != SCHE_OK)
    {
        goto EXIT;
    }

    // 删除链表节点
    list_del_init(&p_node->list);
    vesync_free(p_node);

    s_schedule_mgt.obj_nbr--;

EXIT:
    SCHEDULE_MGMT_UNLOCK(s_schedule_mgt.mutex);
    return ret;
}

int vesync_schedule_add(uint32_t handle_id, vesync_schedule_t *p_sch_cfg, vesync_buf_t *p_app_cfg, bool is_gen_id)
{
    SCHEDULE_MGMT_LOCK(s_schedule_mgt.mutex, return SCHE_ERR);
    schedule_obj_t *p_obj = get_schedule_obj(handle_id);
    SCHEDULE_MGMT_UNLOCK(s_schedule_mgt.mutex);

    int ret = SCHE_ERR;
    if (NULL != p_obj)
    {
        ret = sche_obj_add(p_obj, p_sch_cfg, p_app_cfg, is_gen_id);
    }
    return ret;
}

int vesync_schedule_upd(uint32_t handle_id, vesync_schedule_t *p_sch_cfg, vesync_buf_t *p_app_cfg)
{
    SCHEDULE_MGMT_LOCK(s_schedule_mgt.mutex, return SCHE_ERR);
    schedule_obj_t *p_obj = get_schedule_obj(handle_id);
    SCHEDULE_MGMT_UNLOCK(s_schedule_mgt.mutex);

    int ret = SCHE_ERR;
    if (NULL != p_obj)
    {
        ret = sche_obj_upd(p_obj, p_sch_cfg, p_app_cfg);
    }
    return ret;
}

int vesync_schedule_del(uint32_t handle_id, uint32_t sch_id)
{
    SCHEDULE_MGMT_LOCK(s_schedule_mgt.mutex, return SCHE_ERR);
    schedule_obj_t *p_obj = get_schedule_obj(handle_id);
    SCHEDULE_MGMT_UNLOCK(s_schedule_mgt.mutex);

    int ret = SCHE_ERR;
    if (NULL != p_obj)
    {
        ret = sche_obj_del(p_obj, sch_id);
    }
    return ret;
}

int vesync_schedule_get_by_id(uint32_t handle_id, uint32_t sch_id, vesync_schedule_t *p_sch_cfg, vesync_buf_t *p_app_cfg)
{
    SCHEDULE_MGMT_LOCK(s_schedule_mgt.mutex, return SCHE_ERR);
    schedule_obj_t *p_obj = get_schedule_obj(handle_id);
    SCHEDULE_MGMT_UNLOCK(s_schedule_mgt.mutex);

    int ret = SCHE_ERR;
    if (NULL != p_obj)
    {
        ret = sche_obj_get_by_id(p_obj, sch_id, p_sch_cfg, p_app_cfg);
    }
    return ret;
}

int vesync_schedule_get_next_exc_sec(uint32_t handle_id, uint32_t *sec)
{
    if (NULL == sec)
    {
        return SCHE_ERR;
    }

    SCHEDULE_MGMT_LOCK(s_schedule_mgt.mutex, return SCHE_ERR);
    schedule_obj_t *p_obj = get_schedule_obj(handle_id);
    SCHEDULE_MGMT_UNLOCK(s_schedule_mgt.mutex);

    int32_t ret = SCHE_ERR;
    if (NULL != p_obj)
    {
        ret = sche_obj_get_next_exc_sec(p_obj, sec);
    }
    return ret;
}

int vesync_schedule_get_by_index(uint32_t handle_id,
                                 uint32_t idx, uint32_t nbr, uint32_t *p_total_num,
                                 vesync_schedule_t *p_sch_cfg_list, vesync_buf_t *p_app_cfg_list,
                                 uint32_t *p_out_len)
{
    SCHEDULE_MGMT_LOCK(s_schedule_mgt.mutex, return SCHE_ERR);
    schedule_obj_t *p_obj = get_schedule_obj(handle_id);
    SCHEDULE_MGMT_UNLOCK(s_schedule_mgt.mutex);

    int ret = SCHE_ERR;
    if (NULL != p_obj)
    {
        ret = sche_obj_get_by_index(p_obj, idx, nbr, p_total_num, p_sch_cfg_list, p_app_cfg_list, p_out_len);
    }
    return ret;
}

int vesync_schedule_clear(uint32_t handle_id)
{
    SCHEDULE_MGMT_LOCK(s_schedule_mgt.mutex, return SCHE_ERR);
    schedule_obj_t *p_obj = get_schedule_obj(handle_id);
    SCHEDULE_MGMT_UNLOCK(s_schedule_mgt.mutex);

    int ret = SCHE_ERR;
    if (NULL != p_obj)
    {
        ret = sche_obj_clear(p_obj);
    }
    return ret;
}

int vesync_schedule_get_exec_cnt(uint32_t handle_id, uint32_t sch_id, uint32_t *p_exec_cnt)
{
    SCHEDULE_MGMT_LOCK(s_schedule_mgt.mutex, return SCHE_ERR);
    schedule_obj_t *p_obj = get_schedule_obj(handle_id);
    SCHEDULE_MGMT_UNLOCK(s_schedule_mgt.mutex);

    int ret = SCHE_ERR;
    if (NULL != p_obj)
    {
        ret = sche_obj_get_exec_cnt(p_obj, sch_id, p_exec_cnt);
    }
    return ret;
}

int vesync_schedule_get_total_num(uint32_t handle_id, uint32_t *p_num)
{
    SCHEDULE_MGMT_LOCK(s_schedule_mgt.mutex, return SCHE_ERR);
    schedule_obj_t *p_obj = get_schedule_obj(handle_id);
    SCHEDULE_MGMT_UNLOCK(s_schedule_mgt.mutex);

    int ret = SCHE_ERR;
    if (NULL != p_obj)
    {
        ret = sche_obj_get_total_num(p_obj, p_num);
    }
    return ret;
}
