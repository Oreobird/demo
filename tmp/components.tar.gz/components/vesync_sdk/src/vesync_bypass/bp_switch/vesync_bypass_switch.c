/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_bypass_switch.c
 * @brief       bypass处理接口
 * @date        2021-05-14
 */

#include <string.h>

#include "vesync_common.h"
#include "vesync_memory.h"
#include "vesync_log_internal.h"

#include "vesync_bypass_internal.h"


/**
 * @brief "setSwitch"  method数据解析
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  json                     [json数据指针]
 * @return BYPASS_ERR_E                 [错误码]
 */
static BYPASS_ERR_E bypass_method_set_switch_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    BYPASS_ERR_E ret = BP_OK;
    bypass_switch_data_t *pSwitch = (bypass_switch_data_t *)vesync_malloc(sizeof(bypass_switch_data_t));
    if (NULL == pSwitch)
    {
        return BP_ERR_NOMEM;
    }

    memset(pSwitch, 0, sizeof(bypass_switch_data_t));
    //pSwitch->src_type = src_type;

    cJSON* json_data = cJSON_GetObjectItemCaseSensitive(json, "id");
    if (cJSON_IsNumber(json_data))
    {
        pSwitch->id = json_data->valueint & 0xFF;
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "enabled");
    if (cJSON_IsBool(json_data))
    {
        pSwitch->enable = json_data->valueint;
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_SET_SWITCH);
    if (method_cb)
    {
        method_cb(p_msg_ctx, (void*)pSwitch);
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

_exit:
    vesync_free(pSwitch);

    return ret;
}

/**
 * @brief "getSwitch"  method数据解析
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  json                     [json数据指针]
 * @return BYPASS_ERR_E                 [错误码]
 */
static BYPASS_ERR_E bypass_method_get_switch_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    BYPASS_ERR_E ret = BP_OK;

    int *id_buf = (int*)vesync_malloc(sizeof(int));
    if (NULL == id_buf)
    {
        return BP_ERR_NOMEM;
    }

    cJSON* json_data = cJSON_GetObjectItemCaseSensitive(json, "id");
    if (cJSON_IsNumber(json_data))
    {
        *id_buf = json_data->valueint;
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_GET_SWITCH);
    if (method_cb)
    {
        method_cb(p_msg_ctx, (void*)id_buf);
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

_exit:
    vesync_free(id_buf);
    return ret;
}

/**
 * @brief "toggleSwitch"  method数据解析
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  json                     [json数据指针]
 * @return BYPASS_ERR_E                 [错误码]
 */
static BYPASS_ERR_E bypass_method_toggle_switch_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    BYPASS_ERR_E ret = BP_OK;

    bypass_toggle_switch_data_t *pSwitch = vesync_malloc(sizeof(bypass_toggle_switch_data_t));
    if (NULL == pSwitch)
    {
        return BP_ERR_NOMEM;
    }

    memset(pSwitch, 0, sizeof(bypass_toggle_switch_data_t));

    cJSON* json_data = cJSON_GetObjectItemCaseSensitive(json, "id");
    if (cJSON_IsNumber(json_data))
    {
        pSwitch->id = json_data->valueint & 0xFF;
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_TOGGLE_SWITCH);
    if (method_cb)
    {
        method_cb(p_msg_ctx, (void*)pSwitch);
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

_exit:
    vesync_free(pSwitch);

    return ret;
}

static bypass_item_data_t switch_method_tbl[] = {
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_SET_SWITCH, "setSwitch", bypass_method_set_switch_handle, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_GET_SWITCH, "getSwitch", bypass_method_get_switch_handle, NULL},

    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_TOGGLE_SWITCH, "toggleSwitch", bypass_method_toggle_switch_handle, NULL},
};


void vesync_bypass_switch_init(void)
{
    for (int i = 0; i < SIZEOF_ARRAY(switch_method_tbl); i++)
    {
        bypass_item_t *item = vesync_bypass_init_item(&switch_method_tbl[i]);
        if (item != NULL)
        {
            vesync_bypass_add_item(item);
        }
    }
}

