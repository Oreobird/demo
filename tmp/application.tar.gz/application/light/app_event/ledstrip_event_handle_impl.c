/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
* @file         event_hancle_impl.c
* @brief        应用事件处理业务实现
* @author       Joshua
* @date         2021-12-2
*/
#include <stdint.h>
#include "vesync_common.h"
#include "vesync_log.h"
#include "vesync_netcfg.h"
#include "vesync_production.h"

#include "event_handle.h"
#include "device.h"
#include "scene.h"

static EV_HANDLE_RET ev_poweron_handle(app_event_t *ev)
{
    APP_LOG(LOG_DEBUG, "power on event handle\n");
    scene_t *scene = scene_registry_get(ev->scene_type, ev->scene_id);
    int ret = app_scene_light_apply(scene, NULL);
    if (ret != APP_OK)
    {
        APP_LOG(LOG_DEBUG, "scene light apply fail\n");
    }
    return EV_HANDLE_LOOP;
}

static EV_HANDLE_RET ev_prd_handle(app_event_t *ev)
{
    APP_LOG(LOG_DEBUG, "Production event handle\n");
    vesync_production_enter_testmode(true);
    return EV_HANDLE_OK;
}

static EV_HANDLE_RET ev_pre_netcfg_handle(app_event_t *ev)
{
    APP_LOG(LOG_DEBUG, "Pre netcfg event handle\n");
    scene_t *scene = scene_registry_get(SCENE_NETCFG, 0);
    netcfg_light_scene_wait(scene);
    return EV_HANDLE_OK;
}

static EV_HANDLE_RET ev_netcfg_handle(app_event_t *ev)
{
    APP_LOG(LOG_DEBUG, "Start netcfg event handle\n");
    vesync_netcfg_restart();
    return EV_HANDLE_OK;
}

static EV_HANDLE_RET ev_nwk_reconnect_handle(app_event_t *ev)
{

    return EV_HANDLE_OK;
}

static EV_HANDLE_RET ev_reset_handle(app_event_t *ev)
{
    APP_LOG(LOG_DEBUG, "Reset event handle\n");

    scene_t *scene = scene_registry_get(SCENE_RESET, 0);
    reset_light_scene_process(scene);
    vesync_device_factory_reset(true, STAT_CHG_RSN_BTN_STR);
    return EV_HANDLE_OK;
}

static EV_HANDLE_RET ev_scene_switch_handle(app_event_t *ev)
{
    APP_LOG(LOG_DEBUG, "Scene switch event handle scene: type=%d, id=%d\n", ev->scene_type, ev->scene_id);

    scene_t *scene = scene_registry_get(ev->scene_type, ev->scene_id);
    int ret = app_scene_light_apply(scene, NULL);
    if (ret != APP_OK)
    {
        APP_LOG(LOG_DEBUG, "scene light apply fail\n");
    }
    return EV_HANDLE_LOOP;
}

static event_handle_t s_ev_handle_tbl[] = {
    {EV_POWERON, ev_poweron_handle},
    {EV_PRODUCTION, ev_prd_handle},
    {EV_PRE_NETCFG, ev_pre_netcfg_handle},
    {EV_NETCFG, ev_netcfg_handle},
    {EV_NWK_RECONNECT, ev_nwk_reconnect_handle},
    {EV_RESET, ev_reset_handle},
    {EV_SCENE_SWITCH, ev_scene_switch_handle},
    {EV_UNKNOWN, NULL}
};

EV_HANDLE_RET app_event_handle(app_event_t *ev)
{
    EV_HANDLE_RET ret = EV_HANDLE_FAIL;

    for (int i = 0; i < SIZEOF_ARRAY(s_ev_handle_tbl); i++)
    {
        if (ev->id == s_ev_handle_tbl[i].id && s_ev_handle_tbl[i].handle)
        {
            ret = s_ev_handle_tbl[i].handle(ev);
            break;
        }
    }

    return ret;
}

