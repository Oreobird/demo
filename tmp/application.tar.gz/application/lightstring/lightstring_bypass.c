/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        lightstring_bypass.c
 * @brief       lightstring bypass通信接口
 * @author      Henrik
 * @date        2021-11-01
 */
#include <stdint.h>
#include <string.h>

#include "vesync_common.h"
#include "vesync_log.h"
#include "vesync_memory.h"
#include "vesync_buffer.h"
#include "vesync_bypass.h"
#include "vesync_timing.h"
#include "vesync_device.h"
#include "vesync_schedule.h"

#include "lightstring.h"
#include "lightstring_scene.h"
#include "lightstring_board.h"
#include "lightstring_timing.h"
#include "lightstring_bypass.h"
#include "lightstring_report.h"
#include "lightstring_schedule.h"

static bool s_ls_voice_off_flag = false; // 第三方语音设置亮度为0，标志位（认证需求）


/**
* @brief 设置语音关闭标志位，
* @param[in]  flag          [true:语音导致灯带关闭;false:当前状态不是语音关闭]
*/
void ls_set_voice_off_flag(bool flag)
{
    s_ls_voice_off_flag = flag;
}

/**
* @brief 新增timer
* @note  新增bypass method
* @param[in]        p_msg_ctx       [bypass上下文]
* @param[in]        json            [传入json]
* @return           BYPASS_ERR_E    [错误码]
*/
static BYPASS_ERR_E ls_bp_add_timer(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    ls_timing_t action ;
    cJSON* json_data = NULL;
    cJSON* json_timer = NULL;
    cJSON* json_obj = NULL;
    cJSON* json_act = NULL;
    cJSON* json_type = NULL;
    int ret = 0;

    if (NULL == p_msg_ctx || NULL == p_msg_ctx->p_trace_msg || NULL == json)
    {
        APP_LOG(LOG_DEBUG, " addTimerV2 error \n");
        return BP_ERROR;
    }

    APP_LOG(LOG_DEBUG, "-------addTimerV2 handle--------\n");

    memset(&action, 0, sizeof(ls_timing_t));

    json_data = cJSON_GetObjectItemCaseSensitive(json, "total");
    if (cJSON_IsNumber(json_data))
    {
         action.total_sec = json_data->valueint;
         VCOM_IN_RANGE_CHK(action.total_sec, TIMER_SEC_MIN, TIMER_SEC_MAX, (ret++));
         if (ret)
         {
            return BP_ERR_ARG;
         }
    }
    else
    {
        return BP_ERR_ARG;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "startAct");
    if (!cJSON_IsArray(json_data))
    {
        return BP_ERR_ARG;
    }

    int arr_size = cJSON_GetArraySize(json_data);
    if (arr_size > 2)
    {
        return BP_ERR_ARG;
    }

    for (int i = 0; i < arr_size; i++)
    {
        json_obj = cJSON_GetArrayItem(json_data, i);
        if (NULL == json_obj)
        {
            return BP_ERR_ARG;
        }

        json_type = cJSON_GetObjectItemCaseSensitive(json_obj, "type");
        if (0 == strcmp(json_type->valuestring, "switch"))
        {
            json_act = cJSON_GetObjectItemCaseSensitive(json_obj, "act");
            if (0 == strcmp(json_act->valuestring, "off"))
            {
                action.mode = LS_MODE_OFF;
                break;
            }

        }
        else if (0 == strcmp(json_type->valuestring, "color_mode"))
        {
            json_act = cJSON_GetObjectItemCaseSensitive(json_obj, "act");
            if (!cJSON_IsString(json_act))
            {
                return BP_ERR_ARG;
            }

            cJSON *json_param = NULL;
            cJSON *json_id = NULL;
            json_param = cJSON_GetObjectItemCaseSensitive(json_obj, "params");
            if (NULL == json_param)
            {
                return BP_ERR_ARG;
            }

            if (0 == strcmp(json_act->valuestring, "scenario"))
            {
                action.mode = LS_MODE_SCENE;
                json_id = cJSON_GetObjectItemCaseSensitive(json_param, "sceneId");
            }
            else if (0 == strcmp(json_act->valuestring, "music"))
            {
                action.mode = LS_MODE_MUSIC;
                json_id = cJSON_GetObjectItemCaseSensitive(json_param, "musicModeId");
            }
            else
            {
                return BP_ERR_ARG;
            }

            if (NULL == json_id)
            {
                return BP_ERR_ARG;
            }
            else
            {
                VCOM_IN_RANGE_CHK( json_id->valueint, 1, (action.mode == LS_MODE_SCENE ? LS_MODE_NUM : LS_MODE_MUSIC_NUM),
                                 (ret++));
                if (ret)
                {
                    return BP_ERR_ARG;
                }

                action.scene_id = json_id->valueint;
            }

        }
        else
        {
            return BP_ERR_ARG;
        }
    }


    if (APP_OK == ls_timing_add(action.total_sec, &(action.id), action.mode, action.scene_id))
    {
        json_timer = cJSON_CreateObject();
        if (NULL != json_timer)
        {
            cJSON_AddNumberToObject(json_timer, "id", action.id);
            APP_LOG(LOG_DEBUG,"add timer %d\n", action.id);
            vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, json_timer);
        }
        else
        {
            return BP_ERR_NOMEM;
        }
    }
    else
    {
        return BP_ERROR;
    }
    return BP_OK;
}

/**
* @brief 获取timer
* @note  新增bypass method
* @param[in]        p_msg_ctx       [bypass上下文]
* @param[in]        json            [传入json]
* @return           BYPASS_ERR_E    [错误码]
*/
static BYPASS_ERR_E ls_bp_get_timer(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    BYPASS_ERR_E ret = BP_OK;
    uint16_t timer_id = 0;
    ls_timing_t *timing = NULL;
    cJSON *json_data = NULL;
    cJSON *json_timers = NULL;
    cJSON *json_timer = NULL;
    cJSON *json_arr = NULL;
    cJSON *json_mode = NULL;
    cJSON *json_action = NULL;
    cJSON *json_params = NULL;
    timing_data_t tm;
    memset(&tm, 0, sizeof(timing_data_t));

    if (NULL == p_msg_ctx || NULL == p_msg_ctx->p_trace_msg)
    {
        return BP_ERROR;
    }
    UNUSED(json);

    json_data = cJSON_CreateObject();
    if (NULL == json_data)
    {
        return BP_ERR_NOMEM;
    }

    cJSON_AddItemToObject(json_data, "timers", json_timers =  cJSON_CreateArray());
    if (NULL == json_timers)
    {
        ret = BP_ERR_NOMEM;
        goto exit;
    }

    timing = ls_timing_get_act();
    timer_id = timing->id;
    if (timer_id == 0)
    {
        vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, json_data);
        return BP_OK;
    }

    if (SDK_OK == vesync_timing_get(timer_id, &tm))
    {
        cJSON_AddItemToArray(json_timers, json_timer = cJSON_CreateObject());
        if (NULL == json_timer)
        {
            ret = BP_ERR_NOMEM;
            goto exit;
        }
        cJSON_AddNumberToObject(json_timer, "id", tm.timing_id);
        cJSON_AddNumberToObject(json_timer, "total", tm.total_second);
        cJSON_AddNumberToObject(json_timer, "remain", tm.remain_second);
        // package
        cJSON_AddItemToObject(json_timer, "startAct", json_arr = cJSON_CreateArray());
        cJSON_AddItemToArray(json_arr, json_mode = cJSON_CreateObject());
        if (NULL == json_arr || NULL == json_mode)
        {
            ret = BP_ERR_NOMEM;
            goto exit;
        }

        cJSON_AddStringToObject(json_mode, "type", "switch");
        cJSON_AddNumberToObject(json_mode, "num", 0);
        if (timing->mode == LS_MODE_OFF)
        {
            cJSON_AddStringToObject(json_mode, "act", "off");
        }
        else
        {
            cJSON_AddStringToObject(json_mode, "act", "on");
            cJSON_AddItemToArray(json_arr, json_action = cJSON_CreateObject());
            if (NULL == json_action)
            {
                ret = BP_ERR_NOMEM;
                goto exit;
            }

            cJSON_AddStringToObject(json_action, "type", "color_mode");
            cJSON_AddItemToObject(json_action, "params",json_params = cJSON_CreateObject());
            if (NULL == json_params)
            {
                ret = BP_ERR_NOMEM;
                goto exit;
            }

            if (timing->mode == LS_MODE_SCENE)
            {
                cJSON_AddStringToObject(json_action, "act", "scenario");
                cJSON_AddNumberToObject(json_params, "sceneId", timing->scene_id);
            }
            else
            {
                cJSON_AddStringToObject(json_action, "act", "music");
                cJSON_AddNumberToObject(json_params, "musicModeId", timing->scene_id);
            }
            cJSON_AddNumberToObject(json_action, "num", 0);
        }

    }

    vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, json_data);
    return BP_OK;

exit:
    vesync_bypass_reply_pkg_err_msg(ret, p_msg_ctx->p_trace_msg, NULL);
    cJSON_Delete(json_data);
    return ret;
}

/**
* @brief 删除timer
* @note  新增bypass method
* @param[in]        p_msg_ctx       [bypass上下文]
* @param[in]        json            [传入json]
* @return           BYPASS_ERR_E    [错误码]
*/
static BYPASS_ERR_E ls_bp_del_timer(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    if (NULL == p_msg_ctx || NULL == p_msg_ctx->p_trace_msg || NULL == json)
    {
        return BP_ERROR;
    }

    cJSON *json_data = cJSON_GetObjectItemCaseSensitive(json, "id");
    if (cJSON_IsNumber(json_data))
    {
        if (APP_OK == ls_timing_remove(json_data->valueint))
        {
            cJSON *json_ret = cJSON_CreateObject();
            if (NULL != json_ret)
            {
                cJSON_AddNumberToObject(json_ret, "id", json_data->valueint);
            }
            vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, json_ret);
        }
        else
        {
            vesync_bypass_reply_pkg_err_msg(BP_ERR_TIMER_NOT_FOUND, p_msg_ctx->p_trace_msg, "Timer remove fail");
        }
    }
    else
    {
        return BP_ERR_ARG;
    }

    return BP_OK;
}


/**
* @brief ledstrip bypass 添加Schedule回调接口
* @param[in]  p_msg_ctx                [msg context]
* @param[in]  p_data                   [回调函数传入数据]
*/
static void ls_bp_add_schedule(bypass_msg_ctx_t *p_msg_ctx, void *p_data)
{
    int error_code = BP_ERR_ARG;

    if(NULL == p_data)
    {
        vesync_bypass_reply_pkg_err_msg(BP_ERR_PARA_ILLEGAL, p_msg_ctx->p_trace_msg, BP_ERR_PARAM_CONV(p_data, BP_ERR_PARAM_NULL_PTR));
        return;
    }

    uint32_t sch_id = 0;
    cJSON *json_sch_ret = NULL;
    bypass_schedule_base_t *p_bp_sch = (bypass_schedule_base_t *)p_data;

    error_code = ls_schedule_add(p_bp_sch, &sch_id);
    if (BP_ERR_NO_ERR == error_code)
    {
        // 添加成功，生成回应
        json_sch_ret = cJSON_CreateObject();
        if (NULL != json_sch_ret)
        {
            cJSON_AddNumberToObject(json_sch_ret, "id", sch_id);
        }
    }

    vesync_bypass_reply_noqos(error_code, p_msg_ctx->p_trace_msg, json_sch_ret);
}

/**
* @brief Outlet bypass 更新Schedule回调接口
* @param[in]  p_msg_ctx                [msg context]
* @param[in]  p_data                   [回调函数传入数据]
*/
static void ls_bp_upd_schedule(bypass_msg_ctx_t *p_msg_ctx, void *p_data)
{
    int error_code = BP_ERR_PARA_ILLEGAL;

    if(NULL == p_data)
    {
        vesync_bypass_reply_pkg_err_msg(BP_ERR_PARA_ILLEGAL, p_msg_ctx->p_trace_msg, BP_ERR_PARAM_CONV(p_data, BP_ERR_PARAM_NULL_PTR));
        return;
    }

    uint32_t sch_id = 0;
    cJSON *json_sch_ret = NULL;
    bypass_schedule_base_t *p_bp_sch = (bypass_schedule_base_t *)p_data;

    error_code = ls_schedule_upd(p_bp_sch, &sch_id);
    if (BP_ERR_NO_ERR == error_code)
    {
        // 更新成功，生成回应
        json_sch_ret = cJSON_CreateObject();
        if (NULL != json_sch_ret)
        {
            cJSON_AddNumberToObject(json_sch_ret, "id", sch_id);
        }
    }

    vesync_bypass_reply_noqos(error_code, p_msg_ctx->p_trace_msg, json_sch_ret);
}

/**
* @brief Outlet bypass 删除Schedule回调接口
* @param[in]  p_msg_ctx                [msg context]
* @param[in]  p_data                   [回调函数传入数据]
*/
static void ls_bp_del_schedule(bypass_msg_ctx_t *p_msg_ctx, void *p_data)
{
    APP_LOG(LOG_DEBUG, "del schedule \n");
    int error_code = BP_ERR_PARA_ILLEGAL;

    if(NULL == p_data)
    {
        vesync_bypass_reply_pkg_err_msg(BP_ERR_PARA_ILLEGAL, p_msg_ctx->p_trace_msg, BP_ERR_PARAM_CONV(p_data, BP_ERR_PARAM_NULL_PTR));
        return;
    }

    uint32_t sch_id = *((uint32_t *)p_data);
    cJSON *json_sch_ret = NULL;

    error_code = ls_schedule_del(sch_id);
    if (BP_ERR_NO_ERR == error_code)
    {
        // 删除成功，生成回应
        json_sch_ret = cJSON_CreateObject();
        if (NULL != json_sch_ret)
        {
            cJSON_AddNumberToObject(json_sch_ret, "id", sch_id);
        }
    }

    vesync_bypass_reply_noqos(error_code, p_msg_ctx->p_trace_msg, json_sch_ret);
}


/**
* @brief 生成Schedule配置项列表的JSON
* @param[in] json_array    [JSON数组根对象]
* @param[in] p_list        [Schedule配置项列表]
* @param[in] list_len      [列表的最大长度,注意大于等于列表内的配置项数量]
* @return      int         [Bypass定义的错误]
*/
static int schedule_list_json_marshal(void *json_array, bypass_schedule_base_t *p_list, uint32_t list_len)
{
    cJSON *p_out = (cJSON *)json_array;

    if (!cJSON_IsArray(p_out))
    {
        return BP_ERR_PARA_ILLEGAL;
    }

    for (uint32_t cnt = 0; cnt < list_len; cnt++)
    {
        // 判断列表结束
        if (0 == p_list[cnt].id)
        {
            break;
        }

        cJSON *sch_obj = cJSON_CreateObject();
        cJSON *sub_obj = NULL;
        uint8_t type = *((uint8_t *)p_list[cnt].type);

        if (NULL == sch_obj)
        {
            APP_LOG(LOG_ERROR,"creat error!\n");
            return BP_ERROR;
        }

        cJSON_AddNumberToObject(sch_obj, "id", p_list[cnt].id);
        cJSON_AddBoolToObject(sch_obj, "enabled", *((bool *)p_list[cnt].enabled));
        cJSON_AddItemToObject(sch_obj, "startAct", (cJSON*)p_list[cnt].json_action);
        cJSON_AddNumberToObject(sch_obj, "type", type);
        if (BYPASS_SCHEDULE_JSON_TYPE_TMG_EVT == type)
        {
            sub_obj = cJSON_AddObjectToObject(sch_obj, "tmgEvt");

            cJSON_AddNumberToObject(sub_obj, "clkSec", *p_list[cnt].clock_sec);
        }
        else if (BYPASS_SCHEDULE_JSON_TYPE_SUN_EVT == type)
        {
            sub_obj = cJSON_AddObjectToObject(sch_obj, "sunEvt");

            cJSON_AddBoolToObject(sub_obj, "isRise", *((bool *)p_list[cnt].is_sunrise));
            cJSON_AddNumberToObject(sub_obj, "ofsSec", *p_list[cnt].offset_sec);
        }

        cJSON_AddNumberToObject(sch_obj, "repeat", *((uint8_t *)p_list[cnt].repeat_config));
        cJSON_AddItemToArray(p_out, sch_obj);
    }

    return BP_ERR_NO_ERR;
}


/**
* @brief bypass 查询Schedule回调接口
* @param[in]  p_msg_ctx                [msg context]
* @param[in]  p_data                   [回调函数传入数据]
*/
static void ls_bp_get_schedules(bypass_msg_ctx_t *p_msg_ctx, void *p_data)
{
    int error_code = BP_ERR_PARA_ILLEGAL;

    if(NULL == p_data)
    {
        vesync_bypass_reply_pkg_err_msg(BP_ERR_PARA_ILLEGAL, p_msg_ctx->p_trace_msg, BP_ERR_PARAM_CONV(p_data, BP_ERR_PARAM_NULL_PTR));
        return;
    }

    uint32_t index = *((uint32_t *)p_data);
    cJSON *json_sch_ret = NULL;
    cJSON *json_array = NULL;
    // 配置项总数
    uint32_t total_num = 0;
    void *mult_sche_buf = NULL;

    // 输出列表
    bypass_schedule_base_t sch_bp_list[LS_SCHEDULE_GET_MAX_NUM];
    // 初始化输出列表
    memset(sch_bp_list, 0, sizeof(bypass_schedule_base_t) * LS_SCHEDULE_GET_MAX_NUM);
    // 读取配置项
    error_code = ls_schedule_get_mult(index, &mult_sche_buf, sch_bp_list, &total_num);
    if (BP_ERR_NO_ERR == error_code)
    {
        // 查询成功，生成回应
        json_sch_ret = cJSON_CreateObject();
        if (NULL != json_sch_ret)
        {
            cJSON_AddNumberToObject(json_sch_ret, "total", total_num);
            json_array = cJSON_AddArrayToObject(json_sch_ret, "schedules");
            // 把配置项列表生成JSON添加到回应的JSON
            error_code =  schedule_list_json_marshal(json_array, sch_bp_list, LS_SCHEDULE_GET_MAX_NUM);
        }
    }

    if (BP_ERR_SCHEDULE_NOT_FOUND == error_code)
    {
        error_code = BP_ERR_NO_ERR;

        // 生成空回应
        json_sch_ret = cJSON_CreateObject();
        if (NULL != json_sch_ret)
        {
            cJSON_AddNumberToObject(json_sch_ret, "total", total_num);
            cJSON_AddArrayToObject(json_sch_ret, "schedules");
        }
    }

    // 释放配置读取内存
    vesync_free(mult_sche_buf);
    vesync_bypass_reply_noqos(error_code, p_msg_ctx->p_trace_msg, json_sch_ret);
}


/**
* @brief 设置开关开启/关闭
* @param[in]  p_msg_ctx                [msg context]
* @param[in]  p_data                   [回调函数传入数据]
*/
static void ls_bp_set_switch_onoff(bypass_msg_ctx_t *p_msg_ctx, void *p_data)
{
    if (NULL == p_data)
    {
        vesync_bypass_reply_pkg_err_msg(BP_ERR_PARA_ILLEGAL, p_msg_ctx->p_trace_msg, BP_ERR_PARAM_CONV(p_data, BP_ERR_PARAM_NULL_PTR));
        return;
    }
    bypass_switch_data_t *p_sw = (bypass_switch_data_t*)p_data;
    ls_ev_t ev;
    ls_status_t ls_status;
    ls_get_status(&ls_status);
    memset(&ev, 0, sizeof(ls_ev_t));
    if (p_sw->enable)
    {
        ev.id = LS_EV_ON;
        ev.param.mode_param.mode = ls_status.mode;
        ev.param.mode_param.scene_id = (ls_status.mode == LS_MODE_SCENE ? ls_status.scene_id : ls_status.music_id);
        ev.param.mode_param.brightness = ls_status.brightness;
        ev.param.mode_param.speed = ls_status.speed;
    }
    else
    {
        ev.id = LS_EV_OFF;
    }

    ev.act_src = LS_ACT_SRC_BYPASS;
    ls_app_task_notify(&ev);
    ls_report_set_chg_rsn(p_msg_ctx->p_trace_msg->src_type);
    vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, NULL);
}

/**
* @brief 反转开关的开启/关闭状态
* @param[in]  p_msg_ctx                [msg context]
* @param[in]  p_data                   [回调函数传入数据]
*/
static void ls_bp_toggle(bypass_msg_ctx_t *p_msg_ctx, void *p_data)
{
    ls_ev_t ev;
    ls_status_t ls_status;
    ls_get_status(&ls_status);
    memset(&ev, 0, sizeof(ls_ev_t));
    if (!ls_status.status)
    {
        ev.id = LS_EV_ON;
        ev.param.mode_param.mode = ls_status.mode;
        ev.param.mode_param.scene_id = (ls_status.mode == LS_MODE_SCENE ? ls_status.scene_id : ls_status.music_id);
        ev.param.mode_param.brightness = ls_status.brightness;
        ev.param.mode_param.speed = ls_status.speed;
    }
    else
    {
        ev.id = LS_EV_OFF;
    }

    ev.act_src = LS_ACT_SRC_BYPASS;
    ls_app_task_notify(&ev);
    ls_report_set_chg_rsn(p_msg_ctx->p_trace_msg->src_type);
    vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, NULL);
}

/**
* @brief 调整亮度色温百分比
* @param[in]  p_msg_ctx                [msg context]
* @param[in]  p_data                   [回调函数传入数据]
*/
static void ls_bp_adjust_percent(bypass_msg_ctx_t *p_msg_ctx, void *p_data)
{
    if (NULL == p_data)
    {
        vesync_bypass_reply_pkg_err_msg(BP_ERR_PARA_ILLEGAL, p_msg_ctx->p_trace_msg, BP_ERR_PARAM_CONV(p_data, BP_ERR_PARAM_NULL_PTR));
        return;
    }

    bypass_adjust_percent_t *data = (bypass_adjust_percent_t*)p_data;
    int temp = 0;
    uint8_t cur_bright;
    ls_ev_t ev;
    memset(&ev, 0, sizeof(ls_ev_t));
    ev.id = LS_EV_ON;
    ev.act_src = LS_ACT_SRC_BYPASS;

    ls_status_t ls_status;
    ls_get_status(&ls_status);
    cur_bright = ls_status.brightness;
    ev.param.mode_param.mode = ls_status.mode;
    ev.param.mode_param.scene_id = (ls_status.mode == LS_MODE_SCENE ? ls_status.scene_id : ls_status.music_id);
    ev.param.mode_param.brightness = ls_status.brightness;
    ev.param.mode_param.speed = ls_status.speed;

    if (0 == strcmp(data->type, "brightness"))
    {
        if (LS_MODE_MUSIC == ls_status.mode && true == ls_status.status)
        {
            // 该接口设置亮度时处于音乐模式下不响应
            vesync_bypass_reply_pkg_err_msg(BP_ERR_NOT_EXEC_IN_CUR_MODE, p_msg_ctx->p_trace_msg, "Mode doesn't suport! \n");
            return;
        }
        // 不响应关闭模式下降低亮度，其他都需要调整亮度
        if (false != ls_status.status || 0 < data->step)
        {
            cur_bright = (false == ls_status.status ? 0 : cur_bright);
            temp = cur_bright + data->step;
            if (temp <= 0)
            {
                ev.id = LS_EV_OFF;
                temp = 0;
            }
            else if (temp > LS_BRIGHTNESS_MAX)
            {
                temp = LS_BRIGHTNESS_MAX;
            }

            if (0 < temp )
            {
                if (LS_MODE_MUSIC != ls_status.mode)
                {
                    ev.param.mode_param.brightness = temp;
                }
            }
        }
        else
        {
            ev.id = LS_EV_UNKNOWN;
        }

    }
    else if (0 == strcmp(data->type, "speed"))
    {
        if (true == ls_status.status &&
           (LS_MODE_MUSIC == ls_status.mode || (false == ls_scene_id_speed_check(ls_status.scene_id) && LS_MODE_SCENE == ls_status.mode)))
        {
            // 该接口调整速度时，处于音乐模式下或者一些场景模式下不响应
            vesync_bypass_reply_pkg_err_msg(BP_ERR_NOT_EXEC_IN_CUR_MODE, p_msg_ctx->p_trace_msg, "Mode doesn't suport! \n");
            return;
        }

        temp = ls_status.speed * 25 + data->step;
        if (temp > 100)
        {
            temp = 100;
        }
        else if (temp < 25)
        {
            temp = 25;
        }

        ev.param.mode_param.speed = temp / 25;
    }
    else
    {
        vesync_bypass_reply_pkg_err_msg(BP_ERR_PARA_ILLEGAL, p_msg_ctx->p_trace_msg, "Invalid type ! ");
        return;
    }

    // 回复与上报
    cJSON *p_json_result = NULL;
    p_json_result = cJSON_CreateObject();
    if (p_json_result != NULL)
    {
        cJSON_AddNumberToObject(p_json_result, "percent", temp);
    }
    if (ev.id != LS_EV_UNKNOWN)
    {
        ls_app_task_notify(&ev);
    }
    ls_report_set_chg_rsn(p_msg_ctx->p_trace_msg->src_type);
    vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, p_json_result);
}


/**
* @brief led状态json数据打包
* @param[in]  light_params      [led参数]
* @param[out]  *p_data          [json指针]
*/
static void ls_bp_light_status_json_marshal(ls_status_t *light_params, cJSON *p_data)
{
    if (light_params->status == false)
    {
        cJSON_AddStringToObject(p_data, "enabled", "off");
    }
    else
    {
        cJSON_AddStringToObject(p_data, "enabled", "on");
    }

    if (light_params->mode == LS_MODE_SCENE)
    {
        cJSON_AddStringToObject(p_data, "colorMode", "scenario");
    }
    else
    {
        cJSON_AddStringToObject(p_data, "colorMode", "music");
    }

    cJSON_AddNumberToObject(p_data, "sceneId", light_params->scene_id);
    cJSON_AddNumberToObject(p_data, "musicModeId", light_params->music_id);
    cJSON_AddNumberToObject(p_data, "brightness", light_params->brightness);
    cJSON_AddNumberToObject(p_data, "speed", light_params->speed);
}

/**
* @brief 设置灯状态
* @param[in]  p_msg_ctx                [msg context]
* @param[in]        json            [传入json]
* @return           BYPASS_ERR_E    [错误码]
*/
static BYPASS_ERR_E ls_bp_set_light_status(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);
    cJSON* json_data = NULL;
    cJSON *json_id = NULL;
    uint8_t force = 0;
    int ret = 0;
    uint8_t data_num = 0;
    ls_ev_t ev;
    memset(&ev, 0, sizeof(ls_ev_t));
    ls_status_t ls_status;

    ls_get_status(&ls_status);
    ev.id = LS_EV_ON;           // 默认开启
    ev.act_src = LS_ACT_SRC_BYPASS;
    ls_status_t set_params;
    memset(&set_params, 0xff, sizeof(ls_status_t));
    set_params.mode = LS_MODE_OFF;
    json_data = cJSON_GetObjectItemCaseSensitive(json, "force");
    if (NULL != json_data)
    {
        force = json_data->valueint;
    }
    else // force字段可选，没有时为0
    {
        force = 0;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "brightness");
    if (NULL != json_data)
    {
        VCOM_IN_RANGE_CHK(json_data->valueint, (force != 2 ? 1 : 0), LS_BRIGHTNESS_MAX, (ret++));
        if (ret)
        {
            vesync_bypass_reply_pkg_err_msg(BP_ERR_PARA_ILLEGAL, p_msg_ctx->p_trace_msg, NULL);
            return BP_ERR_ARG;
        }
        set_params.brightness = json_data->valueint;

        data_num++;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "speed");
    if (NULL != json_data)
    {
        VCOM_IN_RANGE_CHK(json_data->valueint, 1, LS_SPEED_MAX, (ret++));
        if (ret)
        {
            vesync_bypass_reply_pkg_err_msg(BP_ERR_PARA_ILLEGAL, p_msg_ctx->p_trace_msg, NULL);
            return BP_ERR_ARG;
        }
        set_params.speed = json_data->valueint;
        data_num++;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "colorMode");
    if (NULL != json_data)  // APP 下发的指令
    {
        // colorMode != NULL
        if (!cJSON_IsString(json_data))
        {
            vesync_bypass_reply_pkg_err_msg(BP_ERR_PARA_ILLEGAL, p_msg_ctx->p_trace_msg, NULL);
            return BP_ERR_ARG;
        }
        else if (0 == strcmp(json_data->valuestring, "scenario"))
        {
            set_params.mode = LS_MODE_SCENE;
            json_id = cJSON_GetObjectItemCaseSensitive(json, "sceneId");
        }
        else if (0 == strcmp(json_data->valuestring, "music"))
        {
            set_params.mode = LS_MODE_MUSIC;
            json_id = cJSON_GetObjectItemCaseSensitive(json, "musicModeId");
        }
        else
        {
            vesync_bypass_reply_pkg_err_msg(BP_ERR_PARA_ILLEGAL, p_msg_ctx->p_trace_msg, NULL);
            return BP_ERR_ARG;
        }

        if (json_id == NULL)
        {
            vesync_bypass_reply_pkg_err_msg(BP_ERR_PARA_ILLEGAL, p_msg_ctx->p_trace_msg, NULL);
            return BP_ERR_ARG;
        }
        else
        {
            VCOM_IN_RANGE_CHK(json_id->valueint, 1, (set_params.mode == LS_MODE_SCENE ? LS_MODE_NUM : LS_MODE_MUSIC_NUM),
                             (ret++));
            if (ret)
            {
                vesync_bypass_reply_pkg_err_msg(BP_ERR_PARA_ILLEGAL, p_msg_ctx->p_trace_msg, NULL);
               return BP_ERR_ARG;
            }

            if (set_params.mode == LS_MODE_SCENE)
            {
                set_params.scene_id = json_id->valueint;
            }
            else
            {
                set_params.music_id = json_id->valueint;
            }
        }
        data_num++;
    }

    if (data_num == 0)
    {
        // 无相关数据
        vesync_bypass_reply_pkg_err_msg(BP_ERR_PARA_ILLEGAL, p_msg_ctx->p_trace_msg, NULL);
        return BP_OK;
    }

    if (force == 2)
    {
        if (set_params.brightness == 0 && ls_status.status)
        {
            if (ls_status.mode == LS_MODE_MUSIC)
            {
                vesync_bypass_reply_pkg_err_msg(BP_ERR_NOT_EXEC_IN_CUR_MODE, p_msg_ctx->p_trace_msg, NULL);
                return BP_OK;
            }
            ev.id = LS_EV_OFF;
            s_ls_voice_off_flag = true;
            ls_status.status = false;
        }
        else if (set_params.brightness == 100 && !ls_status.status)
        {
            if (!ls_status.status)
            {
                if (s_ls_voice_off_flag)
                {
                    ls_status.status = true;
                    ls_status.brightness = 100;
                }
            }
        }
        else
        {
            ev.id = LS_ACT_SRC_UNKNOW;
        }
    }
    else if (force < 2)
    {
        if (ls_status.status == true)
        {
            // 等同force=0 ,开机状态下处于不支持音乐模式调节速度和亮度,并且一些模式不支持调速度
            if ((set_params.mode == LS_MODE_MUSIC && (set_params.speed != 0xff || set_params.brightness != 0xff))
               // 未下发模式，则认为是第三方语音或group下发指令，音乐模式和某些场景模式不支持调速
               || (set_params.mode == LS_MODE_OFF && (ls_status.mode == LS_MODE_MUSIC || false == ls_scene_id_speed_check(ls_status.scene_id))
                                                  && set_params.speed != 0xff)
               // 未下发模式，则认为是第三方语音或group下发指令，音乐模式不支持调亮度
               || (set_params.mode == LS_MODE_OFF && ls_status.mode == LS_MODE_MUSIC && set_params.brightness != 0xff))
            {
                vesync_bypass_reply_pkg_err_msg(BP_ERR_NOT_EXEC_IN_CUR_MODE, p_msg_ctx->p_trace_msg, NULL);
                return BP_ERR_ARG;
            }
        }
        else
        {
            if (set_params.mode == LS_MODE_OFF)
            {
                //关机状态下,仅开机
                set_params.mode = ls_status.mode;
            }
        }

        ls_status.status = true;
        ls_status.mode = (set_params.mode == LS_MODE_OFF ? ls_status.mode : set_params.mode);
        if (ls_status.mode == LS_MODE_MUSIC)
        {
            ls_status.music_id = (set_params.music_id == 0xff ? ls_status.music_id : set_params.music_id);
        }
        else
        {
            ls_status.scene_id = (set_params.scene_id == 0xff ? ls_status.scene_id : set_params.scene_id);
            ls_status.brightness = (set_params.brightness == 0xff ? ls_status.brightness : set_params.brightness);
            if (set_params.speed == 0xff || false == ls_scene_id_speed_check(ls_status.scene_id))
            {
                ls_status.speed = ls_status.speed;
            }
            else
            {
                ls_status.speed = set_params.speed;
            }
        }
    }
    else
    {
        vesync_bypass_reply_pkg_err_msg(BP_ERR_PARA_ILLEGAL, p_msg_ctx->p_trace_msg, NULL);
        return BP_ERR_ARG;
    }

    ev.param.mode_param.mode = ls_status.mode;
    ev.param.mode_param.scene_id = (ls_status.mode == LS_MODE_SCENE ? ls_status.scene_id : ls_status.music_id);
    ev.param.mode_param.brightness = ls_status.brightness;
    ev.param.mode_param.speed = ls_status.speed;
    if (ev.id != LS_EV_UNKNOWN)
    {
        ls_app_task_notify(&ev);
    }
    ls_report_set_chg_rsn(p_msg_ctx->p_trace_msg->src_type);
    // 回复led状态数据
    cJSON *json_result = NULL;
    json_result = cJSON_CreateObject();
    if (NULL== json_result)
    {
        vesync_bypass_reply_pkg_err_msg(BP_ERR_OUT_OF_MEMORY, p_msg_ctx->p_trace_msg, NULL);
    }
    else
    {
        ls_bp_light_status_json_marshal(&ls_status, json_result);
        vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, json_result);
    }

    return BP_OK;
}


/**
* @brief 获取灯状态
* @param[in]  p_msg_ctx                [msg context]
* @param[in]        json            [传入json]
* @return           BYPASS_ERR_E    [错误码]
*/
static BYPASS_ERR_E ls_bp_get_light_status(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    cJSON *json_result = NULL;
    cJSON *json_extension = NULL;
    ls_status_t ls_status;

    ls_get_status(&ls_status);

    json_result = cJSON_CreateObject();
    if (NULL== json_result)
    {
        vesync_bypass_reply_pkg_err_msg(BP_ERR_OUT_OF_MEMORY, p_msg_ctx->p_trace_msg, NULL);
        return BP_ERR_NOMEM;
    }

    ls_bp_light_status_json_marshal(&ls_status, json_result);
    cJSON_AddItemToObject(json_result, "extension", json_extension = cJSON_CreateObject());
    if (json_extension == NULL)
    {
        cJSON_Delete(json_result);
        vesync_bypass_reply_pkg_err_msg(BP_ERR_OUT_OF_MEMORY, p_msg_ctx->p_trace_msg, NULL);
        return BP_ERR_NOMEM;
    }

    uint32_t next_sch_sec = 0;
    vesync_schedule_get_next_exc_sec(LS_SCHE_INS_ID, &next_sch_sec);
    cJSON_AddNumberToObject(json_extension, "rctSchOffsec", next_sch_sec);
    cJSON_AddNumberToObject(json_extension, "timerRemain", vesync_timing_get_remain_sec(LIGHTSTRING_TIMER_MIN_ID));
    vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, json_result);
    return BP_OK;
}

/**
* @brief 获取灯配置
* @param[in]  p_msg_ctx                [msg context]
* @param[in]        json               [传入json]
* @return           BYPASS_ERR_E       [错误码]
*/
static BYPASS_ERR_E ls_bp_get_light_config(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    cJSON *json_data = NULL;
    json_data = cJSON_CreateObject();
    if (NULL== json_data)
    {
        vesync_bypass_reply_pkg_err_msg(BP_ERR_OUT_OF_MEMORY, p_msg_ctx->p_trace_msg, NULL);
        return BP_ERR_NOMEM;
    }

    ls_status_t ls_status;
    ls_get_status(&ls_status);
    cJSON_AddBoolToObject(json_data, "voiceControl", ls_status.voice_ctrl);
    vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, json_data);
    return BP_OK;

}

/**
* @brief 修改灯配置
* @param[in]  p_msg_ctx                [msg context]
* @param[in]        json               [传入json]
* @return           BYPASS_ERR_E       [错误码]
*/
static BYPASS_ERR_E ls_bp_set_light_config(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    cJSON *json_data = NULL;
    json_data = cJSON_GetObjectItemCaseSensitive(json, "voiceControl");
    if (json_data == NULL || !cJSON_IsBool(json_data))
    {
        vesync_bypass_reply_noqos(BP_ERR_PARA_ILLEGAL, p_msg_ctx->p_trace_msg, NULL);
        return BP_ERR_ARG;
    }

    ls_ev_t ev;
    memset(&ev, 0, sizeof(ls_ev_t));
    ev.id = LS_EV_VOICE_CTRL_ONOFF;
    ev.act_src = LS_ACT_SRC_BYPASS;
    ev.param.voice_ctrl = (bool)json_data->valueint;
    ls_app_task_notify(&ev);
    ls_report_set_chg_rsn(STAT_CHG_RSN_BP_APP_STR);
    vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, NULL);
    return BP_OK;
}


static bypass_user_data_t ls_method_tbl[] = {
    // timer
    {"addTimerV2", ls_bp_add_timer},
    {"getTimerV2", ls_bp_get_timer},
    {"delTimerV2", ls_bp_del_timer},
    {"setLightStatusV2",ls_bp_set_light_status},
    {"getLightStatusV2",ls_bp_get_light_status},
    {"setLightConfig", ls_bp_set_light_config},
    {"getLightConfig", ls_bp_get_light_config},
};



/**
* @brief 注册bypass回调函数
*/
void ls_bypass_reg_cb(void)
{
    // LED
    vesync_bypass_reg_method_cb(BYPASS_METHOD_ID_SET_SWITCH, ls_bp_set_switch_onoff);
    vesync_bypass_reg_method_cb(BYPASS_METHOD_ID_TOGGLE_SWITCH, ls_bp_toggle);
    // addjustPercent
    vesync_bypass_reg_method_cb(BYPASS_METHOD_ID_ADJUST_PERCENT, ls_bp_adjust_percent);
    // Schedule
    vesync_bypass_reg_method_cb(BYPASS_METHOD_ID_ADD_SCHEDULE_V3, ls_bp_add_schedule);
    vesync_bypass_reg_method_cb(BYPASS_METHOD_ID_UPD_SCHEDULE_V3, ls_bp_upd_schedule);
    vesync_bypass_reg_method_cb(BYPASS_METHOD_ID_DEL_SCHEDULE_V3, ls_bp_del_schedule);
    vesync_bypass_reg_method_cb(BYPASS_METHOD_ID_GET_SCHEDULES_V3, ls_bp_get_schedules);

    for (int i = 0; i < SIZEOF_ARRAY(ls_method_tbl); i++)
    {
        vesync_bypass_add_user_item(&ls_method_tbl[i]);
    }

}

