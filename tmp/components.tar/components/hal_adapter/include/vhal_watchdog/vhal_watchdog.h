/**
 *  Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vhal_watchdog.h
 * @brief       开门狗开启和关闭
 * @date        2021-04-22
 */

#ifndef _VHAL_WATCHDOG_H_
#define _VHAL_WATCHDOG_H_

#include <stdint.h>
#include <stdlib.h>


#ifdef __cplusplus
extern "C"
{
#endif

/**
 * @brief   初始化并启动看门狗
 * @param[in]  uint32_t             [看门狗周期]
 * @return     void
 * @note 只能启动1次
 */
void vhal_watchdog_start(uint32_t timeout_ms);

/**
 * @brief   停止看门狗
 * @return  void
 */
void vhal_watchdog_stop(void);


#ifdef __cplusplus
}
#endif

#endif /* _VHAL_WATCHDOG_H_ */
