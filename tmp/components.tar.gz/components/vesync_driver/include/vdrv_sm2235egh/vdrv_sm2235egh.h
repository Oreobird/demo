/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
 * @file        vdrv_sm2235egh.h
 * @brief       sm2235egh驱动接口
 * @date        2021-11-30
 */
#ifndef __VDRV_SM2235EGH_H__
#define __VDRV_SM2235EGH_H__

#include "stdint.h"

#ifdef __cplusplus
extern "C"
{
#endif

/**
 * @brief SM2235EGH工作模式枚举类型定义
 */
typedef enum
{
    SHUTDOWN = 0x00,    // 待机模式
    RGB_MODE = 0x08,    // RGB模式
    CW_MODE = 0x10,     // CW模式
    RGBCW_MODE = 0x18,  // RGBCW模式
} SM2235EGH_MODE_E;

/**
 * @brief SM2235EGH灰度设置参数类型定义
 */
typedef union
{
    struct
    {
        uint16_t out_1r;    // 1号输出的灰度值，取值范围[0～1023]
        uint16_t out_2g;    // 2号输出的灰度值，取值范围[0～1023]
        uint16_t out_3b;    // 3号输出的灰度值，取值范围[0～1023]
    } rgb;                  // RGB灯路灰度值设置
    struct
    {
        uint16_t out_4c;    // 4号输出的灰度值，取值范围[0～1023]
        uint16_t out_5w;    // 5号输出的灰度值，取值范围[0～1023]
    } cw;                   // CW灯路灰度值设置
} sm2235egh_gray_t;

/**
 * @brief 初始化SM2235EGH的IIC端口
 * @param[in] sda_io        [sda输入引脚]
 * @param[in] scl_io        [scl输入引脚]
 * @return int              [成功：SDK_OK，失败：SDK_FAIL]
 */
int vdrv_sm2235egh_init(uint8_t sda_io, uint8_t scl_io);

/**
 * @brief 设置SM2235EGH的工作模式
 * @param[in] mode          [模式由SM2235EGH_MODE_E定义]
 * @return int              [成功：SDK_OK，失败：SDK_FAIL]
 */
int vdrv_sm2235egh_set_mode(SM2235EGH_MODE_E mode);

/**
 * @brief 设置SM2235EGH的各模式的电流量程，设置数值与电流量程关系表如下：
 *          RGB灯路，电流量程配置：     CW灯路，电流量程配置：
 *              0000：4mA               0000：5mA
 *              0001：8mA               0001：10mA
 *              0010：12mA              0010：15mA
 *              0011：16mA              0011：20mA
 *              0100：20mA              0100：25mA
 *              0101：24mA              0101：30mA
 *              0110：28mA              0110：35mA
 *              0111：32mA              0111：40mA
 *              1000：36mA              1000：45mA
 *              1001：40mA              1001：50mA
 *              1010：44mA              1010：55mA
 *              1011：48mA              1011：60mA
 *              1100：52mA              1100：65mA
 *              1101：56mA              1101：70mA
 *              1110：60mA              1110: 75mA
 *              1111：64mA              1111：80mA
 *              default：0010           default：0100
 * @param[in] p_rgb_or_cw   [该参数在RGB或者RGBCW模式为RGB路的电流量程，在CW模式为CW路的电流量程]
 * @param[in] p_optional_cw [可选参数，若在RGBCW模式，需给定CW路的电流量程]
 * @return int              [成功：SDK_OK，失败：SDK_FAIL]
 */
int vdrv_sm2235egh_set_cr(uint8_t *p_rgb_or_cw, uint8_t *p_optional_cw);

/**
 * @brief 设置SM2235EGH的各模式的灰度输出
 * @param[in] p_rgb_or_cw   [该参数在RGB或者RGBCW模式为RGB路的灰度值，在CW模式为CW路的灰度值]
 * @param[in] p_optional_cw [可选参数，若在RGBCW模式，需给定CW路的灰度值]
 * @return int              [成功：SDK_OK，失败：SDK_FAIL]
 */
int vdrv_sm2235egh_set_output(sm2235egh_gray_t *p_rgb_or_cw, sm2235egh_gray_t *p_optional_cw);

#ifdef __cplusplus
}
#endif

#endif /* __VDRV_SM2235EGH_H__ */