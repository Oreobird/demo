/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_task.c
 * @brief       task抽象层，封装freertos任务相关接口
 * @author      Joshua
 * @date        2021-04-20
 */

#include <freertos/FreeRTOS.h>
#include <freertos/task.h>

#include "vesync_common.h"
#include "vesync_task.h"

#define VESYNC_TASK_NAME_MAX_LEN (16)

/*
 * @brief  任务入口函数参数结构体
 */
typedef struct
{
    char name[VESYNC_TASK_NAME_MAX_LEN];
    void (*fn)(void *);
    void *arg;
} targ_t;


/*
 * @brief  任务函数执行入口
 */
static void task_entry(void *arg)
{
    targ_t *targ = arg;
    void (*fn)(void *) = targ->fn;
    void *farg = targ->arg;
    free(targ);

    fn(farg);

    vTaskDelete(NULL);
}

/*
 * @brief  创建任务
 * @param[in]  name                    [任务名称]
 * @param[in]  fn                      [任务执行函数]
 * @param[in]  arg                     [参数]
 * @param[in]  stack_size              [栈大小]
 * @param[in]  prio                    [任务优先级]
 * @param[in]  task_handle             [创建的任务结构体指针]
 * @return int                         [成功：VOS_OK；失败：VOS_FAIL]
 */
int vesync_task_new(const char *name,
                          void (*fn)(void *),
                          void *arg,
                          int stack_size,
                          int prio,
                          vesync_task_t task)
{
    VCOM_NULL_PARAM_CHK(name, return -1);
    VCOM_NULL_PARAM_CHK(fn, return -1);

    BaseType_t ret;
    TaskHandle_t task_hdl;
    targ_t *targ = malloc(sizeof(targ_t));
    if (targ == NULL)
    {
        return VOS_FAIL;
    }

    targ->fn = fn;
    targ->arg = arg;

    ret = xTaskCreate(task_entry,
                      name,
                      stack_size/sizeof(portSTACK_TYPE),
                      targ,
                      prio,
                      &task_hdl);
    if (ret != pdPASS)
    {
        free(targ);
        return VOS_FAIL;
    }

    if (task)
    {
        task = task_hdl;
    }

    return VOS_OK;
}

/*
* @brief  销毁任务
* @param[in]  task                    [任务结构体指针]
* @return void
*/
void vesync_task_free(vesync_task_t task)
{
    if (task == NULL)
    {
        vTaskDelete(NULL);
        return;
    }

    vTaskDelete(task);
}

/*
 * @brief  获取当前任务名称
 * @return const char *                [返回当前任务名称]
 */
const char *vesync_task_name(void)
{
    TaskHandle_t task = xTaskGetCurrentTaskHandle();
    return pcTaskGetTaskName(task);
}

/*
 * @brief  运行任务调度
 * @return const char *                [返回当前任务名称]
 */
void vesync_task_start(vesync_task_t task)
{
    UNUSED(task);
    vTaskStartScheduler();
}

/*
 * @brief  获取系统tick，单位转为毫秒
 * @return uint64_t                     [返回系统tick]
 */
uint64_t vesync_task_get_tick_ms(void)
{
    TickType_t ticks = xTaskGetTickCount();
    uint64_t ms = (ticks + configTICK_RATE_HZ - 1) / configTICK_RATE_HZ * 1000;
    return ms;
}

