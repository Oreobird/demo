/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_netcfg_event.h
 * @brief       配网模块的定时器
 * @author      Louis
 * @date        2021-05-21
 */

#ifndef __VESYNC_NETCFG_EVENT_H__
#define __VESYNC_NETCFG_EVENT_H__

#include "vesync_event_internal.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef PR_NETCFG_QUEUE_MAX_NUM
#error "Error: Please set PR_NETCFG_QUEUE_MAX_NUM in vesync_config.ini"
#else
#define NETCFG_QUEUE_MAX_NUM       (PR_NETCFG_QUEUE_MAX_NUM)
#endif

/**
* @brief 事件订阅回调函数类型
*/
typedef int (*netcfg_event_cb)(vesync_ev_t *event);

typedef void (*netcfg_app_cb)(void);

/**
* @brief 事件结构体
*/
typedef struct
{
    EVENT_ID_E ev_id;
    netcfg_event_cb ev_cb;
} netcfg_ev_t;



/**
 * @brief  初始化事件处理
 * @return     int              [处理结果]
 */
int netcfg_event_init(void);

/**
 * @brief  注销事件通知
 */
void netcfg_event_deinit(void);

/**
 * @brief  接收事件通知
 * @param[out] event            [事件消息]
 * @param[in]  timeout_ms       [超时时间]
 * @return     int              [接收结果]
 */
int netcfg_receive_event(vesync_ev_t *event, unsigned int timeout_ms);

/**
 * @brief  事件通知分发处理
 * @param[in]  event            [事件消息]
 * @return     int              [处理结果]
 */
int netcfg_dispatch_event(vesync_ev_t *event);



#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_NETCFG_EVENT_H__ */

