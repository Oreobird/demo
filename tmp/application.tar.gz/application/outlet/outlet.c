/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        outlet.c
 * @brief       SDK入口函数
 * @author      Joshua
 * @date        2021-04-22
 */

#include <stdio.h>
#include "vesync_common.h"
#include "vesync_init.h"
#include "vesync_log.h"
#include "vesync_queue.h"
#include "vesync_device.h"
#include "vesync_flash.h"
#include "vesync_production.h"
#include "vesync_netcfg.h"
#include "vesync_wifi_led.h"

#include "outlet_board.h"
#include "outlet_wifi_led.h"
#include "outlet_device.h"
#include "outlet_bypass.h"
#include "outlet_flash.h"
#if defined(OUTLET_ELEC_METERING) && (OUTLET_ELEC_METERING == 1)
#include "outlet_metering.h"
#include "outlet_save_elec.h"
#endif
#include "outlet_button.h"
#include "outlet_timing.h"
#include "outlet_inching.h"
#include "outlet_report.h"
#include "outlet_production.h"
#include "outlet_schedule.h"
#include "outlet_away.h"
#include "outlet.h"


static vesync_queue_t *s_event_queue = NULL;

/**
 * @brief  vesync sdk初始化前回调
 */
static void outlet_pre_cb(void)
{
    APP_LOG(LOG_DEBUG, "Outlet pre init callback\n");
    outlet_init_gpio();
    outlet_reg_wifi_led();
}


/**
 * @brief  app任务事件处理
 */
static void app_event_handle(outlet_ev_t ev)
{
    bool status_change = false;

    switch (ev.id)
    {
        case OUTLET_EV_ON:
            outlet_set_switch_change_reason(ev.rsn);
            if (!outlet_get_switch_onoff())
            {
                status_change = true;
                outlet_set_switch_onoff(true);
                outlet_inching_start();
            }
            break;
        case OUTLET_EV_OFF:
            outlet_set_switch_change_reason(ev.rsn);
            if (outlet_get_switch_onoff())
            {
                status_change = true;
                outlet_set_switch_onoff(false);
                outlet_inching_stop();
#if defined(OUTLET_ELEC_METERING) && (OUTLET_ELEC_METERING == 1)
                outlet_metering_clear_electricity(OUTLET_SWITCH_USED_ELEC_UNIT);
#endif
            }
            break;
        case OUTLET_EV_TOGGLE:
            outlet_set_switch_change_reason(ev.rsn);
            status_change = true;
            if (OUTLET_ACT_SRC_BTN != ev.act_src)   // 开关IO由按键任务直接处理
            {
                outlet_set_switch_toggle();
            }
            if (outlet_get_switch_onoff())
            {
                outlet_inching_start();
            }
            else
            {
                outlet_inching_stop();
#if defined(OUTLET_ELEC_METERING) && (OUTLET_ELEC_METERING == 1)
                outlet_metering_clear_electricity(OUTLET_SWITCH_USED_ELEC_UNIT);
#endif
            }
            break;
#if defined(OUTLET_ELEC_METERING) && (OUTLET_ELEC_METERING == 1)
        case OUTLET_EV_REPORT_EXC:
            outlet_inching_stop();
            outlet_metering_clear_electricity(OUTLET_SWITCH_USED_ELEC_UNIT);
            outlet_report_exception();
            break;
        case OUTLET_EV_SAVE_ELEC:
            switch (ev.act_src)
            {
                case OUTLET_ACT_SRC_ELEC_SAVE_TICK:
                    outlet_save_elec_exec(ELEC_SAVE_TRIG_TICK);
                    break;
                case OUTLET_ACT_SRC_ELEC_SAVE_CLOCK:
                    APP_LOG(LOG_DEBUG, "ELEC_SAVE_CLOCK\n");
                    outlet_save_elec_exec(ELEC_SAVE_TRIG_CLOCK);
                    break;
                case OUTLET_ACT_SRC_ELEC_SAVE_UPD_TS:
                    outlet_save_elec_exec(ELEC_SAVE_TRIG_UPD_TS);
                    break;
                default:
                    break;
            }
            break;
        case OUTLET_EV_REPORT_ELEC:
            outlet_save_elec_report();
            break;
#endif
        case OUTLET_EV_PRODUCTION:
            vesync_production_enter_testmode(true);
            break;
        case OUTLET_EV_PCBA_TEST:
            outlet_production_test_relay();
            break;
        case OUTLET_EV_BEFORE_NETCFG:
            vesync_wifi_led_set_behavior(WIFI_LED_NOT_CONFIG);
            break;
        case OUTLET_EV_NETCFG:
            vesync_netcfg_start();
            break;
        case OUTLET_EV_NET_CONNETED:
#if defined(OUTLET_ELEC_METERING) && (OUTLET_ELEC_METERING == 1)
            outlet_retry_report_history_elec();
            if (outlet_get_protect_status())    // 已触发保护
            {
                outlet_report_exception();
            }
#endif
            break;
        case OUTLET_EV_RESET:
            vesync_device_factory_reset(true, STAT_CHG_RSN_BTN_STR);
            break;
        default:
            APP_LOG(LOG_WARN, "Unknown event\n");
            break;
    }

    if (status_change)
    {
        if (OUTLET_ACT_SRC_BTN == ev.act_src
            || OUTLET_ACT_SRC_APP == ev.act_src
            || OUTLET_ACT_SRC_TASK == ev.act_src)
        {
            outlet_report_on_off(outlet_get_switch_onoff());
        }
#if defined(OUTLET_ELEC_METERING) && (OUTLET_ELEC_METERING == 1)
        else if (OUTLET_ACT_SRC_LOW_POW_TRIG == ev.act_src)
        {
            outlet_report_pow_trig_exec(1); // 1——低功率保护
            outlet_report_on_off(outlet_get_switch_onoff());
        }
        else if (OUTLET_ACT_SRC_HIGH_POW_TRIG == ev.act_src)
        {
            outlet_report_pow_trig_exec(0); // 0——高功率保护
            outlet_report_on_off(outlet_get_switch_onoff());
        }
        else if (OUTLET_ACT_SRC_ELEC_SAVE_OVER == ev.act_src)
        {
            outlet_report_elec_save_exec();
            outlet_report_on_off(outlet_get_switch_onoff());
        }
#endif
    }

    if (OUTLET_ACT_SRC_RESET == ev.act_src)
    {
        outlet_report_on_off(outlet_get_switch_onoff());
    }
}


/**
 * @brief  app应用任务
 */
static void app_task(void *arg)
{
    UNUSED(arg);
    APP_LOG(LOG_DEBUG, "-------app task running--------\n");
    outlet_ev_t ev;

    while(1)
    {
        int ret = vesync_queue_recv(s_event_queue, &ev, VESYNC_OS_WAIT_FOREVER);
        if (VOS_OK == ret)
        {
            app_event_handle(ev);
        }
        else
        {
            APP_LOG(LOG_ERROR, "Event queue recv fail\n");
        }
    }

}

#if defined(OUTLET_ELEC_METERING) && (OUTLET_ELEC_METERING == 1)
/**
 * @brief  过流保护处理
 * @note    触发过流保护会断开继电器并禁用继电器，需要重新上电才能恢复
 */
static void outlet_overcurrent_protection_handle(void)
{
    outlet_ev_t ev;

    if (outlet_get_protect_status())    // 已触发保护
    {
        return;
    }
    outlet_disable_switch();

    memset(&ev, 0, sizeof(ev));
    ev.id = OUTLET_EV_REPORT_EXC;
    ev.act_src = OUTLET_ACT_SRC_UNKNOW;
    snprintf(ev.rsn, sizeof(ev.rsn), "%s", STAT_CHG_RSN_PROT_STR);
    outlet_app_task_notify(&ev);
}

#define STAT_CHG_RSN_METERING_STR       "metering"

/**
 * @brief  用电量超过省电设置处理
 */
static void outlet_over_elec_handle(void)
{
    outlet_ev_t ev;

    ev.id = OUTLET_EV_OFF;
    ev.act_src = OUTLET_ACT_SRC_ELEC_SAVE_OVER;
    snprintf(ev.rsn, sizeof(ev.rsn), "%s", STAT_CHG_RSN_METERING_STR);
    outlet_app_task_notify(&ev);
}

/**
 * @brief  功率触发处理
 * @param[in]   type        [0——高于最大功率触发，1——低于最小功率触发]
 */
static void outlet_pow_trig_handle(uint8_t type)
{
    outlet_ev_t ev;
    ev.id = OUTLET_EV_OFF;
    if (1 == type)
    {
        ev.act_src = OUTLET_ACT_SRC_LOW_POW_TRIG;
    }
    else
    {
        ev.act_src = OUTLET_ACT_SRC_HIGH_POW_TRIG;
    }
    snprintf(ev.rsn, sizeof(ev.rsn), "%s", STAT_CHG_RSN_METERING_STR);
    outlet_app_task_notify(&ev);
}

#define OUTLET_HIGH_POW_TRIG_THOLD        (1)
#define OUTLET_HIGH_POW_TICK_MS_MAX_INVL    (1000)

/**
 * @brief  高于设置功率处理
 * @param[in]   value       [功率值]
 */
static void outlet_high_pow_handle(float value)
{
    static uint64_t s_last_tick = 0;
    static uint8_t trig_times = 0;

    uint64_t cur_tick = vesync_task_get_tick_ms();

    if (0 >= value)
    {
        trig_times = 0;
        s_last_tick = 0;
        return;
    }

    if (cur_tick - s_last_tick > OUTLET_HIGH_POW_TICK_MS_MAX_INVL)
    {
        trig_times = 0;
    }
    s_last_tick = cur_tick;
    trig_times += 1;
    if (trig_times < OUTLET_HIGH_POW_TRIG_THOLD)
    {
        return;
    }

    trig_times = 0;
    outlet_pow_trig_handle(0);
}


#define OUTLET_LOW_POW_TICK_MS_MAX_INVL       (30*1000)
#define OUTLET_LOW_POW_TRIG_START_WAIT_MS     (10*1000)
#define OUTLET_LOW_POW_TRIG_THOLD             (5 * 60)

/**
 * @brief  低于设置功率处理
 * @note   存在功率从高于设置功率下降到低于设置功率，并持续一段时间才触发
 *         修改设置后需要传入零重置
 * @param[in]   value       [功率值]
 */
static void outlet_low_pow_handle(float value)
{
    static uint64_t s_last_tick = 0;
    static uint32_t trig_times = 0;
    static uint8_t high_to_low_flag = 0;    // 标记是否从高功率下降到低功率

    uint64_t cur_tick = vesync_task_get_tick_ms();
    if (s_last_tick < OUTLET_LOW_POW_TRIG_START_WAIT_MS || 0 >= value || !outlet_get_switch_onoff())
    {
        s_last_tick = cur_tick;
        trig_times = 0;
        high_to_low_flag = 0;
        return;
    }
    if (cur_tick - s_last_tick > OUTLET_LOW_POW_TICK_MS_MAX_INVL)
    {
        trig_times = 0;
        high_to_low_flag = 1;
    }
    s_last_tick = cur_tick;
    if (high_to_low_flag)
    {
        trig_times += 1;
    }
    if (trig_times < OUTLET_LOW_POW_TRIG_THOLD)
    {
        return;
    }

    high_to_low_flag = 0;
    trig_times = 0;
    outlet_pow_trig_handle(1);
}

/**
 * @brief  软件保护处理
 * @param[in]   unit        [电量计量通道]
 * @param[in]   type        [计量数据类型]
 * @param[in]   value       [数值]
 */
static void outlet_soft_prot_handle(uint8_t unit, METERING_TYPE_E type, float value)
{
    //APP_LOG(LOG_DEBUG, "unit: %d, type: %d, value: %f\n", unit, type, value);
    switch(type)
    {
        case METERING_ELE:
            if (OUTLET_SWITCH_USED_ELEC_UNIT == unit) // 监控通道1
            {
                outlet_over_elec_handle();
            }
            break;
        case METERING_HIGH_POW:
            outlet_high_pow_handle(value);
            break;
        case METERING_LOW_POW:
            outlet_low_pow_handle(value);
            break;
        case METERING_LOW_VOL:
        case METERING_HIGH_VOL:
        case METERING_LOW_CUR:
        case METERING_HIGH_CUR:
        default:
            break;
    }
}
#endif


/**
 * @brief  应用层任务回调
 */
static void outlet_app_run(void)
{
    APP_LOG(LOG_INFO, "Vesync APP Outlet start\n");

#if defined(OUTLET_ELEC_METERING) && (OUTLET_ELEC_METERING == 1)
    metering_conf_t conf;
    memset(&conf, 0, sizeof(conf));
    conf.gpios.sel_gpio = OUTLET_METERING_SEL_GPIO_NUM;
    conf.gpios.cf_gpio = OUTLET_METERING_CF_GPIO_NUM;
    conf.gpios.cfi_gpio = OUTLET_METERING_CFI_GPIO_NUM;
    conf.max_power = OUTLET_METERING_MAX_POW;
    conf.max_voltage = OUTLET_METERING_MAX_VOL;
    conf.max_current = OUTLET_METERING_MAX_CUR;
    conf.exception_cb = outlet_overcurrent_protection_handle;
    conf.event_cb = outlet_soft_prot_handle;
    outlet_metering_init(&conf);

    outlet_save_elec_init();
#endif

    outlet_button_init();

    outlet_bypass_reg_cb();

    //注册产测回调函数
    vesync_production_reg_status_cb(outlet_production_callback);

    // 注册恢复出厂重启前其它事务处理回调函数
    vesync_device_reg_reset_pre_reboot_cb(outlet_device_pre_reset_callback);

    // 注册缓存数据清除函数(恢复出厂/删除设备时调用)
    vesync_device_reg_clear_data_cb(outlet_device_clear_all_data);

    outlet_timing_init();
    outlet_inching_init();
    outlet_report_init();
    outlet_schedule_init();
    outlet_away_init();

    s_event_queue = vesync_queue_new(OUTLET_EVENT_QUEUE_MAX_NUM * sizeof(outlet_ev_t), sizeof(outlet_ev_t));
    if (s_event_queue == NULL)
    {
        APP_LOG(LOG_ERROR, "App event queue create failed\n");
        return;
    }

    int ret = vesync_task_new(OUTLET_APP_TASK_NAME, NULL, app_task, NULL, OUTLET_APP_TASK_STACKSIZE, OUTLET_APP_TASK_PRIO, NULL);
    if (ret != VOS_OK)
    {
        APP_LOG(LOG_ERROR, "App task create failed\n");
        vesync_queue_free(s_event_queue);
        return;
    }
    if (APP_OK != outlet_pcba_test_process())
    {
        switch_load_config(OUTLET_ACT_SRC_INIT);
    }
}

/**
 * @brief  给switch应用任务发通知
 * @param[in]   event_id        [通知消息]
 * @return     int              [成功：SDK_OK，失败：SDK_FAIL]
 */
int outlet_app_task_notify(outlet_ev_t *ev)
{
    int ret = vesync_queue_send(s_event_queue, ev, VESYNC_OS_NO_WAIT);
    if (ret != VOS_OK)
    {
        APP_LOG(LOG_ERROR, "Event publish failed\n");
        return APP_FAIL;
    }

    return APP_OK;
}

/**
 * @brief  应用入口
 */
void app_main(void)
{
    vesync_sdk_reg_pre_run_cb(outlet_pre_cb);
    vesync_sdk_reg_post_run_cb(outlet_app_run);

    vesync_sdk_run();
}

