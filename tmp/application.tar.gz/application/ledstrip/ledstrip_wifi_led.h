/**
*Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file    ledstrip_wifi_led.h
* @brief   Wi-Fi指示灯配置
* @author  Lind
*@date     2021-09-09
*/


#ifndef __LEDSTRIP_WIFI_LED_H__
#define __LEDSTRIP_WIFI_LED_H__

#ifdef __cplusplus
extern "C" {
#endif

/**
* @brief    设置配网标志位
* @param[in]  flag          [true:未配网/等待配网；false:配网结束/已配网]
*/
void ls_wifi_set_netcfg_flag(bool flag);


/**
* @brief  灯效配置
* @return     int             [成功/失败]
*/
int ls_reg_wifi_led(void);

#ifdef __cplusplus
}
#endif

#endif

