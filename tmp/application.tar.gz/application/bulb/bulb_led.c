/**
*Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file    bulb_led.c
* @brief   灯泡灯效控制
* @author  Dave
*@date     2021-11-11
*/

#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
#include <stdio.h>
#include <math.h>

#include "vesync_common.h"
#include "vesync_log.h"
#include "vesync_memory.h"
#include "vesync_task.h"
#include "vesync_queue.h"
#include "vesync_device.h"
#include "vesync_sem.h"
#include "vesync_timer.h"

#include "bulb.h"
#include "bulb_led.h"
#include "bulb_status.h"
#include "bulb_report.h"
#include "bulb_bypass.h"

#include "bulb_board.h"

static vesync_sem_t *s_bulb_led_sem = NULL;

/**
 * @brief  灯泡led渐变任务退出后的清理
 */
static void bulb_led_deinit(void)
{
    vesync_sem_free(s_bulb_led_sem);
    return;
}

/**
 * @brief   灯泡led渐变任务
 */
static void bulb_led_task(void *args)
{
    uint32_t wait_time = VESYNC_OS_WAIT_FOREVER;
    while (1)
    {
        if (VOS_OK != vesync_sem_wait(s_bulb_led_sem, wait_time))
        {
            bulb_report_status_change(bulb_get_report_status_change());
            wait_time = VESYNC_OS_WAIT_FOREVER;
            continue;
        }
        bulb_open();
        wait_time = 1000;
    }

    APP_LOG(LOG_DEBUG, "bulb led task exit\r\n");
}

/**
 * @brief 灯泡led渐变任务初始化
 * @return int32_t          [成功：APP_OK， 失败：APP_FAIL]
 */
int32_t bulb_led_task_init(void)
{
    int32_t ret = APP_OK;
    s_bulb_led_sem = vesync_sem_binary_new();
    if (NULL == s_bulb_led_sem)
    {
        ret = APP_FAIL;
        APP_LOG(LOG_DEBUG, "bulb led task exit\r\n");
        goto EXIT;
    }
    if (VOS_OK != vesync_task_new(BULB_LED_TASK_NAME,
                                  bulb_led_deinit,
                                  bulb_led_task,
                                  NULL,
                                  BULB_LED_TASK_STACSIZE,
                                  BULB_LED_TASK_PRIO,
                                  NULL))
    {
        APP_LOG(LOG_ERROR, "Create task fail!\r\n");
        ret = APP_FAIL;
        goto EXIT;
    }

EXIT:
    if (APP_FAIL == ret)
    {
        if (NULL != s_bulb_led_sem)
        {
            vesync_sem_free(s_bulb_led_sem);
        }
    }
    else
    {
        APP_LOG(LOG_INFO, "bulb led task init success\r\n");
    }

    return ret;
}

/**
 * @brief  释放信号量，通知收发任务处理
 * @return     int32_t          [成功：APP_OK， 失败：APP_FAIL]
 */
int32_t bulb_led_sem_signal(void)
{
    return (VOS_OK == vesync_sem_signal(s_bulb_led_sem)) ? APP_OK : APP_FAIL;
}
