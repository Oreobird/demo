/**
* Copyright © Vesync Technologies Co.Ltd. 2022. All rights reserved.
* @file    led_strip.c
* @brief   应用层主函数
* @author  Lind
* @date    2022-01-05
*/

#include <stdio.h>
#include <string.h>
#include <math.h>

#include "vesync_init.h"
#include "vesync_common.h"
#include "vesync_init.h"
#include "vesync_log.h"
#include "vesync_queue.h"
#include "vesync_sem.h"
#include "vesync_device.h"
#include "vesync_bypass.h"
#include "vesync_flash.h"
#include "vesync_production.h"
#include "vesync_netcfg.h"
#include "vesync_memory.h"
#include "vesync_wifi_led.h"

#include "vhal_rmt_1_wire.h"
#include "vhal_rmt.h"
#include "vhal_rmt_ir.h"

#include "led_strip.h"
#include "led_strip_led.h"
#include "led_strip_board.h"
#include "led_strip_flash.h"
#include "led_strip_bypass.h"
#include "led_strip_report.h"
#include "led_strip_timing.h"
#include "led_strip_device.h"
#include "led_strip_button.h"
#include "led_strip_schedule.h"
#include "led_strip_wifi_led.h"
#include "led_strip_production.h"

// 应用层事件队列消息
static vesync_queue_t *s_event_queue = NULL;
static vesync_sem_t *s_ls_sem = NULL;

// 应用层参数
static ls_status_t s_ls_status;

static void app_pre_cb(void)
{
    APP_LOG(LOG_DEBUG, "pre init callback\n");
}

/**
* @brief 添加场景成功后释放信号量
*/
static void ls_rel_scene_sem(void)
{
    vesync_sem_signal(s_ls_sem);
}

/**
 * @brief  app任务事件处理
 * @param[in]    ev     [主任务事件结构体]
 */
static void app_event_handle(ls_ev_t ev)
{
    APP_LOG(LOG_INFO, "id %d src %d scene id %d ! \n", ev.id, ev.act_src,ev.scene_id);
    ls_scene_t *pst_scene = NULL;
    static LS_ACT_SRC_E last_src = LS_ACT_SRC_WIFI_LED;
    switch (ev.id)
    {
        case LS_EV_RESET:
            // 灯效
            pst_scene = ls_get_default_scene(ev.scene_id);
            ls_led_set_scene(pst_scene);
            vesync_device_factory_reset(true, STAT_CHG_RSN_BTN_STR);
            break;
        case LS_EV_BEFORE_NETCFG:
            if (ev.act_src == LS_ACT_SRC_BTN || last_src == ev.act_src)
            {
                // 防止按键和平台触发两次配网灯效
                pst_scene = ls_get_default_scene(ev.scene_id);
                ls_led_set_scene(pst_scene);
                s_ls_status.status = false;     // 配网灯效数据不存入flash，该状态用于区分未配网时的模式切换逻辑
                ls_led_set_scene(pst_scene);
            }
            last_src = ev.act_src;
            break;
        case LS_EV_NETCFG:
            APP_LOG(LOG_INFO, "start netcfg\n");
            vesync_netcfg_restart();
            break;
        case LS_EV_PRODUCTION:
            APP_LOG(LOG_INFO, "enter production test mode !!\n");
            vesync_production_enter_testmode(true);
            break;
        case LS_EV_TURN_OFF:
            ls_get_scene_lock(true);
            s_ls_status.status = false;
            ls_set_static_scene(&pst_scene, LS_LED_MODE_OFF);
            ls_led_set_scene(pst_scene);
            ls_save_config(s_ls_status);
            ls_get_scene_lock(false);
            ls_report_status();
            break;
        case LS_EV_TURN_ON:
            ls_get_scene_lock(true);
            if (ev.act_src == LS_ACT_SRC_BTN)
            {
                // 当前模式为判读条件
                if (s_ls_status.mode != LS_MODE_SCENE || s_ls_status.status == false || s_ls_status.scene_id == 0)
                {
                    ls_get_scene_pointer(&s_ls_status.scene_id, s_ls_status.custom_scene_num, false, &pst_scene);
                }
                else
                {
                     ls_get_scene_pointer(&s_ls_status.scene_id, s_ls_status.custom_scene_num, true, &pst_scene);
                }

                s_ls_status.mode = ev.mode;
            }
            else if (ev.act_src == LS_ACT_SRC_SCHEDULE || ev.act_src == LS_ACT_SRC_TIMER)
            {
                s_ls_status.scene_id = ev.scene_id;
                ls_get_scene_pointer(&s_ls_status.scene_id, s_ls_status.custom_scene_num, false, &pst_scene);
                s_ls_status.mode = ev.mode;
            }
            else if (ev.act_src == LS_ACT_SRC_PRD)
            {
                pst_scene = ls_get_default_scene(ev.scene_id);
                s_ls_status.scene_id = 1;
                s_ls_status.mode = LS_MODE_SCENE;
            }
            else if (ev.act_src == LS_ACT_SRC_WIFI_LED)
            {
                // 配网中灯效
                s_ls_status.mode = ev.mode;
                s_ls_status.hsvw.white = 100;
                ls_set_static_scene(&pst_scene, LS_LED_MODE_STATIC);
            }
            else
            {
                // bypass or init
                s_ls_status.mode = ev.mode;
                if (s_ls_status.mode == LS_MODE_SCENE)
                {
                    s_ls_status.scene_id = ev.scene_id;
                    ls_get_scene_pointer(&s_ls_status.scene_id, s_ls_status.custom_scene_num, false, &pst_scene);
                }
                else if (s_ls_status.mode < LS_MODE_SCENE)
                {
                    ls_set_static_scene(&pst_scene, LS_LED_MODE_STATIC);
                }
                else
                {
                    APP_LOG(LOG_ERROR, "Wrong mode ! \n");
                }
            }

            if (s_ls_status.mode != LS_MODE_SCENE)
            {
                s_ls_status.scene_id = ls_get_id_by_index(0);
            }

            s_ls_status.status = true;
            ls_led_set_scene(pst_scene);
            ls_set_voice_off_flag(false);
            ls_save_config(s_ls_status);
            ls_get_scene_lock(false);
            ls_report_status();
            break;
        case LS_EV_SET_NODE_NUM:
            ls_get_scene_lock(true);
            ls_led_set_led_num(s_ls_status.node_num);
            ls_save_config(s_ls_status);
            ls_get_scene_lock(false);
            ls_report_status();
            break;
        case LS_EV_ADD_SCENE:
            ls_get_scene_lock(true);
            if (ls_add_scene(ev.scene_id) == APP_OK)
            {
                s_ls_status.custom_scene_num++;
                s_ls_status.scene_id = ls_get_id_by_index(1);    // 业务逻辑需求
                s_ls_status.last_gen_id = ev.scene_id;
            }
            else
            {
                APP_LOG(LOG_ERROR, "add scene failed ! \n");
            }
            ls_save_config(s_ls_status);
            ls_get_scene_lock(false);
            ls_rel_scene_sem();
            break;
        case LS_EV_DEL_SCENE:
            ls_get_scene_lock(true);
            if (ls_del_scene(ev.scene_id) == APP_OK)
            {
                s_ls_status.custom_scene_num--;
                if (ev.scene_id == s_ls_status.scene_id)
                {
                    // 删除当前场景时赋值为0
                    s_ls_status.scene_id = 0;
                    ls_save_config(s_ls_status);
                    ls_get_scene_lock(false);
                    ls_report_status();
                    return;
                }
            }
            ls_save_config(s_ls_status);
            ls_get_scene_lock(false);
            break;
        default:
            APP_LOG(LOG_WARN, "Unknown event\n");
            break;
    }
}

/**
* @brief 应用灯效参数初始化
*/
void ls_init(void)
{
    VCOM_SAFE_FREE(s_ls_status.multi_hsv);
    memset(&s_ls_status, 0, sizeof(s_ls_status));
    if (APP_FAIL == ls_read_config(&s_ls_status))
    {
        // 读取flash失败
        s_ls_status.status = false;
        s_ls_status.mode = LS_MODE_WHITE;
        s_ls_status.node_num = LED_NODE_NUM;
        s_ls_status.hsvw.white = 100;
        s_ls_status.hsvw.H = 6666;
        s_ls_status.hsvw.S = 10000;
        s_ls_status.hsvw.V = 100;
        s_ls_status.scene_id = 1;
        s_ls_status.custom_scene_num = 0;
        s_ls_status.last_gen_id = LS_SCENE_DEFAULT_MAX_ID;
        ls_hsv_t *multi_hsv = (ls_hsv_t*)vesync_malloc(sizeof(ls_hsv_t) * LED_NODE_MAX_NUM);
        if (multi_hsv == NULL)
        {
            APP_LOG(LOG_ERROR, "out of memory \n");
            return;
        }

        for (uint8_t i = 0; i < LED_NODE_MAX_NUM; i++)
        {
            *(multi_hsv + i) = s_ls_status.hsvw;
        }

        s_ls_status.multi_hsv = multi_hsv;
    }

    if (s_ls_status.custom_scene_num != 0)
    {
        if (APP_FAIL == ls_get_scene(s_ls_status.custom_scene_num))
        {
            if (s_ls_status.scene_id > LS_SCENE_DEFAULT_MAX_ID)
            {
                s_ls_status.scene_id = 1;
            }

            s_ls_status.custom_scene_num = 0;
        }
    }

    ls_scene_init();
    ls_led_set_led_num(s_ls_status.node_num);
    APP_LOG(LOG_INFO, "ls init successful\n");
}

/**
* @brief  app应用任务
*/
static void app_task(void *arg)
{
    UNUSED(arg);
    APP_LOG(LOG_DEBUG, "-------app task running--------\n");
    int ret = VOS_FAIL;
    ls_ev_t ev;
    ev.act_src = LS_ACT_SRC_UNKNOW;
    ret = vesync_queue_recv(s_event_queue, &ev, LS_INIT_TIMS);
    if (ret == VOS_FAIL)
    {
        // 防止短时间内相继触发配网灯效和断电记忆恢复的灯效。
        if (s_ls_status.status)
        {
            // 初始化开启
            ev.id = LS_EV_TURN_ON;
            ev.mode = s_ls_status.mode;
            ev.scene_id = s_ls_status.scene_id;
            APP_LOG(LOG_DEBUG, "Init mode %d \n", ev.mode);
        }
        else
        {
            ev.id = LS_EV_TURN_OFF;
        }
        ls_report_set_chg_rsn(STAT_CHG_RSN_RECONNECT_STR);
        ls_app_task_notify(&ev);
        app_event_handle(ev);
    }

    while(1)
    {
        if (ret == VOS_OK)
        {
            app_event_handle(ev);
        }

        ls_led_display_handle();
        ret = vesync_queue_recv(s_event_queue, &ev, LS_TASK_CYCLE);
    }

}

/**
* @brief 获取添加场景信号量
*/
void ls_wait_scene_sem(void)
{
    vesync_sem_wait(s_ls_sem, 100);
}

/**
* @brief 主函数
*/
static void app_run(void)
{
    APP_LOG(LOG_INFO, "led_strip start\n");
    ls_reg_wifi_led();
    ls_init();
    ls_led_init();
    ls_report_init();
    ls_button_init();
    ls_production_init();
    ls_device_init();
    ls_schedule_init();
    ls_timing_init();
    ls_bypass_reg_cb();
    s_event_queue = vesync_queue_new(LS_EVENT_QUEUE_MAX_NUM * sizeof(ls_ev_t), sizeof(ls_ev_t));
    if (s_event_queue == NULL)
    {
        APP_LOG(LOG_ERROR, "App event queue create failed\n");
        return;
    }

    s_ls_sem = vesync_sem_binary_new();
    if (s_ls_sem == NULL)
    {
        vesync_queue_free(s_event_queue);
        APP_LOG(LOG_ERROR, "App sem create failed\n");
        return;
    }

    int ret = vesync_task_new(LS_APP_TASK_NAME, NULL, app_task, NULL, LS_APP_TASK_STACSIZE, LS_APP_TASK_PRIO, NULL);
    if (ret != VOS_OK)
    {
        APP_LOG(LOG_ERROR, "App task create failed\n");
        vesync_queue_free(s_event_queue);
        vesync_sem_free(s_ls_sem);
        s_ls_sem = NULL;
        s_event_queue = NULL;
        return;
    }
}

/**
* @brief 获取状态
* @param[out]  *pst_status       [状态参数]
*/
void ls_get_status(ls_status_t *pst_status)
{
    if (NULL == pst_status)
    {
        APP_LOG(LOG_ERROR, "NULL pointer\n");
        return;
    }

    *pst_status = s_ls_status;
}

/**
* @brief 获取状态指针，修改灯效参数
* @return[out]  ls_status_t*        [状态指针]
*/
ls_status_t* ls_get_status_pointer(void)
{
    return &s_ls_status;
}


/**
 * @brief  给ledstrip应用任务发通知
 * @param[in]   ev              [通知消息]
 * @return     int              [成功：APP_OK，失败：APP_FAIL]
 */
int ls_app_task_notify(ls_ev_t *ev)
{
    int ret = vesync_queue_send(s_event_queue, ev, VESYNC_OS_NO_WAIT);
    if (ret != VOS_OK)
    {
        APP_LOG(LOG_ERROR, "Event publish failed\n");
        return APP_FAIL;
    }

    return APP_OK;
}

/**
 * @brief  应用层入口
 */
void app_main(void)
{
    vesync_sdk_reg_pre_run_cb(app_pre_cb);
    vesync_sdk_reg_post_run_cb(app_run);
    vesync_sdk_run();
}

