/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vdrv_sm2235egh_test.cpp
 * @brief       vdrv_sm2235egh测试用例
 * @author      Herve
 * @date        2021-12-01
 */

#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <gtest/gtest.h>

#include "vesync_common.h"
#include "vesync_log.h"
#include "vdrv_sm2235egh.h"

#include "stub.h"
#include "vdrv_sm2235egh.c"

#define BITS2BYTE(b7, b6, b5, b4, b3, b2, b1, b0) \
    ((b7 << 7) | (b6 << 6) | (b5 << 5) | (b4 << 4) | (b3 << 3) | (b2 << 2) | (b1 << 1) | (b0))

#define BYTES2SHORT(byte1, byte2) (((byte1) << 8) | (byte2))

static uint8_t sda_io_stub = 0xff;
static uint8_t scl_io_stub = 0xff;
static int32_t vhal_i2c_master_init_stub(uint8_t i2c_num, uint8_t sda_io, uint8_t scl_io, uint32_t speed)
{
    UNUSED(i2c_num);
    UNUSED(speed);
    sda_io_stub = sda_io;
    scl_io_stub = scl_io;
    return VHAL_OK;
}

static uint8_t i2c_addr_stub;
static uint8_t i2c_write_stub[64];
static uint8_t i2c_write_len;
static int32_t vhal_i2c_master_write_stub(uint8_t i2c_num, bool check_ack, uint8_t addr, uint8_t *p_data, int32_t len)
{
    UNUSED(i2c_num);
    UNUSED(check_ack);
    i2c_addr_stub = addr;
    i2c_write_len = len;
    memcpy(i2c_write_stub, p_data, i2c_write_len);
    return VHAL_OK;
}

class vdrv_sm2235egh_test : public testing::Test
{
private:
    static Stub stub;

protected:
    static void SetUpTestCase()
    {
        stub.set(vhal_i2c_master_init, vhal_i2c_master_init_stub);
        stub.set(vhal_i2c_master_write, vhal_i2c_master_write_stub);

        vesync_log_init();

        int ret;
        ret = vdrv_sm2235egh_init(1, 2);
        EXPECT_EQ(ret, SDK_OK);
        EXPECT_EQ(sda_io_stub, 1);
        EXPECT_EQ(scl_io_stub, 2);
    }
    static void TearDownTestCase()
    {
        vesync_log_deinit();

        stub.reset(vhal_i2c_master_init);
        stub.reset(vhal_i2c_master_write);
    }
};

Stub vdrv_sm2235egh_test::stub;

TEST_F(vdrv_sm2235egh_test, set_mode)
{
    int ret;

    ret = vdrv_sm2235egh_set_mode(SHUTDOWN);
    EXPECT_EQ(ret, SDK_OK);
    EXPECT_EQ(i2c_addr_stub, BITS2BYTE(1, 1, 0, 0, 0, 0, 0, 0));
    EXPECT_EQ(i2c_write_len, 0);

    ret = vdrv_sm2235egh_set_mode(RGB_MODE);
    EXPECT_EQ(ret, SDK_OK);
    EXPECT_EQ(i2c_addr_stub, BITS2BYTE(1, 1, 0, 0, 1, 0, 0, 0));
    EXPECT_EQ(i2c_write_len, 0);

    ret = vdrv_sm2235egh_set_mode(CW_MODE);
    EXPECT_EQ(ret, SDK_OK);
    EXPECT_EQ(i2c_addr_stub, BITS2BYTE(1, 1, 0, 1, 0, 0, 0, 0));
    EXPECT_EQ(i2c_write_len, 0);

    ret = vdrv_sm2235egh_set_mode(RGBCW_MODE);
    EXPECT_EQ(ret, SDK_OK);
    EXPECT_EQ(i2c_addr_stub, BITS2BYTE(1, 1, 0, 1, 1, 0, 0, 0));
    EXPECT_EQ(i2c_write_len, 0);
}

TEST_F(vdrv_sm2235egh_test, set_current_range)
{
    int ret;
    uint8_t rgb_cr, cw_cr;

    ret = vdrv_sm2235egh_set_mode(SHUTDOWN);
    EXPECT_EQ(ret, SDK_OK);
    rgb_cr = BITS2BYTE(0, 0, 0, 0, 1, 0, 1, 1);
    cw_cr = BITS2BYTE(0, 0, 0, 0, 1, 1, 0, 1);
    ret = vdrv_sm2235egh_set_cr(&rgb_cr, &cw_cr);
    EXPECT_EQ(ret, SDK_OK);
    EXPECT_EQ(i2c_addr_stub, BITS2BYTE(1, 1, 0, 0, 0, 0, 0, 0));
    EXPECT_EQ(i2c_write_len, 1);
    EXPECT_EQ(i2c_write_stub[0], (rgb_cr << 4) | cw_cr);

    ret = vdrv_sm2235egh_set_mode(RGB_MODE);
    EXPECT_EQ(ret, SDK_OK);
    rgb_cr = BITS2BYTE(0, 0, 0, 0, 0, 1, 0, 1);
    ret = vdrv_sm2235egh_set_cr(&rgb_cr, NULL);
    EXPECT_EQ(ret, SDK_OK);
    EXPECT_EQ(i2c_addr_stub, BITS2BYTE(1, 1, 0, 0, 1, 0, 0, 0));
    EXPECT_EQ(i2c_write_len, 1);
    EXPECT_EQ(i2c_write_stub[0], (rgb_cr << 4) | cw_cr);

    ret = vdrv_sm2235egh_set_mode(CW_MODE);
    EXPECT_EQ(ret, SDK_OK);
    cw_cr = BITS2BYTE(0, 0, 0, 0, 0, 1, 1, 0);
    ret = vdrv_sm2235egh_set_cr(&cw_cr, NULL);
    EXPECT_EQ(ret, SDK_OK);
    EXPECT_EQ(i2c_addr_stub, BITS2BYTE(1, 1, 0, 1, 0, 0, 0, 0));
    EXPECT_EQ(i2c_write_len, 1);
    EXPECT_EQ(i2c_write_stub[0], (rgb_cr << 4) | cw_cr);

    ret = vdrv_sm2235egh_set_mode(RGBCW_MODE);
    EXPECT_EQ(ret, SDK_OK);
    rgb_cr = BITS2BYTE(0, 0, 0, 0, 0, 0, 1, 1);
    cw_cr = BITS2BYTE(0, 0, 0, 0, 1, 1, 0, 0);
    ret = vdrv_sm2235egh_set_cr(&rgb_cr, &cw_cr);
    EXPECT_EQ(ret, SDK_OK);
    EXPECT_EQ(i2c_addr_stub, BITS2BYTE(1, 1, 0, 1, 1, 0, 0, 0));
    EXPECT_EQ(i2c_write_len, 1);
    EXPECT_EQ(i2c_write_stub[0], (rgb_cr << 4) | cw_cr);
}

TEST_F(vdrv_sm2235egh_test, set_gray_level)
{
    int ret;
    uint8_t rgb_cr, cw_cr;
    sm2235egh_gray_t rgb_gray, cw_gray;

    ret = vdrv_sm2235egh_set_mode(SHUTDOWN);
    EXPECT_EQ(ret, SDK_OK);
    rgb_cr = BITS2BYTE(0, 0, 0, 0, 0, 0, 1, 1);
    cw_cr = BITS2BYTE(0, 0, 0, 0, 1, 1, 0, 0);
    ret = vdrv_sm2235egh_set_cr(&rgb_cr, &cw_cr);
    EXPECT_EQ(ret, SDK_OK);

    rgb_gray.rgb.out_1r = BYTES2SHORT(BITS2BYTE(0, 0, 0, 0, 0, 0, 1, 1), BITS2BYTE(0, 0, 1, 0, 0, 0, 0, 1));
    rgb_gray.rgb.out_2g = BYTES2SHORT(BITS2BYTE(0, 0, 0, 0, 0, 0, 1, 1), BITS2BYTE(0, 0, 1, 0, 0, 0, 1, 1));
    rgb_gray.rgb.out_3b = BYTES2SHORT(BITS2BYTE(0, 0, 0, 0, 0, 0, 1, 1), BITS2BYTE(0, 0, 1, 0, 0, 1, 0, 1));
    cw_gray.cw.out_4c = BYTES2SHORT(BITS2BYTE(0, 0, 0, 0, 0, 0, 1, 1), BITS2BYTE(0, 0, 1, 0, 1, 0, 0, 1));
    cw_gray.cw.out_5w = BYTES2SHORT(BITS2BYTE(0, 0, 0, 0, 0, 0, 1, 1), BITS2BYTE(0, 0, 1, 1, 0, 0, 0, 1));
    LOG_RAW_HEX(LOG_INFO, "hex:", &rgb_gray.rgb.out_1r, 2);
    ret = vdrv_sm2235egh_set_output(&rgb_gray, &cw_gray);
    EXPECT_EQ(ret, SDK_OK);
    EXPECT_EQ(i2c_addr_stub, BITS2BYTE(1, 1, 0, 0, 0, 0, 0, 0));
    EXPECT_EQ(i2c_write_len, 11);
    LOG_RAW_HEX(LOG_INFO, "hex:", i2c_write_stub, i2c_write_len);
    EXPECT_EQ(i2c_write_stub[0], (rgb_cr << 4) | cw_cr);
    EXPECT_EQ(i2c_write_stub[1], BITS2BYTE(0, 0, 0, 0, 0, 0, 1, 1));
    EXPECT_EQ(i2c_write_stub[2], BITS2BYTE(0, 0, 1, 0, 0, 0, 0, 1));
    EXPECT_EQ(i2c_write_stub[3], BITS2BYTE(0, 0, 0, 0, 0, 0, 1, 1));
    EXPECT_EQ(i2c_write_stub[4], BITS2BYTE(0, 0, 1, 0, 0, 0, 1, 1));
    EXPECT_EQ(i2c_write_stub[5], BITS2BYTE(0, 0, 0, 0, 0, 0, 1, 1));
    EXPECT_EQ(i2c_write_stub[6], BITS2BYTE(0, 0, 1, 0, 0, 1, 0, 1));
    EXPECT_EQ(i2c_write_stub[7], BITS2BYTE(0, 0, 0, 0, 0, 0, 1, 1));
    EXPECT_EQ(i2c_write_stub[8], BITS2BYTE(0, 0, 1, 0, 1, 0, 0, 1));
    EXPECT_EQ(i2c_write_stub[9], BITS2BYTE(0, 0, 0, 0, 0, 0, 1, 1));
    EXPECT_EQ(i2c_write_stub[10], BITS2BYTE(0, 0, 1, 1, 0, 0, 0, 1));

    ret = vdrv_sm2235egh_set_mode(RGB_MODE);
    EXPECT_EQ(ret, SDK_OK);
    rgb_gray.rgb.out_1r = BYTES2SHORT(BITS2BYTE(0, 0, 0, 0, 0, 0, 1, 1), BITS2BYTE(0, 0, 1, 1, 0, 0, 0, 0));
    rgb_gray.rgb.out_2g = BYTES2SHORT(BITS2BYTE(0, 0, 0, 0, 0, 0, 1, 1), BITS2BYTE(0, 0, 1, 0, 1, 0, 0, 0));
    rgb_gray.rgb.out_3b = BYTES2SHORT(BITS2BYTE(0, 0, 0, 0, 0, 0, 1, 1), BITS2BYTE(0, 0, 1, 0, 0, 1, 0, 0));
    ret = vdrv_sm2235egh_set_output(&rgb_gray, NULL);
    EXPECT_EQ(ret, SDK_OK);
    EXPECT_EQ(i2c_addr_stub, BITS2BYTE(1, 1, 0, 0, 1, 0, 0, 0));
    EXPECT_EQ(i2c_write_len, 7);
    EXPECT_EQ(i2c_write_stub[0], (rgb_cr << 4) | cw_cr);
    EXPECT_EQ(i2c_write_stub[1], BITS2BYTE(0, 0, 0, 0, 0, 0, 1, 1));
    EXPECT_EQ(i2c_write_stub[2], BITS2BYTE(0, 0, 1, 1, 0, 0, 0, 0));
    EXPECT_EQ(i2c_write_stub[3], BITS2BYTE(0, 0, 0, 0, 0, 0, 1, 1));
    EXPECT_EQ(i2c_write_stub[4], BITS2BYTE(0, 0, 1, 0, 1, 0, 0, 0));
    EXPECT_EQ(i2c_write_stub[5], BITS2BYTE(0, 0, 0, 0, 0, 0, 1, 1));
    EXPECT_EQ(i2c_write_stub[6], BITS2BYTE(0, 0, 1, 0, 0, 1, 0, 0));

    ret = vdrv_sm2235egh_set_mode(CW_MODE);
    EXPECT_EQ(ret, SDK_OK);
    cw_gray.cw.out_4c = BYTES2SHORT(BITS2BYTE(0, 0, 0, 0, 0, 0, 1, 1), BITS2BYTE(1, 0, 0, 0, 1, 0, 0, 1));
    cw_gray.cw.out_5w = BYTES2SHORT(BITS2BYTE(0, 0, 0, 0, 0, 0, 1, 1), BITS2BYTE(1, 0, 0, 0, 0, 0, 1, 1));
    ret = vdrv_sm2235egh_set_output(&cw_gray, NULL);
    EXPECT_EQ(ret, SDK_OK);
    EXPECT_EQ(i2c_addr_stub, BITS2BYTE(1, 1, 0, 1, 0, 0, 1, 1));
    EXPECT_EQ(i2c_write_len, 5);
    EXPECT_EQ(i2c_write_stub[1], BITS2BYTE(0, 0, 0, 0, 0, 0, 1, 1));
    EXPECT_EQ(i2c_write_stub[2], BITS2BYTE(1, 0, 0, 0, 1, 0, 0, 1));
    EXPECT_EQ(i2c_write_stub[3], BITS2BYTE(0, 0, 0, 0, 0, 0, 1, 1));
    EXPECT_EQ(i2c_write_stub[4], BITS2BYTE(1, 0, 0, 0, 0, 0, 1, 1));

    ret = vdrv_sm2235egh_set_mode(RGBCW_MODE);
    EXPECT_EQ(ret, SDK_OK);
    rgb_gray.rgb.out_1r = BYTES2SHORT(BITS2BYTE(0, 0, 0, 0, 0, 0, 1, 1), BITS2BYTE(0, 1, 1, 0, 0, 0, 0, 1));
    rgb_gray.rgb.out_2g = BYTES2SHORT(BITS2BYTE(0, 0, 0, 0, 0, 0, 1, 1), BITS2BYTE(0, 1, 1, 0, 0, 0, 1, 1));
    rgb_gray.rgb.out_3b = BYTES2SHORT(BITS2BYTE(0, 0, 0, 0, 0, 0, 1, 1), BITS2BYTE(0, 1, 1, 0, 0, 1, 0, 1));
    cw_gray.cw.out_4c = BYTES2SHORT(BITS2BYTE(0, 0, 0, 0, 0, 0, 1, 1), BITS2BYTE(0, 1, 1, 0, 1, 0, 0, 1));
    cw_gray.cw.out_5w = BYTES2SHORT(BITS2BYTE(0, 0, 0, 0, 0, 0, 1, 1), BITS2BYTE(0, 1, 1, 1, 0, 0, 0, 1));
    ret = vdrv_sm2235egh_set_output(&rgb_gray, &cw_gray);
    EXPECT_EQ(ret, SDK_OK);
    EXPECT_EQ(i2c_addr_stub, BITS2BYTE(1, 1, 0, 1, 1, 0, 0, 0));
    EXPECT_EQ(i2c_write_len, 11);
    EXPECT_EQ(i2c_write_stub[0], (rgb_cr << 4) | cw_cr);
    EXPECT_EQ(i2c_write_stub[1], BITS2BYTE(0, 0, 0, 0, 0, 0, 1, 1));
    EXPECT_EQ(i2c_write_stub[2], BITS2BYTE(0, 1, 1, 0, 0, 0, 0, 1));
    EXPECT_EQ(i2c_write_stub[3], BITS2BYTE(0, 0, 0, 0, 0, 0, 1, 1));
    EXPECT_EQ(i2c_write_stub[4], BITS2BYTE(0, 1, 1, 0, 0, 0, 1, 1));
    EXPECT_EQ(i2c_write_stub[5], BITS2BYTE(0, 0, 0, 0, 0, 0, 1, 1));
    EXPECT_EQ(i2c_write_stub[6], BITS2BYTE(0, 1, 1, 0, 0, 1, 0, 1));
    EXPECT_EQ(i2c_write_stub[7], BITS2BYTE(0, 0, 0, 0, 0, 0, 1, 1));
    EXPECT_EQ(i2c_write_stub[8], BITS2BYTE(0, 1, 1, 0, 1, 0, 0, 1));
    EXPECT_EQ(i2c_write_stub[9], BITS2BYTE(0, 0, 0, 0, 0, 0, 1, 1));
    EXPECT_EQ(i2c_write_stub[10], BITS2BYTE(0, 1, 1, 1, 0, 0, 0, 1));
}