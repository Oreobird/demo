/**
 *  Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
 * @file        vhal_utils.c
 * @brief       厂家Realtek SDK提供的通用接口封装
 * @author      Dongri.Su
 * @date        2021-04-22
 */

#include "wifi_constants.h"
#include "wifi_structures.h"
#include "wifi_conf.h"
#include "lwip_netconf.h"
#include "ethernetif.h"

#include "vhal_utils.h"


/**
 * @brief 重启系统
 * @param[in]  arg                  [定时器参数，未使用]
 * @return     void
 */
void vhal_utils_restart(void *arg)
{
    HAL_LOG(LOG_INFO, "Prepare to restart system!\n");
    ota_platform_reset();
}

/**
 * @brief 通过硬件RNG获取随机数
 * @param[in]  p_buf                [用于存储随机数的缓存空间]
 * @param[in]  buf_len              [缓存空间大小]
 * @return     void
 */
void vhal_utils_get_random(uint8_t *p_buf, int32_t buf_len)
{
    rtw_get_random_bytes(p_buf, buf_len);
}

/**
 * @brief 修改dhcp的hostname
 * @param[in]  p_hostname            [新的hostname]
 * @return     void
 */
void vhal_utils_chg_dhcp_hostname(const char *p_hostname)
{
    if (NULL == p_hostname)
    {
        return;
    }

    int ret = etek_change_dhcp_hostname(p_hostname);
    HAL_LOG(LOG_DEBUG, "ret = %d, Hostname is %s\n", ret, p_hostname);
}

/**
 * @brief  获取Wi-Fi模组芯片名称
 * @return     char *               [字符串格式芯片名称]
 */
char *vhal_utils_get_chip_name(void)
{
#if defined(CONFIG_TARGET_RTL8710CX)
    return "RTL8710CX";
#elif defined(CONFIG_TARGET_RTL8720CF)
    return "RTL8720CF";
#else
    return "Unkown";
#endif
}


/*
 * @brief  MAC地址增加1
 * @param[in/out] char*         [字符串形式的MAC]
 * @param[in]  int              [MAC地址字符串长度]
 * @param[in]  uint8_t          [MAC地址分隔符]
 * @return void
 */
static bool vhal_rtl_mac_increase(uint8_t *p_mac, int num, uint8_t sep)
{
    if (NULL == p_mac)
    {
        HAL_LOG(LOG_ERROR, "Input param is a null pointer!\n");
        return VHAL_FAIL;
    }

    while (num>=0)
    {
        if('9' == p_mac[num])
        {
            p_mac[num]='a';     // 全部采用小写格式
            break;
        }
        else if('F' == p_mac[num] || 'f' == p_mac[num])
        {
            p_mac[num]='0';
            num--;
        }
        else if(sep == p_mac[num])
        {
            num--;
        }
        else
        {
            p_mac[num]++;
            break;
        }
    }

    if(-1 == num)
         return FALSE;
    else
        return TRUE;
}

/*
 * @brief 获取设备的MAC地址
 * @param[in]  type                 [详见DEVICE_TYPE_MAC_E定义]
 * @param[out] p_buf                [获取到的MAC地址]
 * @param[in]  buf_len              [dev_mac的最小空间长度]
 * @return     int                  [执行成功，返回OK；执行失败，返回FAIL]
 */
int vhal_utils_get_dev_mac(VHAL_MAC_TYPE_E type, char *p_buf, int32_t buf_len)
{
    int ret = RTW_ERROR;
    uint8_t mac_addr_str[MAC_ADDR_STR_MAX_LEN] = {0, };

    if (NULL == p_buf)
    {
        HAL_LOG(LOG_ERROR, "Null Ptr!\n");
        return VHAL_FAIL;
    }
    if (buf_len < MAC_ADDR_STR_MAX_LEN)
    {
        HAL_LOG(LOG_ERROR, "Buf len(=%d) is too small!\n", buf_len);
        return VHAL_FAIL;
    }

    if (VHAL_MAC_WIFI_STA == type || VHAL_MAC_WIFI_SOFTAP == type)
    {
        if (!wifi_is_up(RTW_STA_INTERFACE))
        {
            HAL_LOG(LOG_INFO ,"Wi-Fi STA is down, start now!\n");
            wifi_on(RTW_MODE_STA);
            vTaskDelay(20/portTICK_RATE_MS);
        }
        ret = wifi_get_mac_address((char *)mac_addr_str);       // 有分隔符
    }
    /*else if (VHAL_MAC_WIFI_SOFTAP == type)     // AP 接口未启动，读取值为空
    {
        // 声明位置\sdk\rtl-amebaz2_v7.1c\component\common\api\lwip_netconf.c
        extern struct netif xnetif[NET_IF_NUM];
        struct netif *p_netif = &xnetif[1];     // ap interface
        snprintf((char *)mac_addr_str, sizeof(mac_addr_str), "%s", LwIP_GetMAC(p_netif));   // 无分隔符
        if (strlen((char *)mac_addr_str) > 0)
            ret = RTW_SUCCESS;
    }*/
    else if (VHAL_MAC_ROUTER == type)
    {
        ret = wifi_get_ap_bssid(mac_addr_str);      // 无分隔符
    }
    else
    {
        HAL_LOG(LOG_ERROR, "Unknow device type = %d!\n", type);
        return VHAL_FAIL;
    }

    //HAL_LOG(LOG_DEBUG, "mac_addr_str %s.\n", mac_addr_str);
    if (RTW_SUCCESS == ret)
    {
        if (VHAL_MAC_ROUTER == type /*|| VHAL_MAC_WIFI_SOFTAP == type*/)
        {
            snprintf(p_buf, buf_len, MACSTR, MAC2STR(mac_addr_str));
        }
        else if (VHAL_MAC_WIFI_SOFTAP == type)
        {
            if (vhal_rtl_mac_increase(mac_addr_str, strlen((char *)mac_addr_str) - 1, ':'))
            {
                snprintf(p_buf, buf_len, "%s", mac_addr_str);
            }
        }
        else
        {
            snprintf(p_buf, buf_len, "%s", mac_addr_str);
        }
    }
    else
    {
        HAL_LOG(LOG_ERROR, "Get mac fail, errCode = %d!\n", ret);
        return VHAL_FAIL;
    }

    return VHAL_OK;
}

/*
 * @brief 设备作为STA时，获取分配到的IP。
 * @param[in]  char *               [保存IP的缓存]
 * @param[in]  int                  [缓存大小]
 * @return     char*                [IP地址]
 */
char* vhal_utils_get_sta_ip(char *p_buf, int32_t buf_len)
{
    if (NULL == p_buf)
    {
        return NULL;
    }

    // 声明位置\sdk\rtl-amebaz2_v7.1c\component\common\api\lwip_netconf.c
    extern struct netif xnetif[NET_IF_NUM];
    struct netif *p_netif = &xnetif[0];     // sta interface
    uint8_t *p_ip = LwIP_GetIP(p_netif);
    if (NULL != p_ip)
    {
        snprintf(p_buf, buf_len, "%d.%d.%d.%d", p_ip[0], p_ip[1], p_ip[2], p_ip[3]);
        //HAL_LOG(LOG_DEBUG, "Device IP addr is %s\n", p_buf);
        // 169.254.0.0-169.254.255.255,127.0.0.1,0.0.0.0这三类ip地址为非法地址
        if (/*INADDR_NONE == inet_addr(p_buf) ||*/
            (0 == p_ip[0] && 0 == p_ip[1] && 0 == p_ip[2] && 0 == p_ip[3]) ||
            (169 == p_ip[0] && 254 == p_ip[1]) ||
            (127 == p_ip[0] && 0 == p_ip[1] && 0 == p_ip[2] && 1 == p_ip[3]))
        {
            //HAL_LOG(LOG_ERROR, "Error IP addr is %s\n", p_buf);
            return NULL;
        }
        return p_buf;
    }

    return NULL;
}

