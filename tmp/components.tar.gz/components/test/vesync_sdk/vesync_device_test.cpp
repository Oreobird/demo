/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_device_test.cpp
 * @brief       vesync device测试用例
 * @author      Joshua
 * @date        2021-11-19
 */

#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <gtest/gtest.h>


#include "vesync_os.h"
#include "vesync_common.h"
#include "vesync_memory.h"
#include "vesync_device_internal.h"

#include "stub.h" // cpp-stub
#include "vesync_device.c" // cpp-stub needs the source file


static int vesync_production_cfg_init_mock(void)
{
    return 0;
}

static void vesync_device_subscribe_event_mock(void)
{
    return;
}


TEST(vesync_device_test, vesync_device_get_plugin_name_by_type_test)
{
    int ret = SDK_FAIL;
    char *plugin_name = NULL;

    Stub stub;
    stub.set(vesync_production_cfg_init, vesync_production_cfg_init_mock);
    stub.set(vesync_device_subscribe_event, vesync_device_subscribe_event_mock);

    ret = vesync_device_init();
    EXPECT_EQ(ret, SDK_OK);

    if (vesync_cfg_get_ota_type_wifi())
    {
        plugin_name = vesync_device_get_plugin_name_by_type(UPG_TP_WIFI);
        EXPECT_STREQ(VESYNC_WIFI_DEFAULT_PLUGIN_NAME, plugin_name);
    }
    else
    {
        plugin_name = vesync_device_get_plugin_name_by_type(UPG_TP_WIFI);
        EXPECT_STREQ(VESYNC_INVALID_PLUGIN_NAME, plugin_name);
    }

    if (vesync_cfg_get_ota_type_ble())
    {
        plugin_name = vesync_device_get_plugin_name_by_type(UPG_TP_BLE);
        EXPECT_STREQ(VESYNC_BLE_DEFAULT_PLUGIN_NAME, plugin_name);
    }
    else
    {
        plugin_name = vesync_device_get_plugin_name_by_type(UPG_TP_BLE);
        EXPECT_STREQ(VESYNC_INVALID_PLUGIN_NAME, plugin_name);
    }

    if (vesync_cfg_get_ota_type_mcu() >= 1)
    {
        plugin_name = vesync_device_get_plugin_name_by_type(UPG_TP_MCU);
        EXPECT_STREQ(VESYNC_MCU_DEFAULT_PLUGIN_NAME, plugin_name);
    }
    else
    {
        plugin_name = vesync_device_get_plugin_name_by_type(UPG_TP_MCU);
        EXPECT_STREQ(VESYNC_INVALID_PLUGIN_NAME, plugin_name);
    }

    if (vesync_cfg_get_ota_type_mcu() >= 2)
    {
        plugin_name = vesync_device_get_plugin_name_by_type(UPG_TP_MCU2);
        EXPECT_STREQ(VESYNC_MCU2_DEFAULT_PLUGIN_NAME, plugin_name);
    }
    else
    {
        plugin_name = vesync_device_get_plugin_name_by_type(UPG_TP_MCU2);
        EXPECT_STREQ(VESYNC_INVALID_PLUGIN_NAME, plugin_name);
    }

    if (vesync_cfg_get_ota_type_mcu() >= 3)
    {
        plugin_name = vesync_device_get_plugin_name_by_type(UPG_TP_MCU3);
        EXPECT_STREQ(VESYNC_MCU3_DEFAULT_PLUGIN_NAME, plugin_name);
    }
    else
    {
        plugin_name = vesync_device_get_plugin_name_by_type(UPG_TP_MCU3);
        EXPECT_STREQ(VESYNC_INVALID_PLUGIN_NAME, plugin_name);
    }

    vesync_device_deinit();
}

