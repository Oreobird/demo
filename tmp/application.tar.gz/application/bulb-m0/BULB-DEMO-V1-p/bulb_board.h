/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
* @file        bulb_board.h
* @brief       bulb BULB-DEMO板级硬件配置
* @author      Herve
* @date        2021-10-09
*/
#ifndef __BULB_BOARD_H__
#define __BULB_BOARD_H__

// 基于ESP8685-WROOM-04的灯球公版，LED驱动信息由产家给定

// Digital Control Mode
// MCU与第三方驱动芯片通信的控制方式
#define BULB_I2C_SDA_IO (4)   // i2c数据引脚
#define BULB_I2C_SCL_IO (1)   // i2c时钟引脚
#define BULB_RED_MAX (0x03)   // 红灯输出量程，16mA最大电流；SM2235EGH按照这一路设置RGB灯路量程
#define BULB_GREEN_MAX (0x03) // 绿灯输出量程，16mA最大电流
#define BULB_BULE_MAX (0x03)  // 蓝灯输出量程，16mA最大电流
#define BULB_COLD_MAX (0x0A)  // 冷白灯输出量程，55mA最大电流；SM2235EGH按照这一路设置CW灯路量程
#define BULB_WARM_MAX (0x0A)  // 暖白灯输出量程，55mA最大电流

// MCU PWM Control Mode
// MCU输出PWM信号控制方式
#define BULB_LEDC_PWM_FREQ (600)     // LEDC PWM控制频率
#define BULB_LEDC_DUTY_RST_BIT (10)  // LEDC 占空比分辨率设置（10位对应1024）

// 通用配置
#define BULB_GRADIENT_STEP (10)           // 渐变的步数
#define BULB_GRADIENT_TIME (100)          // 渐变的时间
#define BULB_DRIVER_TYPE (1)              // 驱动类型设定。0：BP5758；1：输出PWM驱动；3：SM2235EGH
#define BULB_RGB_MIN_PERCENT (5)          // 彩光模式的实际最小明度百分数，这个数值是为了防止灯泡在超低电流下出现偏色做的限制
#define BULB_W_MIN_PERCENT (3)            // 白光模式的实际最小亮度百分数，这个数值是为了防止设置最低亮度出现近似关断的情况
#define BULB_W_MAX_PERCENT (100)          // 白光模式的实际最大亮度百分数，用于微调设备功率
#define BULB_PWM_MAX_SCALE (1024)         // LED驱动控制，PWM数字输出最大量程，十位分辨率
#define BULB_RED_OUT_IO (3)               // 红灯输出的IO号（对于BP5758，是芯片IO。对于PWM输出，是SOC的IO）
#define BULB_GREEN_OUT_IO (2)             // 绿灯输出的IO号（对于BP5758，是芯片IO。对于PWM输出，是SOC的IO）
#define BULB_BULE_OUT_IO (1)              // 蓝灯输出的IO号（对于BP5758，是芯片IO。对于PWM输出，是SOC的IO）
#define BULB_COLD_OUT_IO (5)              // 冷白灯(CCT下是亮度PWM)输出的IO号（对于BP5758，是芯片IO。对于PWM输出，是SOC的IO）
#define BULB_WARM_OUT_IO (4)              // 暖白灯(CCT下是色温PWM)输出的IO号（对于BP5758，是芯片IO。对于PWM输出，是SOC的IO）
#define BULB_NETCFG_SW_TRG_MIN_TIMES (3)  // 触发进入配网模式的最小开关次数
#define BULB_NETCFG_SW_TRG_MAX_TIMES (4)  // 触发进入配网模式的最大开关次数
#define BULB_PRD_SW_TRG_MAX_TIMES (10)    // 触发进入产测模式的开关次数
#define BULB_RST_SW_TRG_MAX_TIMES (6)     // 触发恢复出产设置的最小开关次数，注意需要考虑和以上触发配置的兼容性问题
#define BULB_APP_DATA_VERSION (1)         // APP数据的配置版本
#define BULB_SCHE_MIN_ID (100)            // Schedule ID生成的最小限制
#define BULB_SCHE_MAX_NUM (26)            // Schedule每个实例的最大数量限制
#define BULB_SCHE_GET_MAX_NUM (6)         // Schedule每个实例读取Schedule时，最大一次读取数量
#define BULB_SCHE_MAX_APP_CFG_SIZE (32)   // APP配置传入Schedule实例的时候，对APP大小校验的最大限制
#define BULB_PRODUCTION_PRE_TEST_MIN (30) // 老化测试时间（分钟）
#define BULB_LED_TASK_STACSIZE (1024*2)   // LED控制任务栈大小
#define BULB_WHITE_IS_CW (1)              // 白光光路的驱动类型。0：CCT，1：CW
#define BULB_CCT_TEMP_INVERT (0)          // CCT色温控制反转。0：不反转，1：反转
#define BULB_INDICATOR_MODE (0)           // 灯泡指示灯效模式。0：RGBCW/RGBCCT，1：RGBC，2：RGB，3：CW/CCT，4：C


#endif /* __BULB_BOARD_H__ */
