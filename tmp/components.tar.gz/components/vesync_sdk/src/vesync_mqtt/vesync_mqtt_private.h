/*
 * Copyright © Vesync Technologies Co.Ltd. 2019-2021. All rights reserved.
 *
 * This file is subject to the terms and conditions defined in
 * file 'LICENSE', which is part of this source code package.
 * Tuan PM <tuanpm at live dot com>
 */

#ifndef __VESYNC_MQTT_PRIVATE_H__
#define __VESYNC_MQTT_PRIVATE_H__

#include "vesync_queue.h"
#include "vesync_mutex.h"
#include "vesync_common.h"
#include "vesync_log_internal.h"
#include "vesync_mqtt_internal.h"
#include "mqtt_log.h"

#define VESYNC_PRINTF_FREE_HEAP()       \
    do                                  \
    {                                       \
        SDK_LOG(LOG_DEBUG, "free_heap_size = %d\n", vhal_utils_get_free_heap_size());    \
    }while(0)

#define VERR_UPLOAD(x, y)

/* The above is the redirection of the interface called by this module */


typedef struct mqtt_state
{
    mqtt_connect_info_t *connect_info;
    uint8_t *in_buffer;
    uint8_t *out_buffer;
    int in_buffer_length;
    int out_buffer_length;
    uint32_t in_buffer_offset;
    mqtt_message_t *outbound_message;
    mqtt_connection_t mqtt_connection;
    uint16_t pending_msg_id;
    int pending_msg_type;
    int pending_publish_qos;
    int pending_msg_count;
} mqtt_state_t;


typedef enum {
    MQTT_STATE_DISCONNECTED = 0,
    MQTT_STATE_CONNECTED,
} MQTT_CLIENT_STATE_E;

typedef struct {
    vesync_transport_handle_t transport;
    mqtt_state_t  mqtt_state;
    mqtt_connect_info_t connect_info;
    mqtt_event_callback_t event_handle;
    char *host;
    char *ip;
    uint32_t port;
    MQTT_TLS_CA_E tls;
    MQTT_CLIENT_STATE_E state;
    int keepalive;
    uint64_t keepalive_tick;
    uint64_t reconnect_tick;
    int wait_reconnect_ms;
    int auto_reconnect;
    int network_timeout_ms;
    vesync_mqtt_event_t event;
    bool wait_for_ping_resp;
    uint8_t ping_missed_cnt;
    outbox_handle_t outbox;
    vesync_queue_t *queue;
    vesync_mutex_t lock;
    uint64_t last_retransmit;
}vesync_mqtt_client_t;


typedef enum {
    MQTT_EV_CONFIG = 0,
    MQTT_EV_CONNECT,
    MQTT_EV_DISCONNECT,
    MQTT_EV_PUBLISH,
    MQTT_EV_SUBSCRIBE,
} MQTT_EV_ID_E;

typedef struct {
    MQTT_EV_ID_E id;
    void *data;
}vesync_mqtt_ev_t;

typedef struct {
    int len;
    int qos;
    int retain;
    void (*ack_cb)(void);
    char *topic;
    char data[0];
}mqtt_publish_data_t;

/**
 * MQTT client configuration structure
 */
typedef struct {
    char *host;                             /*!< MQTT server domain (ipv4 as string) */
    uint32_t port;                          /*!< MQTT server port */
    char *ip;                               /*!< MQTT server ip (ipv4 as string) */
    char *username;                         /*!< MQTT username */
    char *password;                         /*!< MQTT password */
    MQTT_TLS_CA_E tls;
} mqtt_connect_data_t;


/**
 * MQTT client configuration structure
 */
typedef struct {
    mqtt_event_callback_t event_handle;     /*!< handle for MQTT events */
    char *client_id;
} mqtt_config_data_t;


#else
#error This private file can only be included by owner
#endif /* __VESYNC_MQTT_PRIVATE_H__ */

