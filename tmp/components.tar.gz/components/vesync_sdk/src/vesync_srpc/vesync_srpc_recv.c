/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_srpc.c
 * @brief       vesync SRPC模块的接收实现
 * @author      Herve
 * @date        2021-12-28
 */
#include <stdio.h>

#include "vesync_srpc_private.h"
#include "vesync_log_internal.h"
#include "vesync_json_internal.h"

#include "vhal_utils.h"

#include "vesync_memory.h"
#include "vesync_base64.h"
#include "vesync_common.h"
#include "vesync_utils.h"
#include "vesync_device.h"

#include "vesync_tl_payload_parse.h"

// SRPC接收请求流程中，对生成的Bypass JSON进行处理的回调
static srpc_request_recv_cb_t s_rpc_request_json_proc_cb = NULL;

bool srpc_tl_data_recv_cb(uint8_t *p_data, uint16_t len, bool need_ack)
{
    uint16_t opcode = 0;
    uint8_t status_code = 0;

    uint16_t pl_len = 0;
    uint8_t *p_pl = vesync_tl_payload_decode(p_data, len, &opcode, &status_code, &pl_len);
    if (opcode != SRPC_OPCODE_REQUEST)
    {
        return false;
    }

    if (NULL == p_pl)
    {
        return true;
    }
    // 创建Mock进Bypass的JSON消息
    cJSON *p_bp_msg = cJSON_CreateObject();
    if (NULL == p_bp_msg)
    {
        return true;
    }
    // 实际来自Host的Bypass Payload
    cJSON *p_bp_pl = NULL;

#if 0
    LOG_RAW_HEX(LOG_ERROR, "protobuf:", p_data, len);
    uint8_t *base64 = vesync_malloc(1024);
    if (base64 != NULL)
    {
        size_t out_len;
        vesync_base64_encode(base64, 1024, &out_len, p_data, len);
        SDK_LOG(LOG_DEBUG, "protobuf_base64:%s\n", base64);
        vesync_free(base64);
    }
#endif

    char p_tid_str[BP_TRACE_ID_MAX_LEN];
    p_bp_pl = srpc_request_unmarshal(p_pl, pl_len);
    if (NULL == p_bp_pl)
    {
        SDK_LOG(LOG_ERROR, "srpc unmarshal fail\n");
        srpc_tl_send_error_ack(SRPC_OPCODE_REQUEST, TL_FRAME_INTERNAL_ERR);
        goto EXIT;
    }
    cJSON_AddStringToObject(p_bp_msg, "method", "bypassV2");
    // 把Payload JSON的引用接入Message JSON
    cJSON_AddItemToObject(p_bp_msg, "payload", p_bp_pl);
    // 添加SRPC Source字段
    cJSON_AddStringToObject(p_bp_pl, "source", STAT_CHG_RSN_BP_SRPC_STR);
    // 为SRPC Request创建Trace ID
    vhal_utils_get_system_time_ms_str(p_tid_str, BP_TRACE_ID_MAX_LEN);
    cJSON_AddStringToObject(p_bp_msg, "traceId", p_tid_str);

#if 0
    SDK_LOG(LOG_DEBUG, "generate adapted bypass message\n");
    vesync_json_print(p_bp_msg);
#endif

    // JSON对象交给Bypass去处理
    if (NULL == s_rpc_request_json_proc_cb)
    {
        goto EXIT;
    }
    // Message JSON应该在Bypass的处理中被销毁
    s_rpc_request_json_proc_cb(p_bp_msg);
    return true;
EXIT:
    cJSON_Delete(p_bp_msg);
    return true;
}

void srpc_reg_request_recv_cb(srpc_request_recv_cb_t cb)
{
    s_rpc_request_json_proc_cb = cb;
}