/**
*Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file    led_strip_wifi_led.c
* @brief   Wi-Fi指示灯配置
* @author  henrik
*@date     2021-10-25
*/

#include <string.h>

#include "vhal_led.h"

#include "vesync_common.h"
#include "vesync_wifi_led.h"
#include "vesync_log.h"
#include "vesync_netcfg.h"

#include "led_strip_wifi_led.h"
#include "led_strip_scene.h"
#include "vhal_led.h"
#include "led_strip_board.h"
#include "led_strip.h"
#include "led_strip_led_drv.h"


static bool s_ls_netcfg_flag = true;   // 配网标志位

/**
* @brief wifi led控制回调
* @param[in]  status    [led状态]
*/
static void led_strip_wifi_led_ctrl_cb(WIFI_LED_IO_STATUS_E status)
{
    ls_ev_t ev;
    ev.event = LS_EV_NETCFG;
    ev.act_src = LS_ACT_SRC_WIFI_LED;
    ev.scene_type = SCENE_TYPE_CFNET;

    switch (status)
    {
        case WIFI_LED_IO_LED_OFF:
            break;
        case WIFI_LED_IO_LED_ON:
            break;
        case WIFI_LED_IO_CUSTOM_MODE:
            if (s_ls_netcfg_flag)
            {
                ev.scene_id = CFG_SCENE_START;
                led_strip_app_task_notify(&ev);
            }
            break;
        case WIFI_LED_IO_BREATHING:
            ev.scene_id = CFG_SCENE_RUNNING;
            led_strip_app_task_notify(&ev);
            break;
        case WIFI_LED_IO_DISABLE:
        default:
            break;
    }
}

/**
* @brief wifi 连接成功回调
*/
static void led_strip_wifi_success_cb(void)
{
    ls_ev_t ev;

    if (s_ls_netcfg_flag)
    {
        ev.act_src = LS_ACT_SRC_WIFI_LED;
        ev.event = LS_EV_NETCFG;
        ev.scene_type = SCENE_TYPE_CFNET;
        ev.scene_id = CFG_SCENE_SUCCESS;
        led_strip_app_task_notify(&ev);
    }
    s_ls_netcfg_flag = false;
}

/**
* @brief    设置配网标志位
* @param[in]  flag          [true:未配网/等待配网；false:配网结束/已配网]
*/
void led_strip_wifi_set_netcfg_flag(bool flag)
{
    s_ls_netcfg_flag = flag;
}

/**
* @brief  灯效配置
* @return     int             [成功/失败]
*/
int led_strip_reg_wifi_led(void)
{
    wifi_led_info_t led_cfg;

    memset(&led_cfg, 0, sizeof(led_cfg));

    // 未配网，灯效配置
    led_cfg.led_not_config.status = WIFI_LED_CUSTOM_MODE;
    led_cfg.led_not_config.blink_ms = 500; // 500ms
    led_cfg.led_not_config.off_times = 1;
    led_cfg.led_not_config.blink_times = 5;

    led_cfg.led_config_net.status = WIFI_LED_BREATHING;
    led_cfg.led_config_net.blink_ms = 5; // 5s
    led_cfg.led_config_net.off_times = 1;
    led_cfg.led_config_net.blink_times = 1;

    // 注册所有情况的灯效规则
    vesync_wifi_led_info_set(led_cfg);

    // 注册闪灯实现函数
    vesync_wifi_led_reg_ctrl_cb(led_strip_wifi_led_ctrl_cb, NULL);

    // 注册配网成功实现函数
    vesync_net_cfg_reg_success_cb(led_strip_wifi_success_cb);

    return APP_OK;
}



