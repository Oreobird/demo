/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_uart_recv.c
 * @brief       UART通信模块接收接口
 * @author      Louis
 * @date        2021-08-17
 */

#include <string.h>

#include "vhal_uart.h"
#include "vesync_common.h"
#include "vesync_memory.h"
#include "vesync_log_internal.h"
#include "vesync_tl_frame_parse.h"
#include "vesync_uart_private.h"


static vesync_uart_recv_t s_uart_recv[VESYNC_UART_NUM] = {0};


/**
 * @brief  处理vhal层收到的UART数据，校验完整后缓存到接收队列
 * @param[in]  p_data           [数据指针]
 * @param[in]  len              [数据长度]
 * @param[in]  idx              [UART编号]
 * @return     int32_t          [SDK_OK/SDK_FAIL]
 */
static void vesync_uart_recv_data(uint8_t idx, uint8_t *p_data, uint16_t len)
{
    tl_frame_recv_info_t *frame_header = s_uart_recv[idx].frame_header;
    vesync_msg_recv_t recv_data = {0};

    if (idx >= VESYNC_UART_NUM || NULL == p_data || 0 == len || len > VESYNC_FRAME_PAYLOAD_MAX_LEN)
    {
        return;
    }

    for (int i = 0; i < len; i++)
    {
        // 逐个字节解析
        if (vesync_tl_frame_decode(p_data[i], VESYNC_FRAME_PAYLOAD_MAX_LEN, frame_header))
        {
            continue;
        }

        // 校验checksum
        if (vesync_tl_frame_checksum_verify(frame_header))
        {
            continue;
        }

        // 申请缓存空间
        recv_data.data_len = sizeof(tl_frame_recv_info_t) + frame_header->payload_len;
        recv_data.p_data = vesync_malloc(recv_data.data_len);

        if (NULL == recv_data.p_data)
        {
            continue;
        }

        // 把接收到的整包数据放入缓存空间
        memcpy(recv_data.p_data, frame_header, recv_data.data_len);

        // 入队列缓存，然后释放信号量通知收发任务开始处理
        if (VOS_OK != vesync_queue_send(s_uart_recv[idx].recv_queue, &recv_data, VESYNC_OS_NO_WAIT))
        {
            VCOM_SAFE_FREE(recv_data.p_data);
            continue;
        }
        vesync_uart_sem_signal();
    }

    return;
}

/**
 * @brief  UART串口接收数据，执行应用层回调
 * @param[in]  idx                   [串口编号]
 * @param[in]  p_payload             [接收到的数据payload]
 * @param[in]  payload_len           [接收到的数据长度]
 */
static void vesync_uart_trans_recv_data(uint8_t idx, tl_payload_info_t *p_payload, uint16_t payload_len)
{
    if(idx >= VESYNC_UART_NUM || NULL == p_payload)
    {
        return;
    }

    // 优先执行同属平台层的ota的回调
    if(NULL != s_uart_recv[idx].ota_recv_cb)
    {
        // 执行ota回调返回OK，则说明该消息属于ota消息，已经处理，返回即可
        if (SDK_OK == s_uart_recv[idx].ota_recv_cb(idx, p_payload, payload_len))
        {
            return;
        }
    }

    // 执行ota回调返回FAIL，说明非ota消息，继续调用应用层的回调进行处理
    if(NULL != s_uart_recv[idx].frame_recv_cb)
    {
        s_uart_recv[idx].frame_recv_cb(idx, p_payload, payload_len);
    }
}

/**
 * @brief  UART模块接收初始化
 * @return     int32_t          [SDK_OK/SDK_FAIL]
 */
int32_t vesync_uart_recv_init(void)
{
    for (int i = 0; i < VESYNC_UART_NUM; i++)
    {
        // 申请接收消息的buffer，大小=协议头部+payload最大长度，其中payload最大长度支持产品自定义。
        s_uart_recv[i].frame_header = vesync_malloc(sizeof(tl_frame_recv_info_t) + VESYNC_FRAME_PAYLOAD_MAX_LEN);
        if (NULL == s_uart_recv[i].frame_header)
        {
            SDK_LOG(LOG_ERROR, "malloc fail\n");
            return SDK_FAIL;
        }
        memset(s_uart_recv[i].frame_header, 0, sizeof(tl_frame_recv_info_t) + VESYNC_FRAME_PAYLOAD_MAX_LEN);

        // 申请用于缓存接收消息的队列
        s_uart_recv[i].recv_queue = vesync_queue_new(VESYNC_UART_RECV_QUEUE_MAX_NUM * sizeof(vesync_msg_recv_t), sizeof(vesync_msg_recv_t));
        if (NULL == s_uart_recv[i].recv_queue)
        {
            SDK_LOG(LOG_ERROR, "queue create fail\n");
            return SDK_FAIL;
        }

        // 往vhal层注册接收回调函数
        vhal_uart_reg_recv_cb(i, vesync_uart_recv_data);
    }

    return SDK_OK;
}

/**
 * @brief  UART模块接收退出
 */
void vesync_uart_recv_deinit(void)
{
    for (int i = 0; i < VESYNC_UART_NUM; i++)
    {
        VCOM_SAFE_FREE(s_uart_recv[i].frame_header);

        if (s_uart_recv[i].recv_queue)
        {
            vesync_queue_free(s_uart_recv[i].recv_queue);
            s_uart_recv[i].recv_queue = NULL;
        }
    }
}

/**
 * @brief  从接收队列中取出数据包进行处理，并回调给上层
 * @return     int32_t          [SDK_OK/SDK_FAIL]
 */
int32_t vesync_uart_parse_recv_data(void)
{
    int32_t ret = SDK_FAIL;
    tl_frame_recv_info_t *frame_header = NULL;
    vesync_msg_recv_t recv_data = {0};
    UART_SEND_TYPE_E send_result;

    for (int i = 0; i < VESYNC_UART_NUM; i++)
    {
        if (VOS_OK != vesync_queue_recv(s_uart_recv[i].recv_queue, &recv_data, VESYNC_OS_NO_WAIT))
        {
            continue;
        }

        ret = SDK_OK;
        frame_header = (tl_frame_recv_info_t *)recv_data.p_data;
        if (VESYNC_PROTOCO_VERSION != frame_header->ctrl.bitN.version)
        {
            VCOM_SAFE_FREE(recv_data.p_data);
            continue;
        }

        // 属于ACK消息，若sequence id和发送的一致，则说明已经回包，需要取消超时重发定时器，然后通知应用层
        if (frame_header->ctrl.bitN.ack_flag)
        {
            if (frame_header->seq_id != vesync_uart_get_send_seq_id(i))
            {
                VCOM_SAFE_FREE(recv_data.p_data);
                continue;
            }

            vesync_uart_del_send_timeout_timer(i);

            if (frame_header->ctrl.bitN.error_flag)
            {
                send_result = UART_SEND_FAIL;
            }
            else
            {
                send_result = UART_SEND_SUCCESS;
            }

            vesync_uart_report_tx_event(i, send_result, (tl_payload_info_t *)frame_header->p_payload, frame_header->payload_len);
        }
        else    // 请求报文，如要求回复则记录sequence id，然后通过回调传给应用层处理
        {
            if (frame_header->ctrl.bitN.request_flag)
            {
                s_uart_recv[i].seq_id = frame_header->seq_id;
            }

            vesync_uart_trans_recv_data(i, (tl_payload_info_t *)frame_header->p_payload, frame_header->payload_len);
        }

        VCOM_SAFE_FREE(recv_data.p_data);
    }

    // recv队列读取到消息则该队列可能还有其他消息，处理之后需要重新释放信号量，让收发任务继续处理
    if(SDK_OK == ret)
    {
        vesync_uart_sem_signal();
    }

    return SDK_OK;
}


/**
 * @brief  获取收包的sequence id
 * @param[in]  idx              [UART编号]
 * @return     int8_t           [sequence id]
 */
uint8_t vesync_uart_get_recv_seq_id(uint8_t idx)
{
    return s_uart_recv[idx].seq_id;
}



/**
 * @brief  注册某路串口的接收回调函数，应用层cb处理具体的业务
 * @param[in]  idx                      [串口号]
 * @param[in]  cb                       [串口数据接收回调函数]
 * @note  cb回调函数内不允许阻塞
 */
void vesync_uart_reg_recv_cb(uint8_t idx, uart_recv_data_cb_t cb)
{
    if(idx < VESYNC_UART_NUM)
    {
        s_uart_recv[idx].frame_recv_cb = cb;
    }
}


/**
 * @brief  注册OTA数据接收回调函数，应用层cb处理具体的业务
 * @param[in]  cb                   [串口数据接收回调函数]
 */
void vesync_uart_reg_ota_recv_cb(uint8_t idx, uart_recv_data_cb_t cb)
{
    if(idx < VESYNC_UART_NUM)
    {
        s_uart_recv[idx].ota_recv_cb = cb;
    }
}

