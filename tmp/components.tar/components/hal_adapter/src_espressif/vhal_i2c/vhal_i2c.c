/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file       vhal_i2c.c
 * @brief      乐鑫平台的i2c读写接口
 * @author     Dongri.Su
 * @date       2021-04-22
 */

#include <stdio.h>

#include "driver/i2c.h"

#include "vesync_log.h"
#include "vesync_common.h"


#include "vhal_i2c.h"
#include "vhal_i2c_internal.h"



/**
 * @brief  iic初始化为主机模式
 * @param[in]  i2c_num              [iic编号，0或1]
 * @param[in]  sda_io               [SDA数据线引脚]
 * @param[in]  scl_io               [SCL时钟线引脚]
 * @param[in]  speed                [通信速率]
 * @return     int32_t              [初始化结果，0为成功，其他值表示失败]
 */
int32_t vhal_i2c_master_init(uint8_t i2c_num, uint8_t sda_io, uint8_t scl_io, uint32_t speed)
{
    uint8_t i2c_master_port = i2c_num;
    i2c_config_t conf;

    conf.mode = I2C_MODE_MASTER;
    conf.sda_io_num = sda_io;
    conf.sda_pullup_en = GPIO_PULLUP_ENABLE;
    conf.scl_io_num = scl_io;
    conf.scl_pullup_en = GPIO_PULLUP_ENABLE;
    conf.master.clk_speed = speed;
    i2c_param_config(i2c_master_port, &conf);

    return i2c_driver_install(i2c_master_port, conf.mode,
                              I2C_MASTER_RX_BUF_DISABLE,
                              I2C_MASTER_TX_BUF_DISABLE, 0);
}

/**
 * @brief  iic读取客户端数据
 * @param[in]  i2c_num              [iic编号，0或1]
 * @param[in]  addr                 [操作的地址]
 * @param[in]  p_data               [读取的数据缓存buffer]
 * @param[in]  len                  [读取的数据大小]
 * @return     int32_t              [读取结果，0为成功，其他值表示失败]
 * @note
 *_______________________________________________________________________________________
 * | start | slave_addr + rd_bit +ack | read n-1 bytes + ack | read 1 byte + nack | stop |
 * --------|--------------------------|----------------------|--------------------|------|
 */
int32_t vhal_i2c_master_read(uint8_t i2c_num, uint8_t addr, uint8_t *p_data, int32_t len)
{
    int32_t ret = VHAL_FAIL;
    i2c_cmd_handle_t cmd = i2c_cmd_link_create();

    if (0 == len)
    {
        return ret;
    }

    i2c_master_start(cmd);
    i2c_master_write_byte(cmd, (addr << 1) | READ_BIT, ACK_CHECK_EN);
    if (len > 1)
    {
        i2c_master_read(cmd, p_data, len - 1, ACK_VAL);
    }
    i2c_master_read_byte(cmd, p_data + len - 1, NACK_VAL);
    i2c_master_stop(cmd);
    ret = i2c_master_cmd_begin(i2c_num, cmd, 1000 / portTICK_RATE_MS);
    i2c_cmd_link_delete(cmd);

    return ret;
}

/**
 * @brief  iic写数据到客户端
 * @param[in]  i2c_num              [iic编号，0或1]
 * @param[in]  addr                 [操作的地址]
 * @param[in]  p_data               [待写入的数据]
 * @param[in]  len                  [待写入的数据大小]
 * @return     int32_t              [写入结果，0为成功，其他值表示失败]
 * @note
 * ___________________________________________________________________
 * | start | slave_addr + wr_bit + ack | write n bytes + ack  | stop |
 * --------|---------------------------|----------------------|------|
 */
int32_t vhal_i2c_master_write(uint8_t i2c_num, uint8_t addr, uint8_t *p_data, int32_t len)
{
    int32_t ret = VHAL_FAIL;
    i2c_cmd_handle_t cmd = i2c_cmd_link_create();

    i2c_master_start(cmd);
    i2c_master_write_byte(cmd, (addr << 1) | WRITE_BIT, ACK_CHECK_EN);
    i2c_master_write(cmd, p_data, len, ACK_CHECK_EN);
    i2c_master_stop(cmd);
    ret = i2c_master_cmd_begin(i2c_num, cmd, 1000 / portTICK_RATE_MS);
    i2c_cmd_link_delete(cmd);

    return ret;
}

/**
 * @brief  iic总线单独写stop信号到客户端
 * @param[in]  i2c_num              [iic编号，0或1]
 * @return     int32_t              [写入结果，0为成功，其他值表示失败]
 */
int32_t vhal_i2c_master_write_stop_condition(uint8_t i2c_num)
{
    int32_t ret = VHAL_FAIL;
    i2c_cmd_handle_t cmd = i2c_cmd_link_create();

    i2c_master_stop(cmd);
    i2c_master_stop(cmd);           // 必须连续两个
    ret = i2c_master_cmd_begin(i2c_num, cmd, 1000 / portTICK_RATE_MS);
    i2c_cmd_link_delete(cmd);

    return ret;
}
