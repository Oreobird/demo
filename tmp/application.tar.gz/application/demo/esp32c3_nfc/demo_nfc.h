/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
 * @file        demo_nfc.h
 * @brief       nfc vesync层demo接口
 * @date        2021-11-13
 */
 
#ifndef __DEMO_NFC_H__
#define __DEMO_NFC_H__

#include "vesync_frame.h"
#ifdef __cplusplus
extern "C"
{
#endif

/**
 * @brief  nfc demo初始化接口
 */
void demo_nfc_init(void);


#ifdef __cplusplus
}
#endif


#endif /* __DEMO_NFC_H__ */

