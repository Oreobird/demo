/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_https_test.cpp
 * @brief       vesync https测试用例
 * @author      Joshua
 * @date        2021-10-17
 */

#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <gtest/gtest.h>


#include "vesync_os.h"
#include "vesync_common.h"
#include "vesync_memory.h"
#include "vesync_https_internal.h"

#include "stub.h" // cpp-stub
#include "vesync_https.c" // cpp-stub needs the source file

TEST(vesync_https_test, vesync_https_parse_url_test)
{
    int ret = SDK_FAIL;
    char url[1024] = {0};
    //error url format
    snprintf(url, sizeof(url), "haha");
    ret = vesync_https_parse_url(url);
    EXPECT_EQ(ret, SDK_FAIL);

    // error host len
    char err_host[130] = {0};
    char path[250] = {0};
    memset(err_host, 'a', sizeof(err_host) - 1);
    memset(path, 'b', sizeof(path) - 1);
    snprintf(url, sizeof(url), "https://%s/%s", err_host, path);
    ret = vesync_https_parse_url(url);
    EXPECT_EQ(ret, SDK_FAIL);

    // error path len
    char host[120] = {0};
    char err_path[260] = {0};
    memset(host, 'a', sizeof(host) - 1);
    memset(err_path, 'b', sizeof(err_path) - 1);
    snprintf(url, sizeof(url), "https://%s/%s", host, err_path);
    ret = vesync_https_parse_url(url);
    EXPECT_EQ(ret, SDK_FAIL);

    // error port
    snprintf(url, sizeof(url), "https://192.168.1.102:65537");
    ret = vesync_https_parse_url(url);
    EXPECT_EQ(ret, SDK_FAIL);

    // case ok
    snprintf(url, sizeof(url), "https://192.168.1.111:9988");
    ret = vesync_https_parse_url(url);
    EXPECT_EQ(ret, SDK_OK);

    snprintf(url, sizeof(url), "https://192.168.1.111:9988/resource/test.jpeg");
    ret = vesync_https_parse_url(url);
    EXPECT_EQ(ret, SDK_OK);
}


static int vesync_https_cli_ssl_init_stub(vesync_https_cli_cfg_t *config)
{
    return SDK_OK;
}


TEST(vesync_https_test, vesync_https_cli_init_test)
{
    Stub stub;
    stub.set(vesync_https_cli_ssl_init, vesync_https_cli_ssl_init_stub);

    int ret = SDK_FAIL;

    vesync_https_cli_cfg_t https_cfg = {
                    .url = NULL,
                    .host = NULL,
                    .path = NULL,
                    .ca_pem = NULL,
                    .client_pem = NULL,
                    .client_key = NULL,
                    .keep_alive = false,
                    .port = 443,
                    .timeout_ms = HTTPS_WAIT_TIME_MS};

    // error host len
    char err_host[130] = {0};
    char path[250] = {0};
    memset(err_host, 'a', sizeof(err_host) - 1);
    memset(path, 'b', sizeof(path) - 1);
    https_cfg.host = err_host;
    https_cfg.path = path;
    ret = vesync_https_cli_init(&https_cfg);
    EXPECT_EQ(ret, SDK_FAIL);

    // error path len
    char host[120] = {0};
    char err_path[260] = {0};
    memset(host, 'a', sizeof(host) - 1);
    memset(err_path, 'b', sizeof(err_path) - 1);
    https_cfg.host = host;
    https_cfg.path = err_path;
    ret = vesync_https_cli_init(&https_cfg);
    EXPECT_EQ(ret, SDK_FAIL);

    // case ok
    snprintf(host, sizeof(host), "https://192.168.1.102");
    snprintf(path, sizeof(path), "/resource/test/test.jpg");
    https_cfg.host = host;
    https_cfg.path = path;
    ret = vesync_https_cli_init(&https_cfg);
    EXPECT_EQ(ret, SDK_OK);
}

static bool vhal_wifi_get_link_status_stub(int32_t wait_time_ms)
{
    return true;
}

static int mbedtls_ssl_write_stub(mbedtls_ssl_context *ssl, const unsigned char *buf, size_t len)
{
    return 25;
}

TEST(vesync_https_test, vesync_https_cli_request_test)
{
    Stub stub;
    stub.set(vesync_https_cli_ssl_init, vesync_https_cli_ssl_init_stub);
    stub.set(vhal_wifi_get_link_status, vhal_wifi_get_link_status_stub);
    stub.set(mbedtls_ssl_write, mbedtls_ssl_write_stub);

    int ret = SDK_FAIL;

    vesync_https_cli_cfg_t https_cfg = {
                    .url = (char *)"haha",
                    .host = NULL,
                    .path = (char *)"/cloud/v1/deviceWeb/deviceRegisterV3",
                    .ca_pem = NULL,
                    .client_pem = NULL,
                    .client_key = NULL,
                    .keep_alive = false,
                    .port = 443,
                    .timeout_ms = HTTPS_WAIT_TIME_MS};

    ret = vesync_https_cli_init(&https_cfg);
    EXPECT_EQ(ret, SDK_FAIL);

    char https_buffer[HTTPS_BUFFER_SIZE] = {0};
    char *send_buf = (char *)"hello world\r\n";
    ret = vesync_https_cli_request(HTTPS_METHOD_GET, https_buffer, send_buf);
    EXPECT_EQ(ret, SDK_OK);
}

static int mbedtls_ssl_read_stub1(mbedtls_ssl_context *ssl, unsigned char *buf, size_t len)
{
    const char *response = "HTTP/1.1 200\r\n"
    "Server: nginx/1.20.1\r\n"
    "Date: Wed, 13 Oct 2021 03:14:55 GMT\r\n"
    "Content-Type: application/json;charset=UTF-8\r\n"
    "Transfer-Encoding: chunked\r\n"
    "Connection: keep-alive\r\n\r\n"
    "2\r\n"
    "ab\r\n"
    "0\r\n\r\n";
    snprintf((char *)buf, len, "%s", response);
    return strlen(response);
}

static int mbedtls_ssl_read_stub2(mbedtls_ssl_context *ssl, unsigned char *buf, size_t len)
{
    static int chunk_idx = 1;
    const char *chunk1 = "HTTP/1.1 200\r\n"
                         "Server: nginx/1.20.1\r\n"
                         "Date: Wed, 13 Oct 2021 03:14:55 GMT\r\n"
                         "Content-Type: application/json;charset=UTF-8\r\n"
                         "Transfer-Encoding: chunked\r\n"
                         "Connection: keep-alive\r\n\r\n"
                         "2\r\n"
                         "ab\r\n";

    const char *chunk2 = "4\r\n"
                         "cdef\r\n"
                         "0\r\n\r\n";
    int ret = 0;

    if (chunk_idx == 1)
    {
        snprintf((char *)buf, len, "%s", chunk1);
        ret = strlen(chunk1);
        chunk_idx++;
    }
    else if (chunk_idx == 2)
    {
        snprintf((char *)buf, len, "%s", chunk2);
        ret = strlen(chunk2);
    }

    return ret;
}

TEST(vesync_https_test, vesync_https_cli_recv_test)
{
    Stub stub;
    stub.set(mbedtls_ssl_read, mbedtls_ssl_read_stub1);

    int ret = SDK_FAIL;

    char https_buffer[HTTPS_BUFFER_SIZE] = {0};
    char recv_buf[1024] = {0};
    int recv_len = sizeof(recv_buf);
    ret = vesync_https_cli_recv(https_buffer, recv_buf, &recv_len, false);
    EXPECT_EQ(ret, SDK_OK);
    EXPECT_STREQ("ab", recv_buf);

    stub.set(mbedtls_ssl_read, mbedtls_ssl_read_stub2);
    recv_len = sizeof(recv_buf);
    ret = vesync_https_cli_recv(https_buffer, recv_buf, &recv_len, false);
    EXPECT_EQ(ret, SDK_OK);
    EXPECT_STREQ("abcdef", recv_buf);
}


