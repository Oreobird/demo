/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_lan_comm_reports.c
 * @brief       局域网通信状态更新接口实现文件
 * @author      henrikzhou
 * @date        2020-10-21
 */

#include <string.h>
#include "vesync_memory.h"
#include "vesync_lan_comm.h"
#include "vesync_lan_comm_reports.h"
#include "cJSON.h"
#include "vesync_common.h"
#include "vesync_log_internal.h"

/**
 * @brief 局域网状态更新通知
 * @return int      [SDK_OK：成功/SDK_FAIL：失败]
 */
int vesync_lan_comm_report_status(void)
{
    cJSON * root = NULL;
    char* p_reply = NULL;
    int ret = SDK_FAIL;

    root = cJSON_CreateObject();
    if (NULL == root)
    {
        SDK_LOG(LOG_ERROR, "offline report cjson creat fail!\n");
        goto exit;
    }

    if (NULL == cJSON_AddNumberToObject(root, "type",1))
    {
        SDK_LOG(LOG_ERROR, "offline report creat cJson NetStatus string fail!\n");
        goto exit;
    }

    if (NULL == cJSON_AddNumberToObject(root, "value",0))
    {
        SDK_LOG(LOG_ERROR, "offline report creat cJson NetStatus string fail!\n");
        goto exit;

    }


    p_reply = cJSON_PrintUnformatted(root);
    if (NULL == p_reply)
    {
        SDK_LOG(LOG_ERROR, "offline report printunformatted fail!\n");
    }
    else
    {
        ret = SDK_OK;
        vesync_lan_comm_tcp_data_send((uint8_t *)p_reply, strlen(p_reply),LAN_COMM_OP_TCP_NOTIFY,1,0);
    }

exit:
    VCOM_SAFE_FREE(p_reply);
    if (NULL != root)
    {
        cJSON_Delete(root);
    }
    return ret;
}


/**
 * @brief 局域网设备离线通知
 * @return int      [SDK_OK：成功/SDK_FAIL：失败]
 */
int vesync_lan_comm_report_offline(void)
{
    cJSON * root = NULL;
    char* p_reply = NULL;
    int ret = SDK_FAIL;

    root = cJSON_CreateObject();
    if (NULL == root)
    {
        SDK_LOG(LOG_ERROR, "offline report cjson creat fail!\n");
        goto exit;
    }

    if (NULL == cJSON_AddNumberToObject(root, "type",0))
    {
        SDK_LOG(LOG_ERROR, "offline report creat cJson NetStatus string fail!\n");
        goto exit;
    }

    if (NULL == cJSON_AddNumberToObject(root, "value",0))
    {
        SDK_LOG(LOG_ERROR, "offline report creat cJson NetStatus string fail!\n");
        goto exit;
    }

    p_reply = cJSON_PrintUnformatted(root);
    if (NULL == p_reply)
    {
        SDK_LOG(LOG_ERROR, "offline report printunformatted fail!\n");
    }
    else
    {
        ret = SDK_OK;
        vesync_lan_comm_tcp_data_send((uint8_t *)p_reply, strlen(p_reply),LAN_COMM_OP_TCP_NOTIFY,1,0);
    }


exit:
    VCOM_SAFE_FREE(p_reply);
    if (NULL != root)
    {
        cJSON_Delete(root);
    }
    return ret;
}


