/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        outlet_wifi_led.h
 * @brief       outlet Wi-Fi指示灯配置
 * @author      Joshua
 * @date        2021-06-04
 */

#ifndef __OUTLET_WIFI_LED_H__
#define __OUTLET_WIFI_LED_H__

#ifdef __cplusplus
extern "C" {
#endif


/**
 * @brief  灯效配置
 * @return     int             [成功/失败]
 */
int outlet_reg_wifi_led(void);


#ifdef __cplusplus
}
#endif

#endif

