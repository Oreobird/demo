/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        bulb.c
 * @brief       bulb入口
 * @author      Dave.Ming
 * @date        2021-08-30
 */

#include <stdio.h>

#include "vesync_common.h"
#include "vesync_init.h"
#include "vesync_log.h"
#include "vesync_queue.h"
#include "vesync_device.h"
#include "vesync_flash.h"
#include "vesync_production.h"
#include "vesync_netcfg.h"
#include "vesync_wifi_led.h"
#include "vesync_net_service.h"
#include "vesync_task.h"

#include "bulb.h"
#include "bulb_bypass.h"
#include "bulb_report.h"
#include "bulb_schedule.h"
#include "bulb_timing.h"
#include "bulb_wifi_led.h"
#include "bulb_switch.h"
#include "bulb_flash.h"
#include "bulb_device.h"
#include "bulb_status.h"
#include "bulb_production.h"
#include "bulb_def.h"
#include "bulb_scene.h"
#include "bulb_pwr_mem.h"
#include "bulb_color_tbl.h"

static vesync_queue_t *s_event_queue = NULL;

#define BULB_APP_TASK_NAME "app_task"
#define BULB_APP_TASK_STACSIZE (1024 * 4)
#define BULB_APP_TASK_PRIO TASK_PRIORITY_NORMAL

/**
* @brief bulb设备上电事件发布
*/
static void bulb_poweron_event()
{
    bulb_ev_t ev;
    ev.act_src = BULB_ACT_SRC_SWITCH;
    ev.id = BULB_EV_PWOERON;
    memset(ev.rsn, 0, sizeof(ev.rsn));
    bulb_app_task_notify(&ev);
}

/**
 * @brief 灯泡配网成功后的回调
 */
static void bulb_netcfg_success_cb(void)
{
    bulb_ev_t ev;
    memset(&ev, 0, sizeof(ev));
    ev.id = BULB_EV_NETCFGED;
    bulb_app_task_notify(&ev);
}

/**
 * @brief 灯泡网络重连成功后的回调
 */
static void bulb_network_reconnected_cb(void)
{
    bulb_ev_t ev;
    memset(&ev, 0, sizeof(ev));
    ev.id = BULB_EV_NET_RECONNECTED;
    bulb_app_task_notify(&ev);
}

/**
 * @brief  app任务事件处理
  * @param[in]   bulb_ev_t        [发布事件结构体]
 */
static void app_event_handle(bulb_ev_t ev)
{
    bulb_status_t bulb_status;
    switch (ev.id)
    {
    case BULB_EV_PWOERON:
        APP_LOG(LOG_DEBUG, "switch times:%d\n", bulb_flash_get_cfg(BULB_CFG_POWERNUM));
        bulb_switch_poweron_cb();
        break;
    case BULB_EV_PRODUCTION:
        vesync_production_enter_testmode(true);
        break;
    case BULB_EV_NETCFG:
        bulb_status_direct_set_white(&g_white_6500k_100, 1.0);

        vesync_netcfg_start();
        break;
    case BULB_EV_NETCFGED:
        bulb_status_fetch(&bulb_status);
        bulb_status.enable = true;
        bulb_status_update(&bulb_status);
        break;
    case BULB_EV_RESET:
        vesync_device_factory_reset(true, STAT_CHG_RSN_BTN_STR);
        break;
    case BULB_EV_NET_RECONNECTED:
        bulb_report_status_change(STAT_CHG_RSN_RECONNECT_STR);
        break;
    default:
        APP_LOG(LOG_WARN, "Unknown event\n");
    }
}

/**
 * @brief  app应用任务
 */
static void app_task(void *arg)
{
    UNUSED(arg);
    APP_LOG(LOG_DEBUG, "-------app task running--------\n");
    bulb_ev_t ev;
    while (1)
    {
        int ret = vesync_queue_recv(s_event_queue, &ev, VESYNC_OS_WAIT_FOREVER);
        if (ret != VOS_OK)
        {
            APP_LOG(LOG_ERROR, "Event queue recv fail\n");
            return;
        }
        app_event_handle(ev);
    }
}

/**
 * @brief  Bulb上电状态恢复
 */
void bulb_poweron_restore(void)
{
    uint8_t mode;
    bulb_action_t action;
    bulb_pwr_mem_get(&mode, &action);

    bulb_status_t bulb_status;
    bulb_status_fetch(&bulb_status);
    switch (mode)
    {
    case BULB_CFG_POWEROFF_MEMORY_MODE_1:
        bulb_status.enable = true;
        break;
    case BULB_CFG_POWEROFF_MEMORY_MODE_3:
        bulb_status.enable = (action.onoff > 0) ? true : false;
        if (true == bulb_status.enable)
        {
            bulb_status.mode = action.mode;
            switch (bulb_status.mode)
            {
            case BULB_CFG_COLOR_MODE_WHITE:
                bulb_status.white.brightness = action.bright;
                bulb_status.white.color_temp = action.temp;
                break;
            case BULB_CFG_COLOR_MODE_HSV:
                bulb_status.hsv.hue = action.hue;
                bulb_status.hsv.saturation = action.saturation;
                bulb_status.hsv.value = action.value;
                break;
            case BULB_CFG_COLOR_MODE_SCENARIO:
                bulb_status.scene_id = action.scene_id;
                break;
            default:
                break;
            }
        }
        break;
    case BULB_CFG_POWEROFF_MEMORY_MODE_2:
        // fall-through
    default:
        break;
    }
    bulb_status_update(&bulb_status);
}

/**
 * @brief  SDK初始化前回调
 */
static void bulb_pre_cb(void)
{
    bulb_flash_load_cfg(BULB_ACT_SRC_SWITCH);

    s_event_queue = vesync_queue_new(BULB_EVENT_QUEUE_MAX_NUM * sizeof(bulb_ev_t), sizeof(bulb_ev_t));
    if (s_event_queue == NULL)
    {
        APP_LOG(LOG_ERROR, "App event queue create failed\n");
        return;
    }

    int ret = vesync_task_new(BULB_APP_TASK_NAME, NULL, app_task, NULL, BULB_APP_TASK_STACSIZE, BULB_APP_TASK_PRIO, NULL);
    if (ret != VOS_OK)
    {
        APP_LOG(LOG_ERROR, "App task create failed\n");
        vesync_queue_free(s_event_queue);
        return;
    }
    bulb_pwr_mem_init();
    bulb_scene_init();
    bulb_status_init();

    bulb_poweron_restore();

    bulb_production_init();
    bulb_switch_upd_poweron_cnt();
}

/**
 * @brief  SDK初始化完成后app应用入口
 */
static void bulb_app_run(void)
{
    APP_LOG(LOG_INFO, "Vesync APP Bulb start\n");

    // 根据硬件版本更新WiFi mainFw Plugin Name
    // 默认的HW_VERSION为"1.0"，对应默认的mainFw Plugin Name为"mainFw"
    if (0 != strcmp((char *)BULB_DEFAULT_HW_VER, vesync_cfg_get_hw_version()))
    {
        vesync_device_add_plugin_name_suffix(UPG_TP_WIFI, vesync_cfg_get_hw_version());
    }

    // 设备上电事件发布
    bulb_poweron_event();
    bulb_bypass_reg_cb();
    bulb_schedule_init();
    bulb_timing_init();
    bulb_device_init();

    // 注册联网成功回调
    vesync_net_cfg_reg_success_cb(bulb_netcfg_success_cb);
    // 服务器连接成功回调
    vesync_net_event_reg_nwk_conn_cb(bulb_network_reconnected_cb);
}

/**
 * @brief  bulb应用运行入口
 */
void app_main(void)
{
    vesync_sdk_reg_pre_run_cb(bulb_pre_cb);
    vesync_sdk_reg_post_run_cb(bulb_app_run);
    vesync_sdk_run();
}

int bulb_app_task_notify(bulb_ev_t *ev)
{
    int ret = vesync_queue_send(s_event_queue, ev, VESYNC_OS_NO_WAIT);
    if (ret != VOS_OK)
    {
        APP_LOG(LOG_ERROR, "Event publish failed\n");
        return APP_FAIL;
    }

    return APP_OK;
}
