/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_bypass_timer.c
 * @brief       bypass处理接口
 * @date        2021-05-17
 */
#include <string.h>

#include "vesync_common.h"
#include "vesync_memory.h"

#include "vesync_bypass_internal.h"

/**
 * @brief "addTimer" method数据解析
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  json                     [json数据指针]
 * @return BYPASS_ERR_E                 [错误码]
 */
static BYPASS_ERR_E bypass_method_add_timer_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    BYPASS_ERR_E ret = BP_OK;

    bypass_timer_data_t *ptimer_data = (bypass_timer_data_t *)vesync_malloc(sizeof(bypass_timer_data_t));
    if (NULL == ptimer_data)
    {
        return BP_ERR_NOMEM;
    }

    memset(ptimer_data, 0, sizeof(bypass_timer_data_t));

    cJSON* json_data = cJSON_GetObjectItemCaseSensitive(json, "total");
    if (cJSON_IsNumber(json_data))
    {
        // 执行时间0~86400，最大倒计时24小时
        if (json_data->valueint <= 0 || json_data->valueint >= 86400)
        {
            vesync_bypass_reply_noqos(BP_ERR_TIMER_CONFIG, p_msg_ctx->p_trace_msg ,NULL);  // 回复指定错误码
            ret = BP_ERROR;
            goto _exit;
        }

        ptimer_data->total_sec = json_data->valueint;
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    cJSON* json_action = cJSON_GetObjectItemCaseSensitive(json, "action");
    if (cJSON_IsString(json_action))
    {
        if (strcmp(json_action->valuestring, "on") == 0)
        {
            ptimer_data->action = TIMER_ACTION_ON;
        }
        else if (strcmp(json_action->valuestring, "off") == 0)
        {
            ptimer_data->action = TIMER_ACTION_OFF;
        }
        else
        {
            ret = BP_ERR_ARG;
            goto _exit;
        }
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_ADD_TIMER);
    if (method_cb)
    {
        method_cb(p_msg_ctx, (void*)ptimer_data);
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

_exit:
    vesync_free(ptimer_data);
    return ret;
}

/**
 * @brief "delTimer" method数据解析
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  json                     [json数据指针]
 * @return BYPASS_ERR_E                 [错误码]
 */
static BYPASS_ERR_E bypass_method_del_timer_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    int *id_buf = (int*)vesync_malloc(sizeof(int));
    if (NULL == id_buf)
    {
        return BP_ERR_NOMEM;
    }

    BYPASS_ERR_E ret = BP_OK;

    cJSON* json_data = cJSON_GetObjectItemCaseSensitive(json, "id");
    if (cJSON_IsNumber(json_data))
    {
        *id_buf = json_data->valueint;
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_DEL_TIMER);
    if (method_cb)
    {
        method_cb(p_msg_ctx, (void*)id_buf);
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

_exit:
    vesync_free(id_buf);
    return ret;
}

/**
 * @brief "getTimer" method数据解析
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  json                     [json数据指针]
 * @return BYPASS_ERR_E                 [错误码]
 */
static BYPASS_ERR_E bypass_method_get_timer_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    UNUSED(json);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    BYPASS_ERR_E ret = BP_OK;

    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_GET_TIMER);
    if (method_cb)
    {
        method_cb(p_msg_ctx, NULL);
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

    return ret;
}


static bypass_item_data_t method_tbl[] = {
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_ADD_TIMER, "addTimer", bypass_method_add_timer_handle, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_DEL_TIMER, "delTimer", bypass_method_del_timer_handle, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_GET_TIMER, "getTimer", bypass_method_get_timer_handle, NULL},
};

void vesync_bypass_timer_init(void)
{
    for (int i = 0; i < SIZEOF_ARRAY(method_tbl); i++)
    {
        bypass_item_t *item = vesync_bypass_init_item(&method_tbl[i]);
        if (item != NULL)
        {
            vesync_bypass_add_item(item);
        }
    }
}

