/**
 *  Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_uart_internal.h
 * @brief       串口内部处理模块、UART数据封装/解析
 * @author      Louis
 * @date        2021-08-17
 */

#ifndef __VESYNC_UART_INTERNAL_H__
#define __VESYNC_UART_INTERNAL_H__

#include <stdbool.h>

#include "vesync_cfg_internal.h"
#include "vesync_task.h"
#include "vesync_loop_timer_internal.h"
#include "vesync_uart.h"
#include "vesync_tl_frame_parse.h"
#include "vesync_tl_payload_parse.h"
#include "vesync_queue.h"

#ifdef __cplusplus
extern "C"
{
#endif


/**
 * @brief  串口接收消息数据结构
 */
typedef struct
{
    void  *p_data;
    uint16_t  data_len;
}vesync_msg_recv_t;


/**
 * @brief 一路收发通道控制信息
 */
typedef struct
{
    uint8_t idx;                            // uart idx
    uint8_t seq_id;                         // sequence id
    bool busy;                              // 发送繁忙状态
    uint8_t repeat_cnt;                     // 超时重发次数
    vloop_timer_t timeout;                  // 超时重发定时器
    vesync_queue_t *ack_queue;              // ack发送队列
    vesync_queue_t *cmd_queue;              // cmd发送队列
    uart_msg_send_t cmd_data;               // 当前正在发送的cmd数据
    uart_tx_event_cb_t  cmd_evt_cb;         // 发送结果的事件通知
    uart_tx_event_cb_t  ota_evt_cb;         // OTA发送结果的事件通知
}vesync_uart_send_t;

typedef struct
{
    uint8_t seq_id;                         // sequence id
    vesync_queue_t *recv_queue;             // receive接收队列
    tl_frame_recv_info_t *frame_header;     // 接收数据包头
    uart_recv_data_cb_t frame_recv_cb;      // 接收到数据包回调函数
    uart_recv_data_cb_t ota_recv_cb;        // OTA接收到数据包回调函数
}vesync_uart_recv_t;


/**
 * @brief  vesync串口初始化
 * @return     uint32_t         [SDK_OK成功，SDK_FAIL失败]
 */
uint32_t vesync_uart_init(void);

/**
 * @brief  释放信号量，通知收发任务处理
 * @return     int32_t          [SDK_OK/SDK_FAIL]
 */
int32_t vesync_uart_sem_signal(void);

/**
 * @brief  UART模块接收初始化
 * @return     int32_t          [SDK_OK/SDK_FAIL]
 */
int32_t vesync_uart_recv_init(void);

/**
 * @brief  UART模块接收退出
 */
void vesync_uart_recv_deinit(void);

/**
 * @brief  从接收队列中取出数据包进行处理，并回调给上层
 * @return     int32_t          [SDK_OK/SDK_FAIL]
 */
int32_t vesync_uart_parse_recv_data(void);

/**
 * @brief  获取收包的sequence id
 * @param[in]  idx              [UART编号]
 * @return     int8_t           [sequence id]
 */
uint8_t vesync_uart_get_recv_seq_id(uint8_t idx);

/**
 * @brief  UART模块发送初始化
 * @return     int32_t          [SDK_OK/SDK_FAIL]
 */
int32_t vesync_uart_send_init(void);

/**
 * @brief  UART模块发送退出
 */
void vesync_uart_send_deinit(void);

/**
 * @brief  从发送队列中取出数据，然后调用vhal接口发送出去
 * @note   数据处理优先级：ACK数据、无需对端回复的数据、需要对端回复的数据
 */
int32_t vesync_uart_parse_send_data(void);

/**
 * @brief 添加超时重发定时器
 */
void vesync_uart_add_send_timeout_timer(uint8_t idx);

/**
 * @brief 删除超时重发定时器
 */
void vesync_uart_del_send_timeout_timer(uint8_t idx);

/**
 * @brief 处理已经超时的定时器
 * @return    uint64_t      [下一个即将超时定时器的时间ms]
 */
uint64_t vesync_uart_process_expired_timer(void);

/**
 * @brief  获取发送的sequence id
 * @param[in]  idx                 [串口编号]
 * @return     uint8_t             [sequence id]
 */
uint8_t vesync_uart_get_send_seq_id(uint8_t idx);

/**
 * @brief  UART串口发送返回事件回调
 * @param[in]  cb                   [发送返回事件回调函数]
 */
void vesync_uart_report_tx_event(uint8_t idx, UART_SEND_TYPE_E event, tl_payload_info_t *p_payload, uint16_t payload_len);


/**
 * @brief  注册OTA数据接收回调函数，应用层cb处理具体的业务
 * @param[in]  idx                      [UART编号]
 * @param[in]  cb                       [串口数据接收回调函数]
 */
void vesync_uart_reg_ota_recv_cb(uint8_t idx, uart_recv_data_cb_t cb);

/**
 * @brief  注册OTA串口ota事件回调函数
 * @param[in]  idx                      [UART编号]
 * @param[in]  cb                       [ota事件回调函数]
 */
void vesync_uart_reg_ota_event_cb(uint8_t idx, uart_tx_event_cb_t cb);


#ifdef __cplusplus
}
#endif

#endif
