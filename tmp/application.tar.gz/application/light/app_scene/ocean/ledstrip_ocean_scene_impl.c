/**
* Copyright © Vesync Technologies Co.Ltd. 2022. All rights reserved
* @file         ledstrip_ocean_scene_impl.c
* @brief        海洋场景回调业务实现
* @author       Joshua
* @date         2022-1-14
*/

#include <string.h>
#include "vesync_log.h"
#include "vesync_common.h"
#include "ocean.h"
#include "light.h"

static int ocean(void *param)
{
    UNUSED(param);
    APP_LOG(LOG_DEBUG, "ocean scene\n");
    light_param_t light_param[] = {{0, 0, 4500, 5700, 100},
                             {0, 0, 2780, 5600, 100},
                             {0, 0, 4500, 5700, 100},
                             {0, 0, 6000, 10000, 100}};
    app_light_color_flow(light_param, SIZEOF_ARRAY(light_param), 1, LIGHT_REFLESH_INTERVAL_MS, 0, true);
    return APP_OK;
}

int ocean_light_scene_impl_init(void)
{
    light_scene_t light_scene;
    memset(&light_scene, 0, sizeof(light_scene_t));
    light_scene.light_cb = ocean;
    return ocean_light_scene_reg(&light_scene);
}

