/**
 * Copyright © Etekcity Technologies Co., Ltd. 2021. All rights reserved.
 * @file        vesync_certificate.c
 * @brief       处理ffs 证书以及相关设备私钥更新
 * @author      Patrick
 * @date        20120-09-3
 */

#include "mbedtls/x509_crt.h"
#include "mbedtls/x509_csr.h"
#include "mbedtls/md5.h"
#include "ffs/common/ffs_result.h"
#include "ffs/common/ffs_stream.h"
#include "ffs/common/ffs_wifi.h"
#include "ffs/common/ffs_check_result.h"
#include "ffs/common/ffs_log_level.h"

#include "vesync_task.h"
#include "vesync_memory.h"
#include "vesync_common.h"
#include "vesync_log_internal.h"
#include "vesync_http_internal.h"
#include "vesync_report_internal.h"

#include "ffs_rtos_configuration_map.h"
#include "ffs_wifi_context.h"
#include "ffs_wifi_connection_attempt_list.h"
#include "ffs_wifi_configuration_list.h"
#include "ffs_pem_file.h"
#include "ffs_certificate.h"
#include "ffs_flash.h"

#include "vesync_ffs_user_context.h"
#include "vesync_ffs_internal.h"
#include "vesync_ffs_user_context.h"
#include "vesync_ffs_crypto.h"

// 证书更新结构体
//#if CONFIG_VESYNC_SDK_HTTP_ENABLE
static ffs_update_certificate_info_t s_update_certificate;
//#endif

//证书更新任务
static vesync_task_t ffs_update_certificate_taskhd = NULL;

static mbedtls_md5_context *p_md5 = NULL; // 计算MD5

/**
* @brief  初始化MD5 context
* @return    int32_t          [成功/失败]
*/
static int32_t ffs_cert_md5_check_init(void)
{
    p_md5 = (mbedtls_md5_context *)vesync_malloc(sizeof(mbedtls_md5_context) + 1);
    if (NULL == p_md5)
    {
        return SDK_FAIL;
    }

    memset(p_md5, 0, sizeof(mbedtls_md5_context) + 1);
    mbedtls_md5_init(p_md5);
#if defined(MBEDTLS_DEPRECATED)
    mbedtls_md5_starts(p_md5);
#else
    mbedtls_md5_starts_ret(p_md5);
#endif

    return SDK_OK;
}

/**
* @brief  MD5数据计算
* @param[in]   p_buff          [接收到的固件buff]
* @param[in]   buff_len        [固件buff的长度]
*/
static void ffs_cert_md5_calc(uint8_t *p_buff, int32_t buff_len)
{
    if (NULL != p_md5)
    {
        mbedtls_md5_update(p_md5, p_buff, buff_len);
    }
}

/**
* @brief  本地计算的md5跟下发的对比
* @param[in]  p_md5_data    [对比的md5]
* @return int32_t           [SDK_OK检验通过，SDK_FAIL检验失败]
*/
static int ffs_cert_md5_check(char *p_md5_data)
{
    int ret = SDK_FAIL;
    uint8_t tmp1 = 0x0, tmp2 = 0x0;
    unsigned char hash[16] = {0};
    uint8_t md5_str[36] = {0};

    if ((NULL == p_md5) || (NULL == p_md5_data))
    {
        return SDK_FAIL;
    }

    mbedtls_md5_finish(p_md5, hash);
    mbedtls_md5_free(p_md5);
    LOG_RAW_HEX(LOG_DEBUG, "Hash: ", hash, sizeof(hash));

    for (uint8_t idx = 0; idx < 16; idx++) //转成小写
    {                                      // 格式转换
        tmp1 = (hash[idx] >> 4) & 0x0F;
        tmp2 = hash[idx] & 0x0F;

        if (tmp1 < 0xA)
            md5_str[idx * 2] = tmp1 + 0x30;
        else // A~F
            md5_str[idx * 2] = tmp1 + 0x57;
        if (tmp2 < 0xA)
            md5_str[idx * 2 + 1] = tmp2 + 0x30;
        else // A~F
            md5_str[idx * 2 + 1] = tmp2 + 0x57;
    }

    //SDK_LOG(LOG_DEBUG, "md5 sum = %s \n", md5_str);
    if (strncmp((const char *)md5_str, (const char *)p_md5_data, 32) == 0) //比较md5
    {
        ret = SDK_OK;
    }
    else
    {
        ret = SDK_FAIL;
    }

    return ret;
}

/**
 * @brief  释放申请的校验数据空间
 * @return              [无]
 */
static void ffs_cert_md5_release(void)
{
    if (NULL != p_md5)
    {
        VCOM_SAFE_FREE(p_md5);
        p_md5 = NULL;
    }
}

/**
* @brief  x509证书解析
* @param[in]  pbuf      [证书数据]
* @param[in]  dat_len   [证书数据长度]
* @return int           [SDK_OK 解析成功, SDK_FAIL 解析失败]
*/
static int ffs_cert_x509_parse(uint8_t *pbuf, int32_t dat_len)
{
    if (NULL == pbuf)
    {
        return SDK_FAIL;
    }

    int parse_ret = SDK_FAIL;

    mbedtls_x509_crt crt;
    mbedtls_x509_crt_init(&crt);

    int ret = mbedtls_x509_crt_parse(&crt, (uint8_t *)pbuf, dat_len);
    if (0 == ret)
    {
        parse_ret = SDK_OK;
    }
    else
    {
        parse_ret = SDK_FAIL;
    }
    mbedtls_x509_crt_free(&crt);

    return parse_ret;
}

/**
* @brief  私钥解析
* @param[in]  pbuf      [私钥数据]
* @param[in]  dat_len   [私钥数据长度]
* @return int           [SDK_OK 解析成功, SDK_FAIL 解析失败]
*/
static int ffs_cert_pk_parse(uint8_t *pbuf, int32_t dat_len)
{
    if (NULL == pbuf)
    {
        return SDK_FAIL;
    }
    int parse_ret = SDK_FAIL;
    mbedtls_pk_context pk_ctx;

    mbedtls_pk_init(&pk_ctx);

    int ret = mbedtls_pk_parse_key(&pk_ctx, (const unsigned char *)pbuf, dat_len, NULL, 0);
    if (0 == ret)
    {
        parse_ret = SDK_OK;
    }
    else
    {
        parse_ret = SDK_FAIL;
    }

    mbedtls_pk_free(&pk_ctx);

    return parse_ret;
}

#if CONFIG_VESYNC_SDK_HTTP_ENABLE
/**
  * @brief  证书更新任务, 证书更新完毕退出
  * @param[in] args
  */
static void vesyn_ffs_certificate_update_task(void *arg)
{
    int ret = 0, retry_cnt = 0, md5_ret = 0;
    FFS_CERT_E ffs_cert = FFS_CA;
    ffs_update_certificate_info_t *p_cert_info = &s_update_certificate;
    char *p_ca_buff = NULL;

    if (HTTP_GET_PRIVATE_KEY == p_cert_info->get_mode)
    {
        ffs_cert = FFS_PRIVATE_KEY;
    }

    do
    {
        retry_cnt++;
        if (retry_cnt > 3) //重试2次
        {
            break;
        }

        ret = vesync_ffs_get_generate_ca_files_api(p_cert_info->url, p_cert_info->get_mode);
    } while (SDK_OK != ret);

    if (retry_cnt > 3)
    {
        SDK_LOG(LOG_DEBUG, "down ca file fail\n");
        vesync_report_ffs_cert_update(ffs_cert, FFS_CERT_UP_DL_FAIL);
        goto _exit;
    }

    if (SDK_OK == ret) //证书更新完成, 读取出来校验md5
    {
        int read_len = 0;

        SDK_LOG(LOG_DEBUG, "download ok,read and check md5 \n");

        if (HTTP_GET_CLI_CA == p_cert_info->get_mode)
        {
            //先读一次获取长度
            if (vesync_ffs_flash_read_cert_chain(NULL, &read_len) == SDK_OK)
            {
                SDK_LOG(LOG_DEBUG, "\n read_cert_chain len %d \n", read_len);
                if (read_len)
                {
                    p_ca_buff = (char *)vesync_malloc(read_len + 1);
                }

                if (p_ca_buff)
                {
                    memset(p_ca_buff, 0, read_len + 1);
                    if (vesync_ffs_flash_read_cert_chain(p_ca_buff, &read_len) == SDK_OK)
                    {
                        ffs_cert_md5_check_init();
                        ffs_cert_md5_calc((uint8_t *)p_ca_buff, read_len);
                        md5_ret = ffs_cert_md5_check(p_cert_info->md5);
                        ffs_cert_md5_release();

                        if (SDK_FAIL == md5_ret)
                        {
                            vesync_report_ffs_cert_update(ffs_cert, FFS_CERT_UP_VERIFY_ERR); //md5校验失败
                            goto _exit;
                        }

                        if (ffs_cert_x509_parse((uint8_t *)p_ca_buff, read_len + 1) == SDK_FAIL) //校验x509证书格式
                        {
                            vesync_report_ffs_cert_update(ffs_cert, FFS_CERT_UP_PARSE_ERR);
                            goto _exit;
                        }

                        vesync_report_ffs_cert_update(ffs_cert, FFS_CERT_UP_OK);
                    }
                }
                else
                {
                    SDK_LOG(LOG_ERROR, "\n vesync_malloc failed\n");
                }
            }
            else
            {
                SDK_LOG(LOG_ERROR, "read ffs ca err\r\n");
            }
        }
        else if (HTTP_GET_PRIVATE_KEY == p_cert_info->get_mode)
        {
            if (vesync_ffs_flash_read_dha_private_key(NULL, &read_len) == SDK_OK)
            {
                SDK_LOG(LOG_DEBUG, "\n  ffs private key len %d \n", read_len);
                if (read_len)
                {
                    p_ca_buff = (char *)vesync_malloc(read_len + 1);
                }

                if (p_ca_buff)
                {
                    memset(p_ca_buff, 0, read_len + 1);
                    if (vesync_ffs_flash_read_dha_private_key(p_ca_buff, &read_len) == SDK_OK)
                    {
                        ffs_cert_md5_check_init();
                        ffs_cert_md5_calc((uint8_t *)p_ca_buff, read_len);
                        md5_ret = ffs_cert_md5_check(p_cert_info->md5);
                        ffs_cert_md5_release();

                        if (SDK_FAIL == md5_ret)
                        {
                            vesync_report_ffs_cert_update(ffs_cert, FFS_CERT_UP_VERIFY_ERR); //md5校验失败
                            goto _exit;
                        }

                        if (ffs_cert_pk_parse((uint8_t *)p_ca_buff, read_len + 1) == SDK_FAIL) //校验私钥证书格式
                        {
                            vesync_report_ffs_cert_update(ffs_cert, FFS_CERT_UP_PARSE_ERR);
                            goto _exit;
                        }
                        vesync_report_ffs_cert_update(ffs_cert, FFS_CERT_UP_OK);
                    }
                }
                else
                {
                    SDK_LOG(LOG_ERROR, "\n vesync_malloc failed\n");
                }
            }
            else
            {
                SDK_LOG(LOG_ERROR, "read ffs private key err\r\n");
            }
        }
        else
        {
            SDK_LOG(LOG_ERROR, "cert get mode err\n");
        }
    }

_exit:
    if (p_ca_buff)
    {
        VCOM_SAFE_FREE(p_ca_buff);
    }
    ffs_update_certificate_taskhd = NULL;
}

/**
* @brief  产测更新证书
* @param[in]  info    [更新证书信息]
* @return int         [成功/失败]
*/
int vesync_ffs_certificate_update_start(ffs_update_certificate_info_t info)
{
    if (NULL != ffs_update_certificate_taskhd)
    {
        SDK_LOG(LOG_ERROR, "production certificate update task running...\n");
        return SDK_FAIL;
    }

    memset(&s_update_certificate, 0, sizeof(ffs_update_certificate_info_t));

    s_update_certificate.get_mode = info.get_mode;
    snprintf(s_update_certificate.url, sizeof(s_update_certificate.url), "%s", info.url);
    strncpy(s_update_certificate.md5, info.md5, sizeof(s_update_certificate.md5));

    int ret = vesync_task_new(CERTIFICATE_UPDATE_TASK_NAME,
                                NULL,
                                vesyn_ffs_certificate_update_task,
                                NULL,
                                CERTIFICATE_UPDATE_TASK_STACKSIZE,
                                CERTIFICATE_UPDATE_TASK_PRIO,
                                &ffs_update_certificate_taskhd);
    if (ret != VOS_OK)
    {
        SDK_LOG(LOG_ERROR, "certificate update task.\n");
        return SDK_FAIL;
    }

    return SDK_OK;
}
#endif
