/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
 * @file        vesync_nfc_card.c
 * @brief       nfc模块card通信模块接口实现
 * @date        2021-11-13
 */
#include "vesync_common.h"
#include "vesync_log_internal.h"
#include "vesync_cfg.h"
#include "vesync_log.h"
#include "stdio.h"
#include "string.h"
#include "vesync_memory.h"
#include "vesync_task.h"
#include "vhal_i2c.h"
#include "vhal_gpio.h"
#include "vesync_nfc_card.h"
#include "vesync_nfc_card_internal.h"
#include "vesync_memory.h"
#include "vesync_task.h"
#include "vesync_cfg_internal.h"
#include "vesync_nfc.h"

// nfc任务句柄
static vesync_task_t s_hal_nfc_taskhd = NULL;

//nfc 事件回调函数
static vesync_nfc_card_evt_cb_t s_event_call_back_func = NULL;

//nfc 数据接收回调函数
static vesync_nfc_card_data_recv_cb_t s_data_recv_call_back_func = NULL;

//nfc 卡实例定义
static vesync_nfc_card_info_t vesync_nfc_card_instance;

/**
 * @brief  NFC卡唤醒回调处理
 * @param[in]  para    [驱动层传回相关参数]
 */
void vesync_nfc_card_wake_up_handle(uint8_t para)
{
    if ((vesync_nfc_card_instance.netcfg_started == 1) && (STATUS_NETCFG_IDLE == vesync_nfc_card_instance.netcfg_status))
    {
        vesync_nfc_card_instance.netcfg_status = STATUS_RFID_WRITE_DATA;
        vesync_nfc_card_instance.wait_cnt = 0;
    }
}

void vesync_nfc_card_reg_recv_cb(vesync_nfc_card_data_recv_cb_t cb)
{
    s_data_recv_call_back_func = cb;
}

void vesync_nfc_card_reg_event_cb(vesync_nfc_card_evt_cb_t cb)
{
    s_event_call_back_func = cb;
}

uint32_t vesync_nfc_card_stop_netcfg(void)
{
    vesync_nfc_card_instance.netcfg_started = 0;
    vesync_nfc_card_instance.netcfg_status = STATUS_NETCFG_IDLE;
    return SDK_OK;
}

/**
 * @brief nfc数据处理任务
 * @param[in]  pvParameters             [未使用]
 */
static void vesync_nfc_card_task(void *pvParameters) //此处有硬件操作，以及调起应用层回调，因此用任务不用timer
{
    uint8_t *nfc_data = NULL;
    uint32_t event = NFC_EVT_NETCFG_OK;
    uint16_t i = 0;

    while (1)
    {
        if (vesync_nfc_card_instance.netcfg_status == STATUS_RFID_WRITE_DATA)
        {
            vesync_nfc_card_instance.wait_cnt++;
            VESYNC_NFC_CARD_LOG(LOG_DEBUG, "wait write cnt =%d\r\n", vesync_nfc_card_instance.wait_cnt);
            if (vesync_nfc_card_instance.wait_cnt >= vesync_nfc_card_instance.card_info.wake_up_ctrl.wait_time_after_wakeup_s)
            {
                vesync_nfc_card_instance.netcfg_status = STATUS_WIFI_READ_DATA;
                VESYNC_NFC_CARD_LOG(LOG_DEBUG, "now we can read data\r\n");
            }
        }
        else if (vesync_nfc_card_instance.netcfg_status == STATUS_WIFI_READ_DATA) //等待超时或手机离开读NFC卡数据
        {
            VESYNC_NFC_CARD_LOG(LOG_DEBUG, "read nfc data now\r\n");
            if (NULL == (nfc_data = vesync_malloc(vesync_nfc_card_instance.card_info.basic_info.netcfg_info_len)))
            {
                event = NFC_EVT_INTERNAL_ERROR;
                SDK_LOG(LOG_ERROR, "malloc error\r\n");
            }
            else
            {
                if (vesync_nfc_card_instance.card_info.read_cb)
                {
                    if (vesync_nfc_card_instance.card_info.read_cb(vesync_nfc_card_instance.card_info.basic_info.netcfg_info_addr,
                                                                   nfc_data, vesync_nfc_card_instance.card_info.basic_info.netcfg_info_len) != SDK_OK)
                    {
                        event = NFC_EVT_DATA_READ_ERROR;
                        SDK_LOG(LOG_ERROR, "read error\r\n");
                    }
                    else
                    {
                        if (s_data_recv_call_back_func)
                        {
                            s_data_recv_call_back_func(nfc_data, vesync_nfc_card_instance.card_info.basic_info.netcfg_info_len);
                        }
                    }
                }

                vesync_free(nfc_data);
            }

            if (s_event_call_back_func) //将数据通过回调传给vesync 层
            {
                s_event_call_back_func(event);
            }

            //停止配网处理,删除线程
            vesync_nfc_card_stop_netcfg();
        }
        vesync_sleep(1000);

        VESYNC_NFC_CARD_LOG(LOG_INFO, "run i =%d \r\n", i++);

        if (vesync_nfc_card_instance.netcfg_started == 0)
        {
            s_hal_nfc_taskhd = NULL;
            break;
        }
    }
}

uint32_t vesync_nfc_card_start_netcfg(void)
{
    vesync_nfc_card_instance.netcfg_started = 1;
    vesync_nfc_card_instance.netcfg_status = STATUS_NETCFG_IDLE;
    vesync_nfc_card_instance.wait_cnt = 0;

    if (s_hal_nfc_taskhd == NULL)
    {
        if (VOS_OK != vesync_task_new(VESYNC_NFC_CARD_TASK_NAME, NULL, vesync_nfc_card_task, NULL, VESYNC_NFC_CARD_TASK_STACK_SIZE, VESYNC_NFC_CARD_TASK_PRIO, &s_hal_nfc_taskhd))
        {
            SDK_LOG(LOG_ERROR, "Create nfc task fail!!!\n");
            return SDK_FAIL;
        }
        else
        {
            SDK_LOG(LOG_DEBUG, "Create nfc task success\n");
            return SDK_OK;
        }
    }
    return SDK_OK;
}

uint32_t vesync_nfc_card_netcfg_data_send(VESYNC_NFC_CARD_DATA_TYPE_E data_type, uint8_t *p_data, uint16_t len)
{
    uint16_t addr = 0;

    if (data_type == TYPE_DEV)
    {
        addr = vesync_nfc_card_instance.card_info.basic_info.dev_info_addr;
    }
    else if (data_type == TYPE_NETCFG_ERR_INFO)
    {
        addr = vesync_nfc_card_instance.card_info.basic_info.netcfg_error_info_addr;
    }
#if 1
    else if (data_type == TYPE_NETCFG_INFO) //for test
    {
        addr = vesync_nfc_card_instance.card_info.basic_info.netcfg_info_addr;
    }
#endif

    if (addr != 0)
    {
        return vesync_nfc_card_instance.card_info.write_data_cb(addr, p_data, len);
    }
    else
    {
        return SDK_FAIL;
    }
}

uint32_t vesync_nfc_card_get_uid(char *dev_uid, uint32_t max_len)
{
    if ((dev_uid == NULL) || (max_len < VESYNC_NFC_CARD_PWD_MAX_LEN))
    {
        return SDK_FAIL;
    }
    //此处增加获取uid代码
    return SDK_OK;
}

uint32_t vesync_nfc_card_create(vesync_nfc_card_ctrl_t *nfc_card_ctrl)
{
    if (nfc_card_ctrl == NULL)
    {
        return SDK_FAIL;
    }

    memset(&vesync_nfc_card_instance, 0, sizeof(vesync_nfc_card_instance));
    vesync_nfc_card_instance.card_id = 1;
    memcpy(&vesync_nfc_card_instance.card_info, nfc_card_ctrl, sizeof(vesync_nfc_card_ctrl_t));

#if defined(CONFIG_NFC_CARD_INTERFACE) && (CONFIG_NFC_CARD_INTERFACE == CARD_INTERFACE_IIC)
    if (nfc_card_ctrl->interface_init_cb.iic_init_cb)
    {
        nfc_card_ctrl->interface_init_cb.iic_init_cb(nfc_card_ctrl->hw_interface.iic_ctrl.sda_pin,
                                                     nfc_card_ctrl->hw_interface.iic_ctrl.scl_pin, nfc_card_ctrl->hw_interface.iic_ctrl.iic_cs_pin);
    }
#endif

    if ((nfc_card_ctrl->wake_up_init_cb) && (nfc_card_ctrl->nfc_card_wake_up_isr_register_cb))
    {
        nfc_card_ctrl->wake_up_init_cb(nfc_card_ctrl->wake_up_ctrl.wake_up_en);
        nfc_card_ctrl->nfc_card_wake_up_isr_register_cb(vesync_nfc_card_wake_up_handle, nfc_card_ctrl->wake_up_ctrl.wake_up_pin);
    }

    if (nfc_card_ctrl->psw_inti_cb)
    {
        nfc_card_ctrl->psw_inti_cb(nfc_card_ctrl->psw_ctrl.psw_en, nfc_card_ctrl->psw_ctrl.psw, nfc_card_ctrl->psw_ctrl.psw_ack);
    }

    if (nfc_card_ctrl->sleep_init_cb)
    {
        nfc_card_ctrl->sleep_init_cb(nfc_card_ctrl->sleep_ctrl.sleep_en, nfc_card_ctrl->sleep_ctrl.sleep_pin);
    }

    return SDK_OK;
}
