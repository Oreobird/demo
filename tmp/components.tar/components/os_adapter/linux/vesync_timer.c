/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_timer.c
 * @brief       timer抽象层，封装linux posix定时器相关接口
 * @author      Joshua
 * @date        2021-04-20
 */
#include <stdbool.h>
#include <unistd.h>
#include <time.h>
#include <signal.h>
#include <stdio.h>

#include "vesync_common.h"
#include "vesync_timer.h"

typedef void (*sigev_notify_fn)(union sigval);

/*
 * @brief  创建定时器
 * @param[in]  timer                 [定时器结构体指针]
 * @param[in]  cb                    [timout回调函数]
 * @param[in]  cb_arg                [回调函数输入参数]
 * @param[in]  timeout_ms            [超时时间，单位毫秒]
 * @param[in]  reload                [定时类型:
 *                                    false：一次
 *                                    true：周期性]
 * @return int                       [成功：0；失败：-1]
 */
int vesync_timer_new(vesync_timer_t *timer,
                            char *name,
                            void (*cb)(void*),
                            void *cb_arg,
                            long timeout_ms,
                            bool reload)
{
    UNUSED(name);
    VCOM_NULL_PARAM_CHK(timer, return -1);

    int ret = -1;
    struct sigevent sev;
    timer_t timer_id;

    sev.sigev_notify = SIGEV_THREAD;
    sev.sigev_value.sival_ptr = cb_arg;
    sev.sigev_notify_function = (sigev_notify_fn)cb;
    sev.sigev_notify_attributes = NULL;

    ret = timer_create(CLOCK_REALTIME, &sev, &timer_id);
    if (ret != 0)
    {
        return -1;
    }

    timer->timeout_ms = timeout_ms;
    timer->reload = reload;
    timer->handle = timer_id;

    return 0;
}

/*
* @brief  启动定时器
* @param[in]  timer                   [定时器结构体指针]
* @return int                         [成功：0；失败：返回-1]
*/
int vesync_timer_start(vesync_timer_t *timer)
{
    VCOM_NULL_PARAM_CHK(timer, return -1);
    VCOM_NULL_PARAM_CHK(timer->handle, return -1);

    int ret = -1;
    struct itimerspec its;

    its.it_value.tv_sec = timer->timeout_ms / 1000;
    its.it_value.tv_nsec = (timer->timeout_ms % 1000) * 1000000;

    its.it_interval.tv_sec = (timer->reload == true) ? its.it_value.tv_sec : 0;
    its.it_interval.tv_nsec = (timer->reload == true) ? its.it_value.tv_nsec : 0;

    ret = timer_settime(timer->handle, TIMER_ABSTIME, &its, NULL);
    if (ret < 0)
    {
        return -1;
    }

    return 0;
}

/*
 * @brief  停止定时器
 * @param[in]  timer                   [定时器结构体指针]
 * @return int                         [成功：0；失败：返回-1]
 */
int vesync_timer_stop(vesync_timer_t *timer)
{
    VCOM_NULL_PARAM_CHK(timer, return -1);
    VCOM_NULL_PARAM_CHK(timer->handle, return -1);

    int ret = -1;
    struct itimerspec its;
    its.it_value.tv_sec = 0;
    its.it_value.tv_nsec = 0;

    its.it_interval.tv_sec = 0;
    its.it_interval.tv_nsec = 0;

    ret = timer_settime(timer->handle, TIMER_ABSTIME, &its, NULL);
    if (ret < 0)
    {
        return -1;
    }

    return 0;
}

/**
* @brief 修改计时周期
* @param[in] timer                    [定时器结构体指针]
* @param[in] timeout_ms               [超时时间]
* @return int                         [成功：VOS_OK；失败：VOS_FAIL]
*/
int vesync_timer_change_period(vesync_timer_t *timer, long timeout_ms)
{
    VCOM_NULL_PARAM_CHK(timer, return -1);
    VCOM_NULL_PARAM_CHK(timer->handle, return -1);

    int ret = -1;
    struct itimerspec its;

    timer->timeout_ms = timeout_ms;

    its.it_value.tv_sec = timer->timeout_ms / 1000;
    its.it_value.tv_nsec = (timer->timeout_ms % 1000) * 1000000;

    its.it_interval.tv_sec = (timer->reload == true) ? its.it_value.tv_sec : 0;
    its.it_interval.tv_nsec = (timer->reload == true) ? its.it_value.tv_nsec : 0;

    ret = timer_settime(timer->handle, TIMER_ABSTIME, &its, NULL);
    if (ret < 0)
    {
        return -1;
    }

    return 0;
}

/*
 * @brief  删除定时器
 * @param[in]  timer                   [定时器结构体指针]
 * @return int                         [成功：0；失败：返回-1]
 */
int vesync_timer_free(vesync_timer_t *timer)
{
    VCOM_NULL_PARAM_CHK(timer, return -1);
    VCOM_NULL_PARAM_CHK(timer->handle, return -1);

    timer_delete(timer->handle);
    return 0;
}


