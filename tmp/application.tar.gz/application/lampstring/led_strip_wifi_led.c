/**
*Copyright © Vesync Technologies Co.Ltd. 2022. All rights reserved.
* @file    led_strip_wifi_led.c
* @brief   Wi-Fi指示灯配置
* @author  Lind
*@date     2022-01-05
*/

#include <string.h>

#include "vesync_common.h"
#include "vesync_wifi_led.h"
#include "vesync_log.h"
#include "vesync_netcfg.h"

#include "led_strip_wifi_led.h"
#include "led_strip.h"
#include "led_strip_report.h"

static bool s_ls_netcfg_flag = false;   // 配网标志位

/**
* @brief wifi led控制回调
* @param[in]  status    [led状态]
*/
static void ls_wifi_led_ctrl_cb(WIFI_LED_IO_STATUS_E status)
{
    ls_ev_t ev;

    switch (status)
    {
        case WIFI_LED_IO_LED_OFF:
            break;
        case WIFI_LED_IO_LED_ON:
            ev.id = LS_EV_TURN_ON;
            ev.act_src = LS_ACT_SRC_WIFI_LED;
            ev.scene_id = 1;
            ev.mode = LS_MODE_WHITE;
            ls_app_task_notify(&ev);
            break;
        case WIFI_LED_IO_CUSTOM_MODE:
            ev.id = LS_EV_BEFORE_NETCFG;
            ev.act_src = LS_ACT_SRC_WIFI_LED;
            ev.scene_id = 20;
            ls_app_task_notify(&ev);
            s_ls_netcfg_flag = true;
            break;
        case WIFI_LED_IO_BREATHING:
            break;
        case WIFI_LED_IO_DISABLE:
        default:
            break;
    }
}

/**
* @brief wifi 连接成功回调
*/
static void led_strip_wifi_success_cb(void)
{
    if (s_ls_netcfg_flag == true)
    {
        ls_ev_t ev;
        ev.id = LS_EV_TURN_ON;
        ev.act_src = LS_ACT_SRC_WIFI_LED;
        ev.scene_id = 1;
        ev.mode = LS_MODE_WHITE;
        ls_report_set_chg_rsn(STAT_CHG_RSN_CONFIG_NET_STR);
        ls_app_task_notify(&ev);
    }

    s_ls_netcfg_flag = false;
}

/**
* @brief  灯效配置
* @return     int             [成功/失败]
*/
int ls_reg_wifi_led(void)
{
    wifi_led_info_t led_cfg;

    memset(&led_cfg, 0, sizeof(led_cfg));

    // 未配网，灯效配置
    led_cfg.led_not_config.status = WIFI_LED_CUSTOM_MODE;
    led_cfg.led_not_config.blink_ms = 500; // 500ms
    led_cfg.led_not_config.off_times = 1;
    led_cfg.led_not_config.blink_times = 5;

    // 配网中
    led_cfg.led_config_net.status = WIFI_LED_ON;
    led_cfg.led_config_net.blink_ms = 500;
    led_cfg.led_config_net.off_times = 1;
    led_cfg.led_config_net.blink_times = 0;

    // FFS配网中
    led_cfg.led_ffs_config_net.status = WIFI_LED_ON;
    led_cfg.led_ffs_config_net.blink_ms = 500;
    led_cfg.led_ffs_config_net.off_times = 1;
    led_cfg.led_ffs_config_net.blink_times = 0;

    // 注册所有情况的灯效规则
    vesync_wifi_led_info_set(led_cfg);

    // 注册闪灯实现函数
    vesync_wifi_led_reg_ctrl_cb(ls_wifi_led_ctrl_cb, NULL);

    // 注册配网成功实现函数
    vesync_net_cfg_reg_success_cb(led_strip_wifi_success_cb);

    return APP_OK;
}


