/**
*Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file     ledstrip_device_impl.c
* @brief    设备业务处理
* @author   Joshua
*@date      2021-12-1
*/
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include "vesync_log.h"
#include "vesync_memory.h"
#include "vesync_common.h"
#include "vesync_flash.h"
#include "vesync_klv.h"
#include "app_cfg.h"
#include "flash.h"
#include "scene.h"

static int ext_cfg_set(flash_t *thiz, uint8_t *p_buf, uint32_t buf_len, uint32_t *ofs, extra_cfg_t *extra_cfg)
{
    if (extra_cfg->seg_param != NULL)
    {
        *ofs +=  vesync_klv_set(p_buf + (*ofs), buf_len - (*ofs), KEY_SEG_LIGHT_PARAM,
                                sizeof(light_color_t) * (thiz->cfg.seg_num), (uint8_t*)extra_cfg->seg_param);
    }

    return APP_OK;
}

static int ext_cfg_get(flash_t *thiz, uint8_t *p_buf, uint32_t buf_len, extra_cfg_t *extra_cfg)
{
    if (extra_cfg->seg_param != NULL)
    {
        vesync_klv_get(p_buf, buf_len, KEY_SEG_LIGHT_PARAM, sizeof(light_color_t) * (thiz->cfg.seg_num),
                        (uint8_t*)extra_cfg->seg_param);
    }

    return APP_OK;
}

static uint32_t buf_len_cal(flash_t *thiz)
{
    UNUSED(thiz);
    return sizeof(flash_cfg_t) + sizeof(light_color_t) * (LIGHT_SEGMENT_MAX_NUM);
}

static void default_init(flash_t *thiz)
{
    thiz->cfg.light_param.H = LIGHT_DEFAULT_H;
    thiz->cfg.light_param.S = LIGHT_DEFAULT_S;
    thiz->cfg.light_param.V = LIGHT_DEFAULT_V;
    thiz->cfg.light_param.brightness = LIGHT_DEFAULT_BRIGHTNESS;
    thiz->cfg.light_param.color_temp = LIGHT_DEFAULT_COLOR_TEMP;
    thiz->cfg.bead_num = LIGHT_NODE_NUM;
    thiz->cfg.mode = LIGHT_MODE_WHITE;
    thiz->cfg.onoff = LIGHT_STATUS_OFF;
    thiz->cfg.scene_id = SCENE_DEFAULT_ID_MIN + 1; // TODO

    thiz->cfg.seg_num = 1;
    memset(thiz->cfg.extra.seg_param, 0, LIGHT_SEGMENT_MAX_NUM * sizeof(light_color_t));
}

flash_t *app_flash_create(void)
{
    flash_t *thiz = (flash_t *)vesync_malloc(sizeof(flash_t) + LIGHT_SEGMENT_MAX_NUM * sizeof(light_color_t));
    if (thiz  == NULL)
    {
        APP_LOG(LOG_ERROR, "app flash create fail\n");
        return NULL;
    }

    memset(thiz , 0, sizeof(flash_t));

    thiz->len_cal = buf_len_cal;
    thiz->ext_set = ext_cfg_set;
    thiz->ext_get = ext_cfg_get;
    thiz->default_init = default_init;
    return thiz;
}

