/**
 * Copyright © Etekcity Technologies Co., Ltd. 2019-2099. All rights reserved.
 * @file ffs_rtos_configuration_map.h
 * @brief Ffs RTOS configuration map
 * @author  Owen.zhang
 * @date    2020-04-22
 */

#ifndef FFS_RTOS_CONFIGURATION_MAP_H_
#define FFS_RTOS_CONFIGURATION_MAP_H_

#include "ffs/common/ffs_configuration_map.h"
#include "ffs/common/ffs_result.h"
#include "ffs/common/ffs_stream.h"

/*
 * @brief Ffs configuration map structure.
 */
typedef struct FfsRTOSConfigMap_s
{
        FfsStream_t manufacturerStream;
        FfsStream_t modelNumberStream;
        FfsStream_t serialNumberStream;
        FfsStream_t softwareVersionIndexStream;
        FfsStream_t pinStream;
        FfsStream_t hardwareRevisionStream;
        FfsStream_t firmwareRevisionStream;
        FfsStream_t cpuIdStream;
        FfsStream_t deviceNameStream;
        FfsStream_t productIndexStream;
} FfsRTOSConfigMap_t;

/** @brief Initialize the Ffs Wi-Fi Linux configuration map.
 *
 * @param configurationMap Ffs Wi-Fi Linux configuration map structure
 *
 * @returns Enumerated [result](@ref FFS_RESULT)
 */
FFS_RESULT ffsInitializeConfigurationMap(FfsRTOSConfigMap_t *configurationMap);

/** @brief Deinitialize the Ffs Wi-Fi Linux configuration map.
 *
 * @param configurationMap Ffs Wi-Fi Linux configuration map structure
 *
 * @returns Enumerated [result](@ref FFS_RESULT)
 */
FFS_RESULT ffsDeinitializeConfigurationMap(FfsRTOSConfigMap_t *configurationMap);

/** @brief Set a configuration value (\a e.g., country code) in the configuration map.
 *
 * @param userContext User context
 * @param configurationKey The configuration key string
 * @param configurationValue The configuration value to set
 *
 * @returns Enumerated [result](@ref FFS_RESULT)
 */
FFS_RESULT ffsSetConfigurationMapValue(struct FfsUserContext_s *userContext, const char *configurationKey,
                                       FfsMapValue_t *configurationValue);

/** @brief Get a configuration value (\a e.g., country code) from the configuration map.
 *
 * @param userContext User context
 * @param configurationKey The configuration key string
 * @param configurationValue The destination configuration value
 *
 * @returns Enumerated [result](@ref FFS_RESULT)
 */
FFS_RESULT ffsGetConfigurationMapValue(struct FfsUserContext_s *userContext, const char *configurationKey,
                                       FfsMapValue_t *configurationValue);

/** @brief init configuration value (\a e.g., country code) from the configuration map.
 *
 * @param stream the config key
 * @param entry  the strean string value
 * @param buffSize The malloc buff len
 *
 * @returns Enumerated [result](@ref FFS_RESULT)
 */
FFS_RESULT ffsInitializeEntryStream(FfsStream_t *stream, const char *entry, uint8_t buffSize);

FFS_RESULT ffsDeinitializeEntryStream(FfsStream_t *stream);

#endif
