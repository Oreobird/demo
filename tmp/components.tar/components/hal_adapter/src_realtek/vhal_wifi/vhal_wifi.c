/**
 *  Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
 * @file        vhal_wifi.c
 * @brief       Wi-Fi驱动抽象层，封装厂家Realtek SDK提供的Wi-Fi相关接口
 * @author      Dongri.Su
 * @date        2021-04-22
 */

#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/timers.h"
#include <lwip/inet.h>

#include "wifi_constants.h"
#include "wifi_structures.h"
#include "lwip_netconf.h"
#include "wifi_conf.h"
#include "dhcp/dhcps.h"
#include "wifi_ind.h"
#include "wifi_util.h"
#include "ip_addr.h"
#include "ip4_addr.h"

#include "vesync_log.h"

#include "vhal_wifi_internal.h"


static TimerHandle_t s_rtl_ip_timer_hd = NULL;              // 定时查询IP地址是否存在的定时器句柄

static vhal_rtl_wifi_cfg_t s_rtl_wifi_cfg;                  // Wi-Fi运行配置
static vhal_rtl_wifi_status_t s_rtl_wifi_status;            // Wi-Fi运行状态


/*-----------------------------------------------------------------------------*
 *                           内部函数API实现                                         *
 *-----------------------------------------------------------------------------*/

/*
 * @brief 1秒钟判断一次是否获取到IP地址
 * @param arg        参数(未使用)
 * @return void
 */
static void vhal_rtl_ip_check(void *arg)
{
    char ip_buf[20] = {0};      // 保存ip空间
    if (NULL != vhal_wifi_get_sta_ip(ip_buf, sizeof(ip_buf)))
    {
        wifi_indication(WIFI_EVENT_STA_GOT_IP, NULL, 0, 0);
        //vhal_rtl_ip_timer_stop();
    }
}


/**
 * @brief 创建并启动IP地址获取定时器
 * @return  void
 */
static void vhal_rtl_ip_timer_start(void)
{
    if (NULL == s_rtl_ip_timer_hd)
    {
        // 创建数据记录定时器，自动加载
        s_rtl_ip_timer_hd = xTimerCreate("ip_check", pdMS_TO_TICKS(1000), pdTRUE, NULL, vhal_rtl_ip_check);
    }

    if (NULL != s_rtl_ip_timer_hd)
    {
        if (xTimerIsTimerActive(s_rtl_ip_timer_hd) == pdFALSE)      // The timer is not running.
        {
            HAL_LOG(LOG_DEBUG, "Timer is not start.\n");
            if (xTimerStart(s_rtl_ip_timer_hd, portMAX_DELAY) != pdPASS)
            {
                HAL_LOG(LOG_ERROR, "Timer start fail!!\n");
            }
            else
            {
                HAL_LOG(LOG_DEBUG, "Timer start succ\n");
            }
        }
        else
        {
            HAL_LOG(LOG_DEBUG, "Timer is already running.\n");
        }
    }
    else
    {
        HAL_LOG(LOG_ERROR, "Timer create fail!!\n");
    }
}

/**
 * @brief 停止IP地址获取定时器
 * @return  void
 */
static void vhal_rtl_ip_timer_stop(void)
{
    if (NULL != s_rtl_ip_timer_hd)
    {
        if (xTimerStop(s_rtl_ip_timer_hd, portMAX_DELAY) == pdPASS)
        {
            if (xTimerDelete(s_rtl_ip_timer_hd, portMAX_DELAY) == pdPASS)
            {
                s_rtl_ip_timer_hd = NULL;
            }
        }
    }
    HAL_LOG(LOG_DEBUG, "Timer was stoped\n");
}

/**
 * @brief  作为STA时，获取到IP后回调
 * @param[in]  char*            []
 * @param[in]  int              []
 * @param[in]  int              []
 * @param[in]  void*            []
 * @return    void
 */
static void vhal_rtl_wifi_sta_got_ip_hdl(char* buf, int buf_len, int flags, void* userdata)
{
    /* To avoid gcc warnings */
    ( void ) buf;
    ( void ) buf_len;
    ( void ) flags;
    ( void ) userdata;

    HAL_LOG(LOG_DEBUG, "Wi-Fi STA got ip event.\n");
}

/**
 * @brief  作为STA时，IP丢失回调
 * @param[in]  char*            []
 * @param[in]  int              []
 * @param[in]  int              []
 * @param[in]  void*            []
 * @return    void
 */
static void vhal_rtl_wifi_sta_lost_ip_hdl(char* buf, int buf_len, int flags, void* userdata)
{
    /* To avoid gcc warnings */
    ( void ) buf;
    ( void ) buf_len;
    ( void ) flags;
    ( void ) userdata;

    HAL_LOG(LOG_DEBUG, "Wi-Fi STA lost ip event\n");
}


/*
 * @brief  注册_WIFI_EVENT_INDICATE中19~24的事件回调
 * @return int                  [成功]
 */
static int vhal_rtl_wifi_event_init(void)
{
    wifi_reg_event_handler(WIFI_EVENT_STA_GOT_IP, vhal_rtl_wifi_sta_got_ip_hdl, NULL);
    wifi_reg_event_handler(WIFI_EVENT_STA_LOST_IP, vhal_rtl_wifi_sta_lost_ip_hdl, NULL);

    return VHAL_OK;
}

/*
 * @brief  AP模式，重置IP地址为192.168.4.1
 * @param[in]  netif*            [SDK中定义的结构体]
 * @return  void
 */
static void vhal_rtl_wifi_reset_ip_addr(struct netif *pnetif)
{
    struct ip_addr ipaddr;
    struct ip_addr netmask;
    struct ip_addr gw;

    IP4_ADDR(ip_2_ip4(&ipaddr), VHAL_RTL_GW_ADDR0, VHAL_RTL_GW_ADDR1, VHAL_RTL_GW_ADDR2, VHAL_RTL_GW_ADDR3);
    IP4_ADDR(ip_2_ip4(&netmask), VHAL_RTL_NETMASK_ADDR0, VHAL_RTL_NETMASK_ADDR1 , VHAL_RTL_NETMASK_ADDR2, VHAL_RTL_NETMASK_ADDR3);
    IP4_ADDR(ip_2_ip4(&gw), VHAL_RTL_GW_ADDR0, VHAL_RTL_GW_ADDR1, VHAL_RTL_GW_ADDR2, VHAL_RTL_GW_ADDR3);
    netif_set_addr(pnetif, ip_2_ip4(&ipaddr), ip_2_ip4(&netmask),ip_2_ip4(&gw));
}

/*
 * @brief  获取设备网络信息(gw/mask/dns)
 * @return  void
 */
static void vhal_rtl_wifi_get_netif_info(void)
{
    char ip_buf[IP_ADDR_STR_MAX_LEN] = {0};          // 保存IP空间
    char gw_buf[IP_ADDR_STR_MAX_LEN] = {0};          // 保存gw空间
    char mask_buf[IP_ADDR_STR_MAX_LEN] = {0};        // 保存mask空间
    //char dns_buf[IP_ADDR_STR_MAX_LEN] = {0};         // 保存dns空间
    uint8_t *p_buf = NULL;
    struct ip_addr dns;

    // 声明位置\sdk\rtl-amebaz2_v7.1c\component\common\api\lwip_netconf.c
    extern struct netif xnetif[NET_IF_NUM];
    struct netif *p_netif = &xnetif[0];     // sta interface

    p_buf = LwIP_GetIP(p_netif);
    if (NULL != p_buf)
    {
        snprintf(ip_buf, sizeof(ip_buf), "%d.%d.%d.%d", p_buf[0], p_buf[1], p_buf[2], p_buf[3]);
    }

    p_buf = NULL;
    p_buf = LwIP_GetGW(p_netif);
    if (NULL != p_buf)
    {
        snprintf(gw_buf, sizeof(gw_buf), "%d.%d.%d.%d", p_buf[0], p_buf[1], p_buf[2], p_buf[3]);
    }

    p_buf = NULL;
    p_buf = LwIP_GetMASK(p_netif);
    if (NULL != p_buf)
    {
        snprintf(mask_buf, sizeof(mask_buf), "%d.%d.%d.%d", p_buf[0], p_buf[1], p_buf[2], p_buf[3]);
    }

    LwIP_GetDNS(&dns);
    //snprintf(dns_buf, sizeof(dns_buf), "%d.%d.%d.%d", ip4_addr1(dns), ip4_addr2(dns), ip4_addr3(dns), ip4_addr4(dns));
    HAL_LOG(LOG_DEBUG, "Device got IP: %s, GW: %s, mask: %s, DNS: %s.\n", ip_buf, gw_buf, mask_buf, ip4addr_ntoa(&dns));
}

/*
 * @brief 认证方式转换
 * @param[in]  mode                 [驱动返回的auth mode]
 * @return     int                  [转换后的auth mode]
 */
static VHAL_WIFI_AUTH_MODE_E vhal_rtl_wifi_conv_auth_mode(rtw_security_t mode)
{
    switch (mode)
    {
        case RTW_SECURITY_OPEN:
            return VHAL_WIFI_AUTH_OPEN;

        case RTW_SECURITY_WEP_PSK:
        case RTW_SECURITY_WEP_SHARED:
            return VHAL_WIFI_AUTH_WEP;

        case RTW_SECURITY_WPA_TKIP_PSK:
        case RTW_SECURITY_WPA_AES_PSK:
            return VHAL_WIFI_AUTH_WPA_PSK;

        case RTW_SECURITY_WPA2_AES_PSK:
        case RTW_SECURITY_WPA2_TKIP_PSK:
        case RTW_SECURITY_WPA2_MIXED_PSK:
            return VHAL_WIFI_AUTH_WPA2_PSK;

        case RTW_SECURITY_WPA_WPA2_MIXED:
        case RTW_SECURITY_WPA2_AES_CMAC:
            return VHAL_WIFI_AUTH_WPA_WPA2_PSK;

        case RTW_SECURITY_WPA2_ENTERPRISE:
        case RTW_SECURITY_WPA_WPA2_ENTERPRISE:
            return VHAL_WIFI_AUTH_WPA2_ENTERPRISE;

        case RTW_SECURITY_WPA3_AES_PSK:
            return VHAL_WIFI_AUTH_WPA3_PSK;

        default:
            return VHAL_WIFI_AUTH_MAX;
    }
}

/*
 * @brief  更新Wi-Fi状态，当状态发生改变时通知上层
 * @param[in]  status                   [Wi-Fi状态]
 * @return void
 */
static void vhal_rtl_wifi_update_status(VHAL_WIFI_STATUS_E status)
{
    /* 网络状态发生改变，主动通知上一层(消息处理中心)     */
    s_rtl_wifi_status.net_status = _status;
    HAL_LOG(LOG_DEBUG, "Wi-Fi new status is %d\n", status);
    // 定义：vesync_connect_wifi_callback()
    if(NULL != s_rtl_wifi_status.status_cb)
    {
        s_rtl_wifi_status.status_cb(status);
    }
}

/*
 * @brief  获取Wi-Fi的连接失败时的错误原因
 * @return  void
 */
static void vhal_rtl_wifi_get_connect_fail_rsn(void)
{
    int error_flag = wifi_get_last_error();
    HAL_LOG(LOG_ERROR, "Wi-Fi connect fail, err: %d.\n", error_flag);
    switch (error_flag)
    {
        // Cannot scan AP
        case RTW_NONE_NETWORK:
            vhal_wifi_set_status(VHAL_WIFI_NO_AP_FOUND);
            if(NULL != s_rtl_wifi_status.disc_log_cb)
                s_rtl_wifi_status.disc_log_cb("RTL_NO_AP_FOUND");
            break;

        // Connection fail caused by auth/assoc failure
        case RTW_CONNECT_FAIL:
            vhal_wifi_set_status(VHAL_WIFI_CONNECT_FAIL);
            if(NULL != s_rtl_wifi_status.disc_log_cb)
                s_rtl_wifi_status.disc_log_cb("RTL_CONNECTION_FAIL");
            break;

        // Password length incorrect or not the same password as AP used
        case RTW_WRONG_PASSWORD:
        case RTW_4WAY_HANDSHAKE_TIMEOUT:
            vhal_rtl_wifi_update_status(VHAL_WIFI_WRONG_PWD);
            if(NULL != s_rtl_wifi_status.disc_log_cb)
                s_rtl_wifi_status.disc_log_cb("RTL_WRONG_PWD");
            break;

        // Unexpected error
        default:
            vhal_wifi_set_status(VHAL_WIFI_CONNECT_FAIL);
            if(NULL != s_rtl_wifi_status.disc_log_cb)
                s_rtl_wifi_status.disc_log_cb("RTL_CONNECTION_FAIL");
            //HAL_LOG(LOG_ERROR, "Unexpected connection failure\n");
            break;
    }
}

/*
 * @brief  设置国家码
 * @param[in]  p_country_code               [国家码，字符串长度为2byte]
 * @return void
 */
static void vhal_rtl_wifi_set_country_code(char *p_country_code)
{
    if (0 == strcmp(s_rtl_wifi_cfg.country_code, "JP"))
    {
        wifi_set_country(RTW_COUNTRY_JP);
    }
    else if (0 == strcmp(s_rtl_wifi_cfg.country_code, "US"))
    {
        wifi_set_country(RTW_COUNTRY_US);
    }
    else
    {
        wifi_set_country(RTW_COUNTRY_CN);       // 设置国家码，2.4G可以工作的信道范围1~13，
    }
}


/*
 * @brief  Wi-Fi连接
 * @return void
 */
static void vhal_rtl_wifi_connect(void *arg)
{
    rtw_wifi_setting_t wifi_config;
    rtw_security_t sec_type;
    int ssid_len = 0;
    int pwd_len = 0;
    int key_idx = -1;
    VHAL_WIFI_STATUS_E wifi_status = VHAL_WIFI_INIT;
    uint8_t ret = -1;

    // Wi-Fi配置不合法，退出
    ssid_len = strlen(s_rtl_wifi_cfg.sta_cfg.ssid);
    pwd_len = strlen(s_rtl_wifi_cfg.sta_cfg.pwd);
    if (ssid_len <= 0)
    {
        HAL_LOG(LOG_ERROR, "No Wi-Fi ssid, exit\n");
        goto exit;
    }

    wifi_status = s_rtl_wifi_status.net_status;
    HAL_LOG(LOG_DEBUG, "status = %d, chan = %d.\n", wifi_status, vhal_wifi_get_channel());
    // 如果WiFi已经连上，并且新配置的ssid/pwd和已关联的是一致，直接返回ok，不需要断开重连。
    if (VHAL_WIFI_GOT_IP == wifi_status)
    {
        memset(&wifi_config, 0, sizeof(rtw_wifi_setting_t));
        if ((RTW_SUCCESS == wifi_get_setting(WLAN0_NAME, &wifi_config)) &&
            (0 == strcmp((char *)wifi_config.ssid, s_rtl_wifi_cfg.sta_cfg.ssid) &&
            0 == strcmp((char *)wifi_config.password, s_rtl_wifi_cfg.sta_cfg.pwd)))
        {
            HAL_LOG(LOG_INFO, "Wi-Fi was associated(%s/%s).\n", s_rtl_wifi_cfg.sta_cfg.ssid, s_rtl_wifi_cfg.sta_cfg.pwd);
            goto exit;
        }
    }

    if((VHAL_WIFI_GOT_IP == wifi_status) || (VHAL_WIFI_CONNECTED == wifi_status))
    {
        // 采用新的ssid/pwd，需要断开已有的连接
        HAL_LOG(LOG_INFO, "Wi-Fi disconnect......\n");
        wifi_disconnect();
    }

    if (!wifi_is_up(RTW_STA_INTERFACE))
    {
        HAL_LOG(LOG_INFO, "Wi-Fi STA is down, up now...\n");
        wifi_on(s_rtl_wifi_status.mode);
    }

    vhal_rtl_wifi_set_country_code(s_rtl_wifi_cfg.country_code);

    sec_type = RTW_SECURITY_OPEN;
    if(0 == pwd_len)
    {
        HAL_LOG(LOG_DEBUG, "Setting Wi-Fi configuration SSID [%s], pwd [null]\n", s_rtl_wifi_cfg.sta_cfg.ssid);
    }
    else
    {
        if (VHAL_WIFI_AUTH_WEP == s_rtl_wifi_cfg.sta_cfg.auth_mode)
        {
            key_idx = 0;
            sec_type = RTW_SECURITY_WEP_PSK;
        }
        else if (VHAL_WIFI_AUTH_WPA3_PSK == s_rtl_wifi_cfg.sta_cfg.auth_mode)
        {
            sec_type = RTW_SECURITY_WPA3_PSK;
        }
        else
        {
            //sec_type = RTW_SECURITY_WPA2_MIXED_PSK;   // 如果需要改为该加密类型，需要修改WiFi驱动，否则会获取不到连接失败的状态，如wifi_disconn_hdl()
            sec_type = RTW_SECURITY_WPA2_AES_PSK;
        }
        HAL_LOG(LOG_DEBUG, "Wi-Fi config SSID [%s], pwd [%s], auth %d\n",
                            s_rtl_wifi_cfg.sta_cfg.ssid, s_rtl_wifi_cfg.sta_cfg.pwd, s_rtl_wifi_cfg.sta_cfg.auth_mode);
    }

    // 设置自动连接
    wifi_config_autoreconnect(RTW_AUTORECONNECT_INFINITE, 5, 5);     // 自动连接5次，5秒钟超时

    // 连接Wi-Fi
    //vhal_wifi_set_status(VHAL_WIFI_CONNECTING);
    s_rtl_wifi_status.start_flag = true;  // 设置标志位
    if (RTW_SUCCESS != wifi_connect(s_rtl_wifi_cfg.sta_cfg.ssid, sec_type, s_rtl_wifi_cfg.sta_cfg.pwd, ssid_len, pwd_len, key_idx, NULL))
    {
        vhal_rtl_wifi_get_connect_fail_rsn();
        vhal_rtl_ip_timer_start();      // 启动ip检测定时器
        //return VHAL_FAIL;     // 有可能会连接失败，但dhcp client需要启动
    }

    // 发起DHCP请求获取IP,驱动中的神操作
    ret = LwIP_DHCP(0, DHCP_START);
    if (ret == DHCP_ADDRESS_ASSIGNED)
    {
        wifi_indication(WIFI_EVENT_STA_GOT_IP, NULL, 0, 0);
    }
    else
    {
        wifi_indication(WIFI_EVENT_STA_LOST_IP, NULL, 0, 0);
    }

    HAL_LOG(LOG_INFO, "Wi-Fi start connect...........\n");

exit:
    vTaskDelete(NULL);
}

/*
 * @brief Wi-Fi连接事件应用程序任务回调函数
 * @param[in]  event                [系统事件指针]
 * @return     void                 [none]
 */
static void vhal_rtl_wifi_event_hdl(rtw_event_indicate_t event)
{
    char ip_buf[20] = {0};      // 保存ip空间
    //HAL_LOG(LOG_DEBUG, "event %d.\n", event);

    switch(event)
    {
        case WIFI_EVENT_STA_START:
        case WIFI_EVENT_CONNECT:
            HAL_LOG(LOG_DEBUG, "[%02d] Wi-Fi start connecting, chan = %d.\n", event, vhal_wifi_get_channel());
            vhal_rtl_wifi_update_status(VHAL_WIFI_CONNECTING);
            break;

        case WIFI_EVENT_STA_STOP:
            HAL_LOG(LOG_DEBUG, "[%02d] Wi-Fi stop.\n", event);
            break;

        case WIFI_EVENT_DISCONNECT:
        case WIFI_EVENT_RECONNECTION_FAIL:
            HAL_LOG(LOG_DEBUG, "[%02d] Wi-Fi disconnect.\n", event);
            // WiFi驱动在初始情况下，会莫名返回连接失败的状态。因此，只有在调用了vhal_wifi_connect()后，才起定时器
            if (s_rtl_wifi_status.start_flag)
            {
                //vhal_wifi_set_status(VHAL_WIFI_CONNECT_FAIL);
                //if(NULL != s_rtl_wifi_disconnect_log_cb)
                //    s_rtl_wifi_disconnect_log_cb("RTL_CONNECTION_FAIL");
                vhal_rtl_wifi_get_connect_fail_rsn();
                // 如果断网还存在IP，释放IP，然后启动定时器检测
                if (NULL != vhal_wifi_get_sta_ip(ip_buf, sizeof(ip_buf)))
                {
                    LwIP_ReleaseIP(0);
                }
                vhal_rtl_ip_timer_start();          // Wi-Fi 断开后，启动ip检测定时器
            }
            break;

        case WIFI_EVENT_NO_NETWORK:
            HAL_LOG(LOG_DEBUG, "[%02d] Wi-Fi no ap found.\n", event);
            vhal_rtl_wifi_update_status(VHAL_WIFI_NO_AP_FOUND);
            if(NULL != s_rtl_wifi_status.disc_log_cb)
                s_rtl_wifi_status.disc_log_cb("RTL_NO_AP_FOUND");
            break;

        case WIFI_EVENT_ICV_ERROR:
        //case WIFI_EVENT_CHALLENGE_FAIL:
            HAL_LOG(LOG_DEBUG, "[%02d] Wi-Fi PWD error.\n", event);
            vhal_rtl_wifi_update_status(VHAL_WIFI_WRONG_PWD);
            if(NULL != s_rtl_wifi_status.disc_log_cb)
            {
                s_rtl_wifi_status.disc_log_cb("RTL_WRONG_PWD");
            }
            break;

        case WIFI_EVENT_FOURWAY_HANDSHAKE_DONE:
            HAL_LOG(LOG_DEBUG, "[%02d] Wi-Fi connect successful, chan = %d.\n", event, vhal_wifi_get_channel());
            vhal_rtl_wifi_update_status(VHAL_WIFI_CONNECTED);
            break;

        case WIFI_EVENT_IP_CHANGED:
        case WIFI_EVENT_STA_GOT_IP:
            // 获取到合法的IP地址，才通知上层
            if (NULL != vhal_wifi_get_sta_ip(ip_buf, sizeof(ip_buf)))
            {
                if (s_rtl_wifi_status.start_flag)
                {
                    vhal_rtl_wifi_update_status(VHAL_WIFI_GOT_IP);
                    vhal_rtl_ip_timer_stop();       // 停止定时器
                }

                // 获取IP地址成功，获取网关地址和DNS
                vhal_rtl_wifi_get_netif_info();
            }
            break;

        case WIFI_EVENT_STA_LOST_IP:
            HAL_LOG(LOG_DEBUG, "[%02d] Wi-Fi lost IP.\n", event);
            vhal_rtl_wifi_update_status(VHAL_WIFI_LOST_IP);
            // ip丢失，重新发起dhcp连接
            LwIP_DHCP(0, DHCP_START);
            break;

        case WIFI_EVENT_SCAN_RESULT_REPORT:     // Wi-Fi扫描，每上报一条信息，返回一次状态
            //HAL_LOG(LOG_DEBUG, "[%02d] Wi-Fi scan result report.\n", event);
            break;

        case WIFI_EVENT_SCAN_DONE:      // Wi-Fi列表扫描结束事件
            //HAL_LOG(LOG_DEBUG, "[%02d] Wi-Fi scan done.\n", event);
            //vhal_rtl_wifi_update_status(VHAL_WIFI_SCAN_DONE);
            break;

        case WIFI_EVENT_STA_ASSOC:      // AP模式，STA连上AP的事件
            HAL_LOG(LOG_DEBUG, "[%02d] STA connect Wi-Fi AP.\n", event);
            vhal_rtl_wifi_update_status(VHAL_WIFI_STA_CONNECT_SOFTAP);
            break;

        case WIFI_EVENT_STA_DISASSOC:   // AP模式，STA断开AP连接的事件
            HAL_LOG(LOG_DEBUG, "[%02d] STA disconnect Wi-Fi AP.\n", event);
            vhal_rtl_wifi_update_status(VHAL_WIFI_STA_DISCONNECT_SOFTAP);
            break;

        case WIFI_EVENT_RX_MGNT:
            break;

#if CONFIG_ENABLE_P2P
        case WIFI_EVENT_SEND_ACTION_DONE:
            break;
#endif /* CONFIG_ENABLE_P2P */

#ifdef CONFIG_WPS
        case WIFI_EVENT_STA_WPS_START:
            break;

        case WIFI_EVENT_WPS_FINISH:
            break;

        case WIFI_EVENT_EAPOL_RECVD:
            break;
#endif /* CONFIG_WPS */

        case WIFI_EVENT_BEACON_AFTER_DHCP:  // beacon帧发送回调，100ms打印一次
            break;

        default:
            HAL_LOG(LOG_DEBUG, "[%02d] Wi-Fi other event.\n", event);
            break;
    }
}

/*
 * @brief 切换Wi-Fi运行模式
 * @param[in]  VHAL_WIFI_MODE_E         [Wi-Fi模式(AP/APSTA)]
 * @return     int                      [执行成功，返回OK；执行失败，返回FAIL]
 */
int vhal_rtl_wifi_chg_wifi_mode(VHAL_WIFI_MODE_E wifi_mode)
{
    s_rtl_wifi_status.mode = RTW_MODE_NONE;     // 初始值

    switch (wifi_mode)
    {
        case VHAL_WIFI_MODE_STA:
            s_rtl_wifi_status.mode = RTW_MODE_STA;
            break;
        case VHAL_WIFI_MODE_AP:
            s_rtl_wifi_status.mode = RTW_MODE_AP;
            break;
        case VHAL_WIFI_MODE_APSTA:
            s_rtl_wifi_status.mode = RTW_MODE_STA_AP;
            break;
        default:
            HAL_LOG(LOG_ERROR, "Unknow wifi_mode(%d)\n", wifi_mode);
            return VHAL_FAIL;
    }

    // 先停止当前运行模式
    wifi_off();
    vTaskDelay(20);

    // 启动新模式
    if (wifi_on(s_rtl_wifi_status.mode) < 0)
    {
        HAL_LOG(LOG_ERROR, "wifi_on failed\n");
        return VHAL_FAIL;
    }

    return VHAL_OK;
}

/*
 * @brief Wi-Fi驱动扫描AP列表回调函数
 * @param[in]   p_scan_result               [扫描到的AP信息]
 * @return      rtw_result_t                [成功返回RTW_SUCCESS，失败返回RTW_ERROR]
 */
static rtw_result_t vhal_rtl_wifi_scan_result_hdl(rtw_scan_handler_result_t *p_scan_result)
{
    int max_ap_num = 48;        // 默认AP列表最大数量
    static int ap_num = 0;

    if (p_scan_result->scan_complete != RTW_TRUE)
    {
        rtw_scan_result_t* record = &p_scan_result->ap_details;
        record->SSID.val[record->SSID.len] = 0; /* Ensure the SSID is null terminated */

        //HAL_LOG(LOG_DEBUG, "ap_num = %d\n", ++ap_num);
        //HAL_LOG(LOG_DEBUG, "MAC: %02x:%02x:%02x:%02x:%02x:%02x\n", MAC_ARG(record->BSSID.octet));
        //HAL_LOG(LOG_DEBUG, "SSID: %s\n", record->SSID.val);
        //HAL_LOG(LOG_DEBUG,"RSSI: %d, channel: %d\n", record->signal_strength, record->channel);
        ap_num += 1;
        if(NULL != s_rtl_wifi_status.scan_cb)
            s_rtl_wifi_status.scan_cb(record->BSSID.octet, record->SSID.val, record->signal_strength,
                                        vhal_rtl_wifi_conv_auth_mode(record->security), max_ap_num);
    }
    else
    {
        HAL_LOG(LOG_DEBUG, "ap_num = %d\n", ap_num);
        ap_num = 0;
        s_rtl_wifi_status.scan_flag = false;         // Wi-Fi列表已经扫描结束
        vhal_rtl_wifi_update_status(VHAL_WIFI_SCAN_DONE);
    }

    return RTW_SUCCESS;
}


/*-----------------------------------------------------------------------------*
 *                           外部函数API实现                                         *
 *-----------------------------------------------------------------------------*/

/*
 * @brief  初始化Wi-Fi模块
 * @param[in]  status_cb                [Wi-Fi的连接状态回调函数]
 * @param[in]  power_save               [Wi-Fi节能模式标志位]
 * @param[in]  p_hostname               [DHCP hostname]
 * @param[in]  p_country_code           [长度为2byte的国家码，如：US、EU、CN]
 * @return void
 */
void vhal_wifi_init(vhal_wifi_status_cb_t status_cb, VHAL_WIFI_PS_TYPE_E power_save, char *p_hostname, char *p_country_code)
{
    // 参数初始化
    memset(&s_rtl_wifi_cfg, 0, sizeof(vhal_rtl_wifi_cfg_t));
    memset(&s_rtl_wifi_status, 0, sizeof(vhal_rtl_wifi_status_t));
    s_rtl_wifi_status.mode = RTW_MODE_STA;

    // 初始化WiFi驱动
    wifi_manager_init();
    wifi_on(s_rtl_wifi_status.mode);
    vhal_change_dhcp_hostname(p_hostname);       // 必须在LwIP_Init()之前，否则不生效
    LwIP_Init();
    memset(s_rtl_wifi_cfg.country_code, 0, sizeof(s_rtl_wifi_cfg.country_code));
    if (NULL != p_country_code)
    {
        snprintf(s_rtl_wifi_cfg.country_code, sizeof(s_rtl_wifi_cfg.country_code), "%s", p_country_code);
        vhal_rtl_wifi_set_country_code(p_country_code);
    }
    if (NULL != p_hostname)
    {
        snprintf(s_rtl_wifi_cfg.hostname, sizeof(s_rtl_wifi_cfg.hostname), "%s", p_hostname);
    }

    // 注册驱动中缺失的两个事件
    vhal_rtl_wifi_event_init();

    // Wi-Fi+BLE方案，不支持powersave
#if defined(CONFIG_TARGET_RTL8710CX)
    if (power_save)
    {
        wifi_enable_powersave();
    }
    else
#endif
    {
        wifi_disable_powersave();
    }

    s_rtl_wifi_status.status_cb = status_cb;

    /* 注册Wi-Fi连接事件回调函数到SDK */
    rtl_wifi_reg_event_handler(vhal_rtl_wifi_event_hdl);

    HAL_LOG(LOG_INFO, "Init Wi-Fi module done.\n");
}

/*
 * @brief  卸载Wi-Fi驱动
 * @return void
 */
void vhal_wifi_deinit(void)
{
    //rtw_wifi_manager_deinit();

    if (RTW_SUCCESS == wifi_off())
        HAL_LOG(LOG_INFO, "Deinit Wi-Fi module done.\n");
    else
        HAL_LOG(LOG_INFO, "Deinit Wi-Fi module fail.\n");
}

/*
 * @brief  Wi-Fi启动工作
 * @return void
 */
void vhal_wifi_start(void)
{
    vhal_wifi_sta_cfg_t sta_cfg;

    // Wi-Fi先启动
    s_rtl_wifi_status.mode = RTW_MODE_STA;
    wifi_on(s_rtl_wifi_status.mode);

    memset((int8_t *)&sta_cfg, 0, sizeof(vhal_wifi_sta_cfg_t));
    memcpy(sta_cfg.ssid, s_rtl_wifi_cfg.sta_cfg.ssid, WIFI_SSID_MAX_LEN);
    memcpy(sta_cfg.pwd, s_rtl_wifi_cfg.sta_cfg.pwd, WIFI_PWD_MAX_LEN);
    sta_cfg.auth_mode = s_rtl_wifi_cfg.sta_cfg.auth_mode;
    vhal_wifi_connect(sta_cfg.ssid, sta_cfg.pwd, sta_cfg.auth_mode);

    HAL_LOG(LOG_DEBUG, "Realtek Wi-Fi start.\n");
}

/*
 * @brief Wi-Fi停止工作
 * @return void
 */
void vhal_wifi_stop(void)
{
    // Wi-Fi+BLE方案，Wi-Fi必须需on的状态，因为BLE和Wi-Fi是共用射频，否则会引起BLE卡死
#if defined(CONFIG_TARGET_RTL8710CX)
     wifi_off();
#else
    wifi_disconnect();
#endif
    LwIP_ReleaseIP(0);
    s_rtl_wifi_status.mode = RTW_MODE_STA;
    s_rtl_wifi_status.start_flag = false;  // 设置标志位
    HAL_LOG(LOG_DEBUG, "Realtek Wi-Fi stop.\n");
}

/*
 * @brief  设备作为STA，主动发起关联AP
 * @param[in]  p_ssid                   [Wi-Fi的名称]
 * @param[in]  p_pwd                    [Wi-Fi的密码]
 * @param[in]  auth_mode                [Wi-Fi加密模式]
 * @return     int                      [执行成功，返回OK；执行失败，返回FAIL]
 */
int vhal_wifi_connect(char *p_ssid, char *p_pwd, VHAL_WIFI_AUTH_MODE_E auth_mode)
{
    int ssid_len = 0;
    int pwd_len = 0;

    if (NULL == p_ssid)
    {
        HAL_LOG(LOG_ERROR, "Input param is a null pointer!\n");
        return VHAL_FAIL;
    }

    // 另存WiFi配置信息
    memset((int8_t *)&s_rtl_wifi_cfg.sta_cfg, 0, sizeof(vhal_wifi_sta_cfg_t));
    ssid_len = strlen(p_ssid);
    memcpy(s_rtl_wifi_cfg.sta_cfg.ssid, p_ssid, ssid_len);
    if (NULL != p_pwd)
    {
        pwd_len = strlen(p_pwd);
        if (pwd_len > 0)
            memcpy(s_rtl_wifi_cfg.sta_cfg.pwd, p_pwd, pwd_len);
    }
    s_rtl_wifi_cfg.sta_cfg.auth_mode = auth_mode;
    //HAL_LOG(LOG_DEBUG, "ssid: %s, pwd: %s\n", p_ssid, p_pwd);

    // 创建1个task去连接WiFi，以配网模块去耦合
    if (pdPASS != xTaskCreate(vhal_rtl_wifi_connect,
                        "wifi_conn",
                        2*1024/sizeof(portSTACK_TYPE),
                        NULL,
                        5,
                        NULL))
    {
        HAL_LOG(LOG_ERROR, "Create wifi connect task fail!!!\n");
        return VHAL_FAIL;
    }

    return VHAL_OK;
}

/*
 * @brief  Wi-Fi运行在STA模式时，与router AP的连接状态
 * @param[in]  wait_time_ms             [最大阻塞等待时间]
 * @return     bool                     [关联AP成功且获取IP成功，返回true；否则返回false]
 */
bool vhal_wifi_get_link_status(int32_t wait_time_ms)
{
    int cnt = 0;
    int delay_ms = 30;      // 等待周期

    // 计算周期
    cnt = wait_time_ms/delay_ms;
    while (cnt-- > 0)
    {
        // 已关联上AP，返回true，否则返回false
        if (VHAL_WIFI_GOT_IP == s_rtl_wifi_status.net_status)
        {
            return true;
        }
        vTaskDelay(delay_ms/portTICK_RATE_MS);
    }

    return false;
}

/*
 * @brief 设备作为STA时，与AP关联成功，检测到AP的接收信号强度
 * @param[in]  points                   [循环检测的次数]
 * @return     int                      [平均rssi(连续point个测试数据取平均)]
 */
int vhal_wifi_get_router_rssi(int points)
{
    int ret = RTW_ERROR;
    int avg_rssi = 0;

    ret = wifi_get_rssi(&avg_rssi);
    if (RTW_SUCCESS != ret)
    {
        avg_rssi = 1;
    }
    HAL_LOG(LOG_DEBUG, "Router AP rssi strength is %d.\n", avg_rssi);

    return avg_rssi;
}

/*
 * @brief 获取当前Wi-Fi信道
 * @return     int                      [Wi-Fi工作信道]
 */
int vhal_wifi_get_channel(void)
{
    int chan = 0;
    int ret = RTW_ERROR;

    ret = wifi_get_channel(&chan);
    if (RTW_SUCCESS == ret)
    {
        HAL_LOG(LOG_DEBUG, "current channel is %d.\n", chan);
        if (chan >= VHAL_WIFI_2G4_CHAN1 && chan < VHAL_WIFI_2G4_CHAN_MAX)
        {
            s_rtl_wifi_status.chan = chan;
        }
    }
    else
    {
        HAL_LOG(LOG_DEBUG, "get channel error(%d).\n", ret);
    }

    return chan;
}

/*
 * @brief 设备作为STA时，获取当前连接路由器成功所使用的ssid和密码。
 * @param[out] p_sta_cfg                [保存Wi-Fi连接使用的ssid和密码]
 * @return     int                      [执行成功，返回OK；执行失败，返回FAIL]
 */
int vhal_wifi_get_sta_cfg(vhal_wifi_sta_cfg_t *p_sta_cfg)
{
    rtw_wifi_setting_t sta_cfg;

    if (NULL == p_sta_cfg)
    {
        HAL_LOG(LOG_ERROR, "Input param is a null pointer!\n");
        return VHAL_FAIL;
    }

    memset(&sta_cfg, 0, sizeof(rtw_wifi_setting_t));
    memset((uint8_t *)p_sta_cfg, 0, sizeof(vhal_wifi_sta_cfg_t));
    if (RTW_SUCCESS != wifi_get_setting(WLAN0_NAME, &sta_cfg))
    {
        HAL_LOG(LOG_ERROR, "Get Wi-Fi STA cfg fail!\n");
        return VHAL_FAIL;
    }

    //wifi_show_setting(WLAN0_NAME, &sta_cfg);

    memcpy(p_sta_cfg->ssid, sta_cfg.ssid, sizeof(sta_cfg.ssid));
    memcpy(p_sta_cfg->pwd, sta_cfg.password, sizeof(sta_cfg.password));

	return VHAL_OK;
}


/*
 * @brief  注册配网时需要的Wi-Fi回调函数
 * @param[in]  scan_cb                  [Wi-Fi列表扫描结果回调]
 * @param[in]  disconn_cb               [Wi-Fi断开连接时回调]
 * @return void
 */
void vhal_wifi_reg_cfgnet_cb(vhal_wifi_scan_cb_t scan_cb, vhal_wifi_disc_log_cb_t disconn_cb)
{
    s_rtl_wifi_status.scan_cb = scan_cb;
    s_rtl_wifi_status.disc_log_cb = disconn_cb;
}

/*
 * @brief 撤销注册配网时需要的Wi-Fi回调函数
 */
void vhal_wifi_unreg_cfgnet_cb(void)
{
    s_rtl_wifi_status.scan_cb = NULL;
    s_rtl_wifi_status.disc_log_cb = NULL;
}

/*
 * @brief 硬件抽象层设置设备为WiFi热点
 * @param[in]  wifi_mode  Wi-Fi模式(AP/APSTA)
 * @param[in]  ssid                     [ssid名称]
 * @param[in]  pwd                      [Wi-Fi密码]
 * @param[in]  chan                     [Wi-Fi信道]
 * @param[in]  auth_mode                [加密方式]
 * @return     int                      [执行成功，返回OK；执行失败，返回FAIL]
 */
int vhal_wifi_setup_ap_cfg(VHAL_WIFI_MODE_E wifi_mode, char *ssid, char* pwd, uint8_t chan, uint8_t auth_mode)
{
    if (NULL == ssid /*|| (NULL == pwd && VHAL_WIFI_AUTH_OPEN != auth_mode)*/)
    {
        HAL_LOG(LOG_ERROR, "Input param is a null pointer!\n");
        return VHAL_FAIL;
    }

    if (VHAL_WIFI_MODE_AP == wifi_mode || VHAL_WIFI_MODE_APSTA == wifi_mode)
    {
        dhcps_deinit();     // 停止

        if (VHAL_OK != vhal_rtl_wifi_chg_wifi_mode(wifi_mode))
        {
            return VHAL_FAIL;
        }

        // 2.4G Wi-Fi信道范围为1~13
        if (s_rtl_wifi_status.chan >= VHAL_WIFI_2G4_CHAN1 && s_rtl_wifi_status.chan < VHAL_WIFI_2G4_CHAN_MAX)
        {
            chan = s_rtl_wifi_status.chan;
        }

        // 配置AP
        rtw_security_t sec_type = RTW_SECURITY_OPEN;
        int pwd_len = 0;
        if (NULL != pwd && strlen(pwd) >= 8)
        {
            pwd_len = strlen(pwd);
            sec_type = RTW_SECURITY_WPA_WPA2_MIXED;
        }
        else
        {
            HAL_LOG(LOG_DEBUG, "Setting Wi-Fi(%s) with open security, channel is %d.\n", ssid, chan);
        }

        if (wifi_start_ap(ssid, sec_type, pwd, strlen(ssid), pwd_len, chan) < 0)
        {
            HAL_LOG(LOG_ERROR, "wifi_start_ap failed\n");
            return VHAL_FAIL;
        }

        // 检测是否启动成功
        int cnt = 20;
        char essid[33] = {0};
        while (cnt-- > 0)
        {
            if (wext_get_ssid(WLAN1_NAME, (unsigned char *)essid) > 0)
            {
                if (strcmp((const char *)essid, (const char *)ssid) == 0)
                {
                    HAL_LOG(LOG_INFO, "%s is started\n", ssid);
                    break;
                }
            }
            vTaskDelay(pdMS_TO_TICKS(50));
        }

        // 声明位置\sdk\rtl-amebaz2_v7.1c\component\common\api\lwip_netconf.c
        extern struct netif xnetif[NET_IF_NUM];
        struct netif *p_netif = &xnetif[1];             // AP interface
        vhal_rtl_wifi_reset_ip_addr(p_netif);           // 修改网关IP

        // 启动dhcp服务器
        dhcps_init(p_netif);

        return VHAL_OK;
    }
    else
    {
        HAL_LOG(LOG_ERROR, "Unkown Wi-Fi mode (%d)!\n", wifi_mode);
        return VHAL_FAIL;
    }
}


/*
 * @brief 关闭Wi-Fi的AP模式，不影响STA接口
 * @return     void            [none]
 */
void vhal_wifi_stop_ap_mode(void)
{
    int ret = -1;
    char *ap_name = "wlan1";

    // 关闭dhcp server
    dhcps_deinit();
    HAL_LOG(LOG_DEBUG, "Stop DHCP server\n");

    // Wi-Fi AP未启动，不能suspend，否则会引起崩溃
    //if (/*s_rtl_mode != RTW_MODE_STA && */s_rtl_mode != RTW_MODE_STA_AP && s_rtl_mode != RTW_MODE_AP)
    //{
    //    HAL_LOG(LOG_ERROR, "Current mode(%d) is not ap, skip!!\n", s_rtl_mode);
    //    return;
    //}
    // 如果接口已经stop，不能再suspend，否则会引起崩溃
    if (!wifi_is_up(RTW_AP_INTERFACE))
    {
        HAL_LOG(LOG_ERROR, "AP is stop, skip!!\n");
        return;
    }

    extern int rltk_suspend_softap(const char *ifname);     // SDK中*.c文件中实现的函数，无源码

    ret = rltk_suspend_softap(ap_name);
    HAL_LOG(LOG_DEBUG, "Stop AP mode, ret = %d\n", ret);
}

/*
 * @brief  Wi-Fi开始扫描周围的AP热点
 * @return      int                     [执行成功，返回OK；执行失败，返回FAIL]
 */
int vhal_wifi_scan_start(void)
{
    if (!wifi_is_up(RTW_AP_INTERFACE))   // TODO: RTW_AP_INTERFACE or RTW_MODE_STA??
    {
        HAL_LOG(LOG_INFO ,"Wi-Fi is down, start now!\n");
        s_rtl_wifi_status.mode = RTW_MODE_STA;
        wifi_on(s_rtl_wifi_status.mode);
        //return VHAL_FAIL;
    }

    if (s_rtl_wifi_status.scan_flag)
    {
        HAL_LOG(LOG_INFO ,"Scanning Wi-Fi list, skip.\n");
        return VHAL_OK;
    }

    // 需要在esp_wifi_scan_start()之前设置状态，
    s_rtl_wifi_status.scan_flag = true;

    HAL_LOG(LOG_INFO ,"Start scaning Wi-Fi list.\n");
    int ret = wifi_scan_networks(vhal_rtl_wifi_scan_result_hdl, NULL);
    if (RTW_SUCCESS != ret)
    {
        HAL_LOG(LOG_ERROR ,"Scanning Wi-Fi list error: 0x%x\n", ret);
        return VHAL_FAIL;
    }

    // Wait for scan finished.
    //int cnt = 25;       // 循环次数，最长等待5秒
    //while(cnt-- > 0)
    //{
    //    vTaskDelay(200/portTICK_RATE_MS);    // 延时200ms
    //    if (!s_rtl_wifi_scan_status)
    //        break;
    //}
    //HAL_LOG(LOG_INFO ,"Scaning Wi-Fi list finish.\n");
    HAL_LOG(LOG_INFO ,"End Wi-Fi scan.\n");

    return VHAL_OK;
}

/*
 * @brief  Wi-Fi停止扫描AP热点
 * @return      int                     [执行成功，返回OK；执行失败，返回FAIL]
 */
int vhal_wifi_scan_stop(void)
{
    s_rtl_wifi_status.scan_flag = false;

    HAL_LOG(LOG_DEBUG ,"Stop scaning Wi-Fi list.\n");

    return VHAL_OK;
}



