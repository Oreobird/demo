/*
 * Copyright © Vesync Technologies Co.Ltd. 2022. All rights reserved.
 * @file        aging.c
 * @brief       resetAging处理接口
 * @date        2022-01-24
 */

#include <stdio.h>

#include "vesync_common.h"
#include "vesync_log.h"
#include "vesync_memory.h"
#include "app_bypass.h"
#include "event.h"
#include "device.h"
#include "scene.h"

int handle_for_reset_aging(int *err_code, char *err_msg)
{
    return APP_OK;
}


