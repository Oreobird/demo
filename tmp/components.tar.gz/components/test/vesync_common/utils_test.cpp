/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        utils_test.cpp
 * @brief       vesync utils测试用例
 * @author      Joshua
 * @date        2021-09-09
 */

#include <unistd.h>
#include <gtest/gtest.h>

#include <math.h>
#include <float.h>

#include "vesync_utils.h"

/**
 * @brief 对换一个16位整型的高低位字节
 * @param[in] x     [被求数]
 * @return uint16_t [输出结果]
 */
static inline uint16_t os_bswap_16(uint16_t x)
{
    return ((uint16_t) ((((x) & 0xff00) >> 8) | (((x) & 0x00ff) << 8)));
}


TEST(utils_test, endian_test)
{
    char endianness;
    union {
        char c[4];
        unsigned long mylong;
    } endian_test = {{ 'l', '?', '?', 'b' } };

    // 判断主机序
    endianness = ((char)endian_test.mylong);

    uint16_t htole = 0x1001;
    uint16_t htobe = 0x2002;
    uint16_t letoh = 0x3003;
    uint16_t betoh = 0x4004;

    uint16_t res_1 = vesync_htole16(htole);
    uint16_t res_2 = vesync_htobe16(htobe);
    uint16_t res_3 = vesync_le16toh(letoh);
    uint16_t res_4 = vesync_be16toh(betoh);

    switch (endianness)
    {
    case 'l':
        EXPECT_EQ(res_1, htole);
        EXPECT_EQ(res_2, os_bswap_16(htobe));
        EXPECT_EQ(res_3, letoh);
        EXPECT_EQ(res_4, os_bswap_16(betoh));
        break;
    case 'b':
        EXPECT_EQ(res_1, os_bswap_16(htole));
        EXPECT_EQ(res_2, htobe);
        EXPECT_EQ(res_3, os_bswap_16(letoh));
        EXPECT_EQ(res_4, betoh);
        break;
    default:
        return;
    }
}

#define CALCULATION_COUNT 10000 // 指标测试的计算次数

TEST(utils_test, fast_pow_benchmark)
{
    int start_time;

    float b_stub[CALCULATION_COUNT];
    float e_stub[CALCULATION_COUNT];
    float ref[CALCULATION_COUNT];

    float a[CALCULATION_COUNT];
    float b[CALCULATION_COUNT];
    float c[CALCULATION_COUNT];

    srand((unsigned int)clock());

    printf("---benchmark start---\n");

    for (int i = 0; i < CALCULATION_COUNT; ++i)
    {
        b_stub[i] = (float)rand() / (float)RAND_MAX;
        e_stub[i] = 10 * (float)rand() / (float)RAND_MAX;
    }

#if 0
    printf("stub start:\n");
    for (int i = 0; i < CALCULATION_COUNT; ++i)
    {
        printf(" %f ^ %f \n ", b_stub[i], e_stub[i]);
    }
    printf("stub end\n");
#endif

    start_time = clock();
    for (int i = 0; i < CALCULATION_COUNT; ++i)
    {
        a[i] = vesync_powf(b_stub[i], e_stub[i]);
    }
    printf("sum (fast) in clock %ld\n", clock() - start_time);

    start_time = clock();
    for (int i = 0; i < CALCULATION_COUNT; ++i)
    {
        b[i] = vesync_powf_x(b_stub[i], e_stub[i]);
    }
    printf("sum (faster) in clock %ld\n", clock() - start_time);

    start_time = clock();
    for (int i = 0; i < CALCULATION_COUNT; ++i)
    {
        c[i] = powf(b_stub[i], e_stub[i]);
    }
    printf("sum (std_powf) in clock %ld\n", clock() - start_time);
    for (int i = 0; i < CALCULATION_COUNT; ++i)
    {
        EXPECT_FALSE(isnanf(c[i]));
        EXPECT_FALSE(isinff(c[i]));
    }

    start_time = clock();
    for (int i = 0; i < CALCULATION_COUNT; ++i)
    {
        ref[i] = pow(b_stub[i], e_stub[i]);
    }
    printf("sum (std_pow) in clock %ld\n", clock() - start_time);
    for (int i = 0; i < CALCULATION_COUNT; ++i)
    {
        EXPECT_FALSE(isnan(ref[i]));
        EXPECT_FALSE(isinf(ref[i]));
    }

    double max_err = 0.0f;
    for (int i = 0; i < CALCULATION_COUNT; ++i)
    {
        double err = fabsf(a[i] - ref[i]);
        if (err > max_err)
            max_err = err;
    }
    printf("Error (fast) is %.10f\n", max_err);

    max_err = 0.0f;
    for (int i = 0; i < CALCULATION_COUNT; ++i)
    {
        double err = fabsf(b[i] - ref[i]);
        if (err > max_err)
            max_err = err;
    }
    printf("Error (faster) is %.10f\n", max_err);

    max_err = 0.0f;
    for (int i = 0; i < CALCULATION_COUNT; ++i)
    {
        double err = fabsf(c[i] - ref[i]);
        if (err > max_err)
            max_err = err;
    }
    printf("Error (std_powf) is %.10f\n", max_err);
}

TEST(utils_test, fast_log10_benchmark)
{
    int start_time;

    float n_stub[CALCULATION_COUNT];
    float ref[CALCULATION_COUNT];

    float a[CALCULATION_COUNT];
    float b[CALCULATION_COUNT];
    float c[CALCULATION_COUNT];

    srand((unsigned int)clock());

    printf("---benchmark start---\n");

    for (int i = 0; i < CALCULATION_COUNT; ++i)
    {
        n_stub[i] = 20 * (float)rand() / (float)RAND_MAX;
    }

#if 0
    printf("stub start:\n");
    for (int i = 0; i < CALCULATION_COUNT; ++i)
    {
        printf(" log10(%f) \n ", n_stub[i]);
    }
    printf("stub end\n");
#endif

    start_time = clock();
    for (int i = 0; i < CALCULATION_COUNT; ++i)
    {
        a[i] = vesync_log10f(n_stub[i]);
    }
    printf("sum (fast) in clock %ld\n", clock() - start_time);

    start_time = clock();
    for (int i = 0; i < CALCULATION_COUNT; ++i)
    {
        b[i] = vesync_log10f_x(n_stub[i]);
    }
    printf("sum (faster) in clock %ld\n", clock() - start_time);

    start_time = clock();
    for (int i = 0; i < CALCULATION_COUNT; ++i)
    {
        c[i] = log10f(n_stub[i]);
    }
    printf("sum (std_log10f) in clock %ld\n", clock() - start_time);
    for (int i = 0; i < CALCULATION_COUNT; ++i)
    {
        EXPECT_FALSE(isnanf(c[i]));
        EXPECT_FALSE(isinff(c[i]));
    }

    start_time = clock();
    for (int i = 0; i < CALCULATION_COUNT; ++i)
    {
        ref[i] = log10(n_stub[i]);
    }
    printf("sum (std_log10) in clock %ld\n", clock() - start_time);
    for (int i = 0; i < CALCULATION_COUNT; ++i)
    {
        EXPECT_FALSE(isnan(ref[i]));
        EXPECT_FALSE(isinf(ref[i]));
    }

    double max_err = 0.0f;
    for (int i = 0; i < CALCULATION_COUNT; ++i)
    {
        double err = fabsf(a[i] - ref[i]);
        if (err > max_err)
            max_err = err;
    }
    printf("Error (fast) is %.10f\n", max_err);

    max_err = 0.0f;
    for (int i = 0; i < CALCULATION_COUNT; ++i)
    {
        double err = fabsf(b[i] - ref[i]);
        if (err > max_err)
            max_err = err;
    }
    printf("Error (faster) is %.10f\n", max_err);

    max_err = 0.0f;
    for (int i = 0; i < CALCULATION_COUNT; ++i)
    {
        double err = fabsf(c[i] - ref[i]);
        if (err > max_err)
            max_err = err;
    }
    printf("Error (std_logf) is %.10f\n", max_err);
}
