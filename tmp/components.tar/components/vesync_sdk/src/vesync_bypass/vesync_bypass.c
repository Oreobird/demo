/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_bypass.c
 * @brief       bypass处理接口
 * @date        2021-05-13
 */

#include <string.h>
#include <stdio.h>

#include "vesync_common.h"
#include "vesync_memory.h"
#include "vesync_bypass_internal.h"
#include "vesync_log_internal.h"

static bypass_mgt_t s_bypass_mgt;


/*-----------------------------------------------------------------------------*
*-----------------------------------内部函数API实现-------------------------------*
*-----------------------------------------------------------------------------*/

static bypass_item_t *vesync_bypass_init_item(bypass_item_data_t *data)
{
    bypass_item_t *item = vesync_bypass_get_item_by_id(data->method_id);
    if (item != NULL)
    {
        SDK_LOG(LOG_INFO, "bypass item already exist\n");
        return NULL;
    }

    item = (bypass_item_t *)vesync_malloc(sizeof(bypass_item_t));
    if (item == NULL)
    {
        SDK_LOG(LOG_ERROR, "bypass init item failed\n");
        return NULL;
    }

    memset(item, 0, sizeof(bypass_item_t));
    memcpy(&item->data, data, sizeof(bypass_item_data_t));

    INIT_LIST_HEAD(item->list);

    return item;
}

static bypass_item_t *vesync_bypass_get_item_by_id(BYPASS_METHOD_ID_E  method_id)
{
    bypass_item_t *pos, *n;
    struct list_head *head;

    head = &s_bypass_mgt.list;

    list_for_each_entry_safe(pos, n, head, list)
    {
        if (pos->method_id == method_id)
        {
            return pos;
        }
    }

    return NULL;
}

static int vesync_bypass_add_item(bypass_item_t *item)
{
    VCOM_NULL_PARAM_CHK(item, return SDK_FAIL);

    bypass_item_t *pos = vesync_bypass_get_item_by_id(item->method_id);
    if (pos != NULL)
    {
        SDK_LOG(LOG_ERROR, "bypass item add failed\n");
        return SDK_FAIL;
    }

    list_add(&item->list, &s_bypass_mgt.list);
    s_bypass_mgt.num++;
    return SDK_OK;
}



/*-----------------------------------------------------------------------------*
*-----------------------------------外部函数API实现-------------------------------*
*-----------------------------------------------------------------------------*/

/**
 * @brief bypass 模块初始化
 */
void veysnc_bypass_init(void)
{
    memset(&s_bypass_mgt, 0, sizeof(bypass_mgt_t));
    INIT_LIST_HEAD(&s_bypass_mgt.list);
}


/**
 * @brief 应用层注册bypass method 回调函数
 * @param method_id method                   [对应的id]
 * @param cb bypass method                   [回调函数]
 * @return                                   [0 注册成功  -1 注册失败]
 */
int vesync_bypass_reg_mothod_cb(BYPASS_METHOD_ID_E method_id, bypass_method_cb_t cb)
{
    bypass_item_t *pos, *n;
    struct list_head *head;

    head = &s_bypass_mgt.list;
    list_for_each_entry_safe(pos, n, head, list)
    {
        if (pos->method_id == method_id)
        {
            pos->app_cb = cb;
            return SDK_OK;
        }
    }

    return SDK_FAIL;
}


/**
 * @brief bypass 消息应答函数
 * @param code                               [错误码]
 * @param p_trace_msg                        [trace message app 发送过来原样返回]
 * @param json                               [返回数据json指针， 如果没返回数据返回空指针]
 * @return bypass_err_t
 */
BYPASS_ERR_E vesync_bypass_reply_noqos(int code, const bypass_trace_msg_t *p_trace_msg, cJSON *json)
{
}


/**
 * @brief bypass异常处理，回复信息封装
 * @param[in] err_code                       [错误码]
 * @param[in] p_trace_msg                    [trace message]
 * @param[in] p_msg                          [错误消息(字符串)，支持NULL]
 */
void vesync_bypass_reply_pkg_err_msg(int err_code, bypass_trace_msg_t *p_trace_msg, char *p_msg)
{
}


/**
 * @brief 应用层注册查询串口队列剩余空间 回调函数
 * @param cb                                 [串口队列剩余空间 回调函数]
 * @return void
 */
void vesync_bypass_reg_get_uart_mq_freesize_cb(bypass_get_uart_mq_freesize_cb_t cb)
{
}


/**
 * @brief bypass 消息应答函数, 带MQTT消息等级
 * @param[in] code                           [错误码]
 * @param[in] p_trace_msg                    [trace message app发送过来原样返回]
 * @param[in] json                           [返回数据json指针， 如果没返回数据返回空指针]
 * @param[in] qos                            [MQTT消息等级]
 * @param[in] puback_cb                      [收到qos1确认包后的回调函数]
 * @return bypass_err_t
 */
int vesync_bypass_reply_qos(int code, const bypass_trace_msg_t *p_trace_msg, cJSON *json, REPORT_QOS_E qos, void* puback_cb)
{
}


