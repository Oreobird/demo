/**
 *  Copyright © Vesync Technologies Co.Ltd. 2019-2021. All rights reserved
 * @file        vesync_led_color_palette.c
 * @brief       led color palettes definition
 * @author      henrik
 * @date        2021-09-26
 */
 #include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "led_color_palette.h"


static rgb_color_t s_lighting[1] = {{255, 255, 255}};
static rgb_color_t s_romatic[1] = {{0xfe, 0x0, 0x07}};
static rgb_color_t s_movie[1] = {{0x7f, 0x7f, 0x7f}};
static rgb_color_t s_sweet[1] = {{0xfe, 0x1B, 0}};
static rgb_color_t s_christmas[3] = {{0xff, 0, 0},{0, 0xff, 0},{0xff, 0x40, 0x10}};
static rgb_color_t s_flowing[2] = {{0, 0xff, 0},{0, 0xff, 0xff}};
static rgb_color_t s_rainbow[7] = {{0xff, 0, 0},{0xff, 0x3D, 0},{0xfe, 0xC5, 0},\
                          {0, 0xC5, 0},{0, 0xC5, 0xDE},{0, 0, 0xDE},{0x98, 0, 0xDE}};
static hsv_color_t s_breath[7] = {{0, 1, 1},{30, 1, 1},{60, 1, 1},{120, 1, 1},\
                        {180, 1, 1},{240, 1, 1},{280, 1, 1}};



static color_palette_t s_local_palette[] = {
    { .id = LIGHTING, .color_num = 1, .color = s_lighting, .hsv = NULL},
    { .id = MOVIE, .color_num = 1, .color = s_movie, .hsv = NULL},
    { .id = SWEET, .color_num = 1, .color = s_sweet, .hsv = NULL},
    { .id = ROMATIC , .color_num = 1, .color = s_romatic, .hsv = NULL},
    { .id = CHRISTMAS, .color_num = 3, .color = s_christmas, .hsv = NULL},
    { .id = FLOWING, .color_num = 2, .color = s_flowing, .hsv = NULL},
    { .id = RAINBOW , .color_num = 7, .color = s_rainbow, .hsv = NULL},
    { .id = BREATH, .color_num = 7, .color = NULL, .hsv = s_breath},
};


/**
 * @brief 读取指定名称的色盘信息
 * @param[in ]        id                                     [色盘id]
 * @return            palette                                [成功返回色盘指针或失败返回空]
 * @note
 */
color_palette_t * led_strip_color_get_palette(uint8_t id )
{
    return &s_local_palette[id];
}


