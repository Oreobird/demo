/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_timer.c
 * @brief       timer抽象层，封装freertos定时器相关接口
 * @author      Joshua
 * @date        2021-04-20
 */

#include <stdbool.h>
#include <freertos/FreeRTOS.h>
#include <freertos/timers.h>

#include "vesync_os_internal.h"
#include "vesync_common.h"
#include "vesync_timer.h"

/*
 * @brief  创建定时器
 * @param[in]  timer                 [定时器结构体指针]
 * @param[in]  cb                    [timout回调函数]
 * @param[in]  cb_arg                [回调函数输入参数]
 * @param[in]  timeout_ms            [超时时间，单位毫秒]
 * @param[in]  reload                [定时类型:
 *                                    false：一次
 *                                    true：周期性]
 * @return int                       [成功：VOS_OK；失败：VOS_FAIL]
 */
int vesync_timer_new(vesync_timer_t *timer,
                           char *name,
                           void (*cb)(void*),
                           void *cb_arg,
                           long timeout_ms,
                           bool reload)
{
    int ret = VOS_FAIL;
    VCOM_NULL_PARAM_CHK(name, return VOS_FAIL);
    VCOM_NULL_PARAM_CHK(cb, return VOS_FAIL);

    if (NULL != timer->handle)
    {
        return VOS_FAIL;
    }

    timer->timeout_ms = timeout_ms;
    timer->reload = reload;
    timer->handle = xTimerCreate(name, VESYNC_MS_TO_TICKS(timeout_ms), reload ? pdTRUE : pdFALSE, NULL, cb);
    ret = (NULL == timer->handle) ? VOS_FAIL : VOS_OK;

    return ret;
}

/*
* @brief  启动定时器
* @param[in]  timer                   [定时器结构体指针]
* @return int                         [成功：VOS_OK；失败：VOS_FAIL]
*/
int vesync_timer_start(vesync_timer_t *timer)
{
    VCOM_NULL_PARAM_CHK(timer, return VOS_FAIL);
    VCOM_NULL_PARAM_CHK(timer->handle, return VOS_FAIL);

    BaseType_t ret = pdFAIL;
    ret = xTimerStart(timer->handle, portMAX_DELAY);
    if (pdPASS != ret)
    {
        return VOS_FAIL;
    }

    return VOS_OK;
}

/*
 * @brief  停止定时器
 * @param[in]  timer                   [定时器结构体指针]
 * @return int                         [成功：VOS_OK；失败：VOS_FAIL]
 */
int vesync_timer_stop(vesync_timer_t *timer)
{
    VCOM_NULL_PARAM_CHK(timer, return VOS_FAIL);
    VCOM_NULL_PARAM_CHK(timer->handle, return VOS_FAIL);

    BaseType_t ret = pdFAIL;
    ret = xTimerStop(timer->handle, portMAX_DELAY);
    if (pdPASS != ret)
    {
        return VOS_FAIL;
    }

    return VOS_OK;
}

/**
* @brief 修改计时周期
* @param[in] timer                    [定时器结构体指针]
* @param[in] timeout_ms               [超时时间]
* @return int                         [成功：VOS_OK；失败：VOS_FAIL]
*/
int vesync_timer_change_period(vesync_timer_t *timer, long timeout_ms)
{
    VCOM_NULL_PARAM_CHK(timer, return VOS_FAIL);
    VCOM_NULL_PARAM_CHK(timer->handle, return VOS_FAIL);

    BaseType_t ret = pdFAIL;
    ret = xTimerChangePeriod(timer->handle, timeout_ms/portTICK_PERIOD_MS, portMAX_DELAY);
    if (pdPASS != ret)
    {
        return VOS_FAIL;
    }

    return VOS_OK;
}

/*
 * @brief  删除定时器
 * @param[in]  timer                   [定时器结构体指针]
 * @return int                         [成功：VOS_OK；失败：VOS_FAIL]
 */
int vesync_timer_free(vesync_timer_t *timer)
{
    VCOM_NULL_PARAM_CHK(timer, return VOS_FAIL);
    VCOM_NULL_PARAM_CHK(timer->handle, return VOS_FAIL);

    BaseType_t ret = pdFAIL;

    ret = xTimerDelete(timer->handle, portMAX_DELAY);
    if (pdPASS != ret)
    {
        return VOS_FAIL;
    }

    timer->handle = NULL;

    return VOS_OK;
}
