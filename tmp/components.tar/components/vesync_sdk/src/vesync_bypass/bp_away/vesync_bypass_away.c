/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_bypass_away.c
 * @brief       bypass处理接口
 * @date        2021-05-17
 */

#include <string.h>
#include "vesync_common.h"
#include "vesync_memory.h"
#include "vesync_bypass_internal.h"

/**
 * @brief "addAway" method数据解析
 * @param p_trace_msg trace message
 * @param json数据指针
 * @return BYPASS_ERR_E
 */
static BYPASS_ERR_E bypass_method_add_away_handle(bypass_trace_msg_t *p_trace_msg, cJSON *json)
{
    BYPASS_ERR_E ret = BP_OK;
    cJSON* json_data = NULL;
    if ((NULL == json)||(NULL == p_trace_msg))    return BP_ERROR;

    bypass_away_base_t *pAway_data = (bypass_away_base_t *)vesync_malloc(sizeof(bypass_away_base_t));
    if (NULL == pAway_data)
    {
        return BP_ERR_NOMEM;
    }

    memset(pAway_data, 0, sizeof(bypass_away_base_t));

    json_data = cJSON_GetObjectItemCaseSensitive(json, "startTs");
    if (cJSON_IsNumber(json_data))
    {
        // 开始执行时间必须大于0
        if (json_data->valueint <= 0)
        {
            ret = BP_ERR_ARG;
            goto _exit;
        }

        pAway_data->start_ts =  json_data->valueint;
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "endTs");
    if (cJSON_IsNumber(json_data))
    {
        // 结束时间必须大于0
        if (json_data->valueint <= 0)
        {
            ret = BP_ERR_ARG;
            goto _exit;
        }

        pAway_data->end_ts = json_data->valueint;
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "repeat");
    if (cJSON_IsNumber(json_data))
    {
        pAway_data->repeat = json_data->valueint&0xFF;
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "timeZone");     //时区解析
    if (cJSON_IsString(json_data))
    {
        memcpy(pAway_data->time_zone, json_data->valuestring, sizeof(pAway_data->time_zone) - 1);
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

//    json_data = cJSON_GetObjectItemCaseSensitive(json, "startAct");
//    if (cJSON_IsArray(json_data))
//    {
//        pAway_data->start_act = (void*)json_data;     //startAct 指针传给应用层处理
//    }
//    else
//    {
//        ret = BP_ERR_ARG;
//        goto _exit;
//    }

//    json_data = cJSON_GetObjectItemCaseSensitive(json, "endAct");
//    if (cJSON_IsArray(json_data))
//    {
//        pAway_data->end_act = json_data;     //endAct 指针传给应用层处理
//    }
//    else
//    {
//        ret = BP_ERR_ARG;
//        goto _exit;
//    }

    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_ADD_AWAY);
    if (method_cb)
    {
        method_cb(p_trace_msg, (void*)pAway_data, sizeof(bypass_away_base_t));
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

_exit:
    vesync_free(pAway_data);
    return ret;
}

/**
 * @brief "delAway" method数据解析
 * @param p_trace_msg trace message
 * @param json数据指针
 * @return BYPASS_ERR_E
 */
static BYPASS_ERR_E bypass_method_del_away_handle(bypass_trace_msg_t *p_trace_msg, cJSON *json)
{
    if (NULL == p_trace_msg)   return BP_ERROR;

    //删除需解析id
    int id = 0;
    BYPASS_ERR_E ret = BP_OK;

    cJSON* json_data = cJSON_GetObjectItemCaseSensitive(json, "id");
    if (cJSON_IsNumber(json_data))
    {
        id = json_data->valueint;
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_DEL_AWAY);
    if (method_cb)
    {
        method_cb(p_trace_msg, (void*)&id, sizeof(int));
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

 _exit:
    return ret;
}

/**
 * @brief "getAway" method数据解析
 * @param p_trace_msg trace message
 * @param json数据指针
 * @return BYPASS_ERR_E
 */
static BYPASS_ERR_E bypass_method_get_away_handle(bypass_trace_msg_t *p_trace_msg, cJSON *json)
{
    if (NULL == p_trace_msg)   return BP_ERROR;
    BYPASS_ERR_E ret = BP_OK;
    //查询无需解析json
    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_GET_AWAY);
    if (method_cb)
    {
        method_cb(p_trace_msg, NULL, 0);
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

    return ret;
}

static bypass_item_data_t away_method_tbl[] = {
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_ADD_AWAY, "addAway", bypass_method_add_away_handle, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_DEL_AWAY, "delAway", bypass_method_del_away_handle, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_GET_AWAY, "getAway", bypass_method_get_away_handle, NULL},
};

/**
 * @brief bypass away初始化
 */
void vesync_bypass_away_init(void)
{
    for (int i = 0; i < SIZEOF_ARRAY(away_method_tbl); i++)
    {
        bypass_item_t *item = vesync_bypass_init_item(&away_method_tbl[i]);
        if (item != NULL)
        {
            vesync_bypass_add_item(item);
        }
    }
}
