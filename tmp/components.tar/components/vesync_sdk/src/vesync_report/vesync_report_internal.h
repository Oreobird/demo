/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_report_internal.h
 * @brief       report模块接口定义
 * @date        2021-05-18
 */

#ifndef __VESYNC_REPORT_INTERNAL_H__
#define __VESYNC_REPORT_INTERNAL_H__

#include <stdint.h>
#include "cJSON.h"
#include "vesync_report.h"
#include "vesync_device.h"

#ifdef __cplusplus
extern "C" {
#endif

//-------TODO : FIXME

#define vesync_net_get_reconnect_data NULL
#define vesync_flash_write_reconnect_reason NULL
#define vesync_net_clear_reconnect_data NULL
#define vesync_net_get_reconnect_reason_str NULL
#define vesync_mqtt_client_get_status NULL
#define vesync_mqtt_client_publish NULL
#define vesync_production_get_status NULL


/**
 * @brief 产测状态
 */
typedef enum
{
    PRODUCTION_START = 0,       //产测模式开始
    PRODUCTION_RUNNING = 1,     //产测模式运行中
    PRODUCTION_TEST_PASS = 2,   //产测模式测试通过
    PRODUCTION_TEST_FAIL = 3,   //产测模式测试失败
    PRODUCTION_EXIT = 4,        //产测模式退出
    PRODUCTION_LOGIN_FAIL = 5,  //产测模式固件登录产测服务器失败
    PRODUCTION_WIFI_TEST = 6,   //产测WiFi自检模式
} PRODUCTION_STATUS_E;


/**
 * @brief 设备在线/离线状态
 */
typedef enum
{
    RECONNECT_NONE_REASON   = 0,
    POWER_ON_REASON         = 1,    /* 设备上电 */
    CONFIG_NET_REASON       = 2,    /* 配网导致的重新上线 */
    MQTT_REASON             = 3,    /* 网络断开(MQTT/TCP)导致的重新上线 */
    WIFI_REASON             = 4,    /* Wi-Fi断开导致的重新上线 */
    UPGRATE_REASON          = 5,    /* OTA升级导致的重新上线 */
    PRODUCTION_REASON       = 6,    /* 产测升级导致重新上线*/
    //FACTORY_RESET           = 6     /* 按键/删除设备后回复出厂 */
} RECONNECT_REASON_E;


/*
 * @brief设备重连次数
 */
typedef enum
{
    WIFI_RETRY_NO_AP_FOUND      = 0,    // Wi-Fi连接未找到AP
    WIFI_RETRY_INVALID_PWD,             // Wi-Fi连接返回密码错误
    WIFI_RETRY_CONNECT_FAIL,            // Wi-Fi连接失败
    MQTT_RETRY_FAIL,                    // MQTT连接失败
    CONNECT_RETRY_TYPE_TOTAL,
} DEV_CONNECT_FAIL_TYPE_E;


typedef struct
{
    uint32_t wifi_disconn_ts;   // 时间戳
    uint32_t wifi_reconn_ts;
    uint32_t mqtt_disconn_ts;
    uint32_t mqtt_reconn_ts;
    uint32_t retry_cnt[CONNECT_RETRY_TYPE_TOTAL];   // 记录几种错误原因的重连次数
    uint8_t  flag;  // 第1次离线标识
    RECONNECT_REASON_E reason;      // 设备上线原因
} reconn_data_t;

/**
 * @brief MQTT在线/离线状态
 */
typedef enum
{
    NET_UNINIT      = 0,       // MQTT未初始化
    NET_INIT_COMPL,            // MQTT初始化完成
    NET_OFFLINE,               // MQTT连接断开
    NET_ONLINE,                // MQTT已连接服务器
} VESYNC_NET_STATUS_E;

//--------end TODO



#define MAX_TRACEID_LEN         (32)

/**
* @brief 获取traceid函数
*/
typedef void (*get_traceid_t)(char *p_traceID, int buf_len);

/**
* @brief 上报云函数，包含qos
*/
typedef int (*report_cloud_qos_t)(REPORT_TOPIC_TYPE_E topic_type, const char *method,
                                      cJSON *json_data, REPORT_CAUSE_E cause, REPORT_QOS_E qos, void* puback_cb);

/**
* @brief 上报云函数
*/
typedef int (*report_cloud_t)(REPORT_TOPIC_TYPE_E topic_type, const char *method, cJSON *json_data, REPORT_CAUSE_E cause);

/**
* @brief 添加协议头函数
*/
typedef cJSON *(*json_add_method_head_t)(char *trace_id, char *method, cJSON *p_data, REPORT_CAUSE_E cause);

/**
* @brief 获取重连数据函数
*/
typedef void (*get_reconn_data_t)(reconn_data_t *p_data);

/**
* @brief 获取重连数据函数
*/
typedef const char *(*get_reconn_reason_str_t)(RECONNECT_REASON_E reason);


/**
* @brief 清除重连数据函数
*/
typedef void (*clear_reconn_data_t)(void);

/**
* @brief 保存重连原因函数
*/
typedef int (*save_reconn_reason_t)(uint32_t reason);

/**
* @brief 获取连接状态函数
*/
typedef int (*get_cloud_connect_status_t)(void);

/**
* @brief 上报函数
*/
typedef int (*send_to_cloud_t)(REPORT_TOPIC_TYPE_E topic_type, const char *pData, int len, int qos, void *ack_cb);

/**
 * @brief 获取产测状态
 * @return int        [产测状态值]
 */
typedef int (*get_production_status_t)(void);


/**
* @brief 协议方法名称
*/
typedef struct
{
    char firm_up[16];
    char reset_dev[16];
    char update_dev_info[16];
    char status_change[20];
} report_method_t;

/**
* @brief 上报管理结构体
*/
typedef struct
{
    char trace_id_head[16];      // v3 新TraceID前缀，格式：3byte(平台ID) + 4byte 身份标识符（mac去掉冒号后4位）
    uint16_t trace_id_count;     // 运行时自增数字，每次上报都会加1
    report_method_t methods;

    get_traceid_t get_traceid;
    report_cloud_t report_cloud;
    report_cloud_qos_t report_cloud_qos;
    json_add_method_head_t json_add_method_head;

    get_reconn_data_t get_reconn_data;
    clear_reconn_data_t clear_reconn_data;
    get_reconn_reason_str_t get_reconn_reason_str;
    save_reconn_reason_t save_reconn_reason;

    get_cloud_connect_status_t get_cloud_connect_status;
    send_to_cloud_t send_to_cloud;
    get_production_status_t get_production_status;
} report_mgt_t;



/**
* @brief 上报升级状态到云端(http://34.194.32.46:8080/doc/N5iaViSJO)，方法名：reportFirmUpV2
*        设备升级状态上报(http://34.194.32.46:8080/doc/1Lt80cvinF)，方法名：reportFirmUpV3
* @param[in]  type              [固件类型]
* @param[in]  p_latest_ver      [最新固件版本]
* @param[in]  p_fw_url          [固件的URL]
* @param[in]  status            [升级状态]
* @param[in]  percent           [上报升级进度，单位：%]
* @return     int               [成功/失败]
*/
int vesync_report_firm_up(FW_TYPE_E type, char *p_latest_ver, char *p_fw_url, uint8_t status, uint8_t percent);


/**
* @brief 手动重置设备，通知云端(http://34.194.32.46:8080/doc/N5ZU7Jwgm)，方法名：resetDeviceV2
*        设备重置上报(http://34.194.32.46:8080/doc/1Lt66hVc2N)，方法名：resetDeviceV3
* @return      int      [成功/失败]
*/
int vesync_report_reset_device(void);


#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_REPORT_INTERNAL_H__ */

