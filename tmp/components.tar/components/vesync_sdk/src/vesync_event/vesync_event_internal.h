/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_event_internal.h
 * @brief       事件处理接口
 * @date        2021-05-11
 */

#ifndef __VESYNC_EVENT_INTERNAL_H__
#define __VESYNC_EVENT_INTERNAL_H__

#include <stdbool.h>

#include "vesync_cfg.h"
#include "vesync_task.h"
#include "vesync_event.h"
#include "vesync_mutex.h"

#ifdef __cplusplus
extern "C" {
#endif


#define EVENT_TASK_NAME           "event_center_task"
#define EVENT_TASK_PRIO           TASK_PRIORITY_HIGH


/**
* @brief 订阅节点
*/
typedef struct
{
    int sub_id;
    event_subscribe_cb event_handle;
    struct list_head list;
} event_subscribe_t;


/**
* @brief 事件节点
*/
typedef struct
{
    EVENT_ID_E event_id;

    vesync_mutex_t mutex;
    struct list_head subscribe_list; //挂接订阅者

    struct list_head list;
} event_node_t;


/**
* @brief 事件订阅管理
*/
typedef struct
{
    int event_num;

    vesync_mutex_t mutex;
    struct list_head node_list; //挂接事件节点
} event_manage_t;

/**
* @brief 增加订阅节点
* @param sub_id                   [订阅者ID]
* @param cb                       [订阅回调函数]
* @param *node                    [订阅的事件ID]
* @return int                     [SDK_OK/SDK_FAIL]
*/
int vesync_event_subscribe_list_add(int sub_id, event_subscribe_cb cb, event_node_t *node);

/**
* @brief 删除订阅节点
* @param sub_id                   [订阅者ID]
* @param *node                    [订阅的事件ID]
*/
void vesync_event_subscribe_list_del(int sub_id, event_node_t *node);

/**
* @brief 增加事件节点
* @param event_id                 [事件ID]
* @return event_node_t*           [添加的事件节点指针]
*/
event_node_t *vesync_event_node_list_add(EVENT_ID_E event_id);

/**
* @brief 获取事件节点
* @param event_id                 [事件ID]
* @return event_node_t*           [事件节点指针]
*/
event_node_t *vesync_event_node_get(EVENT_ID_E event_id);

#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_EVENT_INTERNAL_H__ */



