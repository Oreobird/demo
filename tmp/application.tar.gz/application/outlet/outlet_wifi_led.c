/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        outlet_wifi_led.c
 * @brief       outlet Wi-Fi指示灯配置
 * @author      Joshua
 * @date        2021-06-04
 */

#include <string.h>

#include "vhal_gpio.h"
#include "vesync_common.h"
#include "vesync_log.h"
#include "vesync_wifi_led.h"

#include "outlet_gpio.h"
#include "outlet_wifi_led.h"

static void outlet_wifi_led_ctrl_cb(WIFI_LED_IO_STATUS_E status)
{
    switch (status)
    {
        case WIFI_LED_IO_LED_OFF:
            outlet_disable_indicator();
            outlet_set_wifi_led_onoff(false);
            break;
        case WIFI_LED_IO_LED_ON:
            outlet_disable_indicator();
            outlet_set_wifi_led_onoff(true);
            break;
        case WIFI_LED_IO_DISABLE:
        default:
            if (WIFI_LED_IO_DISABLE != status)
            {
                APP_LOG(LOG_ERROR, "invalid status for wifi led gpio!!!\r\n");
            }
            outlet_set_wifi_led_onoff(false);
            outlet_enable_indicator();
            break;
    }
}

/**
 * @brief  灯效配置
 * @return     int             [成功/失败]
 */
int outlet_reg_wifi_led(void)
{
    wifi_led_info_t led_cfg;

    memset(&led_cfg, 0, sizeof(led_cfg));

    // 未配网，灯效配置
    led_cfg.led_not_config.status = WIFI_LED_BLINK;
    led_cfg.led_not_config.blink_ms = 500;
    led_cfg.led_not_config.off_times = 1;
    led_cfg.led_not_config.blink_times = 0;

    // 配网中
    led_cfg.led_config_net.status = WIFI_LED_BLINK;
    led_cfg.led_config_net.blink_ms = 125;
    led_cfg.led_config_net.off_times = 1;
    led_cfg.led_config_net.blink_times = 0;

    // FFS配网中
    led_cfg.led_ffs_config_net.status = WIFI_LED_BLINK;
    led_cfg.led_ffs_config_net.blink_ms = 200;
    led_cfg.led_ffs_config_net.off_times = 2;
    led_cfg.led_ffs_config_net.blink_times = 0;

    // 配网超时
    led_cfg.led_config_timeout.status = WIFI_LED_OFF;
    led_cfg.led_config_timeout.blink_ms = 125;
    led_cfg.led_config_timeout.off_times = 1;
    led_cfg.led_config_timeout.blink_times = 0;

    // 上电,网络连接中
    led_cfg.led_connecting.status = WIFI_LED_OFF;
    led_cfg.led_connecting.blink_ms = 125;
    led_cfg.led_connecting.off_times = 1;
    led_cfg.led_connecting.blink_times = 0;

    // 连接服务器成功
    led_cfg.led_login.status = WIFI_LED_OFF;
    led_cfg.led_login.blink_ms = 125;
    led_cfg.led_login.off_times = 1;
    led_cfg.led_login.blink_times = 0;

    // Wi-Fi掉线
    led_cfg.led_wifi_disconnect.status = WIFI_LED_BLINK;
    led_cfg.led_wifi_disconnect.blink_ms = 125;
    led_cfg.led_wifi_disconnect.off_times = 1;
    led_cfg.led_wifi_disconnect.blink_times = 0;

    // Wi-Fi连接10min超时
    led_cfg.led_wifi_timeout.status = WIFI_LED_BLINK;
    led_cfg.led_wifi_timeout.blink_ms = 125;
    led_cfg.led_wifi_timeout.off_times = 1;
    led_cfg.led_wifi_timeout.blink_times = 0;

    // Wi-Fi连接正常，但连接服务器失败
    led_cfg.led_server_disconnect.status = WIFI_LED_OFF;
    led_cfg.led_server_disconnect.blink_ms = 125;
    led_cfg.led_server_disconnect.off_times = 1;
    led_cfg.led_server_disconnect.blink_times = 0;

    // 连接服务器连接10min超时
    led_cfg.led_server_timeout.status = WIFI_LED_OFF;
    led_cfg.led_server_timeout.blink_ms = 1000;
    led_cfg.led_server_timeout.off_times = 4;
    led_cfg.led_server_timeout.blink_times = 0;

    // 恢复出厂设置
    led_cfg.led_reset_device.status = WIFI_LED_OFF;
    led_cfg.led_reset_device.blink_ms = 500;
    led_cfg.led_reset_device.off_times = 1;
    led_cfg.led_reset_device.blink_times = 0;

    // 产测为连上服务器前的灯效
    led_cfg.led_production_test.status = WIFI_LED_BLINK;
    led_cfg.led_production_test.blink_ms = 75;
    led_cfg.led_production_test.off_times = 1;
    led_cfg.led_production_test.blink_times = 0;

    // 上电时Wi-Fi指示灯状态
    led_cfg.led_startup.status = WIFI_LED_OFF;
    led_cfg.led_startup.blink_ms = 75;
    led_cfg.led_startup.off_times = 1;
    led_cfg.led_startup.blink_times = 0;

    // 注册所有情况的灯效规则
    vesync_wifi_led_info_set(led_cfg);

    // 注册闪灯实现函数
    vesync_wifi_led_reg_ctrl_cb(outlet_wifi_led_ctrl_cb, NULL);

    return APP_OK;
}


