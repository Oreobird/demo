/**
*Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file    ledstrip_production.h
* @brief   灯带产测模块
* @author  Lind
*@date     2021-09-09
*/

#ifndef __LEDSTRIP_PRODUCTION_H__
#define __LEDSTRIP_PRODUCTION_H__

#ifdef __cplusplus
extern "C" {
#endif


/**
* @brief ledstrip产测功能初始化
*/
void ls_production_init(void);

#ifdef __cplusplus
}
#endif

#endif

