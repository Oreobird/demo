/**
 *  Copyright © Vesync Technologies Co.Ltd. 2019-2021. All rights reserved.
 * @file        vesync_tl_payload_parse.c
 * @brief       数据帧解析和封装
 * @author      zhenlang
 * @date        2019-09-24
 */

#include <string.h>

#include "vesync_tl_payload_parse.h"


/**
 * @brief  payload封装
 * @param[in]  op_code                  [操作码]
 * @param[in]  status_code              [状态码]
 * @param[in]  in_data                  [数据指针]
 * @param[in]  in_len                   [数据输入长度]
 * @param[out] out_data                 [数据输出缓存区]
 * @param[out] out_len                  [数据输出长度]
 * @return     int32_t                  [0表示成功, 非零表示失败]
 */
int32_t vesync_tl_payload_encode(uint16_t op_code, uint8_t status_code, uint8_t *in_data,
                                         uint16_t in_len, uint8_t *out_data, uint16_t *out_len)
{
    uint16_t data_len = 0;
    tl_payload_info_t *p_paylaod = NULL;

    if ((NULL == in_data) && (0 != in_len))
    {
        return -1;
    }

    if ((NULL == out_data) || (NULL == out_len))
    {
        return -1;
    }

    data_len = in_len + TL_PAYLOAD_PROTOCOL_HEAD_LEN; // payload协议头部长度为4bytes

    p_paylaod = (tl_payload_info_t *)out_data;

    p_paylaod->version = TL_PAYLOAD_PROTOCOL_VERSION;
    p_paylaod->op_code = op_code;
    p_paylaod->status_code = status_code;

    if (NULL != in_data)
    {
        memcpy(p_paylaod->payload_data, in_data, in_len);
    }

    *out_len = data_len;

    return 0;
}
