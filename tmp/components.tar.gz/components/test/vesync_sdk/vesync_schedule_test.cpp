/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_schedule_test.cpp
 * @brief       vesync schedule测试用例
 * @author      Herve
 * @date        2021-11-12
 */

#include <map>
#include <vector>
#include <cstdlib>
#include <ctime>

#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <gtest/gtest.h>
#include <sys/sysinfo.h>

#include "vesync_common.h"
#include "vesync_log_internal.h"
#include "vesync_schedule_internal.h"
#include "vesync_timebase_internal.h"

#include "stub.h"
#include "vesync_schedule.c"
#include "vesync_schedule_config.c"

#define LOG(...) SDK_LOG(LOG_DEBUG, __VA_ARGS__)
#define DEFAULT_INSTANCE_HANDLE_ID (0)
#define PRINT_FREE_HEAP_SIZE()                         \
    do                                                 \
    {                                                  \
        struct sysinfo info;                           \
        sysinfo(&info);                                \
        LOG(">> free_heap_size: %ld\n", info.freeram); \
    } while (0)

typedef std::vector<char> map_key_t;
typedef std::vector<uint8_t> map_value_t;

typedef std::map<map_key_t, map_value_t> mock_kv_t;
typedef std::map<int, mock_kv_t> mock_ptn_t;

static mock_ptn_t s_mock_flash;

static map_key_t convert_char_key(const char *key)
{
    map_key_t map_key;
    for (size_t i = 0; i < strlen(key); i++)
    {
        map_key.push_back(key[i]);
    }
    return map_key;
}

static map_value_t convert_bytes_value(uint8_t *value, uint32_t len)
{
    map_value_t map_value;
    for (size_t i = 0; i < len; i++)
    {
        map_value.push_back(value[i]);
    }
    return map_value;
}

static int vhal_flash_read_mock(PARTITION_ID_E pid, const char *key, uint8_t *p_data, uint32_t *p_len)
{
    map_key_t k = convert_char_key(key);
    if (s_mock_flash[(int)pid].find(k) == s_mock_flash[(int)pid].end())
    {
        LOG("raw flash\n");
        return VHAL_FAIL;
    }

    size_t value_len = s_mock_flash[(int)pid][k].size();
    *p_len = (uint32_t)value_len;
    if (p_data != nullptr)
    {
        for (size_t i = 0; i < value_len; i++)
        {
            p_data[i] = s_mock_flash[(int)pid][k][i];
        }
    }

    LOG("pid: %d, key: %s, buf: %p, read_out: %d\n", pid, key, p_data, *p_len);
    return VHAL_OK;
}

static int vhal_flash_write_mock(PARTITION_ID_E pid, const char *key, uint8_t *p_data, uint32_t len)
{
    map_key_t k = convert_char_key(key);
    map_value_t v = convert_bytes_value(p_data, len);

    mock_kv_t kv;
    kv[k] = v;

    s_mock_flash[(int)pid] = kv;

    LOG("pid: %d, key: %s, write_in: %d\n", pid, key, len);
    return VHAL_OK;
}

static void clear_mock_flash(void)
{
    mock_ptn_t::iterator it;
    for (it = s_mock_flash.begin(); it != s_mock_flash.end(); it++)
    {
        s_mock_flash[it->first].clear();
    }

    s_mock_flash.clear();
}

static int s_execute_flag = 0;

static void reset_execute_flag(int f)
{
    s_execute_flag = f;
}

static void set_execute_flag(void)
{
    s_execute_flag += 1;
}

static int raw_execute_flag(void)
{
    return s_execute_flag - 1;
}

static int exec_app_task_cb_stub(vesync_schedule_t sch_cfg, vesync_buf_t app_cfg)
{
    int ret;

    uint32_t exec_cnt = 0;
    ret = vesync_schedule_get_exec_cnt(DEFAULT_INSTANCE_HANDLE_ID, sch_cfg.id, &exec_cnt);
    EXPECT_EQ(ret, SCHE_OK);

    uint32_t total_num = 0;
    ret = vesync_schedule_get_total_num(DEFAULT_INSTANCE_HANDLE_ID, &total_num);
    EXPECT_EQ(ret, SCHE_OK);

    LOG("Schedule task executes. sche_id[%d], exec_cnt[%d], total_num[%d]\n", sch_cfg.id, exec_cnt, total_num);

    set_execute_flag();

    return 0;
}

class vesync_schedule_test : public testing::Test
{
public:
    uint32_t max_app_cfg_size = 10;
    uint32_t min_id_limit = 100;
    uint32_t max_sche_nbr = 5;
    uint32_t instance_id = DEFAULT_INSTANCE_HANDLE_ID;

    static timebase_info_t mock_tb;
    static vesync_timer_t *mock_timer;
    static void *timer_cb;
    static void *timer_cb_arg;
    static uint32_t mock_utc;

    void schedule_run_once(void)
    {
        if (timer_cb != nullptr)
        {
            ((void (*)(void *))timer_cb)(timer_cb_arg);
        }
    }

private:
    Stub stub;

    static vesync_timer_t *vesync_timer_new_mock(const char *, void (*)(void *), void *, long, bool);
    static int vesync_timer_start_mock(vesync_timer_t *);
    static int vesync_timer_stop_mock(vesync_timer_t *);
    static int vesync_timer_free_mock(vesync_timer_t *);
    static int vesync_timebase_get_info_mock(uint32_t, timebase_info_t *);
    static uint32_t vhal_utils_get_system_time_sec_mock(void);

protected:
    static void SetUpTestCase()
    {
        vesync_log_init();
        PRINT_FREE_HEAP_SIZE();
    }

    virtual void SetUp()
    {
        int ret;

        this->stub.set(vhal_flash_read, vhal_flash_read_mock);
        this->stub.set(vhal_flash_write, vhal_flash_write_mock);

        this->stub.set(vesync_timer_new, vesync_timer_new_mock);
        this->stub.set(vesync_timer_start, vesync_timer_start_mock);
        this->stub.set(vesync_timer_stop, vesync_timer_stop_mock);
        this->stub.set(vesync_timer_free, vesync_timer_free_mock);

        this->stub.set(vesync_timebase_get_info, vesync_timebase_get_info_mock);
        this->stub.set(vhal_utils_get_system_time_sec, vhal_utils_get_system_time_sec_mock);

        clear_mock_flash();

        // 北京时间 2021-11-18 08:00:00
        this->mock_utc = 1637193600;
        this->mock_tb.local_ts = this->mock_utc + 3600 * 8;
        this->mock_tb.local_clk_sec = 3600 * 8;
        this->mock_tb.sunrise_clk = 3600 * 6;
        this->mock_tb.sunset_clk = 3600 * 18;
        this->mock_tb.is_sunrise_valid = true;
        this->mock_tb.is_sunset_valid = true;

        ret = vesync_schedule_main_init();
        EXPECT_EQ(ret, SCHE_OK);

        vesync_schedule_param_t sche_param;
        sche_param.rd_cfg_cb = NULL;
        sche_param.wr_cfg_cb = NULL;
        sche_param.exec_app_task_cb = exec_app_task_cb_stub;
        sche_param.max_app_cfg_size = this->max_app_cfg_size;
        sche_param.min_id_limit = this->min_id_limit;
        sche_param.max_sche_nbr = this->max_sche_nbr;

        ret = vesync_schedule_new_instance(this->instance_id, &sche_param);
        EXPECT_EQ(ret, SCHE_OK);
    }

    virtual void TearDown()
    {
        int ret;

        ret = vesync_schedule_destroy_instance(this->instance_id);
        EXPECT_EQ(ret, SCHE_OK);

        this->mock_utc = 0;
        this->mock_tb.local_ts = 0;
        this->mock_tb.local_clk_sec = 0;
        this->mock_tb.sunrise_clk = 0;
        this->mock_tb.sunset_clk = 0;
        this->mock_tb.is_sunrise_valid = false;
        this->mock_tb.is_sunset_valid = false;

        ret = vesync_schedule_main_deinit();
        EXPECT_EQ(ret, SCHE_OK);

        this->stub.reset(vhal_flash_read);
        this->stub.reset(vhal_flash_write);

        this->stub.reset(vesync_timer_new);
        this->stub.reset(vesync_timer_start);
        this->stub.reset(vesync_timer_stop);
        this->stub.reset(vesync_timer_free);

        this->stub.reset(vesync_timebase_get_info);
        this->stub.reset(vhal_utils_get_system_time_sec);
    }

    static void TearDownTestCase()
    {
        PRINT_FREE_HEAP_SIZE();
        vesync_log_deinit();
    }
};

vesync_timer_t *vesync_schedule_test::mock_timer = nullptr;
void *vesync_schedule_test::timer_cb = nullptr;
void *vesync_schedule_test::timer_cb_arg = nullptr;
timebase_info_t vesync_schedule_test::mock_tb = {0};
uint32_t vesync_schedule_test::mock_utc = 0;

vesync_timer_t *vesync_schedule_test::vesync_timer_new_mock(const char *name,
                                                            void (*cb)(void *),
                                                            void *cb_arg,
                                                            long timeout_ms,
                                                            bool reload)
{
    LOG("name: %s, timeout: %d, reload: %d\n", name, timeout_ms, reload);

    vesync_timer_t *p_timer = (vesync_timer_t *)malloc(0);

    if (nullptr == mock_timer)
    {
        mock_timer = p_timer;
        timer_cb = (void *)cb;
        timer_cb_arg = cb_arg;
    }

    return p_timer;
}

int vesync_schedule_test::vesync_timer_start_mock(vesync_timer_t *timer)
{
    LOG("mock_timer: %p\n", timer);
    return VOS_OK;
}

int vesync_schedule_test::vesync_timer_stop_mock(vesync_timer_t *timer)
{
    LOG("mock_timer: %p\n", timer);
    return VOS_OK;
}

int vesync_schedule_test::vesync_timer_free_mock(vesync_timer_t *timer)
{
    LOG("mock_timer: %p\n", timer);

    if (timer == mock_timer)
    {
        mock_timer = nullptr;
        timer_cb = nullptr;
        timer_cb_arg = nullptr;
    }

    free(timer);

    return VOS_OK;
}

int vesync_schedule_test::vesync_timebase_get_info_mock(uint32_t utc, timebase_info_t *p_tb_info)
{
    LOG("get tb_info: %d\n", utc);

    memcpy(p_tb_info, &mock_tb, sizeof(timebase_info_t));
    return TMBS_OK;
}

uint32_t vesync_schedule_test::vhal_utils_get_system_time_sec_mock(void)
{
    LOG("get mock_utc: %d\n", mock_utc);

    return mock_utc;
}

static bool is_sch_cfg_eq(vesync_schedule_t *cfg_a, vesync_schedule_t *cfg_b)
{
    if (cfg_a->id != cfg_b->id)
    {
        return false;
    }
    if (cfg_a->repeat_config != cfg_b->repeat_config)
    {
        return false;
    }
    if (cfg_a->type != cfg_b->type)
    {
        return false;
    }
    if (cfg_a->enabled != cfg_b->enabled)
    {
        return false;
    }
    switch (cfg_a->type)
    {
    case SCHE_TMG_EVT:
        if (cfg_a->event_config.timing.clock_sec != cfg_b->event_config.timing.clock_sec)
        {
            return false;
        }
        break;
    case SCHE_SUN_EVT:
        if (cfg_a->event_config.sun.is_sunrise != cfg_b->event_config.sun.is_sunrise)
        {
            return false;
        }
        if (cfg_a->event_config.sun.offset_sec != cfg_b->event_config.sun.offset_sec)
        {
            return false;
        }
        break;
    default:
        return false;
    }

    return true;
}

static void print_schedule_cfg(vesync_schedule_t *p_sch_cfg)
{
    if (p_sch_cfg->type == SCHE_TMG_EVT)
    {
        SDK_LOG(LOG_DEBUG, "Schedule print. ID:[%ld], en:[%d], type:[%d], clk_sec:[%ld], rpt_cfg:[%d]\n",
                p_sch_cfg->id, p_sch_cfg->enabled, p_sch_cfg->type,
                p_sch_cfg->event_config.timing.clock_sec, p_sch_cfg->repeat_config);
    }

    if (p_sch_cfg->type == SCHE_SUN_EVT)
    {
        SDK_LOG(LOG_DEBUG, "Schedule print. ID:[%ld], en:[%d], type:[%d], is_sr:[%d], ofs_sec:[%ld], rpt_cfg:[%d]\n",
                p_sch_cfg->id, p_sch_cfg->enabled, p_sch_cfg->type,
                p_sch_cfg->event_config.sun.is_sunrise,
                p_sch_cfg->event_config.sun.offset_sec, p_sch_cfg->repeat_config);
    }
}

TEST_F(vesync_schedule_test, vesync_schedule_init_test)
{
    int ret;

    vesync_schedule_param_t sche_param;
    sche_param.rd_cfg_cb = NULL;
    sche_param.wr_cfg_cb = NULL;
    sche_param.exec_app_task_cb = exec_app_task_cb_stub;
    sche_param.max_app_cfg_size = 10;
    sche_param.min_id_limit = 100;
    sche_param.max_sche_nbr = 10;

    for (uint32_t i = 1; i <= SCHEDULE_MAX_INSTANCES_NBR; i++)
    {
        ret = vesync_schedule_new_instance(i, &sche_param);
        if (i < SCHEDULE_MAX_INSTANCES_NBR)
        {
            EXPECT_EQ(ret, SCHE_OK);
        }
        else
        {
            EXPECT_EQ(ret, SCHE_ERR);
        }
    }

    for (uint32_t i = 1; i <= SCHEDULE_MAX_INSTANCES_NBR; i++)
    {
        ret = vesync_schedule_destroy_instance(i);
        if (i < SCHEDULE_MAX_INSTANCES_NBR)
        {
            EXPECT_EQ(ret, SCHE_OK);
        }
        else
        {
            EXPECT_EQ(ret, SCHE_ERR);
        }
    }
}

#if 1
TEST_F(vesync_schedule_test, vesync_schedule_add_param_check_test)
{
    int ret;

    vesync_schedule_t inv_sche_cfg;
    vesync_buf_t inv_app_cfg = vesync_buf_new();

    inv_sche_cfg.enabled = true;
    inv_sche_cfg.type = SCHE_TMG_EVT;
    inv_sche_cfg.repeat_config = (uint8_t)TMBS_ONCE;
    // 非法定时值
    inv_sche_cfg.event_config.timing.clock_sec = 86400;
    ret = vesync_schedule_add(this->instance_id, &inv_sche_cfg, &inv_app_cfg, true);
    EXPECT_EQ(ret, SCHE_INV_CFG_PARAM);

    inv_sche_cfg.type = SCHE_SUN_EVT;
    inv_sche_cfg.event_config.sun.is_sunrise = false;
    // 非法偏移
    inv_sche_cfg.event_config.sun.offset_sec = -86400;
    ret = vesync_schedule_add(this->instance_id, &inv_sche_cfg, &inv_app_cfg, true);
    EXPECT_EQ(ret, SCHE_INV_CFG_PARAM);
    // 非法偏移
    inv_sche_cfg.event_config.sun.offset_sec = 86400;
    ret = vesync_schedule_add(this->instance_id, &inv_sche_cfg, &inv_app_cfg, true);
    EXPECT_EQ(ret, SCHE_INV_CFG_PARAM);

    // 非法APP数据大小
    char app_data[] = "this is a invalid app_data content";
    EXPECT_EQ(true, strlen(app_data) > this->max_app_cfg_size);
    vesync_buf_set(&inv_app_cfg, app_data, strlen(app_data));
    inv_sche_cfg.type = SCHE_TMG_EVT;
    inv_sche_cfg.event_config.timing.clock_sec = 3600;
    ret = vesync_schedule_add(this->instance_id, &inv_sche_cfg, &inv_app_cfg, true);
    EXPECT_EQ(ret, SCHE_INV_APP_CFG_SIZE);

    vesync_buf_clr(&inv_app_cfg);
}
#endif

#if 1
TEST_F(vesync_schedule_test, vesync_schedule_mult_add_test)
{
    int ret;

    vesync_schedule_t dup_sche_cfg;
    vesync_buf_t dup_app_cfg = vesync_buf_new();
    dup_sche_cfg.enabled = true;
    dup_sche_cfg.type = SCHE_TMG_EVT;
    dup_sche_cfg.repeat_config = (uint8_t)TMBS_ONCE;
    dup_sche_cfg.event_config.timing.clock_sec = 500;
    dup_sche_cfg.id = 130;
    ret = vesync_schedule_add(this->instance_id, &dup_sche_cfg, &dup_app_cfg, false);
    EXPECT_EQ(ret, SCHE_OK);
    PRINT_FREE_HEAP_SIZE();

    dup_sche_cfg.event_config.timing.clock_sec = 1500;
    ret = vesync_schedule_add(this->instance_id, &dup_sche_cfg, &dup_app_cfg, false);
    EXPECT_EQ(ret, SCHE_ID_EXIST_ERR);
    PRINT_FREE_HEAP_SIZE();

    ret = vesync_schedule_del(this->instance_id, dup_sche_cfg.id);
    EXPECT_EQ(ret, SCHE_OK);
    PRINT_FREE_HEAP_SIZE();

    std::vector<vesync_schedule_t> sche_cfg_list;
    std::vector<vesync_buf_t> app_cfg_list;

    for (uint32_t i = 0; i <= this->max_sche_nbr; i++)
    {
        vesync_schedule_t sche_cfg;
        vesync_buf_t app_cfg = vesync_buf_new();

        sche_cfg.enabled = true;
        sche_cfg.type = SCHE_TMG_EVT;
        sche_cfg.repeat_config = (uint8_t)TMBS_ONCE;
        sche_cfg.event_config.timing.clock_sec = 120 * i;
        vesync_buf_set(&app_cfg, &i, sizeof(i));

        ret = vesync_schedule_add(this->instance_id, &sche_cfg, &app_cfg, true);
        if (i < this->max_sche_nbr)
        {
            EXPECT_EQ(ret, SCHE_OK);
            PRINT_FREE_HEAP_SIZE();

            sche_cfg_list.push_back(sche_cfg);
            app_cfg_list.push_back(app_cfg);
        }
        else
        {
            EXPECT_EQ(ret, SCHE_EXCEED_MAX);
            vesync_buf_clr(&app_cfg);
        }
    }

    ret = vesync_schedule_destroy_instance(this->instance_id);
    EXPECT_EQ(ret, SCHE_OK);

    vesync_schedule_param_t sche_param;
    sche_param.rd_cfg_cb = NULL;
    sche_param.wr_cfg_cb = NULL;
    sche_param.exec_app_task_cb = exec_app_task_cb_stub;
    sche_param.max_app_cfg_size = this->max_app_cfg_size;
    sche_param.min_id_limit = this->min_id_limit;
    sche_param.max_sche_nbr = this->max_sche_nbr;

    ret = vesync_schedule_new_instance(this->instance_id, &sche_param);
    EXPECT_EQ(ret, SCHE_OK);

    for (uint32_t i = 0; i < this->max_sche_nbr; i++)
    {
        vesync_schedule_t sche_cfg;
        vesync_buf_t app_cfg = vesync_buf_new();

        ret = vesync_schedule_get_by_id(this->instance_id, sche_cfg_list[i].id, &sche_cfg, &app_cfg);
        EXPECT_EQ(ret, SCHE_OK);
        EXPECT_EQ(is_sch_cfg_eq(&sche_cfg_list[i], &sche_cfg), true);
        print_schedule_cfg(&sche_cfg);

        int app_data, app_data_read;
        vesync_buf_get(&app_cfg, &app_data_read, sizeof(app_data_read));
        vesync_buf_get(&app_cfg_list[i], &app_data, sizeof(app_data));
        EXPECT_EQ(app_data, app_data_read);

        vesync_buf_clr(&app_cfg);
        vesync_buf_clr(&app_cfg_list[i]);
    }

    uint32_t total_num = 0;
    ret = vesync_schedule_get_total_num(DEFAULT_INSTANCE_HANDLE_ID, &total_num);
    EXPECT_EQ(ret, SCHE_OK);

    uint32_t limit = total_num - 1;
    EXPECT_EQ(true, limit > 0);
    EXPECT_EQ(true, limit < total_num);

    vesync_schedule_t *sche_cfg_array = (vesync_schedule_t *)malloc(sizeof(vesync_schedule_t) * limit);
    vesync_buf_t *app_cfg_array = (vesync_buf_t *)malloc(sizeof(vesync_buf_t) * limit);
    for (uint32_t i = 0; i < limit; i++)
    {
        app_cfg_array[i] = vesync_buf_new();
    }

    uint32_t total_num_get_by_idx = 0;
    uint32_t rd_out_num = 0;
    ret = vesync_schedule_get_by_index(DEFAULT_INSTANCE_HANDLE_ID,
                                       0, limit, &total_num_get_by_idx,
                                       sche_cfg_array, app_cfg_array, &rd_out_num);
    EXPECT_EQ(ret, SCHE_OK);
    EXPECT_EQ(total_num, total_num_get_by_idx);
    EXPECT_EQ(limit, rd_out_num);

    for (uint32_t i = 0; i < limit; i++)
    {
        vesync_buf_clr(&app_cfg_array[i]);
    }
    free(sche_cfg_array);
    free(app_cfg_array);

    ret = vesync_schedule_clear(DEFAULT_INSTANCE_HANDLE_ID);
    EXPECT_EQ(ret, SCHE_OK);
    PRINT_FREE_HEAP_SIZE();
}
#endif

#if 1
TEST_F(vesync_schedule_test, vesync_schedule_execute_test)
{
    int ret;

    // 北京时间 2021-11-18 08:00:00
    this->mock_utc = 1637193600;
    this->mock_tb.local_ts = this->mock_utc + 3600 * 8;
    this->mock_tb.local_clk_sec = 3600 * 8;
    this->mock_tb.sunrise_clk = 3600 * 6;
    this->mock_tb.sunset_clk = 3600 * 18;
    this->mock_tb.is_sunrise_valid = true;
    this->mock_tb.is_sunset_valid = true;

    vesync_schedule_t sche_cfg;
    vesync_buf_t app_cfg = vesync_buf_new();

    sche_cfg.enabled = true;
    sche_cfg.type = SCHE_TMG_EVT;
    sche_cfg.repeat_config = (uint8_t)TMBS_ONCE;
    // 设置在十点
    sche_cfg.event_config.timing.clock_sec = 3600 * 10;
    ret = vesync_schedule_add(this->instance_id, &sche_cfg, &app_cfg, true);
    EXPECT_EQ(ret, SCHE_OK);

    uint32_t flag;
    std::srand(std::time(NULL));

    // 标记
    flag = std::rand();
    reset_execute_flag(flag);
    this->schedule_run_once();
    // Schedule应该不被执行
    EXPECT_EQ(flag, s_execute_flag);

    // 北京时间 2021-11-18 10:00:00
    this->mock_utc = 1637200800;
    this->mock_tb.local_ts = this->mock_utc + 3600 * 8;
    this->mock_tb.local_clk_sec = 3600 * 10;
    // Schedule应该被执行
    this->schedule_run_once();
    EXPECT_EQ(flag, raw_execute_flag());

    sche_cfg.enabled = true;
    sche_cfg.type = SCHE_TMG_EVT;
    // 设置在星期四十一点
    sche_cfg.repeat_config = (uint8_t)TMBS_BIT_THU;
    sche_cfg.event_config.timing.clock_sec = 3600 * 11;
    ret = vesync_schedule_add(this->instance_id, &sche_cfg, &app_cfg, true);
    EXPECT_EQ(ret, SCHE_OK);

    // 标记
    flag = std::rand();
    reset_execute_flag(flag);

    // 北京时间 2021-11-18 11:00:00
    this->mock_utc = 1637204400;
    this->mock_tb.local_ts = this->mock_utc + 3600 * 8;
    this->mock_tb.local_clk_sec = 3600 * 11;
    // Schedule应该被执行
    this->schedule_run_once();
    EXPECT_EQ(flag, raw_execute_flag());

    // 标记
    flag = std::rand();
    reset_execute_flag(flag);

    // 北京时间 2021-11-25 11:00:00
    this->mock_utc = 1637204400 + 604800;
    this->mock_tb.local_ts = this->mock_utc + 3600 * 8;
    this->mock_tb.local_clk_sec = 3600 * 11;
    // Schedule应该被执行
    this->schedule_run_once();
    EXPECT_EQ(flag, raw_execute_flag());

    // 标记
    flag = std::rand();
    reset_execute_flag(flag);

    // 北京时间 2021-12-02 11:00:00
    this->mock_utc = 1637204400 + 604800 + 604800;
    this->mock_tb.local_ts = this->mock_utc + 3600 * 8;
    this->mock_tb.local_clk_sec = 3600 * 11;
    // Schedule应该被执行
    this->schedule_run_once();
    EXPECT_EQ(flag, raw_execute_flag());
}
#endif

TEST_F(vesync_schedule_test, vesync_schedule_conflict_test_1)
{
    int ret;

    // 北京时间 2021-11-18 08:00:00，星期四
    this->mock_utc = 1637193600;
    this->mock_tb.local_ts = this->mock_utc + 3600 * 8;
    this->mock_tb.local_clk_sec = 3600 * 8;
    this->mock_tb.sunrise_clk = 3600 * 6;
    this->mock_tb.sunset_clk = 3600 * 18;
    this->mock_tb.is_sunrise_valid = true;
    this->mock_tb.is_sunset_valid = true;

    vesync_schedule_t sche_cfg;
    vesync_buf_t app_cfg = vesync_buf_new();

    sche_cfg.enabled = true;
    sche_cfg.type = SCHE_TMG_EVT;
    sche_cfg.repeat_config = (uint8_t)TMBS_ONCE;
    // 设置在十点
    sche_cfg.event_config.timing.clock_sec = 3600 * 10;
    ret = vesync_schedule_add(this->instance_id, &sche_cfg, &app_cfg, true);
    EXPECT_EQ(ret, SCHE_OK);

    sche_cfg.enabled = true;
    sche_cfg.type = SCHE_TMG_EVT;
    sche_cfg.repeat_config = (uint8_t)TMBS_BIT_THU;
    sche_cfg.event_config.timing.clock_sec = 3600 * 10;
    ret = vesync_schedule_add(this->instance_id, &sche_cfg, &app_cfg, true);
    EXPECT_EQ(ret, SCHE_CFLT_ERR);

    sche_cfg.enabled = true;
    sche_cfg.type = SCHE_TMG_EVT;
    sche_cfg.repeat_config = (uint8_t)TMBS_BIT_WED;
    sche_cfg.event_config.timing.clock_sec = 3600 * 10;
    ret = vesync_schedule_add(this->instance_id, &sche_cfg, &app_cfg, true);
    EXPECT_EQ(ret, SCHE_OK);

    sche_cfg.enabled = true;
    sche_cfg.type = SCHE_TMG_EVT;
    sche_cfg.repeat_config = (uint8_t)TMBS_BIT_FRI;
    sche_cfg.event_config.timing.clock_sec = 3600 * 10;
    ret = vesync_schedule_add(this->instance_id, &sche_cfg, &app_cfg, true);
    EXPECT_EQ(ret, SCHE_OK);
}

TEST_F(vesync_schedule_test, vesync_schedule_conflict_test_2)
{
    int ret;

    // 北京时间 2021-11-18 08:00:00，星期四
    this->mock_utc = 1637193600;
    this->mock_tb.local_ts = this->mock_utc + 3600 * 8;
    this->mock_tb.local_clk_sec = 3600 * 8;
    this->mock_tb.sunrise_clk = 3600 * 6;
    this->mock_tb.sunset_clk = 3600 * 18;
    this->mock_tb.is_sunrise_valid = true;
    this->mock_tb.is_sunset_valid = true;

    vesync_schedule_t sche_cfg;
    vesync_buf_t app_cfg = vesync_buf_new();

    sche_cfg.enabled = true;
    sche_cfg.type = SCHE_TMG_EVT;
    sche_cfg.repeat_config = (uint8_t)TMBS_BIT_FRI;
    // 设置在7点
    sche_cfg.event_config.timing.clock_sec = 3600 * 7;
    ret = vesync_schedule_add(this->instance_id, &sche_cfg, &app_cfg, true);
    EXPECT_EQ(ret, SCHE_OK);

    sche_cfg.enabled = true;
    sche_cfg.type = SCHE_TMG_EVT;
    sche_cfg.repeat_config = (uint8_t)TMBS_ONCE;
    // 设置在7点，也就是后一天星期五才执行
    sche_cfg.event_config.timing.clock_sec = 3600 * 7;
    ret = vesync_schedule_add(this->instance_id, &sche_cfg, &app_cfg, true);
    EXPECT_EQ(ret, SCHE_CFLT_ERR);

    sche_cfg.enabled = true;
    sche_cfg.type = SCHE_TMG_EVT;
    sche_cfg.repeat_config = (uint8_t)TMBS_ONCE;
    sche_cfg.event_config.timing.clock_sec = 3600 * 6;
    ret = vesync_schedule_add(this->instance_id, &sche_cfg, &app_cfg, true);
    EXPECT_EQ(ret, SCHE_OK);

    sche_cfg.enabled = true;
    sche_cfg.type = SCHE_TMG_EVT;
    sche_cfg.repeat_config = (uint8_t)TMBS_ONCE;
    sche_cfg.event_config.timing.clock_sec = 3600 * 8;
    ret = vesync_schedule_add(this->instance_id, &sche_cfg, &app_cfg, true);
    EXPECT_EQ(ret, SCHE_OK);
}

TEST_F(vesync_schedule_test, vesync_schedule_conflict_test_3)
{
    int ret;

    // 北京时间 2021-11-18 08:00:00，星期四
    this->mock_utc = 1637193600;
    this->mock_tb.local_ts = this->mock_utc + 3600 * 8;
    this->mock_tb.local_clk_sec = 3600 * 8;
    this->mock_tb.sunrise_clk = 3600 * 6;
    this->mock_tb.sunset_clk = 3600 * 18;
    this->mock_tb.is_sunrise_valid = true;
    this->mock_tb.is_sunset_valid = true;

    vesync_schedule_t sche_cfg;
    vesync_buf_t app_cfg = vesync_buf_new();

    sche_cfg.enabled = true;
    sche_cfg.type = SCHE_SUN_EVT;
    sche_cfg.repeat_config = (uint8_t)TMBS_ONCE;
    // 设置在日出前2小时，将在第二天执行，也就是周五
    sche_cfg.event_config.sun.is_sunrise = true;
    sche_cfg.event_config.sun.offset_sec = 3600 * -2;
    ret = vesync_schedule_add(this->instance_id, &sche_cfg, &app_cfg, true);
    EXPECT_EQ(ret, SCHE_OK);

    sche_cfg.enabled = true;
    sche_cfg.type = SCHE_SUN_EVT;
    sche_cfg.repeat_config = (uint8_t)TMBS_BIT_FRI;
    sche_cfg.event_config.sun.is_sunrise = true;
    sche_cfg.event_config.sun.offset_sec = 3600 * -2;
    ret = vesync_schedule_add(this->instance_id, &sche_cfg, &app_cfg, true);
    EXPECT_EQ(ret, SCHE_CFLT_ERR);

    sche_cfg.enabled = true;
    sche_cfg.type = SCHE_SUN_EVT;
    sche_cfg.repeat_config = (uint8_t)TMBS_BIT_THU;
    sche_cfg.event_config.sun.is_sunrise = true;
    sche_cfg.event_config.sun.offset_sec = 3600 * -2;
    ret = vesync_schedule_add(this->instance_id, &sche_cfg, &app_cfg, true);
    EXPECT_EQ(ret, SCHE_OK);

    sche_cfg.enabled = true;
    sche_cfg.type = SCHE_SUN_EVT;
    sche_cfg.repeat_config = (uint8_t)TMBS_BIT_SAT;
    sche_cfg.event_config.sun.is_sunrise = true;
    sche_cfg.event_config.sun.offset_sec = 3600 * -2;
    ret = vesync_schedule_add(this->instance_id, &sche_cfg, &app_cfg, true);
    EXPECT_EQ(ret, SCHE_OK);
}

TEST_F(vesync_schedule_test, vesync_schedule_conflict_test_4)
{
    int ret;

    // 北京时间 2021-11-18 08:00:00，星期四
    this->mock_utc = 1637193600;
    this->mock_tb.local_ts = this->mock_utc + 3600 * 8;
    this->mock_tb.local_clk_sec = 3600 * 8;
    this->mock_tb.sunrise_clk = 3600 * 6;
    this->mock_tb.sunset_clk = 3600 * 18;
    this->mock_tb.is_sunrise_valid = true;
    this->mock_tb.is_sunset_valid = true;

    vesync_schedule_t sche_cfg;
    vesync_buf_t app_cfg = vesync_buf_new();

    sche_cfg.enabled = true;
    sche_cfg.type = SCHE_SUN_EVT;
    sche_cfg.repeat_config = (uint8_t)TMBS_ONCE;
    // 设置在日出前9小时，将在今天的晚上23点执行
    sche_cfg.event_config.sun.is_sunrise = true;
    sche_cfg.event_config.sun.offset_sec = 3600 * -9;
    ret = vesync_schedule_add(this->instance_id, &sche_cfg, &app_cfg, true);
    EXPECT_EQ(ret, SCHE_OK);

    sche_cfg.enabled = true;
    sche_cfg.type = SCHE_SUN_EVT;
    sche_cfg.repeat_config = (uint8_t)TMBS_BIT_THU;
    sche_cfg.event_config.sun.is_sunrise = true;
    sche_cfg.event_config.sun.offset_sec = 3600 * -9;
    ret = vesync_schedule_add(this->instance_id, &sche_cfg, &app_cfg, true);
    EXPECT_EQ(ret, SCHE_CFLT_ERR);

    sche_cfg.enabled = true;
    sche_cfg.type = SCHE_SUN_EVT;
    sche_cfg.repeat_config = (uint8_t)TMBS_BIT_WED;
    sche_cfg.event_config.sun.is_sunrise = true;
    sche_cfg.event_config.sun.offset_sec = 3600 * -9;
    ret = vesync_schedule_add(this->instance_id, &sche_cfg, &app_cfg, true);
    EXPECT_EQ(ret, SCHE_OK);

    sche_cfg.enabled = true;
    sche_cfg.type = SCHE_SUN_EVT;
    sche_cfg.repeat_config = (uint8_t)TMBS_BIT_FRI;
    sche_cfg.event_config.sun.is_sunrise = true;
    sche_cfg.event_config.sun.offset_sec = 3600 * -9;
    ret = vesync_schedule_add(this->instance_id, &sche_cfg, &app_cfg, true);
    EXPECT_EQ(ret, SCHE_OK);
}

TEST_F(vesync_schedule_test, vesync_schedule_conflict_test_5)
{
    int ret;

    // 北京时间 2021-11-18 08:00:00，星期四
    this->mock_utc = 1637193600;
    this->mock_tb.local_ts = this->mock_utc + 3600 * 8;
    this->mock_tb.local_clk_sec = 3600 * 8;
    this->mock_tb.sunrise_clk = 3600 * 6;
    this->mock_tb.sunset_clk = 3600 * 18;
    this->mock_tb.is_sunrise_valid = true;
    this->mock_tb.is_sunset_valid = true;

    vesync_schedule_t sche_cfg;
    vesync_buf_t app_cfg = vesync_buf_new();

    sche_cfg.enabled = true;
    sche_cfg.type = SCHE_SUN_EVT;
    sche_cfg.repeat_config = (uint8_t)TMBS_ONCE;
    // 设置在日落后6小时，将在第二天（星期5）的早上1点执行
    sche_cfg.event_config.sun.is_sunrise = false;
    sche_cfg.event_config.sun.offset_sec = 3600 * 7;
    ret = vesync_schedule_add(this->instance_id, &sche_cfg, &app_cfg, true);
    EXPECT_EQ(ret, SCHE_OK);

    sche_cfg.enabled = true;
    sche_cfg.type = SCHE_SUN_EVT;
    sche_cfg.repeat_config = (uint8_t)TMBS_BIT_FRI;
    sche_cfg.event_config.sun.is_sunrise = false;
    sche_cfg.event_config.sun.offset_sec = 3600 * 7;
    ret = vesync_schedule_add(this->instance_id, &sche_cfg, &app_cfg, true);
    EXPECT_EQ(ret, SCHE_CFLT_ERR);

    sche_cfg.enabled = true;
    sche_cfg.type = SCHE_SUN_EVT;
    sche_cfg.repeat_config = (uint8_t)TMBS_BIT_THU;
    sche_cfg.event_config.sun.is_sunrise = false;
    sche_cfg.event_config.sun.offset_sec = 3600 * 7;
    ret = vesync_schedule_add(this->instance_id, &sche_cfg, &app_cfg, true);
    EXPECT_EQ(ret, SCHE_OK);

    sche_cfg.enabled = true;
    sche_cfg.type = SCHE_SUN_EVT;
    sche_cfg.repeat_config = (uint8_t)TMBS_BIT_SAT;
    sche_cfg.event_config.sun.is_sunrise = false;
    sche_cfg.event_config.sun.offset_sec = 3600 * 7;
    ret = vesync_schedule_add(this->instance_id, &sche_cfg, &app_cfg, true);
    EXPECT_EQ(ret, SCHE_OK);
}

static void clk_sec_to_time(uint32_t clk_sec, char *buffer)
{
    sprintf(buffer, "h%02d-m%02d-s%02d", clk_sec / 3600, clk_sec % 3600 / 60, clk_sec % 60);
}

TEST_F(vesync_schedule_test, vesync_schedule_get_next_exec_test_1)
{
    int ret;

    // 北京时间 2021-11-18 08:00:00，星期四
    this->mock_utc = 1637193600;
    this->mock_tb.local_ts = this->mock_utc + 3600 * 8;
    this->mock_tb.local_clk_sec = 3600 * 8;
    this->mock_tb.sunrise_clk = 3600 * 6;
    this->mock_tb.sunset_clk = 3600 * 18;
    this->mock_tb.is_sunrise_valid = true;
    this->mock_tb.is_sunset_valid = true;

    uint32_t next_exec;

    ret = vesync_schedule_get_next_exc_sec(this->instance_id, &next_exec);
    EXPECT_EQ(ret, SCHE_INV_ID_ERR);
}

TEST_F(vesync_schedule_test, vesync_schedule_get_next_exec_test_2)
{
    int ret;

    // 北京时间 2021-11-18 08:00:00，星期四
    this->mock_utc = 1637193600;
    this->mock_tb.local_ts = this->mock_utc + 3600 * 8;
    this->mock_tb.local_clk_sec = 3600 * 8;
    this->mock_tb.sunrise_clk = 3600 * 6;
    this->mock_tb.sunset_clk = 3600 * 18;
    this->mock_tb.is_sunrise_valid = true;
    this->mock_tb.is_sunset_valid = true;

    uint32_t next_exec;
    char time_buffer[32];

    vesync_schedule_t sche_cfg;
    vesync_buf_t app_cfg = vesync_buf_new();

    sche_cfg.enabled = true;
    sche_cfg.type = SCHE_TMG_EVT;
    sche_cfg.repeat_config = (uint8_t)TMBS_BIT_FRI;
    // 设置在7点
    sche_cfg.event_config.timing.clock_sec = 3600 * 7;
    ret = vesync_schedule_add(this->instance_id, &sche_cfg, &app_cfg, true);
    EXPECT_EQ(ret, SCHE_OK);

    ret = vesync_schedule_get_next_exc_sec(this->instance_id, &next_exec);
    EXPECT_EQ(ret, SCHE_OK);
    EXPECT_EQ(next_exec, (7 + 24 - 8) * 3600);

    clk_sec_to_time(next_exec, time_buffer);
    SDK_LOG(LOG_INFO, "next_exc_sec: %s\n", time_buffer);

    sche_cfg.enabled = true;
    sche_cfg.type = SCHE_TMG_EVT;
    sche_cfg.repeat_config = (uint8_t)TMBS_BIT_THU;
    // 设置在7点会在下星期超过24小时才执行
    sche_cfg.event_config.timing.clock_sec = 3600 * 7;
    ret = vesync_schedule_add(this->instance_id, &sche_cfg, &app_cfg, true);
    EXPECT_EQ(ret, SCHE_OK);

    ret = vesync_schedule_get_next_exc_sec(this->instance_id, &next_exec);
    EXPECT_EQ(ret, SCHE_OK);
    EXPECT_EQ(next_exec, (7 + 24 - 8) * 3600);

    clk_sec_to_time(next_exec, time_buffer);
    SDK_LOG(LOG_INFO, "next_exc_sec: %s\n", time_buffer);
}

TEST_F(vesync_schedule_test, vesync_schedule_get_next_exec_test_4)
{
    int ret;

    // 北京时间 2021-11-18 08:00:00，星期四
    this->mock_utc = 1637193600;
    this->mock_tb.local_ts = this->mock_utc + 3600 * 8;
    this->mock_tb.local_clk_sec = 3600 * 8;
    this->mock_tb.sunrise_clk = 3600 * 6;
    this->mock_tb.sunset_clk = 3600 * 18;
    this->mock_tb.is_sunrise_valid = true;
    this->mock_tb.is_sunset_valid = true;

    uint32_t next_exec;
    char time_buffer[32];

    vesync_schedule_t sche_cfg;
    vesync_buf_t app_cfg = vesync_buf_new();

    sche_cfg.enabled = true;
    sche_cfg.type = SCHE_TMG_EVT;
    sche_cfg.repeat_config = (uint8_t)TMBS_ONCE;
    // 设置在7点，会在下一天7点执行
    sche_cfg.event_config.timing.clock_sec = 3600 * 7;
    ret = vesync_schedule_add(this->instance_id, &sche_cfg, &app_cfg, true);
    EXPECT_EQ(ret, SCHE_OK);

    ret = vesync_schedule_get_next_exc_sec(this->instance_id, &next_exec);
    EXPECT_EQ(ret, SCHE_OK);
    EXPECT_EQ(next_exec, (7 + 24 - 8) * 3600);

    clk_sec_to_time(next_exec, time_buffer);
    SDK_LOG(LOG_INFO, "next_exc_sec: %s\n", time_buffer);

    sche_cfg.enabled = true;
    sche_cfg.type = SCHE_TMG_EVT;
    sche_cfg.repeat_config = (uint8_t)TMBS_ONCE;
    // 设置在9点，会1小时后执行
    sche_cfg.event_config.timing.clock_sec = 3600 * 9;
    ret = vesync_schedule_add(this->instance_id, &sche_cfg, &app_cfg, true);
    EXPECT_EQ(ret, SCHE_OK);

    ret = vesync_schedule_get_next_exc_sec(this->instance_id, &next_exec);
    EXPECT_EQ(ret, SCHE_OK);
    EXPECT_EQ(next_exec, 1 * 3600);

    clk_sec_to_time(next_exec, time_buffer);
    SDK_LOG(LOG_INFO, "next_exc_sec: %s\n", time_buffer);
}

TEST_F(vesync_schedule_test, vesync_schedule_get_next_exec_test_5)
{
    int ret;

    // 北京时间 2021-07-05 12:09:54，星期一
    this->mock_utc = 1625458194;
    this->mock_tb.local_ts = this->mock_utc - 3600 * 5;
    this->mock_tb.local_clk_sec = 3600 * 23 + 9 * 60 + 54;
    this->mock_tb.sunrise_clk = 10 * 60 + 9;
    this->mock_tb.sunset_clk = 3600 * 12 + 21 * 60 + 36;
    this->mock_tb.is_sunrise_valid = true;
    this->mock_tb.is_sunset_valid = true;

    uint32_t next_exec;
    char time_buffer[32];

    vesync_schedule_t sche_cfg;
    vesync_buf_t app_cfg = vesync_buf_new();

    sche_cfg.enabled = true;
    sche_cfg.type = SCHE_SUN_EVT;
    sche_cfg.repeat_config = (uint8_t)TMBS_ONCE;
    sche_cfg.event_config.sun.is_sunrise = true;
    sche_cfg.event_config.sun.offset_sec = 3600 * -1;
    ret = vesync_schedule_add(this->instance_id, &sche_cfg, &app_cfg, true);
    EXPECT_EQ(ret, SCHE_OK);

    ret = vesync_schedule_get_next_exc_sec(this->instance_id, &next_exec);
    EXPECT_EQ(ret, SCHE_OK);
    EXPECT_EQ(next_exec, (10 - 9) * 60);

    clk_sec_to_time(next_exec, time_buffer);
    SDK_LOG(LOG_INFO, "next_exc_sec: %s\n", time_buffer);
}

TEST_F(vesync_schedule_test, vesync_schedule_get_next_exec_test_6)
{
    int ret;

    // 北京时间 2021-07-05 12:09:54，星期一
    this->mock_utc = 1625458194;
    this->mock_tb.local_ts = this->mock_utc - 3600 * 5;
    this->mock_tb.local_clk_sec = 3600 * 23 + 9 * 60 + 54;
    this->mock_tb.sunrise_clk = 10 * 60 + 9;
    this->mock_tb.sunset_clk = 3600 * 12 + 21 * 60 + 36;
    this->mock_tb.is_sunrise_valid = true;
    this->mock_tb.is_sunset_valid = true;

    uint32_t next_exec;
    char time_buffer[32];

    vesync_schedule_t sche_cfg;
    vesync_buf_t app_cfg = vesync_buf_new();

    sche_cfg.enabled = true;
    sche_cfg.type = SCHE_SUN_EVT;
    sche_cfg.repeat_config = (uint8_t)TMBS_ONCE;
    sche_cfg.event_config.sun.is_sunrise = false;
    sche_cfg.event_config.sun.offset_sec = 3600 * 12;
    ret = vesync_schedule_add(this->instance_id, &sche_cfg, &app_cfg, true);
    EXPECT_EQ(ret, SCHE_OK);

    ret = vesync_schedule_get_next_exc_sec(this->instance_id, &next_exec);
    EXPECT_EQ(ret, SCHE_OK);
    EXPECT_EQ(next_exec, (3600 * 12 + 3600 * 12 + 21 * 60) - (3600 * 23 + 9 * 60));

    clk_sec_to_time(next_exec, time_buffer);
    SDK_LOG(LOG_INFO, "next_exc_sec: %s\n", time_buffer);
}