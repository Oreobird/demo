/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_main.c
 * @brief       SDK初始化接口
 * @author      Joshua
 * @date        2021-04-22
 */

#include "vesync_log.h"
#include "vesync_device.h"

/*
 * @brief  vesync sdk 初始化
 * @return int                         [成功：0；失败：-1]
*/
int vesync_sdk_init(void)
{
    int ret = 0;
    vesync_log_init(LOG_DEBUG);

    vesync_device_init();

    APP_LOG(LOG_INFO, "Vesync Wi-Fi SDK say: Hello World!\n");

    return ret;
}


