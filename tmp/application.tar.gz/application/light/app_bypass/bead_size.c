/*
 * Copyright © Vesync Technologies Co.Ltd. 2022. All rights reserved.
 * @file        bead_size.c
 * @brief       setBeadSize处理接口
 * @date        2022-01-24
 */

#include <stdio.h>

#include "vesync_common.h"
#include "vesync_log.h"
#include "vesync_memory.h"
#include "app_bypass.h"
#include "event.h"
#include "device.h"
#include "scene.h"

int request_data_handle_for_set_bead_size(bp_set_bead_size_request_t *request_data, int *err_code, char *err_msg, void **extra)
{
    UNUSED(extra);
    dev_cfg_t *p_dev_cfg = app_device_cfg_get();
    if (p_dev_cfg == NULL)
    {
        *err_code = BP_ERR_PARA_ILLEGAL;
        snprintf(err_msg, BP_ERR_MSG_LEN, "device abnormal");
        return APP_FAIL;
    }

    p_dev_cfg->flash->cfg.bead_num = (uint16_t)(request_data->bead_size);
    app_device_cfg_save(p_dev_cfg);

    return APP_OK;
}

int reply_data_get_for_get_bead_size(bp_get_bead_size_reply_t *reply_data, int *err_code, char *err_msg, void *extra)
{
    UNUSED(extra);
    reply_data->bead_size = (int)app_device_bead_num();
    return APP_OK;
}


