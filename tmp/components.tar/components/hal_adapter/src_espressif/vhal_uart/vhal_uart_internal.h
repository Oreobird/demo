/**
 *  Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vhal_uart_internal.h
 * @brief       乐鑫平台串口配置参数
 * @author      Dongri.Su
 * @date        2021-04-28
 */

#ifndef __VHAL_UART_INTERNAL_H__
#define __VHAL_UART_INTERNAL_H__

#include <stdint.h>

#include "vhal_uart.h"


#ifdef __cplusplus
extern "C"
{
#endif

#define ENABLE_MULTI_UART           (0)     // 支持多串口同时工作标志位


// 可以考虑将参数移到配置文件中
#ifdef CONFIG_IDF_TARGET_ESP8266
#define UART_BUF_SIZE               (256)
#define UART_RECV_BUF_SIZE          (UART_BUF_SIZE)
#elif defined(CONFIG_IDF_TARGET_ESP32)
#define UART_BUF_SIZE               (1024)
#define UART_RECV_BUF_SIZE          (UART_BUF_SIZE)
#endif


// uart_event任务
#define UART_TASK_NAME              "uart_event"
#define UART_TASK_STACK_SIZE        (1024*2)
#define UART_TASK_PRIO              (6)     // TASK_PRIORITY_HARD_REALTIME


/*
 * @brief  串口收发状态
 */
typedef struct
{
    bool cfg_flag;                          // 配置（初始化）标志位，true表示该串口已被配置
    uint8_t uart_num;                       // 串口号
    QueueHandle_t uart_queue;               // 串口接收队列
    vhal_uart_recv_cb_t recv_cb;            // 接收回调
} vhal_esp_uart_status_t;


#ifdef __cplusplus
}
#endif

#endif /* __VHAL_UART_INTERNAL_H__ */
