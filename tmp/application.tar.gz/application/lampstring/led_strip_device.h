/**
* Copyright © Vesync Technologies Co.Ltd. 2022. All rights reserved.
* @file    led_strip_device.h
* @brief   设备重置
* @author  Lind
* @date    2022-01-06
*/

#ifndef __LED_STRIP_DEVICE_H__
#define __LED_STRIP_DEVICE_H__

#ifdef __cplusplus
extern "C" {
#endif

/**
* @brief 设备管理初始化
*/
void ls_device_init(void);

#ifdef __cplusplus
}
#endif

#endif

