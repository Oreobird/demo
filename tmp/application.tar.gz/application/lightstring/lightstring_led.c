/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file    lightstring_led.c
* @brief   灯效控制
* @author  Lind
* @date     2021-12-13
*/

#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
#include <stdio.h>
#include <math.h>

#include "vhal_led.h"
#include "vhal_adc.h"

#include "vesync_common.h"
#include "vesync_log.h"
#include "vesync_memory.h"
#include "vesync_task.h"
#include "vesync_queue.h"
#include "vesync_device.h"

#include "lightstring.h"
#include "lightstring_scene.h"
#include "lightstring_board.h"
#include "lightstring_led.h"
#include "lightstring_report.h"

static vesync_queue_t *s_led_event_queue = NULL;
static ls_led_changing_status_t s_ls_changing_status;
static uint8_t s_scene_id = 0;                  // 默认关闭
static int task_cycle = 10; // 任务最长执行间隔一次
static uint8_t s_speed = 3;         // 速度
static float s_brightness = 1;    // 最大亮度

static bool s_voice_ctrl_flag = false;      // 声控开启标志位
static uint64_t s_adc_init_ts = 0;          // adc初始化时间戳
static bool s_adc_en_flag = false;   // adc使能标志位，上电一段时间内保护

static ls_led_dynamic_params **s_mode_list = NULL;
static uint8_t *s_mode_cycle_times = NULL;
static ls_led_dynamic_params *s_production_scene = NULL;

// 计算最低亮度为10%后的真实亮度(1分辨率)
#define TRUE_BRIGHTNESS(x)     (LS_LED_USER_MIN_BRIGHTNESS + (x) * (1 - LS_LED_USER_MIN_BRIGHTNESS))
// 实际亮度换算
#define BREATHING_BRIGHTNESS(x)     (LS_LED_MIN_BRIGHTNESS * LS_LED_PWM_RST + (x) * (LS_LED_MAX_BRIGHTNESS - LS_LED_MIN_BRIGHTNESS))


/**
* @brief 计算渐变下一步参数
*/
static uint16_t next_param(uint16_t step_num, uint16_t remain_step, uint16_t begin_param, uint16_t end_param)
{
    if (0 == remain_step || begin_param == end_param)
    {
        return (uint16_t)BREATHING_BRIGHTNESS(end_param);
    }

    if (remain_step == step_num)
    {
        return (uint16_t)BREATHING_BRIGHTNESS(begin_param);
    }

    return (uint16_t)BREATHING_BRIGHTNESS(begin_param * remain_step / step_num + end_param * (step_num - remain_step) / step_num);
}


/**
* @brief 关闭led
* @param[in]  delay_flag    [是否空运行一段时间]
*/
static void ls_led_turn_off(bool delay_flag)
{
    vhal_led_set_duty_bits(LS_LED_CH0, 0, LS_LED_PWM_RST);
    vhal_led_set_duty_bits(LS_LED_CH1, LS_LED_PWM_RST, LS_LED_PWM_RST);
    if (delay_flag)
    {
        DELAY_500US;
    }
}

/**
* @brief    变化灯效改变状态记录
* @param[in]  *pst_params   [灯效参数]
* @return  int  [APP_OK/APP_FAIL,变化中/灯效结束]
*/
static int save_changing_status(ls_led_dynamic_params *pst_params, uint8_t times)
{
    if (pst_params != s_ls_changing_status.last_mode || s_ls_changing_status.times != times)
    {
        s_ls_changing_status.last_mode = pst_params;
        s_ls_changing_status.cur_node = 0;
        s_ls_changing_status.mode =pst_params->mode;
        s_ls_changing_status.type = pst_params->type;
        s_ls_changing_status.times = times;
        s_ls_changing_status.remain_times = times;
        s_ls_changing_status.remain_step = (pst_params->node_head->step_num);
    }

    if (0 == s_ls_changing_status.remain_step)
    {
        s_ls_changing_status.cur_node++;
        s_ls_changing_status.remain_step = (pst_params->node_head + s_ls_changing_status.cur_node % pst_params->node_num)->step_num - 1;
    }

    if (s_ls_changing_status.cur_node == pst_params->node_num)
    {
        // 一次灯效周期结束
        if (0 != s_ls_changing_status.times)
        {
            s_ls_changing_status.remain_times--;
            if (0 == s_ls_changing_status.remain_times)
            {
                // 执行结束
                s_ls_changing_status.last_mode = NULL;
                s_ls_changing_status.remain_step = 0;
                return APP_FAIL;
            }
        }

        s_ls_changing_status.cur_node = 0;
    }
    return APP_OK;
}

/**
* @brief  灯效显示
* @param[in]  *pst_mode_params  [灯效参数]
* @param[in]  times             [循环次数]
* @return  int                  [成功：APP_OK，失败：APP_FAIL]
*/
static int ls_led_scene(ls_led_dynamic_params *pst_mode_params, uint8_t times)
{
    if (pst_mode_params == NULL || pst_mode_params->node_head == NULL)
    {
        APP_LOG(LOG_ERROR, "Invaild parameters \n");
        return APP_PARA_ERR;
    }

    ls_led_node_t *cur_node = NULL;
    ls_led_node_t *tgt_node = NULL;
    uint16_t real_pwm1 = 0;
    uint16_t real_pwm2 = 0;
    // 灯效模式状态记录
    if (APP_FAIL == save_changing_status(pst_mode_params, times))
    {
        return APP_FAIL;
    }
    cur_node = pst_mode_params->node_head + s_ls_changing_status.cur_node;
    if (pst_mode_params->mode == LS_LED_BREATHING)
    {
        tgt_node = pst_mode_params->node_head + (s_ls_changing_status.cur_node + 1) % pst_mode_params->node_num;
        real_pwm1 = next_param(cur_node->step_num, s_ls_changing_status.remain_step, cur_node->output1 * s_brightness, tgt_node->output1 * s_brightness);
        real_pwm2 = next_param(cur_node->step_num, s_ls_changing_status.remain_step, cur_node->output2 * s_brightness, tgt_node->output2 * s_brightness);
    }
    else
    {
        real_pwm1 = cur_node->output1 == 0 ? 0 : BREATHING_BRIGHTNESS(cur_node->output1 * s_brightness);
        real_pwm2 = cur_node->output2 == 0 ? 0 : BREATHING_BRIGHTNESS(cur_node->output2 * s_brightness);
    }
    // 点灯
    switch (s_ls_changing_status.type)
    {
        case MODE_TYPE_CH0:
            vhal_led_set_duty_bits(LS_LED_CH1, LS_LED_PWM_RST, LS_LED_PWM_RST);
            vhal_led_set_duty_bits(LS_LED_CH0, real_pwm1, LS_LED_PWM_RST);
            break;
        case MODE_TYPE_CH1:
            vhal_led_set_duty_bits(LS_LED_CH0, 0, LS_LED_PWM_RST);
            vhal_led_set_duty_bits(LS_LED_CH1, LS_LED_PWM_RST - real_pwm2, LS_LED_PWM_RST);
            break;
        case MODE_TYPE_ALL:
            // pwm换算，单路最大亮度为50%
            real_pwm1 = real_pwm1 * 0.45;
            real_pwm2 = LS_LED_PWM_RST - (real_pwm2 * 0.55);
            vhal_led_set_duty_bits(LS_LED_CH0, real_pwm1, LS_LED_PWM_RST);
            vhal_led_set_duty_bits(LS_LED_CH1, real_pwm2, LS_LED_PWM_RST);
            break;
        case MODE_TYPE_ALTERNATE:
            if (real_pwm1 >= real_pwm2)
            {
                // 最低亮度限制
                vhal_led_set_duty_bits(LS_LED_CH1, LS_LED_PWM_RST, LS_LED_PWM_RST);
                vhal_led_set_duty_bits(LS_LED_CH0, real_pwm1, LS_LED_PWM_RST);
            }
            else
            {
                vhal_led_set_duty_bits(LS_LED_CH0, 0, LS_LED_PWM_RST);
                vhal_led_set_duty_bits(LS_LED_CH1, LS_LED_PWM_RST - real_pwm2, LS_LED_PWM_RST);
            }
            break;
        default:
            break;
    }

    s_ls_changing_status.remain_step = (s_ls_changing_status.remain_step >= s_speed ? s_ls_changing_status.remain_step - s_speed : 0);
    return APP_OK;
}

/**
 * @brief  给lightstring  led任务发通知
 * @param[in]   ev              [通知消息]
 * @return     int              [成功：APP_OK，失败：APP_FAIL]
 */
int ls_led_task_notify(ls_led_ev_t *ev)
{
    int ret = vesync_queue_send(s_led_event_queue, ev, VESYNC_OS_NO_WAIT);
    if (ret != VOS_OK)
    {
        APP_LOG(LOG_ERROR, "LED Event publish failed\n");
        return APP_FAIL;
    }

    return APP_OK;
}


/**
* @brief 灯效控制任务参数初始化
* @param[in]  voice_ctrl    [声控标志位]
* @param[in]  speed         [速度]
* @param[in]  brightness    [亮度]
*/
void ls_led_params_init(bool voice_ctrl, uint8_t speed, float brightness)
{
    s_voice_ctrl_flag = voice_ctrl;
    s_speed = speed;
    s_brightness = TRUE_BRIGHTNESS(brightness);
    APP_LOG(LOG_DEBUG, " %d %d %f \n", s_voice_ctrl_flag, s_speed, s_brightness);
}

/**
* @brief led控制事件处理函数
* @param  ev        [队列消息]
*/
static void ls_led_event_handle(ls_led_ev_t ev)
{
    switch (ev.id)
    {
        case LS_LED_EV_OFF:
            s_scene_id = 0;
            ls_led_turn_off(false);
            break;
        case LS_LED_EV_ON:
            if (ev.param.mode_param.mode == LS_MODE_SCENE)
            {
                s_scene_id = ev.param.mode_param.scene_id;
                s_brightness = (float)ev.param.mode_param.brightness / 100.0;
                s_brightness = TRUE_BRIGHTNESS(s_brightness);
                switch (ev.param.mode_param.speed)
                {
                    case 1:
                        s_speed = 1;
                        break;
                    case 2:
                        s_speed = 2;
                        break;
                    case 3:
                        s_speed = 3;
                        break;
                    case 4:
                        s_speed = 5;
                        break;
                    default:
                        s_speed = 3;
                        break;
                }
            }
            else
            {
                s_scene_id = ev.param.mode_param.scene_id + 30;
            }
            break;
        case LS_LED_EV_VOICE_CTRL:
            s_voice_ctrl_flag = ev.param.voice_ctrl;
            break;
        case LS_LED_EV_PRODUCTION:
            s_scene_id = ev.param.mode_param.scene_id + 20;
            s_voice_ctrl_flag = false;
            s_speed = 3;
            break;
        default:
            break;
    }
}


/**
* @brief adc滤波算法
* @param[in]  last_data [上一次的数据]
* @param[in]  new_data  [新数据]
* @return  uint16_t     [滤波后的数据]
*/
static uint16_t ls_adc_filter(uint16_t last_data, uint16_t new_data)
{
    uint32_t data = ((100 - LS_ADC_FILTER_COEF) * last_data + LS_ADC_FILTER_COEF * new_data) / 100;
    return (uint16_t)data;
}

/**
* @brief 声控和音乐模式
* @param[in]  *adc_data     [adc 数据buf]
* @param[in]  scene_id      [情景id]
*/
static void ls_led_sound_detect(adc_data_t *adc_data, uint8_t scene_id)
{
    uint8_t num = 0;
    uint32_t data = 0;
    uint16_t pwm = 0;
    uint16_t pwm1 = 0;
    uint16_t pwm2 = LS_LED_PWM_RST;
    uint16_t adc_data_num = 0;
    static uint16_t last_data = LS_SOUND_THRESHOLD - 300;
    uint16_t new_data;
    static uint8_t voice_ctrl_interval_cnt = 0;   // 声控间隔
    memset(adc_data, 0,sizeof(adc_data_t) * LS_ADC_DATA_NUM);
    if (s_adc_en_flag == true)
    {
        vhal_adc_dma_get_data(adc_data, LS_ADC_DATA_NUM, &adc_data_num, 10);
        for (uint16_t i = 0; i < adc_data_num; i++)
        {
            new_data = ls_adc_filter(last_data, adc_data[i].data); // 滤波
            if (scene_id < 30 && voice_ctrl_interval_cnt == 0
                && new_data > LS_VOICE_CTRL_THRESHOLD)
            {
                ls_ev_t ev;
                ev.id = LS_EV_ON;
                ev.act_src = LS_ACT_SRC_VOICE_CTRL;
                ls_app_task_notify(&ev);

                voice_ctrl_interval_cnt = 10;
                break;
            }

            last_data = new_data;
            if (new_data > LS_SOUND_THRESHOLD)
            {
                num++;
                data += (new_data - LS_SOUND_THRESHOLD);
            }
        }
        // 声控
        if (voice_ctrl_interval_cnt != 0)
        {
            voice_ctrl_interval_cnt--;
        }
    }

    pwm = 50 + (num > 0 ? data / num : 0);
    pwm = pwm > 1024 ? 1024 : pwm;
    switch (scene_id - 30)
    {
        case 2:
            // 全亮
            pwm1 = pwm * 19 / 20 / 2;
            pwm2 = LS_LED_PWM_RST - (pwm * 21 / 20 / 2);
            break;
        case 3:
            // 亮一路，有声音同时亮
            pwm1 = pwm  * 19 / 20 / 2;
            pwm2 = LS_LED_PWM_RST - (pwm > 50 ? (pwm * 21 / 20 / 2) : 0);
            break;
        case 4:
            // 亮一路，声音超过一定数值另一路一起亮
            pwm1 = pwm > 400 ? (pwm  * 19 / 20 / 2) : 0;
            pwm2 = LS_LED_PWM_RST - (pwm * 21 / 20 / 2);
            break;
        default:
            break;
    }
    vhal_led_set_duty_bits(LS_LED_CH0, pwm1, LS_LED_PWM_RST);
    vhal_led_set_duty_bits(LS_LED_CH1, pwm2, LS_LED_PWM_RST);
}

/**
* @brief LED控制任务
*/
static void ls_led_task(void *args)
{
    ls_led_ev_t ev;
    int ret = 0;
    uint8_t scene_cycle_num = 0;
    uint8_t music_cycle_num = 2;
    uint64_t music_comb_star_ts = 0;
    adc_data_t adc_data[LS_ADC_DATA_NUM] = {0};
    memset(adc_data, 0,sizeof(adc_data_t) * LS_ADC_DATA_NUM);
    while(1)
    {
        ret = vesync_queue_recv(s_led_event_queue, &ev, task_cycle);
        if (VOS_OK == ret)
        {
            ls_led_event_handle(ev);
            report_ls_status();
            APP_LOG(LOG_DEBUG, "led ev %d scene id %d brightness %f speed %d\n", ev.id, s_scene_id, s_brightness, s_speed);
            if (s_scene_id == 31)
            {
                music_comb_star_ts = vesync_task_get_tick_ms();
            }
            else
            {
                music_cycle_num = 2;
            }
        }

        if (s_adc_en_flag == false && (vesync_task_get_tick_ms() - s_adc_init_ts) > LS_ADC_PROTECT_TIME)
        {
            // adc 上电保护
            s_adc_en_flag = true;
        }

        scene_cycle_num = (s_scene_id == 1 ? scene_cycle_num : 0);
        music_cycle_num = (s_scene_id == 31 ? music_cycle_num : 2);
        if (s_voice_ctrl_flag || s_scene_id > 30)
        {
            if (s_scene_id == 31)
            {
                // 音乐模式循环
                uint64_t new_ts = vesync_task_get_tick_ms();
                if ((new_ts - music_comb_star_ts) > 10000)
                {
                    music_comb_star_ts = new_ts;
                    music_cycle_num = (music_cycle_num == LS_MODE_MUSIC_NUM ? 2 : music_cycle_num + 1);
                }

                ls_led_sound_detect(adc_data, music_cycle_num + 30);
            }
            else
            {
                ls_led_sound_detect(adc_data, s_scene_id);
            }
        }

        if (s_scene_id > 0 && s_scene_id <= LS_MODE_NUM)
        {
            // 普通场景模式
            if (s_scene_id == 1)
            {
                // 场景循环
                if(APP_FAIL == ls_led_scene(s_mode_list[scene_cycle_num], s_mode_cycle_times[scene_cycle_num]))
                {
                    scene_cycle_num = (scene_cycle_num + 1) % (LS_MODE_NUM - 1);
                    APP_LOG(LOG_DEBUG, "mode 1 cur scene [%d] \n", scene_cycle_num + 1);
                }
            }
            else
            {
                ls_led_scene(s_mode_list[s_scene_id - 2], 0);
            }
        }
        else if (s_scene_id >= 20 && s_scene_id < 30)
        {
            switch (s_scene_id)
            {
                case 20:
                    // 20-23为产测灯效
                    // 交替闪 连接产测服务器
                    ls_led_scene(s_production_scene, 0);
                    break;
                case 21:
                    // 关闭
                    ls_led_turn_off(false);
                    break;
                case 22:
                    // 100% 亮度 成功
                    vhal_led_set_duty_bits(LS_LED_CH0, 490, LS_LED_PWM_RST);
                    vhal_led_set_duty_bits(LS_LED_CH1, 524, LS_LED_PWM_RST);
                    return;
                case 23:
                    // 10%亮度 失败
                    vhal_led_set_duty_bits(LS_LED_CH0, 80, LS_LED_PWM_RST);
                    vhal_led_set_duty_bits(LS_LED_CH1, 944, LS_LED_PWM_RST);
                    return;
                default:
                    break;
            }
        }
        else
        {
            continue;
        }
    }
}

static void ls_adc_init(void)
{
    uint8_t adc_io = LS_MIC_IO;
    if (vhal_adc_dma_init(&adc_io, 1,20000))
    {
        APP_LOG(LOG_ERROR, "adc init failed\n");
        return;
    }

    s_adc_init_ts = vesync_task_get_tick_ms();
}

/**
* @brief  led 控制初始化
*/
void ls_led_init(void)
{
    int ret = APP_OK;

    // led pwm timer配置
    vhal_led_timer_cfg_t led_timer_cfg =
    {
        .duty_resolution = LED_DUTY_RST_13_BIT,
        .freq_hz = 5000,
    };
    ret = vhal_led_timer_cfg(&led_timer_cfg);

    // led gpio 配置
    vhal_led_gpio_cfg_t gpio_cfg[LS_LED_NUM] =
    {
        {
            .gpio_num = LS_LED_OUT2_IO, .channel = LS_LED_CH0, .duty = 0,
        },
        {
            .gpio_num = LS_LED_OUT1_IO, .channel = LS_LED_CH1, .duty = 0, .invert_flag = true, // 输出翻转
        },
    };
    ret = vhal_led_gpio_cfg(LS_LED_NUM, gpio_cfg);
    ls_led_turn_off(false);
    ls_adc_init();

    ls_get_scene_head((void *)&s_mode_list);
    ls_get_production_scene(&s_production_scene);
    ls_get_comb_cycle_times(&s_mode_cycle_times);
    s_led_event_queue = vesync_queue_new(LS_LED_EVENT_QUEUE_MAX_NUM * sizeof(ls_led_ev_t), sizeof(ls_led_ev_t));
    if (s_led_event_queue == NULL)
    {
        APP_LOG(LOG_ERROR, "led event queue create failed\n");
        return;
    }

    if (VOS_OK != vesync_task_new(LS_LED_TASK_NAME, NULL,
                    ls_led_task,
                    NULL,
                    LS_LED_TASK_STACKSIZE,
                    LS_LED_TASK_PRIO, NULL))
    {
        vesync_queue_free(s_led_event_queue);
        ret = APP_FAIL;
    }

    if (ret)
    {
        APP_LOG(LOG_ERROR, "led  init failed.\r\n");
    }
}

