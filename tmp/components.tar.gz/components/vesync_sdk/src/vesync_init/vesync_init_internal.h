/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_init_internal.h
 * @brief       SDK初始化
 * @date        2021-05-06
 */

#ifndef __VESYNC_INIT_INTERNAL_H__
#define __VESYNC_INIT_INTERNAL_H__

#include "vesync_init.h"
#include "vesync_cfg_internal.h"

#ifdef __cplusplus
extern "C" {
#endif

#define INIT_TASK_NAME                "init_task"
#define INIT_TASK_STACKSIZE           (vesync_cfg_get_init_task_stacksize())
#define INIT_TASK_PRIO                TASK_PRIORITY_NORMAL

typedef void (*sdk_reg_run_cb_t)(void);

#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_INIT_INTERNAL_H__ */


