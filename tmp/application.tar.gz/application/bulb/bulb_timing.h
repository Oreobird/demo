/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        bulb_timing.h
 * @brief       bulb timing头文件
 * @author      Dave
 * @date        2021-09-09
 */


#include <stdint.h>

#include "vesync_timing.h"

#include "bulb.h"


#ifndef __BULB_TIMING_H__
#define __BULB_TIMING_H__

#ifdef __cplusplus
    extern "C" {
#endif


/**
 * @brief light timer定时配置
 */
typedef struct
{
    uint16_t id;            // timer id，light最多一个timer
    bulb_action_t action;
} bulb_timing_t;

/**
 * @brief 新增一个timer
 * @param[in]   action                  [timer执行动作]
 * @param[in]   total_sec               [timer定时时间]
 * @param[out]  p_id                    [timer id]
 * @return      int_t                   [成功：APP_OK， 失败：APP_FAIL]
 */
int bulb_timing_add(void* action, uint32_t total_sec, uint16_t *p_id);

/**
 * @brief 获取timer执行的动作
 * @param[in]  action                   [timer执行的动作]
 * @return     int_t                    [成功：APP_OK， 失败：APP_FAIL]
 */
int bulb_timing_get_act(const void **action);

/**
 * @brief 删除一个timer
 * @param[in]  uint16_t                 [timer id]
 * @return     int_t                    [成功：APP_OK， 失败：APP_FAIL]
 */
int bulb_timing_remove(uint16_t timer_id);

/**
 * @brief 清空timer
 * @param void
 */
int bulb_timing_clear(void);

/**
 * @brief 初始化timer
 * @param void
 */
void bulb_timing_init(void);


#ifdef __cplusplus
}
#endif

#endif

