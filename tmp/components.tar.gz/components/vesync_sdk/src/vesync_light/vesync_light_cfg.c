/**
* Copyright © Vesync Technologies Co.Ltd. 2022. All rights reserved.
* @file    vesync_light_cfg.c
* @brief   灯光照明控制模块实现
* @author  Herve & Joshua
* @date    2021-11-09
*/
#include <stdio.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#include "vesync_memory.h"
#include "vesync_common.h"
#include "vesync_utils.h"
#include "vesync_log_internal.h"

#include "vesync_light_internal.h"
#include "vesync_light_timer.h"


/**
 * @brief 灯光控制器的通道延时定时回调函数
 * @param[in] arg           [回调的灯光控制器对象]
 */
static void delay_timer_cb(void *arg)
{
    light_effect_cfg_t *cfg = (light_effect_cfg_t*)arg;
    if (cfg == NULL)
    {
        return;
    }

    uint8_t ch_idx = cfg->ch_idx;
    light_t *p_light = cfg->light;
    if (p_light == NULL)
    {
        VCOM_SAFE_FREE(cfg);
        return;
    }

    if (cfg->cfg_action_cb)
    {
        LIGHT_CB_LOCK(p_light->mutex);
        int ret = cfg->cfg_action_cb(cfg);
        if (SDK_OK != ret)
        {
            SDK_LOG(LOG_ERROR, "apply config error:%d\n", ret);
        }
        LIGHT_UNLOCK(p_light->mutex);
    }

    light_obj_start(p_light, ch_idx);

    VCOM_SAFE_FREE(cfg);
}

/**
 * @brief 灯光控制器的灯效配置函数
 * @param[in] *cfg           [灯效配置指针]
 * @return  int              [LIGHT_RESULT_E]
 */
static int light_obj_effect_cfg(light_effect_cfg_t *cfg)
{
    PTR_ASSERT(cfg);

    int ret = LIGHT_OK;
    light_t *p_obj = cfg->light;
    light_ch_t *p_l_chn = p_obj->ch_grp[cfg->ch_idx];

    if (cfg->delay > 0)
    {
        if (p_l_chn->delay_timer == NULL)
        {
            light_effect_cfg_t *effect_cfg = (light_effect_cfg_t *)vesync_calloc(1, sizeof(light_effect_cfg_t));
            if (NULL == effect_cfg)
            {
                ret = LIGHT_N_PTR;
                goto EXIT;
            }

            memcpy(effect_cfg, cfg, sizeof(light_effect_cfg_t));

            p_l_chn->delay_timer = light_timer_new(false, cfg->delay, delay_timer_cb, effect_cfg);
            if (NULL == p_l_chn->delay_timer)
            {
                SDK_LOG(LOG_ERROR, "delay timer create fail\n");
                VCOM_SAFE_FREE(effect_cfg);
                ret = LIGHT_N_PTR;
                goto EXIT;
            }
        }

        if (!p_l_chn->delay_timer_start)
        {
            light_timer_start(p_l_chn->delay_timer);
            p_l_chn->delay_timer_start = true;
        }
    }
    else
    {
        if (cfg->cfg_action_cb)
        {
            p_l_chn->delay_timer_start = false;

            if (p_l_chn->delay_timer)
            {
                light_timer_stop(p_l_chn->delay_timer);
                light_timer_del(p_l_chn->delay_timer);
                p_l_chn->delay_timer = NULL;
            }
            ret = cfg->cfg_action_cb(cfg);
        }
    }

EXIT:
    return ret;
}

/**
 * @brief  按照规定时长进行渐变的配置函数
 * @param[in] *cfg           [灯效配置指针]
 * @return  int              [LIGHT_RESULT_E]
 */
static int fade_with_time_cfg(light_effect_cfg_t *cfg)
{
    light_t *p_obj = cfg->light;
    uint16_t ch_idx = cfg->ch_idx;
    float bright = cfg->bright;
    uint32_t period = cfg->period;
    int ret = LIGHT_OK;

    light_ch_t *p_l_chn = p_obj->ch_grp[ch_idx];
    light_ch_fade_clr(p_l_chn);

    float r_gamma = 1.0f / p_l_chn->gamma;
    // 当亮度不会有变化的时候，不会进行真正的渐变流程
    if (p_obj->curr_duty[ch_idx] == (uint32_t)(vesync_powf(bright, r_gamma) * p_obj->max_duty))
    {
        return LIGHT_OK;
    }

    // 计算当前的亮度
    // Power percentage convert to bright percentage
    float curr_bright = vesync_powf((float)p_obj->curr_duty[ch_idx] / (float)p_obj->max_duty, p_l_chn->gamma);
    float diff_bright = bright - curr_bright;
    float step_bright;

    uint32_t table_size = period / p_obj->timer_intvl;
    p_l_chn->fade_step_num = table_size + 1;
    p_l_chn->fade_steps = (uint32_t *)vesync_malloc(p_l_chn->fade_step_num * sizeof(uint32_t));
    if (NULL == p_l_chn->fade_steps)
    {
        ret = LIGHT_N_PTR;
        goto EXIT;
    }

    step_bright = diff_bright / (float)table_size;
    // 由伽马参数生成PWM控制量步进渐变表
    // Gamma curve formula: b=a*p^(1/gm)
    if (diff_bright > 0)
    {
        for (int i = 0; i < (int)p_l_chn->fade_step_num; i++)
        {
            // 渐变时长不足一个占空比刷新周期，直接输出目标占空比
            // Bright percentage convert to power percentage
            p_l_chn->fade_steps[i] = vesync_powf((0 == table_size) ? (bright) : (curr_bright + i * step_bright), r_gamma) * p_obj->max_duty;
#if 0
            SDK_LOG(LOG_DEBUG, "step[%d]: duty[%d]\n", i, p_l_chn->fade_steps[i]);
#endif
        }
        p_l_chn->fade_up = true;
    }
    else
    {
        for (int i = 0; i < (int)p_l_chn->fade_step_num; i++)
        {
            p_l_chn->fade_steps[i] = vesync_powf((0 == table_size) ? (bright) : (bright - i * step_bright), r_gamma) * p_obj->max_duty;
        }
        p_l_chn->fade_cnt = p_l_chn->fade_step_num - 1;
        p_l_chn->fade_up = false;
    }
    // 渐变模式的一次执行周期就是一个渐变半周期
    p_l_chn->semicycle_cnt = 1;

EXIT:
    p_l_chn->delay_timer_start = false;

    if (p_l_chn->delay_timer)
    {
        light_timer_del(p_l_chn->delay_timer);
        p_l_chn->delay_timer = NULL;
    }

    return ret;
}

/**
 * @brief  按照规定步速进行渐变的配置函数
 * @param[in] *cfg           [灯效配置指针]
 * @return  int              [LIGHT_RESULT_E]
 */
static int fade_with_step_cfg(light_effect_cfg_t *cfg)
{
    light_t *p_obj = cfg->light;
    uint16_t ch_idx = cfg->ch_idx;
    float bright = cfg->bright;
    float scale = cfg->scale;
    int ret = LIGHT_OK;

    light_ch_t *p_l_chn = p_obj->ch_grp[ch_idx];
    light_ch_fade_clr(p_l_chn);

    float r_gamma = (float)1.0 / p_l_chn->gamma;
    if (p_obj->curr_duty[ch_idx] == (uint32_t)(vesync_powf(bright, r_gamma) * p_obj->max_duty))
    {
        return LIGHT_OK;
    }

    float curr_bright = vesync_powf((float)p_obj->curr_duty[ch_idx] / (float)p_obj->max_duty, p_l_chn->gamma);
    float diff_bright = bright - curr_bright;
    float step_bright = scale;

    p_l_chn->fade_step_num = ceilf(fabsf(diff_bright) / scale) + 1;
    p_l_chn->fade_steps = (uint32_t *)vesync_malloc(p_l_chn->fade_step_num * sizeof(uint32_t));
    if (NULL == p_l_chn->fade_steps)
    {
        ret = LIGHT_N_PTR;
        goto EXIT;
    }

    if (diff_bright > 0)
    {
        for (int i = 0; i < (int)p_l_chn->fade_step_num; i++)
        {
            float target_bright = curr_bright + i * step_bright;
            target_bright = (target_bright > bright) ? bright : target_bright;
            p_l_chn->fade_steps[i] = vesync_powf(target_bright, r_gamma) * p_obj->max_duty;
#if 0
            SDK_LOG(LOG_DEBUG, "step[%d]: duty[%d]\n", i, p_l_chn->fade_steps[i]);
#endif
        }
        p_l_chn->fade_up = true;
    }
    else
    {
        for (int i = 0; i < (int)p_l_chn->fade_step_num; i++)
        {
            float target_bright = bright + i * step_bright;
            target_bright = (target_bright > curr_bright) ? curr_bright : target_bright;
            p_l_chn->fade_steps[i] = vesync_powf(target_bright, r_gamma) * p_obj->max_duty;
        }
        p_l_chn->fade_cnt = p_l_chn->fade_step_num - 1;
        p_l_chn->fade_up = false;
    }
    p_l_chn->semicycle_cnt = 1;

EXIT:
    p_l_chn->delay_timer_start = false;

    if (p_l_chn->delay_timer)
    {
        light_timer_del(p_l_chn->delay_timer);
        p_l_chn->delay_timer = NULL;
    }

    return ret;
}

/**
 * @brief  均匀亮灭闪烁的配置函数
 * @param[in] *cfg           [灯效配置指针]
 * @return  int              [LIGHT_RESULT_E]
 */
static int blink_cfg(light_effect_cfg_t *cfg)
{
    light_t *p_obj = cfg->light;
    uint16_t ch_idx = cfg->ch_idx;
    float bright = cfg->bright;
    uint32_t period = cfg->period;
    uint32_t sc_num = cfg->sc_num;
    int ret = LIGHT_OK;

    light_ch_t *p_l_chn = p_obj->ch_grp[ch_idx];
    light_ch_fade_clr(p_l_chn);

    int step_cnt;
    float r_gamma = 1.0f / p_l_chn->gamma;

    p_l_chn->fade_step_num = (period / 2) / p_obj->timer_intvl;
    if (p_l_chn->fade_step_num < 2)
    {
        ret = LIGHT_INV_ARG;
        goto EXIT;
    }
    p_l_chn->fade_steps = (uint32_t *)vesync_malloc(p_l_chn->fade_step_num * sizeof(uint32_t));
    if (NULL == p_l_chn->fade_steps)
    {
        ret = LIGHT_N_PTR;
        goto EXIT;
    }

    step_cnt = 0;
    for (; step_cnt < (int)(p_l_chn->fade_step_num / 2); step_cnt++)
    {
        p_l_chn->fade_steps[step_cnt] = 0;
    }
    for (; step_cnt < (int)p_l_chn->fade_step_num; step_cnt++)
    {
        p_l_chn->fade_steps[step_cnt] = vesync_powf(bright, r_gamma) * p_obj->max_duty;
    }

    if (0 == sc_num)
    {
        p_l_chn->is_rpt = true;
    }
    else
    {
        p_l_chn->semicycle_cnt = sc_num;
    }

EXIT:
    p_l_chn->delay_timer_start = false;

    if (p_l_chn->delay_timer)
    {
        light_timer_del(p_l_chn->delay_timer);
        p_l_chn->delay_timer = NULL;
    }

    return ret;
}

/**
 * @brief  均匀亮灭呼吸的配置函数
 * @param[in] *cfg           [灯效配置指针]
 * @return  int              [LIGHT_RESULT_E]
 */
static int breath_cfg(light_effect_cfg_t *cfg)
{
    light_t *p_obj = cfg->light;
    uint16_t ch_idx = cfg->ch_idx;
    float bright = cfg->bright;
    uint32_t period = cfg->period;
    uint32_t sc_num = cfg->sc_num;
    int ret = LIGHT_OK;

    light_ch_t *p_l_chn = p_obj->ch_grp[ch_idx];
    light_ch_fade_clr(p_l_chn);

    float step_bright;
    float r_gamma = 1.0f / p_l_chn->gamma;

    uint32_t table_size = (period / 2) / p_obj->timer_intvl;
    if (table_size < 1)
    {
        ret = LIGHT_INV_ARG;
        goto EXIT;
    }
    p_l_chn->fade_step_num = table_size + 1;
    p_l_chn->fade_steps = (uint32_t *)vesync_malloc(p_l_chn->fade_step_num * sizeof(uint32_t));
    if (NULL == p_l_chn->fade_steps)
    {
        ret = LIGHT_N_PTR;
        goto EXIT;
    }

    step_bright = bright / (float)table_size;

    for (int i = 0; i < (int)p_l_chn->fade_step_num; i++)
    {
        p_l_chn->fade_steps[i] = vesync_powf(i * step_bright, r_gamma) * p_obj->max_duty;
    }

    if (0 == sc_num)
    {
        p_l_chn->is_rpt = true;
    }
    else
    {
        p_l_chn->semicycle_cnt = sc_num;
    }

EXIT:
    p_l_chn->delay_timer_start = false;

    if (p_l_chn->delay_timer)
    {
        light_timer_del(p_l_chn->delay_timer);
        p_l_chn->delay_timer = NULL;
    }

    return ret;
}

int light_obj_fade_with_time_cfg(light_t *p_obj, uint16_t ch_idx, float bright, uint32_t period, uint32_t delay)
{
    LIGHT_CHECK(bright <= 1.0, LIGHT_INV_ARG);
    LIGHT_CHECK(bright >= 0.0, LIGHT_INV_ARG);

    LIGHT_LOCK(p_obj->mutex);
    LIGHT_CHECK_ACTION(ch_idx < p_obj->ch_num, LIGHT_UNLOCK(p_obj->mutex); return LIGHT_INV_CH);

    int ret = LIGHT_OK;
    light_effect_cfg_t effect_cfg;

    memset(&effect_cfg, 0, sizeof(light_effect_cfg_t));
    effect_cfg.light = p_obj;
    effect_cfg.bright = bright;
    effect_cfg.ch_idx = ch_idx;
    effect_cfg.period = period;
    effect_cfg.delay = delay;
    effect_cfg.cfg_action_cb = fade_with_time_cfg;

    ret = light_obj_effect_cfg(&effect_cfg);

    LIGHT_UNLOCK(p_obj->mutex);
    return ret;
}


int light_obj_fade_with_step_cfg(light_t *p_obj, uint16_t ch_idx, float bright, float scale, uint32_t delay)
{
    LIGHT_CHECK(bright <= 1.0, LIGHT_INV_ARG);
    LIGHT_CHECK(bright >= 0.0, LIGHT_INV_ARG);
    LIGHT_CHECK(scale <= 1.0, LIGHT_INV_ARG);
    LIGHT_CHECK(scale > 0.0, LIGHT_INV_ARG);

    LIGHT_LOCK(p_obj->mutex);
    LIGHT_CHECK_ACTION(ch_idx < p_obj->ch_num, LIGHT_UNLOCK(p_obj->mutex); return LIGHT_INV_CH);

    int ret = LIGHT_OK;
    light_effect_cfg_t effect_cfg;

    memset(&effect_cfg, 0, sizeof(light_effect_cfg_t));
    effect_cfg.light = p_obj;
    effect_cfg.bright = bright;
    effect_cfg.ch_idx = ch_idx;
    effect_cfg.scale = scale;
    effect_cfg.delay = delay;
    effect_cfg.cfg_action_cb = fade_with_step_cfg;

    ret = light_obj_effect_cfg(&effect_cfg);

    LIGHT_UNLOCK(p_obj->mutex);
    return ret;
}


int light_obj_blink_cfg(light_t *p_obj, uint16_t ch_idx, float bright, uint32_t period, uint32_t delay, uint32_t sc_num)
{
    LIGHT_CHECK(bright <= 1.0, LIGHT_INV_ARG);
    LIGHT_CHECK(bright >= 0.0, LIGHT_INV_ARG);

    LIGHT_LOCK(p_obj->mutex);
    LIGHT_CHECK_ACTION(ch_idx < p_obj->ch_num, LIGHT_UNLOCK(p_obj->mutex); return LIGHT_INV_CH);

    int ret = LIGHT_OK;
    light_effect_cfg_t effect_cfg;

    memset(&effect_cfg, 0, sizeof(light_effect_cfg_t));
    effect_cfg.light = p_obj;
    effect_cfg.bright = bright;
    effect_cfg.ch_idx = ch_idx;
    effect_cfg.sc_num = sc_num;
    effect_cfg.period = period;
    effect_cfg.delay = delay;
    effect_cfg.cfg_action_cb = blink_cfg;

    ret = light_obj_effect_cfg(&effect_cfg);

    LIGHT_UNLOCK(p_obj->mutex);
    return ret;
}

int light_obj_breath_cfg(light_t *p_obj, uint16_t ch_idx, float bright, uint32_t period, uint32_t delay, uint32_t sc_num)
{
    LIGHT_CHECK(bright <= 1.0, LIGHT_INV_ARG);
    LIGHT_CHECK(bright >= 0.0, LIGHT_INV_ARG);

    LIGHT_LOCK(p_obj->mutex);
    LIGHT_CHECK_ACTION(ch_idx < p_obj->ch_num, LIGHT_UNLOCK(p_obj->mutex); return LIGHT_INV_CH);

    int ret = LIGHT_OK;
    light_effect_cfg_t effect_cfg;

    memset(&effect_cfg, 0, sizeof(light_effect_cfg_t));
    effect_cfg.light = p_obj;
    effect_cfg.bright = bright;
    effect_cfg.ch_idx = ch_idx;
    effect_cfg.sc_num = sc_num;
    effect_cfg.period = period;
    effect_cfg.delay = delay;
    effect_cfg.cfg_action_cb = breath_cfg;

    ret = light_obj_effect_cfg(&effect_cfg);

    LIGHT_UNLOCK(p_obj->mutex);
    return ret;
}


