/**
 * Copyright © Vesync Technologies Co.Ltd. 2019-2021. All rights reserved.
 * @file    vesync_wifi.c
 * @brief   Wi-Fi服务
 * @author  CharlesMei
 * @date    2021-06-04
 */


#include <stdio.h>
#include <string.h>

#include "vhal_wifi.h"

#include "vesync_os.h"
#include "vesync_wifi.h"
#include "vesync_wifi_scan.h"
#include "vesync_event_internal.h"
#include "vesync_log_internal.h"
#include "vesync_net_service_internal.h"

// Wi-Fi连接状态，默认为断开状态
static VHAL_WIFI_STATUS_E s_wifi_link_status = VHAL_WIFI_INIT;
static VHAL_WIFI_STATUS_E s_wifi_fail_rsn = VHAL_WIFI_INIT;


/**
 * @brief       Wi-Fi状态回调
 * @param[in]   status               [WiFi连接状态，包括连接成功和连接掉线，以及连接失败时的错误原因]
 */
static void vesync_wifi_status_callback(VHAL_WIFI_STATUS_E status)
{
    EVENT_ID_E ev_id;
    s_wifi_link_status = status;

    switch (s_wifi_link_status)
    {
        case VHAL_WIFI_CONNECTED:
            ev_id = EVENT_WIFI_CONNECTED;
            break;
        case VHAL_WIFI_GOT_IP:
            s_wifi_fail_rsn = VHAL_WIFI_INIT;
            ev_id = EVENT_ROUTER_GOT_IP;
            break;
        case VHAL_WIFI_LOST_IP:
        case VHAL_WIFI_WRONG_PWD:
        case VHAL_WIFI_NO_AP_FOUND:
        case VHAL_WIFI_CONNECT_FAIL:
        {
            // 配网Wi-Fi错误原因
            s_wifi_fail_rsn = status;

            // 离线统计分析
            vesync_net_mgmt_set_reconnect_reason(WIFI_REASON);
            if (VHAL_WIFI_NO_AP_FOUND == status)
            {
                vesync_net_mgmt_set_reconnect_count(WIFI_RETRY_NO_AP_FOUND);
            }
            else if (VHAL_WIFI_WRONG_PWD == status)
            {
                vesync_net_mgmt_set_reconnect_count(WIFI_RETRY_INVALID_PWD);
            }
            else if (VHAL_WIFI_CONNECT_FAIL == status)
            {
                vesync_net_mgmt_set_reconnect_count(WIFI_RETRY_CONNECT_FAIL);
            }

            ev_id = EVENT_WIFI_DISCONNECTED;

            break;
        }
        case VHAL_WIFI_SCAN_DONE:
            vesync_wifi_scan_done();
            ev_id = EVENT_WIFI_SCANDONE;
            break;
        case VHAL_WIFI_STA_CONNECT_SOFTAP:
            ev_id = EVENT_NETCFG_APP_CONNECTED;
            break;
        case VHAL_WIFI_STA_DISCONNECT_SOFTAP:
            ev_id = EVENT_NETCFG_APP_DISCONNECTED;
            break;
        default:
            ev_id = EVENT_UNKNOWN;
            break;
    }

    if (EVENT_UNKNOWN != ev_id)
    {
        vesync_ev_t event;
        VESYNC_POPULATE_EV(event, ev_id, WIFI_EVENT_PUBLISH_STR, 0, NULL);
        vesync_event_publish(&event);
    }
}

/**
 * @brief       获取dhcp的hostname
 * @param[in]   p_hostname           [保存hostname]
 * @param[in]   buf_len              [p_hostname空间大小]
 * @return      char                 [dhcp主机名]
 */
static char *vesync_get_dhcp_hostname(char *p_hostname, int buf_len)
{
    if (NULL == p_hostname)
    {
        return NULL;
    }

    snprintf(p_hostname, buf_len, "%s-%s", vesync_cfg_get_brand(), vesync_cfg_get_type());
    SDK_LOG(LOG_DEBUG, "hostname:%s\n", p_hostname);

    return p_hostname;
}

/**
 * @brief       用户调用初始化wifi模块
 */
void vesync_wifi_client_init(void)
{
    char hostname[HOSTNAME_MAX_LEN + 1];
    VHAL_WIFI_PS_TYPE_E ps_mode = VHAL_WIFI_PS_NONE;

    memset(hostname, 0, sizeof(hostname));

    if (PR_WIFI_PS_TYPE >= VHAL_WIFI_PS_NONE && PR_WIFI_PS_TYPE <= VHAL_WIFI_PS_ULTRA_LOW)
    {
        ps_mode = PR_WIFI_PS_TYPE;
    }

    vhal_wifi_init(vesync_wifi_status_callback, ps_mode,
        vesync_get_dhcp_hostname(hostname, sizeof(hostname)), vesync_cfg_get_country_code());
}

/**
 * @brief       用户调用关闭wifi模块
 */
void vesync_wifi_client_deinit(void)
{
    vhal_wifi_deinit();
}

/**
 * @brief       vesync客户端连接WiFi
 * @param[in]   p_wifi_ssid          [WiFi账号]
 * @param[in]   p_wifi_pwd           [WiFi密码]
 * @param[in]   auth_mode            [WiFi加密模式]
 */
void vesync_wifi_client_connect(const char *p_wifi_ssid, const char *p_wifi_pwd, VHAL_WIFI_AUTH_MODE_E auth_mode)
{
    vhal_wifi_connect(p_wifi_ssid, p_wifi_pwd, auth_mode);
}

/**
 * @brief       vesync客户端断开重连WiFi
 */
void vesync_wifi_client_reconnect(void)
{
    vhal_wifi_stop();
    vesync_sleep(20);   // 延时
    vhal_wifi_start();
    SDK_LOG(LOG_DEBUG, "Reconnect Wi-Fi.\n");
}

/**
 * @brief       获取Wi-Fi连接状态
 * @return      与HAL相同定义的wifi连接状态
 */
VHAL_WIFI_STATUS_E vesync_wifi_get_link_status(void)
{
    return s_wifi_link_status;
}

/**
 * @brief       获取Wi-Fi连接连接失败原因
 * @return      与HAL相同定义的wifi连接失败原因
 */
VHAL_WIFI_STATUS_E vesync_wifi_get_fail_rsn(void)
{
    return s_wifi_fail_rsn;
}

