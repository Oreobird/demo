/**
 * Copyright © Vesync Technologies Co.Ltd. 2019-2021. All rights reserved.
 * @file    vhal_uart.c
 * @brief   串口硬件抽象层相关功能
 * @author  Louis
 * @date    2021-03-23
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <vfs_err.h>
#include <vfs_register.h>
#include <vfs.h>
#include <aos/kernel.h>
#include <aos/yloop.h>
#include <event_device.h>
#include <hal_uart.h>
#include <hal_board.h>
#include <device/vfs_uart.h>
#include <fdt.h>
#include <libfdt.h>
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"

#include "vesync_common.h"
#include "vesync_log.h"
#include "vhal_uart.h"
#include "vhal_uart_internal.h"

// 串口配置
static TaskHandle_t s_uart_taskhd = NULL;      // UART数据接收任务句柄
static uint8_t *s_rx_buf = NULL;
static vhal_bl_uart_status_t s_uart_status[VHAL_UART_NUM_MAX] = {0};

/**
 * @brief  串口读取回调函数
 * @param[in]  fd                   [串口句柄]
 * @param[in]  param                [入参]
 * @return     void
 */
static void console_cb_read(int fd, void *param)
{
    if (fd < 0 || param == NULL)
    {
        HAL_LOG(LOG_ERROR, "param null\n");
        return;
    }

    uint8_t idx = *((uint8_t*)param);
    uint8_t *rx_buf = s_rx_buf;

    int rx_len = aos_read(fd, rx_buf, UART_RECV_BUF_SIZE);
    if (rx_len > 0)
    {
        if (rx_len < UART_RECV_BUF_SIZE)
        {
            if (NULL != s_uart_status[idx].recv_cb)
            {
                s_uart_status[idx].recv_cb(idx, rx_buf, rx_len);
            }

            memset(rx_buf, 0, UART_RECV_BUF_SIZE);
        }
        else
        {
            HAL_LOG(LOG_ERROR, "BUG from aos_read for rx_len\r\n");
        }
    }
}


/**
 * @brief  串口事件任务
 * @param[in]  pvParameters
 * @return     void
 */
static void vhal_uart_event_task(void *pvParameters)
{
    uint8_t idx = 0;

    s_rx_buf = (uint8_t *)malloc(UART_RECV_BUF_SIZE);
    if (NULL == s_rx_buf)
    {
        HAL_LOG(LOG_ERROR, "malloc fail!!\n");
        vTaskDelete(NULL);
        return;
    }

    aos_loop_init();
    for (idx = 0; idx < VHAL_UART_NUM_MAX; idx++)
    {
        if (s_uart_status[idx].cfg_flag)
        {
            aos_poll_read_fd(s_uart_status[idx].fd, console_cb_read, (void*)&idx);
        }
    }

    aos_loop_run();
    vTaskDelete(NULL);
}


/**
 * @brief  获取dts地址
 * @param[in]  name                 [dts name]
 * @param[out] start                [起始地址]
 * @param[out] off                  [偏移]
 * @return     int                  [0成功，非0失败]
 */
static int get_dts_addr(const char *name, uint32_t *start, uint32_t *off)
{
    uint32_t addr = hal_board_get_factory_addr();
    const void *fdt = (const void *)addr;
    uint32_t offset;

    if (name == NULL || start == NULL || off == NULL)
    {
        return -1;
    }

    offset = fdt_subnode_offset(fdt, 0, name);
    if (offset <= 0)
    {
       HAL_LOG(LOG_ERROR, "%s NULL.\r\n", name);
       return -1;
    }

    *start = (uint32_t)fdt;
    *off = offset;

    return 0;
}


/**
 * @brief  串口参数配置
 * @param[in]  idx                  [串口编号]
 * @param[in]  rx_pin               [串口rx引脚]
 * @param[in]  rx_pin               [串口tx引脚]
 * @param[in]  baudrate             [串口波特率]
 * @return     void
 * @note 博流的uart在dts文件中配置，uart0用于串口打印，uart1用于mcu通讯
 */
void vhal_uart_config(uint8_t idx, uint32_t rx_pin, uint32_t tx_pin, uint32_t baudrate)
{
    uint32_t fdt = 0;
    uint32_t offset = 0;

    vfs_init();
    vfs_device_init();

    /* uart */
    if (0 == get_dts_addr("uart", &fdt, &offset))
    {
        vfs_uart_init(fdt, offset);
    }

    char uart_name[64] = {0};
    snprintf(uart_name, sizeof(uart_name), "/dev/ttyS%d", idx);

    s_uart_status[idx].fd = aos_open(uart_name, 0);
    if (s_uart_status[idx].fd < 0)
    {
        HAL_LOG(LOG_ERROR, "aos_open /dev/ttyS%d failed!\r\n", idx);
        return;
    }

    aos_ioctl(s_uart_status[idx].fd, IOCTL_UART_IOC_BAUD_MODE, baudrate);

    s_uart_status[idx].cfg_flag = true;
}


/**
 * @brief  启动串口接收任务
 * @return     void
 */
void vhal_uart_start(void)
{
    if (NULL != s_uart_taskhd)
    {
        return;
    }

    // Create a task to handler UART event from ISR
    if (xTaskCreate(vhal_uart_event_task, UART_TASK_NAME, UART_TASK_STACSIZE, NULL, UART_TASK_PRIO, &s_uart_taskhd) != pdPASS)
    {
        HAL_LOG(LOG_ERROR, "Create UART event task fail!!!\n");
    }
}


/**
 * @brief 注册串口接收数据回调
 * @param[in]  idx                  [串口编号]
 * @param[in]  cb                   [串口数据接收回调函数]
 * @return     void
 */
void vhal_uart_reg_recv_cb(uint8_t idx, vhal_uart_recv_cb_t cb)
{
    if (idx >= VHAL_UART_NUM_MAX)
    {
        HAL_LOG(LOG_ERROR, "UART number(%d) is error!!\n", idx);
        return;
    }

    s_uart_status[idx].recv_cb = cb;
}


/**
 * @brief  串口发送数据
 * @param[in]  idx                  [串口编号]
 * @param[in]  p_buf                [待发送数据]
 * @param[in]  buf_len              [待发送数据长度]
 * @return     int                  [执行结果，0表示成功，其他值表示失败]
 */
int vhal_uart_send(uint8_t idx, uint8_t *p_buf, uint16_t buf_len)
{
    int send_bytes = -1;

    if (NULL == p_buf || buf_len <= 0)
    {
        return VHAL_FAIL;
    }

    send_bytes = aos_write(s_uart_status[idx].fd, (const void *)p_buf, buf_len);
    if (send_bytes < 0)
    {
        return VHAL_FAIL;
    }

    return VHAL_OK;
}

