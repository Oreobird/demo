/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_ffs_event.h
 * @brief       vesync ffs事件处理接口
 * @date        2021-06-10
 */

#ifndef __VESYNC_FFS_EVENT_H__
#define __VESYNC_FFS_EVENT_H__

#include "vesync_event_internal.h"

#ifdef __cplusplus
extern "C" {
#endif

#define VESYNC_FFS_PWD "{\"wss_session_tk\":\"%s\",\"signature\":\"%s\",\"host\":\"%s\"}"

/**
 *@brief 事件表结构
*/
typedef struct
{
    EVENT_ID_E event_id;
    event_subscribe_cb_t cb;
} event_cb_tbl_t;


/**
 * @brief  ffs发送事件通知
 * @param[in]  event_id      [事件ID]
 * @return     void          [无]
 */
int vesync_ffs_event_notify(EVENT_ID_E event_id);

/**
 * @brief  ffs事件处理资源初始化
 * @param[in]  event_id      [事件ID]
 * @return     void          [无]
 */
int vesync_ffs_event_init(void);

/**
 * @brief  ffs等待wifi扫描
 * @return     void          [无]
 */
void vesync_ffs_event_wait_for_wifi_scan(void);


/**
 * @brief  ffs事件资源销毁
 * @param[in]  event_id      [事件ID]
 * @return     void          [无]
 */
void vesync_ffs_event_deinit(void);

#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_FFS_EVENT_H__ */

