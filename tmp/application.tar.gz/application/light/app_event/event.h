/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
* @file         app_event.h
* @brief        应用事件处理接口
* @author       Joshua
* @date         2021-12-1
*/
#include <string.h>
#include "event_handle.h"

#ifndef __APP_EVENT_H__
#define __APP_EVENT_H__

#ifdef __cplusplus
extern "C" {
#endif

#define APP_EVENT_QUEUE_MAX_NUM  (16)

/**
 * @brief 应用事件初始化
 * @return int           [成功：APP_OK， 失败：APP_FAIL]
 */
int app_event_init(void);

/**
 * @brief 应用事件销毁
 * @return int           [成功：APP_OK， 失败：APP_FAIL]
 */
int app_event_deinit(void);

/**
 * @brief 事件通知
 * @param[in]  *ev       [应用事件结构体]
 * @return int           [成功：APP_OK， 失败：APP_FAIL]
 */
int app_event_notify(app_event_t *ev);

/**
 * @brief 事件接收处理循环
 */
void app_event_loop_run(void);


#define APP_EVENT_NOTIFY(_ev_id, _src, _scene_type, _scene_id) \
    do { \
        app_event_t ev; \
        memset(&ev, 0, sizeof(app_event_t)); \
        ev.act_src = (_src); \
        ev.id = (_ev_id); \
        ev.scene_type = (_scene_type); \
        ev.scene_id = (_scene_id); \
        app_event_notify(&ev); \
    } while (0)

#define POWERON_NOTIFY(src, scene_type, scene_id)   APP_EVENT_NOTIFY(EV_POWERON, src, scene_type, scene_id)
#define PRODUCTION_NOTIFY(src)     APP_EVENT_NOTIFY(EV_PRODUCTION, src, SCENE_PRD, 0)
#define PRE_NETCFG_NOTIFY(src)     APP_EVENT_NOTIFY(EV_PRE_NETCFG, src, SCENE_NETCFG, 0)
#define NETCFG_NOTIFY(src)         APP_EVENT_NOTIFY(EV_NETCFG, src, SCENE_NETCFG, 0)
#define NETCFG_SUCCESS_NOTIFY(src) APP_EVENT_NOTIFY(EV_NETCFG_SUCCESS, src, SCENE_NETCFG, 0)
#define NWK_RECON_NOTIFY(src)      APP_EVENT_NOTIFY(EV_NWK_RECONNECT, src, SCENE_NETCFG, 0)
#define RESET_NOTIFY(src)          APP_EVENT_NOTIFY(EV_RESET, src, SCENE_RESET, 0)
#define SCENE_SWITCH_NOTIFY(src, scene_type, scene_id)   APP_EVENT_NOTIFY(EV_SCENE_SWITCH, src, scene_type, scene_id)
#define BYPASS_NOTIFY(scene_type, scene_id)     APP_EVENT_NOTIFY(EV_SCENE_SWITCH, ACT_SRC_APP, scene_type, scene_id)

#ifdef __cplusplus
}
#endif

#endif


