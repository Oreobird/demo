/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_bypass_upgrade.c
 * @brief       bypass处理接口
 * @date        2021-05-14
 */

#include <string.h>
#include <stdio.h>

#include "vesync_cfg.h"
#include "vesync_common.h"
#include "vesync_device.h"
#include "vesync_ota_internal.h"
#include "vesync_log_internal.h"
#include "vesync_bypass_internal.h"

/**
 * @brief 升级固件处理函数
 * bypass-V2 固件升级接口   参照 http://34.194.32.46:8080/doc/Rn3hCEyMn
 * @param p_trace_msg trace message
 * @param json json数据指针
 * @return BYPASS_ERR_E
 */
static BYPASS_ERR_E bypass_method_up_firmware_handle(bypass_trace_msg_t *p_trace_msg, cJSON *json)
{
    //此处调用固件升级接口
    BYPASS_ERR_E ret = BP_OK;
    char msg[64] = {0};
    dev_fw_info_t firm_info;
    upgrade_info_t upg;

    if ((NULL == json)||(NULL == p_trace_msg))
    {
        return BP_ERROR;
    }

    memset(&firm_info, 0, sizeof(dev_fw_info_t));
    upg.upg_entry = UPG_EN_WIFI;
    upg.upg_type = UPG_TP_WIFI;

    cJSON* fw_ver = cJSON_GetObjectItemCaseSensitive(json, "newVersion");   //固件版本
    if (cJSON_IsString(fw_ver))
    {
        SDK_LOG(LOG_INFO, "newVersion=%s\r\n", fw_ver->valuestring);

        snprintf(upg.fw_ver, sizeof(upg.fw_ver), "%s", fw_ver->valuestring);
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    cJSON* plugin_name = cJSON_GetObjectItemCaseSensitive(json, "pluginName");  //插件名
    if (cJSON_IsString(plugin_name))
    {
#if PR_OTA_TYPE_WIFI
        if (strcmp(plugin_name->valuestring, vesync_device_get_plugin_name_by_type(UPG_TP_WIFI)) == 0)   //主固件，芯片自己的固件
        {
            upg.upg_type = UPG_TP_WIFI;
        }
#endif
#if PR_OTA_TYPE_BLE
        else if (strcmp(plugin_name->valuestring, vesync_device_get_plugin_name_by_type(UPG_TP_BLE)) == 0)   //ble固件
        {
            upg.upg_type = UPG_TP_BLE;
        }
#endif
#if (PR_OTA_TYPE_MCU >= 1)
        else if (strcmp(plugin_name->valuestring, vesync_device_get_plugin_name_by_type(UPG_TP_MCU)) == 0)   //mcu固件
        {
            upg.upg_type = UPG_TP_MCU;
        }
#endif
#if (PR_OTA_TYPE_MCU >= 2)
        else if (strcmp(plugin_name->valuestring, vesync_device_get_plugin_name_by_type(UPG_TP_MCU2)) == 0)   //mcu固件
        {
            upg.upg_type = UPG_TP_MCU2;
        }
#endif
#if (PR_OTA_TYPE_MCU >= 3)
        else if (strcmp(plugin_name->valuestring, vesync_device_get_plugin_name_by_type(UPG_TP_MCU3)) == 0)   //mcu固件
        {
            upg.upg_type = UPG_TP_MCU3;
        }
#endif
        else
        {
            snprintf(msg, sizeof(msg), "Uknow pluginName(%s)", plugin_name->valuestring);
            vesync_bypass_reply_pkg_err_msg(BP_ERR_PARA_ILLEGAL, p_trace_msg, msg);
            goto _exit;
        }

        // 不可以升级的固件，返回错误码
        vesync_device_get_fw_info_by_type(upg.upg_type, &firm_info);
        if (!firm_info.is_upgrade)
        {
            snprintf(msg, sizeof(msg), "pluginName(%s) isn't support OTA", plugin_name->valuestring);
            vesync_bypass_reply_pkg_err_msg(BP_ERR_PARA_ILLEGAL, p_trace_msg, msg);
            goto _exit;
        }
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    cJSON* json_url = cJSON_GetObjectItemCaseSensitive(json, "url");
    if (cJSON_IsString(json_url))
    {
        if (strlen(json_url->valuestring) <= 1)
        {
            ret = BP_ERR_ARG;
            goto _exit;
        }
        snprintf(upg.fw_url, sizeof(upg.fw_url), "%s", json_url->valuestring);
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    //获取模式
    cJSON* json_mode = cJSON_GetObjectItemCaseSensitive(json, "upMode");
    if (cJSON_IsNumber(json_mode))
    {
        upg.upg_mode = json_mode->valueint;
        if (UPG_MODE_IDLE == json_mode->valueint)        //空闲模式升级
        {

        }
        else if (UPG_MODE_NORMAL == json_mode->valueint)     //标准升级
        {
            if (vesync_ota_get_device_work_status() == true)
            {
                vesync_bypass_reply_noqos(BP_ERR_DEVICE_BUSY, p_trace_msg, NULL);
                goto _exit;
            }
        }
        else if (UPG_MODE_HIGH == json_mode->valueint)       //强制升级
        {

        }
        else
        {
            ret = BP_ERR_ARG;
            goto _exit;
        }
    }
    else
    {
        upg.upg_mode = UPG_MODE_NORMAL;
    }

    vesync_bypass_reply_noqos(SDK_OK, p_trace_msg, NULL);

    vesync_ota_start(upg);    //开始升级

_exit:
    return ret;
}

static bypass_item_data_t upgrade_method_tbl[] = {
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_UP_FIRMWARE, "upFirmware", bypass_method_up_firmware_handle, NULL},
};


void vesync_bypass_upgrade_init(void)
{
    for (int i = 0; i < SIZEOF_ARRAY(upgrade_method_tbl); i++)
    {
        bypass_item_t *item = vesync_bypass_init_item(&upgrade_method_tbl[i]);
        if (item != NULL)
        {
            vesync_bypass_add_item(item);
        }
    }
}

