/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file    lightstring_ir.c
* @brief   红外遥控
* @author  Lind
* @date    2021-12-24
*/
#include <stdio.h>

#include "vesync_common.h"
#include "vesync_log.h"
#include "vesync_device.h"

#include "vhal_rmt_ir.h"

#include "lightstring.h"
#include "lightstring_board.h"
#include "lightstring_ir.h"
#include "lightstring_report.h"


/**
* @brief 接收回调
* @param[in]  addr          [用户码]
* @param[in]  cmd           [指令码]
* @param[in]  repeat_flag   [是否重复]
*/
static void ir_rx_cb(uint32_t addr, uint32_t cmd, bool repeat_flag)
{
    if (0xfd02 != addr || true == repeat_flag)
    {
        APP_LOG(LOG_ERROR, " %x %x\n", addr, cmd);
        return;
    }
    uint16_t real_cmd = cmd & 0xff;
    ls_status_t status;
    ls_get_status(&status);
    ls_ev_t ev;
    if (status.status == false && real_cmd != 0x00)
    {
        // 关闭状态下无法控制，只能开启
        return;
    }
    ev.act_src = LS_ACT_SRC_IR;
    ev.id = LS_EV_ON;
    ev.param.mode_param.mode = status.mode;
    ev.param.mode_param.scene_id = (status.mode == LS_MODE_SCENE ? status.scene_id : status.music_id);
    ev.param.mode_param.brightness = status.brightness;
    ev.param.mode_param.speed = status.speed;
    switch (real_cmd)
    {
        case 0x00:
            break;
        case 0x01:
            ev.id = LS_EV_SET_TIMER;
            ev.param.timer_mode = LS_TIMER_OFF;
            break;
        case 0x02:
            ev.id = LS_EV_OFF;
            break;
        case 0x04:
            ev.id = LS_EV_SET_TIMER;
            ev.param.timer_mode = LS_TIMER_6;
            break;
        case 0x05:
            ev.id = LS_EV_SET_TIMER;
            ev.param.timer_mode = LS_TIMER_8;
            break;
        case 0x06:
            ev.id = LS_EV_SET_TIMER;
            ev.param.timer_mode = LS_TIMER_6639;
            break;
        case 0x08:
            ev.param.mode_param.mode = LS_MODE_MUSIC;
            ev.param.mode_param.scene_id = 1;
            break;
        case 0x09:
            ev.param.mode_param.mode = LS_MODE_SCENE;
            ev.param.mode_param.scene_id = 1;
            break;
        case 0x0a:
            ev.param.mode_param.mode = LS_MODE_SCENE;
            ev.param.mode_param.scene_id = 2;
            break;
        case 0x0c:
            ev.param.mode_param.mode = LS_MODE_MUSIC;
            ev.param.mode_param.scene_id = 2;
            break;
        case 0x0d:
            ev.param.mode_param.mode = LS_MODE_SCENE;
            ev.param.mode_param.scene_id = 3;
            break;
        case 0x0e:
            ev.param.mode_param.mode = LS_MODE_SCENE;
            ev.param.mode_param.scene_id = 4;
            break;
        case 0x10:
            ev.param.mode_param.mode = LS_MODE_MUSIC;
            ev.param.mode_param.scene_id = 3;
            break;
        case 0x11:
            ev.param.mode_param.mode = LS_MODE_SCENE;
            ev.param.mode_param.scene_id = 5;
            break;
        case 0x12:
            ev.param.mode_param.mode = LS_MODE_SCENE;
            ev.param.mode_param.scene_id = 6;
            break;
        case 0x14:
            ev.param.mode_param.mode = LS_MODE_MUSIC;
            ev.param.mode_param.scene_id = 4;
            break;
        case 0x15:
            ev.param.mode_param.mode = LS_MODE_SCENE;
            ev.param.mode_param.scene_id = 7;
            break;
        case 0x16:
            ev.param.mode_param.mode = LS_MODE_SCENE;
            ev.param.mode_param.scene_id = 8;
            break;
        case 0x18:
            ev.id = LS_EV_VOICE_CTRL_ONOFF;
            ev.param.voice_ctrl = !status.voice_ctrl;
            break;
        case 0x19:
            if (status.mode == LS_MODE_MUSIC)
            {
                return;
            }
            ev.param.mode_param.brightness = (status.brightness > 25 ? status.brightness - 25 : status.brightness);
            break;
        case 0x1a:
            if (status.mode == LS_MODE_MUSIC)
            {
                return;
            }
            ev.param.mode_param.brightness  = (status.brightness <= 75 ? status.brightness + 25 : LS_BRIGHTNESS_MAX);
            break;
        default:
            break;
    }
    ls_app_task_notify(&ev);
    ls_report_set_chg_rsn(STAT_CHG_RSN_BTN_STR);
}


/**
* @brief 红外初始化
*/
void ls_ir_rx_init(void)
{
    int ret = vhal_rmt_ir_rx_init(RMT_RX_CH_0, LS_IR_RX_IO, IR_PROTOCOL_NEC, 1000, true);
    if (ret == VHAL_OK)
    {
        APP_LOG(LOG_INFO, "ir init successfully io[%d]\n", LS_IR_RX_IO);
    }
    else
    {
        APP_LOG(LOG_ERROR, "ir init failed\n");
    }
    vhal_rmt_ir_reg_rx_cb(ir_rx_cb);
}

