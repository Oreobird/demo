/**
 *  Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
 * @file        vhal_ble_nimble.c
 * @brief       蓝牙Nimble栈的Hal接口实现
 * @author      Herve.Lin
 * @date        2021-09-03
 */
#include "esp_nimble_hci.h"

#include "nimble/ble.h"
#include "nimble/nimble_port.h"
#include "nimble/nimble_port_freertos.h"
#include "host/ble_hs.h"
#include "host/util/util.h"
#include "host/ble_hs.h"
#include "host/ble_uuid.h"
#include "services/gap/ble_svc_gap.h"
#include "services/gatt/ble_svc_gatt.h"

#include "vesync_common.h"
#include "vesync_log.h"

#include "vhal_ble_internal.h"

// 事件通知回调
static vhal_ble_evt_cb_t s_hal_ble_evt_cb = NULL;
// 命令接收通道回调
static vhal_ble_recv_cb_t s_hal_ble_cmd_recv_cb = NULL;
// 配网接收通道回调
static vhal_ble_recv_cb_t s_hal_ble_netcfg_recv_cb = NULL;
// 设备标志信息
static vhal_ble_t s_ble_info = {false, false, 0};
// 设备名称
static char s_advertise_name[BLE_ADV_NAME_MAX_LEN + 1];
// 协议参考蓝牙协议接口规范:http://wiki.vesync.com:8090/pages/viewpage.action?pageId=14254597
static uint8_t s_adv_manufacturer[26] = {0xd0, 0x06, 0x01, 0x36, 0x35, 0x34, 0x33, 0x32, 0x31, 0xe0, 0xa0, 0x0, 0x0, 0x0};
// 连接后的广播工作模式
static VHAL_BLE_ADV_WORK_E s_ble_adv_work_mode = BLE_ADV_WORK_NORMAL;
// 软件版本号
static uint8_t s_sw_version[] = "R0000V0001";
// 连接句柄
static uint16_t s_conn_handle = BLE_INVALID_CONN_ID;

// cmd GATT服务notify句柄
static uint16_t s_gatt_cmd_notify_handle;
// netcfg GATT服务notify句柄
static uint16_t s_gatt_netcfg_notify_handle;
// update GATT服务notify句柄
static uint16_t s_gatt_update_notify_handle;
// update GATT服务write句柄
static uint16_t s_gatt_update_write_handle;

// Client Characteristic Configuration UUID
static const ble_uuid16_t s_gatt_svr_ccc_uuid = BLE_UUID16_INIT(BLE_GATT_DSC_CLT_CFG_UUID16);
// User service UUID
static const ble_uuid16_t s_gatt_svr_svc_cmd_uuid = BLE_UUID16_INIT(0xFFF0);
static const ble_uuid16_t s_gatt_svr_chr_cmd_notify_uuid = BLE_UUID16_INIT(0xFFF1);
static const ble_uuid16_t s_gatt_svr_chr_cmd_write_uuid = BLE_UUID16_INIT(0xFFF2);
// Netcfg service UUID
static const ble_uuid128_t s_gatt_svr_svc_netcfg_uuid = BLE_UUID128_INIT(0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xB0, 0x00, 0x40, 0x51, 0x04, 0xE0, 0xFF, 0x00, 0xF0);
static const ble_uuid128_t s_gatt_svr_chr_netcfg_write_uuid = BLE_UUID128_INIT(0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xB0, 0x00, 0x40, 0x51, 0x04, 0xE1, 0xFF, 0x00, 0xF0);
static const ble_uuid128_t s_gatt_svr_chr_netcfg_notify_uuid = BLE_UUID128_INIT(0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xB0, 0x00, 0x40, 0x51, 0x04, 0xE2, 0xFF, 0x00, 0xF0);
// User update service UUID
static const ble_uuid128_t s_gatt_svr_svc_update_uuid = BLE_UUID128_INIT(0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xB0, 0x00, 0x40, 0x51, 0x04, 0xC0, 0xFF, 0x00, 0xF0);
static const ble_uuid128_t s_gatt_svr_chr_update_write_uuid = BLE_UUID128_INIT(0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xB0, 0x00, 0x40, 0x51, 0x04, 0xC2, 0xFF, 0x00, 0xF0);
static const ble_uuid128_t s_gatt_svr_chr_update_notify_uuid = BLE_UUID128_INIT(0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xB0, 0x00, 0x40, 0x51, 0x04, 0xC1, 0xFF, 0x00, 0xF0);

// 设备地址类型
static uint8_t s_ble_addr_type;
// 广播参数
static struct ble_gap_adv_params s_adv_params;
// 广播数据
static struct ble_hs_adv_fields s_adv_fields;
// 广播RSP数据
static struct ble_hs_adv_fields s_adv_rsp_fields;

static int gatt_svr_chr_cb(uint16_t conn_handle, uint16_t attr_handle, struct ble_gatt_access_ctxt *ctxt, void *arg);
static int gatt_svr_dsc_ccc_cb(uint16_t conn_handle, uint16_t attr_handle, struct ble_gatt_access_ctxt *ctxt, void *arg);
static int ble_gap_event(struct ble_gap_event *event, void *arg);

/**
 * @brief 毫秒延时实现
 * @param[in] interval [延时时间间隔]
 */
static void ble_delay_ms(uint32_t interval)
{
    vTaskDelay(interval / portTICK_RATE_MS);
}

/**
 * @brief GATT服务定义
 */
static const struct ble_gatt_svc_def gatt_svr_svcs[] =
{
    {
        /**
         * @brief 设备应用通信服务，业务逻辑交互通道
         * @note  Service: cmd
         */
        .type = BLE_GATT_SVC_TYPE_PRIMARY,
        .uuid = &s_gatt_svr_svc_cmd_uuid.u,
        .characteristics = (struct ble_gatt_chr_def[])
        {
            {
                .uuid = &s_gatt_svr_chr_cmd_notify_uuid.u,
                .access_cb = gatt_svr_chr_cb,
                .val_handle = &s_gatt_cmd_notify_handle,
                .flags = BLE_GATT_CHR_F_NOTIFY | BLE_GATT_CHR_F_READ,
                .descriptors = (struct ble_gatt_dsc_def[])
                {
                    {
                        .uuid = &s_gatt_svr_ccc_uuid.u,
                        .att_flags = BLE_GATT_CHR_F_WRITE | BLE_GATT_CHR_F_READ,
                        .access_cb = gatt_svr_dsc_ccc_cb,
                    },
                    {
                        0,
                    },
                },
            },
            {
                .uuid = &s_gatt_svr_chr_cmd_write_uuid.u,
                .access_cb = gatt_svr_chr_cb,
                .flags = BLE_GATT_CHR_F_WRITE | BLE_GATT_CHR_F_WRITE_NO_RSP,
            },
            {
                0,
            },
        },
    },

    {
        /**
         * @brief 设备升级服务，标准服务UUID，公共接口升级通道
         * @note  Service: update
         */
        .type = BLE_GATT_SVC_TYPE_PRIMARY,
        .uuid = &s_gatt_svr_svc_update_uuid.u,
        .characteristics = (struct ble_gatt_chr_def[])
        {
            {
                .uuid = &s_gatt_svr_chr_update_notify_uuid.u,
                .access_cb = gatt_svr_chr_cb,
                .val_handle = &s_gatt_update_notify_handle,
                .flags = BLE_GATT_CHR_F_NOTIFY | BLE_GATT_CHR_F_WRITE | BLE_GATT_CHR_F_WRITE_NO_RSP,
                .descriptors = (struct ble_gatt_dsc_def[])
                {
                    {
                        .uuid = &s_gatt_svr_ccc_uuid.u,
                        .att_flags = BLE_GATT_CHR_F_WRITE | BLE_GATT_CHR_F_READ,
                        .access_cb = gatt_svr_dsc_ccc_cb,
                    },
                    {
                        0,
                    },
                },
            },
            {
                .uuid = &s_gatt_svr_chr_update_write_uuid.u,
                .access_cb = gatt_svr_chr_cb,
                .val_handle = &s_gatt_update_write_handle,
                .flags = BLE_GATT_CHR_F_NOTIFY | BLE_GATT_CHR_F_WRITE | BLE_GATT_CHR_F_WRITE_NO_RSP,
                .descriptors = (struct ble_gatt_dsc_def[])
                {
                    {
                        .uuid = &s_gatt_svr_ccc_uuid.u,
                        .att_flags = BLE_GATT_CHR_F_WRITE | BLE_GATT_CHR_F_READ,
                        .access_cb = gatt_svr_dsc_ccc_cb,
                    },
                    {
                        0,
                    },
                },
            },
            {
                0,
            },
        },
    },

    {
        /**
         * @brief 配网接口
         * @note  Service: netcfg
         */
        .type = BLE_GATT_SVC_TYPE_PRIMARY,
        .uuid = &s_gatt_svr_svc_netcfg_uuid.u,
        .characteristics = (struct ble_gatt_chr_def[])
        {
            {
                .uuid = &s_gatt_svr_chr_netcfg_write_uuid.u,
                .access_cb = gatt_svr_chr_cb,
                .flags = BLE_GATT_CHR_F_WRITE | BLE_GATT_CHR_F_WRITE_NO_RSP,
            },
            {
                .uuid = &s_gatt_svr_chr_netcfg_notify_uuid.u,
                .access_cb = gatt_svr_chr_cb,
                .val_handle = &s_gatt_netcfg_notify_handle,
                .flags = BLE_GATT_CHR_F_NOTIFY | BLE_GATT_CHR_F_READ,
                .descriptors = (struct ble_gatt_dsc_def[])
                {
                    {
                        .uuid = &s_gatt_svr_ccc_uuid.u,
                        .att_flags = BLE_GATT_CHR_F_WRITE | BLE_GATT_CHR_F_READ,
                        .access_cb = gatt_svr_dsc_ccc_cb,
                    },
                    {
                        0,
                    },
                },
            },
            {
                0,
            },
        },
    },

    {
        0,
    },
};

/**
 * @brief 上报蓝牙事件
 * @param[in] evt   [蓝牙事件]
 */
static void hal_ble_evt_set(VHAL_BLE_EVT_E evt)
{
    if (NULL != s_hal_ble_evt_cb)
    {
        s_hal_ble_evt_cb(evt);
    }
}

/**
 * @brief 打印连接的调试信息
 * @param[in] desc  [GAP连接描述信息]
 */
static void ble_print_conn_desc(struct ble_gap_conn_desc *desc)
{
    HAL_LOG(LOG_INFO,
            "\n"
            "  conn_handle=%d conn_itvl=%d conn_latency=%d supervision_timeout=%d encrypted=%d authenticated=%d bonded=%d\n"
            "  our_ota_addr_type=%d our_ota_addr=%02x:%02x:%02x:%02x:%02x:%02x\n"
            "  our_id_addr_type=%d our_id_addr=%02x:%02x:%02x:%02x:%02x:%02x\n"
            "  peer_ota_addr_type=%d peer_ota_addr=%02x:%02x:%02x:%02x:%02x:%02x\n"
            "  peer_id_addr_type=%d peer_id_addr=%02x:%02x:%02x:%02x:%02x:%02x\n",
            desc->conn_handle, desc->conn_itvl, desc->conn_latency, desc->supervision_timeout, desc->sec_state.encrypted, desc->sec_state.authenticated, desc->sec_state.bonded,
            desc->our_ota_addr.type, desc->our_ota_addr.val[5], desc->our_ota_addr.val[4], desc->our_ota_addr.val[3], desc->our_ota_addr.val[2], desc->our_ota_addr.val[1], desc->our_ota_addr.val[0],
            desc->our_id_addr.type, desc->our_id_addr.val[5], desc->our_id_addr.val[4], desc->our_id_addr.val[3], desc->our_id_addr.val[2], desc->our_id_addr.val[1], desc->our_id_addr.val[0],
            desc->peer_ota_addr.type, desc->peer_ota_addr.val[5], desc->peer_ota_addr.val[4], desc->peer_ota_addr.val[3], desc->peer_ota_addr.val[2], desc->peer_ota_addr.val[1], desc->peer_ota_addr.val[0],
            desc->peer_id_addr.type, desc->peer_id_addr.val[5], desc->peer_id_addr.val[4], desc->peer_id_addr.val[3], desc->peer_id_addr.val[2], desc->peer_id_addr.val[1], desc->peer_id_addr.val[0]);
}

/**
 * @brief 特征被写操作时，取出数据
 * @param[in]  om       [蓝牙数据Buffer]
 * @param[in]  cb       [蓝牙数据处理回调]
 * @return int          [结果]
 */
static int gatt_svr_chr_write(struct os_mbuf *om, vhal_ble_recv_cb_t cb)
{
    uint16_t om_len = OS_MBUF_PKTLEN(om);
    uint8_t *p_buf = NULL;
    int rc;

    if (om_len > BLE_RX_MAX_SIZE)
    {
        return BLE_ATT_ERR_INVALID_ATTR_VALUE_LEN;
    }

    p_buf = malloc(om_len);
    if (NULL == p_buf)
    {
        return BLE_ATT_ERR_UNLIKELY;
    }

    uint16_t rd_len = 0;
    rc = ble_hs_mbuf_to_flat(om, p_buf, om_len, &rd_len);
    if (rc != 0)
    {
        rc = BLE_ATT_ERR_UNLIKELY;
        goto EXIT;
    }

    HAL_LOG(LOG_DEBUG, "receive data. om_len: %d, len: %d\n", om_len, rd_len);

    if (NULL != cb)
    {
        cb(p_buf, rd_len);
    }

EXIT:
    free(p_buf);
    return rc;
}

/**
 * @brief Dummy Function
 */
static int gatt_svr_dsc_ccc_cb(uint16_t conn_handle, uint16_t attr_handle, struct ble_gatt_access_ctxt *ctxt, void *arg)
{
    HAL_LOG(LOG_INFO, "skip access, conn_handle: %d, attr_handle: %d\n", conn_handle, attr_handle);
    return 0;
}

/**
 * @brief 特征被读或写时调用的回调函数
 * @param[in] conn_handle   [连接句柄]
 * @param[in] attr_handle   [属性句柄]
 * @param[in] ctxt          [特征的上下文信息]
 * @param[in] arg           [传入的辨识服务的参数]
 * @return int              [处理结果]
 */
static int gatt_svr_chr_cb(uint16_t conn_handle, uint16_t attr_handle, struct ble_gatt_access_ctxt *ctxt, void *arg)
{
    const ble_uuid_t *uuid = ctxt->chr->uuid;

    if (ble_uuid_cmp(uuid, &s_gatt_svr_chr_cmd_write_uuid.u) == 0)
    {
        switch (ctxt->op)
        {
        case BLE_GATT_ACCESS_OP_WRITE_CHR:
            HAL_LOG(LOG_INFO, "write cmd, conn_handle: %d, attr_handle: %d\n", conn_handle, attr_handle);
            return gatt_svr_chr_write(ctxt->om, s_hal_ble_cmd_recv_cb);

        default:
            return BLE_ATT_ERR_UNLIKELY;
        }
    }

    if (ble_uuid_cmp(uuid, &s_gatt_svr_chr_netcfg_write_uuid.u) == 0)
    {
        switch (ctxt->op)
        {
        case BLE_GATT_ACCESS_OP_WRITE_CHR:
            HAL_LOG(LOG_INFO, "write net config, conn_handle: %d, attr_handle: %d\n", conn_handle, attr_handle);
            return gatt_svr_chr_write(ctxt->om, s_hal_ble_netcfg_recv_cb);

        default:
            return BLE_ATT_ERR_UNLIKELY;
        }
    }

    if (ble_uuid_cmp(uuid, &s_gatt_svr_chr_update_write_uuid.u) == 0)
    {
        switch (ctxt->op)
        {
        case BLE_GATT_ACCESS_OP_WRITE_CHR:
            HAL_LOG(LOG_DEBUG, "write update, skip\n");
            return gatt_svr_chr_write(ctxt->om, NULL);

        default:
            return BLE_ATT_ERR_UNLIKELY;
        }
    }

    return BLE_ATT_ERR_UNLIKELY;
}

/**
 * @brief GATT服务注册OP回调
 * @param[in] ctxt  [GATT服务注册上下文]
 * @param[in] arg   [用户传入参数]
 */
static void gatt_svr_register_cb(struct ble_gatt_register_ctxt *ctxt, void *arg)
{
    char buf[BLE_UUID_STR_LEN];

    switch (ctxt->op)
    {
    case BLE_GATT_REGISTER_OP_SVC:
        HAL_LOG(LOG_DEBUG, "registered service %s with handle=%d\n",
                ble_uuid_to_str(ctxt->svc.svc_def->uuid, buf),
                ctxt->svc.handle);
        break;

    case BLE_GATT_REGISTER_OP_CHR:
        HAL_LOG(LOG_DEBUG, "registering characteristic %s with def_handle=%d val_handle=%d\n",
                ble_uuid_to_str(ctxt->chr.chr_def->uuid, buf),
                ctxt->chr.def_handle,
                ctxt->chr.val_handle);
        break;

    case BLE_GATT_REGISTER_OP_DSC:
        HAL_LOG(LOG_DEBUG, "registering descriptor %s with handle=%d\n",
                ble_uuid_to_str(ctxt->dsc.dsc_def->uuid, buf),
                ctxt->dsc.handle);
        break;

    default:
        break;
    }
}

/**
 * @brief 初始化GATT服务
 * @return int  [结果]
 */
static int gatt_svr_init(void)
{
    int ret = 0;

    ret = ble_gatts_count_cfg(gatt_svr_svcs);
    if (ret != 0)
    {
        return ret;
    }

    ret = ble_gatts_add_svcs(gatt_svr_svcs);
    if (ret != 0)
    {
        return ret;
    }

    return ret;
}

/**
 * @brief 设置广播类型为：不可连接、可扫描、不定向广播
 * @param[in/out] p_parm    [指向广播参数结构体]
 */
static void set_adv_scan_ind(struct ble_gap_adv_params *p_parm)
{
    // ADV_TYPE: ADV_SCAN_IND
    // CONN_MODE: BLE_GAP_CONN_MODE_NON
    // DISC_MODE: BLE_GAP_DISC_MODE_GEN
    p_parm->conn_mode = BLE_GAP_CONN_MODE_NON;
    p_parm->disc_mode = BLE_GAP_DISC_MODE_GEN;
}

/**
 * @brief 设置广播类型为：可连接、可扫描、不定向广播
 * @param[in/out] p_parm    [指向广播参数结构体]
 */
static void set_adv_ind(struct ble_gap_adv_params *p_parm)
{
    // ADV_TYPE: ADV_IND
    // CONN_MODE: BLE_GAP_CONN_MODE_UND
    // DISC_MODE: BLE_GAP_DISC_MODE_GEN
    p_parm->conn_mode = BLE_GAP_CONN_MODE_UND;
    p_parm->disc_mode = BLE_GAP_DISC_MODE_GEN;
}

/**
 * @brief 设置广播参数，并且开始蓝牙广播
 * @return int  [0：成功；-1：失败]
 */
static int ble_advertise_start(void)
{
    int ret = 0;

    // 设置广播数据
    ret = ble_gap_adv_set_fields(&s_adv_fields);
    if (ret != 0)
    {
        HAL_LOG(LOG_ERROR, "error set ble_adv data: ret=%d\n", ret);
        return ret;
    }
    ret = ble_gap_adv_rsp_set_fields(&s_adv_rsp_fields);
    if (ret != 0)
    {
        HAL_LOG(LOG_ERROR, "error set ble_adv_rsp data: ret=%d\n", ret);
        return ret;
    }

    // 启动广播
    ret = ble_gap_adv_start(s_ble_addr_type, NULL, BLE_HS_FOREVER, &s_adv_params, ble_gap_event, NULL);
    if (ret != 0)
    {
        if (BLE_HS_EALREADY != ret)
        {
            HAL_LOG(LOG_ERROR, "error enable ble_adv: ret=%d\n", ret);
            return ret;
        }
        HAL_LOG(LOG_INFO, "ble_adv already start\n");
    }
    else
    {
        HAL_LOG(LOG_WARN, "ble_adv start: [%s]\n", s_advertise_name);
    }

    return 0;
}

/**
 * @brief 停止蓝牙广播
 * @return int  [0：成功；-1：失败]
 */
static int ble_advertise_stop(void)
{
    int ret = ble_gap_adv_stop();
    if (0 != ret)
    {
        if (BLE_HS_EALREADY != ret)
        {
            HAL_LOG(LOG_WARN, "ble_adv stop fail:%d\n", ret);
            return ret;
        }
        HAL_LOG(LOG_INFO, "ble_adv already stop\n");
    }

    return 0;
}

/**
 * @brief GAP事件回调，由Nimble Host调用
 * @param[in] event     [发出的事件类型]
 * @param[in] arg       [应用相关参数，对于外设无用]
 * @return int          [0：应用成功处理了事件；非零：处理失败，返回值与事件相关]
 */
static int ble_gap_event(struct ble_gap_event *event, void *arg)
{
    UNUSED(arg);

    struct ble_gap_conn_desc desc;

    switch (event->type)
    {
    case BLE_GAP_EVENT_CONNECT:
        HAL_LOG(LOG_INFO, "connection %s: status=%d\n",
                event->connect.status == 0 ? "established" : "failed",
                event->connect.status);

        if (event->connect.status != 0)
        {
            if (true == s_ble_info.adv_started)
            {
                // 连接失败，恢复广播
                set_adv_ind(&s_adv_params);
                ble_advertise_start();
            }
        }
        else
        {
            if (0 != ble_gap_conn_find(event->connect.conn_handle, &desc))
            {
                HAL_LOG(LOG_ERROR, "find_conn error\n");
                return -1;
            }
            ble_print_conn_desc(&desc);

            // 检查配置是否需要蓝牙连接后继续开启广播
            if ((BLE_ADV_WORK_CONNECTED == s_ble_adv_work_mode) &&
                (true == s_ble_info.adv_started))
            {
                set_adv_scan_ind(&s_adv_params);
                ble_advertise_start();
            }

            hal_ble_evt_set(HB_EVT_CONNECTED);
        }

        // Update the connection handle
        s_conn_handle = event->connect.conn_handle;
        break;

    case BLE_GAP_EVENT_DISCONNECT:
        HAL_LOG(LOG_INFO, "disconnect: reason=%d\n", event->disconnect.reason);
        ble_print_conn_desc(&event->disconnect.conn);

        // Reset the connection handle
        s_conn_handle = BLE_INVALID_CONN_ID;

        // Reset the MTU value for prepare the next communication
        s_ble_info.tx_mtu = BLE_DEFAULT_MTU_SIZE - BLE_ATT_OPCODE_HANDLE_LEN;

        // 如果蓝牙广播已经被失能，那么不恢复广播
        if(true == s_ble_info.adv_started)
        {
            // 可能蓝牙在连接后又恢复了广播，这里统一停止
            ble_advertise_stop();

            // 连接断开，恢复广播
            set_adv_ind(&s_adv_params);
            ble_advertise_start();
        }

        hal_ble_evt_set(HB_EVT_DISCONNECTED);
        break;

    case BLE_GAP_EVENT_CONN_UPDATE:
        // The central has updated the connection parameters
        HAL_LOG(LOG_INFO, "connection updated: status=%d\n", event->conn_update.status);

        if (0 != ble_gap_conn_find(event->conn_update.conn_handle, &desc))
        {
            HAL_LOG(LOG_ERROR, "find_conn error\n");
            return -1;
        }
        ble_print_conn_desc(&desc);
        return 0;

    case BLE_GAP_EVENT_ADV_COMPLETE:
        // 广播时间被设置为BLE_HS_FOREVER，不会到达这里
        HAL_LOG(LOG_INFO, "adv complete: reason=%d\n", event->adv_complete.reason);
        vhal_ble_advertising_stop();
        set_adv_ind(&s_adv_params);
        vhal_ble_advertising_start();
        break;

    case BLE_GAP_EVENT_ENC_CHANGE:
        // Encryption has been enabled or disabled for this connection
        HAL_LOG(LOG_INFO, "encryption change event: status=%d\n", event->enc_change.status);

        if (0 != ble_gap_conn_find(event->conn_update.conn_handle, &desc))
        {
            HAL_LOG(LOG_ERROR, "find_conn error\n");
            return -1;
        }
        ble_print_conn_desc(&desc);
        return 0;

    case BLE_GAP_EVENT_SUBSCRIBE:
        HAL_LOG(LOG_INFO, "subscribe event: conn_handle=%d attr_handle=%d reason=%d prevn=%d curn=%d previ=%d curi=%d\n",
                event->subscribe.conn_handle,
                event->subscribe.attr_handle,
                event->subscribe.reason,
                event->subscribe.prev_notify,
                event->subscribe.cur_notify,
                event->subscribe.prev_indicate,
                event->subscribe.cur_indicate);
        break;

    case BLE_GAP_EVENT_MTU:
        HAL_LOG(LOG_INFO, "mtu update event: conn_handle=%d cid=%d req_mtu=%d\n",
                event->mtu.conn_handle,
                event->mtu.channel_id,
                event->mtu.value);
        // 更新MTU值
        s_ble_info.tx_mtu = event->mtu.value - BLE_ATT_OPCODE_HANDLE_LEN;
        break;

    case BLE_GAP_EVENT_REPEAT_PAIRING:
        // We already have a bond with the peer, but it is attempting to
        // establish a new secure link. This app sacrifices security for
        // convenience: just throw away the old bond and accept the new link

        // Delete the old bond
        if (0 != ble_gap_conn_find(event->conn_update.conn_handle, &desc))
        {
            HAL_LOG(LOG_ERROR, "find_conn error\n");
            return -1;
        }
        ble_store_util_delete_peer(&desc.peer_id_addr);

        // Return BLE_GAP_REPEAT_PAIRING_RETRY to indicate that the host should
        // continue with the pairing operation
        return BLE_GAP_REPEAT_PAIRING_RETRY;

    default:
        return 0;
    }

    return 0;
}

/**
 * @brief ble发送数据
 * @param[in] handle        [发送的类型cmd/update/netcfg]
 * @param[in] p_data        [发送数据指针]
 * @param[in] len           [发送数据长度]
 * @return int32_t          [VHAL_OK/VHAL_FAIL]
 */
static int32_t ble_data_send(uint16_t handle, uint8_t *p_data, uint16_t len)
{
    HAL_LOG(LOG_DEBUG, "handle=%d, len=%d\n", handle, len);

    if (BLE_INVALID_CONN_ID == s_conn_handle)
    {
        HAL_LOG(LOG_WARN, "fail. device disconnected\n");
        return VHAL_FAIL;
    }

    uint16_t offset = 0, retry = 0;

    while (offset < len)
    {
        uint16_t tx_len = ((len - offset) > s_ble_info.tx_mtu ? s_ble_info.tx_mtu : (len - offset));

        struct os_mbuf *om = ble_hs_mbuf_from_flat(p_data + offset, tx_len);
        if (NULL == om)
        {
            HAL_LOG(LOG_DEBUG, "mbuf_from_flat fail. retry:%d\n", tx_len, retry);

            if (retry++ > BLE_SEND_POLL_MAX_RETRY)
            {
                HAL_LOG(LOG_ERROR, "mbuf_from_flat error\n");
                return VHAL_FAIL;
            }

            ble_delay_ms(BLE_SEND_POLL_DELAY_MS);
            continue;
        }
        else
        {
            HAL_LOG(LOG_DEBUG, "mbuf_from_flat done. tx_len: %d\n", tx_len);
        }

        int rc = ble_gattc_notify_custom(s_conn_handle, handle, om);
        if (0 != rc)
        {
            HAL_LOG(LOG_ERROR, "notify custom error:%d, tx_len:%d\n", rc, tx_len);
            return VHAL_FAIL;
        }

        retry = 0;
        offset += tx_len;
    }

    return VHAL_OK;
}

/**
 * @brief 蓝牙协议栈Host任务
 * @param[in] param [无用]
 */
static void ble_host_task(void *param)
{
    UNUSED(param);
    HAL_LOG(LOG_DEBUG, "nimble host task started\n");

    // This function will return only when nimble_port_stop() is executed
    nimble_port_run();
    nimble_port_freertos_deinit();
}

/**
 * @brief Host与Controller同步成功回调
 */
static void ble_on_sync(void)
{
    int ret = 0;

    ret = ble_hs_id_infer_auto(0, &s_ble_addr_type);
    if (ret != 0)
    {
        HAL_LOG(LOG_ERROR, "get ble_addr_type error\n");
        return;
    }

    uint8_t addr_val[6] = {0};
    ret = ble_hs_id_copy_addr(s_ble_addr_type, addr_val, NULL);
    if (ret != 0)
    {
        HAL_LOG(LOG_ERROR, "get copy addr error\n");
        return;
    }

    HAL_LOG(LOG_INFO, "host_dev addr: %02x:%02x:%02x:%02x:%02x:%02x\n",
            addr_val[5], addr_val[4], addr_val[3], addr_val[2], addr_val[1], addr_val[0]);

    hal_ble_evt_set(HB_EVT_INIT_COMPLETE);
}

/**
 * @brief Host复位回调
 * @param[in] reason [复位原因]
 */
static void ble_on_reset(int reason)
{
    HAL_LOG(LOG_ERROR, "resetting: reason=%d\n", reason);
}

/**
 * @brief  初始化蓝牙协议栈及配置蓝牙广播参数
 * @param[in]  dev_name         [蓝牙设备名称]
 * @param[in]  prj_version      [软件版本号，必须是“1.0.00”的格式]
 * @param[in]  mfr_data         [厂商定义数据]
 * @return     int32_t          [执行结果]
 */
int32_t vhal_ble_init(char *dev_name, char *prj_version, ble_adv_mfr_data_t mfr_data)
{
    if (s_ble_info.init_flag)
    {
        return VHAL_FAIL;
    }

    if ((NULL == dev_name) || (strlen(dev_name) > BLE_ADV_NAME_MAX_LEN) ||
        (NULL == s_sw_version) || (6 != strlen(prj_version)))
    {
        return VHAL_FAIL;
    }

    hal_ble_evt_set(HB_EVT_INIT);

    s_sw_version[6] = prj_version[0];
    s_sw_version[7] = prj_version[2];
    s_sw_version[8] = prj_version[4];
    s_sw_version[9] = prj_version[5];

    strncpy(s_advertise_name, dev_name, BLE_ADV_NAME_MAX_LEN);

    uint8_t mac[6] = {0};

    esp_err_t ret = esp_read_mac(&mac[0], ESP_MAC_BT);
    if (ret)
    {
        HAL_LOG(LOG_ERROR, "%s get mac failed: %s\n", __func__, esp_err_to_name(ret));
        return ret;
    }

    for (uint8_t i = 0; i < sizeof(mac); i++)
    {
        s_adv_manufacturer[3 + i] = mac[5 - i];
    }

    s_adv_manufacturer[9] = mfr_data.product_type;
    s_adv_manufacturer[10] = mfr_data.product_model;
    s_adv_manufacturer[11] = mfr_data.cmd_code;
    s_adv_manufacturer[12] = mfr_data.netcfg_ver;
    s_adv_manufacturer[13] = mfr_data.netcfg_status;

    s_ble_adv_work_mode = mfr_data.ble_adv_work;

    s_ble_info.tx_mtu = BLE_DEFAULT_MTU_SIZE - BLE_ATT_OPCODE_HANDLE_LEN;

    // 在这之前确定ESP_NVS已经被初始化了
    ESP_ERROR_CHECK(esp_nimble_hci_and_controller_init());

    nimble_port_init();
    // 设置Nimble host配置全局变量
    ble_hs_cfg.reset_cb = ble_on_reset;
    ble_hs_cfg.sync_cb = ble_on_sync;
    ble_hs_cfg.gatts_register_cb = gatt_svr_register_cb;

    ble_svc_gap_init();
    ble_svc_gatt_init();

    if (0 != gatt_svr_init())
    {
        return VHAL_FAIL;
    }

    if (0 != ble_svc_gap_device_name_set(s_advertise_name))
    {
        return VHAL_FAIL;
    }

    nimble_port_freertos_init(ble_host_task);

    // 设置广播数据：
    //  1、Flags:指定广播类型和部分设备信息。
    //  2、Mfg_data:厂商数据
    memset(&s_adv_fields, 0, sizeof(s_adv_fields));
    // 广播标志：可被发现，只支持BLE蓝牙
    s_adv_fields.flags = BLE_HS_ADV_F_DISC_GEN | BLE_HS_ADV_F_BREDR_UNSUP;
    // 设置厂商数据，注意载荷大小受限，如果要再带上设备名称或者射频功率，需要考虑减小厂商数据大小
    s_adv_fields.mfg_data = s_adv_manufacturer;
    s_adv_fields.mfg_data_len = MFR_DEFAULT_DATA_LEN;

    // 设置广播RSP数据
    memset(&s_adv_rsp_fields, 0, sizeof(s_adv_rsp_fields));
    s_adv_rsp_fields.name = (const uint8_t *)s_advertise_name;
    s_adv_rsp_fields.name_len = strlen(s_advertise_name);
    s_adv_rsp_fields.name_is_complete = 1;

    s_adv_params.itvl_min = BLE_ADV_INTERVAL_MIN;
    s_adv_params.itvl_max = BLE_ADV_INTERVAL_MAX;
    set_adv_ind(&s_adv_params);

    s_ble_info.init_flag = true;
    return VHAL_OK;
}

/**
 * @brief 启动广播
 * @return int32_t      [VHAL_OK/VHAL_FAIL]
 */
int32_t vhal_ble_advertising_start(void)
{
    s_ble_info.adv_started = true;

    int ret = ble_advertise_start();
    if (0 != ret)
    {
        return VHAL_FAIL;
    }

    return VHAL_OK;
}

/**
 * @brief 停止广播
 * @return int32_t      [VHAL_OK/VHAL_FAIL]
 */
int32_t vhal_ble_advertising_stop(void)
{
    s_ble_info.adv_started = false;

    int ret = ble_advertise_stop();
    if (0 != ret)
    {
        return VHAL_FAIL;
    }

    return VHAL_OK;
}

/**
 * @brief 主动断开当前的蓝牙连接
 * @return int32_t      [VHAL_OK/VHAL_FAIL]
 */
int32_t vhal_ble_disconnect(void)
{
    if (0 != ble_gap_terminate(s_conn_handle, BLE_ERR_REM_USER_CONN_TERM))
    {
        return VHAL_FAIL;
    }

    return VHAL_OK;
}

/**
 * @brief 关闭蓝牙功能
 * @return int32_t      [VHAL_OK/VHAL_FAIL]
 */
int32_t vhal_ble_disable(void)
{
    int ret = vhal_ble_advertising_stop();
    if (ret != VHAL_OK)
    {
        return VHAL_FAIL;
    }

    if (vhal_ble_is_connected())
    {
        ret = vhal_ble_disconnect();
        if (ret != VHAL_OK)
        {
            return VHAL_FAIL;
        }
    }
    return VHAL_OK;
}

/**
 * @brief 蓝牙是否已经初始化
 * @return bool     [是否已经初始化]
 */
bool vhal_ble_is_init(void)
{
    return s_ble_info.init_flag;
}

/**
 * @brief 蓝牙是否连接成功？
 * @return bool     [true 连接 false 未连接]
 */
bool vhal_ble_is_connected(void)
{
    return (BLE_INVALID_CONN_ID != s_conn_handle);
}

/**
 * @brief  获取BLE MAC
 * @param[out] dev_mac      [输出蓝牙MAC buffer]
 * @param[in]  max_len      [buffer 长度]
 * @return     int32_t      [执行结果 VHAL_OK/VHAL_FAIL]
 */
int32_t vhal_ble_get_mac(char *dev_mac, uint32_t max_len)
{
    esp_err_t ret = 0;
    uint8_t mac_addr[MAC_ADDR_HEX_LEN] = {0};

    if (NULL == dev_mac || max_len < MAC_ADDR_STR_MAX_LEN)
    {
        HAL_LOG(LOG_ERROR, "invalid param\n");
        return VHAL_FAIL;
    }

    ret = esp_read_mac(mac_addr, ESP_MAC_BT);
    if (ret != 0)
    {
        HAL_LOG(LOG_ERROR, "esp_read_mac failed: %s\n", esp_err_to_name(ret));
        return VHAL_FAIL;
    }

    snprintf(dev_mac, max_len, MACSTR, MAC2STR(mac_addr));

    return VHAL_OK;
}

/**
 * @brief 动态修改广播参数
 * @param[in] product_type
 * @param[in] product_model
 * @return int32_t              [VHAL_OK/VHAL_FAIL]
 */
int32_t vhal_ble_set_adv_product_info(uint8_t product_type, uint8_t product_model)
{
    esp_err_t ret;

    s_adv_manufacturer[9] = product_type;
    s_adv_manufacturer[10] = product_model;

    ret = ble_gap_adv_set_fields(&s_adv_fields);
    if (ret != 0)
    {
        HAL_LOG(LOG_ERROR, "error set ble_adv data: ret=%d\n", ret);
        return VHAL_FAIL;
    }

    return VHAL_OK;
}


/**
 * @brief 动态修改广播命令字段
 * @param[in] cmd_data           [命令数据段]
 * @param[in] cmd_len            [命令数据长度]
 * @param[in] up_flag            [是否更新广播包长度]
 * @return  int32_t              [成功：VHAL_OK，失败：VHAL_FAIL]
 */
int32_t vhal_ble_set_adv_cmd_data(uint8_t * cmd_data, uint8_t cmd_len, bool up_flag)
{
    esp_err_t ret;

    if ((NULL == cmd_data)||(MFR_MAX_CMD_DATA_LEN < cmd_len))
    {
        HAL_LOG(LOG_ERROR, "input illigle!\r\n");
        return VHAL_FAIL;
    }

    memcpy(&s_adv_manufacturer[11], cmd_data, cmd_len);
    if (true == up_flag)
    {
        s_adv_fields.mfg_data_len = MFR_DEFAULT_DATA_LEN + cmd_len - 3;
    }

    ret = ble_gap_adv_set_fields(&s_adv_fields);
    if (ret != 0)
    {
        HAL_LOG(LOG_ERROR, "error set ble_adv data: ret=%d\n", ret);
        return VHAL_FAIL;
    }

    return VHAL_OK;
}


/**
 * @brief 蓝牙广播动态修改配网状态
 * @param[in] netcfg_status     [设备配网状态]
 * @return int32_t              [VHAL_OK/VHAL_FAIL]
 */
int32_t vhal_ble_set_adv_netcfg_status(uint8_t netcfg_status)
{
    esp_err_t ret;

    s_adv_manufacturer[13] = netcfg_status;

    ret = ble_gap_adv_set_fields(&s_adv_fields);
    if (ret != 0)
    {
        HAL_LOG(LOG_ERROR, "error set ble_adv data: ret=%d\n", ret);
        return VHAL_FAIL;
    }

    return VHAL_OK;
}

/**
 * @brief cmd接口发送数据
 * @param[in] p_data        [发送数据指针]
 * @param[in] len           [发送数据长度]
 * @return int32_t          [VHAL_OK/VHAL_FAIL]
 */
int32_t vhal_ble_cmd_data_send(uint8_t *p_data, uint16_t len)
{
    HAL_LOG(LOG_INFO, "send data, len:%d\n", len);

    return ble_data_send(s_gatt_cmd_notify_handle, p_data, len);
}

/**
 * @brief 配网接口发送数据
 * @param[in] p_data        [发送数据指针]
 * @param[in] len           [发送数据长度]
 * @return int32_t          [VHAL_OK/VHAL_FAIL]
 */
int32_t vhal_ble_netcfg_data_send(uint8_t *p_data, uint16_t len)
{
    HAL_LOG(LOG_INFO, "send data, len:%d\n", len);

    return ble_data_send(s_gatt_netcfg_notify_handle, p_data, len);
}

/**
 * @brief 注册蓝牙事件函数
 */
void vhal_ble_reg_evt_cb(vhal_ble_evt_cb_t cb)
{
    s_hal_ble_evt_cb = cb;
}

/**
 * @brief 注册cmd接口接收回调
 */
void vhal_ble_reg_cmd_recv_cb(vhal_ble_recv_cb_t cb)
{
    s_hal_ble_cmd_recv_cb = cb;
}

/**
 * @brief 注册配网接口接收回调
 */
void vhal_ble_reg_netcfg_recv_cb(vhal_ble_recv_cb_t cb)
{
    s_hal_ble_netcfg_recv_cb = cb;
}
