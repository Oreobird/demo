/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        lightstring_button.c
 * @brief       按键任务
 * @author      Lind
 * @date        2021-12-17
 */

#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <stdio.h>

#include "vhal_gpio.h"

#include "vesync_common.h"
#include "vesync_log.h"
#include "vesync_task.h"
#include "vesync_device.h"

#include "lightstring_button.h"
#include "lightstring.h"
#include "lightstring_board.h"
#include "lightstring_report.h"

static bool s_task_run = true;     // 按键扫描任务运行标志
static key_status_t s_switch_key;   // 开关按键参数

/**
 * @brief 设置扫描到的瞬时按键值
 * @param[in]   scan_value      [瞬时按键值]
 */
static void button_key_set_scan_value(int8_t scan_value)
{
    uint64_t new_scan_ts = vesync_task_get_tick_ms();

    if (KEY_SCAN_VALUE_MAX_NUM == ++(s_switch_key.key_scan_value_index))
    {
        (s_switch_key.key_scan_value_index) = 0;
    }
    if (scan_value == s_switch_key.key_scan_value[s_switch_key.key_scan_value_index])
    {
        if (1 == scan_value)    // 高电平
        {
            s_switch_key.key_scan_value[(s_switch_key.key_scan_value_index)] = 0;
            --(s_switch_key.key_pressed_num);
            if(KEY_RELEASED_THRESHOLD == (s_switch_key.key_pressed_num))
            {
                s_switch_key.key_status = KEY_RELEASED_1S_LESS;
                s_switch_key.key_upturn_ts = new_scan_ts;
                return;
            }
        }
        else                    // 低电平
        {
            s_switch_key.key_scan_value[(s_switch_key.key_scan_value_index)] = 1;
            ++(s_switch_key.key_pressed_num);
            if(KEY_PRESSED_THRESHOLD == (s_switch_key.key_pressed_num))
            {
                s_switch_key.key_status = KEY_PRESSED_1S_LESS;
                s_switch_key.key_upturn_ts = new_scan_ts;
                return;
            }
        }
    }
//    APP_LOG(LOG_ERROR, " %d \n", scan_value);
    switch (s_switch_key.key_status)
    {
        case KEY_RELEASED_1S_LESS:
            if (new_scan_ts - s_switch_key.key_upturn_ts > 1000)  // 松开按键超过1s
            {
                s_switch_key.key_status = KEY_RELEASED_1S_MORE;
            }
            break;
        case KEY_PRESSED_1S_LESS:
        case KEY_PRESSED_1S_TO_5S:
        case KEY_PRESSED_5S_TO_15S:
            if (new_scan_ts - s_switch_key.key_upturn_ts > 15000)  // 按下按键超过15s
            {
                s_switch_key.key_status = KEY_PRESSED_15S_MORE;
            }
            else if (new_scan_ts - s_switch_key.key_upturn_ts > 5000)  // 按下按键超过5s
            {
                s_switch_key.key_status = KEY_PRESSED_5S_TO_15S;
            }
            else if (new_scan_ts - s_switch_key.key_upturn_ts > 1000)  // 按下按键超过1s
            {
                s_switch_key.key_status = KEY_PRESSED_1S_TO_5S;
            }
            break;
        case KEY_RELEASED_1S_MORE:
        case KEY_PRESSED_15S_MORE:
        default:
            break;
    }
}


/**
* @brief 按键任务发送消息给APP主任务
* @param[in]  ev_id         [事件id]
*/
static void ls_button_send_ev(LS_EV_E ev_id)
{
    ls_ev_t ev;
    memset(&ev, 0, sizeof(ls_ev_t));
    ev.id = ev_id;
    ev.act_src = LS_ACT_SRC_DEVICE;
    ls_app_task_notify(&ev);
}

/**
 * @brief 按键扫描任务
 */
static void ls_button_task(void *args)
{
    KEY_STATE_E last_key_status;
    uint64_t start_ts = vesync_task_get_tick_ms();
    uint64_t btn_ts[5];
    uint8_t button_cnt = 0;
    uint64_t new_ts;
    s_task_run = true;
    while (s_task_run)
    {
        last_key_status = s_switch_key.key_status;
        s_switch_key.key_set_scan_value(vhal_gpio_get_output(LS_BUTTON_IO));
        if (last_key_status != s_switch_key.key_status)
        {
            switch (s_switch_key.key_status)
            {
                case KEY_RELEASED_1S_MORE:
                    break;
                case KEY_PRESSED_5S_TO_15S:
                    ls_button_send_ev(LS_EV_BEFORE_NETCFG);
                    break;
                case KEY_PRESSED_15S_MORE:
                    APP_LOG(LOG_ERROR, "button pressed 15s\n");
                    ls_button_send_ev(LS_EV_RESET);
                    ls_report_set_chg_rsn(STAT_CHG_RSN_BTN_STR);
                    break;
                case KEY_RELEASED_1S_LESS:
                    switch (last_key_status)
                    {
                        case KEY_PRESSED_1S_LESS:
                            APP_LOG(LOG_DEBUG, "button pressed \n");
                            new_ts = vesync_task_get_tick_ms();
                            if ((new_ts - start_ts) < 10000)
                            {
                                // 上电10s内 可以触发产测模式，要2s内按5次按键
                                btn_ts[button_cnt % 5] = new_ts;
                                button_cnt++;
                                if (button_cnt >= 5 && (new_ts - btn_ts[(button_cnt - 5) % 5]) < 2000)
                                {
                                    ls_button_send_ev(LS_EV_PRODUCTION);
                                    return;
                                }
                            }
                            ls_button_send_ev(LS_EV_ON);
                            ls_report_set_chg_rsn(STAT_CHG_RSN_BTN_STR);
                            break;
                        case KEY_PRESSED_5S_TO_15S:
                            ls_button_send_ev(LS_EV_NETCFG);
                            break;
                        case KEY_PRESSED_1S_TO_5S:
                        case KEY_PRESSED_15S_MORE:
                        default:
                            break;
                    }
                case KEY_PRESSED_1S_LESS:
                case KEY_PRESSED_1S_TO_5S:
                default:
                    break;
            }
        }

        vesync_sleep(10);        // 按键扫描10ms一次
    }
}

/**
 * @brief 产测时，强制退出按键扫描任务
 */
void ls_button_task_exit(void)
{
    APP_LOG(LOG_DEBUG, "button disable \n");
    s_task_run = false;
}

/**
 * @brief ledstrip button初始化
 */
void ls_button_init(void)
{
        // 初始化触摸按键信号接入GPIO
    vhal_gpio_config_t button_io;
    button_io.pin_bit_mask = (1ULL << LS_BUTTON_IO);
    button_io.mode = GPIO_MODE_IN;
    button_io.pull_up_en = GPIO_PULLUP_EN;
    button_io.pull_down_en = GPIO_PULLDOWN_DIS;
    button_io.intr_type = GPIO_INTR_DIS;
    vhal_gpio_init(button_io);

    memset(&s_switch_key, 0, sizeof(s_switch_key));
    s_switch_key.key_set_scan_value = button_key_set_scan_value;
    if (VOS_OK != vesync_task_new(LIGHTSTRING_BUTTON_TASK_NAME, NULL,
                    ls_button_task,
                    NULL,
                    LIGHTSTRING_BUTTON_TASK_STACKSIZE,
                    LIGHTSTRING_BUTTON_TASK_PRIO, NULL))
    {
        APP_LOG(LOG_ERROR, "button task create fail!!!\r\n");
    }
}

