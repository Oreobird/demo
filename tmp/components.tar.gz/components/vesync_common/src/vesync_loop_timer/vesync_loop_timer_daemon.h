/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
 * @file        vesync_loop_timer_daemon_internal.h
 * @brief       基于内部定时器封装的事件与定时器处理任务内部接口声明
 * @date        2021-05-21
 */
#ifndef __VESYNC_LOOP_TIMER_DAEMON_H__
#define __VESYNC_LOOP_TIMER_DAEMON_H__

#include <stdint.h>
#include <stdbool.h>

#include "vesync_loop_timer_internal.h"

#include "vesync_task.h"
#include "vesync_queue.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief 内部的定时器事件ID定义
 * @note  ID枚举的值取在不容易被上层定义重复的负数域
 */
typedef enum
{
    TIMER_EV_ID_MIN = -1,
    TIMER_EV_ADD = -2,
    TIMER_EV_DEL = -3,
    TIMER_EV_CH_PERIOD = -4,
    TIMER_EV_FREE = -5,
    TIMER_EV_ID_MAX = -6,
} TIMER_EV_E;

/**
 * @brief 内部的定时器事件的随行数据定义
 */
typedef struct
{
    vloop_timer_t *timer;
    long  new_period;
} timer_ev_cont_t;

/**
 * @brief 事件订阅者单向链表的节点定义
 */
typedef struct event_sub
{
    int id;
    void (*handle_cb)(void *arg);
    struct event_sub *next;
} event_sub_t;

/**
 * @brief vloop任务实例的数据结构
 */
typedef struct
{
    vesync_queue_t *event_queue;        // 事件接收队列
    vesync_task_t task_handle;          // vloop任务句柄
    vloop_timer_header_t timer_header;  // vloop内部timer表
    event_sub_t *event_subs_header;     // vloop内部事件订阅表
} task_daemon_t;

#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_LOOP_TIMER_DAEMON_H__ */
