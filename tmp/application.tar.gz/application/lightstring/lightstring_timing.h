/**
*Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file    lightstring_timing.h
* @brief   倒计时接口
* @author  Lind
* @date     2021-12-20
*/

#ifndef __LIGHTSTRING_TIMING_H__
#define __LIGHTSTRING_TIMING_H__

#include <stdint.h>
#include <stdbool.h>

#include "lightstring_led.h"

#ifdef __cplusplus
extern "C" {
#endif

#define LIGHTSTRING_TIMER_MAX_NUM            (1)       // timing最大数量
#define LIGHTSTRING_TIMER_MIN_ID             (1)       // itmer最小ID

/**
 * @brief timer定时配置
 */
typedef struct
{
    uint16_t id;            // timer id，最多5个，范围为1~5
    LS_MODE_E mode;         // 模式 关、场景、音乐
    uint32_t total_sec;     // 时间，单位：秒
    uint8_t scene_id;       // 场景id
} ls_timing_t;

/**
* @brief 新增一个timer
* @param[in]   total_sec   [timer定时时间]
* @param[out]  p_id        [timer id]
* @param[in]   mode        [timer执行模式]
* @param[in]  scene_id     [场景id]
* @return     int          [APP_OK/APP_FAIL]
*/
int ls_timing_add(uint32_t total_sec, uint16_t *p_id, LS_MODE_E mode, uint8_t scene_id);

/**
* @brief 删除一个timer
* @param[in]  uint16_t                 [timer id]
* @return     int_t                    [APP_OK/APP_FAIL]
*/
int ls_timing_remove(uint16_t timer_id);

/**
* @brief 删除imer
*/
void ls_timing_clear(void);

/**
* @brief 获取timer执行的动作
*/
ls_timing_t *ls_timing_get_act(void);

/**
* @brief 初始化timer
*/
void ls_timing_init(void);

#ifdef __cplusplus
}
#endif

#endif /* __LIGHTSTRING_TIMING_H__ */

