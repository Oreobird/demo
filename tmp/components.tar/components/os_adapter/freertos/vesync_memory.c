/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_memory.c
 * @brief       memory抽象层，封装freertos内存相关接口
 * @author      Joshua
 * @date        2021-04-20
 */

#include <stdlib.h>
#include "vesync_memory.h"

/*
 * @brief  申请内存
 * @param[in]  size                    [内存块大小，以字节为单位]
 * @return void (*)                    [成功：返回内存地址；失败：返回 NULL]
 */
void *vesync_malloc(uint32_t size)
{
    return malloc(size);
}

/*
 * @brief  申请内存并初始化
 * @param[in]  nmemb                   [要被分配的元素个数]
 * @param[in]  size                    [元素的大小]
 * @return void (*)                    [成功：返回内存地址；失败：返回 NULL]
 */
void *vesync_calloc(uint32_t nmemb, uint32_t size)
{
    return calloc(nmemb, size);
}

/*
 * @brief  重新分配内存大小
 * @param[in]  ptr                     [指向一个要重新分配内存的内存块]
 * @param[in]  size                    [内存块新的大小，以字节为单位]
 * @return void (*)                    [成功：返回内存地址；失败：返回 NULL]
 */
void *vesync_realloc(void *ptr, uint32_t size)
{
    return realloc(ptr, size);
}

/*
 * @brief  释放内存空间
 * @param[in]  ptr                     [指向的内存地址]
 * @return void
 */
void vesync_free(void *ptr)
{
    if (ptr)
    {
        free(ptr);
        ptr = NULL;
    }
}

