/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_utils.h
 * @brief       Vesync工具类函数声明
 * @date        2021-04-20
 */
#ifndef __VESYNC_UTILS_H__
#define __VESYNC_UTILS_H__

#include "stdint.h"

#ifdef __cplusplus
extern "C" {
#endif


/**
 * @brief 主机序转16位整形小端
 * @param[in]   host            [16位整形主机序数据]
 * @return      uint16_t        [16位整形小端数据]
 */
uint16_t vesync_htole16(uint16_t host);

/**
 * @brief 主机序转16位整形大端
 * @param[in]   host            [16位整形主机序数据]
 * @return      uint16_t        [16位整形大端数据]
 */
uint16_t vesync_htobe16(uint16_t host);

/**
 * @brief 16位整形小端转主机序
 * @param[in]   le              [16位整形小端数据]
 * @return      uint16_t        [16位整形主机序数据]
 */
uint16_t vesync_le16toh(uint16_t le);

/**
 * @brief 16位整形大端转主机序
 * @param[in]   be              [16位整形大端数据]
 * @return      uint16_t        [16位整形主机序数据]
 */
uint16_t vesync_be16toh(uint16_t be);

/**
 * @brief powf的替代实现，减小ROM占用和提高运算速度
 * @attention 大数运算时是不安全，要注意正负无穷的问题
 * @param[in]   x               [底数]
 * @param[in]   p               [指数]
 * @return      float           [运算结果]
 */
float vesync_powf(float x, float p);

/**
 * @brief 比vesync_powf更快，降低精度的实现
 * @attention 大数运算时是不安全，要注意正负无穷的问题
 * @param[in]   x               [底数]
 * @param[in]   p               [指数]
 * @return      float           [运算结果]
 */
float vesync_powf_x(float x, float p);

/**
 * @brief log10f的替代实现，减小ROM占用和提高运算速度
 * @param[in]   x               [真数]
 * @return      float           [运算结果]
 */
float vesync_log10f(float x);

/**
 * @brief 比vesync_log10f更快，降低精度的实现
 * @param[in]   x               [真数]
 * @return      float           [运算结果]
 */
float vesync_log10f_x(float x);


#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_UTILS_H__ */