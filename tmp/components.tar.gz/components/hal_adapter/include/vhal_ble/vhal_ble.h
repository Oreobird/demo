/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
 * @file        vhal_ble.h
 * @brief       蓝牙hal配置ble服务属性接口
 * @date        2021-06-22
 */

#ifndef __VHAL_BLE_H__
#define __VHAL_BLE_H__

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#include "vesync_common.h"


#ifdef __cplusplus
extern "C"
{
#endif

#define  MFR_MAX_CMD_DATA_LEN             15       // 广播命令字段最大长度
#define  MFR_DEFAULT_DATA_LEN             14       // 广播用户自定义数据固定长度数值


/**
 * @brief 蓝牙状态事件
 */
typedef enum
{
    HB_EVT_INIT,
    HB_EVT_INIT_COMPLETE,
    HB_EVT_CONNECTED,
    HB_EVT_DISCONNECTED
} VHAL_BLE_EVT_E;


/**
 * @brief 蓝牙广播工作模式
 */
typedef enum
{
    BLE_ADV_WORK_NORMAL,       //正常模式蓝牙连接后广播关闭
    BLE_ADV_WORK_CONNECTED,    //蓝牙连接后广播依然开启
} VHAL_BLE_ADV_WORK_E;


/**
 * @brief  蓝牙广播包中厂商自定义数据(不包含Mac和header)
 */
typedef struct
{
    uint8_t product_type;       // 产品类型
    uint8_t product_model;      // 产品型号码
    uint8_t cmd_code;           // 命令码
    uint8_t netcfg_ver;         // 蓝牙配网版本
    uint8_t netcfg_status;      // 设备配网状态
    VHAL_BLE_ADV_WORK_E ble_adv_work;       // 蓝牙广播工作方式
} ble_adv_mfr_data_t;

/**
 * @brief  蓝牙事件回调函数
 * @param[in]  event           [蓝牙事件类型]
 */
typedef void (*vhal_ble_evt_cb_t)(VHAL_BLE_EVT_E event);

/**
 * @brief  蓝牙cmd接口接收回调函数
 * @param[in]  p_data          [接收的命令数据]
 * @param[in]  length          [数据长度]
 */
typedef void (*vhal_ble_recv_cb_t)(uint8_t *p_data, uint16_t length);


/**
 * @brief  初始化蓝牙协议栈及配置蓝牙广播参数
 * @param[in]  dev_name         [蓝牙设备名称]
 * @param[in]  prj_version      [软件版本号，必须是“1.0.00”的格式]
 * @param[in]  mfr_data         [厂商定义数据]
 * @return  int32_t             [成功：VHAL_OK，失败：VHAL_FAIL]
 */
int32_t vhal_ble_init(char *dev_name, char *prj_version, ble_adv_mfr_data_t mfr_data);

/**
 * @brief 注册蓝牙事件函数
 */
void vhal_ble_reg_evt_cb(vhal_ble_evt_cb_t cb);

/**
 * @brief 注册cmd接口接收回调
 */
void vhal_ble_reg_cmd_recv_cb(vhal_ble_recv_cb_t cb);

/**
 * @brief 注册配网接口接收回调
 */
void vhal_ble_reg_netcfg_recv_cb(vhal_ble_recv_cb_t cb);


/**
 * @brief 启动广播
 * @return  int32_t             [成功：VHAL_OK，失败：VHAL_FAIL]
 */
int32_t vhal_ble_advertising_start(void);

/**
 * @brief 停止广播
 * @return  int32_t             [成功：VHAL_OK，失败：VHAL_FAIL]
 */
int32_t vhal_ble_advertising_stop(void);


/**
 * @brief 主动断开当前的蓝牙连接
 * @return  int32_t             [成功：VHAL_OK，失败：VHAL_FAIL]
 */
int32_t vhal_ble_disconnect(void);

/**
 * @brief 关闭蓝牙功能
 * @return  int32_t             [成功：VHAL_OK，失败：VHAL_FAIL]
 */
int32_t vhal_ble_disable(void);

/**
 * @brief cmd接口发送数据
 * @param[in] p_data            [发送数据指针]
 * @param[in] len               [发送数据长度]
 * @return  int32_t             [成功：VHAL_OK，失败：VHAL_FAIL]
 */
int32_t vhal_ble_cmd_data_send(uint8_t *p_data, uint16_t len);

/**
 * @brief update接口发送数据
 * @param[in] p_data            [发送数据指针]
 * @param[in] len               [发送数据长度]
 * @return  int32_t             [成功：VHAL_OK，失败：VHAL_FAIL]
 */
int32_t vhal_ble_update_data_send(uint8_t *p_data, uint16_t len);

/**
 * @brief 配网接口发送数据
 * @param[in] p_data            [发送数据指针]
 * @param[in] len               [发送数据长度]
 * @return  int32_t             [成功：VHAL_OK，失败：VHAL_FAIL]
 */
int32_t vhal_ble_netcfg_data_send(uint8_t *p_data, uint16_t len);

/**
 * @brief  蓝牙是否已经初始化
 * @return     bool             [true 已初始化，false 未初始化]
 */
bool vhal_ble_is_init(void);


/**
 * @brief 蓝牙是否连接成功
 * @return bool                 [true 连接， false 未连接]
 */
bool vhal_ble_is_connected(void);


/**
 * @brief  获取BLE MAC
 * @param[out] dev_mac          [输出蓝牙MAC buffer]
 * @param[in]  max_len          [buffer 长度]
 * @return  int32_t             [成功：VHAL_OK，失败：VHAL_FAIL]
 */
int32_t vhal_ble_get_mac(char *dev_mac, uint32_t max_len);

/**
 * @brief 动态修改广播参数
 * @param[in] product_type       [产品类型]
 * @param[in] product_model      [产品model]
 * @return  int32_t              [成功：VHAL_OK，失败：VHAL_FAIL]
 */
int32_t vhal_ble_set_adv_product_info(uint8_t product_type, uint8_t product_model);

/**
 * @brief 动态修改广播命令字段
 * @param[in] cmd_data           [命令数据段]
 * @param[in] cmd_len            [命令数据长度]
 * @param[in] up_flag            [是否更新广播包长度]
 * @return  int32_t              [成功：VHAL_OK，失败：VHAL_FAIL]
 */
int32_t vhal_ble_set_adv_cmd_data(uint8_t * cmd_data, uint8_t cmd_len, bool up_flag);


/**
 * @brief 蓝牙广播动态修改配网状态
 * @param[in] netcfg_status       [设备配网状态]
 * @return  int32_t               [成功：VHAL_OK，失败：VHAL_FAIL]
 */
int32_t vhal_ble_set_adv_netcfg_status(uint8_t netcfg_status);

#ifdef __cplusplus
}
#endif

#endif /* __VHAL_BLE_H__ */

