/**
 *  Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vhal_mcpwm.c
 * @brief       乐鑫平台MCPWM驱动接口封装
 * @author      Dongri.Su
 * @date        2021-04-22
 */

#include <stdio.h>

#include "driver/mcpwm.h"
#include "soc/mcpwm_reg.h"
#include "soc/mcpwm_struct.h"

#include "vesync_common.h"
#include "vesync_log.h"

#include "vhal_mcpwm.h"


/*-----------------------------------------------------------------------------*
 *                           内部函数API实现                                         *
 *-----------------------------------------------------------------------------*/

/*
 * @brief  pwm io signal转换
 * @param[in]  pwm_io_signal            [HAL层封装的pwm io]
 * @return     mcpwm_io_signals_t       [转换为SDK定义的pwm io]
 */
static mcpwm_io_signals_t vhal_esp_pwm_conv_io_signal(PWM_IO_SIGNALS_E pwm_io_signal)
{
    switch (pwm_io_signal)
    {
        case PWM_0A:
            return MCPWM0A;
        case PWM_0B:
            return MCPWM0B;
        case PWM_1A:
            return MCPWM1A;
        case PWM_1B:
            return MCPWM1B;
        case PWM_2A:
            return MCPWM2A;
        case PWM_2B:
            return MCPWM2B;
        case PWM_SYNC_0:
            return MCPWM_SYNC_0;
        case PWM_SYNC_1:
            return MCPWM_SYNC_1;
        case PWM_SYNC_2:
            return MCPWM_SYNC_2;
        case PWM_FAULT_0:
            return MCPWM_FAULT_0;
        case PWM_FAULT_1:
            return MCPWM_FAULT_1;
        case PWM_FAULT_2:
            return MCPWM_FAULT_2;
        case PWM_CAP_0:
            return MCPWM_CAP_0;
        case PWM_CAP_1:
            return MCPWM_CAP_1;
        case PWM_CAP_2:
            return MCPWM_CAP_2;
        default:
            return MCPWM0A;
    }
}

/*
 * @brief  pwm_unit转换
 * @param[in]  pwm_unit                 [HAL层封装的pwm unit]
 * @return     mcpwm_unit_t             [转换为SDK定义的pwm unit]
 */
static mcpwm_unit_t vhal_pwm_conv_unit(PWM_UNIT_E pwm_unit)
{
    switch (pwm_unit)
    {
        case PWM_UNIT_0:
            return MCPWM_UNIT_0;
        case PWM_UNIT_1:
            return MCPWM_UNIT_1;
        default:
            return MCPWM_UNIT_MAX;
    }
}

/*
 * @brief  pwm_timer转换
 * @param[in]  pwm_timer                [HAL层封装的pwm timer]
 * @return     mcpwm_timer_t            [转换为SDK定义的驱动pwm timer]
 */
static mcpwm_timer_t vhal_pwm_conv_timer(PWM_TIMER_E pwm_timer)
{
    switch (pwm_timer)
    {
        case PWM_TIMER_0:
            return MCPWM_TIMER_0;
        case PWM_TIMER_1:
            return MCPWM_TIMER_1;
        case PWM_TIMER_2:
            return MCPWM_TIMER_2;
        default:
            return MCPWM_TIMER_MAX;
    }
}

/*
 * @brief  pwm_operator转换
 * @param[in]  pwm_operator             [HAL层封装的pwm operator]
 * @return     mcpwm_operator_t         [转换为SDK定义的pwm operator]
 */
static mcpwm_operator_t vhal_pwm_conv_operator(PWM_OPERATOR_E pwm_operator)
{
    switch (pwm_operator)
    {
        case PWM_OPR_A:
            return MCPWM_OPR_A;
        case PWM_OPR_B:
            return MCPWM_OPR_B;
        default:
            return MCPWM_OPR_MAX;
    }
}

/*
 * @brief  pwm_counter_type转换
 * @param[in]  pwm_counter_type         [HAL层封装的pwm counter type]
 * @return    mcpwm_counter_type_t      [转换为SDK定义的pwm counter type]
 */
static mcpwm_counter_type_t vhal_pwm_conv_counter_type(PWM_COUNTER_TYPE_E pwm_counter_type)
{
    switch (pwm_counter_type)
    {
        case PWM_UP_COUNTER:
            return MCPWM_UP_COUNTER;
        case PWM_DOWN_COUNTER:
            return MCPWM_DOWN_COUNTER;
        case PWM_UP_DOWN_COUNTER:
            return MCPWM_UP_DOWN_COUNTER;
        default:
            return MCPWM_COUNTER_MAX;
    }
}

/*
 * @brief  pwm_duty_type转换
 * @param[in]  pwm_duty_type            [HAL层封装的pwm duty type]
 * @return     mcpwm_duty_type_t        [转换为SDK定义的驱动pwm duty type]
 */
static mcpwm_duty_type_t vhal_pwm_conv_duty_type(PWM_DUTY_TYPE_E pwm_duty_type)
{
    switch (pwm_duty_type)
    {
        case PWM_DUTY_MODE_0:
            return MCPWM_DUTY_MODE_0;
        case PWM_DUTY_MODE_1:
            return MCPWM_DUTY_MODE_1;
        default:
            return MCPWM_DUTY_MODE_MAX;
    }
}

/*
 * @brief  pwm_capture_signal转换
 * @param[in]  pwm_capture_signal       [HAL层封装的pwm capture signal]
 * @return     mcpwm_capture_signal_t   [转换为SDK定义的pwm capture signal]
 */
static mcpwm_capture_signal_t vhal_pwm_conv_capture_signal(PWM_CAPTURE_SIGNAL_E pwm_capture_signal)
{
    switch (pwm_capture_signal)
    {
        case PWM_SELECT_CAP0:
            return MCPWM_SELECT_CAP0;
        case PWM_SELECT_CAP1:
            return MCPWM_SELECT_CAP1;
        case PWM_SELECT_CAP2:
            return MCPWM_SELECT_CAP2;
        default:
            return MCPWM_SELECT_CAP0;
    }
}

/*
 * @brief  pwm_capture_on_edge转换
 * @param[in]  pwm_capture_on_edge      [HAL层封装的pwm capture on edge]
 * @return     mcpwm_capture_on_edge_t  [转换为SDK定义的pwm capture on edge]
 */
static mcpwm_capture_on_edge_t vhal_pwm_conv_capture_on_edge(PWM_CAPTURE_ON_EDGE_E pwm_capture_on_edge)
{
    switch (pwm_capture_on_edge)
    {
        case PWM_NEG_EDGE:
            return MCPWM_NEG_EDGE;
        case PWM_POS_EDGE:
            return MCPWM_POS_EDGE;
        default:
            return MCPWM_NEG_EDGE;
    }
}


/*-----------------------------------------------------------------------------*
 *                           外部函数API实现                                         *
 *-----------------------------------------------------------------------------*/

/**
 * @brief  pwm gpio 初始化函数
 * @param[in]  pwm_unit                 [设置MCPWM单元(0-1)]
 * @param[in]  pwm_io_signal            [设置MCPWM信号]
 * @param[in]  gpio_num                 [MCPWM配置GPIO]
 * @return     int32_t                  [操作结果, 0为成功，其他值表示失败]
 */
int32_t vhal_pwm_gpio_init(PWM_UNIT_E pwm_unit, PWM_IO_SIGNALS_E pwm_io_signal, int gpio_num)
{
    int32_t ret = -1;
    mcpwm_unit_t mcpwm_unit;
    mcpwm_io_signals_t mcpwm_io_signal;

    mcpwm_unit = vhal_pwm_conv_unit(pwm_unit);
    mcpwm_io_signal = vhal_esp_pwm_conv_io_signal(pwm_io_signal);
    ret = mcpwm_gpio_init(mcpwm_unit, mcpwm_io_signal, gpio_num);

    if (ESP_OK != ret)
    {
        return VHAL_FAIL;
    }

    return VHAL_OK;
}

/**
 * @brief  pwm 功能初始化函数
 * @param[in]  pwm_unit                 [设置MCPWM单元(0-1)]
 * @param[in]  pwm_timer                [设置MCPWM timer]
 * @param[in]  pwm_cfg                  [MCPWM配置]
 * @return     int32_t                  [操作结果, 0为成功，其他值表示失败]
 */
int32_t vhal_pwm_init(PWM_UNIT_E pwm_unit, PWM_TIMER_E pwm_timer, pwm_config_t *pwm_cfg)
{
    int32_t ret = -1;
    mcpwm_unit_t mcpwm_unit;
    mcpwm_timer_t mcpwm_timer;
    mcpwm_config_t mcpwm_cfg;

    mcpwm_unit = vhal_pwm_conv_unit(pwm_unit);
    mcpwm_timer = vhal_pwm_conv_timer(pwm_timer);

    mcpwm_cfg.frequency = pwm_cfg->frequency;
    mcpwm_cfg.cmpr_a = pwm_cfg->cmpr_a;
    mcpwm_cfg.cmpr_b = pwm_cfg->cmpr_b;
    mcpwm_cfg.duty_mode = vhal_pwm_conv_duty_type(pwm_cfg->duty_mode);
    mcpwm_cfg.counter_mode = vhal_pwm_conv_counter_type(pwm_cfg->counter_mode);

    ret = mcpwm_init(mcpwm_unit, mcpwm_timer, &mcpwm_cfg);
    if (ESP_OK != ret)
    {
        return VHAL_FAIL;
    }

    return VHAL_OK;
}

/**
 * @brief  pwm 功能开启函数
 * @param[in]  pwm_unit                 [设置MCPWM单元(0-1)]
 * @param[in]  pwm_timer                [设置MCPWM timer]
 * @return     int32_t                  [操作结果, 0为成功，其他值表示失败]
 */
int32_t vhal_pwm_start(PWM_UNIT_E pwm_unit, PWM_TIMER_E pwm_timer)
{
    int32_t ret = -1;
    mcpwm_unit_t mcpwm_unit;
    mcpwm_timer_t mcpwm_timer;

    mcpwm_unit = vhal_pwm_conv_unit(pwm_unit);
    mcpwm_timer = vhal_pwm_conv_timer(pwm_timer);

    ret = mcpwm_start(mcpwm_unit, mcpwm_timer);
    if (ESP_OK != ret)
    {
        return VHAL_FAIL;
    }

    return VHAL_OK;
}

/**
 * @brief  pwm 功能关闭函数
 * @param[in]  pwm_unit                 [设置MCPWM单元(0-1)]
 * @param[in]  pwm_timer                [设置MCPWM timer]
 * @return     int32_t                  [操作结果, 0为成功，其他值表示失败]
 */
int32_t vhal_pwm_stop(PWM_UNIT_E pwm_unit, PWM_TIMER_E pwm_timer)
{
    int32_t ret = -1;
    mcpwm_unit_t mcpwm_unit;
    mcpwm_timer_t mcpwm_timer;

    mcpwm_unit = vhal_pwm_conv_unit(pwm_unit);
    mcpwm_timer = vhal_pwm_conv_timer(pwm_timer);

    ret = mcpwm_stop(mcpwm_unit, mcpwm_timer);
    if (ESP_OK != ret)
    {
        return VHAL_FAIL;
    }

    return VHAL_OK;
}

/**
 * @brief  设置pwm 频率
 * @param[in]  pwm_unit                 [设置MCPWM单元(0-1)]
 * @param[in]  pwm_timer                [设置MCPWM timer]
 * @param[in]  frequency                [设置MCPWM 频率]
 * @return     int32_t                  [操作结果, 0为成功，其他值表示失败]
 */
int32_t vhal_pwm_set_frequency(PWM_UNIT_E pwm_unit, PWM_TIMER_E pwm_timer, uint32_t frequency)
{
    int32_t ret = -1;
    mcpwm_unit_t mcpwm_unit;
    mcpwm_timer_t mcpwm_timer;

    mcpwm_unit = vhal_pwm_conv_unit(pwm_unit);
    mcpwm_timer = vhal_pwm_conv_timer(pwm_timer);

    ret = mcpwm_set_frequency(mcpwm_unit, mcpwm_timer, frequency);
    if (ESP_OK != ret)
    {
        return VHAL_FAIL;
    }

    return VHAL_OK;
}

/**
 * @brief  设置pwm 占空比
 * @param[in]  pwm_unit                 [设置MCPWM单元(0-1)]
 * @param[in]  pwm_timer                [设置MCPWM timer]
 * @param[in]  pwm_operator             [设置MCPWM operator]
 * @param[in]  duty                     [设置MCPWM 占空比]
 * @return     int32_t                  [操作结果, 0为成功，其他值表示失败]
 */
int32_t vhal_pwm_set_duty(PWM_UNIT_E pwm_unit, PWM_TIMER_E pwm_timer, PWM_OPERATOR_E pwm_operator, float duty)
{
    int32_t ret = -1;
    mcpwm_unit_t mcpwm_unit;
    mcpwm_timer_t mcpwm_timer;
    mcpwm_operator_t mcpwm_operator;

    mcpwm_unit = vhal_pwm_conv_unit(pwm_unit);
    mcpwm_timer = vhal_pwm_conv_timer(pwm_timer);
    mcpwm_operator = vhal_pwm_conv_operator(pwm_operator);

    ret = mcpwm_set_duty(mcpwm_unit, mcpwm_timer, mcpwm_operator, duty);
    if (ESP_OK != ret)
    {
        return VHAL_FAIL;
    }

    return VHAL_OK;
}

/**
 * @brief  设置pwm 占空比类型
 * @param[in]  pwm_unit                 [设置MCPWM单元(0-1)]
 * @param[in]  pwm_timer                [设置MCPWM timer]
 * @param[in]  pwm_operator             [设置MCPWM operator]
 * @param[in]  duty_type                [设置MCPWM 占空比类型]
 * @return     int32_t                  [操作结果, 0为成功，其他值表示失败]
 */
int32_t vhal_pwm_set_duty_type(PWM_UNIT_E pwm_unit, PWM_TIMER_E pwm_timer, PWM_OPERATOR_E pwm_operator,
                                    PWM_DUTY_TYPE_E duty_type)
{
    int32_t ret = -1;
    mcpwm_unit_t mcpwm_unit;
    mcpwm_timer_t mcpwm_timer;
    mcpwm_operator_t mcpwm_operator;
    mcpwm_duty_type_t mcpwm_duty_type;

    mcpwm_unit = vhal_pwm_conv_unit(pwm_unit);
    mcpwm_timer = vhal_pwm_conv_timer(pwm_timer);
    mcpwm_operator = vhal_pwm_conv_operator(pwm_operator);
    mcpwm_duty_type = vhal_pwm_conv_duty_type(duty_type);

    ret = mcpwm_set_duty_type(mcpwm_unit, mcpwm_timer, mcpwm_operator, mcpwm_duty_type);
    if (ESP_OK != ret)
    {
        return VHAL_FAIL;
    }

    return VHAL_OK;
}

/**
 * @brief  获取pwm 频率
 * @param[in]   pwm_unit                 [设置MCPWM单元(0-1)]
 * @param[in]   pwm_timer                [设置MCPWM timer]
 * @return      uint32_t                 [获取频率]
 */
uint32_t vhal_pwm_get_frequency(PWM_UNIT_E pwm_unit, PWM_TIMER_E pwm_timer)
{
    mcpwm_unit_t mcpwm_unit;
    mcpwm_timer_t mcpwm_timer;

    mcpwm_unit = vhal_pwm_conv_unit(pwm_unit);
    mcpwm_timer = vhal_pwm_conv_timer(pwm_timer);

    return (mcpwm_get_frequency(mcpwm_unit, mcpwm_timer));
}

/**
 * @brief   获取pwm 占空比
 * @param[in]   pwm_unit                [设置MCPWM单元(0-1)]
 * @param[in]   pwm_timer               [设置MCPWM timer]
 * @param[in]   pwm_operator            [设置MCPWM operator]
 * @return      float                   [获取占空比]
 */
float vhal_pwm_get_duty(PWM_UNIT_E pwm_unit, PWM_TIMER_E pwm_timer, PWM_OPERATOR_E pwm_operator)
{
    mcpwm_unit_t mcpwm_unit;
    mcpwm_timer_t mcpwm_timer;
    mcpwm_operator_t mcpwm_operator;

    mcpwm_unit = vhal_pwm_conv_unit(pwm_unit);
    mcpwm_timer = vhal_pwm_conv_timer(pwm_timer);
    mcpwm_operator = vhal_pwm_conv_operator(pwm_operator);

    return (mcpwm_get_duty(mcpwm_unit, mcpwm_timer, mcpwm_operator));
}

/**
 * @brief  使能pwm capture功能
 * @param[in]  pwm_unit                 [设置MCPWM单元(0-1)]
 * @param[in]  cap_sig                  [捕获通道]
 * @param[in]  cap_edge                 [设置捕获边沿]
 * @param[in]  num_of_pulse             [脉冲数]
 * @return     int32_t                  [操作结果, 0为成功，其他值表示失败]
 */
int32_t vhal_pwm_enable_capture(PWM_UNIT_E pwm_unit, PWM_CAPTURE_SIGNAL_E cap_sig, PWM_CAPTURE_ON_EDGE_E cap_edge,
                                uint32_t num_of_pulse)
{
    int32_t ret = -1;
    mcpwm_unit_t mcpwm_unit;
    mcpwm_capture_signal_t mcpwm_cap_sig;
    mcpwm_capture_on_edge_t mcpwm_cap_edge;

    mcpwm_unit = vhal_pwm_conv_unit(pwm_unit);
    mcpwm_cap_sig = vhal_pwm_conv_capture_signal(cap_sig);
    mcpwm_cap_edge = vhal_pwm_conv_capture_on_edge(cap_edge);

    ret = mcpwm_capture_enable(mcpwm_unit, mcpwm_cap_sig, mcpwm_cap_edge, num_of_pulse);
    if (ESP_OK != ret)
    {
        return VHAL_FAIL;
    }

    return VHAL_OK;
}

/**
 * @brief  除能pwm capture 功能
 * @param[in]  mcpwm_num                 [MCPWM单元(0-1)]
 * @param[in]  cap_sig                   [捕获通道]
 * @return     int32_t                  [操作结果, 0为成功，其他值表示失败]
 */
int32_t vhal_pwm_disable_capture(PWM_UNIT_E pwm_unit, PWM_CAPTURE_SIGNAL_E cap_sig)
{
    int32_t ret = -1;
    mcpwm_unit_t mcpwm_unit;
    mcpwm_capture_signal_t mcpwm_cap_sig;

    mcpwm_unit = vhal_pwm_conv_unit(pwm_unit);
    mcpwm_cap_sig = vhal_pwm_conv_capture_signal(cap_sig);

    ret = mcpwm_capture_disable(mcpwm_unit, mcpwm_cap_sig);
    if (ESP_OK != ret)
    {
        return VHAL_FAIL;
    }

    return VHAL_OK;
}

/**
 * @brief  获取 pwm capture value
 * @param[in]   pwm_unit                [MCPWM单元(0-1)]
 * @param[in]   cap_sig                 [捕获通道]
 * @return      uint32_t                [捕获值]
 */
uint32_t vhal_pwm_get_capture_signal_value(PWM_UNIT_E pwm_unit, PWM_CAPTURE_SIGNAL_E cap_sig)
{
    mcpwm_unit_t mcpwm_unit;
    mcpwm_capture_signal_t mcpwm_cap_sig;

    mcpwm_unit = vhal_pwm_conv_unit(pwm_unit);
    mcpwm_cap_sig = vhal_pwm_conv_capture_signal(cap_sig);

    return (mcpwm_capture_signal_get_value(mcpwm_unit, mcpwm_cap_sig));
}

/**
 * @brief  pwm 中断函数注册
 * @param[in]  pwm_unit                 [设置MCPWM单元(0-1)]
 * @param[in]  fn                       [中断处理函数]
 * @param[in]  arg                      [中断处理函数传参(无则填NULL)]
 * @param[in]  intr_alloc_flags         [中断分配标志]
 * @param[in]  handle                   [中断返回函数处理]
 * @return     int32_t                  [操作结果, 0为成功，其他值表示失败]
 */
int32_t vhal_pwm_reg_isr(PWM_UNIT_E pwm_unit, void (*fn)(void *), void *arg, int intr_alloc_flags, intr_handle_t *handle)
{
    int32_t ret = -1;
    mcpwm_unit_t mcpwm_unit;

    mcpwm_unit = vhal_pwm_conv_unit(pwm_unit);

    ret = mcpwm_isr_register(mcpwm_unit, fn, arg, intr_alloc_flags, handle);
    if (ESP_OK != ret)
    {
        return VHAL_FAIL;
    }

    return VHAL_OK;
}

