/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_timebase_test.cpp
 * @brief       vesync timebase测试用例
 * @author      Herve
 * @date        2021-11-02
 */

#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <gtest/gtest.h>

#include "vesync_timebase_internal.h"

TEST(vesync_timebase_test, vesync_validate_rtp_test)
{
    int rpt_once = TMBS_ONCE;
    int rpt_mon = TMBS_BIT_MON;
    int rpt_tue = TMBS_BIT_TUE;
    int rpt_sat = TMBS_BIT_SAT;
    int rpt_sun = TMBS_BIT_SUN;

    int rpt_ok_1;
    int rpt_ok_2;
    int rpt_ok_3;
    int rpt_ok_4;
    int rpt_ok_5;

    int rpt_resv = 0x01 << 0;

    rpt_ok_1 = rpt_once | rpt_mon;
    rpt_ok_2 = rpt_tue | rpt_sat;
    rpt_ok_3 = rpt_resv | rpt_mon;
    rpt_ok_4 = rpt_resv | rpt_sat;
    rpt_ok_5 = rpt_sun | rpt_mon;

    int rpt_ok_6 = 0;
    int rpt_ok_7 = 0xff;

    rpt_ok_6 |= TMBS_BIT_MON;
    rpt_ok_6 |= TMBS_BIT_TUE;
    rpt_ok_6 |= TMBS_BIT_WED;
    rpt_ok_6 |= TMBS_BIT_THU;
    rpt_ok_6 |= TMBS_BIT_FRI;
    rpt_ok_6 |= TMBS_BIT_SAT;
    rpt_ok_6 |= TMBS_BIT_SUN;

    int rpt_inv_1 = TMBS_BIT_SUN << 1;
    int rpt_inv_2 = 10000;
    int rpt_inv_3 = 10000 | TMBS_BIT_MON;
    int rpt_inv_4 = 0x100;
    int rpt_inv_5 = 0x101;

    EXPECT_EQ(true, vesync_timebase_is_rpt_valid(rpt_once));
    EXPECT_EQ(true, vesync_timebase_is_rpt_valid(rpt_mon));
    EXPECT_EQ(true, vesync_timebase_is_rpt_valid(rpt_tue));
    EXPECT_EQ(true, vesync_timebase_is_rpt_valid(rpt_sat));

    EXPECT_EQ(true, vesync_timebase_is_rpt_valid(rpt_ok_1));
    EXPECT_EQ(true, vesync_timebase_is_rpt_valid(rpt_ok_2));
    EXPECT_EQ(true, vesync_timebase_is_rpt_valid(rpt_ok_3));
    EXPECT_EQ(true, vesync_timebase_is_rpt_valid(rpt_ok_4));
    EXPECT_EQ(true, vesync_timebase_is_rpt_valid(rpt_ok_5));
    EXPECT_EQ(true, vesync_timebase_is_rpt_valid(rpt_ok_6));
    EXPECT_EQ(true, vesync_timebase_is_rpt_valid(rpt_ok_7));

    EXPECT_EQ(false, vesync_timebase_is_rpt_valid(rpt_resv));

    EXPECT_EQ(false, vesync_timebase_is_rpt_valid(rpt_inv_1));
    EXPECT_EQ(false, vesync_timebase_is_rpt_valid(rpt_inv_2));
    EXPECT_EQ(false, vesync_timebase_is_rpt_valid(rpt_inv_3));
    EXPECT_EQ(false, vesync_timebase_is_rpt_valid(rpt_inv_4));
    EXPECT_EQ(false, vesync_timebase_is_rpt_valid(rpt_inv_5));

    EXPECT_EQ(false, vesync_timebase_is_rpt_valid(-1));
    EXPECT_EQ(false, vesync_timebase_is_rpt_valid(-100));
}