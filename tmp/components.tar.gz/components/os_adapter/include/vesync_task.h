/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_task.h
 * @brief       task抽象层，封装任务相关接口
 * @date        2021-04-20
 */

#ifndef __VESYNC_TASK_H__
#define __VESYNC_TASK_H__

#include <stdint.h>
#include "vesync_os.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief 任务优先级
 */
typedef enum
{
    TASK_PRIORITY_IDLE = 0,                                 /* lowest, special for idle task */
    /* User task priority begin, please define your task priority at this interval */
    TASK_PRIORITY_LOW,                                      /* low */
    TASK_PRIORITY_BELOW_NORMAL,                             /* below normal */
    TASK_PRIORITY_NORMAL,                                   /* normal */
    TASK_PRIORITY_ABOVE_NORMAL,                             /* above normal */
    TASK_PRIORITY_HIGH,                                     /* high */
    TASK_PRIORITY_SOFT_REALTIME,                            /* soft real time */
    TASK_PRIORITY_HARD_REALTIME,                            /* hard real time */
    /* User task priority end */
} TASK_PRIORITY_TYPE_E;


typedef vesync_handle_t *vesync_task_t;

/**
 * @brief  创建任务
 * @param[in]  name                    [任务名称]
 * @param[in]  exit_fn                 [任务退出前处理函数]
 * @param[in]  fn                      [任务执行函数]
 * @param[in]  arg                     [参数]
 * @param[in]  stack_size              [栈大小]
 * @param[in]  prio                    [任务优先级]
 * @param[in]  *task                   [创建的任务结构体指针]
 * @return int                         [成功：VOS_OK；失败：返回VOS_FAIL]
 * @note  任务运行完成后会销毁创建的任务资源
 */
int vesync_task_new(const char *name,
                          void (*exit_fn)(void),
                          void (*fn)(void *),
                          void *arg,
                          int stack_size,
                          int prio,
                          vesync_task_t *task);

/**
 * @brief  获取当前任务名称
 * @return const char *                 [返回当前任务名称]
 */
const char *vesync_task_name(void);

/**
 * @brief  获取tick cout最大值对应的毫秒值
 * @return  uint64_t                    [转换为毫秒的tick count最大值]
 */
uint64_t vesync_task_get_max_tick_ms(void);

/**
 * @brief  获取系统tick，单位转为毫秒
 * @return uint64_t                     [返回系统tick]
 */
uint64_t vesync_task_get_tick_ms(void);

/**
 * @brief  获取当前任务的句柄
 * @return vesync_handle_t              [返回当前任务句柄]
 */
vesync_task_t vesync_task_get_curr_handle(void);

#ifdef __cplusplus
}
#endif
#endif /* __VESYNC_TASK_H__ */

