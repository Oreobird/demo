/*
 * This file is subject to the terms and conditions defined in
 * file 'LICENSE', which is part of this source code package.
 * Tuan PM <tuanpm at live dot com>
 */


#include <stdlib.h>
#include <string.h>

#include "vesync_memory.h"

#include "mqtt_util.h"
#include "mqtt_outbox_private.h"


#if !(defined(CONFIG_MQTT_CUSTOM_OUTBOX) && (CONFIG_MQTT_CUSTOM_OUTBOX))

outbox_handle_t outbox_init(void)
{
    outbox_handle_t outbox = vesync_calloc(1, sizeof(struct outbox_list_t));
    MQTT_UTIL_MEM_CHECK(
        outbox,
        do
        {
            VERR_UPLOAD(VERR_LINK_MOD_COM(VERR_MEM_ALLOC_FAIL), vhal_get_free_heap_size());
            return NULL;
        }
        while (0));
    STAILQ_INIT(outbox);
    return outbox;
}

outbox_item_handle_t outbox_enqueue(outbox_handle_t outbox, outbox_message_handle_t message, outbox_tick_t tick)
{
    MQTT_UTIL_MEM_CHECK(outbox, return NULL);
    MQTT_UTIL_MEM_CHECK(message, return NULL);

    outbox_item_handle_t item = vesync_calloc(1, sizeof(outbox_item_t));
    MQTT_UTIL_MEM_CHECK(
        item,
        do
        {
            VERR_UPLOAD(VERR_LINK_MOD_COM(VERR_MEM_ALLOC_FAIL), vhal_get_free_heap_size());
            return NULL;
        }
        while (0));
    item->msg_id = message->msg_id;
    item->msg_type = message->msg_type;
    item->msg_qos = message->msg_qos;
    item->tick = tick;
    item->len = message->len + message->remaining_len;
    item->pending = QUEUED;
    item->buffer = vesync_malloc(message->len + message->remaining_len);
    MQTT_UTIL_MEM_CHECK(
        item->buffer,
        do
        {
            MQTT_UTIL_SAFE_FREE(item);
            VERR_UPLOAD(VERR_LINK_MOD_COM(VERR_MEM_ALLOC_FAIL), vhal_get_free_heap_size());
            return NULL;
        }
        while (0));
    memset(item->buffer, 0, message->len + message->remaining_len);
    memcpy(item->buffer, message->data, message->len);
    if (message->remaining_data)
    {
        memcpy(item->buffer+message->len, message->remaining_data, message->remaining_len);
    }
    STAILQ_INSERT_TAIL(outbox, item, next);
    MQTT_LOG(LOG_DEBUG, "ENQUEUE msgid=%d, msg_type=%d, len=%d, tick=%lld, size=%d\n", \
        message->msg_id, message->msg_type, message->len + message->remaining_len, item->tick, outbox_get_size(outbox));
    return item;
}

outbox_item_handle_t outbox_get(outbox_handle_t outbox, int msg_id)
{
    MQTT_UTIL_MEM_CHECK(outbox, return NULL);

    outbox_item_handle_t item;
    STAILQ_FOREACH(item, outbox, next)
    {
        if (item->msg_id == msg_id)
        {
            return item;
        }
    }
    return NULL;
}

outbox_item_handle_t outbox_dequeue(outbox_handle_t outbox, pending_state_t pending, outbox_tick_t *tick)
{
    MQTT_UTIL_MEM_CHECK(outbox, return NULL);

    outbox_item_handle_t item;
    STAILQ_FOREACH(item, outbox, next)
    {
        if (item->pending == pending)
        {
            if (tick)
            {
                *tick = item->tick;
            }
            return item;
        }
    }
    return NULL;
}

uint8_t *outbox_item_get_data(outbox_item_handle_t item,  size_t *len, uint16_t *msg_id, int *msg_type, int *qos)
{
    if (item)
    {
        *len = item->len;
        *msg_id = item->msg_id;
        *msg_type = item->msg_type;
        *qos = item->msg_qos;
        return (uint8_t *)item->buffer;
    }
    return NULL;
}

int outbox_delete(outbox_handle_t outbox, int msg_id, int msg_type)
{
    outbox_item_handle_t item, tmp;

    MQTT_UTIL_MEM_CHECK(outbox, return VERR_FAIL);

    STAILQ_FOREACH_SAFE(item, outbox, next, tmp)
    {
        if (item->msg_id == msg_id && item->msg_type == msg_type)
        {
            MQTT_LOG(LOG_DEBUG, "DELETED msgid=%d, msg_type=%d, len=%d, remain size=%d\n", msg_id, msg_type, item->len, outbox_get_size(outbox));
            STAILQ_REMOVE(outbox, item, outbox_item, next);
            MQTT_UTIL_SAFE_FREE(item->buffer);
            MQTT_UTIL_SAFE_FREE(item);
            return VERR_OK;
        }

    }

    return VERR_FAIL;
}

int outbox_delete_msgid(outbox_handle_t outbox, int msg_id)
{
    outbox_item_handle_t item, tmp;

    MQTT_UTIL_MEM_CHECK(outbox, return VERR_FAIL);

    STAILQ_FOREACH_SAFE(item, outbox, next, tmp)
    {
        if (item->msg_id == msg_id)
        {
            STAILQ_REMOVE(outbox, item, outbox_item, next);
            MQTT_LOG(LOG_DEBUG, "DELETED msgid=%d, msg_type=%d, len=%d\n", item->msg_id, item->msg_type, item->len);
            MQTT_UTIL_SAFE_FREE(item->buffer);
            MQTT_UTIL_SAFE_FREE(item);
        }

    }
    return VERR_OK;
}

int outbox_set_pending(outbox_handle_t outbox, int msg_id, pending_state_t pending)
{
    MQTT_UTIL_MEM_CHECK(outbox, return VERR_FAIL);

    outbox_item_handle_t item = outbox_get(outbox, msg_id);
    if (item)
    {
        item->pending = pending;
        if (CONFIRMED == pending && item->ack_cb)
        {
            item->ack_cb();
        }
        return VERR_OK;
    }
    return VERR_FAIL;
}

int outbox_set_tick(outbox_handle_t outbox, int msg_id, outbox_tick_t tick)
{
    outbox_item_handle_t item = outbox_get(outbox, msg_id);
    if (item)
    {
        item->tick = tick;
        return VERR_OK;
    }
    return VERR_FAIL;
}

int outbox_set_ack_cb(outbox_handle_t outbox, int msg_id, void (*ack_cb)(void))
{
    MQTT_UTIL_MEM_CHECK(outbox, return VERR_FAIL);

    outbox_item_handle_t item = outbox_get(outbox, msg_id);
    if (item)
    {
        item->ack_cb = ack_cb;
        return VERR_OK;
    }
    return VERR_FAIL;
}

int outbox_delete_msgtype(outbox_handle_t outbox, int msg_type)
{
    outbox_item_handle_t item, tmp;

    MQTT_UTIL_MEM_CHECK(outbox, return VERR_FAIL);

    STAILQ_FOREACH_SAFE(item, outbox, next, tmp)
    {
        if (item->msg_type == msg_type)
        {
            STAILQ_REMOVE(outbox, item, outbox_item, next);
            MQTT_LOG(LOG_DEBUG, "DELETED msgid=%d, msg_type=%d, len=%d\n", item->msg_id, item->msg_type, item->len);
            MQTT_UTIL_SAFE_FREE(item->buffer);
            MQTT_UTIL_SAFE_FREE(item);
        }

    }
    return VERR_OK;
}

int outbox_delete_expired(outbox_handle_t outbox, outbox_tick_t current_tick, outbox_tick_t timeout)
{
    int deleted_items = 0;
    outbox_item_handle_t item, tmp;

    MQTT_UTIL_MEM_CHECK(outbox, return VERR_FAIL);

    STAILQ_FOREACH_SAFE(item, outbox, next, tmp)
    {
        if (current_tick - item->tick > timeout)
        {
            STAILQ_REMOVE(outbox, item, outbox_item, next);
            MQTT_LOG(LOG_DEBUG, "DELETED msgid=%d, msg_type=%d, len=%d, tick=%lld, current_tick=%lld\n", \
                                     item->msg_id, item->msg_type, item->len, item->tick, current_tick);
            MQTT_UTIL_SAFE_FREE(item->buffer);
            MQTT_UTIL_SAFE_FREE(item);
            deleted_items ++;
        }

    }
    return deleted_items;
}

int outbox_get_size(outbox_handle_t outbox)
{
    int siz = 0;
    outbox_item_handle_t item;

    MQTT_UTIL_MEM_CHECK(outbox, return 0);

    STAILQ_FOREACH(item, outbox, next)
    {
        siz += item->len;
    }
    return siz;
}

int outbox_cleanup(outbox_handle_t outbox, int max_size)
{
    MQTT_UTIL_MEM_CHECK(outbox, return VERR_FAIL);

    while(outbox_get_size(outbox) > max_size)
    {
        outbox_item_handle_t item = outbox_dequeue(outbox, CONFIRMED, NULL);
        if (item == NULL)
        {
            return VERR_FAIL;
        }
        STAILQ_REMOVE(outbox, item, outbox_item, next);
        MQTT_LOG(LOG_DEBUG, "DELETED msgid=%d, msg_type=%d, len=%d\n", item->msg_id, item->msg_type, item->len);
        MQTT_UTIL_SAFE_FREE(item->buffer);
        MQTT_UTIL_SAFE_FREE(item);
    }
    return VERR_OK;
}

void outbox_delete_all_items(outbox_handle_t outbox)
{
    outbox_item_handle_t item, tmp;
    STAILQ_FOREACH_SAFE(item, outbox, next, tmp) 
    {
        STAILQ_REMOVE(outbox, item, outbox_item, next);
        MQTT_UTIL_SAFE_FREE(item->buffer);
        MQTT_UTIL_SAFE_FREE(item);
    }
}

void outbox_destroy(outbox_handle_t outbox)
{
#if 0
    outbox_cleanup(outbox, 0);
#else
    outbox_delete_all_items(outbox);
#endif
    MQTT_UTIL_SAFE_FREE(outbox);
}

#endif /* !(defined(CONFIG_MQTT_CUSTOM_OUTBOX) && (CONFIG_MQTT_CUSTOM_OUTBOX)) */

