/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file    led_strip_board.h
* @brief   灯串配置
* @author  Lind
* @date    2021-12-13
*/

#ifndef __LED_STRIP_BOARD__
#define __LED_STRIP_BOARD__

#ifdef __cplusplus
extern "C" {
#endif

#define LS_BUTTON_IO        (1)     // 按键io
#define LS_RMT_TX_IO        (2)     // rmt信号发送io

#define LS_LED_HS_RST           (10000)
#define LS_LED_V_RST            (100)
#define LS_LED_MIN_BRIGHTNESS   (5)
#define LS_LED_RST              (255)
#define LS_DEFAULT_SCENE_NUM    (15) // 默认场景数量
#define LS_CUSTOM_SCENE_MAX_NUM (16) // 用户自定义场景最大数量

#define   LS_SCENE_DEFAULT_MIN_ID            1       //  默认场景的ID最小值为1
#define   LS_SCENE_DEFAULT_MAX_ID            1024    //  默认场景的ID最大值为1024
#define   LS_SCENE_CUSTOM_MIN_ID             1025    //  自定义场景的ID最小值为1025
#define   LS_SCENE_CUSTOM_MAX_ID             65535   //  自定义场景的ID最大值为65535

// RMT驱动参数
#define WS2814_T0H_NS (300)
#define WS2814_T0L_NS (800)
#define WS2814_T1H_NS (800)
#define WS2814_T1L_NS (800)
#define LED_DATA_LEN  (4)

#define LED_NODE_MAX_NUM    (30)
#define LED_NODE_MIN_NUM    (5)
#define LED_NODE_NUM        (15)

#ifdef __cplusplus
}
#endif

#endif /* __LED_STRIP_BOARD__ */

