/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file        bulb_flash.c
* @brief       bulb flash接口
* @author      Dave
* @date        2021-09-02
*/
#include <stdio.h>
#include <string.h>

#include "vesync_common.h"
#include "vesync_log.h"
#include "vesync_flash.h"
#include "vesync_device.h"
#include "vesync_klv.h"
#include "vesync_memory.h"
#include "vesync_crc.h"

#include "bulb_board.h"
#include "bulb_flash.h"
#include "bulb.h"

static bulb_flash_data_t s_bulb_cfg; // 当前配置
static uint32_t s_flash_crc32; // 当前flash中灯泡配置的crc值

/**
 * @brief 保存灯泡数据到flash
 * @param[in]  p_data           [指向灯泡配置]
 * @return     int              [成功：APP_OK， 失败：APP_FAIL]
 */
static int save_config(bulb_flash_data_t *p_data)
{
    int ret = APP_OK;
    uint8_t *p_buf = (uint8_t *)vesync_calloc(1, BULB_KLV_DATA_LEN);
    if (NULL == p_buf)
    {
        return APP_FAIL;
    }

    // 组装KLV数据
    uint8_t version = BULB_APP_DATA_VERSION;
    int offset = 0;
    offset += vesync_klv_set(p_buf + offset, BULB_KLV_DATA_LEN - offset, BULB_KEY_VERSION, sizeof(version), &version);
    offset += vesync_klv_set(p_buf + offset, BULB_KLV_DATA_LEN - offset, BULB_KEY_ONOFF, sizeof(p_data->bulb_onoff), &p_data->bulb_onoff);
    offset += vesync_klv_set(p_buf + offset, BULB_KLV_DATA_LEN - offset, BULB_KEY_COLOR_MODE, sizeof(p_data->bulb_color_mode), &p_data->bulb_color_mode);
    offset += vesync_klv_set(p_buf + offset, BULB_KLV_DATA_LEN - offset, BULB_KEY_COLOR_TEMP, sizeof(p_data->bulb_color_temp), &p_data->bulb_color_temp);
    offset += vesync_klv_set(p_buf + offset, BULB_KLV_DATA_LEN - offset, BULB_KEY_COLOR_BRIGHT, sizeof(p_data->bulb_color_bright), &p_data->bulb_color_bright);
    offset += vesync_klv_set(p_buf + offset, BULB_KLV_DATA_LEN - offset, BULB_KEY_COLOR_HUE, sizeof(p_data->bulb_color_hue), (uint8_t *)&p_data->bulb_color_hue);
    offset += vesync_klv_set(p_buf + offset, BULB_KLV_DATA_LEN - offset, BULB_KEY_COLOR_SATURATION, sizeof(p_data->bulb_color_saturation), (uint8_t *)&p_data->bulb_color_saturation);
    offset += vesync_klv_set(p_buf + offset, BULB_KLV_DATA_LEN - offset, BULB_KEY_COLOR_VALUE, sizeof(p_data->bulb_color_value), &p_data->bulb_color_value);
    offset += vesync_klv_set(p_buf + offset, BULB_KLV_DATA_LEN - offset, BULB_KEY_POWERNUM, sizeof(p_data->bulb_powernum), &p_data->bulb_powernum);
    offset += vesync_klv_set(p_buf + offset, BULB_KLV_DATA_LEN - offset, BULB_KEY_INIT_FLAG, sizeof(p_data->bulb_init_flag), &p_data->bulb_init_flag);
    offset += vesync_klv_set(p_buf + offset, BULB_KLV_DATA_LEN - offset, BULB_KEY_AGING_TEST, sizeof(p_data->bulb_aging_test), &p_data->bulb_aging_test);
    offset += vesync_klv_set(p_buf + offset, BULB_KLV_DATA_LEN - offset, BULB_KEY_AGING_TEST_TIME, sizeof(p_data->bulb_aging_test_time), &p_data->bulb_aging_test_time);
    offset += vesync_klv_set(p_buf + offset, BULB_KLV_DATA_LEN - offset, BULB_KEY_CLOUD_ZERO, sizeof(p_data->cloud_zero), &p_data->cloud_zero);
    offset += vesync_klv_set(p_buf + offset, BULB_KLV_DATA_LEN - offset, BULB_KEY_SENSITIVE_TYPE, sizeof(p_data->bulb_sensitive_type), &p_data->bulb_sensitive_type);
    offset += vesync_klv_set(p_buf + offset, BULB_KLV_DATA_LEN - offset, BULB_KEY_SENSITIVE_VALUE, sizeof(p_data->bulb_sensitive_value), &p_data->bulb_sensitive_value);
    offset += vesync_klv_set(p_buf + offset, BULB_KLV_DATA_LEN - offset, BULB_KEY_EFFECT, sizeof(p_data->bulb_effect), &p_data->bulb_effect);
    offset += vesync_klv_set(p_buf + offset, BULB_KLV_DATA_LEN - offset, BULB_KEY_SCENE_ID, sizeof(p_data->bulb_scene_id), (uint8_t *)&p_data->bulb_scene_id);
    offset += vesync_klv_set(p_buf + offset, BULB_KLV_DATA_LEN - offset, BULB_KEY_FADE_SPEED_MS, sizeof(p_data->bulb_fade_speed_ms), (uint8_t *)&p_data->bulb_fade_speed_ms);
    offset += vesync_klv_set(p_buf + offset, BULB_KLV_DATA_LEN - offset, BULB_KEY_FADE_ENABLE, sizeof(p_data->bulb_fade_enable), &p_data->bulb_fade_enable);


    uint32_t crc32;
    vesync_crc32(0, p_buf, offset, &crc32);
    if (crc32 == s_flash_crc32)
    {
        goto EXIT;
    }

    // Update crc32
    s_flash_crc32 = crc32;
    APP_LOG(LOG_DEBUG, "update cfg in flash[0x%x]\n", crc32);

    // 将数据写入指定flash分区
    ret = vhal_flash_write(PARTITION_CFG, BULB_USER_CFG_KEY_DATA, p_buf, offset);
    if (VHAL_OK != ret)
    {
        APP_LOG(LOG_ERROR, "write flash fail, ret[%d]\n", ret);
        ret = APP_FAIL;
    }
    else
    {
        ret = APP_OK;
    }

EXIT:
    vesync_free(p_buf);
    return ret;
}

/**
 * @brief 从flash中读取灯泡数据到内存
 * @param[out] p_data           [输出灯泡配置缓存]
 * @param[out] p_crc            [读出数据的crc32]
 * @return     int              [成功：APP_OK， 失败：APP_FAIL]
 */
static int read_bulb_data(bulb_flash_data_t *p_data, uint32_t *p_crc)
{
    if (NULL == p_data || NULL == p_crc)
    {
        return APP_FAIL;
    }

    int ret;
    uint32_t len = BULB_KLV_DATA_LEN;
    uint8_t *p_buf = (uint8_t *)vesync_calloc(1, len);
    if (NULL == p_buf)
    {
        return APP_FAIL;
    }

    ret = vhal_flash_read(PARTITION_CFG, BULB_USER_CFG_KEY_DATA, p_buf, &len);
    if (VHAL_OK != ret)
    {
        APP_LOG(LOG_WARN, "read flash fail, ret[%d]\n", ret);
        ret = APP_FAIL;
    }
    else
    {
        ret = APP_OK;
    }

    uint8_t version = 0;
    vesync_klv_get(p_buf, len, BULB_KEY_VERSION, sizeof(version), &version);
    vesync_klv_get(p_buf, len, BULB_KEY_ONOFF, sizeof(p_data->bulb_onoff), &p_data->bulb_onoff);
    vesync_klv_get(p_buf, len, BULB_KEY_COLOR_MODE, sizeof(p_data->bulb_color_mode), &p_data->bulb_color_mode);
    vesync_klv_get(p_buf, len, BULB_KEY_COLOR_TEMP, sizeof(p_data->bulb_color_temp), &p_data->bulb_color_temp);
    vesync_klv_get(p_buf, len, BULB_KEY_COLOR_BRIGHT, sizeof(p_data->bulb_color_bright), &p_data->bulb_color_bright);
    vesync_klv_get(p_buf, len, BULB_KEY_COLOR_HUE, sizeof(p_data->bulb_color_hue), (uint8_t *)&p_data->bulb_color_hue);
    vesync_klv_get(p_buf, len, BULB_KEY_COLOR_SATURATION, sizeof(p_data->bulb_color_saturation), (uint8_t *)&p_data->bulb_color_saturation);
    vesync_klv_get(p_buf, len, BULB_KEY_COLOR_VALUE, sizeof(p_data->bulb_color_value), &p_data->bulb_color_value);
    vesync_klv_get(p_buf, len, BULB_KEY_POWERNUM, sizeof(p_data->bulb_powernum), &p_data->bulb_powernum);
    vesync_klv_get(p_buf, len, BULB_KEY_INIT_FLAG, sizeof(p_data->bulb_init_flag), &p_data->bulb_init_flag);
    vesync_klv_get(p_buf, len, BULB_KEY_AGING_TEST, sizeof(p_data->bulb_aging_test), &p_data->bulb_aging_test);
    vesync_klv_get(p_buf, len, BULB_KEY_AGING_TEST_TIME, sizeof(p_data->bulb_aging_test_time), &p_data->bulb_aging_test_time);
    vesync_klv_get(p_buf, len, BULB_KEY_CLOUD_ZERO, sizeof(p_data->cloud_zero), &p_data->cloud_zero);
    vesync_klv_get(p_buf, len, BULB_KEY_SENSITIVE_TYPE, sizeof(p_data->bulb_sensitive_type), &p_data->bulb_sensitive_type);
    vesync_klv_get(p_buf, len, BULB_KEY_SENSITIVE_VALUE, sizeof(p_data->bulb_sensitive_value), &p_data->bulb_sensitive_value);
    vesync_klv_get(p_buf, len, BULB_KEY_EFFECT, sizeof(p_data->bulb_effect), &p_data->bulb_effect);
    vesync_klv_get(p_buf, len, BULB_KEY_SCENE_ID, sizeof(p_data->bulb_scene_id), (uint8_t *)&p_data->bulb_scene_id);
    vesync_klv_get(p_buf, len, BULB_KEY_FADE_SPEED_MS, sizeof(p_data->bulb_fade_speed_ms), (uint8_t *)&p_data->bulb_fade_speed_ms);
    vesync_klv_get(p_buf, len, BULB_KEY_FADE_ENABLE, sizeof(p_data->bulb_fade_enable), &p_data->bulb_fade_enable);

    // Calculate crc32
    vesync_crc32(0, p_buf, len, p_crc);

    vesync_free(p_buf);
    return ret;
}

int bulb_flash_reset_cfg(void)
{
    bulb_flash_upd_cfg(BULB_CFG_COLOR_BRIGHT, 100);
    bulb_flash_upd_cfg(BULB_CFG_COLOR_TEMP, 100);
    bulb_flash_upd_cfg(BULB_CFG_COLOR_HUE, 0);
    bulb_flash_upd_cfg(BULB_CFG_COLOR_MODE, 0);
    bulb_flash_upd_cfg(BULB_CFG_COLOR_SATURATION, 10000);
    bulb_flash_upd_cfg(BULB_CFG_COLOR_VALUE, 100);
    bulb_flash_upd_cfg(BULB_CFG_ONOFF, 1);
    bulb_flash_upd_cfg(BULB_CFG_POWERNUM, 0);
    bulb_flash_upd_cfg(BULB_CFG_SENSITIVE_TYPE, 1);
    bulb_flash_upd_cfg(BULB_CFG_SENSITIVE_VALUE, 100);
    bulb_flash_upd_cfg(BULB_CFG_EFFECT, BULB_CFG_EFFECT_MODE_1);
    bulb_flash_upd_cfg(BULB_CFG_FADE_SPEED_MS, BULB_CFG_DEFAULT_FADE_SPEED_MS);
    bulb_flash_upd_cfg(BULB_CFG_FADE_ENABLE, 0);

    bulb_flash_flush_cfg();
    return APP_OK;
}

int bulb_flash_get_cfg(BULB_CFG_FLAG_E flag)
{
    switch (flag)
    {
    case BULB_CFG_ONOFF:
        return s_bulb_cfg.bulb_onoff;
    case BULB_CFG_COLOR_MODE:
        return s_bulb_cfg.bulb_color_mode;
    case BULB_CFG_COLOR_TEMP:
        return s_bulb_cfg.bulb_color_temp;
    case BULB_CFG_COLOR_BRIGHT:
        return s_bulb_cfg.bulb_color_bright;
    case BULB_CFG_COLOR_HUE:
        return s_bulb_cfg.bulb_color_hue;
    case BULB_CFG_COLOR_SATURATION:
        return s_bulb_cfg.bulb_color_saturation;
    case BULB_CFG_COLOR_VALUE:
        return s_bulb_cfg.bulb_color_value;
    case BULB_CFG_POWERNUM:
        return s_bulb_cfg.bulb_powernum;
    case BULB_CFG_INIT_FLAG:
        return s_bulb_cfg.bulb_init_flag;
    case BULB_CFG_AGING_TEST:
        return s_bulb_cfg.bulb_aging_test;
    case BULB_CFG_AGING_TEST_TIME:
        return s_bulb_cfg.bulb_aging_test_time;
    case BULB_CFG_CLOUD_ZERO:
        return s_bulb_cfg.cloud_zero;
    case BULB_CFG_SENSITIVE_TYPE:
        return s_bulb_cfg.bulb_sensitive_type;
    case BULB_CFG_SENSITIVE_VALUE:
        return s_bulb_cfg.bulb_sensitive_value;
    case BULB_CFG_EFFECT:
        return s_bulb_cfg.bulb_effect;
    case BULB_CFG_SCENE_ID:
        return s_bulb_cfg.bulb_scene_id;
    case BULB_CFG_FADE_SPEED_MS:
        return s_bulb_cfg.bulb_fade_speed_ms;
    case BULB_CFG_FADE_ENABLE:
        return s_bulb_cfg.bulb_fade_enable;
    default:
        return 0xFF;
    }
}

int bulb_flash_upd_cfg(BULB_CFG_FLAG_E flag, int val)
{
    switch (flag)
    {
    case BULB_CFG_ONOFF:
        s_bulb_cfg.bulb_onoff = val;
        break;
    case BULB_CFG_COLOR_MODE:
        s_bulb_cfg.bulb_color_mode = val;
        break;
    case BULB_CFG_COLOR_TEMP:
        s_bulb_cfg.bulb_color_temp = val;
        break;
    case BULB_CFG_COLOR_BRIGHT:
        s_bulb_cfg.bulb_color_bright = val;
        break;
    case BULB_CFG_COLOR_HUE:
        s_bulb_cfg.bulb_color_hue = val;
        break;
    case BULB_CFG_COLOR_SATURATION:
        s_bulb_cfg.bulb_color_saturation = val;
        break;
    case BULB_CFG_COLOR_VALUE:
        s_bulb_cfg.bulb_color_value = val;
        break;
    case BULB_CFG_POWERNUM:
        s_bulb_cfg.bulb_powernum = val;
        break;
    case BULB_CFG_INIT_FLAG:
        s_bulb_cfg.bulb_init_flag = val;
        break;
    case BULB_CFG_AGING_TEST:
        s_bulb_cfg.bulb_aging_test = val;
        break;
    case BULB_CFG_AGING_TEST_TIME:
        s_bulb_cfg.bulb_aging_test_time = val;
        break;
    case BULB_CFG_CLOUD_ZERO:
        s_bulb_cfg.cloud_zero = val;
        break;
    case BULB_CFG_SENSITIVE_TYPE:
        s_bulb_cfg.bulb_sensitive_type = val;
        break;
    case BULB_CFG_SENSITIVE_VALUE:
        s_bulb_cfg.bulb_sensitive_value = val;
        break;
    case BULB_CFG_EFFECT:
        s_bulb_cfg.bulb_effect = val;
        break;
    case BULB_CFG_SCENE_ID:
        s_bulb_cfg.bulb_scene_id = val;
        break;
    case BULB_CFG_FADE_SPEED_MS:
        s_bulb_cfg.bulb_fade_speed_ms = val;
        break;
    case BULB_CFG_FADE_ENABLE:
        s_bulb_cfg.bulb_fade_enable = val;
        break;
    default:
        APP_LOG(LOG_ERROR, "Unknown flag(=%d).\n", flag);
        return APP_FAIL;
    }

    return APP_OK;
}

int bulb_flash_flush_cfg(void)
{
    return save_config(&s_bulb_cfg);
}

void bulb_flash_load_cfg(BULB_ACT_SRC_E src)
{
    UNUSED(src);
    memset(&s_bulb_cfg, 0, sizeof(bulb_flash_data_t));

    uint32_t crc32;
    if (APP_OK == read_bulb_data(&s_bulb_cfg, &crc32))
    {
        s_bulb_cfg.bulb_init_flag = 1;
        s_flash_crc32 = crc32;
        APP_LOG(LOG_DEBUG, "load cfg from flash[0x%x]\n", crc32);
    }
    else
    {
        APP_LOG(LOG_ERROR, "load cfg from flash fail\n");
    }
}
