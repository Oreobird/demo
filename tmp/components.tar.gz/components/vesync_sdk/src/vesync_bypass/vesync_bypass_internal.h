/*
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file        vesync_bypass_internal.h
* @brief       bypass处理接口
* @date        2021-05-13
*/

#ifndef __VESYNC_BYPASS_INTERNAL_H__
#define __VESYNC_BYPASS_INTERNAL_H__

#include "vesync_bypass.h"
#include "vesync_list.h"
#include "vesync_report.h"

#ifdef __cplusplus
extern "C" {
#endif

#define BYPASS_EVENT_PUBLISH_STR    "bypass"

// 设备消息来源
#define BP_AUTH_MSG_FROM_DVLPR       (MSG_TAG_DVLPR)                                 // 只允许developer来源的消息
#define BP_AUTH_MSG_FROM_MQTT        (MSG_TAG_MQTT)                                  // 只允许MQTT来源的消息
#define BP_AUTH_MSG_FROM_LOCAL       (MSG_TAG_LOCAL)                                 // 只允许局域网（本地通信）来源的消息
#define BP_AUTH_MSG_FROM_MQTT_LOCAL  (MSG_TAG_MQTT | MSG_TAG_LOCAL)                  // 允许MQTT和局域网来源的消息
#define BP_AUTH_MSG_FROM_ALL         (MSG_TAG_DVLPR | MSG_TAG_MQTT | MSG_TAG_LOCAL)  // 允许所有来源的消息

/**
 * @brief 设备消息来源标签(MQTT/developer/Local)
 */
typedef enum
{
    MSG_TAG_NULL  = 0,          // 未知(非法制)
    MSG_TAG_DVLPR = 0x1,        // 消息来源于开发者模式
    MSG_TAG_MQTT  = 0x2,        // 消息来源于MQTT
    MSG_TAG_LOCAL = 0x4,        // 消息来源于局域网
    //MSG_TAG_HTTP  = 0x8,        // 消息来源于http
    MSG_TAG_SRPC = 0x10,        // 消息来源于SRPC
} BYPASS_MSG_TAG_TYPE_E;


/**
 * @brief bypass item 数据结构
 */
typedef struct
{
    uint32_t auth_mask;                      // 接口授权掩码
    BYPASS_METHOD_ID_E  method_id;           // 接口id
    char method[BYPASS_METHOD_NAME_MAX_LEN]; // 接口名称
    bypass_method_handle_fn_t method_handle; // 接口json解析回调函数
    bypass_method_cb_t app_cb;               // 接口应用层回调函数
} bypass_item_data_t;


/**
 * @brief bypass item 数据结构
 */
typedef struct
{
    struct list_head list;
    bypass_item_data_t data;
} bypass_item_t;


/**
 * @brief bypass user item 数据结构
 */
typedef struct
{
    struct list_head list;
    bypass_user_data_t data;
} bypass_user_item_t;


/**
 * @brief bypass item 数据结构
 */
typedef struct
{
    int num;
    //vesync_mutex_t mutex;
    struct list_head list;
    struct list_head user_list;  // user define method list
} bypass_mgt_t;


/**
 * @brief bypass 模块初始化
 */
void vesync_bypass_init(void);

/**
* @brief 初始化节点
* @param[in] bypass_item_data_t            [节点数据]
* @return bypass_item_t *                  [节点指针]
*/
bypass_item_t *vesync_bypass_init_item(bypass_item_data_t *data);


/**
 * @brief 添加节点
 * @param[in] bypass_item_t                [节点]
 * @return                                 [SDK_OK/SDK_FAIL]
 */
int vesync_bypass_add_item(bypass_item_t *item);


/**
 * @brief bypass 消息应答函数, 带MQTT消息等级
 * @param[in] code                         [错误码]
 * @param[in] p_trace_msg                  [trace message app发送过来原样返回]
 * @param[in] json                         [返回数据json指针， 如果没返回数据返回空指针]
 * @param[in] qos                          [MQTT消息等级]
 * @param[in] puback_cb                    [收到qos1确认包后的回调函数]
 * @return                                 [BYPASS_ERR_E]
 */
int vesync_bypass_reply_qos(int code, bypass_trace_msg_t *p_trace_msg, cJSON *json, SEND_QOS_E qos, void* puback_cb);


/**
 * @brief 通过method id 找到method 的回调函数
 * @param[in]                              [method_id]
 * @return bypass_method_cb_t              [method 回调函数]
 */
bypass_method_cb_t vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_E method_id);


/**
* @brief bypass消息处理入口
* @param[in]  p_raw_json       [数据指针]
* @param[in]  msg_tag          [消息来源标签]
* @return     none
*/
void vesync_bypass_msg_handle(char *p_raw_json, uint32_t msg_tag);


/**
* @brief bypass JSON消息处理入口
* @param[in]  p_msg            [JSON数据指针]
* @param[in]  msg_tag          [消息来源标签]
*/
void vesync_bypass_json_msg_handle(cJSON *p_msg, uint32_t msg_tag);


/**
* @brief bypass 各类method id功能初始化函数
*/
void vesync_bypass_away_init(void);
void vesync_bypass_childlock_init(void);
void vesync_bypass_cooking_init(void);
void vesync_bypass_device_init(void);
void vesync_bypass_error_upload_init(void);
void vesync_bypass_ffs_setup_init(void);
void vesync_bypass_humidity_init(void);
void vesync_bypass_indicator_init(void);
void vesync_bypass_level_init(void);
void vesync_bypass_light_init(void);
void vesync_bypass_light_switch_init(void);
void vesync_bypass_nightlight_init(void);
void vesync_bypass_nightlight_brightness_init(void);
void vesync_bypass_notify_device_init(void);
void vesync_bypass_plasma_init(void);
void vesync_bypass_purifier_init(void);
void vesync_bypass_range_init(void);
void vesync_bypass_relay_init(void);
void vesync_bypass_schedule_init(void);
void vesync_bypass_timebase_init(void);
void vesync_bypass_set_device_trigger_init(void);
void vesync_bypass_set_display_init(void);
void vesync_bypass_set_temp_unit_init(void);
void vesync_bypass_switch_init(void);
void vesync_bypass_target_temp_init(void);
void vesync_bypass_temp_unit_init(void);
void vesync_bypass_timer_init(void);
void vesync_bypass_timerV2_init(void);
void vesync_bypass_upgrade_init(void);
void vesync_bypass_device_init(void);
void vesync_bypass_production_init(void);
void vesync_bypass_uart_init(void);
void vesync_bypass_developer_init(void);
void vesync_bypass_outlet_init(void);
void vesync_bypass_percent_init(void);
void vesync_bypass_lan_com_init(void);



#ifdef __cplusplus
}
#endif
#endif /* __VESYNC_BYPASS_H__ */

