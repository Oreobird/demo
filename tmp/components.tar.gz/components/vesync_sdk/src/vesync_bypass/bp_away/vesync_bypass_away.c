/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_bypass_away.c
 * @brief       Bypass Away接口定义
 * @author      Herve Lin
 * @date        2021-06-29
 */
#include <string.h>

#include "vesync_common.h"
#include "vesync_memory.h"
#include "vesync_bypass_internal.h"
#include "vesync_timebase_internal.h"


/**
 * @brief "addAwayV2" method数据解析
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  json                     [json数据指针]
 * @return BYPASS_ERR_E                 [错误码]
 */
static BYPASS_ERR_E bypass_method_add_away_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    BYPASS_ERR_E ret = BP_OK;
    cJSON* json_data = NULL;
    bypass_away_base_t away_base;

    json_data = cJSON_GetObjectItemCaseSensitive(json, "startClkSec");
    if (!cJSON_IsNumber(json_data))
    {
        ret = BP_ERR_ARG;
        goto EXIT;
    }

    away_base.start_clk_sec = (uint32_t)json_data->valueint;

    json_data = cJSON_GetObjectItemCaseSensitive(json, "endClkSec");
    if (!cJSON_IsNumber(json_data))
    {
        ret = BP_ERR_ARG;
        goto EXIT;
    }

    away_base.end_clk_sec = (uint32_t)json_data->valueint;

    json_data = cJSON_GetObjectItemCaseSensitive(json, "repeat");
    if ((!cJSON_IsNumber(json_data)) || (!vesync_timebase_is_rpt_valid(json_data->valueint)))
    {
        ret = BP_ERR_ARG;
        goto EXIT;
    }

    away_base.repeat_config = (uint8_t)json_data->valueint;

    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_ADD_AWAY_V2);
    if (method_cb)
    {
        method_cb(p_msg_ctx, (void*)&away_base);
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

EXIT:
    return ret;
}

/**
 * @brief "delAwayV2" method数据解析
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  json                     [json数据指针]
 * @return BYPASS_ERR_E                 [错误码]
 */
static BYPASS_ERR_E bypass_method_del_away_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    BYPASS_ERR_E ret = BP_OK;

    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_DEL_AWAY_V2);
    if (method_cb)
    {
        method_cb(p_msg_ctx, NULL);
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

    return ret;
}

/**
 * @brief "getAwayV2" method数据解析
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  json                     [json数据指针]
 * @return BYPASS_ERR_E                 [错误码]
 */
static BYPASS_ERR_E bypass_method_get_away_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    BYPASS_ERR_E ret = BP_OK;

    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_GET_AWAY_V2);
    if (method_cb)
    {
        method_cb(p_msg_ctx, NULL);
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

    return ret;
}

static bypass_item_data_t away_method_tbl[] = {
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_ADD_AWAY_V2, "addAwayV2", bypass_method_add_away_handle, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_DEL_AWAY_V2, "delAwayV2", bypass_method_del_away_handle, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_GET_AWAY_V2, "getAwayV2", bypass_method_get_away_handle, NULL},
};

/**
 * @brief bypass away初始化
 */
void vesync_bypass_away_init(void)
{
    for (int i = 0; i < SIZEOF_ARRAY(away_method_tbl); i++)
    {
        bypass_item_t *item = vesync_bypass_init_item(&away_method_tbl[i]);
        if (item != NULL)
        {
            vesync_bypass_add_item(item);
        }
    }
}
