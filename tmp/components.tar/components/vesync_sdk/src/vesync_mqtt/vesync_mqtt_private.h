/*
 * Copyright © Vesync Technologies Co.Ltd. 2019-2021. All rights reserved.
 *
 * This file is subject to the terms and conditions defined in
 * file 'LICENSE', which is part of this source code package.
 * Tuan PM <tuanpm at live dot com>
 */


#ifndef __VESYNC_MQTT_PRIVATE_H__
#define __VESYNC_MQTT_PRIVATE_H__


#include "vesync_mutex.h"
#include "vesync_mqtt_internal.h"


#ifdef __cplusplus
extern "C"
{
#endif


/* The following is the redirection of the interface called by this module */

#ifndef VERR_OK
#include "vesync_common.h"
#define VERR_OK SDK_OK
#define VERR_FAIL SDK_FAIL
#endif /* VERR_OK */

#ifndef MQTT_LOG
#include "vesync_log_internal.h"
#ifdef SDK_LOG
#define MQTT_LOG SDK_LOG
#else
#define MQTT_LOG(level, format, ...)
#endif /* SDK_LOG */
#endif /* MQTT_LOG */

#include "mqtt_log.h"
#ifndef MQTT_LOG_ERROR
#define MQTT_LOG_ERROR(format, ...)
#endif /* MQTT_LOG_ERROR(format, ...) */

#define VERR_UPLOAD(x, y)

/* The above is the redirection of the interface called by this module */


#if defined(CONFIG_IDF_TARGET_ESP8266)

//#define MQTT_DISABLE_API_LOCKS 1

#elif defined(CONFIG_TARGET_RTL8710CX) || defined(CONFIG_TARGET_RTL8720CF) || defined(CONFIG_IDF_TARGET_ESP32)

#ifdef MQTT_DISABLE_API_LOCKS
#undef MQTT_DISABLE_API_LOCKS
#endif

#endif /* defined(CONFIG_IDF_TARGET_ESP8266) */

#ifdef MQTT_DISABLE_API_LOCKS

#define MQTT_API_LOCK(c)
#define MQTT_API_UNLOCK(c)

#else

#ifdef MQTT_LOCK_DEBUG
#define MQTT_API_LOCK(c)                    \
do{                                         \
    MQTT_LOG(LOG_DEBUG, "try lock...\n");   \
    vesync_recursive_mutex_lock(c->api_lock);\
    MQTT_LOG(LOG_DEBUG, "lock taken\n");    \
}while(0)

#define MQTT_API_UNLOCK(c)                  \
do{                                         \
    MQTT_LOG(LOG_DEBUG, "unlock...\n");     \
    vesync_recursive_mutex_unlock(c->api_lock);   \
}while(0)

#else

#define MQTT_API_LOCK(c)          vesync_recursive_mutex_lock(c->api_lock)
#define MQTT_API_UNLOCK(c)        vesync_recursive_mutex_unlock(c->api_lock)

#endif /* MQTT_LOCK_DEBUG */

#endif /* MQTT_DISABLE_API_LOCKS */

typedef struct mqtt_state
{
    mqtt_connect_info_t *connect_info;
    uint8_t *in_buffer;
    uint8_t *out_buffer;
    int in_buffer_length;
    int out_buffer_length;
    uint32_t message_length;
    uint32_t message_length_read;
    mqtt_message_t *outbound_message;
    mqtt_connection_t mqtt_connection;
    uint16_t pending_msg_id;
    int pending_msg_type;
    int pending_publish_qos;
    int pending_msg_count;
} mqtt_state_t;

typedef struct {
    mqtt_event_callback_t event_handle;
    int task_stack;
    int task_prio;
    char *uri;
    char *host;
    char *path;
    char *scheme;
    int port;
    bool auto_reconnect;
    void *user_context;
    int network_timeout_ms;
    int refresh_connection_after_ms;
} mqtt_config_storage_t;

typedef enum {
    MQTT_STATE_ERROR = -1,
    MQTT_STATE_UNKNOWN = 0,
    MQTT_STATE_INIT,
    MQTT_STATE_CONNECTED,
    MQTT_STATE_WAIT_TIMEOUT,
} MQTT_CLIENT_STATE_E;

typedef union
{
    uint8_t event_group;
    struct
    {
        uint8_t zero : 1;
        uint8_t one : 1;
        uint8_t two : 1;
        uint8_t three : 1;
        uint8_t four : 1;
        uint8_t five : 1;
        uint8_t six : 1;
        uint8_t seven : 1;
    } map;
} event_group_map;

struct vesync_mqtt_client {
    //vesync_transport_list_handle_t transport_list;
    vesync_transport_handle_t transport;
    mqtt_config_storage_t *config;
    mqtt_state_t  mqtt_state;
    mqtt_connect_info_t connect_info;
    MQTT_CLIENT_STATE_E state;
    uint64_t refresh_connection_tick;
    uint64_t keepalive_tick;
    uint64_t reconnect_tick;
    int wait_timeout_ms;
    int auto_reconnect;
    vesync_mqtt_event_t event;
    bool run;
    bool wait_for_ping_resp;
    outbox_handle_t outbox;
    event_group_map status_bits;
#ifndef MQTT_DISABLE_API_LOCKS
    vesync_mutex_t  api_lock;
#endif
};


#ifdef __cplusplus
}
#endif


#endif /* __VESYNC_MQTT_PRIVATE_H__ */

