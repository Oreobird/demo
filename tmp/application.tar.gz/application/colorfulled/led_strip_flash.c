/**
 *  Copyright © Vesync Technologies Co.Ltd. 2019-2021. All rights reserved
 * @file        led_strip_flash.c
 * @brief       led strip data storage  function
 * @author      henrik
 * @date        2021-10-27
 */

#include <stdio.h>
#include <string.h>

#include "vesync_common.h"
#include "vesync_log.h"
#include "vesync_flash.h"
#include "vesync_device.h"
#include "vesync_klv.h"
#include "vesync_memory.h"
#include "vesync_cfg.h"


#include "led_strip.h"
#include "led_strip_flash.h"
#include "led_strip_scene.h"


/**
 * @brief 保存灯带信息
 * @param[in]  data                 [开关配置]
 * @return     int                  [成功：APP_OK， 失败：APP_FAIL]
 */
int  led_strip_save_info(ls_info_t * data)
{
    int ret = APP_FAIL;
    uint8_t *p_buf= NULL;
    uint32_t len = 0;
    uint32_t offset = 0;

    if (data->multiple.num > MAX_SEGMENT_NUM)
    {
        APP_LOG(LOG_ERROR, "multiple num is %d.\n", data->multiple.num);
        return ret ;
    }

    len = LS_INFO_FIXED_LEN + sizeof(ls_color_seg_t) * (data->multiple.num + 1);  // 计算当前信息长度

    if (NULL == (p_buf = (uint8_t *)vesync_malloc(len)))
    {
        return APP_FAIL;
    }
    memset(p_buf, 0, len);
    offset +=  vesync_klv_set(p_buf+offset, len-offset, LS_KEY_MODE, sizeof(data->mode), (uint8_t*)&data->mode);
    offset +=  vesync_klv_set(p_buf+offset, len-offset, LS_KEY_STATUS, sizeof(data->status), (uint8_t*)&data->status);
    offset +=  vesync_klv_set(p_buf+offset, len-offset, LS_KEY_BRIGHTNESS, sizeof(data->brightness), (uint8_t*)&data->brightness);
    offset +=  vesync_klv_set(p_buf+offset, len-offset, LS_KEY_SCENE_NOW, sizeof(data->scene_now), (uint8_t*)&data->scene_now);
    offset +=  vesync_klv_set(p_buf+offset, len-offset, LS_KEY_LED_NUM, sizeof(data->led_num), (uint8_t*)&data->led_num);
    offset +=  vesync_klv_set(p_buf+offset, len-offset, LS_KEY_LAST_ID, sizeof(data->last_id), (uint8_t*)&data->last_id);
    offset +=  vesync_klv_set(p_buf+offset, len-offset, LS_KEY_COLOR, sizeof(data->color), (uint8_t*)&data->color);
    offset +=  vesync_klv_set(p_buf+offset, len-offset, LS_KEY_MULTI_NUM, sizeof(data->multiple.num), (uint8_t*)&data->multiple.num);
    if ((NULL != data->multiple.color)&&(0 < data->multiple.num))
    {
        offset +=  vesync_klv_set(p_buf+offset, len-offset, LS_KEY_MULTI_COLOR, sizeof(ls_color_seg_t)*(data->multiple.num),\
                                 (uint8_t*)data->multiple.color);
    }


    ret = vhal_flash_write(PARTITION_CFG, LS_USER_INFO_KEY_DATA,p_buf,offset);
    APP_LOG(LOG_DEBUG, "mode:%d status:%d brightness: %d led_num: %d.\n", data->mode, data->status, data->brightness, data->led_num);
    APP_LOG(LOG_DEBUG, "scene_id:%d last_id:%d mult_num: %d.\n", data->scene_now, data->last_id, data->multiple.num);

    vesync_free(p_buf);

    if (VHAL_OK != ret)
    {
        APP_LOG(LOG_ERROR, "Write data fail, ret = %d.\n", ret);
        return APP_FAIL;
    }

    return APP_OK;
}

/**
 * @brief 从flash中读取灯带信息到内存
 * @param[out] p_data               [开关配置]
 * @return     int                  [成功：APP_OK， 失败：APP_FAIL]
 */
int  led_strip_read_info(ls_info_t *p_data)
{
    int ret = APP_FAIL;
    uint32_t len = 0;   // 分段15+单色HSV+信息固定字节数
    uint8_t *p_buf= NULL;

    if (NULL == p_data)
    {
        APP_LOG(LOG_ERROR, "Input illegal!\n");
        return APP_FAIL;
    }

    len = LS_INFO_FIXED_LEN + sizeof(ls_color_seg_t) * (MAX_SEGMENT_NUM + 1);
     if(NULL == (p_buf = (uint8_t *)vesync_malloc(len)))
    {
        return APP_FAIL;
    }


    if (VHAL_OK != vhal_flash_read(PARTITION_CFG, LS_USER_INFO_KEY_DATA, p_buf, &len))
    {
        APP_LOG(LOG_ERROR, "Read ledstrip data fail, ret = %d.\n", ret);
        vesync_free(p_buf);
        return APP_FAIL;
    }

    vesync_klv_get(p_buf, len, LS_KEY_MODE, sizeof(p_data->mode), (uint8_t*)&p_data->mode);
    vesync_klv_get(p_buf, len, LS_KEY_STATUS, sizeof(p_data->status), (uint8_t*)&p_data->status);
    vesync_klv_get(p_buf, len, LS_KEY_BRIGHTNESS, sizeof(p_data->brightness), (uint8_t*)&p_data->brightness);
    vesync_klv_get(p_buf, len, LS_KEY_SCENE_NOW, sizeof(p_data->scene_now), (uint8_t*)&p_data->scene_now);
    vesync_klv_get(p_buf, len, LS_KEY_LED_NUM, sizeof(p_data->led_num), (uint8_t*)&p_data->led_num);
    vesync_klv_get(p_buf, len, LS_KEY_LAST_ID, sizeof(p_data->last_id), (uint8_t*)&p_data->last_id);
    vesync_klv_get(p_buf, len, LS_KEY_COLOR, sizeof(p_data->color), (uint8_t*)&p_data->color);
    vesync_klv_get(p_buf, len, LS_KEY_MULTI_NUM, sizeof(p_data->multiple.num), (uint8_t*)&p_data->multiple.num);
    if ((0 < p_data->multiple.num)&&(p_data->multiple.num <= MAX_SEGMENT_NUM)&&(NULL != p_data->multiple.color))
    {
        vesync_klv_get(p_buf, len, LS_KEY_MULTI_COLOR, sizeof(ls_color_seg_t)*p_data->multiple.num,\
                                 (uint8_t*)p_data->multiple.color);
    }
    else
    {
        p_data->multiple.num = 0 ;
    }

    APP_LOG(LOG_DEBUG, "mode:%d status:%d brightness: %d led_num: %d.\n", p_data->mode, p_data->status, p_data->brightness, p_data->led_num);
    APP_LOG(LOG_DEBUG, "scene_id:%d last_id:%d mult_num: %d.\n", p_data->scene_now, p_data->last_id, p_data->multiple.num);
    vesync_free(p_buf);

    return APP_OK;
}

/**
 * @brief 清除灯带信息
 * @return int          [成功：APP_OK， 失败：APP_FAIL]
 */
int led_strip_clear_info(void)
{
    int ret = APP_FAIL;

    ret = vhal_flash_erase_key(PARTITION_CFG, LS_USER_INFO_KEY_DATA);
    if (VHAL_OK != ret)
    {
        APP_LOG(LOG_ERROR, "Clear ledstrip data fail\n");
        return APP_FAIL;
    }

    return APP_OK;
}

/**
 * @brief 保存场景信息
 * @param[in]  p_data                   [场景信息]
 * @param[in]  num                      [场景数量]
 * @return     int                      [成功：APP_OK， 失败：APP_FAIL]
 */
int led_strip_save_scene(ls_scene_t * p_data, uint8_t num)
{
    uint8_t color_size = sizeof(ls_color_seg_t);
    uint8_t *p_color = NULL;
    uint8_t *p_buf= NULL;
    uint8_t segment_num[SCENE_CUSTOM_MAX_NUM];
    uint8_t segment_type[SCENE_CUSTOM_MAX_NUM];
    uint16_t scene_id[SCENE_CUSTOM_MAX_NUM];
    uint16_t temp_len = 0;
    uint16_t temp_count = 0;
    uint32_t len = 0;   // 场景固定字节数+场景数*(最大分段数*hsv结构体字节数+(id字节数+分段数num字节数))
    uint32_t color_len = 0;
    uint32_t offset = 0;
    int ret = APP_FAIL;

    if (NULL == p_data)
    {
        APP_LOG(LOG_ERROR, "input illegal!\n");
        return APP_FAIL;
    }

    if (0 == num)
    {
        return led_strip_clear_scene();
    }

    if(NULL == (p_color = (uint8_t *)vesync_malloc(color_size * MAX_SEGMENT_NUM *num)))
    {
        APP_LOG(LOG_ERROR, "malloc error!\n");
        return APP_FAIL;
    }

    APP_LOG(LOG_DEBUG, "scene_num:%d \n", num);
    for (int j = SCENE_CUSTOM_MAX_NUM -1 ; j >= (SCENE_CUSTOM_MAX_NUM - num); j--)
    {
        if ((NULL != p_data[j].color)&&(0 < p_data[j].id))
        {
            segment_num[temp_count] = p_data[j].num;
            segment_type[temp_count] = p_data[j].type;
            temp_len = p_data[j].num * color_size;
            scene_id[temp_count] = p_data[j].id;
            APP_LOG(LOG_DEBUG, "type:%d id: %d seg_num: %d.\n", p_data[j].type, p_data[j].id, p_data[j].num);
            temp_count++;
            if (temp_count <= num)   // 实际场景数与传入场景数不符，避免越界
            {
                memcpy(p_color + color_len, (uint8_t *)p_data[j].color, temp_len);
                color_len += temp_len;
            }
            else
            {
                APP_LOG(LOG_ERROR, "scene number illegal!\n");
            }
        }
    }

    len = LS_SCENE_FIXED_LEN + (color_size * MAX_SEGMENT_NUM + 3) * num ;
    if(NULL == (p_buf = (uint8_t *)vesync_malloc(len)))
    {
        APP_LOG(LOG_ERROR, "malloc error!\n");
        vesync_free(p_color);
        return APP_FAIL;
    }

    temp_count = num; // 可能实际场景数与传入场景数不符，按照传入的场景数进行保存
    offset +=  vesync_klv_set(p_buf+offset, len-offset, LS_KEY_SCENE_NUM, 1, (uint8_t*)&temp_count);
    offset +=  vesync_klv_set(p_buf+offset, len-offset, LS_KEY_SCENE_ID, temp_count * 2, (uint8_t*)scene_id);
    offset +=  vesync_klv_set(p_buf+offset, len-offset, LS_KEY_SEG_NUM, temp_count , segment_num);
    offset +=  vesync_klv_set(p_buf+offset, len-offset, LS_KEY_SEG_TYPE, temp_count , segment_type);
    offset +=  vesync_klv_set(p_buf+offset, len-offset, LS_KEY_SEG_COLOR, color_len, p_color);

    ret = vhal_flash_write(PARTITION_CFG, LS_SCENE_KEY,p_buf,offset);
    vesync_free(p_buf);
    vesync_free(p_color);

    if (VHAL_OK != ret)
    {
        APP_LOG(LOG_ERROR, "Write data fail, ret = %d.\n", ret);
        return APP_FAIL;
    }

    return APP_OK;
}

/**
 * @brief 从flash中读取场景信息到内存
 * @param[in]  p_data                   [场景信息]
 * @param[out]  num                     [场景数量]
 * @return     int                      [成功：APP_OK， 失败：APP_FAIL]
 */
int led_strip_read_scene(ls_scene_t         * p_data, uint8_t * p_num)
{
    int ret = APP_FAIL;
    uint32_t len = 0;   // 场景固定字节数+最大场景数*最大分段数*hsv结构体字节数+最大场景数*（id字节数+分段数num字节数）
    uint32_t color_len = 0;
    uint32_t offset = 0;
    uint16_t temp_len = 0;
    uint8_t count = 0;
    uint8_t *p_color = NULL;
    uint8_t *p_buf= NULL;
    uint8_t segment_num[SCENE_CUSTOM_MAX_NUM];
    uint8_t segment_type[SCENE_CUSTOM_MAX_NUM];
    uint16_t scene_id[SCENE_CUSTOM_MAX_NUM];

    if ((NULL == p_data)||(NULL == p_num))
    {
        APP_LOG(LOG_ERROR, "Input illegal!\n");
        return APP_FAIL;
    }

    memset(segment_num, 0, SCENE_CUSTOM_MAX_NUM);
    memset(segment_type, 0, SCENE_CUSTOM_MAX_NUM);
    memset(scene_id, 0, SCENE_CUSTOM_MAX_NUM*2);
    len = LS_SCENE_FIXED_LEN + sizeof(ls_color_seg_t) * MAX_SEGMENT_NUM * SCENE_CUSTOM_MAX_NUM ;
    len = len + SCENE_CUSTOM_MAX_NUM * (1 + 2);   // id 两个字节， 分段数量一个字节
     if(NULL == (p_buf = (uint8_t *)vesync_malloc(len)))
    {
        APP_LOG(LOG_ERROR, "malloc error.\n");
        return APP_FAIL;
    }


    if (VHAL_OK != vhal_flash_read(PARTITION_CFG, LS_SCENE_KEY, p_buf, &len))
    {
        APP_LOG(LOG_ERROR, "Read ledstrip data fail, ret = %d.\n", ret);
        vesync_free(p_buf);
        return APP_FAIL;
    }

    vesync_klv_get(p_buf, len, LS_KEY_SCENE_NUM, 1, p_num);
    if ((*p_num > SCENE_CUSTOM_MAX_NUM) ||(0 == *p_num))  // 若flash 数据错误, 原有数据丢弃
    {
        APP_LOG(LOG_ERROR, "flash data error %d.\n", *p_num);
        *p_num = 0;
        vesync_free(p_buf);
        return APP_OK;
    }

    vesync_klv_get(p_buf, len, LS_KEY_SCENE_ID, 2*SCENE_CUSTOM_MAX_NUM, (uint8_t*)scene_id);
    vesync_klv_get(p_buf, len, LS_KEY_SEG_NUM, SCENE_CUSTOM_MAX_NUM, segment_num);
    vesync_klv_get(p_buf, len, LS_KEY_SEG_TYPE, SCENE_CUSTOM_MAX_NUM, segment_type);

    APP_LOG(LOG_DEBUG, "scene_num:%d .\n", *p_num);
    for (int i = SCENE_CUSTOM_MAX_NUM -1 ; i >= (SCENE_CUSTOM_MAX_NUM - *p_num); i-- )
    {
        segment_num[count] = segment_num[count] % (MAX_SEGMENT_NUM + 1);   // 避免数据出错时,内存操作异常出现复位
        temp_len = segment_num[count]*sizeof(ls_color_seg_t);
        color_len += temp_len;
        APP_LOG(LOG_DEBUG, "segment_num:%d %d, id:%d .\n", count, segment_num[count], scene_id[count]);
        if (NULL != p_data[i].color)  // 若之前该指针非空，则需要释放掉之前的空间
        {
            vesync_free(p_data[i].color);
        }

        // 每个场景必须独立申请分段颜色空间，避免删除场景时，释放空间时出现BUG
        if(NULL == (p_data[i].color = (ls_color_seg_t *)vesync_malloc(temp_len)))
        {
            APP_LOG(LOG_ERROR, "malloc faild\n");
            vesync_free(p_buf);
            for (int j = SCENE_CUSTOM_MAX_NUM -1 ; j > i; j--)
            {
                vesync_free(p_data[j].color);
            }
            return APP_FAIL;
        }

        p_data[i].id = scene_id[count];
        p_data[i].num = segment_num[count];
        p_data[i].type= segment_type[count];
        APP_LOG(LOG_DEBUG, "type:%d id: %d seg_num: %d.\n", p_data[i].type, p_data[i].id, p_data[i].num);
        count++;
    }

    if(NULL == (p_color = (uint8_t *)vesync_malloc(color_len)))
    {
        APP_LOG(LOG_ERROR, "malloc faild\n");
        vesync_free(p_buf);
        for (int j = SCENE_CUSTOM_MAX_NUM -1 ; j >= (SCENE_CUSTOM_MAX_NUM - *p_num); j--)
        {
            vesync_free(p_data[j].color);
        }
        return APP_FAIL;
    }

    vesync_klv_get(p_buf, len, LS_KEY_SEG_COLOR, color_len, p_color);
    count = 0;
    for (int j = SCENE_CUSTOM_MAX_NUM -1 ; j >= (SCENE_CUSTOM_MAX_NUM - *p_num); j--)
    {
        temp_len = segment_num[count]*sizeof(ls_color_seg_t);
        memcpy((uint8_t *)p_data[j].color, p_color+offset, temp_len);
        offset += temp_len;
        count++;
    }

    vesync_free(p_buf);
    vesync_free(p_color);
    return APP_OK;
}

/**
 * @brief 清除场景信息
 * @return int          [成功：APP_OK， 失败：APP_FAIL]
 */
int led_strip_clear_scene(void)
{
    int ret = APP_FAIL;

    ret = vhal_flash_erase_key(PARTITION_CFG, LS_SCENE_KEY);
    if (VHAL_OK != ret)
    {
        APP_LOG(LOG_ERROR, "Clear ledstrip data fail\n");
        return APP_FAIL;
    }

    return APP_OK;
}



