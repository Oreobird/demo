/**
* Copyright © Vesync Technologies Co.Ltd. 2022. All rights reserved
* @file         segment.c
* @brief        分段场景注册
* @author       Joshua
* @date         2022-2-11
*/

#include <string.h>
#include <stdint.h>
#include "vesync_common.h"
#include "vesync_memory.h"
#include "vesync_log.h"
#include "segment.h"


int segment_on_light_scene_reg(light_scene_t *light_scene)
{
    VCOM_NULL_PARAM_CHK(light_scene, return APP_FAIL);

    scene_t *thiz = (scene_t *) vesync_malloc(sizeof(scene_t) + sizeof(light_scene_t));
    if (thiz == NULL)
    {
        APP_LOG(LOG_ERROR, "segment on light scene reg fail\n");
        return APP_FAIL;
    }

    memset(thiz, 0, sizeof(scene_t) + sizeof(light_scene_t));

    thiz->type = SCENE_SEGMENT;
    thiz->id = SCENE_COLOR_ON;

    light_scene_t *ctx = (light_scene_t *)thiz->ctx;
    memcpy(ctx, light_scene, sizeof(light_scene_t));

    scene_registry_add(thiz);

    return APP_OK;
}

int segment_on_light_scene_unreg(int id)
{
    return scene_registry_del(SCENE_ONOFF, id);
}


int segment_off_light_scene_reg(light_scene_t *light_scene)
{
    VCOM_NULL_PARAM_CHK(light_scene, return APP_FAIL);

    scene_t *thiz = (scene_t *) vesync_malloc(sizeof(scene_t) + sizeof(light_scene_t));
    if (thiz == NULL)
    {
        APP_LOG(LOG_ERROR, "segment off light scene reg fail\n");
        return APP_FAIL;
    }

    memset(thiz, 0, sizeof(scene_t) + sizeof(light_scene_t));

    thiz->type = SCENE_SEGMENT;
    thiz->id = SCENE_COLOR_OFF;

    light_scene_t *ctx = (light_scene_t *)thiz->ctx;
    memcpy(ctx, light_scene, sizeof(light_scene_t));

    scene_registry_add(thiz);

    return APP_OK;
}

int segment_off_light_scene_unreg(int id)
{
    return scene_registry_del(SCENE_SEGMENT, id);
}


