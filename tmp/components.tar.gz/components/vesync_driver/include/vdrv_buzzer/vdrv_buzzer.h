/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
 * @file        vdrv_buzzer.c
 * @brief       蜂鸣器驱动
 * @date        2021-09-13
 */

#ifndef __VDRV_BUZZER_H__
#define __VDRV_BUZZER_H__

#include <stdint.h>
#include <stdlib.h>
#include <string.h>


#ifdef __cplusplus
extern "C"
{
#endif

/**
 * @brief 改变蜂鸣器的频率
 * @param[in]  freq_hz          [频率值]
 */
void vdrv_buzzer_freq_change(uint32_t freq_hz);


/**
 * @brief 开启蜂鸣器
 */
void vdrv_buzzer_on(void);


/**
 * @brief 关闭蜂鸣器
 */
void vdrv_buzzer_off(void);


/**
 * @brief 初始化蜂鸣器
 */
void vdrv_buzzer_init(void);


#ifdef __cplusplus
}
#endif

#endif /* __VDRV_BUZZER_H__ */

