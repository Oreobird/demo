/**
 *  Copyright © Vesync Technologies Co.Ltd. 2019-2021. All rights reserved.
 * @file        vesync_tl_payload_parse.c
 * @brief       数据帧解析和封装
 * @author      zhenlang & Herve
 * @date        2022-01-13
 */

#include <stdint.h>
#include <string.h>

#include "vesync_tl_payload_parse.h"
#include "vesync_log_internal.h"
#include "vesync_utils.h"
#include "vesync_common.h"


int32_t vesync_tl_payload_encode(uint16_t op, uint8_t sc, uint8_t *p_pl, uint16_t pl_len, uint8_t *p_out, uint16_t *p_out_len)
{
    uint16_t out_len = 0;
    tl_payload_info_t *p_paylaod = NULL;

    if ((NULL == p_pl) && (0 != pl_len))
    {
        return SDK_FAIL;
    }
    if ((NULL == p_out) || (NULL == p_out_len))
    {
        return SDK_FAIL;
    }

    out_len = pl_len + TL_PAYLOAD_PROTOCOL_HEAD_LEN;
    if (*p_out_len < out_len)
    {
        return SDK_FAIL;
    }

    p_paylaod = (tl_payload_info_t *)p_out;
    if (NULL != p_pl)
    {
        memmove(p_paylaod->payload_data, p_pl, pl_len);
        *p_out_len = out_len;
    }
    else
    {
        *p_out_len = 0;
    }
    // 头部信息在p_pl复制之后，防止输入输出在同一块内存时被覆盖
    p_paylaod->version = TL_PAYLOAD_PROTOCOL_VERSION;
    p_paylaod->op_code = vesync_htole16(op);
    p_paylaod->status_code = sc;
    return SDK_OK;
}

uint8_t *vesync_tl_payload_decode(uint8_t *p_in, uint16_t in_len, uint16_t *p_op, uint8_t *p_sc, uint16_t *p_pl_len)
{
    if (NULL == p_in)
    {
        return NULL;
    }

    if (in_len < TL_PAYLOAD_PROTOCOL_HEAD_LEN)
    {
        SDK_LOG(LOG_ERROR, "invalid tl_payload_len:%d\n", in_len);
        return NULL;
    }

    tl_payload_info_t *p_tl_pl = (tl_payload_info_t *)p_in;
    if (p_tl_pl->version > TL_PAYLOAD_PROTOCOL_VERSION)
    {
        SDK_LOG(LOG_ERROR, "invalid version:0x%02x\n", p_tl_pl->version);
        return NULL;
    }

    *p_op = vesync_le16toh(p_tl_pl->op_code);
    *p_sc = p_tl_pl->status_code;
    *p_pl_len = in_len - TL_PAYLOAD_PROTOCOL_HEAD_LEN;
    return p_tl_pl->payload_data;
}
