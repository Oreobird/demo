/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        outlet_button.c
 * @brief       outlet button文件
 * @author      CharlesMei
 * @date        2021-06-22
 */


#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <stdio.h>

#include "vhal_gpio.h"

#include "vesync_common.h"
#include "vesync_log.h"
#include "vesync_task.h"
#include "vesync_production.h"

#include "outlet.h"
#include "outlet_report.h"
#include "outlet_production.h"
#include "outlet_button.h"
#include "outlet_board.h"

// 按键消抖，按键计数最大值
#define KEY_SCAN_VALUE_MAX_NUM      (5)

// 判断松开或按下按键的阈值
#define KEY_RELEASED_THRESHOLD      (1)
#define KEY_PRESSED_THRESHOLD       (KEY_SCAN_VALUE_MAX_NUM - KEY_RELEASED_THRESHOLD)

// 触发产测所需短按次数
#define PRODUCTION_KEY_PRESSED_NUM      (5)
// 触发产测的全部短按所在的限制时间
#define PRODUCTION_KEY_PRESSED_PERIOD   (2000)
// 上电后触发产测的限制时间
#define PRODUCTION_KEY_EFFECT_TIME_MS   (10 * 1000)

// 按键扫描任务的参数
#define OUTLET_BUTTON_TASK_NAME       ("button_task")
#define OUTLET_BUTTON_TASK_PRIO       TASK_PRIORITY_HIGH


// key_status_t成员函数指针，具体见key_status_t
typedef void(*key_set_scan_value_t)(int8_t scan_value);

/**
 * @brief 按键状态
 */
typedef enum
{
    KEY_RELEASED_1S_MORE = 0,
    KEY_PRESSED_1S_LESS,
    KEY_PRESSED_1S_TO_5S,
    KEY_PRESSED_5S_TO_15S,
    KEY_PRESSED_15S_MORE,
    KEY_RELEASED_1S_LESS,
} KEY_STATE_E;

/**
 * @brief 按键参数
 */
typedef struct
{
    uint64_t key_upturn_ts;
    //uint32_t id;
    key_set_scan_value_t key_set_scan_value;
    KEY_STATE_E key_status;
    int8_t key_scan_value[KEY_SCAN_VALUE_MAX_NUM];
    uint8_t key_scan_value_index;
    uint8_t key_pressed_num;
} key_status_t;

static bool s_task_run = false;     // 按键扫描任务运行标志

static key_status_t s_switch_key;   // 开关按键参数


/**
 * @brief 设置扫描到的瞬时按键值
 * @param[in]   scan_value      [瞬时按键值]
 */
static void button_key_set_scan_value(int8_t scan_value)
{
    uint64_t new_scan_ts = vesync_task_get_tick_ms();

    if (KEY_SCAN_VALUE_MAX_NUM == ++(s_switch_key.key_scan_value_index))
    {
        (s_switch_key.key_scan_value_index) = 0;
    }
    if (scan_value == s_switch_key.key_scan_value[s_switch_key.key_scan_value_index])
    {
        if (1 == scan_value)    // 高电平
        {
            s_switch_key.key_scan_value[(s_switch_key.key_scan_value_index)] = 0;
            --(s_switch_key.key_pressed_num);
            if(KEY_RELEASED_THRESHOLD == (s_switch_key.key_pressed_num))
            {
                s_switch_key.key_status = KEY_RELEASED_1S_LESS;
                s_switch_key.key_upturn_ts = new_scan_ts;
                return;
            }
        }
        else                    // 低电平
        {
            s_switch_key.key_scan_value[(s_switch_key.key_scan_value_index)] = 1;
            ++(s_switch_key.key_pressed_num);
            if(KEY_PRESSED_THRESHOLD == (s_switch_key.key_pressed_num))
            {
                s_switch_key.key_status = KEY_PRESSED_1S_LESS;
                s_switch_key.key_upturn_ts = new_scan_ts;
                return;
            }
        }
    }

    switch (s_switch_key.key_status)
    {
        case KEY_RELEASED_1S_LESS:
            if (new_scan_ts - s_switch_key.key_upturn_ts > 1000)  // 松开按键超过1s
            {
                s_switch_key.key_status = KEY_RELEASED_1S_MORE;
            }
            break;
        case KEY_PRESSED_1S_LESS:
        case KEY_PRESSED_1S_TO_5S:
        case KEY_PRESSED_5S_TO_15S:
            if (new_scan_ts - s_switch_key.key_upturn_ts > 15000)  // 按下按键超过15s
            {
                s_switch_key.key_status = KEY_PRESSED_15S_MORE;
                break;
            }
            else if (new_scan_ts - s_switch_key.key_upturn_ts > 5000)  // 按下按键超过5s
            {
                s_switch_key.key_status = KEY_PRESSED_5S_TO_15S;
                break;
            }
            else if (new_scan_ts - s_switch_key.key_upturn_ts > 1000)  // 按下按键超过1s
            {
                s_switch_key.key_status = KEY_PRESSED_1S_TO_5S;
                break;
            }
            break;
        case KEY_RELEASED_1S_MORE:
        case KEY_PRESSED_15S_MORE:
        default:
            break;
    }
}

/**
 * @brief 计数短按次数
 * @param[in]   reset           [true: 清零计数; false: 计数]
 */
static void handle_pressed_key_count(bool reset)
{
    static uint16_t short_pressed_cnt = 0;
    static uint64_t first_short_pressed_ts = 0;

    if (first_short_pressed_ts > PRODUCTION_KEY_EFFECT_TIME_MS)
    {
        return;
    }

    if (reset)
    {
        short_pressed_cnt = 0;
    }
    else
    {
        if (0 == short_pressed_cnt)
        {
            ++short_pressed_cnt;
            first_short_pressed_ts = vesync_task_get_tick_ms();
        }
        else if (vesync_task_get_tick_ms() - first_short_pressed_ts < PRODUCTION_KEY_PRESSED_PERIOD)
        {
            if (short_pressed_cnt < PRODUCTION_KEY_PRESSED_NUM)
            {
                ++short_pressed_cnt;
            }
            else if (PRODUCTION_KEY_PRESSED_NUM == short_pressed_cnt)
            {
                APP_LOG(LOG_INFO, "Switch button trigger production test.\r\n");
                outlet_ev_t ev;
                ev.act_src = OUTLET_ACT_SRC_BTN;
                ev.id = OUTLET_EV_PRODUCTION;
                memset(ev.rsn, 0, sizeof(ev.rsn));
                outlet_app_task_notify(&ev);
            }
            else
            {
                APP_LOG(LOG_WARN,"don't press again! wait 1s for short pressed count to be reset.\r\n");
            }
        }
        else
        {
            short_pressed_cnt = 1;
            first_short_pressed_ts = vesync_task_get_tick_ms();
        }
        APP_LOG(LOG_DEBUG,"Short press button(cnt = %d).\r\n", short_pressed_cnt);
    }
}

/**
 * @brief 按键扫描任务
 */
static void switch_button_task(void *args)
{
    KEY_STATE_E last_key_status;
    outlet_ev_t ev;
    PRODUCTION_STATUS_E pro_status;
    static uint8_t s_pcba_flag = 1;

    s_task_run = true;

    while (s_task_run)
    {
        last_key_status = s_switch_key.key_status;
        s_switch_key.key_set_scan_value(vhal_gpio_get_output(OUTLET_BUTTON_GPIO_NUM));
        if (PRODUCTION_EXIT != (pro_status = vesync_production_get_status()) &&
            PRODUCTION_TEST_PASS != pro_status)
        {
            if (PRODUCTION_WIFI_TEST == pro_status && s_pcba_flag &&
                KEY_RELEASED_1S_LESS == s_switch_key.key_status &&
                KEY_PRESSED_1S_LESS == last_key_status)
            {
                s_pcba_flag = 0;
                ev.id = OUTLET_EV_PCBA_TEST;
                ev.act_src = OUTLET_ACT_SRC_UNKNOW;
                memset(ev.rsn, 0, sizeof(ev.rsn));
                outlet_app_task_notify(&ev);
            }
        }
        else if (last_key_status != s_switch_key.key_status)
        {
            switch (s_switch_key.key_status)
            {
                case KEY_RELEASED_1S_MORE:
                    handle_pressed_key_count(true);
                    break;
                case KEY_PRESSED_5S_TO_15S:
                    ev.act_src = OUTLET_ACT_SRC_BTN;
                    ev.id = OUTLET_EV_BEFORE_NETCFG;
                    memset(ev.rsn, 0, sizeof(ev.rsn));
                    outlet_app_task_notify(&ev);
                    break;
                case KEY_PRESSED_15S_MORE:
                    APP_LOG(LOG_INFO, "Switch button trigger factory reset.\r\n");
                    ev.act_src = OUTLET_ACT_SRC_BTN;
                    ev.id = OUTLET_EV_RESET;
                    memset(ev.rsn, 0, sizeof(ev.rsn));
                    outlet_app_task_notify(&ev);
                    break;
                case KEY_RELEASED_1S_LESS:
                    switch (last_key_status)
                    {
                        case KEY_PRESSED_1S_LESS:
                        {
                            outlet_set_switch_toggle();

                            ev.act_src = OUTLET_ACT_SRC_BTN;
                            ev.id = OUTLET_EV_TOGGLE;
                            snprintf(ev.rsn, sizeof(ev.rsn), "%s", STAT_CHG_RSN_BTN_STR);
                            outlet_app_task_notify(&ev);
                            handle_pressed_key_count(false);
                            break;
                        }
                        case KEY_PRESSED_5S_TO_15S:
                            APP_LOG(LOG_INFO, "Switch button trigger config net.\n");
                            ev.act_src = OUTLET_ACT_SRC_BTN;
                            ev.id = OUTLET_EV_NETCFG;
                            memset(ev.rsn, 0, sizeof(ev.rsn));
                            outlet_app_task_notify(&ev);
                            break;
                        case KEY_PRESSED_1S_TO_5S:
                        case KEY_PRESSED_15S_MORE:
                            handle_pressed_key_count(true);
                            break;
                        default:
                            break;
                    }
                case KEY_PRESSED_1S_LESS:
                case KEY_PRESSED_1S_TO_5S:
                default:
                    break;
            }
        }

        vesync_sleep(10);        // 按键扫描10ms一次
    }
    APP_LOG(LOG_INFO, "button task exit.\r\n");
}

/**
 * @brief 产测时，强制退出按键扫描任务
 */
void outlet_button_task_exit(void)
{
    s_task_run = false;
}

/**
 * @brief outlet button初始化
 */
void outlet_button_init(void)
{
    memset(&s_switch_key, 0, sizeof(s_switch_key));
    s_switch_key.key_set_scan_value = button_key_set_scan_value;
    if (VOS_OK != vesync_task_new(OUTLET_BUTTON_TASK_NAME, NULL,
                    switch_button_task,
                    NULL,
                    OUTLET_BUTTON_TASK_STACKSIZE,
                    OUTLET_BUTTON_TASK_PRIO, NULL))
    {
        APP_LOG(LOG_ERROR, "button task create fail!!!\r\n");
    }
    APP_LOG(LOG_INFO, "button init done.\r\n");
}

