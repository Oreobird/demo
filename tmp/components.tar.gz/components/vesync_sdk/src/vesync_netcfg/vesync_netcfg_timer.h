/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_netcfg_timer.h
 * @brief       配网模块的定时器
 * @author      Louis
 * @date        2021-05-21
 */

#ifndef __VESYNC_NETCFG_TIMER_H__
#define __VESYNC_NETCFG_TIMER_H__


#ifdef __cplusplus
extern "C" {
#endif

// 配网定时最大时间
#define NETCFG_TIMER_MAIN_PERIOD           (10*60*1000)
// 各步骤超时时间：连接WIFI，获取IP，连接服务器
#define NETCFG_TIMER_STEP_PERIOD           (60*1000)
// 重新启动APN配网的等待时间
#define NETCFG_TIMER_RESTART_PERIOD        (10000)
// 定期上报配网状态log的时间间隔
#define NETCFG_TIMER_NETLOG_PERIOD         (5000)

/**
 * @brief 定时器初始化
 * @return    int       [初始化成功与否]
 */
int netcfg_timer_init(void);

/**
 * @brief 定时器销毁
 */
void netcfg_timer_deinit(void);

/**
 * @brief 添加配网超时定时器
 */
void netcfg_add_main_timer(void);

/**
 * @brief 删除配网超时定时器
 */
void netcfg_del_main_timer(void);

/**
 * @brief 添加配网步骤超时定时器
 */
void netcfg_add_step_timer(void);

/**
 * @brief 删除配网步骤超时定时器
 */
void netcfg_del_step_timer(void);

/**
 * @brief 添加配网重启定时器
 */
void netcfg_add_restart_timer(void);

/**
 * @brief 删除配网重启定时器
 */
void netcfg_del_restart_timer(void);

/**
 * @brief 添加配网log上报定时器
 */
void netcfg_add_netlog_timer(void);

/**
 * @brief 删除配网log上报定时器
 */
void netcfg_del_netlog_timer(void);

/**
 * @brief 处理已经超时的定时器
 * @return    uint64_t      [下一个即将超时定时器的时间ms]
 */
uint64_t netcfg_process_expired_timer(void);


#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_NETCFG_TIMER_H__ */

