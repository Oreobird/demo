/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_bypass_target_temp.c
 * @brief       bypass处理接口
 * @date        2021-05-17
 */

#include <string.h>
#include "vesync_common.h"
#include "vesync_memory.h"

#include "vesync_bypass_internal.h"

/**
 * @brief 设置目标温度
 * @param p_trace_msg trace message
 * @param json数据指针
 * @return BYPASS_ERR_E
 */
static BYPASS_ERR_E bypass_method_set_target_temp_handle(bypass_trace_msg_t *p_trace_msg, cJSON *json)
{
    BYPASS_ERR_E ret = BP_OK;

    if ((NULL == json)||(NULL == p_trace_msg))    return BP_ERROR;

    bypass_target_temp_t *pTarget_temp = (bypass_target_temp_t *)vesync_malloc(sizeof(bypass_target_temp_t));
    if (NULL == pTarget_temp)
    {
        return BP_ERR_NOMEM;
    }

    memset(pTarget_temp, 0, sizeof(bypass_target_temp_t));

    cJSON* json_data = cJSON_GetObjectItemCaseSensitive(json, "cookTemp");    //烹饪温度
    if (cJSON_IsNumber(json_data))
    {
        pTarget_temp->target_temp = json_data->valueint & 0xFFFF;
    }
    else
    {
        json_data = cJSON_GetObjectItemCaseSensitive(json, "targetTemp");
        if (cJSON_IsNumber(json_data))
        {
            pTarget_temp->target_temp = json_data->valueint & 0xFFFF;
        }
        else
        {
            ret = BP_ERR_ARG;
            goto _exit;
        }
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "id");
    if (cJSON_IsNumber(json_data))
    {
        pTarget_temp->id = json_data->valueint;
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "startTimestamp");
    if (cJSON_IsNumber(json_data))
    {
        pTarget_temp->start_ts = json_data->valueint;
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_SET_TGT_TEMP);
    if (method_cb)
    {
        method_cb(p_trace_msg, (void*)pTarget_temp, sizeof(bypass_target_temp_t));
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

_exit:
    vesync_free(pTarget_temp);
    return ret;
}

/**
 * @brief 清除目标温度
 * @param p_trace_msg trace message
 * @param json数据指针
 * @return BYPASS_ERR_E
 */
static BYPASS_ERR_E bypass_method_clear_target_temp_handle(bypass_trace_msg_t *p_trace_msg, cJSON *json)
{
    if ((NULL == json)||(NULL == p_trace_msg))    return BP_ERROR;

    int *pId = (int *)vesync_malloc(sizeof(int));
    if (NULL == pId)
    {
        return BP_ERR_NOMEM;
    }

    BYPASS_ERR_E ret = BP_OK;

    cJSON *json_data = cJSON_GetObjectItemCaseSensitive(json, "id");
    if (cJSON_IsNumber(json_data))
    {
        *pId = json_data->valueint;
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_CLEAR_TGT_TEMP);
    if (method_cb)
    {
        method_cb(p_trace_msg, (void*)pId, sizeof(int));
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

_exit:
    vesync_free(pId);
    return ret;
}

static bypass_item_data_t target_temp_method_tbl[] = {
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_SET_TGT_TEMP, "setTargetTemp", bypass_method_set_target_temp_handle, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_CLEAR_TGT_TEMP,  "clearTargetTemp", bypass_method_clear_target_temp_handle, NULL},
};

void vesync_bypass_target_temp_init(void)
{
    for (int i = 0; i < SIZEOF_ARRAY(target_temp_method_tbl); i++)
    {
        bypass_item_t *item = vesync_bypass_init_item(&target_temp_method_tbl[i]);
        if (item != NULL)
        {
            vesync_bypass_add_item(item);
        }
    }
}
