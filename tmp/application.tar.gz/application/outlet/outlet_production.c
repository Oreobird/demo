/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
 * @file        outlet_production.c
 * @brief       产测过程和状态处理
 * @author      Joshua
 * @date        2021-06-20
 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "vesync_timer.h"
#include "vesync_common.h"
#include "vesync_log.h"
#include "vesync_device.h"
#include "vesync_wifi_led.h"
#include "vesync_flash.h"

#include "outlet.h"
#include "outlet_gpio.h"
#include "outlet_flash.h"
#include "outlet_button.h"
#include "outlet_inching.h"
#include "outlet_report.h"
#if defined(OUTLET_ELEC_METERING) && (OUTLET_ELEC_METERING == 1)
#include "outlet_metering.h"
#endif
#include "outlet_production.h"


#define PRO_PCBA_TEST_FLAG          "pcba_flag"
// 产测PCBA测试通过标志，如没有该标志标示未产测通过
#define PRO_PCBA_TEST_MAGIC_CODE   (0xAABBCCDD)

static vesync_timer_t *s_test_timerhd = NULL;       // 定时记录数据定时器
static uint8_t s_pcba_test_pass = 1;                // PCBA测试通过标志
#if defined(OUTLET_ELEC_METERING) && (OUTLET_ELEC_METERING == 1)
static vesync_timer_t *s_pcba_test_timerhd = NULL;  // PCBA结果扫描定时器
static struct
    {
        uint32_t wifi : 1;
        uint32_t metering : 1;
    } s_pacb_pass_flag ={
        wifi : 1,
        metering : 1
    };
#endif

/**
 * @brief 停止定时器
 */
static void outlet_production_timer_stop(void)
{


#if defined(OUTLET_ELEC_METERING) && (OUTLET_ELEC_METERING == 1)
    if (!s_pcba_test_pass)
    {
        outlet_production_self_cal_metering();

    }
#endif

    if (NULL != s_test_timerhd && VOS_OK == vesync_timer_free(s_test_timerhd))
    {
        s_test_timerhd = NULL;
    }
}

/*
 * @brief 定时器超时回调
 * @param arg        参数(未使用)
 * @return void
 */
static void outlet_production_timer_cb(void *arg)
{
    outlet_ev_t ev;
    static uint8_t cnt = 0;

    memset(&ev, 0, sizeof(ev));
    cnt++;
    if (cnt > 2)
    {
        outlet_production_timer_stop();
        ev.id = OUTLET_EV_ON;
        ev.act_src = OUTLET_ACT_SRC_TASK;
        cnt = 0;
    }
    else
    {
        if (cnt%2)
        {
            ev.id = OUTLET_EV_ON;
            ev.act_src = OUTLET_ACT_SRC_TASK;
        }
        else
        {
            ev.id = OUTLET_EV_OFF;
            ev.act_src = OUTLET_ACT_SRC_TASK;
        }
    }

    snprintf(ev.rsn, sizeof(ev.rsn), "%s", STAT_CHG_RSN_PRODUCTION_STR);
    outlet_app_task_notify(&ev);
}

/**
 * @brief 创建并启动数据记录定时器
 * @param void
 */
static void outlet_production_timer_start(void)
{
    if (NULL == s_test_timerhd)
    {
        // 创建定时器，间隔800ms，自动加载
        s_test_timerhd = vesync_timer_new("outlet_production_timer", outlet_production_timer_cb, NULL, 800, true);
    }

    if (NULL != s_test_timerhd)
    {
        if (vesync_timer_start(s_test_timerhd) != VOS_OK)
        {
            APP_LOG(LOG_ERROR, "Switch test timer start fail!!\n");
        }
    }
    else
    {
        APP_LOG(LOG_ERROR, "Switch test timer create fail!!\n");
    }

}


/**
 * @brief 继电器测试
 *
 * @param arg
 */
void outlet_production_test_relay(void)
{
    outlet_production_timer_start();
}

/**
 * @brief WiFi测试回调
 * @param[in]   flag
 */
static void outlet_production_wifi_test_cb(int flag)
{
    if (1 == flag)  // WiFi连接成功
    {
#if defined(OUTLET_ELEC_METERING) && (OUTLET_ELEC_METERING == 1)
        s_pacb_pass_flag.wifi = 1;
#else
        // 关闭灯效
        vesync_wifi_led_set_behavior(WIFI_LED_STARTUP);
        outlet_disable_indicator();
#endif
    }
    else
    {
#if defined(OUTLET_ELEC_METERING) && (OUTLET_ELEC_METERING == 1)
        s_pacb_pass_flag.wifi = 0;
#else
        // 仅展示灯效
        vesync_wifi_led_set_behavior(WIFI_LED_WIFI_DISC);
#endif

    }
}

#if defined(OUTLET_ELEC_METERING) && (OUTLET_ELEC_METERING == 1)
/**
 * @brief 停止定时器
 */
static void outlet_production_pcba_timer_stop(void)
{
    if (NULL != s_pcba_test_timerhd && VOS_OK == vesync_timer_free(s_pcba_test_timerhd))
    {
        s_pcba_test_timerhd = NULL;
    }
}

/**
 * @brief PCBA测试通过回调
 */
static void outlet_production_pcba_test_pass_cb(void)
{
    uint32_t magic_code = PRO_PCBA_TEST_MAGIC_CODE;
    if (SDK_OK == vesync_flash_write(PARTITION_CFG, PRO_PCBA_TEST_FLAG, (uint8_t*)&magic_code, sizeof(magic_code)))
    {
        APP_LOG(LOG_DEBUG, "write pcba flag success\n");
    }
    else
    {
        APP_LOG(LOG_ERROR, "write pcba flag fail\n");
    }
}

/*
 * @brief 定时器超时回调
 * @param arg        参数(未使用)
 * @return void
 */
static void outlet_production_pcba_timer_cb(void *arg)
{
    static uint8_t cnt = 0;

    cnt++;

    metering_data_t temp;

    if (APP_OK == outlet_metering_get_metering_data(&temp))
    {
        s_pacb_pass_flag.metering = 1;
    }

    if (2 < cnt)   // 检查校准结果
    {
        if (s_pacb_pass_flag.wifi && s_pacb_pass_flag.metering)
        {
            // 关闭灯效
            vesync_wifi_led_set_behavior(WIFI_LED_STARTUP);
            outlet_disable_indicator();
            outlet_production_pcba_test_pass_cb();
            outlet_production_pcba_timer_stop();
        }
        if (10 < cnt)   // 超时
        {
            if (!s_pacb_pass_flag.wifi)
            {
                // 仅展示灯效
                vesync_wifi_led_set_behavior(WIFI_LED_WIFI_DISC);
            }
            else if (!s_pacb_pass_flag.metering)
            {
                // 仅展示灯效
                vesync_wifi_led_set_behavior(WIFI_LED_NOT_CONFIG);
            }
            outlet_production_pcba_timer_stop();
        }
    }
}

/**
 * @brief 创建并启动数据记录定时器
 * @param void
 */
static void outlet_production_timer_pcba_start(void)
{
    if (NULL == s_pcba_test_timerhd)
    {
        s_pcba_test_timerhd = vesync_timer_new("outlet_production_timer", outlet_production_pcba_timer_cb, NULL, 1000, true);
    }

    if (NULL != s_pcba_test_timerhd)
    {
        if (vesync_timer_start(s_pcba_test_timerhd) != VOS_OK)
        {
            APP_LOG(LOG_ERROR, "Switch test timer start fail!!\n");
        }
    }
    else
    {
        APP_LOG(LOG_ERROR, "Switch test timer create fail!!\n");
    }

}

/**
 * @brief PCBA测试，计量自校正
 */
void outlet_production_self_cal_metering(void)
{
    metering_rated_t rated_data = {
        flag : 0,
        Power0 : OUTLET_MTR_SELF_CAL_POWER0,
        Voltage0 : OUTLET_MTR_SELF_CAL_VOLTAGE0,
        Current0 : OUTLET_MTR_SELF_CAL_CURRENT0
    };
    // 设置校准参数
    outlet_metering_set_rated_data(&rated_data);
    outlet_production_timer_pcba_start();
}
#endif

#if defined(OUTLET_METERING_PRO_REPORT) && (OUTLET_METERING_PRO_REPORT == 1)
/**
 * @brief 产测时，计量校准后的计量数据上报
 * @param[in]   arg
 */
static void outlet_production_metering_report(void *arg)
{
    static vesync_timer_t *s_pro_mtr_timer = NULL;

    if (NULL == s_pro_mtr_timer)
    {
        s_pro_mtr_timer = vesync_timer_new("pro_mtr_timer", outlet_production_metering_report, NULL, 4 * 1000, true);
        if (NULL != s_pro_mtr_timer)
        {
            vesync_timer_start(s_pro_mtr_timer);
        }
    }
    else
    {
        outlet_report_measured_pui();
    }
}
#endif

/**
 * @brief 产测回调函数
 * @param[in]  arg          [产测状态码]
 */
void outlet_production_callback(PRODUCTION_STATUS_E arg)
{
    int cnt = 0;
    switch(arg)
    {
        case PRODUCTION_START:
            // 进入产测，强制关机
            outlet_set_switch_onoff(false);
            outlet_inching_stop();
#if defined(OUTLET_ELEC_METERING) && (OUTLET_ELEC_METERING == 1)
            outlet_metering_clear_electricity(OUTLET_SWITCH_USED_ELEC_UNIT);
#endif
            APP_LOG(LOG_INFO, "Switch production start.\n");
            break;
        case PRODUCTION_RUNNING:
            APP_LOG(LOG_INFO, "Switch production running.\n");
#if defined(OUTLET_METERING_PRO_REPORT) && (OUTLET_METERING_PRO_REPORT == 1)
            outlet_production_metering_report(NULL);
#endif
            break;
        case PRODUCTION_TEST_PASS:
#if defined(OUTLET_PRO_PASS_RESET) && (OUTLET_PRO_PASS_RESET == 1)  // fix bug 40864
            {
                APP_LOG(LOG_INFO, "Switch production pass, factory reset atfer 2sec....\n");
                while (cnt < 10)
                {
                    vesync_sleep(500);
                    cnt += 1;
                    APP_LOG(LOG_INFO, "delay 500ms\n");
                    if (NULL == s_test_timerhd)
                    {
                        break;
                    }
                }
                vesync_device_factory_reset(false, STAT_CHG_RSN_NONE_STR);
            }
#else
            UNUSED(cnt);
            APP_LOG(LOG_INFO, "Switch production pass.\n");
            switch_clear_config();
#endif
            break;
        case PRODUCTION_TEST_FAIL:
            APP_LOG(LOG_INFO, "Switch production fail.\n");
            switch_clear_config();
            // fix bug 40864后，仅为了展示灯效，提示产测失败
            // 产测成功继电器保持开，指示灯开，若WiFi断开，指示灯闪烁也判定为失败
            vesync_wifi_led_set_behavior(WIFI_LED_WIFI_DISC);
            break;
        default:
            break;
    }
}

/**
 * @brief 加载PCBA测试结果
 * @return int             [错误码，成功/失败]
 */
static int outlet_production_load_pcba_flag(void)
{
    uint32_t magic_code = 0;
    uint32_t len = 0;

    if (SDK_OK == vesync_flash_read(PARTITION_CFG, PRO_PCBA_TEST_FLAG,
        (uint8_t*) &magic_code, &len) &&
        len == sizeof(magic_code) &&
        PRO_PCBA_TEST_MAGIC_CODE == magic_code)
    {
        return APP_OK;
    }
    if (SDK_OK == vesync_flash_read(PARTITION_FAC, PRO_PCBA_TEST_FLAG,
        (uint8_t*) &magic_code, &len) &&
        len == sizeof(magic_code) &&
        PRO_PCBA_TEST_MAGIC_CODE == magic_code)
    {
        vesync_flash_write(PARTITION_CFG, PRO_PCBA_TEST_FLAG, (uint8_t*)&magic_code, sizeof(magic_code));
        return APP_OK;
    }

#if defined(OUTLET_ELEC_METERING) && (OUTLET_ELEC_METERING == 1)
    s_pacb_pass_flag.metering = 0;
    s_pacb_pass_flag.wifi = 0;
#endif
    s_pcba_test_pass = 0;


    return APP_FAIL;
}

/**
 * @brief 执行PCBA测试
 * @return int             [错误码，成功/失败]
 */
int outlet_pcba_test_process(void)
{
    if (APP_OK != outlet_production_load_pcba_flag())
    {
        vesync_production_connect_router_test(PRO_WIFI_TEST_SSID, PRO_WIFI_TEST_PWD, outlet_production_wifi_test_cb);
        return APP_OK;
    }

    return APP_FAIL;
}

