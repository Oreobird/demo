/**
*Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file    lightstring_flash.c
* @brief   lightstring flash 读写
* @author  Lind
*@date     2021-1220
*/

#include <stdio.h>
#include <string.h>

#include "vesync_common.h"
#include "vesync_log.h"
#include "vesync_flash.h"
#include "vesync_device.h"
#include "vesync_klv.h"
#include "vesync_memory.h"

#include "lightstring_flash.h"
#include "lightstring.h"
#include "lightstring_button.h"

/**
 * @brief 保存开关数据到flash
 * @param[in]  data                 [开关配置]
 * @return     int               [成功：APP_OK ，失败:：APP_FAIL]
 */
int ls_save_config(ls_status_t data)
{
    int ret = APP_FAIL;
    uint8_t *p_buf= NULL;
    int offset = 0;
    uint8_t version = 0;
    if (NULL == (p_buf = (uint8_t *)vesync_malloc(LS_KLV_DATE_LEN)))
    {
        return APP_FAIL;
    }

    memset(p_buf, 0, LS_KLV_DATE_LEN);

    version = LSP_APP_DATA_VERSION;
    offset +=  vesync_klv_set(p_buf+offset, LS_KLV_DATE_LEN-offset, LS_KEY_VERSION, sizeof(version), (uint8_t*)&version);
    offset +=  vesync_klv_set(p_buf+offset, LS_KLV_DATE_LEN-offset, LS_KEY_STATUS, sizeof(data.status), (uint8_t*)&data.status);
    offset +=  vesync_klv_set(p_buf+offset, LS_KLV_DATE_LEN-offset, LS_KEY_MODEL, sizeof(data.mode), (uint8_t*)&data.mode);
    offset +=  vesync_klv_set(p_buf+offset, LS_KLV_DATE_LEN-offset, LS_KEY_TIMER_MODE, sizeof(data.timer_mode), (uint8_t*)&data.timer_mode);
    offset +=  vesync_klv_set(p_buf+offset, LS_KLV_DATE_LEN-offset, LS_KEY_SCENE_ID, sizeof(data.scene_id), (uint8_t*)&data.scene_id);
    offset +=  vesync_klv_set(p_buf+offset, LS_KLV_DATE_LEN-offset, LS_KEY_MUSIC_ID, sizeof(data.music_id), (uint8_t*)&data.music_id);
    offset +=  vesync_klv_set(p_buf+offset, LS_KLV_DATE_LEN-offset, LS_KEY_SPEED, sizeof(data.speed), (uint8_t*)&data.speed);
    offset +=  vesync_klv_set(p_buf+offset, LS_KLV_DATE_LEN-offset, LS_KEY_BRIGHTNESS, sizeof(data.brightness), (uint8_t*)&data.brightness);
    offset +=  vesync_klv_set(p_buf+offset, LS_KLV_DATE_LEN-offset, LS_KEY_VOICE_CTRL, sizeof(data.voice_ctrl), (uint8_t*)&data.voice_ctrl);
    ret = vhal_flash_write(PARTITION_CFG, LS_USER_CFG_KEY_DATA, p_buf, offset);

    vesync_free(p_buf);

    if (VHAL_OK != ret)
    {
        APP_LOG(LOG_ERROR, "Write data fail, ret = %d.\n", ret);
        return APP_FAIL;
    }
    return APP_OK;
}

/**
 * @brief 从flash中读取数据到内存
 * @param[out] p_data               [开关配置]
 * @return     int               [成功：APP_OK ，失败:：APP_FAIL]
 */
int ls_read_config(ls_status_t *p_data)
{
    int ret = APP_OK;
    uint32_t len = 0;
    uint8_t *p_buf= NULL;
    uint8_t version = 0;

    if (NULL == p_data)
    {
        APP_LOG(LOG_ERROR, "Input parameters contain null pointers!\n");
        return APP_FAIL;
    }

     if(NULL == (p_buf = (uint8_t *)vesync_malloc(LS_KLV_DATE_LEN)))
    {
        return APP_FAIL;
    }

    if (VHAL_OK != vhal_flash_read(PARTITION_CFG, LS_USER_CFG_KEY_DATA, p_buf, &len) || len == 0)
    {
        APP_LOG(LOG_ERROR, "Read lightstring data fail, ret = %d.\n", ret);
        vesync_free(p_buf);
        return APP_FAIL;
    }

    ret += vesync_klv_get(p_buf, len, LS_KEY_VERSION, sizeof(version), (uint8_t*)&version);
    ret += vesync_klv_get(p_buf, len, LS_KEY_STATUS, sizeof(p_data->status), (uint8_t*)&p_data->status);
    ret += vesync_klv_get(p_buf, len, LS_KEY_MODEL, sizeof(p_data->mode), (uint8_t*)&p_data->mode);
    ret += vesync_klv_get(p_buf, len, LS_KEY_TIMER_MODE, sizeof(p_data->timer_mode), (uint8_t*)&p_data->timer_mode);
    ret += vesync_klv_get(p_buf, len, LS_KEY_SCENE_ID, sizeof(p_data->scene_id), (uint8_t*)&p_data->scene_id);
    ret += vesync_klv_get(p_buf, len, LS_KEY_MUSIC_ID, sizeof(p_data->music_id), (uint8_t*)&p_data->music_id);
    ret += vesync_klv_get(p_buf, len, LS_KEY_SPEED, sizeof(p_data->speed), (uint8_t*)&p_data->speed);
    ret += vesync_klv_get(p_buf, len, LS_KEY_BRIGHTNESS, sizeof(p_data->brightness), (uint8_t*)&p_data->brightness);
    ret += vesync_klv_get(p_buf, len, LS_KEY_VOICE_CTRL, sizeof(p_data->voice_ctrl), (uint8_t*)&p_data->voice_ctrl);
    vesync_free(p_buf);

    return (ret == APP_OK ? APP_OK : APP_FAIL);
}

/**
 * @brief 清除开关配置
 * @return int          [APP_OK/APP_FAIL]
 */
int ls_clear_config(void)
{
    int ret = APP_FAIL;

    ret = vhal_flash_erase_key(PARTITION_CFG, LS_USER_CFG_KEY_DATA);
    if (VHAL_OK != ret)
    {
        APP_LOG(LOG_ERROR, "Clear lightstring data fail\n");
        return APP_FAIL;
    }

    return APP_OK;
}

