/**
 * Copyright © Vesync Technologies Co.Ltd. 2022. All rights reserved.
 * @file        led_strip_bypass.c
 * @brief       led strip bypass通信接口
 * @author      Lind
 * @date        2022-01-10
 */

#include <stdint.h>
#include <string.h>

#include "vesync_common.h"
#include "vesync_log.h"
#include "vesync_memory.h"
#include "vesync_buffer.h"
#include "vesync_bypass.h"
#include "vesync_timing.h"
#include "vesync_device.h"
#include "vesync_schedule.h"

#include "led_strip.h"
#include "led_strip_led.h"
#include "led_strip_scene.h"
#include "led_strip_flash.h"
#include "led_strip_timing.h"
#include "led_strip_bypass.h"
#include "led_strip_report.h"
#include "led_strip_schedule.h"

static bool s_ls_voice_off_flag = false; // 第三方语音设置亮度为0，标志位（认证需求）

/**
* @brief 设置语音关闭标志位，
* @param[in]  flag          [true:语音导致灯带关闭;false:当前状态不是语音关闭]
*/
void ls_set_voice_off_flag(bool flag)
{
    s_ls_voice_off_flag = flag;
}

/**
* @brief 新增timer
* @note  新增bypass method
* @param[in]        p_msg_ctx       [bypass上下文]
* @param[in]        json            [传入json]
* @return           BYPASS_ERR_E    [错误码]
*/
static BYPASS_ERR_E ls_bp_add_timer(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    ls_timing_t action ;
    cJSON* json_data = NULL;
    cJSON* json_timer = NULL;
    cJSON* json_obj = NULL;
    cJSON* json_act = NULL;
    cJSON* json_type = NULL;
    int ret = 0;

    if (NULL == p_msg_ctx || NULL == p_msg_ctx->p_trace_msg || NULL == json)
    {
        APP_LOG(LOG_DEBUG, " addTimerV2 error \n");
        return BP_ERROR;
    }

    APP_LOG(LOG_DEBUG, "-------addTimerV2 handle--------\n");

    memset(&action, 0, sizeof(ls_timing_t));

    json_data = cJSON_GetObjectItemCaseSensitive(json, "total");
    if (cJSON_IsNumber(json_data))
    {
         action.total_sec = json_data->valueint;
         VCOM_IN_RANGE_CHK(action.total_sec, TIMER_SEC_MIN, TIMER_SEC_MAX, (ret++));
         if (ret)
         {
            return BP_ERR_ARG;
         }
    }
    else
    {
        return BP_ERR_ARG;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "startAct");
    if (!cJSON_IsArray(json_data))
    {
        return BP_ERR_ARG;
    }

    int arr_size = cJSON_GetArraySize(json_data);
    if (arr_size > 2)
    {
        return BP_ERR_ARG;
    }

    for (int i = 0; i < arr_size; i++)
    {
        json_obj = cJSON_GetArrayItem(json_data, i);
        if (NULL == json_obj)
        {
            return BP_ERR_ARG;
        }

        json_type = cJSON_GetObjectItemCaseSensitive(json_obj, "type");
        if (0 == strcmp(json_type->valuestring, "switch"))
        {
            json_act = cJSON_GetObjectItemCaseSensitive(json_obj, "act");
            if (0 == strcmp(json_act->valuestring, "off"))
            {
                action.mode = LS_MODE_OFF;
                break;
            }

        }
        else if (0 == strcmp(json_type->valuestring, "color_mode"))
        {
            json_act = cJSON_GetObjectItemCaseSensitive(json_obj, "act");
            if (!cJSON_IsString(json_act))
            {
                return BP_ERR_ARG;
            }

            cJSON *json_param = NULL;
            cJSON *json_id = NULL;
            json_param = cJSON_GetObjectItemCaseSensitive(json_obj, "params");
            if (NULL == json_param)
            {
                return BP_ERR_ARG;
            }

            if (0 == strcmp(json_act->valuestring, "scenario"))
            {
                action.mode = LS_MODE_SCENE;
                json_id = cJSON_GetObjectItemCaseSensitive(json_param, "sceneId");
            }
            else
            {
                return BP_ERR_ARG;
            }

            if (NULL == json_id)
            {
                return BP_ERR_ARG;
            }
            else
            {
                ret = ls_scene_id_check(json_id->valueint);
                if (ret)
                {
                    vesync_bypass_reply_pkg_err_msg(ret, p_msg_ctx->p_trace_msg, NULL);
                    return BP_OK;
                }

                action.scene_id = json_id->valueint;
            }

        }
        else
        {
            return BP_ERR_ARG;
        }
    }


    if (APP_OK == ls_timing_add(action.total_sec, &(action.id), action.mode, action.scene_id))
    {
        json_timer = cJSON_CreateObject();
        if (NULL != json_timer)
        {
            cJSON_AddNumberToObject(json_timer, "id", action.id);
            APP_LOG(LOG_DEBUG,"add timer %d\n", action.id);
            vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, json_timer);
        }
        else
        {
            return BP_ERR_NOMEM;
        }
    }
    else
    {
        vesync_bypass_reply_noqos(BP_ERR_TIMER_EXCEED_MAX, p_msg_ctx->p_trace_msg, NULL);
    }

    return BP_OK;
}

/**
* @brief 获取timer
* @note  新增bypass method
* @param[in]        p_msg_ctx       [bypass上下文]
* @param[in]        json            [传入json]
* @return           BYPASS_ERR_E    [错误码]
*/
static BYPASS_ERR_E ls_bp_get_timer(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    BYPASS_ERR_E ret = BP_OK;
    uint16_t timer_id = 0;
    ls_timing_t *timing = NULL;
    cJSON *json_data = NULL;
    cJSON *json_timers = NULL;
    cJSON *json_timer = NULL;
    cJSON *json_arr = NULL;
    cJSON *json_mode = NULL;
    cJSON *json_action = NULL;
    cJSON *json_params = NULL;
    timing_data_t tm;
    memset(&tm, 0, sizeof(timing_data_t));

    if (NULL == p_msg_ctx || NULL == p_msg_ctx->p_trace_msg)
    {
        return BP_ERROR;
    }
    UNUSED(json);

    json_data = cJSON_CreateObject();
    if (NULL == json_data)
    {
        return BP_ERR_NOMEM;
    }

    cJSON_AddItemToObject(json_data, "timers", json_timers =  cJSON_CreateArray());
    if (NULL == json_timers)
    {
        ret = BP_ERR_NOMEM;
        goto exit;
    }

    timing = ls_timing_get_act();
    timer_id = timing->id;
    if (timer_id == 0)
    {
        vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, json_data);
        return BP_OK;
    }

    if (SDK_OK == vesync_timing_get(timer_id, &tm))
    {
        cJSON_AddItemToArray(json_timers, json_timer = cJSON_CreateObject());
        if (NULL == json_timer)
        {
            ret = BP_ERR_NOMEM;
            goto exit;
        }

        cJSON_AddNumberToObject(json_timer, "id", tm.timing_id);
        cJSON_AddNumberToObject(json_timer, "total", tm.total_second);
        cJSON_AddNumberToObject(json_timer, "remain", tm.remain_second);
        // package
        cJSON_AddItemToObject(json_timer, "startAct", json_arr = cJSON_CreateArray());
        cJSON_AddItemToArray(json_arr, json_mode = cJSON_CreateObject());
        if (NULL == json_arr || NULL == json_mode)
        {
            ret = BP_ERR_NOMEM;
            goto exit;
        }

        cJSON_AddStringToObject(json_mode, "type", "switch");
        cJSON_AddNumberToObject(json_mode, "num", 0);
        if (timing->mode == LS_MODE_OFF)
        {
            cJSON_AddStringToObject(json_mode, "act", "off");
        }
        else
        {
            cJSON_AddStringToObject(json_mode, "act", "on");
            cJSON_AddItemToArray(json_arr, json_action = cJSON_CreateObject());
            if (NULL == json_action)
            {
                ret = BP_ERR_NOMEM;
                goto exit;
            }

            cJSON_AddStringToObject(json_action, "type", "color_mode");
            cJSON_AddItemToObject(json_action, "params",json_params = cJSON_CreateObject());
            if (NULL == json_params)
            {
                ret = BP_ERR_NOMEM;
                goto exit;
            }

            if (timing->mode == LS_MODE_SCENE)
            {
                cJSON_AddStringToObject(json_action, "act", "scenario");
                cJSON_AddNumberToObject(json_params, "sceneId", timing->scene_id);
            }

            cJSON_AddNumberToObject(json_action, "num", 0);
        }
    }

    vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, json_data);
    return BP_OK;

exit:
    vesync_bypass_reply_pkg_err_msg(ret, p_msg_ctx->p_trace_msg, NULL);
    cJSON_Delete(json_data);
    return ret;
}

/**
* @brief 删除timer
* @note  新增bypass method
* @param[in]        p_msg_ctx       [bypass上下文]
* @param[in]        json            [传入json]
* @return           BYPASS_ERR_E    [错误码]
*/
static BYPASS_ERR_E ls_bp_del_timer(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    if (NULL == p_msg_ctx || NULL == p_msg_ctx->p_trace_msg || NULL == json)
    {
        return BP_ERROR;
    }

    cJSON *json_data = cJSON_GetObjectItemCaseSensitive(json, "id");
    if (cJSON_IsNumber(json_data))
    {
        if (APP_OK == ls_timing_remove(json_data->valueint))
        {
            cJSON *json_ret = cJSON_CreateObject();
            if (NULL != json_ret)
            {
                cJSON_AddNumberToObject(json_ret, "id", json_data->valueint);
            }

            vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, json_ret);
        }
        else
        {
            vesync_bypass_reply_pkg_err_msg(BP_ERR_TIMER_NOT_FOUND, p_msg_ctx->p_trace_msg, "Timer remove fail");
        }
    }
    else
    {
        return BP_ERR_ARG;
    }

    return BP_OK;
}

/**
* @brief ledstrip bypass 添加Schedule回调接口
* @param[in]  p_msg_ctx                [msg context]
* @param[in]  p_data                   [回调函数传入数据]
*/
static void ls_bp_add_schedule(bypass_msg_ctx_t *p_msg_ctx, void *p_data)
{
    int error_code = BP_ERR_ARG;

    if(NULL == p_data)
    {
        vesync_bypass_reply_pkg_err_msg(BP_ERR_PARA_ILLEGAL, p_msg_ctx->p_trace_msg, BP_ERR_PARAM_CONV(p_data, BP_ERR_PARAM_NULL_PTR));
        return;
    }

    uint32_t sch_id = 0;
    cJSON *json_sch_ret = NULL;
    bypass_schedule_base_t *p_bp_sch = (bypass_schedule_base_t *)p_data;

    error_code = ls_schedule_add(p_bp_sch, &sch_id);
    if (BP_ERR_NO_ERR == error_code)
    {
        // 添加成功，生成回应
        json_sch_ret = cJSON_CreateObject();
        if (NULL != json_sch_ret)
        {
            cJSON_AddNumberToObject(json_sch_ret, "id", sch_id);
        }
    }

    vesync_bypass_reply_noqos(error_code, p_msg_ctx->p_trace_msg, json_sch_ret);
}

/**
* @brief Outlet bypass 更新Schedule回调接口
* @param[in]  p_msg_ctx                [msg context]
* @param[in]  p_data                   [回调函数传入数据]
*/
static void ls_bp_upd_schedule(bypass_msg_ctx_t *p_msg_ctx, void *p_data)
{
    int error_code = BP_ERR_PARA_ILLEGAL;

    if(NULL == p_data)
    {
        vesync_bypass_reply_pkg_err_msg(BP_ERR_PARA_ILLEGAL, p_msg_ctx->p_trace_msg, BP_ERR_PARAM_CONV(p_data, BP_ERR_PARAM_NULL_PTR));
        return;
    }

    uint32_t sch_id = 0;
    cJSON *json_sch_ret = NULL;
    bypass_schedule_base_t *p_bp_sch = (bypass_schedule_base_t *)p_data;

    error_code = ls_schedule_upd(p_bp_sch, &sch_id);
    if (BP_ERR_NO_ERR == error_code)
    {
        // 更新成功，生成回应
        json_sch_ret = cJSON_CreateObject();
        if (NULL != json_sch_ret)
        {
            cJSON_AddNumberToObject(json_sch_ret, "id", sch_id);
        }
    }

    vesync_bypass_reply_noqos(error_code, p_msg_ctx->p_trace_msg, json_sch_ret);
}

/**
* @brief Outlet bypass 删除Schedule回调接口
* @param[in]  p_msg_ctx                [msg context]
* @param[in]  p_data                   [回调函数传入数据]
*/
static void ls_bp_del_schedule(bypass_msg_ctx_t *p_msg_ctx, void *p_data)
{
    APP_LOG(LOG_DEBUG, "del schedule \n");
    int error_code = BP_ERR_PARA_ILLEGAL;

    if(NULL == p_data)
    {
        vesync_bypass_reply_pkg_err_msg(BP_ERR_PARA_ILLEGAL, p_msg_ctx->p_trace_msg, BP_ERR_PARAM_CONV(p_data, BP_ERR_PARAM_NULL_PTR));
        return;
    }

    uint32_t sch_id = *((uint32_t *)p_data);
    cJSON *json_sch_ret = NULL;

    error_code = ls_schedule_del(sch_id);
    if (BP_ERR_NO_ERR == error_code)
    {
        // 删除成功，生成回应
        json_sch_ret = cJSON_CreateObject();
        if (NULL != json_sch_ret)
        {
            cJSON_AddNumberToObject(json_sch_ret, "id", sch_id);
        }
    }

    vesync_bypass_reply_noqos(error_code, p_msg_ctx->p_trace_msg, json_sch_ret);
}


/**
* @brief 生成Schedule配置项列表的JSON
* @param[in] json_array    [JSON数组根对象]
* @param[in] p_list        [Schedule配置项列表]
* @param[in] list_len      [列表的最大长度,注意大于等于列表内的配置项数量]
* @return      int         [Bypass定义的错误]
*/
static int schedule_list_json_marshal(void *json_array, bypass_schedule_base_t *p_list, uint32_t list_len)
{
    cJSON *p_out = (cJSON *)json_array;

    if (!cJSON_IsArray(p_out))
    {
        return BP_ERR_PARA_ILLEGAL;
    }

    for (uint32_t cnt = 0; cnt < list_len; cnt++)
    {
        // 判断列表结束
        if (0 == p_list[cnt].id)
        {
            break;
        }

        cJSON *sch_obj = cJSON_CreateObject();
        cJSON *sub_obj = NULL;
        uint8_t type = *((uint8_t *)p_list[cnt].type);

        if (NULL == sch_obj)
        {
            APP_LOG(LOG_ERROR,"creat error!\n");
            return BP_ERROR;
        }

        cJSON_AddNumberToObject(sch_obj, "id", p_list[cnt].id);
        cJSON_AddBoolToObject(sch_obj, "enabled", *((bool *)p_list[cnt].enabled));
        cJSON_AddItemToObject(sch_obj, "startAct", (cJSON*)p_list[cnt].json_action);
        cJSON_AddNumberToObject(sch_obj, "type", type);
        if (BYPASS_SCHEDULE_JSON_TYPE_TMG_EVT == type)
        {
            sub_obj = cJSON_AddObjectToObject(sch_obj, "tmgEvt");

            cJSON_AddNumberToObject(sub_obj, "clkSec", *p_list[cnt].clock_sec);
        }
        else if (BYPASS_SCHEDULE_JSON_TYPE_SUN_EVT == type)
        {
            sub_obj = cJSON_AddObjectToObject(sch_obj, "sunEvt");

            cJSON_AddBoolToObject(sub_obj, "isRise", *((bool *)p_list[cnt].is_sunrise));
            cJSON_AddNumberToObject(sub_obj, "ofsSec", *p_list[cnt].offset_sec);
        }

        cJSON_AddNumberToObject(sch_obj, "repeat", *((uint8_t *)p_list[cnt].repeat_config));
        cJSON_AddItemToArray(p_out, sch_obj);
    }

    return BP_ERR_NO_ERR;
}


/**
* @brief bypass 查询Schedule回调接口
* @param[in]  p_msg_ctx                [msg context]
* @param[in]  p_data                   [回调函数传入数据]
*/
static void ls_bp_get_schedules(bypass_msg_ctx_t *p_msg_ctx, void *p_data)
{
    int error_code = BP_ERR_PARA_ILLEGAL;

    if(NULL == p_data)
    {
        vesync_bypass_reply_pkg_err_msg(BP_ERR_PARA_ILLEGAL, p_msg_ctx->p_trace_msg, BP_ERR_PARAM_CONV(p_data, BP_ERR_PARAM_NULL_PTR));
        return;
    }

    uint32_t index = *((uint32_t *)p_data);
    cJSON *json_sch_ret = NULL;
    cJSON *json_array = NULL;
    // 配置项总数
    uint32_t total_num = 0;
    void *mult_sche_buf = NULL;

    // 输出列表
    bypass_schedule_base_t sch_bp_list[LS_SCHEDULE_GET_MAX_NUM];
    // 初始化输出列表
    memset(sch_bp_list, 0, sizeof(bypass_schedule_base_t) * LS_SCHEDULE_GET_MAX_NUM);
    // 读取配置项
    error_code = ls_schedule_get_mult(index, &mult_sche_buf, sch_bp_list, &total_num);
    if (BP_ERR_NO_ERR == error_code)
    {
        // 查询成功，生成回应
        json_sch_ret = cJSON_CreateObject();
        if (NULL != json_sch_ret)
        {
            cJSON_AddNumberToObject(json_sch_ret, "total", total_num);
            json_array = cJSON_AddArrayToObject(json_sch_ret, "schedules");
            // 把配置项列表生成JSON添加到回应的JSON
            error_code =  schedule_list_json_marshal(json_array, sch_bp_list, LS_SCHEDULE_GET_MAX_NUM);
        }
    }

    if (BP_ERR_SCHEDULE_NOT_FOUND == error_code)
    {
        error_code = BP_ERR_NO_ERR;

        // 生成空回应
        json_sch_ret = cJSON_CreateObject();
        if (NULL != json_sch_ret)
        {
            cJSON_AddNumberToObject(json_sch_ret, "total", total_num);
            cJSON_AddArrayToObject(json_sch_ret, "schedules");
        }
    }

    // 释放配置读取内存
    vesync_free(mult_sche_buf);
    vesync_bypass_reply_noqos(error_code, p_msg_ctx->p_trace_msg, json_sch_ret);
}

/**
* @brief 设置开关开启/关闭
* @param[in]  p_msg_ctx                [msg context]
* @param[in]  p_data                   [回调函数传入数据]
*/
static void ls_bp_set_switch_onoff(bypass_msg_ctx_t *p_msg_ctx, void *p_data)
{
    if (NULL == p_data)
    {
        vesync_bypass_reply_pkg_err_msg(BP_ERR_PARA_ILLEGAL, p_msg_ctx->p_trace_msg, BP_ERR_PARAM_CONV(p_data, BP_ERR_PARAM_NULL_PTR));
        return;
    }
    bypass_switch_data_t *p_sw = (bypass_switch_data_t*)p_data;
    ls_status_t status;
    ls_ev_t ev;
    ev.id = LS_EV_UNKNOWN;
    ev.act_src = LS_ACT_SRC_BYPASS;

    ls_get_status(&status);
    if (p_sw->enable && status.status == false)
    {
        ev.id = LS_EV_TURN_ON;
        switch(status.mode)
        {
            case LS_MODE_WHITE:
                ev.mode = LS_MODE_WHITE;
                break;
            case LS_MODE_HSV:
                ev.mode = LS_MODE_HSV;
                break;
            case LS_MODE_MULTI_SEG:
                ev.mode = LS_MODE_MULTI_SEG;
                break;
            case LS_MODE_SCENE:
                ev.mode = LS_MODE_SCENE;
                ev.scene_id = status.scene_id;
                break;
            default:
                break;
        }
    }
    else if ((status.status == true) && p_sw->enable == false)
    {
        ev.id = LS_EV_TURN_OFF;
    }

    if (LS_EV_UNKNOWN != ev.id)
    {
        ls_app_task_notify(&ev);
        ls_report_set_chg_rsn(p_msg_ctx->p_trace_msg->src_type);
    }

    vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, NULL);
}

/**
* @brief 反转开关的开启/关闭状态
* @param[in]  p_msg_ctx                [msg context]
* @param[in]  p_data                   [回调函数传入数据]
*/
static void ls_bp_toggle(bypass_msg_ctx_t *p_msg_ctx, void *p_data)
{
    ls_ev_t ev;
    ev.id = LS_EV_UNKNOWN;
    ev.act_src = LS_ACT_SRC_BYPASS;

    ls_status_t status;
    ls_get_status(&status);
    // 翻转开关
    if (false == status.status)
    {
        ev.id = LS_EV_TURN_ON;
        switch(status.mode)
        {
            case LS_MODE_WHITE:
                ev.mode = LS_MODE_WHITE;
                break;
            case LS_MODE_HSV:
                ev.mode = LS_MODE_HSV;
                break;
            case LS_MODE_MULTI_SEG:
                ev.mode = LS_MODE_MULTI_SEG;
                break;
            case LS_MODE_SCENE:
                ev.mode = LS_MODE_SCENE;
                ev.scene_id = status.scene_id;
                break;
            default:
                break;
        }
    }
    else
    {
        ev.id = LS_EV_TURN_OFF;
    }

    if (LS_EV_UNKNOWN != ev.id)
    {
        ls_app_task_notify(&ev);
        ls_report_set_chg_rsn(p_msg_ctx->p_trace_msg->src_type);
    }

    vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, NULL);
}

/**
* @brief 调整亮度色温百分比
* @param[in]  p_msg_ctx                [msg context]
* @param[in]  p_data                   [回调函数传入数据]
*/
static void ls_bp_adjust_percent(bypass_msg_ctx_t *p_msg_ctx, void *p_data)
{
    if (NULL == p_data)
    {
        vesync_bypass_reply_pkg_err_msg(BP_ERR_PARA_ILLEGAL, p_msg_ctx->p_trace_msg, BP_ERR_PARAM_CONV(p_data, BP_ERR_PARAM_NULL_PTR));
        return;
    }

    bypass_adjust_percent_t *data = (bypass_adjust_percent_t*)p_data;
    int temp = 0;
    ls_ev_t ev;
    ev.id = LS_EV_UNKNOWN;
    ev.act_src = LS_ACT_SRC_BYPASS;

    ls_status_t status;
    ls_get_status(&status);

    if (0 == strcmp(data->type, "brightness"))
    {
        if ((true == status.status)&&(LS_MODE_WHITE != status.mode)&&(LS_MODE_HSV != status.mode))
        {
            // 开启状态下，该接口设置亮度时处于情景模式下不响应
            vesync_bypass_reply_pkg_err_msg(BP_ERR_NOT_EXEC_IN_CUR_MODE, p_msg_ctx->p_trace_msg, "Params matched error! ");
            return;
        }

        // 不响应关闭模式下降低亮度，其他都需要调整亮度
        if (false != status.status || 0 < data->step)
        {
            if (LS_MODE_WHITE == status.mode)
            {
                int cur_bright = (false == status.status) ? 0 : status.hsvw.white;
                temp = cur_bright + data->step;
                if (temp <= 0)
                {
                    temp = 0;
                }
                else if (temp > 100)
                {
                    temp = 100;
                }
            }
            else if (LS_MODE_HSV == status.mode)
            {
                int cur_V = (false == status.status) ? 0: status.hsvw.V;
                temp = cur_V + data->step;
                if (temp <= 0)
                {
                    temp = 0;
                }
                else if (temp > 100)
                {
                    temp = 100;
                }
            }
            else
            {
                // 仅开启
                temp = 1;
            }
        }
    }
    else
    {
        vesync_bypass_reply_pkg_err_msg(BP_ERR_PARA_ILLEGAL, p_msg_ctx->p_trace_msg, "Invalid type ! ");
        return;
    }

    if (temp == 0)
    {
        ev.id = LS_EV_TURN_OFF;
    }
    else
    {
        ev.id = LS_EV_TURN_ON;
        ev.mode = status.mode;
        if (LS_MODE_SCENE == status.mode || LS_MODE_MULTI_SEG == status.mode)
        {
            ev.scene_id = status.scene_id;
        }
        else
        {
            ls_status_t *pst_status = NULL;
            ls_get_scene_lock(true);
            pst_status = ls_get_status_pointer();
            if (LS_MODE_WHITE == ev.mode)
            {
                pst_status->hsvw.white = temp;
            }
            else if (LS_MODE_HSV == ev.mode)
            {
                pst_status->hsvw.V = temp;
            }

            ls_get_scene_lock(false);
        }
    }

    ls_app_task_notify(&ev);

    // 回复与上报
    cJSON *p_json_result = NULL;
    p_json_result = cJSON_CreateObject();
    if (p_json_result != NULL)
    {
        cJSON_AddNumberToObject(p_json_result, "percent", temp);
    }

    ls_report_set_chg_rsn(p_msg_ctx->p_trace_msg->src_type);
    vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, p_json_result);
}


/**
* @brief led状态json数据打包
* @param[in]  light_params      [led参数]
* @param[out]  *p_data          [json指针]
*/
static void ls_bp_light_status_json_marshal(ls_status_t *light_params, cJSON *p_data)
{
    if (light_params->status == false)
    {
        cJSON_AddStringToObject(p_data, "enabled", "off");
    }
    else
    {
        cJSON_AddStringToObject(p_data, "enabled", "on");
        switch(light_params->mode)
        {
            case LS_MODE_SCENE:
                cJSON_AddStringToObject(p_data, "colorMode", "scenario");
                break;
            case LS_MODE_MULTI_SEG:
                cJSON_AddStringToObject(p_data, "colorMode", "multiHsv");
                cJSON_AddNumberToObject(p_data, "cnt", light_params->node_num);
                break;
            case LS_MODE_HSV:
                cJSON_AddStringToObject(p_data, "colorMode", "hsv");
                break;
            case LS_MODE_WHITE:
                cJSON_AddStringToObject(p_data, "colorMode", "white");
                break;
            default:
                break;
        }
    }

    cJSON_AddNumberToObject(p_data, "brightness", light_params->hsvw.white);
    cJSON_AddNumberToObject(p_data, "colorTemp", 0);
    cJSON_AddNumberToObject(p_data, "sceneId", light_params->scene_id);
    cJSON_AddNumberToObject(p_data, "hue", light_params->hsvw.H);
    cJSON_AddNumberToObject(p_data, "saturation", light_params->hsvw.S);
    cJSON_AddNumberToObject(p_data, "value", light_params->hsvw.V);
}

/**
* @brief 设置灯状态
* @param[in]  p_msg_ctx             [msg context]
* @param[in]        json            [传入json]
* @return           BYPASS_ERR_E    [错误码]
*/
static BYPASS_ERR_E ls_bp_set_light_status(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    cJSON* json_data = NULL;
    uint8_t force = 0;
    int ret = 0;
    ls_status_t status;
    ls_status_t temp_status ;
    uint8_t brightness = 0xff;
    cJSON* json_H = NULL;
    cJSON* json_S = NULL;
    ls_ev_t ev;
    ev.id = LS_EV_UNKNOWN;
    ev.act_src = LS_ACT_SRC_BYPASS;

    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    ls_get_status(&status);

    memset(&temp_status, 0xff, sizeof(ls_status_t));
    temp_status.multi_hsv = NULL;
    json_data = cJSON_GetObjectItemCaseSensitive(json, "force");
    if (NULL != json_data)
    {
        force = json_data->valueint;
    }
    else // force字段可选，没有时为0
    {
        force = 0;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "brightness");
    if (NULL != json_data)
    {
        VCOM_IN_RANGE_CHK(json_data->valueint, (force == 2 ? 0 : 1), LS_LED_V_RST, (ret++));
        brightness = json_data->valueint;
    }

    json_H = cJSON_GetObjectItemCaseSensitive(json, "hue");
    if (NULL != json_H)
    {
        VCOM_IN_RANGE_CHK(json_H->valueint, 0, LS_LED_HS_RST, (ret++));
        temp_status.hsvw.H = json_H->valueint;
    }

    json_S = cJSON_GetObjectItemCaseSensitive(json, "saturation");
    if (NULL != json_S)
    {
        VCOM_IN_RANGE_CHK(json_S->valueint, 0, LS_LED_HS_RST, (ret++));
        temp_status.hsvw.S = json_S->valueint;
    }

    if (ret > 0)
    {
        APP_LOG(LOG_ERROR,"HSV out of range !\n");
        return BP_ERR_ARG;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "sceneId");
    if (NULL != json_data)
    {
        if (json_data->valueint > LS_SCENE_CUSTOM_MAX_ID)
        {
            vesync_bypass_reply_pkg_err_msg(BP_ERR_PARA_ILLEGAL, p_msg_ctx->p_trace_msg, NULL);
            return BP_OK; // 避免回两次reply
        }

        ret = ls_scene_id_check(json_data->valueint);
        if (APP_OK != ret)  // 场景不存在
        {
            vesync_bypass_reply_pkg_err_msg(ret, p_msg_ctx->p_trace_msg, NULL);
            return BP_OK; // 避免回两次reply
        }

        temp_status.scene_id = json_data->valueint;
        APP_LOG(LOG_DEBUG,"scene id %d\n", temp_status.scene_id);
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "colorMode");
    if (NULL != json_data)  // APP 下发的指令
    {
        // colorMode != NULL
        status.status = true;
        if (!cJSON_IsString(json_data))
        {
            return BP_ERR_ARG;
        }

        if (0 == strcmp(json_data->valuestring, "white"))
        {
            status.mode = LS_MODE_WHITE;
        }
        else if (0 == strcmp(json_data->valuestring, "hsv"))
        {
                status.mode = LS_MODE_HSV;
        }
        else if (0 == strcmp(json_data->valuestring, "multiHsv"))
        {
            json_H = cJSON_GetObjectItemCaseSensitive(json, "cnt");
            json_S = cJSON_GetObjectItemCaseSensitive(json, "hsv");;

            if ((NULL !=json_S )&&(NULL !=json_H ))
            {
                if ((json_H->valueint > LED_NODE_MAX_NUM)||(LED_NODE_MIN_NUM > json_H->valueint))
                {
                    APP_LOG(LOG_ERROR,"cnt out of range !\n");
                    return BP_ERR_ARG;
                }

                temp_status.node_num = json_H->valueint;
                temp_status.multi_hsv = (ls_hsv_t *)vesync_malloc(sizeof(ls_hsv_t) * temp_status.node_num);
                if (NULL == temp_status.multi_hsv)
                {
                    APP_LOG(LOG_ERROR,"malloc fail!\n");
                    return BP_ERR_NOMEM;
                }

                status.mode = LS_MODE_MULTI_SEG;
                APP_LOG(LOG_DEBUG,"segment num:%d !\n", temp_status.node_num);
                for (int i = 0; i < temp_status.node_num ; i++)
                {
                    json_H = cJSON_GetArrayItem(json_S, i);
                    ret = 0;
                    if (NULL != json_H)
                    {
                        json_data = cJSON_GetArrayItem(json_H, 0);
                        temp_status.multi_hsv[i].H = json_data->valueint;
                        VCOM_IN_RANGE_CHK(json_data->valueint, 0, LS_LED_HS_RST, (ret++));
                        json_data = cJSON_GetArrayItem(json_H, 1);
                        temp_status.multi_hsv[i].S = json_data->valueint;
                        VCOM_IN_RANGE_CHK(json_data->valueint, 0, LS_LED_HS_RST, (ret++));
                        json_data = cJSON_GetArrayItem(json_H, 2);
                        temp_status.multi_hsv[i].V = json_data->valueint;
                        VCOM_IN_RANGE_CHK(json_data->valueint, 1, LS_LED_V_RST, (ret++));
                        if (ret > 0)
                        {
                            APP_LOG(LOG_ERROR,"multi hsv out of range !\n");
                            vesync_free(temp_status.multi_hsv);
                            return BP_ERR_ARG;
                        }
                    }
                    else
                    {
                        vesync_free(temp_status.multi_hsv);
                        return BP_ERR_ARG;
                    }
                }
            }
            else
            {
                return BP_ERR_ARG;
            }
        }
        else if (0 == strcmp(json_data->valuestring, "scenario"))
        {
            status.mode = LS_MODE_SCENE;
        }
        else
        {
            return BP_ERR_ARG;
        }
    }
    else  // 云和第三方的指令
    {
        // 模式选择
        if (status.status == true && force == 0)
        {
            // 开启状态下，force = 0，参数和模式不匹配
            if((status.mode != LS_MODE_HSV && temp_status.hsvw.H != 0xffff)
               || ((status.mode == LS_MODE_MULTI_SEG || status.mode == LS_MODE_SCENE) && brightness != 0xff))
            {
                vesync_bypass_reply_pkg_err_msg(BP_ERR_NOT_EXEC_IN_CUR_MODE, p_msg_ctx->p_trace_msg, NULL);
                return BP_OK;
            }
        }
        else if (force == 2)
        {
            if (status.status == false && brightness == LS_LED_V_RST)
            {
                status.status = true;
                if (s_ls_voice_off_flag == true)
                {
                    brightness = LS_LED_V_RST;
                }
                else
                {
                    brightness = (status.mode == LS_MODE_WHITE ? status.hsvw.white : status.hsvw.V);
                }
            }
            else if (status.status == true && brightness == 0)
            {
                if (status.mode != LS_MODE_WHITE && status.mode != LS_MODE_HSV)
                {
                    vesync_bypass_reply_noqos(BP_ERR_NOT_EXEC_IN_CUR_MODE, p_msg_ctx->p_trace_msg, NULL);
                    return BP_OK;
                }
                status.status = false;
                s_ls_voice_off_flag = true;
            }
            else
            {
                vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, NULL);
                return BP_OK;
            }
        }
        else
        {
            // 关闭状态下或者force= 1
            if (temp_status.hsvw.H != 0xffff)
            {
                // 传HS则改变模式，否则按原来模式开启
                status.mode = LS_MODE_HSV;
            }

            status.status = true;
        }
    }

    if (status.status == false)
    {
        ev.id = LS_EV_TURN_OFF;
        ev.scene_id = 0;
    }
    else
    {
        ev.id = LS_EV_TURN_ON;
        ev.mode = status.mode;
        ev.scene_id = 0;
        ls_get_scene_lock(true);
        // 仅用于修改node_num、hsvw、multi_hsv

        ls_status_t *pst_status = ls_get_status_pointer();
        switch(status.mode)
        {
            case LS_MODE_WHITE:
                status.hsvw.white = brightness != 0xff ? brightness : status.hsvw.white;
                pst_status->hsvw.white = status.hsvw.white;
                break;
            case LS_MODE_HSV:
                status.hsvw.H = temp_status.hsvw.H != 0xffff ? temp_status.hsvw.H : status.hsvw.H;
                status.hsvw.S = temp_status.hsvw.S != 0xffff ? temp_status.hsvw.S : status.hsvw.S;
                status.hsvw.V = brightness != 0xff ? brightness : status.hsvw.V;
                pst_status->hsvw.H = status.hsvw.H;
                pst_status->hsvw.S = status.hsvw.S;
                pst_status->hsvw.V = status.hsvw.V;
                break;
            case LS_MODE_MULTI_SEG:
                if (temp_status.node_num != 0xff && temp_status.node_num != status.node_num)
                {
                    // 异常情况
                    status.node_num = temp_status.node_num;
                    pst_status->node_num = status.node_num;
                    ls_led_set_led_num(status.node_num);
                }

                ev.id = LS_EV_TURN_ON;
                if (temp_status.multi_hsv != NULL)
                {
                    memcpy(pst_status->multi_hsv, temp_status.multi_hsv, sizeof(ls_hsv_t) * status.node_num);
                    VCOM_SAFE_FREE(temp_status.multi_hsv);
                }
                break;
            case LS_MODE_SCENE:
                status.scene_id = temp_status.scene_id != 0xffff ? temp_status.scene_id : status.scene_id;
                ev.scene_id = status.scene_id;
                break;
            default:
                break;
        }

        ls_get_scene_lock(false);
     }

    if (LS_EV_UNKNOWN != ev.id)
    {
        APP_LOG(LOG_INFO, "id %d mode : %d scene_id : %d\n", ev.id,ev.mode, ev.scene_id);
        ls_app_task_notify(&ev);
    }

    ls_report_set_chg_rsn(p_msg_ctx->p_trace_msg->src_type);
    // 回复led状态数据
    cJSON *json_result = NULL;
    json_result = cJSON_CreateObject();
    if (NULL== json_result)
    {
        vesync_bypass_reply_pkg_err_msg(BP_ERR_OUT_OF_MEMORY, p_msg_ctx->p_trace_msg, NULL);
    }
    else
    {
        ls_bp_light_status_json_marshal(&status, json_result);
        vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, json_result);
    }

    return BP_OK;
}

/**
* @brief 获取灯状态
* @param[in]        p_msg_ctx       [msg context]
* @param[in]        json            [传入json]
* @return           BYPASS_ERR_E    [错误码]
*/
static BYPASS_ERR_E ls_bp_get_light_status(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    cJSON *json_result = NULL;
    cJSON *json_extension = NULL;
    ls_status_t hsv_info;
    cJSON *array = NULL;
    cJSON *hsv = NULL;
    int ret = BP_OK;
    int  temp_color[3] = {0, 0, 0};

    ls_get_status(&hsv_info);

    json_result = cJSON_CreateObject();
    if (NULL== json_result)
    {
        ret =  BP_ERR_NOMEM;
        goto EXIT;
    }

    if (hsv_info.status == false)
    {
        cJSON_AddStringToObject(json_result, "enabled", "off");
    }
    else
    {
        cJSON_AddStringToObject(json_result, "enabled", "on");
    }

    switch(hsv_info.mode)
    {
        case LS_MODE_SCENE:
            cJSON_AddStringToObject(json_result, "colorMode", "scenario");
            break;
        case LS_MODE_MULTI_SEG:
            cJSON_AddStringToObject(json_result, "colorMode", "multiHsv");
            break;
        case LS_MODE_HSV:
            cJSON_AddStringToObject(json_result, "colorMode", "hsv");
            break;
        case LS_MODE_WHITE:
            cJSON_AddStringToObject(json_result, "colorMode", "white");
            break;
        default:
            break;
    }
    cJSON_AddNumberToObject(json_result, "cnt", hsv_info.node_num);
    cJSON_AddNumberToObject(json_result, "sceneId", hsv_info.scene_id);
    hsv = cJSON_AddArrayToObject(json_result, "hsv");
    if(NULL == hsv )
    {
        APP_LOG(LOG_ERROR, "Create object fail\n");
        ret =  BP_ERR_NOMEM;
        goto EXIT;
    }

    for (int i = 0; i < hsv_info.node_num; i++)
    {
        temp_color[0] = hsv_info.multi_hsv[i].H ;
        temp_color[1] = hsv_info.multi_hsv[i].S;
        temp_color[2] = hsv_info.multi_hsv[i].V;
        array = cJSON_CreateIntArray(temp_color, 3);
        if(NULL == array )
        {
            APP_LOG(LOG_ERROR, "Create array fail\n");
            ret =  BP_ERR_NOMEM;
            goto EXIT;
        }
        cJSON_AddItemToArray(hsv, array);
    }

    cJSON_AddNumberToObject(json_result, "hue", hsv_info.hsvw.H);
    cJSON_AddNumberToObject(json_result, "saturation", hsv_info.hsvw.S);
    cJSON_AddNumberToObject(json_result, "value", hsv_info.hsvw.V);
    cJSON_AddNumberToObject(json_result, "brightness", hsv_info.hsvw.white);

    cJSON_AddItemToObject(json_result, "extension", json_extension = cJSON_CreateObject());
    if (json_extension == NULL)
    {
        cJSON_Delete(json_result);
        vesync_bypass_reply_pkg_err_msg(BP_ERR_OUT_OF_MEMORY, p_msg_ctx->p_trace_msg, NULL);
        return BP_ERR_NOMEM;
    }

    uint32_t next_sch_sec = 0;
    vesync_schedule_get_next_exc_sec(LS_SCHE_INS_ID, &next_sch_sec);
    cJSON_AddNumberToObject(json_extension, "rctSchOffsec", next_sch_sec);
    cJSON_AddNumberToObject(json_extension, "timerRemain", vesync_timing_get_remain_sec(LS_TIMER_MIN_ID));
    vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, json_result);
EXIT:
    if (BP_OK == ret)
    {
        vesync_bypass_reply_noqos(BP_OK, p_msg_ctx->p_trace_msg, json_result);
    }

    return ret;
}

/**
* @brief 增加场景
* @param[in]        p_msg_ctx       [msg context]
* @param[in]        json            [传入json]
* @return           BYPASS_ERR_E    [错误码]
*/
static BYPASS_ERR_E ls_bp_add_light_scene(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    cJSON* json_result = NULL;
    uint16_t scene_id = 0;
    ls_ev_t ev;
    ev.id = LS_EV_ADD_SCENE;
    ev.act_src = LS_ACT_SRC_BYPASS;
    ls_status_t status;
    int ret = BP_OK;

    if (NULL == p_msg_ctx || NULL == p_msg_ctx->p_trace_msg)
    {
        APP_LOG(LOG_ERROR, " error \n");
        return BP_ERROR;
    }

    json_result = cJSON_CreateObject();
    if (NULL== json_result)
    {
        ret =  BP_ERR_OUT_OF_MEMORY;
        goto EXIT;
    }

    ls_get_status(&status);
    if (status.mode == LS_MODE_OFF || status.mode == LS_MODE_SCENE)
    {
        ret = BP_ERR_NOT_EXEC_IN_CUR_MODE;
        goto EXIT;
    }

    if (status.custom_scene_num >= LS_CUSTOM_SCENE_MAX_NUM)
    {
        ret = BP_ERR_VALUE_OUT_OF_RANGE;
        goto EXIT;
    }

    scene_id = ls_gen_new_scene_id(status.custom_scene_num);
    if (0 != scene_id)
    {
        cJSON_AddNumberToObject(json_result, "sceneId", scene_id);
        ev.scene_id = scene_id;
        ls_app_task_notify(&ev);
    }
    else
    {
        ret = BP_ERR_CMD_EXECUTE_FAIL;
    }

    ls_wait_scene_sem();
    if (APP_OK != ls_scene_id_check(scene_id))
    {
        ret = BP_ERR_VALUE_OUT_OF_RANGE;
        APP_LOG(LOG_ERROR, "add scene failed ! \n");
    }

EXIT:
    if (BP_OK == ret)
    {
        vesync_bypass_reply_noqos(BP_OK, p_msg_ctx->p_trace_msg, json_result);
    }
    else
    {
        vesync_bypass_reply_pkg_err_msg(ret, p_msg_ctx->p_trace_msg, NULL);
        if (NULL != json_result)
        {
            cJSON_Delete(json_result);
        }
    }

    return BP_OK;  // 避免回两次 reply
}

/**
* @brief 删除场景
* @param[in]        p_msg_ctx       [msg context]
* @param[in]        json            [传入json]
* @return           BYPASS_ERR_E    [错误码]
*/
static BYPASS_ERR_E ls_bp_del_light_scene(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    cJSON* json_data = NULL;
    int ret = BP_OK;
    ls_ev_t ev;
    ev.id = LS_EV_DEL_SCENE;
    ev.act_src = LS_ACT_SRC_BYPASS;

    if (NULL == p_msg_ctx || NULL == p_msg_ctx->p_trace_msg || NULL == json)
    {
        APP_LOG(LOG_DEBUG, "error \n");
        return BP_ERROR;
    }
    json_data = cJSON_GetObjectItemCaseSensitive(json, "sceneId");
    if (NULL != json_data)
    {
        if (json_data->valueint < LS_SCENE_CUSTOM_MIN_ID || json_data->valueint > LS_SCENE_CUSTOM_MAX_ID)
        {
            vesync_bypass_reply_pkg_err_msg(BP_ERR_PARA_ILLEGAL, p_msg_ctx->p_trace_msg, NULL);
            return BP_OK; // 避免回两次reply
        }

        ret = ls_scene_id_check(json_data->valueint);
        if (APP_OK != ret)  // 场景不存在
        {
            vesync_bypass_reply_pkg_err_msg(ret, p_msg_ctx->p_trace_msg, NULL);
            return BP_OK; // 避免回两次reply
        }


        ev.scene_id = json_data->valueint;
        ls_app_task_notify(&ev);
    }
    else
    {
        ret = BP_ERR_PARA_ILLEGAL;
    }

    vesync_bypass_reply_pkg_err_msg(ret, p_msg_ctx->p_trace_msg, NULL);
    ls_report_set_chg_rsn(p_msg_ctx->p_trace_msg->src_type);

    return BP_OK; // 避免回两次 reply
}

/**
* @brief 获取自定义场景列表
* @param[in]        p_msg_ctx       [msg context]
* @param[in]        json            [传入json]
* @return           BYPASS_ERR_E    [错误码]
*/
static BYPASS_ERR_E ls_bp_get_light_scene(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    cJSON* json_result = NULL;
    cJSON* json_array = NULL;
    int ret = BP_OK;
    uint16_t *id_list = NULL;
    int *list = NULL;
    ls_status_t status;

    if (NULL == p_msg_ctx || NULL == p_msg_ctx->p_trace_msg)
    {
        APP_LOG(LOG_DEBUG, "error \n");
        return BP_ERROR;
    }
    ls_get_status(&status);
    id_list = ls_get_id_list();
    json_result = cJSON_CreateObject();
    if (NULL== json_result)
    {
        ret =  BP_ERR_OUT_OF_MEMORY;
        goto EXIT;
    }

    cJSON_AddNumberToObject(json_result, "total", status.custom_scene_num);
    if (0 < status.custom_scene_num)
    {
        list = (int *) vesync_malloc(4 * status.custom_scene_num);
        if (NULL== list)
        {
            ret =  BP_ERR_OUT_OF_MEMORY;
            goto EXIT;
        }

        for (uint8_t i = 0; i < status.custom_scene_num; i++)
        {
            list[i] = id_list[i];
        }

        json_array = cJSON_CreateIntArray(list, status.custom_scene_num);;
        if (NULL== json_array)
        {
            ret =  BP_ERR_OUT_OF_MEMORY;
            goto EXIT;
        }
        else
        {
            cJSON_AddItemToObject(json_result, "scenes",json_array);
        }
    }
EXIT:
    if (BP_OK == ret)
    {
        vesync_bypass_reply_noqos(BP_OK, p_msg_ctx->p_trace_msg, json_result);
    }
    else
    {
        vesync_bypass_reply_pkg_err_msg(ret, p_msg_ctx->p_trace_msg, NULL);
        if (NULL != json_result)
        {
            cJSON_Delete(json_result);
        }
    }

    VCOM_SAFE_FREE(list);
    return BP_OK;
}

/**
* @brief 设置灯带灯珠数量
* @param[in]        p_msg_ctx       [msg context]
* @param[in]        json            [传入json]
* @return           BYPASS_ERR_E    [错误码]
*/
static BYPASS_ERR_E ls_bp_set_led_num(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    ls_ev_t ev;
    ev.id = LS_EV_SET_NODE_NUM;
    ev.act_src = LS_ACT_SRC_BYPASS;
    cJSON* json_data = NULL;
    int ret = BP_OK;

    if (NULL == p_msg_ctx || NULL == p_msg_ctx->p_trace_msg || NULL == json)
    {
        APP_LOG(LOG_DEBUG, "error \n");
        return BP_ERROR;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "lightBeadsSize");
    if ((NULL != json_data)&&(json_data->valueint <= LED_NODE_MAX_NUM )&&(json_data->valueint >= LED_NODE_MIN_NUM))
    {
        ls_get_scene_lock(true);
        // 仅用于修改node_num、hsvw、multi_hsv
        ls_status_t *pst_status = ls_get_status_pointer();
        pst_status->node_num = json_data->valueint;
        ls_get_scene_lock(false);
    }
    else
    {
        ret = BP_ERR_PARA_ILLEGAL;
    }

    if (BP_OK == ret)
    {
        vesync_bypass_reply_noqos(BP_OK, p_msg_ctx->p_trace_msg, NULL);
    }
    else
    {
        vesync_bypass_reply_pkg_err_msg(ret, p_msg_ctx->p_trace_msg, NULL);
    }

    ls_app_task_notify(&ev);
    ls_report_set_chg_rsn(p_msg_ctx->p_trace_msg->src_type);
    return BP_OK;
}

/**
* @brief 获取灯带灯珠数量
* @param[in]        p_msg_ctx       [msg context]
* @param[in]        json            [传入json]
* @return           BYPASS_ERR_E    [错误码]
*/
static BYPASS_ERR_E ls_bp_get_led_num(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    cJSON* json_result = NULL;
    ls_status_t status;

    if (NULL == p_msg_ctx || NULL == p_msg_ctx->p_trace_msg)
    {
        APP_LOG(LOG_DEBUG, "error \n");
        return BP_ERROR;
    }

    ls_get_status(&status);
    json_result = cJSON_CreateObject();
    if (NULL== json_result)
    {
        vesync_bypass_reply_pkg_err_msg(BP_ERR_OUT_OF_MEMORY, p_msg_ctx->p_trace_msg, NULL);
        return BP_OK;
    }

    cJSON_AddNumberToObject(json_result, "lightBeadsSize", status.node_num);
    vesync_bypass_reply_noqos(BP_OK, p_msg_ctx->p_trace_msg, json_result);
    return BP_OK;
}


static bypass_user_data_t ls_method_tbl[] = {
    // timer
    {"addTimerV2", ls_bp_add_timer},
    {"getTimerV2", ls_bp_get_timer},
    {"delTimerV2", ls_bp_del_timer},
    {"setLightStatusV2",ls_bp_set_light_status},
    {"getLightStatusV2",ls_bp_get_light_status},
    {"addScene", ls_bp_add_light_scene},
    {"getScenes",  ls_bp_get_light_scene},
    {"delScene", ls_bp_del_light_scene},
    {"setLightBeadsSize",ls_bp_set_led_num},
    {"getLightBeadsSize",ls_bp_get_led_num}
};

/**
* @brief 注册bypass回调函数
*/
void ls_bypass_reg_cb(void)
{
    // LED
    vesync_bypass_reg_method_cb(BYPASS_METHOD_ID_SET_SWITCH, ls_bp_set_switch_onoff);
    vesync_bypass_reg_method_cb(BYPASS_METHOD_ID_TOGGLE_SWITCH, ls_bp_toggle);
    // addjustPercent
    vesync_bypass_reg_method_cb(BYPASS_METHOD_ID_ADJUST_PERCENT, ls_bp_adjust_percent);
    // Schedule
    vesync_bypass_reg_method_cb(BYPASS_METHOD_ID_ADD_SCHEDULE_V3, ls_bp_add_schedule);
    vesync_bypass_reg_method_cb(BYPASS_METHOD_ID_UPD_SCHEDULE_V3, ls_bp_upd_schedule);
    vesync_bypass_reg_method_cb(BYPASS_METHOD_ID_DEL_SCHEDULE_V3, ls_bp_del_schedule);
    vesync_bypass_reg_method_cb(BYPASS_METHOD_ID_GET_SCHEDULES_V3, ls_bp_get_schedules);

    for (int i = 0; i < SIZEOF_ARRAY(ls_method_tbl); i++)
    {
        vesync_bypass_add_user_item(&ls_method_tbl[i]);
    }

}

