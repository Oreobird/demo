/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_light_test.cpp
 * @brief       vesync light测试用例
 * @author      Herve
 * @date        2021-11-12
 */

#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <gtest/gtest.h>
#include <time.h>

#include "vhal_utils.h"
#include "vesync_timer.h"

#include "vesync_log_internal.h"
#include "vesync_light_internal.h"

#include "stub.h"
#include "vesync_light.c"

enum
{
    LIGHT_CH_IDX_0 = 0,
    LIGHT_CH_IDX_1 = 1,
    LIGHT_CH_IDX_2 = 2,
    LIGHT_CH_IDX_3 = 3,
    LIGHT_CH_IDX_4 = 4,
    LIGHT_CH_IDX_MAX,
};
class vesync_light_test : public testing::Test
{
public:
    vesync_light_t light;

    static bool is_timer_task_start;
    static bool is_timer_start;
    static uint32_t ch1_duty_out;

private:
    static Stub stub;
    static int timer_task_start_mock(void);
    static int timer_task_stop_mock(void);
    static void *timer_new_mock(bool, uint32_t, light_timer_cb_t, void *);
    static int timer_start_mock(void *);
    static int timer_stop_mock(void *);
    static int timer_del_mock(void *);
    static void channel_ctrl_cb(void *, uint16_t, uint32_t *);

protected:
    static void SetUpTestCase()
    {
        vesync_log_init();

        int ret;
        stub.set(light_timer_task_start, timer_task_start_mock);
        stub.set(light_timer_task_stop, timer_task_stop_mock);
        stub.set(light_timer_new, timer_new_mock);
        stub.set(light_timer_start, timer_start_mock);
        stub.set(light_timer_stop, timer_stop_mock);
        stub.set(light_timer_del, timer_del_mock);

        EXPECT_TRUE(vesync_light_create(5, 20, 2048, channel_ctrl_cb, NULL) == nullptr);
        EXPECT_TRUE(vesync_light_create(0, 20, 2048, channel_ctrl_cb, NULL) == nullptr);
        EXPECT_TRUE(vesync_light_create(2, 20, 2048, NULL, NULL) == nullptr);

        ret = vesync_light_init();
        EXPECT_EQ(ret, LIGHT_OK);
        EXPECT_EQ(is_timer_task_start, true);

        ret = vesync_light_init();
        EXPECT_EQ(ret, LIGHT_IS_INIT);
    }

    virtual void SetUp()
    {
        this->ch1_duty_out = 0;
        this->light = nullptr;

        this->light = vesync_light_create(5, 20, 2048, this->channel_ctrl_cb, NULL);
        EXPECT_TRUE(this->light != nullptr);
    }

    virtual void TearDown()
    {
        int ret;

        ret = vesync_light_destroy(this->light);
        EXPECT_EQ(ret, LIGHT_OK);
    }

    static void TearDownTestCase()
    {
        int ret;

        ret = vesync_light_deinit();
        EXPECT_EQ(ret, LIGHT_OK);
        EXPECT_EQ(is_timer_task_start, false);

        ret = vesync_light_deinit();
        EXPECT_EQ(ret, LIGHT_NO_INIT);

        stub.reset(light_timer_task_start);
        stub.reset(light_timer_task_stop);
        stub.reset(light_timer_new);
        stub.reset(light_timer_start);
        stub.reset(light_timer_stop);
        stub.reset(light_timer_del);

        vesync_log_deinit();
    }
};

bool vesync_light_test::is_timer_task_start = false;
bool vesync_light_test::is_timer_start = false;
uint32_t vesync_light_test::ch1_duty_out;

Stub vesync_light_test::stub;

int vesync_light_test::timer_task_start_mock(void)
{
    is_timer_task_start = true;
    return LIGHT_OK;
}

int vesync_light_test::timer_task_stop_mock(void)
{
    is_timer_task_start = false;
    return LIGHT_OK;
}

void *vesync_light_test::timer_new_mock(bool reload, uint32_t intvl_ms, light_timer_cb_t cb, void *arg)
{
    SDK_LOG(LOG_DEBUG, "new timer\n");

    vesync_timer_t *ptr = vesync_timer_new("light_timer",
                                           cb,
                                           arg,
                                           (long)(intvl_ms),
                                           reload);
    return (void *)ptr;
}

int vesync_light_test::timer_start_mock(void *p_tmr)
{
    SDK_LOG(LOG_DEBUG, "start timer\n");

    int ret = vesync_timer_start((vesync_timer_t *)p_tmr);
    if (ret != 0)
    {
        return LIGHT_ERR;
    }
    is_timer_start = true;
    return LIGHT_OK;
}

int vesync_light_test::timer_stop_mock(void *p_tmr)
{
    SDK_LOG(LOG_DEBUG, "stop timer\n");

    int ret = vesync_timer_stop((vesync_timer_t *)p_tmr);
    if (ret != 0)
    {
        return LIGHT_ERR;
    }
    is_timer_start = false;
    return LIGHT_OK;
}

int vesync_light_test::timer_del_mock(void *p_tmr)
{
    int ret = vesync_timer_free((vesync_timer_t *)p_tmr);
    if (ret != 0)
    {
        return LIGHT_ERR;
    }
    return LIGHT_OK;
}

void vesync_light_test::channel_ctrl_cb(void *opt, uint16_t ch_num, uint32_t *duty)
{
    SDK_LOG(LOG_WARN, "%lld: %d\n", vhal_utils_get_system_time_ms_int(), duty[LIGHT_CH_IDX_4]);
    ch1_duty_out = duty[LIGHT_CH_IDX_4];
}

TEST_F(vesync_light_test, vesync_light_fade_with_time_cfg_test)
{
    int ret;

    ret = vesync_light_fade_with_time_cfg(this->light, LIGHT_CH_IDX_4, 1.0, 200, 0);
    EXPECT_EQ(ret, LIGHT_OK);
    ret = vesync_light_start(this->light, LIGHT_CH_IDX_4);
    EXPECT_EQ(ret, LIGHT_OK);
    vesync_sleep(500);

    // Set the channel to zero
    ret = vesync_light_fade_with_time_cfg(this->light, LIGHT_CH_IDX_4, 0, 0, 0);
    EXPECT_EQ(ret, LIGHT_OK);
    ret = vesync_light_start(this->light, LIGHT_CH_IDX_4);
    EXPECT_EQ(ret, LIGHT_OK);
    vesync_sleep(10);

    SDK_LOG(LOG_DEBUG, "-----gamma 0.8-----\n");

    ret = vesync_light_set_gamma(this->light, LIGHT_CH_IDX_4, 0.8);
    EXPECT_EQ(ret, LIGHT_OK);

    ret = vesync_light_fade_with_time_cfg(this->light, LIGHT_CH_IDX_4, 1.0, 200, 0);
    EXPECT_EQ(ret, LIGHT_OK);
    ret = vesync_light_start(this->light, LIGHT_CH_IDX_4);
    EXPECT_EQ(ret, LIGHT_OK);
    vesync_sleep(500);

    // Set the channel to zero
    ret = vesync_light_fade_with_time_cfg(this->light, LIGHT_CH_IDX_4, 0, 0, 0);
    EXPECT_EQ(ret, LIGHT_OK);
    ret = vesync_light_start(this->light, LIGHT_CH_IDX_4);
    EXPECT_EQ(ret, LIGHT_OK);
    vesync_sleep(10);

    SDK_LOG(LOG_DEBUG, "-----gamma 0.6-----\n");

    ret = vesync_light_set_gamma(this->light, LIGHT_CH_IDX_4, 0.6);
    EXPECT_EQ(ret, LIGHT_OK);

    ret = vesync_light_fade_with_time_cfg(this->light, LIGHT_CH_IDX_4, 1.0, 200, 0);
    EXPECT_EQ(ret, LIGHT_OK);
    ret = vesync_light_start(this->light, LIGHT_CH_IDX_4);
    EXPECT_EQ(ret, LIGHT_OK);
    vesync_sleep(500);

    // Set the channel to zero
    ret = vesync_light_fade_with_time_cfg(this->light, LIGHT_CH_IDX_4, 0, 0, 0);
    EXPECT_EQ(ret, LIGHT_OK);
    ret = vesync_light_start(this->light, LIGHT_CH_IDX_4);
    EXPECT_EQ(ret, LIGHT_OK);
    vesync_sleep(10);

    SDK_LOG(LOG_DEBUG, "-----gamma 2.2-----\n");

    ret = vesync_light_set_gamma(this->light, LIGHT_CH_IDX_4, 2.2);
    EXPECT_EQ(ret, LIGHT_OK);

    ret = vesync_light_fade_with_time_cfg(this->light, LIGHT_CH_IDX_4, 1.0, 200, 0);
    EXPECT_EQ(ret, LIGHT_OK);
    ret = vesync_light_start(this->light, LIGHT_CH_IDX_4);
    EXPECT_EQ(ret, LIGHT_OK);
    vesync_sleep(500);

    ret = vesync_light_set_gamma(this->light, LIGHT_CH_IDX_4, 1.0);
    EXPECT_EQ(ret, LIGHT_OK);

    SDK_LOG(LOG_DEBUG, "----------\n");

    ret = vesync_light_fade_with_time_cfg(this->light, LIGHT_CH_IDX_4, 0, 200, 0);
    EXPECT_EQ(ret, LIGHT_OK);
    ret = vesync_light_start(this->light, LIGHT_CH_IDX_4);
    EXPECT_EQ(ret, LIGHT_OK);
    vesync_sleep(500);

    SDK_LOG(LOG_DEBUG, "----------\n");

    ret = vesync_light_fade_with_time_cfg(this->light, LIGHT_CH_IDX_4, 1.0, 800, 0);
    EXPECT_EQ(ret, LIGHT_OK);
    ret = vesync_light_start(this->light, LIGHT_CH_IDX_4);
    EXPECT_EQ(ret, LIGHT_OK);
    vesync_sleep(1000);

    SDK_LOG(LOG_DEBUG, "----------\n");

    ret = vesync_light_fade_with_time_cfg(this->light, LIGHT_CH_IDX_4, 0, 800, 0);
    EXPECT_EQ(ret, LIGHT_OK);
    ret = vesync_light_start(this->light, LIGHT_CH_IDX_4);
    EXPECT_EQ(ret, LIGHT_OK);
    vesync_sleep(1000);

    SDK_LOG(LOG_DEBUG, "----------\n");

    ret = vesync_light_fade_with_time_cfg(this->light, LIGHT_CH_IDX_4, 1.0, 500, 0);
    EXPECT_EQ(ret, LIGHT_OK);
    ret = vesync_light_start(this->light, LIGHT_CH_IDX_4);
    EXPECT_EQ(ret, LIGHT_OK);
    vesync_sleep(250);

    ret = vesync_light_fade_with_time_cfg(this->light, LIGHT_CH_IDX_4, 0, 500, 0);
    EXPECT_EQ(ret, LIGHT_OK);
    ret = vesync_light_start(this->light, LIGHT_CH_IDX_4);
    EXPECT_EQ(ret, LIGHT_OK);
    vesync_sleep(250);

    ret = vesync_light_fade_with_time_cfg(this->light, LIGHT_CH_IDX_4, 1.0, 500, 0);
    EXPECT_EQ(ret, LIGHT_OK);
    ret = vesync_light_start(this->light, LIGHT_CH_IDX_4);
    EXPECT_EQ(ret, LIGHT_OK);
    vesync_sleep(750);

    EXPECT_EQ(ret, LIGHT_OK);
}

TEST_F(vesync_light_test, vesync_light_fade_with_step_cfg_test)
{
    int ret;

    ret = vesync_light_fade_with_step_cfg(this->light, LIGHT_CH_IDX_4, 1.0, 0.1, 0);
    EXPECT_EQ(ret, LIGHT_OK);
    ret = vesync_light_start(this->light, LIGHT_CH_IDX_4);
    EXPECT_EQ(ret, LIGHT_OK);
    vesync_sleep(500);

    ret = vesync_light_fade_with_step_cfg(this->light, LIGHT_CH_IDX_4, 0.5, 0.1, 0);
    EXPECT_EQ(ret, LIGHT_OK);
    ret = vesync_light_start(this->light, LIGHT_CH_IDX_4);
    EXPECT_EQ(ret, LIGHT_OK);
    vesync_sleep(500);

    SDK_LOG(LOG_DEBUG, "----------\n");

    // 步速大于减量测试
    ret = vesync_light_fade_with_step_cfg(this->light, LIGHT_CH_IDX_4, 0, 0.5 + 0.1, 0);
    EXPECT_EQ(ret, LIGHT_OK);
    ret = vesync_light_start(this->light, LIGHT_CH_IDX_4);
    EXPECT_EQ(ret, LIGHT_OK);
    vesync_sleep(500);

    // 步速大于增量测试
    ret = vesync_light_fade_with_step_cfg(this->light, LIGHT_CH_IDX_4, 0.1, 0.1 + 0.1, 0);
    EXPECT_EQ(ret, LIGHT_OK);
    ret = vesync_light_start(this->light, LIGHT_CH_IDX_4);
    EXPECT_EQ(ret, LIGHT_OK);
    vesync_sleep(500);

    // 清零
    ret = vesync_light_fade_with_step_cfg(this->light, LIGHT_CH_IDX_4, 0.0, 0.2, 0);
    EXPECT_EQ(ret, LIGHT_OK);
    ret = vesync_light_start(this->light, LIGHT_CH_IDX_4);
    EXPECT_EQ(ret, LIGHT_OK);
    vesync_sleep(100);

    SDK_LOG(LOG_DEBUG, "----------\n");

    // 25步，500ms完成渐变测试
    ret = vesync_light_fade_with_step_cfg(this->light, LIGHT_CH_IDX_4, 1.0, 1.0 / 25, 0);
    EXPECT_EQ(ret, LIGHT_OK);
    ret = vesync_light_start(this->light, LIGHT_CH_IDX_4);
    EXPECT_EQ(ret, LIGHT_OK);
    vesync_sleep(100);
    SDK_LOG(LOG_DEBUG, "---------- 100ms passed -------------\n");
    vesync_sleep(200);
    SDK_LOG(LOG_DEBUG, "---------- 300ms passed -------------\n");
    vesync_sleep(200);
    SDK_LOG(LOG_DEBUG, "---------- 500ms passed -------------\n");
    vesync_sleep(100);

    // 一样步速，250ms完成渐变测试
    ret = vesync_light_fade_with_step_cfg(this->light, LIGHT_CH_IDX_4, 0.5, 1.0 / 25, 0);
    EXPECT_EQ(ret, LIGHT_OK);
    ret = vesync_light_start(this->light, LIGHT_CH_IDX_4);
    EXPECT_EQ(ret, LIGHT_OK);
    vesync_sleep(100);
    SDK_LOG(LOG_DEBUG, "---------- 100ms passed -------------\n");
    vesync_sleep(100);
    SDK_LOG(LOG_DEBUG, "---------- 200ms passed -------------\n");
    vesync_sleep(50);
    SDK_LOG(LOG_DEBUG, "---------- 250ms passed -------------\n");
    vesync_sleep(100);
}

TEST_F(vesync_light_test, vesync_light_blink_test)
{
    int ret;

    ret = vesync_light_blink_cfg(this->light, LIGHT_CH_IDX_4, 0.5, 300, 0, 0);
    EXPECT_EQ(ret, LIGHT_OK);
    ret = vesync_light_start(this->light, LIGHT_CH_IDX_4);
    EXPECT_EQ(ret, LIGHT_OK);
    vesync_sleep(1000);

    SDK_LOG(LOG_DEBUG, "---------- repeat once, gamma: 0.8 -------------\n");

    ret = vesync_light_set_gamma(this->light, LIGHT_CH_IDX_4, 0.8);
    EXPECT_EQ(ret, LIGHT_OK);

    ret = vesync_light_blink_cfg(this->light, LIGHT_CH_IDX_4, 0.5, 300, 0, 2);
    EXPECT_EQ(ret, LIGHT_OK);
    ret = vesync_light_start(this->light, LIGHT_CH_IDX_4);
    EXPECT_EQ(ret, LIGHT_OK);
    vesync_sleep(1000);

    ret = vesync_light_stop(this->light, LIGHT_CH_IDX_4);
    EXPECT_EQ(ret, LIGHT_OK);
}

TEST_F(vesync_light_test, vesync_light_breath_test)
{
    int ret;

    ret = vesync_light_breath_cfg(this->light, LIGHT_CH_IDX_4, 0.5, 200, 0, 0);
    EXPECT_EQ(ret, LIGHT_OK);
    ret = vesync_light_start(this->light, LIGHT_CH_IDX_4);
    EXPECT_EQ(ret, LIGHT_OK);
    vesync_sleep(1000);

    SDK_LOG(LOG_DEBUG, "---------- gamma: 0.8 -------------\n");

    ret = vesync_light_set_gamma(this->light, LIGHT_CH_IDX_4, 0.8);
    EXPECT_EQ(ret, LIGHT_OK);

    ret = vesync_light_breath_cfg(this->light, LIGHT_CH_IDX_4, 0.5, 200, 0, 0);
    EXPECT_EQ(ret, LIGHT_OK);
    ret = vesync_light_start(this->light, LIGHT_CH_IDX_4);
    EXPECT_EQ(ret, LIGHT_OK);
    vesync_sleep(1000);
    ret = vesync_light_stop(this->light, LIGHT_CH_IDX_4);
    EXPECT_EQ(ret, LIGHT_OK);

    ret = vesync_light_set_gamma(this->light, LIGHT_CH_IDX_4, 1.0);
    EXPECT_EQ(ret, LIGHT_OK);

    SDK_LOG(LOG_DEBUG, "---------- one semicycle -------------\n");

    ret = vesync_light_breath_cfg(this->light, LIGHT_CH_IDX_4, 0.5, 200, 0, 1);
    EXPECT_EQ(ret, LIGHT_OK);
    ret = vesync_light_start(this->light, LIGHT_CH_IDX_4);
    EXPECT_EQ(ret, LIGHT_OK);
    vesync_sleep(1000);
    ret = vesync_light_stop(this->light, LIGHT_CH_IDX_4);
    EXPECT_EQ(ret, LIGHT_OK);

    SDK_LOG(LOG_DEBUG, "---------- two semicycle -------------\n");
    ret = vesync_light_breath_cfg(this->light, LIGHT_CH_IDX_4, 1.0, 200, 0, 2);
    EXPECT_EQ(ret, LIGHT_OK);
    ret = vesync_light_start(this->light, LIGHT_CH_IDX_4);
    EXPECT_EQ(ret, LIGHT_OK);
    vesync_sleep(1000);
    ret = vesync_light_stop(this->light, LIGHT_CH_IDX_4);
    EXPECT_EQ(ret, LIGHT_OK);

    SDK_LOG(LOG_DEBUG, "---------- three semicycle -------------\n");
    ret = vesync_light_breath_cfg(this->light, LIGHT_CH_IDX_4, 1.0, 200, 0, 3);
    EXPECT_EQ(ret, LIGHT_OK);
    ret = vesync_light_start(this->light, LIGHT_CH_IDX_4);
    EXPECT_EQ(ret, LIGHT_OK);
    vesync_sleep(1000);
    ret = vesync_light_stop(this->light, LIGHT_CH_IDX_4);
    EXPECT_EQ(ret, LIGHT_OK);

    SDK_LOG(LOG_DEBUG, "---------- delay test -------------\n");
    ret = vesync_light_breath_cfg(this->light, LIGHT_CH_IDX_4, 0.8, 200, 300, 0);
    EXPECT_EQ(ret, LIGHT_OK);
    ret = vesync_light_start(this->light, LIGHT_CH_IDX_4);
    EXPECT_EQ(ret, LIGHT_OK);
    vesync_sleep(100);
    SDK_LOG(LOG_DEBUG, "---------- 100ms passed -------------\n");
    vesync_sleep(100);
    SDK_LOG(LOG_DEBUG, "---------- 200ms passed -------------\n");
    vesync_sleep(100);
    SDK_LOG(LOG_DEBUG, "---------- 300ms passed -------------\n");
    vesync_sleep(500);
    ret = vesync_light_stop(this->light, LIGHT_CH_IDX_4);
    EXPECT_EQ(ret, LIGHT_OK);
}
