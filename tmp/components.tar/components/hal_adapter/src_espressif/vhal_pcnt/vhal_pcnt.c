/**
 *  Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vhal_pcnt.c
 * @brief       乐鑫平台pcnt接口封装
 * @author      Dongri.Su
 * @date        2021-04-22
 */

#include "soc/pcnt_caps.h"
#include "driver/pcnt.h"

#include "vesync_log.h"
#include "vesync_common.h"

#include "vhal_pcnt.h"


/*-----------------------------------------------------------------------------*
 *                           内部函数API实现                                         *
 *-----------------------------------------------------------------------------*/

/*
 * @brief pcnt ctrl mode转换
 * @param[in]  pcnt_ctrl_mode           [HAL层封装的pcnt ctrl mode]
 * @return     pcnt_ctrl_mode_t         [转换为SDK定义的pcnt ctrl mode]
 */
static pcnt_ctrl_mode_t vhal_pcnt_conv_ctrl_mode(PCNT_CTRL_MODE_E pcnt_ctrl_mode)
{
    switch (pcnt_ctrl_mode)
    {
        case VHAL_PCNT_MODE_KEEP:
            return PCNT_MODE_KEEP;
        case VHAL_PCNT_MODE_REVERSE:
            return PCNT_MODE_REVERSE;
        case VHAL_PCNT_MODE_DISABLE:
            return PCNT_MODE_DISABLE;
        default:
            return PCNT_MODE_MAX;
    }
}

/*
 * @brief pcnt_count_mode转换
 * @param[in]  pcnt_count_mode          [HAL层封装的pcnt count mode]
 * @return     pcnt_count_mode_t        [转换为SDK定义后的pcnt count mode]
 */
static pcnt_count_mode_t vhal_pcnt_conv_count_mode(PCNT_COUNT_MODE_E pcnt_count_mode)
{
    switch (pcnt_count_mode)
    {
        case VHAL_PCNT_COUNT_DIS:
            return PCNT_COUNT_DIS;
        case VHAL_PCNT_COUNT_INC:
            return PCNT_COUNT_INC;
        case VHAL_PCNT_COUNT_DEC:
            return PCNT_COUNT_DEC;
        default:
            return PCNT_COUNT_MAX;
    }
}

/*
 * @brief pcnt_unit转换
 * @param[in]  pcnt_unit                [HAL层封装的pcnt unit]
 * @return     pcnt_unit_t              [转换为SDK定义的pcnt unit]
 */
static pcnt_unit_t vhal_pcnt_conv_unit(PCNT_UNIT_E pcnt_unit)
{
    switch (pcnt_unit)
    {
        case VHAL_PCNT_UNIT_0:
            return PCNT_UNIT_0;
        case VHAL_PCNT_UNIT_1:
            return PCNT_UNIT_1;
        case VHAL_PCNT_UNIT_2:
            return PCNT_UNIT_2;
        case VHAL_PCNT_UNIT_3:
            return PCNT_UNIT_3;
        case VHAL_PCNT_UNIT_4:
            return PCNT_UNIT_4;
        case VHAL_PCNT_UNIT_5:
            return PCNT_UNIT_5;
        case VHAL_PCNT_UNIT_6:
            return PCNT_UNIT_6;
        case VHAL_PCNT_UNIT_7:
            return PCNT_UNIT_7;
        default:
            return PCNT_UNIT_MAX;
    }
}

/*
 * @brief  pcnt_channel转换
 * @param[in]  pcnt_channel             [HAL层封装的pcnt channel]
 * @return     pcnt_channel_t           [转换为SDK定义的pcnt channel]
 */
static pcnt_channel_t vhal_pcnt_conv_channel(PCNT_CHANNEL_E pcnt_channel)
{
    switch (pcnt_channel)
    {
        case VHAL_PCNT_CHANNEL_0:
            return PCNT_CHANNEL_0;
        case VHAL_PCNT_CHANNEL_1:
            return PCNT_CHANNEL_1;
        default:
            return PCNT_COUNT_MAX;
    }
}


/*-----------------------------------------------------------------------------*
 *                           外部函数API实现                                         *
 *-----------------------------------------------------------------------------*/

/**
 * @brief  pcnt单元配置函数
 * @param[in]  pcnt_config              [pcnt配置结构体指针]
 * @return     int32_t                  [操作结果, 0为成功，其他值表示失败]
 */
int32_t vhal_pcnt_unit_config(const vhal_pcnt_config_t *pcnt_config)
{
    int ret = -1;
    pcnt_config_t pcnt_cfg;

    pcnt_cfg.pulse_gpio_num = pcnt_config->pulse_gpio_num;
    pcnt_cfg.ctrl_gpio_num = pcnt_config->ctrl_gpio_num;
    pcnt_cfg.lctrl_mode = vhal_pcnt_conv_ctrl_mode(pcnt_config->lctrl_mode);
    pcnt_cfg.hctrl_mode = vhal_pcnt_conv_ctrl_mode(pcnt_config->hctrl_mode);
    pcnt_cfg.pos_mode = vhal_pcnt_conv_count_mode(pcnt_config->pos_mode);
    pcnt_cfg.neg_mode = vhal_pcnt_conv_count_mode(pcnt_config->neg_mode);
    pcnt_cfg.counter_h_lim = pcnt_config->counter_h_lim;
    pcnt_cfg.counter_l_lim = pcnt_config->counter_l_lim;
    pcnt_cfg.unit = vhal_pcnt_conv_unit(pcnt_config->unit);
    pcnt_cfg.channel = vhal_pcnt_conv_channel(pcnt_config->channel);

    ret = pcnt_unit_config(&pcnt_cfg);
    if (ESP_OK != ret)
    {
        return VHAL_FAIL;
    }

    return VHAL_OK;
}

/**
 * @brief  获取pcnt计数值
 * @param[in]  pcnt_unit                [pcnt计数unit]
 * @param[out] count                    [pcnt计数值]
 * @return     int32_t                  [操作结果, 0为成功，其他值表示失败]
 */
int32_t vhal_pcnt_get_counter_value(PCNT_UNIT_E pcnt_unit, int16_t *count)
{
    int ret = -1;
    pcnt_unit_t vhal_pcnt_unit;

    vhal_pcnt_unit = vhal_pcnt_conv_unit(pcnt_unit);

    ret = pcnt_get_counter_value(vhal_pcnt_unit, count);
    if (ESP_OK != ret)
    {
        return VHAL_FAIL;
    }

    return VHAL_OK;
}

/**
 * @brief  暂停pcnt计数
 * @param[in]  pcnt_unit                [pcnt计数unit]
 * @return     int32_t                  [操作结果, 0为成功，其他值表示失败]
 */
int32_t vhal_pcnt_pause_counter(PCNT_UNIT_E pcnt_unit)
{
    int ret = -1;
    pcnt_unit_t vhal_pcnt_unit;

    vhal_pcnt_unit = vhal_pcnt_conv_unit(pcnt_unit);

    ret = pcnt_counter_pause(vhal_pcnt_unit);
    if (ESP_OK != ret)
    {
        return VHAL_FAIL;
    }

    return VHAL_OK;
}

/**
 * @brief  pcnt重新计数
 * @param[in]  pcnt_unit               [pcnt计数unit]
 * @return     int32_t                  [操作结果, 0为成功，其他值表示失败]
 */
int32_t vhal_pcnt_resume_counter(PCNT_UNIT_E pcnt_unit)
{
    int ret = -1;
    pcnt_unit_t vhal_pcnt_unit;

    vhal_pcnt_unit = vhal_pcnt_conv_unit(pcnt_unit);

    ret = pcnt_counter_resume(vhal_pcnt_unit);
    if (ESP_OK != ret)
    {
        return VHAL_FAIL;
    }

    return VHAL_OK;
}

/**
 * @brief  清除pcnt计数
 * @param[in]  pcnt_unit               [pcnt计数unit]
 * @return     int32_t                  [操作结果, 0为成功，其他值表示失败]
 */
int32_t vhal_pcnt_clear_counter(PCNT_UNIT_E pcnt_unit)
{
    int ret = -1;
    pcnt_unit_t vhal_pcnt_unit;

    vhal_pcnt_unit = vhal_pcnt_conv_unit(pcnt_unit);

    ret = pcnt_counter_clear(vhal_pcnt_unit);
    if (ESP_OK != ret)
    {
        return VHAL_FAIL;
    }

    return VHAL_OK;
}

/**
 * @brief  使能pcnt滤波
 * @param[in]  pcnt_unit                [pcnt计数unit]
 * @return     int32_t                  [操作结果, 0为成功，其他值表示失败]
 */
int32_t vhal_pcnt_enable_filter(PCNT_UNIT_E pcnt_unit)
{
    int ret = -1;
    pcnt_unit_t vhal_pcnt_unit;

    vhal_pcnt_unit = vhal_pcnt_conv_unit(pcnt_unit);

    ret = pcnt_filter_enable(vhal_pcnt_unit);
    if (ESP_OK != ret)
    {
        return VHAL_FAIL;
    }

    return VHAL_OK;
}

/**
 * @brief  除能pcnt滤波
 * @param[in]  pcnt_unit                [pcnt计数unit]
 * @return     int32_t                  [操作结果, 0为成功，其他值表示失败]
 */
int32_t vhal_pcnt_disable_filter(PCNT_UNIT_E pcnt_unit)
{
    int ret = -1;
    pcnt_unit_t vhal_pcnt_unit;

    vhal_pcnt_unit = vhal_pcnt_conv_unit(pcnt_unit);

    ret = pcnt_filter_disable(vhal_pcnt_unit);
    if (ESP_OK != ret)
    {
        return VHAL_FAIL;
    }

    return VHAL_OK;
}

/**
 * @brief  设置pcnt滤波值
 * @param[in]  pcnt_unit                [pcnt计数unit]
 * @param[in]  filter_val               [pcnt滤波值（10bit,最大1023）]
 * @return     int32_t                  [操作结果, 0为成功，其他值表示失败]
 */
int32_t vhal_pcnt_set_filter_value(PCNT_UNIT_E pcnt_unit, uint16_t filter_val)
{
    int ret = -1;
    pcnt_unit_t vhal_pcnt_unit;

    vhal_pcnt_unit = vhal_pcnt_conv_unit(pcnt_unit);

    ret = pcnt_set_filter_value(vhal_pcnt_unit, filter_val);
    if (ESP_OK != ret)
    {
        return VHAL_FAIL;
    }

    return VHAL_OK;
}
