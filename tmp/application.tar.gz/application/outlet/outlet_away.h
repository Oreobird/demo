/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        outlet_away.h
 * @brief       outlet Away 功能定义
 * @author      Herve Lin
 * @date        2021-06-29
 */

#ifndef __OUTLET_AWAY_H__
#define __OUTLET_AWAY_H__

#include <stdint.h>
#include <stdbool.h>

#include "vesync_bypass.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief 初始化Away功能
 * @return int              [返回APP的错误定义： APP_OK, APP_FAIL]
 */
int outlet_away_init(void);

/**
 * @brief Bypass添加Away配置项
 * @param[in] pst_bp_msg    [Bypass添加的Schedule配置项信息]
 * @return int              [返回BYPASS的错误定义]
 */
int outlet_away_add(bypass_away_base_t *pst_bp_msg);

/**
 * @brief Bypass删除Away配置项
 * @return int              [返回BYPASS的错误定义]
 */
int outlet_away_del(void);

/**
 * @brief Bypass获取Away配置项
 * @param pst_bp_out            [指向输出获取Away配置结果的缓存]
 * @param pst_rnd_times_point   [随机时间点的输出]
 * @param p_point_num           [随机时间点的数量]
 * @return int                  [返回BYPASS的错误定义]
 */
int outlet_away_get(bypass_away_base_t *pst_bp_out, uint32_t *pst_rnd_times_point, uint32_t *p_point_num);

/**
 * @brief Bypass获取Away最大和最小时间点（动作）的数量
 * @param[out] p_max    [指向输出最大值的缓存，NULL指针忽略]
 * @param[out] p_min    [指向输出最小值的缓存，NULL指针忽略]
 * @return int          [返回BYPASS的错误定义]
 */
int outlet_away_get_max_min_rnd_times_point_num(uint32_t *p_max, uint32_t *p_min);

/**
 * @brief Away 清除所有配置信息
 * @return int  [返回APP的错误定义： APP_OK, APP_FAIL]
 */
int outlet_away_clear(void);

#ifdef __cplusplus
}
#endif

#endif /* __OUTLET_AWAY_H__ */
