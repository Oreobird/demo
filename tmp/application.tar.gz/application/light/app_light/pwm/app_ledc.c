/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
* @file         app_led.c
* @brief        pwm驱动器创建接口
* @author       Joshua
* @date         2021-11-16
*/
#include <stdint.h>
#include "vesync_common.h"
#include "vesync_log.h"
#include "vesync_memory.h"
#include "vhal_led.h"
#include "light_drv.h"
#include "app_cfg.h"


static int destroy(light_drv_t *thiz)
{
    VCOM_SAFE_FREE(thiz);
    return APP_OK;
}

static int setup(light_drv_t *thiz)
{
    UNUSED(thiz);

    int ret;
    vhal_led_timer_cfg_t led_timer_cfg =
        {
            .duty_resolution = (LED_DUTY_RST_E)LIGHT_LEDC_DUTY_RST_BIT,
            .freq_hz = LIGHT_LEDC_PWM_FREQ,
        };

    ret = vhal_led_timer_cfg(&led_timer_cfg);
    if (VHAL_OK != ret)
    {
        APP_LOG(LOG_WARN, "led timer cfg fail[%d]\n", ret);
    }

    vhal_led_gpio_cfg_t gpio_cfg[PWM_CH_NUM] = {
#ifdef PWM_CW_CH
        {
            .gpio_num = LIGHT_COLD_OUT_IO, .channel = PWM_CW_CH, .duty = 0,
        },
#endif
#ifdef PWM_WW_CH
        {
            .gpio_num = LIGHT_WARM_OUT_IO, .channel = PWM_WW_CH, .duty = 0,
        },
#endif
#ifdef PWM_R_CH
        {
            .gpio_num = LIGHT_RED_OUT_IO, .channel = PWM_R_CH, .duty = 0,
        },
#endif
#ifdef PWM_G_CH
        {
            .gpio_num = LIGHT_GREEN_OUT_IO, .channel = PWM_G_CH, .duty = 0,
        },
#endif
#ifdef PWM_B_CH
        {
            .gpio_num = LIGHT_BULE_OUT_IO, .channel = PWM_B_CH, .duty = 0,
        }
#endif
    };

    ret = vhal_led_gpio_cfg(PWM_CH_NUM, gpio_cfg);
    if (VHAL_OK != ret)
    {
        APP_LOG(LOG_WARN, "led gpio cfg fail[%d]\n", ret);
    }

    return APP_OK;
}

static void output(light_drv_t *thiz, uint16_t ch_num, uint32_t *p_ch_duty)
{
    UNUSED(thiz);
    UNUSED(ch_num);
#ifdef PWM_CW_CH
    vhal_led_set_duty_bits(PWM_CW_CH, p_ch_duty[LIGHT_CH_IDX_C], LIGHT_PWM_MAX_SCALE);
#endif
#ifdef PWM_WW_CH
    vhal_led_set_duty_bits(PWM_WW_CH, p_ch_duty[LIGHT_CH_IDX_W], LIGHT_PWM_MAX_SCALE);
#endif
#ifdef PWM_R_CH
    vhal_led_set_duty_bits(PWM_R_CH, p_ch_duty[LIGHT_CH_IDX_R], LIGHT_PWM_MAX_SCALE);
#endif
#ifdef PWM_G_CH
    vhal_led_set_duty_bits(PWM_G_CH, p_ch_duty[LIGHT_CH_IDX_G], LIGHT_PWM_MAX_SCALE);
#endif
#ifdef PWM_B_CH
    vhal_led_set_duty_bits(PWM_B_CH, p_ch_duty[LIGHT_CH_IDX_B], LIGHT_PWM_MAX_SCALE);
#endif
}

light_drv_t *light_pwm_drv_create(void)
{
    light_drv_t *thiz = (light_drv_t *)vesync_malloc(sizeof(light_drv_t));
    if (thiz != NULL)
    {
        thiz->destroy = destroy;
        thiz->setup = setup;
        thiz->output = output;
    }

    return thiz;
}

