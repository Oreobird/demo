/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_srpc_test.c
 * @brief       vesync SRPC模块的测试相关实现
 * @author      Herve
 * @date        2021-12-28
 */
#include <stdio.h>
#include <string.h>

#include "vesync_srpc_private.h"
#include "vesync_log_internal.h"
#include "vesync_json_internal.h"

#include "vesync_tl_payload_parse.h"

#include "vesync_common.h"
#include "vesync_utils.h"
#include "vesync_memory.h"

void vesync_srpc_mock_for_request_recv(cJSON *p_bp_pl)
{
    if (NULL == p_bp_pl)
    {
        return;
    }

    SDK_LOG(LOG_DEBUG, "print bypass request payload\n");
    vesync_json_print(p_bp_pl);

    uint32_t srpc_data_len;
    uint8_t *p_srpc_req = srpc_request_marshal(p_bp_pl, &srpc_data_len);
    if (NULL == p_srpc_req)
    {
        return;
    }

#if 0
    LOG_RAW_HEX(LOG_ERROR, "mock protobuf:", p_srpc_req, srpc_data_len);
#endif

    uint16_t tl_pl_len = srpc_data_len + TL_PAYLOAD_PROTOCOL_HEAD_LEN;
    uint8_t *p_tl_pl = (uint8_t *)vesync_malloc(tl_pl_len);
    if (NULL == p_tl_pl)
    {
        return;
    }
    if (SDK_OK != vesync_tl_payload_encode(SRPC_OPCODE_REQUEST, 0,
                                           p_srpc_req, srpc_data_len,
                                           p_tl_pl, &tl_pl_len))
    {
        return;
    }

#if 0
    LOG_RAW_HEX(LOG_ERROR, "mock ble tl_payload:", p_tl_pl, tl_pl_len);
#endif

    srpc_tl_data_recv_cb(p_tl_pl, tl_pl_len, false);
    vesync_free(p_srpc_req);
}