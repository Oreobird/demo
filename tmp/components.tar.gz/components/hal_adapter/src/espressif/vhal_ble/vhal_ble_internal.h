/**
 *  Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
 * @file        vhal_ble_internal.h
 * @brief       蓝牙hal配置ble服务属性接口
 * @date        2021-06-22
 */

#ifndef __VHAL_BLE_INTERNAL_H__
#define __VHAL_BLE_INTERNAL_H__

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#include "vesync_common.h"


#ifdef __cplusplus
extern "C"
{
#endif


//cmd Attributes Indexs
enum{
    IDX_CMD_SVC,
    IDX_CHAR_CMD_NOTIFY,
    IDX_CHAR_VAL_CMD_NOTIFY,
    IDX_CHAR_CFG_CMD_NOTIFY,

    IDX_CHAR_CMD_WRITE,
    IDX_CHAR_VAL_CMD_WRITE,

    CMD_IDX_NB
};

///device update Attributes Indexs
enum{
    IDX_UPDATE_SVC,

    IDX_UPDATE,
    IDX_UPDATE_NOTIFY_CHAR,
    IDX_UPDATE_NOTIFY_CFG,

    IDX_UPDATE_WRITE_CHAR,
    IDX_UPDATE_WRITE_VAL,
    IDX_UPDATE_WRITE_NOTIFY_CFG,

    DEV_UPDATE_NB
};

//net config Attributes Indexs
enum{
    IDX_NET_CFG_SVC,
    IDX_CHAR_NET_CFG_NOTIFY,
    IDX_CHAR_VAL_NET_CFG_NOTIFY,
    IDX_CHAR_CFG_NET_CFG_NOTIFY,

    IDX_CHAR_NET_CFG_WRITE,
    IDX_CHAR_VAL_NET_CFG_WRITE,

    NET_CFG_IDX_NB
};



struct gatts_profile_inst{
    uint16_t gatts_if;
    uint16_t conn_id;
    esp_bd_addr_t remote_device_addr;
    esp_bd_addr_t master_remote_device_addr;
};


typedef struct{
    uint16_t                handle;
    uint8_t                 *prepare_buf;
    int                     prepare_len;
} prepare_type_env_t;


typedef struct{
    bool    init_flag;
    bool    adv_started;
} vhal_ble_t;


#define VHAL_BLE_QUEUE_LEN  (100)

#define CONN_ID_INVALID     0XFFFF

#define ADV_NAME_MAX_LEN                29  //scan rsp最大数据长度
#define APP_ADV_INTERVAL_MIN            0x200                          /**< The advertising interval (in units of 0.625 ms. This value corresponds to 300 ms). */
#define APP_ADV_INTERVAL_MAX            0x200                          /**< The advertising interval (in units of 0.625 ms. This value corresponds to 300 ms). */
#define TX_POWER                        ESP_PWR_LVL_N0                /* +0dbm*/

#define GATTS_APP_ID                0x55
#define SVC_INST_ID                 0

#define ATT_OPCODE_HANDLE_LEN       3 //3是蓝牙协议att层数据包的头opcode+handle
#define BLE_MAX_MTU                 ESP_GATT_MAX_MTU_SIZE //(200 + ATT_OPCODE_HANDLE_LEN)
#define GATTS_CHAR_VAL_LEN_MAX      (BLE_MAX_MTU - ATT_OPCODE_HANDLE_LEN)
#define PREPARE_BUF_MAX_SIZE        1024
#define CHAR_DECLARATION_SIZE       (sizeof(uint8_t))




#ifdef __cplusplus
}
#endif

#endif /* __VHAL_BLE_INTERNAL_H__ */
