/**
*Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file    led_strip_flash.c
* @brief   led_strip flash 读写
* @author  Lind
*@date     2021-12-20
*/

#include <stdio.h>
#include <string.h>

#include "vesync_common.h"
#include "vesync_log.h"
#include "vesync_flash.h"
#include "vesync_device.h"
#include "vesync_klv.h"
#include "vesync_memory.h"

#include "led_strip.h"
#include "led_strip_scene.h"
#include "led_strip_flash.h"

/**
 * @brief 保存开关数据到flash
 * @param[in]  data              [开关配置]
 * @return     int               [成功：APP_OK ，失败:：APP_FAIL]
 */
int ls_save_config(ls_status_t data)
{
    int ret = APP_FAIL;
    uint8_t *p_buf= NULL;
    int offset = 0;
    uint8_t version = 0;
    int buf_len = LS_KLV_DATA_LEN + LS_KLV_MULTI_HSV_DATA_LEN;
    if (NULL == (p_buf = (uint8_t *)vesync_malloc(buf_len)))
    {
        return APP_FAIL;
    }

    memset(p_buf, 0, buf_len);

    version = LSP_APP_DATA_VERSION;
    offset +=  vesync_klv_set(p_buf+offset, buf_len-offset, LS_KEY_VERSION, sizeof(version), (uint8_t*)&version);
    offset +=  vesync_klv_set(p_buf+offset, buf_len-offset, LS_KEY_STATUS, sizeof(data.status), (uint8_t*)&data.status);
    offset +=  vesync_klv_set(p_buf+offset, buf_len-offset, LS_KEY_MODEL, sizeof(data.mode), (uint8_t*)&data.mode);
    offset +=  vesync_klv_set(p_buf+offset, buf_len-offset, LS_KEY_NODE_NUM, sizeof(data.node_num), (uint8_t*)&data.node_num);
    offset +=  vesync_klv_set(p_buf+offset, buf_len-offset, LS_KEY_CUSTOM_SCENE_NUM, sizeof(data.custom_scene_num), (uint8_t*)&data.custom_scene_num);
    offset +=  vesync_klv_set(p_buf+offset, buf_len-offset, LS_KEY_HSVW, sizeof(data.hsvw), (uint8_t*)&data.hsvw);
    offset +=  vesync_klv_set(p_buf+offset, buf_len-offset, LS_KEY_SCENE_ID, sizeof(data.scene_id), (uint8_t*)&data.scene_id);
    offset +=  vesync_klv_set(p_buf+offset, buf_len-offset, LS_KEY_MULTI_HSV, sizeof(data.hsvw) * data.node_num, (uint8_t*)data.multi_hsv);
    offset +=  vesync_klv_set(p_buf+offset, buf_len-offset, LS_KEY_LAST_GEN_ID, sizeof(data.last_gen_id), (uint8_t*)&data.last_gen_id);
    ret = vhal_flash_write(PARTITION_CFG, LS_USER_CFG_KEY_DATA, p_buf, offset);
    vesync_free(p_buf);

    if (VHAL_OK != ret)
    {
        APP_LOG(LOG_ERROR, "Write data fail, ret = %d.\n", ret);
        return APP_FAIL;
    }

    APP_LOG(LOG_INFO, "save led_strip data len = %d.\n", offset);

    return APP_OK;
}

/**
 * @brief 从flash中读取数据到内存
 * @param[out] p_data            [开关配置]
 * @return     int               [成功：APP_OK ，失败:：APP_FAIL]
 */
int ls_read_config(ls_status_t *p_data)
{
    int ret = APP_FAIL;
    uint32_t len = 0;
    uint8_t *p_buf= NULL;
    uint8_t version = 0;
    ls_hsv_t *temp_hsv = NULL;

    if (NULL == p_data)
    {
        APP_LOG(LOG_ERROR, "Input parameters contain null pointers!\n");
        return APP_FAIL;
    }

    if (VHAL_OK != vhal_flash_read(PARTITION_CFG, LS_USER_CFG_KEY_DATA, NULL, &len))
    {
        APP_LOG(LOG_ERROR, "Read led_strip data fail, ret = %d.\n", ret);
        return APP_FAIL;
    }

    if(NULL == (p_buf = (uint8_t *)vesync_malloc(len)))
    {
        return APP_FAIL;
    }

    len = LS_KLV_DATA_LEN;
    if (VHAL_OK != vhal_flash_read(PARTITION_CFG, LS_USER_CFG_KEY_DATA, p_buf, &len))
    {
        APP_LOG(LOG_ERROR, "Read led_strip data fail, ret = %d.\n", ret);
        vesync_free(p_buf);
        return APP_FAIL;
    }
    APP_LOG(LOG_INFO, "Read led_strip data len = %d.\n", len);
    vesync_klv_get(p_buf, len, LS_KEY_VERSION, sizeof(version), (uint8_t*)&version);
    vesync_klv_get(p_buf, len, LS_KEY_STATUS, sizeof(p_data->status), (uint8_t*)&p_data->status);
    vesync_klv_get(p_buf, len, LS_KEY_MODEL, sizeof(p_data->mode), (uint8_t*)&p_data->mode);
    vesync_klv_get(p_buf, len, LS_KEY_NODE_NUM, sizeof(p_data->node_num), (uint8_t*)&p_data->node_num);
    vesync_klv_get(p_buf, len, LS_KEY_CUSTOM_SCENE_NUM, sizeof(p_data->custom_scene_num), (uint8_t*)&p_data->custom_scene_num);
    vesync_klv_get(p_buf, len, LS_KEY_HSVW, sizeof(p_data->hsvw), (uint8_t*)&p_data->hsvw);
    vesync_klv_get(p_buf, len, LS_KEY_SCENE_ID, sizeof(p_data->scene_id), (uint8_t*)&p_data->scene_id);
    vesync_klv_get(p_buf, len, LS_KEY_LAST_GEN_ID, sizeof(p_data->last_gen_id), (uint8_t*)&p_data->last_gen_id);
    APP_LOG(LOG_DEBUG, "mode %d.\n", p_data->mode);
    APP_LOG(LOG_DEBUG, "SCENE id %d.\n", p_data->scene_id);
    APP_LOG(LOG_DEBUG, "hsvw %d %d %d %d.\n", p_data->hsvw.H, p_data->hsvw.S, p_data->hsvw.V, p_data->hsvw.white);

    temp_hsv = (ls_hsv_t*)vesync_malloc(sizeof(ls_hsv_t) * LED_NODE_MAX_NUM);
    if (temp_hsv == NULL)
    {
        APP_LOG(LOG_ERROR, "Read led_strip data fail : Out of memory\n");
        return APP_FAIL;
    }

    memset(temp_hsv, 0, sizeof(ls_hsv_t) * LED_NODE_MAX_NUM);
    vesync_klv_get(p_buf, len, LS_KEY_MULTI_HSV, (sizeof(ls_hsv_t) * p_data->node_num), (uint8_t*)temp_hsv);
    VCOM_SAFE_FREE(p_data->multi_hsv);
    p_data->multi_hsv = temp_hsv;
    APP_LOG(LOG_INFO, "multi hsvw %d %d %d %d.\n", p_data->multi_hsv[0].H, p_data->multi_hsv[0].S, p_data->multi_hsv[0].V, p_data->multi_hsv[0].white);
    vesync_free(p_buf);
    APP_LOG(LOG_INFO, "Read led_strip flash successful\n");
    return APP_OK;
}

/**
 * @brief 保存场景信息
 * @param[in]  **pst_data               [场景信息]
 * @param[in]  num                      [自定义场景数量]
 * @param[in]  *p_id_list               [场景ID]
 * @return     int                      [成功：APP_OK， 失败：APP_FAIL]
 */
int  ls_save_scene(ls_static_param_t **pst_data, uint8_t num, uint16_t *p_id_list)
{
    int ret = APP_FAIL;
    uint8_t *p_buf= NULL;
    int offset = 0;
    int buf_len = (sizeof(ls_static_param_t) + LS_KLV_MULTI_HSV_DATA_LEN) * num;
    if (NULL == pst_data || 0 == num || NULL == p_id_list || LS_CUSTOM_SCENE_MAX_NUM < num)
    {
        APP_LOG(LOG_ERROR, "Param illegal :scene num[%d]\n", num);
        return APP_FAIL;
    }

    p_buf = (uint8_t *)vesync_malloc(buf_len);
    if (NULL == p_buf)
    {
        APP_LOG(LOG_ERROR, "Out of memory \n");
        return APP_FAIL;
    }

    memset(p_buf, 0, buf_len);
    LS_LED_STATIC_E mode[num];
    uint8_t node_num[num];
    uint16_t color_num = 0;
    APP_LOG(LOG_DEBUG, "save scene  total %d\n", num);
    for (uint8_t i = 0; i < num; i++)
    {
        ls_static_param_t *temp_param = NULL;
        temp_param = pst_data[i];
        if (NULL == temp_param)
        {
            APP_LOG(LOG_ERROR, "pointer NULL \n");
            return APP_FAIL;
        }

        mode[i] = temp_param->mode;
        node_num[i] = temp_param->node_num;
        color_num += node_num[i];
    }

    offset +=  vesync_klv_set(p_buf+offset, buf_len-offset, LS_KEY_SCENE_MODE, sizeof(mode), (uint8_t*)mode);
    offset +=  vesync_klv_set(p_buf+offset, buf_len-offset, LS_KEY_SCENE_NODE_NUM, sizeof(node_num), (uint8_t*)node_num);
    offset +=  vesync_klv_set(p_buf+offset, buf_len-offset, LS_KEY_SCENE_ID_LIST, sizeof(uint16_t) * num, (uint8_t*)p_id_list);

    ls_hsv_t color[color_num];
    int temp_offset = 0;
    for (uint8_t i = 0; i < num; i++)
    {
        ls_hsv_t *color_head = pst_data[i]->color_head;
        if (temp_offset + pst_data[i]->node_num > color_num)
        {
            return APP_FAIL;
        }

        memcpy(color + temp_offset, color_head, sizeof(ls_hsv_t) * pst_data[i]->node_num);
        temp_offset += pst_data[i]->node_num;
    }

    offset +=  vesync_klv_set(p_buf+offset, buf_len-offset, LS_KEY_SCENE_MULTI_HSV, sizeof(color), (uint8_t*)color);
    ret = vhal_flash_write(PARTITION_CFG, LS_USER_SCENE_KEY_DATA, p_buf, offset);
    vesync_free(p_buf);

    if (VHAL_OK != ret)
    {
        APP_LOG(LOG_ERROR, "Write data fail, ret = %d.\n", ret);
        return APP_FAIL;
    }

    APP_LOG(LOG_DEBUG, "save scene successfully\n");
    return APP_OK;
}

/**
 * @brief 从flash中读取场景信息到内存
 * @param[out]  **pst_data               [场景信息]
 * @param[in]   num                      [自定义场景数量]
 * @param[in]  *p_id_list                [场景ID]
 * @return     int                       [成功：APP_OK， 失败：APP_FAIL]
 */
int ls_read_scene(ls_static_param_t **pst_data, uint8_t num, uint16_t *p_id_list)
{
    if (NULL == pst_data || 0 == num || NULL == p_id_list)
    {
        APP_LOG(LOG_ERROR, "Param illegal \n");
        return APP_FAIL;
    }

    int ret = APP_FAIL;
    uint32_t len = 0;
    uint8_t *p_buf= NULL;

    if (VHAL_OK != vhal_flash_read(PARTITION_CFG, LS_USER_SCENE_KEY_DATA, NULL, &len))
    {
        APP_LOG(LOG_ERROR, "Read led_strip data fail, ret = %d.\n", ret);
        return APP_FAIL;
    }

    if(NULL == (p_buf = (uint8_t *)vesync_malloc(len)))
    {
        return APP_FAIL;
    }

    memset(p_buf, 0, len);
    if (VHAL_OK != vhal_flash_read(PARTITION_CFG, LS_USER_SCENE_KEY_DATA, p_buf, &len))
    {
        APP_LOG(LOG_ERROR, "Read led_strip data fail, ret = %d.\n", ret);
        vesync_free(p_buf);
        return APP_FAIL;
    }

    LS_LED_STATIC_E mode[num];
    uint8_t node_num[num];
    uint16_t color_node_num = 0;
    uint16_t temp_offset = 0;
    ls_hsv_t *p_temp_color = NULL;
    vesync_klv_get(p_buf, len, LS_KEY_SCENE_MODE, sizeof(mode), (uint8_t*)mode);
    vesync_klv_get(p_buf, len, LS_KEY_SCENE_ID_LIST, sizeof(uint16_t) * num, (uint8_t*)p_id_list);
    vesync_klv_get(p_buf, len, LS_KEY_SCENE_NODE_NUM, sizeof(node_num), (uint8_t*)node_num);
    for (uint8_t i = 0; i < num; i++)
    {
        color_node_num += node_num[i];
    }

    ls_hsv_t color[color_node_num];
    vesync_klv_get(p_buf, len, LS_KEY_SCENE_MULTI_HSV, sizeof(color), (uint8_t*)color);
    for (uint8_t i = 0; i < num; i++)
    {
        p_temp_color = NULL;
        p_temp_color = (ls_hsv_t*)vesync_malloc(sizeof(ls_hsv_t) * node_num[i]);
        VCOM_SAFE_FREE(pst_data[i]);
        pst_data[i] = (ls_static_param_t*)vesync_malloc(sizeof(ls_static_param_t));
        if (p_temp_color == NULL || pst_data[i] == NULL)
        {
            // free
            for (int n = i - 1; n >= 0; n--)
            {
                VCOM_SAFE_FREE(pst_data[n]->color_head);
                VCOM_SAFE_FREE(pst_data[n]);
            }

            vesync_free(p_buf);
            return APP_FAIL;
        }

        memset(p_temp_color, 0, sizeof(ls_hsv_t) * node_num[i]);
        memset(pst_data[i], 0, sizeof(ls_static_param_t));
        memcpy(p_temp_color, color + temp_offset, sizeof(ls_hsv_t) * node_num[i]);
        pst_data[i]->mode = mode[i];
        pst_data[i]->node_num = node_num[i];
        pst_data[i]->color_head = p_temp_color;
        temp_offset += node_num[i];
    }

    vesync_free(p_buf);
    return APP_OK;
}

/**
 * @brief 清除开关配置
 * @return int          [APP_OK/APP_FAIL]
 */
int ls_clear_config(void)
{
    int ret = APP_OK;

    ret += vhal_flash_erase_key(PARTITION_CFG, LS_USER_CFG_KEY_DATA);
    ret += vhal_flash_erase_key(PARTITION_CFG, LS_USER_SCENE_KEY_DATA);
    if (VHAL_OK != ret)
    {
        APP_LOG(LOG_ERROR, "Clear led strip data fail\n");
        return APP_FAIL;
    }

    return APP_OK;
}

