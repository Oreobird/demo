/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_netcfg_event.c
 * @brief       配网模块的事件处理
 * @author      Louis
 * @date        2021-05-21
 */

#include <string.h>
#include <stdio.h>
#include "cJSON.h"
#include "vesync_common.h"
#include "vesync_log_internal.h"
#include "vesync_queue.h"
#include "vesync_event_internal.h"
#include "vesync_wifi_scan.h"
#include "vesync_netcfg_event.h"
#include "vesync_net_service_internal.h"
#include "vesync_wifi_led.h"
#include "vhal_wifi.h"
#if CONFIG_VESYNC_SDK_FFS_ENABLE
#include "vesync_ffs_internal.h"
#endif
#if CONFIG_VESYNC_SDK_DEVELOPER_ENABLE
#include "vesync_developer_internal.h"
#endif
#include "vesync_netcfg_internal.h"
#include "vesync_netcfg_send.h"
#include "vesync_netcfg_recv.h"
#include "vesync_netcfg_timer.h"
#include "vhal_utils.h"
#include "vesync_tcp_server.h"
#include "vesync_report.h"

static int s_nwk_reconnect_cnt = 0;
static bool ever_connected_success = false;

static vesync_queue_t *s_event_queue = NULL;

// APP层注册的配网成功回调
static void (*s_net_cfg_ok_app_cb)(void) = NULL;


// 事件回调函数声明
static int ev_cb_force_exit(vesync_ev_t *event);
static int ev_cb_app_cancel(vesync_ev_t *event);
static int ev_cb_scan_done(vesync_ev_t *event);
static int ev_cb_app_connected(vesync_ev_t *event);
static int ev_cb_app_disconnected(vesync_ev_t *event);
static int ev_cb_ble_connected(vesync_ev_t *event);
static int ev_cb_ble_disconnected(vesync_ev_t *event);
static int ev_cb_receive_config(vesync_ev_t *event);
static int ev_cb_wifi_connected(vesync_ev_t *event);
static int ev_cb_got_ip(vesync_ev_t *event);
static int ev_cb_dns_resolved(vesync_ev_t *event);
static int ev_cb_nwk_connected(vesync_ev_t *event);
static int ev_cb_nwk_disconnected(vesync_ev_t *event);
static int ev_cb_nwk_ready(vesync_ev_t *event);

// APP层关心的配网事件回调
static netcfg_app_cb s_netcfg_app_evcb[NETCFG_EV_MAX] = {NULL};

// 事件回调注册列表
static netcfg_ev_t s_event_list[] = {
    {EVENT_NETCFG_FORCE_EXIT, ev_cb_force_exit},
    {EVENT_NETCFG_APP_CANCEL, ev_cb_app_cancel},
    {EVENT_WIFI_SCANDONE, ev_cb_scan_done},
    {EVENT_NETCFG_APP_CONNECTED, ev_cb_app_connected},
    {EVENT_NETCFG_APP_DISCONNECTED, ev_cb_app_disconnected},
    {EVENT_BLE_CONNECTED, ev_cb_ble_connected},
    {EVENT_BLE_DISCONNECTED, ev_cb_ble_disconnected},
    {EVENT_NETCFG_RECEIVE_CONFIG, ev_cb_receive_config},
    {EVENT_WIFI_CONNECTED, ev_cb_wifi_connected},
    {EVENT_ROUTER_GOT_IP, ev_cb_got_ip},
    {EVENT_DNS_RESOLVED, ev_cb_dns_resolved},
    {EVENT_NWK_CONNECTED, ev_cb_nwk_connected},
    {EVENT_NWK_DISCONNECTED, ev_cb_nwk_disconnected},
    {EVENT_NWK_READY, ev_cb_nwk_ready},
};


/**
 * @brief 发布配网事件给APP层
 * @param[in] ev                    [配网事件]
 */
static void vesync_netcfg_post_app_ev(NETCFG_EVT_E ev)
{
    if (s_netcfg_app_evcb[ev])
    {
        s_netcfg_app_evcb[ev]();
    }
}


/**
 * @brief  退出配网模块事件回调
 * @param[in]  event            [事件消息体]
 * @return     int              [处理结果]
 */
static int ev_cb_force_exit(vesync_ev_t *event)
{
    SDK_LOG(LOG_DEBUG, "force exit.\r\n");
    UNUSED(event);
    vesync_wifi_led_set_behavior(WIFI_LED_CONFIG_TIMEOUT);   // 取消配网，灯灭

    vesync_net_client_disconnect_server();
    vhal_wifi_stop();

    vesync_netcfg_set_exit();

    vesync_netcfg_post_app_ev(NETCFG_EV_EXIT);

    return SDK_OK;
}


/**
 * @brief  APP取消配网事件回调
 * @param[in]  event            [事件消息体]
 * @return     int              [处理结果]
 */
static int ev_cb_app_cancel(vesync_ev_t *event)
{
    cJSON *root = NULL;
    SDK_LOG(LOG_DEBUG, "app cancel.\r\n");

    UNUSED(event);
    vesync_wifi_led_set_behavior(WIFI_LED_CONFIG_TIMEOUT);   // 取消配网，灯灭

    root = cJSON_CreateObject();
    if(NULL != root)
    {
        cJSON_AddNumberToObject(root, "result", 0);
        vesync_netcfg_send_data(OP_CANCLE_CONFIG, MTYPE_ACK, root);
        cJSON_Delete(root);
    }

    vesync_net_client_disconnect_server();
    vhal_wifi_stop();

    vesync_netcfg_set_exit();

    vesync_netcfg_post_app_ev(NETCFG_EV_APP_CANCEL);

    return SDK_OK;
}



/**
 * @brief APN配网按产品名称和MAC设置ap名称
 * @return    int       [设置成功与否]
 */
static int vesync_netcfg_setup_ap_cfg(void)
{
    int ret = RET_FAIL;
    char ssid_str[WIFI_SSID_MAX_LEN] = {0};
    char ap_mac_str[MAC_ADDR_STR_MAX_LEN];
    char *ap_name_prefix = vesync_cfg_get_ssid_prefix();

    if (VHAL_OK == vhal_utils_get_dev_mac(VHAL_MAC_WIFI_SOFTAP, ap_mac_str, sizeof(ap_mac_str))
        && NULL != ap_name_prefix)
    {
        snprintf(ssid_str, WIFI_SSID_MAX_LEN, "%s_%c%c%c%c", ap_name_prefix,
                 ap_mac_str[12], ap_mac_str[13], ap_mac_str[15], ap_mac_str[16]);

        if (VHAL_OK == vhal_wifi_setup_ap_cfg(VHAL_WIFI_MODE_APSTA, ssid_str, NULL,
                                              VHAL_WIFI_2G4_CHAN1, VHAL_WIFI_AUTH_OPEN))
        {
            ret = RET_OK;
        }
    }

    return ret;
}


/**
 * @brief  扫描完成事件回调
 * @param[in]  event            [事件消息体]
 * @return     int              [处理结果]
 */
static int ev_cb_scan_done(vesync_ev_t *event)
{
    SDK_LOG(LOG_DEBUG, "scan done.\n");
    UNUSED(event);

    if(AP_CONFIG == vesync_netcfg_get_mode())
    {
        if (!vesync_tcp_server_is_started())
        {
            /* set AP-STA mode, set ap ssid, open tcp server */
            if(RET_OK != vesync_netcfg_setup_ap_cfg())
            {
                SDK_LOG(LOG_ERROR, "configure ap error.\r\n");
            }
            if(0 != vesync_tcp_server_start(VESYNC_TCP_SERVER_PORT))
            {
                SDK_LOG(LOG_ERROR, "fail to start tcp server.\r\n");
            }

#if CONFIG_VESYNC_SDK_DEVELOPER_ENABLE
            vesync_developer_stop();
            SDK_LOG(LOG_DEBUG, "vesync_developer_stop..............\r\n");
#endif
        }
        else
        {
            vesync_netcfg_reply_aplist(1);
        }
    }
    else if(BLE_CONFIG == vesync_netcfg_get_mode())
    {
        vesync_netcfg_reply_aplist(1);
    }

    return SDK_OK;
}


/**
 * @brief  APP连接事件回调
 * @param[in]  event            [事件消息体]
 * @return     int              [处理结果]
 */
static int ev_cb_app_connected(vesync_ev_t *event)
{
    SDK_LOG(LOG_DEBUG, "app connected.\r\n");
    UNUSED(event);

    // 手机关联上设备，退出10min倒计时
    netcfg_del_main_timer();

    vesync_netcfg_post_app_ev(NETCFG_EV_APP_CONNECTED);

    return SDK_OK;
}


/**
 * @brief  APP断开连接事件回调
 * @param[in]  event            [事件消息体]
 * @return     int              [处理结果]
 */
static int ev_cb_app_disconnected(vesync_ev_t *event)
{
    SDK_LOG(LOG_DEBUG, "app disconnected.\r\n");
    UNUSED(event);

    // APP断开连接，重新开始倒计时
    netcfg_add_main_timer();

    vesync_netcfg_post_app_ev(NETCFG_EV_APP_DISCONNECTED);

    return SDK_OK;
}


/**
 * @brief  BLE连接事件回调
 * @param[in]  event            [事件消息体]
 * @return     int              [处理结果]
 */
static int ev_cb_ble_connected(vesync_ev_t *event)
{
    SDK_LOG(LOG_DEBUG, "ble connected.\r\n");
    UNUSED(event);

    // 手机关联上设备，退出10min倒计时
    netcfg_del_main_timer();

    vesync_netcfg_post_app_ev(NETCFG_EV_BLE_CONNECTED);

    return SDK_OK;
}


/**
 * @brief  BLE断开连接事件回调
 * @param[in]  event            [事件消息体]
 * @return     int              [处理结果]
 */
static int ev_cb_ble_disconnected(vesync_ev_t *event)
{
    SDK_LOG(LOG_DEBUG, "ble disconnected.\r\n");
    UNUSED(event);

    // BLE断开连接，重新开始倒计时
    netcfg_add_main_timer();

    // 断开蓝牙，设备进入等待配网中
    vesync_wifi_led_set_behavior(WIFI_LED_NOT_CONFIG);

    vesync_netcfg_post_app_ev(NETCFG_EV_BLE_DISCONNECTED);

    return SDK_OK;
}


/**
 * @brief  收到配网信息事件回调
 * @param[in]  event            [事件消息体]
 * @return     int              [处理结果]
 */
static int ev_cb_receive_config(vesync_ev_t *event)
{
    UNUSED(event);
    net_info_t *p_net_cfg = vesync_net_mgmt_get_net_cfg();
    SDK_LOG(LOG_DEBUG, "receive config.\r\n");
    vesync_wifi_led_set_behavior(WIFI_LED_CONFIGING);        // 配网中，快闪

    vesync_netcfg_set_status(NETCFG_STATUS_RECV_CFG_DATA);
    vesync_netcfg_report_status(NULL);

    // reset mqtt when get new config
    ever_connected_success = false;
    s_nwk_reconnect_cnt = 0;

    // APN配网，设备收到APP下发的配网信息后，释放WiFi列表
    if (vesync_netcfg_get_mode() == AP_CONFIG)
    {
        vesync_wifi_aplist_clear();
    }

    vesync_wifi_client_connect((char*)p_net_cfg->wifiSSID,
                                (char*)p_net_cfg->wifiPassword,
                                (VHAL_WIFI_AUTH_MODE_E)p_net_cfg->auth_mode);

    // 收到配网数据，连接WIFI倒计时启动
    netcfg_add_step_timer();

    /* start the log timer to send config net log to APP every 5s. */
    netcfg_add_netlog_timer();

    vesync_netcfg_post_app_ev(NETCFG_EV_RECV_CONFIG);

    return SDK_OK;
}


/**
 * @brief  WIFI连接事件回调
 * @param[in]  event            [事件消息体]
 * @return     int              [处理结果]
 */
static int ev_cb_wifi_connected(vesync_ev_t *event)
{
    SDK_LOG(LOG_DEBUG, "wifi connected.\r\n");
    UNUSED(event);

    vesync_netcfg_set_status(NETCFG_STATUS_CONNECTED_WIFI);
    vesync_netcfg_report_status(NULL);

    // Wi-Fi连接成功，获取IP倒计时
    netcfg_add_step_timer();

    vesync_netcfg_post_app_ev(NETCFG_EV_WIFI_CONNECTED);

    return SDK_OK;
}


/**
 * @brief  获取到IP事件回调
 * @param[in]  event            [事件消息体]
 * @return     int              [处理结果]
 */
static int ev_cb_got_ip(vesync_ev_t *event)
{
    UNUSED(event);
    net_info_t *p_net_cfg = vesync_net_mgmt_get_net_cfg();
    SDK_LOG(LOG_DEBUG, "got ip.\r\n");
    vesync_netcfg_set_status(NETCFG_STATUS_GOT_IP);
    vesync_netcfg_report_status(NULL);

    //if (NETWORK_UNINIT == vesync_net_client_get_status())
    {
        vesync_ev_t ev = {0};
        vesync_net_client_connect((char *)p_net_cfg->serverDN,
                                  (char *)p_net_cfg->serverIP,
                                  (char *)p_net_cfg->configKey, // pwd需要用configKey填充
                                  &p_net_cfg->serverPort,
                                  vesync_net_client_get_tls_option());

        VESYNC_POPULATE_EV(ev, EVENT_NWK_RESET, NETCFG_TASK_NAME, 0, NULL);
        vesync_event_publish(&ev);

        // 获取IP成功，云端连接倒计时
        netcfg_add_step_timer();
    }

    vesync_netcfg_post_app_ev(NETCFG_EV_GOT_IP);

    return SDK_OK;
}


/**
 * @brief  DNS解析成功事件回调
 * @param[in]  event            [事件消息体]
 * @return     int              [处理结果]
 */
static int ev_cb_dns_resolved(vesync_ev_t *event)
{
    SDK_LOG(LOG_DEBUG, "dns resolved.\r\n");
    vesync_netcfg_set_status(NETCFG_STATUS_DNS_RESOLVED);

    char *ip_str = (char*)(event->buf);
    if(NULL == ip_str)
    {
        SDK_LOG(LOG_ERROR, "event buf is null.\n");
        vesync_netcfg_report_status(NULL);
    }
    else
    {
        vesync_netcfg_report_status((const char*)ip_str);
    }

    vesync_netcfg_post_app_ev(NETCFG_EV_DNS_RESOLVED);

    return SDK_OK;
}


/**
 * @brief  云端连接事件回调
 * @param[in]  event            [事件消息体]
 * @return     int              [处理结果]
 */
static int ev_cb_nwk_connected(vesync_ev_t *event)
{
    SDK_LOG(LOG_DEBUG, "cloud nwk connected.\r\n");
    UNUSED(event);

    vesync_netcfg_set_status(NETCFG_STATUS_CONNECTED_SERVER);
    vesync_netcfg_report_status(NULL);
    ever_connected_success = true;

    vesync_netcfg_post_app_ev(NETCFG_EV_SERV_CONNECTED);

    return SDK_OK;
}


/**
 * @brief  云端断开连接事件回调
 * @param[in]  event            [事件消息体]
 * @return     int              [处理结果]
 */
static int ev_cb_nwk_disconnected(vesync_ev_t *event)
{
    cJSON *root = NULL;
    SDK_LOG(LOG_DEBUG, "cloud nwk disconnected.\r\n");

    char *err_msg = (char*)(event->buf);
    net_info_t *p_net_cfg = vesync_net_mgmt_get_net_cfg();

    root = cJSON_CreateObject();
    if (NULL != root)
    {
        cJSON_AddStringToObject(root,"type", NETCFG_ERR_TYPE_STR_MQTT);
        if (NULL != err_msg)
        {
            cJSON_AddStringToObject(root, "msg", err_msg);
        }

        vesync_netcfg_send_data(OP_ERR_REPORT, MTYPE_LOG, root);
        cJSON_Delete(root);
    }

    // only calcuate the reconnect count after a successful connect.
    if (true == ever_connected_success)
    {
        s_nwk_reconnect_cnt ++;
    }

    // reset password after a successful connect.
    if (1 == s_nwk_reconnect_cnt)
    {
        char * p_server_domain = (char *) p_net_cfg->serverDN;
        if(NULL != p_server_domain)
        {
            vesync_net_client_connect(p_server_domain, (char *)p_net_cfg->serverIP, "0", &p_net_cfg->serverPort, TLS_CA_SERVER);
        }
    }

    vesync_netcfg_post_app_ev(NETCFG_EV_SERV_DISCONNECTED);

    return SDK_OK;
}


/**
 * @brief  网络就绪事件回调
 * @param[in]  event            [事件消息体]
 * @return     int              [处理结果]
 */
static int ev_cb_nwk_ready(vesync_ev_t *event)
{
    SDK_LOG(LOG_DEBUG, "event:mqtt subscribed.\n");
    UNUSED(event);

    net_info_t *p_net_cfg = vesync_net_mgmt_get_net_cfg();
    SDK_LOG(LOG_DEBUG, "subscribe success.\n");
    netcfg_del_step_timer();

    vesync_netcfg_set_status(NETCFG_STATUS_SUBSCRIBE_SUCCESS);
    vesync_netcfg_report_status(NULL);
    //连接服务器就绪，回复APP成功结果
    vesync_netcfg_prot_report_result(ERR_CONFIG_NET_SUCCESS, ERR_CONFIG_NET_SUCCESS_MSG);

    if(SDK_OK == vesync_net_flash_write_net_info(p_net_cfg))
    {
        vesync_wifi_led_set_behavior(WIFI_LED_LOGIN_SUCCESS);
        vesync_netcfg_set_status(NETCFG_STATUS_SAVE_CFG_SUCCESS);
#if CONFIG_VESYNC_SDK_FFS_ENABLE
        vesync_ffs_disable();       //配网成功，ffs配网功能失效
#endif
        vesync_netcfg_set_exit();
    }
    else
    {
        SDK_LOG(LOG_ERROR, "write flash error!\r\n");
    }

    // 配网成功，上报并更新设备信息
    vesync_report_update_dev_info();

    vesync_netcfg_post_app_ev(NETCFG_EV_SUCCESS);
    if (NULL != s_net_cfg_ok_app_cb)
    {
        s_net_cfg_ok_app_cb();
    }

    return SDK_OK;
}


/**
 * @brief  事件通知回调函数
 * @param[in]  data             [事件消息]
 * @return     int              [处理结果]
 */
static int netcfg_event_sub_cb(void *data)
{
    vesync_ev_t *event = (vesync_ev_t *)data;
    int ret = vesync_queue_send(s_event_queue, event, VESYNC_OS_NO_WAIT);
    if (ret != VOS_OK)
    {
        SDK_LOG(LOG_ERROR, "Event publish\n");
        return SDK_FAIL;
    }

    return SDK_OK;
}


/**
 * @brief  初始化事件处理
 * @return     int              [处理结果]
 */
int netcfg_event_init(void)
{
    int i = 0;

    s_event_queue = vesync_queue_new(NETCFG_QUEUE_MAX_NUM * sizeof(vesync_ev_t), sizeof(vesync_ev_t));
    if (NULL == s_event_queue)
    {
        SDK_LOG(LOG_ERROR, "queue create fail\n");
        goto exit;
    }

    for (i = 0; i < sizeof(s_event_list)/sizeof(netcfg_ev_t); i++)
    {
        if (SDK_OK != vesync_event_subscribe(s_event_list[i].ev_id, SUB_ID_NETCFG, netcfg_event_sub_cb))
        {
            SDK_LOG(LOG_ERROR, "subscribe %d fail\n", s_event_list[i].ev_id);
            goto exit;
        }
    }

    return SDK_OK;

exit:
    vesync_queue_free(s_event_queue);
    s_event_queue = NULL;
    for (i = 0; i < sizeof(s_event_list)/sizeof(netcfg_ev_t); i++)
    {
        vesync_event_unsubscribe(s_event_list[i].ev_id, SUB_ID_NETCFG);
    }

    return SDK_FAIL;
}


/**
 * @brief  注销事件通知
 */
void netcfg_event_deinit(void)
{
    int i;
    for (i = 0; i < sizeof(s_event_list)/sizeof(netcfg_ev_t); i++)
    {
        vesync_event_unsubscribe(s_event_list[i].ev_id, SUB_ID_NETCFG);
    }

    vesync_queue_free(s_event_queue);
    s_event_queue = NULL;

    return;
}


/**
 * @brief  接收事件通知
 * @param[out] event            [事件消息]
 * @param[in]  timeout_ms       [超时时间]
 * @return     int              [接收结果]
 */
int netcfg_receive_event(vesync_ev_t *event, unsigned int timeout_ms)
{
    int ret = vesync_queue_recv(s_event_queue, event, timeout_ms);
    if (ret != VOS_OK)
    {
        return SDK_FAIL;
    }

    return SDK_OK;
}


/**
 * @brief  事件通知分发处理
 * @param[in]  event            [事件消息]
 * @return     int              [处理结果]
 */
int netcfg_dispatch_event(vesync_ev_t *event)
{
    int i;
    for (i = 0; i < sizeof(s_event_list)/sizeof(netcfg_ev_t); i++)
    {
        if (event->event_id == s_event_list[i].ev_id)
        {
            return s_event_list[i].ev_cb(event);
        }
    }

    return SDK_FAIL;
}


/**
 * @brief 向配网事件管理注册配网成功事件回调
 * @note  提供给应用层的接口
 * @param[in] net_cfg_ok_cb         [注册回调接口]
 * @return int
 */
int vesync_net_cfg_reg_success_cb(void (*net_cfg_ok_cb)(void))
{
    s_net_cfg_ok_app_cb = net_cfg_ok_cb;

    return SDK_OK;
}


int vesync_netcfg_reg_ev_cb(NETCFG_EVT_E ev, void (*netcfg_ev_cb)(void))
{
    if (ev >= NETCFG_EV_MAX)
    {
        return SDK_FAIL;
    }

    s_netcfg_app_evcb[ev] = netcfg_ev_cb;
    return SDK_OK;
}