/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        demo.c
 * @brief       SDK入口函数
 * @author      Joshua
 * @date        2021-04-22
 */

#include "vesync_init.h"
#include "vesync_common.h"
#include "vesync_log.h"
#include "demo_https_netcfg.h"
#include "demo_production.h"
#include "vesync_cfg.h"
#include "vesync_uart.h"

static int demo_sdk_cfg_init(void)
{
    vesync_cfg_set_alias_model("EFS-A591S");
    vesync_cfg_set_config_model("WB_SCL_EFS-A591S_US");
    vesync_cfg_set_authkey("ww6zvzwtaa6hqjl991g0w1obkeo0sd44");
    vesync_cfg_set_ssid_prefix("Etekcity_Apex_test");
    vesync_cfg_set_ble_name("Etekcity_Apex");
    vesync_cfg_set_init_task_stacksize(1024*4);
    int data[1] = {9600};
    vesync_cfg_set_uart_baud_rate_arr(data);
    return APP_OK;
}

static void demo_pre_cb(void)
{
    APP_LOG(LOG_DEBUG, "Demo pre init callback\n");
    demo_sdk_cfg_init();
}

static void demo_app_run(void)
{
    APP_LOG(LOG_INFO, "Vesync APP Demo start\n");

    demo_production_init();
    demo_netcfg_init();
}

void app_main()
{
    vesync_sdk_reg_pre_run_cb(demo_pre_cb);
    vesync_sdk_reg_post_run_cb(demo_app_run);

    vesync_sdk_run();
}

