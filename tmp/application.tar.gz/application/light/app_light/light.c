/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
* @file         light.c
* @brief        灯光控制接口
* @author       Joshua
* @date         2021-11-16
*/
#include <stdint.h>
#include "vesync_common.h"
#include "vesync_log.h"
#include "vesync_light.h"
#include "vesync_os.h"
#include "light_drv.h"
#include "app_cfg.h"
#include "device.h"

#define LIGHT_FRAME_PERIOD (20) // 灯光控制器单帧周期（毫秒）

static light_drv_t *s_pwm_drv = NULL;
static light_drv_t *s_i2c_drv = NULL;
static light_drv_t *s_rmt_drv = NULL;

static vesync_light_t s_color_light = NULL;   // 灯光控制器实例
static vesync_light_t s_w_light = NULL;

/**
 * @brief HSV to RGB的色域参数转换为PWM控制量
 * @param[in]  H            [色相]
 * @param[in]  S            [饱和度]
 * @param[in]  V            [明度]
 * @param[out]  p_led       [输出的LED PWM控制量]
 */
static void light_hsv_to_rgb(uint16_t H, uint16_t S, uint8_t V, light_ctrl_data_t *p_light)
{
    uint16_t hi = (H / 1667) % 6;
    float F = (float)H / 1667.0f * 100.0f - 100.0f * (float)hi;

    float ofs_v = (0 == V) ? 0 : ((float)V / 100.0f) * (100.0f - LIGHT_RGB_MIN_PERCENT) + LIGHT_RGB_MIN_PERCENT;;
    float P = ofs_v * (10000.0f - (float)S) / 10000.0f;
    float Q = ofs_v * (1000000.0f - F * (float)S) / 1000000.0f;
    float T = ofs_v * (1000000.0f - (float)S * (100.0f - F)) / 1000000.0f;
    float red, green, blue;

    switch (hi)
    {
        case 0:
            red = ofs_v;
            green = T;
            blue = P;
            break;
        case 1:
            red = Q;
            green = ofs_v;
            blue = P;
            break;
        case 2:
            red = P;
            green = ofs_v;
            blue = T;
            break;
        case 3:
            red = P;
            green = Q;
            blue = ofs_v;
            break;
        case 4:
            red = T;
            green = P;
            blue = ofs_v;
            break;
        case 5:
            red = ofs_v;
            green = P;
            blue = Q;
            break;
        default:
            APP_LOG(LOG_WARN, "invalid hsv args\n");
            return;
    }


    float mixed = red + green + blue;
    float red_ratio = (mixed == 0) ? 0 : red / mixed;
    float green_ratio = (mixed == 0) ? 0 : green / mixed;
    float blue_ratio = (mixed == 0) ? 0 : blue / mixed;
    float scaling = ofs_v / 100.0f;

    uint16_t pwm_red = (uint16_t)(red_ratio * LIGHT_PWM_MAX_SCALE * scaling);
    uint16_t pwm_green = (uint16_t)(green_ratio * LIGHT_PWM_MAX_SCALE * scaling);
    uint16_t pwm_blue = (uint16_t)(blue_ratio * LIGHT_PWM_MAX_SCALE * scaling);

    // 最大量程限制
    p_light->r = (pwm_red >= LIGHT_PWM_MAX_SCALE) ? (LIGHT_PWM_MAX_SCALE - 1) : pwm_red;
    p_light->g = (pwm_green >= LIGHT_PWM_MAX_SCALE) ? (LIGHT_PWM_MAX_SCALE - 1) : pwm_green;
    p_light->b = (pwm_blue >= LIGHT_PWM_MAX_SCALE) ? (LIGHT_PWM_MAX_SCALE - 1) : pwm_blue;
    p_light->c = 0;
    p_light->w = 0;
#if 0
    APP_LOG(LOG_DEBUG, "RGB calculate result: R[%f], G[%f], B[%f]; Scaling[%f]\n",
            red, green, blue, ofs_v);
    APP_LOG(LOG_DEBUG, "PWM calculate result: R[%d], G[%d], B[%d], sum[%d]\n",
            p_light->r, p_light->g, p_light->b, p_light->r + p_light->g + p_light->b);
#endif
}


/**
 * @brief 白光模式色温与亮度转换为PWM控制量
 * @param[in]  color_temp       [色温]
 * @param[in] bright            [亮度]
 * @param[out] p_light          [输出的LED PWM控制量]
 */
static void light_kl_to_pwm(uint8_t color_temp, uint8_t bright, light_ctrl_data_t *p_light)
{
    float ofs_b = (0 == bright) ? 0.0f : ((float)bright / 100.0f) * (LIGHT_W_MAX_PERCENT - LIGHT_W_MIN_PERCENT) + LIGHT_W_MIN_PERCENT;

#if LIGHT_WHITE_CW
    uint16_t pwm_cold = color_temp * ofs_b * LIGHT_PWM_MAX_SCALE / 10000;
    uint16_t pwm_warm = (LIGHT_COLOR_TEMP_MAX - color_temp) * ofs_b * LIGHT_PWM_MAX_SCALE / 10000;
#else
    uint16_t pwm_cold = ofs_b / 100 * LIGHT_PWM_MAX_SCALE;
#if LIGHT_CCT_COLOR_TEMP_INVERT
    uint16_t pwm_warm = (LIGHT_COLOR_TEMP_MAX - color_temp) * LIGHT_PWM_MAX_SCALE / 100;
#else
    uint16_t pwm_warm = color_temp * LIGHT_PWM_MAX_SCALE / 100;
#endif
#endif

    // 最大量程限制
    p_light->r = 0;
    p_light->g = 0;
    p_light->b = 0;
    p_light->c = (pwm_cold >= LIGHT_PWM_MAX_SCALE) ? (LIGHT_PWM_MAX_SCALE - 1) : pwm_cold;
    p_light->w = (pwm_warm >= LIGHT_PWM_MAX_SCALE) ? (LIGHT_PWM_MAX_SCALE - 1) : pwm_warm;
#if 0
    APP_LOG(LOG_DEBUG, "CWW: bright[%d], ofs_bright[%d]\n", bright, (uint8_t)ofs_b);
    APP_LOG(LOG_DEBUG, "PWM calculate result: C[%d], W[%d]\n", p_light->c, p_light->w);
#endif
}

/**
 * @brief 灯驱动配置
 * @return int          [成功：APP_OK，失败：APP_FAIL]
 */
static int light_drv_init(void)
{
    int ret = APP_OK;
#if CONFIG_VESYNC_APP_LIGHT_CTRL_DRV_I2C
    s_i2c_drv = light_i2c_drv_create();
    VCOM_NULL_RET_CHK(s_i2c_drv, return APP_FAIL);
    ret = light_drv_setup(s_i2c_drv);
#endif

#if CONFIG_VESYNC_APP_LIGHT_CTRL_DRV_PWM
    s_pwm_drv = light_pwm_drv_create();
    VCOM_NULL_RET_CHK(s_pwm_drv, return APP_FAIL);
    ret = light_drv_setup(s_pwm_drv);
#endif

#if CONFIG_VESYNC_APP_LIGHT_CTRL_DRV_RMT
    s_rmt_drv = light_rmt_drv_create();
    VCOM_NULL_RET_CHK(s_rmt_drv, return APP_FAIL);
    ret = light_drv_setup(s_rmt_drv);
#endif
    return ret;
}

/**
 * @brief 灯驱动销毁
 */
static void light_drv_deinit(void)
{
#if CONFIG_VESYNC_APP_LIGHT_CTRL_DRV_I2C
    light_drv_destroy(s_i2c_drv);
#endif

#if CONFIG_VESYNC_APP_LIGHT_CTRL_DRV_PWM
    light_drv_destroy(s_pwm_drv);
#endif

#if CONFIG_VESYNC_APP_LIGHT_CTRL_DRV_RMT
    light_drv_destroy(s_rmt_drv);
#endif
}

static int light_white_init(void)
{
    switch (LIGHT_WHITE_DRV_TYPE)
    {
        case 0:
            s_w_light = vesync_light_create(LIGHT_CH_IDX_MAX,
                                    LIGHT_FRAME_PERIOD,
                                    LIGHT_PWM_MAX_SCALE,
                                    light_drv_output,
                                    s_i2c_drv);
            break;
        case 1:
            s_w_light = vesync_light_create(LIGHT_CH_IDX_MAX,
                                    LIGHT_FRAME_PERIOD,
                                    LIGHT_PWM_MAX_SCALE,
                                    light_drv_output,
                                    s_pwm_drv);
            break;
        case 2:
            s_w_light = vesync_light_create(LIGHT_CH_IDX_MAX * app_device_bead_num(),
                                    LIGHT_FRAME_PERIOD,
                                    LIGHT_PWM_MAX_SCALE,
                                    light_drv_output,
                                    s_rmt_drv);
            break;
        default:
            return APP_FAIL;
    }

    if (NULL == s_w_light)
    {
        APP_LOG(LOG_ERROR, "create white light fail\n");
        return APP_FAIL;
    }

    vesync_light_set_gamma(s_w_light, LIGHT_CH_IDX_C, 1);
    vesync_light_set_gamma(s_w_light, LIGHT_CH_IDX_W, 1);
    vesync_light_set_gamma(s_w_light, LIGHT_CH_IDX_R, 0.8);
    vesync_light_set_gamma(s_w_light, LIGHT_CH_IDX_G, 0.6);
    vesync_light_set_gamma(s_w_light, LIGHT_CH_IDX_B, 0.6);

    return APP_OK;
}

static int light_color_init(void)
{
    switch (LIGHT_COLOR_DRV_TYPE)
    {
        case 0:
            s_color_light = vesync_light_create(LIGHT_CH_IDX_MAX,
                                                LIGHT_FRAME_PERIOD,
                                                LIGHT_PWM_MAX_SCALE,
                                                light_drv_output,
                                                s_i2c_drv);
            break;
        case 1:
            s_color_light = vesync_light_create(LIGHT_CH_IDX_MAX,
                                                LIGHT_FRAME_PERIOD,
                                                LIGHT_PWM_MAX_SCALE,
                                                light_drv_output,
                                                s_pwm_drv);
            break;
        case 2:
            s_color_light = vesync_light_create(LIGHT_CH_IDX_MAX * app_device_bead_num(),
                                                LIGHT_FRAME_PERIOD,
                                                LIGHT_PWM_MAX_SCALE,
                                                light_drv_output,
                                                s_rmt_drv);
            break;
        default:
            return APP_FAIL;
    }

    if (NULL == s_color_light)
    {
        APP_LOG(LOG_ERROR, "create color light fail\n");
        return APP_FAIL;
    }

    vesync_light_set_gamma(s_color_light, LIGHT_CH_IDX_C, 1);
    vesync_light_set_gamma(s_color_light, LIGHT_CH_IDX_W, 1);
    vesync_light_set_gamma(s_color_light, LIGHT_CH_IDX_R, 0.8);
    vesync_light_set_gamma(s_color_light, LIGHT_CH_IDX_G, 0.6);
    vesync_light_set_gamma(s_color_light, LIGHT_CH_IDX_B, 0.6);

    return APP_OK;
}

bool light_white_is_seperated(void)
{
    return (LIGHT_WHITE_DRV_TYPE != LIGHT_COLOR_DRV_TYPE && LIGHT_WHITE_DRV_TYPE != 2);
}

bool light_is_off(void)
{
    dev_cfg_t *p_dev_cfg = app_device_cfg_get();
    return (p_dev_cfg->flash->cfg.onoff == LIGHT_STATUS_OFF) ? true : false;
}

int app_light_init(void)
{
    int ret = APP_FAIL;

    ret = light_drv_init();
    if (ret != APP_OK)
    {
        APP_LOG(LOG_ERROR, "light driver init fail\n");
        return APP_FAIL;
    }

    ret = vesync_light_init();
    if (ret != SDK_OK)
    {
        APP_LOG(LOG_ERROR, "vesync_light init fail\n");
        return APP_FAIL;
    }

    if (light_white_is_seperated())
    {
        ret = light_white_init();
        if (ret != APP_OK)
        {
            goto EXIT;
        }
    }

    ret = light_color_init();
    if (ret != APP_OK)
    {
        goto EXIT;
    }

    return APP_OK;

EXIT:
    vesync_light_deinit();
    light_drv_deinit();
    return APP_FAIL;
}



#define LIGHT_FADE_STEP_CFG(hdl, node_num, ofs, data, step, delay) \
    for (int i = 0; i < (node_num); i++)  \
    { \
        ofs = LIGHT_CH_IDX_MAX * i; \
        vesync_light_fade_with_step_cfg(hdl, (ofs) + LIGHT_CH_IDX_C, ((float)(data.c)) / LIGHT_PWM_MAX_SCALE, (step), (delay)); \
        vesync_light_fade_with_step_cfg(hdl, (ofs) + LIGHT_CH_IDX_W, ((float)(data.w)) / LIGHT_PWM_MAX_SCALE, (step), (delay)); \
        vesync_light_fade_with_step_cfg(hdl, (ofs) + LIGHT_CH_IDX_R, ((float)(data.r)) / LIGHT_PWM_MAX_SCALE, (step), (delay)); \
        vesync_light_fade_with_step_cfg(hdl, (ofs) + LIGHT_CH_IDX_G, ((float)(data.g)) / LIGHT_PWM_MAX_SCALE, (step), (delay)); \
        vesync_light_fade_with_step_cfg(hdl, (ofs) + LIGHT_CH_IDX_B, ((float)(data.b)) / LIGHT_PWM_MAX_SCALE, (step), (delay)); \
    }

#define LIGHT_FADE_TIME_CFG(hdl, node_num, ofs, data, time, delay) \
        for (int i = 0; i < (node_num); i++)  \
        { \
            ofs = LIGHT_CH_IDX_MAX * i; \
            vesync_light_fade_with_time_cfg(hdl, (ofs) + LIGHT_CH_IDX_C, ((float)(data.c)) / LIGHT_PWM_MAX_SCALE, (time), (delay)); \
            vesync_light_fade_with_time_cfg(hdl, (ofs) + LIGHT_CH_IDX_W, ((float)(data.w)) / LIGHT_PWM_MAX_SCALE, (time), (delay)); \
            vesync_light_fade_with_time_cfg(hdl, (ofs) + LIGHT_CH_IDX_R, ((float)(data.r)) / LIGHT_PWM_MAX_SCALE, (time), (delay)); \
            vesync_light_fade_with_time_cfg(hdl, (ofs) + LIGHT_CH_IDX_G, ((float)(data.g)) / LIGHT_PWM_MAX_SCALE, (time), (delay)); \
            vesync_light_fade_with_time_cfg(hdl, (ofs) + LIGHT_CH_IDX_B, ((float)(data.b)) / LIGHT_PWM_MAX_SCALE, (time), (delay)); \
        }

#define LIGHT_START(hdl, node_num, ofs) \
    for (int i = 0; i < (node_num); i++) \
    { \
        ofs = LIGHT_CH_IDX_MAX * i; \
        vesync_light_start(hdl, (ofs) + LIGHT_CH_IDX_C); \
        vesync_light_start(hdl, (ofs) + LIGHT_CH_IDX_W); \
        vesync_light_start(hdl, (ofs) + LIGHT_CH_IDX_R); \
        vesync_light_start(hdl, (ofs) + LIGHT_CH_IDX_G); \
        vesync_light_start(hdl, (ofs) + LIGHT_CH_IDX_B); \
    }

#define LIGHT_STOP(hdl, node_num, ofs) \
    for (int i = 0; i < (node_num); i++) \
    { \
        ofs = LIGHT_CH_IDX_MAX * i; \
        vesync_light_stop(hdl, (ofs) + LIGHT_CH_IDX_C); \
        vesync_light_stop(hdl, (ofs) + LIGHT_CH_IDX_W); \
        vesync_light_stop(hdl, (ofs) + LIGHT_CH_IDX_R); \
        vesync_light_stop(hdl, (ofs) + LIGHT_CH_IDX_G); \
        vesync_light_stop(hdl, (ofs) + LIGHT_CH_IDX_B); \
    }

#define LIGHT_BREATH_CFG(hdl, node_num, ofs, data, times, delay) \
    for (int i = 0; i < (node_num); i++) \
    { \
        ofs = LIGHT_CH_IDX_MAX * i; \
        vesync_light_breath_cfg(hdl, (ofs) + LIGHT_CH_IDX_C, ((float)(data.c)) / LIGHT_PWM_MAX_SCALE, 1000, (delay), times); \
        vesync_light_breath_cfg(hdl, (ofs) + LIGHT_CH_IDX_W, ((float)(data.w)) / LIGHT_PWM_MAX_SCALE, 1000, (delay), times); \
        vesync_light_breath_cfg(hdl, (ofs) + LIGHT_CH_IDX_R, ((float)(data.r)) / LIGHT_PWM_MAX_SCALE, 1000, (delay), times); \
        vesync_light_breath_cfg(hdl, (ofs) + LIGHT_CH_IDX_G, ((float)(data.g)) / LIGHT_PWM_MAX_SCALE, 1000, (delay), times); \
        vesync_light_breath_cfg(hdl, (ofs) + LIGHT_CH_IDX_B, ((float)(data.b)) / LIGHT_PWM_MAX_SCALE, 1000, (delay), times); \
    }

#define LIGHT_BLINK_CFG(hdl, node_num, ofs, data, times, delay) \
    for (int i = 0; i < (node_num); i++) \
    { \
        ofs = LIGHT_CH_IDX_MAX * i; \
        vesync_light_blink_cfg(hdl, (ofs) + LIGHT_CH_IDX_C, ((float)(data.c)) / LIGHT_PWM_MAX_SCALE, 1000, (delay), times); \
        vesync_light_blink_cfg(hdl, (ofs) + LIGHT_CH_IDX_W, ((float)(data.w)) / LIGHT_PWM_MAX_SCALE, 1000, (delay), times); \
        vesync_light_blink_cfg(hdl, (ofs) + LIGHT_CH_IDX_R, ((float)(data.r)) / LIGHT_PWM_MAX_SCALE, 1000, (delay), times); \
        vesync_light_blink_cfg(hdl, (ofs) + LIGHT_CH_IDX_G, ((float)(data.g)) / LIGHT_PWM_MAX_SCALE, 1000, (delay), times); \
        vesync_light_blink_cfg(hdl, (ofs) + LIGHT_CH_IDX_B, ((float)(data.b)) / LIGHT_PWM_MAX_SCALE, 1000, (delay), times); \
    }


void app_light_white_on(uint8_t color_temp, uint8_t brightness, uint32_t delay, bool fade)
{
    dev_cfg_t *p_dev_cfg = app_device_cfg_get();
    if (p_dev_cfg)
    {
        app_light_color_off(0, p_dev_cfg->fade);
        int ofs = 0;
        int node_num = 1;
        vesync_light_t p_light = NULL;
        light_ctrl_data_t ctrl_data = {0, 0, 0, 0, 0};

        light_kl_to_pwm(color_temp, brightness, &ctrl_data);

        if (light_white_is_seperated())
        {
            p_light = s_w_light;
            node_num = 1;
        }
        else
        {
            p_light = s_color_light;
            node_num = app_device_bead_num();
        }

        LIGHT_FADE_TIME_CFG(p_light, node_num, ofs, ctrl_data, fade ? LIGHT_REFLESH_INTERVAL_MS : 0, delay);
        LIGHT_START(p_light, node_num, ofs);

        p_dev_cfg->white_status = LIGHT_STATUS_ON;
        p_dev_cfg->voice_off = false;
    }

}

void app_light_white_off(uint32_t delay, bool fade)
{
    dev_cfg_t *p_dev_cfg = app_device_cfg_get();
    if (p_dev_cfg && p_dev_cfg->white_status != LIGHT_STATUS_OFF)
    {
        int ofs = 0;
        int node_num = 1;
        vesync_light_t p_light = NULL;
        light_ctrl_data_t ctrl_data = {0, 0, 0, 0, 0};

        if (light_white_is_seperated())
        {
            p_light = s_w_light;
            node_num = 1;
        }
        else
        {
            p_light = s_color_light;
            node_num = app_device_bead_num();
        }

        LIGHT_FADE_TIME_CFG(p_light, node_num, ofs, ctrl_data, fade ? LIGHT_REFLESH_INTERVAL_MS : 0, delay);
        LIGHT_START(p_light, node_num, ofs);
        p_dev_cfg->white_status = LIGHT_STATUS_OFF;
    }
}

void app_light_white_blink(uint8_t color_temp, uint8_t brightness, uint32_t times, uint32_t delay)
{
    dev_cfg_t *p_dev_cfg = app_device_cfg_get();
    if (p_dev_cfg)
    {
        app_light_color_off(0, p_dev_cfg->fade);
        int ofs = 0;
        int node_num = 1;
        vesync_light_t p_light = NULL;
        light_ctrl_data_t ctrl_data = {0, 0, 0, 0, 0};
        light_kl_to_pwm(color_temp, brightness, &ctrl_data);

        if (light_white_is_seperated())
        {
            p_light = s_w_light;
            node_num = 1;
        }
        else
        {
            p_light = s_color_light;
            node_num = app_device_bead_num();
        }

        LIGHT_BLINK_CFG(p_light, node_num, ofs, ctrl_data, 2 * times, delay);
        LIGHT_START(p_light, node_num, ofs);
        p_dev_cfg->white_status = LIGHT_STATUS_ON;
        p_dev_cfg->voice_off = false;
    }
}

void app_light_white_breath(uint8_t color_temp, uint8_t brightness, uint32_t times, uint32_t delay)
{
    dev_cfg_t *p_dev_cfg = app_device_cfg_get();
    if (p_dev_cfg)
    {
        app_light_color_off(0, p_dev_cfg->fade);
        int ofs = 0;
        int node_num = 1;
        vesync_light_t p_light = NULL;
        light_ctrl_data_t ctrl_data = {0, 0, 0, 0, 0};
        light_kl_to_pwm(color_temp, brightness, &ctrl_data);

        if (light_white_is_seperated())
        {
            p_light = s_w_light;
            node_num = 1;
        }
        else
        {
            p_light = s_color_light;
            node_num = app_device_bead_num();
        }

        LIGHT_BREATH_CFG(p_light, node_num, ofs, ctrl_data, 2 * times, delay);
        LIGHT_START(p_light, node_num, ofs);
        p_dev_cfg->white_status = LIGHT_STATUS_ON;
        p_dev_cfg->voice_off = false;
    }
}

void app_light_color_on(uint16_t H, uint16_t S, uint8_t V, uint32_t delay, bool fade)
{
    dev_cfg_t *p_dev_cfg = app_device_cfg_get();
    if (p_dev_cfg)
    {
        app_light_white_off(0, p_dev_cfg->fade);
        int ofs = 0;
        int node_num = app_device_bead_num();
        vesync_light_t p_light = s_color_light;
        light_ctrl_data_t ctrl_data = {0, 0, 0, 0, 0};
        light_hsv_to_rgb(H, S, V, &ctrl_data);
        LIGHT_FADE_TIME_CFG(p_light, node_num, ofs, ctrl_data, fade ? LIGHT_REFLESH_INTERVAL_MS : 0, delay);
        LIGHT_START(p_light, node_num, ofs);
        p_dev_cfg->color_status = LIGHT_STATUS_ON;
        p_dev_cfg->voice_off = false;
    }
}

void app_light_color_off(uint32_t delay, bool fade)
{
    dev_cfg_t *p_dev_cfg = app_device_cfg_get();
    if (p_dev_cfg && p_dev_cfg->color_status != LIGHT_STATUS_OFF)
    {
        int ofs = 0;
        int node_num = app_device_bead_num();
        vesync_light_t p_light = s_color_light;
        light_ctrl_data_t ctrl_data = {0, 0, 0, 0, 0};
        LIGHT_FADE_TIME_CFG(p_light, node_num, ofs, ctrl_data, fade ? LIGHT_REFLESH_INTERVAL_MS : 0, delay);
        LIGHT_START(p_light, node_num, ofs);
        p_dev_cfg->color_status = LIGHT_STATUS_OFF;
    }
}

void app_light_color_breath(uint16_t H, uint16_t S, uint8_t V, uint32_t times, uint32_t delay)
{
    dev_cfg_t *p_dev_cfg = app_device_cfg_get();
    if (p_dev_cfg)
    {
        app_light_white_off(0, p_dev_cfg->fade);
        int ofs = 0;
        int node_num = app_device_bead_num();
        vesync_light_t p_light = s_color_light;
        light_ctrl_data_t ctrl_data = {0, 0, 0, 0, 0};
        light_hsv_to_rgb(H, S, V, &ctrl_data);
        LIGHT_BREATH_CFG(p_light, node_num, ofs, ctrl_data, 2 * times, delay);
        LIGHT_START(p_light, node_num, ofs);
        p_dev_cfg->color_status = LIGHT_STATUS_ON;
        p_dev_cfg->voice_off = false;
    }
}

void app_light_color_blink(uint16_t H, uint16_t S, uint8_t V, uint32_t times, uint32_t delay)
{
    dev_cfg_t *p_dev_cfg = app_device_cfg_get();
    if (p_dev_cfg)
    {
        app_light_white_off(0, p_dev_cfg->fade);
        int ofs = 0;
        int node_num = app_device_bead_num();
        vesync_light_t p_light = s_color_light;
        light_ctrl_data_t ctrl_data = {0, 0, 0, 0, 0};
        light_hsv_to_rgb(H, S, V, &ctrl_data);
        LIGHT_BLINK_CFG(p_light, node_num, ofs, ctrl_data, 2 * times, delay);
        LIGHT_START(p_light, node_num, ofs);
        p_dev_cfg->color_status = LIGHT_STATUS_ON;
        p_dev_cfg->voice_off = false;
    }
}

void app_light_red_on(uint32_t delay, bool fade)
{
    app_light_color_on(0, 10000, 100, delay, fade);
}

void app_light_red_blink(uint32_t times, uint32_t delay)
{
    app_light_color_blink(0, 10000, 100, times, delay);
}

void app_light_red_breath(uint32_t times, uint32_t delay)
{
    app_light_color_breath(0, 10000, 100, times, delay);
}

void app_light_green_on(uint32_t delay, bool fade)
{
    app_light_color_on(3333, 10000, 100, delay, fade);
}

void app_light_green_blink(uint32_t times, uint32_t delay)
{
    app_light_color_blink(3333, 10000, 100, times, delay);
}

void app_light_green_breath(uint32_t times, uint32_t delay)
{
    app_light_color_breath(3333, 10000, 100, times, delay);
}

void app_light_blue_on(uint32_t delay, bool fade)
{
    app_light_color_on(6666, 10000, 100, delay, fade);
}

void app_light_blue_blink(uint32_t times, uint32_t delay)
{
    app_light_color_blink(6666, 10000, 100, times, delay);
}

void app_light_blue_breath(uint32_t times, uint32_t delay)
{
    app_light_color_breath(6666, 10000, 100, times, delay);
}

void app_light_color_flow(light_param_t *param, uint8_t param_num, uint8_t flow_step,
                                uint32_t period, uint32_t delay, bool overall)
{
    VCOM_NULL_PARAM_CHK(param, return);
    VCOM_IN_RANGE_CHK(param_num, 1, LIGHT_PARAM_MAX_NUM, return);

    dev_cfg_t *p_dev_cfg = app_device_cfg_get();
    app_light_white_off(0, p_dev_cfg->fade);
    light_ctrl_data_t ctrl_data = {0, 0, 0, 0, 0};
    int idx = 0;
    int ofs = 0;
    int node_num = app_device_bead_num();
    vesync_light_t p_light = s_color_light;

    static uint8_t s_flow_step = 0;

    if (overall)
    {
        idx = s_flow_step % param_num;
        light_hsv_to_rgb(param[idx].H, param[idx].S, param[idx].V, &ctrl_data);
        LIGHT_FADE_TIME_CFG(p_light, node_num, ofs, ctrl_data, period, delay);
    }
    else
    {
        for (int i = 0; i < node_num; i++)
        {
            idx = (i + s_flow_step) % param_num;
            light_hsv_to_rgb(param[idx].H, param[idx].S, param[idx].V, &ctrl_data);
            ofs = LIGHT_CH_IDX_MAX * i;
            vesync_light_fade_with_time_cfg(p_light, ofs + LIGHT_CH_IDX_C, ((float)(ctrl_data.c)) / LIGHT_PWM_MAX_SCALE, period, delay);
            vesync_light_fade_with_time_cfg(p_light, ofs + LIGHT_CH_IDX_W, ((float)(ctrl_data.w)) / LIGHT_PWM_MAX_SCALE, period, delay);
            vesync_light_fade_with_time_cfg(p_light, ofs + LIGHT_CH_IDX_R, ((float)(ctrl_data.r)) / LIGHT_PWM_MAX_SCALE, period, delay);
            vesync_light_fade_with_time_cfg(p_light, ofs + LIGHT_CH_IDX_G, ((float)(ctrl_data.g)) / LIGHT_PWM_MAX_SCALE, period, delay);
            vesync_light_fade_with_time_cfg(p_light, ofs + LIGHT_CH_IDX_B, ((float)(ctrl_data.b)) / LIGHT_PWM_MAX_SCALE, period, delay);
        }
    }

    LIGHT_START(p_light, node_num, ofs);

    s_flow_step += flow_step;
    if (s_flow_step > param_num)
    {
        s_flow_step = 0;
    }
    p_dev_cfg->color_status = LIGHT_STATUS_FLOW;
    p_dev_cfg->voice_off = false;
}

void app_light_segment_on(light_color_t *seg_param, uint8_t seg_num, uint32_t delay, bool fade)
{
    dev_cfg_t *p_dev_cfg = app_device_cfg_get();
    app_light_white_off(0, p_dev_cfg->fade);

    if (p_dev_cfg && seg_param)
    {
        int ofs = 0;
        int node_num = app_device_bead_num();
        vesync_light_t p_light = s_color_light;
        light_ctrl_data_t ctrl_data = {0, 0, 0, 0, 0};
        int seg_idx = 0;
        uint32_t period = LIGHT_REFLESH_INTERVAL_MS;

        for (int i = 0; i < node_num; i++)
        {
            seg_idx = (i * seg_num) / node_num;
            ofs = LIGHT_CH_IDX_MAX * i;
            light_hsv_to_rgb(seg_param[seg_idx].H, seg_param[seg_idx].S, seg_param[seg_idx].V, &ctrl_data);
            vesync_light_fade_with_time_cfg(p_light, ofs + LIGHT_CH_IDX_C, ((float)(ctrl_data.c)) / LIGHT_PWM_MAX_SCALE, period, delay);
            vesync_light_fade_with_time_cfg(p_light, ofs + LIGHT_CH_IDX_W, ((float)(ctrl_data.w)) / LIGHT_PWM_MAX_SCALE, period, delay);
            vesync_light_fade_with_time_cfg(p_light, ofs + LIGHT_CH_IDX_R, ((float)(ctrl_data.r)) / LIGHT_PWM_MAX_SCALE, period, delay);
            vesync_light_fade_with_time_cfg(p_light, ofs + LIGHT_CH_IDX_G, ((float)(ctrl_data.g)) / LIGHT_PWM_MAX_SCALE, period, delay);
            vesync_light_fade_with_time_cfg(p_light, ofs + LIGHT_CH_IDX_B, ((float)(ctrl_data.b)) / LIGHT_PWM_MAX_SCALE, period, delay);
        }

        LIGHT_START(p_light, node_num, ofs);
        p_dev_cfg->color_status = LIGHT_STATUS_ON;
        p_dev_cfg->voice_off = false;
    }
}

void app_light_segment_off(uint32_t delay, bool fade)
{
    app_light_color_off(delay, fade);
}

