/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
* @file         production_light.c
* @brief        产测灯效控制
* @author       Joshua
* @date         2021-11-20
*/

#include <string.h>
#include <stdint.h>
#include "vesync_common.h"
#include "vesync_memory.h"
#include "vesync_log.h"
#include "production_light.h"

int prd_light_scene_reg(prd_light_scene_t *light_scene)
{
    VCOM_NULL_PARAM_CHK(light_scene, return APP_FAIL);

    scene_t *thiz = (scene_t *) vesync_malloc(sizeof(scene_t) + sizeof(prd_light_scene_t));
    if (thiz == NULL)
    {
        APP_LOG(LOG_ERROR, "production light scenee reg fail\n");
        return APP_FAIL;
    }

    memset(thiz, 0, sizeof(scene_t) + sizeof(prd_light_scene_t));

    prd_light_scene_t *ctx = (prd_light_scene_t *)thiz->ctx;

    ctx->prd_age_test_pre_light = light_scene->prd_age_test_pre_light;
    ctx->prd_age_testing_light = light_scene->prd_age_testing_light;
    ctx->prd_age_test_post_light = light_scene->prd_age_test_post_light;

    ctx->prd_start_light = light_scene->prd_start_light;
    ctx->prd_running_light = light_scene->prd_running_light;
    ctx->prd_pass_light = light_scene->prd_pass_light;
    ctx->prd_fail_light = light_scene->prd_fail_light;

    thiz->type = SCENE_PRD;
    thiz->id = 0;

    scene_registry_add(thiz);

    return APP_OK;
}

int prd_light_scene_unreg(void)
{
    return scene_registry_del(SCENE_PRD, 0);
}


