/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        bulb_device.c
 * @brief       bulb device
 * @author      Dave
 * @date        2021-09-8
 */
#include <string.h>

#include "vesync_common.h"
#include "vesync_log.h"
#include "vesync_device.h"

#include "bulb.h"
#include "bulb_flash.h"
#include "bulb_device.h"
#include "bulb_schedule.h"
#include "bulb_timing.h"



/**
* @brief bulb设备恢复出厂的数据清理
*/
static void bulb_device_clear_all_data(const char* rsn, DEV_RESET_TYPE_E rst_type)
{
    UNUSED(rsn);
    UNUSED(rst_type);
    int ret = bulb_reset_config();
    if (APP_OK != ret)
    {
        APP_LOG(LOG_DEBUG,"flash data reset fail\n");
    }
    ret = bulb_schedule_clear();
    if (APP_OK != ret)
    {
        APP_LOG(LOG_DEBUG,"schedule reset fail\n");
    }
    ret = bulb_timing_clear();
    if (APP_OK != ret)
    {
        APP_LOG(LOG_DEBUG,"timer reset fail\n");
    }
}

/**
* @brief bulb设备管理初始化
*/
void bulb_device_init(void)
{
    // 注册缓存数据清除函数(恢复出厂/删除设备时调用)
    vesync_device_reg_clear_data_cb(bulb_device_clear_all_data);
}
