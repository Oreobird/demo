/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        ledstrip_bypass.h
 * @brief       ledstrip bypass应用回调
 * @author      Lind
 * @date        2021-09-07
 */

#ifndef __LEDSTRIP_FLASH_H__
#define __LEDSTRIP_FLASH_H__


#include "ledstrip.h"
#include "ledstrip_led.h"

#ifdef __cplusplus
extern "C" {
#endif

#define  LS_KLV_DATE_LEN    60              // klv 数据长度

#define LS_USER_CFG_KEY_DATA        "ledstrip"            // NVS采用key:value格式进行存储

#define LS_SCHEDULE_MOD_CFG_KEY     "sche_mod"          // ledstrip Schedule模块配置存储KEY

/*
 * @brief 配置数据key 定义
 */
typedef enum
{
    LS_KEY_VERSION = 0,         //版本
    LS_KEY_INIT,           //初始化标志
    LS_KEY_STATUS,
    LS_KEY_MODEL,
    LS_KEY_LAST_MODE,
    LS_KEY_COLOR,
    LS_KEY_SCENE,
    LS_KEY_MAX
} LS_CFG_KEY_E;

/*
 * @brief 灯带配置标识符
 */
typedef enum
{
    LS_CFG_STATUS = 0,          // 标识ls_flash_data_t中的status
    LS_CFG_MODEL,               // 标识ls_flash_data_t中的model
    LS_CFG_LAST_MODE,           //  标识ls_flash_data_t中的last_app_mode
    LS_CFG_COLOR,               // 标识ls_flash_data_t中的app_color
    LS_CFG_SCENE,               // 标识ls_flash_data_t中的scene_cnt
} LS_CFG_FLAG_E;

/*
 * @brief 开关存储的flash数据
 */
typedef struct
{
    bool init_flag;
    bool status;
    LS_MODE_E model;
    LS_MODE_E last_app_mode;                // app最新操作的灯光模式
    ls_led_hsv_t app_color;               // app最近1次的彩光和白光参数
    uint8_t scene_cnt;                    // 情景模式序号
} ls_flash_data_t;


/**
 * @brief 保存开关数据到flash
 * @param[in]  data                 [开关配置]
 * @return     int8_t               [成功：APP_OK， 失败：APP_FAIL]
 */
int8_t ls_save_config(ls_flash_data_t data);

/**
 * @brief 从flash中读取数据到内存
 * @param[out] p_data               [开关配置]
 * @return     int8_t               [成功：APP_OK， 失败：APP_FAIL]
 */
int8_t ls_read_config(ls_flash_data_t *p_data);

/**
 * @brief 清除开关配置
 * @return int          [成功：APP_OK， 失败：APP_FAIL]
 */
int ls_clear_config(void);

/**
 * @brief 给Schedule应用层调用的读取对应配置的接口
 * @param[out] p_rd_buf      [指向数据读取的Buffer]
 * @param[out] p_rd_len      [指向储存读取的长度]
 * @return int               [成功：APP_OK， 失败：APP_FAIL]
 */
int ls_read_schedule_cfg(uint8_t *p_rd_buf, uint32_t *p_rd_len);

/**
 * @brief 给Schedule应用层调用的写入对应配置的接口
 * @param[in]  p_wr_buf      [指向被写入的Buffer]
 * @param[in]  len           [将被写入的数据长度]
 * @return int               [成功：APP_OK， 失败：APP_FAIL]
 */
int ls_write_schedule_cfg(uint8_t *p_wr_buf, uint32_t len);


#ifdef __cplusplus
}
#endif

#endif

