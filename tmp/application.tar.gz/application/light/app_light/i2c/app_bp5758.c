/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
* @file         app_bp5758.c
* @brief        bp5758驱动器创建接口
* @author       Joshua
* @date         2021-11-16
*/
#include <string.h>
#include "vesync_common.h"
#include "vesync_log.h"
#include "vesync_memory.h"
#include "vdrv_bp5758d.h"
#include "light_drv.h"
#include "app_cfg.h"

typedef struct
{
    bp5758d_range_t range;
} privinfo_t;

static int destroy(light_drv_t *thiz)
{
    VCOM_SAFE_FREE(thiz);
    return APP_OK;
}

static int setup(light_drv_t *thiz)
{
    int ret = vdrv_bp5758d_init(LIGHT_I2C_SDA_IO, LIGHT_I2C_SCL_IO);
    if (SDK_OK != ret)
    {
        APP_LOG(LOG_ERROR, "bp5758d driver init fail\n");
        return APP_FAIL;
    }

    privinfo_t *priv = (privinfo_t *)thiz->priv;
    VCOM_NULL_PARAM_CHK(priv, return APP_FAIL);

    priv->range.out_num = 5;
    priv->range.outs[0] = LIGHT_BULE_OUT_IO;
    priv->range.outs[1] = LIGHT_WARM_OUT_IO;
    priv->range.outs[2] = LIGHT_COLD_OUT_IO;
    priv->range.outs[3] = LIGHT_GREEN_OUT_IO;
    priv->range.outs[4] = LIGHT_RED_OUT_IO;

    priv->range.data[0] = LIGHT_BULE_MAX;
    priv->range.data[1] = LIGHT_WARM_MAX;
    priv->range.data[2] = LIGHT_COLD_MAX;
    priv->range.data[3] = LIGHT_GREEN_MAX;
    priv->range.data[4] = LIGHT_RED_MAX;

    return APP_OK;
}

static void output(light_drv_t *thiz, uint16_t ch_num, uint32_t *p_ch_duty)
{
    if (ch_num < 5)
    {
        return;
    }

    privinfo_t *priv = (privinfo_t *)thiz->priv;
    VCOM_NULL_PARAM_CHK(priv, return);

    bp5758d_gray_t bp5758d_gray;
    bp5758d_gray.out_num = 5;
    bp5758d_gray.outs[0] = LIGHT_BULE_OUT_IO;
    bp5758d_gray.outs[1] = LIGHT_WARM_OUT_IO;
    bp5758d_gray.outs[2] = LIGHT_COLD_OUT_IO;
    bp5758d_gray.outs[3] = LIGHT_GREEN_OUT_IO;
    bp5758d_gray.outs[4] = LIGHT_RED_OUT_IO;
    bp5758d_gray.data[0] = p_ch_duty[LIGHT_CH_IDX_B];
    bp5758d_gray.data[1] = p_ch_duty[LIGHT_CH_IDX_W];
    bp5758d_gray.data[2] = p_ch_duty[LIGHT_CH_IDX_C];
    bp5758d_gray.data[3] = p_ch_duty[LIGHT_CH_IDX_G];
    bp5758d_gray.data[4] = p_ch_duty[LIGHT_CH_IDX_R];

    if (SDK_OK != vdrv_bp5758d_range_cfg(&(priv->range)))
    {
        APP_LOG(LOG_ERROR, "set bp5758 range fail\n");
    }

    if (SDK_OK != vdrv_bp5758d_gray_cfg(&bp5758d_gray))
    {
        APP_LOG(LOG_ERROR, "set bp5758 gray fail\n");
    }

    if (SDK_OK != vdrv_bp5758d_cfg_write())
    {
        APP_LOG(LOG_ERROR, "write bp5758 cfg fail\n");
    }
}

light_drv_t *light_i2c_drv_create(void)
{
    light_drv_t *thiz = (light_drv_t *)vesync_malloc(sizeof(light_drv_t) + sizeof(privinfo_t));
    if (thiz != NULL)
    {
        privinfo_t *priv = (privinfo_t *)thiz->priv;
        memset(priv, 0, sizeof(privinfo_t));

        thiz->destroy = destroy;
        thiz->setup = setup;
        thiz->output = output;
    }

    return thiz;
}

