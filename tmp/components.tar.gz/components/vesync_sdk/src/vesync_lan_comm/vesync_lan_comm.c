/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_lan_comm.c
 * @brief       局域网通信业务接口实现文件
 * @author      henrikzhou
 * @date        2020-9-21
 */

#include <string.h>
#include <unistd.h>
#include <stdbool.h>

#include "vesync_common.h"
#include "vesync_log_internal.h"
#include "vesync_task.h"
#include "vesync_memory.h"
#include "vesync_mutex.h"
#include "vesync_device_internal.h"

#include "vesync_lan_comm.h"
#include "vesync_lan_comm_tcp.h"
#include "vesync_lan_comm_udp.h"

#include "vesync_lan_trans_prot.h"

#include "vesync_netcfg_internal.h"
#include "vesync_netcfg_recv.h"

#include "vhal_utils.h"
#include "vhal_wifi.h"

#include "vesync_aes.h"
#include "vesync_net_service_internal.h"
#include "vesync_event_internal.h"

#include "cJSON.h"
#include "mbedtls/md5.h"
#include "mbedtls/md.h"
#include "mbedtls/base64.h"


/*parameter*/
static lan_comm_context_t s_lan_comm ;
static vesync_mutex_t s_key_protect_muex = NULL;
static vesync_task_t s_lan_comm_taskhd = NULL;

// 局域网TCP数据回调
static vesync_lan_msg_recv_callback_t s_lan_tcp_data_recv_cb = NULL;

static char * s_lan_comm_msg = NULL;
static uint32_t s_offset = 0;
static uint32_t s_lan_comm_tcp_port = 0;
static uint32_t s_lan_comm_udp_port = 0;

uint8_t aes_test[16]= {0xDE,0x2D, 0x3B, 0x27, 0xC9, 0xA5, 0x25, 0xB7, 0xC3, 0xBF, 0xF5, 0x08, 0xD6,0x73,0x5A,0x34};
uint8_t authkey_test[16]= {0xCC,0xBB,0x2C,0x76,0x06,0x47,0xEE,0x49,0xA6,0x6E,0xB8,0x89,0x2D,0x35,0x33,0x06};
//uint8_t test_key[] = "{\"auth_key\":\"CCBB2C760647EE49A66EB8892D353306\"}";

/*-----------------------------------------------------------------------------*
*-----------------------------------内部函数API实现-------------------------------*
*-----------------------------------------------------------------------------*/

/**
 * @brief 校验authkey
 * @param[in] msg           [输入hex数组]
 * @return int              [时间差，单位为秒]
 */
static int vesync_verificate_authkey(uint8_t * msg)
{
    cJSON * p_root_json = NULL;

    if (NULL == msg)
    {
        return SDK_FAIL;
    }

    SDK_LOG(LOG_DEBUG, "authkey:%s.\n",msg);
    p_root_json = cJSON_Parse((char *)msg);
    if (NULL == p_root_json)
    {
        SDK_LOG(LOG_ERROR, "TCP verifivation json parse fail.\n");
        return SDK_FAIL;
    }

    cJSON * p_auth_key = cJSON_GetObjectItemCaseSensitive(p_root_json, "auth_key");
    if (cJSON_IsString(p_auth_key))
    {
        SDK_LOG(LOG_DEBUG,"receive auth_key:%s \n",p_auth_key->valuestring);
        SDK_LOG(LOG_DEBUG,"local auth_key:%s\n",s_lan_comm.authkey);
        if ((NULL != s_lan_comm.authkey)&&(0 == memcmp(p_auth_key->valuestring,(char *)s_lan_comm.authkey,2*LAN_COMM_KEY_SIZE)))
        {
            vesync_lan_comm_tcp_data_send(msg,0,LAN_COMM_OP_TCP_REQUEST,0,0);
            s_lan_comm.state_entry_time = vesync_task_get_tick_ms();/*校验通过后进入认证通过状态*/
            s_lan_comm.state = LAN_COMM_VERIFICATION;
            SDK_LOG(LOG_DEBUG, "TCP verifivated successfully,enter LAN_COMM_VERIFICATION state.\n");
        }
        else
        {
            SDK_LOG(LOG_ERROR,"TCP verifivated Failed! \n");
        }
    }
    else
    {
        SDK_LOG(LOG_ERROR, "TCP verifivation json get item fail.\n");
    }

    if (NULL != p_root_json)
    {
        cJSON_Delete(p_root_json);
    }

    return SDK_OK;
}

/**
 * @brief 计算tick时间差
 * @param[in] old_time           [以前的时间戳]
 * @param[in] now_time           [当前时间戳]
 * @return uint32_t              [时间差，单位为秒]
 */
static uint64_t vesync_compute_time_difference(uint64_t old_time, uint64_t now_time)
{
    uint64_t difference = 0;

    if (old_time <= now_time)
    {
        difference = now_time - old_time;
    }
    else
    {
        difference = now_time + (vesync_task_get_max_tick_ms() - old_time);
    }

    // 将毫秒换算成秒
    return (difference / 1000);
}


/**
 * @brief 初始化局域网通信参数
 * @param[in] hex           [输入hex数组]
 * @param[in] len           [hex数组长度]
 * @param[out] str          [输出字符串]
 * @return int      [成功/失败]
 */
static void vesync_hex2string(uint8_t * hex ,uint32_t len ,uint8_t * str)
{
    uint8_t tmp1 = 0x0, tmp2 = 0x0;

    for (uint32_t idx = 0; idx < len; idx++)
    { // 格式转换
        tmp1 = (hex[idx]>>4)&0x0F;
        tmp2 = hex[idx]&0x0F;

        if (tmp1 < 0xA)
            str[idx*2] = tmp1 + 0x30;
        else // A~F
            str[idx*2] = tmp1 + 0x37;
        if (tmp2 < 0xA)
            str[idx*2+1] = tmp2 + 0x30;
        else // A~F
            str[idx*2+1] = tmp2 + 0x37;
    }
}


/**
 * @brief 初始化局域网通信参数
 * @param[in/out] cid_in           [输入值为CID，输出值为CID的MD5值]
 * @param[in] len                  [CID长度]
 * @return int                     [成功/失败]
 */
static int vesync_lan_comm_get_cid_md5(uint8_t * cid_in,uint32_t len)
{
    mbedtls_md5_context *p_md5 = NULL;
    uint8_t hash[16] = {0};

    p_md5 = (mbedtls_md5_context*)vesync_malloc(sizeof(mbedtls_md5_context) +1 ) ;
    if (NULL == p_md5)
    {
        return SDK_FAIL;
    }

    memset(p_md5, 0, sizeof(mbedtls_md5_context) + 1 );
    mbedtls_md5_init(p_md5);
#if !defined(MBEDTLS_DEPRECATED_REMOVED)
    mbedtls_md5_starts(p_md5);
#else
    mbedtls_md5_starts_ret(p_md5);
#endif
    mbedtls_md5_update(p_md5, cid_in, len);
    mbedtls_md5_finish(p_md5, hash);
    mbedtls_md5_free(p_md5);
    vesync_free(p_md5);

    vesync_hex2string(hash,16,cid_in);
    SDK_LOG(LOG_DEBUG, "cid_md5:%s\n",cid_in);
    return SDK_OK;
}



/**
 * @brief 初始化局域网通信参数
 * @return int      [成功/失败]
 */
static int  vesync_lan_comm_para_init(void )
{
    uint8_t port[2] = {0,0};

    if (NULL == s_key_protect_muex)
    {
        s_key_protect_muex = vesync_mutex_new();
        if (NULL == s_key_protect_muex)
        {
            SDK_LOG(LOG_ERROR,"LAN_COMM Key protect mutex create fail \n");
        }
    }

    s_lan_comm.state = LAN_COMM_IDLE;
    s_lan_comm.aes = NULL;
    s_lan_comm.authkey = NULL;
    s_lan_comm.udp_socket_fd = -1;
    s_lan_comm.tcp_socket_fd = -1;
    s_lan_comm.tcp_conn_fd = -1;

    /*generate tcp port */
    vesync_aes_generate_key(port, 2);

    s_lan_comm_tcp_port = (port[0] << 8) + port[1];
    s_lan_comm_tcp_port = 64000 + (s_lan_comm_tcp_port % 1000);
    SDK_LOG(LOG_DEBUG,"LAN_COMM TCP port is %d\n",s_lan_comm_tcp_port);

    /*generate udp port */
    s_lan_comm_udp_port = LAN_COMM_UDP_PORT;
    SDK_LOG(LOG_DEBUG,"LAN_COMM UDP port is %d\n",s_lan_comm_udp_port);

    return SDK_OK;
}

/**
 * @brief 局域网通信协议头部校验，以及数据头参数提取
 * @param[in] data           [数据缓存地址]
 * @param[in] len            [接收到的数据长度]
 * @param[out] head          [存储数据头部参数的结构体指针]
 * @param[out] outlen        [存储数据头部参数的结构体指针]
 * @param[in]  payload       [接收到的数据pyload的起始地址]
 * @return int               [成功/失败]
 */
static int vesync_lan_comm_prot_head_get(uint8_t* data ,int len, payload_info_t* head,uint32_t *outlen,uint8_t** payload)
{
    if ((NULL == data)||(NULL == head))
    {
        return SDK_FAIL;
    }

    int ret = 0;
    uint8_t * p_msg_data = data + LAN_PROT_HEADER_LEN;
    uint32_t msg_len = len;
    *payload = p_msg_data + 4;

    //LOG_RAW_HEX(LOG_INFO, "p_msg_data:", p_msg_data, 4);

    ret = vesync_lan_trans_prot_parse(data,&msg_len);
    if (SDK_OK != ret)
    {
        SDK_LOG(LOG_ERROR, "Parse data error!!\n");
        return SDK_FAIL;
    }
    head->version = p_msg_data[0];
    head->opcode = ntohs(*((uint16_t *) & p_msg_data[1]));
    head->status_code = p_msg_data[3];
    *outlen = msg_len;

    return ret ;
}


/**
* @brief    局域网connected状态数据包处理回调函数
* @param[in]  *p_data  [完整数据包buffer]
* @param[in]  data_len [数据长度]
*/
void vesync_lan_connected_cb(uint8_t *p_data, uint32_t data_len)
{
    uint8_t * p_msg_data = NULL;
    payload_info_t msg;
    uint32_t pyload_len = 0;
    uint8_t * p_decrypt_data = NULL;
    uint32_t decrypt_data_len = 0;

    memset(&msg, 0, sizeof(payload_info_t));
    vesync_lan_comm_prot_head_get((uint8_t *)p_data, data_len, &msg, &pyload_len,&p_msg_data);
    if ((LAN_COMM_PROTOCOL_VERSION == (LAN_COMM_PROTOCOL_VERSION & (msg.version))) &&
        (LAN_COMM_OP_TCP_REQUEST == msg.opcode))
    {
        /*payload解密*/
        decrypt_data_len = vesync_aes_decrypt(p_msg_data, pyload_len - LAN_COMM_PROT_DATA_HEAD_SIZE, &p_decrypt_data);
        /*auth_key校验*/
        if ((0 == decrypt_data_len))
        {
            SDK_LOG(LOG_ERROR, "TCP verifivation decrypt fail.\n");
            VCOM_SAFE_FREE(p_decrypt_data);
        }
        vesync_verificate_authkey(p_decrypt_data);
    }
}


/**
 * @brief 局域网通信Idle状态下udp 消息处理接口
 * @param[in] buffer         [udp数据接收缓存起始地址]
 * @param[in] len            [数据接收缓存的最大长度]
 * @return int               [成功/失败]
 */
static int vesync_lan_comm_udp_msg_handler(char* buffer,int len)
{
    int ret = 0;
    uint32_t sock_len = 0;
    uint32_t pyload_len;
    char t_ip[IP_BUFFER_SIZE+1];
    uint8_t t_cid[DEVICE_CID_LEN+1];
    uint32_t reply_len = 0;
    uint8_t * unicast_reply = NULL;
    uint8_t * unicast_data = NULL;
    uint8_t * p_msg_data = NULL;
    char* p_reply = NULL;
    cJSON * root = NULL;
    payload_info_t msg;
    struct sockaddr_in remote_udp;

    if (NULL == buffer)
    {
        return SDK_FAIL;
    }

    memset(t_ip, 0, IP_BUFFER_SIZE + 1);
    memset(t_cid, 0, DEVICE_CID_LEN + 1);
    memset(&msg, 0, sizeof(payload_info_t));
    memset(&remote_udp, 0, sizeof(struct sockaddr_in));
    sock_len = sizeof(remote_udp);

    /*监听UDP是否有数据*/
    ret = vesync_udp_recv(s_lan_comm.udp_socket_fd,LAN_COMM_RECV_TIMEOUT,buffer,len,&remote_udp,&sock_len);
    if (0 < ret)
    {
        vesync_log_hex_print(LOG_INFO,"udp receive data:\n",buffer,ret);
        //SDK_LOG(LOG_INFO, "form:%s!\n",inet_ntoa(remote_udp.sin_addr));

        ret = vesync_lan_comm_prot_head_get((uint8_t *)buffer,ret,&msg,&pyload_len,&p_msg_data);
        //SDK_LOG(LOG_INFO, "opcode:%d!\n",msg.opcode);
        if (SDK_OK == ret)
        {
            if ((LAN_COMM_PROTOCOL_VERSION == (LAN_COMM_PROTOCOL_VERSION&msg.version)) &&
                (LAN_COMM_OP_UDP_BROADCAST == msg.opcode))
            {
                // 回复UDP单播消息
                memcpy(t_cid, vesync_device_get_cid(), DEVICE_CID_LEN);
                vesync_lan_comm_get_cid_md5(t_cid, DEVICE_CID_LEN);

                root = cJSON_CreateObject();
                if (NULL == root)
                {
                    SDK_LOG(LOG_ERROR, "unicast_reply creat fail!\n");
                    return SDK_FAIL;
                }

                if (NULL == cJSON_AddStringToObject(root, "ip", vhal_utils_get_sta_ip(t_ip,IP_BUFFER_SIZE)))
                {
                    SDK_LOG(LOG_ERROR, "unicast_reply creat cJson ip string fail!\n");
                    goto exit;
                }

                if (NULL == cJSON_AddStringToObject(root, "cid", (char *)t_cid))
                {
                    SDK_LOG(LOG_ERROR, "unicast_reply creat cJson ip string fail!\n");
                    goto exit;
                }

                p_reply = cJSON_PrintUnformatted(root);
                if (NULL == p_reply)
                {
                    SDK_LOG(LOG_ERROR, "unicast_reply printunformatted fail!\n");
                    goto exit;
                }

                SDK_LOG(LOG_DEBUG, "unicast_reply json:%s!\n",p_reply);
                unicast_reply = (uint8_t *)vesync_malloc(UDP_REPLY_SIZE);
                unicast_data = (uint8_t *)vesync_malloc(UDP_REPLY_SIZE);
                if ((NULL != unicast_reply)&&(NULL != unicast_data))
                {
                    unicast_data[0] = msg.version;
                    unicast_data[1] = (msg.opcode >> 8);
                    unicast_data[2] = msg.opcode;
                    unicast_data[3] = 0x00; // all is ok

                    strcpy((char *)(&unicast_data[4]), p_reply);
                    reply_len = LAN_COMM_PROT_DATA_HEAD_SIZE + strlen(p_reply) ;
                    vesync_lan_trans_prot_pack(unicast_reply,unicast_data,&reply_len,1);
                    sendto(s_lan_comm.udp_socket_fd,unicast_reply,reply_len,0,\
                          (struct sockaddr *)&remote_udp,sock_len);
                    //for test
                    //s_lan_comm.state_entry_time = vesync_task_get_tick_ms();
                    //s_lan_comm.state = LAN_COMM_DISCOVERY;
                }

                vesync_free(unicast_reply);
                vesync_free(unicast_data);
                vesync_free(p_reply);
            }
        }
    }

exit:
    if (NULL != root)
    {
        cJSON_Delete(root);
    }

    p_reply = NULL;
    return ret;
}

static int vesync_lan_comm_notify_bypass(char *data)
{
    if (data == NULL)
    {
        return SDK_FAIL;
    }

    if (NULL != s_lan_tcp_data_recv_cb)
    {
        s_lan_tcp_data_recv_cb(data);
    }

    return SDK_OK;
}

/**
 * @brief 局域网通信建立后tcp 消息处理接口
 * @param[in] buffer         [tcp 数据接收缓存起始地址]
 * @param[in]  len           [数据接收缓存的最大长度]
 */
static void vesync_lan_comm_tcp_msg_handler(uint8_t* buffer,uint32_t len)
{
    int ret = 0;
    uint8_t * p_msg_data = NULL;
    uint8_t * p_decrypt_data = NULL;
    uint32_t decrypt_data_len = 0;
    uint32_t pyload_len;
    payload_info_t msg ;

    if (NULL == buffer)
    {
        return ;
    }

    ret = vesync_lan_comm_prot_head_get((uint8_t *)buffer,len,&msg,&pyload_len,&p_msg_data);
    if (SDK_OK == ret)
    {
        if (LAN_COMM_PROTOCOL_VERSION == (LAN_COMM_PROTOCOL_VERSION&msg.version))
        {
            /*payload解密*/
            decrypt_data_len = vesync_aes_decrypt(p_msg_data, pyload_len-LAN_COMM_PROT_DATA_HEAD_SIZE, &p_decrypt_data);
            if ((0 == decrypt_data_len))
            {
                SDK_LOG(LOG_ERROR, "TCP msg decrypt fail.\n");
                vesync_free(p_decrypt_data);
                return ;
            }

            switch (msg.opcode)
            {
                case LAN_COMM_OP_TCP_COMMUNICATE:
                    SDK_LOG(LOG_DEBUG, "TCP receive msg :%s.\n",p_decrypt_data);
                    vesync_lan_comm_notify_bypass((char*)p_decrypt_data);
                    break;

                case LAN_COMM_OP_TCP_REQUEST:
                    vesync_verificate_authkey(p_decrypt_data);
                    break;

                default:
                    break;
            }

            vesync_free(p_decrypt_data);
            s_lan_comm.state_entry_time = vesync_task_get_tick_ms();
        }
    }

}


/**
 * @brief 申请aes密钥和auth_key的存储空间，并生成aes密钥和auth_key
 * @return int      [成功/失败]
 */
static int vesync_lan_comm_generate_key(void)
{
    int ret = SDK_FAIL;
    uint8_t t_auth_key[LAN_COMM_KEY_SIZE] = {0};

    if (NULL == s_key_protect_muex)
    {
        s_key_protect_muex = vesync_mutex_new();
    }

    if (NULL != s_key_protect_muex)
    {
        vesync_mutex_lock(s_key_protect_muex);
        if (NULL == s_lan_comm.aes)
        {
            s_lan_comm.aes = (uint8_t*)vesync_malloc(LAN_COMM_KEY_SIZE);
        }

        if (NULL == s_lan_comm.authkey)
        {
            s_lan_comm.authkey = (uint8_t*)vesync_malloc(2*LAN_COMM_KEY_SIZE+1);
        }

        if ((NULL != s_lan_comm.aes) && (NULL != s_lan_comm.authkey))
        {
            vesync_aes_generate_key(s_lan_comm.aes,LAN_COMM_KEY_SIZE);
            //memcpy(s_lan_comm.aes,aes_test,LAN_COMM_KEY_SIZE);
            vesync_log_hex_print(LOG_INFO,"lan_comm aes key:\n",s_lan_comm.aes,LAN_COMM_KEY_SIZE);

            vesync_aes_generate_key(t_auth_key,LAN_COMM_KEY_SIZE);
            //memcpy(t_auth_key,authkey_test,LAN_COMM_KEY_SIZE);
            vesync_hex2string(t_auth_key,LAN_COMM_KEY_SIZE,s_lan_comm.authkey);
            SDK_LOG(LOG_INFO, "lan_comm auth_key:%s.\n",s_lan_comm.authkey);

            vesync_aes_reg_key(s_lan_comm.aes,s_lan_comm.aes); //注册aes密钥
            s_lan_comm.key_generate_time = vesync_task_get_tick_ms();
            ret = SDK_OK;
        }
        else
        {
            SDK_LOG(LOG_ERROR,"auth_key or aes buffer vesync_malloc fail\n");
        }

        vesync_mutex_unlock(s_key_protect_muex);
    }

    return ret;
}


/**
 * @brief 释放aes密钥和auth_key的存储空间
 */
static void vesync_lan_comm_relese_key(void)
{
    if (NULL != s_key_protect_muex)
    {
        vesync_mutex_lock(s_key_protect_muex);
        VCOM_SAFE_FREE(s_lan_comm.aes);
        VCOM_SAFE_FREE(s_lan_comm.authkey);
        vesync_mutex_unlock(s_key_protect_muex);
        SDK_LOG(LOG_DEBUG, "Relese aes and auth_key message.\n");
    }
}

/**
 * @brief 局域网通信discovered状态工作接口
 * @return int      [成功/失败]
 */
static int vesync_lan_comm_discovered(void)
{
    int ret = 0;
    uint64_t t_time = 0;

    if (0 > s_lan_comm.tcp_socket_fd)
    {
        ret = vesync_tcp_sever_init(&s_lan_comm.tcp_addr,&s_lan_comm.tcp_socket_fd,s_lan_comm_tcp_port,LAN_COMM_TCP_LISTEN_NUM);
        //for test
        vesync_lan_comm_generate_key();
    }

    if (0 == ret)/*socket created successfully*/
    {
        ret = vesync_tcp_sever_accept(s_lan_comm.tcp_socket_fd,&s_lan_comm.tcp_conn_fd,&s_lan_comm.tcp_addr,LAN_COMM_RECV_TIMEOUT);
        if (0 == ret)/*timeout or accepted successfully*/
        {
            if (0 <=  s_lan_comm.tcp_conn_fd) /*accepted successfully*/
            {
                s_lan_comm.state_entry_time = vesync_task_get_tick_ms();
                s_lan_comm.state = LAN_COMM_CONNECTED;
                s_offset = 0;

                if (0 <= s_lan_comm.udp_socket_fd)//close udp
                {
                    vesync_udp_stop(&s_lan_comm.udp_socket_fd);
                }

                SDK_LOG(LOG_DEBUG, "APP connected equipment's tcp server, equipment enter  LAN_COMM_CONNECTED state !\n");
            }
            else/*timeout*/
            {
                t_time = vesync_task_get_tick_ms();
                if (LAN_COMM_DISCOVERED_TIMEOUT <= vesync_compute_time_difference(s_lan_comm.state_entry_time,t_time))
                {
                    if (LAN_COMM_DISCOVERY == s_lan_comm.state)
                    {
                        SDK_LOG(LOG_DEBUG, "TCP server accept timeout, socket_fd = %d,time:%d,entry_time:%d.\n",s_lan_comm.tcp_socket_fd,t_time,\
                                                s_lan_comm.state_entry_time);
                        s_lan_comm.state = LAN_COMM_IDLE;
                        s_lan_comm.state_entry_time = vesync_task_get_tick_ms();
                    }
                }
            }

            return SDK_OK;
        }
    }

    SDK_LOG(LOG_ERROR, "TCP server error,has closed, enter idle state ,socket_fd = %d.\n",s_lan_comm.tcp_socket_fd);
    s_lan_comm.state = LAN_COMM_IDLE;
    vesync_tcp_stop(&s_lan_comm.tcp_socket_fd);
    s_lan_comm.state_entry_time = vesync_task_get_tick_ms();

    return SDK_FAIL;
}



/**
 * @brief 局域网通信connected状态工作接口
 * @return int      [成功/失败]
 */
static int vesync_lan_comm_connected(void)
{
    int ret = SDK_OK;
    uint64_t t_time = 0;

    ret = vesync_tcp_recv(s_lan_comm.tcp_conn_fd, LAN_COMM_RECV_TIMEOUT, s_lan_comm_msg + s_offset, LAN_COMM_BUFFER_SIZE - s_offset);
    if (0 < ret)
    {
        if ((ret + s_offset) >= LAN_COMM_BUFFER_SIZE)
        {
            SDK_LOG(LOG_ERROR, "frame is too long to cache\n");
        }

        s_offset = vesync_tcp_data_parse((uint8_t*)s_lan_comm_msg, ret + s_offset, vesync_lan_connected_cb);
    }
    else if (0 == ret)
    {
        t_time = vesync_task_get_tick_ms();
        if (LAN_COMM_VERIFICATION_TIMEOUT <= vesync_compute_time_difference(s_lan_comm.state_entry_time,t_time))
        {
            s_lan_comm.state = LAN_COMM_IDLE;
            SDK_LOG(LOG_INFO, "TCP server verification timeout, socket_fd:%d\n", s_lan_comm.tcp_conn_fd);
            vesync_tcp_stop(&s_lan_comm.tcp_conn_fd);
            s_lan_comm.state_entry_time = vesync_task_get_tick_ms();
        }
    }
    else /*recv fail ,need to be checked*/
    {
        s_lan_comm.state = LAN_COMM_IDLE;
        vesync_tcp_stop(&s_lan_comm.tcp_conn_fd);
        SDK_LOG(LOG_WARN, "TCP closed, connected_fd:%d\n", s_lan_comm.tcp_conn_fd);
        ret =  SDK_FAIL;
    }

    return ret;
}


/**
 * @brief 局域网通信状态verificated工作接口
 * @return int      [成功/失败]
 */
static int vesync_lan_comm_verificated(void)
{
    int ret = 0;
    uint64_t t_time = 0;

    ret = vesync_tcp_recv(s_lan_comm.tcp_conn_fd,LAN_COMM_RECV_TIMEOUT,s_lan_comm_msg + s_offset,LAN_COMM_BUFFER_SIZE - s_offset);
    if (0 < ret)
    {
        if ((ret + s_offset) >= LAN_COMM_BUFFER_SIZE)
        {
            SDK_LOG(LOG_WARN, "use up buffer\n");
        }

        t_time = vesync_task_get_tick_ms();
        SDK_LOG(LOG_DEBUG, "message receive time:%u-%u\n", (uint32_t)(t_time >> 32), (uint32_t)t_time);
        s_offset = vesync_tcp_data_parse((uint8_t*)s_lan_comm_msg, ret + s_offset, vesync_lan_comm_tcp_msg_handler);
    }
    else if (0 == ret)
    {
        t_time = vesync_task_get_tick_ms();
        if (LAN_COMM_CONNECTED_TIMEOUT <= vesync_compute_time_difference(s_lan_comm.state_entry_time,t_time))
        {
            s_lan_comm.state = LAN_COMM_IDLE;
            vesync_tcp_stop(&s_lan_comm.tcp_conn_fd);
            s_lan_comm.state_entry_time = t_time;
            SDK_LOG(LOG_INFO, "TCP server wait message timeout, socket_fd:%d\n", s_lan_comm.tcp_conn_fd);
        }
    }
    else /*recv fail ,need to be checked*/
    {
        s_lan_comm.state = LAN_COMM_IDLE;
        vesync_tcp_stop(&s_lan_comm.tcp_conn_fd);
        SDK_LOG(LOG_ERROR, "TCP closed, connected_fd:%d\n", s_lan_comm.tcp_conn_fd);
        return SDK_FAIL;
    }

    return SDK_OK;
}

/**
 * @brief 局域网通信任务主函数
 * @return int      [成功/失败]
 */
static void vesync_lan_comm_thread(void *args)
{
    uint64_t t_time = 0;

    s_lan_comm_msg = (char *)vesync_malloc(LAN_COMM_BUFFER_SIZE);
    if (NULL == s_lan_comm_msg)
    {
        goto exit;
    }

    SDK_LOG(LOG_INFO, "lan_comm thread run\n");

    while (1)
    {
        switch (s_lan_comm.state)
        {
            case LAN_COMM_IDLE:
                if (0 > s_lan_comm.udp_socket_fd)
                {
                    vesync_udp_init(&s_lan_comm.udp_addr,&s_lan_comm.udp_socket_fd,s_lan_comm_udp_port);
                }
                else
                {
                    vesync_lan_comm_udp_msg_handler(s_lan_comm_msg,LAN_COMM_BUFFER_SIZE);/*udp message handler*/
                }

                if (0 <= s_lan_comm.tcp_socket_fd)
                {
                    t_time = vesync_task_get_tick_ms();
                    if ((LAN_COMM_KEY_UPDATE_PERIOD <= vesync_compute_time_difference(s_lan_comm.key_generate_time,t_time)) ||
                        (LAN_COMM_IDLE_TIMEOUT <= vesync_compute_time_difference(s_lan_comm.state_entry_time,t_time)))
                    {
                        vesync_lan_comm_relese_key();
                        vesync_tcp_stop(&s_lan_comm.tcp_socket_fd);
                        SDK_LOG(LOG_INFO, "TCP server closed, socket_fd:%d, time:%u-%u\n", s_lan_comm.tcp_socket_fd,
                                (uint32_t)(t_time >> 32), (uint32_t)t_time);
                    }
                    else
                    {
                        vesync_lan_comm_discovered();
                    }
                }
                break;
            case LAN_COMM_DISCOVERY:
                vesync_lan_comm_discovered();
                break;
            case LAN_COMM_CONNECTED:
                vesync_lan_comm_connected();
                break;
            case LAN_COMM_VERIFICATION:
                vesync_lan_comm_verificated();
                break;
            case LAN_COMM_SHUTDOWN:
                goto exit;
            default:
                break;
        }

        vesync_sleep(LAN_COMM_TASK_DELAY_TIME);
    }
exit:
    vesync_lan_comm_stop();
}


/*-----------------------------------------------------------------------------*
*-----------------------------------SDK函数API实现-------------------------------*
*-----------------------------------------------------------------------------*/

/**
 * @brief     tcp数据回调函数注册
 * @param[in] cb
 */
void vesync_lan_reg_tcp_data_recv_cb(vesync_lan_msg_recv_callback_t cb)
{
    s_lan_tcp_data_recv_cb = cb;
}


/**
 * @brief 局域网通信功能入口（初始化局域网参数，创建udp socket,创建局域网通信任务）
 * @return int      [成功/失败]
 */
int vesync_lan_comm_start(void )
{
    vesync_lan_comm_para_init();
    vesync_udp_init(&s_lan_comm.udp_addr,&s_lan_comm.udp_socket_fd,s_lan_comm_udp_port);

    int ret = vesync_task_new(LAN_COMM_TASK_NAME,
                                NULL,
                                vesync_lan_comm_thread,
                                NULL,
                                LAN_COMM_TASK_STACSIZE,
                                LAN_COMM_TASK_PRIO,
                                &s_lan_comm_taskhd);
    if (VOS_OK != ret)
    {
        SDK_LOG(LOG_ERROR, "Cannot create developer tcp server thread.\n");
        vesync_udp_stop(&s_lan_comm.udp_socket_fd);
        s_lan_comm_taskhd = NULL;
        return SDK_FAIL;
    }

    SDK_LOG(LOG_DEBUG, "LAN communication service start ,equipment state is idle!\n");
    return SDK_OK;
}

/**
 * @brief 局域网通信功能开启TCP sever
 * @return int      [成功/失败]
 */
int vesync_lan_comm_tcp_start(void)
{
    int ret = SDK_FAIL;
    int retry_count = 0;


    if (0 > s_lan_comm.tcp_socket_fd)
    {
        ret = vesync_tcp_sever_init(&s_lan_comm.tcp_addr,&s_lan_comm.tcp_socket_fd,s_lan_comm_tcp_port,LAN_COMM_TCP_LISTEN_NUM);
    }
    else
    {
        ret = SDK_OK;
    }

    if  (0 <=  s_lan_comm.tcp_conn_fd)//已建立连接，禁止重复连接
    {
        return SDK_FAIL;
    }

    s_lan_comm.state_entry_time = vesync_task_get_tick_ms();
    s_lan_comm.state = LAN_COMM_DISCOVERY;

    if (SDK_OK == ret)
    {
        SDK_LOG(LOG_DEBUG, "LAN communication tcp server start,equiment state is Discovered !\n");
        ret = SDK_FAIL;
        for (retry_count = 3;((0 < retry_count)&&(ret == SDK_FAIL));retry_count--)
        {
            ret = vesync_lan_comm_generate_key();
        }
    }

    if (0 <= s_lan_comm.udp_socket_fd)//close udp
    {
        vesync_udp_stop(&s_lan_comm.udp_socket_fd);
    }

    return ret;
}

/**
 * @brief 局域网通信功能TCP 数据发送
 * @param[in] data             [将要发送的数据]
 * @param[in] len              [数据长度]
 * @param[in] opcode           [指令操作码]
 * @param[in] encrypt_flag     [加密标记位：1为需要加密，0为不需要加密]
 * @param[in] status           [响应状态]
 * @return int                 [成功/失败]
 */
int vesync_lan_comm_tcp_data_send(uint8_t *data, uint32_t len,uint16_t opcode, uint8_t encrypt_flag, uint8_t status)
{
    int ret = SDK_FAIL;
    uint8_t * p_msg_pack = NULL;
    uint8_t * p_pyload = NULL;
    uint8_t *p_encrypt =NULL;
    uint64_t t_time = 0;
    uint32_t data_len = 0;
    payload_info_t * p_data_head = NULL;

    if (NULL == data)
    {
        return ret;
    }
    data_len = len;

    if (0 > s_lan_comm.tcp_conn_fd)
    {
        return ret;
    }

    if (LAN_COMM_ENCRYPT == encrypt_flag)
    {
        data_len = vesync_aes_encrypt(data, len, &p_encrypt);

        p_pyload =(uint8_t *) vesync_malloc(data_len + LAN_COMM_PROT_DATA_HEAD_SIZE);
        if (NULL == p_pyload)
        {
            VCOM_SAFE_FREE(p_encrypt);
            return ret;
        }

        memset(p_pyload, 0, data_len + LAN_COMM_PROT_DATA_HEAD_SIZE);
        p_pyload[0] = 0x10;
        if (data_len != 0)
        {
            memcpy((p_pyload + LAN_COMM_PROT_DATA_HEAD_SIZE), p_encrypt, data_len);
        }
        VCOM_SAFE_FREE(p_encrypt);
    }
    else
    {
        p_pyload =(uint8_t *) vesync_malloc(data_len + LAN_COMM_PROT_DATA_HEAD_SIZE);
        if (NULL == p_pyload)
        {
            return ret;
        }

        memset(p_pyload, 0, data_len + LAN_COMM_PROT_DATA_HEAD_SIZE);
        if (data_len != 0)
        {
            memcpy((p_pyload + LAN_COMM_PROT_DATA_HEAD_SIZE), data, data_len);
        }
    }

    p_data_head = (payload_info_t *)p_pyload;
    p_data_head->version |= LAN_COMM_PROTOCOL_VERSION;
    p_data_head->opcode = ntohs(opcode);
    p_data_head->status_code = status;
    data_len = data_len + LAN_COMM_PROT_DATA_HEAD_SIZE;
    p_msg_pack =(uint8_t *) vesync_malloc(data_len + LAN_PROT_HEADER_LEN);
    if (NULL == p_msg_pack)
    {
        VCOM_SAFE_FREE(p_pyload);
        return ret;
    }

    memset(p_msg_pack, 0, data_len + LAN_PROT_HEADER_LEN);
    ret = vesync_lan_trans_prot_pack(p_msg_pack, p_pyload, &data_len, 1);
    if (SDK_OK == ret)
    {
#if 0
        vesync_log_hex_print(LOG_DEBUG,"lan_comm tcp server send:", p_msg_pack, data_len);
#endif
        ret = send(s_lan_comm.tcp_conn_fd, p_msg_pack, data_len, 0);
        if (0 >= ret)
        {
            SDK_LOG(LOG_ERROR, "send data failed[%d]\n", ret);
        }
        t_time = vesync_task_get_tick_ms();
        SDK_LOG(LOG_DEBUG, "send time:%u-%u, data length:%u\n", (uint32_t)(t_time >> 32), (uint32_t)t_time, data_len);
    }

    VCOM_SAFE_FREE(p_msg_pack);
    VCOM_SAFE_FREE(p_pyload);
    return ret;
}


/**
 * @brief 获取TCP端口号
 * @return uint32-t           [TCP端口号]
 */
uint32_t vesync_lan_comm_get_tcp_port(void)
{
    return s_lan_comm_tcp_port ;
}

/**
 * @brief 获取AES字符串
 * @param[in] aes             [存储aes密钥地址，空间至少32个字节]
 * @param[in/out] aes         [输入为缓存最大长度，输出为实际字符串长度]
 * @return int                [0：成功/1：失败]
 */
int vesync_lan_comm_get_aes(uint8_t * aes,uint32_t * len)
{
    int ret = SDK_FAIL;
    uint32_t length =  *len;


    if ((NULL != aes) && (NULL != s_lan_comm.aes))
    {
        memset(aes,0,length);
        vesync_hex2string(s_lan_comm.aes,LAN_COMM_KEY_SIZE,aes);
        ret = SDK_OK;
    }

    return ret;
}

/**
 * @brief 获取auth_key字符串
 * @param[in] auth_key             [存储auth_key地址，空间至少32个字节]
 * @return int                     [0：成功/1：失败]
 */
int vesync_lan_comm_get_authkey(uint8_t * auth_key)
{
    int ret = SDK_FAIL;

    if ((NULL != auth_key)&&(NULL != s_lan_comm.authkey))
    {
        strncpy((char *)auth_key,(char *)s_lan_comm.authkey,2*LAN_COMM_KEY_SIZE);
        ret = SDK_OK;
    }

    return ret;
}

/**
 * @brief 局域网通信功能关闭
 * @return int      [成功/失败]
 */
void vesync_lan_comm_stop(void)
{
    if (LAN_COMM_SHUTDOWN != s_lan_comm.state)
    {
        if (0 <= s_lan_comm.udp_socket_fd)//close udp
        {
            vesync_udp_stop(&s_lan_comm.udp_socket_fd);
        }

        if (0 <= s_lan_comm.tcp_conn_fd)//close tcp connect
        {
            vesync_tcp_stop(&s_lan_comm.tcp_conn_fd);
        }

        if (0 <= s_lan_comm.tcp_socket_fd)//close tcp sever
        {
            vesync_tcp_stop(&s_lan_comm.tcp_socket_fd);
        }

        VCOM_SAFE_FREE(s_lan_comm_msg);
        vesync_lan_comm_relese_key();
        SDK_LOG(LOG_DEBUG, "[lan_comm_thread] exit task.\n");
        s_lan_comm_taskhd = NULL;
        s_lan_comm.state = LAN_COMM_SHUTDOWN;
    }
    else
    {
        SDK_LOG(LOG_DEBUG, "lan_comm_thread task already exit.\n");
    }
}

