/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_bypass_light.c
 * @brief       bypass处理接口
 * @date        2021-05-17
 */
#include <string.h>

#include "vesync_common.h"
#include "vesync_memory.h"
#include "vesync_log_internal.h"
#include "vesync_bypass_internal.h"

/**
 * @brief 设置调光数据
 * @param p_trace_msg trace message
 * @param json数据指针
 * @return BYPASS_ERR_E
 */
static BYPASS_ERR_E bypass_method_set_lights_handle(bypass_trace_msg_t *p_trace_msg, cJSON *json)
{
    BYPASS_ERR_E ret = BP_OK;
    cJSON* json_data = NULL;

    if ((NULL == json)||(NULL == p_trace_msg))    return BP_ERROR;

    bypass_light_base_t *pLight_data = (bypass_light_base_t *)vesync_malloc(sizeof(bypass_light_base_t));
    if (NULL == pLight_data)
    {
        return BP_ERR_NOMEM;
    }

    memset(pLight_data, 0, sizeof(bypass_light_base_t));

    json_data = cJSON_GetObjectItemCaseSensitive(json, "action");
    if (cJSON_IsString(json_data))
    {
        memcpy(pLight_data->action, json_data->valuestring, sizeof(pLight_data->action) - 1);
        SDK_LOG(LOG_DEBUG,"action : %s\r\n",pLight_data->action);
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "colorMode");
    if (cJSON_IsString(json_data))
    {
        memcpy(pLight_data->colorMode, json_data->valuestring, sizeof(pLight_data->colorMode) - 1);
        SDK_LOG(LOG_DEBUG,"colorMode : %s\r\n",pLight_data->colorMode);
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "brightness");
    if (cJSON_IsNumber(json_data))
    {
        pLight_data->bright = json_data->valueint&0xFF;
        SDK_LOG(LOG_DEBUG,"bright : %d\r\n",pLight_data->bright);
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "red");
    if (cJSON_IsNumber(json_data))
    {
        pLight_data->red = json_data->valueint&0xFF;
        SDK_LOG(LOG_DEBUG,"red : %d\r\n",pLight_data->red);
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "green");
    if (cJSON_IsNumber(json_data))
    {
        pLight_data->green = json_data->valueint&0xFF;
        SDK_LOG(LOG_DEBUG,"green : %d\r\n",pLight_data->green);
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "blue");
    if (cJSON_IsNumber(json_data))
    {
        pLight_data->blue = json_data->valueint&0xFF;
        SDK_LOG(LOG_DEBUG,"blue : %d\r\n",pLight_data->blue);
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }
    json_data = cJSON_GetObjectItemCaseSensitive(json, "speed");
    if (cJSON_IsNumber(json_data))
    {
        pLight_data->speed = json_data->valueint&0xFF;
        SDK_LOG(LOG_DEBUG,"speed : %d\r\n",pLight_data->speed);
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }
    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_SET_LIGHT);
    if (method_cb)
    {
        method_cb(p_trace_msg, (void*)pLight_data, sizeof(bypass_light_base_t));
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

_exit:
    vesync_free(pLight_data);
    return ret;
}

/**
 * @brief "getLightStatus" method数据解析
 * @param p_trace_msg trace message
 * @param json数据指针
 * @return BYPASS_ERR_E
 */
static BYPASS_ERR_E bypass_method_get_lights_handle(bypass_trace_msg_t *p_trace_msg, cJSON *json)
{
    UNUSED(json);
    if (NULL == p_trace_msg)   return BP_ERROR;
    BYPASS_ERR_E ret = BP_OK;
    //查询无需解析json
    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_GET_LIGHT);
    if (method_cb)
    {
        method_cb(p_trace_msg, NULL, 0);
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

    return ret;
}

static bypass_item_data_t light_method_tbl[] = {
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_SET_LIGHT, "setLightStatus", bypass_method_set_lights_handle, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_GET_LIGHT, "getLightStatus", bypass_method_get_lights_handle, NULL},
};

void vesync_bypass_light_init(void)
{
    for (int i = 0; i < SIZEOF_ARRAY(light_method_tbl); i++)
    {
        bypass_item_t *item = vesync_bypass_init_item(&light_method_tbl[i]);
        if (item != NULL)
        {
            vesync_bypass_add_item(item);
        }
    }
}
