/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vhal_flash.c
 * @brief       linux mock flash读写接口封装
 * @author      Joshua
 * @date        2021-08-10
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>
#include <pthread.h>
#include "cJSON.h"
#include "vesync_log.h"
#include "vesync_memory.h"
#include "vesync_common.h"
#include "vhal_flash.h"
#include "vhal_flash_internal.h"


static pthread_rwlock_t s_rwlock;

/*-----------------------------------------------------------------------------*
 *                           内部函数API实现                                         *
 *-----------------------------------------------------------------------------*/
/**
 * @brief  NVS flash分区名映射
 * @param[in]  partition_id             [分区的ID]
 * @return     char*                    [字符串格式的分区名称]
 * @note  分区的名称对应分区表的名字
 */
static char *vhal_nvs_flash_conv_name(PARTITION_ID_E partition_id)
{
    if (partition_id <= PARTITION_MIN || partition_id >= PARTITION_MAX)
    {
        HAL_LOG(LOG_ERROR, "Invalid partition ID(%d)!\n", partition_id);
        return NULL;
    }

    switch (partition_id)
    {
        case PARTITION_DEFAULT:
            return VHAL_LINUX_DEFAULT_NVS_NAMESPACE;
        case PARTITION_FAC:
            return VHAL_LINUX_FAC_DATA_NAMESPACE;
        case PARTITION_CFG:
            return VHAL_LINUX_USER_CFG_NAMESPACE;
        case PARTITION_DATA:
            return VHAL_LINUX_DATA_CFG_NAMESPACE;
        case PARTITION_LOG:
            return VHAL_LINUX_LOG_NAMESPACE;
        default:
            break;
    }

    return NULL;
}


/**
 * @brief  从文件读取json数据
 * @param[in]  file_name             [文件路径]
 * @return  cJSON*                   [json数据]
 */
static cJSON *read_json_from_file(const char *file_name)
{
    int ret = -1;
    struct stat file_stat;
    size_t file_size = 0;
    char *buf = NULL;
    size_t read_size;
    FILE *fp = NULL;

    if (NULL == file_name)
    {
        return NULL;
    }

    pthread_rwlock_wrlock(&s_rwlock);

    // 获取文件大小
    memset(&file_stat, 0, sizeof(struct stat));
    ret = stat(file_name, &file_stat);
    if (ret != 0)
    {
        HAL_LOG(LOG_ERROR, "stat %s fail\n", file_name);
        pthread_rwlock_unlock(&s_rwlock);
        return NULL;
    }

    file_size = file_stat.st_size;
    if (file_size == 0)
    {
        HAL_LOG(LOG_ERROR, "file_size error\n");
        pthread_rwlock_unlock(&s_rwlock);
        return NULL;
    }

    // 根据文件大小申请内存
    buf = (char *)malloc(file_size + 1);
    if (NULL == buf)
    {
        HAL_LOG(LOG_ERROR, "malloc error\n");
        pthread_rwlock_unlock(&s_rwlock);
        return NULL;
    }

    memset(buf, 0, file_size + 1);

    fp = fopen(file_name, "r");
    if (NULL == fp)
    {
        VCOM_SAFE_FREE(buf);
        HAL_LOG(LOG_ERROR, "fopen fail\n");
        pthread_rwlock_unlock(&s_rwlock);
        return NULL;
    }

    read_size = fread(buf, 1, file_size, fp);
    if (read_size != file_size)
    {
        VCOM_SAFE_FREE(buf);
        fclose(fp);
        HAL_LOG(LOG_ERROR, "fread fail\n");
        pthread_rwlock_unlock(&s_rwlock);
        return NULL;
    }

    fclose(fp);
    buf[file_size] = 0;
    cJSON *p_json = cJSON_Parse(buf);
    VCOM_SAFE_FREE(buf);

    pthread_rwlock_unlock(&s_rwlock);

    return p_json;
}

/**
 * @brief  写json数据到文件中
 * @param[in]  file_name             [文件路径]
 * @param[in]  p_json*               [json数据]
 * @return  int32_t                  [0表示读取成功，非0表示失败]
 */
static int32_t write_json_to_file(const char *file_name, cJSON *p_json)
{
    pthread_rwlock_wrlock(&s_rwlock);
    FILE *fp = fopen(file_name, "w");
    if (fp == NULL)
    {
        pthread_rwlock_unlock(&s_rwlock);
        return VHAL_FAIL;
    }

    char *buf = cJSON_Print(p_json);
    fwrite(buf, strlen(buf), 1, fp);
    vesync_free(buf);

    fclose(fp);

    pthread_rwlock_unlock(&s_rwlock);

    return VHAL_OK;
}

/*-----------------------------------------------------------------------------*
 *                           外部函数API实现                                         *
 *-----------------------------------------------------------------------------*/

/**
 * @brief  flash初始化
 * @param[in]  part_id              [分区ID]
 * @return     int32_t              [错误码]
 */
int32_t vhal_flash_init(PARTITION_ID_E part_id)
{
    FILE *fp = NULL;
    char *file_name = vhal_nvs_flash_conv_name(part_id);
    if (file_name == NULL)
    {
        return VHAL_FAIL;
    }

    if (access(file_name, 0) == 0)
    {
        HAL_LOG(LOG_DEBUG, "%s inited\n", file_name);
        return VHAL_OK;
    }

    fp = fopen(file_name, "w+");
    if (fp == NULL)
    {
        HAL_LOG(LOG_ERROR, "init %s fail\n", file_name);
        return VHAL_FAIL;
    }

    fclose(fp);

    pthread_rwlock_init(&s_rwlock, NULL);

    return VHAL_OK;
}

/**
 * @brief  从flash读取数据
 * @param[in]  part_id              [分区ID]
 * @param[in]  key_name             [键值名称]
 * @param[in]  p_data               [读取数据缓存区；如果该读取Buffer为NULL，则返回该数据的长度]
 * @param[in]  p_len                [当前读取的数据长度]
 * @return  int32_t                 [成功：VHAL_OK，失败：VHAL_FAIL]
 */
int32_t vhal_flash_read(PARTITION_ID_E part_id, const char *key_name, uint8_t *p_data, uint32_t *p_len)
{
    char *file_name = vhal_nvs_flash_conv_name(part_id);
    if (file_name == NULL)
    {
        return VHAL_FAIL;
    }

    cJSON *p_json = read_json_from_file(file_name);
    if (p_json == NULL)
    {
        HAL_LOG(LOG_ERROR, "flash read fail\n");
        return VHAL_FAIL;
    }

    cJSON *p_obj = cJSON_GetObjectItem(p_json, key_name);
    if (p_obj == NULL)
    {
        cJSON_Delete(p_json);
        return VHAL_FAIL;
    }

    strncpy((char *)p_data, p_obj->valuestring, *p_len);
    cJSON_Delete(p_json);

    return VHAL_OK;
}

/**
 * @brief  往flash写入数据
 * @param[in]  part_id              [分区ID]
 * @param[in]  key_name             [键值名称]
 * @param[in]  p_data               [写入的数据]
 * @param[in]  len                  [写入数据的长度]
 * @return     int32_t              [0表示写入成功，非0表示写入失败]
 */
int32_t vhal_flash_write(PARTITION_ID_E part_id, const char *key_name, uint8_t *p_data, uint32_t len)
{
    char *file_name = vhal_nvs_flash_conv_name(part_id);
    if (file_name == NULL)
    {
        return VHAL_FAIL;
    }

    cJSON *p_json = read_json_from_file(file_name);
    if (p_json == NULL)
    {
        p_json = cJSON_CreateObject();
        if (p_json == NULL)
        {
            return VHAL_FAIL;
        }
    }

    cJSON_DeleteItemFromObject(p_json, key_name);
    cJSON_AddItemToObject(p_json, key_name, cJSON_CreateString((char *)p_data));
    int ret = write_json_to_file(file_name, p_json);
    if (ret != VHAL_OK)
    {
        HAL_LOG(LOG_ERROR, "flash write fail\n");
    }

    cJSON_Delete(p_json);

    return ret;
}

/**
 * @brief  擦除指定分区
 * @param[in]  part_id              [分区ID]
 * @return     int32_t              [0表示擦除成功，非0表示擦除失败]
 */
int32_t vhal_flash_erase(PARTITION_ID_E part_id)
{
    FILE *fp = NULL;
    char *file_name = vhal_nvs_flash_conv_name(part_id);
    if (file_name == NULL)
    {
        return VHAL_FAIL;
    }

    pthread_rwlock_wrlock(&s_rwlock);

    fp = fopen(file_name, "w+");
    if (fp == NULL)
    {
        pthread_rwlock_unlock(&s_rwlock);
        HAL_LOG(LOG_ERROR, "erase %s fail\n", file_name);
        return VHAL_FAIL;
    }

    fclose(fp);
    pthread_rwlock_unlock(&s_rwlock);

    return  VHAL_OK;
}

/**
 * @brief  擦除指定分区中的指定键值对
 * @param[in]  part_id              [分区ID]
 * @param[in]  key_name             [键值名称]
 * @return     int32_t              [0表示擦除成功，非0表示擦除失败]
 */
int32_t vhal_flash_erase_key(PARTITION_ID_E part_id, const char *key_name)
{
    char *file_name = vhal_nvs_flash_conv_name(part_id);
    if (file_name == NULL)
    {
        return VHAL_FAIL;
    }

    int ret = VHAL_FAIL;
    cJSON *p_json = read_json_from_file(file_name);
    if (p_json != NULL)
    {
        cJSON_DeleteItemFromObject(p_json, key_name);
        ret = write_json_to_file(file_name, p_json);
        if (ret != VHAL_OK)
        {
            HAL_LOG(LOG_ERROR, "flash write fail\n");
        }

        cJSON_Delete(p_json);
    }

    return ret;
}


