/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_timebase_internal.h
 * @brief       Timebase模块接口内部定义
 * @date        2021-08-18
 */

#ifndef __VESYNC_TIMEBASE_INTERNAL_H__
#define __VESYNC_TIMEBASE_INTERNAL_H__

#include <stdint.h>
#include <stdbool.h>

#include "cJSON.h"

#include "vesync_timebase.h"

#ifdef __cplusplus
extern "C"
{
#endif

#define TIMEBASE_TZ_STR_LENGTH (64)      // 时区字符串长度
#define TIMEBASE_TZ_INV_STR "invalid_tz" // 出厂的时区信息值
#define TIMEBASE_JSON_TYPE_ALL (0)       // Timebase type枚举，所有信息类型
#define TIMEBASE_JSON_TYPE_TZ_INFO (1)   // Timebase type枚举，时区信息类型
#define TIMEBASE_JSON_TYPE_SUN_INFO (2)  // Timebase type枚举，太阳日出日落信息类型
#define TIMEBASE_JSON_TYPE_DST_INFO (3)  // Timebase type枚举，DST信息类型

/**
 * @brief Timebase Repeat 配置位定义
 */
typedef enum
{
    TMBS_ONCE = 0x00,         // Once类型Repeat配置值
    TMBS_BIT_MON = 0x01 << 1, // Repeat配置值的星期一位码
    TMBS_BIT_TUE = 0x01 << 2, // Repeat配置值的星期二位码
    TMBS_BIT_WED = 0x01 << 3, // Repeat配置值的星期三位码
    TMBS_BIT_THU = 0x01 << 4, // Repeat配置值的星期四位码
    TMBS_BIT_FRI = 0x01 << 5, // Repeat配置值的星期五位码
    TMBS_BIT_SAT = 0x01 << 6, // Repeat配置值的星期六位码
    TMBS_BIT_SUN = 0x01 << 7, // Repeat配置值的星期天位码
} TMBS_RPT_CFG_E;

/**
 * @brief Timebase 配置数据定义
 */
typedef struct
{
    struct
    {
        char timezone_str[TIMEBASE_TZ_STR_LENGTH]; // 时区名字符串
        int32_t timezone_ofs_sec;                  // 时区偏移值，基于秒。正负决定偏移方向
    } tz_info;                                     // 时区信息

    struct
    {
        int32_t longitude;     // 经度
        int32_t latitude;      // 纬度
        int32_t altitude;      // 高度
        uint32_t sun_rise_utc; // 日出UTC时间戳
        uint32_t sun_set_utc;  // 日落UTC时间戳
    } sun_rs_info;             // 日出日落信息

    struct
    {
        bool enabled;         // 冬夏令时是否有效
        int32_t cur_ofs_sec;  // 当前本地区冬夏令时的基于秒的偏移参数
        int32_t next_ofs_sec; // 下一期本地区冬夏令时的基于秒的偏移参数
        uint32_t dst_sw_utc;  // 接下来的本地区冬夏令时切换的UTC时间；如果是从夏令时切换到冬令时，那么这个时间点需要考虑夏令时的偏移。
    } dst_info;               // 冬夏令时信息
} vesync_timebase_t;

/**
 * @brief Timebase 初始化
 * @return int              [TMBS_RESULT_E]
 */
int vesync_timebase_init(void);

/**
 * @brief Timebase 清除所有信息
 * @return int              [TMBS_RESULT_E]
 */
int vesync_timebase_clear(void);

/**
 * @brief Timebase读取时基信息
 * @param[in]  utc          [基准UTC，用于计算输出的时间戳]
 * @param[out] p_tb_info    [指向传出的Timebase Info缓存]
 * @return int              [TMBS_RESULT_E]
 */
int vesync_timebase_get_info(uint32_t utc, timebase_info_t *p_tb_info);

/**
 * @brief Timebase根据时间戳计算偏移指定天数是星期几
 * @param[in] ts            [指定的时间戳]
 * @param[in] day_offset    [天的偏移]
 * @return TMBS_RPT_CFG_E   [返回的结果]
 */
TMBS_RPT_CFG_E vesync_timebase_ts_to_weekday(uint32_t ts, int32_t day_offset);

/**
 * @brief Timebase信息更新
 * @param[in] p_new_tb      [指向传入的新的Timebase参数]
 * @return int              [TMBS_RESULT_E]
 */
int vesync_timebase_update(vesync_timebase_t *p_new_tb);

/**
 * @brief Timebase信息读取
 * @param[out] p_sch_tb     [指向传出的Timebase Buffer]
 * @return int              [TMBS_RESULT_E]
 */
int vesync_timebase_get(vesync_timebase_t *p_sch_tb);

/**
 * @brief Timebase设置时基信息是否自动更新
 * @note  测试接口
 * @param[in] en            [true - 自动更新；false - 禁止自动更新]
 * @return int              [TMBS_RESULT_E]
 */
int vesync_timebase_set_auto_update(bool en);

/**
 * @brief Timebase判断Repeat配置的数值合法性
 * @param[in] rpt           [输入的Repeat数值]
 * @return true             [该参数合法]
 * @return false            [该参数非法]
 */
bool vesync_timebase_is_rpt_valid(uint32_t rpt);

/**
 * @brief Timebase读取应用层注册的时基更新通知回调
 * @return timebase_info_upd_ntf_cb_t
 */
timebase_info_upd_ntf_cb_t vesync_timebase_get_reg_info_upd_cb(void);

/**
 * @brief Timebase从Bypass JSON消息中读取并更新时基信息
 * @param[in]   json        [包含时基信息的JSON消息]
 * @param[out]  p_type      [输出解析得到的时基类型]
 * @param[out]  p_tb        [输出被更新的时基数据体，只会被做增量更新]
 * @return      int         [TMBS_RESULT_E]
 */
int vesync_timebase_bp_tb_info_parse(cJSON *json, TMBS_INFO_TYPE_E *p_type, vesync_timebase_t *p_tb);

#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_TIMEBASE_INTERNAL_H__ */
