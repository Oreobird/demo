/**
 * Copyright © Vesync Technologies Co.Ltd. 2019-2021. All rights reserved.
 * @file    vhal_flash.c
 * @brief   设备flash读写驱动
 * @author  Louis
 * @date    2021-02-26
 */

#include "easyflash.h"

#include "vesync_log.h"
#include "vhal_flash.h"
#include "flash_api.h"
#include "vesync_common.h"


static bool s_flash_init_flag = false;                  // flash初始化标志位，true表示已经初始化

/*-----------------------------------------------------------------------------*
 *                           内部函数API实现                                         *
 *-----------------------------------------------------------------------------*/


/**
 * @brief  将信息写入到FAC扇区
 * @param[in]  p_data               [保存的数据]
 * @param[in]  len                  [p_data的最小长度]
 * @return     int                  [成功/失败]
 * @note  如果len的长度不是4的倍数，p_data末尾插入0补齐为4的倍数。
 *        存储数据的实际格式：实际长度(4byte) + p_data + [填充0] + checksum32(4byte)
 */
static int vhal_write_fac(uint8_t *p_data, uint32_t len)
{
    uint32_t addr = VHAL_SPI_FLASH_BASE;            // 实际地址
    uint32_t len_pad = 0;                           // 输入参数不是4的倍数时，需要填充的最小个数来满足4的倍数
    uint32_t uint32_size = sizeof(uint32_t);        // uint32_t的长度
    uint32_t len_fill = 0;                          // 按4字节对齐后的长度
    int idx = 0;
    uint32_t cksum32 = 0;
    uint32_t data32 = 0;
    flash_t flash;
    uint8_t *p_data_new = NULL;

    if (NULL == p_data)
    {
        HAL_LOG(LOG_ERROR, "Input parameter contains null pointer!!\n");
        return VHAL_FAIL;
    }

    if (0 != (len%uint32_size))
    {
        len_pad = len + (uint32_size - (len%uint32_size));
    }
    else
    {
        len_pad = len;
    }

    // 2. 申请空间，填充数据长度与数据
    len_fill = uint32_size + len_pad + uint32_size;
    p_data_new = malloc(len_fill + uint32_size);                // 多预留4个byte
    if (NULL == p_data_new)
    {
        HAL_LOG(LOG_ERROR, "malloc memory fail!!\n");
        return VHAL_FAIL;
    }
    memset(p_data_new, 0, len_fill + uint32_size);
    HAL_LOG(LOG_DEBUG, "ptr = %p, len_pad = %d, len_fill = %d.\n", p_data_new, len_pad, len_fill);
    memcpy(p_data_new, (uint8_t *)&len, uint32_size);          // 实际数据的长度
    memcpy(p_data_new + uint32_size, p_data, len);             // 源数据

    // 3. 计算checksum，内容包含：实际长度(4byte) + p_data + [填充0]
    for (idx = 0; idx < len_fill - uint32_size; idx += uint32_size)
    {
        data32 = (p_data_new[idx+3] << 24) | (p_data_new[idx+2] << 16) | (p_data_new[idx+1] << 8) | (p_data_new[idx]);
        cksum32 += data32;
    }
    HAL_LOG(LOG_DEBUG, "cksum32 = 0x%04x.\n", cksum32);

    memcpy(p_data_new + (len_fill - uint32_size), (uint8_t *)&cksum32, uint32_size);    // 末尾插入checksum

    // 4.1. erase
    flash_erase_sector(&flash, addr);

    flash_burst_write(&flash, addr, len_fill, p_data_new);       // 包含checksum

    // 释放空间
    if (NULL != p_data_new)
    {
        free(p_data_new);
        p_data_new = NULL;
    }

    HAL_LOG(LOG_DEBUG, "Flash write succ.\n");

    return VHAL_OK;
}

/**
 * @brief 读取FAC扇区中的信息
 * @param[out] p_data               [保存的数据]
 * @param[in/out] p_len             [输入时表示p_data的最小长度，输出时表示读取的数据长度]
 * @return     int                  [成功/失败]
 * @note  如果len的长度不是4的倍数，按4的倍数进行补齐。
 *        存储数据的实际格式：实际长度(4byte) + p_data + [填充0] + checksum32(4byte)
 */
static int vhal_read_fac(uint8_t *p_data, uint32_t *p_len)
{
    int ret = VHAL_FAIL;
    uint32_t addr = 0;                              // 实际地址
    uint32_t len_pad = 0;                           // 输入参数不是4的倍数时，需要填充的最小个数来满足4的倍数
    uint32_t uint32_size = sizeof(uint32_t);        // uint32_t的长度
    uint32_t len_fill = 0;                          // 按4字节对齐后的长度
    flash_t flash;
    uint8_t *p_data_new = NULL;

    if (NULL == p_data || NULL == p_len)
    {
        HAL_LOG(LOG_DEBUG, "Input parameter contains null pointer!!\n");
        return VHAL_FAIL;
    }

    if (0 != (*p_len%uint32_size))
    {
        len_pad = *p_len + (uint32_size - (*p_len%uint32_size));                // 不是4的倍数时，填充的最小个数来满足4的倍数
    }
    else
    {
        len_pad = *p_len;
    }
    addr = VHAL_SPI_FLASH_BASE;
    HAL_LOG(LOG_DEBUG, "addr = 0x%08x, len = %d.\n", addr, *p_len);

    len_fill = uint32_size + len_pad + uint32_size;             // 增加"长度+checksum32"后的数据长度
    p_data_new = malloc(len_fill + uint32_size);                // 多预留4个byte
    if (NULL == p_data_new)
    {
        HAL_LOG(LOG_ERROR, "malloc memory fail!!\n");
        return VHAL_FAIL;
    }
    memset(p_data_new, 0, len_fill + uint32_size);
    HAL_LOG(LOG_DEBUG, "len_pad = %d, len_fill = %d.\n", len_pad, len_fill);

    flash_stream_read(&flash, addr, len_fill, p_data_new);

    // 3.校验数据
    uint32_t len_data = 0;
    uint32_t len_rd = 0;       // 重新计算读取数据的长度
    memcpy((uint8_t *)&len_data, p_data_new, uint32_size);        // 提取头部4byte的数据长度
    HAL_LOG(LOG_DEBUG, "len_data = %d.\n", len_data);
    if (len_data == 0xFFFFFFFF)
    {
        HAL_LOG(LOG_ERROR, "Not data!!\n");
        goto exit;
    }
    else
    {
        // 3.1 校验数据长度
        if (len_data > *p_len)
        {
            HAL_LOG(LOG_ERROR, "Param buf is not enought!!\n");
            goto exit;
        }

        // 3.2 存储数据长度
        len_rd = len_data;
        if ((len_rd%uint32_size) != 0)
        {
            len_rd += (uint32_size - (len_rd%uint32_size));     // 存储时，实际是按照4byte倍数进行的，因此需要进行4倍数补齐
        }
        len_rd += 2*uint32_size;        // 加上4byte的长度和checksum32长度
    }

    // 3.3 校验数据的checksu32
    int idx = 0;
    uint32_t data_cksum32 = 0, read_cksum32 = 0;
    uint32_t data32 = 0;
    for (idx = 0; idx < len_rd - uint32_size; idx += uint32_size)        // checksum32计算,不包含末尾的4byte
    {
        data32 = (p_data_new[idx+3] << 24) | (p_data_new[idx+2] << 16) | (p_data_new[idx+1] << 8) | (p_data_new[idx]);
        data_cksum32 += data32;
    }
    memcpy((uint8_t *)&read_cksum32, &p_data_new[len_rd - uint32_size], uint32_size);
    //HAL_LOG(LOG_DEBUG, "data_cksum32 = 0x%08x, read_cksum32 = 0x%08x.\n", data_cksum32, read_cksum32);

    // 4.数据拷贝
    if (data_cksum32 == read_cksum32)
    {
        memcpy(p_data, p_data_new + uint32_size, len_data);
        *p_len = len_data;
        ret = VHAL_OK;
    }
    else
    {
        memset(p_data, 0, len_data);     // 清空数据
        HAL_LOG(LOG_ERROR, "Checksum fail, the actual checksum is 0x%08x, but expected is 0x%08x!!\n", data_cksum32, read_cksum32);
    }

exit:
    // 5.释放空间
    if (NULL != p_data_new)
    {
        free(p_data_new);
        p_data_new = NULL;
    }

    return ret;
}


/*-----------------------------------------------------------------------------*
 *                           外部函数API实现                                         *
 *-----------------------------------------------------------------------------*/

/**
 * @brief  flash初始化
 * @param[in]  part_id              [分区ID]
 * @return     int32_t              [错误码]
 */
int32_t vhal_flash_init(PARTITION_ID_E part_id)
{
    EfErrCode err = EF_NO_ERR;

    if (!s_flash_init_flag)
    {
        err = easyflash_init();

        if (EF_NO_ERR != err)
        {
            HAL_LOG(LOG_ERROR, "Easy flash init failed!\n");
            return VHAL_FAIL;
        }

        s_flash_init_flag = true;
    }

    return VHAL_OK;
}

/**
 * @brief  从flash读取数据
 * @param[in]  part_id              [分区ID]
 * @param[in]  key_name             [键值名称]
 * @param[in]  p_data               [读取数据缓存区]
 * @param[in/out]  p_len                [当前读取的数据长度]
 * @return     int32_t              [0表示读取成功，非0表示读取失败]
 */
int32_t vhal_flash_read(PARTITION_ID_E part_id, const char *key_name, uint8_t *p_data, uint32_t *p_len)
{
    size_t read_len = 0;
    size_t value_len = 0;
    uint32_t buf_len = 0;
    int ret = VHAL_OK;

    if (part_id <= PARTITION_MIN || part_id >= PARTITION_MAX)
    {
        HAL_LOG(LOG_ERROR, "Invalid partition ID(%d)!\n", part_id);
        return VHAL_FAIL;
    }

    if (NULL == key_name || NULL == p_data || NULL == p_len)
    {
        HAL_LOG(LOG_ERROR, "Null ptr!\n");
        return VHAL_FAIL;
    }

    buf_len = *p_len;
    if (0 == buf_len)
    {
        HAL_LOG(LOG_ERROR, "buf len == 0!\n");
        return VHAL_FAIL;
    }

    HAL_LOG(LOG_DEBUG, "partition = %d, buf_len = %d.\n", part_id, buf_len);
    switch (part_id)
    {
        case PARTITION_CFG:
            read_len = ef_get_env_blob(key_name, p_data, buf_len, &value_len);
            if (0 == read_len)
            {
                HAL_LOG(LOG_ERROR, "read env failed! value_len=%d\n", value_len);
                ret = VHAL_FAIL;
            }
            break;

        case PARTITION_FAC:
            read_len = buf_len;
            ret = vhal_read_fac(p_data, (uint32_t*)&read_len);
            break;

        default:
            HAL_LOG(LOG_ERROR, "unsupport PARTTION ID %d\n", part_id);
            ret = VHAL_FAIL;
            break;
    }


    *p_len = read_len;
    HAL_LOG(LOG_DEBUG, "ret = %d, read_len = %d.\n", ret, read_len);

    return ret;
}

/**
 * @brief  往flash写入数据
 * @param[in]  part_id              [分区ID]
 * @param[in]  key_name             [键值名称]
 * @param[in]  p_data               [写入的数据]
 * @param[in]  len                  [写入数据的长度]
 * @return     int32_t              [0表示写入成功，非0表示写入失败]
 */
int32_t vhal_flash_write(PARTITION_ID_E part_id, const char *key_name, uint8_t *p_data, uint32_t len)
{
    EfErrCode err = EF_NO_ERR;
    int ret = VHAL_OK;

    if (part_id <= PARTITION_MIN || part_id >= PARTITION_MAX)
    {
        HAL_LOG(LOG_ERROR, "Invalid partition ID(%d)!\n", part_id);
        return VHAL_FAIL;
    }

    if (NULL == key_name || NULL == p_data || 0 == len)
    {
        HAL_LOG(LOG_ERROR, "Null ptr!\n");
        return VHAL_FAIL;
    }

    HAL_LOG(LOG_DEBUG, "partition = %d, len = %d.\n", part_id, len);
    switch (part_id)
    {
        case PARTITION_CFG:
            err = ef_set_env_blob(key_name, p_data, len);
            if (EF_NO_ERR != err)
            {
                HAL_LOG(LOG_ERROR, "write env failed!\n");
                ret = VHAL_FAIL;
            }
            break;

        case PARTITION_FAC:
            ret = vhal_write_fac(p_data, len);
            break;

        default:
            HAL_LOG(LOG_ERROR, "unsupport PARTTION ID %d\n", part_id);
            break;
    }

    return ret;
}

/**
 * @brief  擦除指定分区
 * @param[in]  part_id              [分区ID]
 * @return     int32_t              [0表示擦除成功，非0表示擦除失败]
 */
int32_t vhal_flash_erase(PARTITION_ID_E part_id)
{

    return VHAL_OK;
}

/**
 * @brief  擦除指定分区中的指定键值对
 * @param[in]  part_id              [分区ID]
 * @param[in]  key_name             [键值名称]
 * @return     int32_t              [0表示擦除成功，非0表示擦除失败]
 */
int32_t vhal_flash_erase_key(PARTITION_ID_E part_id, const char *key_name)
{
    EfErrCode err = EF_NO_ERR;

    if (part_id <= PARTITION_MIN || part_id >= PARTITION_MAX)
    {
        HAL_LOG(LOG_ERROR, "Invalid partition ID(%d)!\n", part_id);
        return VHAL_FAIL;
    }

    if (NULL == key_name)
    {
        HAL_LOG(LOG_ERROR, "Null ptr!\n");
        return VHAL_FAIL;
    }

    switch (part_id)
    {
        case PARTITION_CFG:
            err = ef_del_env(key_name);
            break;
        default:
            HAL_LOG(LOG_ERROR, "erase unsupport PARTTION ID %d\n", part_id);
            err = EF_ERASE_ERR;
            break;
    }

    if (EF_NO_ERR != err)
    {
        return VHAL_FAIL;
    }

    return VHAL_OK;
}
