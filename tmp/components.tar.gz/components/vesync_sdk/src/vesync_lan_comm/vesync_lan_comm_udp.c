/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_udp.c
 * @brief       局域网通信-UDP初始化、UDP数据接收、UDP socket关闭
 * @author      henrikzhou
 * @date        2020-9-21
 */

#include <string.h>

#include "vesync_common.h"
#include "vesync_log_internal.h"
#include "vesync_lan_comm_udp.h"

/**
 * @brief 初始化UDP socket
 * @param[in] addr      [udp socket 结构体地址]
 * @param[in] fd        [udp socket 句柄指针]
 * @param[in] port      [udp socket 端口]
 * @return int          [成功/失败]
 */
int vesync_udp_init(struct sockaddr_in* addr, int* fd,uint32_t port)
{
    if((NULL == addr)||(NULL == fd))
    {
        return SDK_FAIL;
    }

    memset(addr, 0, sizeof(struct sockaddr_in));
    *fd = socket(AF_INET,SOCK_DGRAM,0);
    if (0 > (*fd))
    {
        SDK_LOG(LOG_ERROR, "UDP  Socket Created Fail.\n");
        return SDK_FAIL;
    }

    addr->sin_family = AF_INET;
    addr->sin_addr.s_addr = htonl(INADDR_ANY);
    addr->sin_port = htons(port);
    memset(&(addr->sin_zero),0,sizeof(addr->sin_zero));

    if (bind(*fd,(struct sockaddr *)addr, sizeof(struct sockaddr)) == -1)
    {
        SDK_LOG(LOG_ERROR, "UDP  Socket Bind Fail.\n");
        return SDK_FAIL;
    }

    SDK_LOG(LOG_DEBUG, "UDP  Socket Created, socket_fd = %d,port:%d.\n",*fd,addr->sin_port);
    return SDK_OK;
}

/**
 * @brief UDP 数据接收监听接口
 * @param[in] fd                [udp socket 句柄指针]
 * @param[in] timeout_ms        [udp server 数据接收监听超时时间，单位毫秒]
 * @param[out] buffer           [udp 数据接收缓存起始地址]
 * @param[in]  len              [数据接收缓存的最大长度]
 * @param[out]  addr            [存储远端udp socket 地址结构体指针]
 * @param[out]  socket_len      [存储远端udp socket 地址结构体长度指针]
 * @return int                  [成功/失败/实际接收数据长度]
 */
int vesync_udp_recv(int fd, int timeout_ms, char *buffer, int len, struct sockaddr_in *addr, uint32_t *socket_len)
{
    if ((NULL == addr) || (NULL == socket_len) || (NULL == buffer))
    {
        return SDK_FAIL;
    }

    int recv_len = 0, rc = 0, ret = 0, erro = 0;
    uint32_t err_len = sizeof(int);
    struct timeval timeout;
    fd_set fdset;

    FD_ZERO(&fdset);
    FD_SET(fd, &fdset);

    timeout.tv_sec = 0;
    timeout.tv_usec = timeout_ms * 1000;

    ret = select(fd + 1, &fdset, 0, 0, &timeout);
    if (ret == 0)
    {
        return ret;
    }
    else if (ret < 0)
    {
        SDK_LOG(LOG_ERROR, "select error\n");
        return ret;
    }

    if (FD_ISSET(fd, &fdset))
    {
        rc = recvfrom(fd, buffer, len, 0, (struct sockaddr*)addr, (socklen_t *)socket_len);
        if (rc > 0)
        {
            recv_len = rc;
        }
        else
        {
            recv_len = (rc < 0) ? rc : -1;

            getsockopt(fd, SOL_SOCKET, SO_ERROR, (void *)&erro, &err_len);
            SDK_LOG(LOG_WARN, "udp recv return:%d, errno:%d\n", rc, erro);
        }
    }

    return recv_len;
}

/**
 * @brief 关闭UDP socket
 * @param[in] fd             [udp 句柄指针]
 */
void vesync_udp_stop(int* fd)
{
    if ((NULL != fd)&&(0 <= (*fd)))
    {
        close(*fd);
        *fd = -1;
    }
}