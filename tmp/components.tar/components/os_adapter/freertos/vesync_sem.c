/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_sem.c
 * @brief       semaphore抽象层，封装freertos信号量相关接口
 * @author      Joshua
 * @date        2021-04-20
 */
#include <freertos/FreeRTOS.h>
#include <freertos/semphr.h>

#include "vesync_common.h"
#include "vesync_os_internal.h"
#include "vesync_sem.h"

/*
 * @brief  创建信号量
 * @return vesync_sem_t                [信号量结构体指针]
 */
vesync_sem_t vesync_sem_new(void)
{
    SemaphoreHandle_t sem_count = xSemaphoreCreateCounting(VESYNC_OS_SEM_MAX_COUNT, 0);
    return (vesync_sem_t)sem_count;
}

/*
 * @brief  等待信号量
 * @param[in]  sem                     [信号量结构体指针]
 * @param[in]  timeout_ms              [等待时间：
 *                                      VESYNC_OS_NO_WAIT: 不等待
 *                                      VESYNC_OS_WAIT_FOREVER: 等待信号量]
 * @return int                         [成功：VOS_OK；失败：VOS_FAIL]
 */
int vesync_sem_wait(vesync_sem_t sem, unsigned int timeout_ms)
{
    VCOM_NULL_PARAM_CHK(sem, return VOS_FAIL);
    BaseType_t ret = xSemaphoreTake(sem, timeout_ms == VESYNC_OS_WAIT_FOREVER ? portMAX_DELAY : VESYNC_MS_TO_TICKS(timeout_ms));
    return ret == pdPASS ? VOS_OK : VOS_FAIL;
}

/*
 * @brief  释放信号量
 * @param[in]  sem                     [信号量结构体指针]
 * @return int                         [成功：VOS_OK；失败：VOS_FAIL]
 */
int vesync_sem_signal(vesync_sem_t sem)
{
    VCOM_NULL_PARAM_CHK(sem, return VOS_FAIL);
    BaseType_t ret = xSemaphoreGive(sem);
    return ret == pdPASS ? VOS_OK : VOS_FAIL;
}

/*
 * @brief  销毁信号量
 * @param[in]  sem                     [信号量结构体指针]
 * @return int                         [成功：VOS_OK；失败：VOS_FAIL]
 */
int vesync_sem_free(vesync_sem_t sem)
{
    VCOM_NULL_PARAM_CHK(sem, return VOS_FAIL);
    vSemaphoreDelete(sem);
    return VOS_OK;
}

