/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_bypass_childlock.c
 * @brief       bypass处理接口
 * @date        2021-05-17
 */
#include <string.h>
#include "vesync_common.h"
#include "vesync_memory.h"
#include "vesync_log_internal.h"
#include "vesync_bypass_internal.h"

/**
 * @brief 设置童锁
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  json                     [json数据指针]
 * @return BYPASS_ERR_E                 [错误码]
 */
static BYPASS_ERR_E bypass_method_set_childlock_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    BYPASS_ERR_E ret = BP_OK;
    cJSON* json_data = NULL;

    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    bypass_childlock_t * p_childlock = (bypass_childlock_t *)vesync_malloc(sizeof(bypass_childlock_t));
    if (NULL == p_childlock)
    {
        return BP_ERR_NOMEM;
    }

    memset(p_childlock, 0, sizeof(bypass_childlock_t));

    json_data = cJSON_GetObjectItemCaseSensitive(json, "child_lock");
    if (cJSON_IsBool(json_data))
    {
        p_childlock->childlock = json_data->valueint;

        SDK_LOG(LOG_DEBUG,"child_lock : %d\r\n", p_childlock->childlock);
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_SET_CHILDLOCK);
    if (method_cb)
    {
        method_cb(p_msg_ctx, (void*)p_childlock);
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

_exit:
    vesync_free(p_childlock);
    return ret;
}


static bypass_item_data_t childlock_method_tbl[] = {
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_SET_CHILDLOCK, "setChildLock", bypass_method_set_childlock_handle, NULL},
};

/**
 * @brief bypass childlock初始化
 */
void vesync_bypass_childlock_init(void)
{
    for (int i = 0; i < SIZEOF_ARRAY(childlock_method_tbl); i++)
    {
        bypass_item_t *item = vesync_bypass_init_item(&childlock_method_tbl[i]);
        if (item != NULL)
        {
            vesync_bypass_add_item(item);
        }
    }
}
