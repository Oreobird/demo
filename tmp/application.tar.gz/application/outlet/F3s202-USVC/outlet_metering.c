/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        outlet_metering.c
 * @brief       outlet电量计量
 * @author      Charles.Mei
 * @date        2021-12-16
 */


#include <stdint.h>
#include <string.h>
#include <stdio.h>

#include "vhal_gpio.h"
#include "vhal_pcnt.h"
#include "vhal_utils.h"

#include "vesync_common.h"
#include "vesync_log.h"
#include "vesync_memory.h"
#include "vesync_os.h"
#include "vesync_task.h"
#include "vesync_mutex.h"

#include "vesync_flash.h"
#include "vesync_klv.h"
#include "vesync_production.h"

#include "outlet_metering.h"
#include "outlet_board.h"


/* 以下是测试宏 */
#define METERING_DEBUG_LEVLE    LOG_DISABLE

#define MTR_DEBUG_LEVLE(level, ...)   \
    do                                          \
    {                                           \
        if (level >= METERING_DEBUG_LEVLE)      \
        {                                       \
            APP_LOG(level, ##__VA_ARGS__);      \
        }                                       \
    } while (0)

#define MTR_DEBUG_E(...)    MTR_DEBUG_LEVLE(LOG_ERROR, ##__VA_ARGS__)
#define MTR_DEBUG_W(...)    MTR_DEBUG_LEVLE(LOG_WARN, ##__VA_ARGS__)
#define MTR_DEBUG_I(...)    MTR_DEBUG_LEVLE(LOG_INFO, ##__VA_ARGS__)
#define MTR_DEBUG_D(...)    MTR_DEBUG_LEVLE(LOG_DEBUG, ##__VA_ARGS__)
/* 以上是测试宏 */


#define METERING_TASK_NAME              ("metering_task")
#define METERING_TASK_PRIO              TASK_PRIORITY_HIGH
#define METERING_TASK_STACKSIZE         (1024 * 2)

#define METERING_FACTOR                 ("metering_factor")
#define METERING_FACTOR_DATA_BUF_LEN    (64)

#define METERING_CAL_ERROR_PCT          (0.01f)    // 计量校准的可接受误差为1%
#define METERING_SCAN_COUNT_INTERVAL    (1000)    // 扫描间隔1000ms
#define METERING_SEL_GPIO_DEFAULT_VALUE VHAL_GPIO_DATA_HIGH     // 默认CFI读取电压值
#define METERING_SEL_CFI_IN_TURN        (0)     // 1——交替测量电压和电流，0只测量电压
#define METERING_PULSE_COUNT_MIN        (0)     // 最小计数值为零
#define METERING_PULSE_COUNT_MAX        (32765) // 最大计数值为2^15-1

#define METERING_POW_LV1_VAL            (10)    // 功率挡位1为1w~10w
#define METERING_POW_LV2_VAL            (20)    // 功率挡位2为10w~20w
#define METERING_POW_LV3_VAL            (50)    // 功率挡位3为20w~50w
#define METERING_POW_LV4_VAL            (100)   // 功率挡位4为50w~100w
#define METERING_POW_MAX_LV_VAL         METERING_POW_LV4_VAL
#define METERING_POW_LV1_INT            (10)    // 功率挡位1扫描次数为10
#define METERING_POW_LV2_INT            (5)     // 功率挡位2扫描次数为5
#define METERING_POW_LV3_INT            (2)     // 功率挡位3扫描次数为2
#define METERING_POW_LV4_INT            (1)     // 功率挡位4扫描次数为1
#define METERING_POW_MIN_INT            METERING_POW_LV4_INT
#define METERING_POW_ZERO_INT           (3)     // 功率判断为0的扫描次数为3


#define METERING_ABS(a, b)          (((a) > (b)) ? ((a) - (b)) : ((b) - (a)))

/*
 * @brief 功率挡位
 */
typedef enum
{
    METERING_POW_LV1    = 1,
    METERING_POW_LV2    = 2,
    METERING_POW_LV3    = 3,
    METERING_POW_LV4    = 4,
    METERING_POW_LV_MAX
} METERING_POW_LV_E;

static metering_rated_t s_metering_rated;       // 记量校准额定参数
static metering_factor_t s_metering_factor;     // 记量校准系数
static metering_status_t s_metering_status;     // 计量状态
static metering_mgmt_t s_metering_mgmt;         // 计量管理配置

/**
 * @brief 保存计量校准系数
 * @return      int             [错误码，成功/失败]
 */
static int save_factor(void)
{
    uint8_t *factor_buf = vesync_malloc(METERING_FACTOR_DATA_BUF_LEN);
    uint32_t  offset = 0;
    int ret = APP_FAIL;

    if (NULL == factor_buf)
    {
        APP_LOG(LOG_ERROR, "malloc fail\n");
        return APP_FAIL;
    }
    memset(factor_buf, 0, METERING_FACTOR_DATA_BUF_LEN);

    offset += vesync_klv_set(factor_buf + offset, METERING_FACTOR_DATA_BUF_LEN - offset,
        FACTOR_KEY_ELE_PER_PULSE, sizeof(s_metering_factor.ele_per_pulse), (uint8_t *)&s_metering_factor.ele_per_pulse);
    offset += vesync_klv_set(factor_buf + offset, METERING_FACTOR_DATA_BUF_LEN - offset,
        FACTOR_KEY_POW_FACTOR, sizeof(s_metering_factor.pow_factor), (uint8_t *)&s_metering_factor.pow_factor);
    offset += vesync_klv_set(factor_buf + offset, METERING_FACTOR_DATA_BUF_LEN - offset,
        FACTOR_KEY_VOL_FACTOR, sizeof(s_metering_factor.vol_factor), (uint8_t *)&s_metering_factor.vol_factor);
    offset += vesync_klv_set(factor_buf + offset, METERING_FACTOR_DATA_BUF_LEN - offset,
        FACTOR_KEY_CUR_FACTOR, sizeof(s_metering_factor.cur_factor), (uint8_t *)&s_metering_factor.cur_factor);
    if (SDK_OK == vesync_flash_aes_crypto_write(PARTITION_CFG, METERING_FACTOR, factor_buf, offset) &&
        SDK_OK == vesync_flash_aes_crypto_write(PARTITION_FAC, METERING_FACTOR, factor_buf, offset))
    {
        ret = APP_OK;
        // 保存成功，清除校准额定数据
        memset(&s_metering_rated, 0, sizeof(s_metering_rated));
    }
    vesync_free(factor_buf);

    return ret;
}

/**
 * @brief 加载计量校准系数
 * @return      int             [错误码，成功/失败]
 */
static int load_factor(void)
{
    uint8_t copy_flag = 0; // 默认不需要copy备份分区的数据到主分区
    uint8_t *factor_buf = vesync_malloc(METERING_FACTOR_DATA_BUF_LEN);
    uint32_t buf_len = METERING_FACTOR_DATA_BUF_LEN;
    int ret = APP_FAIL;
    memset(&s_metering_factor, 0, sizeof(s_metering_factor));

    if (NULL == factor_buf)
    {
        APP_LOG(LOG_ERROR, "malloc fail\n");
        return APP_FAIL;
    }
    if (SDK_OK != vesync_flash_aes_crypto_read(PARTITION_CFG, METERING_FACTOR, factor_buf, &buf_len) || 0 == buf_len)
    {
        APP_LOG(LOG_ERROR, "read main flash err\n");
        buf_len = 0;
        if (SDK_OK != vesync_flash_aes_crypto_read(PARTITION_FAC, METERING_FACTOR, factor_buf, &buf_len) || 0 == buf_len)
        {
            APP_LOG(LOG_ERROR, "read backup flash err\n");
            goto EXIT;
        }
        copy_flag = 1; // 主分区数据损坏，备份分区数据正常，需要copy备份分区的数据到主分区
    }
    if(SDK_OK != vesync_klv_get(factor_buf, METERING_FACTOR_DATA_BUF_LEN, FACTOR_KEY_ELE_PER_PULSE,
        sizeof(s_metering_factor.ele_per_pulse), (uint8_t *)&s_metering_factor.ele_per_pulse))
    {
         APP_LOG(LOG_ERROR, "read ele_per_pulse factor err\n");
    }
    if(SDK_OK != vesync_klv_get(factor_buf, METERING_FACTOR_DATA_BUF_LEN, FACTOR_KEY_POW_FACTOR,
        sizeof(s_metering_factor.pow_factor), (uint8_t *)&s_metering_factor.pow_factor))
    {
         APP_LOG(LOG_ERROR, "read power factor err\n");
    }
    if(SDK_OK != vesync_klv_get(factor_buf, METERING_FACTOR_DATA_BUF_LEN, FACTOR_KEY_VOL_FACTOR,
        sizeof(s_metering_factor.vol_factor), (uint8_t *)&s_metering_factor.vol_factor))
    {
         APP_LOG(LOG_ERROR, "read voltage factor err\n");
    }
    if(SDK_OK != vesync_klv_get(factor_buf, METERING_FACTOR_DATA_BUF_LEN, FACTOR_KEY_CUR_FACTOR,
        sizeof(s_metering_factor.cur_factor), (uint8_t *)&s_metering_factor.cur_factor))
    {
         APP_LOG(LOG_ERROR, "read current factor err\n");
    }
    if (1 == copy_flag)
    {
        vesync_flash_aes_crypto_write(PARTITION_CFG, METERING_FACTOR, factor_buf, buf_len);
    }
    ret = APP_OK;

EXIT:
    vesync_free(factor_buf);
    return ret;
}

/**
 * @brief 获取脉冲计数
 * @param[in]   sel_gpio        [select对应的GPIO]
 * @param[out]  pow_count       [功率对应的脉冲计数]
 * @param[out]  vol_count       [电压对应的脉冲计数]
 * @param[out]  cur_count       [电量对应的脉冲计数]
 * @return      int             [错误码，成功/失败]
 * @note  此函数通过翻转sel_gpio的电压，交替测量电压和电量的脉冲计量，一直测量功率
 */
static int metering_get_pulse_count(uint8_t sel_gpio, int16_t *pow_count, int16_t *vol_count, int16_t *cur_count)
{
    static uint8_t sel_gpio_value = METERING_SEL_GPIO_DEFAULT_VALUE;
    int ret = APP_FAIL;

    if (VHAL_OK != vhal_pcnt_get_counter_value(VHAL_PCNT_UNIT_0, pow_count))
    {
        APP_LOG(LOG_ERROR, "get counter fail\n");
        goto exit;
    }
    MTR_DEBUG_D("pow count: %d\n", *pow_count);
    // 默认先测量电压
    if (METERING_SEL_GPIO_DEFAULT_VALUE == sel_gpio_value)
    {
        if (VHAL_OK != vhal_pcnt_get_counter_value(VHAL_PCNT_UNIT_1, vol_count))
        {
            APP_LOG(LOG_ERROR, "get counter fail\n");
            goto exit;
        }
        *cur_count = 0; // 未测量设置为零
        MTR_DEBUG_D("vol count: %d\n", *vol_count);
    }
#if METERING_SEL_CFI_IN_TURN   // 交替测量
    else
    {
        if (VHAL_OK != vhal_pcnt_get_counter_value(VHAL_PCNT_UNIT_1, cur_count))
        {
            APP_LOG(LOG_ERROR, "get counter fail\n");
            goto exit;
        }
        *vol_count = 0; // 未测量设置为零
        MTR_DEBUG_D("cur count: %d\n", *cur_count);
    }

    if (VHAL_GPIO_DATA_HIGH == sel_gpio_value)
    {
        sel_gpio_value = VHAL_GPIO_DATA_LOW;
    }
    else
    {
        sel_gpio_value = VHAL_GPIO_DATA_HIGH;
    }
    vhal_gpio_set_output(sel_gpio, sel_gpio_value);
#endif
    ret = APP_OK;

exit:
    vhal_pcnt_clear_counter(VHAL_PCNT_UNIT_0);
    vhal_pcnt_clear_counter(VHAL_PCNT_UNIT_1);
    return ret;
}

/**
 * @brief 计量校准
 * @param[in]   conf            [配置]
 */
static void metering_calibrate_run(metering_conf_t *conf)
{
    static uint32_t s_last_tick = 0;
    static float s_power_freq = 0;
    static float s_voltage_freq = 0;
    static float s_current_freq = 0;

    uint32_t cur_tick = 0;
    int16_t pow_count = 0;
    int16_t vol_count = 0;
    int16_t cur_count = 0;
    float cur_power_freq = 0;

    vhal_pcnt_clear_counter(VHAL_PCNT_UNIT_0);
    vhal_pcnt_clear_counter(VHAL_PCNT_UNIT_1);
    s_last_tick = vesync_task_get_tick_ms();
    while(1)
    {
        vesync_sleep(METERING_SCAN_COUNT_INTERVAL);

        // 计量校准的额定参数已设置，且获取到大于零的有效值才继续校准，否则持续等待
        if (APP_OK != metering_get_pulse_count(conf->gpios.sel_gpio, &pow_count, &vol_count, &cur_count) ||
            0 == pow_count || (0 == vol_count && 0 == cur_count) || 0 == s_metering_rated.flag)
        {
            s_last_tick = vesync_task_get_tick_ms();
            continue;
        }

        cur_tick = vesync_task_get_tick_ms();
        cur_power_freq = (float)pow_count / (float)((cur_tick - s_last_tick));
        // 两次测量数据进行校准，其中功率取均值
        if (METERING_ABS((uint32_t)(s_power_freq * 1000), (uint32_t)(cur_power_freq * 1000)) <=
            (uint32_t)(s_power_freq * 1000) * METERING_CAL_ERROR_PCT)   // 与上一次功率之差小于等于1%
        {
            MTR_DEBUG_I("s_power_freq = %8f, cur_power_freq = %8f\n", s_power_freq * 1000, cur_power_freq * 1000);
            s_power_freq = (s_power_freq + cur_power_freq) / 2;
#if METERING_SEL_CFI_IN_TURN
            if (0 == s_voltage_freq && 0 == cur_count)  // 此次测量电压
            {
                s_voltage_freq = (float)vol_count / (float)(cur_tick - s_last_tick);
            }
            else                                        // 此次测量电流
            {
                s_current_freq = (float)cur_count / (float)(cur_tick - s_last_tick);
            }
            // 计算校准值
            s_metering_factor.pow_factor = s_metering_rated.Power0 / s_power_freq;
            s_metering_factor.vol_factor = s_metering_rated.Voltage0 / s_voltage_freq;
            s_metering_factor.cur_factor = s_metering_rated.Current0 / s_current_freq;
            s_metering_factor.ele_per_pulse = (double)s_metering_rated.Power0 / (double)(s_power_freq * 1000 * 3600);    //单位为瓦时/个
#else
            s_voltage_freq = (((float)vol_count / (float)(cur_tick - s_last_tick)) + s_voltage_freq) / 2;
            // 计算校准值
            s_metering_factor.pow_factor = s_metering_rated.Power0 / s_power_freq;
            s_metering_factor.vol_factor = s_metering_rated.Voltage0 / s_voltage_freq;
            s_metering_factor.cur_factor = 0;
            s_metering_factor.ele_per_pulse = (double)s_metering_rated.Power0 / (double)(s_power_freq * 1000 * 3600);    //单位为瓦时/个
#endif
            MTR_DEBUG_D("s_power_freq: %8f, s_voltage_freq: %8f, s_current_freq: %8f\n", s_power_freq, s_voltage_freq, s_current_freq);
            MTR_DEBUG_D("pow_factor: %8f, vol_factor: %8f, cur_factor: %8f, ele_per_pulse: %8f\n", s_metering_factor.pow_factor, s_metering_factor.vol_factor, s_metering_factor.cur_factor, s_metering_factor.ele_per_pulse);
            if (APP_OK == save_factor())
            {
                break;
            }
            // 保存失败，恢复状态，重新校准
            memset(&s_metering_factor, 0, sizeof(s_metering_factor));
            s_power_freq = 0;
            s_voltage_freq = 0;
            s_current_freq = 0;
        }
        else
        {
            s_power_freq = cur_power_freq;
            s_voltage_freq = (float)vol_count / (float)(cur_tick - s_last_tick);
            s_current_freq = (float)cur_count / (float)(cur_tick - s_last_tick);
        }
        s_last_tick = cur_tick;
    }
}

/**
 * @brief 计量
 * @param[in]   conf            [配置]
 */
static void metering_run(metering_conf_t *conf)
{
    static uint64_t s_last_tick = 0;
    static uint64_t s_first_tick = 0;
    uint64_t cur_tick = 0;
    float power = 0;
    float voltage = 0;
    float current = 0;
    int16_t pow_cnt = 0;
    int16_t vol_cnt = 0;
    int16_t cur_cnt = 0;
    int16_t tot_pow_cnt = 0;
    METERING_POW_LV_E pow_lv = METERING_POW_LV_MAX;
    uint8_t mtr_cnt = 0;
    uint8_t zero_cnt = 0;
    uint8_t index = 0;

    vhal_pcnt_clear_counter(VHAL_PCNT_UNIT_0);
    vhal_pcnt_clear_counter(VHAL_PCNT_UNIT_1);
    s_last_tick = vesync_task_get_tick_ms();
    s_first_tick = s_last_tick;
    while(!s_metering_rated.flag)
    {
        vesync_sleep(METERING_SCAN_COUNT_INTERVAL);

        if (APP_OK != metering_get_pulse_count(conf->gpios.sel_gpio, &pow_cnt, &vol_cnt, &cur_cnt))
        {
            s_last_tick = vesync_task_get_tick_ms();
            s_first_tick = s_last_tick;
            pow_lv = METERING_POW_LV_MAX;
            mtr_cnt = 0;
            tot_pow_cnt = 0;
            continue;
        }
        cur_tick = vesync_task_get_tick_ms();
        power = (float)pow_cnt / (float)(cur_tick - s_last_tick) * s_metering_factor.pow_factor;
        voltage = (float)vol_cnt / (float)(cur_tick - s_last_tick) * s_metering_factor.vol_factor;
        current = (float)cur_cnt / (float)(cur_tick - s_last_tick) * s_metering_factor.cur_factor;
        if (0 != voltage)
        {
            s_metering_status.voltage = voltage;
        }
        if (0 == pow_cnt)
        {
            ++zero_cnt;
        }
        else
        {
            zero_cnt = 0;
        }
        if (0 == s_metering_status.power || power > METERING_POW_MAX_LV_VAL || METERING_POW_ZERO_INT == zero_cnt)
        {
            pow_lv = METERING_POW_LV_MAX;
            mtr_cnt = 0;
            tot_pow_cnt = 0;
            s_first_tick = cur_tick;
            s_metering_status.power = power;
            if (0 == current && 0!= voltage)
            {
                s_metering_status.current = power / voltage;
            }
#if METERING_SEL_CFI_IN_TURN
            else if (0 != current)    // 此次测量电流
            {
                s_metering_status.current = current;
            }
#endif
        }
        else
        {
            switch (pow_lv)
            {
                case METERING_POW_LV1:
                    ++mtr_cnt;
                    tot_pow_cnt += pow_cnt;
                    if (METERING_POW_LV1_INT == mtr_cnt)
                    {
                        s_metering_status.power = (float)tot_pow_cnt / (float)(cur_tick - s_first_tick) * s_metering_factor.pow_factor;
                        if (0 != s_metering_status.voltage)
                        {
                            s_metering_status.current = s_metering_status.power / s_metering_status.voltage;
                        }
                        mtr_cnt = 0;
                        tot_pow_cnt = 0;
                        s_first_tick = cur_tick;
                        pow_lv = METERING_POW_LV_MAX;
                    }
                    break;
                case METERING_POW_LV2:
                    ++mtr_cnt;
                    tot_pow_cnt += pow_cnt;
                    if (METERING_POW_LV2_INT == mtr_cnt)
                    {
                        s_metering_status.power = (float)tot_pow_cnt / (float)(cur_tick - s_first_tick) * s_metering_factor.pow_factor;
                        if (0 != s_metering_status.voltage)
                        {
                            s_metering_status.current = s_metering_status.power / s_metering_status.voltage;
                        }
                        mtr_cnt = 0;
                        tot_pow_cnt = 0;
                        s_first_tick = cur_tick;
                        pow_lv = METERING_POW_LV_MAX;
                    }
                    break;
                case METERING_POW_LV3:
                    ++mtr_cnt;
                    tot_pow_cnt += pow_cnt;
                    if (METERING_POW_LV3_INT == mtr_cnt)
                    {
                        s_metering_status.power = (float)tot_pow_cnt / (float)(cur_tick - s_first_tick) * s_metering_factor.pow_factor;
                        if (0 != s_metering_status.voltage)
                        {
                            s_metering_status.current = s_metering_status.power / s_metering_status.voltage;
                        }
                        mtr_cnt = 0;
                        tot_pow_cnt = 0;
                        s_first_tick = cur_tick;
                        pow_lv = METERING_POW_LV_MAX;
                    }
                    break;
                case METERING_POW_LV4:
                case METERING_POW_LV_MAX:
                default:
                    if (power < METERING_POW_LV1_VAL)
                    {
                        pow_lv = METERING_POW_LV1;
                        ++mtr_cnt;
                        tot_pow_cnt += pow_cnt;
#if METERING_POW_MIN_INT == METERING_POW_LV1_INT
                        if (METERING_POW_LV1_INT == mtr_cnt)
                        {
                            s_metering_status.power = (float)tot_pow_cnt / (float)(cur_tick - s_first_tick) * s_metering_factor.pow_factor;
                            if (0 != s_metering_status.voltage)
                            {
                                s_metering_status.current = s_metering_status.power / s_metering_status.voltage;
                            }
                            mtr_cnt = 0;
                            tot_pow_cnt = 0;
                            s_first_tick = cur_tick;
                            pow_lv = METERING_POW_LV_MAX;
                        }
#endif
                    }
                    else if (power < METERING_POW_LV2_VAL)
                    {
                        pow_lv = METERING_POW_LV2;
                        ++mtr_cnt;
                        tot_pow_cnt += pow_cnt;
#if METERING_POW_MIN_INT == METERING_POW_LV2_INT
                        if (METERING_POW_LV2_INT == mtr_cnt)
                        {
                            s_metering_status.power = (float)tot_pow_cnt / (float)(cur_tick - s_first_tick) * s_metering_factor.pow_factor;
                            if (0 != s_metering_status.voltage)
                            {
                                s_metering_status.current = s_metering_status.power / s_metering_status.voltage;
                            }
                            mtr_cnt = 0;
                            tot_pow_cnt = 0;
                            s_first_tick = cur_tick;
                            pow_lv = METERING_POW_LV_MAX;
                        }
#endif
                    }
                    else if (power < METERING_POW_LV3_VAL)
                    {
                        pow_lv = METERING_POW_LV3;
                        ++mtr_cnt;
                        tot_pow_cnt += pow_cnt;
#if METERING_POW_MIN_INT == METERING_POW_LV3_INT
                        if (METERING_POW_LV3_INT == mtr_cnt)
                        {
                            s_metering_status.power = (float)tot_pow_cnt / (float)(cur_tick - s_first_tick) * s_metering_factor.pow_factor;
                            if (0 != s_metering_status.voltage)
                            {
                                s_metering_status.current = s_metering_status.power / s_metering_status.voltage;
                            }
                            mtr_cnt = 0;
                            tot_pow_cnt = 0;
                            s_first_tick = cur_tick;
                            pow_lv = METERING_POW_LV_MAX;
                        }
#endif
                    }
                    else
                    {
                        pow_lv = METERING_POW_LV4;
                        s_first_tick = cur_tick;
                        s_metering_status.power = power;
                        if (0 == current && 0!= voltage)
                        {
                            s_metering_status.current = power / voltage;
                        }
#if METERING_SEL_CFI_IN_TURN
                        else if (0 != current)    // 此次测量电流
                        {
                            s_metering_status.current = current;
                        }
#endif
                    }
                    break;
            }
        }

        for (index = 0; index < OUTLET_METERING_ELEC_UNIT_NUM; ++index)
        {
            if (VOS_OK == vesync_mutex_try_lock(s_metering_status.elec_arry[index].ele_lock))
            {
                s_metering_status.elec_arry[index].electricity += pow_cnt * s_metering_factor.ele_per_pulse;
                vesync_mutex_unlock(s_metering_status.elec_arry[index].ele_lock);
            }
        }

        s_last_tick = cur_tick;
        MTR_DEBUG_D("power: %8f, voltage: %8f, current: %8f, electricity[0]: %8f, electricity[1]: %8f\n",
        s_metering_status.power, s_metering_status.voltage, s_metering_status.current, s_metering_status.elec_arry[0].electricity, s_metering_status.elec_arry[1].electricity);
        if (NULL != conf->exception_cb)  // 硬件保护失效，重启？
        {
            if (s_metering_status.power < conf->min_power || s_metering_status.power > conf->max_power ||
                s_metering_status.voltage < conf->min_voltage || s_metering_status.voltage > conf->max_voltage ||
                s_metering_status.current < conf->min_current || s_metering_status.current > conf->max_current)
            {
                conf->exception_cb();
            }
        }

        if (NULL != conf->event_cb)  // 软件保护
        {
            if (VOS_OK != vesync_mutex_try_lock(s_metering_mgmt.mgmt_lock))
            {
                continue;
            }
            // 电压、电流和功率不区分通道，不处理通道参数
            // 先判断管理数据是否改变，若改变则重置管理事件
            if (s_metering_mgmt.chg_flag.min_pow)
            {
                conf->event_cb(0, METERING_LOW_POW, 0);
                s_metering_mgmt.chg_flag.min_pow = 0;
            }
            if (s_metering_mgmt.chg_flag.max_pow)
            {
                conf->event_cb(0, METERING_HIGH_POW, 0);
                s_metering_mgmt.chg_flag.max_pow = 0;
            }
            if (s_metering_mgmt.chg_flag.min_vol)
            {
                conf->event_cb(0, METERING_LOW_VOL, 0);
                s_metering_mgmt.chg_flag.min_vol = 0;
            }
            if (s_metering_mgmt.chg_flag.max_vol)
            {
                conf->event_cb(0, METERING_HIGH_VOL, 0);
                s_metering_mgmt.chg_flag.max_vol = 0;
            }
            if (s_metering_mgmt.chg_flag.min_cur)
            {
                conf->event_cb(0, METERING_LOW_CUR, 0);
                s_metering_mgmt.chg_flag.min_cur = 0;
            }
            if (s_metering_mgmt.chg_flag.max_cur)
            {
                conf->event_cb(0, METERING_HIGH_CUR, 0);
                s_metering_mgmt.chg_flag.max_cur = 0;
            }
            if (s_metering_status.power < s_metering_mgmt.min_power)
            {
                conf->event_cb(0, METERING_LOW_POW, s_metering_status.power);
            }
            if (s_metering_status.power > s_metering_mgmt.max_power)
            {
                conf->event_cb(0, METERING_HIGH_POW, s_metering_status.power);
            }
            if (s_metering_status.voltage < s_metering_mgmt.min_voltage)
            {
                conf->event_cb(0, METERING_LOW_VOL, s_metering_status.voltage);
            }
            if (s_metering_status.voltage > s_metering_mgmt.max_voltage)
            {
                conf->event_cb(0, METERING_HIGH_VOL, s_metering_status.voltage);
            }
            if (s_metering_status.current < s_metering_mgmt.min_current)
            {
                conf->event_cb(0, METERING_LOW_CUR, s_metering_status.current);
            }
            if (s_metering_status.current > s_metering_mgmt.max_current)
            {
                conf->event_cb(0, METERING_HIGH_CUR, s_metering_status.current);
            }
            for (index = 0; index < OUTLET_METERING_ELEC_UNIT_NUM; ++index)
            {
                 if (VOS_OK == vesync_mutex_try_lock(s_metering_status.elec_arry[index].ele_lock))
                {
                    if (0 < s_metering_mgmt.max_electrictiy[index] && s_metering_status.elec_arry[index].electricity > s_metering_mgmt.max_electrictiy[index])
                    {
                        conf->event_cb(index, METERING_ELE, s_metering_mgmt.max_electrictiy[index]);
                    }
                    vesync_mutex_unlock(s_metering_status.elec_arry[index].ele_lock);
                }
            }
            vesync_mutex_unlock(s_metering_mgmt.mgmt_lock);
        }
    }
    // 循环退出，清空数据
    s_metering_status.power = 0;
    s_metering_status.voltage = 0;
    s_metering_status.current = 0;
    for (index = 0; index < OUTLET_METERING_ELEC_UNIT_NUM; ++index)
    {
        vesync_mutex_lock(s_metering_status.elec_arry[index].ele_lock);
        s_metering_status.elec_arry[index].electricity = 0;
        vesync_mutex_unlock(s_metering_status.elec_arry[index].ele_lock);
    }
}

/**
 * @brief 计量任务
 * @param[in]   arg
 */
static void metering_task(void* arg)
{
    metering_conf_t *conf = (metering_conf_t *)arg;

    while(1)
    {
        if (1 == s_metering_rated.flag || APP_OK != load_factor())
        {
            metering_calibrate_run(conf);
        }

        metering_run(conf);
    }

}

int outlet_metering_init(metering_conf_t *conf)
{
    int ret = APP_FAIL;

    vhal_gpio_config_t sel_io;
    vhal_pcnt_config_t cf;
    vhal_pcnt_config_t cfi;
    metering_conf_t *metering_conf = NULL;
    uint8_t index = 0;

    VCOM_NULL_PARAM_CHK(conf, return APP_FAIL);
    if (NULL == conf->exception_cb)
    {
        APP_LOG(LOG_ERROR, "must set exception_cb\n");
        return APP_FAIL;
    }

    sel_io.pin_bit_mask = (1ULL << conf->gpios.sel_gpio);
    sel_io.mode = GPIO_MODE_OUT;
    sel_io.pull_up_en = GPIO_PULLUP_DIS;
    sel_io.pull_down_en = GPIO_PULLDOWN_DIS;
    sel_io.intr_type = GPIO_INTR_DIS;
    vhal_gpio_init(sel_io);
    vhal_gpio_set_output(conf->gpios.sel_gpio, METERING_SEL_GPIO_DEFAULT_VALUE);

    cf.pulse_gpio_num = conf->gpios.cf_gpio;
    cf.ctrl_gpio_num = -1; // 不使用此IO，置为负数
    cf.lctrl_mode = VHAL_PCNT_MODE_KEEP;
    cf.hctrl_mode = VHAL_PCNT_MODE_KEEP;
    cf.pos_mode = VHAL_PCNT_COUNT_INC;
    cf.neg_mode = VHAL_PCNT_COUNT_DIS;
    cf.counter_l_lim = METERING_PULSE_COUNT_MIN;
    cf.counter_h_lim = METERING_PULSE_COUNT_MAX;
    cf.unit = VHAL_PCNT_UNIT_0;
    cf.channel = VHAL_PCNT_CHANNEL_0;
    vhal_pcnt_unit_config(&cf);

    cfi.pulse_gpio_num = conf->gpios.cfi_gpio;
    cfi.ctrl_gpio_num = -1; // 不使用此IO，置为负数
    cfi.lctrl_mode = VHAL_PCNT_MODE_KEEP;
    cfi.hctrl_mode = VHAL_PCNT_MODE_KEEP;
    cfi.pos_mode = VHAL_PCNT_COUNT_INC;
    cfi.neg_mode = VHAL_PCNT_COUNT_DIS;
    cfi.counter_l_lim = METERING_PULSE_COUNT_MIN;
    cfi.counter_h_lim = METERING_PULSE_COUNT_MAX;
    cfi.unit = VHAL_PCNT_UNIT_1;
    cfi.channel = VHAL_PCNT_CHANNEL_0;
    vhal_pcnt_unit_config(&cfi);
    memset(&s_metering_rated, 0, sizeof(s_metering_rated));
    memset(&s_metering_status, 0, sizeof(s_metering_status));
    memset(&s_metering_mgmt, 0, sizeof(s_metering_mgmt));

    for (index = 0; index < OUTLET_METERING_ELEC_UNIT_NUM; ++index)
    {
        s_metering_status.elec_arry[index].ele_lock = vesync_mutex_new();
        if (NULL == s_metering_status.elec_arry[index].ele_lock)
        {
            APP_LOG(LOG_ERROR, "create lock fail\n");
            goto exit;
        }
    }
    s_metering_mgmt.min_power = conf->min_power;
    s_metering_mgmt.max_power = conf->max_power;
    s_metering_mgmt.min_voltage = conf->min_voltage;
    s_metering_mgmt.max_voltage = conf->max_voltage;
    s_metering_mgmt.min_current = conf->min_current;
    s_metering_mgmt.max_current = conf->max_current;
    s_metering_mgmt.mgmt_lock = vesync_mutex_new();
    if (NULL == s_metering_mgmt.mgmt_lock)
    {
        APP_LOG(LOG_ERROR, "create lock fail\n");
        goto exit;
    }
    metering_conf = (metering_conf_t *)vesync_malloc(sizeof(metering_conf_t));
    if (NULL == metering_conf)
    {
        APP_LOG(LOG_ERROR, "malloc fail\n");
        goto exit;
    }
    memcpy(metering_conf, conf, sizeof(metering_conf_t));
    if (VOS_OK != vesync_task_new(METERING_TASK_NAME, NULL,
                    metering_task,
                    metering_conf,
                    METERING_TASK_STACKSIZE,
                    METERING_TASK_PRIO, NULL))
    {
        APP_LOG(LOG_ERROR, "metering task create fail!!!\r\n");
        goto exit;
    }
    APP_LOG(LOG_INFO, "metering init done.\r\n");
    ret = APP_OK;

exit:
    if (APP_OK != ret)
    {
        for (index = 0; index < OUTLET_METERING_ELEC_UNIT_NUM; ++index)
        {
            if (NULL != s_metering_status.elec_arry[index].ele_lock)
            {
                vesync_mutex_free(s_metering_status.elec_arry[index].ele_lock);
            }
        }
        if (NULL != s_metering_mgmt.mgmt_lock)
        {
            vesync_mutex_free(s_metering_mgmt.mgmt_lock);
        }
        VCOM_SAFE_FREE(metering_conf);
    }
    return ret;
}

#if 0
/**
 * @brief 清除计量校准系数
 * @return      int             [错误码，成功/失败]
 */
static int clear_factor(void)
{
    uint8_t *factor_buf = NULL;
    uint32_t buf_len = METERING_FACTOR_DATA_BUF_LEN;
    if (SDK_OK != vesync_flash_erase_key(PARTITION_CFG, METERING_FACTOR))
    {
        return APP_FAIL;
    }
    if (SDK_OK != vesync_flash_erase_key(PARTITION_FAC, METERING_FACTOR))
    {
        factor_buf = vesync_malloc(METERING_FACTOR_DATA_BUF_LEN);
        if (NULL != factor_buf)
        {
            if (SDK_OK == vesync_flash_aes_crypto_read(PARTITION_FAC, METERING_FACTOR, factor_buf, &buf_len) && 0 != buf_len)
            {
                vesync_flash_aes_crypto_write(PARTITION_CFG, METERING_FACTOR, factor_buf, buf_len);
            }
            vesync_free(factor_buf);
        }
        return APP_FAIL;
    }

    return APP_OK;
}
#endif

int outlet_metering_set_rated_data(metering_rated_t *rated_data)
{
    VCOM_NULL_PARAM_CHK(rated_data, return APP_FAIL);
    VCOM_IN_RANGE_CHK(rated_data->Power0, 0, OUTLET_METERING_MAX_POW, return APP_FAIL);
    VCOM_IN_RANGE_CHK(rated_data->Voltage0, OUTLET_METERING_MIN_VOL, OUTLET_METERING_MAX_VOL, return APP_FAIL);
    VCOM_IN_RANGE_CHK(rated_data->Current0, 0, OUTLET_METERING_MAX_CUR, return APP_FAIL);

#if 0
    if (APP_OK != clear_factor())
    {
        return APP_FAIL;
    }
#endif
    s_metering_rated.Power0 = rated_data->Power0;
    s_metering_rated.Voltage0 = rated_data->Voltage0;
    s_metering_rated.Current0 = rated_data->Current0;
    s_metering_rated.flag = 1;
    return APP_OK;
}

int outlet_metering_get_metering_data(metering_data_t *metering_data)
{
    VCOM_NULL_PARAM_CHK(metering_data, return APP_FAIL);
    if (s_metering_rated.flag)
    {
        return APP_FAIL;
    }
    else
    {
        if (0 == s_metering_status.voltage && PRODUCTION_EXIT != vesync_production_get_status())
        {
            return APP_FAIL;
        }
    }
    metering_data->power = s_metering_status.power;
    metering_data->voltage = s_metering_status.voltage;
    metering_data->current = s_metering_status.current;
    return APP_OK;
}

int outlet_metering_get_electricity(uint8_t index, float *electricity)
{
    VCOM_NULL_PARAM_CHK(electricity, return APP_FAIL);
    if (index >= OUTLET_METERING_ELEC_UNIT_NUM)
    {
        return APP_FAIL;
    }
    if (VOS_OK != vesync_mutex_lock(s_metering_status.elec_arry[index].ele_lock))
    {
        APP_LOG(LOG_ERROR, "lock fail\n");
        return APP_FAIL;
    }
    *electricity = s_metering_status.elec_arry[index].electricity;
    vesync_mutex_unlock(s_metering_status.elec_arry[index].ele_lock);
    return APP_OK;
}

int outlet_metering_clear_electricity(uint8_t index)
{
    if (index >= OUTLET_METERING_ELEC_UNIT_NUM)
    {
        return APP_FAIL;
    }
    if (VOS_OK != vesync_mutex_lock(s_metering_status.elec_arry[index].ele_lock))
    {
        APP_LOG(LOG_ERROR, "lock fail\n");
        return APP_FAIL;
    }
    s_metering_status.elec_arry[index].electricity = 0;
    vesync_mutex_unlock(s_metering_status.elec_arry[index].ele_lock);
    return APP_OK;
}



int outlet_metering_set_mgmt(metering_mgmt_conf_t *conf)
{
    uint8_t index = 0;

    VCOM_NULL_PARAM_CHK(conf, return APP_FAIL);
    if (VOS_OK != vesync_mutex_lock(s_metering_mgmt.mgmt_lock))
    {
        APP_LOG(LOG_ERROR, "lock fail\n");
        return APP_FAIL;
    }

    for (index = 0; index < OUTLET_METERING_ELEC_UNIT_NUM; ++index)
    {
        if (NULL != conf->max_electrictiy[index])
        {
            s_metering_mgmt.max_electrictiy[index] = *conf->max_electrictiy[index];
        }
    }
    if (NULL != conf->min_power &&
        s_metering_mgmt.min_power != *conf->min_power)
    {
        s_metering_mgmt.chg_flag.min_pow = 0x1;
        s_metering_mgmt.min_power = *conf->min_power;
    }
    if (NULL != conf->max_power &&
        s_metering_mgmt.max_power != *conf->max_power)
    {
        s_metering_mgmt.chg_flag.max_pow = 0x1;
        s_metering_mgmt.max_power = *conf->max_power;
    }
    if (NULL != conf->min_voltage &&
        s_metering_mgmt.min_voltage != *conf->min_voltage)
    {
        s_metering_mgmt.chg_flag.min_vol = 0x1;
        s_metering_mgmt.min_voltage = *conf->min_voltage;
    }
    if (NULL != conf->max_voltage &&
        s_metering_mgmt.max_voltage != *conf->max_voltage)
    {
        s_metering_mgmt.chg_flag.max_vol = 0x1;
        s_metering_mgmt.max_voltage = *conf->max_voltage;
    }
    if (NULL != conf->min_current &&
        s_metering_mgmt.min_current != *conf->min_current)
    {
        s_metering_mgmt.chg_flag.min_cur = 0x1;
        s_metering_mgmt.min_current = *conf->min_current;
    }
    if (NULL != conf->max_current &&
        s_metering_mgmt.max_current != *conf->max_current)
    {
        s_metering_mgmt.chg_flag.max_cur = 0x1;
        s_metering_mgmt.max_current = *conf->max_current;
    }

    vesync_mutex_unlock(s_metering_mgmt.mgmt_lock);

    return APP_OK;
}

