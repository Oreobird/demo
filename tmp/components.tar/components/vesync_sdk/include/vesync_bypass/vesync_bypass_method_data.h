/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file       vesync_bypass_method_data.h
* @brief      vesync device config information.
* @date       2021-05-28
* @note       File auto generated, DO NOT edit.
*/

#ifndef __VESYNC_METHOD_DATA_H__
#define __VESYNC_METHOD_DATA_H__

#ifdef __cplusplus
extern "C" {
#endif

/**
* @brief bypass method id 定义
*/
typedef enum
{
    BYPASS_METHOD_ID_SET_SWITCH,    // 设置开关状态
    BYPASS_METHOD_ID_GET_SWITCH,    // 获取开关状态
    BYPASS_METHOD_ID_TOGGLE_SWITCH, // 反转开关状态
    BYPASS_METHOD_ID_SET_INDICATOR,     // 设置指示灯状态
    BYPASS_METHOD_ID_ADD_TIMER,    //添加timer
    BYPASS_METHOD_ID_DEL_TIMER,    //删除timer
    BYPASS_METHOD_ID_GET_TIMER,    //查询timer
    BYPASS_METHOD_ID_ADD_SCHEDULE,      //添加schedule
    BYPASS_METHOD_ID_UP_SCHEDULE,       //编辑schedule
    BYPASS_METHOD_ID_DEL_SCHEDULE,      //删除schedule
    BYPASS_METHOD_ID_GET_SCHEDULE,      //查询schedule
    BYPASS_METHOD_ID_UPDATE_TIMEZONE,   //更新时区偏差值
    BYPASS_METHOD_ID_ADD_AWAY, // 添加away
    BYPASS_METHOD_ID_DEL_AWAY, // 删除away
    BYPASS_METHOD_ID_GET_AWAY, // 查询away
    BYPASS_METHOD_ID_SET_TGT_TEMP,       //设置目标温度
    BYPASS_METHOD_ID_CLEAR_TGT_TEMP,     //清楚目标温度
    BYPASS_METHOD_ID_SET_LIGHT,             //设置灯泡状态
    BYPASS_METHOD_ID_GET_LIGHT,             //获取灯泡状态
    BYPASS_METHOD_ID_GET_OVEN_STATUS,          // 获取烤箱状态（只有普通烹饪）
    BYPASS_METHOD_ID_CONFIRM_COOK_END,         // 确认烹饪结束
    BYPASS_METHOD_ID_START_COOK,               // 开始烹饪接口
    BYPASS_METHOD_ID_PREHEAT_COOK,             // 预热结束开始烹饪
    BYPASS_METHOD_ID_END_COOK,                 // 结束烹饪
    BYPASS_METHOD_ID_SET_TIME_AND_TEMP,        // 设置烹饪时间和温度
    BYPASS_METHOD_ID_READY_COOK,               // 进入ready cook 状态,需要用户按start按键启动
    BYPASS_METHOD_ID_ADJUST_COOK_TIME,         // 调整烹饪时间
    BYPASS_METHOD_ID_OVEN_PREHEAT,             // 烤箱预热
    BYPASS_METHOD_ID_END_PREHEAT,              // 结束预热
    BYPASS_METHOD_ID_GET_AIRFRYER_STATUS,      // 获取空气炸锅状态
    BYPASS_METHOD_ID_START_APPOINT,            // 开始预约
    BYPASS_METHOD_ID_START_STEP_COOK,          // 开始多段烹饪
    BYPASS_METHOD_ID_PAUSE_WORK,               // 暂停
    BYPASS_METHOD_ID_RESUME_WORK,              // 恢复
    BYPASS_METHOD_ID_SKIP_STEP,                // 跳过当前步骤
    BYPASS_METHOD_ID_GET_PRESET_RECIPE,        // 获取设备预设菜谱
    BYPASS_METHOD_ID_RESET_ALL_PRESET_RECIPE,  // 重置所有设备预设菜谱
    BYPASS_METHOD_ID_UPDATE_PRESET_RECIPE,     // 修改单个预设菜谱
    BYPASS_METHOD_ID_RESET_PRESET_RECIPE,      // 重置单个预设菜谱
    BYPASS_METHOD_ID_GET_OVEN_STATUS_V2,       // 获取烤箱状态(含多段烹饪)
    BYPASS_METHOD_ID_START_PRESET_COOK,        // 开始预设菜谱烹饪接口
    BYPASS_METHOD_ID_SET_TIME_OR_TEMP,         // 设置烹饪时间或者温度
    BYPASS_METHOD_ID_SET_LIGHT_SWITCH,         //改变灯的状态
    BYPASS_METHOD_ID_SET_LEVEL,            // 设置设备真实档位
    BYPASS_METHOD_ID_SET_VIRTUAL_LEVEL,    // 设置设备虚拟档位
    BYPASS_METHOD_ID_ADJUST_REAL_RANGE,        // 调整设备真实档位变化范围
    BYPASS_METHOD_ID_ADJUST_VIRTUAL_RANGE,     // 调整设备虚拟档位变化范围
    BYPASS_METHOD_ID_SET_TEMP_UNIT,       //设置温度单位
    BYPASS_METHOD_ID_UPDATE_TEMP_UNIT,    //更新温度单位
    BYPASS_METHOD_ID_SET_DISPLAY,           //设置常规模式下的屏显
    BYPASS_METHOD_ID_SET_DISPLAY_MODE,      //设置熄屏模式
    BYPASS_METHOD_ID_GET_DEVICE_STATUS,             //获取设备状态
    BYPASS_METHOD_ID_GET_SLEEP_STATE,               //获取睡眠模式配置
    BYPASS_METHOD_ID_SET_SLEEP_MANUAL,              //设置睡眠手动模式配置
    BYPASS_METHOD_ID_SET_SLEEP_AUTO,                //设置睡眠自动模式配置
    BYPASS_METHOD_ID_SET_TARGET_HUMIDITY,           //设置恒湿模式下的目标湿度
    BYPASS_METHOD_ID_SET_HUMIDITY_MODE,             //设置加湿器模式
    BYPASS_METHOD_ID_SET_WARM_SWITCH,               //设置热雾档位开关
    BYPASS_METHOD_ID_SET_AUTOMATIC_STOP,            //设置自动停止功能
    BYPASS_METHOD_ID_SET_CONTAINER_CLEAN_SWITCH,    //设置加湿器水箱清洁提醒功能开关
    BYPASS_METHOD_ID_RESET_CONTAINER_CLEAN_STATUS,  //重置加湿器水箱清洁状态
    BYPASS_METHOD_ID_GET_PURIFIER_STATUS,   //获取净化器状态
    BYPASS_METHOD_ID_SET_PURIFIER_MODE,     //设置净化器模式
    BYPASS_METHOD_ID_RESET_FILTER,          //重置滤网
    BYPASS_METHOD_ID_SET_AUTO_PREFERENCE,   //设置自动模式偏好
    BYPASS_METHOD_ID_SET_CHILDLOCK, //设置童锁
    BYPASS_METHOD_ID_TEST_RELAY,        // 继电器测试
    BYPASS_METHOD_ID_SET_NIGHTLIGHT,        //设置夜灯
    BYPASS_METHOD_ID_SET_NIGHTLIGHT_BRIGHTNESS, //设置夜灯亮度
    BYPASS_METHOD_ID_NOTIFY_DEVICE,     // APP/云通知设备
    BYPASS_METHOD_ID_SET_PLASMA,                //设置等离子
    BYPASS_METHOD_ID_SET_DEVICE_TRIGGER,           //设备联动触发值
    BYPASS_METHOD_ID_GET_DEVICE_TRIGGER,           //设备联动触发值
    BYPASS_METHOD_ID_UP_FIRMWARE,    // 固件升级
    BYPASS_METHOD_ID_MAX
} BYPASS_METHOD_ID_E;

/**
 * @brief 开关配置
*/
typedef struct
{
    uint8_t id;                     // 0代表总开关，1~N代表分开关
    bool enable;                    // true: 设备开机，false: 设备关机
} bypass_switch_data_t;

/**
 * @brief 反转开关配置
 */
typedef struct
{
    uint8_t id;                     // 0代表总开关，1~N代表分开关
} bypass_toggle_switch_data_t;

/**
 * @brief 指示灯配置
 */
typedef struct
{
    uint8_t id;                     // 0代表总指示灯，N代表分指示灯
    bool enable;                    // true: 指示灯打开，false: 指示灯关闭
} bypass_indicator_data_t;

/**
 * @brief 设备开关状态
 */
typedef enum
{
    TIMER_ACTION_OFF,
    TIMER_ACTION_ON
} TIMER_ACTION_E;

/**
 * @brief timer定时配置
 */
typedef struct
{
    uint32_t total_sec;         //timer 设定时间
    TIMER_ACTION_E action;      //timer 执行动作
} bypass_timer_data_t;

#define TIMETZONE_STRING_LENGTH            64        //时区长度为64字节

/*
 * @brief 时区与时间偏差值
 */
typedef struct
{
    uint16_t rand_key;                  //随机值固定为
    int      time_deviation;            //相对UTC时间的偏差值,单位为秒
    char     timezone[TIMETZONE_STRING_LENGTH];         // 时区
} timezone_info_t;

/**
 * @brief schedule配置
 */
typedef struct
{
    uint32_t sch_id;        //id
    bool enable;            //使能字段
    uint32_t start_ts;      //开始时间戳
    uint8_t repeat;         //重复控制
    int sun_rise;           //日出日落
    char time_zone[64];     //时区
    char longitude[20];     //经度
    char latitude[20];      //纬度
    void *json_action;      //schedule 执行动作
    uint32_t id;            //schdule 唯一识别id
} bypass_schedule_base_t;    //schedule 基础类型

/**
 * @brief away配置
 */
typedef struct
{
    uint32_t away_id;       //id
    uint32_t start_ts;      //开始时间戳
    uint32_t end_ts;        //结束时间戳
    uint8_t repeat;         //重复控制
    char time_zone[64];     //时区
} bypass_away_base_t;       //away 基础类型定义

/**
 * @brief 目标温度设置
 */
typedef struct
{
    uint32_t target_temp;   // 目标温度
    uint32_t id;            // 探针id
    uint32_t start_ts;      // 时间戳
} bypass_target_temp_t;

/**
 * @brief RGB灯效配置
 */
typedef struct
{
    char action[4];        // 动作on打开，off关闭
    char colorMode[8];     // 模式
    uint8_t bright;        // 亮度百分比
    uint8_t speed;         // 流光周期，单位秒
    uint8_t red;           // 红色分量
    uint8_t green;         // 绿色分量
    uint8_t blue;          // 蓝色分量
} bypass_light_base_t;    //light 基础类型定义

/**
 * @brief 烤箱风扇档位定义
 */
typedef enum
{
    BP_OVEN_FAN_OFF = 0,      //风扇关闭
    BP_OVEN_FAN_LOW = 1,      //风扇低档
    BP_OVEN_FAN_HIGH = 2,     //风扇高档
} BP_OVEN_FAN_E;

/**
* @brief 温度单位定义
*/
typedef enum
{
    BP_TEMP_INVALID    = 0,     //温度单位非法值
    BP_TEMP_FAHRENHEIT = 1,     //华氏度
    BP_TEMP_CENTIGRADE = 2      //摄氏度
} BP_TEMP_UNIT_E;

/**
 * @brief 烤箱模式定义
 */
typedef enum
{
    BP_OVEN_MODE_NONE               = 0x00 ,
    BP_OVEN_MODE_STEAK              = 0x01 ,
    BP_OVEN_MODE_CHICKEN            = 0x02 ,
    BP_OVEN_MODE_SEAFOOD            = 0x03 ,
    BP_OVEN_MODE_BACON              = 0x04 ,
    BP_OVEN_MODE_FROZEN             = 0x05 ,
    BP_OVEN_MODE_FRENCH_FRIES       = 0x06 ,
    BP_OVEN_MODE_VEGETABLES         = 0x07 ,
    BP_OVEN_MODE_SHRIMP             = 0x08 ,
    BP_OVEN_MODE_BAKE               = 0x09 ,
    BP_OVEN_MODE_TOAST              = 0x0A ,
    BP_OVEN_CUSTOM                  = 0x0B ,
    BP_OVEN_MODE_PREHEAT            = 0x0C ,
    BP_OVEN_MODE_WARM               = 0x0D ,
    BP_OVEN_MODE_DEHYDRATE          = 0x0E ,
    BP_OVEN_MODE_ROAST              = 0x0F ,
    BP_OVEN_MODE_BROIL              = 0x10 ,
    BP_OVEN_MODE_AIRFRY             = 0x11 ,
    BP_OVEN_MODE_PIZZA              = 0x12 ,
    BP_OVEN_MODE_COOKIES            = 0x13 ,
    BP_OVEN_MODE_BAGEL              = 0x14 ,
    BP_OVEN_MODE_FERMENTATION       = 0x15 ,
    BP_OVEN_MODE_POULTRY            = 0x16 ,
    BP_OVEN_MODE_DESSERTS           = 0x17 ,
    BP_OVEN_MODE_BREAD              = 0x18 ,
    BP_OVEN_MODE_ROOTVEGGIES        = 0x19 ,
    BP_OVEN_MODE_COOLDOWN           = 0x1A ,
    BP_OVEN_MODE_SLOWCOOK           = 0x1B ,
    BP_OVEN_MODE_DEFROST            = 0x1C ,
    BP_OVEN_MODE_ROTISSERIE         = 0x1D ,
    BP_OVEN_MODE_SWEETPOTATO        = 0x1E ,
    BP_OVEN_MODE_WHOLE_CHICKEN      = 0x1F ,
    BP_OVEN_MODE_EGG_TART           = 0x20 ,
    BP_OVEN_MODE_AIRGRILL           = 0x22 ,
} BP_OVEN_MODE_E;

/**
 * @brief 菜谱类型定义
 */
typedef enum
{
    BP_PUBLIC_RECIPE = 1,   //公共菜谱
    BP_CUSTOM_RECIPE = 2,   //自定义菜谱
    BP_MANUAL_RECIPE = 3,   //手动菜谱
    BP_OPTIONAL_RECIPE = 5, //内置食谱（控制板上的）
} BP_RECIPE_TYPE_E;

/**
 * @brief 开始烹饪参数
 */
typedef struct
{
    uint8_t cook_level;     //烹饪档位
    uint32_t cook_set_time; //烹饪设置时间
    uint16_t cook_temp;     //烹饪温度
    uint16_t preheat_temp;  //预热温度
    uint32_t shake_time;       //shake时间
    uint8_t wind_mode;         //风扇状态//新增
    uint8_t heating_type;      //加热模式
    uint16_t up_tube_temp;     //烹饪上管温度
    uint16_t down_tube_temp;   //烹饪下管温度
} bypass_oven_start_act_t;   //烤箱烹饪动作定义


/**
 * @brief 烹饪字段非法值定义
 */
typedef enum
{
    BP_COOK_LEVEL_INVALID       = 0xF1,             //级别数值非法值
    BP_COOK_TEMP_INVALID        = 0xFFF1,           //温度数值非法值
    BP_COOK_TIME_INVALID        = 0xFFFFFFF1,       //烹饪时间非法值
    BP_COOK_HEATING_TYPE_INVALID    = 0xF1,         //加热模式数值非法值//新增
    BP_SHAKE_TIME_INVALID           = 0xFFFFFFF1,   //shake时间非法值
    BP_WIND_MODE_INVALID            = 0xF1,         //风扇挡位非法值//新增
} BP_OVEN_COOKING_E;


/**
 * @brief 烹饪时间和温度
 */
typedef struct
{
    uint32_t cook_set_time;                     //烹饪设置时间
    BP_TEMP_UNIT_E temp_unit;               //温度单位
    uint16_t cook_temp;                         //烹饪温度
} bypass_cooking_time_and_temp_t;


typedef struct
{
    BP_OVEN_MODE_E mode;                    //烤箱工作模式
    char account_id[32];                        //acount id
    uint32_t recipe_id;                         //菜谱id
    char recipe_name[128];                      //菜谱名称
    BP_RECIPE_TYPE_E recipe_type;           //菜谱类型
    bool preheat;                               //是否预热
    bool keepwarm;                               //是否保温
    BP_TEMP_UNIT_E temp_unit;               //温度单位
    bool ready;                                 //是否进入ready状态
    union
    {
        bypass_oven_start_act_t cooking_act;    //烹饪动作
    } action;
    void * json_start_act;                      //开始动作json对象
} bypass_oven_cooking_t;     //烤箱烹饪参数

/**
 * @brief 烹饪动作定义
 */
typedef struct
{
    uint8_t cook_level;     //烹饪档位
    uint32_t cook_set_time; //烹饪设置时间
    uint16_t cook_temp;     //烹饪温度
    uint16_t preheat_temp;  //预热温度
    uint32_t shake_time;    //shake时间
}bypass_preset_start_act_t;

/**
 * @brief 预设菜谱烹饪
 *
 */
typedef struct
{
    BP_OVEN_MODE_E mode;
    char account_id[32];
    uint32_t recipe_id;                         //菜谱id
    char recipe_name[128];                      //菜谱名称
    BP_RECIPE_TYPE_E recipe_type;           //菜谱类型
    BP_TEMP_UNIT_E temp_unit;               //温度单位
    bool ready;                                 //是否进入ready状态
    union
    {
        bypass_preset_start_act_t cooking_act;    //烹饪动作
    } action;
}bypass_preset_cooking_t;     //烤箱烹饪参数

/**
 * @brief 多段烹饪参数
 *
 */
typedef struct
{
    char account_id[32];
    bool has_preheat;                           //是否预热
    uint16_t preheat_temp;                      //预热温度
    BP_TEMP_UNIT_E temp_unit;               //温度单位
    void * json_step;
    bool ready;                                 //是否进入ready状态
} bypass_step_cook_t;

typedef struct
{
    int adjust_time;                //烹饪调整时间
}bypass_oven_adjust_time_t;

//烤箱单独预热功能数据结果
typedef struct
{
    BP_TEMP_UNIT_E temp_unit;               //温度单位
    uint16_t preheat_temp;                      //烹饪温度
    bool ready;                                 //ready状态（可选）
} bypass_oven_preheat_para_t;

/**
 * @brief 预约
 *
 */
typedef struct
{
    BP_OVEN_MODE_E mode;
    char account_id[32];
    uint32_t recipe_id;                         //菜谱id
    char recipe_name[128];                      //菜谱名称
    BP_RECIPE_TYPE_E recipe_type;           //菜谱类型
    BP_TEMP_UNIT_E temp_unit;               //温度单位
    uint32_t cook_set_time;                     //烹饪设置时间
    uint16_t cook_temp;                         //烹饪温度
    uint32_t shake_time;                        //shake时间
    uint32_t appointment_ts;                    //预约时间
    bool ready;                                 //ready状态（可选）
    uint8_t cook_level;                         //烹饪级别 （可选）
    uint8_t wind_mode;                          //风扇状态//新增 （可选）
    uint8_t heating_type;                       //加热模式//新增（可选）
    uint16_t up_tube_temp;                      //烹饪上管温度//新增（可选）
    uint16_t down_tube_temp;                    //烹饪下管温度//新增（可选）
} bypass_cook_start_appoint_t;

/**
 * @brief 跳过的步骤
 *
 */
typedef enum
{
    BP_COOK_STEP_PREHEAT,   //跳过预热
    BP_COOK_STEP_COOK,      //跳过烹饪
    BP_COOK_STEP_SHAKE,     //跳过shake
    BP_COOK_APPOINT,        //跳过预约
} BYPASS_COOK_STEP_E;

/**
 * @brief 跳过当前步骤
 *
 */
typedef struct
{
    BYPASS_COOK_STEP_E step;
} bypass_skip_step_t;

/**
 * @brief 修改单个预设菜谱
 *
 */
typedef struct
{
    BP_OVEN_MODE_E mode;
    BP_TEMP_UNIT_E temp_unit;   //温度单位
    uint32_t cook_set_time;     //烹饪设置时间
    uint16_t cook_temp;         //烹饪温度
    uint32_t shake_time;        //shake时间
    uint8_t  cook_level;        //烹饪级别
    bool has_warm;              //是否关联保温
    bool has_preheat;           //是否关联预热
} bypass_update_preset_recipe_t;

/**
 * @brief 重置单个预设菜谱
 *
 */
typedef struct
{
    BP_OVEN_MODE_E mode;
    uint8_t cook_level;     //烹饪档位
} bypass_reset_preset_recipe_t;

/**
 * @brief 关联预热
 *
 */
typedef enum
{
    BP_PREHEAT_CONGIG_NO      = 0,      //无关联预热
    BP_PREHEAT_CONGIG_YES     = 1,      //有关联预热
} BYPASS_PREHEAT_CONGIG_E;

/**
 * @brief 灯开关
 */
typedef struct
{
    bool enable;            //开关使能
    uint32_t id;            //开关id
} bypass_light_switch_para_t;

/*
 * @brief 开关类型
 */
typedef enum
{
    BP_LEVEL_WIND = 0,  // 风扇档位
    BP_LEVEL_MIST,      // 加湿器冷雾档位
    BP_LEVEL_WARM,      // 加湿器热雾档位
} BP_LEVEL_E;

/*
 * @brief 开关和档位定义
 */
typedef struct
{
    uint32_t id;             // id
    int level;               // 档位
    BP_LEVEL_E type;     //档位类型定义
} bypass_level_para_t;       //档位类型定义

/*
 * @brief 调整设备范围类型
 */
typedef enum
{
    BP_RANGE_WARM = 0,              // 加湿器热雾档位
    BP_RANGE_MIST,                  // 加湿器冷雾档位
    BP_RANGE_WIND,                  // 净化器风速档位
    BP_RANGE_TGT_HUM,               // 加湿器自动模式目标湿度增/减
    BP_RANGE_LIGHT_BRIGHTNESS,      // 加湿器夜灯亮度
} BP_RANGE_E;

/*
 * @brief 调整设备范围
 */
typedef struct
{
    int value;                      //调整值，正表示增加，负表示减小
    BP_RANGE_E type;            //调整类型
} bypass_range_para_t;       //档位类型定义

/**
 * @brief 温度单位设置
 */
typedef struct
{
    uint32_t temp_unit;        //温度单位
} bypass_update_temp_unit_t;

/*
 * @brief 常规模式下的屏显类型定义
 */
typedef struct
{
    bool display;                //true/false    屏显开关
} bypass_normal_display_t;

/**
 * @brief 熄屏模式定义
 */
typedef struct
{
    bool display_forever;    //true为永久息屏/false为一次息屏
} bypass_display_mode_t;

/*
 * @brief 加湿器模式类型
 */
typedef enum
{
    BP_HUM_AUTO = 0,            // 加湿器自动模式
    BP_HUM_MANUAL,              // 加湿器手动模式
    BP_HUM_HUMIDITY,            // 净化器恒湿模式
    BP_HUM_SLEEP,               // 加湿器睡眠模式
} BYPASS_HUM_MODE_E;

/*
 * @brief 加湿器睡眠手动模式类型定义
 */
typedef struct
{
    bool warm_enabled;          //true/false    热雾档位开关
    uint8_t warm_level;         //1-3           热雾档位
    uint8_t mist_level;         //1-11          冷雾档位
    bool display;               //true/false    屏显开关
} bypass_sleep_manual_t;

/*
 * @brief 加湿器睡眠自动模式类型定义
 */
typedef struct
{
    uint8_t target_humidity;     //30-80         目标湿度
    bool display;                //true/false    屏显开关
} bypass_sleep_auto_t;

/*
 * @brief 恒湿/自动模式下的目标湿度
 */
typedef struct
{
    BYPASS_HUM_MODE_E mode;     // 模式，目前有恒湿/自动
    uint8_t target_humidity;    // 目标湿度
} bypass_target_humidity_t;

/*
 * @brief 加湿器模式
 */
typedef struct
{
    char mode[10];              // "auto"/"humidity"/"sleep"/"manual"
} bypass_humidifier_mode_t;

/*
 * @brief 热雾档位的开关
 */
typedef struct
{
    bool warm_enabled;           //true/false
} bypass_warm_mode_t;

/*
 * @brief 历史数据
 */
typedef struct
{
    int recordTime;             // 时间戳
    int totalTime;              // 设备使用时长，以秒为单位
    uint8_t humidity;           // 湿度数据
} bypass_hum_data_t;

/**
 * @brief 自动停止功能数据结构
 */
typedef struct
{
    bool enable;                    // true: 自动停止功能打开，false: 自动停止功能关闭
} bypass_auto_stop_data_t;

/**
 * @brief 当前湿度值设置
 */
typedef struct
{
    uint8_t cur_humidity_value;        //当前湿度值
} bypass_cur_humidity_data_t;

/**
 * @brief 净化器模式
 */
typedef enum
{
    BP_PURIFIER_MODE_MANUAL = 0,    //手动模式
    BP_PURIFIER_MODE_SLEEP, //睡眠模式
    BP_PURIFIER_MODE_AUTO,  //自动模式
    BP_PURIFIER_MODE_POLLEN,    //花粉模式
} BP_PURIFIER_MODE_E;

/**
 * @brief 净化器档位
 */
typedef enum
{
    BP_PURIFIER_LEVEL_SLEEP = 0,    //睡眠档
    BP_PURIFIER_LEVEL_1,    //1档
    BP_PURIFIER_LEVEL_2,    //2档
    BP_PURIFIER_LEVEL_3,    //3档
    BP_PURIFIER_LEVEL_4,    //4档
    BP_PURIFIER_LEVEL_5,    //5档
    BP_PURIFIER_LEVEL_6,    //6档
    BP_PURIFIER_LEVEL_7,    //7档
    BP_PURIFIER_LEVEL_8,    //8档
    BP_PURIFIER_LEVEL_9,    //9档
    BP_PURIFIER_LEVEL_10,   //10档
} BP_PURIFIER_LEVEL_E;


/**
 * @brief 净化器模式配置
 */
typedef struct
{
    BP_PURIFIER_MODE_E mode;
} bypass_set_purifier_mode_t;

/**
 * @brief 净化器自动偏好
 */
typedef enum
{
    BP_PURIFIER_AUTO_DEFAULT = 0,           // 默认模式
    BP_PURIFIER_AUTO_QUIET,                 // 安静模式
    BP_PURIFIER_AUTO_EFFICIENT,             // 高效模式
} BYPASS_PUR_AUTO_PREF_E;

/**
 * @brief 净化器自动偏好设置
 */
typedef struct
{
    BYPASS_PUR_AUTO_PREF_E auto_pref;      //净化器自动偏好
    uint16_t room_size;                    //房间尺寸
}bypass_set_purifier_auto_preference_t;

/**
 * @brief PM2.5设置
 */
typedef struct
{
    uint16_t pm25_value;        //pm2.5值
} bypass_pm25_data_t;

/**
 * @brief 设置滤网使用
 */
typedef struct
{
    uint32_t dust;              // 集尘量
    uint32_t use_time;          // 滤网使用时间
} bypass_filter_use_data_t;

/**
 * @brief 设置滤网加速速率
 */
typedef struct
{
    uint32_t speed;
} bypass_filter_speed_data_t;

/**
 * @brief 设置滤网加速开关
 */
typedef struct
{
    bool speed_up;                 //滤网加速测试开关
} bypass_filter_speed_up_t;

/*
 * @brief 童锁定义
 */
typedef struct
{
    bool childlock;     // true/false  童锁开关
} bypass_childlock_t;

/**
 * @brief 继电器测试配置
 */
typedef struct
{
    bool start;                    // true为开始测试，false为停止测试
} bypass_test_relay_data_t;

/**
 * @brief 夜灯状态
 */
typedef enum
{
    BP_NIGHTLIGHT_OFF = 0, //夜灯关闭
    BP_NIGHTLIGHT_ON,  //夜灯开启
    BP_NIGHTLIGHT_DIM  //夜灯dimmer
} BP_NIGHTLIGHT_E;

/**
 * @brief 夜灯配置
 */
typedef struct
{
    BP_NIGHTLIGHT_E nightlight;
} bypass_set_nightlight_t;

/**
 * @brief 夜灯亮度
 */
typedef struct
{
    uint8_t brightness;             //亮度
} bypass_nightlight_brightness_t;

/**
 * @brief 设备通知
 */
typedef enum
{
    BP_NOTIFY_FFS_SETUP = 0,        // 通知设备FFS配网成功
    BP_NOTIFY_UNKNOWN,                  // 未知消息
} BYPASS_NOTIFY_TYPE_E;

/*
 * @brief 等离子定义
 */
typedef struct
{
    bool plasma;        // true/false  等离子开关
} bypass_plasma_t;

/**
 * @brief 传感器枚举类型
 */
typedef enum
{
    BP_SENSOR_PM25  = 0,      //pm25传感器
    BP_SENSOR_HUMIDITY= 1,    //湿度传感器
} BP_SENSOR_TYPE_E;


/**
 * @brief 联动触发参数
 */
typedef struct
{
    int sensor_id;             //传感器id
    bool enable;               //触发使能
    BP_SENSOR_TYPE_E sensor_type;   //传感器数据类型
    int threshold;             //变化阀值
    int interval_sec;          //固定上报时间间隔
} bypass_set_device_trigger_t;


/**
 * @brief 获取联动触发参数
 */
typedef struct
{
    int sensor_id;             //传感器id
} bypass_get_device_trigger_t;

#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_METHOD_DATA_H__ */
