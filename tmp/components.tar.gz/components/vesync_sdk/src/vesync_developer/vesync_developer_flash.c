/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_developer_flash.c
 * @brief       开发者模式读写flash接口实现
 * @date        2021-06-22
 */

#include "vesync_memory.h"
#include "vesync_flash.h"
#include "vesync_common.h"
#include "vesync_log_internal.h"
#include "vesync_developer_internal.h"
#include "vesync_klv.h"

#define  VESYNC_DBG_CFG_WRITE_LEN          64

//klv数据key的定义，key不能重用，若新增数据key ID从后面添加，若某项数据废弃后其ID不能删除
typedef enum
{
    DBG_KEY_ID_DATA_VERSION =0,
    DBG_KEY_ID_ENABLE_DEVELOPER = 1,
    DBG_KEY_ID_LOG_LEVEL = 2,
    DBG_KEY_ID_LOG_RAW_LEVEL = 3,
    NET_KEY_ID_MAX
} DBG_CFG_KEY_E;


/**
 * @brief 清除调试方式配置
 * @param[in]  dbg_cfg_t   [保存调试方式配置]
 * @return int              [成功：SDK_OK，失败：SDK_FAIL]
 */
int vesync_developer_flash_clear_dbg_cfg(void)
{
    int ret = vhal_flash_erase_key(PARTITION_CFG, USER_CFG_KEY_DBG_CONFIG);
    if (VHAL_OK != ret)
    {
        SDK_LOG(LOG_ERROR, "clear dbg_cfg fail\n");
        return SDK_FAIL;
    }

    return SDK_OK;
}


/**
 * @brief 读取调试方式配置
 * @param[out]  dbg_cfg_t   [保存调试方式配置]
 * @return int              [成功：SDK_OK，失败：SDK_FAIL]
 */
int vesync_developer_flash_read_dbg_cfg(dbg_cfg_t *p_dbg_cfg)
{
    char *ptr_buf = NULL;
    int ret = SDK_OK;
    uint32_t read_len  = 0;

    VCOM_NULL_PARAM_CHK(p_dbg_cfg, return SDK_FAIL);

    ptr_buf = vesync_malloc(VESYNC_DBG_CFG_WRITE_LEN * sizeof(uint8_t));
    VCOM_NULL_RET_CHK(ptr_buf, return SDK_FAIL);

    memset(ptr_buf, 0, VESYNC_DBG_CFG_WRITE_LEN);
    memset(p_dbg_cfg, 0, sizeof(dbg_cfg_t));

    read_len = VESYNC_DBG_CFG_WRITE_LEN;
    ret = vesync_flash_read(PARTITION_CFG, USER_CFG_KEY_DBG_CONFIG, (uint8_t*)ptr_buf, &read_len);
    if (ret != SDK_OK)
    {
        SDK_LOG(LOG_WARN, "read dbg cfg fail\n");
        vesync_free(ptr_buf);
        return SDK_FAIL;
    }

    ret |= vesync_klv_get((uint8_t *)ptr_buf, VESYNC_DBG_CFG_WRITE_LEN, DBG_KEY_ID_DATA_VERSION,
        sizeof(p_dbg_cfg->data_version), &p_dbg_cfg->data_version);

    ret |= vesync_klv_get((uint8_t *)ptr_buf, VESYNC_DBG_CFG_WRITE_LEN, DBG_KEY_ID_ENABLE_DEVELOPER,
        sizeof(p_dbg_cfg->enable_developer), (uint8_t*)&p_dbg_cfg->enable_developer);

    ret |= vesync_klv_get((uint8_t *)ptr_buf, VESYNC_DBG_CFG_WRITE_LEN, DBG_KEY_ID_LOG_LEVEL,
        sizeof(p_dbg_cfg->log_level), &p_dbg_cfg->log_level);

    ret |= vesync_klv_get((uint8_t *)ptr_buf, VESYNC_DBG_CFG_WRITE_LEN, DBG_KEY_ID_LOG_RAW_LEVEL,
        sizeof(p_dbg_cfg->log_raw_level), &p_dbg_cfg->log_raw_level);

    VCOM_SAFE_FREE(ptr_buf);

    SDK_LOG(LOG_DEBUG, "data_ver = %d, enable_developer = %d, log_level = %d, log_raw_level = %d.\n",
        p_dbg_cfg->data_version, p_dbg_cfg->enable_developer, p_dbg_cfg->log_level, p_dbg_cfg->log_raw_level);

    return ret;
}

/**
 * @brief 调试方式设置，保存到用户分区，恢复出厂需要清除
 * @param[in]  dbg_cfg_t        [调试方式配置]
 * @param[in]  uint8_t          [调试方式配置修改的变量]
 * @return int                  [成功：SDK_OK，失败：SDK_FAIL]
 */
int vesync_developer_flash_update_dbg_cfg(dbg_cfg_t *p_dbg_cfg, uint8_t flag)
{
    int ret = SDK_FAIL;
    char *write_ptr_buf = NULL;
    int offset =0;

    VCOM_NULL_PARAM_CHK(p_dbg_cfg, return SDK_FAIL);

    dbg_cfg_t dbg_cfg_old;
    dbg_cfg_t dbg_cfg_new;

    memset((uint8_t *)&dbg_cfg_old, 0, sizeof(dbg_cfg_t));
    memset((uint8_t *)&dbg_cfg_new, 0, sizeof(dbg_cfg_t));

    // 读出当前配置，(失败时使用默认值)
    vesync_developer_flash_read_dbg_cfg(&dbg_cfg_old);

    if ((flag & DBG_CFG_CHANGE_DEVELOPER_FLAG) == DBG_CFG_CHANGE_DEVELOPER_FLAG)
    {
        dbg_cfg_new.enable_developer = p_dbg_cfg->enable_developer;
    }
    else
    {
        dbg_cfg_new.enable_developer = dbg_cfg_old.enable_developer;
    }

    if ((flag & DBG_CFG_CHANGE_LOG_LVL_FLAG) == DBG_CFG_CHANGE_LOG_LVL_FLAG)
    {
        dbg_cfg_new.log_level = p_dbg_cfg->log_level;
        vesync_log_level_set(dbg_cfg_new.log_level);
    }
    else
    {
        dbg_cfg_new.log_level = dbg_cfg_old.log_level;
    }

    if ((flag & DBG_CFG_CHANGE_LOG_RAW_LVL_FLAG) == DBG_CFG_CHANGE_LOG_RAW_LVL_FLAG)
    {
        dbg_cfg_new.log_raw_level = p_dbg_cfg->log_raw_level;
        vesync_log_raw_level_set(dbg_cfg_new.log_raw_level);
    }
    else
    {
        dbg_cfg_new.log_raw_level = dbg_cfg_old.log_raw_level;
    }


    write_ptr_buf = vesync_malloc(VESYNC_DBG_CFG_WRITE_LEN * sizeof(uint8_t));
    VCOM_NULL_RET_CHK(write_ptr_buf, return SDK_FAIL);

    memset(write_ptr_buf, 0, VESYNC_DBG_CFG_WRITE_LEN);

    uint8_t version = PR_DEVELOPER_CFG_VERSION;
    offset += vesync_klv_set((uint8_t *)write_ptr_buf + offset, VESYNC_DBG_CFG_WRITE_LEN - offset,
        DBG_KEY_ID_DATA_VERSION, sizeof(dbg_cfg_new.data_version), &version);
    offset += vesync_klv_set((uint8_t *)write_ptr_buf + offset, VESYNC_DBG_CFG_WRITE_LEN - offset,
        DBG_KEY_ID_ENABLE_DEVELOPER, sizeof(dbg_cfg_new.enable_developer), (uint8_t*)&dbg_cfg_new.enable_developer);
    offset += vesync_klv_set((uint8_t *)write_ptr_buf + offset, VESYNC_DBG_CFG_WRITE_LEN - offset,
        DBG_KEY_ID_LOG_LEVEL, sizeof(dbg_cfg_new.log_level), &dbg_cfg_new.log_level);
    offset += vesync_klv_set((uint8_t *)write_ptr_buf  +offset, VESYNC_DBG_CFG_WRITE_LEN - offset,
        DBG_KEY_ID_LOG_RAW_LEVEL, sizeof(dbg_cfg_new.log_raw_level), &dbg_cfg_new.log_raw_level);

    ret = vesync_flash_write(PARTITION_CFG, USER_CFG_KEY_DBG_CONFIG, (uint8_t*)write_ptr_buf, offset);
    if (ret != SDK_OK)
    {
        VERR_UPLOAD(VERR_FLASH_WRITE_FAIL, 0);
        return SDK_FAIL;
    }

    SDK_LOG(LOG_DEBUG, "Update dbg config success.\n");

    VCOM_SAFE_FREE(write_ptr_buf);
    return SDK_OK;
}


