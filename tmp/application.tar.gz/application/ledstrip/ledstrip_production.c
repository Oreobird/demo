/**
*Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file    ledstrip_production.c
* @brief   产测功能
* @author  Lind
*@date     2021-09-08
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "vesync_common.h"
#include "vesync_log.h"
#include "vesync_device.h"
#include "vesync_production.h"

#include "ledstrip.h"
#include "ledstrip_led.h"
#include "ledstrip_production.h"
#include "ledstrip_button.h"
#include "ledstrip_flash.h"
#include "ledstrip_report.h"

// 产测灯效
static ls_led_rgb_t s_production_test[6] = {{50, 0, 0, 0, 0}, {0, 50, 0, 0, 0}, {0, 0, 50, 0, 0}, {0, 0, 0, 50, 0}, {0, 0, 0, 0, 50}, {0, 0, 0, 0, 0}};
static ls_led_rgb_t s_production_running = {50, 0, 0, 0, 0};
static ls_led_rgb_t s_production_pass = {0, 0, 0, 50, 0};
static ls_led_rgb_t s_production_fail = {0, 0, 50, 0, 0};

// 所有灯循环切换
static ls_led_diverse_param_t s_ls_production_mode =
 {
     .mode = LS_SCENE_SWITCH,
     .node_num = 6,
     .first_node = 0,
     .step_num = 50,
     .times = 0,
     .mode_head = s_production_test,
 };

 // 产测服务器连接成功后冷光50%常亮
 static ls_led_diverse_param_t s_ls_production_running =
 {
     .mode = LS_SCENE_SINGLE,
     .node_num = 1,
     .first_node = 0,
     .step_num = 0,
     .times = 0,
     .mode_head = &s_production_running,
 };


// 产测通过常绿
static ls_led_diverse_param_t s_ls_production_pass =
{
    .mode = LS_SCENE_SINGLE,
    .node_num = 1,
    .first_node = 0,
    .step_num = 0,
    .times = 0,
    .mode_head = &s_production_pass,
};

// 产测不通过常红
static ls_led_diverse_param_t s_ls_production_fail =
 {
     .mode = LS_SCENE_SINGLE,
     .node_num = 1,
     .first_node = 0,
     .step_num = 0,
     .times = 0,
     .mode_head = &s_production_fail,
 };


/**
* @brief 产测 测试5种led灯珠
*/
 static void ls_production_bp_test_led(void)
{
    APP_LOG(LOG_INFO, "start testing led! \n");
    ls_led_set_led((void*)&s_ls_production_mode, LS_LED_ACT_SRC_PRODUCTION);
}


/**
* @brief 产测状态回调函数
* @param[in]  status          [产测状态码]
*/
static void ls_production_status_cb(PRODUCTION_STATUS_E status)
{
    switch(status)
    {
        case PRODUCTION_START:
            ls_report_set_chg_rsn(STAT_CHG_RSN_PRODUCTION_STR);
            ls_button_task_exit(); // 关闭按键任务
            APP_LOG(LOG_INFO, "production start\n");
            ls_production_bp_test_led();
            break;
        case PRODUCTION_RUNNING:
            APP_LOG(LOG_INFO, "production running\n");
            ls_led_set_led((void*)&s_ls_production_running, LS_LED_ACT_SRC_PRODUCTION);
            break;
        case PRODUCTION_TEST_PASS:
            APP_LOG(LOG_INFO, "production pass\n");
            ls_led_set_led((void*)&s_ls_production_pass, LS_LED_ACT_SRC_PRODUCTION);
            ls_clear_config();
            break;
        case PRODUCTION_TEST_FAIL:
            APP_LOG(LOG_INFO, "production fail\n");
            ls_led_set_led((void*)&s_ls_production_fail, LS_LED_ACT_SRC_PRODUCTION);
            ls_clear_config();
            break;
        default:
            break;
    }
}

/**
* @brief 产测结果回调函数
* @param[in]  err_code          [产测状态码]
*/
static void ls_production_result_cb(PRODUCTION_ERROR_E err_code)
{
    if (PRD_NO_ERR == err_code)
    {
        APP_LOG(LOG_INFO, "production success\n");
    }
    else
    {
        APP_LOG(LOG_INFO, "production error %d\n", err_code);
    }
}

/**
* @brief ledstrip产测功能初始化
*/
void ls_production_init(void)
{
    vesync_production_reg_status_cb(ls_production_status_cb);
    vesync_production_reg_result_cb(ls_production_result_cb);
}

