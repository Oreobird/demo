/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        demo_wifi_led.h
 * @brief       demo Wi-Fi指示灯配置
 * @author      Joshua
 * @date        2021-06-04
 */

#ifndef __DEMO_WIFI_LED_H__
#define __DEMO_WIFI_LED_H__

#ifdef __cplusplus
extern "C" {
#endif

#define DEMO_WIFI_LED_PORT       (17)  // WIFI指示灯为GPIO17

/**
 * @brief  灯效配置
 * @return     int             [成功/失败]
 */
int demo_reg_wifi_led(void);

#ifdef __cplusplus
}
#endif

#endif

