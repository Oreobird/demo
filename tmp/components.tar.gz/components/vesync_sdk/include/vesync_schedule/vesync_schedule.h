/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_schedule.h
 * @brief       Schedule模块接口定义
 * @date        2021-06-22
 */

#ifndef __VESYNC_SCHEDULE_H__
#define __VESYNC_SCHEDULE_H__

#include <stdint.h>
#include <stdbool.h>

#include "vesync_buffer.h"

#ifdef __cplusplus
extern "C"
{
#endif

/**
 * @brief Schedule 结果枚举
 */
typedef enum
{
    SCHE_OK = 0,                 // OK
    SCHE_ERR = -1,               // 一般错误
    SCHE_MEM_ERR = -2,           // 内存出错：malloc失败
    SCHE_BUF_ERR = -3,           // 缓存出错：buffer溢出
    SCHE_CFG_ERR = -4,           // 读取或者写入持久化的Schedule配置信息错误
    SCHE_CFG_NO_EXIST = -5,      // 不存在持久化的Schedule配置
    SCHE_CFLT_ERR = -6,          // Schedule 配置项冲突
    SCHE_ID_EXIST_ERR = -7,      // Schedule ID已经存在
    SCHE_INV_ID_ERR = -8,        // Schedule ID非法或者不存在
    SCHE_NO_INIT = -9,           // Schedule 没有初始化
    SCHE_EXCEED_MAX = -10,       // Schedule 配置项的数量超过了限制
    SCHE_INV_IDX_ERR = -11,      // 非法的查找Index
    SCHE_INV_APP_CFG_SIZE = -12, // APP配置大小超过了限制
    SCHE_INV_CFG_PARAM = -13,    // 非法的Schedule参数
} SCHE_RESULT_E;

/**
 * @brief Schedule 配置类型枚举
 */
typedef enum
{
    SCHE_TMG_EVT = 0, // Schedule定时类型枚举
    SCHE_SUN_EVT = 1, // Schedule日出日落类型枚举
} SCHE_TYPE_E;

/**
 * @brief Schedule 配置项定义
 */
typedef struct
{
    uint32_t id;  // Schedule ID
    bool enabled; // 配置项是否使能
    uint8_t type; // Schedule类型
    union
    {
        struct
        {
            bool is_sunrise;    // 是否是日出触发，否则是日落触发
            int32_t offset_sec; // 日出、日落时间触发偏移，正负决定偏移方向；取值范围：(-86400, 86400)
        } sun;                  // 日出日落事件类型Schedule的配置
        struct
        {
            uint32_t clock_sec; // 定时时钟的秒数；取值范围：[0,86400)
        } timing;               // 定时事件类型Schedule的配置
    } event_config;             // Schedule类型相关事件配置
    uint8_t repeat_config;      // Schedule的重复功能配置
} vesync_schedule_t;

/**
 * @brief Schedule读取配置二进制数据回调
 * @param[out] p_rd_buf      [指向数据读取的Buffer]
 * @param[in]  buf_len       [Buffer的长度]
 * @param[out] p_rd_len      [指向储存读取的长度]
 * @return int               [SCHE_RESULT_E]
 */
typedef int (*sche_rd_cfg_cb_t)(uint8_t *p_rd_buf, uint32_t buf_len, uint32_t *p_rd_len);

/**
 * @brief Schedule写入配置二进制数据回调
 * @param[in]  p_wr_buf      [指向被写入的Buffer]
 * @param[in]  len           [将被写入的数据长度]
 * @return int               [SCHE_RESULT_E]
 */
typedef int (*sche_wr_cfg_cb_t)(uint8_t *p_wr_buf, uint32_t len);

/**
 * @brief Schedule Application任务执行回调
 * @param[in] sch_cfg       [回调给应用层的配置项数据]
 * @param[in] app_cfg       [回调给应用层的APP配置数据]
 * @return int              [SCHE_RESULT_E]
 */
typedef int (*sche_exec_app_task_cb_t)(vesync_schedule_t sch_cfg, vesync_buf_t app_cfg);

/**
 * @brief Schedule 模块初始化参数数据结构定义
 */
typedef struct
{
    sche_wr_cfg_cb_t wr_cfg_cb;               // 底层写配置回调，初始化时置空则注册平台默认函数
    sche_rd_cfg_cb_t rd_cfg_cb;               // 底层读配置回调，初始化时置空则注册平台默认函数
    sche_exec_app_task_cb_t exec_app_task_cb; // APP任务执行回调
    uint32_t max_app_cfg_size;                // APP配置数据大小限制
    uint32_t min_id_limit;                    // 生成ID的最小限制
    uint32_t max_sche_nbr;                    // 最大的Schedule配置项数量
} vesync_schedule_param_t;

/**
 * @brief Schedule 整个模块、管理器的初始化
 * @return int                      [SCHE_RESULT_E]
 */
int vesync_schedule_main_init(void);

/**
 * @brief Schedule 整个模块、管理器的反初始化
 * @return int                      [SCHE_RESULT_E]
 */
int vesync_schedule_main_deinit(void);

/**
 * @brief Schedule 创建一个实例
 * @param[in] handle_id             [实例句柄ID，handle_id需要小于Schedule的最大实例数]
 * @param[in] p_sch_param           [初始化参数]
 * @return int                      [SCHE_RESULT_E]
 */
int vesync_schedule_new_instance(uint32_t handle_id, vesync_schedule_param_t *p_sch_param);

/**
 * @brief Schedule 销毁一个实例
 * @param[in] handle_id             [实例ID]
 * @return int                      [SCHE_RESULT_E]
 */
int vesync_schedule_destroy_instance(uint32_t handle_id);

/**
 * @brief Schedule 添加配置项
 * @param[in] handle_id             [实例句柄ID]
 * @param[in] p_sch_cfg             [指向应添加的Schedule配置项]
 * @param[in] p_app_cfg             [指向应添加的APP配置]
 * @param[in] is_gen_id             [true - 模块自动生成ID； false - 方法调用方指定ID]
 * @return int                      [SCHE_RESULT_E]
 */
int vesync_schedule_add(uint32_t handle_id, vesync_schedule_t *p_sch_cfg, vesync_buf_t *p_app_cfg, bool is_gen_id);

/**
 * @brief Schedule 修改配置项
 * @param[in] handle_id             [实例句柄ID]
 * @param[in] p_sch_cfg             [指向新的Schedule配置项]
 * @param[in] p_app_cfg             [指向新的APP配置]
 * @return  int                     [SCHE_RESULT_E]
 */
int vesync_schedule_upd(uint32_t handle_id, vesync_schedule_t *p_sch_cfg, vesync_buf_t *p_app_cfg);

/**
 * @brief Schedule 删除配置项
 * @param[in] handle_id             [实例句柄ID]
 * @param[in] sch_id                [要删除的Schedule ID]
 * @return int                      [SCHE_RESULT_E]
 */
int vesync_schedule_del(uint32_t handle_id, uint32_t sch_id);

/**
 * @brief Schedule 读取配置项
 * @param[in]  handle_id            [实例句柄ID]
 * @param[in]  sch_id               [要读取的Schedule ID]
 * @param[out] p_sch_cfg            [指向读取Schedule配置项的缓存]
 * @param[out] p_app_cfg            [指向读取APP配置的缓存]
 * @return  int                     [SCHE_RESULT_E]
 */
int vesync_schedule_get_by_id(uint32_t handle_id, uint32_t sch_id, vesync_schedule_t *p_sch_cfg, vesync_buf_t *p_app_cfg);

/**
 * @brief Schedule 获取距下一个schedule的执行时间（一天内）
 * @param[in]  handle_id            [实例句柄ID]
 * @param[out] sec                  [距下个schedule执行的秒数，精度为一分钟]
 * @return  int                     [SCHE_RESULT_E]
 */
int vesync_schedule_get_next_exc_sec(uint32_t handle_id, uint32_t *sec);

/**
 * @brief Schedule 按照顺序读取配置项
 * @param[in]  handle_id            [实例句柄ID]
 * @param[in]  idx                  [需要读取的配置项开始的Schedule序号，注意和Schedule ID不一样]
 * @param[in]  nbr                  [需要读取的最大配置项数量]
 * @param[out] p_total_num          [指向输出配置项总数的缓存]
 * @param[out] p_sch_cfg_list       [指向读取Schedule配置项列表的缓存]
 * @param[out] p_app_cfg_list       [指向读取APP配置列表的缓存]
 * @param[out] p_out_len            [指向输出最终读取到配置项数量的缓存]
 * @return int                      [SCHE_RESULT_E]
 */
int vesync_schedule_get_by_index(uint32_t handle_id, uint32_t idx, uint32_t nbr, uint32_t *p_total_num,
                                 vesync_schedule_t *p_sch_cfg_list, vesync_buf_t *p_app_cfg_list, uint32_t *p_out_len);

/**
 * @brief Schedule 清除所有配置项
 * @param[in] handle_id             [实例句柄ID]
 * @return  int                     [SCHE_RESULT_E]
 */
int vesync_schedule_clear(uint32_t handle_id);

/**
 * @brief Schedule 读取配置项的执行次数
 * @param[in]  handle_id            [实例句柄ID]
 * @param[in]  sch_id               [要读取的Schedule ID]
 * @param[out] p_exec_cnt           [指向输出Schedule配置项执行计数的缓存]
 * @return int                      [SCHE_RESULT_E]
 */
int vesync_schedule_get_exec_cnt(uint32_t handle_id, uint32_t sch_id, uint32_t *p_exec_cnt);

/**
 * @brief Schedule 读取配置项的总数
 * @param[in]  handle_id            [实例句柄ID]
 * @param[out] p_num                [指向输出Schedule配置项总数的缓存]
 * @return int                      [SCHE_RESULT_E]
 */
int vesync_schedule_get_total_num(uint32_t handle_id, uint32_t *p_num);

#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_SCHEDULE_H__ */
