/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_bypass_common.c
 * @brief       bypass处理接口
 * @date        2021-05-14
 */

#include <string.h>
#include <stdio.h>

#include "vhal_utils.h"
#include "vesync_cfg_internal.h"
#include "vesync_common.h"
#include "vesync_device_internal.h"
#include "vesync_log_internal.h"
#include "vesync_bypass_internal.h"
#include "vesync_report_internal.h"
#include "vesync_production_internal.h"

/**
 * @brief "setCid" method数据解析
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  json                     [json数据指针]
 * @return BYPASS_ERR_E                 [错误码]
 */
static BYPASS_ERR_E bypass_method_set_cid(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    BYPASS_ERR_E by_ret = BP_OK;

    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    cJSON *json_data = cJSON_GetObjectItemCaseSensitive(json, "cid");
    if (cJSON_IsString(json_data))
    {
        SDK_LOG(LOG_DEBUG,"bypass_method_set_cid = %s \r\n", json_data->valuestring);

        uint8_t cid[64] = {0};
        uint16_t cid_len = sizeof(cid);

        int rd_ret = vesync_production_get_value_by_key(PRODUCTION_KEY_ID_CID,cid, &cid_len);
        if ((SDK_OK == rd_ret)/*&&(strlen((char*)cid) == CID_STR_LEN)*/)    //cid 已写入
        {
            cJSON *cid_json = cJSON_CreateObject();
            if (cid_json)
            {
                cJSON_AddStringToObject(cid_json, "cid", (char*)cid);
            }
            vesync_bypass_reply_noqos(BP_ERR_CID_EXIST, p_msg_ctx->p_trace_msg, cid_json);
        }
        else
        {
            int  write_ret = vesync_production_set_value_by_key(PRODUCTION_KEY_ID_CID,(uint8_t *)json_data->valuestring,strlen(json_data->valuestring));
            if (0 != write_ret)
            {
                by_ret = BP_ERR_ARG;
            }
            else
            {
                vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, NULL);
            }
        }
    }
    else
    {
        by_ret = BP_ERR_ARG;
    }

    return by_ret;
}

/**
 * @brief "setComplete" method数据解析
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  json                     [json数据指针]
 * @return BYPASS_ERR_E                 [错误码]
 */
static BYPASS_ERR_E bypass_method_set_complete(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    BYPASS_ERR_E ret = BP_OK;

    uint32_t err_code = PRD_NO_ERR;

    cJSON *json_data = cJSON_GetObjectItemCaseSensitive(json, "complete");
    if (cJSON_IsString(json_data))
    {
        if (strncmp(json_data->valuestring, "ok", 2) == 0)
        {
            SDK_LOG(LOG_INFO,"production recv complete!\r\n");
            void* puback_cb = NULL;
            puback_cb = (void*)vesync_production_complete_success_ack_cb;
            vesync_bypass_reply_qos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, NULL, SEND_QOS1, puback_cb);  //使用QOS1应答，确认服务器收到才认为产测成功
        }
        else
        {
            cJSON *json_err = cJSON_GetObjectItemCaseSensitive(json, "err");
            if (cJSON_IsNumber(json_err))
            {
                err_code = json_err->valueint;
                vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, NULL);  // 必须在vesync_production_complete_error(err_code)之前
                vesync_production_complete_error(err_code);
            }
            else
            {
                ret = BP_ERR_ARG;
            }
        }
    }
    else
    {
        ret = BP_ERR_ARG;
    }

    return ret;
}

static bypass_item_data_t production_method_tbl[] = {
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_SET_CID,      "setCid",      bypass_method_set_cid, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_SET_COMPLETE, "setComplete", bypass_method_set_complete, NULL},
};


void vesync_bypass_production_init(void)
{
    for (int i = 0; i < SIZEOF_ARRAY(production_method_tbl); i++)
    {
        bypass_item_t *item = vesync_bypass_init_item(&production_method_tbl[i]);
        if (item != NULL)
        {
            vesync_bypass_add_item(item);
        }
    }
}

