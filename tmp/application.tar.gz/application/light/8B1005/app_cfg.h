/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
* @file         app_cfg.h
* @brief        应用功能配置
* @author       Joshua
* @date         2021-11-23
*/

#include <stdint.h>
#include <stdbool.h>
#include "vesync_common.h"

#ifndef __APP_CFG_H__
#define __APP_CFG_H__

#ifdef __cplusplus
extern "C" {
#endif

// 通用配置
#define LIGHT_NODE_NUM          (1)

// 灯光控制IO配置
#define LIGHT_RED_OUT_IO        (10)        // 红灯输出的IO号（对于BP5758，是芯片IO。对于PWM输出，是SOC的IO）
#define LIGHT_GREEN_OUT_IO      (5)         // 绿灯输出的IO号（对于BP5758，是芯片IO。对于PWM输出，是SOC的IO）
#define LIGHT_BULE_OUT_IO       (4)         // 蓝灯输出的IO号（对于BP5758，是芯片IO。对于PWM输出，是SOC的IO）
#define LIGHT_COLD_OUT_IO       (3)         // 冷白灯(CCT下是亮度PWM)输出的IO号（对于BP5758，是芯片IO。对于PWM输出，是SOC的IO）
#define LIGHT_WARM_OUT_IO       (6)         // 暖白灯(CCT下是色温PWM)输出的IO号（对于BP5758，是芯片IO。对于PWM输出，是SOC的IO）

// 灯光驱动配置
#define LIGHT_WHITE_DRV_TYPE    (1)         // 白光驱动方式：0-i2c，1-pwm，2-rmt
#define LIGHT_COLOR_DRV_TYPE    (1)         // 彩光驱动方式：0-i2c，1-pwm，2-rmt

// PWM驱动参数
#define PWM_CW_CH               (LED_CH0)   // 冷光的led通道
#define PWM_WW_CH               (LED_CH1)   // 暖光的led通道
#define PWM_R_CH                (LED_CH2)   // 红光的led通道
#define PWM_G_CH                (LED_CH3)   // 绿光的led通道
#define PWM_B_CH                (LED_CH4)   // 蓝光的led通道
#define PWM_CH_NUM              (5)         // 配置的led数量
#define LIGHT_LEDC_DUTY_RST_BIT (13)        // LEDC 占空比分辨率设置（10位对应1024）
#define LIGHT_LEDC_PWM_FREQ     (5000)      // LEDC PWM控制频率
#define LIGHT_WHITE_CW          (1)

// 灯光参数量程配置
#define LIGHT_W_MIN_PERCENT     (1)         // 白光模式的实际最小亮度百分数，这个数值是为了防止设置最低亮度出现近似关断的情况
#define LIGHT_W_MAX_PERCENT     (100)       // 白光模式的实际最小亮度百分数，这个数值是为了防止设置最低亮度出现近似关断的情况
#define LIGHT_RGB_MIN_PERCENT   (5)         // 彩光模式的实际最小明度百分数，这个数值是为了防止灯泡在超低电流下出现偏色做的限制
#define LIGHT_COLOR_TEMP_MAX    (100)       // 色温值上限
#define LIGHT_PWM_MAX_SCALE     (256)       // PWM数字输出最大量程，十位分辨率

// 设备配置默认初值
#define LIGHT_DEFAULT_H          (6666)      // 默认hue值
#define LIGHT_DEFAULT_S          (10000)     // 默认saturation值
#define LIGHT_DEFAULT_V          (100)       // 默认value值
#define LIGHT_DEFAULT_BRIGHTNESS (50)        // 默认brightness值
#define LIGHT_DEFAULT_COLOR_TEMP (100)       // 默认colorTemp值

// 存储配置
#define APP_USER_CFG_KEY_DATA   "8B1005"    // 配置标识符
#define APP_FLASH_DATA_LEN      (60)        // 写flash数据预分配长度
#define APP_FLASH_CFG_VERSION   (1)         // 配置版本

// 按键配置
#define APP_BUTTON_NUM          (1)
#define APP_BUTTON0_CFG         {7, 0, 3, 1},  // {GPIO, 使能电平, 短按功能类型(BTN_SHORT_PRESS_TYPE_E), 长按功能类型(BTN_LONG_PRESS_TYPE_E)}


#ifdef __cplusplus
}
#endif

#endif



