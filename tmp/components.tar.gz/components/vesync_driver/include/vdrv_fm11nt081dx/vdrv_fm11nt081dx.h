/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
 * @file        vdrv_fm11nt081dx.h
 * @brief       复旦FM11NT081Dx芯片驱动接口
 * @date        2021-11-15
 */

#ifndef __VDRV_FM11NT081DX_H__
#define __VDRV_FM11NT081DX_H__

#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C"
{
#endif

/**
 * @brief NFC卡密码认证错误次数上限，超过上限后卡片不能再被无线端读写
*/
typedef enum
{
    NO_LIMIT = 0, //无上限
    LIMIT_ONCE = 1,
    LIMIT_TWO = 2,
    LIMIT_THREE = 3,
    LIMIT_FOUR = 4,
    LIMIT_FIVE = 5,
    LIMIT_SIX = 6,
    LIMIT_SEVEN = 7
} AUTH_ERROR_CNT_E;

/**
 * @brief NFC 卡通信产生中断信号模式
*/
typedef enum
{
    MODE_NONE_WAKEUP = 0, //无唤醒功能
    MODE_SOF = 1,         //收到第一帧RFID数据时产生中断信号
    MODE_SELECT_CHIP = 2, //TAG选中时产生中断信号
    MODE_ENTER_FEILD = 3  //进场时产生中断信号
} WAKEUP_MODE_E;

/**
 * @brief NFC 卡休眠/唤醒功能配置参数定义
 */
typedef enum
{
    OP_FUNC_NONE = 0,   //休眠唤醒功能均不使能
    OP_FUNC_SLEEP = 1,  //休眠功能使能
    OP_FUNC_WAKEUP = 2, //唤醒功能使能
    OP_FUNC_MAX
} VDRV_NT081D_OP_FUNC;

/**
 * @brief NFC 卡工作状态定义 
 */
typedef enum
{
    STATUS_SLEEP,  //休眠中
    STATUS_MCU_WR, //MCU端读写中
    STATUS_RF_WR   //RF端读写中
} NFC_WORK_STATUS_E;

/**
 * @brief fm11nc081dx芯片初始化
 * @param[in] sda_io        [sda输入引脚]
 * @param[in] scl_io        [scl输入引脚]
 * @param[in] cs_pin        [iic片选引脚]
 * @return uint32_t         [成功：SDK_OK，失败：SDK_FAIL]
 */
uint32_t vdrv_fm11nt081dx_init(uint8_t sda_io, uint8_t scl_io, uint8_t cs_pin);

/**
 * @brief 设置芯片无线端读写时认证密码,以及密码认证过程手机密码正确时NFC卡回发的PACK码
 * @param[in]   pwd_en      [密码功能是否使能]
 * @param[in]   pwd         [4byte的密码值]
 * @param[in]   psw_ack     [2byte的ACK值]
 * @return uint32_t         [成功：SDK_OK，失败：SDK_FAIL]
 */
uint32_t vdrv_fm11nt081dx_set_auth_pwd(bool pwd_en, uint32_t pwd, uint16_t pwd_ack);

/**
 * @brief 设置锁住NFC卡认证密码以及PACK码，锁定后无法修改密码及PACK值
 * @param[in]   enable       [1 锁住密码参数，0解除锁定]
 * @return uint32_t          [成功：SDK_OK，失败：SDK_FAIL]
 */
uint32_t vdrv_fm11nt081dx_lock_pwd(bool enable);

/**
 * @brief 设置密码保护EE等级
 * @param[in]   level        [密码保护等级，0仅写EE需要密码认证，1读写EE都需要密码认证]
 * @return uint32_t          [成功：SDK_OK，失败：SDK_FAIL]
 */
uint32_t vdrv_fm11nt081dx_set_auth_level(uint8_t level);

/**
 * @brief 设置密码验证错误次数上限
 * @note ，当错误次数超过上限，NFC卡再也不允许无线端进行读写，即使后面写了正确密码
 * @param[in]   auth_limit   [密码允许出错次数，0:无上限,1~7:密码允许出错次数]
 * @return uint32_t          [成功：SDK_OK，失败：SDK_FAIL]
 */
uint32_t vdrv_fm11nt081dx_set_auth_error_cnt(AUTH_ERROR_CNT_E auth_limit);

/**
* @brief 设置芯片唤醒功能是否使能，此功能依赖外部硬件电路，唤醒与休眠功能不能同时使用
* @param[in]  enable        [唤醒功能是否使能，0禁止，1使能]
* @return uint32_t          [成功：SDK_OK，失败：SDK_FAIL]
*/
uint32_t vdrv_fm11nt081dx_set_wakeup(bool enable);

/**
 * @brief 注册NFC无线端唤醒中断回调函数注册
 * @param[in]   rf_wake_up_cb    [NFC卡无线端进场中断回调]
 * @param[in]   int_pin_num      [中断pin脚] 
 * @return uint32_t              [成功：SDK_OK，失败：SDK_FAIL]
 */
uint32_t vdrv_fm11nt081dx_register_wake_cb(void (*wake_up_cb)(uint8_t), uint8_t int_pin_num);

/**
* @brief 初始化芯片休眠功能是否使能
* @param[in]  sleep_enable  [休眠是否使能]
* @param[in]  pin_num       [休眠功能使用引脚]
* @return uint32_t          [成功：SDK_OK，失败：SDK_FAIL]
*/
uint32_t vdrv_fm11nt081dx_init_sleep(bool sleep_enable, uint32_t pin_num);

/**
* @brief 设置芯片无线端休眠
* @param[in]  sleepe        [休眠/不休眠]
* @return uint32_t          [成功：SDK_OK，失败：SDK_FAIL]
*/
uint32_t vdrv_fm11nt081dx_set_sleep(bool sleep);

/**
 * @brief 设置唤醒功能唤醒信号产生时机
 * @param[in]   mode        [NFC 卡通信产生中断信号模式]
 * @return uint32_t         [成功：SDK_OK，失败：SDK_FAIL]
 */
uint32_t vdrv_fm11nt081dx_set_wake_mode(uint8_t mode);

/**
 * @brief 向NFC卡写数据
 * @param[in]  addr     [要写数据的EE地址]
 * @param[in]  buf      [数据缓存]
 * @param[in]  len      [数据长度]
 * @return uint32_t     [成功：SDK_OK，失败：SDK_FAIL]
 */
uint32_t vdrv_fm11nt081dx_write_data(uint16_t addr, uint8_t *buf, uint16_t len);

/**
 * @brief 从NFC卡读数据
 * @param[in]  addr     [要读数据的EE地址]
 * @param[in]  buf      [数据缓存]
 * @param[in]  len      [要读的长度]
 * @return uint32_t     [成功：SDK_OK，失败：SDK_FAIL]
 */
uint32_t vdrv_fm11nt081dx_read_data(uint16_t addr, uint8_t *buf, uint16_t len);

/**
 * @brief 获取NFC卡的UID
 * @param[in]  uid      [uid缓存buffer]
 * @param[in]  len      [buf长度，长度不能小于9]
 * @return uint32_t     [成功：SDK_OK，失败：SDK_FAIL]
 */
uint32_t vdrv_fm11nt081dx_get_uid(uint8_t *uid, uint8_t len);

/**
 * @brief 禁止NFC卡片RF无线端通信
 * @param[in]  if_disable      [是否禁止无线端通信，1禁止，0允许]
 * @return uint32_t            [成功：SDK_OK，失败：SDK_FAIL]
 */
uint32_t vdrv_fm11nt081dx_disable_rfid(bool if_disable);

#ifdef __cplusplus
}
#endif

#endif /*__VDRV_FM11NT081DX_H__ */
