/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_ffs_crypto.c
 * @brief       ffs 秘钥解析处理
 * @author      Owen.zhang
 * @date        2012-04-22
 */
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <mbedtls/sha256.h>
#include "mbedtls/md.h"
#include "mbedtls/ecdh.h"
#include "mbedtls/entropy.h"
#include "mbedtls/ctr_drbg.h"
#include "mbedtls/ecdsa.h"
#include "mbedtls/platform.h"
#include "mbedtls/x509_crt.h"
#include "mbedtls/pk.h"
#include "mbedtls/ecp.h"
#include "vesync_common.h"
#include "vesync_memory.h"
#include "vesync_log_internal.h"
#include "vesync_ffs_crypto.h"
#include "mbedtls/base64.h"
#include "ffs_pem_file.h"
#include "vhal_utils.h"

/**
 * @brief print the hex data in the special buff .
 * @param input :headline
 * @param input :buff
 * @param len
 * @return void
 */
void vesync_ffs_dump_buf(char *info, uint8_t *buf, uint32_t len)
{
    if (!info || !buf)
    {
        return;
    }
    FFS_CA_PRINTF("%s", info);
    for (int i = 0; i < len; i++)
    {
        FFS_CA_PRINTF("%s%02x%s", i % 16 == 0 ? "\n     " : " ", buf[i], i == len - 1 ? "\n" : "");
    }
}

/**
 * @brief random function for ECDH
 * @param rng_state: none use
 * @param output : the string make of radom data
 * @param len : the string's len
 * @return 0
 */
int vesync_ffs_rand(void *rng_state, unsigned char *output, size_t len)
{
    if (rng_state != NULL)
    {
        rng_state = NULL;
    }

    if (output)
    {
        vhal_utils_get_random(output, (uint32_t)len);
    }
    return (0);
}

/**
 * @brief Extracts device Public key with ext info from a pem chain file .
 * @param output:keyValue with ext info
 * @param input :KeyPem
 * @return void
 */
void parsePublicKeyExtToHex(FfsKeyContext_t *keyValue, const char *KeyPem)
{

    mbedtls_x509_crt crt;
    size_t len;
    uint16_t total_len;
    if (!keyValue || !KeyPem)
    {
        return;
    }

    mbedtls_x509_crt_init(&crt);

    //printf("parsePublicKey: %d\n %s \n",strlen(KeyPem),KeyPem);
    VESYNC_ASSERT(mbedtls_x509_crt_parse(&crt, (uint8_t *)KeyPem, strlen(KeyPem) + 1));

    uint16_t buff_len = (uint16_t)(crt.tbs.len - crt.issuer_raw.len - crt.serial.len - crt.sig_oid.len - sizeof(int) - sizeof(crt.valid_from) - sizeof(crt.valid_to));
    FFS_CA_PRINTF("  . buff_len = %d\n", buff_len);
    if (!buff_len)
    {
        goto exit;
    }

    unsigned char *p = crt.subject_raw.p;
    unsigned char *result = NULL;
    VESYNC_ASSERT(mbedtls_asn1_get_tag(&p, p + buff_len, &len, MBEDTLS_ASN1_CONSTRUCTED | MBEDTLS_ASN1_SEQUENCE));

    buff_len -= len;

    if (!len)
    {
        goto exit;
    }

    VESYNC_ASSERT(mbedtls_x509_get_name(&p, p + len, &crt.subject));

    //起始地址
    result = p;

    //数据长度
    VESYNC_ASSERT(mbedtls_asn1_get_tag(&p, p + buff_len, &len, MBEDTLS_ASN1_CONSTRUCTED | MBEDTLS_ASN1_SEQUENCE));
    total_len = p - result;
    total_len += len;
    FFS_CA_PRINTF("  . total_len = %d\n", total_len);
    //拷贝公钥信息
    if (result)
    {
        uint8_t *buffer = (uint8_t *)vesync_malloc(sizeof(uint8_t) * total_len + 1);
        if (buffer)
        {
            keyValue->buf = buffer;
            memcpy(keyValue->buf, result, total_len);
            keyValue->len = total_len;
        }

        vesync_ffs_dump_buf("  + PublicExtKey:", (uint8_t *)keyValue->buf, total_len);
    }
exit:
    mbedtls_x509_crt_free(&crt);
}

/**
 * @brief Extracts device Public key from a pem chain file .
 * @param output:keyValue without ext info
 * @param input :KeyPem
 * @return void
 */
void parsePublicKeyToHex(FfsKeyContext_t *keyValue, const char *KeyPem)
{
    if (!keyValue || !KeyPem)
    {
        return;
    }
    mbedtls_x509_crt crt;
    mbedtls_ecp_keypair *pecpKey;
    uint8_t puk_buf[100] = {0};
    mbedtls_x509_crt_init(&crt);

    //printf("parsePublicKey: %d\n %s \n",strlen(KeyPem),KeyPem);
    VESYNC_ASSERT(mbedtls_x509_crt_parse(&crt, (uint8_t *)KeyPem, strlen(KeyPem) + 1));

    //解析钥匙
    pecpKey = mbedtls_pk_ec(crt.pk);
    if (pecpKey)
    {
        size_t rlen = mbedtls_mpi_size(&pecpKey->Q.X);
        puk_buf[0] = 0x04;

        VESYNC_ASSERT(mbedtls_mpi_write_binary(&pecpKey->Q.X, puk_buf + 1, rlen));
        VESYNC_ASSERT(mbedtls_mpi_write_binary(&pecpKey->Q.Y, puk_buf + rlen + 1, rlen));
        rlen <<= 1;
        rlen += 1;
        FFS_CA_PRINTF("  . keys len = %d\n", rlen);
        uint8_t *buffer = (uint8_t *)vesync_malloc(sizeof(uint8_t) * rlen + 1);
        if (buffer)
        {
            keyValue->buf = buffer;
            memcpy(keyValue->buf, puk_buf, rlen);
            keyValue->len = rlen;
        }

        vesync_ffs_dump_buf("  + PublicKey:", (uint8_t *)keyValue->buf, rlen);
    }
exit:
    mbedtls_x509_crt_free(&crt);
}

/**
 * @brief Extracts device  Public key from a pem file.
 * @param output:keyValue
 * @param input :KeyPem
 * @return void
 */
void parseCloudPublicKeyToHex(FfsKeyContext_t *keyValue, const char *KeyPem)
{
    if (!keyValue || !KeyPem)
    {
        return;
    }
    mbedtls_pk_context pk_ctx;
    mbedtls_ecp_keypair *pecpKey;
    uint8_t puk_buf[100] = {0};
    mbedtls_pk_init(&pk_ctx);
    VESYNC_ASSERT(mbedtls_pk_parse_public_key(&pk_ctx, (const unsigned char *)KeyPem, strlen(KeyPem) + 1));
    //解析钥匙
    pecpKey = mbedtls_pk_ec(pk_ctx);
    if (pecpKey)
    {
        size_t rlen = mbedtls_mpi_size(&pecpKey->Q.X);
        puk_buf[0] = 0x04;

        VESYNC_ASSERT(mbedtls_mpi_write_binary(&pecpKey->Q.X, puk_buf + 1, rlen));
        VESYNC_ASSERT(mbedtls_mpi_write_binary(&pecpKey->Q.Y, puk_buf + rlen + 1, rlen));
        rlen <<= 1;
        rlen += 1;
        FFS_CA_PRINTF("  . keys len = %d\n", rlen);
        uint8_t *buffer = (uint8_t *)vesync_malloc(sizeof(uint8_t) * rlen + 1);
        if (buffer)
        {
            keyValue->buf = buffer;
            memcpy(keyValue->buf, puk_buf, rlen);
            keyValue->len = rlen;
        }

        vesync_ffs_dump_buf("  + CloudPublicKey:", (uint8_t *)keyValue->buf, rlen);
    }
exit:
    mbedtls_pk_free(&pk_ctx);
}

/**
 * @brief Extracts device Private key from a pem file.
 * @param output:keyValue
 * @param input :KeyPem
 * @return void
 */
void parsePrivateKeyToHex(FfsKeyContext_t *keyValue, const char *KeyPem)
{
    if (!keyValue || !KeyPem)
    {
        return;
    }
    mbedtls_pk_context pk_ctx;
    mbedtls_ecp_keypair *pecpKey;
    uint8_t puk_buf[100] = {0};
    mbedtls_pk_init(&pk_ctx);
    VESYNC_ASSERT(mbedtls_pk_parse_key(&pk_ctx, (const unsigned char *)KeyPem, strlen(KeyPem) + 1, NULL, 0));

    pecpKey = mbedtls_pk_ec(pk_ctx);
    if (pecpKey)
    {
        size_t rlen = mbedtls_mpi_size(&pecpKey->d);
        VESYNC_ASSERT(mbedtls_mpi_write_binary(&pecpKey->d, puk_buf, rlen));
        FFS_CA_PRINTF("  . keys len = %d\n", rlen);
        uint8_t *buffer = (uint8_t *)vesync_malloc(sizeof(uint8_t) * rlen + 1);
        if (buffer)
        {
            keyValue->buf = buffer;
            memcpy(keyValue->buf, puk_buf, rlen);
            keyValue->len = rlen;
        }
        vesync_ffs_dump_buf("  + PrivateKey:", (uint8_t *)keyValue->buf, rlen);
    }
exit:
    mbedtls_pk_free(&pk_ctx);
}

/**
 * @brief load public key for ECDH
 * @param ecp: keypair
 * @param input : public key
 * @param len : the public len
 * @return 0 or -1
 */
int vesync_ffs_load_public_key(int grp_id, mbedtls_ecp_keypair *ecp, unsigned char *publicKey, char len)
{

    if (!ecp || !publicKey)
    {
        return -1;
    }
    int result = -1;
    vesync_ffs_dump_buf("  + PublicKey:", publicKey, len);
    VESYNC_ASSERT(mbedtls_ecp_group_load(&ecp->grp, grp_id));
    VESYNC_ASSERT(mbedtls_ecp_point_read_binary(&ecp->grp, &ecp->Q, publicKey, len));
    VESYNC_ASSERT(mbedtls_ecp_check_pubkey(&ecp->grp, &ecp->Q));
    result = 0;
exit:
    return (result);
}

/**
 * @brief load private key for ECDH
 * @param ecp: keypair
 * @param input : private key
 * @param len : the private_key len
 * @return 0 or -1
 */
int vesync_ffs_load_private_key(int grp_id, mbedtls_ecp_keypair *ecp, unsigned char *privateKey, char len)
{
    if (!ecp || !privateKey)
    {
        return -1;
    }
    int result = -1;
    vesync_ffs_dump_buf("  + PrivateKey:", privateKey, len);
    VESYNC_ASSERT(mbedtls_ecp_group_load(&ecp->grp, grp_id));
    VESYNC_ASSERT(mbedtls_mpi_read_binary(&ecp->d, privateKey, len));
    VESYNC_ASSERT(mbedtls_ecp_check_privkey(&ecp->grp, &ecp->d));
    /* Calculate the public key from the private key. */
    VESYNC_ASSERT(mbedtls_ecp_mul(&ecp->grp, &ecp->Q, &ecp->d, &ecp->grp.G, vesync_ffs_rand, NULL));
    result = 0;
exit:
    return (result);
}

/**
 * @brief compute ECDH key
 * @param input : privateKey
 * @param input : publicKey
 * @param output: secretKey
 * @return 0 or -1
 */
int vesync_ffs_compute_ecdh_key(FfsKeyContext_t *privateKey, FfsKeyContext_t *publicKey, FfsKeyContext_t *secretKey)
{
    if (!publicKey || !privateKey || !secretKey)
    {
        return -1;
    }

    int result = -1;
    mbedtls_ecdh_context ecdh;
    mbedtls_ecp_keypair private_keypair;
    mbedtls_ecp_keypair public_keypair;
    size_t shared_secret_length = 0;

    mbedtls_ecdh_init(&ecdh);
    mbedtls_ecp_keypair_init(&private_keypair);
    mbedtls_ecp_keypair_init(&public_keypair);
    memset(secretKey->buf, 0, sizeof(secretKey->len));

    VESYNC_ASSERT(mbedtls_ecp_group_load(&ecdh.grp, MBEDTLS_ECP_DP_SECP256R1));

    VESYNC_ASSERT(vesync_ffs_load_private_key(MBEDTLS_ECP_DP_SECP256R1,
                                              &private_keypair,
                                              privateKey->buf,
                                              privateKey->len));

    VESYNC_ASSERT(vesync_ffs_load_public_key(MBEDTLS_ECP_DP_SECP256R1,
                                             &public_keypair,
                                             publicKey->buf,
                                             publicKey->len));

    VESYNC_ASSERT(mbedtls_ecdh_get_params(&ecdh,
                                          &public_keypair,
                                          MBEDTLS_ECDH_THEIRS));
    VESYNC_ASSERT(mbedtls_ecdh_get_params(&ecdh,
                                          &private_keypair,
                                          MBEDTLS_ECDH_OURS));
    /* Perform the ECDH calculation. */
    VESYNC_ASSERT(mbedtls_ecdh_calc_secret(&ecdh,
                                           &shared_secret_length,
                                           secretKey->buf,
                                           secretKey->len,
                                           vesync_ffs_rand, NULL));
    FFS_CA_PRINTF("  . shared_secret_length = %d , %d\n", shared_secret_length, secretKey->len);
    secretKey->len = shared_secret_length;
    vesync_ffs_dump_buf("  + secret_buf:", secretKey->buf, shared_secret_length);
    result = 0;
exit:
    mbedtls_ecdh_free(&ecdh);
    mbedtls_ecp_keypair_free(&private_keypair);
    mbedtls_ecp_keypair_free(&public_keypair);
    return result;
}

/**
 * @brief compute signatrue from sessionTok
 * @param input : privateKey
 * @param input : publicKey
 * @param input : sessionToken
 * @param output: buf
 *
 * @return len of buf
 */
int vesync_ffs_sign_from_sessionToken(FfsKeyContext_t *privateKey, FfsKeyContext_t *publicKey, char *sessionToken, unsigned char *buf)
{
    if (!publicKey || !privateKey || !sessionToken || !buf)
    {
        return -1;
    }
    mbedtls_ecdsa_context ctx_sign;
    mbedtls_ecp_keypair private_keypair;
    mbedtls_ecp_keypair public_keypair;
    unsigned char hash[SHA256_DIGEST_LENGTH + 2];
    unsigned char sig[MBEDTLS_ECDSA_MAX_LEN];
    size_t sig_len;
    size_t len = 0;
    FFS_CA_PRINTF("  sig buf max : %d\n", sizeof(sig));
    mbedtls_ecdsa_init(&ctx_sign); /*初始化ecdsa sign结构体*/
    mbedtls_ecp_keypair_init(&private_keypair);
    mbedtls_ecp_keypair_init(&public_keypair);

    memset(sig, 0, sizeof(sig));
    memset(hash, 0, sizeof(hash));

    FFS_CA_PRINTF("  . Generating key pair...\n");
    VESYNC_ASSERT(mbedtls_ecp_group_load(&ctx_sign.grp, MBEDTLS_ECP_DP_SECP256R1));

    VESYNC_ASSERT(vesync_ffs_load_private_key(MBEDTLS_ECP_DP_SECP256R1,
                                              &private_keypair,
                                              privateKey->buf,
                                              privateKey->len));

    VESYNC_ASSERT(mbedtls_mpi_copy(&ctx_sign.d, &private_keypair.d));

    VESYNC_ASSERT(vesync_ffs_load_public_key(MBEDTLS_ECP_DP_SECP256R1,
                                             &public_keypair,
                                             publicKey->buf,
                                             publicKey->len));
    VESYNC_ASSERT(mbedtls_ecp_copy(&ctx_sign.Q, &public_keypair.Q));
    //  /*计算数据的hash值*/
    VESYNC_ASSERT(mbedtls_sha256_ret((uint8_t *)sessionToken, strlen(sessionToken), hash, 0));

    vesync_ffs_dump_buf("  + Hash: ", hash, sizeof(hash));

    /*
     * Sign message hash
     */
    FFS_CA_PRINTF("  . Signing message hash...\n");

    /*生成签名*/
    VESYNC_ASSERT(mbedtls_ecdsa_write_signature(&ctx_sign, MBEDTLS_MD_SHA256,
                                                hash, sizeof(hash),
                                                sig, &sig_len,
                                                vesync_ffs_rand, NULL));

    FFS_CA_PRINTF("  ok (signature length = %u)\n", (unsigned int)sig_len);

    /*dump签名数据的信息*/
    vesync_ffs_dump_buf("  + Signature: ", sig, sig_len);

    //encode as base64
    size_t olen = 0;
    unsigned char base64_buffer[BASE64_DIGEST_LENGTH + 2];
    memset(base64_buffer, 0, sizeof(base64_buffer));
    VESYNC_ASSERT(mbedtls_base64_encode(base64_buffer, sizeof(base64_buffer), &olen, sig, sig_len));
    FFS_CA_PRINTF("  ok (base64 length = %u)\n  base64 string: %s\n", (unsigned int)olen, base64_buffer);
    if (olen)
    {
        memcpy(buf, base64_buffer, olen);
    }

    len = olen;

exit:
    mbedtls_ecdsa_free(&ctx_sign);
    mbedtls_ecp_keypair_free(&private_keypair);
    mbedtls_ecp_keypair_free(&public_keypair);
    return len;
}
