/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_timebase.h
 * @brief       Timebase模块接口定义
 * @date        2021-08-18
 */

#ifndef __VESYNC_TIMEBASE_H__
#define __VESYNC_TIMEBASE_H__

#include <stdint.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C"
{
#endif

/**
 * @brief Timebase结果枚举
 */
typedef enum
{
    TMBS_OK = 0,            // OK
    TMBS_ERR = -1,          // 一般错误
    TMBS_MEM_ERR = -2,      // 内存出错：malloc失败
    TMBS_BUF_ERR = -3,      // 缓存出错：buffer溢出
    TMBS_CFG_ERR = -4,      // 读取或者写入持久化的Timebase配置信息错误
    TMBS_CFG_NO_EXIST = -5, // 不存在持久化的Timebase配置
    TMBS_NO_INIT = -9,      // Timebase没有初始化
    TMBS_INV_UTC = -10,     // 不合法的UTC数值
    TMBS_UNAVBL = -11,      // Timebase信息未和服务器同步
} TMBS_RESULT_E;

/**
 * @brief Timebase时基信息类型定义
 */
typedef enum
{
    TMBS_NONE = -1,         // 非法值
    TMBS_ALL = 0,           // 包括时区、日出日落时间和冬夏令时
    TMBS_TZ = 1,            // 当地时区类型
    TMBS_SUNTIME = 2,       // 日出日落时间类型
    TMBS_DST = 3,           // 冬夏令时类型
} TMBS_INFO_TYPE_E;

/**
 * @brief Timebase时间信息
 */
typedef struct
{
    uint32_t local_ts;      // 当地时间戳，以秒计数
    uint32_t local_clk_sec; // 当地时刻值，从当天0点计起的累计秒数
    bool is_sunrise_valid;  // 日出时间是否合法
    uint32_t sunrise_clk;   // 日出时刻值
    bool is_sunset_valid;   // 日落时间是否合法
    uint32_t sunset_clk;    // 日落时刻值
} timebase_info_t;

/**
 * @brief Timebase信息更新通知回调类型
 * @param[in] info_upd_type [回调的时基信息更新类型]
 */
typedef void (*timebase_info_upd_ntf_cb_t)(TMBS_INFO_TYPE_E info_upd_type);

/**
 * @brief Timebase获取当前的时基信息
 * @param[out] p_tb_info    [指向传出的Timebase Info缓存]
 * @return int              [TMBS_RESULT_E]
 */
int vesync_timebase_get_cur_info(timebase_info_t *p_tb_info);

/**
 * @brief Timebase注册时基信息更新的通知回调
 * @note 请不要在该回调中做阻塞操作
 * @param[in] cb            [应注册回调函数]
 */
void vesync_timebase_reg_info_upd_cb(timebase_info_upd_ntf_cb_t cb);

#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_TIMEBASE_H__ */