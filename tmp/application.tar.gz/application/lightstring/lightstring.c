/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file    lightstring.c
* @brief   灯串应用层
* @author  Lind
* @date     2021-12-13
*/
#include <stdio.h>

#include "vesync_init.h"
#include "vesync_common.h"
#include "vesync_log.h"
#include "vesync_queue.h"
#include "vesync_flash.h"
#include "vesync_production.h"
#include "vesync_netcfg.h"
#include "vesync_wifi_led.h"
#include "vesync_timer.h"

#include "vhal_led.h"
#include "vhal_gpio.h"

#include "lightstring.h"
#include "lightstring_led.h"
#include "lightstring_board.h"
#include "lightstring_flash.h"
#include "lightstring_report.h"
#include "lightstring_timing.h"
#include "lightstring_button.h"
#include "lightstring_device.h"
#include "lightstring_bypass.h"
#include "lightstring_schedule.h"
#include "lightstring_wifi_led.h"
#include "lightstring_production.h"
#include "lightstring_ir.h"

// 应用层事件队列消息
static vesync_queue_t *s_event_queue = NULL;

// 灯串状态记录
static ls_status_t s_ls_status;
static uint64_t s_sys_start_ts = 0;
static vesync_timer_t *s_timer = NULL;
static bool s_timer_ls_status = true; // 定时器控制的灯串状态
static uint8_t s_timer_hour_cnt = 0;  // 遥控定时器计时

/**
* @brief SDK层初始化前回调函数
*/
static void ls_pre_cb(void)
{
    APP_LOG(LOG_DEBUG, " pre init callback\n");
}

/**
* @brief 手动进产测功能
*/
static void ls_manual_production(void)
{
    static uint8_t button_cnt = 0;
    uint64_t btn_ts[5];
    uint64_t new_ts = vesync_task_get_tick_ms();
    btn_ts[button_cnt % 5] = new_ts;
    button_cnt++;
    if (button_cnt >= 5 && (new_ts - btn_ts[(button_cnt - 5) % 5]) < 2000) // 2s内按5下
    {
        APP_LOG(LOG_INFO, "enter production test mode !!\n");
        vesync_production_enter_testmode(true);
    }
}

/**
* @brief    遥控定时器回调，1h轮询一次
* @param[in]  *arg          [定时器类型]
*/
static void ls_timer_cb(void *arg)
{
    static LS_TIMER_E cur_mode = LS_TIMER_OFF;
    LS_TIMER_E *mode = (LS_TIMER_E*)arg;
    if (*mode != cur_mode)
    {
        s_timer_hour_cnt = 0;
        cur_mode = *mode;
    }

    ls_ev_t ev;
    memset(&ev, 0, sizeof(ls_ev_t));
    ev.act_src = LS_ACT_SRC_DEVICE;
    s_timer_hour_cnt = (s_timer_hour_cnt + 1 ) % 24; // 24h循环
    APP_LOG(LOG_INFO, "timer hour s_timer_hour_cnt %d \n", s_timer_hour_cnt);
    if (cur_mode == LS_TIMER_6 && (s_timer_hour_cnt == 6 || s_timer_hour_cnt == 0))
    {
        ev.id = (s_timer_hour_cnt == 6 ? LS_EV_OFF : LS_EV_ON);
    }
    else if (cur_mode == LS_TIMER_8 && (s_timer_hour_cnt == 8 || s_timer_hour_cnt == 0))
    {
        ev.id = (s_timer_hour_cnt == 8 ? LS_EV_OFF : LS_EV_ON);
    }
    else if (cur_mode == LS_TIMER_6639 && (s_timer_hour_cnt == 6 || s_timer_hour_cnt == 12 || s_timer_hour_cnt == 15 || s_timer_hour_cnt == 0))
    {
        ev.id = ((s_timer_hour_cnt == 6 || s_timer_hour_cnt == 15) ? LS_EV_OFF : LS_EV_ON);
    }
    else
    {
        return;
    }

    if (ev.id == LS_EV_OFF)
    {
        s_timer_ls_status = false;
    }
    else
    {
        s_timer_ls_status = true;
    }

    ls_app_task_notify(&ev);
    ls_report_set_chg_rsn(STAT_CHG_RSN_BTN_STR);
}

/**
* @brief 遥控定时器处理
* @param[in]  type      [定时器类型]
*/
static void ls_timer_process(LS_TIMER_E type)
{
    if (LS_TIMER_OFF == type)
    {
        s_timer_ls_status = true;
        s_timer_hour_cnt = 0;
        vhal_gpio_set_output(LS_WIFI_LED_IO, VHAL_GPIO_DATA_LOW);
        if(NULL != s_timer)
        {
            vesync_timer_free(s_timer);
            s_timer = NULL;
        }
    }
    else
    {
        vhal_gpio_set_output(LS_WIFI_LED_IO, VHAL_GPIO_DATA_HIGH);
        s_ls_status.timer_mode = type;
        if (NULL == s_timer)
        {
            s_timer = vesync_timer_new("ls_timer", ls_timer_cb, (void*)&s_ls_status.timer_mode, VCOM_SECOND_PER_HR * 1000, true);
            if (s_timer == NULL)
            {
                APP_LOG(LOG_ERROR, "Create ir timer failed\n");
                s_ls_status.timer_mode = LS_TIMER_OFF;
                vhal_gpio_set_output(LS_WIFI_LED_IO, VHAL_GPIO_DATA_LOW);
                return;
            }

            vesync_timer_start(s_timer);
        }
        else
        {
            vesync_timer_change_priod(s_timer, VCOM_SECOND_PER_HR * 1000);
        }
    }
}

/**
 * @brief  app任务事件处理
 * @param[in]    ev     [主任务事件结构体]
 */
static void app_event_handle(ls_ev_t ev)
{
    APP_LOG(LOG_DEBUG, "ev id %d src %d\n", ev.id, ev.act_src);
    ls_led_ev_t led_ev;
    memset(&led_ev, 0,sizeof(ls_led_ev_t));
    switch (ev.id)
    {
        case LS_EV_RESET:
            vesync_device_factory_reset(true, STAT_CHG_RSN_BTN_STR);
            break;
        case LS_EV_BEFORE_NETCFG:
            s_ls_status.timer_mode = LS_TIMER_OFF;
            ls_timer_process(s_ls_status.timer_mode);
            vesync_wifi_led_set_behavior(WIFI_LED_NOT_CONFIG);
            ls_save_config(s_ls_status);
            break;
        case LS_EV_NETCFG:
            APP_LOG(LOG_INFO, "start netcfg\n");
            vesync_netcfg_restart();
            break;
        case LS_EV_PRODUCTION:
            led_ev.id = LS_LED_EV_PRODUCTION;
            led_ev.param.mode_param.scene_id = ev.param.mode_param.scene_id;
            ls_led_task_notify(&led_ev);
            vesync_production_enter_testmode(true);
            break;
        case LS_EV_OFF:
            if (s_ls_status.status == false)
            {
                return;
            }

            s_ls_status.status = false;
            led_ev.id = LS_LED_EV_OFF;
            if (s_ls_status.timer_mode != LS_TIMER_OFF && s_timer_ls_status == true)
            {
                s_ls_status.timer_mode = LS_TIMER_OFF;
                ls_timer_process(s_ls_status.timer_mode);
            }

            ls_led_task_notify(&led_ev);
            ls_save_config(s_ls_status);
            break;
        case LS_EV_ON:
            led_ev.id = LS_LED_EV_ON;
            if (s_ls_status.timer_mode != LS_TIMER_OFF && s_timer_ls_status == false
                && ev.act_src != LS_ACT_SRC_VOICE_CTRL && ev.act_src != LS_ACT_SRC_INIT)
            {
                s_ls_status.timer_mode = LS_TIMER_OFF;
                ls_timer_process(s_ls_status.timer_mode);
            }

            if (ev.act_src == LS_ACT_SRC_VOICE_CTRL)
            {
                if (s_ls_status.status == false)
                {
                    // 关闭状态不响应声控
                    return;
                }

                s_ls_status.scene_id = ((s_ls_status.scene_id + 1) > LS_MODE_NUM ? 1 : (s_ls_status.scene_id + 1));
                s_ls_status.mode = LS_MODE_SCENE;
            }
            else if (ev.act_src == LS_ACT_SRC_DEVICE)
            {
                // 按键和遥控timer相关逻辑判断
                if ((vesync_task_get_tick_ms() - s_sys_start_ts) < 10000)
                {
                    // 上电10s内 可以触发产测模式，要2s内按5次按键
                    ls_manual_production();
                }

                if (s_ls_status.mode == LS_MODE_SCENE)
                {
                    if (s_ls_status.status == true)
                    {
                        s_ls_status.scene_id++;
                    }

                    if (s_ls_status.scene_id > LS_MODE_NUM)
                    {
                        s_ls_status.scene_id = LS_MODE_NUM;
                        s_ls_status.music_id = 1;
                        s_ls_status.mode = LS_MODE_MUSIC;
                    }
                }
                else
                {
                    if (s_ls_status.status == true)
                    {
                        s_ls_status.music_id++;
                    }

                    if (s_ls_status.music_id > LS_MODE_MUSIC_NUM)
                    {
                        s_ls_status.scene_id = 1;
                        s_ls_status.music_id = LS_MODE_MUSIC_NUM;
                        s_ls_status.mode = LS_MODE_SCENE;
                    }
                }
            }
            else if (ev.act_src == LS_ACT_SRC_SCHEDULE || ev.act_src == LS_ACT_SRC_TIMER)
            {
                s_ls_status.mode = ev.param.mode_param.mode;
                if (s_ls_status.mode == LS_MODE_SCENE)
                {
                    s_ls_status.scene_id = ev.param.mode_param.scene_id;
                }
                else
                {
                    s_ls_status.music_id = ev.param.mode_param.scene_id;
                }
            }
            else
            {
                // bypass 红外遥控 init
                s_ls_status.mode = ev.param.mode_param.mode;
                if (s_ls_status.mode == LS_MODE_SCENE)
                {
                    s_ls_status.scene_id = ev.param.mode_param.scene_id;
                    s_ls_status.brightness = ev.param.mode_param.brightness;
                    s_ls_status.speed = ev.param.mode_param.speed;
                }
                else
                {
                    s_ls_status.music_id = ev.param.mode_param.scene_id;
                }
            }

            if (s_ls_status.mode == LS_MODE_MUSIC)
            {
                led_ev.param.mode_param.mode = LS_MODE_MUSIC;
                led_ev.param.mode_param.scene_id = s_ls_status.music_id;
            }
            else
            {
                led_ev.param.mode_param.mode = LS_MODE_SCENE;
                led_ev.param.mode_param.scene_id = s_ls_status.scene_id;
                led_ev.param.mode_param.brightness = s_ls_status.brightness;
                led_ev.param.mode_param.speed = s_ls_status.speed;
            }
            s_ls_status.status = true;
            ls_led_task_notify(&led_ev);
            ls_set_voice_off_flag(false);
            ls_save_config(s_ls_status);
            break;
        case LS_EV_VOICE_CTRL_ONOFF:
            s_ls_status.voice_ctrl = ev.param.voice_ctrl;
            led_ev.id = LS_LED_EV_VOICE_CTRL;
            led_ev.param.voice_ctrl = s_ls_status.voice_ctrl;
            ls_led_task_notify(&led_ev);
            ls_save_config(s_ls_status);
            break;
        case LS_EV_SET_TIMER:
            if (s_ls_status.status == true && ev.param.timer_mode != LS_TIMER_OFF)
            {
                s_ls_status.timer_mode = ev.param.timer_mode;
                ls_timer_process(s_ls_status.timer_mode);
            }
            else
            {
                s_ls_status.timer_mode = LS_TIMER_OFF;
                ls_timer_process(s_ls_status.timer_mode);
            }
            ls_save_config(s_ls_status);
            break;
        default:
            APP_LOG(LOG_WARN, "Unknown event\n");
            break;
    }
}

/**
* @brief  app应用任务
*/
static void app_task(void *arg)
{
    UNUSED(arg);
    APP_LOG(LOG_DEBUG, "-------app task running--------\n");
    ls_ev_t ev;
    ls_status_init();
    while(1)
    {
        int ret = vesync_queue_recv(s_event_queue, &ev, VESYNC_OS_WAIT_FOREVER);
        if (ret != VOS_OK)
        {
            APP_LOG(LOG_ERROR, "Event queue recv fail\n");
            return;
        }

        app_event_handle(ev);
    }

}

/**
* @brief 获取遥控定时器模式
* @return  LS_TIMER_E       [定时器模式]
*/
LS_TIMER_E ls_get_timer_mode(void)
{
    return s_ls_status.timer_mode;
}

/**
* @brief
* @param[out]  *pst_status       [状态参数]
*/
void ls_get_status(ls_status_t *pst_status)
{
    *pst_status = s_ls_status;
}

/**
* @brief 初始化应用层配置
*/
void ls_status_init(void)
{
    //flash read
    if (ls_read_config(&s_ls_status) == APP_FAIL)
    {
        s_ls_status.status = true;
        s_ls_status.mode = LS_MODE_SCENE;
        s_ls_status.scene_id = 1;
        s_ls_status.music_id = 1;
        s_ls_status.timer_mode = LS_TIMER_OFF;
        s_ls_status.brightness = 100;
        s_ls_status.speed = 3;
        s_ls_status.voice_ctrl = false;
    }

    ls_led_params_init(s_ls_status.voice_ctrl, s_ls_status.speed, (s_ls_status.brightness / 100.0));
    ls_led_ev_t led_ev;
    memset(&led_ev, 0,sizeof(ls_led_ev_t));
    if (s_ls_status.status)
    {
        // 灯串默认关闭，根据初始化状态开启
        led_ev.id = LS_LED_EV_ON;
        led_ev.param.mode_param.mode = s_ls_status.mode;
        if (s_ls_status.mode == LS_MODE_SCENE)
        {
            led_ev.param.mode_param.scene_id = s_ls_status.scene_id;
            led_ev.param.mode_param.brightness = s_ls_status.brightness;
            led_ev.param.mode_param.speed = s_ls_status.speed;
        }
        else
        {
            led_ev.param.mode_param.scene_id = s_ls_status.music_id;
        }

        ls_led_task_notify(&led_ev);
    }
    else
    {
        APP_LOG(LOG_ERROR, "Led turn off \n");
    }

    ls_timer_process(s_ls_status.timer_mode);
    ls_ev_t ev;
    memset(&ev, 0, sizeof(ls_ev_t));
    if (s_ls_status.timer_mode != LS_TIMER_OFF)
    {
        ev.id = LS_EV_ON;
        ev.act_src = LS_ACT_SRC_INIT;
        ev.param.mode_param.mode = s_ls_status.mode;
        ev.param.mode_param.scene_id = (s_ls_status.mode == LS_MODE_SCENE ? s_ls_status.scene_id : s_ls_status.music_id);
        ev.param.mode_param.brightness = s_ls_status.brightness;
        ev.param.mode_param.speed = s_ls_status.speed;
        APP_LOG(LOG_DEBUG, "timer on \n");
        ls_app_task_notify(&ev);
    }
    ls_report_set_chg_rsn(STAT_CHG_RSN_FLASH_STR);
}

/**
* @brief SDK初始化结束后回调函数
*/
static void ls_app_run(void)
{
    ls_led_init();
    ls_button_init();
    ls_bypass_reg_cb();
    ls_device_init();
    ls_report_init();
    ls_production_init();
    ls_schedule_init();
    ls_timing_init();
    ls_reg_wifi_led();
    ls_ir_rx_init();
    s_sys_start_ts = vesync_task_get_tick_ms();
    APP_LOG(LOG_DEBUG, " APP init start \n");
    s_event_queue = vesync_queue_new(LS_EVENT_QUEUE_MAX_NUM * sizeof(ls_ev_t), sizeof(ls_ev_t));
    if (s_event_queue == NULL)
    {
        APP_LOG(LOG_ERROR, "App event queue create failed\n");
        return;
    }

    int ret = vesync_task_new(LS_APP_TASK_NAME, NULL, app_task, NULL, LS_APP_TASK_STACSIZE, LS_APP_TASK_PRIO, NULL);
    if (ret != VOS_OK)
    {
        APP_LOG(LOG_ERROR, "App task create failed\n");
        vesync_queue_free(s_event_queue);
        s_event_queue = NULL;
        return;
    }
}

/**
 * @brief  给lightstring应用任务发通知
 * @param[in]   ev              [通知消息]
 * @return     int              [成功：APP_OK，失败：APP_FAIL]
 */
int ls_app_task_notify(ls_ev_t *ev)
{
    int ret = vesync_queue_send(s_event_queue, ev, VESYNC_OS_NO_WAIT);
    if (ret != VOS_OK)
    {
        APP_LOG(LOG_ERROR, "Event publish failed\n");
        return APP_FAIL;
    }
    APP_LOG(LOG_DEBUG, "ev id %d src %d\n", ev->id, ev->act_src);
    return APP_OK;
}

/**
* @brief 应用入口
*/
void app_main()
{
    vesync_sdk_reg_pre_run_cb(ls_pre_cb);
    vesync_sdk_reg_post_run_cb(ls_app_run);

    vesync_sdk_run();

    APP_LOG(LOG_INFO, "Lightstring app init\n");
}


