/*
 * Copyright © Vesync Technologies Co.Ltd. 2019-2021. All rights reserved.
 *
 * This file is subject to the terms and conditions defined in
 * file 'LICENSE', which is part of this source code package.
 * Tuan PM <tuanpm at live dot com>
 */


#ifndef __VESYNC_MQTT_INTERNAL_H__
#define __VESYNC_MQTT_INTERNAL_H__


#include <stdint.h>
#include <stdbool.h>
#include <string.h>

#include "vesync_mqtt_config.h"


#ifdef __cplusplus
extern "C" {
#endif


typedef struct vesync_mqtt_client* vesync_mqtt_client_handle_t;

/**
 * @brief MQTT QoS
 */
typedef enum
{
    MQTT_QOS0 = 0,
    MQTT_QOS1 = 1,
    MQTT_QOS2 = 2
} MQTT_QOS_E;

/**
 * @brief MQTT event types.
 *
 * User event handler receives context data in `vesync_mqtt_event_t` structure with
 *  - `user_context` - user data from `vesync_mqtt_client_config_t`
 *  - `client` - mqtt client handle
 *  - various other data depending on event type
 *
 */
typedef enum {
    MQTT_EVENT_ERROR = 0,
    MQTT_EVENT_CONNECTED,          /*!< connected event, additional context: session_present flag */
    MQTT_EVENT_DISCONNECTED,       /*!< disconnected event */
    MQTT_EVENT_SUBSCRIBED,         /*!< subscribed event, additional context: msg_id */
    MQTT_EVENT_UNSUBSCRIBED,       /*!< unsubscribed event */
    MQTT_EVENT_PUBLISHED,          /*!< published event, additional context:  msg_id */
    MQTT_EVENT_DATA,               /*!< data event, additional context:
                                        - msg_id               message id
                                        - topic                pointer to the received topic
                                        - topic_len            length of the topic
                                        - data                 pointer to the received data
                                        - data_len             length of the data for this event
                                        - current_data_offset  offset of the current data for this event
                                        - total_data_len       total length of the data received
                                         */
    MQTT_EVENT_BEFORE_CONNECT,     /*!< The event occurs before connecting */
    MQTT_EVENT_DNS_RESOLVED,
} VESYNC_MQTT_EVENT_ID_E;

/**
 * @brief MQTT transport type
 */
typedef enum {
    MQTT_TRANSPORT_UNKNOWN = 0x0,
    MQTT_TRANSPORT_OVER_TCP,      /*!< MQTT over TCP, using scheme: ``mqtt`` */
    MQTT_TRANSPORT_OVER_SSL,      /*!< MQTT over SSL, using scheme: ``mqtts`` */
    MQTT_TRANSPORT_OVER_WS,       /*!< MQTT over Websocket, using scheme:: ``ws`` */
    MQTT_TRANSPORT_OVER_WSS       /*!< MQTT over Websocket Secure, using scheme: ``wss`` */
} VESYNC_MQTT_TRANSPORT_E;

/**
 * @brief MQTT event configuration structure
 */
typedef struct {
    VESYNC_MQTT_EVENT_ID_E event_id;       /*!< MQTT event type */
    vesync_mqtt_client_handle_t client;    /*!< MQTT client handle for this event */
    void *user_context;                 /*!< User context passed from MQTT client config */
    char *data;                         /*!< Data asociated with this event */
    int data_len;                       /*!< Lenght of the data for this event */
    int total_data_len;                 /*!< Total length of the data (longer data are supplied with multiple events) */
    int current_data_offset;            /*!< Actual offset for the data asociated with this event */
    char *topic;                        /*!< Topic asociated with this event */
    int topic_len;                      /*!< Length of the topic for this event asociated with this event */
    int msg_id;                         /*!< MQTT messaged id of message */
    int session_present;                /*!< MQTT session_present flag for connection event */
} vesync_mqtt_event_t;

typedef vesync_mqtt_event_t* vesync_mqtt_event_handle_t;

typedef int (* mqtt_event_callback_t)(vesync_mqtt_event_handle_t event);

/**
 * MQTT client configuration structure
 */
typedef struct {
    mqtt_event_callback_t event_handle;     /*!< handle for MQTT events */
    const char *host;                       /*!< MQTT server domain (ipv4 as string) */
    const char *uri;                        /*!< Complete MQTT broker URI */
    uint32_t port;                          /*!< MQTT server port */
    const char *client_id;                  /*!< default client id is ``ESP32_%CHIPID%`` where %CHIPID% are last 3 bytes of MAC address in hex format */
    const char *username;                   /*!< MQTT username */
    const char *password;                   /*!< MQTT password */
    const char *lwt_topic;                  /*!< LWT (Last Will and Testament) message topic (NULL by default) */
    const char *lwt_msg;                    /*!< LWT message (NULL by default) */
    int lwt_qos;                            /*!< LWT message qos */
    int lwt_retain;                         /*!< LWT retained message flag */
    int lwt_msg_len;                        /*!< LWT message length */
    int disable_clean_session;              /*!< mqtt clean session, default clean_session is true */
    int keepalive;                          /*!< mqtt keepalive, default is 120 seconds */
    bool disable_auto_reconnect;            /*!< this mqtt client will reconnect to server (when errors/disconnect). Set disable_auto_reconnect=true to disable */
    void *user_context;                     /*!< pass user context to this option, then can receive that context in ``event->user_context`` */
    int task_prio;                          /*!< MQTT task priority, default is 5, can be changed in ``make menuconfig`` */
    int task_stack;                         /*!< MQTT task stack size, default is 6144 bytes, can be changed in ``make menuconfig`` */
    int buffer_size;                        /*!< size of MQTT send/receive buffer, default is 1024 */
    const char *cert_pem;                   /*!< Pointer to certificate data in PEM format for server verify (with SSL), default is NULL, not required to verify the server */
    const char *client_cert_pem;            /*!< Pointer to certificate data in PEM format for SSL mutual authentication, default is NULL, not required if mutual authentication is not needed. If it is not NULL, also `client_key_pem` has to be provided. */
    const char *client_key_pem;             /*!< Pointer to private key data in PEM format for SSL mutual authentication, default is NULL, not required if mutual authentication is not needed. If it is not NULL, also `client_cert_pem` has to be provided. */
    VESYNC_MQTT_TRANSPORT_E transport;         /*!< overrides URI transport */
    int refresh_connection_after_ms;        /*!< Refresh connection after this value (in milliseconds) */
} vesync_mqtt_client_config_t;

/**
 * @brief       Creates mqtt client handle based on the configuration
 * @param[in]   config                      [mqtt configuration structure]
 * @return      vesync_mqtt_client_handle_t [the handle of mqtt client]
 */
vesync_mqtt_client_handle_t vesync_mqtt_client_init(const vesync_mqtt_client_config_t *config);

/**
 * @brief       Sets mqtt connection URI. This API is usually used to overrides the URI
 *              configured in vesync_mqtt_client_init
 * @param[in]   client                      [mqtt client handle]
 * @param[in]   uri
 * @return      int                         [success or fail]
 * @note        This interface is not working yet
 */
int vesync_mqtt_client_set_uri(vesync_mqtt_client_handle_t client, const char *uri);

/**
 * @brief       Starts mqtt client with already created client handle
 * @param[in]   client                      [mqtt client handle]
 * @return      int                         [success or fail]
 */
int vesync_mqtt_client_start(vesync_mqtt_client_handle_t client);

/**
 * @brief       Stops mqtt client tasks
 * @param[in]   client                      [mqtt client handle]
 * @return      int                         [success or fail]
 */
int vesync_mqtt_client_stop(vesync_mqtt_client_handle_t client);

/**
 * @brief       Subscribe the client to defined topic with defined qos
 * @param[in]   client                      [mqtt client handle]
 * @param[in]   topic
 * @param[in]   qos
 * @return      int                         [message_id of the subscribe message on success; -1 on failure]
 * @Notes:
 *              - Client must be connected to send subscribe message
 *              - This API is could be executed from a user task or
 *              from a mqtt event callback i.e. internal mqtt task
 *              (API is protected by internal mutex, so it might block
 *              if a longer data receive operation is in progress.)
 */
int vesync_mqtt_client_subscribe(vesync_mqtt_client_handle_t client, const char *topic, int qos);

/**
 * @brief       Unsubscribe the client from defined topic
 * @param[in]   client                      [mqtt client handle]
 * @param[in]   topic
 * @return      int                         [message_id of the unsubscribe message on success; -1 on failure]
 * @Notes:
 *              - Client must be connected to send unsubscribe message
 *              - It is thread safe, please refer to `vesync_mqtt_client_subscribe` for details
 */
int vesync_mqtt_client_unsubscribe(vesync_mqtt_client_handle_t client, const char *topic);

/**
 * @brief       Client to send a publish message to the broker
 * @param[in]   client                      [mqtt client handle]
 * @param[in]   topic                       [topic string]
 * @param[in]   data                        [payload string (set to NULL, sending empty payload message)]
 * @param[in]   len                         [data length, if set to 0, length is calculated from payload string]
 * @param[in]   qos                         [qos of publish message]
 * @param[in]   retain                      [retain flag]
 * @return      int                         [message_id of the publish message(for QoS 0 message_id will always be zero) on success; -1 on failure]
 * @Notes:
 *              - Client doesn't have to be connected to send publish message
 *              (although it would drop all qos=0 messages, qos>1 messages would be enqueued)
 *              - It is thread safe, please refer to `vesync_mqtt_client_subscribe` for details
 */
int vesync_mqtt_client_publish(vesync_mqtt_client_handle_t client, const char *topic, const char *data, int len, int qos, int retain);

/**
 * @brief       Destroys the client handle
 * @param[in]   client                      [mqtt client handle]
 * @return      int                         [success or fail]
 */
int vesync_mqtt_client_destroy(vesync_mqtt_client_handle_t client);

/**
 * @brief       Set configuration structure, typically used when updating the config (i.e. on "before_connect" event)
 * @param[in]   client                      [mqtt client handle]
 * @param[in]   config                      [mqtt configuration structure]
 * @return      int                         [success or fail]
 */
int vesync_mqtt_set_config(vesync_mqtt_client_handle_t client, const vesync_mqtt_client_config_t *config);

/**
 * @brief       Sets the configuration of mqtt client over tls
 * @param[in]   client_config               [client configuration structure]
 * @param[in]   client_id                   [client id]
 * @param[in]   server_addr                 [server address]
 * @param[in]   server_port                 [server port]
 * @param[in]   username                    [mqtt client username]
 * @param[in]   password                    [mqtt client password]
 * @param[in]   event_cb                    [mqtt event callback]
 * @param[in]   ca_cert                     [CA certificate]
 * @param[in]   client_cert                 [client certificate]
 * @param[in]   client_key                  [client key]
 * @return      int                         [success or fail]
 */
int vesync_mqtt_client_config_tls(vesync_mqtt_client_config_t* client_config, char *client_id, char *server_addr, uint16_t server_port,
                                    char *username, char *password, mqtt_event_callback_t event_cb,
                                    const char * ca_cert, const char *client_cert, const char *client_key);

/**
 * @brief       Sets the configuration of mqtt client over tcp
 * @param[in]   client_config               [client configuration structure]
 * @param[in]   client_id                   [client id]
 * @param[in]   server_addr                 [server address]
 * @param[in]   server_port                 [server port]
 * @param[in]   username                    [mqtt client username]
 * @param[in]   password                    [mqtt client password]
 * @param[in]   event_cb                    [mqtt event callback]
 * @return      int                         [success or fail]
 */
int vesync_mqtt_client_config(vesync_mqtt_client_config_t *client_config, char *client_id, char *server_addr, uint16_t server_port,
                                    char *username, char *password, mqtt_event_callback_t event_cb);

/**
 * @brief       Destroys the client configuration structure
 * @param[in]   client_config               [client configuration structure]
 * @return      int                         [success or fail]
 */
int vesync_mqtt_destroy_client_config(vesync_mqtt_client_config_t *client_config);

/*
 * @brief       Saves the address information of server
 */
void vesync_mqtt_update_serv_addr_info(void);


#ifdef __cplusplus
}
#endif


#endif /* __VESYNC_MQTT_INTERNAL_H__ */
