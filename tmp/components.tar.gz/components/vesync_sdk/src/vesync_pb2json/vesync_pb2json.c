/**
 * Copyright © Vesync Technologies Co.Ltd. 2019-2021. All rights reserved.
 * @file    vesync_pb2json.c
 * @brief   Protobuf与JSON互转接口实现
 * @author  Herve Lin
 * @date    2021-12-13
 */

#include <string.h>
#include <stdio.h>
#include <assert.h>

#include "vesync_memory.h"
#include "vesync_common.h"

#include "vesync_pb2json_internal.h"
#include "vesync_log_internal.h"

/**
 * @brief Protobuf转JSON的Message处理方法（提前声明）
 * @param[in]   flag                [功能选项]
 * @param[in]   protobuf_message    [输入Protobuf Message对象]
 * @param[out]  json_message        [指向输出的JSON对象的引用]
 * @return      int                 [PROTOBUF2JSON_ERR_E]
 */
static int protobuf2json_process_message(proc_flag_t flag, const ProtobufCMessage *protobuf_message, cJSON **json_message);

/**
 * @brief Protobuf转JSON的Field处理方法
 * @param[in]   flag                [功能选项]
 * @param[in]   field_descriptor    [指向Protobuf Field域描述符]
 * @param[in]   protobuf_value      [指向Protobuf Field的值]
 * @param[out]  json_value          [指向输出的JSON对象的引用]
 * @return      int                 [PROTOBUF2JSON_ERR_E]
 */
static int protobuf2json_process_field(proc_flag_t flag, const ProtobufCFieldDescriptor *field_descriptor, const void *protobuf_value, cJSON **json_value)
{
    switch (field_descriptor->type)
    {
    case PROTOBUF_C_TYPE_INT32:
    case PROTOBUF_C_TYPE_SINT32:
    case PROTOBUF_C_TYPE_SFIXED32:
        *json_value = cJSON_CreateNumber((double)(*(int32_t *)protobuf_value));
        break;
    case PROTOBUF_C_TYPE_UINT32:
    case PROTOBUF_C_TYPE_FIXED32:
        *json_value = cJSON_CreateNumber((double)(*(uint32_t *)protobuf_value));
        break;
    case PROTOBUF_C_TYPE_INT64:
    case PROTOBUF_C_TYPE_SINT64:
    case PROTOBUF_C_TYPE_SFIXED64:
        *json_value = cJSON_CreateNumber((double)(*(int64_t *)protobuf_value));
        break;
    case PROTOBUF_C_TYPE_UINT64:
    case PROTOBUF_C_TYPE_FIXED64:
        *json_value = cJSON_CreateNumber((double)(*(uint64_t *)protobuf_value));
        break;
    case PROTOBUF_C_TYPE_FLOAT:
        *json_value = cJSON_CreateNumber((double)(*(float *)protobuf_value));
        break;
    case PROTOBUF_C_TYPE_DOUBLE:
        *json_value = cJSON_CreateNumber(*(int64_t *)protobuf_value);
        break;
    case PROTOBUF_C_TYPE_BOOL:
        if (flag & PROC_FLAG_NUMBERIC_BOOL)
        {
            *json_value = cJSON_CreateNumber((double)((PB_TRUE == *(protobuf_c_boolean *)protobuf_value) ? 1 : 0));
        }
        else
        {
            *json_value = cJSON_CreateBool((cJSON_bool)((PB_TRUE == *(protobuf_c_boolean *)protobuf_value) ? 1 : 0));
        }
        break;
    case PROTOBUF_C_TYPE_ENUM:
    {
        const ProtobufCEnumValue *protobuf_enum_value = protobuf_c_enum_descriptor_get_value(field_descriptor->descriptor, *(int *)protobuf_value);
        if (NULL == protobuf_enum_value)
        {
            PB2JSON_LOG(LOG_DEBUG, "unknown value %d for enum '%s'\n", *(int *)protobuf_value, ((ProtobufCEnumDescriptor *)field_descriptor->descriptor)->name);
            return PROTOBUF2JSON_ERR_UNKNOWN_ENUM_VALUE;
        }

        if (flag & PROC_FLAG_NUMBERIC_ENUM)
        {
            *json_value = cJSON_CreateNumber((int)protobuf_enum_value->value);
        }
        else
        {
            *json_value = cJSON_CreateString((const char *)protobuf_enum_value->name);
        }
        break;
    }
    case PROTOBUF_C_TYPE_STRING:
        *json_value = cJSON_CreateString((const char *)(*((char **)protobuf_value)));
        break;
    case PROTOBUF_C_TYPE_BYTES:
    {
        const ProtobufCBinaryData *protobuf_binary = (const ProtobufCBinaryData *)protobuf_value;

        int base64_encoded_length = BASE64_ENCODED_LEN(protobuf_binary->len);
        char *base64_encoded_data = vesync_calloc(base64_encoded_length, sizeof(char));
        if (NULL == base64_encoded_data)
        {
            PB2JSON_LOG(LOG_ERROR, "cannot allocate %zu bytes\n", base64_encoded_length * sizeof(char));
            return PROTOBUF2JSON_ERR_CANNOT_ALLOCATE_MEMORY;
        }

        base64_encoded_length = base64_encode(base64_encoded_data, (const char *)protobuf_binary->data, protobuf_binary->len);
        PB2JSON_LOG(LOG_DEBUG, "create string_item for base64 encoded bytes[%d]\n", base64_encoded_length);
        *json_value = cJSON_CreateString((const char *)base64_encoded_data);
        vesync_free(base64_encoded_data);
        break;
    }
    case PROTOBUF_C_TYPE_MESSAGE:
    {
        const ProtobufCMessage **protobuf_message = (const ProtobufCMessage **)protobuf_value;
        int ret = protobuf2json_process_message(flag, *protobuf_message, json_value);
        if (ret != PROTOBUF2JSON_ERR_OK)
        {
            return ret;
        }
        break;
    }
    default:
        assert(0);
        return PROTOBUF2JSON_ERR_INVALID_FIELD_TYPE;
    }

    if (NULL == *json_value)
    {
        PB2JSON_LOG(LOG_ERROR, "cannot allocate JSON structure\n");
        return PROTOBUF2JSON_ERR_CANNOT_ALLOCATE_MEMORY;
    }

    return PROTOBUF2JSON_ERR_OK;
}

static int protobuf2json_process_message(proc_flag_t flag, const ProtobufCMessage *protobuf_message, cJSON **json_message)
{
    *json_message = cJSON_CreateObject();
    if (NULL == *json_message)
    {
        PB2JSON_LOG(LOG_ERROR, "cannot allocate JSON object\n");
        return PROTOBUF2JSON_ERR_CANNOT_ALLOCATE_MEMORY;
    }

    cJSON *json_value = NULL;
    for (unsigned int i = 0; i < protobuf_message->descriptor->n_fields; i++)
    {
        const ProtobufCFieldDescriptor *field_descriptor = protobuf_message->descriptor->fields + i;
        const void *protobuf_value = ((const char *)protobuf_message) + field_descriptor->offset;
        const void *protobuf_value_quantifier = ((const char *)protobuf_message) + field_descriptor->quantifier_offset;

        if (PROTOBUF_C_LABEL_REQUIRED == field_descriptor->label)
        {
            json_value = NULL;
            int ret = protobuf2json_process_field(flag, field_descriptor, protobuf_value, &json_value);
            if (ret != PROTOBUF2JSON_ERR_OK)
            {
                return ret;
            }

            cJSON_AddItemToObject(*json_message, field_descriptor->name, json_value);
        }
        else if (PROTOBUF_C_LABEL_OPTIONAL == field_descriptor->label)
        {
            if (field_descriptor->flags & PROTOBUF_C_FIELD_FLAG_ONEOF)
            {
                uint32_t *oneof_case = (uint32_t *)protobuf_value_quantifier;
                if (*oneof_case == field_descriptor->id)
                {
                    if ((PROTOBUF_C_TYPE_MESSAGE == field_descriptor->type) || (PROTOBUF_C_TYPE_STRING == field_descriptor->type))
                    {
                        if ((NULL == protobuf_value) || (protobuf_value == field_descriptor->default_value))
                        {
                            continue;
                        }
                    }
                }
                else
                {
                    continue;
                }
            }

            protobuf_c_boolean is_set = PB_FALSE;
            if ((PROTOBUF_C_TYPE_MESSAGE == field_descriptor->type) || (PROTOBUF_C_TYPE_STRING == field_descriptor->type))
            {
                if (*(const void *const *)protobuf_value != NULL)
                {
                    is_set = PB_TRUE;
                }
            }
            else
            {
                const protobuf_c_boolean *has_member = (const protobuf_c_boolean *)protobuf_value_quantifier;
                // Check the `has_MEMBER` field for optional members or the `n_MEMBER` field
                if (PB_TRUE == *has_member)
                {
                    is_set = PB_TRUE;
                }
            }

            if ((PB_TRUE == is_set) || (field_descriptor->default_value != NULL))
            {
                json_value = NULL;
                int ret = protobuf2json_process_field(flag, field_descriptor, protobuf_value, &json_value);
                if (ret != PROTOBUF2JSON_ERR_OK)
                {
                    return ret;
                }
                cJSON_AddItemToObject(*json_message, field_descriptor->name, json_value);
            }
        }
        else if (PROTOBUF_C_LABEL_NONE == field_descriptor->label)
        {
            if (field_descriptor->flags & PROTOBUF_C_FIELD_FLAG_ONEOF)
            {
                uint32_t *oneof_case = (uint32_t *)protobuf_value_quantifier;
                if (*oneof_case != field_descriptor->id)
                {
                    continue;
                }
            }

            protobuf_c_boolean is_set = PB_TRUE;
            if (PROTOBUF_C_TYPE_MESSAGE == field_descriptor->type)
            {
                if (NULL == *(const void *const *)protobuf_value)
                {
                    is_set = PB_FALSE;
                }
            }
            else if (PROTOBUF_C_TYPE_STRING == field_descriptor->type)
            {
                // Check if the string field has been set
                if (*(const void *const *)protobuf_value == field_descriptor->default_value)
                {
                    is_set = PB_FALSE;
                }
            }

            if (PB_TRUE == is_set)
            {
                json_value = NULL;
                int ret = protobuf2json_process_field(flag, field_descriptor, protobuf_value, &json_value);
                if (ret != PROTOBUF2JSON_ERR_OK)
                {
                    return ret;
                }
                cJSON_AddItemToObject(*json_message, field_descriptor->name, json_value);
            }
        }
        else // PROTOBUF_C_LABEL_REPEATED
        {
            const size_t *protobuf_values_count = (const size_t *)protobuf_value_quantifier;

            cJSON *array = cJSON_CreateArray();
            if (NULL == array)
            {
                PB2JSON_LOG(LOG_ERROR, "cannot allocate JSON structure for array\n");
                return PROTOBUF2JSON_ERR_CANNOT_ALLOCATE_MEMORY;
            }

            if (*protobuf_values_count > 0)
            {
                size_t value_size = protobuf2json_value_size_by_type(field_descriptor->type);
                if (0 == value_size)
                {
                    cJSON_Delete(array);
                    PB2JSON_LOG(LOG_ERROR, "cannot calculate value size for %d\n", field_descriptor->type);
                    return PROTOBUF2JSON_ERR_UNSUPPORTED_FIELD_TYPE;
                }

                for (size_t j = 0; j < *protobuf_values_count; j++)
                {
                    json_value = NULL;
                    const char *protobuf_value_repeated = (*(char *const *)protobuf_value) + j * value_size;
                    int ret = protobuf2json_process_field(flag, field_descriptor, (const void *)protobuf_value_repeated, &json_value);
                    if (ret != PROTOBUF2JSON_ERR_OK)
                    {
                        cJSON_Delete(array);
                        return ret;
                    }

                    cJSON_AddItemToArray(array, json_value);
                }
            }
            else
            {
                if (flag & PROC_FLAG_IGNORE_EMPTY_ARRAY)
                {
                    continue;
                }
            }
            cJSON_AddItemToObject(*json_message, field_descriptor->name, array);
        }
    }

    return PROTOBUF2JSON_ERR_OK;
}

size_t protobuf2json_value_size_by_type(ProtobufCType type)
{
    switch (type)
    {
    case PROTOBUF_C_TYPE_INT32:
    case PROTOBUF_C_TYPE_SINT32:
    case PROTOBUF_C_TYPE_SFIXED32:
    case PROTOBUF_C_TYPE_UINT32:
    case PROTOBUF_C_TYPE_FIXED32:
        return 4;
    case PROTOBUF_C_TYPE_INT64:
    case PROTOBUF_C_TYPE_SINT64:
    case PROTOBUF_C_TYPE_SFIXED64:
    case PROTOBUF_C_TYPE_UINT64:
    case PROTOBUF_C_TYPE_FIXED64:
        return 8;
    case PROTOBUF_C_TYPE_FLOAT:
        return 4;
    case PROTOBUF_C_TYPE_DOUBLE:
        return 8;
    case PROTOBUF_C_TYPE_BOOL:
        return sizeof(protobuf_c_boolean);
    case PROTOBUF_C_TYPE_ENUM:
        return 4;
    case PROTOBUF_C_TYPE_STRING:
        return sizeof(char *);
    case PROTOBUF_C_TYPE_BYTES:
        return sizeof(ProtobufCBinaryData);
    case PROTOBUF_C_TYPE_MESSAGE:
        return sizeof(ProtobufCMessage *);
    default:
        assert(0);
        return 0;
    }
}

int vesync_pb2json(proc_flag_t flag, ProtobufCMessage *p_pb_msg, cJSON **p_json_ref)
{
    int ret = protobuf2json_process_message(flag, p_pb_msg, p_json_ref);
    if (ret != PROTOBUF2JSON_ERR_OK)
    {
        cJSON_Delete(*p_json_ref);
        return ret;
    }

    return PROTOBUF2JSON_ERR_OK;
}
