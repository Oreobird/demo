/**
 *  Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
 * @file        vhal_wifi_internal.h
 * @brief       封装Linux Wi-Fi接口
 * @author      Dongri.Su
 * @date        2021-04-20
 */

#ifndef __VHAL_WIFI_INTERNAL_H__
#define __VHAL_WIFI_INTERNAL_H__

#include "vesync_common.h"

#include "vhal_wifi.h"


#ifdef __cplusplus
extern "C"
{
#endif

/**
 * @brief  2G频率信道结构
 */
typedef struct
{
    unsigned int freq;
    unsigned int channel;
} vhal_hz_channel_2g_t;


#ifdef __cplusplus
}
#endif

#endif /* __VHAL_WIFI_INTERNAL_H__ */

