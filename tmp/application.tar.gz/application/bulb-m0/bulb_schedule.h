/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        bulb_schedule.h
 * @brief       bulb schedule头文件
 * @author      Dave
 * @date        2021-09-02
 */

#ifndef __BULB_SCHEDULE_H__
#define __BULB_SCHEDULE_H__

#include <stdint.h>
#include <stdbool.h>

#include "vesync_schedule.h"
#include "vesync_buffer.h"
#include "vesync_bypass.h"

#include "bulb.h"
#include "bulb_board.h"

#ifdef __cplusplus
extern "C" {
#endif

#define BULB_SCHEDULE_MIN_ID (BULB_SCHE_MIN_ID)                     // Schedule最小ID
#define BULB_SCHEDULE_MAX_NUM (BULB_SCHE_MAX_NUM)                   // Schedule最大条目数
#define BULB_SCHEDULE_GET_MAX_NUM (BULB_SCHE_GET_MAX_NUM)           // 一次Schedule查询最大的返回数量
#define BULB_SCHEDULE_MAX_APP_CFG_SIZE (BULB_SCHE_MAX_APP_CFG_SIZE) // 配置读取Buffer大小
#define BULB_SCHE_INS_ID (0)                                        // Bulb Schedule实例ID
#define BULB_SCHEDULE_MOD_CFG_KEY "sche_mod"                        // Bulb Schedule模块配置存储KEY

#define BULB_SCHE_SUN_EVT_TIME_MAX (3600)
#define BULB_SCHE_SUN_EVT_TIME_MIN (-3600)

/**
 * @brief Bypass添加Schedule配置项
 * @param[in]   sch_cfg     [Schedule配置]
 * @param[in]   action      [Schedule动作]
 * @param[out]  p_out_id    [添加成功后，返回生成的ID]
 * @return int              [返回BYPASS的错误定义]
 */
int bulb_schedule_add(vesync_schedule_t *sch_cfg, void *action, uint32_t *p_out_id);

/**
 * @brief Bypass更新Schedule配置项
 * @param[in]   p_bp_sch    [Bypass下发的Schedule配置]
 * @param[out]  p_out_id    [更新成功后，返回操作的ID]
 * @return int              [返回BYPASS的错误定义]
 */
int bulb_schedule_upd(bypass_schedule_base_t *p_bp_sch, uint32_t *p_out_id);

/**
 * @brief Bypass按顺序获取Schedule多个配置项
 * @note  返回多少个连续的配置项是由Schedule模块决定
 * @param[in]  index        [要获取的Schedule配置项的初始序号]
 * @param[in]  sche_cfg     [schedule配置数组]
 * @param[in]  action       [schedule动作数组]
 * @param[in]  cur_num      [返回的schedule数]
 * @param[in]  total_num    [配置项总数]
 * @return int              [返回BYPASS的错误定义]
 */
int bulb_schedule_get_mult(uint32_t index, vesync_schedule_t *sche_cfg, bulb_action_t *action, uint32_t *cur_num, uint32_t *total_num);

/**
 * @brief Bypass删除指定ID的Schedule配置项
 * @param[in]   id_to_del   [要删除的Schedule配置项ID]
 * @return      int         [返回BYPASS的错误定义]
 */
int bulb_schedule_del(uint32_t id_to_del);

/**
 * @brief App层调用，复位Schedule的所有配置信息
 * @return      int         [成功：APP_OK， 失败：APP_FAIL]
 */
int bulb_schedule_clear(void);

/**
 * @brief 初始化Schedule功能
 * @return      int         [成功：APP_OK， 失败：APP_FAIL]
 */
int bulb_schedule_init(void);

#ifdef __cplusplus
}
#endif

#endif



