/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_buffer.h
 * @brief       Vesync buffer 相关声明
 * @date        2021-08-06
 */
#ifndef __VESYNC_BUFFER_H__
#define __VESYNC_BUFFER_H__

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief Vesync Buffer数据结构定义
 *
 */
typedef struct
{
    void *buf;      // @readonly: Buffer缓存指针
    uint32_t len;   // @readonly: Buffer数据长度
    uint16_t _mc;   // @private: Magic code防止Buffer未初始化操作
} vesync_buf_t;

/**
 * @brief 新建一个Buffer。需要用vesync_buf_clr()清除以释放内存。
 * @return vesync_buf_t         [返回的Buffer]
 */
vesync_buf_t vesync_buf_new(void);

/**
 * @brief 清空一个Buffer。Buffer需要是由vesync_buf_new()生成的。
 * @param[in] buffer            [指向要被清空的Buffer]
 */
void vesync_buf_clr(vesync_buf_t *buffer);

/**
 * @brief 将一个Buffer拷贝到另一个Buffer
 * @param[in] dest              [指向目的Buffer]
 * @param[in] src               [指向源Buffer]
 */
void vesync_buf_cpy(vesync_buf_t *dest, const vesync_buf_t *src);

/**
 * @brief 向Buffer缓存数据
 * @param[in] buffer            [指向写入的Buffer]
 * @param[in] p_data            [指向缓存数据]
 * @param[in] len               [数据长度]
 */
void vesync_buf_set(vesync_buf_t *buffer, void *p_data, uint32_t len);

/**
 * @brief 向Buffer读出数据
 * @param[in]  buffer           [指向源数据Buffer]
 * @param[out] p_data           [指向读出数据的缓存]
 * @param[in]  len              [读出数据的缓存长度]
 */
void vesync_buf_get(const vesync_buf_t *buffer, void *p_data, uint32_t len);

#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_BUFFER_H__ */
