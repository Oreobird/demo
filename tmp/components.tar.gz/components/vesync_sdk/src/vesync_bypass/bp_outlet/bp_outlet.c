/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        bp_outlet.c
 * @brief       outlet bypass feature
 * @author      CharlesMei
 * @date        2021-06-28
 */


#include <string.h>

#include "vesync_common.h"
#include "vesync_memory.h"
#include "vesync_log_internal.h"

#include "vesync_bypass_internal.h"


/**
 * @brief "addInching"  method数据解析
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  json                     [json数据指针]
 * @return BYPASS_ERR_E                 [错误码]
 */
static BYPASS_ERR_E bypass_method_add_inching_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    BYPASS_ERR_E ret = BP_OK;
    uint32_t total_sec = 0;

    cJSON* json_data = cJSON_GetObjectItemCaseSensitive(json, "totalSec");
    if (cJSON_IsNumber(json_data))
    {
        total_sec = json_data->valueint & 0xFFFFFFFF;
    }
    if (0 == total_sec || total_sec > 7*24*3600)    // 最大倒计时7*24小时
    {
        ret = BP_ERR_ARG;
        goto exit;
    }
    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_ADD_INCHING);
    if (method_cb)
    {
        method_cb(p_msg_ctx, (void*)(&total_sec));
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
        goto exit;
    }

exit:
    return ret;
}

/**
 * @brief "delInching"  method数据解析
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  json                     [json数据指针]
 * @return BYPASS_ERR_E                 [错误码]
 */
static BYPASS_ERR_E bypass_method_del_inching_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    UNUSED(json);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    BYPASS_ERR_E ret = BP_OK;

    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_DEL_INCHING);
    if (method_cb)
    {
        method_cb(p_msg_ctx, NULL);
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
        goto exit;
    }

exit:
    return ret;
}

/**
 * @brief "getInching"  method数据解析
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  json                     [json数据指针]
 * @return BYPASS_ERR_E                 [错误码]
 */
static BYPASS_ERR_E bypass_method_get_inching_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    UNUSED(json);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    BYPASS_ERR_E ret = BP_OK;

    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_GET_INCHING);
    if (method_cb)
    {
        method_cb(p_msg_ctx, NULL);
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
        goto exit;
    }

exit:
    return ret;
}


static bypass_item_data_t method_tbl[] = {
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_ADD_INCHING, "addInching", bypass_method_add_inching_handle, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_DEL_INCHING, "delInching", bypass_method_del_inching_handle, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_GET_INCHING, "getInching", bypass_method_get_inching_handle, NULL},
};

void vesync_bypass_outlet_init(void)
{
    for (int i = 0; i < SIZEOF_ARRAY(method_tbl); i++)
    {
        bypass_item_t *item = vesync_bypass_init_item(&method_tbl[i]);
        if (item != NULL)
        {
            vesync_bypass_add_item(item);
        }
    }
}

