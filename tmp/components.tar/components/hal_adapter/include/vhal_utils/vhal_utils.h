/**
 *  Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
 * @file        vhal_utils.h
 * @brief       通用接口
 * @date        2021-04-20
 */

#ifndef __VHAL_UTILS_H__
#define __VHAL_UTILS_H__

#include <stdbool.h>
#include <stdint.h>

//#include "vesync_common.h"


#ifdef __cplusplus
extern "C"
{
#endif

/*
 * @brief 设备侧MAC地址类型
 */
typedef enum
{
    VHAL_MAC_WIFI_STA,          // STA模式时，WiFi的MAC地址
    VHAL_MAC_WIFI_SOFTAP,       // AP模式时，WiFi的MAC地址
    VHAL_MAC_BT,                // 蓝牙MAC地址
    VHAL_MAC_ROUTER,            // 关联上AP的MAC地址
} VHAL_MAC_TYPE_E;

/**
 * @brief 重启系统
 * @param[in]  arg                  [定时器参数，未使用]
 * @return     void
 */
void vhal_utils_restart(void *arg);

/**
 * @brief 通过硬件RNG获取随机数
 * @param[in]  p_buf                [用于存储随机数的缓存空间]
 * @param[in]  buf_len              [缓存空间大小]
 * @return     void
 */
void vhal_utils_get_random(uint8_t *p_buf, int32_t buf_len);

/**
 * @brief 修改dhcp的hostname
 * @param[in]  p_hostname            [新的hostname]
 * @return     void
 */
void vhal_utils_chg_dhcp_hostname(const char *p_hostname);

/**
 * @brief  获取Wi-Fi模组芯片名称
 * @return     char *               [字符串格式芯片名称]
 */
char *vhal_utils_get_chip_name(void);

/*
 * @brief 获取设备的MAC地址
 * @param[in]  type                 [详见DEVICE_TYPE_MAC_E定义]
 * @param[out] p_buf                [获取到的MAC地址]
 * @param[in]  buf_len              [缓存大小]
 * @return     int                  [执行成功，返回OK；执行失败，返回FAIL]
 */
int vhal_utils_get_dev_mac(VHAL_MAC_TYPE_E type, char *p_buf, int32_t buf_len);

/*
 * @brief 设备作为STA时，获取分配到的IP。
 * @param[in]  char *               [保存IP的缓存]
 * @param[in]  int                  [缓存大小]
 * @return     char*                [IP地址]
 */
char* vhal_utils_get_sta_ip(char *p_buf, int32_t buf_len);

#ifdef __cplusplus
}
#endif

#endif /* __VHAL_UTILS_H__ */