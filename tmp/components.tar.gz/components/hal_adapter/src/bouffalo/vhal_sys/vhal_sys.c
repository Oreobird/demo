/**
 * Copyright © Vesync Technologies Co.Ltd. 2019-2021. All rights reserved.
 * @file        vhal_sys.c
 * @brief       系统相关功能
 * @author      Joshua
 * @date        2021-08-26
 */

#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <lwip/tcpip.h>
#include <bl_sys.h>
#include <bl_uart.h>
#include <bl_sec.h>
#include <bl_irq.h>
#include <bl_dma.h>
#include <hal_boot2.h>
#include <hal_board.h>
#include <blog.h>

#include "vhal_sys.h"

extern uint8_t _heap_start;
extern uint8_t _heap_size; // @suppress("Type cannot be resolved")
extern uint8_t _heap_wifi_start;
extern uint8_t _heap_wifi_size; // @suppress("Type cannot be resolved")
static HeapRegion_t xHeapRegions[] =
{
        { &_heap_start,  (unsigned int) &_heap_size}, //set on runtime
        { &_heap_wifi_start, (unsigned int) &_heap_wifi_size },
        { NULL, 0 }, /* Terminates the array. */
        { NULL, 0 } /* Terminates the array. */
};

/*
 * @brief 系统硬件初始化，Vesync SDK初始化前调用
 */
void vhal_sys_board_init(void)
{
    bl_sys_early_init();

    /*Init UART In the first place*/
    bl_uart_init(0, 16, 7, 255, 255, 2 * 1000 * 1000);
    printf("Starting bl602 now....\r\n");

    bl_sys_init();

    vPortDefineHeapRegions(xHeapRegions);
    printf("Heap %u@%p, %u@%p\r\n",
            (unsigned int)&_heap_size, &_heap_start,
            (unsigned int)&_heap_wifi_size, &_heap_wifi_start
    );

    blog_init();
    bl_irq_init();
    bl_sec_init();
    bl_sec_test();
    bl_dma_init();
    hal_boot2_init();

    /* board config is set after system is init*/
    hal_board_cfg(0);

    printf("Starting TCP/IP Stack...\r\n");
    tcpip_init(NULL, NULL);
}

void vhal_sys_task_schedule(void)
{
    vTaskStartScheduler();
}

