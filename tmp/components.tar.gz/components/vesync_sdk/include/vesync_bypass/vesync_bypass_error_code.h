/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file        vesync_bypass_error_code.h
* @brief       bypass错误码
* @date        2021-06-15
*/

#ifndef __VESYNC_BYPASS_ERROR_CODE_H__
#define __VESYNC_BYPASS_ERROR_CODE_H__


//通用错误码定义
#define BP_ERR_NO_ERR                               (0)
#define BP_ERR_UNDEFINE                             (-1)            // 未定义错误
#define BP_ERR_PARA_ILLEGAL                         (11000000UL)    // 参数不合法
#define BP_ERR_OUT_OF_MEMORY                        (11001000UL)    // 内存不足
#define BP_ERR_CMD_EXECUTE_FAIL                     (11002000UL)    // 命令执行失败
#define BP_ERR_VALUE_OUT_OF_RANGE                   (11003000UL)    // 数值超出范围
#define BP_ERR_DEVICE_BUSY                          (11004000UL)    // 设备忙，不可升级
#define BP_ERR_DEVICE_STDBY                         (11005000UL)    // 设备处于待机状态
#define BP_ERR_SENSOR_OPEN                          (11006000UL)    //传感器开路错误
#define BP_ERR_SENSOR_SHORT_CIRCUIT                 (11007000UL)    //传感器短路错误
#define BP_ERR_TIME_EXCEED_MAX                      (11008000UL)    //时长范围超过上限错误
#define BP_ERR_TIME_EXCEED_MIN                      (11009000UL)    //时长范围超过下限错误
#define BP_ERR_TEMP_EXCEED_MAX                      (11010000UL)    //烹饪温度超过上限错误
#define BP_ERR_TEMP_EXCEED_MIN                      (11011000UL)    //烹饪温度超过下限错误
#define BP_ERR_ALREADY_RUNNING                      (11012000UL)    //烤箱烹饪中，不能开启新的烹饪
#define BP_ERR_HIGH_VOLTAGE                         (11013000UL)    //电压错误
#define BP_ERR_SENSOR_FAULT                         (11014000UL)    // 传感器故障
#define BP_ERR_TEMP_FAULT                           (11015000UL)    //高温保护或温度异常保护
#define BP_ERR_NOT_EXEC_IN_MANUAL_MODE              (11016000UL)    // 手动模式下无法执行该操作
#define BP_ERR_NOT_EXEC_IN_CUR_MODE                 (11017000UL)    // 当前模式下不支持该操作
#define BP_ERR_NOT_EXEC_IN_SLEEP_MODE               (11018000UL)    // 睡眠模式下不支持该操作
#define BP_ERR_LOW_VOLTAGE                          (11019000UL)    //电压过低
#define BP_ERR_ALREADY_PAUSED                       (11020000UL)    //设备已经暂停
#define BP_ERR_ALREADY_STOPPED                      (11021000UL)    //设备已经停止
#define BP_ERR_NOT_EXEC_IN_AUTO_MODE                (11022000UL)    // 自动模式下无法执行该操作
#define BP_ERR_BOTTOM_NTC_OPEN_CIRCUIT              (11023000ul)    //底部NTC开路
#define BP_ERR_BOTTOM_NTC_SHORT_CIRCUIT             (11024000ul)    //底部NTC短路
#define BP_ERR_TOP_NTC_SHORT_CIRCUIT                (11025000ul)    //顶部NTC短路
#define BP_ERR_TOP_NTC_OPEN_CIRCUIT                 (11026000ul)    //顶部NTC开路
#define BP_ERR_HEATER_OR_FUSE_OPEN_CIRCUIT          (11027000ul)    //发热管开路或保险丝开路
#define BP_ERR_MOTOR_OPEN_CIRCUIT                   (11028000ul)    //马达开路
#define BP_ERR_WIFI                                 (11029000ul)    //WIFI模块故障
#define BP_ERR_METHOD_NOT_SUPPORT                   (11030000UL)    //设备不支持该bypass命令
#define BP_ERR_LANCOMM_CONNECTED                    (11031000UL)    // 局域网通信连接已存在
#define BP_ERR_DEFAULT_SCENE_NON_EXISTENT           (11032000UL)    // 默认场景不存在，APP通知需要升级固件
#define BP_ERR_CUSTOM_SCENE_NON_EXISTENT            (11033000UL)    // 自定义场景不存在，APP需要删除该场景
#define BP_ERR_CID_EXIST                            (11100000UL)    // cid 已存在

// 定时器相关错误码
#define BP_ERR_TIMER_EXCEED_MAX                     (11503000UL)    // timer(倒计时)个数已达上限
#define BP_ERR_TIMER_CONFIG                         (11505000UL)    // Timer倒计时时间必须大于0且小于24个小时
#define BP_ERR_TIMER_NOT_FOUND                      (11508000UL)    // 相关timer不存在
#define BP_ERR_SCHEDULE_EXCEED_MAX                  (11502000UL)    // schedule个数已达上限
#define BP_ERR_SCHEDULE_NOT_FOUND                   (11507000UL)    // 相关Schedule不存在
#define BP_ERR_SCHEDULE_CONFLICT                    (11510000UL)    // 添加或编辑Schedule与已有的冲突
#define BP_ERR_AWAY_EXCEED_MAX                      (11504000UL)    // away个数已达上限
#define BP_ERR_AWAY_NOT_FOUND                       (11509000UL)    // 相关away不存在

//净化器错误码定义
#define BP_ERR_PURIFIER_SENSOR                      (11801000UL)    //传感器故障
#define BP_ERR_PURIFIER_MOTOR                       (11802000UL)    //电机故障
#define BP_ERR_PURIFIER_RESET_FILTER                (11803000UL)    //重置滤网失败
#define BP_ERR_PURIFIER_LEVEL_EXCEED_MAX            (11804000UL)    //调整档位超出上限
#define BP_ERR_PURIFIER_LEVEL_EXCEED_MIN            (11805000UL)    //调整档位超出下限

// 加湿器错误码定义
#define BP_ERR_DRY_BURN                             (11601000UL)    // 雾化片干烧
#define BP_ERR_PTC_FAILURE                          (11602000UL)    // PTC温度故障
#define BP_ERR_HIGH_TEMP                            (11603000UL)    // 雾化板高温故障
#define BP_ERR_DETECTION_FAILURE                    (11604000UL)    // 检水板故障
#define BP_ERR_WATER_LACKS                          (11605000UL)    // 设备处于缺水状态
#define BP_ERR_WATER_TANK_LIFTED                    (11606000UL)    // 水箱被提起

//空气炸锅错误码定义
#define BP_ERR_AIRFRYER_PULL_OUT                    (11901000UL)    //炸篮拉出
#define BP_ERR_AIRFRYER_COOKING                     (11902000UL)    //设备已经处于烹饪状态
#define BP_ERR_AIRFRYER_NOT_COOKING                 (11903000UL)    //设备未处于烹饪状态

//空气烤架错误码定义
#define BP_ERR_AIRGRILL_POT_OUT                     (11905000UL)    //无锅

#define BP_ERR_OVEN_DOOR_OPEN                       (11901000UL)    //烤箱门打开
#define BP_ERR_OVEN_NOT_COOKING                     (11903000UL)    //设备未处于烹饪状态
#define BP_ERR_OVEN_NOT_FAN_SWITCH                  (11904000UL)    //当前模式不支持开关风扇

// 参数错误类型
#define BP_ERR_PARAM_TYPE               " type err"
#define BP_ERR_PARAM_MISS               " miss"
#define BP_ERR_PARAM_VAL_INVALID        " val invaild"
#define BP_ERR_PARAM_NULL_PTR           " null pointer"
#define BP_ERR_PARAM_CONV(param, type)  #param type

#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_BYPASS_ERROR_CODE_H__ */

