/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        ota_tool.c
 * @brief       ota头部生成工具
 * @author      Joshua
 * @date        2021-07-16
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdint.h>
#include <unistd.h>
#include "mbedtls/md.h"
#include "mbedtls/md5.h"
#include "vesync_aes.h"
#include "vesync_cfg_internal.h"
#include "vesync_common.h"
#include "vesync_memory.h"
#include "vesync_log.h"
#include "vesync_ota_internal.h"

//#define OTA_TOOL_DEBUG 1

#define MAX_SUPPORT_COUNTRY_NUM 10

static uint8_t s_aes_key[AES_KEY_LEN];
static uint8_t s_aes_iv[AES_KEY_LEN];


/**
 * @brief  密钥初始化
 * @return     int32_t              [错误码]
 */
static int32_t vesync_ota_tool_key_init(char *brand)
{
    VCOM_NULL_PARAM_CHK(brand, return APP_FAIL);

    mbedtls_md5_context *p_md5 = NULL;

    p_md5 = (mbedtls_md5_context*)vesync_malloc(sizeof(mbedtls_md5_context) +1);
    if (NULL == p_md5)
    {
        return APP_FAIL;
    }

    memset(s_aes_key, 0, AES_KEY_LEN);
    memset(p_md5, 0, sizeof(mbedtls_md5_context) + 1 );
    mbedtls_md5_init(p_md5);
    mbedtls_md5_starts(p_md5);
    mbedtls_md5_update(p_md5, (unsigned char *)brand, strlen(brand));
    mbedtls_md5_finish(p_md5, s_aes_key);
    mbedtls_md5_free(p_md5);

    //LOG_RAW_HEX(LOG_INFO, "ota AES Key:", s_aes_key, AES_KEY_LEN);
    VCOM_SAFE_FREE(p_md5);

    memcpy(s_aes_iv, s_aes_key, AES_KEY_LEN);
    return APP_OK;
}

/**
 * @brief  写文件
 * @param[in]  ver                  [加密版本]
 * @param[in]  data                 [写入的数据]
 * @param[in]  len                  [写入数据的长度]
 * @param[in] out_file              [写入的文件路径]
 * @return     int                  [APP_OK:成功，APP_FAIL:写入失败]
 */
static int vesync_ota_tool_file_write(uint8_t ver, uint8_t *data, uint32_t len, char *out_file)
{
    FILE *fp = NULL;

    fp = fopen(out_file, "wb+");
    if (fp == NULL)
    {
        return APP_FAIL;
    }

    fwrite(&ver, sizeof(ver), 1, fp);
    fwrite(data, len, 1, fp);
    fclose(fp);

    return APP_OK;
}


/**
 * @brief  加密写入数据
 * @param[in]  p_data               [写入的数据]
 * @param[in]  len                  [写入数据的长度]
 * @param[in]  p_encrypt            [加密的数据]
 * @param[in]  len                  [加密的长度]
 * @return     int                  [0表示写入成功，非0表示写入失败]
 */
static int vesync_ota_tool_aes_encrypt(uint8_t *p_data, uint32_t len, uint8_t **p_encrypt, uint32_t *encrypt_len)
{
    int en_len = vesync_aes_encrypt_with_key(NO_PADDING, p_data, len, p_encrypt, s_aes_key, s_aes_iv);
    if (0 == en_len)
    {
        VCOM_SAFE_FREE(p_encrypt);
        return APP_FAIL;
    }

    *encrypt_len = en_len;
    return APP_OK;
}

#if OTA_TOOL_DEBUG
/**
 * @brief  读文件
 * @param[in]  ver                  [加密版本]
 * @param[in]  data                 [读出的数据]
 * @param[in]  len                  [读出数据的长度]
 * @param[in] out_file              [读入的文件路径]
 * @return     int                  [APP_OK:成功，APP_FAIL:写入失败]
 */
static int vesync_ota_tool_file_read(uint8_t *ver, uint8_t *data, uint32_t len, char *in_file)
{
    FILE *fp = NULL;

    fp = fopen(in_file, "r");
    if (fp == NULL)
    {
        return APP_FAIL;
    }

    fread(ver, sizeof(uint8_t), 1, fp);
    fread(data, len, 1, fp);
    fclose(fp);
    return APP_OK;
}

/**
 * @brief  读取加密数据
 * @param[in]  p_data               [读取数据缓存区]
 * @param[in/out]  p_len            [当前读取的数据长度]
 * @return     uint8_t              [解密后的数据指针]
 */
static uint8_t *vesync_ota_tool_aes_decrypt(uint8_t *p_data, uint32_t *p_len)
{
    uint8_t *p_out = NULL;
    size_t encrypt_len = *p_len;
    int ret = 0;

    ret = vesync_aes_decrypt_with_key(NO_PADDING, p_data, encrypt_len, &p_out, s_aes_key, s_aes_iv);
    if (0 == ret || NULL == p_out)
    {
        return NULL;
    }

    return p_out;
}
#endif


/**
 * @brief  使用
 */
static void ota_tool_usage(void)
{
    printf( "Usage: ota_tool -t$PR_OTA_CRYPTO_TYPE -v$PR_OTA_HEADER_VER -b$PR_BRAND -m$md5str -n$PR_MODEL -s$PR_FW_VER -h$PR_HW_VER -c$PR_CTRY_LIST -f$tmp_bin\n" );
}

int main(int argc, char *argv[])
{
    int ret = SDK_FAIL;
    int ch;
    uint8_t crypto_type = 0;
    uint8_t ver = 0;
    char *brand = NULL;
    char *md5 = NULL;
    char *model = NULL;
    char *sw = NULL;
    char *hw = NULL;
    char *ctry_list = NULL;
    char *out_file = NULL;

    vesync_log_init();

    while( (ch=getopt(argc, argv, "t:v:b:m:n:s:h:c:f:")) != -1 )
    {
        switch(ch)
        {
            case 't':
                crypto_type = atoi(optarg);
                break;
            case 'v':
                ver = atoi(optarg);
                break;
            case 'b':
                brand = optarg;
                break;
            case 'm':
                md5 = optarg;
                break;
            case 'n':
                model = optarg;
                break;
                break;
            case 's':
                sw = optarg;
                break;
            case 'h':
                hw = optarg;
                break;
            case 'c':
                ctry_list = optarg;
                break;
            case 'f':
                out_file = optarg;
                break;
            default:
                ota_tool_usage();
                return -1;
        }
    }

    ret = vesync_ota_tool_key_init(brand);
    if (ret != APP_OK)
    {
        APP_LOG(LOG_ERROR, "key init fail\n");
        return -1;
    }

    vesync_ota_header_t ota_header;
    memset(&ota_header, 0, sizeof(vesync_ota_header_t));
    ota_header.ver = (uint8_t)ver;
    memcpy(ota_header.md5, (uint8_t *)md5, sizeof(ota_header.md5));
    memcpy(ota_header.model, (uint8_t *)model, sizeof(ota_header.model));
    memcpy(ota_header.sw_ver, (uint8_t *)sw, sizeof(ota_header.sw_ver));
    memcpy(ota_header.hw_ver, (uint8_t *)hw, sizeof(ota_header.hw_ver));
    memcpy(ota_header.country_list, (uint8_t *)ctry_list, sizeof(ota_header.country_list));

    uint8_t *encrypt_data = NULL;
    uint32_t encrypt_len = 0;

    if (crypto_type == 1)
    {
        // AES加密头部
        ret = vesync_ota_tool_aes_encrypt((uint8_t*)&ota_header, sizeof(vesync_ota_header_t), &encrypt_data, &encrypt_len);
        if (ret != APP_OK)
        {
            APP_LOG(LOG_ERROR, "aes crypto fail\n");
            return -1;
        }
    }
    else
    {
        APP_LOG(LOG_ERROR, "crypto type not supported yet\n");
        return -1;
    }

    vesync_ota_tool_file_write((uint8_t)crypto_type, encrypt_data, encrypt_len, out_file);

    VCOM_SAFE_FREE(encrypt_data);

#if OTA_TOOL_DEBUG
    //读入文件
    uint8_t in_ver = 0;
    uint8_t in_encrypt_data[128] = {0};
    vesync_ota_tool_file_read(&in_ver, in_encrypt_data, sizeof(vesync_ota_header_t), out_file);
    APP_LOG(LOG_DEBUG, "in_ver=%d\n", in_ver);

    // AES解密字符串
    uint32_t decrypt_len = sizeof(vesync_ota_header_t);
    uint8_t *decrypt_data = vesync_ota_tool_aes_decrypt(in_encrypt_data, &decrypt_len);
    if (decrypt_data == NULL)
    {
        APP_LOG(LOG_ERROR, "aes decrypt fail\n");
        return -1;
    }

    vesync_ota_header_t *header = (vesync_ota_header_t *)decrypt_data;
    APP_LOG(LOG_DEBUG, "h_ver:%s\n", header->ver);
    APP_LOG(LOG_DEBUG, "md5:%s\n", header->md5);
    APP_LOG(LOG_DEBUG, "model:%s\n", header->model);
    APP_LOG(LOG_DEBUG, "sw:%s\n", header->sw_ver);
    APP_LOG(LOG_DEBUG, "hw:%s\n", header->hw_ver);
    APP_LOG(LOG_DEBUG, "country_list:%s\n", header->country_list);
#endif
    return 0;
}

