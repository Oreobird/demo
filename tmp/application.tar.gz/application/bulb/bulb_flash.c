/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file        bulb_flash.c
* @brief       bulb flash接口
* @author      Dave
* @date        2021-09-02
*/
#include <stdio.h>
#include <string.h>

#include "vesync_common.h"
#include "vesync_log.h"
#include "vesync_flash.h"
#include "vesync_device.h"
#include "vesync_klv.h"
#include "vesync_memory.h"

#include "bulb_board.h"
#include "bulb_flash.h"
#include "bulb.h"

static bulb_flash_data_t s_bu_cfg;            // 当前配置

/**
 * @brief 保存灯泡数据到flash
 * @param[in]  bulb_flash_data_t  [灯泡配置]
 * @return     int8_t               [成功：0， 失败：1]
 */
int8_t bulb_save_config(bulb_flash_data_t data)
{
    int ret = 0;
    uint8_t *p_buf= NULL;
    int offset = 0;
    uint8_t version = 0;

    if(NULL == (p_buf = (uint8_t *)vesync_malloc(BULB_KLV_DATA_LEN)))
    {
        return APP_FAIL;
    }

    memset(p_buf, 0, BULB_KLV_DATA_LEN);

    //组装KLV数据
    version = BULB_APP_DATA_VERSION;
    offset += vesync_klv_set(p_buf + offset, BULB_KLV_DATA_LEN - offset, BULB_KEY_VERSION, sizeof(version), &version);
    offset += vesync_klv_set(p_buf + offset, BULB_KLV_DATA_LEN - offset, BULB_KEY_ONOFF, sizeof(data.bulb_onoff), &data.bulb_onoff);
    offset += vesync_klv_set(p_buf + offset, BULB_KLV_DATA_LEN - offset, BULB_KEY_COLOR_MODE, sizeof(data.bulb_color_mode), &data.bulb_color_mode);
    offset += vesync_klv_set(p_buf + offset, BULB_KLV_DATA_LEN - offset, BULB_KEY_COLOR_TEMP, sizeof(data.bulb_color_temp), &data.bulb_color_temp);
    offset += vesync_klv_set(p_buf + offset, BULB_KLV_DATA_LEN - offset, BULB_KEY_COLOR_BRIGHT, sizeof(data.bulb_color_bright), &data.bulb_color_bright);
    offset += vesync_klv_set(p_buf + offset, BULB_KLV_DATA_LEN - offset, BULB_KEY_COLOR_HUE, sizeof(data.bulb_color_hue), (uint8_t *)&data.bulb_color_hue);
    offset += vesync_klv_set(p_buf + offset, BULB_KLV_DATA_LEN - offset, BULB_KEY_COLOR_SATURATION, sizeof(data.bulb_color_saturation), (uint8_t *)&data.bulb_color_saturation);
    offset += vesync_klv_set(p_buf + offset, BULB_KLV_DATA_LEN - offset, BULB_KEY_COLOR_VALUE, sizeof(data.bulb_color_value), &data.bulb_color_value);
    offset += vesync_klv_set(p_buf + offset, BULB_KLV_DATA_LEN - offset, BULB_KEY_POWERNUM, sizeof(data.bulb_powernum), &data.bulb_powernum);
    offset += vesync_klv_set(p_buf + offset, BULB_KLV_DATA_LEN - offset, BULB_KEY_INIT_FLAG, sizeof(data.bulb_init_flag), &data.bulb_init_flag);
    offset += vesync_klv_set(p_buf + offset, BULB_KLV_DATA_LEN - offset, BULB_KEY_AGING_TEST, sizeof(data.bulb_aging_test), &data.bulb_aging_test);
    offset += vesync_klv_set(p_buf + offset, BULB_KLV_DATA_LEN - offset, BULB_KEY_AGING_TEST_TIME, sizeof(data.bulb_aging_test_time), &data.bulb_aging_test_time);

    //将数据写入指定flash分区
    ret = vhal_flash_write(PARTITION_CFG, BULB_USER_CFG_KEY_DATA,p_buf,offset);

    vesync_free(p_buf);

    if (VHAL_OK != ret)
    {
        APP_LOG(LOG_ERROR, "write flash fail, ret[%d]\n", ret);
        return APP_FAIL;
    }

    return APP_OK;
}

/**
 * @brief 重置灯泡状态
 * @param void
 * @return     int8_t               [成功：0， 失败：1]
 */
int bulb_reset_config(void)
{
    int ret = bulb_update_config(BULB_CFG_COLOR_BRIGHT,100);
    if (APP_OK != ret)
    {
        return APP_FAIL;
    }
    bulb_update_config(BULB_CFG_COLOR_TEMP,100);
    bulb_update_config(BULB_CFG_COLOR_HUE,0);
    bulb_update_config(BULB_CFG_COLOR_MODE,0);
    bulb_update_config(BULB_CFG_COLOR_SATURATION,10000);
    bulb_update_config(BULB_CFG_COLOR_VALUE,100);
    bulb_update_config(BULB_CFG_ONOFF,1);
    bulb_update_config(BULB_CFG_POWERNUM,0);
    bulb_resave_config();
    return ret;
}

/**
 * @brief 从flash中读取灯泡数据到内存
 * @param[out] bulb_flash_data_t  [灯泡配置]
 * @return     int8_t               [成功：0， 失败：1]
 */
int8_t bulb_read_bulb_data(bulb_flash_data_t *p_data)
{
    int ret = 0;
    uint32_t len = 0;
    uint8_t *p_buf= NULL;
    uint8_t version = 0;

    if (NULL == p_data)
    {
        APP_LOG(LOG_ERROR, "null pointer\n");
        return APP_FAIL;
    }

    if(NULL == (p_buf = (uint8_t *)vesync_malloc(BULB_KLV_DATA_LEN)))
    {
        return APP_FAIL;
    }

    len = BULB_KLV_DATA_LEN;
    if (VHAL_OK != vhal_flash_read(PARTITION_CFG, BULB_USER_CFG_KEY_DATA, p_buf, &len))
    {
        APP_LOG(LOG_WARN, "read flash fail, ret[%d]\n", ret);
        vesync_free(p_buf);
        return APP_FAIL;
    }

    vesync_klv_get(p_buf, len, BULB_KEY_VERSION, sizeof(version), &version);
    vesync_klv_get(p_buf, len, BULB_KEY_ONOFF, sizeof(p_data->bulb_onoff), &p_data->bulb_onoff);
    vesync_klv_get(p_buf, len, BULB_KEY_COLOR_MODE, sizeof(p_data->bulb_color_mode), &p_data->bulb_color_mode);
    vesync_klv_get(p_buf, len, BULB_KEY_COLOR_TEMP, sizeof(p_data->bulb_color_temp), &p_data->bulb_color_temp);
    vesync_klv_get(p_buf, len, BULB_KEY_COLOR_BRIGHT, sizeof(p_data->bulb_color_bright), &p_data->bulb_color_bright);
    vesync_klv_get(p_buf, len, BULB_KEY_COLOR_HUE, sizeof(p_data->bulb_color_hue), (uint8_t*)&p_data->bulb_color_hue);
    vesync_klv_get(p_buf, len, BULB_KEY_COLOR_SATURATION, sizeof(p_data->bulb_color_saturation), (uint8_t*)&p_data->bulb_color_saturation);
    vesync_klv_get(p_buf, len, BULB_KEY_COLOR_VALUE, sizeof(p_data->bulb_color_value), &p_data->bulb_color_value);
    vesync_klv_get(p_buf, len, BULB_KEY_POWERNUM, sizeof(p_data->bulb_powernum), &p_data->bulb_powernum);
    vesync_klv_get(p_buf, len, BULB_KEY_INIT_FLAG, sizeof(p_data->bulb_init_flag), &p_data->bulb_init_flag);
    vesync_klv_get(p_buf, len, BULB_KEY_AGING_TEST, sizeof(p_data->bulb_aging_test), &p_data->bulb_aging_test);
    vesync_klv_get(p_buf, len, BULB_KEY_AGING_TEST_TIME, sizeof(p_data->bulb_aging_test_time), &p_data->bulb_aging_test_time);

    vesync_free(p_buf);
    return APP_OK;
}

/**
 * @brief 获取灯泡的配置
 * @param[in]  BULB_CFG_FLAG_E    [标识符]
 * @return     uint8_t              [配置值]
 */
int bulb_get_config(BULB_CFG_FLAG_E flag)
{
    switch(flag)
    {
    case BULB_CFG_ONOFF:
        return s_bu_cfg.bulb_onoff;
    case BULB_CFG_COLOR_MODE:
        return s_bu_cfg.bulb_color_mode;
    case BULB_CFG_COLOR_TEMP:
        return s_bu_cfg.bulb_color_temp;
    case BULB_CFG_COLOR_BRIGHT:
        return s_bu_cfg.bulb_color_bright;
    case BULB_CFG_COLOR_HUE:
        return s_bu_cfg.bulb_color_hue;
    case BULB_CFG_COLOR_SATURATION:
        return s_bu_cfg.bulb_color_saturation;
    case BULB_CFG_COLOR_VALUE:
        return s_bu_cfg.bulb_color_value;
    case BULB_CFG_POWERNUM:
        return s_bu_cfg.bulb_powernum;
    case BULB_CFG_INIT_FLAG:
        return s_bu_cfg.bulb_init_flag;
    case BULB_CFG_AGING_TEST:
        return s_bu_cfg.bulb_aging_test;
    case BULB_CFG_AGING_TEST_TIME:
        return s_bu_cfg.bulb_aging_test_time;
    default:
        return 0xFF;
    }
}

/**
 * @brief 更新灯泡内存配置
 * @param[in]  BULB_CFG_FLAG_E    [标识符]
 * @param[in]  uint8_t              [配置值]
 * @return     int8_t               [成功：0， 失败：1]
 */
int8_t bulb_update_config(BULB_CFG_FLAG_E flag, int val)
{
    switch(flag)
    {
    case BULB_CFG_ONOFF:
        s_bu_cfg.bulb_onoff = val;
        break;
    case BULB_CFG_COLOR_MODE:
        s_bu_cfg.bulb_color_mode = val;
        break;
    case BULB_CFG_COLOR_TEMP:
        s_bu_cfg.bulb_color_temp = val;
        break;
    case BULB_CFG_COLOR_BRIGHT:
        s_bu_cfg.bulb_color_bright = val;
        break;
    case BULB_CFG_COLOR_HUE:
        s_bu_cfg.bulb_color_hue = val;
        break;
    case BULB_CFG_COLOR_SATURATION:
        s_bu_cfg.bulb_color_saturation = val;
        break;
    case BULB_CFG_COLOR_VALUE:
        s_bu_cfg.bulb_color_value = val;
        break;
    case BULB_CFG_POWERNUM:
        s_bu_cfg.bulb_powernum = val;
        break;
    case BULB_CFG_INIT_FLAG:
        s_bu_cfg.bulb_init_flag = val;
        break;
    case BULB_CFG_AGING_TEST:
        s_bu_cfg.bulb_aging_test = val;
        break;
    case BULB_CFG_AGING_TEST_TIME:
        s_bu_cfg.bulb_aging_test_time = val;
        break;
    default:
        APP_LOG(LOG_ERROR, "Unknown flag(=%d).\n", flag);
        return APP_FAIL;
    }

    return APP_OK;
}

/**
 * @brief 将内存配置重新写入flash
 * @return     int8_t               [成功：APP_OK， 失败：APP_FAIL]
 */
int bulb_resave_config(void)
{
    return (bulb_save_config(s_bu_cfg));
}

/**
 * @brief 从flash加载灯泡配置到内存
 * @param[in]  BULB_ACT_SRC_E         [动作来源]
 * @return void
 */
void bulb_load_config(BULB_ACT_SRC_E src)
{
    bulb_ev_t ev;
    memset((uint8_t *)&s_bu_cfg, 0, sizeof(bulb_flash_data_t));
    memset(&ev, 0, sizeof(ev));
    bulb_flash_data_t bu_data;
    if (APP_OK == bulb_read_bulb_data(&bu_data))
    {
        bu_data.bulb_init_flag = 1;
        s_bu_cfg = bu_data;
    }
}
