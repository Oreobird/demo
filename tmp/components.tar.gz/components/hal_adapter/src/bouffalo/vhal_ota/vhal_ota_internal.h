/**
 * Copyright © Vesync Technologies Co.Ltd. 2019-2021. All rights reserved.
 * @file    vhal_ota.h
 * @brief   ota功能实现
 * @author  Louis
 * @date    2021-03-26
 */

#ifndef __VHAL_OTA_INTERNAL_H__
#define __VHAL_OTA_INTERNAL_H__

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

#define MAX_URL_LEN             (256)
#define BUFFSIZE                4096
//#define OTA_BUFFSIZE            1300
#define MAX_TCP_BUFF_SIZE       1500        // 每1包数据长度是1460

#define BL_OTA_HEADER_LEN   (512)
#define EVERY_PACKET_LEN    (1024)
#define OTA_BUFFER_SIZE     (4096)
#define HTTP_GET "GET /%s HTTP/1.1\r\nHOST: %s\r\nAccept: */*\r\n\r\n"

/*
 * @brief ota http解析
 * @note 该定义应该放到平台层，但目前还使用乐鑫的升级程序，先放着hal层
 */
 typedef struct
{
	char host[128];
	int  port;
	char path[256];
} URLParts_t;


typedef struct ota_header {
    union {
        struct {
            uint8_t header[16];

            uint8_t type[4];//RAW XZ
            uint32_t len;//body len
            uint8_t pad0[8];

            uint8_t ver_hardware[16];
            uint8_t ver_software[16];

            uint8_t sha256[32];
        } s;
        uint8_t _pad[512];
    } u;
} ota_header_t;


typedef struct ota_info
{
    uint32_t total_len;     // 固件总大小
    uint8_t *buffer;        // 存放固件的缓存
    uint32_t flash_offset;  // 当前写入备份分区偏移
    uint32_t ota_offset;    // 写入缓存偏移
    uint32_t percent;       // 下载固件百分比
    bool header_checked;    // 固件头部是否已经检查
    bool timeout_flag;      // 是否下载超时
    VHAL_OTA_STATE_E stat;   // OTA升级状态
}ota_info_t;


typedef struct ota_cb
{
    uint32_t head_len;      // vesync再封装的固件头部大小
    vhal_ota_status_cb_t hal_stat_cb;       // 上报OTA升级状态和进度的回调函数
    vhal_ota_check_header_cb_t check_header_cb;     // 检查固件头部的回调函数
    vhal_ota_check_md5_cb_t check_md5_cb;       // 检查md5的回调函数
}ota_cb_t;



#ifdef __cplusplus
}
#endif

#endif /* __VHAL_OTA_INTERNAL_H__ */
