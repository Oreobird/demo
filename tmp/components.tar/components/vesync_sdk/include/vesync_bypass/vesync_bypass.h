/*
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file        vesync_bypass.h
* @brief       bypass处理接口
* @date        2021-05-15
*/

#ifndef __VESYNC_BYPASS_H__
#define __VESYNC_BYPASS_H__

#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>

#include "cJSON.h"
#include "vesync_bypass_method_data.h"

#ifdef __cplusplus
extern "C" {
#endif


/*
 * @brief 设备消息来源标签(MQTT/developer/Local)
 */
typedef enum
{
    MSG_TAG_NULL  = 0,          // 未知(非法制)
    MSG_TAG_DVLPR = 0x1,        // 消息来源于开发者模式
    MSG_TAG_MQTT  = 0x2,        // 消息来源于MQTT
    MSG_TAG_LOCAL = 0x4,        // 消息来源于局域网
    //MSG_TAG_HTTP  = 0x8,        // 消息来源于http
} DEV_MSG_TAG_TYPE_E; //TODO: Fix Me, 调整定义位置？？？

/*-----------------------------------------------------------------*/

#define BP_SOURCE_MAX_LEN            (16) //"source"值的最大长度
#define BP_TRACE_ID_MAX_LEN          (32) //trace id的最大长度


/**
 * @brief bypass函数返回值
 */
typedef enum
{
    BP_OK           = 0,       // 无异常
    BP_ERROR        = 1,       // 通用错误
    BP_ERR_ARG      = 2,       // 参数不合法
    BP_ERR_NOMEM    = 3,       // 内存不足
    BP_ERR_APP_CB_NULL  = 4,   // 应用层回调函数为空
    BP_ERR_UN_AUTH  = 5,       // 指令未授权
} BYPASS_ERR_E;


/**
 * @brief bypass消息来源
 */
typedef enum
{
    BP_SRC_UNKNOW        = 0,   // 来源于APP
    BP_SRC_APP,                 // 来源于APP
    BP_SRC_ALEXA,               // 来源于Alexa
    BP_SRC_IFTTT,               // 来源于IFTTT
    BP_SRC_GOOGLE,              // 来源于GoogleHome
    BP_SRC_CLOUD,               // 来源于cloud
    BP_SRC_APP_LAN,             //来源于APP局域网通信
} BYPASS_SRC_TYPE_E;


/**
 * @brief bypass trace message
 */
typedef struct
{
    char trace_id[BP_TRACE_ID_MAX_LEN];
    char src_type[BP_SOURCE_MAX_LEN];
} bypass_trace_msg_t;


/**
 * @brief bypass 命令应用层回调函数
 * @param:  p_trace_msg trace message
 * @param:  pData 数据指针
 * @param:  data_len 数据长度
 */
typedef void (*bypass_method_cb_t)(bypass_trace_msg_t *p_trace_msg, void *pData, uint16_t data_len);

/**
 * @brief bypass 命令处理函数
 * @param:  p_trace_msg trace message
 * @param:  json json数据指针
 * @return: bypass_err_t 错误码
 */
typedef BYPASS_ERR_E (*bypass_method_handle_fn_t)(bypass_trace_msg_t *p_trace_msg, cJSON *json);

/**
 * @brief 查询串口队列剩余空间回调函数
 * @return uint8_t 剩余空间数量
 */
typedef uint8_t (*bypass_get_uart_mq_freesize_cb_t)(void);



/**
 * @brief bypass 模块初始化
 */
void veysnc_bypass_init(void);


/**
 * @brief 应用层注册bypass method 回调函数
 * @param method_id method                   [对应的id]
 * @param cb bypass method                   [回调函数]
 * @return                                   [0 注册成功  -1 注册失败]
 */
int vesync_bypass_reg_mothod_cb(BYPASS_METHOD_ID_E method_id, bypass_method_cb_t cb);


/**
 * @brief bypass 消息应答函数
 * @param code                               [错误码]
 * @param p_trace_msg                        [trace message app 发送过来原样返回]
 * @param json                               [返回数据json指针， 如果没返回数据返回空指针]
 * @return bypass_err_t
 */
BYPASS_ERR_E vesync_bypass_reply_noqos(int code, const bypass_trace_msg_t *p_trace_msg, cJSON *json);


/**
 * @brief bypass异常处理，回复信息封装
 * @param[in] err_code                       [错误码]
 * @param[in] p_trace_msg                    [trace message]
 * @param[in] p_msg                          [错误消息(字符串)，支持NULL]
 */
void vesync_bypass_reply_pkg_err_msg(int err_code, bypass_trace_msg_t *p_trace_msg, char *p_msg);


#ifdef __cplusplus
}
#endif
#endif /* __VESYNC_BYPASS_H__ */

