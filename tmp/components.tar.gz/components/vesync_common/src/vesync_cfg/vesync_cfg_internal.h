/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file       vesync_cfg.h
* @brief      vesync device config information.
* @date       2022-03-03
* @note       File auto generated, DO NOT edit.
*/

#ifndef __VESYNC_CFG_INTERNAL_H__
#define __VESYNC_CFG_INTERNAL_H__

#include "vesync_cfg.h"

#ifdef __cplusplus
extern "C" {
#endif

// vesync sdk cfg
#define VESYNC_SDK_VERSION                        "v1.1.0"            // Vesync SDK 版本号

// product_cfg
#define PR_PID                                    "2lzvl8x3hshnmlwq"  // Production ID
#define PR_DEVELOPER_TASK_STACSIZE                1024*4              // 开发者模式任务堆栈大小

// event_cfg
#define PR_EVENT_TASK_STACKSIZE                   1024*6              // 事件中心主任务堆栈大小
#define PR_EVENT_QUEUE_MAX_NUM                    32                  // 事件中心队列的数量上限

// schedule_cfg
#define PR_SCHEDULE_MAX_INST_NBR                  3                   // 最大的Schedule实例数量

// timebase_cfg
#define PR_TIMEBASE_INFO_MIN_REQ_PERIOD_SEC       120                 // 时基模块最小的连续两次请求时基信息的时间间隔限制（秒）
#define PR_TIMEBASE_UPDATE_UTC_PERIOD             86400               // 时基模块同步时间的周期（秒）
#define PR_TIMEBASE_REQUEST_UTC_PERIOD            30                  // 时基模块尝试请求云时间戳的最小周期（秒）
#define PR_TIMEBASE_SNTP_EXPIRED_DURING           5400                // 时基模块判断从上一次SNTP同步到SNTP同步过期的时间间隔（秒）

// net_cfg
#define PR_NETCFG_AUTO_START                      1                   // 是否自动开启配网:0 - 不自动进入配网，1 - 自动进入配网
#define PR_BAN_BLE_BROADCAST                      0                   // 是否禁止蓝牙广播：0 - 使能蓝牙广播；1 - 禁止蓝牙广播
#define PR_PROT_HEADER_VER                        0x2                 // 协议头版本
#define PR_PROT_PAYLOAD_VER                       0x1                 // 协议数据包版本
#define PR_NETCFG_QUEUE_MAX_NUM                   5                   // 配网消息队列长度上限
#define PR_NETCFG_TASK_STACKSIZE                  1024*6              // 配网任务栈

// ble_cfg
#define PR_BLE_NETCFG_VER                         0x2                 // 蓝牙配网协议版本

// protocol_cfg
#define PR_REPORT_PROTOCOL_VER                    2                   // Report云端上报协议版本
#define PR_BYPASS_PROTOCOL_VER                    2                   // Bypass协议版本
#define PR_NET_TRANS_PROT                         0                   // 云端通信方式：0-mqtt，1-https

// ota_cfg
#define PR_OTA_TASK_STACKSIZE                     1024*4              // OTA任务栈大小
#define PR_OTA_CRYPTO_TYPE                        1                   // OTA加密类型
#define PR_OTA_HEADER_VER                         1                   // OTA头部版本

// uart_cfg
#define PR_UART_TASK_STACSIZE                     1024*4              // 串口任务栈大小

// production_cfg
#define PR_PRODUCTION_WIFI_SSID                   "linksys2020"       // 产测Wi-Fi的SSID
#define PR_PRODUCTION_WIFI_PWD                    "blue12345678"      // 产测Wi-Fi的密码
#define PR_PRODUCTION_SERVER_ADDR                 "testonline-production-mqtt.vesync.com" // 产测服务器域名
#define PR_PRODUCTION_AUTO_ENTER                  1                   // 是否自动进行产测任务
#define PR_PRODUCTION_TESTMODE_TASK_STACKSIZE     1024*4              // 产测Testmode任务堆栈大小
#define PR_PRODUCTION_PRE_TEST_MIN                0                   // 老化测试时间（分钟）

// flash_data_cfg
#define PR_NET_FLASH_VERSION                      1                   // 配网Flash数据版本
#define PR_PRODUCTION_CFG_VERSION                 1                   // 产测数据版本
#define PR_SCHEDULE_CFG_VERSION                   1                   // Schedule数据版本
#define PR_AWAY_CFG_VERSION                       1                   // Away数据版本
#define PR_DEVELOPER_CFG_VERSION                  1                   // Developer配置数据版本
#define PR_TIMEBASE_CFG_VERSION                   1                   // Timebase配置数据版本

// app_cfg
#define PR_FW_VERSION                             "1.0.06"            // min=6,max=6|本产品固件版本号,格式为“1.0.00”
#define PR_HW_VERSION                             "1.0"               // min=1,max=8|本产品硬件版本号
#define PR_BRAND                                  "Valceno"           // min=1,max=16|本产品品牌标识
#define PR_TYPE                                   "light"             // min=1,max=16|本产品类目标识
#define PR_MODEL                                  "XYD0015"           // min=1,max=16|本产品型号标识
#define PR_ALIAS_MODEL                            "XYD0015"           // min=1,max=16|本产品型号别名
#define PR_COUNTRY_CODE                           "US"                // min=1,max=3|本产品国家代码
#define PR_SUPPORT_CTRY_CODE                      "US"                // min=1,max=32|本产品国家代码（OTA）
#define PR_CONFIG_MODEL                           "VC_WFON_BLB_XYD0015_US" // min=1,max=32|本产品配置模型
#define PR_AUTHKEY                                "tewe6uodhtvhpxpxhicxfljdvpowedwr" // min=1,max=33|MQTT连接认证密钥
#define PR_INIT_TASK_STACKSIZE                    1024*4              // min=1024*2,max=1024*8|Vesync SDK 初始化任务堆栈大小
#define PR_NETCFG_MODE                            "cfg_by_ble"        // min=9,max=10|配网模式："cfg_by_ble" - 蓝牙配网； "cfg_by_ap" - AP配网
#define PR_SSID_PREFIX                            "Valceno_Colorful_Led" // min=1,max=27|WiFi配网AP SSID名称前缀字符串设置
#define PR_BLE_NAME                               "Valceno_XYD0015"   // min=1,max=29|蓝牙设备名称
#define PR_BLE_TYPE                               0x0f                // min=0x0,max=0xFF|蓝牙广播产品类型标识
#define PR_BLE_MODEL                              0x02                // min=0x0,max=0xFF|蓝牙广播产品型号标识
#define PR_BLE_CMD                                0x2                 // min=0x0,max=0xFF|蓝牙广播命令码
#define PR_TOTAL_MCU_NUM                          0                   // min=0,max=1|外挂MCU总数
#define PR_OTA_TYPE_WIFI                          1                   // min=0,max=1|WiFi OTA使能
#define PR_OTA_TYPE_BLE                           0                   // min=0,max=1|蓝牙 OTA使能
#define PR_OTA_TYPE_MCU                           0                   // min=0,max=1|MCU OTA使能, 0表示不使能MCU的OTA，>0表示使能第n路MCU的OTA
#define PR_OTA_TIMEOUT_TIME                       285000              // min=1,max=285000|OTA超时时间（秒）
#define PR_WIFI_PS_TYPE                           1                   // min=0,max=1|WiFi节能模式设置
#define PR_UART_NUM_MAX                           1                   // min=0,max=1|串口最大数量
#define PR_UART0_IDX                              0                   // min=0,max=1|串口UART0的索引号
#define PR_UART_TX_PIN_ARR                        {17}                // 串口TX脚设置数组
#define PR_UART_RX_PIN_ARR                        {16}                // 串口RX脚设置数组
#define PR_UART_BAUD_RATE_ARR                     {9600}              // 串口波特率设置数组
#define PR_UART_RESEND_CNT                        3                   // min=0,max=10|串口重发次数设置
#define PR_UART_SEND_TIMEOUT_MS                   2000                // min=1,max=10000|串口发送超时（毫秒）
#define PR_UART_PAYLOAD_MAX_LEN                   1000                // min=1,max=1000|串口收发单个包的最大长度

#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_CFG_INTERNAL_H__ */
