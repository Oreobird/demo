/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_netcfg_recv.h
 * @brief       配网模块的协议层处理
 * @author      Louis
 * @date        2021-05-21
 */

#ifndef __VESYNC_NETCFG_RCV_H__
#define __VESYNC_NETCFG_RCV_H__

#include "stdint.h"
#include "vesync_tl_frame_parse.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief error type names, used in opcode 0x8015
 */
#define NETCFG_ERR_TYPE_STR_WIFI        "wifi"
#define NETCFG_ERR_TYPE_STR_MQTT        "mqtt"

#define NETCFG_KEY_LEN                  (20)
#define VESYNC_NETCFG_BASE64_BUF_LEN    (256)
#define VESYNC_NETCFG_PUB_KEY_PEM_LEN   (384)
#define VESYNC_NETCFG_AES_KEY_LEN       (16)

/*
 * @brief 配网协议头
 */
#pragma pack(1)
typedef struct
{
    uint8_t version;            // BLE配网协议使用版本0x01，APN配网该字段意义不同，前4bit表示加密类型，后4bit表示version
    uint16_t opcode;            // 业务opcode
    uint8_t status_code;        // 状态码，用于响应
    uint8_t payload_data[0];    // 数据
}payload_info_t;
#pragma pack()

/*
 * @brief 配网过程使用到的opcode
 */
typedef enum
{
    OP_KEY_EXCHANGE     = 0x8000,       // APP <-> device, 双向，AES秘钥协商
    OP_QUERY_INFO       = 0x8010,       // APP <-> device, 双向，获取设备信息
    OP_QUERY_WIFI_LIST  = 0x8011,       // APP <-> device, 双向，查询wifi列表
    OP_CONFIG_INFO      = 0x8012,       // APP <-> device, 双向，发送配网信息
    OP_NETCFG_RESULT    = 0x8013,       // device -> APP, 单向，设备配网结果上报
    OP_NETCFG_STATUS    = 0x8014,       // device -> APP, 单向，设备连接状态上报
    OP_ERR_REPORT       = 0x8015,       // device -> APP, 单向，上报错误公共通道
    OP_CANCLE_CONFIG    = 0x8016,       // APP <-> device, 双向，取消配网
    OP_QUERY_FAIL_INFO  = 0x8017,       // APP <-> device, 双向，查询上一次配网失败的日志
    OP_CLOSE_AP         = 0x8018,       // APP <-> device, 双向，关闭Wi-Fi热点
}NETCFG_OPCODE_E;



/**
 * @brief 配网结果上报
 * @param[in]  err_code         [错误码]
 * @param[in]  err_describe     [错误描述]
 */
void vesync_netcfg_prot_report_result(const int err_code, const char *err_describe);

/**
 * @brief 配网wifi列表返回
 * @param[in] page      [需要返回的页码数]
 */
void vesync_netcfg_reply_aplist(const uint16_t page);


/**
 * @brief AP配网时局域网收包入口
 * @param[in]  p_data       [配网信息的指针]
 * @param[in]  data_len     [配网信息长度]
 */
void vesync_netcfg_lan_recv_cb(uint8_t *p_data, uint32_t data_len);


/**
 * @brief BLE配网时蓝牙收包入口
 * @param[in]   p_data          [指向收到BLE数据的缓存]
 * @param[in]   len             [BLE数据长度]
 * @param[in]   need_ack        [是否需要应答]
 */
void vesync_netcfg_ble_recv_cb(uint8_t *p_data, uint16_t len, bool need_ack);


/**
 * @brief 配网接收处理模块退出处理
 */
void vesync_netcfg_recv_deinit(void);


#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_NETCFG_RCV_H__ */

