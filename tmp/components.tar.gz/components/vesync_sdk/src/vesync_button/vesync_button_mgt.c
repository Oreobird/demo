/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_button_mgt.c
 * @brief       按键管理器接口
 * @author      Joshua
 * @date        2021-12-9
 */

#include <string.h>
#include <stdio.h>
#include <stdbool.h>

#include "vesync_common.h"
#include "vesync_log_internal.h"
#include "vesync_memory.h"
#include "vesync_button_internal.h"

static vbtn_mgt_t s_vbtn_mgt;

int vesync_btn_mgt_init(void)
{
    if (s_vbtn_mgt.init)
    {
        vesync_sleep(TICKS_INTERVAL_MS);
        if (s_vbtn_mgt.init)
        {
            SDK_LOG(LOG_ERROR, "button mgt already init\n");
            return SDK_FAIL;
        }
    }

    memset(&s_vbtn_mgt, 0, sizeof(s_vbtn_mgt));

    s_vbtn_mgt.init = true;
    s_vbtn_mgt.mutex = vesync_mutex_new();
    if (s_vbtn_mgt.mutex == NULL)
    {
        s_vbtn_mgt.init = false;
        SDK_LOG(LOG_ERROR, "mutex create fail\n");
        return SDK_FAIL;
    }

    INIT_LIST_HEAD(&s_vbtn_mgt.list);
    return SDK_OK;
}

int vesync_btn_mgt_deinit(void)
{
    vesync_btn_t *pos, *n;
    struct list_head *head;

    vesync_mutex_lock(s_vbtn_mgt.mutex);
    head = &s_vbtn_mgt.list;
    if (!list_empty(head))
    {
        list_for_each_entry_safe(pos, n, head, list)
        {
            list_del(&pos->list);
            INIT_LIST_HEAD(&s_vbtn_mgt.list);
            VCOM_SAFE_FREE(pos);
            s_vbtn_mgt.num--;
        }
    }
    vesync_mutex_unlock(s_vbtn_mgt.mutex);
  
    vesync_mutex_free(s_vbtn_mgt.mutex);

    s_vbtn_mgt.init = false;
    return SDK_OK;
}

vesync_btn_t *vesync_btn_mgt_get(uint8_t gpio)
{
    vesync_btn_t *pos, *n;
    struct list_head *head;

    vesync_mutex_lock(s_vbtn_mgt.mutex);
    head = &s_vbtn_mgt.list;
    list_for_each_entry_safe(pos, n, head, list)
    {
        if (pos->gpio == gpio)
        {
            vesync_mutex_unlock(s_vbtn_mgt.mutex);
            return pos;
        }
    }

    vesync_mutex_unlock(s_vbtn_mgt.mutex);
    return NULL;
}

int vesync_btn_mgt_add(vesync_btn_t *btn)
{
    VCOM_NULL_PARAM_CHK(btn, return SDK_FAIL);

    vesync_btn_t *pos = vesync_btn_mgt_get(btn->gpio);
    if (pos != NULL)
    {
        SDK_LOG(LOG_INFO, "already exist\n");
        return SDK_FAIL;
    }

    vesync_mutex_lock(s_vbtn_mgt.mutex);
    list_add(&btn->list, &s_vbtn_mgt.list);
    s_vbtn_mgt.num++;
    vesync_mutex_unlock(s_vbtn_mgt.mutex);

    return SDK_OK;
}

int vesync_btn_mgt_del(uint8_t gpio)
{
    vesync_btn_t *pos, *n;
    struct list_head *head;
    bool deleted = false;

    vesync_mutex_lock(s_vbtn_mgt.mutex);
    head = &s_vbtn_mgt.list;
    if (list_empty(head))
    {
        vesync_mutex_unlock(s_vbtn_mgt.mutex);
        SDK_LOG(LOG_ERROR, "button empty\n");
        return SDK_FAIL;
    }

    list_for_each_entry_safe(pos, n, head, list)
    {
        if (pos->gpio == gpio)
        {
            list_del(&pos->list);
            INIT_LIST_HEAD(&pos->list);

            VCOM_SAFE_FREE(pos);

            s_vbtn_mgt.num--;
            deleted = true;

            break;
        }
    }
    vesync_mutex_unlock(s_vbtn_mgt.mutex);

    if (!deleted)
    {
        SDK_LOG(LOG_ERROR, "deleted fail\n");
        return SDK_FAIL;
    }

    return SDK_OK;
}

int vesync_btn_event_handle(btn_handle_fn_t btn_handle)
{
    vesync_btn_t *pos, *n;
    struct list_head *head;

    if (btn_handle == NULL)
    {
        return SDK_FAIL;
    }

    vesync_mutex_lock(s_vbtn_mgt.mutex);
    head = &s_vbtn_mgt.list;
    list_for_each_entry_safe(pos, n, head, list)
    {
        btn_handle(pos);
    }
    vesync_mutex_unlock(s_vbtn_mgt.mutex);

    return SDK_OK;
}

