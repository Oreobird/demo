/**
 *  Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
 * @file        vhal_wifi_internal.h
 * @brief       封装厂家Realtek SDK提供的Wi-Fi相关接口
 * @author      Dongri.Su
 * @date        2021-04-22
 */

#ifndef __VHAL_WIFI_INTERNAL_H__
#define __VHAL_WIFI_INTERNAL_H__

#include "vesync_common.h"

#include "vhal_wifi.h"


#ifdef __cplusplus
extern "C"
{
#endif

/* NETMASK */
#define VHAL_RTL_NETMASK_ADDR0              (255)
#define VHAL_RTL_NETMASK_ADDR1              (255)
#define VHAL_RTL_NETMASK_ADDR2              (255)
#define VHAL_RTL_NETMASK_ADDR3              (0)
/* Gateway Address */
#define VHAL_RTL_GW_ADDR0                   (192)
#define VHAL_RTL_GW_ADDR1                   (168)
#define VHAL_RTL_GW_ADDR2                   (4)
#define VHAL_RTL_GW_ADDR3                   (1)



/*
 * @brief  Wi-Fi连接失败错误原因
 * @note  从components/esp32/event_default_handlers.c拷贝过来的
 */
typedef struct
{
    int err;
    const char *reason;
} wifi_reason_t;

/*
 * @brief  Wi-Fi运行配置
 * @note
 */
typedef struct
{
    VHAL_WIFI_PS_TYPE_E ps_type;                    // Wi-Fi节能模式
    vhal_wifi_sta_cfg_t sta_cfg;                    // Wi-Fi的ssid和pwd，用于重连
    char country_code[CONUTRY_CODE_STR_MAX_LEN + 1];// 国家码
    char hostname[DHCP_HOST_NAME_MAX_LEN];          // DHCP hostname
} vhal_rtl_wifi_cfg_t;

/*
 * @brief  Wi-Fi运行状态
 * @note
 */
typedef struct
{
    int32_t chan;                                   // 当前工作信道
    rtw_mode_t mode;                                // Wi-Fi工作模式（STA/AP/APSTA）
    bool scan_flag;                                 // Wi-Fi扫描列表标志位，true表示正在扫描
    bool stop_flag;                                 // Wi-Fi停止标志位，true表示应用层主动停止Wi-Fi连接，忽略event中的disconnect事件
    bool start_flag;                                // 开始连接标志位，true表示已启动连接，false表示未启动连接
    VHAL_WIFI_STATUS_E net_status;                  // 当前网络状态(Wi-Fi)

    // 回调函数指针
    vhal_wifi_status_cb_t status_cb;                // Wi-Fi连接状态回调函数指针
    vhal_wifi_scan_cb_t scan_cb;                    // 保存扫描结果到WiFi扫描列表管理模块回调函数
    vhal_wifi_disc_log_cb_t disc_log_cb;            // Wi-Fi异常断开连接时传递错误码和错误描述的callback
} vhal_rtl_wifi_status_t;


#ifdef __cplusplus
}
#endif

#endif /* __VHAL_WIFI_INTERNAL_H__ */

