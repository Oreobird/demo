#include "vhal_led.h"
#include "vhal_gpio.h"
#include "led_strip.h"
#include "led_display.h"
#include "vesync_memory.h"

#include "vesync_log.h"
#include "led_strip_board.h"
#include "led_strip_led_drv.h"

/**
 * @brief led颜色数组,目前乐鑫sdk中需要赋值的参数，还不了解怎么使用，保留部分值
 */
const uint8_t rgb_gradient[ 3][3] ={{255, 0, 0}, {254, 1, 0}, {253, 2, 0}};
const uint8_t rgb_base[1][3] ={{0, 50, 0}};


void manual_configuration(rgb_config_t *rgb_config)
{
    rgb_config->audio_samplerate     = AUDIO_SAMPLE;
    rgb_config->n_samples            = N_SAMPLES;
    rgb_config->min_sound_threshold  = MINIMUM_SOUND;
    rgb_config->min_freq_threshold   = MINIMUM_FREQ;
    rgb_config->leds_total_number    = MAX_LED_NUM;
    rgb_config->yuv_flag             = 0;
    rgb_config->gradient_method_type = METHOD_ARRAY;
}

/**
 * @brief      Change the base color function
 *
 * @param[in]  method                Color base
 *
 * @return
 *      - rgb_color_t                The rgb value
 */
rgb_color_t *change_color_base_cb(rgb_assign_method_t *method)
{
    rgb_color_t *rgb_color = (rgb_color_t *)vesync_malloc(sizeof(rgb_color_t));
    if (method->type)
    {
        static int32_t change_color = 0;
        uint32_t (*p)[3];
        p = (uint32_t (*)[3])method->rgb_assign_array;
        rgb_color->green = **(p + change_color);
        rgb_color->red   = *(*(p + change_color) + 1);
        rgb_color->blue  = *(*(p + change_color) + 2);
        change_color++;
        if (change_color > method->rgb_assign_array_rows)
        {
            change_color = 0;
        }
    }
    else
    {
        method->rgb_assign_func(rgb_color);
    }
    return rgb_color;
}

/**
 * @brief      Configure RMT and initialize ws2812
 *
 * @param[in]  gpio_io_num           Pin used to send signal
 * @param[in]  rmt_tx_channel        RMT TX channel
 * @param[in]  led_numbers           The number of enabled LEDs
 *
 * @return
 *      - ESP_OK
 *      - ESP_FAIL
 */
led_strip_t *rmt_ws2812_init(gpio_num_t gpio_io_num, rmt_channel_t rmt_tx_channel, int32_t led_numbers)
{
    /* Configure the RGB signal control pin to use rmt to send commands */
    rmt_config_t config = RMT_DEFAULT_CONFIG_TX(gpio_io_num, rmt_tx_channel);
    config.clk_div = 2;                          /* set counter clock to 40MHz */
    ESP_ERROR_CHECK(rmt_config(&config));
    ESP_ERROR_CHECK(rmt_driver_install(config.channel, 0, 0));

    /* Initialize ws2812 */
    led_strip_config_t strip_config = LED_STRIP_DEFAULT_CONFIG(led_numbers + 1, (led_strip_dev_t)config.channel);
    led_strip_t *strip = led_strip_new_rmt_ws2812(&strip_config);
    return strip;
}

/**
* @brief  RGB灯驱动初始化
* @return     led_rgb_handle_t             [驱动控制结构体指针]
*/
led_rgb_handle_t * led_strip_rgb_ctrl_init(void)
{
    led_rgb_handle_t *led_rgb_handle = NULL ;
    rgb_config_t rgb_config   = DEFAULT_ESP_LED_STRIP_SET_CONFIG_POINTER();
    rgb_config.rgb_assign_array   = (uint32_t *)rgb_gradient;       /* Color rgb array */
    rgb_config.rgb_assign_array_rows = sizeof(rgb_gradient) / sizeof(rgb_gradient[0]);
    rgb_config.base_color     = change_color_base_cb;
    manual_configuration(&rgb_config);
    led_rgb_handle = led_display_init(&rgb_config);

    /* Configure RMT and initialize ws2812 */
    led_rgb_handle->strip = rmt_ws2812_init(LED_CTRL_IO, RMT_TX_CHANNEL, MAX_LED_NUM);
    return led_rgb_handle;
}

/**
* @brief  灯带电源配置
* @return     int             [成功/失败]
*/
void  led_strip_power_ctrl_init(void)
{
    vhal_gpio_config_t power_io;
    power_io.pin_bit_mask = (1ULL << POWER_IO_NUM);
    power_io.mode = GPIO_MODE_OUT;
    power_io.pull_up_en = GPIO_PULLUP_EN;
    power_io.pull_down_en = GPIO_PULLDOWN_DIS;
    power_io.intr_type = GPIO_INTR_DIS;
    vhal_gpio_init(power_io);
    vhal_gpio_set_output(POWER_IO_NUM, 1);
}

/**
* @brief  设置灯带电源IO电平
* @param[in]  level           [IO电平]
* @return     int             [成功/失败]
*/
void  led_strip_set_power_io(uint8_t level)
{
    vhal_gpio_set_output(POWER_IO_NUM, level);
}


/**
* @brief  白灯驱动初始化
* @return     int             [成功/失败]
*/
int  led_strip_white_ctrl_init(void)
{
    int ret = 0;
    // led pwm timer配置
    vhal_led_timer_cfg_t led_timer_cfg =
    {
     .duty_resolution = LED_DUTY_RST_11_BIT,
     .freq_hz = 5000,
    };
    ret = vhal_led_timer_cfg(&led_timer_cfg);
    if (0 == ret)
    {
     // led gpio 配置
     vhal_led_gpio_cfg_t gpio_cfg = {.gpio_num = WHITE_LED_NUM, .channel = WHITE_LED_CHANNEL, .duty = 0,};
     ret = vhal_led_gpio_cfg(1, &gpio_cfg);
    }
    if (0 != ret)
    {
        APP_LOG(LOG_ERROR, "init faild!\n");
    }
    else
    {
        vhal_led_set_duty(WHITE_LED_CHANNEL, 0);
    }

    return ret;
}

/**
* @brief  白灯脉宽设置
* @param[in]  pulse           [脉冲宽度]
* @return     int             [成功/失败]
*/
int  led_strip_set_white_pulse(uint8_t pulse)
{
    vhal_led_set_duty(WHITE_LED_CHANNEL, pulse);

    return 0;
}


