/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_security.c
 * @brief       AES加解密相关接口
 * @author      Joshua
 * @date        2021-04-26
 */

#include "vesync_aes_internal.h"

#include "vesync_memory.h"
#include "vesync_log_internal.h"
#include "vesync_base64.h"
#include "vesync_aes.h"
#include "vesync_common.h"

#include "vhal_utils.h"
#include <stdio.h>

static uint8_t AES_KEY[AES_KEY_LEN]/* =
{
    0x6c, 0x6c, 0x77, 0x61, 0x6e, 0x74, 0x61, 0x65,
    0x73, 0x6b, 0x65, 0x79, 0x31, 0x2e, 0x30, 0x31
}*/;

static uint8_t AES_IV[AES_KEY_LEN]/* =
{
    0x6c, 0x6c, 0x77, 0x61, 0x6e, 0x74, 0x61, 0x65,
    0x73, 0x69, 0x76, 0x76, 0x31, 0x2e, 0x30, 0x31
}*/;

/**
 * @brief AES初始化
 * @note 如果需要修改AES KEY，请修改KEY值，然后生成新的base64码填入base64_buf
*/
void vesync_aes_init(void)
{
#if 1
    unsigned char base64_buf[] = {'b', 'G', 'x', '3', 'Y', 'W', '5', '0', 'Y', 'W', 'V', 'z', 'a',
                                    '2', 'V', '5', 'M', 'S', '4', 'w', 'M', 'Q', '=', '='};
    uint32_t len = AES_KEY_LEN;
    size_t olen = 0;
    memset(AES_KEY, 0, sizeof(AES_KEY));
    memset(AES_IV, 0, sizeof(AES_IV));
    if (SDK_OK != vesync_base64_decode(AES_KEY, len, &olen, base64_buf, sizeof(base64_buf)))
    {
        SDK_LOG(LOG_ERROR, "aes_key decode ERROR\n");
        // how to deal?
    }
    memcpy(AES_IV, AES_KEY, AES_KEY_LEN);
    //LOG_RAW_HEX(LOG_DEBUG, "AES KEY: ", AES_KEY, AES_KEY_LEN);
#else
    unsigned char *base64_buf = NULL;
    size_t olen = 0;

    size_t buf_len = ((sizeof(AES_KEY) + 2) / 3) * 4 + 1; //ceil(len/3)*4 + 1;
    base64_buf = vesync_malloc(sizeof(unsigned char)*buf_len);
    if (base64_buf == NULL)
    {
        return;
    }

    memset(base64_buf, 0, buf_len);

    int ret = vesync_base64_encode(base64_buf, buf_len, &olen, AES_KEY, sizeof(AES_KEY));
    if (ret != SDK_OK)
    {
        vesync_free(base64_buf);
        return;
    }
    SDK_LOG(LOG_DEBUG, "base64 of aes_key:\n %s\n", base64_buf);
    vesync_free(base64_buf);
#endif
}

/**
 * @brief AES密钥注册
 * @param[in]  pKey                 [密钥128bits]
 * @param[in]  pIV                  [IV初始向量128bits]
 * @return     void                 [无]
*/
void vesync_aes_reg_key(uint8_t *pKey, uint8_t *pIV)
{
    VCOM_NULL_PARAM_CHK(pKey, return);
    VCOM_NULL_PARAM_CHK(pIV, return);

    memcpy(AES_KEY, pKey, AES_KEY_LEN);
    memcpy(AES_IV, pIV, AES_KEY_LEN);
}

/**
 * @brief  AES加密
 * @param[in]  padding              [padding类型]
 * @param[in]  in_data              [待加密的数据]
 * @param[in]  in_len               [待加密数据的长度]
 * @param[out] out_data             [加密后的数据]
 * @param[in]  p_key                [加密密钥]
 * @param[in]  p_iv                 [加密向量]
 * @return     int                  [加密后的数据长度，为0则加密失败]
*/
int vesync_aes_encrypt_with_key(AES_PADDING_E padding, uint8_t* in_data, int in_len, uint8_t** out_data, uint8_t *p_key, uint8_t *p_iv)
{
    int out_len = 0;
    int idx = 0;
    int remainder_len = in_len % AES_KEY_LEN;
    int padding_len = 0;
    uint8_t *output = NULL;
    static uint8_t padding_arr[AES_KEY_LEN + 1] = {0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f, 0x10};

    VCOM_NULL_PARAM_CHK(in_data, return 0);
    VCOM_NULL_PARAM_CHK(out_data, return 0);

    if (padding != NO_PADDING)
    {
        padding_len = remainder_len > 0 ? (AES_KEY_LEN - remainder_len) : AES_KEY_LEN;       // 填充长度
    }

    out_len = in_len + padding_len;
    // 以输出数据的长度为准，16的倍数
    output = (uint8_t *)vesync_malloc(out_len);
    if(NULL == output)
    {
        SDK_LOG(LOG_ERROR, "AES encrypt malloc memory fail!\n");
        return 0;
    }

    // PKCS5Padding/PKCS7Padding填充
    memset(output, 0, out_len);
    memcpy(output, in_data, in_len);
    if (padding_len > 0)
    {
        for (idx = 0; idx < padding_len; idx++)
        {
            output[in_len + idx] = padding_arr[padding_len];
        }
    }

    //LOG_RAW_HEX(LOG_DEBUG, "PKCS7Padding:", output, outLen);

    AES128_CBC_encrypt_buffer(output, output, out_len, p_key, p_iv);

    *out_data = output;

    return out_len;
}

/**
 * @brief  AES解密
 * @param[in]  padding              [padding类型]
 * @param[in]  in_data              [待解密的数据]
 * @param[in]  in_len               [待解密数据的长度]
 * @param[out] out_data             [解密后的数据]
 * @param[in]  p_key                [加密密钥]
 * @param[in]  p_iv                 [加密向量]
 * @return int                      [解密后的数据长度，为0则解密失败]
*/
int vesync_aes_decrypt_with_key(AES_PADDING_E padding, uint8_t* in_data, int in_len, uint8_t** out_data, uint8_t *p_key, uint8_t *p_iv)
{
    uint8_t padding_ch = 0x0;
    uint8_t *input = NULL;
    uint8_t *output = NULL;
    static uint8_t padding_arr[AES_KEY_LEN + 1] ={0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f, 0x10};
    int out_len = 0;
    int idx = 0;
    int remainder_len = in_len % AES_KEY_LEN;
    int padding_len = 0;

    VCOM_NULL_PARAM_CHK(in_data, return 0);
    VCOM_NULL_PARAM_CHK(out_data, return 0);

    if (padding != NO_PADDING)
    {
        padding_len = remainder_len > 0 ? (AES_KEY_LEN - remainder_len) : 0; // 填充长度
    }

    out_len = in_len + padding_len;
    if (0 == out_len)
    {
        return 0;
    }
    //以输出数据的长度为准，16的倍数
    input = (uint8_t *)vesync_malloc(out_len);
    if(NULL == input)
    {
        SDK_LOG(LOG_ERROR, "AES decrypt malloc memory fail!\n");
        return 0;
    }

    output = (uint8_t *)vesync_malloc(out_len);
    if(NULL == output)
    {
        SDK_LOG(LOG_ERROR, "AES decrypt malloc memory fail!\n");
        vesync_free(input);
        return 0;
    }

    memset(input, 0, out_len);
    memset(output, 0, out_len);
    memcpy(input, in_data, in_len);

#if 0
    SDK_LOG(LOG_ERROR, "remainder_len = %d, padding_len= %d, AES_KEY_LEN = %d, in_len = %d\n", remainder_len, padding_len, AES_KEY_LEN, in_len);
    LOG_RAW_HEX(LOG_DEBUG, "AES enc PKCS7Padding:", input, in_len);
#endif
    AES128_CBC_decrypt_buffer(output, input, out_len, p_key, p_iv);
#if 0
    LOG_RAW_HEX(LOG_DEBUG, "AES dec PKCS7Padding:", output, out_len);
    LOG_RAW_HEX(LOG_DEBUG, "AES_KEY:", AES_KEY, 16);
    LOG_RAW_HEX(LOG_DEBUG, "AES_IV:", AES_IV, 16);
#endif

    if (padding != NO_PADDING)
    {
        // PKCS5Padding/PKCS7Padding填充
        padding_len = 0;
        if ((uint8_t)output[out_len - 1] <= (uint8_t)padding_arr[AES_KEY_LEN])
        {
            for (idx = 1; idx <= AES_KEY_LEN; idx++)
            {
#if 0
                SDK_LOG(LOG_DEBUG, "idx = %d/%d, %02x, %02x\n", idx, AES_KEY_LEN, output[out_len - 1], padding_arr[idx]);
#endif
                if (output[out_len - 1] == padding_arr[idx]) // 查找填充的个数
                {
                    SDK_LOG(LOG_DEBUG, "idx = %d\n", idx);
                    padding_ch = padding_arr[idx];
                    padding_len = idx; // 填充的长度
                    break;
                }
            }

            if (padding_len > 0) // 有填充字符
            {
                if (out_len < padding_len)
                {
                    SDK_LOG(LOG_ERROR, "AES decrypt error padding_len = %d\n", padding_len);
                    vesync_free(input);
                    vesync_free(output);
                    return 0;
                }

                for (idx = 0; idx < padding_len; idx++)
                {
                    if (output[out_len - padding_len + idx] != padding_ch)
                    {
#if 0
                        SDK_LOG(LOG_ERROR, "[%d] Error output[%d] = %02x\n", idx, outLen - padding_len + idx, output[outLen - padding_len + idx]);
#endif
                        LOG_RAW_HEX(LOG_INFO, "AES DEC MSG:", output, out_len);
                        vesync_free(input);
                        vesync_free(output);
                        return 0;
                    }
                }

                // 删除填充
                out_len -= padding_len;
                output[out_len] = '\0';
            }
        }
    }

    *out_data = output;
    vesync_free(input);

    return out_len;
}


/**
 * @brief  AES加密，使用PKCS7padding
 * @param[in]  in_data              [待加密的数据]
 * @param[in]  in_len               [待加密数据的长度]
 * @param[out] out_data             [加密后的数据]
 * @return     int                  [加密后的数据长度，为0则加密失败]
*/
int vesync_aes_encrypt(uint8_t* in_data, int in_len, uint8_t** out_data)
{
    return vesync_aes_encrypt_with_key(PKCS7_PADDING, in_data, in_len, out_data, AES_KEY, AES_IV);
}

/**
 * @brief  AES解密，使用PKCS7padding
 * @param[in]  in_data              [待解密的数据]
 * @param[in]  in_len               [待解密数据的长度]
 * @param[out] out_data             [解密后的数据]
 * @return int                      [解密后的数据长度，为0则解密失败]
*/
int vesync_aes_decrypt(uint8_t* in_data, int in_len, uint8_t** out_data)
{
    return vesync_aes_decrypt_with_key(PKCS7_PADDING, in_data, in_len, out_data, AES_KEY, AES_IV);
}

/**
 * @brief 通过随机数生成AES密钥
 * @param[in]  pKey                 [生成的AES密钥]
 * @param[in]  size                 [密钥长度]
 * @return int                      [成功返回SDK_OK, 失败返回SDK_FAIL]
 */
int vesync_aes_generate_key(uint8_t *pKey, int size)
{
    int i = 0, j = 0;
    int cnt = 10;   // 最大生成10次
    bool flag = false;

    VCOM_NULL_PARAM_CHK(pKey, return SDK_FAIL);
    if (size <= 0)
    {
        return SDK_FAIL;
    }

    for (i = 0; i < cnt; i++)
    {
        vhal_utils_get_random(pKey, size);
        for (j = 0; j < size; j++)
        {
            if (0x0 == pKey[j])
            {
                break;
            }
        }

        if (j >= size)
        {
            flag = true;
            break;      // 已经生成合法的秘钥
        }
    }

    //SDK_LOG(LOG_WARN, "i = %d.\n", i);
    // 10次都没生成合法的秘钥，采用默认秘钥
    if (!flag)
    {
        for (j = 0; j < size; j++)
        {
            pKey[j] = AES_KEY[j];
        }
        SDK_LOG(LOG_WARN, "Use default AES key.\n");
    }

    return SDK_OK;
}

