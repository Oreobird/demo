/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        bulb_report.h
 * @brief       bulb状态上报
 * @author      Dave
 * @date        2021-09-09
 */

#include <string.h>

#include "cJSON.h"

#include "vesync_common.h"
#include "vesync_log.h"
#include "vesync_device.h"
#include "vesync_report.h"

#include "bulb.h"
#include "bulb_report.h"
#include "bulb_flash.h"
#include "bulb_bypass.h"


static void pack_mode_info_json(cJSON *obj, int color_mode)
{
    cJSON *sub_obj = NULL;

    cJSON_AddStringToObject(obj, "mode", bulb_bp_get_color_mode_str(color_mode));
    switch (color_mode)
    {
    case BULB_CFG_COLOR_MODE_WHITE:
        cJSON_AddNumberToObject(obj, "colorTempe", bulb_flash_get_cfg(BULB_CFG_COLOR_TEMP));
        cJSON_AddNumberToObject(obj, "brightness", bulb_flash_get_cfg(BULB_CFG_COLOR_BRIGHT));
        break;
    case BULB_CFG_COLOR_MODE_HSV:
        cJSON_AddItemToObject(obj, "hsvMode", sub_obj = cJSON_CreateObject());
        cJSON_AddNumberToObject(sub_obj, "hue", bulb_flash_get_cfg(BULB_CFG_COLOR_HUE));
        cJSON_AddNumberToObject(sub_obj, "saturation", bulb_flash_get_cfg(BULB_CFG_COLOR_SATURATION));
        cJSON_AddNumberToObject(sub_obj, "value", bulb_flash_get_cfg(BULB_CFG_COLOR_VALUE));
        break;
    case BULB_CFG_COLOR_MODE_SCENARIO:
        cJSON_AddNumberToObject(obj, "sceneId", bulb_flash_get_cfg(BULB_CFG_SCENE_ID));
        break;
    case BULB_CFG_COLOR_MODE_PHONE_MIC:
        // fall-through
    case BULB_CFG_COLOR_MODE_PHONE_MUSIC:
        cJSON_AddNumberToObject(obj, "effect", bulb_flash_get_cfg(BULB_CFG_EFFECT));
        cJSON_AddItemToObject(obj, "sensitive", sub_obj = cJSON_CreateObject());
        cJSON_AddNumberToObject(sub_obj, "type", bulb_flash_get_cfg(BULB_CFG_SENSITIVE_TYPE));
        cJSON_AddNumberToObject(sub_obj, "sensitive", bulb_flash_get_cfg(BULB_CFG_SENSITIVE_VALUE));
        break;
    default:
        break;
    }
}

int bulb_report_status_change(const char *chg_rsn)
{
    int ret = APP_FAIL;

    cJSON *json_chg_stat = NULL;
    cJSON *json_unchg_stat = NULL;

    cJSON *json_data = cJSON_CreateObject();
    if (NULL == json_data)
    {
        APP_LOG(LOG_ERROR, "create object fail");
        return APP_FAIL;
    }

    cJSON_AddItemToObject(json_data, "changedStatus", json_chg_stat = cJSON_CreateObject());
    cJSON_AddItemToObject(json_data, "unchangedStatus", json_unchg_stat = cJSON_CreateObject());
    if (NULL == json_chg_stat || NULL == json_unchg_stat)
    {
        APP_LOG(LOG_ERROR, "create object fail\n");
        ret = APP_FAIL;
        goto exit;
    }

    cJSON_AddStringToObject(json_data, "changeReason", (char *)chg_rsn);

    cJSON *status_slot = NULL;
    // 当changeReason为Setup/Reconnect/Unknown时，所有状态放在 unchangedStatus
    if (0 == strcmp((char *)chg_rsn, STAT_CHG_RSN_NONE_STR) ||
        0 == strcmp((char *)chg_rsn, STAT_CHG_RSN_CONFIG_NET_STR) ||
        0 == strcmp((char *)chg_rsn, STAT_CHG_RSN_RECONNECT_STR))
    {
        status_slot = json_unchg_stat;
    }
    else
    {
        status_slot = json_chg_stat;
    }

    int color_mode = bulb_flash_get_cfg(BULB_CFG_COLOR_MODE);
    if (false == bulb_flash_get_cfg(BULB_CFG_ONOFF))
    {
        cJSON_AddStringToObject(status_slot, "action", "off");
    }
    else
    {
        cJSON_AddStringToObject(status_slot, "action",  "on");
        pack_mode_info_json(status_slot, color_mode);
    }

    // 上报设备的状态改变
    if (SDK_OK != vesync_report_status_change_nty(json_data))
    {
        return APP_FAIL;
    }
    return APP_OK;
exit:
    cJSON_Delete(json_data);
    return ret;
}

int bulb_report_timing_exec(void *action, uint8_t ret, char *p_err_msg)
{
    // 参数判断
    if (NULL == action || NULL == p_err_msg)
    {
        return APP_FAIL;
    }

    cJSON *json_data = cJSON_CreateObject();
    if (NULL == json_data)
    {
        APP_LOG(LOG_ERROR, "create object fail\n");
        return APP_FAIL;
    }

    cJSON_AddStringToObject(json_data, "subDeviceType", "bulb");
    if (false == ((bulb_action_t *)action)->onoff)
    {
        cJSON_AddStringToObject(json_data, "act", "timer exec: switch=off");
    }
    else
    {
        cJSON_AddStringToObject(json_data, "act", "timer exec: switch=on");
        pack_mode_info_json(json_data, ((bulb_action_t *)action)->mode);
    }
    if (APP_OK == ret)
    {
        cJSON_AddStringToObject(json_data, "result", "success");
    }
    else
    {
        cJSON_AddStringToObject(json_data, "result", "fail");
        cJSON_AddStringToObject(json_data, "reason", p_err_msg);
    }
    // 上报设备的运行日志
    if (SDK_OK != vesync_report_device_log(json_data))
    {
        return APP_FAIL;
    }

    return APP_OK;
}

int bulb_report_schedule_exec(vesync_schedule_t *sch_cfg, void *action, uint8_t ret, char *p_err_msg)
{
    // 参数判断
    if (NULL == action || NULL == p_err_msg)
    {
        return APP_FAIL;
    }

    cJSON *json_data = cJSON_CreateObject();
    if (NULL == json_data)
    {
        APP_LOG(LOG_ERROR, "create object fail\n");
        return APP_FAIL;
    }

    cJSON_AddNumberToObject(json_data, "schID", sch_cfg->id);
    cJSON_AddNumberToObject(json_data, "type", sch_cfg->type);
    cJSON_AddNumberToObject(json_data, "repeat", sch_cfg->repeat_config);
    if (false == ((bulb_action_t *)action)->onoff)
    {
        cJSON_AddStringToObject(json_data, "act", "sche exec: switch=off");
    }
    else
    {
        cJSON_AddStringToObject(json_data, "act", "sche exec: switch=on");
        pack_mode_info_json(json_data, ((bulb_action_t *)action)->mode);
    }
    if (APP_OK == ret)
    {
        cJSON_AddStringToObject(json_data, "result", "success");
    }
    else
    {
        cJSON_AddStringToObject(json_data, "result", "fail");
        cJSON_AddStringToObject(json_data, "reason", p_err_msg);
    }
    if (SDK_OK != vesync_report_device_log(json_data))
    {
        return APP_FAIL;
    }

    return APP_OK;
}
