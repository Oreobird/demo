/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_srpc_recv.c
 * @brief       vesync SRPC 模块的主接口实现
 * @author      Herve
 * @date        2021-12-28
 */
#include <stdio.h>
#include <string.h>

#include "vesync_srpc_private.h"

#include "vesync_bypass_internal.h"
#include "vesync_log_internal.h"
#include "vesync_ble_internal.h"

#include "vesync_common.h"


/**
 * @brief SRPC接收Bypass JSON数据处理回调
 * @param[in]   p_msg               [Bypass Message JSON对象]
 */
static void srpc_recv_bypass_data_event_cb(cJSON *p_msg)
{
    vesync_bypass_json_msg_handle(p_msg, MSG_TAG_SRPC);
}

int vesync_srpc_init(void)
{
    // 注册蓝牙CMD通道数据接收处理回调
    vesync_ble_muxer_add_rxer(srpc_tl_data_recv_cb);

    // 注册SRPC Request接收JSON处理回调
    srpc_reg_request_recv_cb(srpc_recv_bypass_data_event_cb);

    return SDK_OK;
}