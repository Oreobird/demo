/**
 *  Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vhal_i2c.h
 * @brief       i2c读写接口
 * @date        2021-04-22
 */

#ifndef _VHAL_I2C_H_
#define _VHAL_I2C_H_

#include <stdint.h>

#ifdef __cplusplus
extern "C"
{
#endif

/**
 * @brief  iic初始化为主机模式
 * @param[in]  i2c_num              [iic编号，0或1]
 * @param[in]  sda_io               [SDA数据线引脚]
 * @param[in]  scl_io               [SCL时钟线引脚]
 * @param[in]  speed                [通信速率]
 * @return     int32_t              [初始化结果，0为成功，其他值表示失败]
 */
int32_t vhal_i2c_master_init(uint8_t i2c_num, uint8_t sda_io, uint8_t scl_io, uint32_t speed);

/**
 * @brief  iic读取客户端数据
 * @param[in]  i2c_num              [iic编号，0或1]
 * @param[in]  addr                 [操作的地址]
 * @param[in]  p_data               [读取的数据缓存buffer]
 * @param[in]  len                  [读取的数据大小]
 * @return     int32_t              [读取结果，0为成功，其他值表示失败]
 * @note
 *_______________________________________________________________________________________
 * | start | slave_addr + rd_bit +ack | read n-1 bytes + ack | read 1 byte + nack | stop |
 * --------|--------------------------|----------------------|--------------------|------|
 */
int32_t vhal_i2c_master_read(uint8_t i2c_num, uint8_t addr, uint8_t *data, int32_t len);

/**
 * @brief  iic写数据到客户端
 * @param[in]  i2c_num              [iic编号，0或1]
 * @param[in]  addr                 [操作的地址]
 * @param[in]  p_data               [待写入的数据]
 * @param[in]  len                  [待写入的数据大小]
 * @return     int32_t              [写入结果，0为成功，其他值表示失败]
 * @note
 * ___________________________________________________________________
 * | start | slave_addr + wr_bit + ack | write n bytes + ack  | stop |
 * --------|---------------------------|----------------------|------|
 */
int32_t vhal_i2c_master_write(uint8_t i2c_num, uint8_t addr, uint8_t *p_data, int32_t len);

/**
 * @brief  iic总线单独写stop信号到客户端
 * @param[in]  i2c_num              [iic编号，0或1]
 * @return     int32_t              [写入结果，0为成功，其他值表示失败]
 */
int32_t vhal_i2c_master_write_stop_condition(uint8_t i2c_num);


#ifdef __cplusplus
}
#endif

#endif /* _VHAL_I2C_H_ */

