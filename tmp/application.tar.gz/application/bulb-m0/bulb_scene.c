/**
 * Copyright © Vesync Technologies Co.Ltd. 2022. All rights reserved.
 * @file        bulb_scene.c
 * @brief       bulb场景功能实现
 * @author      Herve.Lin
 * @date        2022-01-19
 */
#include "stdio.h"

#include "bulb_scene.h"
#include "bulb_status.h"
#include "bulb_flash.h"
#include "bulb_color_tbl.h"

#include "vhal_flash.h"

#include "vesync_log.h"
#include "vesync_common.h"
#include "vesync_list.h"
#include "vesync_memory.h"
#include "vesync_buffer.h"
#include "vesync_timer.h"

#define BULB_SCENE_VER_CFG_KEY "bulb_scene_ver"
#define BULB_SCENE_NUM_CFG_KEY "bulb_scene_num"
#define BULB_SCENE_INS_CFG_KEY "bulb_scene:"
#define BULB_SCENE_OFS_CFG_KEY "bulb_scene_ofs"

#define BULB_SCENE_CFG_VERSION (1)
#define BULB_SCENE_DEFAULT_FLOW_MODE_INTERVAL_MS (1000)
#define BULB_SCENE_DEFAULT_CHANGE_MODE_INTERVAL_MS (500)
#define BULB_SCENE_DEFAULT_BREATH_MODE_INTERVAL_MS (1500)
#define BULB_SCENE_DEFAULT_FLASH_MODE_INTERVAL_MS (500)

static void scene_default_flow_mode_cb(void *arg)
{
    vesync_timer_t *self = *(vesync_timer_t **)arg;
    static uint8_t index = 0;
    if (index >= BULB_HSV_RAINBOW_TBL_LEN)
    {
        index = 0;
    }
    bulb_status_direct_set_hsv(g_hsv_rainbow_tbl[index], 0.01);
    index++;
    bulb_status_timer_change_period(self, BULB_SCENE_DEFAULT_FLOW_MODE_INTERVAL_MS);
}

static void scene_default_change_mode_cb(void *arg)
{
    vesync_timer_t *self = *(vesync_timer_t **)arg;
    static uint8_t index = 0;
    if (index >= BULB_HSV_RAINBOW_TBL_LEN)
    {
        index = 0;
    }
    bulb_status_direct_set_hsv(g_hsv_rainbow_tbl[index], 1.0);
    index++;
    bulb_status_timer_change_period(self, BULB_SCENE_DEFAULT_CHANGE_MODE_INTERVAL_MS);
}

static void scene_default_breath_mode_cb(void *arg)
{
    vesync_timer_t *self = *(vesync_timer_t **)arg;
    static uint8_t index = 0;
    static bool is_upward = true;
    if (is_upward)
    {
        if (index >= BULB_HSV_RAINBOW_TBL_LEN)
        {
            index = 0;
        }
        bulb_status_direct_set_hsv(g_hsv_rainbow_tbl[index], 0.025);
        index++;
    }
    else
    {
        bulb_status_direct_set_hsv(&g_hsv_dark_color, 0.025);
    }
    is_upward = !is_upward;
    bulb_status_timer_change_period(self, BULB_SCENE_DEFAULT_BREATH_MODE_INTERVAL_MS);
}

static void scene_default_flash_mode_cb(void *arg)
{
    vesync_timer_t *self = *(vesync_timer_t **)arg;
    static uint8_t index = 0;
    static bool is_upward = true;
    if (is_upward)
    {
        if (index >= BULB_HSV_RAINBOW_TBL_LEN)
        {
            index = 0;
        }
        bulb_status_direct_set_hsv(g_hsv_rainbow_tbl[index], 1.0);
        index++;
    }
    else
    {
        bulb_status_direct_set_hsv(&g_hsv_dark_color, 1.0);
    }
    is_upward = !is_upward;
    bulb_status_timer_change_period(self, BULB_SCENE_DEFAULT_FLASH_MODE_INTERVAL_MS);
}

const static bulb_scene_t s_default_scenes[BULB_SCENE_DEFAULT_MAX_NUM] = {
    {
        .type = SCENE_TYPE_WHITE,
        .id = 1,
        .param.white.brightness = 100,
        .param.white.color_temp = 0,
    },
    {
        .type = SCENE_TYPE_COLOR,
        .id = 2,
        .param.hsv.hue = 6667,
        .param.hsv.saturation = 392,
        .param.hsv.value = 100,
    },
    {
        .type = SCENE_TYPE_COLOR,
        .id = 3,
        .param.hsv.hue = 0,
        .param.hsv.saturation = 7490,
        .param.hsv.value = 100,
    },
    {
        .type = SCENE_TYPE_COLOR,
        .id = 4,
        .param.hsv.hue = 1548,
        .param.hsv.saturation = 2745,
        .param.hsv.value = 100,
    },
    {
        .type = SCENE_TYPE_WHITE,
        .id = 5,
        .param.white.brightness = 100,
        .param.white.color_temp = 16,
    },
    {
        .type = SCENE_TYPE_WHITE,
        .id = 6,
        .param.white.brightness = 100,
        .param.white.color_temp = 50,
    },
    {
        .type = SCENE_TYPE_WHITE,
        .id = 7,
        .param.white.brightness = 10,
        .param.white.color_temp = 10,
    },
    {
        .type = SCENE_TYPE_WHITE,
        .id = 8,
        .param.white.brightness = 30,
        .param.white.color_temp = 100,
    },
    {
        .type = SCENE_TYPE_DYNAMIC,
        .id = 9,
        .param.dynamic_cb = scene_default_flow_mode_cb,
    },
    {
        .type = SCENE_TYPE_DYNAMIC,
        .id = 10,
        .param.dynamic_cb = scene_default_change_mode_cb,
    },
    {
        .type = SCENE_TYPE_DYNAMIC,
        .id = 11,
        .param.dynamic_cb = scene_default_breath_mode_cb,
    },
    {
        .type = SCENE_TYPE_DYNAMIC,
        .id = 12,
        .param.dynamic_cb = scene_default_flash_mode_cb,
    }};

static struct
{
    uint8_t scenes_num;
    struct list_head scenes;
    uint16_t id_offset;
} s_scene_mgmt;

typedef struct
{
    bulb_scene_t scene;
    struct list_head list;
} scene_node_t;

static uint16_t get_new_next_id(void)
{
    uint16_t cur_id = s_scene_mgmt.id_offset;
    if (s_scene_mgmt.id_offset < 0xffff)
    {
        cur_id = s_scene_mgmt.id_offset;
    }

    while (1)
    {
        cur_id = (cur_id < 0xffff) ? (cur_id + 1) : BULB_SCENE_CUSTOM_ID_OFFSET;

        scene_node_t *p_pos, *p_n;
        list_for_each_entry_safe(p_pos, p_n, &s_scene_mgmt.scenes, list)
        {
            if (p_pos->scene.id == cur_id)
            {
                continue;
            }
        }
        break;
    }
    s_scene_mgmt.id_offset = cur_id;
    return cur_id;
}

static scene_node_t *find_scene_node(uint16_t id)
{
    scene_node_t *p_pos, *p_n;
    list_for_each_entry_safe(p_pos, p_n, &s_scene_mgmt.scenes, list)
    {
        if (p_pos->scene.id == id)
        {
            return p_pos;
        }
    }
    return NULL;
}

static scene_node_t *new_scene_node(void)
{
    scene_node_t *new = (scene_node_t *)vesync_calloc(1, sizeof(scene_node_t));
    if (new != NULL)
    {
        list_add(&new->list, &s_scene_mgmt.scenes);
    }
    return new;
}

static void del_scene_node(scene_node_t *p_node)
{
    list_del_init(&p_node->list);
    vesync_free(p_node);
}

static void scene_load_flash(void)
{
    uint32_t rd_len;
    uint8_t version;
    int ret = vhal_flash_read(PARTITION_CFG, BULB_SCENE_VER_CFG_KEY,
                              &version, &rd_len);
    if (VHAL_OK != ret || rd_len != sizeof(version))
    {
        APP_LOG(LOG_WARN, "no config:%d\n", rd_len);
        version = BULB_SCENE_CFG_VERSION;
        ret = vhal_flash_write(PARTITION_CFG, BULB_SCENE_VER_CFG_KEY,
                               &version, sizeof(version));
        if (VHAL_OK != ret)
        {
            APP_LOG(LOG_ERROR, "write cfg fail\n");
        }
        return;
    }
    ret = vhal_flash_read(PARTITION_CFG, BULB_SCENE_NUM_CFG_KEY,
                          &s_scene_mgmt.scenes_num, &rd_len);
    if (VHAL_OK != ret || rd_len != sizeof(s_scene_mgmt.scenes_num))
    {
        return;
    }
    ret = vhal_flash_read(PARTITION_CFG, BULB_SCENE_OFS_CFG_KEY,
                          (uint8_t *)&s_scene_mgmt.id_offset, &rd_len);
    if (VHAL_OK != ret || rd_len != sizeof(s_scene_mgmt.id_offset))
    {
        return;
    }
    uint8_t load_cnt = 0;
    for (uint8_t cnt = 0; cnt < s_scene_mgmt.scenes_num; cnt++)
    {
        scene_node_t *new = new_scene_node();
        char key_buf[16];
        snprintf(key_buf, sizeof(key_buf), "%s%hu", BULB_SCENE_INS_CFG_KEY, cnt);
        ret = vhal_flash_read(PARTITION_CFG, key_buf, (uint8_t *)&new->scene, &rd_len);
        if (VHAL_OK != ret || rd_len != sizeof(new->scene))
        {
            APP_LOG(LOG_ERROR, "invalid config:%d\n", rd_len);
            del_scene_node(new);
            continue;
        }
#if 0
        APP_LOG(LOG_DEBUG, "read scene:%s\n", key_buf);
#endif
        load_cnt++;
    }
    s_scene_mgmt.scenes_num = load_cnt;
}

static void scene_flush_flash(void)
{
    int ret = vhal_flash_write(PARTITION_CFG, BULB_SCENE_NUM_CFG_KEY,
                               &s_scene_mgmt.scenes_num,
                               sizeof(s_scene_mgmt.scenes_num));
    if (VHAL_OK != ret)
    {
        APP_LOG(LOG_ERROR, "write cfg fail\n");
        return;
    }
    ret = vhal_flash_write(PARTITION_CFG, BULB_SCENE_OFS_CFG_KEY,
                           (uint8_t *)&s_scene_mgmt.id_offset,
                           sizeof(s_scene_mgmt.id_offset));
    if (VHAL_OK != ret)
    {
        APP_LOG(LOG_ERROR, "write cfg fail\n");
        return;
    }
    uint8_t wr_cnt = 0;
    scene_node_t *p_pos, *p_n;
    list_for_each_entry_safe(p_pos, p_n, &s_scene_mgmt.scenes, list)
    {
        if (wr_cnt < s_scene_mgmt.scenes_num)
        {
            char key_buf[16];
            snprintf(key_buf, sizeof(key_buf), "%s%hu", BULB_SCENE_INS_CFG_KEY, wr_cnt);
            ret = vhal_flash_write(PARTITION_CFG, key_buf, (uint8_t *)&p_pos->scene,
                                   sizeof(p_pos->scene));
            if (VHAL_OK != ret)
            {
                APP_LOG(LOG_ERROR, "write cfg fail\n");
                return;
            }
#if 0
            APP_LOG(LOG_DEBUG, "record scene:%s\n", key_buf);
#endif
            wr_cnt++;
            continue;
        }
        break;
    }
}

int bulb_scene_clear(void)
{
    if (!list_empty(&s_scene_mgmt.scenes))
    {
        scene_node_t *p_pos, *p_n;
        list_for_each_entry_safe(p_pos, p_n, &s_scene_mgmt.scenes, list)
        {
            del_scene_node(p_pos);
        }
    }
    s_scene_mgmt.scenes_num = 0;
    s_scene_mgmt.id_offset = BULB_SCENE_CUSTOM_ID_OFFSET;

    scene_flush_flash();
    return APP_OK;
}

int bulb_scene_init(void)
{
    memset(&s_scene_mgmt, 0, sizeof(s_scene_mgmt));
    INIT_LIST_HEAD(&s_scene_mgmt.scenes);

    s_scene_mgmt.id_offset = BULB_SCENE_CUSTOM_ID_OFFSET;

    scene_load_flash();
    return APP_OK;
}

int bulb_scenes_list_get(uint8_t index, bulb_scene_t *p_list, uint8_t *p_list_len, uint8_t *p_total)
{
    uint8_t iter_cnt = 0;
    uint8_t out_cnt = 0;

    scene_node_t *p_pos, *p_n;
    list_for_each_entry_safe(p_pos, p_n, &s_scene_mgmt.scenes, list)
    {
        if (iter_cnt == index)
        {
            if (out_cnt >= BULB_SCENE_GET_MAX_NUM)
            {
                break;
            }
            memcpy(&p_list[out_cnt], &p_pos->scene, sizeof(bulb_scene_t));
            out_cnt++;
            continue;
        }
        iter_cnt++;
    }
    *p_list_len = out_cnt;
    *p_total = s_scene_mgmt.scenes_num;
    return APP_OK;
}

int bulb_scene_del(uint16_t id)
{
    if (id < BULB_SCENE_CUSTOM_ID_OFFSET)
    {
        APP_LOG(LOG_WARN, "can't delete default scene\n");
        return APP_FAIL;
    }
    scene_node_t *p_exist = find_scene_node(id);
    if (NULL != p_exist)
    {
        del_scene_node(p_exist);
        s_scene_mgmt.scenes_num -= 1;
        scene_flush_flash();
        return APP_OK;
    }
    return APP_FAIL;
}

int bulb_scene_add(bulb_scene_t *p_scene, uint16_t *p_id_out)
{
    if (s_scene_mgmt.scenes_num >= BULB_SCENE_CUSTOM_MAX_NUM)
    {
        APP_LOG(LOG_WARN, "scenes number up to max\n");
        return APP_FAIL;
    }

    uint16_t new_id = get_new_next_id();
    if (new_id < BULB_SCENE_CUSTOM_ID_OFFSET)
    {
        APP_LOG(LOG_ERROR, "get new id fail\n");
        return APP_FAIL;
    }

    scene_node_t *new = new_scene_node();
    if (new != NULL)
    {
        memcpy(&new->scene, p_scene, sizeof(bulb_scene_t));
        new->scene.id = new_id;
        s_scene_mgmt.scenes_num += 1;

        scene_flush_flash();
        *p_id_out = new->scene.id;
        return APP_OK;
    }
    return APP_FAIL;
}

int bulb_scene_restore(uint16_t id, bulb_scene_t *p_scene)
{
    if (id >= BULB_SCENE_CUSTOM_ID_OFFSET)
    {
        scene_node_t *find = find_scene_node(id);
        if (NULL == find)
        {
            return APP_FAIL;
        }
        memcpy(p_scene, &find->scene, sizeof(bulb_scene_t));
    }
    else if ((id > 0) && (id <= BULB_SCENE_DEFAULT_MAX_NUM))
    {
        memcpy(p_scene, &s_default_scenes[id - 1], sizeof(bulb_scene_t));
    }
    else
    {
        return APP_FAIL;
    }
    return APP_OK;
}

int bulb_scene_exist(uint16_t id, bool *p_is_exist)
{
    if (NULL == p_is_exist)
    {
        return APP_FAIL;
    }

    *p_is_exist = false;
    if (id >= BULB_SCENE_CUSTOM_ID_OFFSET)
    {
        scene_node_t *find = find_scene_node(id);
        if (NULL != find)
        {
            *p_is_exist = true;
        }
    }
    else if ((id > 0) && (id <= BULB_SCENE_DEFAULT_MAX_NUM))
    {
        *p_is_exist = true;
    }
    return APP_OK;
}