/**
 * Copyright © Vesync Technologies Co.Ltd. 2022. All rights reserved.
 * @file        vesync_sauth.c
 * @brief       Vesync SAUTH模块的主要流程实现
 * @author      Herve.Lin
 * @date        2022-01-10
 */
#include <stdio.h>
#include <string.h>

#include "pt.h"

#include "vesync_sauth_private.h"
#include "vesync_sauth_proto.h"
#include "vesync_sauth_crypto.h"
#include "vesync_sauth_port.h"

#include "vesync_log_internal.h"
#include "vesync_common.h"
#include "vesync_utils.h"
#include "vesync_crc.h"

/**
 * @brief 定义在协程内部使用的队列
 * @param[in]   T           [类型]
 * @param[in]   size        [队列大小]
 */
#define QUEUE(T, size)  \
    struct              \
    {                   \
        T buf[size];    \
        unsigned int r; \
        unsigned int w; \
    }
/**
 * @brief 返回队列初始化宏
 */
#define QUEUE_INIT()   \
    {                  \
        .r = 0, .w = 0 \
    }
/**
 * @brief 返回目标队列的长度
 * @param[in]   q           [指向目标队列]
 */
#define QUEUE_LEN(q) (sizeof((q)->buf) / sizeof((q)->buf[0]))
/**
 * @brief 返回目标队列已接受长度
 * @param[in]   q           [指向目标队列]
 */
#define QUEUE_CAP(q) ((q)->w - (q)->r)
/**
 * @brief 返回目标队列是否空
 * @param[in]   q           [指向目标队列]
 */
#define QUEUE_EMPTY(q) ((q)->w == (q)->r)
/**
 * @brief 返回目标队列是否满
 * @param[in]   q           [指向目标队列]
 */
#define QUEUE_FULL(q) (QUEUE_CAP(q) == QUEUE_LEN(q))
/**
 * @brief 清空目标队列
 * @param[in]   q           [指向目标队列]
 */
#define QUEUE_RESET(q) ((q)->w = (q)->r = 0)

/**
 * @brief 将元素入队
 * @param[in]   q           [指向目标队列]
 * @param[in]   el          [目标元素]
 */
#define QUEUE_PUSH(q, el) (!QUEUE_FULL(q) && ((q)->buf[(q)->w++ % QUEUE_LEN(q)] = (el), 1))
/**
 * @brief 返回队首元素的引用
 * @param[in]   q           [指向目标队列]
 * @param[in]   el          [目标元素]
 */
#define QUEUE_PEEK(q) (QUEUE_EMPTY(q) ? NULL : &(q)->buf[(q)->r % QUEUE_LEN(q)])
/**
 * @brief 将队首元素出队并且返回它的引用
 * @param[in]   q           [指向目标队列]
 * @param[in]   el          [目标元素]
 */
#define QUEUE_POP(q) (QUEUE_EMPTY(q) ? NULL : &(q)->buf[(q)->r++ % QUEUE_LEN(q)])

// 定义监控协程的事件队列
static QUEUE(uint8_t, 1) s_monitor_queue = QUEUE_INIT();

// 定义协程的退出值缓存
static struct
{
    uint8_t pt0 : 1;
    uint8_t pt1 : 1;
    uint8_t pt2 : 1;
    uint8_t rsv : 5;
} s_need_proc;

// 定义组合协程的句柄
static struct pt s_pt0, s_pt1, s_pt2;
// 定义发送与接收子协程的句柄
static struct pt s_pt_tx, s_pt_rx;
// 定义监控协程的句柄
static struct pt s_pt_monitor;

// 信号置位
#define SET_SIGNAL(x) (x) = 1
// 信号复位
#define CLR_SIGNAL(x) (x) = 0
// 信号是否置位
#define IS_SIGNAL_VLD(x) ((x) == 1)
// 信号是否复位
#define IS_SIGNAL_INV(x) ((x) == 0)

// 定义协程同步信号量
static struct
{
    uint8_t dev_info : 1;
    uint8_t app_pub : 1;
    uint8_t dev_pub : 1;
    uint8_t eph_key : 1;
    uint8_t dev_sha : 1;
    uint8_t dev_sign : 1;
    uint8_t dev_cert : 1;
    uint8_t app_cert : 1;
    uint8_t app_sign : 1;
    uint8_t app_sha : 1;
    uint8_t dev_verify : 1;
    uint8_t ltk : 1;
    uint8_t login_token : 1;
} s_signal;

// 定义证书解析的缓存
static sauth_crt_t s_crt;
// 定义发送、接收证书的长度缓存
static uint16_t s_raw_crt_len;

// 大型数据的缓存
static uint8_t *s_mass_buf = NULL;
// 大型数据的缓存大小
static uint16_t s_mass_buf_len = 0;

// 设备公钥缓存
static __ALIGN(4) uint8_t s_dev_pub[64];
// 哈希临时值缓存
static __ALIGN(4) uint8_t s_sha[32];
// APP公钥缓存
static __ALIGN(4) uint8_t s_app_pub[64];
// ECDHE临时密钥缓存
static __ALIGN(4) uint8_t s_eph_key[32];
// LTK密钥缓存
static __ALIGN(4) uint8_t s_ltk[32];
// 设备或者APP的数字签名缓存
static __ALIGN(4) union
{
    uint8_t device[64];
    uint8_t app[64];
} s_sign;
// 会话密钥缓存
static sauth_sess_ctx_t s_sess_key;

// 主调度流程是否需要被执行
static bool s_schd_need_exec;
// 调度是否完成，在事件处理的时候会被置位
static bool s_schd_is_cmplt;

static bool s_is_registered = false;
static bool s_is_login = false;

// 当前的调度流程码
static uint16_t s_schd_procedure = SAUTH_SCHD_IDLE;
// 当前的调度流程计算
static uint32_t s_schd_tick_ms_cnt;
// 当前的调度流程超时时间
static uint32_t s_schd_timeout_ms;
// 当前的主调度流程被执行的周期
static uint32_t s_schd_step_ms;

/**
 * @brief 调度事件处理
 * @param[in]   ev          [指向事件枚举值]
 */
static void sauth_schd_evt_handler(uint8_t *ev)
{
    if (NULL == ev)
    {
        return;
    }

    // 结束调度
    s_schd_is_cmplt = true;

    switch (*ev)
    {
    case SCHD_EVT_REG_SUCCESS:
        SDK_LOG(LOG_INFO, "register success\n");
        s_is_registered = true;
        break;
    case SCHD_EVT_LOGIN_SUCCESS:
        SDK_LOG(LOG_INFO, "login success\n");
        s_is_login = true;
        break;
    case SCHD_EVT_TIMEOUT:
        SDK_LOG(LOG_WARN, "procedure timeout\n");
        break;
    case SCHD_EVT_REG_FAIL:
        SDK_LOG(LOG_ERROR, "register fail\n");
        break;
    case SCHD_EVT_LOGIN_FAIL:
        SDK_LOG(LOG_ERROR, "login fail\n");
        break;
        break;
    default:
        break;
    }
}

/**
 * @brief Sauth调度器的监控程序，插入在所有流程执行前
 * @param[in]   pt          [协程句柄]
 * @return      int         [协程退出值]
 */
static int sauth_monitor(struct pt *pt)
{
    PT_BEGIN(pt);
    // 超时计数复位
    s_schd_tick_ms_cnt = 0;
    // 事件队列复位
    QUEUE_RESET(&s_monitor_queue);
    while (1)
    {
        if (s_schd_tick_ms_cnt >= s_schd_timeout_ms)
        {
            QUEUE_PUSH(&s_monitor_queue, SCHD_EVT_TIMEOUT);
        }
        else
        {
            s_schd_tick_ms_cnt += s_schd_step_ms;
        }

        if (false == s_schd_is_cmplt)
        {
            sauth_schd_evt_handler(QUEUE_POP(&s_monitor_queue));
        }
        if (true == s_schd_is_cmplt)
        {
            s_schd_procedure = SAUTH_SCHD_IDLE;
            s_schd_need_exec = false;
        }
        PT_YIELD(pt);
    }
    PT_END(pt);
}

/**
 * @brief 注册流程的主认证协程
 * @param[in]   pt          [协程句柄]
 * @return      int         [协程退出值]
 */
static int sauth_reg_auth_thd(struct pt *pt)
{
    int stat = 0;
    PT_BEGIN(pt);

    PT_WAIT_UNTIL(pt, IS_SIGNAL_VLD(s_signal.app_cert));
#if SAUTH_DEBUG_PRINT_ENABLE
    LOG_RAW_HEX(LOG_DEBUG, "app_cert:", s_mass_buf, s_raw_crt_len);
#endif
    stat = sauth_crypto_crt_parse_der(s_mass_buf, s_raw_crt_len, NULL, &s_crt);
    if (stat != CRYPTO_OK)
    {
        SDK_LOG(LOG_ERROR, "parse app_cert fail[%d]\n", stat);
        QUEUE_PUSH(&s_monitor_queue, SCHD_EVT_REG_FAIL);
        PT_EXIT(pt);
    }

    stat = sauth_crypto_sha256(s_crt.tbs.p, s_crt.tbs.len, s_sha);
    if (stat != CRYPTO_OK)
    {
        QUEUE_PUSH(&s_monitor_queue, SCHD_EVT_REG_FAIL);
        PT_EXIT(pt);
    }
    SET_SIGNAL(s_signal.app_sha);

    PT_WAIT_UNTIL(pt, IS_SIGNAL_VLD(s_signal.eph_key));
    stat = sauth_crypto_hkdf_sha256(s_eph_key, sizeof(s_eph_key),
                                    NULL, 0, // No oob_info indicates
                                    NULL, 0,
                                    s_ltk, sizeof(s_ltk));
    if (stat != CRYPTO_OK)
    {
        QUEUE_PUSH(&s_monitor_queue, SCHD_EVT_REG_FAIL);
        PT_EXIT(pt);
    }
    stat = sauth_crypto_sha256(s_ltk, sizeof(s_ltk), s_sha);
    if (stat != CRYPTO_OK)
    {
        QUEUE_PUSH(&s_monitor_queue, SCHD_EVT_REG_FAIL);
        PT_EXIT(pt);
    }
    SET_SIGNAL(s_signal.dev_sha);

    PT_WAIT_UNTIL(pt, IS_SIGNAL_VLD(s_signal.dev_verify));
    SDK_LOG(LOG_INFO, "device has been verified\n");
    // todo: HKDF the LTK and then encrypt for final record key
    SET_SIGNAL(s_signal.ltk);

    // 0号进程要阻塞等待LTK的写入完成
    PT_WAIT_UNTIL(pt, IS_SIGNAL_INV(s_signal.ltk));
    QUEUE_PUSH(&s_monitor_queue, SCHD_EVT_REG_SUCCESS);

    PT_END(pt);
}

/**
 * @brief 注册流程的加解密协程
 * @param[in]   pt          [协程句柄]
 * @return      int         [协程退出值]
 */
static int sauth_reg_crypto_thd(struct pt *pt)
{
    int stat = 0;
    PT_BEGIN(pt);

    stat = sauth_crypto_get_crt_len(SAUTH_DEV_CERT, &s_raw_crt_len);
    if (stat != CRYPTO_OK || s_raw_crt_len > s_mass_buf_len)
    {
        if (s_raw_crt_len > s_mass_buf_len)
        {
            SDK_LOG(LOG_ERROR, "raw_crt_buf overflow[%d]\n", s_raw_crt_len);
        }
        QUEUE_PUSH(&s_monitor_queue, SCHD_EVT_REG_FAIL);
        PT_EXIT(pt);
    }
    stat = sauth_crypto_get_crt_der(SAUTH_DEV_CERT, s_mass_buf, s_raw_crt_len);
    if (stat != CRYPTO_OK)
    {
        QUEUE_PUSH(&s_monitor_queue, SCHD_EVT_REG_FAIL);
        PT_EXIT(pt);
    }
    SET_SIGNAL(s_signal.dev_cert);

    stat = sauth_crypto_ecc_keypair_gen(P256R1, s_dev_pub);
    if (stat != CRYPTO_OK)
    {
        QUEUE_PUSH(&s_monitor_queue, SCHD_EVT_REG_FAIL);
        PT_EXIT(pt);
    }
    SET_SIGNAL(s_signal.dev_pub);

    PT_WAIT_UNTIL(pt, IS_SIGNAL_VLD(s_signal.app_sha));
    stat = sauth_crypto_ecc_verify_by_root(P256R1, s_sha, s_crt.sig);
    if (stat != CRYPTO_OK)
    {
        SDK_LOG(LOG_ERROR, "verify app_cert fail[%d]\n", stat);
        sauth_send_status_code(SAUTH_CMD_REG_INVLD_CERT);
        QUEUE_PUSH(&s_monitor_queue, SCHD_EVT_REG_FAIL);
        PT_EXIT(pt);
    }

    PT_WAIT_UNTIL(pt, IS_SIGNAL_VLD(s_signal.app_pub));
    stat = sauth_crypto_ecc_shared_secret_compute(P256R1, s_app_pub, s_eph_key);
    if (stat != CRYPTO_OK)
    {
        QUEUE_PUSH(&s_monitor_queue, SCHD_EVT_REG_FAIL);
        PT_EXIT(pt);
    }
    SET_SIGNAL(s_signal.eph_key);

    PT_WAIT_UNTIL(pt, IS_SIGNAL_VLD(s_signal.app_sign));
    PT_WAIT_UNTIL(pt, IS_SIGNAL_VLD(s_signal.dev_sha));
    uint8_t pub_tmp[64];
    memcpy(pub_tmp, s_crt.pub.p, sizeof(pub_tmp));
    stat = sauth_crypto_ecc_verify(P256R1, pub_tmp, s_sha, s_sign.app);
    if (stat != CRYPTO_OK)
    {
        SDK_LOG(LOG_ERROR, "verify app_sign fail[%d]\n", pt);
        sauth_send_status_code(SAUTH_CMD_REG_VERIFY_FAIL);
        QUEUE_PUSH(&s_monitor_queue, SCHD_EVT_REG_FAIL);
        PT_EXIT(pt);
    }
    stat = sauth_crypto_ecc_sign_by_dev_crt(P256R1, s_sha, s_sign.device);
    if (stat != CRYPTO_OK)
    {
        QUEUE_PUSH(&s_monitor_queue, SCHD_EVT_REG_FAIL);
        PT_EXIT(pt);
    }
    SET_SIGNAL(s_signal.dev_sign);

    PT_WAIT_UNTIL(pt, IS_SIGNAL_VLD(s_signal.ltk));
    stat = sauth_port_write_ltk(s_ltk, sizeof(s_ltk));
    if (stat != SDK_OK)
    {
        SDK_LOG(LOG_ERROR, "write ltk fail[%d]\n", stat);
        QUEUE_PUSH(&s_monitor_queue, SCHD_EVT_REG_FAIL);
        PT_EXIT(pt);
    }
    // 告诉0号进程LTK已经记录完毕
    CLR_SIGNAL(s_signal.ltk);

    PT_END(pt);
}

/**
 * @brief 注册流程的协议传输协程
 * @param[in]   pt          [协程句柄]
 * @return      int         [协程退出值]
 */
static int sauth_reg_trans_thd(struct pt *pt)
{
    PT_BEGIN(pt);

    PT_WAIT_UNTIL(pt, IS_SIGNAL_VLD(s_signal.dev_cert));
    PT_SPAWN(pt, &s_pt_tx, sauth_tx_thd(&s_pt_tx, s_mass_buf, s_mass_buf_len, SAUTH_CMD_INFO_DEV_CERT, s_mass_buf, s_raw_crt_len));
    PT_WAIT_UNTIL(pt, IS_SIGNAL_VLD(s_signal.dev_pub));
    PT_SPAWN(pt, &s_pt_tx, sauth_tx_thd(&s_pt_tx, s_mass_buf, s_mass_buf_len, SAUTH_CMD_INFO_DEV_PK, s_dev_pub, sizeof(s_dev_pub)));

    PT_SPAWN(pt, &s_pt_rx, sauth_rx_thd(&s_pt_rx, SAUTH_CMD_INFO_APP_CERT, s_mass_buf, s_mass_buf_len, &s_raw_crt_len));
    SET_SIGNAL(s_signal.app_cert);
    PT_SPAWN(pt, &s_pt_rx, sauth_rx_thd(&s_pt_rx, SAUTH_CMD_INFO_APP_PK, s_app_pub, sizeof(s_app_pub), NULL));
    SET_SIGNAL(s_signal.app_pub);
    PT_SPAWN(pt, &s_pt_rx, sauth_rx_thd(&s_pt_rx, SAUTH_CMD_INFO_APP_SIGN, s_sign.app, sizeof(s_sign), NULL));
    SET_SIGNAL(s_signal.app_sign);

    PT_WAIT_UNTIL(pt, IS_SIGNAL_VLD(s_signal.dev_sign));
    PT_SPAWN(pt, &s_pt_tx, sauth_tx_thd(&s_pt_tx, s_mass_buf, s_mass_buf_len, SAUTH_CMD_INFO_DEV_SIGN, s_sign.device, sizeof(s_sign)));

    PT_SPAWN(pt, &s_pt_rx, sauth_rx_thd(&s_pt_rx, SAUTH_CMD_REG_SUCCESS, NULL, 0, NULL));
    SET_SIGNAL(s_signal.dev_verify);

    PT_END(pt);
}

/**
 * @brief 注册流程所有协程的父程序
 */
static void sauth_reg_main(void)
{
#if SAUTH_DEBUG_PRINT_ENABLE
    SDK_LOG(LOG_DEBUG, "register procedure start\n");
#endif

    if (s_need_proc.pt0)
    {
        s_need_proc.pt0 = PT_SCHEDULE(sauth_reg_auth_thd(&s_pt0));
    }
    if (s_need_proc.pt0 && s_need_proc.pt1)
    {
        s_need_proc.pt1 = PT_SCHEDULE(sauth_reg_crypto_thd(&s_pt1));
    }
    if (s_need_proc.pt0 && s_need_proc.pt2)
    {
        s_need_proc.pt2 = PT_SCHEDULE(sauth_reg_trans_thd(&s_pt2));
    }

#if SAUTH_DEBUG_PRINT_ENABLE
    SDK_LOG(LOG_DEBUG, "register procedure end\n");
#endif
}

/**
 * @brief 设备信息回应协程
 * @param[in]   pt          [协程句柄]
 * @return      int         [协程退出值]
 */
static int sauth_resp_dev_info_thd(struct pt *pt)
{
    PT_BEGIN(pt);
    sauth_dev_info_t *format = (sauth_dev_info_t *)s_mass_buf;
    format->cipher_status = 0;
    if (s_is_registered)
    {
        format->cipher_status |= SAUTH_CIPER_STATUS_IS_REG_BIT;
    }
    if (s_is_login)
    {
        format->cipher_status |= SAUTH_CIPER_STATUS_IS_LOGIN_BIT;
    }
    format->cipher_suit = SAUTH_CIPER_SUIT_ECDHE_REG_ECDSA_LOG_AES_128_CCM_SHA256;
    format->io_capability = SAUTH_OOB_CAPABILITY_NO_WAY;
    format->version = vesync_htole16(SAUTH_PROTOCOL_VERSION);
    PT_SPAWN(pt, &s_pt_tx, sauth_tx_thd(&s_pt_tx, s_mass_buf, s_mass_buf_len, SAUTH_CMD_INFO_DEV, s_mass_buf, sizeof(sauth_dev_info_t)));
    QUEUE_PUSH(&s_monitor_queue, SCHD_EVT_INTERNAL);
    PT_END(pt);
}

/**
 * @brief Hello流程所有协程的父程序
 */
static void sauth_hello_main(void)
{
    if (s_need_proc.pt0)
    {
        s_need_proc.pt0 = PT_SCHEDULE(sauth_resp_dev_info_thd(&s_pt0));
    }
}

/**
 * @brief 登录流程的主认证协程
 * @param[in]   pt          [协程句柄]
 * @return      int         [协程退出值]
 */
static int sauth_login_auth_thd(struct pt *pt)
{
    int stat = 0;
    PT_BEGIN(pt);

    PT_WAIT_UNTIL(pt, IS_SIGNAL_VLD(s_signal.eph_key));
    if (s_mass_buf_len < (sizeof(s_eph_key) + sizeof(s_ltk)))
    {
        QUEUE_PUSH(&s_monitor_queue, SCHD_EVT_LOGIN_FAIL);
        PT_EXIT(pt);
    }
    memcpy(s_mass_buf, s_eph_key, sizeof(s_eph_key));
    memcpy(s_mass_buf + sizeof(s_eph_key), s_ltk, sizeof(s_ltk));
    stat = sauth_crypto_hkdf_sha256(s_mass_buf, sizeof(s_eph_key) + sizeof(s_ltk),
                                    NULL, 0,
                                    NULL, 0,
                                    (uint8_t *)&s_sess_key, sizeof(s_sess_key));
    if (stat != CRYPTO_OK)
    {
        QUEUE_PUSH(&s_monitor_queue, SCHD_EVT_LOGIN_FAIL);
        PT_EXIT(pt);
    }

    PT_WAIT_UNTIL(pt, IS_SIGNAL_VLD(s_signal.login_token));
    if (s_mass_buf_len < sizeof(sauth_login_token_t))
    {
        QUEUE_PUSH(&s_monitor_queue, SCHD_EVT_LOGIN_FAIL);
        PT_EXIT(pt);
    }

    uint8_t nonce[12] = {0};
    uint8_t dec_ciper[4];
    memcpy(nonce, s_sess_key.app_iv, sizeof(s_sess_key.app_iv));
    sauth_login_token_t *p_login_token = (sauth_login_token_t *)s_mass_buf;
    stat = sauth_crypto_ccm_decrypt(s_sess_key.app_key,
                                    nonce, sizeof(nonce),
                                    NULL, 0,
                                    p_login_token->ciper, sizeof(p_login_token->ciper),
                                    dec_ciper,
                                    p_login_token->mic, sizeof(p_login_token->mic));
    if (stat != CRYPTO_OK)
    {
        SDK_LOG(LOG_ERROR, "ltk has been rejected[%d]\n", stat);
        sauth_send_status_code(SAUTH_CMD_LOGIN_LTK_RJT);
        QUEUE_PUSH(&s_monitor_queue, SCHD_EVT_LOGIN_FAIL);
        PT_EXIT(pt);
    }

    uint32_t dev_crc32, app_crc32;
    app_crc32 = ((uint32_t)dec_ciper[0] << 0) | ((uint32_t)dec_ciper[1] << 8) |
                ((uint32_t)dec_ciper[2] << 16) | ((uint32_t)dec_ciper[3] << 24);
    vesync_crc32(0, s_dev_pub, sizeof(s_dev_pub), &dev_crc32);
    if (dev_crc32 == app_crc32)
    {
        sauth_session_init(&s_sess_key);
        sauth_send_status_code(SAUTH_CMD_LOGIN_SUCCESS);
        QUEUE_PUSH(&s_monitor_queue, SCHD_EVT_LOGIN_SUCCESS);
        PT_EXIT(pt);
    }
    else
    {
        SDK_LOG(LOG_ERROR, "invalid login token\n");
        sauth_send_status_code(SAUTH_CMD_LOGIN_FAIL);
        QUEUE_PUSH(&s_monitor_queue, SCHD_EVT_LOGIN_FAIL);
        PT_EXIT(pt);
    }

    PT_END(pt);
}

/**
 * @brief 登录流程的加密协程
 * @param[in]   pt          [协程句柄]
 * @return      int         [协程退出值]
 */
static int sauth_login_crypto_thd(struct pt *pt)
{
    int stat = 0;
    PT_BEGIN(pt);

    stat = sauth_crypto_ecc_keypair_gen(P256R1, s_dev_pub);
    if (stat != CRYPTO_OK)
    {
        QUEUE_PUSH(&s_monitor_queue, SCHD_EVT_LOGIN_FAIL);
        PT_EXIT(pt);
    }
    SET_SIGNAL(s_signal.dev_pub);

    PT_WAIT_UNTIL(pt, IS_SIGNAL_VLD(s_signal.app_pub));

    stat = sauth_crypto_ecc_shared_secret_compute(P256R1, s_app_pub, s_eph_key);
    if (stat != CRYPTO_OK)
    {
        QUEUE_PUSH(&s_monitor_queue, SCHD_EVT_LOGIN_FAIL);
        PT_EXIT(pt);
    }
    SET_SIGNAL(s_signal.eph_key);

    PT_END(pt);
}

/**
 * @brief 登录流程的协议传输协程
 * @param[in]   pt          [协程句柄]
 * @return      int         [协程退出值]
 */
static int sauth_login_trans_thd(struct pt *pt)
{
    PT_BEGIN(pt);

    PT_SPAWN(pt, &s_pt_rx, sauth_rx_thd(&s_pt_rx, SAUTH_CMD_INFO_APP_PK, s_app_pub, sizeof(s_app_pub), NULL));
    SET_SIGNAL(s_signal.app_pub);

    PT_WAIT_UNTIL(pt, IS_SIGNAL_VLD(s_signal.dev_pub));
    PT_SPAWN(pt, &s_pt_tx, sauth_tx_thd(&s_pt_tx, s_mass_buf, s_mass_buf_len, SAUTH_CMD_INFO_DEV_PK, s_dev_pub, sizeof(s_dev_pub)));

    PT_SPAWN(pt, &s_pt_rx, sauth_rx_thd(&s_pt_rx, SAUTH_CMD_INFO_LOGIN_TOKEN, s_mass_buf, sizeof(sauth_login_token_t), NULL));
    SET_SIGNAL(s_signal.login_token);

    PT_END(pt);
}

/**
 * @brief 登录流程所有协程的父程序
 */
static void sauth_login_main(void)
{
    if (true == s_is_login)
    {
        sauth_send_status_code(SAUTH_CMD_LOGIN_ALREADY);
        QUEUE_PUSH(&s_monitor_queue, SCHD_EVT_LOGIN_FAIL);
        return;
    }

    if (s_need_proc.pt0)
    {
        s_need_proc.pt0 = PT_SCHEDULE(sauth_login_auth_thd(&s_pt0));
    }
    if (s_need_proc.pt0 && s_need_proc.pt1)
    {
        s_need_proc.pt1 = PT_SCHEDULE(sauth_login_crypto_thd(&s_pt1));
    }
    if (s_need_proc.pt0 && s_need_proc.pt2)
    {
        s_need_proc.pt2 = PT_SCHEDULE(sauth_login_trans_thd(&s_pt2));
    }
}

int sauth_schedule_start(uint16_t procedure)
{
    switch (s_schd_procedure)
    {
    case SAUTH_SCHD_IDLE:
        s_schd_procedure = procedure;
        s_schd_need_exec = true;
        s_schd_is_cmplt = false;
        break;
    default:
        return SDK_FAIL;
    }

    PT_INIT(&s_pt0);
    PT_INIT(&s_pt1);
    PT_INIT(&s_pt2);
    PT_INIT(&s_pt_monitor);

    memset(&s_signal, 0, sizeof(s_signal));
    memset(&s_need_proc, 0xFF, sizeof(s_need_proc));

    return SDK_OK;
}

int sauth_internal_init(uint32_t schd_step_ms, uint32_t timeout_ms, uint8_t *p_mass_buf, uint16_t buf_len)
{
    int ret = SDK_OK;

    s_schd_timeout_ms = timeout_ms;
    s_schd_step_ms = schd_step_ms;

    s_mass_buf = p_mass_buf;
    s_mass_buf_len = buf_len;

    // 复位模块的加密状态
    s_is_registered = false;
    s_is_login = false;

    // 读取长期密钥
    ret = sauth_port_read_ltk(s_ltk, sizeof(s_ltk));
    if (SDK_OK == ret)
    {
        SDK_LOG(LOG_INFO, "device is registered\n");
        s_is_registered = true;
    }

    ret = sauth_crypto_init(sauth_port_rnd_block_gen_cb);
    if (SDK_OK != ret)
    {
        return SDK_FAIL;
    }

    return ret;
}

void sauth_schedule(void)
{
    if (false == s_schd_need_exec)
    {
        return;
    }

    sauth_monitor(&s_pt_monitor);

#if SAUTH_DEBUG_PRINT_ENABLE
    SDK_LOG(LOG_DEBUG, "procedure_code[%x]\n", s_schd_procedure);
#endif

    switch (s_schd_procedure & 0x00F0)
    {
    case SAUTH_CMD_REG_TYPE:
        sauth_reg_main();
        break;
    case SAUTH_CMD_LOGIN_TYPE:
        sauth_login_main();
        break;
    case SAUTH_CMD_HELLO:
        sauth_hello_main();
        break;
    }
}

void sauth_login_out(void)
{
    sauth_session_deinit();

    s_is_login = false;
    memset(&s_sess_key, 0, sizeof(s_sess_key));
}

bool vesync_sauth_is_reg(void)
{
    return s_is_registered;
}

bool vesync_sauth_is_login(void)
{
    return s_is_login;
}

int vesync_sauth_clear(void)
{
    sauth_login_out();

    s_is_registered = false;

    uint8_t dummy = 0x08;
    int ret = sauth_port_write_ltk(&dummy, sizeof(dummy));
    if (ret != SDK_OK)
    {
        return SDK_FAIL;
    }
    return SDK_OK;
}