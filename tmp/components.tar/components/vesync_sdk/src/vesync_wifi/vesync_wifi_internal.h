/*
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file        vesync_wifi_internal.h
* @brief       Wi-Fi模块接口定义
* @date        2021-05-17
*/
#ifndef __VESYNC_WIFI_INTERNAL_H__
#define __VESYNC_WIFI_INTERNAL_H__

#include "vesync_wifi.h"
#include "vhal_wifi.h"

#ifdef __cplusplus
extern "C" {
#endif

//TODO:Fixme
#define VERR_UPLOAD(x, y)
#define vesync_net_set_reconnect_reason NULL
#define vesync_net_set_reconnect_count NULL
// End TODO

typedef void (*set_reconnect_reason_t)(int reason);
typedef void (*set_reconnect_count_t)(int fail_type);

typedef struct
{
    VHAL_WIFI_STATUS_E link_status;
    VHAL_WIFI_STATUS_E connect_fail_reason;
    set_reconnect_reason_t set_reconnect_reason;
    set_reconnect_count_t set_reconnect_count;
} vesync_wifi_t;

#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_WIFI_INTERNAL_H__ */



