/**
 *  Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
 * @file        vesync_uart_msg_queue.h
 * @brief       串口消息队列处理
 * @author      Dongri.Su
 * @date        2021-05-08
 */

#ifndef __VESYNC_UART_MSG_QUEUE_H__
#define __VESYNC_UART_MSG_QUEUE_H__

#include <stdint.h>
#include <string.h>
#include <stdbool.h>

#include "vesync_cfg.h"
#include "vesync_uart_internal.h"
#include "vesync_tl_frame_parse.h"


#ifdef __cplusplus
extern "C"
{
#endif

#define UART_QUEUE_USE_TIMER            (PR_UART_SEND_USE_TIMER)        // 1表示使用timer实现串口发送，0表示使用task实现串口发送
#define UART_ACK_MSG_QUEUE_MAX_NUM      (PR_UART_SEND_ACK_QUEUE_LEN)    // ACK队列最大长度
#define UART_DATA_MSG_QUEUE_MAX_NUM     (PR_UART_SEND_DATA_QUEUE_LEN)   // 数据队列最大长度
#define UART_MSG_SEND_INTERVAL          (PR_UART_SEND_INTTERVAL_MS)     // 串口消息发送间隔，单位ms



/**
 * @brief 消息队列功能初始化
 */
void vesync_uart_msg_queue_init(void);

/**
 * @brief  将数据消息或者ACK应答数据放入队列
 * @param[in]  p_msg                [消息指针]
 * @return     int                  [0表示成功，其他值表示失败]
 */
int32_t vesync_uart_msg_queue_put(uart_msg_queue_t *p_msg);

/**
 * @brief  串口消息发送回调处理函数
 * @param[in]  event                [串口数据发送成功/失败事件]
 * @param[in]  frame                [接收到的指针]
 * @return     void
 */
void vesync_uart_msg_tx_event(UART_SEND_TYPE_E event, tl_frame_recv_info_t *frame);

#ifdef __cplusplus
}
#endif

#endif  /* __VESYNC_UART_MSG_QUEUE_H__ */
