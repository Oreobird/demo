/**
*Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file    vhal_rmt_ledstrip.c
* @brief   led strip单总线控制接口
* @author  Lind
*@date     2021-11-04
*/

#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <sys/cdefs.h>

#include "sdkconfig.h"
#include "driver/rmt.h"

#include "vhal_rmt_1_wire.h"
#include "vesync_memory.h"
#include "vesync_common.h"
#include "vesync_log.h"

static uint16_t s_pixel_num = 0;
static uint16_t s_pixel_data_len = 0;
static rmt_channel_t s_rmt_tx_ch = RMT_CHANNEL_0;
static uint8_t *s_buffer = NULL;

static uint32_t s_t0h_ticks = 0;
static uint32_t s_t0l_ticks = 0;
static uint32_t s_t1h_ticks = 0;
static uint32_t s_t1l_ticks = 0;

/**
 * @brief Conver RGB data to RMT format.
 * @note For WS2812, R,G,B each contains 256 different choices (i.e. uint8_t)
 * @param[in] src: source data, to converted to RMT format
 * @param[in] dest: place where to store the convert result
 * @param[in] src_size: size of source data
 * @param[in] wanted_num: number of RMT items that want to get
 * @param[out] translated_size: number of source data that got converted
 * @param[out] item_num: number of RMT items which are converted from source data
 */
static void IRAM_ATTR vhal_1_wire_adapter(const void *src, rmt_item32_t *dest, size_t src_size,
        size_t wanted_num, size_t *translated_size, size_t *item_num)
{
    if (src == NULL || dest == NULL)
    {
        *translated_size = 0;
        *item_num = 0;
        return;
    }
    const rmt_item32_t bit0 = {{{ s_t0h_ticks, 1, s_t0l_ticks, 0 }}}; //Logical 0
    const rmt_item32_t bit1 = {{{ s_t1h_ticks, 1, s_t1l_ticks, 0 }}}; //Logical 1
    size_t size = 0;
    size_t num = 0;
    uint8_t *psrc = (uint8_t *)src;
    rmt_item32_t *pdest = dest;
    while (size < src_size && num < wanted_num)
    {
        for (int i = 0; i < 8; i++)
        {
            // MSB first
            if (*psrc & (1 << (7 - i)))
            {
                pdest->val =  bit1.val;
            }
            else
            {
                pdest->val =  bit0.val;
            }
            num++;
            pdest++;
        }
        size++;
        psrc++;
    }
    *translated_size = size;
    *item_num = num;
}


int vhal_1_wire_send_bits(uint8_t *p_buf, uint32_t bit_len, one_wire_tx_signal_t signal_sample, bool wait_tx_done)
{
    if (NULL == p_buf)
    {
        return VHAL_FAIL;
    }

    uint32_t counter_clk_hz = 0;
    rmt_get_counter_clock(s_rmt_tx_ch, &counter_clk_hz);
    // ns -> ticks
    float ratio = (float)counter_clk_hz / 1e9;
    uint32_t data_len = bit_len + (signal_sample.beginning_flag ? 1 : 0) + (signal_sample.end_flag ? 1 : 0);
    if (data_len <= 0)
    {
        return VHAL_FAIL;
    }

    rmt_item32_t data[data_len];
    memset(data, 0, sizeof(data));

    rmt_item32_t *p_data = data;

    if (signal_sample.beginning_flag == true)
    {
        data[0] = (rmt_item32_t){{{(uint32_t)(ratio * signal_sample.beginning_marker.duration0), signal_sample.beginning_marker.level0,
                    (uint32_t)(ratio * signal_sample.beginning_marker.duration1), signal_sample.beginning_marker.level1}}};
        p_data++;
    }

    rmt_item32_t bit0 = {{{(uint32_t)(ratio * signal_sample.logic0.duration0), signal_sample.logic0.level0,
                            (uint32_t)(ratio * signal_sample.logic0.duration1), signal_sample.logic0.level1}}};
    rmt_item32_t bit1 = {{{(uint32_t)(ratio * signal_sample.logic1.duration0), signal_sample.logic1.level0,
                            (uint32_t)(ratio * signal_sample.logic1.duration1), signal_sample.logic1.level1}}};
    uint32_t byte_len = bit_len / 8;
    if (bit_len % 8 > 0)
    {
        byte_len += 1;
    }

    for (uint32_t i = 0; i < byte_len; i++)
    {
        for (int n = 0; n < 8; n++, p_data++)
        {
            if ((i * 8 + n) >= bit_len)
            {
                break;
            }

            if (*(p_buf + i) & (1 << (7 - n)))
            {
                p_data->val = bit1.val;
            }
            else
            {
                p_data->val = bit0.val;
            }
        }
    }

    if (signal_sample.end_flag == true)
    {
        data[data_len - 1] = (rmt_item32_t){{{(uint32_t)(ratio * signal_sample.end_marker.duration0), signal_sample.end_marker.level0,
                    (uint32_t)(ratio * signal_sample.end_marker.duration1), signal_sample.end_marker.level1}}};
    }

    ESP_ERROR_CHECK(rmt_write_items(s_rmt_tx_ch, data, sizeof(data) / sizeof(data[0]), wait_tx_done));

    return VHAL_OK;

}


int vhal_1_wire_tx_set_pixels(uint32_t begin_pos, uint8_t *p_buf, uint32_t buf_len)
{
    if (s_buffer == NULL)
    {
        return VHAL_FAIL;
    }

    if (buf_len % s_pixel_data_len != 0                         // 输入的数据长度不是单个像素点数据大小的倍数
        || (begin_pos + buf_len / s_pixel_data_len) > s_pixel_num)  // 更改的像素点数量超出初始化的数量
    {
        HAL_LOG(LOG_ERROR, "Parameters error \n");
        return VHAL_FAIL;
    }

    uint8_t *p_tx_buf = s_buffer + begin_pos * s_pixel_data_len;
    memcpy(p_tx_buf, p_buf, buf_len);

    return VHAL_OK;
}


int vhal_1_wire_tx_refresh(uint32_t timeout_ms)
{
    if (s_buffer == NULL)
    {
        return VHAL_FAIL;
    }

    if (ESP_OK != rmt_write_sample(s_rmt_tx_ch, s_buffer, s_pixel_data_len * s_pixel_num, true))
    {
        return VHAL_FAIL;
    }

    if (ESP_OK != rmt_wait_tx_done(s_rmt_tx_ch, pdMS_TO_TICKS(timeout_ms)))
    {
        return VHAL_FAIL;
    }

    return VHAL_OK;
}


int vhal_1_wire_tx_clear(uint32_t timeout_ms)
{
    if (s_buffer == NULL)
    {
        return VHAL_FAIL;
    }

    memset(s_buffer, 0, s_pixel_data_len * s_pixel_num);
    if (0 == timeout_ms)
    {
        return VHAL_OK;
    }
    else
    {
        return vhal_1_wire_tx_refresh(timeout_ms);
    }
}

int vhal_1_wire_tx_init(one_wire_tx_cfg_t *p_tx_cfg)
{
    if (NULL == p_tx_cfg)
    {
        return VHAL_FAIL;
    }

    uint32_t counter_clk_hz = 0;

    rmt_config_t config = RMT_DEFAULT_CONFIG_TX(p_tx_cfg->rmt_tx_gpio, RMT_CHANNEL_0);
    config.clk_div = p_tx_cfg->clk_div;
    config.tx_config.idle_level = (rmt_idle_level_t)p_tx_cfg->idle_level;

    ESP_ERROR_CHECK(rmt_config(&config));
    ESP_ERROR_CHECK(rmt_driver_install(config.channel, 0, 0));

    VCOM_SAFE_FREE(s_buffer);
    s_buffer = (uint8_t*)vesync_calloc(1, p_tx_cfg->pixel_data_len * p_tx_cfg->pixel_num);
    if (NULL == s_buffer)
    {
        return VHAL_FAIL;
    }

    rmt_get_counter_clock((rmt_channel_t)config.channel, &counter_clk_hz);
    // ns -> ticks
    float ratio = (float)counter_clk_hz / 1e9;
    s_t0h_ticks = (uint32_t)(ratio * p_tx_cfg->T0H_NS);
    s_t0l_ticks = (uint32_t)(ratio * p_tx_cfg->T0L_NS);
    s_t1h_ticks = (uint32_t)(ratio * p_tx_cfg->T1H_NS);
    s_t1l_ticks = (uint32_t)(ratio * p_tx_cfg->T1L_NS);

    rmt_translator_init((rmt_channel_t)config.channel, vhal_1_wire_adapter);

    s_pixel_num = p_tx_cfg->pixel_num;
    s_pixel_data_len = p_tx_cfg->pixel_data_len;

    return VHAL_OK;
}


void vhal_1_wire_tx_deinit(void)
{
    rmt_driver_uninstall(s_rmt_tx_ch);
    VCOM_SAFE_FREE(s_buffer);
}

