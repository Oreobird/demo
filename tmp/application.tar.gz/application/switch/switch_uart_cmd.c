/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        switch_uart_cmd.c
 * @brief       switch串口命令
 * @author      Charles.Mei
 * @date        2021-08-02
 */


#include <string.h>
#include <stdint.h>

#include "vesync_common.h"
#include "vesync_log.h"
#include "vesync_memory.h"
#include "vesync_klv.h"

#include "switch.h"
#include "switch_app.h"
#include "switch_uart_cmd.h"

#define PAYLOAD_KLE_LEN_MAX     50

/**
 * @brief  发送串口请求
 * @param[in]  opcode
 * @param[in]  src                      [请求来源]
 * @param[in]  p_pata                   [payload数据]
 * @param[in]  data_len                 [payload数据长度]
 * @param[in]  p_trace_msg              [bypass跟踪数据]
 * @return     int                      [成功：APP_OK，失败：APP_FAIL]
 */
static int uart_send_request(OPCODE_E opcode, void *p_data, uint32_t data_len, bypass_trace_msg_t *p_trace_msg)
{
    int ret = APP_OK;
    uart_msg_send_t msg;

    memset(&msg, 0, sizeof(msg));
    msg.type = UART_MSG_TYPE_CMD;
    msg.request_flag = 1;   // 请求包默认需要回复
    msg.status_code = 0;
    msg.opcode = opcode;
    msg.p_data = p_data;
    msg.data_len = data_len;

    if (NULL != p_trace_msg)
    {
        msg.p_app_data = vesync_malloc(sizeof(bypass_trace_msg_t));
        if (NULL != msg.p_app_data)
        {
            memcpy(msg.p_app_data, p_trace_msg, sizeof(bypass_trace_msg_t));
        }
    }

    if (SDK_OK != vesync_uart_send(SWITCH_UART_NUM, &msg))
    {
        // 目前发送失败才需要应用层释放
        VCOM_SAFE_FREE(msg.p_app_data);
        ret = APP_FAIL;
    }

    return ret;
}


#define OP_INQUIRY_KEY_INQUIRY_STATUS       0x01U

/**
 * @brief  switch查询设备状态
 * @return     int                      [成功：APP_OK，失败：APP_FAIL]
 */
int switch_uart_inquire_status(void)
{
    int ret = APP_FAIL;
    uint16_t data_len = 0;
    uint8_t *p_buf = (uint8_t*)vesync_malloc(PAYLOAD_KLE_LEN_MAX);

    if (NULL == p_buf)
    {
        return APP_FAIL;
    }

    memset(p_buf, 0, PAYLOAD_KLE_LEN_MAX);
    data_len += vesync_klv_set(p_buf, PAYLOAD_KLE_LEN_MAX, OP_INQUIRY_KEY_INQUIRY_STATUS, 0, NULL);
    ret = uart_send_request(OP_INQUIRY, p_buf, data_len, NULL);
    if (APP_OK != ret)
    {
        VCOM_SAFE_FREE(p_buf);
    }
    return ret;
}


#define OP_SET_MIN_LIGHTNESS_KEY_MIN_LIGHTNESS     0x01U

/**
 * @brief  switch设置灯最低亮度
 * @param[in]  min_lightness            [灯最低亮度亮度]
 * @param[in]  src                      [请求来源]
 * @param[in]  p_trace_msg              [bypass跟踪数据]
 * @return     int                      [成功：APP_OK，失败：APP_FAIL]
 */
int switch_uart_set_min_lightness(uint8_t min_lightness, bypass_trace_msg_t *p_trace_msg)
{
    int ret = APP_FAIL;
    uint16_t data_len = 0;
    uint8_t *p_buf = (uint8_t*)vesync_malloc(PAYLOAD_KLE_LEN_MAX);
    uint16_t uart_min_lightness = min_lightness * SWITCH_LIGHT_LIGHTNESS_PRECISION;

    if (NULL == p_buf)
    {
        return APP_FAIL;
    }

    memset(p_buf, 0, PAYLOAD_KLE_LEN_MAX);
    data_len += vesync_klv_set(p_buf, PAYLOAD_KLE_LEN_MAX,
        OP_SET_MIN_LIGHTNESS_KEY_MIN_LIGHTNESS, sizeof(uart_min_lightness), (uint8_t*)&uart_min_lightness);
    ret = uart_send_request(OP_SET_MIN_LIGHTNESS, p_buf, data_len, p_trace_msg);
    if (APP_OK != ret)
    {
        VCOM_SAFE_FREE(p_buf);
    }
    return ret;
}


#define OP_TEST_LIGHT_KEY_MIN_LIGHTNESS     0x01U
#define OP_TEST_LIGHT_KEY_TEST_TIME         0x02U

/**
 * @brief  switch最低亮度测试
 * @param[in]  min_lightness            [灯最低亮度]
 * @param[in]  test_time                [测试执行时间]
 * @param[in]  src                      [请求来源]
 * @param[in]  p_trace_msg              [bypass跟踪数据]
 * @return     int                      [成功：APP_OK，失败：APP_FAIL]
 */
int switch_uart_test_min_lightness(uint8_t min_lightness, uint8_t test_time, bypass_trace_msg_t *p_trace_msg)
{
    int ret = APP_FAIL;
    uint16_t data_len = 0;
    uint8_t *p_buf = (uint8_t*)vesync_malloc(PAYLOAD_KLE_LEN_MAX);
    uint16_t uart_min_lightness = min_lightness * SWITCH_LIGHT_LIGHTNESS_PRECISION;

    if (NULL == p_buf)
    {
        return APP_FAIL;
    }

    memset(p_buf, 0, PAYLOAD_KLE_LEN_MAX);
    data_len += vesync_klv_set(p_buf, PAYLOAD_KLE_LEN_MAX,
        OP_TEST_LIGHT_KEY_MIN_LIGHTNESS, sizeof(uart_min_lightness), (uint8_t*)&uart_min_lightness);
    data_len += vesync_klv_set(p_buf + data_len, PAYLOAD_KLE_LEN_MAX - data_len,
        OP_TEST_LIGHT_KEY_TEST_TIME, sizeof(test_time), &test_time);
    ret = uart_send_request(OP_TEST_LIGHT, p_buf, data_len, p_trace_msg);
    if (APP_OK != ret)
    {
        VCOM_SAFE_FREE(p_buf);
    }
    return ret;
}


#define OP_SET_LIGHT_MOD_KEY_LIGHT_MOD     0x01U

/**
 * @brief  switch调光模式
 * @param[in]  light_mode               [调光模式]
 * @param[in]  src                      [请求来源]
 * @param[in]  p_trace_msg              [bypass跟踪数据]
 * @return     int                      [成功：APP_OK，失败：APP_FAIL]
 */
int switch_uart_set_light_mode(uint8_t light_mode, bypass_trace_msg_t *p_trace_msg)
{
    int ret = APP_FAIL;
    uint16_t data_len = 0;
    uint8_t *p_buf = NULL;

    if (light_mode > SWITCH_LIGHT_MOD_MAX)
    {
        return APP_FAIL;
    }

    p_buf = (uint8_t*)vesync_malloc(PAYLOAD_KLE_LEN_MAX);
    if (NULL == p_buf)
    {
        return APP_FAIL;
    }

    memset(p_buf, 0, PAYLOAD_KLE_LEN_MAX);
    data_len += vesync_klv_set(p_buf, PAYLOAD_KLE_LEN_MAX,
        OP_SET_LIGHT_MOD_KEY_LIGHT_MOD, sizeof(light_mode), &light_mode);
    ret = uart_send_request(OP_SET_LIGHT_MOD, p_buf, data_len, p_trace_msg);
    if (APP_OK != ret)
    {
        VCOM_SAFE_FREE(p_buf);
    }
    return ret;
}


#define OP_SET_SWITCH_KEY_LIGHT_SWITCH     0x01U
#define OP_SET_SWITCH_KEY_FAN_SWITCH       0x02U
#define OP_SET_SWITCH_KEY_LIGHT_EXEC_TIME  0x11U

/**
 * @brief  switch设置开关
 * @param[in]  dev_id                   [子设备id，见DEVICE_ID_E]
 * @param[in]  onoff                    [0:关闭；1：开启]
 * @param[in]  exec_time                [执行时间，控制灯时有效，其它无效；为零无效]
 * @param[in]  src                      [请求来源]
 * @param[in]  p_trace_msg              [bypass跟踪数据]
 * @return     int                      [成功：APP_OK，失败：APP_FAIL]
 */
int switch_uart_set_switch(DEVICE_ID_E dev_id, uint8_t onoff, uint16_t exec_time, bypass_trace_msg_t *p_trace_msg)
{
    int ret = APP_FAIL;
    uint16_t data_len = 0;
    uint8_t *p_buf = (uint8_t*)vesync_malloc(PAYLOAD_KLE_LEN_MAX);

    if (NULL == p_buf)
    {
        return APP_FAIL;
    }

    memset(p_buf, 0, PAYLOAD_KLE_LEN_MAX);

    switch (dev_id)
    {
        case DEVICE_LIGHT:
            if (exec_time > SWITCH_LIGHT_EXEC_LIGHTNESS_TIME_MAX)
            {
                ret = APP_FAIL;
                goto exit;
            }
            data_len += vesync_klv_set(p_buf, PAYLOAD_KLE_LEN_MAX,
                OP_SET_SWITCH_KEY_LIGHT_SWITCH, sizeof(onoff), &onoff);
            if (0 != exec_time)
            {
                data_len += vesync_klv_set(p_buf + data_len, PAYLOAD_KLE_LEN_MAX - data_len,
                    OP_SET_SWITCH_KEY_LIGHT_EXEC_TIME, sizeof(exec_time), (uint8_t*)&exec_time);
            }
            ret = uart_send_request(OP_SET_SWITCH, p_buf, data_len, p_trace_msg);
            break;
        case DEVICE_FAN:
            data_len += vesync_klv_set(p_buf, PAYLOAD_KLE_LEN_MAX,
                OP_SET_SWITCH_KEY_FAN_SWITCH, sizeof(onoff), &onoff);
            ret = uart_send_request(OP_SET_SWITCH, p_buf, data_len, p_trace_msg);
            break;
        case DEVICE_MAX:
        default:
            ret = APP_FAIL;
            goto exit;
    }

exit:
    if (APP_OK != ret)
    {
        VCOM_SAFE_FREE(p_buf);
    }
    return ret;
}


#define OP_SET_LEVEL_KEY_LIGHT_LEVEL        0x01U
#define OP_SET_LEVEL_KEY_LIGHT_LIGHTNESS    0x02U
#define OP_SET_LEVEL_KEY_FAN_LEVEL          0x03U
#define OP_SET_LEVEL_KEY_LIGHT_EXEC_TIME    0x11U

/**
 * @brief  switch设置档位
 * @param[in]  dev_id                   [子设备id，见DEVICE_ID_E]
 * @param[in]  level                    [灯代表亮度，风扇代表档位]
 * @param[in]  exec_time                [执行时间，控制灯时有效，其它无效]
 * @param[in]  src                      [请求来源]
 * @param[in]  p_trace_msg              [bypass跟踪数据]
 * @return     int                      [成功：APP_OK，失败：APP_FAIL]
 */
int switch_uart_set_level(DEVICE_ID_E dev_id, uint8_t level, uint16_t exec_time, bypass_trace_msg_t *p_trace_msg)
{
    int ret = APP_FAIL;
    uint16_t data_len = 0;
    uint8_t *p_buf = (uint8_t*)vesync_malloc(PAYLOAD_KLE_LEN_MAX);

    if (NULL == p_buf)
    {
        return APP_FAIL;
    }

    memset(p_buf, 0, PAYLOAD_KLE_LEN_MAX);

    switch (dev_id)
    {
        case DEVICE_LIGHT:
            if (level < 1 || level > SWITCH_LIGHT_LEVEL_MAX)
            {
                ret = APP_FAIL;
                goto exit;
            }
            if (exec_time > SWITCH_LIGHT_EXEC_LIGHTNESS_TIME_MAX)
            {
                ret = APP_FAIL;
                goto exit;
            }
            data_len += vesync_klv_set(p_buf, PAYLOAD_KLE_LEN_MAX,
                OP_SET_LEVEL_KEY_LIGHT_LEVEL, sizeof(level), &level);
            if (0 != exec_time)
            {
                data_len += vesync_klv_set(p_buf + data_len, PAYLOAD_KLE_LEN_MAX - data_len,
                    OP_SET_SWITCH_KEY_LIGHT_EXEC_TIME, sizeof(exec_time), (uint8_t*)&exec_time);
            }
            ret = uart_send_request(OP_SET_LEVEL, p_buf, data_len, p_trace_msg);
            break;
        case DEVICE_FAN:
            if (level < 1 || level > SWITCH_FAN_LEVEL_MAX)
            {
                ret = APP_FAIL;
                goto exit;
            }
            data_len += vesync_klv_set(p_buf, PAYLOAD_KLE_LEN_MAX,
                OP_SET_LEVEL_KEY_FAN_LEVEL, sizeof(level), &level);
            ret = uart_send_request(OP_SET_LEVEL, p_buf, data_len, p_trace_msg);
            break;
        case DEVICE_MAX:
        default:
            ret = APP_FAIL;
            goto exit;
    }

exit:
    if (APP_OK != ret)
    {
        VCOM_SAFE_FREE(p_buf);
    }
    return ret;
}

/**
 * @brief  switch设置灯亮度
 * @param[in]  level                    [灯亮度]
 * @param[in]  exec_time                [执行时间，非零时有效]
 * @param[in]  src                      [请求来源]
 * @param[in]  p_trace_msg              [bypass跟踪数据]
 * @return     int                      [成功：APP_OK，失败：APP_FAIL]
 */
int switch_uart_set_lightness(uint8_t lightness, uint16_t exec_time, bypass_trace_msg_t *p_trace_msg)
{
    int ret = APP_FAIL;
    uint16_t data_len = 0;
    uint8_t *p_buf = (uint8_t*)vesync_malloc(PAYLOAD_KLE_LEN_MAX);
    uint16_t uart_lightness = switch_lightness_net_to_uart(lightness);

    if (NULL == p_buf)
    {
        return APP_FAIL;
    }

    memset(p_buf, 0, PAYLOAD_KLE_LEN_MAX);

    if (lightness < SWITCH_LIGHT_PERCENT_MIN || lightness > SWITCH_LIGHT_PERCENT_MAX)
    {
        ret = APP_FAIL;
        goto exit;
    }
    if (exec_time > SWITCH_LIGHT_EXEC_LIGHTNESS_TIME_MAX)
    {
        ret = APP_FAIL;
        goto exit;
    }
    data_len += vesync_klv_set(p_buf, PAYLOAD_KLE_LEN_MAX,
        OP_SET_LEVEL_KEY_LIGHT_LIGHTNESS, sizeof(uart_lightness), (uint8_t*)&uart_lightness);
    if (0 != exec_time)
    {
        data_len += vesync_klv_set(p_buf + data_len, PAYLOAD_KLE_LEN_MAX - data_len,
            OP_SET_SWITCH_KEY_LIGHT_EXEC_TIME, sizeof(exec_time), (uint8_t*)&exec_time);
    }
    switch_app_set_net_lightness(lightness);
    ret = uart_send_request(OP_SET_LEVEL, p_buf, data_len, p_trace_msg);

exit:
    if (APP_OK != ret)
    {
        VCOM_SAFE_FREE(p_buf);
    }
    return ret;
}


/*********************************************************************
 *  以下串口命令与产品无关，定义依据以下文档
 *  https://docs.qq.com/sheet/DS0VMc1dKaGZjd0Vo?tab=l0akzv
 *  请后续将以下命令移入VeSync SDK
 *********************************************************************/


#define OP_CTR_WIFI_LED_KEY_STATUS          0x01U
#define OP_CTR_WIFI_LED_KEY_ON_MS           0x02U
#define OP_CTR_WIFI_LED_KEY_OFF_MS          0x03U
#define OP_CTR_WIFI_LED_KEY_BLINK_TIME      0x04U

/**
 * @brief  设置wifi指示灯
 * @param[in]  led                      [WI-FI灯配置]
 * @return     int                      [成功：APP_OK，失败：APP_FAIL]
 */
int switch_uart_set_wifi_led(wifi_led_cfg_t led)
{
    int ret = APP_FAIL;
    uint16_t data_len = 0;
    uint8_t *p_buf = (uint8_t*)vesync_malloc(PAYLOAD_KLE_LEN_MAX);

    uint8_t led_status = (uint8_t)led.status;
    uint16_t led_on_ms = (uint16_t)led.blink_ms;
    uint16_t led_off_ms = (uint16_t)(led.blink_ms * led.off_times);
    uint8_t led_blink_times = (uint8_t)led.blink_times;

    if (NULL == p_buf)
    {
        return APP_FAIL;
    }

    memset(p_buf, 0, PAYLOAD_KLE_LEN_MAX);

    data_len += vesync_klv_set(p_buf, PAYLOAD_KLE_LEN_MAX,
        OP_CTR_WIFI_LED_KEY_STATUS, sizeof(led_status), &led_status);
    if (WIFI_LED_BLINK == led.status)   // 只有闪烁需要填充闪烁相关key
    {
        data_len += vesync_klv_set(p_buf + data_len, PAYLOAD_KLE_LEN_MAX - data_len,
            OP_CTR_WIFI_LED_KEY_ON_MS, sizeof(led_on_ms), (uint8_t*)&led_on_ms);
        data_len += vesync_klv_set(p_buf + data_len, PAYLOAD_KLE_LEN_MAX - data_len,
            OP_CTR_WIFI_LED_KEY_OFF_MS, sizeof(led_off_ms), (uint8_t*)&led_off_ms);
        data_len += vesync_klv_set(p_buf + data_len, PAYLOAD_KLE_LEN_MAX - data_len,
            OP_CTR_WIFI_LED_KEY_BLINK_TIME, sizeof(led_blink_times), &led_blink_times);
    }

    ret = uart_send_request(OP_CTR_WIFI_LED, p_buf, data_len, NULL);
    if (APP_OK != ret)
    {
        VCOM_SAFE_FREE(p_buf);
    }
    return ret;
}

/**
 * @brief  串口测试命令
 * @return     int                      [成功：APP_OK，失败：APP_FAIL]
 */
int switch_uart_test_cmd(void)
{
    return uart_send_request(OP_TEST_UART, NULL, 0, NULL);
}


#define OP_REST_MCU_KEY_RANK          0x01U

/**
 * @brief  重置MCU
 * @param[in]  rank                     [重置等级]
 * @param[in]  src                      [请求来源]
 * @param[in]  p_trace_msg              [bypass跟踪数据]
 * @return     int                      [成功：APP_OK，失败：APP_FAIL]
 */
int switch_uart_reset_mcu(MCU_RESET_RANK_E rank, bypass_trace_msg_t *p_trace_msg)
{
    int ret = APP_FAIL;
    uint16_t data_len = 0;
    uint8_t *p_buf = NULL;

    uint8_t reset_rank;

    if (rank > RESET_RANK_MAX)
    {
        return APP_FAIL;
    }
    reset_rank = (uint8_t)rank;

    p_buf = (uint8_t*)vesync_malloc(PAYLOAD_KLE_LEN_MAX);
    if (NULL == p_buf)
    {
        return APP_FAIL;
    }

    memset(p_buf, 0, PAYLOAD_KLE_LEN_MAX);
    data_len += vesync_klv_set(p_buf, PAYLOAD_KLE_LEN_MAX,
        OP_REST_MCU_KEY_RANK, sizeof(reset_rank), &reset_rank);
    ret = uart_send_request(OP_REST_MCU, p_buf, data_len, p_trace_msg);
    if (APP_OK != ret)
    {
        VCOM_SAFE_FREE(p_buf);
    }
    return ret;
}


#define OP_SET_PRODUCTION_STATE_KEY_STATE   0x01U

/**
 * @brief  通知产测状态
 * @param[in]  state                    [产测状态]
 * @return     int                      [成功：APP_OK，失败：APP_FAIL]
 */
int switch_uart_set_production_state(PRODUCTION_STATUS_E state)
{
    int ret = APP_FAIL;
    uint16_t data_len = 0;
    uint8_t *p_buf = NULL;

    uint8_t prodution_state;

    p_buf = (uint8_t*)vesync_malloc(PAYLOAD_KLE_LEN_MAX);
    if (NULL == p_buf)
    {
        return APP_FAIL;
    }

    switch (state)
    {
        case PRODUCTION_START:
            prodution_state = 0;    // 进入产测
            break;
        case PRODUCTION_RUNNING:
            prodution_state = 1;    // 产测进行中
            break;
        case PRODUCTION_TEST_PASS:
        case PRODUCTION_TEST_FAIL:
        case PRODUCTION_EXIT:
            prodution_state = 2;    // 产测结束
            break;
        case PRODUCTION_LOGIN_FAIL:
            APP_LOG(LOG_WARN, "wifi production login fail\n");
            goto exit;
        case PRODUCTION_WIFI_TEST:
        default:
            APP_LOG(LOG_ERROR, "unknow production status\n");
            goto exit;
    }
    data_len += vesync_klv_set(p_buf, PAYLOAD_KLE_LEN_MAX,
        OP_SET_PRODUCTION_STATE_KEY_STATE, sizeof(prodution_state), &prodution_state);
    ret = uart_send_request(OP_SET_PRODUCTION_STATE, p_buf, data_len, NULL);

exit:
    if (APP_OK != ret)
    {
        VCOM_SAFE_FREE(p_buf);
    }
    return ret;
}


#define OP_SET_PRODUCTION_ERROR_KEY_RESULT      0x01U
#define OP_SET_PRODUCTION_ERROR_KEY_ERR_CODE    0x02U

/**
 * @brief  通知产测结果
 * @param[in]  err_code                 [产测结果]
 * @return     int                      [成功：APP_OK，失败：APP_FAIL]
 */
int switch_uart_set_production_result(PRODUCTION_ERROR_E err_code)
{
    int ret = APP_FAIL;
    uint16_t data_len = 0;
    uint8_t *p_buf = NULL;

    uint8_t prodution_result;
    uint8_t prodution_err;

    p_buf = (uint8_t*)vesync_malloc(PAYLOAD_KLE_LEN_MAX);
    if (NULL == p_buf)
    {
        return APP_FAIL;
    }

    switch (err_code)
    {
        case PRD_NO_ERR:
            // 产测成功，错误码为0
            prodution_result = 0;
            prodution_err = 0;
            break;
        case PRD_CID_ERR:
        case PRD_WIFI_VERSION_ERR:
        case PRD_MCU_VERSION_ERR:
        case PRD_WIFI_RSSI_ERR:
        case PRD_BLE_RSSI_ERR:
        case PRD_NET_COMMUNICATION_ERR:
            // 产测失败，填入错误码
            prodution_result = 1;
            prodution_err = (uint8_t)err_code;
            break;
        default:
            // 此产品此后错误码不支持
            APP_LOG(LOG_ERROR, "unknow production error\n");
            goto exit;
    }
    data_len += vesync_klv_set(p_buf, PAYLOAD_KLE_LEN_MAX,
        OP_SET_PRODUCTION_ERROR_KEY_RESULT, sizeof(prodution_result), &prodution_result);
    data_len += vesync_klv_set(p_buf + data_len, PAYLOAD_KLE_LEN_MAX - data_len,
        OP_SET_PRODUCTION_ERROR_KEY_ERR_CODE, sizeof(prodution_err), &prodution_err);
    ret = uart_send_request(OP_SET_PRODUCTION_RESULT, p_buf, data_len, NULL);

exit:
    if (APP_OK != ret)
    {
        VCOM_SAFE_FREE(p_buf);
    }
    return ret;
}


