/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file        bulb_timing.c
* @brief       bulb_timing配置
* @author      Dave
* @date        2021-09-09
*/

#include <string.h>
#include <stdio.h>

#include "vesync_common.h"
#include "vesync_log.h"
#include "vesync_timing.h"
#include "vesync_device.h"

#include "bulb.h"
#include "bulb_flash.h"
#include "bulb_status.h"
#include "bulb_report.h"
#include "bulb_timing.h"

#define BULB_TIMER_ID_MIN (0)  // timer 最小di
#define BULB_TIMER_NUM_MAX (1) // 每个设备最多的timer数量

static bulb_timing_t s_bulb_timing; // 保存timer

/**
 * @brief timer时间到时执行的动作
 * @param[in]  uint16_t                 [timer id]
 * @return     void                     [none]
 */
static void bulb_timing_act(uint16_t id)
{
    if (id != s_bulb_timing.id)
    {
        return;
    }

    bulb_status_t bulb_status;
    bulb_status_fetch(&bulb_status);
    bulb_status.enable = (s_bulb_timing.action.onoff > 0) ? true : false;
    if (true == bulb_status.enable)
    {
        bulb_status.mode = s_bulb_timing.action.mode;
        switch (bulb_status.mode)
        {
        case BULB_CFG_COLOR_MODE_WHITE:
            bulb_status.white.brightness = s_bulb_timing.action.bright;
            bulb_status.white.color_temp = s_bulb_timing.action.temp;
            break;
        case BULB_CFG_COLOR_MODE_HSV:
            bulb_status.hsv.hue = s_bulb_timing.action.hue;
            bulb_status.hsv.saturation = s_bulb_timing.action.saturation;
            bulb_status.hsv.value = s_bulb_timing.action.value;
            break;
        case BULB_CFG_COLOR_MODE_SCENARIO:
            bulb_status.scene_id = s_bulb_timing.action.scene_id;
            break;
        default:
            break;
        }
    }

    int ret = bulb_status_update(&bulb_status);
    bulb_report_status_change(STAT_CHG_RSN_TIMER_STR);
    bulb_report_timing_exec(&s_bulb_timing.action, ret, "timing_executed");
    bulb_timing_remove(id);
}

int bulb_timing_add(void *action, uint32_t total_sec, uint16_t *p_id)
{
    VCOM_NULL_PARAM_CHK(action, return APP_FAIL);
    VCOM_NULL_PARAM_CHK(p_id, return APP_FAIL);
    if (0 != s_bulb_timing.id)
    {
        APP_LOG(LOG_ERROR, "Timing exist\n");
        return APP_FAIL;
    }
    s_bulb_timing.id = *p_id;
    memcpy(&s_bulb_timing.action, (bulb_action_t *)action, sizeof(s_bulb_timing.action));
    if (SDK_OK != vesync_timing_add(s_bulb_timing.id, total_sec))
    {
        return APP_FAIL;
    }
    return APP_OK;
}

int bulb_timing_get_act(const void **action)
{
    *action = (const void *)&s_bulb_timing;
    return APP_OK;
}

int bulb_timing_remove(uint16_t timer_id)
{
    if (s_bulb_timing.id != timer_id)
    {
        APP_LOG(LOG_ERROR, "Input ID is %d, not equal %d!\n", timer_id, s_bulb_timing.id);
        return APP_FAIL;
    }

    // 从队列中删除
    vesync_timing_remove(timer_id);

    // 清除缓存
    memset((uint8_t *)&s_bulb_timing, 0, sizeof(bulb_timing_t));

    return APP_OK;
}

int bulb_timing_clear(void)
{
    // 清除timer队列
    vesync_timing_clear();

    // 清除缓存
    memset(&s_bulb_timing, 0, sizeof(s_bulb_timing));

    return APP_OK;
}

void bulb_timing_init(void)
{
    // 注册定时器动作回调
    vesync_timing_reg_cb(bulb_timing_act);
}
