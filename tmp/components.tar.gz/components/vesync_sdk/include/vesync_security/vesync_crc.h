/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_crc.h
 * @brief       crc检验计算相关接口
 * @date        2021-04-25
 */

#ifndef __VESYNC_CRC_H__
#define __VESYNC_CRC_H__

#ifdef __cplusplus
extern "C" {
#endif


/**
 * @brief 计算crc8
 * @param[in]  data                 [crc数据]
 * @param[in]  len                  [用来计算的起始数据]
 * @param[out] crc8                 [数据的长度]
 * @return  int                     [成功：SDK_OK, 失败：SDK_FAIL]
 * @note CRC-8算法: MAXIM x8+x5+x4+1
 */
int vesync_crc8(unsigned char const *data, unsigned short len, unsigned char *crc8);

/**
 * @brief 计算一段Buffer内容的CRC32值
 * @param[in]  crc                  [累计crc32值，第一次调用需给定初始化值0]
 * @param[in]  p_buf                [指向输入Buffer]
 * @param[in]  len                  [Buffer内容长度]
 * @param[out] p_out                [crc32计算结果输出]
 * @return  int                     [成功：SDK_OK, 失败：SDK_FAIL]
 */
int vesync_crc32(uint32_t crc, const void *p_buf, size_t len, uint32_t *p_out);

#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_CRC_H__ */

