/**
 *  Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
 * @file        vhal_ble_internal.h
 * @brief       蓝牙hal配置ble服务属性接口
 * @author      Herve.Lin
 * @date        2021-09-03
 */

#ifndef __VHAL_BLE_INTERNAL_H__
#define __VHAL_BLE_INTERNAL_H__

#include "vhal_ble.h"

#ifdef __cplusplus
extern "C"
{
#endif

/**
 * @brief 蓝牙标志信息
 */
typedef struct
{
    bool init_flag;     // 初始化标志
    bool adv_started;   // 广播开始标志
    uint16_t tx_mtu;    // 发送的MTU
} vhal_ble_t;

#define BLE_ADV_NAME_MAX_LEN (29)     // 广播名称最大数据长度
#define BLE_INVALID_CONN_ID (0XFFFF)  // 连接句柄的复位值
#define BLE_ADV_INTERVAL_MIN (0x200)  // 广播最小间隔 (in units of 0.625 ms. This value corresponds to 300 ms)
#define BLE_ADV_INTERVAL_MAX (0x200)  // 广播最大间隔 (in units of 0.625 ms. This value corresponds to 300 ms)
#define BLE_RX_MAX_SIZE (1024)        // 最大收包大小限制
#define BLE_DEFAULT_MTU_SIZE (23)     // 初始化的默认MTU大小
#define BLE_ATT_OPCODE_HANDLE_LEN (3) // 蓝牙协议ATT层数据包的头opcode+handle
#define BLE_SEND_POLL_MAX_RETRY (32)  // (32*20MS=640MS)，发包轮询最大次数。实际次数取决于发包耗时也就是蓝牙通信质量
#define BLE_SEND_POLL_DELAY_MS (20)   // 发包轮询延时

#ifdef __cplusplus
}
#endif

#endif /* __VHAL_BLE_INTERNAL_H__ */
