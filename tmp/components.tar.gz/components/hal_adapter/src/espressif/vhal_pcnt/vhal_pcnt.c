/**
 *  Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vhal_pcnt.c
 * @brief       乐鑫平台pcnt接口封装
 * @author      Dongri.Su
 * @date        2021-04-22
 */


#if defined(CONFIG_IDF_TARGET_ESP32C3)
#include <stdint.h>
#include <string.h>

#include "freertos/FreeRTOS.h"
#include "driver/gpio.h"

#include "vesync_log.h"
#include "vesync_common.h"

#include "vhal_pcnt.h"

#define ESP_INTR_FLAG_DEFAULT 0

#define VHAL_PCNT_GPIO_NUM_MAX      (22)

#define PCNT_ENTER_CRITICAL(mux)    portENTER_CRITICAL(mux)
#define PCNT_EXIT_CRITICAL(mux)     portEXIT_CRITICAL(mux)

/**
 * @brief  pcunt unit config
 */
typedef struct
{
    PCNT_COUNT_MODE_E mode;                 // counter mode
    int16_t counter_h_lim;                  // Maximum counter value
    int16_t counter_l_lim;                  // Minimum counter value
    int16_t count;
} vhal_pcnt_unit_t;

static uint8_t s_unit_to_gpio[VHAL_PCNT_UNIT_MAX];                          // unit to gpio
static vhal_pcnt_unit_t *s_pcnt_run_unit_ptr_arry[VHAL_PCNT_GPIO_NUM_MAX];  // counting unit array
static vhal_pcnt_unit_t *s_pcnt_sus_unit_ptr_arry[VHAL_PCNT_GPIO_NUM_MAX];  // suspend unit array
static portMUX_TYPE pcnt_spinlock = portMUX_INITIALIZER_UNLOCKED;           // spinlock

/**
 * @brief  gpio interrupt,count
 * @param[in]  arg
 */
static void IRAM_ATTR pcnt_gpio_isr_handler(void* arg)
{
    vhal_pcnt_unit_t *p_pcunt_unit = s_pcnt_run_unit_ptr_arry[(uint32_t) arg];
    if (NULL != p_pcunt_unit)
    {
        switch (p_pcunt_unit->mode)
        {
            case VHAL_PCNT_COUNT_INC:
                ++p_pcunt_unit->count;
                if (p_pcunt_unit->count == p_pcunt_unit->counter_h_lim)
                {
                    p_pcunt_unit->count = 0;
                }
                return;
            case VHAL_PCNT_COUNT_DEC:
                --p_pcunt_unit->count;
                if (p_pcunt_unit->count == p_pcunt_unit->counter_l_lim)
                {
                    p_pcunt_unit->count = 0;
                }
                return;
            default:
                return;
        }
    }
}


/**
 * @brief  pcnt单元配置函数
 * @param[in]  pcnt_config              [pcnt配置结构体指针]
 * @return     int32_t                  [操作结果, 0为成功，其他值表示失败]
 */
int32_t vhal_pcnt_unit_config(const vhal_pcnt_config_t *pcnt_config)
{
    static uint8_t init_flag = 0;

    int ret = -1;
    vhal_pcnt_unit_t *p_pcnt_unit = NULL;
    gpio_config_t io_conf;

    if (0 == init_flag)
    {
        //install gpio isr service
        if (ESP_OK != gpio_install_isr_service(ESP_INTR_FLAG_DEFAULT))
        {
            return VHAL_FAIL;
        }

        init_flag = 1;
        memset(s_pcnt_run_unit_ptr_arry, 0, sizeof(s_pcnt_run_unit_ptr_arry));
        memset(s_pcnt_sus_unit_ptr_arry, 0, sizeof(s_pcnt_sus_unit_ptr_arry));
        memset(s_unit_to_gpio, 0xFF, sizeof(s_unit_to_gpio));
        HAL_LOG(LOG_DEBUG, "pcnt init done\n");
    }

    if (pcnt_config->pulse_gpio_num >= VHAL_PCNT_GPIO_NUM_MAX || pcnt_config->pulse_gpio_num < 0)
    {
        HAL_LOG(LOG_ERROR, "gpio not in range(%d,%d)", 0, VHAL_PCNT_GPIO_NUM_MAX - 1);
        return VHAL_FAIL;
    }

    if (pcnt_config->unit >= VHAL_PCNT_UNIT_MAX || pcnt_config->unit < VHAL_PCNT_UNIT_0)
    {
        HAL_LOG(LOG_ERROR, "unit not in range(%d,%d)", VHAL_PCNT_UNIT_0, VHAL_PCNT_UNIT_MAX - 1);
        return VHAL_FAIL;
    }

    if (0xFF != s_unit_to_gpio[pcnt_config->unit])
    {
        HAL_LOG(LOG_ERROR, "unit(%d) already exist\n", pcnt_config->unit);
        return VHAL_FAIL;
    }

    p_pcnt_unit = (vhal_pcnt_unit_t *)malloc(sizeof(vhal_pcnt_unit_t));
    if (NULL == p_pcnt_unit)
    {
        HAL_LOG(LOG_ERROR, "malloc fail\n");
        return VHAL_FAIL;
    }
    p_pcnt_unit->counter_h_lim = pcnt_config->counter_h_lim;
    p_pcnt_unit->counter_l_lim = pcnt_config->counter_l_lim;
    p_pcnt_unit->count = 0;

    io_conf.pin_bit_mask = (1ULL << pcnt_config->pulse_gpio_num);
    io_conf.mode = GPIO_MODE_INPUT;
    io_conf.pull_up_en = GPIO_PULLUP_ENABLE;
    io_conf.pull_down_en = GPIO_PULLDOWN_DISABLE;
    io_conf.intr_type = GPIO_INTR_DISABLE;
    // gpio interrupt do not support multiple interrupt type at the same time. positive edge first
    switch (pcnt_config->pos_mode)
    {
        case VHAL_PCNT_COUNT_INC:
        case VHAL_PCNT_COUNT_DEC:
            io_conf.intr_type = GPIO_INTR_POSEDGE;
            p_pcnt_unit->mode = pcnt_config->pos_mode;
            break;
        default:
            break;
    }
    if (GPIO_INTR_DISABLE == io_conf.intr_type)
    {
        switch (pcnt_config->neg_mode)
        {
            case VHAL_PCNT_COUNT_INC:
            case VHAL_PCNT_COUNT_DEC:
                io_conf.intr_type = GPIO_INTR_NEGEDGE;
                p_pcnt_unit->mode = pcnt_config->pos_mode;
                break;
            default:
                break;
        }
    }

    ret = gpio_config(&io_conf);;
    if (ESP_OK != ret)
    {
        goto EXIT;
    }
    s_pcnt_sus_unit_ptr_arry[pcnt_config->pulse_gpio_num] = p_pcnt_unit;
    s_pcnt_run_unit_ptr_arry[pcnt_config->pulse_gpio_num] = p_pcnt_unit;
    s_unit_to_gpio[pcnt_config->unit] = pcnt_config->pulse_gpio_num;

    ret = gpio_isr_handler_add(pcnt_config->pulse_gpio_num, pcnt_gpio_isr_handler, (void*)pcnt_config->pulse_gpio_num);
    if (ESP_OK != ret)
    {
        s_pcnt_sus_unit_ptr_arry[pcnt_config->pulse_gpio_num] = NULL;
        s_pcnt_run_unit_ptr_arry[pcnt_config->pulse_gpio_num] = NULL;
        s_unit_to_gpio[pcnt_config->unit] = 0xFF;
        goto EXIT;
    }
    return VHAL_OK;

EXIT:
    free(p_pcnt_unit);
    return VHAL_FAIL;
}

/**
 * @brief  获取unit对应结构体指针
 * @param[in]  pcnt_unit                [pcnt计数unit]
 * @return     vhal_pcnt_unit_t*        [unit对应结构体指针]
 */
static vhal_pcnt_unit_t* vhal_pcnt_get_unit_ptr(PCNT_UNIT_E pcnt_unit)
{
    uint8_t gpio_num = 0xFF;
    vhal_pcnt_unit_t *p_unit = NULL;

    if (pcnt_unit >= VHAL_PCNT_UNIT_MAX || pcnt_unit < VHAL_PCNT_UNIT_0)
    {
        HAL_LOG(LOG_ERROR, "unit not in range(%d,%d)", VHAL_PCNT_UNIT_0, VHAL_PCNT_UNIT_MAX - 1);
        return p_unit;
    }
    gpio_num = s_unit_to_gpio[pcnt_unit];
    if (gpio_num >= VHAL_PCNT_GPIO_NUM_MAX || gpio_num < 0)
    {
        return p_unit;
    }

    p_unit = s_pcnt_run_unit_ptr_arry[gpio_num];
    if (NULL == p_unit)
    {
        p_unit = s_pcnt_sus_unit_ptr_arry[gpio_num];
    }

    return p_unit;
}

/**
 * @brief  获取pcnt计数值
 * @param[in]  pcnt_unit                [pcnt计数unit]
 * @param[out] count                    [pcnt计数值]
 * @return     int32_t                  [操作结果, 0为成功，其他值表示失败]
 */
int32_t vhal_pcnt_get_counter_value(PCNT_UNIT_E pcnt_unit, int16_t *count)
{
    vhal_pcnt_unit_t *p_unit = vhal_pcnt_get_unit_ptr(pcnt_unit);
    if (NULL == p_unit)
    {
        return VHAL_FAIL;
    }

    *count = p_unit->count;
    return VHAL_OK;
}

/**
 * @brief  暂停pcnt计数
 * @param[in]  pcnt_unit                [pcnt计数unit]
 * @return     int32_t                  [操作结果, 0为成功，其他值表示失败]
 */
int32_t vhal_pcnt_pause_counter(PCNT_UNIT_E pcnt_unit)
{
    uint8_t gpio_num;
    vhal_pcnt_unit_t *p_unit = vhal_pcnt_get_unit_ptr(pcnt_unit);
    if (NULL == p_unit)
    {
        return VHAL_FAIL;
    }

    gpio_num = s_unit_to_gpio[pcnt_unit];
    s_pcnt_sus_unit_ptr_arry[gpio_num] = p_unit;
    PCNT_ENTER_CRITICAL(&pcnt_spinlock);
    s_pcnt_run_unit_ptr_arry[gpio_num] = NULL;
    PCNT_EXIT_CRITICAL(&pcnt_spinlock);

    return VHAL_OK;
}

/**
 * @brief  pcnt重新计数
 * @param[in]  pcnt_unit               [pcnt计数unit]
 * @return     int32_t                  [操作结果, 0为成功，其他值表示失败]
 */
int32_t vhal_pcnt_resume_counter(PCNT_UNIT_E pcnt_unit)
{
    uint8_t gpio_num;
    vhal_pcnt_unit_t *p_unit = vhal_pcnt_get_unit_ptr(pcnt_unit);
    if (NULL == p_unit)
    {
        return VHAL_FAIL;
    }

    gpio_num = s_unit_to_gpio[pcnt_unit];
    s_pcnt_sus_unit_ptr_arry[gpio_num] = NULL;
    PCNT_ENTER_CRITICAL(&pcnt_spinlock);
    s_pcnt_run_unit_ptr_arry[gpio_num] = p_unit;
    PCNT_EXIT_CRITICAL(&pcnt_spinlock);

    return VHAL_OK;
}

/**
 * @brief  清除pcnt计数
 * @param[in]  pcnt_unit               [pcnt计数unit]
 * @return     int32_t                  [操作结果, 0为成功，其他值表示失败]
 */
int32_t vhal_pcnt_clear_counter(PCNT_UNIT_E pcnt_unit)
{
    vhal_pcnt_unit_t *p_unit = vhal_pcnt_get_unit_ptr(pcnt_unit);
    if (NULL == p_unit)
    {
        return VHAL_FAIL;
    }

    PCNT_ENTER_CRITICAL(&pcnt_spinlock);
    p_unit->count = 0;
    PCNT_EXIT_CRITICAL(&pcnt_spinlock);

    return VHAL_OK;
}

/**
 * @brief  使能pcnt滤波
 * @param[in]  pcnt_unit                [pcnt计数unit]
 * @return     int32_t                  [操作结果, 0为成功，其他值表示失败]
 */
int32_t vhal_pcnt_enable_filter(PCNT_UNIT_E pcnt_unit)
{
    HAL_LOG(LOG_ERROR, "esp32c3 not support pcnt filter\n");
    return VHAL_FAIL;
}

/**
 * @brief  除能pcnt滤波
 * @param[in]  pcnt_unit                [pcnt计数unit]
 * @return     int32_t                  [操作结果, 0为成功，其他值表示失败]
 */
int32_t vhal_pcnt_disable_filter(PCNT_UNIT_E pcnt_unit)
{
    HAL_LOG(LOG_ERROR, "esp32c3 not support pcnt filter\n");
    return VHAL_FAIL;
}

/**
 * @brief  设置pcnt滤波值
 * @param[in]  pcnt_unit                [pcnt计数unit]
 * @param[in]  filter_val               [pcnt滤波值（10bit,最大1023）]
 * @return     int32_t                  [操作结果, 0为成功，其他值表示失败]
 */
int32_t vhal_pcnt_set_filter_value(PCNT_UNIT_E pcnt_unit, uint16_t filter_val)
{
    HAL_LOG(LOG_ERROR, "esp32c3 not support pcnt filter\n");
    return VHAL_FAIL;
}
#else
#include "soc/pcnt_caps.h"
#include "driver/pcnt.h"

#include "vesync_log.h"
#include "vesync_common.h"

#include "vhal_pcnt.h"
/*-----------------------------------------------------------------------------*
 *                           内部函数API实现                                         *
 *-----------------------------------------------------------------------------*/

/*
 * @brief pcnt ctrl mode转换
 * @param[in]  pcnt_ctrl_mode           [HAL层封装的pcnt ctrl mode]
 * @return     pcnt_ctrl_mode_t         [转换为SDK定义的pcnt ctrl mode]
 */
static pcnt_ctrl_mode_t vhal_pcnt_conv_ctrl_mode(PCNT_CTRL_MODE_E pcnt_ctrl_mode)
{
    switch (pcnt_ctrl_mode)
    {
        case VHAL_PCNT_MODE_KEEP:
            return PCNT_MODE_KEEP;
        case VHAL_PCNT_MODE_REVERSE:
            return PCNT_MODE_REVERSE;
        case VHAL_PCNT_MODE_DISABLE:
            return PCNT_MODE_DISABLE;
        default:
            return PCNT_MODE_MAX;
    }
}

/*
 * @brief pcnt_count_mode转换
 * @param[in]  pcnt_count_mode          [HAL层封装的pcnt count mode]
 * @return     pcnt_count_mode_t        [转换为SDK定义后的pcnt count mode]
 */
static pcnt_count_mode_t vhal_pcnt_conv_count_mode(PCNT_COUNT_MODE_E pcnt_count_mode)
{
    switch (pcnt_count_mode)
    {
        case VHAL_PCNT_COUNT_DIS:
            return PCNT_COUNT_DIS;
        case VHAL_PCNT_COUNT_INC:
            return PCNT_COUNT_INC;
        case VHAL_PCNT_COUNT_DEC:
            return PCNT_COUNT_DEC;
        default:
            return PCNT_COUNT_MAX;
    }
}

/*
 * @brief pcnt_unit转换
 * @param[in]  pcnt_unit                [HAL层封装的pcnt unit]
 * @return     pcnt_unit_t              [转换为SDK定义的pcnt unit]
 */
static pcnt_unit_t vhal_pcnt_conv_unit(PCNT_UNIT_E pcnt_unit)
{
    switch (pcnt_unit)
    {
        case VHAL_PCNT_UNIT_0:
            return PCNT_UNIT_0;
        case VHAL_PCNT_UNIT_1:
            return PCNT_UNIT_1;
        case VHAL_PCNT_UNIT_2:
            return PCNT_UNIT_2;
        case VHAL_PCNT_UNIT_3:
            return PCNT_UNIT_3;
        case VHAL_PCNT_UNIT_4:
            return PCNT_UNIT_4;
        case VHAL_PCNT_UNIT_5:
            return PCNT_UNIT_5;
        case VHAL_PCNT_UNIT_6:
            return PCNT_UNIT_6;
        case VHAL_PCNT_UNIT_7:
            return PCNT_UNIT_7;
        default:
            return PCNT_UNIT_MAX;
    }
}

/*
 * @brief  pcnt_channel转换
 * @param[in]  pcnt_channel             [HAL层封装的pcnt channel]
 * @return     pcnt_channel_t           [转换为SDK定义的pcnt channel]
 */
static pcnt_channel_t vhal_pcnt_conv_channel(PCNT_CHANNEL_E pcnt_channel)
{
    switch (pcnt_channel)
    {
        case VHAL_PCNT_CHANNEL_0:
            return PCNT_CHANNEL_0;
        case VHAL_PCNT_CHANNEL_1:
            return PCNT_CHANNEL_1;
        default:
            return PCNT_COUNT_MAX;
    }
}


/*-----------------------------------------------------------------------------*
 *                           外部函数API实现                                         *
 *-----------------------------------------------------------------------------*/

/**
 * @brief  pcnt单元配置函数
 * @param[in]  pcnt_config              [pcnt配置结构体指针]
 * @return     int32_t                  [操作结果, 0为成功，其他值表示失败]
 */
int32_t vhal_pcnt_unit_config(const vhal_pcnt_config_t *pcnt_config)
{
    int ret = -1;
    pcnt_config_t pcnt_cfg;

    pcnt_cfg.pulse_gpio_num = pcnt_config->pulse_gpio_num;
    pcnt_cfg.ctrl_gpio_num = pcnt_config->ctrl_gpio_num;
    pcnt_cfg.lctrl_mode = vhal_pcnt_conv_ctrl_mode(pcnt_config->lctrl_mode);
    pcnt_cfg.hctrl_mode = vhal_pcnt_conv_ctrl_mode(pcnt_config->hctrl_mode);
    pcnt_cfg.pos_mode = vhal_pcnt_conv_count_mode(pcnt_config->pos_mode);
    pcnt_cfg.neg_mode = vhal_pcnt_conv_count_mode(pcnt_config->neg_mode);
    pcnt_cfg.counter_h_lim = pcnt_config->counter_h_lim;
    pcnt_cfg.counter_l_lim = pcnt_config->counter_l_lim;
    pcnt_cfg.unit = vhal_pcnt_conv_unit(pcnt_config->unit);
    pcnt_cfg.channel = vhal_pcnt_conv_channel(pcnt_config->channel);

    ret = pcnt_unit_config(&pcnt_cfg);
    if (ESP_OK != ret)
    {
        return VHAL_FAIL;
    }

    return VHAL_OK;
}

/**
 * @brief  获取pcnt计数值
 * @param[in]  pcnt_unit                [pcnt计数unit]
 * @param[out] count                    [pcnt计数值]
 * @return     int32_t                  [操作结果, 0为成功，其他值表示失败]
 */
int32_t vhal_pcnt_get_counter_value(PCNT_UNIT_E pcnt_unit, int16_t *count)
{
    int ret = -1;
    pcnt_unit_t vhal_pcnt_unit;

    vhal_pcnt_unit = vhal_pcnt_conv_unit(pcnt_unit);

    ret = pcnt_get_counter_value(vhal_pcnt_unit, count);
    if (ESP_OK != ret)
    {
        return VHAL_FAIL;
    }

    return VHAL_OK;
}

/**
 * @brief  暂停pcnt计数
 * @param[in]  pcnt_unit                [pcnt计数unit]
 * @return     int32_t                  [操作结果, 0为成功，其他值表示失败]
 */
int32_t vhal_pcnt_pause_counter(PCNT_UNIT_E pcnt_unit)
{
    int ret = -1;
    pcnt_unit_t vhal_pcnt_unit;

    vhal_pcnt_unit = vhal_pcnt_conv_unit(pcnt_unit);

    ret = pcnt_counter_pause(vhal_pcnt_unit);
    if (ESP_OK != ret)
    {
        return VHAL_FAIL;
    }

    return VHAL_OK;
}

/**
 * @brief  pcnt重新计数
 * @param[in]  pcnt_unit               [pcnt计数unit]
 * @return     int32_t                  [操作结果, 0为成功，其他值表示失败]
 */
int32_t vhal_pcnt_resume_counter(PCNT_UNIT_E pcnt_unit)
{
    int ret = -1;
    pcnt_unit_t vhal_pcnt_unit;

    vhal_pcnt_unit = vhal_pcnt_conv_unit(pcnt_unit);

    ret = pcnt_counter_resume(vhal_pcnt_unit);
    if (ESP_OK != ret)
    {
        return VHAL_FAIL;
    }

    return VHAL_OK;
}

/**
 * @brief  清除pcnt计数
 * @param[in]  pcnt_unit               [pcnt计数unit]
 * @return     int32_t                  [操作结果, 0为成功，其他值表示失败]
 */
int32_t vhal_pcnt_clear_counter(PCNT_UNIT_E pcnt_unit)
{
    int ret = -1;
    pcnt_unit_t vhal_pcnt_unit;

    vhal_pcnt_unit = vhal_pcnt_conv_unit(pcnt_unit);

    ret = pcnt_counter_clear(vhal_pcnt_unit);
    if (ESP_OK != ret)
    {
        return VHAL_FAIL;
    }

    return VHAL_OK;
}

/**
 * @brief  使能pcnt滤波
 * @param[in]  pcnt_unit                [pcnt计数unit]
 * @return     int32_t                  [操作结果, 0为成功，其他值表示失败]
 */
int32_t vhal_pcnt_enable_filter(PCNT_UNIT_E pcnt_unit)
{
    int ret = -1;
    pcnt_unit_t vhal_pcnt_unit;

    vhal_pcnt_unit = vhal_pcnt_conv_unit(pcnt_unit);

    ret = pcnt_filter_enable(vhal_pcnt_unit);
    if (ESP_OK != ret)
    {
        return VHAL_FAIL;
    }

    return VHAL_OK;
}

/**
 * @brief  除能pcnt滤波
 * @param[in]  pcnt_unit                [pcnt计数unit]
 * @return     int32_t                  [操作结果, 0为成功，其他值表示失败]
 */
int32_t vhal_pcnt_disable_filter(PCNT_UNIT_E pcnt_unit)
{
    int ret = -1;
    pcnt_unit_t vhal_pcnt_unit;

    vhal_pcnt_unit = vhal_pcnt_conv_unit(pcnt_unit);

    ret = pcnt_filter_disable(vhal_pcnt_unit);
    if (ESP_OK != ret)
    {
        return VHAL_FAIL;
    }

    return VHAL_OK;
}

/**
 * @brief  设置pcnt滤波值
 * @param[in]  pcnt_unit                [pcnt计数unit]
 * @param[in]  filter_val               [pcnt滤波值（10bit,最大1023）]
 * @return     int32_t                  [操作结果, 0为成功，其他值表示失败]
 */
int32_t vhal_pcnt_set_filter_value(PCNT_UNIT_E pcnt_unit, uint16_t filter_val)
{
    int ret = -1;
    pcnt_unit_t vhal_pcnt_unit;

    vhal_pcnt_unit = vhal_pcnt_conv_unit(pcnt_unit);

    ret = pcnt_set_filter_value(vhal_pcnt_unit, filter_val);
    if (ESP_OK != ret)
    {
        return VHAL_FAIL;
    }

    return VHAL_OK;
}
#endif

