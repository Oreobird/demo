/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
 * @file        switch_production.c
 * @brief       产测功能
 * @author      Charles.Mei
 * @date        2021-07-30
 */

#include "vesync_log.h"
#include "vesync_device.h"
#include "vesync_production.h"

#include "switch_uart_cmd.h"


 /**
  * @brief 产测状态回调函数
  * @param[in]  status          [产测状态码]
  */
static void switch_production_status_cb(PRODUCTION_STATUS_E status)
 {
     switch(status)
     {
         case PRODUCTION_START:
             APP_LOG(LOG_INFO, "production start\n");
             break;
         case PRODUCTION_RUNNING:
             APP_LOG(LOG_INFO, "production running\n");
             break;
         case PRODUCTION_TEST_PASS:
             APP_LOG(LOG_INFO, "production pass\n");
             break;
         case PRODUCTION_TEST_FAIL:
             APP_LOG(LOG_INFO, "production fail\n");
             break;
         default:
             break;
     }
     switch_app_update_status_chg_rsn(STAT_CHG_RSN_PRODUCTION_STR);
     switch_uart_set_production_state(status);
 }

/**
* @brief 产测结果回调函数
* @param[in]  err_code          [产测状态码]
*/
static void switch_production_result_cb(PRODUCTION_ERROR_E err_code)
{
    if (PRD_NO_ERR == err_code)
    {
        APP_LOG(LOG_INFO, "production success\n");
    }
    else
    {
        APP_LOG(LOG_INFO, "production error %d\n", err_code);
    }
    switch_app_update_status_chg_rsn(STAT_CHG_RSN_PRODUCTION_STR);
    switch_uart_set_production_result(err_code);
}

/**
* @brief switch产测功能初始化
*/
void switch_production_init(void)
{
    vesync_production_reg_status_cb(switch_production_status_cb);
    vesync_production_reg_result_cb(switch_production_result_cb);
}


