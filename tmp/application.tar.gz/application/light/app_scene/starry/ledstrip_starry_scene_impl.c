/**
* Copyright © Vesync Technologies Co.Ltd. 2022. All rights reserved
* @file         ledstrip_starry_scene_impl.c
* @brief        星夜场景回调业务实现
* @author       Joshua
* @date         2022-1-14
*/

#include <string.h>
#include "vesync_log.h"
#include "vesync_common.h"
#include "vhal_utils.h"
#include "starry.h"
#include "light.h"

static int starry(void *param)
{
    UNUSED(param);
    APP_LOG(LOG_DEBUG, "starry scene\n");
    light_param_t light_param[] = {{0, 0, 0, 0, 20}, {0, 0, 0, 0, 0}, {0, 0, 0, 0, 50}, {0, 0, 0, 0, 20},
                                 {0, 0, 0, 0, 80}, {0, 0, 0, 0, 50}, {0, 0, 0, 0, 100}, {0, 0, 0, 0, 30},
                                 {0, 0, 0, 0, 0}, {0, 0, 0, 0, 40}, {0, 0, 0, 0, 60}, {0, 0, 0, 0, 30}};
    uint8_t step = 3;
    uint8_t param_num = SIZEOF_ARRAY(light_param);
    vhal_utils_get_random(&step, 1);
    step = step % param_num;
    app_light_color_flow(light_param, param_num, step % SIZEOF_ARRAY(light_param), LIGHT_REFLESH_INTERVAL_MS, 0, false);
    return APP_OK;
}

int starry_light_scene_impl_init(void)
{
    light_scene_t light_scene;
    memset(&light_scene, 0, sizeof(light_scene_t));
    light_scene.light_cb = starry;
    return starry_light_scene_reg(&light_scene);
}

