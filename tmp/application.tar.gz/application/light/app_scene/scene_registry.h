/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
* @file         scene_registry.h
* @brief        场景注册中心
* @author       Joshua
* @date         2021-11-17
*/

#include <stdint.h>
#include <stdbool.h>
#include "vesync_list.h"
#include "vesync_common.h"
#include "vesync_mutex.h"

#ifndef __SCENE_REGISTRY_H__
#define __SCENE_REGISTRY_H__

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief  场景结构体
 */
typedef struct
{
    struct list_head list;
    int type;      // 场景类型
    int id;        // 场景id
    int data_size; // 场景数据长度
    char ctx[0];   // 场景数据
} scene_t;

/**
 * @brief  场景注册中心结构体
 */
typedef struct
{
    int build_in_num;             // 内置场景个数
    int custom_num;               // 自定义场景
    vesync_mutex_t mutex;         // 链表互斥锁
    struct list_head list;        // 内置场景链表
    struct list_head light_list;  // 自定义场景链表
} scene_registry_t;

/**
 * @brief  场景注册中心初始化
 * @return  int             [成功：APP_OK，失败：APP_FAIL]
 */
int scene_registry_init(void);

/**
 * @brief  场景注册中心释放资源
 * @return  int             [成功：APP_OK，失败：APP_FAIL]
 */
int scene_registry_deinit(void);

/**
 * @brief  场景注册中心注册场景
 * @param[in] p_scene       [场景结构体指针]
 * @return  int             [成功：APP_OK，失败：APP_FAIL]
 */
int scene_registry_add(scene_t *p_scene);

/**
 * @brief  场景注册中心获取场景
 * @param[in] type          [场景类型]
 * @param[in] id            [场景id]
 * @return  scene_t*        [成功：场景结构体指针，失败：NULL]
 */
scene_t *scene_registry_get(int type, int id);

/**
 * @brief  获取自定义场景个数
 * @return int              [自定义场景个数]
 */
int scene_registry_get_custom_num(void);

/**
 * @brief  场景注册中心删除场景
 * @param[in] type          [场景类型]
 * @param[in] id            [场景id]
 * @return  int             [成功：APP_OK，失败：APP_FAIL]
 */
int scene_registry_del(int type, int id);

/**
 * @brief  场景注册中心获取下一个场景
 * @param[in] type          [场景类型]
 * @param[in] id            [场景id]
 * @return  scene_t*        [成功：场景结构体指针，失败：NULL]
 */
scene_t *scene_registry_get_next(int type, int id);

/**
 * @brief  场景注册中心遍历场景
 * @param[in] type          [场景类型]
 * @param[in] cb            [回调，输入场景id]
 */
void scene_registry_for_each(int type, int (*cb)(int id));

#ifdef __cplusplus
}
#endif

#endif



