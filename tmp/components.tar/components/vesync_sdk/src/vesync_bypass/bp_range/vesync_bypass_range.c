/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_bypass_range.c
 * @brief       bypass处理接口
 * @date        2021-05-17
 */
#include <string.h>

#include "vesync_common.h"
#include "vesync_memory.h"

#include "vesync_bypass_internal.h"


/**
 * @brief 调整设备真实档位接口
 * @param p_trace_msg trace message
 * @param json数据指针
 * @return BYPASS_ERR_E
 */
static BYPASS_ERR_E bypass_method_adjust_real_range_handle(bypass_trace_msg_t *p_trace_msg, cJSON *json)
{
    BYPASS_ERR_E ret = BP_OK;

    if ((NULL == json)||(NULL == p_trace_msg))
        return BP_ERROR;

    bypass_range_para_t *para = (bypass_range_para_t *)vesync_malloc(sizeof(bypass_range_para_t));
    if (NULL == para)
    {
        return BP_ERR_NOMEM;
    }

    memset(para, 0, sizeof(bypass_range_para_t));

    cJSON *json_data = cJSON_GetObjectItemCaseSensitive(json, "value");
    if (cJSON_IsNumber(json_data))
    {
        para->value = json_data->valueint;
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "type");
    if (cJSON_IsString(json_data))
    {
        if (strcmp(json_data->valuestring, "mist") == 0)
            para->type = BP_RANGE_MIST;
        else if (strcmp(json_data->valuestring, "warm") == 0)
            para->type = BP_RANGE_WARM;
        else if (strcmp(json_data->valuestring, "wind") == 0)
            para->type = BP_RANGE_WIND;
        else if (strcmp(json_data->valuestring, "target_humidity") == 0)
            para->type = BP_RANGE_TGT_HUM;
        else if (strcmp(json_data->valuestring, "night_light_brightness") == 0)
            para->type = BP_RANGE_LIGHT_BRIGHTNESS;
        else
        {
            ret = BP_ERR_ARG;
            goto _exit;
        }
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_ADJUST_REAL_RANGE);
    if (method_cb)
    {
        method_cb(p_trace_msg, para, sizeof(bypass_range_para_t));
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

_exit:
    vesync_free(para);
    return ret;
}

/**
 * @brief 调整设备虚拟档位接口
 * @param p_trace_msg trace message
 * @param json数据指针
 * @return BYPASS_ERR_E
 */
static BYPASS_ERR_E bypass_method_adjust_virtual_range_handle(bypass_trace_msg_t *p_trace_msg, cJSON *json)
{
    BYPASS_ERR_E ret = BP_OK;

    if ((NULL == json)||(NULL == p_trace_msg))
        return BP_ERROR;

    bypass_range_para_t *para = (bypass_range_para_t *)vesync_malloc(sizeof(bypass_range_para_t));
    if (NULL == para)
    {
        return BP_ERR_NOMEM;
    }

    memset(para, 0, sizeof(bypass_range_para_t));

    cJSON *json_data = cJSON_GetObjectItemCaseSensitive(json, "value");
    if (cJSON_IsNumber(json_data))
    {
        para->value = json_data->valueint;
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "type");
    if (cJSON_IsString(json_data))
    {
        if (strcmp(json_data->valuestring, "mist") == 0)
            para->type = BP_RANGE_MIST;
        else if (strcmp(json_data->valuestring, "warm") == 0)
            para->type = BP_RANGE_WARM;
        else if (strcmp(json_data->valuestring, "wind") == 0)
            para->type = BP_RANGE_WIND;
        else
        {
            ret = BP_ERR_ARG;
            goto _exit;
        }
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_ADJUST_VIRTUAL_RANGE);
    if (method_cb)
    {
        method_cb(p_trace_msg, para, sizeof(bypass_range_para_t));
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

_exit:
    vesync_free(para);
    return ret;
}


static bypass_item_data_t range_method_tbl[] = {
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_ADJUST_REAL_RANGE, "adjustRealRange", bypass_method_adjust_real_range_handle, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_ADJUST_VIRTUAL_RANGE, "adjustVirtualRange", bypass_method_adjust_virtual_range_handle, NULL},
};

void vesync_bypass_range_init(void)
{
    for (int i = 0; i < SIZEOF_ARRAY(range_method_tbl); i++)
    {
        bypass_item_t *item = vesync_bypass_init_item(&range_method_tbl[i]);
        if (item != NULL)
        {
            vesync_bypass_add_item(item);
        }
    }
}
