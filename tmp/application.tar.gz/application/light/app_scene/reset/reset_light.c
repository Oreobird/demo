/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
* @file         netcfg_light.c
* @brief        产测灯效控制
* @author       Joshua
* @date         2021-11-20
*/

#include <string.h>
#include <stdint.h>
#include "vesync_common.h"
#include "vesync_memory.h"
#include "vesync_log.h"
#include "reset_light.h"

int reset_light_scene_reg(reset_light_scene_t *light_scene)
{
    VCOM_NULL_PARAM_CHK(light_scene, return APP_FAIL);

    scene_t *thiz = (scene_t *) vesync_malloc(sizeof(scene_t) + sizeof(reset_light_scene_t));
    if (thiz == NULL)
    {
        APP_LOG(LOG_ERROR, "production light scenee reg fail\n");
        return APP_FAIL;
    }

    memset(thiz, 0, sizeof(scene_t) + sizeof(reset_light_scene_t));

    reset_light_scene_t *ctx = (reset_light_scene_t *)thiz->ctx;

    ctx->reset_process_light = light_scene->reset_process_light;

    thiz->type = SCENE_RESET;
    thiz->id = 0;

    scene_registry_add(thiz);

    return APP_OK;
}

int reset_light_scene_unreg(void)
{
    return scene_registry_del(SCENE_RESET, 0);
}


