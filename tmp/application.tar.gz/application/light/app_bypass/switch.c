/*
 * Copyright © Vesync Technologies Co.Ltd. 2022. All rights reserved.
 * @file        switch.c
 * @brief       set_switch处理接口
 * @date        2022-01-24
 */

#include <stdio.h>

#include "vesync_common.h"
#include "vesync_log.h"
#include "vesync_memory.h"
#include "app_bypass.h"
#include "event.h"
#include "device.h"
#include "scene.h"

int request_data_handle_for_set_switch(bp_set_switch_request_t *request_data, int *err_code, char *err_msg, void **extra)
{
    UNUSED(extra);
    dev_cfg_t *p_dev_cfg = app_device_cfg_get();
    if (p_dev_cfg == NULL)
    {
        *err_code = BP_ERR_PARA_ILLEGAL;
        snprintf(err_msg, BP_ERR_MSG_LEN, "device abnormal");
        return APP_FAIL;
    }

    if (p_dev_cfg->flash->cfg.onoff != (uint8_t)(request_data->power_switch))
    {
        p_dev_cfg->flash->cfg.onoff = (uint8_t)(request_data->power_switch);
        app_device_cfg_save(p_dev_cfg);

        uint8_t scene_type = SCENE_LIGHT;
        uint16_t scene_id = p_dev_cfg->flash->cfg.scene_id;
        int ret = app_scene_info_get_from_mode(&scene_type, &scene_id);
        if (ret != APP_OK)
        {
            *err_code = BP_ERR_PARA_ILLEGAL;
            snprintf(err_msg, BP_ERR_MSG_LEN, "light mode error.");
            return APP_FAIL;
        }

        BYPASS_NOTIFY(scene_type, scene_id);
    }

    return APP_OK;
}

int request_data_handle_for_toggle_switch(bp_toggle_switch_request_t *request_data, int *err_code, char *err_msg, void **extra)
{
    UNUSED(extra);
    dev_cfg_t *p_dev_cfg = app_device_cfg_get();
    if (p_dev_cfg == NULL)
    {
        *err_code = BP_ERR_PARA_ILLEGAL;
        snprintf(err_msg, BP_ERR_MSG_LEN, "device abnormal");
        return APP_FAIL;
    }

    p_dev_cfg->flash->cfg.onoff = (p_dev_cfg->flash->cfg.onoff == LIGHT_STATUS_OFF) ? LIGHT_STATUS_ON : LIGHT_STATUS_OFF;
    app_device_cfg_save(p_dev_cfg);

    uint8_t scene_type = SCENE_LIGHT;
    uint16_t scene_id = p_dev_cfg->flash->cfg.scene_id;
    int ret = app_scene_info_get_from_mode(&scene_type, &scene_id);
    if (ret != APP_OK)
    {
        *err_code = BP_ERR_PARA_ILLEGAL;
        snprintf(err_msg, BP_ERR_MSG_LEN, "light mode error.");
        return APP_FAIL;
    }

    BYPASS_NOTIFY(scene_type, scene_id);

    return APP_OK;

}

