/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_away.h
 * @brief       离家模块API定义
 * @date        2021-06-22
 */

#ifndef __VESYNC_AWAY_H__
#define __VESYNC_AWAY_H__

#include <stdint.h>

#ifdef __cplusplus
extern "C"
{
#endif

#define AWAY_RANDOM_TIME_MAX_NUM (6)    // 最大的Away随机时间点个数
#define AWAY_RANDOM_TIME_MIN_NUM (2)    // 最小的Away随机时间点个数

/**
 * @brief Away结果类型
 */
typedef enum
{
    AWAY_OK = 0,             // OK
    AWAY_ERR = -1,           // 一般错误
    AWAY_MEM_ERR = -2,       // 内存出错：malloc失败
    AWAY_BUF_ERR = -3,       // 缓存出错：buffer溢出
    AWAY_CFG_ERR = -4,       // 读取或者写入持久化的Away配置信息错误
    AWAY_CFG_NO_EXIST = -5,  // 不存在持久化的Away配置信息
    AWAY_EXIST_ERR = -6,     // Away配置已经存在，不能重复添加
    AWAY_NO_EXIST = -7,      // Away配置不存在，无法获取或者删除
    AWAY_NO_INIT = -8,       // Away模块没有初始化
    AWAY_PAR_INV = -9,       // Away参数非法
} AWAY_RESULT_E;

/**
 * @brief Away事件类型
 */
typedef enum
{
    AWAY_START_ACTION = 0,      // 开始时间动作
    AWAY_END_ACTION = 1,        // 结束时间动作
    AWAY_RANDOM_ON = 2,         // 随机开，中间执行3次随机开关动作
    AWAY_RANDOM_OFF = 3,        // 随机关
} AWAY_EVENT_E;

/**
 * @brief Away 随机时间点(Random Time Ponits)
 */
typedef struct
{
    uint32_t point_num;                        // Away随机点数量
    uint32_t points[AWAY_RANDOM_TIME_MAX_NUM]; // Away随机时间点列表，成员为基于秒数的时刻值
    uint32_t exec_cnt;                         // 执行次数计数
} vesync_away_tp_t;

/**
 * @brief Away 配置定义
 */
typedef struct
{
    uint32_t start_clk_sec; // 开始的时间时刻秒数
    uint32_t end_clk_sec;   // 结束的时间时刻秒数
    uint8_t  repeat_config; // Away的重复功能配置
} vesync_away_t;

/**
 * @brief Away读取配置二进制数据回调
 * @param[out]  p_rd_buf            [指向数据读取的Buffer]
 * @param[in]   buf_len             [Buffer的长度]
 * @param[out]  p_rd_len            [指向储存读取的长度]
 * @return      int                 [AWAY_RESULT_E]
 */
typedef int (*away_rd_cfg_cb_t)(uint8_t *p_rd_buf, uint32_t buf_len, uint32_t *p_rd_len);

/**
 * @brief Away写入配置二进制数据回调
 * @param[in]  p_wr_buf             [指向被写入的Buffer]
 * @param[in]  len                  [将被写入的数据长度]
 * @return      int                 [AWAY_RESULT_E]
 */
typedef int (*away_wr_cfg_cb_t)(uint8_t *p_wr_buf, uint32_t len);

/**
 * @brief Away Application任务执行回调
 * @param[in]   p_cfg               [回调给应用层的配置项数据]
 * @param[in]   p_tp                [回调给应用层的生成的时间点数据]
 * @param[in]   event               [Away 回调执行的输入事件]
 * @return      int                 [AWAY_RESULT_E]
 */
typedef int (*away_exec_app_task_cb_t)(vesync_away_t *p_cfg, vesync_away_tp_t *p_tp, AWAY_EVENT_E event);

/**
 * @brief Away 模块初始化参数数据结构定义
 */
typedef struct
{
    away_wr_cfg_cb_t wr_cfg_cb;                 // 底层写配置回调，初始化时置空则注册平台默认函数
    away_rd_cfg_cb_t rd_cfg_cb;                 // 底层读配置回调，初始化时置空则注册平台默认函数
    away_exec_app_task_cb_t exec_app_task_cb;   // APP任务执行回调
} vesync_away_param_t;

/**
 * @brief Away 初始化
 * @param[in]   p_away_cbs          [Away 初始化注册的回调函数]
 * @return      int                 [AWAY_RESULT_E]
 */
int vesync_away_init(vesync_away_param_t *p_away_cbs);

/**
 * @brief Away 添加设置
 * @param[in]   p_away_cfg          [输入的 Away 配置]
 * @return      int                 [AWAY_RESULT_E]
 */
int vesync_away_add(vesync_away_t *p_away_cfg);

/**
 * @brief Away 删除配置
 * @return      int                 [AWAY_RESULT_E]
 */
int vesync_away_del(void);

/**
 * @brief Away 读取配置
 * @param[out]  p_away_cfg          [读取出来的Away配置]
 * @param[out]  p_rt_clock_sec      [读取出来的Away目前使用的随机时间表]
 * @return      int                 [AWAY_RESULT_E， AWAY_NO_EXIST：读取失败，没有Away配置]
 */
int vesync_away_get(vesync_away_t *p_away_cfg, vesync_away_tp_t *p_rt_clock_sec);

/**
 * @brief Away 清除所有配置
 * @return      int                 [AWAY_RESULT_E]
 */
int vesync_away_clear(void);

#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_AWAY_H__ */