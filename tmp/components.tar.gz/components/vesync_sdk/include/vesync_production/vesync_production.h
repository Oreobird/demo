/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_production.h
 * @brief       产测模块接口
 * @date        2021-05-25
 */

#ifndef __VESYNC_PRODUCTION_H__
#define __VESYNC_PRODUCTION_H__


#include <stdint.h>
#include <stdbool.h>


#ifdef __cplusplus
extern "C"
{
#endif /* __cplusplus */

/**
 * @brief 产测错误码定义
 */
typedef enum
{
    PRD_NO_ERR                  = 0,
    PRD_CID_ERR                 = 1,    // cid 写入失败
    PRD_WIFI_VERSION_ERR        = 2,    // wifi固件版本测试失败
    PRD_MCU_VERSION_ERR         = 3,    // mcu固件版本测试失败
    PRD_WIFI_RSSI_ERR           = 4,    // wifi rssi测试失败
    PRD_BLE_RSSI_ERR            = 5,    // ble rssi测试失败
    PRD_NET_COMMUNICATION_ERR   = 6,    // 网络通信失败
    PRD_AREA_CODE_ERR           = 7,    // 区域码异常
    PRD_HUMIDITY_ERR            = 8,    // 湿度值异常
    PRD_TEMPERATURE_ERR         = 9,    // 温度值异常
} PRODUCTION_ERROR_E;


/**
 * @brief 产测状态
 */
typedef enum
{
    PRODUCTION_START        = 0,       // 产测模式开始
    PRODUCTION_RUNNING      = 1,       // 产测模式运行中
    PRODUCTION_TEST_PASS    = 2,       // 产测模式测试通过
    PRODUCTION_TEST_FAIL    = 3,       // 产测模式测试失败
    PRODUCTION_EXIT         = 4,       // 产测模式退出
    PRODUCTION_LOGIN_FAIL   = 5,       // 产测模式固件登录产测服务器失败
    PRODUCTION_WIFI_TEST    = 6,       // 产测WiFi自检模式
} PRODUCTION_STATUS_E;


/**
 * @brief 产测数据key id 定义，每个id定义好后，数据项增删时不能重复使用
 */
typedef enum
{
    PRODUCTION_KEY_ID_CFG_VERSION    = 0,    //产测数据版本，uint8_t
    PRODUCTION_KEY_ID_CID            = 1,    //产测CID，string型，32byte
    PRODUCTION_KEY_ID_TEST_FAIL_FLAG = 2,    //产测失败标志，bool型，默认true
    PRODUCTION_KEY_ID_ERROR_CODE     = 3,    //产测错误码，uint8_t
    PRODUCTION_KEY_ID_MAX
} PRODUCTION_CFG_KEY_E;



/**
 * @brief  获取产测数据
 * @param[in]  key_id          [key id值]
 * @param[out]  value          [产测数据]
 * @param[in,out]  len         [in:value缓存长度，out：value有效长度]
 * @return  int                [成功：SDK_OK，失败：SDK_FAIL]
 */
int vesync_production_get_value_by_key(uint8_t key_id,uint8_t *value,uint16_t *len);


/**
 * @brief  设置产测数据
 * @param[in]  key_id          [key id值]
 * @param[out]  value          [产测数据]
 * @param[in,out]  len         [value有效长度]
 * @return  int                [成功：SDK_OK，失败：SDK_FAIL]
 */
int vesync_production_set_value_by_key(uint8_t key_id,uint8_t *value,uint16_t len);


/**
 * @brief  产测结果回调函数指针，该函数由应用层定义，在进入产测模式后的产测特定阶段会回调该函数
 * @param[in]  status          [产测状态]
 */
typedef void (*production_status_cb_t)(PRODUCTION_STATUS_E status);


/**
 * @brief  产测结果回调函数指针，该函数由应用层定义，产测结果回调函数
 * @param[in]  err_code        [产测错误码]
 */
typedef void (*production_result_cb_t)(PRODUCTION_ERROR_E err_code);


/**
 * @brief  产测结果回调函数指针，该函数由应用层定义，产测过程需要应用层传递的参数
 * @param[in]  p_data          [应用层传递的数据指针，指针向JSON数据]
 * @param[in]  name            [JSON数据的名称]
 */
typedef void (*production_para_cb_t)(void *p_data, char *name);


/**
 * @brief  产测连接路由器测试回调函数
 * @param[in]  val            [连接结果, 0:失败，1:成功]
 */
typedef void (*production_wifi_cb_t)(int val);

/**
 * @brief  灯泡老化产测回调函数指针
 */
typedef void (*production_pre_test_cb_t)(void);


/**
 * @brief  注册灯泡老化产测回调函数
 * @param[in]  cb               [产测前回调函数指针]
 */
void vesync_production_reg_pre_test_cb(production_pre_test_cb_t cb);

/**
 * @brief  注册产测状态(进度)回调函数
 * @param[in]  cb               [产测状态回调函数指针]
 */
void vesync_production_reg_status_cb(production_status_cb_t cb);


/**
 * @brief  注册产测结果回调函数
 * @param[in]  cb               [产测结果回调函数指针]
 */
void vesync_production_reg_result_cb(production_result_cb_t cb);


/**
 * @brief  注册产测获取设备参数回调函数
 * @param[in]  cb               [产测获取设备参数回调函数指针]
 */
void vesync_production_reg_extend_data_cb(production_para_cb_t cb);


/**
 * @brief  MCU已准备完毕，通知产测模块
 * @note         暂不使用
 */
void vesync_production_set_mcu_ready(void);


/**
 * @brief  进入产测模式
 * @param[in]  reset_record    [true，重置设备重连记录；false，不重置设备连接记录]
 * @return  int                [成功：SDK_OK，失败：SDK_FAIL]
 */
int vesync_production_enter_testmode(bool reset_record);


/**
 * @brief  获取产测状态
 * @return  PRODUCTION_STATUS_E  [产测状态值]
 */
PRODUCTION_STATUS_E vesync_production_get_status(void);


/**
 * @brief  产测连接路由器测试
 * @param[in]  ssid            [路由器ssid]
 * @param[in]  passwd          [路由器密码, 如没有密码传NULL]
 * @param[in]  cb              [测试结果回调函数]
 */
void vesync_production_connect_router_test(const char *ssid, const char *passwd, production_wifi_cb_t cb);


/**
 * @brief  产测完成，错误码设置
 * @param[in]  err_code        [产测错误码]
 */
void vesync_production_complete_error(PRODUCTION_ERROR_E err_code);


/**
 * @brief  产测成功，收到服务器的ack后的回调，设置产测成功
 */
void vesync_production_complete_success_ack_cb(void);


#ifdef __cplusplus
}
#endif /* __cplusplus */


#endif /* __VESYNC_PRODUCTION_H__ */

