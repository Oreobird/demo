/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        outlet_inching.h
 * @brief       outlet inching头文件
 * @author      CharlesMei
 * @date        2021-06-23
 */


#ifndef __OUTLET_INCHING_H__
#define __OUTLET_INCHING_H__

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#define  INCHING_KLV_DATA_BUF_LEN 60
/**
 * @brief inching状态
 */
typedef enum
{
    INCHING_STOP = 0,
    INCHING_COUNTDOWN = 1,
    INCHING_SUSPEND = 2,        // 暂未使用
    INCHING_UNKNOW
} INCHING_STATE_E;

/**
 * @brief inching配置数据key定义
 */
typedef enum
{
    INCHING_KEY_VERSION = 0,
    INCHING_KEY_TOTAL_SEC = 1,
    INCHING_KEY_MAX
}INCHING_CFG_KEY_E;

/**
 * @brief inching参数
 */
typedef struct
{
    uint32_t remain_sec;
    uint32_t total_sec;
    INCHING_STATE_E state;
} inching_status_t;


/**
 * @brief       outlet inching启动
 * @return      int         [成功：APP_OK；失败：APP_FAIL]
 */
int outlet_inching_start(void);

/**
 * @brief       outlet inching停止
 * @return      int         [成功：APP_OK；失败：APP_FAIL]
 */
int outlet_inching_stop(void);

/**
 * @brief       outlet inching增加配置
 * @param[in]   total_sec   [inching配置的总时间]
 * @return      int         [成功：APP_OK；失败：APP_FAIL]
 * @note        只支持一个配置，此函数即为设置配置，同时会停止当前inching
 */
int outlet_inching_add_cfg(uint32_t total_sec);

/**
 * @brief       outlet inching删除配置
 * @return      int         [成功：APP_OK；失败：APP_FAIL]
 * @note        只支持一个配置，此函数同时会停止当前inching
 */
int outlet_inching_delete_cfg(void);

/**
 * @brief       outlet inching获取当前状态
 * @return      uint32_t    [inching状态]
 */
const inching_status_t* outlet_inching_get_status(void);

/**
 * @brief       outlet inching初始化
 */
void outlet_inching_init(void);


#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* __OUTLET_INCHING_H__ */

