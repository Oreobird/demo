/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_away_internal.h
 * @brief       Away模块接口定义
 * @author      Herve.lin
 * @date        2021-06-28
 */

#ifndef __VESYNC_AWAY_INTERNAL_H__
#define __VESYNC_AWAY_INTERNAL_H__

#include <stdint.h>
#include <stdbool.h>

#include "vesync_list.h"
#include "vesync_timer.h"
#include "vesync_mutex.h"
#include "vesync_away.h"
#include "vesync_cfg_internal.h"

#ifdef __cplusplus
extern "C"
{
#endif

#define AWAY_DEBUG_PRINT 0                                  // Away 模块调试打印开关
#define AWAY_CFG_VERSION (PR_AWAY_CFG_VERSION)              // Away 配置版本定义
#define AWAY_CYCLE_TIMER_INTERVAL (10000)                   // 定时器轮询间隔
#define AWAY_MGT_INIT_VAL {is_init:false, is_running:false} // Away模块管理结构体初始化值
#define AWAY_DEFAULT_USER_CFG_KEY "away_mod"                // Away模块配置存储KEY

/**
 * @brief  Away配置数据key定义
 */
typedef  enum
{
    AWAY_KEY_ID_CFG_VERSION = 0,
    AWAY_KEY_ID_POINT_NUM = 1,
    AWAY_KEY_ID_POINT = 2,
    AWAY_KEY_ID_GENERATED_LOCAL_TS = 3,
    AWAY_KEY_ID_START_CLK_SEC = 4,
    AWAY_KEY_ID_END_CLK_SEC = 5,
    AWAY_KEY_ID_ENABLE = 6,
    AWAY_KEY_ID_REPEAT_FLAG = 7,
    AWAY_KEY_ID_MODIFY_LOCAL_TS = 8,
    AWAY_KEY_ID_EXEC_CNT = 9,
    AWAY_KEY_ID_EXEC_MAX
}AWAY_CFG_KEY_E;

/**
 * @brief  Away 实例
 */
typedef struct
{
    bool is_init;                // Away 初始化标志
    bool is_running;             // Away 运行状态
    vesync_mutex_t mutex;        // Away 实例互斥量
    vesync_timer_t *timer;       // Away 定时器句柄
    vesync_away_t config;        // Away 配置
    vesync_away_tp_t rnd_times;  // Away 随机时间点缓存
    bool enable;                 // Away 配置使能状态
    uint32_t modify_local_ts;    // 配置项修改时的本地时间戳，可以在判断时，随时区的变化偏移过期的时间
    uint32_t generated_local_ts; // Away随机时间点生成时的当地时间戳记录，用于判断随机时间表是否当天有效
} away_mgt_t;

/**
 * @brief Away 配置项序列化
 * @param[in]  p_mgt        [输入的Away管理器]
 * @param[out] p_buf        [输出的Buffer]
 * @param[out] buf_len      [输出的Buffer的长度]
 * @param[out] p_out_size   [序列化的二进制流的长度]
 * @return int              [AWAY_RESULT_E]
 */
int away_cfg_marshal(away_mgt_t *p_mgt, uint8_t *p_buf, uint32_t buf_len, uint32_t *p_out_size);

/**
 * @brief Away 配置项反序列化
 * @param[in]  p_buf        [输入的二进制流数据]
 * @param[in]  data_len     [输入的二进制流数据的长度]
 * @param[out] p_mgt        [输出的Away管理器]
 * @return int              [AWAY_RESULT_E]
 */
int away_cfg_unmarshal(uint8_t *p_buf, uint32_t data_len, away_mgt_t *p_mgt);

/**
 * @brief Away 默认的读取配置回调
 * @param[out] p_rd_buf      [指向数据读取的Buffer]
 * @param[in]  buf_len       [Buffer的长度]
 * @param[out] p_rd_len      [指向储存读取的长度]
 * @return int               [AWAY_RESULT_E]
 */
int away_default_rd_cfg_cb(uint8_t *p_rd_buf, uint32_t buf_len, uint32_t *p_rd_len);

/**
 * @brief Away 默认的写入配置回调
 * @param[in]  p_wr_buf      [指向被写入的Buffer]
 * @param[in]  len           [将被写入的数据长度]
 * @return int               [AWAY_RESULT_E]
 */
int away_default_wr_cfg_cb(uint8_t *p_wr_buf, uint32_t len);

#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_AWAY_INTERNAL_H__ */
