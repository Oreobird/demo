/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_timer_internal.h
 * @brief       定义timer相关宏及通用结构体，供内部调用
 * @date        2022-01-24
 */

#ifndef __VESYNC_TIMER_INTERNAL_H__
#define __VESYNC_TIMER_INTERNAL_H__

#ifdef __cplusplus
extern "C" {
#endif

#ifndef CONFIG_VESYNC_USE_LOOP_TIMER

#define PORT_VESYNC_DELAY  \
(xTaskGetCurrentTaskHandle() == xTimerGetTimerDaemonTaskHandle() ? 0 : portMAX_DELAY)

#else

#include "vesync_loop_timer_internal.h"

#define VESYNC_TIMER_TASK_NAME          "vesync_timer"
#define VESYNC_TIMER_TASK_STACKSIZE     (4 * 1024)
#define VESYNC_TIMER_TASK_PRIO          TASK_PRIORITY_LOW
#define TIMER_EVENT_QUEUE_MAX_NUM       (10)
#define PORT_VESYNC_DELAY  \
(xTaskGetCurrentTaskHandle() == s_task_handle ? VESYNC_OS_NO_WAIT : VESYNC_OS_WAIT_FOREVER)


typedef enum
{
    TIMER_EV_ADD = 0,
    TIMER_EV_DEL,
    TIMER_EV_CH_PERIOD,
    TIMER_EV_FREE,
} TIMER_EVENT_E;

typedef struct
{
    TIMER_EVENT_E id;
    vloop_timer_t *loop_timer;
    long  period_new;
} vesync_timer_ev_t;

/**
 * @brief  初始化定时器任务
 * @return int                         [成功：VOS_OK；失败：VOS_FAIL]
 */
int vesync_timer_init(void);


#endif

#ifdef __cplusplus
}
#endif
#endif /* __VESYNC_TIMER_INTERNAL_H__ */
