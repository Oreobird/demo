/**
 * Copyright © Vesync Technologies Co.Ltd. 2019-2021. All rights reserved.
 * @file    hal_ota.c
 * @brief   esp32/esp8266的ota功能实现
 * @author  Dongri + Owen（@8266）
 * @date    2019-09-10
 */
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "mbedtls/md5.h"
#include "esp_partition.h"
#include "esp_ota_ops.h"
#include "esp_system.h"

#include "nvs.h"
#include "nvs_flash.h"

#include "vesync_log.h"
#include "vesync_common.h"

#include "vhal_ota_internal.h"

#ifdef CONFIG_IDF_TARGET_ESP8266
#include "lwip/netdb.h"
#endif /* CONFIG_IDF_TARGET_ESP8266 */

static vhal_esp_ota_status_t s_ota_status;          // OTA升级状态

/*-----------------------------------------------------------------------------*
 *                           内部函数API实现                                     *
 *-----------------------------------------------------------------------------*/

/**
 * @brief  更新OTA升级状态
 * @param status        [ota状态]
 * @param prog          [固件下载进度]
 */
static void vhal_ota_update_status(VHAL_OTA_STATE_E status, uint8_t prog)
{
    s_ota_status.status = status;
    if (NULL != s_ota_status.status_cb)
    {
        s_ota_status.status_cb(status, prog);
    }
}

/**
 * @brief  初始化头部检验数据@MD5
 * @return    int32_t          [成功/失败]
 */
static int32_t vhal_ota_md5_check_init(void)
{
    s_ota_status.md5 =  (mbedtls_md5_context*)malloc(sizeof(mbedtls_md5_context) + 1) ;
    if (NULL == s_ota_status.md5)
    {
        return VHAL_FAIL;
    }

    memset(s_ota_status.md5, 0, sizeof(mbedtls_md5_context) + 1);
    mbedtls_md5_init(s_ota_status.md5);
#if defined(MBEDTLS_DEPRECATED)
    mbedtls_md5_starts(s_ota_status.md5);
#else
    mbedtls_md5_starts_ret(s_ota_status.md5);
#endif
    return VHAL_OK;
}

/**
 * @brief  头部数据检验@MD5
 * @param[in]   percent         [升级百分百]
 * @return     int32_t          [OK检验通过，fail检验失败]
 */
static int32_t vhal_ota_md5_check_done(uint8_t percent)
{
    uint8_t tmp1 = 0x0, tmp2 = 0x0;
    unsigned char hash[16] = {0};
    uint8_t md5_str[MD5_STR_LEN + 1] = {0};

    if (NULL == s_ota_status.md5)
    {
        return VHAL_FAIL;
    }

    mbedtls_md5_finish(s_ota_status.md5, hash);
    mbedtls_md5_free(s_ota_status.md5);
    LOG_RAW_HEX(LOG_DEBUG, "Hash: ", hash, sizeof(hash));

    for (uint8_t idx = 0; idx < 16; idx++)
    { // 格式转换
        tmp1 = (hash[idx]>>4)&0x0F;
        tmp2 = hash[idx]&0x0F;

        if (tmp1 < 0xA)
            md5_str[idx*2] = tmp1 + 0x30;
        else // A~F
            md5_str[idx*2] = tmp1 + 0x37;
        if (tmp2 < 0xA)
            md5_str[idx*2+1] = tmp2 + 0x30;
        else // A~F
            md5_str[idx*2+1] = tmp2 + 0x37;
    }

    if (NULL != s_ota_status.md5_check_cb)
    {
        if (0 != s_ota_status.md5_check_cb(md5_str))
        {
            HAL_LOG(LOG_ERROR, "md5 check fail!\n");
            return VHAL_FAIL;
        }
    }
    else
    {
        vhal_ota_update_status(VHAL_OTA_ST_FAIL, percent);   // 其他原因
        return VHAL_FAIL;
    }

    return VHAL_OK;
}

/**
 * @brief  MD5数据更新
 * @param[in]   p_buff          [接收到的固件buff]
 * @param[in]   buff_len        [固件buff的长度]
 */
static void vhal_ota_md5_update(uint8_t *p_buff, int32_t buff_len)
{
    if (NULL != s_ota_status.md5)
    {
        mbedtls_md5_update(s_ota_status.md5, p_buff, buff_len);
    }
}

/**
 * @brief  释放申请的校验数据空间
 */
static void vhal_ota_md5_release(void)
{
    if(NULL != s_ota_status.md5)
    {
        free(s_ota_status.md5);
        s_ota_status.md5 = NULL;
    }
}


#if defined(CONFIG_IDF_TARGET_ESP8266)
/**
 * @brief  从http的URL中提取host和port
 * @param[in]  pUrl                 [入参指针，完整的URL]
 * @param[out] urlParts             [输出指针，包含保存host地址、path目录文件、port]
 * @return     int                  [成功/失败]
 */
static int vhal_esp_http_parse_url(const char *pUrl, vhal_esp_url_t *urlParts)
{
    char *pPartA = NULL;
    char *pPartB = NULL;

    if (NULL == pUrl)
    {
        HAL_LOG(LOG_ERROR, "The parameter contains a null pointer!\n");
        return VHAL_FAIL;
    }

    urlParts->port = 80;    //设置默认端口为80，当传递的URL为不带端口号时使用默认端口
    pPartA = (char *)pUrl;

    if(!strncmp(pPartA, "http://", strlen("http://")))              // 检查头部
    {
        pPartA += strlen("http://");
    }
    else
    {
        return VHAL_FAIL;
    }

    pPartB = (char *)strstr(pPartA, ":");
    if (!pPartB)
    {
        pPartB = (char *)strstr(pPartA, "/");
    }

    if(pPartB)                                                      // 如果有URI
    {
        strncpy(urlParts->host, pPartA, pPartB - pPartA);     // 将Host提取出来
        urlParts->host[pPartB - pPartA] = 0;                 // Host结束
    }
    else
    {
        strncpy(urlParts->host, pPartA, sizeof(urlParts->host) - 1);
    }

    if(pPartB && pPartB[0] == ':')
    {
        pPartA = pPartB + 1;
        pPartB = strstr(pPartA, "/");
        urlParts->port = atoi(pPartA);
    }

    if(pPartB)
    {
        strncpy(urlParts->path, pPartB, sizeof(urlParts->path) -1);    // 将FileName提取出来
    }
    else
    {
        strncpy(urlParts->path, "/", sizeof(urlParts->path) -1);    // 将FileName提取出来
    }

    HAL_LOG(LOG_INFO, "host:%s, port: %d, path:%s\n", urlParts->host, urlParts->port, urlParts->path);

    return 0;
}


/**
 * @brief  读取当前数据段直到指定字符的长度
 * @param[in]  buffer           [待拷贝的数据指针]
 * @param[in]  delim            [指定的字符]
 * @param[in]  len              [数据段长度]
 * @return     int              [当前数据段至指定字符的长度]
 */
static int vhal_esp_read_data_len_until_char(const char *buffer, char delim, int len)
{
    int i = 0;

    if(buffer == NULL || !len)
    {
        return 0;
    }

    while (buffer[i] != delim && i < len)
    {
        ++i;
    }

    return i + 1;
}

/**
 * @brief  处理http头数据
 * @param[out]  ota_firm            [升级状态数据]
 * @param[in]   text                [http获取到的数据]
 * @param[in]   total_len           [待处理数据长度]
 * @param[out]  parse_len           [http内容偏移]
 * @return      bool                [true完成、false未完成]
 */
static bool vhal_esp_ota_parse_http_head(vhal_esp8266_ota_t *ota_firm, const char *text, size_t total_len, size_t *parse_len)
{
    /* i means current position */
    int i = 0, i_read_len = 0;
    char *ptr = NULL, *ptr2 = NULL;
    char len_str[32] = {0};

    while (text[i] != 0 && i < total_len)
    {
        if (ota_firm->content_len == 0 && (ptr = (char *)strstr(text, "Content-Length")) != NULL)
        {
            ptr += 16;  // 字符串"Content-Length: "的长度
            ptr2 = (char *)strstr(ptr, "\r\n");
            memcpy(len_str, ptr, ptr2 - ptr);
            ota_firm->content_len = atoi(len_str);       //当前文件总长度
            if(ota_firm->content_len < s_ota_status.header_len)
            {
                return false;
            }
            ota_firm->ota_size = ota_firm->content_len - s_ota_status.header_len;  //升级长度 = 当前文件总长度 - vesync头部
            ota_firm->ota_offset = s_ota_status.header_len;        // 去掉第1包数据的长度
            HAL_LOG(LOG_DEBUG, "parse Content-Length:%d, ota_size %d\n", ota_firm->content_len, ota_firm->ota_size);
        }

        i_read_len = vhal_esp_read_data_len_until_char(&text[i], '\n', total_len - i);

        if (i_read_len > total_len - i)
        {
            HAL_LOG(LOG_ERROR, "recv malformed http header\n");
            return false;
        }

        //头部特征，当前段数据长度为2，“仅包含\r\n”, 表示头部数据处理完毕
        if (i_read_len == 2)
        {
            if (ota_firm->content_len == 0) //数据总长度为0，停止后续的处理
            {
                HAL_LOG(LOG_ERROR, "did not parse Content-Length item\n");
                return false;
            }

            *parse_len = i + 2;

            return true;
        }

        i += i_read_len;
    }

    return false;
}

/**
 * @brief  处理升级bin文件数据
 * @param[in]  ota_firm             [升级状态数据]
 * @param[in]  in_buf               [http获取到的数据]
 * @param[in]  in_len               [输入数据长度]
 * @return     size_t               [有效数据长度]
 */
static size_t vhal_esp_ota_fw_do_parse_msg(vhal_esp8266_ota_t *ota_firm, const char *in_buf, size_t in_len)
{
    size_t tmp = 0;
    size_t parsed_bytes = in_len;

    switch (ota_firm->state)
    {
        case ESP_OTA_INIT:  //http 头数据处理
            if (vhal_esp_ota_parse_http_head(ota_firm, in_buf, in_len, &tmp))
            {
                ota_firm->state = ESP_OTA_PREPARE;
                ota_firm->read_bytes = 0;   //头部数据丢弃不用
                HAL_LOG(LOG_DEBUG, "Http parse %d bytes\n", tmp);
                parsed_bytes = tmp;
            }
            break;

        case ESP_OTA_PREPARE:   //处理第一包数据
            HAL_LOG(LOG_DEBUG, "in_len: %d, offset: %d\n", in_len, ota_firm->ota_offset);
            ota_firm->read_bytes += in_len;
            if (ota_firm->read_bytes >= ota_firm->ota_offset)
            {
                //校验bin文件的头部数据
                if (NULL != s_ota_status.header_check_cb)
                {
                    if (VHAL_OK == s_ota_status.header_check_cb((uint8_t *)&in_buf[ota_firm->read_bytes - in_len], s_ota_status.header_len))
                    {
                        ota_firm->buf = &in_buf[in_len - (ota_firm->read_bytes - ota_firm->ota_offset)];      //存储：跳过头部校验数据
                        ota_firm->bytes = ota_firm->read_bytes - ota_firm->ota_offset;
                        ota_firm->write_bytes += ota_firm->read_bytes - ota_firm->ota_offset;
                        ota_firm->state = ESP_OTA_START;
                        HAL_LOG(LOG_DEBUG, "Receive %d bytes and start to update\n", ota_firm->read_bytes);
                        HAL_LOG(LOG_DEBUG, "Write %d total %d\n", ota_firm->bytes, ota_firm->write_bytes);
                    }
                    else
                    {
                        ota_firm->state = ESP_OTA_FAILED;
                        HAL_LOG(LOG_ERROR, "Head check failed\n");
                    }
                }
                else
                {
                    ota_firm->state = ESP_OTA_FAILED;
                    HAL_LOG(LOG_ERROR, "Not support head check!!\n");
                }
            }
            break;

        case ESP_OTA_START: //获取bin文件升级数据
            if (ota_firm->write_bytes + in_len >= ota_firm->ota_size)
            {
                ota_firm->bytes = ota_firm->ota_size - ota_firm->write_bytes;
                ota_firm->state = ESP_OTA_RECVED;   //数据处理完毕
            }
            else
            {
                ota_firm->bytes = in_len;
            }

            ota_firm->buf = in_buf;
            ota_firm->write_bytes += ota_firm->bytes;
            //HAL_LOG(LOG_DEBUG, "Write %d total %d\n", ota_firm->bytes, ota_firm->write_bytes);
            break;

        case ESP_OTA_RECVED:    //完成
            parsed_bytes = 0;
            ota_firm->state = ESP_OTA_FINISH;
            break;
        default:
            parsed_bytes = 0;
            HAL_LOG(LOG_DEBUG, "State is %d\n", ota_firm->state);
            break;
    }

    return parsed_bytes;
}

/**
 * @brief  处理http传入的数据
 * @param[in]  ota_firm             [升级状态数据]
 * @param[in]  in_buf               [http获取到的数据]
 * @param[in]  in_len               [输入数据长度]
 * @return     void
 * @note   此处存在分段多次处理
 */
static void vhal_esp_ota_fw_parse_msg(vhal_esp8266_ota_t *ota_firm, const char *in_buf, size_t in_len)
{
    size_t parse_bytes = 0;     // 已处理字节数
    size_t bytes = 0;

    do {
        bytes = vhal_esp_ota_fw_do_parse_msg(ota_firm, in_buf + parse_bytes, in_len - parse_bytes);
        if (bytes)
        {
            parse_bytes += bytes;
        }
    } while (parse_bytes != in_len);    //长度不相等，表示未处理完毕
}

/**
 * @brief  升级状态初始化
 * @param[in]  ota_firm             [升级状态数据]
 * @param[in]  ota_firm             [分区数据]
 * @return     void
 */
static void vhal_esp_ota_fw_init(vhal_esp8266_ota_t *ota_firm, const esp_partition_t *update_partition)
{
    memset(ota_firm, 0, sizeof(vhal_esp8266_ota_t));
    ota_firm->state = ESP_OTA_INIT;
    ota_firm->ota_num = get_ota_partition_count();
    ota_firm->update_ota_num = update_partition->subtype - ESP_PARTITION_SUBTYPE_APP_OTA_0;

    HAL_LOG(LOG_INFO, "Totoal OTA number %d update to %d part\n", ota_firm->ota_num, ota_firm->update_ota_num);

}

/**
 * @brief  建立连接http服务器
 * @param[in]  p_url            [APP输入的原始地址数据]
 * @param[in]  urlParts         [解析后的数据]
 * @return     bool             [true连接成功、false连接失败]
 */
static bool vhal_esp_connect_to_http_server(char* p_url, vhal_esp_url_t*urlParts)
{
    int ret = VHAL_FAIL;
    bool ret_val = false;
    struct addrinfo *res = NULL;
    struct in_addr *addr = NULL;
    const struct addrinfo hints = {
        .ai_family = AF_INET,           // IPV4
        .ai_socktype = SOCK_STREAM,     // TCP协议
    };

    if(p_url == NULL)
    {
        return ret_val;
    }

    // 解析URL
    ret = vhal_esp_http_parse_url(p_url, urlParts);
    if (VHAL_OK != ret)
    {
        HAL_LOG(LOG_ERROR, "http url parse error!\n");
        return ret_val;
    }

    //获取IP
    ret = getaddrinfo(urlParts->host, NULL, &hints, &res);
    if(ret != 0 || res == NULL)
    {
        HAL_LOG(LOG_ERROR, "DNS lookup failed err=%d res=%p\n", ret, res);
        goto exit;
    }
    //计算地址
    addr = &((struct sockaddr_in *)res->ai_addr)->sin_addr;
    int address = inet_addr(inet_ntoa(*addr));
    HAL_LOG(LOG_DEBUG, "address : %d. IP=%s\n", address,inet_ntoa(*addr));
    //建立连接
    s_ota_status.socket_id = socket(res->ai_family, res->ai_socktype, 0);
    if (s_ota_status.socket_id == -1)
    {
        HAL_LOG(LOG_ERROR, "Create socket failed!\n");
        goto exit;
    }
    struct sockaddr_in sock_info;
    // set connect info
    memset(&sock_info, 0, sizeof(struct sockaddr_in));
    sock_info.sin_family = AF_INET;
    sock_info.sin_addr.s_addr = address;
    sock_info.sin_port = htons(urlParts->port);

    //连接服务器
    ret = connect(s_ota_status.socket_id, (struct sockaddr *)&sock_info, sizeof(sock_info));
    // connect to http server
    //ret = connect(socket_id, res->ai_addr, res->ai_addrlen);
    if (ret == -1)
    {
        HAL_LOG(LOG_ERROR, "Connect to server failed! errno=%d\n", errno);
        close(s_ota_status.socket_id);
        goto exit;
    }

    // 接收，设置等待超时, Add by Dongri.Su，2020/08/07
    struct timeval recv_timeout;
    recv_timeout.tv_sec = 5;
    recv_timeout.tv_usec = 0;
    if (setsockopt(s_ota_status.socket_id, SOL_SOCKET, SO_RCVTIMEO, &recv_timeout, sizeof(recv_timeout)) < 0)
    {
        HAL_LOG(LOG_ERROR, "Failed to set socket receiving timeout\n");
        close(s_ota_status.socket_id);
        goto exit;
    }

    ret_val = true;
    HAL_LOG(LOG_INFO,"Connected to server\n");

exit:
    if (NULL != res)
        freeaddrinfo(res);

    return ret_val;
}



/*-----------------------------------------------------------------------------*
 *                           外部函数API实现                                     *
 *-----------------------------------------------------------------------------*/

/**
 * @brief  开始OTA升级
 * @param[in]  p_url            [固件下载URL]
 * @param[in]  dg_flag          [true表示进行降级；false表示进行升级]
 * @return     int              [成功返回0，其他值表示失败]
 */
int vhal_ota_start(char *p_url, bool dg_flag)
{
    int binary_file_length = 0;
    int ret = VHAL_FAIL;
    int send_ret = -1;
    int percent = 0;
    uint8_t rd_retry = 0;
    bool flag = true;
    esp_err_t err = ESP_FAIL;
    vhal_esp8266_ota_t ota_firm;
    esp_ota_handle_t update_handle = 0;
    const esp_partition_t *update_partition = NULL;
    char *text = NULL;
    const char *p_data_buf = NULL;
    vhal_esp_url_t urlParts;

    // ota状态判断，若为忙的状态，则直接返回
    if (VHAL_OTA_ST_IDLE != s_ota_status.status)
    {
        HAL_LOG(LOG_WARN, "OTA is busy now, skip!!\n");
        vhal_ota_update_status(VHAL_OTA_ST_PROCESS, percent);
        return VHAL_OK;
    }

    // 参数判断
    if (NULL == p_url)
    {
        HAL_LOG(LOG_ERROR, "p_url is an null pointer, return!!\n");
        vhal_ota_update_status(VHAL_OTA_ST_FAIL, percent);
        return VHAL_FAIL;
    }

    HAL_LOG(LOG_INFO, "OTA is starting...\n");

    // URL解析和连接服务器
    memset(&urlParts, 0, sizeof(vhal_esp_url_t));
    if (vhal_esp_connect_to_http_server(p_url, &urlParts))
    {
        HAL_LOG(LOG_INFO, "Connected to http server\n");
    }
    else
    {
        HAL_LOG(LOG_ERROR, "Connect to http server failed!\n");
        goto exit;
    }

    // http请求
    const char *GET_FORMAT =
        "GET %s HTTP/1.1\r\n"
        "Host: %s\r\n"
        "User-Agent: esp-idf/1.1 esp32\r\n\r\n";
    int ota_http_req_len = strlen(GET_FORMAT) + strlen(urlParts.path) + strlen(urlParts.host) + 16;   // 多预留一段空间
    char *p_http_req = (char *)malloc(ota_http_req_len);
    if (NULL == p_http_req)
    {
        HAL_LOG(LOG_ERROR, "malloc memory fail!!\n");
        vhal_ota_update_status(VHAL_OTA_ST_OUT_MEM, percent);   // 内存不足
        goto exit;
    }
    memset(p_http_req, 0, ota_http_req_len);
    snprintf(p_http_req, ota_http_req_len, GET_FORMAT, urlParts.path, urlParts.host);
    HAL_LOG(LOG_DEBUG, "http_req: %s\n", p_http_req);

    // 发送GET数据
    send_ret = send(s_ota_status.socket_id, p_http_req, strlen(p_http_req), 0);
    free(p_http_req);
    if (send_ret < 0)
    {
        HAL_LOG(LOG_ERROR, "Send GET request to server failed\n");
        goto exit;
    }
    else
    {
        HAL_LOG(LOG_INFO, "Send GET request to server succeeded\n");
    }

    //申请http返回的数据空间
    text = (char *)malloc(MAX_TCP_BUFF_SIZE + 1);
    if (NULL == text)
    {
        HAL_LOG(LOG_ERROR, "malloc text memory fail!!\n");
        vhal_ota_update_status(VHAL_OTA_ST_OUT_MEM, percent);   // 内存不足
        goto exit;
    }

    memset(text, 0, MAX_TCP_BUFF_SIZE + 1);
    //申请MD5校验的数据空间
    if (VHAL_OK != vhal_ota_md5_check_init())
    {
        HAL_LOG(LOG_ERROR, "ota_check_init failed!\n");
        goto exit;
    }

    //获取当前分区数据
    const esp_partition_t *configured = esp_ota_get_boot_partition();
    const esp_partition_t *running = esp_ota_get_running_partition();
    if (configured != running)
    {
        HAL_LOG(LOG_ERROR, "Configured OTA boot partition at offset 0x%08x, but running from offset 0x%08x\n",
                 configured->address, running->address);
        HAL_LOG(LOG_ERROR,  "(This can happen if either the OTA boot data or preferred boot image become corrupted somehow.)\n");
    }
    HAL_LOG(LOG_INFO, "Running partition type %d subtype %d (offset 0x%08x)\n",
             running->type, running->subtype, running->address);

    //获取升级分区
    update_partition = esp_ota_get_next_update_partition(NULL);
    if (NULL == update_partition)
    {
        HAL_LOG(LOG_ERROR, "Get next update partition failed!\n");
        goto exit;
    }

    HAL_LOG(LOG_INFO, "Writing to partition subtype %d at offset 0x%x\n",
             update_partition->subtype, update_partition->address);

    //开始OTA
    err = esp_ota_begin(update_partition, OTA_SIZE_UNKNOWN, &update_handle);
    if (err != ESP_OK)
     {
        HAL_LOG(LOG_ERROR, "esp_ota_begin failed, error=%d\n", err);
        goto exit;
    }

    HAL_LOG(LOG_INFO, "esp_ota_begin start succeeful\n");
    vhal_esp_ota_fw_init(&ota_firm, update_partition);

    //轮询下载升级文件
    while (flag)
    {
        memset(text, 0, MAX_TCP_BUFF_SIZE + 1);
        //memset(ota_write_data, 0, OTA_BUFFSIZE + 1);

        // 由平台层计时，超时后设置该标志位
        if (s_ota_status.timeout_flag)
        {
            vhal_ota_update_status(VHAL_OTA_ST_TIME_OUT, percent);
            HAL_LOG(LOG_ERROR, "OTA timeout!!\n");
            goto exit;
        }

        //分包获取
        int buff_len = recv(s_ota_status.socket_id, text, MAX_TCP_BUFF_SIZE, 0);
        if (buff_len < 0)
        {
            /*receive error*/
            HAL_LOG(LOG_ERROR, "Error: receive data error! errno=%d\n", errno);
            if(rd_retry >= 2)    // 连续3次下载失败
            {
                vhal_ota_update_status(VHAL_OTA_ST_DL_FAIL, percent);   // 固件下载失败
                goto exit;
            }
            rd_retry++;
            vTaskDelay(200 / portTICK_PERIOD_MS);
        }
        else if (buff_len > 0)
        {
            rd_retry = 0;       // 读取成功，重新开始计数
            /*deal with response body*/
            vhal_esp_ota_fw_parse_msg(&ota_firm, text, buff_len);

            if(ota_firm.state == ESP_OTA_FAILED)
            {
                goto exit;
            }

            if (ota_firm.state != ESP_OTA_START && ota_firm.state != ESP_OTA_RECVED)
            {
                continue;
            }

            //数据拷贝
            buff_len = ota_firm.bytes;
            //memcpy(ota_write_data, ota_firm.buf, buff_len);
            p_data_buf = ota_firm.buf;
            //数据存储
            //err = esp_ota_write(update_handle, (const void *)ota_write_data, buff_len);
            err = esp_ota_write(update_handle, (const void *)p_data_buf, buff_len);
            if (err != ESP_OK)
            {
                HAL_LOG(LOG_ERROR, "Error: esp_ota_write failed! err=0x%x\n", err);
                goto exit;
            }
            // 计算下载进度，百分比
            binary_file_length += buff_len;
            if (ota_firm.ota_size != 0)
                percent = (binary_file_length*100)/ota_firm.ota_size;

            vhal_ota_update_status(VHAL_OTA_ST_PROCESS, percent);   // 固件下载中

            //更新MD5
            //ota_update_md5((uint8_t *)ota_write_data, buff_len);
            vhal_ota_md5_update((uint8_t *)p_data_buf, buff_len);
            //HAL_LOG(LOG_DEBUG, "written length %d\n", buff_len);
        }
        else if (buff_len == 0)
        {  /*packet over*/
            flag = false;
            HAL_LOG(LOG_INFO, "Connection closed, all packets received\n");

            if(percent < 100)           // 未下载完成中断，则下载失败
            {
                vhal_ota_update_status(VHAL_OTA_ST_DL_FAIL, percent);   // 固件下载失败
                goto exit;
            }
        }
        else
        {
            HAL_LOG(LOG_ERROR, "Unexpected recv result\n");

        }
        //完成了吧
        if (ota_firm.state == ESP_OTA_FINISH || ota_firm.state == ESP_OTA_RECVED)
        {
            if (percent >= 100)
            {
                if(VHAL_OK != vhal_ota_md5_check_done(100)) //检查MD5
                {
                    goto exit;
                }

                vhal_ota_update_status(VHAL_OTA_ST_DL_COMP, 100);   // 固件下载完成
            }
            break;
        }

        vTaskDelay(20/portTICK_RATE_MS);// 延时
    }

    HAL_LOG(LOG_INFO, "Total Write binary data length : %d\n", binary_file_length);
    //完成
    if (esp_ota_end(update_handle) != ESP_OK)
    {
        HAL_LOG(LOG_ERROR, "esp_ota_end failed!\n");
        ret = VHAL_FAIL;
        goto exit;
    }

    //写入新分区
    err = esp_ota_set_boot_partition(update_partition);
    if (err != ESP_OK)
    {
        HAL_LOG(LOG_ERROR, "esp_ota_set_boot_partition failed! err=0x%x\n", err);
        ret = VHAL_FAIL;
        goto exit;
    }

    //成功后直接复位，不需回调
    vhal_ota_update_status(VHAL_OTA_ST_SUCCESS, percent);   // 升级完成
    ret = VHAL_OK;

exit:

    // 无论最终升级状态是成功还是失败，都需要修改为可升级状态
    s_ota_status.status = VHAL_OTA_ST_IDLE;
    s_ota_status.timeout_flag = false;

    //释放MD5
    vhal_ota_md5_release();

    //关闭http连接
    if(s_ota_status.socket_id >= 0)
    {
        close(s_ota_status.socket_id);
    }

    if (NULL != text)
    {
        free(text);
        text = NULL;
    }

    HAL_LOG(LOG_INFO, "ota exit\n");
    return ret;
}

#else

/**
 * @brief  开始OTA升级
 * @param[in]  p_url            [固件下载URL]
 * @param[in]  dg_flag          [true表示进行降级；false表示进行升级]
 * @return     int              [成功返回0，其他值表示失败]
 */
int vhal_ota_start(char *p_url, bool dg_flag)
{
    int ret = VHAL_FAIL;
    int binary_file_length = 0;
    uint32_t total_size = 0, percent = 0;
    uint8_t rd_retry = 0;
    esp_err_t err;
    // update handle: set by esp_ota_begin(), must be freed via esp_ota_end()
    esp_ota_handle_t update_handle = 0;
    // esp_ota_begin()启动后，中途失败，需要esp_ota_end()释放空间
    bool need_free_handle = false;

    // ota状态判断，若为忙的状态，则直接返回
    if (VHAL_OTA_ST_IDLE != s_ota_status.status)
    {
        HAL_LOG(LOG_ERROR, "OTA is busy now, skip\n");
        vhal_ota_update_status(VHAL_OTA_ST_PROCESS, percent);
        return VHAL_OK;
    }

    if (NULL == p_url)
    {
        HAL_LOG(LOG_ERROR, "p_url is null\n");
        vhal_ota_update_status(VHAL_OTA_ST_FAIL, percent);
        return VHAL_FAIL;
    }

    // 分配空间
    char *ota_write_data = (char *)malloc(BUFFSIZE + 1);
    char *ptr = ota_write_data;
    if (NULL == ota_write_data)
    {
        HAL_LOG(LOG_ERROR, "malloc memory fail\n");
        // 内存不足
        vhal_ota_update_status(VHAL_OTA_ST_OUT_MEM, percent);
        goto exit;
    }
    memset(ota_write_data, 0, BUFFSIZE + 1);

    // 获取分区信息，找到待写入的分区号
    const esp_partition_t *configured = esp_ota_get_boot_partition();
    const esp_partition_t *running = esp_ota_get_running_partition();
    if (NULL == configured || NULL == running)
    {
        HAL_LOG(LOG_ERROR, "Failed to get ota partiton.\n");
        vhal_ota_update_status(VHAL_OTA_ST_FLASH_ERR, percent);
        goto exit;
    }
    if (configured != running)
    {
        // This can happen if either the OTA boot data or preferred boot image become corrupted somehow
        HAL_LOG(LOG_ERROR, "configured partition at offset 0x%08x, but running from offset 0x%08x\n", configured->address, running->address);
    }
    HAL_LOG(LOG_INFO, "configured partition type %d subtype 0x%x (offset 0x%08x)\n", configured->type, configured->subtype, configured->address);

    const esp_partition_t *update_partition = esp_ota_get_next_update_partition(NULL);
    if (NULL == update_partition)
    {
        HAL_LOG(LOG_ERROR, "failed to found next update partiton.\n");
        vhal_ota_update_status(VHAL_OTA_ST_FLASH_ERR, percent);
        goto exit;
    }
    HAL_LOG(LOG_INFO, "update partition subtype 0x%x at offset 0x%x\n", update_partition->subtype, update_partition->address);

    http_client_config_t client_config = {0};
    client_config.url = p_url;
    HAL_LOG(LOG_INFO, "remote url is %s\n", client_config.url);
    // 初始化http连接
    http_client_handle_t client = http_client_init(&client_config);
    if (NULL == client)
    {
        HAL_LOG(LOG_ERROR, "failed to initialise http connection\n");
        vhal_ota_update_status(VHAL_OTA_ST_HTTP_CONN_FAIL, percent);
        goto exit;
    }
    if (http_client_open(client) != VHAL_OK)
    {
        vhal_ota_update_status(VHAL_OTA_ST_HTTP_CONN_FAIL, percent);
        http_cleanup(client);
        goto exit;
    }
    http_client_fetch_headers(client);

    total_size = http_client_get_content_length(client);
    HAL_LOG(LOG_INFO, "total_len %d \n", total_size);

    if (VHAL_OK != vhal_ota_md5_check_init())
    {
        HAL_LOG(LOG_ERROR, "ota_check_init failed!\n");
        goto exit;
    }
    // 开始升级
    vhal_ota_update_status(VHAL_OTA_ST_PROCESS, percent);
    // 标识头部是否已经校验
    bool image_header_was_checked = false;

    while (1)
    {
        // 超时判断
        if (s_ota_status.timeout_flag)
        {
            vhal_ota_update_status(VHAL_OTA_ST_TIME_OUT, percent);
            HAL_LOG(LOG_ERROR, "OTA timeout!!\n");
            http_cleanup(client);
            goto exit;
        }
        // 删除头部时，指针进行了偏移，需要指针指定到初始位置，否则free会报错
        ota_write_data = ptr;
        memset(ota_write_data, 0, BUFFSIZE + 1);
        int data_read = http_client_read(client, ota_write_data, BUFFSIZE);
#if 0
        LOG_RAW_HEX(LOG_DEBUG, "ota bin download buffer: ", ota_write_data, BUFFSIZE);
#endif
        // 下载异常
        if (data_read < 0)
        {
            // 连续3次下载失败
            if (rd_retry >= 2)
            {
                // 固件下载失败
                vhal_ota_update_status(VHAL_OTA_ST_DL_FAIL, percent);
                http_cleanup(client);
                goto exit;
            }
            rd_retry++;
            vTaskDelay(200 / portTICK_PERIOD_MS);
            HAL_LOG(LOG_ERROR, "error http_client_read(%d), retry=%d\n", data_read, rd_retry);
        }
        else if (data_read > 0)
        {
            // 读取成功，重新开始计数
            rd_retry = 0;
            // 头部校验
            if (image_header_was_checked == false)
            {
#if 1
                if (data_read > s_ota_status.header_len)
                {
                    if (NULL != s_ota_status.header_check_cb)
                    {
                        if (VHAL_OK != s_ota_status.header_check_cb((uint8_t *)ota_write_data, s_ota_status.header_len))
                        {
                            HAL_LOG(LOG_ERROR, "check vesync header failed\n");
                            http_cleanup(client);
                            goto exit;
                        }
                    }
                    else
                    {
                        HAL_LOG(LOG_ERROR, "header verify method not found\n");
                        http_cleanup(client);
                        goto exit;
                    }
                    // 删除头部
                    data_read -= s_ota_status.header_len;
                    total_size -= s_ota_status.header_len;
                    // 指针偏移了
                    ota_write_data += s_ota_status.header_len;
                    HAL_LOG(LOG_DEBUG, "data_read=%d, total_size=%d\n", data_read, total_size);
#if 0
                    LOG_RAW_HEX(LOG_DEBUG, NULL, ota_write_data, 20);
#endif
#else
                esp_app_desc_t new_app_info;
                if (data_read > sizeof(esp_image_header_t) + sizeof(esp_image_segment_header_t) + sizeof(esp_app_desc_t))
                {
                    // check current version with downloading
                    memcpy(&new_app_info, &ota_write_data[sizeof(esp_image_header_t) + sizeof(esp_image_segment_header_t)], sizeof(esp_app_desc_t));
                    HAL_LOG(LOG_INFO, "New firmware version: %s.\n", new_app_info.version);

                    esp_app_desc_t running_app_info;
                    if (esp_ota_get_partition_description(running, &running_app_info) == ESP_OK)
                    {
                        HAL_LOG(LOG_INFO, "Running firmware version: %s\n", running_app_info.version);
                    }

                    const esp_partition_t *last_invalid_app = esp_ota_get_last_invalid_partition();
                    esp_app_desc_t invalid_app_info;
                    if (esp_ota_get_partition_description(last_invalid_app, &invalid_app_info) == ESP_OK)
                    {
                        HAL_LOG(LOG_INFO, "Last invalid firmware version: %s\n", invalid_app_info.version);
                    }
#endif
                    image_header_was_checked = true;

                    err = esp_ota_begin(update_partition, OTA_SIZE_UNKNOWN, &update_handle);
                    if (err != ESP_OK)
                    {
                        // 固件下载失败
                        vhal_ota_update_status(VHAL_OTA_ST_DL_FAIL, percent);
                        HAL_LOG(LOG_ERROR, "esp_ota_begin failed(%s)\n", esp_err_to_name(err));
                        http_cleanup(client);
                        goto exit;
                    }
                    need_free_handle = true;
                    HAL_LOG(LOG_INFO, "OTA begin succeeded\n");
                }
                else
                {
                    HAL_LOG(LOG_INFO, "received package is not fit len\n");
                    // 固件下载失败
                    vhal_ota_update_status(VHAL_OTA_ST_DL_FAIL, percent);
                    http_cleanup(client);
                    goto exit;
                }
            }
#if 0
            HAL_LOG(LOG_DEBUG, "data_read=%d\n", data_read);
#endif
            err = esp_ota_write(update_handle, (const void *)ota_write_data, data_read);
            if (err != ESP_OK)
            {
                // 写flash失败
                vhal_ota_update_status(VHAL_OTA_ST_FLASH_ERR, percent);
                http_cleanup(client);
                goto exit;
            }

            // 计算下载进度，百分比
            binary_file_length += data_read;
            if (total_size != 0)
            {
                percent = (binary_file_length * 100) / total_size;
            }

            // 固件下载中
            vhal_ota_update_status(VHAL_OTA_ST_PROCESS, percent);
#if 0
            HAL_LOG(LOG_DEBUG, "Written image length %d(%d%%).\n", binary_file_length, percent);
#endif
            vhal_ota_md5_update((uint8_t *)ota_write_data, data_read);
            if (percent >= 100)
            {
                if (VHAL_OK != vhal_ota_md5_check_done(percent))
                {
                    goto exit;
                }
            }
        }
        else if (data_read == 0)
        {
            // 未下载完成中断，则下载失败
            if (percent < 100)
            {
                // 固件下载失败
                vhal_ota_update_status(VHAL_OTA_ST_DL_FAIL, percent);
                http_cleanup(client);
                goto exit;
            }

            // 固件下载完成
            vhal_ota_update_status(VHAL_OTA_ST_DL_COMP, percent);
            HAL_LOG(LOG_INFO, "connection closed, all data received\n");
            ret = VHAL_OK;
            break;
        }
        // 延时
        vTaskDelay(20 / portTICK_RATE_MS);
    }
    HAL_LOG(LOG_INFO, "binary_file_length: %d\n", binary_file_length);

    if (esp_ota_end(update_handle) != ESP_OK)
    {
        // 其他原因
        vhal_ota_update_status(VHAL_OTA_ST_FAIL, percent);
        HAL_LOG(LOG_ERROR, "esp_ota_end failed!\n");
        http_cleanup(client);
        ret = VHAL_FAIL;
        goto exit;
    }
    need_free_handle = false;

    err = esp_ota_set_boot_partition(update_partition);
    if (err != ESP_OK)
    {
        // 其他原因
        vhal_ota_update_status(VHAL_OTA_ST_FAIL, percent);
        HAL_LOG(LOG_ERROR, "esp_ota_set_boot_partition failed (%s)!\n", esp_err_to_name(err));
        http_cleanup(client);
        ret = VHAL_FAIL;
        goto exit;
    }
    // 升级完成
    vhal_ota_update_status(VHAL_OTA_ST_SUCCESS, percent);

exit:
    // 无论最终升级状态是成功还是失败，都需要修改为可升级状态
    s_ota_status.status = VHAL_OTA_ST_IDLE;
    s_ota_status.timeout_flag = false;

    // 释放MD5
    vhal_ota_md5_release();

    // 升级失败，需要释放资源
    if (need_free_handle)
    {
        esp_ota_end(update_handle);
    }
    if (NULL != ota_write_data)
    {
        free(ota_write_data);
        ota_write_data = NULL;
    }
    if (VHAL_OK == ret)
    {
        HAL_LOG(LOG_INFO, "ESP32 OTA successed, exit\n");
    }

    else
    {
        HAL_LOG(LOG_ERROR, "ESP32 OTA fail, exit\n");
    }

    return ret;
}

#endif /* CONFIG_IDF_TARGET_ESP8266 */

/**
 * @brief  注册ota升级状态数据回调
 * @param[in]  cb               [ota升级状态回调函数]
 * @return     void
 */
void vhal_ota_status_reg_cb(vhal_ota_status_cb_t cb)
{
    s_ota_status.status_cb = cb;
}

/**
 * @brief 注册ota升级头部校验回调
 * @param[in]  cb               [ota头部校验回调函数]
 * @return     void
 */
void vhal_ota_check_header_reg_cb(vhal_ota_check_header_cb_t cb, int32_t head_len)
{
    s_ota_status.header_check_cb = cb;
    s_ota_status.header_len = head_len;
}

/**
 * @brief 注册ota升级md5校验回调
 * @param[in]  cb               [ota头部校验回调函数]
 * @return     void
 */
void vhal_ota_check_md5_reg_cb(vhal_ota_check_md5_cb_t cb)
{
    s_ota_status.md5_check_cb = cb;
}

/*
 * @brief  设置OTA超时标志位
 * @param[in]  flag             [true表示升级超时，false表示未超时]
 * @return     void
 */
void vhal_ota_set_timeout_flag(bool flag)
{
    s_ota_status.timeout_flag = flag;
}

/**
 * @brief  保存文件到flash
 * @param[in]  offset           [偏移地址]
 * @param[in]  p_data           [待保存的数据]
 * @param[in]  data_len         [待保存数据的长度]
 * @return     int              [成功返回0，其他值表示失败]
 * @note   用于存放非自身固件的其他大文件
 */
int vhal_ota_save_bin_file(int offset, char *p_data, int data_len)
{
    if (NULL == p_data)
        return VHAL_FAIL;

    // Find the partition map in the partition table
    const esp_partition_t *partition = esp_partition_find_first(ESP_PARTITION_TYPE_DATA, ESP_PARTITION_SUBTYPE_ANY, "storage");
    if (partition == NULL)
    {
        HAL_LOG(LOG_ERROR, "Can not find storage partition!\n");
        return VHAL_FAIL;
    }

    if (0 == offset)
    {
        HAL_LOG(LOG_INFO, "Erase entire partition!\n");
        ESP_ERROR_CHECK(esp_partition_erase_range(partition, 0, partition->size));
    }

    ESP_ERROR_CHECK(esp_partition_write(partition, offset, p_data, data_len));
    //HAL_LOG(LOG_DEBUG, "Written data len: %d\n", data_len);

    return VHAL_OK;
}

/**
 * @brief 从flash中读出文件
 * @param[in]  offset           [偏移地址]
 * @param[in]  p_data           [待保存的数据]
 * @param[in]  data_len         [待保存数据的长度]
 * @return     int              [成功返回0，其他值表示失败]
 * @note   用于存放非自身固件的其他大文件
 */
int vhal_ota_read_bin_file(int offset ,char *p_data, int data_len)
{
    if (NULL == p_data)
        return VHAL_FAIL;

    // Find the partition map in the partition table
    const esp_partition_t *partition = esp_partition_find_first(ESP_PARTITION_TYPE_DATA, ESP_PARTITION_SUBTYPE_ANY, "storage");
    if (partition == NULL)
    {
        HAL_LOG(LOG_ERROR, "Can not find storage partition!\n");
        return VHAL_FAIL;
    }

    ESP_ERROR_CHECK(esp_partition_read(partition, offset, p_data, data_len));


    return VHAL_OK;
}

