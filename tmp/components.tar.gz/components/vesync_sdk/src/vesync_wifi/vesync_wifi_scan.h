/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_wifi_scan.h
 * @brief       配网模块的AP扫描
 * @date        2021-05-21
 */

#ifndef __VESYNC_WIFI_SCAN_H__
#define __VESYNC_WIFI_SCAN_H__

#include "vhal_wifi.h"
#include "vesync_common.h"

#ifdef __cplusplus
extern "C" {
#endif


// WIFI扫描列表存储AP最大个数
#define VESYNC_APLIST_MAX_NUM           (64)



/**
 * @brief AP信息，只提取这4项配网时APP交互需要的信息。
 */
typedef struct {
    uint8_t ssid[WIFI_SSID_MAX_LEN];        // AP的SSID
    uint8_t bssid[WIFI_BSSID_MAX_LEN];      // AP BSSID,无分隔符的6位MAC
    int8_t rssi;                            // 接收到AP的信号强度
    VHAL_WIFI_AUTH_MODE_E authmode;         // 加密方式
} vesync_bss_info_t;


/**
 * @brief 保存WIFI扫描结果结构体
 */
typedef struct
{
    vesync_bss_info_t *aplist; // AP信息
    uint16_t ap_max_num;       // vhal层上报扫描到的AP总数，aplist按此分配内存空间。由于会忽略重复的SSID，
                               // 实际缓存的AP数量可能小于这个值。该值也受 VESYNC_APLIST_MAX_NUM 控制
    uint16_t ap_cnt;           // 记录当前填充到第几个
    bool scanning;             // 是否正在扫描中
} vesync_aplist_t;


/**
 * @brief  VHAL层扫描结果回调函数，添加AP信息到扫描列表
 * @param[in]  bssid            [BSSID，即AP的MAC地址]，是由6个十六进制数组成]
 * @param[in]  ssid             [AP的SSID，即名称，是一个字符串，通常由UTF-8编码]
 * @param[in]  rssi             [信号强度]
 * @param[in]  auth_mode        [加密方式]
 * @param[in]  total_count      [扫描到的AP总个数]
 * @return     int              [添加成功或者失败]
 */
int vesync_wifi_scan_vhal_cb(const uint8_t* bssid, const uint8_t* ssid, const int8_t rssi,
                             const int auth_mode, const uint16_t total_count);


/**
 * @brief  开启扫描
 * @param[in]  void             [无]
 * @return     void             [无]
 * @note
 */
void vesync_wifi_scan_start(void);


/**
 * @brief  扫描完成
 * @param[in]  void             [无]
 * @return     void             [无]
 * @note
 */
void vesync_wifi_scan_done(void);


/**
 * @brief  释放扫描列表
 * @param[in]  void             [无]
 * @return     void             [无]
 * @note
 */
void vesync_wifi_aplist_clear(void);


/**
 * @brief  获取WIFI列表AP总个数
 * @param[in]  uint16_t         [AP总个数]
 * @return     void             [无]
 * @note
 */
uint16_t vesync_wifi_aplist_get_num(void);


/**
 * @brief  通过序号获取扫描列表中的AP信息
 * @param[in]  index                [AP的序号]
 * @return     vesync_bss_info_t*   [AP信息，不存在则返回空指针]
 * @note
 */
vesync_bss_info_t* vesync_wifi_get_apinfo_by_index(uint16_t index);


/**
 * @brief  通过SSID获取扫描列表中的AP信息
 * @param[in]  ssid                 [AP的SSID]
 * @return     vesync_bss_info_t*   [AP信息，不存在则返回空指针]
 * @note
 */
vesync_bss_info_t* vesync_wifi_get_apinfo_by_ssid(const uint8_t* ssid);


#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_WIFI_SCAN_H__ */

