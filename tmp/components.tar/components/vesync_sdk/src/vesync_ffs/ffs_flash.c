/**
 * Copyright © Etekcity Technologies Co., Ltd. 2021. All rights reserved.
 * @file        vesync_flash.c
 * @brief       处理ffs flash读写
 * @author      Joshua
 * @date        2021-05-28
 */

#include "vesync_flash.h"

/**
 * @brief 读取"DHA private key"
 * @param[out] char            [保存private key的缓存]
 * @param[in]  int             [缓存长度]
 * @return     int             [成功/失败]
 */
int vesync_ffs_flash_read_dha_private_key(char *p_key, int* buf_len)
{
    //note : p_key 为null，代表仅读取长度
    int ret = 0;
    VESYNC_POINTER_IS_EMPTY(buf_len, APP_FAIL)

#if CONFIG_VESYNC_HAL_NVS_FLASH_ENABLE
    ret = vhal_nvs_flash_read(USER_CFG_NAMESPACE, USER_CFG_KEY_FFS_PRIVATE_KEY, (uint8_t *)p_key, (uint32_t *)buf_len);
#elif CONFIG_VESYNC_HAL_SPI_FLASH_ENABLE
    //ret = vhal_flash_read(SEC_ADDR_FFS_RESULT, (uint8_t*)p_data, &len);
#endif
    VESYNC_ERR_RET_CHECK((VHAL_OK != ret), PLAT_FAIL)

    return PLAT_OK;
}

/**
 * @brief 写"DHA private key"
 * @param[in]  char            [待写入的private key]
 * @param[in]  int             [长度]
 * @return     int             [成功/失败]
 */
int vesync_ffs_flash_write_dha_private_key(char *p_key, int buf_len)
{
    int ret = 0;
    VESYNC_POINTER_IS_EMPTY(p_key, APP_FAIL)

#if CONFIG_VESYNC_HAL_NVS_FLASH_ENABLE
    ret = vhal_nvs_flash_write(USER_CFG_NAMESPACE, USER_CFG_KEY_FFS_PRIVATE_KEY, (uint8_t *)p_key, buf_len);
#elif CONFIG_VESYNC_HAL_SPI_FLASH_ENABLE
    //ret = vhal_flash_write(PARTITION_CFG, USER_CFG_KEY_FFS_PRIVATE_KEY, (uint8_t*)&p_key, buf_len);
#endif
    if (VHAL_OK != ret)
    {
        VERR_UPLOAD(VERR_FLASH_WRITE_FAIL, 0);
    }
    VESYNC_ERR_RET_CHECK((VHAL_OK != ret), PLAT_FAIL)

    return PLAT_OK;
}

/**
 * @brief 读取"certificate chain"
 * @param[out] char            [保存certificate chain的缓存]
 * @param[in]  int             [缓存长度]
 * @return     int             [成功/失败]
 */
int vesync_ffs_flash_read_cert_chain(char *p_key, int *buf_len)
{
    //note : p_key 为null，代表仅读取长度
    int ret = 0;
    VESYNC_POINTER_IS_EMPTY(buf_len, APP_FAIL)

#if CONFIG_VESYNC_HAL_NVS_FLASH_ENABLE
    ret = vhal_nvs_flash_read(USER_CFG_NAMESPACE, USER_CFG_KEY_FFS_CLIENT_CHAIN, (uint8_t *)p_key, (uint32_t *)buf_len);
#elif CONFIG_VESYNC_HAL_SPI_FLASH_ENABLE
    //ret = vhal_flash_read(SEC_ADDR_FFS_RESULT, (uint8_t*)p_data, &len);
#endif
    VESYNC_ERR_RET_CHECK((VHAL_OK != ret), PLAT_FAIL)

    return PLAT_OK;
}

/**
 * @brief 写"certificate chain"
 * @param[in]  char            [待写入的certificate chain]
 * @param[in]  int             [长度]
 * @return     int             [成功/失败]
 */
int vesync_ffs_flash_write_cert_chain(char *p_key, int buf_len)
{
    int ret = 0;
    if (NULL == p_key)
    {
        PLAT_LOG(LOG_ERROR, "Input parameters contain null pointers!\n");
        return VHAL_FAIL;
    }

#if CONFIG_VESYNC_HAL_NVS_FLASH_ENABLE
    ret = vhal_nvs_flash_write(USER_CFG_NAMESPACE, USER_CFG_KEY_FFS_CLIENT_CHAIN, (uint8_t *)p_key, buf_len);
#elif CONFIG_VESYNC_HAL_SPI_FLASH_ENABLE
    //ret = vhal_flash_write(PARTITION_CFG, USER_CFG_KEY_FFS_CLIENT_CHAIN, (uint8_t*)&p_key, buf_len);
#endif
    if (VHAL_OK != ret)
    {
        VERR_UPLOAD(VERR_FLASH_WRITE_FAIL, 0);
    }
    VESYNC_ERR_RET_CHECK((VHAL_OK != ret), PLAT_FAIL)

    return PLAT_OK;
}

/**
 * @brief 写读取ffs配网结果到flash中
 * @param[in]  ffs_result_flash_data_t [待写入的ffs配网结果]
 * @param[in]  int             [长度]
 * @return     int             [成功/失败]
 */
int vesync_ffs_flash_write_result_data(ffs_result_flash_data_t *p_data)
{
    int ret = 0;
    uint32_t len = sizeof(ffs_result_flash_data_t);
    if (NULL == p_data)
    {
        PLAT_LOG(LOG_ERROR, "Input parameters contain null pointers!\n");
        return VHAL_FAIL;
    }

#if CONFIG_VESYNC_HAL_NVS_FLASH_ENABLE
    ret = vhal_nvs_flash_write(USER_CFG_NAMESPACE, USER_CFG_KEY_FFS_FFS_RESULT, (uint8_t *)p_data, len);
#elif CONFIG_VESYNC_HAL_SPI_FLASH_ENABLE
    ret = vhal_flash_write(PARTITION_CFG, USER_CFG_KEY_FFS_FFS_RESULT, (uint8_t*)&p_data, len);
#endif
    if (VHAL_OK != ret)
    {
        VERR_UPLOAD(VERR_FLASH_WRITE_FAIL, 0);
    }
    VESYNC_ERR_RET_CHECK((VHAL_OK != ret), PLAT_FAIL)

    return PLAT_OK;
}

/**
 * @brief 从flash中读取ffs配网结果数据到内存
 * @param[out] ffs_result_flash_data_t  [配网结果]
 * @param[out] len                      [长度]
 * @return     int               [成功/失败]
 */
int vesync_ffs_flash_read_result_data(ffs_result_flash_data_t *p_data , uint32_t *len)
{
    int ret = 0;
    if (NULL == p_data || NULL == len )
    {
        PLAT_LOG(LOG_ERROR, "Input parameters contain null pointers!\n");
        return VHAL_FAIL;
    }

#if CONFIG_VESYNC_HAL_NVS_FLASH_ENABLE
    ret = vhal_nvs_flash_read(USER_CFG_NAMESPACE, USER_CFG_KEY_FFS_FFS_RESULT, (uint8_t *)p_data, len);
#elif CONFIG_VESYNC_HAL_SPI_FLASH_ENABLE
    ret = vhal_flash_read(PARTITION_CFG, USER_CFG_KEY_FFS_FFS_RESULT, (uint8_t*)p_data, len);
#endif
    VESYNC_ERR_RET_CHECK((VHAL_OK != ret), PLAT_FAIL)

    return PLAT_OK;
}

/**
 * @brief 清除ffs配网结果
 * @param void
 * @return int
 */
int vesync_ffs_flash_clear_result_data(void)
{
    int ret = VHAL_FAIL;

#if CONFIG_VESYNC_HAL_NVS_FLASH_ENABLE
    ret = vhal_nvs_flash_erase_key(USER_CFG_NAMESPACE, USER_CFG_KEY_FFS_FFS_RESULT);
#elif CONFIG_VESYNC_HAL_SPI_FLASH_ENABLE
    ret = vhal_flash_erase(PARTITION_CFG, USER_CFG_KEY_FFS_FFS_RESULT);
#endif
    if (VHAL_OK != ret)
    {
        VERR_UPLOAD(VERR_FLASH_ERASE_FAIL, 0);
    }
    VESYNC_ERR_RET_CHECK((VHAL_OK != ret), PLAT_FAIL)

    PLAT_LOG(LOG_DEBUG, "Clear ffs result data success...\n");

    return PLAT_OK;
}

