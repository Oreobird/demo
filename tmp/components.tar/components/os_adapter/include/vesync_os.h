/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_os.h
 * @brief       定义os相关宏及通用结构体
 * @date        2021-04-20
 */

#ifndef __VESYNC_OS_H__
#define __VESYNC_OS_H__

#ifdef __cplusplus
extern "C" {
#endif

#define VESYNC_OS_WAIT_FOREVER  (0xFFFFFFFFu)
#define VESYNC_OS_NO_WAIT       (0x0)
#define VESYNC_OS_SEM_MAX_COUNT (64)

/*
 * @brief  os对象通用结构体
 */
typedef struct _vesync_hanndle_t{
    void *handle;
} vesync_handle_t;

/*
 * @brief  延时函数
 * @param[in]  ms                     [延时时间，毫秒]
 * @return none
 */
void vesync_sleep(int ms);


#ifdef __cplusplus
}
#endif
#endif /* __VESYNC_OS_H__ */

