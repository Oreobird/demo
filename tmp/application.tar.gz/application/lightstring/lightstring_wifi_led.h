/**
*Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file    lightstring_wifi_led.h
* @brief   Wi-Fi指示灯配置
* @author  Lind
*@date     2021-12-20
*/

#ifndef __LIGHTSTRING_WIFI_LED_H__
#define __LIGHTSTRING_WIFI_LED_H__

#ifdef __cplusplus
extern "C" {
#endif

/**
* @brief  灯效配置
* @return     int             [成功/失败]
*/
int ls_reg_wifi_led(void);

#ifdef __cplusplus
}
#endif

#endif

