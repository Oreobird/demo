/**
 * Copyright © Etekcity Technologies Co., Ltd. 2019-2099. All rights reserved.
 * @file ffs_wifi_configuration_list.h
 * @brief Ffs Wi-Fi configuration list
 * @author  Owen.zhang
 * @date    2020-04-22
 */

#ifndef FFS_WIFI_CONFIGURATION_LIST_H_
#define FFS_WIFI_CONFIGURATION_LIST_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include "ffs_wifi_context.h"

#include <stddef.h>

    /** @brief Store the Wi-Fi configuration in the list by copy.
 *
 * @param wifiContext Wi-Fi context
 * @param configuration The Wi-Fi configuration
 *
 * @returns Enumerated [result](@ref FFS_RESULT)
 */
    FFS_RESULT ffsWifiConfigurationListPush(FfsWifiContext_t *wifiContext, FfsWifiConfiguration_t *configuration);

    /** @brief Retrieves the next Wi-Fi configuration in the list, without removing it.
 *
 * @param wifiContext Wi-Fi context
 * @param configuration The next Wi-Fi configuration
 *
 * @returns Enumerated [result](@ref FFS_RESULT)
 */
    FFS_RESULT ffsWifiConfigurationListPeek(FfsWifiContext_t *wifiContext, FfsWifiConfiguration_t **configuration);

    /** @brief Removes the next Wi-Fi configuration from the list and frees the resources.
 *
 * @param wifiContext Wi-Fi context
 *
 * @returns Enumerated [result](@ref FFS_RESULT)
 */
    FFS_RESULT ffsWifiConfigurationListPop(FfsWifiContext_t *wifiContext);

    /** @brief Removes a Wi-Fi configuration from the list by SSID.
 *
 * @param wifiContext Wi-Fi context
 * @param ssidStream SSID to remove
 *
 * @returns Enumerated [result](@ref FFS_RESULT)
 */
    FFS_RESULT ffsWifiConfigurationListPopConfiguration(FfsWifiContext_t *wifiContext, FfsStream_t ssidStream);

    /** @brief Removes all the Wi-Fi configurations from the list and frees the resources.
 *
 * @param wifiContext Wi-Fi context
 *
 * @returns Enumerated [result](@ref FFS_RESULT)
 */
    FFS_RESULT ffsWifiConfigurationListClear(FfsWifiContext_t *wifiContext);

    /** @brief Checks if the Wi-Fi configuration list is empty.
 *
 * @param wifiContext Wi-Fi context
 * @param isEmpty The result - true if empty; false otherwise
 *
 * @returns Enumerated [result](@ref FFS_RESULT)
 */
    FFS_RESULT ffsWifiConfigurationListIsEmpty(FfsWifiContext_t *wifiContext, bool *isEmpty);

#ifdef __cplusplus
}
#endif

#endif /* FFS_WIFI_CONFIGURATION_LIST_H_ */
