/**
 * Copyright © Vesync Technologies Co.Ltd. 2019-2021. All rights reserved
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>

#include "mbedtls/entropy.h"
#if defined(CONFIG_TARGET_RTL8710CX) || defined(CONFIG_TARGET_RTL8720CF)
#include "mbedtls/platform.h"
#endif

#include "vesync_memory.h"

#include "mqtt_util.h"
#include "transport_ssl_private.h"


/* we do not use global ca_store, just let the variable exists currently. */
static mbedtls_x509_crt *global_cacert = NULL;


static void transport_util_ms_to_timeval(int timeout_ms, struct timeval *tv)
{
    tv->tv_sec = timeout_ms / 1000;
    tv->tv_usec = (timeout_ms - (tv->tv_sec * 1000)) * 1000;
}

static ssize_t tcp_read(vesync_tls_t *tls, char *data, size_t datalen)
{
    return recv(tls->sockfd, data, datalen, 0);
}

static ssize_t tls_read(vesync_tls_t *tls, char *data, size_t datalen)
{
    ssize_t ret = mbedtls_ssl_read(&tls->ssl, (unsigned char *)data, datalen);
    if (ret < 0)
    {
        if (MBEDTLS_ERR_SSL_PEER_CLOSE_NOTIFY == ret)
        {
            return 0;
        }
        if (ret != MBEDTLS_ERR_SSL_WANT_READ  && ret != MBEDTLS_ERR_SSL_WANT_WRITE) {
            TRANSPORT_LOG(LOG_ERROR, "read error:%d\n", ret);
            VERR_UPLOAD(VERR_MQTT_RECV_DATA_FAIL, ret)
        }
    }
    return ret;
}

static int vesync_mqtt_trans_tcp_connect(const struct addrinfo *ai, int port, int *sockfd, const vesync_tls_cfg_t *cfg)
{
    int ret = -1;

    VESYNC_TRANSPORT_MEM_CHECK(sockfd, return -1);
    VESYNC_TRANSPORT_MEM_CHECK(ai, return -1);
    VESYNC_TRANSPORT_MEM_CHECK(cfg, return -1);

    int fd = socket(ai->ai_family, ai->ai_socktype, ai->ai_protocol);
    if (fd < 0)
    {
        TRANSPORT_LOG(LOG_ERROR, "Failed to create socket (family %d socktype %d protocol %d)\n", ai->ai_family, ai->ai_socktype, ai->ai_protocol);
        TRANSPORT_LOG_ERROR("Failed to create socket (family %d socktype %d protocol %d)", ai->ai_family, ai->ai_socktype, ai->ai_protocol);
        socklen_t optlen = sizeof(int);
        int socket_err;
        if (getsockopt(fd, SOL_SOCKET, SO_ERROR, &socket_err, &optlen) < 0)
        {
            VERR_UPLOAD(VERR_SOCK_CREATE_FAIL, -1);
        }
        else
        {
            VERR_UPLOAD(VERR_SOCK_CREATE_FAIL, socket_err);
        }
        goto err_freeaddr;
    }
    *sockfd = fd;

    void *addr_ptr;
    if (ai->ai_family == AF_INET)
    {
        struct sockaddr_in *p = (struct sockaddr_in *)ai->ai_addr;
        p->sin_port = htons(port);
        addr_ptr = p;
        TRANSPORT_LOG(LOG_DEBUG, "%s, %d\n", inet_ntoa(p->sin_addr), ai->ai_addrlen);
    }
#if LWIP_IPV6
    else if (ai->ai_family == AF_INET6)
    {
        struct sockaddr_in6 *p = (struct sockaddr_in6 *)ai->ai_addr;
        p->sin6_port = htons(port);
        p->sin6_family = AF_INET6;
        addr_ptr = p;
    }
#endif
    else
    {
        TRANSPORT_LOG(LOG_ERROR, "Unsupported protocol family %d\n", ai->ai_family);
        TRANSPORT_LOG_ERROR("Unsupported protocol family %d", ai->ai_family);
        VERR_UPLOAD(VERR_PROTOCOL_UNSUPPORT, ai->ai_family);
        goto err_freesocket;
    }

    if (cfg)
    {
        if (cfg->timeout_ms >= 0)
        {
            struct timeval tv;
            transport_util_ms_to_timeval(cfg->timeout_ms, &tv);
            setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
        }
        if (cfg->non_block)
        {
            int flags = fcntl(fd, F_GETFL, 0);
            fcntl(fd, F_SETFL, flags | O_NONBLOCK);
        }
    }

    ret = connect(fd, addr_ptr, ai->ai_addrlen);
    if (ret < 0 && !(errno == EINPROGRESS && cfg->non_block))
    {
        TRANSPORT_LOG(LOG_ERROR, "Failed to connnect to host (errno %d)\n", errno);
        TRANSPORT_LOG_ERROR("Failed to connnect to host (errno %d)", errno);
        goto err_freesocket;
    }

    return 0;

err_freesocket:
    close(fd);
err_freeaddr:
    return ret;
}

static void verify_certificate(vesync_tls_t *tls)
{
    int flags;
    char buf[100] = {0};

    VESYNC_TRANSPORT_MEM_CHECK(tls, return);

    if ((flags = mbedtls_ssl_get_verify_result(&tls->ssl)) != 0)
    {
        TRANSPORT_LOG(LOG_INFO, "Failed to verify peer certificate!\n");
        bzero(buf, sizeof(buf));
        mbedtls_x509_crt_verify_info(buf, sizeof(buf), "  ! ", flags);
        TRANSPORT_LOG(LOG_INFO, "verification info: %s\n", buf);
    }
    else
    {
        TRANSPORT_LOG(LOG_INFO, "Certificate verified.\n");
    }
}

static void mbedtls_cleanup(vesync_tls_t *tls)
{
    VESYNC_TRANSPORT_MEM_CHECK(tls, return);

    if (tls->cacert_ptr != global_cacert)
    {
        mbedtls_x509_crt_free(tls->cacert_ptr);
    }
    tls->cacert_ptr = NULL;
    mbedtls_x509_crt_free(&tls->cacert);
    mbedtls_x509_crt_free(&tls->clientcert);
    mbedtls_pk_free(&tls->clientkey);
    mbedtls_entropy_free(&tls->entropy);
    mbedtls_ssl_config_free(&tls->conf);
    mbedtls_ctr_drbg_free(&tls->ctr_drbg);
    mbedtls_ssl_free(&tls->ssl);
    mbedtls_net_free(&tls->server_fd);
}

#ifdef VESYNC_SSL_REMOVE_SERVER_NAME_INDICATION
static int vtls_net_send(void *ctx, const unsigned char *buf, size_t len)
{
    int ret = -1;
    vesync_tls_t *tls = (vesync_tls_t*)ctx;
    if (MBEDTLS_SSL_SERVER_HELLO == tls->ssl.state)
    {
        if (NULL != tls->hostname)
        {
            if ((ret = mbedtls_ssl_set_hostname(&tls->ssl, tls->hostname)) != 0)
            {
                TRANSPORT_LOG(LOG_ERROR, "mbedtls_ssl_set_hostname returned -0x%x\n", -ret);
                vesync_free(tls->hostname);
                tls->hostname = NULL;
                return ret;
            }
            vesync_free(tls->hostname);
            tls->hostname = NULL;
        }

    }
    return mbedtls_net_send(&tls->server_fd, buf, len);
}

static int vtls_net_recv(void *ctx, unsigned char *buf, size_t len)
{
    vesync_tls_t *tls = (vesync_tls_t*)ctx;
    return mbedtls_net_recv(&tls->server_fd, buf, len);
}
#endif /* VESYNC_SSL_REMOVE_SERVER_NAME_INDICATION */

static int create_ssl_handle(vesync_tls_t *tls, const vesync_tls_cfg_t *cfg)
{
    int ret = -1;

    VESYNC_TRANSPORT_MEM_CHECK(tls, return -1);

#if defined(CONFIG_TARGET_RTL8710CX) || defined(CONFIG_TARGET_RTL8720CF)
    mbedtls_platform_set_calloc_free(calloc, free);
#endif
    mbedtls_net_init(&tls->server_fd);
    mbedtls_ssl_init(&tls->ssl);
    mbedtls_ctr_drbg_init(&tls->ctr_drbg);
    mbedtls_ssl_config_init(&tls->conf);
    mbedtls_entropy_init(&tls->entropy);

    if ((ret = mbedtls_ctr_drbg_seed(&tls->ctr_drbg,
                    mbedtls_entropy_func, &tls->entropy, NULL, 0)) != 0)
    {
        TRANSPORT_LOG(LOG_ERROR, "mbedtls_ctr_drbg_seed returned %d\n", ret);
        VERR_UPLOAD(VERR_MQTT_TLS_SETUP_FAIL, ret);
        goto exit;
    }

    if ((ret = mbedtls_ssl_config_defaults(&tls->conf,
                    MBEDTLS_SSL_IS_CLIENT,
                    MBEDTLS_SSL_TRANSPORT_STREAM,
                    MBEDTLS_SSL_PRESET_DEFAULT)) != 0)
    {
        TRANSPORT_LOG(LOG_ERROR, "mbedtls_ssl_config_defaults returned %d\n", ret);
        VERR_UPLOAD(VERR_MQTT_TLS_SETUP_FAIL, ret);
        goto exit;
    }

#ifdef CONFIG_MBEDTLS_SSL_ALPN
    if (cfg->alpn_protos)
    {
        mbedtls_ssl_conf_alpn_protocols(&tls->conf, cfg->alpn_protos);
    }
#endif

    // ESP8266的内存容量限制，不开启此处的CA认证程序
#if !defined(CONFIG_IDF_TARGET_ESP8266)
    if (true == cfg->use_global_ca_store)
    {
        if (NULL == global_cacert)
        {
            TRANSPORT_LOG(LOG_ERROR, "global_cacert is NULL\n");
            VERR_UPLOAD(VERR_MQTT_TLS_SETUP_FAIL, (int)(global_cacert));
            goto exit;
        }
        tls->cacert_ptr = global_cacert;
        mbedtls_ssl_conf_authmode(&tls->conf, MBEDTLS_SSL_VERIFY_REQUIRED);
        mbedtls_ssl_conf_ca_chain(&tls->conf, tls->cacert_ptr, NULL);
    }
    else if (cfg->cacert_pem_buf != NULL)
    {
        tls->cacert_ptr = &tls->cacert;
        mbedtls_x509_crt_init(tls->cacert_ptr);
        ret = mbedtls_x509_crt_parse(tls->cacert_ptr, cfg->cacert_pem_buf, cfg->cacert_pem_bytes);
        if (ret < 0) {
            TRANSPORT_LOG(LOG_ERROR, "mbedtls_x509_crt_parse returned -0x%x\n\n", -ret);
            VERR_UPLOAD(VERR_MQTT_TLS_SETUP_FAIL, ret);
            goto exit;
        }
        mbedtls_ssl_conf_authmode(&tls->conf, MBEDTLS_SSL_VERIFY_REQUIRED);
        mbedtls_ssl_conf_ca_chain(&tls->conf, tls->cacert_ptr, NULL);
    }
    else
#endif
    {
        mbedtls_ssl_conf_authmode(&tls->conf, MBEDTLS_SSL_VERIFY_NONE);
    }

    if (cfg->clientcert_pem_buf != NULL && cfg->clientkey_pem_buf != NULL)
    {
        mbedtls_x509_crt_init(&tls->clientcert);
        mbedtls_pk_init(&tls->clientkey);

        ret = mbedtls_x509_crt_parse(&tls->clientcert, cfg->clientcert_pem_buf, cfg->clientcert_pem_bytes);
        if (ret < 0)
        {
            TRANSPORT_LOG(LOG_ERROR, "mbedtls_x509_crt_parse returned -0x%x\n\n", -ret);
            VERR_UPLOAD(VERR_MQTT_TLS_SETUP_FAIL, ret);
            goto exit;
        }

        ret = mbedtls_pk_parse_key(&tls->clientkey, cfg->clientkey_pem_buf, cfg->clientkey_pem_bytes,
                  cfg->clientkey_password, cfg->clientkey_password_len);
        if (ret < 0)
        {
            TRANSPORT_LOG(LOG_ERROR, "mbedtls_pk_parse_keyfile returned -0x%x\n\n", -ret);
            VERR_UPLOAD(VERR_MQTT_TLS_SETUP_FAIL, ret);
            goto exit;
        }

        ret = mbedtls_ssl_conf_own_cert(&tls->conf, &tls->clientcert, &tls->clientkey);
        if (ret < 0)
        {
            TRANSPORT_LOG(LOG_ERROR, "mbedtls_ssl_conf_own_cert returned -0x%x\n\n", -ret);
            VERR_UPLOAD(VERR_MQTT_TLS_SETUP_FAIL, ret);
            goto exit;
        }
    } else if (cfg->clientcert_pem_buf != NULL || cfg->clientkey_pem_buf != NULL) {
        TRANSPORT_LOG(LOG_ERROR, "You have to provide both clientcert_pem_buf and clientkey_pem_buf for mutual authentication\n\n");
        VERR_UPLOAD(VERR_MQTT_TLS_SETUP_FAIL, 0);
        goto exit;
    }

    mbedtls_ssl_conf_rng(&tls->conf, mbedtls_ctr_drbg_random, &tls->ctr_drbg);

    if ((ret = mbedtls_ssl_setup(&tls->ssl, &tls->conf)) != 0)
    {
        TRANSPORT_LOG(LOG_ERROR, "mbedtls_ssl_setup returned -0x%x\n\n", -ret);
        VERR_UPLOAD(VERR_MQTT_TLS_SETUP_FAIL, ret);
        goto exit;
    }

    return 0;
exit:
    mbedtls_cleanup(tls);
    return -1;
}

/**
 * @brief      Close the TLS connection and free any allocated resources.
 */
static void vesync_mqtt_trans_tls_conn_delete(vesync_tls_t *tls)
{
    if (tls != NULL)
    {
        mbedtls_cleanup(tls);
        tls->sockfd = -1;
        vesync_free(tls);
    }
};

static ssize_t tcp_write(vesync_tls_t *tls, const char *data, size_t datalen)
{
    VESYNC_TRANSPORT_MEM_CHECK(tls, return -1);
    VESYNC_TRANSPORT_MEM_CHECK(data, return -1);

    return send(tls->sockfd, data, datalen, 0);
}

static ssize_t tls_write(vesync_tls_t *tls, const char *data, size_t datalen)
{
    VESYNC_TRANSPORT_MEM_CHECK(tls, return -1);
    VESYNC_TRANSPORT_MEM_CHECK(data, return -1);

    ssize_t ret = mbedtls_ssl_write(&tls->ssl, (unsigned char*) data, datalen);
    if (ret < 0) {
        if (ret != MBEDTLS_ERR_SSL_WANT_READ  && ret != MBEDTLS_ERR_SSL_WANT_WRITE) {
            TRANSPORT_LOG(LOG_ERROR, "write error: %d\n", ret);
            VERR_UPLOAD(VERR_MQTT_SEND_DATA_FAIL, ret);
        }
    }
    return ret;
}

static void *vesync_transport_get_context_data(vesync_transport_handle_t t)
{
    VESYNC_TRANSPORT_MEM_CHECK(t, return NULL);
    return t->data;
}

static int vesync_transport_set_context_data(vesync_transport_handle_t t, void *data)
{
    VESYNC_TRANSPORT_MEM_CHECK(t, return VERR_FAIL);
    t->data = data;
    return VERR_OK;
}


static int vesync_mqtt_trans_tls_connect(const struct addrinfo *ai, const char *hostname, int port, const vesync_tls_cfg_t *cfg, vesync_tls_t *tls)
{
    int ret = -1;
    int sockfd = -1;
    uint64_t start = 0;

    ret = vesync_mqtt_trans_tcp_connect(ai, port, &sockfd, cfg);
    if (ret < 0)
    {
        TRANSPORT_LOG(LOG_ERROR, "tcp connect failed\n");
        return -1;
    }
    tls->sockfd = sockfd;
    tls->server_fd.fd = tls->sockfd;
    if (!cfg)
    {
        tls->read = tcp_read;
        tls->write = tcp_write;
        TRANSPORT_LOG(LOG_DEBUG, "non-tls connection established\n");
        return 0;
    }

#ifdef VESYNC_SSL_REMOVE_SERVER_NAME_INDICATION
    if (NULL != tls->hostname)
    {
        vesync_free(tls->hostname);
    }
    tls->hostname = mqtt_create_string(hostname);
    mbedtls_ssl_set_bio(&tls->ssl, tls, vtls_net_send, vtls_net_recv, NULL);
#else
    if ((ret = mbedtls_ssl_set_hostname(&tls->ssl, hostname)) != 0)
    {
        TRANSPORT_LOG(LOG_ERROR, "mbedtls_ssl_set_hostname returned -0x%x\n", -ret);
        VERR_UPLOAD(VERR_MQTT_TLS_SETUP_FAIL, ret);
        goto exit;
    }

    mbedtls_ssl_set_bio(&tls->ssl, &tls->server_fd, mbedtls_net_send, mbedtls_net_recv, NULL);
#endif

    TRANSPORT_LOG(LOG_DEBUG, "handshake in progress...\n");
    //mbedtls_ssl_session_reset(&tls->ssl);
    start = mqtt_util_tick_get_ms();
    while((ret = mbedtls_ssl_handshake(&tls->ssl)) != 0)
    {
        if (ret != MBEDTLS_ERR_SSL_WANT_READ && ret != MBEDTLS_ERR_SSL_WANT_WRITE)
        {
            TRANSPORT_LOG(LOG_ERROR, "mbedtls_ssl_handshake returned -0x%x\n", -ret);
            if (cfg->cacert_pem_buf != NULL || true == cfg->use_global_ca_store)
            {
                /* This is to check whether handshake failed due to invalid certificate*/
                verify_certificate(tls);
            }

            VERR_UPLOAD(VERR_MQTT_TLS_SETUP_FAIL, ret);
            goto exit;
        }

        if(cfg->timeout_ms > 0 && mqtt_util_tick_get_ms() - start >= cfg->timeout_ms)
        {
            TRANSPORT_LOG(LOG_ERROR, "handshake timeout(%d)ms\n", cfg->timeout_ms);
            VERR_UPLOAD(VERR_MQTT_TLS_SETUP_FAIL, expired);
            goto exit;
        }
        TRANSPORT_LOG(LOG_ERROR, "mbedtls_ssl_handshake returned -0x%x, try again\n", -ret);
    }

    return 0;
exit:
    mbedtls_net_free(&tls->server_fd);
    return -1;
}


/**
 * @brief      Create a new TLS/SSL connection
 */
static vesync_tls_t *vesync_mqtt_trans_tls_conn_new(const vesync_tls_cfg_t *cfg)
{
    vesync_tls_t *tls = (vesync_tls_t *)vesync_calloc(1, sizeof(vesync_tls_t));
    if(NULL == tls)
    {
        VERR_UPLOAD(VERR_LINK_MOD_COM(VERR_MEM_ALLOC_FAIL), vhal_get_free_heap_size());
        return NULL;
    }

    tls->server_fd.fd = -1;
    tls->sockfd = -1;

    if(!cfg)
    {
        tls->read = tcp_read;
        tls->write = tcp_write;
        return tls;
    }

    int ret = create_ssl_handle(tls, cfg);
    if (ret != 0)
    {
        TRANSPORT_LOG(LOG_ERROR, "create_ssl_handle failed\n");
        VCOM_SAFE_FREE(tls);
        return NULL;
    }
    tls->read = tls_read;
    tls->write = tls_write;

    return tls;
}

static int ssl_connect(vesync_transport_handle_t t, const struct addrinfo *ai, const char *hostname, int port, int timeout_ms)
{
    VESYNC_TRANSPORT_MEM_CHECK(t, return -1);
    VESYNC_TRANSPORT_MEM_CHECK(ai, return -1);
    VESYNC_TRANSPORT_MEM_CHECK(hostname, return -1);

    transport_ssl_t *ssl = vesync_transport_get_context_data(t);
    VESYNC_TRANSPORT_MEM_CHECK(ssl, return -1);
    ssl->cfg.timeout_ms = timeout_ms;

    if(true != ssl->ssl_initialized)
    {
        ssl->tls = vesync_mqtt_trans_tls_conn_new(&ssl->cfg);
        if (!ssl->tls)
        {
            TRANSPORT_LOG(LOG_ERROR, "tls new failed\n");
            return -1;
        }
        ssl->ssl_initialized = true;
    }

    if(vesync_mqtt_trans_tls_connect(ai, hostname, port, &ssl->cfg, ssl->tls) != 0)
    {
        TRANSPORT_LOG(LOG_ERROR, "tls connect failed\n");
        return -1;
    }

    return 0;
}

static int ssl_poll_read(vesync_transport_handle_t t, int timeout_ms)
{
    VESYNC_TRANSPORT_MEM_CHECK(t, return -1);

    transport_ssl_t *ssl = vesync_transport_get_context_data(t);
    VESYNC_TRANSPORT_MEM_CHECK(ssl, return -1);

    int ret = -1;
    fd_set readset;
    fd_set errset;
    FD_ZERO(&readset);
    FD_ZERO(&errset);
    FD_SET(ssl->tls->sockfd, &readset);
    FD_SET(ssl->tls->sockfd, &errset);
    struct timeval timeout;
    transport_util_ms_to_timeval(timeout_ms, &timeout);

    ret = select(ssl->tls->sockfd + 1, &readset, NULL, &errset, &timeout);
    if (ret > 0 && FD_ISSET(ssl->tls->sockfd, &errset))
    {
        int sock_errno = 0;
        socklen_t optlen = (socklen_t)sizeof(sock_errno);
        getsockopt(ssl->tls->sockfd, SOL_SOCKET, SO_ERROR, &sock_errno, &optlen);
        TRANSPORT_LOG(LOG_ERROR, "ssl_poll_read select error %d, errno = %s, fd = %d\n", sock_errno, strerror(sock_errno), ssl->tls->sockfd);
        ret = -1;
    }
    return ret;
}

static int ssl_poll_write(vesync_transport_handle_t t, int timeout_ms)
{
    VESYNC_TRANSPORT_MEM_CHECK(t, return -1);

    transport_ssl_t *ssl = vesync_transport_get_context_data(t);
    VESYNC_TRANSPORT_MEM_CHECK(ssl, return -1);

    int ret = -1;
    fd_set writeset;
    fd_set errset;
    FD_ZERO(&writeset);
    FD_ZERO(&errset);
    FD_SET(ssl->tls->sockfd, &writeset);
    FD_SET(ssl->tls->sockfd, &errset);
    struct timeval timeout;
    transport_util_ms_to_timeval(timeout_ms, &timeout);
    ret = select(ssl->tls->sockfd + 1, NULL, &writeset, &errset, &timeout);
    if (ret > 0 && FD_ISSET(ssl->tls->sockfd, &errset))
    {
        int sock_errno = 0;
        socklen_t optlen = (socklen_t)sizeof(sock_errno);
        getsockopt(ssl->tls->sockfd, SOL_SOCKET, SO_ERROR, &sock_errno, &optlen);
        TRANSPORT_LOG(LOG_ERROR, "ssl_poll_write select error %d, errno = %s, fd = %d", sock_errno, strerror(sock_errno), ssl->tls->sockfd);
        ret = -1;
    }
    return ret;
}

static int ssl_write(vesync_transport_handle_t t, const char *buffer, int len, int timeout_ms)
{
    int poll, ret;

    VESYNC_TRANSPORT_MEM_CHECK(t, return -1);

    transport_ssl_t *ssl = vesync_transport_get_context_data(t);
    VESYNC_TRANSPORT_MEM_CHECK(ssl, return -1);

    if ((poll = t->_poll_write(t, timeout_ms)) <= 0)
    {
        TRANSPORT_LOG(LOG_WARN, "Poll timeout or error, errno=%s, fd=%d, timeout_ms=%d\n", strerror(errno), ssl->tls->sockfd, timeout_ms);
        return poll;
    }
    ret = ssl->tls->write(ssl->tls, (const char *) buffer, len);
    if (ret < 0)
    {
        TRANSPORT_LOG(LOG_ERROR, "vesync_tls_conn_write error, errno=%s\n", strerror(errno));
    }
    return ret;
}

static int ssl_read(vesync_transport_handle_t t, char *buffer, int len, int timeout_ms)
{
    int poll, ret;

    VESYNC_TRANSPORT_MEM_CHECK(t, return -1);

    transport_ssl_t *ssl = vesync_transport_get_context_data(t);
    VESYNC_TRANSPORT_MEM_CHECK(ssl, return -1);

    if (mbedtls_ssl_get_bytes_avail(&(ssl->tls->ssl)) <= 0)
    {
        if ((poll = t->_poll_read(t, timeout_ms)) <= 0)
        {
            return poll;
        }
    }
    ret = ssl->tls->read(ssl->tls, (char *)buffer, len);
    if (ret < 0)
    {
        TRANSPORT_LOG(LOG_ERROR, "vesync_tls_conn_read error, errno=%s\n", strerror(errno));
    }
    if (ret == 0) {
        ret = -1;
    }
    return ret;
}

static int ssl_close(vesync_transport_handle_t t)
{
    int ret = -1;

    VESYNC_TRANSPORT_MEM_CHECK(t, return -1);

    transport_ssl_t *ssl = vesync_transport_get_context_data(t);
    VESYNC_TRANSPORT_MEM_CHECK(ssl, return -1);

    if (ssl->ssl_initialized)
    {
        mbedtls_net_free(&ssl->tls->server_fd);
        ssl->tls->sockfd = -1;
        mbedtls_ssl_session_reset(&ssl->tls->ssl);
    }
    return ret;
}

static int ssl_destroy(vesync_transport_handle_t t)
{
    VESYNC_TRANSPORT_MEM_CHECK(t, return -1);

    transport_ssl_t *ssl = vesync_transport_get_context_data(t);
    VESYNC_TRANSPORT_MEM_CHECK(ssl, return -1);

    if (NULL != ssl)
    {
        if (ssl->ssl_initialized)
        {
            vesync_mqtt_trans_tls_conn_delete(ssl->tls);
            ssl->ssl_initialized = false;
        }
        vesync_free(ssl);
        ssl = NULL;
    }
    return 0;
}

static int vesync_transport_set_func(vesync_transport_handle_t t,
                             connect_func _connect,
                             io_read_func _read,
                             io_func _write,
                             trans_func _close,
                             poll_func _poll_read,
                             poll_func _poll_write,
                             trans_func _destroy)
{
    if (t == NULL) {
        return VERR_FAIL;
    }
    t->_connect = _connect;
    t->_read = _read;
    t->_write = _write;
    t->_close = _close;
    t->_poll_read = _poll_read;
    t->_poll_write = _poll_write;
    t->_destroy = _destroy;
    return VERR_OK;
}

/**
 * @brief       Create new SSL transport, the transport handle must be release vesync_transport_destroy callback
 * @return      vesync_transport_handle_t   [the allocated vesync_transport_handle_t, or NULL if the handle can not be allocated]
 */
vesync_transport_handle_t vesync_transport_ssl_init(void)
{
    vesync_transport_handle_t t = vesync_calloc(1, sizeof(struct vesync_transport_item_t));
    transport_ssl_t *ssl = vesync_calloc(1, sizeof(transport_ssl_t));
    if(NULL == t || NULL == ssl)
    {
        goto EXIT;
    }

    vesync_transport_set_context_data(t, ssl);

    vesync_transport_set_func(t, ssl_connect, ssl_read, ssl_write, ssl_close, ssl_poll_read, ssl_poll_write, ssl_destroy);

    return t;
EXIT:
    VCOM_SAFE_FREE(t);
    VCOM_SAFE_FREE(ssl);
    return NULL;
}

/**
 * @brief       Set SSL certificate data (as DER format).
 *              Note that, this function stores the pointer to data, rather than making a copy.
 *              So this data must remain valid until after the connection is cleaned up
 * @param       t                           [ssl transport]
 * @param[in]   data                        [The pem data]
 * @param[in]   len                         [The length]
 */
void vesync_transport_ssl_set_cert_data_der(vesync_transport_handle_t t, const char *data, int len)
{
    VESYNC_TRANSPORT_MEM_CHECK(t, return);
    VESYNC_TRANSPORT_MEM_CHECK(data, return);

    transport_ssl_t *ssl = vesync_transport_get_context_data(t);
    if (ssl) {
        ssl->cfg.cacert_buf = (void *)data;
        ssl->cfg.cacert_bytes = len;
    }
}

/**
 * @brief       Set SSL client certificate data for mutual authentication (as DER format).
 *              Note that, this function stores the pointer to data, rather than making a copy.
 *              So this data must remain valid until after the connection is cleaned up
 * @param       t                           [ssl transport]
 * @param[in]   data                        [The pem data]
 * @param[in]   len                         [The length]
 */
void vesync_transport_ssl_set_client_cert_data_der(vesync_transport_handle_t t, const char *data, int len)
{
    VESYNC_TRANSPORT_MEM_CHECK(t, return);
    VESYNC_TRANSPORT_MEM_CHECK(data, return);

    transport_ssl_t *ssl = vesync_transport_get_context_data(t);
    if (ssl) {
        ssl->cfg.clientcert_buf = (void *)data;
        ssl->cfg.clientcert_bytes = len;
    }
}

/**
 * @brief       Set SSL client key data for mutual authentication (as DER format).
 *              Note that, this function stores the pointer to data, rather than making a copy.
 *              So this data must remain valid until after the connection is cleaned up
 * @param       t                           [ssl transport]
 * @param[in]   data                        [The pem data]
 * @param[in]   len                         [The length]
 */
void vesync_transport_ssl_set_client_key_data_der(vesync_transport_handle_t t, const char *data, int len)
{
    VESYNC_TRANSPORT_MEM_CHECK(t, return);
    VESYNC_TRANSPORT_MEM_CHECK(data, return);

    transport_ssl_t *ssl = vesync_transport_get_context_data(t);
    if (ssl) {
        ssl->cfg.clientkey_buf = (void *)data;
        ssl->cfg.clientkey_bytes = len;
    }
}

/**
 * @brief       Enable global CA store for SSL connection
 * @param       t                           [ssl transport]
 */
void vesync_transport_ssl_enable_global_ca_store(vesync_transport_handle_t t)
{
    VESYNC_TRANSPORT_MEM_CHECK(t, return);

    transport_ssl_t *ssl = vesync_transport_get_context_data(t);
    if (ssl) {
        ssl->cfg.use_global_ca_store = true;
    }
}

/**
 * @brief       dns resolve for the host
 * @param[in]   host                        [pointer to host name]
 * @return      struct addrinfo*            [pointer to the addrinfo, or NULL if can not resolve]
 */
struct addrinfo* vesync_transport_resolve_host(const char *host)
{
    int32_t ret;
    char *use_host = NULL;
    struct addrinfo *res = NULL;
    struct addrinfo hints;

    use_host = mqtt_create_string(host);
    if (!use_host)
    {
        VERR_UPLOAD(VERR_LINK_MOD_COM(VERR_MEM_ALLOC_FAIL), vhal_get_free_heap_size());
        return NULL;
    }
    SDK_LOG(LOG_DEBUG, "host:%s: strlen %d\n", use_host, strlen(use_host));

    memset(&hints, 0, sizeof(hints));
    hints.ai_family = AF_UNSPEC;
    hints.ai_socktype = SOCK_STREAM;

    if ((ret = getaddrinfo(use_host, NULL, &hints, &res)))
    {
        SDK_LOG(LOG_ERROR, "dns error(%d), couldn't get hostname for: %s\n", ret, use_host);
        MQTT_LOG_ERROR("dns error(%d), couldn't get hostname for: %s", ret, use_host);
        vesync_free(use_host);
        return NULL;
    }
    vesync_free(use_host);

    SDK_LOG(LOG_DEBUG, "%d, %d, %d\n", res->ai_family, res->ai_socktype, res->ai_protocol);
    SDK_LOG(LOG_DEBUG, "IP: %s, %d\n", inet_ntoa(((struct sockaddr_in *)res->ai_addr)->sin_addr), res->ai_addrlen);

    return res;
}

