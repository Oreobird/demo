/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
 * @file        vdrv_sht30.h
 * @brief       sht30驱动接口
 * @date        2021-09-13
 */
#ifndef __VDRV_SHT30_H__
#define __VDRV_SHT30_H__

#include <stdint.h>

#ifdef __cplusplus
extern "C"
{
#endif

#define CELSIUS_UNIT            0           // 摄氏度单位
#define FAHRENHEIT_UNIT         1           // 华氏度单位

/**
 * @brief 初始化传感器
 * @return int                  [成功：SDK_OK，失败：SDK_FAIL]
 */
int vdrv_sht30_init(void);

/**
 * @brief 读取温湿度值
 * @param[out] p_temp            [温度值]
 * @param[out] p_humi            [湿度值]
 * @return int                   [成功：SDK_OK，失败：SDK_FAIL]
 */
int vdrv_sht30_get_temp_and_humi(float *p_temp, float *p_humi);


#ifdef __cplusplus
}
#endif

#endif /* __VDRV_SHT30_H__ */

