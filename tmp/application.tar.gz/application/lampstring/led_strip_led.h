/**
* Copyright © Vesync Technologies Co.Ltd. 2022. All rights reserved.
* @file    led_strip_led.h
* @brief   led控制
* @author  Lind
* @date    2022-01-04
*/

#ifndef __LED_STRIP_LED_H__
#define __LED_STRIP_LED_H__

#include <stdbool.h>
#include <stdint.h>

#include "vesync_device.h"
#include "vesync_task.h"

#include "led_strip_scene.h"

#ifdef __cplusplus
extern "C" {
#endif

/*
 * @brief LedStrip 变化灯效状态记录
 */
typedef struct
{
    uint8_t cur_node;                   // 模式当前的灯效节点1->2 为1
    uint8_t remain_times;               // 剩余周期次数
    uint16_t step_num;                  // 灯效节点完全切换的步数，等于时间
    uint16_t remain_step;               // 灯效节点完全切换的剩余步数，等于时间
} ls_changing_status_t;

/**
* @brief 更新灯效
* @param[in]  *pst_scene    [参数]
*/
void ls_led_set_scene(ls_scene_t *pst_scene);

/**
* @brief 更新灯珠数量
* @param[in]  num    [参数]
*/
void ls_led_set_led_num(uint8_t num);

/**
* @brief 显示灯效
*/
void ls_led_display_handle(void);

/**
* @brief  led 控制初始化
*/
void ls_led_init();

#ifdef __cplusplus
}
#endif

#endif

