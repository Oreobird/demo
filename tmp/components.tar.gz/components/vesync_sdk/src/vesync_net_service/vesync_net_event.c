/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_net_service.c
 * @brief       网络事件管理
 * @author      CharlesMei
 * @date        2021-06-04
 */


#include <string.h>

#include "vhal_utils.h"
#include "vhal_wifi.h"

#include "vesync_event_internal.h"
#if CONFIG_VESYNC_SDK_MQTT_ENABLE
#include "vesync_net_mqtt_internal.h"
#endif
#if CONFIG_VESYNC_SDK_LAN_COMM_ENABLE
#include "vesync_lan_comm.h"
#endif
#if CONFIG_VESYNC_SDK_LAN_COMM_ENABLE
#include "vesync_lan_comm.h"
#endif
#include "vesync_net_service_private.h"
#include "vesync_report.h"
#include "vesync_device_internal.h"
#include "vesync_timer.h"

static network_mgt_t s_network_mgmt =
{
    /* old_ts = */              0,
    /* new_ts = */              0,
    /* wifi_timeout_flag = */   false,
    /* serv_timeout_flag = */   false,
#if CONFIG_VESYNC_SDK_MQTT_ENABLE
    /* reset_net_cfg = */       true,
    /* net_disc_flag = */       false,
#endif /* CONFIG_VESYNC_SDK_MQTT_ENABLE */
};

// 状态上报轮询UTC时间定时器
static vesync_timer_t *s_dev_info_report_timer = NULL;

// APP层注册的网络连接成功回调
static void (*s_network_connected_app_cb)(void) = NULL;

/**
 * @brief       密码重置标志位复位事件处理
 * @param[in]   p_msg               [未使用]
 * @return      int                 [成功/失败]
 */
static int network_reset_netcfg_event_handle_cb(void *p_msg)
{
    UNUSED(p_msg);
#if CONFIG_VESYNC_SDK_MQTT_ENABLE
    s_network_mgmt.reset_net_cfg = false;
#endif
    return VERR_OK;
}

/**
 * @brief       配网成功事件处理
 * @param[in]   p_msg               [未使用]
 * @return      int                 [成功/失败]
 */
static int network_netcfg_succeed_event_handle_cb(void *p_msg)
{
    UNUSED(p_msg);

    vesync_net_mgmt_set_reconnect_time(NETWORK_RECONN_TS);

    /* config net task may update cfg into flash. */
    if (VERR_OK != vesync_net_mgmt_load_net_cfg())
    {
        NET_LOG(LOG_ERROR, "netcfg info: read flash error!!!\n");
    }

#if CONFIG_VESYNC_SDK_LAN_COMM_ENABLE
    vesync_lan_comm_start();    // 启动局域网通信功能
#endif


    return VERR_OK;
}

/**
 * @brief       Wi-Fi断开事件处理
 * @param[in]   p_msg               [未使用]
 * @return      int                 [成功/失败]
 */
static int wifi_disconnected_event_handle_cb(void *p_msg)
{
    UNUSED(p_msg);

    if (vesync_net_mgmt_set_reconnect_time(WIFI_DISCONN_TS))
    {
        if (!(s_network_mgmt.wifi_timeout_flag))
        {
            vesync_wifi_led_set_behavior(WIFI_LED_WIFI_TIMEOUT);     // Wi-Fi断开超过10min
            s_network_mgmt.wifi_timeout_flag = true;
        }
    }
    else
    {
        vesync_wifi_led_set_behavior(WIFI_LED_WIFI_DISC);
    }
    return VERR_OK;
}

/**
 * @brief       设备获取ip事件处理
 * @param[in]   p_msg               [未使用]
 * @return      int                 [成功/失败]
 */
static int wifi_got_ip_event_handle_cb(void *p_msg)
{
    UNUSED(p_msg);

    vesync_wifi_led_set_behavior(WIFI_LED_SERVER_DISC);

    vesync_net_mgmt_set_reconnect_time(WIFI_RECONN_TS);      // 记录重连服务器开始时间

    //if (NETWORK_UNINIT == vesync_net_client_get_status())
    {
        char *p_cid = vesync_device_get_cid();
        char *p_server = (char *)vesync_net_mgmt_get_server_domain();
        char *p_ip = (char *)vesync_net_mgmt_get_server_ip();
        uint32_t *p_port = vesync_net_mgmt_get_server_port();

        if (NULL != p_server && NULL != p_cid)
        {
            if ((strlen(p_cid) > 0 ) && (strlen(p_server) > 0))
            {
                vesync_net_client_connect(p_server, p_ip, "0", p_port, vesync_net_client_get_tls_option());
            }
        }
    }

    return VERR_OK;
}

/**
 * @brief       服务器断开连接事件处理
 * @param[in]   p_msg               [未使用]
 * @return      int                 [成功/失败]
 */
static int network_disconnected_event_handle_cb(void *p_msg)
{
    UNUSED(p_msg);

    if (vesync_net_mgmt_set_reconnect_time(NETWORK_DISCONN_TS))
    {
        if (!(s_network_mgmt.serv_timeout_flag))
        {
            if (VHAL_WIFI_GOT_IP == vesync_wifi_get_link_status())
            {
                vesync_wifi_led_set_behavior(WIFI_LED_SERVER_TIMEOUT);     // wifi连接成功，服务器断开超过10min
            }

            s_network_mgmt.serv_timeout_flag = true;
        }
    }
    else
    {
        if (VHAL_WIFI_GOT_IP == vesync_wifi_get_link_status())
        {
            vesync_wifi_led_set_behavior(WIFI_LED_SERVER_DISC);            // wifi连接成功，服务器断开
        }

    }
#if CONFIG_VESYNC_SDK_MQTT_ENABLE
    if (!(s_network_mgmt.reset_net_cfg))
    {
        char *p_cid = vesync_device_get_cid();
        char *p_server = (char *)vesync_net_mgmt_get_server_domain();
        char *p_ip = (char *)vesync_net_mgmt_get_server_ip();
        uint32_t *p_port = vesync_net_mgmt_get_server_port();
        if (NULL != p_server && NULL != p_cid)
        {
            vesync_net_client_connect(p_server, p_ip, "0", p_port, TLS_CA_SERVER);
            s_network_mgmt.reset_net_cfg = true;
        }
    }
    if (!(s_network_mgmt.net_disc_flag))
    {
        s_network_mgmt.old_ts = vhal_utils_get_system_time_sec();
        s_network_mgmt.net_disc_flag = true;
    }
    else
#endif
    {
        s_network_mgmt.new_ts = vhal_utils_get_system_time_sec();
        if (s_network_mgmt.new_ts - s_network_mgmt.old_ts >= 600)  // 超过10min，说明中间有同步时间，重新开始计时2min
        {
            s_network_mgmt.old_ts = s_network_mgmt.new_ts;
        }
        else if (s_network_mgmt.new_ts - s_network_mgmt.old_ts >= 120) // 超过120s未连上服务器，重连Wi-Fi
        {
            vesync_wifi_client_reconnect();
            s_network_mgmt.old_ts = s_network_mgmt.new_ts;
        }
    }

    return VERR_OK;
}

/**
 * @brief       定时器回调处理函数
 * @param[in]   arg               [未使用]
 */
static void vesync_report_check_time_sync_cb(void *arg)
{
    UNUSED(arg);

    if (vhal_utils_get_system_time_sec() <= VCOM_SYSTEM_MIN_TS)
    {
        return;
    }

    vesync_timer_free(s_dev_info_report_timer);
    s_dev_info_report_timer = NULL;
    vesync_report_update_dev_info();
}

/**
 * @brief       服务器连接成功事件处理
 * @param[in]   p_msg               [未使用]
 * @return      int                 [成功/失败]
 */
static int network_connected_event_handle_cb(void *p_msg)
{
    vesync_net_mgmt_set_reconnect_time(NETWORK_RECONN_TS);
    vesync_wifi_led_set_behavior(WIFI_LED_LOGIN_SUCCESS); // 先修改灯效，应用层有可能还会有关闭指示灯的操作

    // 网络连接成功，上报并更新设备信息
    if (vhal_utils_get_system_time_sec() <= VCOM_SYSTEM_MIN_TS)
    {
        if (s_dev_info_report_timer == NULL)
        {
            s_dev_info_report_timer = vesync_timer_new("report_timer",
                                                       vesync_report_check_time_sync_cb,
                                                       NULL,
                                                       500,
                                                       true);
            if (s_dev_info_report_timer == NULL)
            {
                SDK_LOG(LOG_ERROR, "Create report timer fail!!!\n");
            }
            else
            {
                if (VOS_OK != vesync_timer_start(s_dev_info_report_timer))
                {
                    vesync_timer_free(s_dev_info_report_timer);
                    s_dev_info_report_timer = NULL;
                    SDK_LOG(LOG_ERROR, "Start report timer fail!!!\n");
                }
            }
        }
    }
    else
    {
        vesync_report_update_dev_info();
    }

    // 回调通知应用层网络连接成功
    if (NULL != s_network_connected_app_cb)
    {
        s_network_connected_app_cb();
    }

    // 清除标志位
    s_network_mgmt.wifi_timeout_flag = false;
    s_network_mgmt.serv_timeout_flag = false;
#if CONFIG_VESYNC_SDK_MQTT_ENABLE
    s_network_mgmt.net_disc_flag = false;
#endif
    s_network_mgmt.old_ts = 0;
    s_network_mgmt.new_ts = 0;

    return VERR_OK;
}


/**
 * @brief       网络服务事件管理初始化
 * @return      int                 [成功/失败]
 * @note        使能所有的事件处理
 */
int vesync_net_event_init(void)
{
    // 以下两个订阅一直存在不可取消
    if (VERR_OK != vesync_event_subscribe(EVENT_NWK_RESET, SUB_ID_NET_SERVICE, network_reset_netcfg_event_handle_cb))
    {
        return VERR_FAIL;
    }
    if (VERR_OK != vesync_event_subscribe(EVENT_NETCFG_SUCCEED, SUB_ID_NET_SERVICE, network_netcfg_succeed_event_handle_cb))
    {
        vesync_event_unsubscribe(EVENT_NWK_RESET, SUB_ID_NET_SERVICE);
        return VERR_FAIL;
    }

    // 如果以下函数的批量订阅失败，不必取消上述订阅
    return vesync_net_event_mgmt_enable();
}

/**
 * @brief  事件通知接口
 * @param[in]  ev_id                [事件ID]
 * @param[in]  p_msg                [消息数据指针]
 */
void vesync_net_event_notify(EVENT_ID_E ev_id, void *p_msg)
{
    vesync_ev_t event;
    VESYNC_POPULATE_EV(event, ev_id, NET_SERVICE_EVENT_PUBLISH_STR, ((p_msg) == NULL) ? 0 : strlen(p_msg), p_msg);
    vesync_event_publish(&event);
}

/**
 * @brief       网络服务事件管理使能
 * @return      int                 [成功/失败]
 * @note        网络服务对网络事件自动处理
 * @note        网络服务初始化后自动完成，不必再调用
 */
int vesync_net_event_mgmt_enable(void)
{
    if (VERR_OK != vesync_event_subscribe(EVENT_WIFI_DISCONNECTED, SUB_ID_NET_SERVICE, wifi_disconnected_event_handle_cb))
    {
        goto exit_fail;
    }
    if (VERR_OK != vesync_event_subscribe(EVENT_ROUTER_GOT_IP, SUB_ID_NET_SERVICE, wifi_got_ip_event_handle_cb))
    {
        goto exit_fail;
    }
    if (VERR_OK != vesync_event_subscribe(EVENT_NWK_DISCONNECTED, SUB_ID_NET_SERVICE, network_disconnected_event_handle_cb))
    {
        goto exit_fail;
    }
    if (VERR_OK != vesync_event_subscribe(EVENT_NWK_CONNECTED, SUB_ID_NET_SERVICE, network_connected_event_handle_cb))
    {
        goto exit_fail;
    }
    return VERR_OK;

exit_fail:
    vesync_net_event_mgmt_disable();
    return VERR_FAIL;
}

/**
 * @brief       网络服务事件管理禁用
 * @note        配网或产测时，自定义网络事件处理，需要关闭网络服务对事件的自动处理
 */
void vesync_net_event_mgmt_disable(void)
{
    NET_LOG(LOG_DEBUG, "--------vesync_net_event_mgmt_disable---------\n");
    vesync_event_unsubscribe(EVENT_WIFI_DISCONNECTED, SUB_ID_NET_SERVICE);
    vesync_event_unsubscribe(EVENT_ROUTER_GOT_IP, SUB_ID_NET_SERVICE);
    vesync_event_unsubscribe(EVENT_NWK_DISCONNECTED, SUB_ID_NET_SERVICE);
    vesync_event_unsubscribe(EVENT_NWK_CONNECTED, SUB_ID_NET_SERVICE);
}


/**
 * @brief 向网络服务事件注册网络连接成功事件回调
 * @note  提供给应用层的接口
 * @param nwk_con_cb
 * @return int
 */
int vesync_net_event_reg_nwk_conn_cb(void (*nwk_con_cb)(void))
{
    s_network_connected_app_cb = nwk_con_cb;

    return VERR_OK;
}


/**
 * @brief 向网络服务事件注销网络连接成功事件回调
 * @note  提供给应用层的接口
 *
 * @return int
 */
int vesync_net_event_unreg_nwk_conn_cb(void)
{
    s_network_connected_app_cb = NULL;

    return VERR_OK;
}
