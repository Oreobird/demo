/*
 * Copyright © Vesync Technologies Co.Ltd. 2019-2021. All rights reserved.
 * @file    vesync_http_private.h
 * @brief   http私有头文件
 * @author  CharlesMei
 * @date    2021-05-21
 */

#ifndef __VESYNC_HTTP_PRIVATE_H__
#define __VESYNC_HTTP_PRIVATE_H__


#include "vesync_http_internal.h"


#ifdef __cplusplus
extern "C"
{
#endif /* __cplusplus */


/* The following is the redirection of the interface called by this module */

#ifndef VERR_OK
#include "vesync_common.h"
#define VERR_OK SDK_OK
#define VERR_FAIL SDK_FAIL
#endif /* VERR_OK */

#ifndef HTTP_LOG
#include "vesync_log_internal.h"
#ifdef SDK_LOG
#define HTTP_LOG SDK_LOG
#else
#define HTTP_LOG(level, format, ...)
#endif /* SDK_LOG */
#endif /* HTTP_LOG */

#ifndef HTTP_UTIL_MEM_CHECK
#include "vesync_common.h"
#ifdef VCOM_NULL_PARAM_CHK
#define HTTP_UTIL_MEM_CHECK VCOM_NULL_PARAM_CHK
#else
#define HTTP_UTIL_MEM_CHECK(param, action)  \
    do {                                    \
        if (NULL == (param))                \
        {                                   \
            action;                         \
        }                                   \
    } while (0)
#endif /* VCOM_NULL_PARAM_CHK */
#endif /* HTTP_UTIL_MEM_CHECK */

#ifndef HTTP_UTIL_SAFE_FREE
#ifdef VCOM_SAFE_FREE
#define HTTP_UTIL_SAFE_FREE VCOM_SAFE_FREE
#else
#define HTTP_UTIL_SAFE_FREE(ptr)            \
    do{                                     \
        if (NULL != ptr)                    \
        {                                   \
            free(ptr);                      \
            ptr = NULL;                     \
        }                                   \
    } while(0)
#endif /* VCOM_SAFE_FREE */
#endif /* HTTP_UTIL_SAFE_FREE */


#define VERR_UPLOAD(x, y)

/* The above is the redirection of the interface called by this module */


#define HTTP_DEFAULT_PORT           (80)       // http默认端口
#define HTTP_BUFFER_SIZE            (2 * 1024)    // https通信的数据交互缓存区大小
#define HTTP_HOST_LEN               (128)
#define HTTP_PATH_LEN               (256)

#define HTTP_WAIT_TIME_MS           (3000)

#ifdef __cplusplus
}
#endif /* __cplusplus */


#endif /* __VESYNC_HTTP_PRIVATE_H__ */

