/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        bulb_bypass.h
 * @brief       灯泡的bypass应用回调
 * @author      Dave
 * @date        2021-09-02
 */

#ifndef __BULB_BYPASS_H__
#define __BULB_BYPASS_H__

#ifdef __cplusplus
extern "C" {
#endif

#define BULB_SUBDEVICE_TYPE_STR      "bulb"
#define BULB_SUBDEVICE_NO           (0)
#define BRIGHT_MAX                  100
#define COLOR_TEMP_MAX              100
#define HSV_PARAM_MAX               10000
#define PARAM_MIN                    0
#define SUN_EVT_TIME_MAX                 3600
#define SUN_EVT_TIME_MIN                 -3600


/**
* @brief setLightStatusV2接口数据解析结构
*/

typedef struct
{
    uint8_t force;         // 相应等级，1时强制响应
    char colorMdoe[8];     // 灯泡模式储存
    uint8_t colorTemp;     // 色温参数
    uint8_t brightness;    // 亮度参数  hsv与white模式共用亮度参数标识
    uint16_t hue;          // 色相参数
    uint16_t saturation;   // 饱和度参数
} bypass_bulb_base_t;

/**
* @brief adjustpercent接口数据解析结构
*/
typedef struct
{
    char type[11];
    int8_t step;
} bypass_adjustpercent_t;


/**
* @brief 注册bypass回调函数
*/
void bulb_bypass_reg_cb(void);

/**
 * @brief  获取状态改变标识
 * @return       bulb_status_t   [状态改变结构体指针]
 */
bulb_status_t* bulb_get_report_status_change();

/**
 * @brief  三方语音设置标识位设置
 * @param[in]       flag   [标识位]
 */
void bulb_set_could_zero_flag(bool flag);


#ifdef __cplusplus
}
#endif

#endif

