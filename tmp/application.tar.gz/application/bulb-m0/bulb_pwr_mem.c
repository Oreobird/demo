/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file        bulb_pwr_mem.c
* @brief       Bulb断电记忆接口定义
* @author      Herve
* @date        2022-01-21
*/
#include "bulb_pwr_mem.h"
#include "bulb_flash.h"

#include "vhal_flash.h"

#include "vesync_log.h"
#include "vesync_common.h"

#define BULB_PWR_MEM_VER_CFG_KEY "bulb_pom_ver"
#define BULB_PWR_MEM_MODE_CFG_KEY "bulb_pom_mode"
#define BULB_PWR_MEM_ACT_CFG_KEY "bulb_pom_act"

#define BULB_PWR_MEM_CFG_VERSION (1)

static uint8_t s_mode;
static bulb_action_t s_act;

int bulb_pwr_mem_init(void)
{
    s_mode = BULB_CFG_POWEROFF_MEMORY_MODE_1;

    uint32_t rd_len;
    uint8_t version;
    int ret = vhal_flash_read(PARTITION_CFG, BULB_PWR_MEM_VER_CFG_KEY, &version, &rd_len);
    if (VHAL_OK != ret || rd_len != sizeof(version))
    {
        APP_LOG(LOG_WARN, "no config:%d\n", rd_len);
        version = BULB_PWR_MEM_CFG_VERSION;
        ret = vhal_flash_write(PARTITION_CFG, BULB_PWR_MEM_VER_CFG_KEY, &version, sizeof(version));
        if (VHAL_OK != ret)
        {
            APP_LOG(LOG_ERROR, "write cfg fail\n");
        }
        return APP_FAIL;
    }

    ret = vhal_flash_read(PARTITION_CFG, BULB_PWR_MEM_MODE_CFG_KEY, &s_mode, &rd_len);
    if (VHAL_OK != ret || rd_len != sizeof(s_mode))
    {
        return APP_FAIL;
    }
    ret = vhal_flash_read(PARTITION_CFG, BULB_PWR_MEM_ACT_CFG_KEY, (uint8_t *)&s_act, &rd_len);
    if (VHAL_OK != ret || rd_len != sizeof(s_act))
    {
        return APP_FAIL;
    }
    return APP_OK;
}

int bulb_pwr_mem_get(uint8_t *p_mode, bulb_action_t *p_act)
{
    if (NULL == p_mode || NULL == p_act)
    {
        return APP_FAIL;
    }
    memcpy(p_mode, &s_mode, sizeof(s_mode));
    memcpy(p_act, &s_act, sizeof(s_act));
    return APP_OK;
}

int bulb_pwr_mem_set(uint8_t *p_mode, bulb_action_t *p_act)
{
    if (NULL == p_mode || NULL == p_act)
    {
        return APP_FAIL;
    }
    memcpy(&s_mode, p_mode, sizeof(s_mode));
    memcpy(&s_act, p_act, sizeof(s_act));

    int ret = vhal_flash_write(PARTITION_CFG, BULB_PWR_MEM_MODE_CFG_KEY, &s_mode, sizeof(s_mode));
    if (VHAL_OK != ret)
    {
        goto WR_FAIL;
    }
    ret = vhal_flash_write(PARTITION_CFG, BULB_PWR_MEM_ACT_CFG_KEY, (uint8_t *)&s_act, sizeof(s_act));
    if (VHAL_OK != ret)
    {
        goto WR_FAIL;
    }
    return APP_OK;
WR_FAIL:
    APP_LOG(LOG_ERROR, "write cfg fail\n");
    return APP_FAIL;
}

int bulb_pwr_mem_clear(void)
{
    s_mode = BULB_CFG_POWEROFF_MEMORY_MODE_1;

    return bulb_pwr_mem_set(&s_mode, &s_act);
}