/**
 * Copyright © Vesync Technologies Co.Ltd. 2019-2021. All rights reserved
 * @file    airgrill_uart_msg_queue.c
 * @brief   串口消息队列处理
 * @author  zhenlang
 * @date    2020-02-17
 */

#include <time.h>
#include <string.h>
#include <stdlib.h>

#include "vesync_common.h"
#include "vesync_log_internal.h"

#include "vesync_os.h"
#include "vesync_queue.h"
#include "vesync_task.h"

#include "vesync_uart.h"
#include "vesync_uart_internal.h"
#include "vesync_uart_msg_queue.h"


static vesync_queue_t s_data_queue;             // 数据队列
static vesync_queue_t s_ack_queue;              // ack队列
static uart_msg_queue_t s_send_buf;             // 发送缓存，用于接收ACK处理

#if ((defined (UART_QUEUE_USE_TIMER)) && (UART_QUEUE_USE_TIMER == 1))
static vesync_timer_t s_uart_queue_timer;       // 定时器句柄
#endif



/*-----------------------------------------------------------------------------*
 *                           内部函数API实现                                         *
 *-----------------------------------------------------------------------------*/

/*
 * @brief 将队列中的消息发送
 *
 */
static void vesync_uart_msg_transfer(void)
{
    uart_msg_queue_t msg;

    if (VOS_OK == vesync_queue_recv(&s_ack_queue, &msg, 0))
    {
        if (UART_MSG_TYPE_ACK == msg.type)
        {
            vesync_uart_send_ack_with_seq_id(msg.seq_id, msg.err_flag, msg.uart_num,
                                             msg.opcode, msg.status_code , msg.p_data, msg.data_len);
            vesync_sleep(UART_MSG_SEND_INTERVAL);    // 发完之后进行延时，确保与下面发命令串口有间隔时间
        }

        VCOM_SAFE_FREE(msg.p_data);
        VCOM_SAFE_FREE(msg.p_app_data);
        VCOM_SAFE_FREE(msg.p_trace_msg);
    }

    if (false == vesync_uart_check_send_busy())  //命令发送必须检查是否忙
    {
        if (VOS_OK == vesync_queue_recv(&s_data_queue, &msg, 0))
        {
            if (UART_MSG_TYPE_CMD == msg.type)
            {
                if (0 == vesycn_uart_send_data(1, msg.uart_num, msg.opcode, msg.p_data, msg.data_len))
                {
                    memset(&s_send_buf, 0, sizeof(uart_msg_queue_t));
                    memcpy(&s_send_buf, &msg, sizeof(uart_msg_queue_t));    // 备份
                }
                else
                {
                    VCOM_SAFE_FREE(msg.p_data);
                    VCOM_SAFE_FREE(msg.p_app_data);
                    VCOM_SAFE_FREE(msg.p_trace_msg);
                }
            }
            else
            {
                VCOM_SAFE_FREE(msg.p_data);
                VCOM_SAFE_FREE(msg.p_app_data);
                VCOM_SAFE_FREE(msg.p_trace_msg);
            }
        }
    }
}

#if defined (UART_QUEUE_USE_TIMER) && (UART_QUEUE_USE_TIMER == 1)
/**
 * @brief 消息队列定时器回调
 *
 */
static void vesync_uart_msg_queue_tmr_cb(void *args)
{
    vesync_uart_msg_transfer();
}

#else
/**
 * @brief 消息队列任务
 *
 */
static void vesync_uart_msg_queue_task(void *args)
{
    while(1)
    {
        vesync_uart_msg_transfer();
        vesync_sleep(UART_MSG_SEND_INTERVAL);
    }
}
#endif



/*-----------------------------------------------------------------------------*
 *                           外部函数API实现                                         *
 *-----------------------------------------------------------------------------*/

/**
 * @brief 消息队列功能初始化
 */
void vesync_uart_msg_queue_init(void)
{
    memset(&s_send_buf, 0, sizeof(uart_msg_queue_t));

    // 创建数据发送队列
    if (VOS_OK != vesync_queue_new(&s_data_queue, UART_DATA_MSG_QUEUE_MAX_NUM*sizeof(uart_msg_queue_t), sizeof(uart_msg_queue_t)))
    {
        SDK_LOG(LOG_ERROR, "Create queue fail\n");
    }

    // 创建ack发送队列
    if (VOS_OK != vesync_queue_new(&s_data_queue, UART_ACK_MSG_QUEUE_MAX_NUM*sizeof(uart_msg_queue_t), sizeof(uart_msg_queue_t)))
    {
        SDK_LOG(LOG_ERROR, "Create queue fail\n");
    }

#if defined (UART_QUEUE_USE_TIMER) && (UART_QUEUE_USE_TIMER == 1)
    if (VOS_OK != vesync_timer_new(&s_uart_queue_timer, "uart_send", vesync_uart_msg_queue_tmr_cb, NULL, UART_MSG_SEND_INTERVAL, true))
    {
        SDK_LOG(LOG_ERROR, "Create timer fail!\n");
    }
    else
    {
        if (VOS_OK != vesync_timer_start(&s_uart_queue_timer))
        {
            SDK_LOG(LOG_ERROR, "Start timer fail!\n");
        }
    }
#else
    // 串口消息队列处理函数
    if (VOS_OK != vesync_task_new("uart_queue", vesync_uart_msg_queue_task, NULL, 2048, 3, NULL))
    {
        SDK_LOG(LOG_ERROR, "Create task fail!\n");
        return;
    }
#endif
}

/**
 * @brief  将数据消息或者ACK应答数据放入队列
 * @param[in]  p_msg                [消息指针]
 * @return     int                  [0表示成功，其他值表示失败]
 */
int32_t vesync_uart_msg_queue_put(uart_msg_queue_t *p_msg)
{
    int32_t ret = SDK_FAIL;

    if (NULL == p_msg)
    {
        return ret;
    }

    if (UART_MSG_TYPE_CMD == p_msg->type)
    {
        ret = vesync_queue_send(&s_data_queue, p_msg, 0);
    }
    else if (UART_MSG_TYPE_ACK == p_msg->type)
    {
        ret = vesync_queue_send(&s_ack_queue, p_msg, 0);
    }
    else
    {
        SDK_LOG(LOG_ERROR, "Unknown type(%d)\n", p_msg->type);
        return ret;
    }

    if (VOS_OK != ret)
    {
        SDK_LOG(LOG_ERROR, "Failed to put item\n");
        return SDK_FAIL;
    }

    return SDK_OK;
}

/**
 * @brief  串口消息发送回调处理函数
 * @param[in]  event                [串口数据发送成功/失败事件]
 * @param[in]  frame                [接收到的指针]
 * @return     void
 */
void vesync_uart_msg_tx_event(UART_SEND_TYPE_E event, tl_frame_recv_info_t *frame)
{
    uart_msg_queue_t *p_msg = &s_send_buf;

    // 发送失败，或者应答包错误，不处理
    if (UART_SEND_FAIL == event)
    {
        SDK_LOG(LOG_ERROR, "uart msg tx fail\n");

        if (UART_MSG_SRC_NONE != p_msg->src)
        {
            if (UART_MSG_SRC_BYPASS == p_msg->src)
            {
                //vesync_bypass_reply_noqos(BP_ERR_CMD_EXECUTE_FAIL, p_msg->p_trace_msg, NULL);
            }

            p_msg->src = UART_MSG_SRC_NONE;
        }

        vesync_uart_rsp_process(UART_SEND_FAIL, NULL, 0, p_msg);    // 回调应用层处理
    }
    else if (UART_SEND_SUCCESS == event)
    {
        if (NULL != frame)
        {
            vesync_uart_rsp_process(UART_SEND_SUCCESS, (tl_payload_info_t *)frame->p_payload, frame->payload_len, p_msg);    // 回调应用层处理
        }
        else
        {
            vesync_uart_rsp_process(UART_SEND_SUCCESS, NULL, 0, p_msg);    // 回调应用层处理
        }

        if (UART_MSG_SRC_NONE != p_msg->src)
        {
            if (UART_MSG_SRC_BYPASS == p_msg->src)
            {
                //vesync_bypass_reply_noqos(ret, p_msg->p_trace_msg, NULL);
            }

            p_msg->src = UART_MSG_SRC_NONE;
        }
    }

    VCOM_SAFE_FREE(p_msg->p_data);
    VCOM_SAFE_FREE(p_msg->p_app_data);
    VCOM_SAFE_FREE(p_msg->p_trace_msg);
}



