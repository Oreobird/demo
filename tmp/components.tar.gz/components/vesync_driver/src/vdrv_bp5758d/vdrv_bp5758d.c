/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
 * @file        vdrv_bp5758d.c
 * @brief       bp5758d驱动接口
 * @author      Joshua
 * @date        2021-09-10
 */

#include <stdio.h>
#include <string.h>
#include <stddef.h>

#include "vesync_common.h"
#include "vesync_log_internal.h"
#include "vhal_i2c.h"
#include "vdrv_bp5758d_internal.h"

static uint8_t s_i2c_addr = BP5758D_NORMAL_MODE;              // BP5758D 模式与寻址设置byte[0]
static uint8_t s_i2c_data[BP5758D_MAX_OUT_DATA_LEN] = {0};    // BP5758D 输出使能设置byte[1]，数据byte[2 ~ 16]

/**
 * @brief 地址选择
 */
static void vdrv_bp5758d_addr_cfg(void)
{
    s_i2c_addr = BP5758D_NORMAL_MODE;    // 选择byte[1]
}

/**
 * @brief 输出使能配置
 * @param[in]  outs[]           [输出索引，支持OUT1~OUT5]
 * @param[in]  out_num          [输出个数，最大为5路]
 * @return int                  [成功:SDK_OK，失败：SDK_FAIL]
 */
static int vdrv_bp5758d_out_enable_cfg(uint8_t outs[], uint8_t out_num)
{
    if (out_num > BP5758D_MAX_OUT_NUM)
    {
        SDK_LOG(LOG_ERROR, "param error\n");
        return SDK_FAIL;
    }

    for (uint8_t i = 0; i < out_num; i++)
    {
        if (outs[i] > BP5758D_MAX_OUT_NUM)
        {
            SDK_LOG(LOG_ERROR, "param error\n");
            return SDK_FAIL;
        }

        s_i2c_data[0] |= (1 << (outs[i] - 1));
    }

    return SDK_OK;
}

int vdrv_bp5758d_init(uint8_t sda_io, uint8_t scl_io)
{
    int ret = vhal_i2c_master_init(BP5758D_IIC_PORT, sda_io, scl_io, 100000);
    if (ret != VHAL_OK)
    {
        SDK_LOG(LOG_ERROR, "bp5758d iic init fail\n");
        return SDK_FAIL;
    }

    SDK_LOG(LOG_INFO, "bp5758d iic init success\n");
    return SDK_OK;
}

int vdrv_bp5758d_out_disable(void)
{
    uint8_t data[1] = {0x00};
    int ret = vhal_i2c_master_write(BP5758D_IIC_PORT, true, BP5758D_NORMAL_MODE, data, 1);
    if (ret != VHAL_OK)
    {
        return SDK_FAIL;
    }

    return SDK_OK;
}

int vdrv_bp5758d_sleep_mode_set(void)
{
    int ret = vdrv_bp5758d_out_disable();
    if (ret != SDK_OK)
    {
#if BP5758D_DEBUG_PRINT == 1
        SDK_LOG(LOG_ERROR, "out disable error\n");
#endif /* BP5758D_DEBUG_PRINT */
        return SDK_FAIL;
    }

    ret = vhal_i2c_master_write(BP5758D_IIC_PORT, true, BP5758D_SLEEP_MODE, NULL, 0);
    if (ret != VHAL_OK)
    {
#if BP5758D_DEBUG_PRINT == 1
        SDK_LOG(LOG_ERROR, "set sleep mode error\n");
#endif /* BP5758D_DEBUG_PRINT */
        return SDK_FAIL;
    }

    return SDK_OK;
}

int vdrv_bp5758d_range_cfg(bp5758d_range_t *p_range)
{
    if (p_range == NULL || p_range->out_num == 0)
    {
        SDK_LOG(LOG_ERROR, "range cfg fail\n");
        return SDK_FAIL;
    }

    vdrv_bp5758d_addr_cfg();

    uint32_t ret = vdrv_bp5758d_out_enable_cfg(p_range->outs, p_range->out_num);
    if (ret != SDK_OK)
    {
        return SDK_FAIL;
    }

    for (uint8_t i = 0; i < p_range->out_num; i++)
    {
        uint8_t range_idx = p_range->outs[i] - 1 + BP5758D_RANGE_START_BYTE_IDX;
        s_i2c_data[range_idx] = p_range->data[i];
    }

    return SDK_OK;
}

int vdrv_bp5758d_gray_cfg(bp5758d_gray_t *p_gray)
{
    if (p_gray == NULL || p_gray->out_num == 0)
    {
        SDK_LOG(LOG_ERROR, "gray cfg fail\n");
        return SDK_FAIL;
    }

    vdrv_bp5758d_addr_cfg();

    uint32_t ret = vdrv_bp5758d_out_enable_cfg(p_gray->outs, p_gray->out_num);
    if (ret != SDK_OK)
    {
        return SDK_FAIL;
    }

    for (uint8_t i = 0; i < p_gray->out_num; i++)
    {
        uint8_t gray_idx = ((p_gray->outs[i] - 1) << 1) + BP5758D_GRAY_START_BYTE_IDX;

        s_i2c_data[gray_idx++] = (p_gray->data[i] & 0x1fu);
        s_i2c_data[gray_idx] = (p_gray->data[i] >> 5);
    }

    return SDK_OK;
}

int vdrv_bp5758d_cfg_write(void)
{
#if BP5758D_DEBUG_PRINT == 1
    LOG_RAW_HEX(LOG_DEBUG, "BP5758D cfg write bytes:", s_i2c_data, BP5758D_MAX_OUT_DATA_LEN);
#endif /* BP5758D_DEBUG_PRINT */

    int ret = vhal_i2c_master_write(BP5758D_IIC_PORT, true, s_i2c_addr, s_i2c_data, BP5758D_MAX_OUT_DATA_LEN);
    if (ret != VHAL_OK)
    {
#if BP5758D_DEBUG_PRINT == 1
        SDK_LOG(LOG_ERROR, "set cfg fail\n");
#endif /* BP5758D_DEBUG_PRINT */
    }

    s_i2c_addr = BP5758D_NORMAL_MODE;
    memset(s_i2c_data, 0, sizeof(s_i2c_data));

    return ret;
}


