/**
*Copyright © Vesync Technologies Co.Ltd. 2022. All rights reserved.
* @file    led_strip_production.c
* @brief   产测功能
* @author  Lind
*@date     2022-01-05
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "vesync_common.h"
#include "vesync_log.h"
#include "vesync_device.h"
#include "vesync_production.h"

#include "led_strip.h"
#include "led_strip_button.h"
#include "led_strip_production.h"

/**
* @brief 产测状态回调函数
* @param[in]  status          [产测状态码]
*/
static void ls_production_status_cb(PRODUCTION_STATUS_E status)
{
    ls_ev_t ev;
    ev.id = LS_EV_TURN_ON;
    ev.act_src = LS_ACT_SRC_PRD;

    switch(status)
    {
        case PRODUCTION_START:
            ls_button_deinit();
            ev.scene_id = 30;
            break;
        case PRODUCTION_RUNNING:
            ev.scene_id = 31;
            break;
        case PRODUCTION_TEST_PASS:
            APP_LOG(LOG_INFO, "production pass\n");
            ev.scene_id = 32;
            break;
        case PRODUCTION_TEST_FAIL:
            APP_LOG(LOG_INFO, "production fail\n");
            ev.scene_id = 33;
            break;
        default:
            break;
    }

    if (status < PRODUCTION_EXIT)
    {
        ls_app_task_notify(&ev);
    }
}

/**
* @brief 产测结果回调函数
* @param[in]  err_code          [产测状态码]
*/
static void ls_production_result_cb(PRODUCTION_ERROR_E err_code)
{
    if (PRD_NO_ERR == err_code)
    {
        APP_LOG(LOG_INFO, "production success\n");
    }
    else
    {
        APP_LOG(LOG_INFO, "production error %d\n", err_code);
    }
}

/**
* @brief 产测功能初始化
*/
void ls_production_init(void)
{
    vesync_production_reg_status_cb(ls_production_status_cb);
    vesync_production_reg_result_cb(ls_production_result_cb);
}

