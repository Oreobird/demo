/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
* @file         netcfg_light.c
* @brief        产测灯效控制
* @author       Joshua
* @date         2021-11-20
*/

#include <string.h>
#include <stdint.h>
#include "vesync_common.h"
#include "vesync_memory.h"
#include "vesync_log.h"
#include "netcfg_light.h"

int netcfg_light_scene_reg(netcfg_light_scene_t *light_scene)
{
    VCOM_NULL_PARAM_CHK(light_scene, return APP_FAIL);

    scene_t *thiz = (scene_t *) vesync_malloc(sizeof(scene_t) + sizeof(netcfg_light_scene_t));
    if (thiz == NULL)
    {
        APP_LOG(LOG_ERROR, "production light scenee reg fail\n");
        return APP_FAIL;
    }

    memset(thiz, 0, sizeof(scene_t) + sizeof(netcfg_light_scene_t));

    netcfg_light_scene_t *ctx = (netcfg_light_scene_t *)thiz->ctx;

    ctx->netcfg_waiting_light = light_scene->netcfg_waiting_light;
    ctx->netcfg_process_light = light_scene->netcfg_process_light;
    ctx->netcfg_success_light = light_scene->netcfg_success_light;
    ctx->netcfg_fail_light = light_scene->netcfg_fail_light;

    thiz->type = SCENE_NETCFG;
    thiz->id = 0;

    scene_registry_add(thiz);

    return APP_OK;
}

int netcfg_light_scene_unreg(void)
{
    return scene_registry_del(SCENE_NETCFG, 0);
}



