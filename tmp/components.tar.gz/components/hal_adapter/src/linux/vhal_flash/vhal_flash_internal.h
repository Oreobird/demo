/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vhal_flash.c
 * @brief       linux mock flash读写接口封装
 * @author      Joshua
 * @date        2021-08-10
 */

#ifndef __VHAL_FLASH_INTERNAL__H__
#define __VHAL_FLASH_INTERNAL__H__

#ifdef __cplusplus
extern "C"
{
#endif

#define VHAL_LINUX_DEFAULT_NVS_NAMESPACE          "nvs"               // NVS默认分区
#define VHAL_LINUX_FAC_DATA_NAMESPACE             "fac_data"          // fac_data分区名
#define VHAL_LINUX_USER_CFG_NAMESPACE             "usercfg"           // usercfg分区名
#define VHAL_LINUX_LOG_NAMESPACE                  "log"               // log分区名
#define VHAL_LINUX_DATA_CFG_NAMESPACE             "historydata"       // 历史数据分区


#ifdef __cplusplus
}
#endif

#endif /* __VHAL_FLASH_INTERNAL__H__ */
