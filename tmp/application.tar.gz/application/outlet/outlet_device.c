/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        outlet_device.c
 * @brief       outlet device文件
 * @author      CharlesMei
 * @date        2021-06-25
 */
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include "vhal_gpio.h"

#include "vesync_common.h"
#include "vesync_log.h"
#include "vesync_timer.h"
#include "vesync_wifi_led.h"
#include "outlet_report.h"
#include "outlet.h"
#include "outlet_device.h"
#include "outlet_timing.h"
#include "outlet_inching.h"
#include "outlet_flash.h"
#include "outlet_schedule.h"
#include "outlet_away.h"
#include "outlet_board.h"
#if defined(OUTLET_ELEC_METERING) && (OUTLET_ELEC_METERING == 1)
#include "outlet_save_elec.h"
#endif

#define OUTLET_PRE_RESET_TIMER_NAME     "pre_reset_timer"
#define OUTLET_PRE_RESET_TIMER_PERIOD   (125)


static vesync_timer_t *s_pre_reset_timer = NULL;    // reset前灯效处理定时器

/**
 * @brief 停止定时器
 * @note  reset前灯效处理定时器的回调函数
 */
static void pre_reset_timer_callback(void *args)
{
    // 上电后此定时器只能启用一次
    static uint16_t run_time = 20;
    static uint8_t indicator_gpio_level = VHAL_GPIO_DATA_HIGH;

    if (0 == run_time)
    {
        // 一般情况下，运行到此之前，设备已经重启
        if (s_pre_reset_timer)
        {
            // 此处只为展示灯效
            vesync_wifi_led_set_behavior(WIFI_LED_NOT_CONFIG);
            vesync_timer_free(s_pre_reset_timer);
        }
        return;
    }
    vhal_gpio_set_output(OUTLET_INDICATOR_GPIO_NUM, indicator_gpio_level);

    --run_time;
    if (VHAL_GPIO_DATA_HIGH == indicator_gpio_level)
    {
        indicator_gpio_level = VHAL_GPIO_DATA_LOW;
    }
    else
    {
        indicator_gpio_level = VHAL_GPIO_DATA_HIGH;
    }
}

/**
 * @brief 恢复出厂重启前其它事务处理函数
 */
void outlet_device_pre_reset_callback(void *args)
{
    outlet_ev_t ev;
    memset(&ev, 0, sizeof(ev));
    ev.act_src = OUTLET_ACT_SRC_RESET;
    ev.id = OUTLET_EV_OFF;
    snprintf(ev.rsn, sizeof(ev.rsn), "%s", STAT_CHG_RSN_NONE_STR);
    outlet_app_task_notify(&ev);

    s_pre_reset_timer = vesync_timer_new(OUTLET_PRE_RESET_TIMER_NAME, pre_reset_timer_callback, NULL, OUTLET_PRE_RESET_TIMER_PERIOD, true);
    if (NULL == s_pre_reset_timer)
    {
        APP_LOG(LOG_ERROR, "pre_reset_timer create fail!!!/r/n");
        return;
    }
    if (VOS_OK != vesync_timer_start(s_pre_reset_timer))
    {
        APP_LOG(LOG_ERROR, "pre_reset_timer start fail!!!/r/n");
        return;
    }
}

/**
 * @brief 清除开关应用层数据
 * @param[in]  rsn              [消息来源]
 * @param[in]  rst_type         [删除用户数据的类型]
 * @return
 */
void outlet_device_clear_all_data(const char* rsn, DEV_RESET_TYPE_E rst_type)
{
    UNUSED(rst_type);
    VCOM_NULL_PARAM_CHK(rsn, return);
    outlet_set_switch_change_reason(rsn);    // 记录开关状态变化原因

    // 清除timing
    outlet_timing_clear();

    // 清除inching
    outlet_inching_delete_cfg();

    // 清空schedule
    outlet_schedule_clear();

    // 清除away
    outlet_away_clear();

    // 重置开关和指示灯为默认状态
    switch_clear_config();
    switch_load_config(OUTLET_ACT_SRC_RESET);

#if defined(OUTLET_ELEC_METERING) && (OUTLET_ELEC_METERING == 1)
    outlet_clear_history_elec();
#endif
}

