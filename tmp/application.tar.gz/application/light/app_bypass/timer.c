/*
 * Copyright © Vesync Technologies Co.Ltd. 2022. All rights reserved.
 * @file        timer.c
 * @brief       add/get/delTimer处理接口
 * @date        2022-01-24
 */

#include <stdio.h>

#include "vesync_common.h"
#include "vesync_log.h"
#include "vesync_memory.h"
#include "vesync_timing.h"
#include "app_bypass.h"
#include "event.h"
#include "device.h"
#include "scene.h"

#define LIGHT_TIMING_ID (1)

typedef struct
{
    uint8_t onoff;
    uint8_t color_mode;
    light_param_t light_param;
    uint16_t scene_id;
    uint16_t music_id;
} action_cfg_t;

typedef struct
{
    int id;
    int num;
    action_cfg_t act_cfg;
} light_timing_t;

static light_timing_t *s_timing = NULL;

static void light_timing_act(uint16_t id)
{
    dev_cfg_t *p_dev_cfg = app_device_cfg_get();

    if (p_dev_cfg != NULL)
    {
        uint8_t scene_type = SCENE_ONOFF;
        uint16_t scene_id = SCENE_COLOR_OFF;

        if (s_timing->act_cfg.onoff == LIGHT_STATUS_OFF)
        {
            p_dev_cfg->flash->cfg.onoff = LIGHT_STATUS_OFF;
        }
        else
        {
            p_dev_cfg->flash->cfg.onoff = LIGHT_STATUS_ON;
            switch (s_timing->act_cfg.color_mode)
            {
                case LIGHT_MODE_WHITE:
                    p_dev_cfg->flash->cfg.mode = LIGHT_MODE_WHITE;
                    p_dev_cfg->flash->cfg.light_param.brightness = s_timing->act_cfg.light_param.brightness;
                    p_dev_cfg->flash->cfg.light_param.color_temp = s_timing->act_cfg.light_param.color_temp;
                    break;
                case LIGHT_MODE_COLOR:
                    p_dev_cfg->flash->cfg.mode = LIGHT_MODE_COLOR;
                    p_dev_cfg->flash->cfg.light_param.H = s_timing->act_cfg.light_param.H;
                    p_dev_cfg->flash->cfg.light_param.S = s_timing->act_cfg.light_param.S;
                    p_dev_cfg->flash->cfg.light_param.V = s_timing->act_cfg.light_param.V;
                    break;
                case LIGHT_MODE_SCENE:
                    p_dev_cfg->flash->cfg.mode = LIGHT_MODE_SCENE;
                    p_dev_cfg->flash->cfg.scene_id = s_timing->act_cfg.scene_id;
                    break;
                default:
                    break;
            }
        }

        app_scene_info_get_from_mode(&scene_type, &scene_id);
        app_device_cfg_save(p_dev_cfg);
        BYPASS_NOTIFY(scene_type, scene_id);

        vesync_timing_remove(s_timing->id);
        VCOM_SAFE_FREE(s_timing);
        p_dev_cfg->timing_cfg = NULL;
        p_dev_cfg->timing_cfg_len = 0;
    }
}


int request_data_handle_for_add_timer(bp_add_timer_request_t *request_data, int *err_code, char *err_msg, void **extra)
{
    UNUSED(extra);
    dev_cfg_t *p_dev_cfg = app_device_cfg_get();
    if (p_dev_cfg == NULL)
    {
        *err_code = BP_ERR_PARA_ILLEGAL;
        snprintf(err_msg, BP_ERR_MSG_LEN, "device abnormal");
        return APP_FAIL;
    }

    int ret = APP_OK;
    uint16_t timing_id = LIGHT_TIMING_ID;

    int sdk_ret = vesync_timing_add(timing_id, (uint32_t)request_data->total_time);
    if (sdk_ret != SDK_OK)
    {
        ret = APP_FAIL;
        *err_code = BP_ERR_CMD_EXECUTE_FAIL;
        snprintf(err_msg, BP_ERR_MSG_LEN, BP_ERR_PARAM_CONV(id, BP_ERR_PARAM_VAL_INVALID));
        goto EXIT;
    }

    s_timing = (light_timing_t *)vesync_calloc(1, sizeof(light_timing_t));
    if (s_timing == NULL)
    {
        ret = APP_FAIL;
        *err_code = BP_ERR_OUT_OF_MEMORY;
        snprintf(err_msg, BP_ERR_MSG_LEN, "Out of memory");
        vesync_timing_remove(timing_id);
        goto EXIT;
    }

    memset(&(s_timing->act_cfg), BP_NO_VALUE, sizeof(action_cfg_t));
    vesync_timing_reg_cb(light_timing_act);

    s_timing->id = timing_id;

    APP_LOG(LOG_DEBUG, "start_act_num=%d\n", request_data->start_act_num);
    for (int i = 0; i < request_data->start_act_num; i++)
    {
        if (request_data->start_act[i].act_type == BP_START_ACT_ACT_TYPE_SWITCH)
        {
            s_timing->act_cfg.onoff = request_data->start_act[i].act;
        }

        if (request_data->start_act[i].act_type == BP_START_ACT_ACT_TYPE_SWITCH
            && request_data->start_act[i].act == BP_START_ACT_ACT_OFF) // switch off 不处理其它参数
        {
            break;
        }

        if (request_data->start_act[i].act_type == BP_START_ACT_ACT_TYPE_COLORMODE)
        {
            if (request_data->start_act[i].act == BP_START_ACT_ACT_WHITE)
            {
                s_timing->act_cfg.color_mode = LIGHT_MODE_WHITE;
                s_timing->act_cfg.light_param.brightness = request_data->start_act[i].params.brightness;
                s_timing->act_cfg.light_param.color_temp = request_data->start_act[i].params.color_temp;
            }
            else if (request_data->start_act[i].act == BP_START_ACT_ACT_HSV)
            {
                s_timing->act_cfg.color_mode = LIGHT_MODE_COLOR;
                s_timing->act_cfg.light_param.H = request_data->start_act[i].params.hue;
                s_timing->act_cfg.light_param.S = request_data->start_act[i].params.saturation;
                s_timing->act_cfg.light_param.V = request_data->start_act[i].params.value;
            }
            else if (request_data->start_act[i].act == BP_START_ACT_ACT_SCENARIO)
            {
                s_timing->act_cfg.color_mode = LIGHT_MODE_SCENE;
                s_timing->act_cfg.scene_id = request_data->start_act[i].params.scene_id;
            }
            else if (request_data->start_act[i].act == BP_START_ACT_ACT_MUSIC)
            {
                s_timing->act_cfg.color_mode = LIGHT_MODE_MUSIC; 
                s_timing->act_cfg.music_id = request_data->start_act[i].params.music_id;
            }
        }
        else if (request_data->start_act[i].act_type == BP_START_ACT_ACT_TYPE_CHANGESCENE)
        {
            s_timing->act_cfg.color_mode = LIGHT_MODE_SCENE; // TODO：color_mode改为workMode
            s_timing->act_cfg.scene_id = request_data->start_act[i].params.scene_id;
        }
    }

    p_dev_cfg->timing_cfg = s_timing;
    p_dev_cfg->timing_cfg_len = sizeof(light_timing_t);
    return ret;

EXIT:
    return ret;
}

int reply_data_get_for_get_timer(bp_get_timer_reply_t *reply_data, int *err_code, char *err_msg, void *extra)
{
    UNUSED(extra);
    int ret = APP_OK;
    timing_data_t tm;
    uint16_t timing_id = 0;

    if (s_timing == NULL || s_timing->id < LIGHT_TIMING_ID)
    {
        ret = APP_FAIL;
        *err_code = BP_ERR_CMD_EXECUTE_FAIL;
        snprintf(err_msg, BP_ERR_MSG_LEN, BP_ERR_PARAM_CONV(param, BP_ERR_PARAM_VAL_INVALID));
        goto EXIT;
    }

    memset(&tm, 0, sizeof(timing_data_t));

    int sdk_ret = vesync_timing_get(timing_id, &tm);
    if (sdk_ret != SDK_OK)
    {
        ret = APP_FAIL;
        *err_code = BP_ERR_CMD_EXECUTE_FAIL;
        snprintf(err_msg, BP_ERR_MSG_LEN, BP_ERR_PARAM_CONV(param, BP_ERR_PARAM_VAL_INVALID));
        goto EXIT;
    }

    memset(reply_data, BP_NO_VALUE, sizeof(bp_get_timer_reply_t));
    reply_data->timers_num = 1;
    for (int i = 0; i < reply_data->timers_num; i++)
    {
        reply_data->timers[i].uid = (int)tm.timing_id;
        reply_data->timers[i].total_time = (int)tm.total_second;
        reply_data->timers[i].remain_time = (int)tm.remain_second;

        // 处理startAct
        int act_idx = 0;
        reply_data->timers[i].start_act[act_idx].num = 0;
        reply_data->timers[i].start_act[act_idx].act_type = BP_START_ACT_ACT_TYPE_SWITCH;
        reply_data->timers[i].start_act[act_idx].act = s_timing->act_cfg.onoff;

        if (s_timing->act_cfg.onoff == LIGHT_STATUS_ON)
        {
            act_idx++;
            reply_data->timers[i].start_act[act_idx].num = 0;
            if (s_timing->act_cfg.color_mode == LIGHT_MODE_WHITE)
            {
                reply_data->timers[i].start_act[act_idx].act_type = BP_START_ACT_ACT_TYPE_COLORMODE;
                reply_data->timers[i].start_act[act_idx].act = BP_START_ACT_ACT_WHITE;
                reply_data->timers[i].start_act[act_idx].params.color_temp = s_timing->act_cfg.light_param.color_temp;
                reply_data->timers[i].start_act[act_idx].params.brightness = s_timing->act_cfg.light_param.brightness;
            }
            else if (s_timing->act_cfg.color_mode == LIGHT_MODE_COLOR)
            {
                reply_data->timers[i].start_act[act_idx].act_type = BP_START_ACT_ACT_TYPE_COLORMODE;
                reply_data->timers[i].start_act[act_idx].act = BP_START_ACT_ACT_HSV;
                reply_data->timers[i].start_act[act_idx].params.hue =s_timing-> act_cfg.light_param.H;
                reply_data->timers[i].start_act[act_idx].params.saturation = s_timing->act_cfg.light_param.S;
                reply_data->timers[i].start_act[act_idx].params.value = s_timing->act_cfg.light_param.V;
            }
            else if (s_timing->act_cfg.color_mode == LIGHT_MODE_SCENE)
            {
                reply_data->timers[i].start_act[act_idx].act_type = BP_START_ACT_ACT_TYPE_CHANGESCENE;
                reply_data->timers[i].start_act[act_idx].act = BP_START_ACT_ACT_MANUAL;
                reply_data->timers[i].start_act[act_idx].params.scene_id = s_timing->act_cfg.scene_id;
            }
        }

        reply_data->timers[i].start_act_num = act_idx + 1;
    }

EXIT:
    return ret;
}

int request_data_handle_for_del_timer(bp_del_timer_request_t *request_data, int *err_code, char *err_msg, void **extra)
{
    UNUSED(extra);
    dev_cfg_t *p_dev_cfg = app_device_cfg_get();
    if (p_dev_cfg == NULL)
    {
        *err_code = BP_ERR_PARA_ILLEGAL;
        snprintf(err_msg, BP_ERR_MSG_LEN, "device abnormal");
        return APP_FAIL;
    }

    int ret = APP_OK;

    if (request_data->uid == BP_NO_VALUE)
    {
        ret = APP_FAIL;
        *err_code = BP_ERR_PARA_ILLEGAL;
        snprintf(err_msg, BP_ERR_MSG_LEN, BP_ERR_PARAM_CONV(id, BP_ERR_PARAM_MISS));
        goto EXIT;
    }

    if (s_timing->id != request_data->uid)
    {
        ret = APP_FAIL;
        *err_code = BP_ERR_TIMER_NOT_FOUND;
        snprintf(err_msg, BP_ERR_MSG_LEN, BP_ERR_PARAM_CONV(id, BP_ERR_PARAM_VAL_INVALID));
        goto EXIT;
    }

    vesync_timing_reg_cb(NULL);
    vesync_timing_remove(s_timing->id);
    VCOM_SAFE_FREE(s_timing);

    p_dev_cfg->timing_cfg = NULL;
    p_dev_cfg->timing_cfg_len = 0;

EXIT:
    return ret;
}

