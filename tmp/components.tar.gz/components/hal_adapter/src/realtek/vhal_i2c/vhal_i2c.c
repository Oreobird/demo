/**
 *  Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vhal_i2c.c
 * @brief       realtek amebaZ2的i2c读写接口
 * @author      Dongri.Su
 * @date        2021-04-22
 */

#include <stdio.h>

#include "i2c_api.h"

#include "vesync_log.h"
#include "vesync_common.h"

#include "vhal_i2c.h"
#include "vhal_gpio.h"


static i2c_t s_i2c_master;              // i2c主机object
static uint8_t s_i2c_num;               // i2c编号

int32_t vhal_i2c_master_init(uint8_t i2c_num, uint8_t sda_io, uint8_t scl_io, uint32_t speed)
{
    s_i2c_num = i2c_num;
    i2c_init(&s_i2c_master, vhal_rtl_giop_get_pin_name(sda_io), vhal_rtl_giop_get_pin_name(scl_io));
    i2c_frequency(&s_i2c_master, speed);

    return VHAL_OK;
}

int32_t vhal_i2c_master_read(uint8_t i2c_num, bool check_ack, uint8_t addr, uint8_t *p_data, int32_t len)
{
    UNUSED(check_ack);

    int stop = 1;   // 接收完后停止
    int val = 0;

    if(i2c_num != s_i2c_num)
    {
        HAL_LOG(LOG_ERROR, "I2C number(%d) is uninitialized!!\n", i2c_num);
        return 0;
    }
    if (NULL == p_data)
    {
        HAL_LOG(LOG_ERROR, "Input parameter contains null pointer!!\n");
        return 0;
    }

    val = i2c_read(&s_i2c_master, addr, (char *)p_data, len, stop);    // 返回实际读取的长度
    HAL_LOG(LOG_DEBUG, "I2C read %d bytes.\n", val);

    return val;
}

int32_t vhal_i2c_master_write(uint8_t i2c_num, bool check_ack, uint8_t addr, uint8_t *p_data, int32_t len)
{
    UNUSED(check_ack);

    int stop = 1;   // 发送完后停止
    int val = 0;

    if(i2c_num != s_i2c_num)
    {
        HAL_LOG(LOG_ERROR, "I2C number(%d) is uninitialized!!\n", i2c_num);
        return VHAL_FAIL;
    }
    if (NULL == p_data)
    {
        HAL_LOG(LOG_DEBUG, "Input parameter contains null pointer!!\n");
        return VHAL_FAIL;
    }

    val = i2c_write(&s_i2c_master, addr, (char *)p_data, len, stop);
    HAL_LOG(LOG_DEBUG, "I2C write %d bytes.\n", val);

    return val;
}

int32_t vhal_i2c_master_write_stop_condition(uint8_t i2c_num)
{
    return VHAL_OK;
}
