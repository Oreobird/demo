/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
* @file         ledstrip_reset_light_scene_impl.c
* @brief        配网场景回调业务实现
* @author       Joshua
* @date         2021-11-23
*/

#include <string.h>
#include "vesync_log.h"
#include "vesync_common.h"
#include "reset_light.h"
#include "light.h"

static int ledstrip_reset_process(void)
{
    APP_LOG(LOG_DEBUG, "Reset scene process\n");
    app_light_red_blink(5, 0);
    app_light_red_on(5500, false);
    return APP_OK;
}


int reset_light_scene_impl_init(void)
{
    reset_light_scene_t light_scene;

    memset(&light_scene, 0, sizeof(reset_light_scene_t));
    light_scene.reset_process_light = ledstrip_reset_process;

    return reset_light_scene_reg(&light_scene);
}

