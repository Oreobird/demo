/**
 * Copyright © Vesync Technologies Co.Ltd. 2019-2021. All rights reserved.
 * @file    humidifier_uart_handle.h
 * @brief   应用层处理uart具体业务
 * @author  Niki
 * @date    2021-07-08
 */
#include "vesync_common.h"
#include "vesync_log_internal.h"
#include "vesync_cfg.h"
#include "vesync_uart.h"
#include "vesync_log.h"
#include  "stdio.h"
#include  "string.h"
#include "vesync_memory.h"
#include "vesync_task.h"


#define OPC_POWER_ON_OFF        (0xA000)        // opcode:设置设备开启/关闭


/**
 * @brief  UART收发测试demo
 * @param[in]  args              [任务入参]
 * @note
 */
static void humidifier_uart_task(void *args)
{
    static uint32_t i = 0;
    uart_msg_send_t   uart_msg;
    char *p_data = NULL;

    memset(&uart_msg, 0, sizeof(uart_msg));
    uart_msg.type = UART_MSG_TYPE_CMD;
    uart_msg.opcode = OPC_POWER_ON_OFF;
    uart_msg.request_flag = 1;
    uart_msg.status_code = 0;
    uart_msg.p_extra_data = NULL;

    uart_msg.data_len = 1;

    while(1)
    {
        i++;
        if(i % 2 == 0)
        {
            //发关机指令
            uart_msg.p_data =  vesync_malloc(1);

            if(uart_msg.p_data == NULL)
            {
                APP_LOG(LOG_DEBUG,"switch off malloc error\n");
                continue;
            }

            p_data = (char*)uart_msg.p_data;
            *p_data = 0;

            vesync_uart_send(vesync_cfg_get_uart0_idx(), &uart_msg);
            vesync_free(uart_msg.p_data);
            uart_msg.p_data = NULL;
        }
        else
        {
            //发开机指令
            uart_msg.p_data =  vesync_malloc(1);

            if(uart_msg.p_data == NULL)
            {
                APP_LOG(LOG_DEBUG,"switch off malloc error\n");
                continue;
            }

            p_data =  (char*)uart_msg.p_data;
            *p_data = 1;

            vesync_uart_send(vesync_cfg_get_uart0_idx(), &uart_msg);
            vesync_free(uart_msg.p_data);
            uart_msg.p_data = NULL;

        }

        APP_LOG(LOG_DEBUG,"i= %d \n",i);

        vesync_sleep(5000);
    }

}


/**
 * @brief  UART接收数据回调
 * @param[in]  idx              [串口序号]
 * @param[in]  p_payload        [接收的数据]
 * @param[in]  payload_len      [接收的数据长度]
 * @return    uint32_t          [回调处理结果成功或者失败]
 * @note
 */
uint32_t humidifier_uart_recv_cb(uint8_t idx, void *p_payload, uint16_t payload_len)
{
    tl_payload_info_t *p_data = (tl_payload_info_t *)p_payload;

    if((idx != 0)||(p_payload == NULL)||(payload_len== 0))
    {
        return SDK_FAIL;
    }

    APP_LOG(LOG_DEBUG,"humidifier app receive opcode=0x%x version=%d status_code=%d\r\n",
            p_data->op_code, p_data->version, p_data->status_code);

    APP_LOG(LOG_DEBUG,"data:\r\n");
    for(int i=0;i<(payload_len-4);i++)
    {
        APP_LOG(LOG_DEBUG,"0x%02x \n ",*(p_data->payload_data+i));
    }

    return SDK_OK;
}


/**
 * @brief  UART发送结果回调
 * @param[in]  event            [发送结果]
 * @param[in]  p_payload        [回复的数据]
 * @param[in]  payload_len      [回复的数据长度]
 * @param[in] p_msg             [发送的信息]
 * @return    uint32_t          [回调处理结果成功或者失败]
 * @note
 */
uint32_t humidifier_uart_tx_evt_cb(UART_SEND_TYPE_E event, tl_payload_info_t *p_payload, uint16_t payload_len, void *p_extra_data)
{
   SDK_LOG(LOG_INFO,"uart_msg_transfer event =%d \n", event);
   APP_LOG(LOG_DEBUG,"data:\r\n");
    for(int i = 0; i < payload_len - 4; i++)
    {
        APP_LOG(LOG_DEBUG,"0x%02x \n ",*(p_payload->payload_data + i ));
    }
    return SDK_OK;
}


/**
 * @brief       串口服务初始化
 * @return      int32_t         [0成功  /1失败]
 */
int32_t demo_uart_app_init(void)
{
    APP_LOG(LOG_DEBUG,"uart app init begin...\r\n");

    vesync_uart_reg_recv_cb(vesync_cfg_get_uart0_idx(), humidifier_uart_recv_cb);

    vesync_uart_reg_tx_event_cb(vesync_cfg_get_uart0_idx(), humidifier_uart_tx_evt_cb);


    // 串口消息队列处理函数
    if (VOS_OK != vesync_task_new("uart task", NULL, humidifier_uart_task, NULL, 2048, 3, NULL))
    {
        SDK_LOG(LOG_ERROR, "Create humidifier uart  task fail!\n");
        return APP_FAIL;
    }

    APP_LOG(LOG_DEBUG,"uart app init end...\r\n");
    return APP_OK;
}

