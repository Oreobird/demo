/*
 * ESPRESSIF MIT License
 *
 * Copyright (c) 2021 <ESPRESSIF SYSTEMS (SHANGHAI) CO., LTD>
 *
 * Permission is hereby granted for use on all ESPRESSIF SYSTEMS products, in which case,
 * it is free of charge, to any person obtaining a copy of this software and associated
 * documentation files (the "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the Software is furnished
 * to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or
 * substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
 * FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
 * IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 */

#ifndef _LED_DISPLAY_H_
#define _LED_DISPLAY_H_

#include "freertos/FreeRTOS.h"
#include "freertos/semphr.h"
#include "led_strip.h"
#include "esp_log.h"
#include "driver/gpio.h"
#include "driver/rmt.h"


#define CHECK_RGB_PARAM(a,y)    if (!a)   {ESP_LOGE("rgb_parameters_t configuration failed", "%s is NULL, please assign a value", y); abort();}
#define LED_CHECK(TAG, a, msg)  if (!(a)) {ESP_LOGE(TAG,"%s", msg);}

#define DEFAULT_ESP_LED_STRIP_SET_CONFIG_POINTER() {                \
        .display_direction      = FORWARD_DIRECTION,                \
        .min_sound_threshold    = 160,                              \
        .min_freq_threshold     = 260,                              \
        .n_samples              = 1024,                             \
        .audio_samplerate       = 16000,                            \
        .leds_total_number      = 20,                               \
        .yuv_flag               = 0,                                \
}

typedef enum {
    METHOD_CALLBACK = 0,       /*!< Use callback function to change rgb value */
    METHOD_ARRAY,              /*!< Use array to change rgb value */
} change_color_method_t;       /*!< Modify the rgb value method */

typedef enum {
    FORWARD_DIRECTION = 1,     /*!< The light is on in the positive direction */
    BACKWARD_DIRECTION,        /*!< The light is on in the negative direction */
    BOTHWAY_DIRECTION          /*!< The light is on in the both direction */
} display_direction_t;         /*!< Light direction parameter */

typedef struct freq_led_num_s {
    int32_t   freq_min;        /*!< The minimum value of the current frequency band */
    int32_t   freq_max;        /*!< The maximum value of the current frequency band */
    int32_t   led_num;         /*!< The corresponding number of lights in this range */
} freq_led_num_t;              /*!< Frequency structure is used to determine the relationship between frequency and LED */

typedef struct  {
    int32_t   freq_min;        /*!< The minimum value of the current frequency band */
    int32_t   freq_max;        /*!< The maximum value of the current frequency band */
} freq_segment_t;              /*!< Frequency structure is used to determine the relationship frequency  */

extern freq_led_num_t freq_led_num_conf_table[];

typedef struct rgb_color_s {
    uint8_t   red;             /*!< The red value */
    uint8_t   green;           /*!< The green value */
    uint8_t   blue;            /*!< The blue value */

#ifdef WHITE_ENABLE
    uint8_t   white;            /*!< The white value */
#endif

} rgb_color_t;                 /*!< The rgb value */

typedef struct hsv_color_s {
    float   hue;             /*!< The red value */
    float   saturation;           /*!< The green value */
    float   value;            /*!< The blue value */
} hsv_color_t;


typedef struct rgb_ctrl_s {
    int32_t   led_num;         /*!< The number of lights currently on */
    int32_t   per_led_num;     /*!< The number of lights on last time */
    // int32_t   change_color;    /*!< Color change counter */
} rgb_ctrl_t;                  /*!< RGB control parameters */


typedef struct freq_normal_s {
    int32_t   n_samples;       /*!< FFT sampling points */
    int32_t  *num;             /*!< FFT frequency X-axis coordinate array */
    float    *value;           /*!< An array of FFT frequency normalized values */
} freq_normal_t;               /*!< Frequency normalization parameter */

typedef struct {
    int32_t  *s_num;           /*!< The ordered array of corresponding subscripts after fft normalization */
    float    *s_value;         /*!< Array normalized by fft */

    /* input array */
    float    *s_audio_data;    /*!< input array */
    /* fft   array */
    float    *s_wind;          /*!< Window coefficients */
    float    *s_y_cf2;         /*!< working complex array */
} fft_array_t;                 /*!< fft related array */

typedef void (*discoloration_method)(rgb_color_t *color);                 /*!< discoloration_method pointer */

typedef struct gradient_method_s{
    uint32_t              *rgb_assign_array;         /*!< Color RGB array */
    uint32_t               rgb_assign_array_rows;    /*!< Color number of rows in RGB array */
    discoloration_method   rgb_assign_func;          /*!< Color change callback function */
    int32_t                type;                     /*!< Callback function or array */
    // int32_t                change_color;          /*!< Color change counter */
} rgb_assign_method_t;

typedef rgb_color_t* (*base_color_t)(rgb_assign_method_t *method);           /*!< discoloration_method pointer */

typedef struct rgb_parameters_s {
    SemaphoreHandle_t   can_shift;                   /*!< Adc semaphore for mutually exclusive when getting values */
    display_direction_t display_direction;           /*!< Light direction parameter */

    rgb_color_t           *rgb_color;                /*!< RGB primary color value */
    rgb_color_t           *rgb_show;                 /*!< RGB Current applied value */
    rgb_ctrl_t            *rgb_ctrl;                 /*!< RGB control parameters */
    freq_normal_t         *freq_normal;              /*!< Frequency normalization parameter */
    double                 max_audio_data;           /*!< Maximum value of source data per frame */
    double                 max_rec;                  /*!< The maximum source data value since the start of the program */
    float                  min_sound_threshold;      /*!< Used to judge whether the minimum sound (source data) threshold is reached */
    int32_t                min_freq_threshold;       /*!< Used to judge whether the minimum freq threshold is reached */
    int32_t                leds_total_number;        /*!< Total number of leds that can be controlled */
    int32_t                audio_samplerate;         /*!< Audio sampling rate */
    int32_t                begin;                    /*!< The starting Point lights location */
    int32_t                level;                    /*!< Calculate the lighting level of the strip according to the energy */
    float                 *audio_data;               /*!< Audio source data */
    base_color_t           base_color;
    rgb_assign_method_t    *method;
    // uint32_t               rgb_grade_rows;
    int32_t                yuv_flag;                 /*!< YUV mode flag */
} rgb_parameters_t;                                  /*!< Rgb parameters */

typedef void (*led_func)(led_strip_t *strip, rgb_parameters_t *rgb);      /*!< function pointer */

typedef struct list_s {
        struct list_s *next;
} list_t;

typedef struct led_mode_func_s{
    led_func   function;                             /*!< Led function */
    list_t     link;                                 /*!< Intrusive linked list */
} led_mode_func_t;

typedef struct led_rgb_handle_s{
    led_strip_t           *strip;                    /*!< A pointer of led light */
    led_mode_func_t       *led_mode;                 /*!< Led function struct */
    rgb_parameters_t      *rgb_parameters;           /*!< Rgb parameters */
    fft_array_t           *fft_array;                /*!< fft related array */
} led_rgb_handle_t;                                  /*!< Led handle */

typedef struct rgb_config_s {
    SemaphoreHandle_t      can_shift;
    display_direction_t    display_direction;
    int32_t                n_samples;
    float                  min_sound_threshold;
    int32_t                min_freq_threshold;
    int32_t                leds_total_number;
    int32_t                audio_samplerate;
    uint32_t              *rgb_assign_array;
    base_color_t           base_color;
    uint32_t               rgb_assign_array_rows;
    int32_t                yuv_flag;
    int32_t                gradient_method_type;
    discoloration_method   rgb_assign_func;
} rgb_config_t;                                      /*!< Rgb configuration */

/**
 * @brief      Change the brightness value of rgb according to the sound
 *
 * @param[in]  rgb                 Rgb parameters
 *
 * @return
 *      - 0
 */
void update_rgb_luminance(rgb_parameters_t *rgb);

/**
 * @brief      Spectrum normalization processing(If frequency-related effects are achieved, it is recommended to
 *             use this function to process fft data)
 *
 * @param[in]  y_cf                Frequency array through fft
 * @param[in out] freq_normal      Frequency normalization parameter(Including the permutation and combination of
 *                                 the normalized array and the subscripts of the original array)
 *
 * @return
 *      - ESP_OK
 *      - ESP_FAIL
 */
esp_err_t normaliton(float * y_cf, freq_normal_t *freq_normal);

/**
 * @brief      Rgb single light with display function, you can choose the starting address to light up,
 *             and refresh the number of lights without using clear
 *
 * @param[in]  strip               The pointer of led strip
 * @param[in]  display_num         The number of lights currently displayed
 * @param[in]  rgb      RGB parameters
 *
 * @return
 *      - 0
 */
void led_rgb_display(led_strip_t *strip, int32_t display_num, rgb_parameters_t *rgb);

/**
 * @brief      Calculate the lighting level based on the minimum energy and maximum energy
 *
 * @param[in]  min                 Minimum audio effective value
 * @param[in]  max                 Maximum audio effective value
 * @param[in]  rgb                 RGB parameters
 *
 * @return
 *      - 0
 */
void energy_detection(double min, double max, rgb_parameters_t *rgb);

/**
 * @brief      Led display registration function
 *
 * @param[in]  rgb_config          The pointer of Rgb configuration
 *
 * @return
 *      - led_rgb_handle_t         Led handle
 */
led_rgb_handle_t * led_display_init(rgb_config_t *rgb_config);

/**
 * @brief      Set the function of the Nth lamp bead
 *
 * @param[in]  strip               The pointer of led strip
 * @param[in]  led_pos             The pointer of led strip
 * @param[in]  green               The green value
 * @param[in]  red                 The red value
 * @param[in]  blue                The blue value
 */
void led_set_pixel(led_strip_t *strip, int32_t led_pos, int32_t green, int32_t red, int32_t blue);

/**
 * @brief      Refresh light strip
 *
 * @param[in]  strip               The pointer of led strip
 * @param[in]  timeout_ms          timeout ms
 */
void led_reflash_pixel(led_strip_t *strip, uint32_t timeout_ms);

/**
 * @brief      Clear light strip
 *
 * @param[in]  strip               The pointer of led strip
 * @param[in]  timeout_ms          timeout ms
 */
void led_clear_pixel(led_strip_t *strip, uint32_t timeout_ms);

#endif
