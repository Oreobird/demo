/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_button.c
 * @brief       事件处理接口，modified from MultiButton
 * @author      Joshua
 * @date        2021-12-8
 */

#include <string.h>
#include <stdio.h>
#include <stdbool.h>

#include "vesync_common.h"
#include "vesync_log_internal.h"
#include "vesync_task.h"
#include "vesync_memory.h"
#include "vesync_button_internal.h"
#include "vhal_gpio.h"

#define BTN_EVENT_CB(ev) \
    do { \
        if (btn->cb[ev]) \
        { \
            btn->cb[ev](); \
        } \
    } while (0)

static bool s_task_running = false;

/**
 *@brief 按键按下状态处理回调
 *@param[in] *btn           [按键结构体指针]
 */
static void state_down_handle(vesync_btn_t *btn)
{
    if (btn->button_level == btn->active_level)
    {
        btn->event = EV_PRESS_DOWN;
        BTN_EVENT_CB(EV_PRESS_DOWN);
        btn->ticks = 0;
        btn->repeat = 1;
        btn->state = STATE_UP;
    }
    else
    {
        btn->event = EV_NONE_PRESS;
    }
}

/**
 *@brief 按键松开状态处理回调
 *@param[in] *btn           [按键结构体指针]
 */
static void state_up_handle(vesync_btn_t *btn)
{
    if (btn->button_level != btn->active_level)
    {
        btn->event = EV_PRESS_UP;
        BTN_EVENT_CB(EV_PRESS_UP);
        btn->ticks = 0;
        btn->state = STATE_REPEAT;

    }
    else if (btn->ticks > btn->long_press_threshold_ticks)  // 超过长按判断时长阈值
    {
        btn->event = EV_LONG_PRESS_START;
        BTN_EVENT_CB(EV_LONG_PRESS_START);
        btn->state = STATE_RESET;
    }
}

/**
 *@brief 按键连击状态处理回调
 *@param[in] *btn           [按键结构体指针]
 */
static void state_repeat_handle(vesync_btn_t *btn)
{
    if (btn->button_level == btn->active_level)
    {
        btn->event = EV_PRESS_DOWN;
        BTN_EVENT_CB(EV_PRESS_DOWN);
        btn->repeat++;
        btn->ticks = 0;
        btn->state = STATE_SHORT;
    }
    else if (btn->ticks > SHORT_PRESS_THRESHOLD_TICKS) // 超过短按判断时长阈值
    {
        if(btn->repeat == 1)
        {
            btn->event = EV_SINGLE_CLICK;
            BTN_EVENT_CB(EV_SINGLE_CLICK);
        }
        else if (btn->repeat == 2)
        {
            btn->event = EV_DOUBLE_CLICK;
            BTN_EVENT_CB(EV_DOUBLE_CLICK);
        }
        btn->state = STATE_DOWN;
    }
}

/**
 *@brief 按键短按状态处理回调
 *@param[in] *btn           [按键结构体指针]
 */
static void state_short_handle(vesync_btn_t *btn)
{
    if (btn->button_level != btn->active_level)
    {
        btn->event = EV_PRESS_UP;
        BTN_EVENT_CB(EV_PRESS_UP);

        if (btn->ticks < SHORT_PRESS_THRESHOLD_TICKS)
        {
            btn->ticks = 0;
            btn->state = STATE_REPEAT; //repeat press
        }
        else
        {
            btn->state = STATE_DOWN;
        }
    }
    else if (btn->ticks > SHORT_PRESS_THRESHOLD_TICKS)
    {
        btn->state = STATE_DOWN;
    }
}

/**
 *@brief 按键初始状态处理回调
 *@param[in] *btn           [按键结构体指针]
 */
static void state_reset_handle(vesync_btn_t *btn)
{
    if (btn->button_level == btn->active_level) // 长按期间
    {
        btn->event = EV_LONG_PRESS_HOLD;
        if (btn->ticks > btn->long_press_cb_interval_ticks)
        {
            btn->ticks = 0;
            BTN_EVENT_CB(EV_LONG_PRESS_HOLD);
        }
    }
    else
    {
        btn->event = EV_PRESS_UP;
        BTN_EVENT_CB(EV_PRESS_UP);
        btn->state = STATE_DOWN;
    }
}

/**
 *@brief 状态回调表
 */
static state_handle_t s_state_handle_tbl[] = {
    {STATE_DOWN,    state_down_handle},
    {STATE_UP,      state_up_handle},
    {STATE_REPEAT,  state_repeat_handle},
    {STATE_SHORT,   state_short_handle},
    {STATE_RESET,   state_reset_handle},
};

/**
 *@brief 按键事件处理
 *@param[in] *btn           [按键结构体指针]
 */
static void button_handler(vesync_btn_t* btn)
{
    uint8_t gpio_level = btn->hal_gpio_level_get(btn->gpio);

    if ((btn->state) > STATE_DOWN)
    {
        btn->ticks++;
    }

    // 处理debounce
    if (gpio_level != btn->button_level)
    {
        if (++(btn->debounce_cnt) >= DEBOUNCE_TICKS)
        {
            btn->button_level = gpio_level;
            btn->debounce_cnt = 0;
        }
    }
    else
    {
        btn->debounce_cnt = 0;
    }

    // 事件处理
    for (int i = 0; i < (int)SIZEOF_ARRAY(s_state_handle_tbl); i++)
    {
        if (btn->state == s_state_handle_tbl[i].state && s_state_handle_tbl[i].fn)
        {
            s_state_handle_tbl[i].fn(btn);
            break;
        }
    }
}

/**
 *@brief 按键事件处理任务
 *@param[in] arg           [任务参数]
 */
static void button_task(void *arg)
{
    UNUSED(arg);
    s_task_running = true;

    while (s_task_running)
    {
        vesync_btn_event_handle(button_handler);
        vesync_sleep(TICKS_INTERVAL_MS);
    }

    vesync_btn_mgt_deinit();
}

/**
 *@brief 按键GPIO初始化
 *@param[in] gpio_num           [gpio引脚]
 */
static void button_gpio_init(uint8_t gpio_num, uint8_t active_level)
{
    vhal_gpio_config_t button_io;
    button_io.pin_bit_mask = (1ULL << gpio_num);
    button_io.mode = GPIO_MODE_IN;
    button_io.pull_up_en = (active_level == ACTIVE_HIGH) ? GPIO_PULLUP_DIS : GPIO_PULLUP_EN;
    button_io.pull_down_en = (active_level == ACTIVE_HIGH) ? GPIO_PULLDOWN_EN : GPIO_PULLDOWN_DIS;
    button_io.intr_type = GPIO_INTR_DIS;
    vhal_gpio_init(button_io);
}

/**
 *@brief 按键配置检查
 *@param[in] *cfg           [配置结构体]
 *@return bool              [true：合法，false：非法]
 */
static bool button_cfg_validate(btn_cfg_t *cfg)
{
    VCOM_NULL_PARAM_CHK(cfg, return false);
    if (cfg->long_press_cb_interval_ms < TICKS_INTERVAL_MS)
    {
        SDK_LOG(LOG_INFO, "invalid cb interval, set to default %d ms\n", TICKS_INTERVAL_MS);
        cfg->long_press_cb_interval_ms = TICKS_INTERVAL_MS;
    }

    if (cfg->long_press_threshold_ms < LONG_PRESS_THRESHOLD_MS)
    {
        SDK_LOG(LOG_INFO, "invalid long press threshold, set to default %d ms\n", DEFAULT_LONG_PRESS_THRESHOLD_MS);
        cfg->long_press_threshold_ms = DEFAULT_LONG_PRESS_THRESHOLD_MS;
    }

    return true;
}

int vesync_button_add(btn_cfg_t *cfg)
{
    if (!button_cfg_validate(cfg))
    {
        return SDK_FAIL;
    }

    button_gpio_init(cfg->gpio, cfg->active_level);

    vesync_btn_t *btn = (vesync_btn_t *)vesync_malloc(sizeof(vesync_btn_t));
    if (btn == NULL)
    {
        SDK_LOG(LOG_ERROR, "reg fail\n");
        return SDK_FAIL;
    }

    memset(btn, 0, sizeof(vesync_btn_t));

    btn->gpio = cfg->gpio;
    btn->active_level = cfg->active_level;
    btn->long_press_cb_interval_ticks = cfg->long_press_cb_interval_ms / TICKS_INTERVAL_MS;
    btn->long_press_threshold_ticks = cfg->long_press_threshold_ms / TICKS_INTERVAL_MS;

    btn->event = EV_NONE_PRESS;
    btn->hal_gpio_level_get = vhal_gpio_get_output;
    btn->button_level = btn->hal_gpio_level_get(cfg->gpio);

    int ret = vesync_btn_mgt_add(btn);
    if (ret != SDK_OK)
    {
        VCOM_SAFE_FREE(btn);
        return SDK_FAIL;
    }

    return SDK_OK;

}

int vesync_button_del(uint8_t gpio)
{
    return vesync_btn_mgt_del(gpio);
}

int vesync_button_reg_cb(uint8_t gpio, BTN_EVENT_E event, vesync_btn_cb_t cb)
{
    if (event >= EV_NUM)
    {
        SDK_LOG(LOG_ERROR, "event gpio invalid\n");
        return SDK_FAIL;
    }

    vesync_btn_t *btn = vesync_btn_mgt_get(gpio);
    if (btn == NULL)
    {
        SDK_LOG(LOG_ERROR, "No button found\n");
        return SDK_FAIL;
    }

    btn->cb[event] = cb;
    return SDK_OK;
}

int vesync_button_reg_cb_arr(uint8_t gpio, btn_ev_cb_t ev_cb_arr[], int num)
{
    if (ev_cb_arr == NULL)
    {
        SDK_LOG(LOG_ERROR, "params invalid\n");
        return SDK_FAIL;
    }

    vesync_btn_t *btn = vesync_btn_mgt_get(gpio);
    if (btn == NULL)
    {
        SDK_LOG(LOG_ERROR, "No button found\n");
        return SDK_FAIL;
    }

    for (int i = 0; i < (int) VCOM_MIN(num, EV_NUM); i++)
    {
        btn->cb[ev_cb_arr[i].ev] = ev_cb_arr[i].cb;
    }

    return SDK_OK;
}

int vesync_button_init(void)
{
    int ret = SDK_FAIL;

    ret = vesync_btn_mgt_init();
    if (ret != SDK_OK)
    {
        SDK_LOG(LOG_ERROR, "button init fail !!!\r\n");
        return SDK_FAIL;
    }

    ret = vesync_task_new(VESYNC_BUTTON_TASK_NAME, NULL,
                        button_task,
                        NULL,
                        VESYNC_BUTTON_TASK_STACKSIZE,
                        VESYNC_BUTTON_TASK_PRIO, NULL);
    if (ret != VOS_OK)
    {
        vesync_btn_mgt_deinit();
        SDK_LOG(LOG_ERROR, "button task create fail !!!\r\n");
        return SDK_FAIL;
    }

    return SDK_OK;
}

int vesync_button_deinit(void)
{
    s_task_running = false;
    return SDK_OK;
}
