/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        demo.c
 * @brief       SDK入口函数
 * @author      Joshua
 * @date        2021-04-22
 */

#include "vesync_init.h"
#include "vesync_log.h"
#include "vesync_cfg.h"

static void demo_pre_cb(void)
{
    APP_LOG(LOG_DEBUG, "Demo pre init callback\n");

    // 设置VeSync SDK的产品配置参数
    vesync_cfg_set_config_model("demo_config_model");
    vesync_cfg_set_authkey("demo_authkey");
    vesync_cfg_set_ble_name("demo_ble_name");
}

static void demo_app_run(void)
{
    APP_LOG(LOG_INFO, "Vesync APP Demo start\n");
}

void app_main(void)
{
    vesync_sdk_reg_pre_run_cb(demo_pre_cb);
    vesync_sdk_reg_post_run_cb(demo_app_run);

    vesync_sdk_run();
}

