/**
 * Copyright © Vesync Technologies Co.Ltd. 2019-2021. All rights reserved.
 * @file    tcp_server.c
 * @brief   本地TCP服务器
 * @author  Dongri.Su
 * @date    2019-11-17
 */

#ifndef __VESYNC_TCP_SERVER_H__
#define __VESYNC_TCP_SERVER_H__

#include <stdbool.h>
#include <stdint.h>
#include "vesync_task.h"

// TCP服务器(APN配网使用)
#define TCP_SERVER_TASK_NAME            "tcp_server"
#define TCP_SERVER_TASK_STACSIZE        (1024*4)
#define TCP_SERVER_TASK_PRIO            TASK_PRIORITY_NORMAL

#define VESYNC_TCP_SERVER_PORT     41234

#define  EV_TCP_SERVER_STOP     0x00000001

#define VESYNC_TCP_SERVER_RECV_BUF     (512)
#define VESYNC_TCP_SERVER_KEEPALIVE     (1)     // enable/disable keepalive
#define VESYNC_TCP_SERVER_KEEPIDLE      (5)     // if 5s no data recv from client, send keep-alive probe packet
#define VESYNC_TCP_SERVER_KEEPINTV      (1)     // every 1s to send keep-alive probe packet
#define VESYNC_TCP_SERVER_KEEPCNT       (3)     // send 3 times keep-alive probe packet


/**
 * @brief 启动TCP服务监听APP的配网注册信息
 * @param[in] port                  [TCP监听端口]
 * @return int                      [启动结果，0为成功]
 */
int vesync_tcp_server_start(uint32_t port);

/**
 * @brief TCP发送数据
 * @param[in]  buf      [待发送数据]
 * @param[in]  length   [待发送数据长度]
 * @return              [发送结果]
 */
int vesync_tcp_server_send(const uint8_t *buf, uint32_t length);

/**
 * @brief 关闭配网TCP服务器
 */
void vesync_tcp_server_stop(void);

/**
 * @brief 检查tcp服务器是否已经启动
 * @return bool         [true:已启动，false：未启动]
 */
bool vesync_tcp_server_is_started(void);

#endif /* __VESYNC_TCP_SERVER_H__ */
