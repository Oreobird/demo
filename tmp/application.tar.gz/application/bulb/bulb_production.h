/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        bulb_production.h
 * @brief       灯泡的产测
 * @author      Dave.Ming
 * @date        2021-09-02
 */

#ifndef __BULB_PRODUCTION_H__
#define __BULB_PRODUCTION_H__

#ifdef __cplusplus
extern "C" {
#endif

/**
* @brief bulb产测功能初始化
*/
void bulb_production_init(void);

/**
* @brief bulb产测前老化测试回调
*/
void bulb_production_pre_test_cb();

#ifdef __cplusplus
}
#endif

#endif

