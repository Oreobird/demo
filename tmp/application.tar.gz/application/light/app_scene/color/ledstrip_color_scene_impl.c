/**
* Copyright © Vesync Technologies Co.Ltd. 2022. All rights reserved
* @file         ledstrip_color_scene_impl.c
* @brief        彩灯控制场景业务实现
* @author       Joshua
* @date         2022-1-24
*/

#include <string.h>
#include "vesync_log.h"
#include "vesync_common.h"
#include "device.h"
#include "light.h"
#include "color.h"

static int color_on(void *param)
{
    UNUSED(param);
    APP_LOG(LOG_DEBUG, "color on scene\n");

    dev_cfg_t *p_dev_cfg = app_device_cfg_get();
    VCOM_NULL_RET_CHK(p_dev_cfg, return APP_FAIL);
    light_param_t *light_param = &(p_dev_cfg->flash->cfg.light_param);
    app_light_color_on(light_param->H, light_param->S, light_param->V, 0, p_dev_cfg->fade);
    return APP_OK;
}

static int color_off(void *param)
{
    UNUSED(param);
    APP_LOG(LOG_DEBUG, "color off scene\n");

    dev_cfg_t *p_dev_cfg = app_device_cfg_get();
    VCOM_NULL_RET_CHK(p_dev_cfg, return APP_FAIL);
    app_light_color_off(0, p_dev_cfg->fade);
    return APP_OK;
}

int color_on_light_scene_impl_init(void)
{
    light_scene_t light_scene;
    memset(&light_scene, 0, sizeof(light_scene_t));
    light_scene.light_cb = color_on;
    return color_on_light_scene_reg(&light_scene);
}

int color_off_light_scene_impl_init(void)
{
    light_scene_t light_scene;
    memset(&light_scene, 0, sizeof(light_scene_t));
    light_scene.light_cb = color_off;
    return color_off_light_scene_reg(&light_scene);
}

