/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_sem.c
 * @brief       semaphore抽象层，封装linux posix信号量相关接口
 * @author      Joshua
 * @date        2021-04-20
 */

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <semaphore.h>
#include <time.h>
#include <sys/time.h>

#include "vesync_common.h"
#include "vesync_os.h"
#include "vesync_sem.h"

/*
 * @brief  创建信号量
 * @param[in]  sem                     [信号量结构体指针]
 * @return int                         [成功：0；失败：-1]
 */
int vesync_sem_new(vesync_sem_t *sem)
{
    VCOM_NULL_PARAM_CHK(sem, return -1);
    sem_t *psem = sem_open("sem", O_CREAT, 0666, 0);
    if (psem == SEM_FAILED)
    {
        return -1;
    }

    sem->handle = psem;

    return 0;
}

/*
 * @brief  等待信号量
 * @param[in]  sem                     [信号量结构体指针]
 * @param[in]  timeout_ms              [等待时间：
 *                                      VESYNC_OS_NO_WAIT: 不等待
 *                                      VESYNC_OS_WAIT_FOREVER: 等待信号量]
 * @return int                         [成功：0；失败：返回-1]
 */
int vesync_sem_wait(vesync_sem_t *sem, unsigned int timeout_ms)
{
    int sec = 0;
    int nsec = 0;

    VCOM_NULL_PARAM_CHK(sem, return -1);
    VCOM_NULL_PARAM_CHK(sem->handle, return -1);

    if (timeout_ms == VESYNC_OS_WAIT_FOREVER)
    {
        return sem_wait(sem->handle);
    }
    else if (timeout_ms == VESYNC_OS_NO_WAIT)
    {
        return sem_trywait(sem->handle);
    }

    struct timespec ts;
    clock_gettime(CLOCK_REALTIME, &ts);

    sec = timeout_ms / 1000;
    nsec = (timeout_ms % 1000) * 1000000;

    ts.tv_nsec += nsec;
    sec += (ts.tv_nsec / 1000000000);
    ts.tv_nsec %= 1000000000;
    ts.tv_sec += sec;

    return sem_timedwait(sem->handle, &ts);
}

/*
 * @brief  释放信号量
 * @param[in]  sem                     [信号量结构体指针]
 * @return int                         [成功：0；失败：返回-1]
 */
int vesync_sem_signal(vesync_sem_t *sem)
{
    VCOM_NULL_PARAM_CHK(sem, return -1);
    VCOM_NULL_PARAM_CHK(sem->handle, return -1);

    int ret = -1;
    ret = sem_post(sem->handle);
    if (ret < 0)
    {
        return -1;
    }
    return 0;
}

/*
 * @brief  销毁信号量
 * @param[in]  sem                     [信号量结构体指针]
 * @return int                         [成功：0；失败：返回-1]
 */
int vesync_sem_free(vesync_sem_t *sem)
{
    VCOM_NULL_PARAM_CHK(sem, return -1);
    VCOM_NULL_PARAM_CHK(sem->handle, return -1);
    sem_close(sem->handle);
    int ret = sem_unlink("sem");
    if (ret < 0)
    {
        return -1;
    }

    return 0;
}

