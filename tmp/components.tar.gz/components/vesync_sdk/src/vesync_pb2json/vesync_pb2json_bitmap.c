/**
 * Copyright © Vesync Technologies Co.Ltd. 2019-2021. All rights reserved.
 * @file    vesync_pb2json_bitmap.c
 * @brief   bitmap的简单实现
 * @author  Herve Lin
 * @date    2021-12-13
 */
#include "vesync_memory.h"
#include "vesync_pb2json_internal.h"

#define bitmap_word_t_bits (8 * sizeof(bitmap_word_t)) // 定义单个字的位数
#define bitmap_words_needed(size) (((size) + (bitmap_word_t_bits - 1)) / bitmap_word_t_bits) // 根据Bitmap大小计算需要多少个字

bitmap_t bitmap_alloc(int size)
{
    return (bitmap_t)vesync_calloc(bitmap_words_needed(size), sizeof(bitmap_word_t));
}

void bitmap_free(bitmap_t bitmap)
{
    vesync_free(bitmap);
}

void bitmap_set(bitmap_t bitmap, unsigned int i)
{
    bitmap[i / bitmap_word_t_bits] |= (1 << (i & (bitmap_word_t_bits - 1)));
}

void bitmap_reset(bitmap_t bitmap, unsigned int i)
{
    bitmap[i / bitmap_word_t_bits] &= (0xFF ^ (1 << (i & (bitmap_word_t_bits - 1))));
}

int bitmap_get(bitmap_t bitmap, unsigned int i)
{
    return (bitmap[i / bitmap_word_t_bits] & (1 << (i & (bitmap_word_t_bits - 1)))) ? 1 : 0;
}
