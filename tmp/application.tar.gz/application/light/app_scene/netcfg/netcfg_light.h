/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
* @file         netcfg_light.h
* @brief        配网灯效控制
* @author       Joshua
* @date         2021-11-20
*/

#include <stdint.h>
#include "vesync_common.h"
#include "scene.h"

#ifndef __NETCFG_LIGHT_H__
#define __NETCFG_LIGHT_H__

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief  配网灯效回调
 * @return  int             [成功：APP_OK，失败：APP_FAIL]
 */
typedef int (*netcfg_light_cb_t)(void);


/**
 * @brief  配网灯效场景结构体
 */
typedef struct
{
    netcfg_light_cb_t netcfg_waiting_light;
    netcfg_light_cb_t netcfg_process_light;
    netcfg_light_cb_t netcfg_success_light;
    netcfg_light_cb_t netcfg_fail_light;
} netcfg_light_scene_t;


/**
 * @brief  等待配网灯效
 * @param[in] thiz          [场景结构体指针]
 * @return  int             [成功：APP_OK，失败：APP_FAIL]
 */
static inline int netcfg_light_scene_wait(scene_t *thiz)
{
    VCOM_NULL_PARAM_CHK(thiz, return APP_FAIL);
    netcfg_light_scene_t *ctx = (netcfg_light_scene_t *)thiz->ctx;
    return (ctx && ctx->netcfg_waiting_light) ? ctx->netcfg_waiting_light() : APP_FAIL;
}

/**
 * @brief  配网中灯效
 * @param[in] thiz          [场景结构体指针]
 * @return  int             [成功：APP_OK，失败：APP_FAIL]
 */
static inline int netcfg_light_scene_process(scene_t *thiz)
{
    VCOM_NULL_PARAM_CHK(thiz, return APP_FAIL);
    netcfg_light_scene_t *ctx = (netcfg_light_scene_t *)thiz->ctx;
    return (ctx && ctx->netcfg_process_light) ? ctx->netcfg_process_light() : APP_FAIL;
}

/**
 * @brief  配网成功灯效
 * @param[in] thiz          [场景结构体指针]
 * @return  int             [成功：APP_OK，失败：APP_FAIL]
 */
static inline int netcfg_light_scene_success(scene_t *thiz)
{
    VCOM_NULL_PARAM_CHK(thiz, return APP_FAIL);
    netcfg_light_scene_t *ctx = (netcfg_light_scene_t *)thiz->ctx;
    return (ctx && ctx->netcfg_success_light) ? ctx->netcfg_success_light() : APP_FAIL;
}

/**
 * @brief  配网失败灯效
 * @param[in] thiz          [场景结构体指针]
 * @return  int             [成功：APP_OK，失败：APP_FAIL]
 */
static inline int netcfg_light_scene_fail(scene_t *thiz)
{
    VCOM_NULL_PARAM_CHK(thiz, return APP_FAIL);
    netcfg_light_scene_t *ctx = (netcfg_light_scene_t *)thiz->ctx;
    return (ctx && ctx->netcfg_fail_light) ? ctx->netcfg_fail_light() : APP_FAIL;
}

/**
 * @brief  配网场景灯效实现初始化
 * @return int              [成功：APP_OK， 失败：APP_FAIL]
 */
int netcfg_light_scene_impl_init(void);

/**
 * @brief  注册配网场景灯效
 * @param[in] *light_scene      [配网灯效场景结构体指针]
 * @return  int                 [成功：APP_OK，失败：APP_FAIL]
 */
int netcfg_light_scene_reg(netcfg_light_scene_t *light_scene);

/**
 * @brief  注销配网场景灯效
 * @return  int             [成功：APP_OK，失败：APP_FAIL]
 */
int netcfg_light_scene_unreg(void);

#ifdef __cplusplus
}
#endif

#endif


