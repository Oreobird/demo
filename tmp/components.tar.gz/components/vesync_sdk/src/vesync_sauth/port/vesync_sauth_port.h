/**
 * Copyright © Vesync Technologies Co.Ltd. 2022. All rights reserved.
 * @file        vesync_sauth_port.h
 * @brief       Vesync SAUTH模块的移植接口定义
 * @author      Herve
 * @date        2022-01-04
 */
#ifndef __VESYNC_SAUTH_PORT_H__
#define __VESYNC_SAUTH_PORT_H__

#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>

#include "vesync_tl_frame_parse.h"
#include "vesync_frame.h"

#ifdef __cplusplus
extern "C"
{
#endif

#define SAUTH_PORT_BLE_PROTOCOL_VERSION (0x01) // 蓝牙透传串口SAUTH的协议版本
#define SAUTH_PORT_OPCODE_APP2DEV (0x8055)     // SAUTH在串口中，APP发送给设备的OPCODE
#define SAUTH_PORT_OPCODE_DEV2APP (0x8055)     // SAUTH在串口中，设备发送给APP的OPCODE
#define SAUTH_PORT_OS_MUTEX_ENABLE (0)         // 是否启用互斥锁

/**
 * @brief Sauth读取LTK
 * @param[out]  p_buf           [读取缓存]
 * @param[in]   len             [缓存长度]
 * @return      int             [成功：SDK_OK；失败：SDK_FAIL]
 */
int sauth_port_read_ltk(uint8_t *p_buf, uint8_t len);

/**
 * @brief Sauth写入LTK
 * @param[in]   p_buf           [写入数据]
 * @param[in]   len             [写入数据长度]
 * @return      int             [成功：SDK_OK；失败：SDK_FAIL]
 */
int sauth_port_write_ltk(uint8_t *p_buf, uint8_t len);

/**
 * @brief Sauth产生随机数块回调
 * @param[out]  dest            [输出缓存]
 * @param[in]   size            [缓存大小]
 */
void sauth_port_rnd_block_gen_cb(uint8_t *dest, uint32_t size);

/**
 * @brief Sauth开启新会话的回调
 */
void sauth_port_new_session_cb(void);

/**
 * @brief Sauth进入临界区
 */
void sauth_port_enter_critical(void);

/**
 * @brief Sauth离开临界区
 */
void sauth_port_exit_critical(void);

/**
 * @brief Sauth传输层发送数据
 * @param[in]   p_data          [指向发送的数据]
 * @param[in]   len             [发送数据的大小]
 */
void sauth_port_tl_send_data(uint8_t *p_data, uint16_t len);

/**
 * @brief Sauth传输层接收数据回调
 * @param[in]   p_data          [Vesync Frame中的透传数据]
 * @param[in]   len             [透传数据长度]
 * @param[in]   need_ack        [是否需要应答]
 * @return      bool            [消息是否被接收者消费]
 */
bool srpc_tl_data_recv_cb(uint8_t *p_data, uint16_t len, bool need_ack);

/**
 * @brief Sauth外部移植接口初始化
 * @return      int             [成功：SDK_OK；失败：SDK_FAIL]
 */
int sauth_port_init(void);

#ifdef __cplusplus
}
#endif

#endif
