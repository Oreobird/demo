/*
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file        vesync_json.c
* @brief       json数据处理接口
* @date        2021-05-17
*/

#include <stdlib.h>
#include "vesync_common.h"
#include "vesync_log_internal.h"
#include "vesync_json_internal.h"
#include "vesync_memory.h"

/**
* @brief 获取cjson的number数据
* @param[in] json                     [cjson格式的数据]
* @param[in] key                      [名称]
* @param[out] val                     [数据]
* @return int                         [成功/失败]
*/
int vesync_json_get_number(cJSON *json, const char *key, int *val)
{
    VCOM_NULL_PARAM_CHK(json, return SDK_FAIL);
    VCOM_NULL_PARAM_CHK(key, return SDK_FAIL);
    VCOM_NULL_PARAM_CHK(val, return SDK_FAIL);

    cJSON* json_data = cJSON_GetObjectItemCaseSensitive(json, key);
    if (!cJSON_IsNumber(json_data))
    {
        return SDK_FAIL;
    }

    *val = json_data->valueint & 0xFF;
    return SDK_OK;
}

/**
* @brief 获取cjson的str数据
* @param[in] json                     [cjson格式的数据]
* @param[in] key                      [名称]
* @param[out] val                     [数据]
* @return int                         [成功/失败]
*/
int vesync_json_get_string(cJSON *json, const char *key, char **val)
{
    VCOM_NULL_PARAM_CHK(json, return SDK_FAIL);
    VCOM_NULL_PARAM_CHK(key, return SDK_FAIL);
    VCOM_NULL_PARAM_CHK(val, return SDK_FAIL);

    cJSON* json_data = cJSON_GetObjectItemCaseSensitive(json, key);
    if (!cJSON_IsString(json_data))
    {
        return SDK_FAIL;
    }

    *val = json_data->valuestring;
    return SDK_OK;
}

/**
* @brief 获取cjson的obj
* @param[in] json                     [cjson格式的数据]
* @param[in] key                      [名称]
* @param[out] val                     [数据]
* @return int                         [成功/失败]
*/
int vesync_json_get_obj(cJSON *json, const char *key, cJSON **val)
{
    VCOM_NULL_PARAM_CHK(json, return SDK_FAIL);
    VCOM_NULL_PARAM_CHK(key, return SDK_FAIL);
    VCOM_NULL_PARAM_CHK(val, return SDK_FAIL);

    cJSON* json_data = cJSON_GetObjectItemCaseSensitive(json, key);
    if (!cJSON_IsObject(json_data))
    {
        return SDK_FAIL;
    }

    *val = json_data;
    return SDK_OK;
}



/**
* @brief 直接按照标准缩进格式打印cjson数据，内部实现转换
* @param json                     [cjson格式的数据]
*/
void vesync_json_print(cJSON *json)
{
#if defined(PR_FW_TYPE) && (PR_FW_TYPE == 0)
    VCOM_NULL_PARAM_CHK(json, return );

    char *out = cJSON_Print(json);
    if (NULL != out)
    {
        SDK_LOG(LOG_INFO, "\n%s\n", out);
        VCOM_SAFE_FREE(out);
    }
#else
    UNUSED(json);
#endif
}
