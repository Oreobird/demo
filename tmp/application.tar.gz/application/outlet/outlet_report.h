/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        outlet_report.h
 * @brief       outlet report应用
 * @author      Joshua
 * @date        2021-06-18
 */

#ifndef __OUTLET_REPORT_H__
#define __OUTLET_REPORT_H__

#include <stdbool.h>

#include "outlet_schedule.h"
#include "outlet_timing.h"
#include "outlet_board.h"


#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief   上报模块初始化
 * @param   无
 * @return  void
 */
void outlet_report_init(void);

/**
 * @brief 获取开关变化的原因
 * @param      void
 * @return     const char*          [开关开启/关闭的原因]
 */
const char* outlet_get_switch_change_reason(void);

/**
 * @brief 开关变化的原因
 * @param[in]  rsn          [开关开启/关闭的原因]
 * @return     void         [none]
 */
void outlet_set_switch_change_reason(const char* rsn);

/**
 * @brief 设备开关状态变化，通知云端(http://34.194.32.46:8080/doc/POgSBTDFF)，方法名：updateOnOffV2
 * @param[in]  on               [开启(true)/关闭(false)]
 * @return     int              [成功/失败]
 */
int outlet_report_on_off(bool on);

/**
 * @brief timer执行结果上报(http://34.194.32.46:8080/doc/BVH3a8uib)， deviceLogReport
 * @param[in]  switch_timer_t   [开关timer结构体]
 * @param[in]  ret              [开关timer执行结果]
 * @param[in]  p_err_msg        [开关timer执行失败原因]
 * @return     int              [成功/失败]
 */
int outlet_report_timing_exec(outlet_timing_t *p_timer, uint8_t ret, char *p_err_msg);

/**
 * @brief Schedule执行结果上报(http://34.194.32.46:8080/doc/BVH3a8uib)， deviceLogReport
 *
 * @param[in] sche_id   [Schedule配置项ID]
 * @param[in] type      [Schedule类型]
 * @param[in] repeat    [重复配置]
 * @param[in] p_app_cfg [APP的Action相关配置]
 * @param[in] ret       [执行的返回码]
 * @param[in] p_err_msg [指向失败的原因字符串]
 * @return int          [成功/失败]
 */
int outlet_report_schedule_exec(uint32_t sche_id, uint8_t type, uint8_t repeat,
                                outlet_sche_app_cfg_t *p_app_cfg, uint8_t ret, char *p_err_msg);

/**
 * @brief Away执行结果上报(http://34.194.32.46:8080/doc/BVH3a8uib)， deviceLogReport
 *
 * @param[in] p_rand_time_points [当前执行的随机时间点表]
 * @param[in] time_point_num     [随机时间点的数量]
 * @param[in] repeat             [重复配置]
 * @param[in] exec_cnt           [执行次数]
 * @param[in] p_action           [执行事件动作描述]
 * @param[in] result             [执行结果]
 * @param[in] p_err_msg          [执行错误的描述信息]
 * @return int                   [成功/失败]
 */
int outlet_report_away_exec(uint32_t *p_rand_time_points, uint32_t time_point_num, uint8_t repeat,
                            uint32_t exec_cnt, char *p_action, uint8_t result, char *p_err_msg);

#if defined(OUTLET_ELEC_METERING) && (OUTLET_ELEC_METERING == 1)
/**
 * @brief 插座异常上报(https://yapi.vesync.com/project/222/interface/api/4185)， outletFaultReport
 * @return     int              [成功/失败]
 */
int outlet_report_exception(void);

/**
 * @brief 插座省电断开上报(https://yapi.vesync.com/project/222/interface/api/4092)， ELECConsumeProtectReport
 * @return     int              [成功/失败]
 */
int outlet_report_elec_save_exec(void);

/**
 * @brief 插座功率触发断开上报(https://yapi.vesync.com/project/222/interface/api/4093)， powerThresholdProtectReport
 * @param[in]  type             [触发类型，0——大于最大功率触发，1——小于最小功率触发]
 * @return     int              [成功/失败]
 */
int outlet_report_pow_trig_exec(uint8_t type);

/**
 * @brief 插座电量统计上报(https://yapi.vesync.com/project/222/interface/api/4091)， reportELECConsumePerDay
 * @param[in]  elec             [用电量]
 * @param[in]  record_ts        [统计当天零点时间戳]
 * @return     int              [成功/失败]
 */
int outlet_report_elec_metering(float elec, uint32_t record_ts);

#if defined(OUTLET_METERING_PRO_REPORT) && (OUTLET_METERING_PRO_REPORT == 1)
/**
 * @brief 插座统计上报(http://54.172.13.146:8080/doc/S9FWJuxcu/edit)， reportMeasuredPUI
 * @return     int              [成功/失败]
 */
int outlet_report_measured_pui(void);
#endif
#endif


#ifdef __cplusplus
}
#endif

#endif



