/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_device_internal.h
 * @brief       设备初始化、配置属性及操作接口
 * @date        2021-05-06
 */

#ifndef __VESYNC_DEVICE_INTERNAL_H__
#define __VESYNC_DEVICE_INTERNAL_H__

#include <stdint.h>
#include <stdbool.h>
#include "vesync_cfg_internal.h"
#include "vesync_device.h"
#include "vesync_common.h"

#ifdef __cplusplus
extern "C" {
#endif

#define DEVICE_PID_LEN      (16)      // pid长度
#define DEVICE_CID_LEN      (32)      // cid长度

#define VESYNC_DEFAULT_FW_VER               "1.0"        // 固件默认版本
#ifndef PR_PLUGNAME_WIFI_SUFFIX
#define VESYNC_WIFI_DEFAULT_PLUGIN_NAME     "mainFw"     // Wi-Fi固件默认plugin name
#else
#define VESYNC_WIFI_DEFAULT_PLUGIN_NAME     ("mainFw-"PR_PLUGNAME_WIFI_SUFFIX)    // Wi-Fi固件默认plugin name
#endif
#define VESYNC_BLE_DEFAULT_PLUGIN_NAME      "bleFw"      // BLE固件默认plugin name
#define VESYNC_MCU_DEFAULT_PLUGIN_NAME      "mcuFw"      // MCU固件默认plugin name
#define VESYNC_MCU2_DEFAULT_PLUGIN_NAME     "mcu2Fw"     // MCU固件默认plugin name
#define VESYNC_MCU3_DEFAULT_PLUGIN_NAME     "mcu3Fw"     // MCU固件默认plugin name
#define VESYNC_INVALID_PLUGIN_NAME          "InvalidType"  // 非法固件plugin name

#define USER_CFG_KEY_CID                    "cfg_cid"                   // CID

#ifdef PR_FAC_RESET_REBOOT_DELAY
#define FAC_RESET_REBOOT_DELAY_MS (vesync_cfg_get_fac_reset_reboot_delay() * 1000)
#else
#define FAC_RESET_REBOOT_DELAY_MS (2000)
#endif

/*
* @brief 设备信息结构体
*/
typedef struct
{
    bool ts_update_disable;                     // 记录是否允许更新时间戳
    char cid[DEVICE_CID_LEN + 4];               // 存储cid
    char account_id[ACCOUNT_ID_STR_LEN + 4];    // account id
    uint8_t total_ota_num;                      // 设备可以进行OTA的固件个数
    vesync_device_clear_data_cb_t dev_clear_data_cb;
    vesync_device_reset_pre_reboot_cb_t dev_reset_pre_reboot_cb;
    dev_fw_info_t fw_info[0];                   // 存储Wi-Fi/MCU/BLE固件信息
} vesync_dev_t;

/**
 * @brief 初始化设备信息
 * @return  int                [成功：SDK_OK，失败：SDK_FAIL]
 */
int vesync_device_init(void);


/**
* @brief 释放设备资源
*/
void vesync_device_deinit(void);


/**
 * @brief  获取配置信息保存扇区，打印固件及设备相关信息等
 */
void vesync_device_print_info(void);

/**
* @brief 更新时间戳
* @param[in] uint32_t           [时间戳]
* @param[in] bool               [true时禁止更新时间戳；false时，允许更新时间戳]
*/
void vesync_device_set_ts_update_status(uint32_t ts, bool disable);

/**
* @brief 更新时间
* @param[in]  utc_time     [utc时间戳]
* @param[in]  time_zone    [时区]
*/
void vesync_device_update_system_time(uint32_t utc_time, int8_t time_zone);

/**
 * @brief  设备仅删除网络配置信息
 */
void vesync_device_delete_net_cfg_data(void);

/**
 * @brief 删除用户（应用层）数据
 * @param[in]  src_type             [消息(动作)来源]
 * @param[in]  rst_type             [删除用户数据的类型]
 */
void vesync_device_delete_user_data(const char* src_type, DEV_RESET_TYPE_E rst_type);

/**
* @brief 时间戳更新标志是否使能
* @return bool               [true时禁止更新时间戳；false时，允许更新时间戳]
*/
bool vesync_device_is_ts_update_disable(void);


#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_DEVICE_INTERNAL_H__ */

