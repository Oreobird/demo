/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_ota_internal.h
 * @brief       ota模块内部接口定义
 * @date        2021-05-19
 */

#ifndef __VESYNC_OTA_INTERNAL_H__
#define __VESYNC_OTA_INTERNAL_H__

#include <stdint.h>

#include "vesync_ota.h"
#include "vesync_timer.h"
#include "vesync_device.h"
#include "vesync_aes.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef PR_OTA_TIMEOUT_TIME
#define OTA_TIMEOUT_TIME         PR_OTA_TIMEOUT_TIME
#else
#define OTA_TIMEOUT_TIME         285000
#endif

#ifdef PR_OTA_STACKSIZE
#define OTA_TASK_STACKSIZE               PR_OTA_STACKSIZE
#else
#define OTA_TASK_STACKSIZE               (1024*4)
#endif

#define OTA_TASK_NAME                   "ota_task"
#define OTA_TASK_PRIO                   TASK_PRIORITY_SOFT_REALTIME

#define VESYNC_OTA_MCU_TIMEOUT_TIME     10000   // OTA升级10s超时

#define FW_VER_HEX_LEN          (3)             // 固件版本十六进制长度
#define FW_VER_STR_MAX_LEN      (16)            // 固件版本字符串最大长度
#define MAX_URL_LEN             (256)           // 下载固件的URL最大长度

#define OTA_STOP_WORK_TIMEOUT   (5000)          //固件升级停止工作超时5秒

// vesync固件头部长度定义
#define MAX_HEADER_LEN          128
#define MAX_VER_LEN             1
#define MD5_LEN                 32
#define MAX_MD5_LEN             (MD5_LEN + 1)
#define MAX_PR_MODEL_LEN        16
#define MAX_SW_VER_LEN          16
#define MAX_HW_VER_LEN          8
#define MAX_COUNTRY_LIST_LEN    32
#define MAX_COUNTRY_CODE_LEN    4
#define HEADER_RESERVED_LEN     (MAX_HEADER_LEN-MAX_VER_LEN-MAX_MD5_LEN-MAX_PR_MODEL_LEN-MAX_SW_VER_LEN-MAX_HW_VER_LEN-MAX_COUNTRY_LIST_LEN)

/*
* @brief OTA头部加密方式
*/
typedef enum
{
    OTA_CRYPT_AES = 1,          // AES加密方式
    OTA_CRYPT_UNKNOWN
} OTA_HEAD_CRYTO_TYPE_E;

/*
* @brief 升级状态
*/
typedef enum
{
    // 状态
    UPG_SUCCESS = 0,             //升级成功
    UPG_FAIL = 1,                //升级过程其他错误失败
    UPG_DNS_FAIL = 3,            //域名解析失败
    UPG_URL_ERR = 4,             // 下发的升级URL错误
    UPG_DOWNLOADING = 5,         // 固件下载中
    UPG_UPGRADING = 6,           // 升级中，包含校验过程
    UPG_IDLE = 7,                // 初始状态

    // 异常错误码
    UPG_HEADER_VER_ERR = 9,      // ota头部版本校验失败
    UPG_LOW_BTRY = 10,           // 电量过低，不可升级
    UPG_MODEL_ILLEGAL = 11,      // model NO非法
    UPG_SW_VER_ERR = 12,         // 软件版本校验失败
    UPG_HW_VER_ERR = 13,         // 硬件版本不支持
    UPG_COUNTRY_CODE_ERR = 14,   // 国家码不支持
    UPG_MD5_FAIL = 15,           // md5校验失败
    UPG_NOT_SUPT= 16,            // 当前设备不可升级(设备不可停止)
    UPG_DL_FAIL = 17,            // 固件下载失败
    UPG_READ_FAIL = 18,          // 从flash读取BLE/MCU固件失败
    UPG_TIME_OUT = 19,           // 升级超时(失败)
    UPG_TRANSFER_TIME_OUT = 20,  // 固件传输超时(串口传输)
    UPG_CHECK_FAIL = 21,         // 固件校验失败, mcu或者ble模块校验失败
    UPG_CONN_FAIL = 22,          // 连接服务器失败
} UPGRADE_STATE_E;

/*
* @brief 升级的指令入口
*/
typedef enum
{
    UPG_EN_WIFI = 0,           // 升级指令入口是Wi-Fi
    UPG_EN_BLE,                // 升级指令入口是BLE
} UPGRADE_ENTRY_E;

/*
* @brief 升级的传输通道
*/
typedef enum
{
    UPG_TR_WIFI = 0,           // 升级传输通道是Wi-Fi
    UPG_TR_BLE,                // 升级传输通道是BLE
} UPGRADE_TRANS_E;

/*
* @brief 升级的模式
*/
typedef enum
{
    UPG_MODE_IDLE = 1,        // 空闲模式升级
    UPG_MODE_NORMAL = 2,      // 标准模式升级
    UPG_MODE_HIGH = 3,        // 强制升级
} UPGRADE_MODE_E;

/*
* @brief 升级相关信息
*/
typedef struct
{
    //uint8_t upgradeId;                    // 下载任务ID
    //uint8_t activeState;                  // 当前指令流状态
    //uint8_t subjectId;                    // 升级主体编号，表示当前要升级
    UPGRADE_TRANS_E upg_trans;              // 升级传输通道，表示从wifi还是蓝牙传输固件
    UPGRADE_ENTRY_E upg_entry;              // 升级指令入口，表示从wifi还是蓝牙接入的指令
    FW_TYPE_E upg_type;                     // 固件类型，表示当前要升级的是wifi、蓝牙、主控MCU
    UPGRADE_STATE_E upg_state;              // 当前升级状态
    uint8_t upg_progress;                   // 下载或者升级进度，0-100
    UPGRADE_MODE_E upg_mode;                // 升级模式
    char fw_ver[FW_VER_STR_MAX_LEN];        // 正在升级的固件版本号，格式：x.x.xx[yyyy]
    char fw_url[MAX_URL_LEN];               // 下载固件的URL
} upgrade_info_t;

/*
* @brief vesync固件头部(共128byte)，
*/
typedef struct
{
    uint8_t ver;                                // 头部版本号
    uint8_t md5[MAX_MD5_LEN];                   // 固件md5(需要先剥离头部)
    uint8_t model[MAX_PR_MODEL_LEN];            // 产品型号(来源立项报告)
    uint8_t sw_ver[MAX_SW_VER_LEN];             // 软件版本
    uint8_t hw_ver[MAX_HW_VER_LEN];             // 硬件版本
    uint8_t country_list[MAX_COUNTRY_LIST_LEN]; // 国家码支持列表(格式：US,EU,CN)，最多11个
    uint8_t reserved[HEADER_RESERVED_LEN];      // 预留字段
} vesync_ota_header_t;

/**
* @brief 保存重连原因
*/
typedef int (*save_reconn_reason_t)(uint32_t reason);

/*
* @brief vesync ota结构体
*/
typedef struct
{
    upgrade_info_t upg_info;                            // 记录升级的信息
    uint8_t upg_code;                                   // 升级错误码
    uint8_t *p_head_md5;                                // 固件头部md5
    vesync_timer_t *timeout_timer;                      // ota超时timer

    vesync_ota_get_status_cb_t get_status_cb;           // 获取设备工作状态回调函数
    vesync_ota_post_cb_t upgrade_post_cb;               // 停止设备工作回调函数
    vesync_ota_pre_cb_t upgrade_pre_cb;                 // 升级前处理回调函数
    vesync_ota_mcu_pre_cb_t mcu_upgrade_pre_cb;         // mcu 升级前回调函数
    vesync_ota_mcu_post_cb_t mcu_upgrade_post_cb;       // mcu 升级后回调函数
    save_reconn_reason_t save_reconn_reason;
} vesync_ota_t;


/**
 * @brief 检测当前设备是否正在升级
 * @return bool                     [正在升级，返回true；不在升级，返回false]
 */
bool vesync_ota_is_upgrading(void);

/**
 * @brief 启动OTA
 * @param[in] upg_info              [升级信息]
 * @return int                      [成功/失败]
 */
int vesync_ota_start(upgrade_info_t upg_info);

/**
 * @brief OTA初始化
 */
void vesync_ota_init(void);

/**
 * @brief 获取设备ota升级前的工作状态
 * @return  bool                     [true:设备处于工作状态, false:设备不处于工作状态，或者OTA时不关心设备工作状态]
 */
bool vesync_ota_get_device_work_status(void);


#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_OTA_INTERNAL_H__ */


