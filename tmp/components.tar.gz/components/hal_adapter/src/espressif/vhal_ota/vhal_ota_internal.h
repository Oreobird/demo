/**
 *  Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vhal_ota_internal.h
 * @brief       esp32/esp8266的ota功能实现
 * @author      Dongri.Su
 * @date        2021-04-23
 */

#ifndef _VHAL_OTA_INTERNAL_H_
#define _VHAL_OTA_INTERNAL_H_

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#include "vhal_ota.h"

#ifdef __cplusplus
extern "C"
{
#endif

#ifdef CONFIG_IDF_TARGET_ESP8266
#define MAX_TCP_BUFF_SIZE (1500)  // 每1包数据长度是1460

/**
 * @brief  ota http解析
 * @note  该定义应该放到平台层，但目前还使用乐鑫的升级程序，先放着hal层
 */
typedef struct
{
    char host[128];
    int  port;
    char path[256];
} vhal_esp_url_t;

/**
 * @brief  ota 升级状态
 * @note   8266平台使用
 */
typedef enum
{
    ESP_OTA_INIT = 0,
    ESP_OTA_PREPARE,
    ESP_OTA_START,
    ESP_OTA_RECVED,
    ESP_OTA_FINISH,
    ESP_OTA_FAILED,
} VHAL_ESP_OTA_STATE_E;

/**
 * @brief  ota 升级状态
 * @note   8266平台使用独立升级函数，非调用库函数，
 */
typedef struct
{
    uint8_t             ota_num;                // OTA分区数量
    uint8_t             update_ota_num;         // OTA升级的分区序号
    VHAL_ESP_OTA_STATE_E    state;              // 升级状态，详见esp_ota_firm_state_t定义
    size_t              content_len;            // http内容的总长度(包括vesync头部)
    size_t              read_bytes;             // 当前读取(接收)的长度
    size_t              write_bytes;            // 已写入的长度
    size_t              ota_size;               // 待写入flash的固件总大小(不包括vesync头部)
    size_t              ota_offset;             // 偏移(第1包数据跳过的字节数)
    size_t              bytes;                  // 当前待写入的长度
    const char          *buf;                   // 当前待写入内容
} vhal_esp8266_ota_t;

/**
 * @brief  OTA执行状态
 */
typedef struct
{
    int32_t header_len;                         // 固件头部长度
    VHAL_OTA_STATE_E status;                    // OTA升级状态
    bool timeout_flag;                          // OTA超时标志位
    mbedtls_md5_context *md5;                   // 存放md5计算中间值
    int socket_id;                              // socket id
    vhal_ota_status_cb_t status_cb;             // OTA状态更新回调函数
    vhal_ota_check_header_cb_t header_check_cb; // 固件头部校验（不包括md5）回调函数
    vhal_ota_check_md5_cb_t md5_check_cb;       // 固件头部md5与固件实际md5比较回调函数
} vhal_esp_ota_status_t;
#else
#define BUFFSIZE (4096) // OTA HTTP Content读取Buffer大小

/**
 * @brief  OTA执行状态
 */
typedef struct
{
    int32_t header_len;                         // 固件头部长度
    VHAL_OTA_STATE_E status;                    // OTA升级状态
    bool timeout_flag;                          // OTA超时标志位
    mbedtls_md5_context *md5;                   // 存放md5计算中间值
    vhal_ota_status_cb_t status_cb;             // OTA状态更新回调函数
    vhal_ota_check_header_cb_t header_check_cb; // 固件头部校验（不包括md5）回调函数
    vhal_ota_check_md5_cb_t md5_check_cb;       // 固件头部md5与固件实际md5比较回调函数
} vhal_esp_ota_status_t;

#ifdef CONFIG_VESYNC_HAL_OTA_ESP_MINI_HTTP_ENABLE
#define HTTP_HOST_LEN (128)             // HTTP hostname字符串缓存大小
#define HTTP_PATH_LEN (256)             // HTTP path字符串缓存大小
#define HTTP_DEFAULT_PORT (80)          // HTTP访问默认端口
#define HTTP_BUF_SIZE (512)             // HTTP Response读取缓存大小
#define HTTP_TCP_RX_TX_TIMEOUT_SEC (5)  // TCP socket发送接收超时的秒参数
#define HTTP_TCP_TX_RX_TIMEOUT_USEC (0) // TCP socker发送接收超时的微秒参数
#define HTTP_SEND_BUF_SIZE (512)        // HTTP Request发送缓存大小

/**
 * @brief HTTP客户端配置数据结构
 */
typedef struct
{
    char *url;                // HTTP Request URL
    int port;                 // HTTP Request Port
    char host[HTTP_HOST_LEN]; // HTTP解析的Hostname
    char path[HTTP_PATH_LEN]; // HTTP解析的Path
} http_client_config_t;

/**
 * @brief HTTP客户端实例定义
 */
struct http_client
{
    bool is_head_fetch;        // HTTP头部是否解析的标志位
    void *http_buf;            // HTTP Response读取缓存
    int buf_len;               // HTTP Response读取缓存中数据的长度
    int buf_ofs;               // HTTP Response数据起始的偏移值
    int ctx_len;               // HTTP Response的Content长度
    int ctx_recv;              // HTTP Response已经接收处理的Content数据
    int result;                // HTTP Request的结果
    int socket;                // HTTP transport socket句柄
    http_client_config_t *cfg; // HTTP client配置
};

// HTTP客户端句柄定义
typedef struct http_client *http_client_handle_t;
#else
#include "esp_http_client.h"

typedef esp_http_client_config_t http_client_config_t;
typedef esp_http_client_handle_t http_client_handle_t;
#endif /* CONFIG_VESYNC_HAL_OTA_ESP_MINI_HTTP_ENABLE */

/**
 * @brief HTTP客户端初始化
 * @param[in] p_http_cfg        [HTTP客户端配置]
 * @return http_client_handle_t [返回一个新建的HTTP客户端句柄，需要释放]
 */
http_client_handle_t http_client_init(http_client_config_t *p_http_cfg);

/**
 * @brief 建立HTTP连接并发送GET请求
 * @param[in] client    [指向HTTP客户端]
 * @return int          [VHAL_OK/VHAL_FAIL]
 */
int http_client_open(http_client_handle_t client);

/**
 * @brief 接收并解析HTTP头部
 * @param[in] client    [指向HTTP客户端]
 * @return int          [VHAL_OK/VHAL_FAIL]
 */
int http_client_fetch_headers(http_client_handle_t client);

/**
 * @brief 读取HTTP响应
 * @param[in] client    [指向HTTP客户端]
 * @param[in] p_buf     [读取的Buffer]
 * @param[in] len       [读取的长度]
 * @return int          [小于0：读取失败；大于等于0：返回最终读取的长度]
 */
int http_client_read(http_client_handle_t client, void *p_buf, int len);

/**
 * @brief 获取HTTP响应内容的长度
 * @param[in] client    [指向HTTP客户端]
 * @return int          [返回的长度]
 */
int http_client_get_content_length(http_client_handle_t client);

/**
 * @brief 清除HTTP客户端会话
 * @param[in] client    [客户端句柄]
 */
int http_cleanup(http_client_handle_t client);

#endif /* CONFIG_IDF_TARGET_ESP8266 */

#ifdef __cplusplus
}
#endif

#endif /* _VHAL_OTA_INTERNAL_H_ */
