/**
 *  Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
 * @file        vhal_utils.c
 * @brief       厂家乐鑫 SDK提供的通用接口封装
 * @author      Dongri.Su
 * @date        2021-04-22
 */

#include <string.h>

#include "esp_system.h"
#include "os.h"
#include "esp_idf_version.h"
#include "esp_wifi.h"
#if defined(CONFIG_IDF_TARGET_ESP32) && defined(ESP_IDF_VERSION)
#if ESP_IDF_VERSION >= ESP_IDF_VERSION_VAL(4, 2, 0)
#include "esp_netif.h"
#endif /* ESP_IDF_VERSION >= ESP_IDF_VERSION_VAL(4, 2, 0) */
#else
#include "tcpip_adapter.h"
#endif /* ESP_IDF_VERSION */

#include "vesync_common.h"
#include "vesync_log.h"
#include "vhal_utils.h"


/**
 * @brief 重启系统
 * @param[in]  arg                  [定时器参数，未使用]
 * @return     void
 */
void vhal_utils_restart(void *arg)
{
    HAL_LOG(LOG_INFO, "Prepare to restart system!\n");
    esp_restart();
}

/**
 * @brief 通过硬件RNG获取随机数
 * @param[in]  p_buf                [用于存储随机数的缓存空间]
 * @param[in]  buf_len              [缓存空间大小]
 * @return     void
 */
void vhal_utils_get_random(uint8_t *p_buf, int32_t buf_len)
{
    os_get_random(p_buf, buf_len);
}

/**
 * @brief 修改dhcp的hostname
 * @param[in]  p_hostname            [新的hostname]
 * @return     void
 */
void vhal_utils_chg_dhcp_hostname(const char *p_hostname)
{
    esp_err_t err;

    if (NULL == p_hostname)
    {
        return;
    }

    // Set the hostname for the default TCP/IP station interface
    if ((err = tcpip_adapter_set_hostname(TCPIP_ADAPTER_IF_STA, p_hostname)) != ESP_OK)
    {
        HAL_LOG(LOG_ERROR, "Err set hostname: %s\n", esp_err_to_name(err));
    }
    else
    {
        const char *name = NULL;
        if ((err = tcpip_adapter_get_hostname(TCPIP_ADAPTER_IF_STA, &name)) != ESP_OK)
        {
            HAL_LOG(LOG_ERROR, "Err get hostname: %s\n", esp_err_to_name(err));
        }
        else
        {
            HAL_LOG(LOG_INFO, "Hostname is %s\n", (name == NULL ? "<None>" : name));
        }
    }
}

/**
 * @brief  获取Wi-Fi模组芯片名称
 * @return     char *               [字符串格式芯片名称]
 */
char *vhal_utils_get_chip_name(void)
{
#if defined(CONFIG_IDF_TARGET_ESP32)
    return "ESP32";
#elif defined(CONFIG_IDF_TARGET_ESP8266)
    return "ESP8266";
#else
    return "Unkown";
#endif
}

/*
 * @brief 获取设备的MAC地址
 * @param[in]  type                 [详见DEVICE_TYPE_MAC_E定义]
 * @param[out] p_buf                [获取到的MAC地址]
 * @param[in]  buf_len              [缓存大小]
 * @return     int                  [执行成功，返回OK；执行失败，返回FAIL]
 */
int vhal_utils_get_dev_mac(VHAL_MAC_TYPE_E type, char *p_buf, int32_t buf_len)
{
    int ret = ESP_FAIL;
    uint8_t mac_addr[MAC_ADDR_STR_MAX_LEN] = {0, };
    wifi_ap_record_t ap_info;
    memset(&ap_info, 0, sizeof(wifi_ap_record_t));

    if (NULL == p_buf)
    {
        HAL_LOG(LOG_ERROR, "Input param is a null pointer!\n");
        return VHAL_FAIL;
    }
    if (buf_len < MAC_ADDR_STR_MAX_LEN)
    {
        HAL_LOG(LOG_ERROR, "Buf len(=%d) is too small!\n", buf_len);
        return VHAL_FAIL;
    }

    if (VHAL_MAC_WIFI_STA == type)
    {
        ret = esp_wifi_get_mac(ESP_MAC_WIFI_STA, mac_addr);
    }
    else if (VHAL_MAC_WIFI_SOFTAP == type)
    {
        ret = esp_wifi_get_mac(ESP_MAC_WIFI_SOFTAP, mac_addr);
    }
    else if (VHAL_MAC_ROUTER == type)
    {
        ret = esp_wifi_sta_get_ap_info(&ap_info);
    }
    else
    {
        HAL_LOG(LOG_ERROR, "Unknow device type = %d!\n", type);
        return VHAL_FAIL;
    }

    if (ESP_OK == ret)
    {
        if (VHAL_MAC_ROUTER == type)
        {
            snprintf(p_buf, buf_len, MACSTR, MAC2STR(ap_info.bssid));
        }
        else
        {
            snprintf(p_buf, buf_len, MACSTR, MAC2STR(mac_addr));
        }
    }
    else
    {
        HAL_LOG(LOG_ERROR, "Get router mac fail, errCode = 0x%x!\n", ret);
        return VHAL_FAIL;
    }

    return VHAL_OK;
}

/*
 * @brief 设备作为STA时，获取分配到的IP。
 * @param[in]  char *               [保存IP的缓存]
 * @param[in]  int                  [缓存大小]
 * @return     char*                [IP地址]
 */
char* vhal_utils_get_sta_ip(char *p_buf, int32_t buf_len)
{
    (void)buf_len;

    tcpip_adapter_ip_info_t sta_ip;
    sta_ip.ip.addr = 0;

    tcpip_adapter_get_ip_info(TCPIP_ADAPTER_IF_STA, &sta_ip);
    snprintf(p_buf, buf_len, "%s", ip4addr_ntoa(&sta_ip.ip));

    return ip4addr_ntoa(&sta_ip.ip);
}


