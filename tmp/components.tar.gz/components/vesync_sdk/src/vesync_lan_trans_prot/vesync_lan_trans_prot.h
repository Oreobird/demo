/**
 * Copyright © Vesync Technologies Co.Ltd. 2019-2021. All rights reserved.
 * @file        vesync_lan_trans_prot.h
 * @brief       设备与APP局域网通讯协议头文件
 * @author      Dongri.Su
 * @date        2020-01-14
 */

#ifndef _VESYNC_LAN_TRANS_PROT_H_
#define _VESYNC_LAN_TRANS_PROT_H_

#include <string.h>
#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

// LAN协议头定义
#define LAN_PROT_HEADER_LEN         8       // 局域网通信协议头部长度
#define LAN_PROT_VER                0x01    // 局域网通信协议，协议版本默认值0x01
#define LAN_PROT_SERV_TYPE          0x01    // 局域网通信协议，业务类型默认值0x01


// LAN data段定义
#define DATA_FLAG_SECURITY_NO       0x00    // 高4bit, 0000标识未加密
#define DATA_FLAG_SECURITY_AES      0x10    // 高4bit, 0001标识采用上文中定义的加密算法RSA1024/AES128/CBC-PKCS1Padding.
#define DATA_FLAG_NETCFG_VER        0x2     // 低4bit，配网业务版本为0010


/*
 * @brief  局域网TCP/UDP通信协议
 * @note   参考：http://wiki.vesync.com:8090/pages/viewpage.action?pageId=52592791
 */
typedef struct
{
    uint8_t protocol;                   // 协议版本(Protocol), 1byte
    uint8_t serv_type;                  // 业务类型(ServiceType), 1byte
    uint16_t seq_id;                    // 序列号，从0开始自增(SequenceId), 1byte
    uint32_t data_len;                  // 数据包长度（Data部分的字节数，采用网络字节序）, 4byte
    uint8_t p_data[0];                     // 数据(包括业务数据头部)
} lan_trans_prot_t;

/**
* @brief    tcp数据包处理回调函数
* @param[in]  *p_frame  [完整数据包buffer]
* @param[in]  frame_len [数据包长度]
*/
typedef void (*vesync_tcp_parse_cb_t)(uint8_t *p_frame, uint32_t frame_len);

/**
* @brief    tcp数据帧解析
* @param[in]  *p_frame  [数据buffer]
* @param[in]  frame_len [数据长度]
* @param[in]  cb        [数据处理回调函数]
* @return  int          [下次buffer写入偏移]
*/
int vesync_tcp_data_parse(uint8_t *p_frame, uint32_t frame_len, vesync_tcp_parse_cb_t cb);

/**
 * @brief  局域网通信协议解析
 * @param[in]  p_frame              [原始数据]
 * @param[in/out]  p_data_len       [输入时，为帧长度(包括头部)；输出时，为数据长度(不包含头部)]
 * @return     int                  [解析的结果，成功/失败]
 */
int vesync_lan_trans_prot_parse(uint8_t *p_frame, uint32_t *p_data_len);

/**
 * @brief 局域网通信协议帧封包
 * @param[out] p_frame              [保存输出结果]
 * @param[in]  p_data               [输入数据内容]
 * @param[in/out] p_data_len        [输入时，表示p_in_data的长度；输出时，表示p_frame的长度]
 * @param[in]  reply                [true表示回复帧；false发送帧]
 * @return     int                  [协议封包结果，成功/失败]
 * @note       [回复帧序列号不变，主动发送的帧，序号在现有序号基础上增加1]
 */
int vesync_lan_trans_prot_pack(  uint8_t *p_frame, uint8_t *p_data, uint32_t *p_data_len, bool reply);

#ifdef __cplusplus
}
#endif

#endif /* _VESYNC_LAN_TRANS_PROT_H_ */
