/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
* @file         ledstrip_flash.h
* @brief        存储数据定义
* @author       Joshua
* @date         2021-12-2
*/

#include <stdint.h>

#ifndef __LEDSTRIP_FLASH_H__
#define __LEDSTRIP_FLASH_H__

#ifdef __cplusplus
extern "C" {
#endif

#ifndef LIGHT_SEGMENT_MAX_NUM
#define LIGHT_SEGMENT_MAX_NUM   (15)
#endif

/*
* @brief 存储的flash数据
*/
typedef struct
{
    light_color_t seg_param[0];  // 多段彩光灯效数据指针
} extra_cfg_t;


/**
 * @brief 配置数据key 定义
 */
typedef enum
{
    KEY_SEG_LIGHT_PARAM = EXTRA_CFG_SLOT,            // 多段彩光灯效参数
} EXTRA_CFG_KEY_E;

#ifdef __cplusplus
}
#endif

#endif

