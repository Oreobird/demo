/**
*Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file    ledstrip_led.c
* @brief   灯带led控制和配置
* @author  Lind
*@date     2021-08-31
*/

#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
#include <stdio.h>
#include <math.h>

#include "vhal_led.h"

#include "vesync_common.h"
#include "vesync_log.h"
#include "vesync_memory.h"
#include "vesync_task.h"
#include "vesync_queue.h"
#include "vesync_device.h"

#include "ledstrip_led.h"
#include "ledstrip_button.h"
#include "ledstrip.h"
#include "ledstrip_flash.h"
#include "ledstrip_report.h"
#include "ledstrip_bypass.h"


static ls_status_t s_ls_status; // led灯带灯光状态信息
static ls_led_changing_status_t s_ls_changing_status;
static ls_led_diverse_param_t *s_led_scene = NULL;
static ls_led_hsv_param_t *s_led_hsv = NULL;
static int task_cycle = 20; // 任务最长执行间隔一次
static uint8_t s_gradient_step = 10;        // 渐变步数 渐变时间 = task_cycle*s_gradient_step
static bool s_ls_gradient_enable = true;

static vesync_queue_t *s_led_event_queue = NULL;
static ls_led_hsv_t s_ls_hsv_init_color = {100, 50, 0, 10000, 100};
static ls_led_rgb_t s_ls_rgb_init_color = {50, 0, 0, 0, 0};
static ls_led_rgb_t s_ls_off = {0, 0, 0, 0, 0};

/**
* @brief 色温亮度转为CW WW的占空比率
* @param[in]  *pst_all_color    [模式颜色参数]
* @param[out]  CW               [冷光占空比]
* @param[out]  WW               [暖光占空比]
*/
static void ls_led_conv_KL2pwm(ls_led_hsv_t *pst_all_color, uint16_t *cw_pwm, uint16_t *ww_pwm)
{
    uint32_t colortemp = pst_all_color->colortemp;
    uint32_t brightness = pst_all_color->brightness;
    *cw_pwm = brightness * colortemp * 1024 / 10000;
    *ww_pwm = brightness * (100 - colortemp) * 1024 / 10000;
    if (*cw_pwm == 0 && *ww_pwm == 0)
    {
        if (pst_all_color->colortemp >= 50)
        {
            *cw_pwm = 1;
        }
        if (pst_all_color->colortemp <= 50)
        {
            *ww_pwm = 1;
        }
    }
}

/**
* @brief  hsv2rgb转换
* @param[in]  *pst_all_color    [模式颜色参数]
* @param[out]  rgb_pwm[3]       [输出的rgb的pwm占空比数组]
*/
static void ls_led_conv_hsv2rgb(ls_led_hsv_t *pst_all_color, uint16_t rgb_pwm[3])
{
    int i;
    float f, p, q, t, v, s, h;
    h = pst_all_color->H;
    s = pst_all_color->S;
    v = pst_all_color->V;
    if (v == 0)
    {
        APP_LOG(LOG_WARN, "Value is 0 !!\n");
    }

    v = v / 100 * 1024;
    if(s == 0)
    {
        // achromatic (grey)
        rgb_pwm[0] = rgb_pwm[1] = rgb_pwm[2] = v;
        return;
    }
    h  = h / 1667;            // sector 0 to 5
    i = floor(h);
    f = h - i;          // factorial part of h
    p = v * (1 - s / 10000);
    q = v * (1 - s / 10000 * f);
    t = v * (1 - s / 10000 * (1 - f));
    switch (i)
    {
        case 0:
            rgb_pwm[0] = (uint16_t)v;
            rgb_pwm[1] = (uint16_t)t;
            rgb_pwm[2] = (uint16_t)p;
            break;
        case 1:
            rgb_pwm[0] = (uint16_t)q;
            rgb_pwm[1] = (uint16_t)v;
            rgb_pwm[2] = (uint16_t)p;
            break;
        case 2:
            rgb_pwm[0] = (uint16_t)p;
            rgb_pwm[1] = (uint16_t)v;
            rgb_pwm[2] = (uint16_t)t;
            break;
        case 3:
            rgb_pwm[0] = (uint16_t)p;
            rgb_pwm[1] = (uint16_t)q;
            rgb_pwm[2] = (uint16_t)v;
            break;
        case 4:
            rgb_pwm[0] = (uint16_t)t;
            rgb_pwm[1] = (uint16_t)p;
            rgb_pwm[2] = (uint16_t)v;
            break;
        default:
            rgb_pwm[0] = (uint16_t)v;
            rgb_pwm[1] = (uint16_t)p;
            rgb_pwm[2] = (uint16_t)q;
            break;
    }
}

/**
* @brief 设置LED颜色组合，HSV,app界面设置时专用
* @param[in]  *pst_all_color    [所有颜色参数]
* @param[in]  mode             [颜色组合模式]
* @return  uint32_t             [APP_OK/APP_FAIL]
*/
static uint32_t ls_led_set_hsv_color(ls_led_hsv_t *pst_all_color, LS_HSV_MODE_E mode)
{
    if (NULL == pst_all_color)
    {
        APP_LOG(LOG_ERROR, "Invalid parameter! \n");
        return APP_FAIL;
    }
    uint16_t cw_duty = 0, ww_duty = 0;
    uint16_t rgb_pwm[3];
    memset(rgb_pwm, 0, sizeof(rgb_pwm));
    switch (mode)
    {
        case LS_LED_SET_WHITE:                      // 设置白光
            ls_led_conv_KL2pwm(pst_all_color, &cw_duty, &ww_duty);

            vhal_led_set_duty_bits(LS_CW_CH, cw_duty, 1024);
            vhal_led_set_duty_bits(LS_WW_CH, ww_duty, 1024);
            vhal_led_set_duty(LS_R_CH, 0);
            vhal_led_set_duty(LS_G_CH, 0);
            vhal_led_set_duty(LS_B_CH, 0);
            break;
        case LS_LED_SET_COLOR:                      // 设置彩光
            ls_led_conv_hsv2rgb(pst_all_color, rgb_pwm);
            vhal_led_set_duty(LS_CW_CH, 0);
            vhal_led_set_duty(LS_WW_CH, 0);
            vhal_led_set_duty_bits(LS_R_CH, rgb_pwm[0], 1024);
            vhal_led_set_duty_bits(LS_G_CH, rgb_pwm[1], 1024);
            vhal_led_set_duty_bits(LS_B_CH, rgb_pwm[2], 1024);
            break;
        case LS_LED_SET_ALL:                      // 设置5种led
            ls_led_conv_hsv2rgb(pst_all_color, rgb_pwm);
            ls_led_conv_KL2pwm(pst_all_color, &cw_duty, &ww_duty);
            vhal_led_set_duty_bits(LS_CW_CH, cw_duty, 1024);
            vhal_led_set_duty_bits(LS_WW_CH, ww_duty, 1024);
            vhal_led_set_duty_bits(LS_R_CH, rgb_pwm[0], 1024);
            vhal_led_set_duty_bits(LS_G_CH, rgb_pwm[1], 1024);
            vhal_led_set_duty_bits(LS_B_CH, rgb_pwm[2], 1024);
            break;
        default:
            APP_LOG(LOG_ERROR, "led set mode invalid  \n");
            break;
    }
    return APP_OK;
}

/**
* @brief 设置LED颜色组合，白光和RGB，情景模式专用
* @param[in]  *pst_all_color    [所有颜色参数]
* @param[in]  mode              [颜色组合模式]
* @return  uint32_t             [APP_OK/APP_FAIL]
*/
static uint32_t ls_led_set_rgb_color(ls_led_rgb_t *color_pwm, uint16_t rgb_duty_rst)
{
    if (NULL == color_pwm)
    {
        APP_LOG(LOG_ERROR, "Invalid parameter! \n");
        return APP_FAIL;
    }
    vhal_led_set_duty_bits(LS_CW_CH, color_pwm->CW, rgb_duty_rst);
    vhal_led_set_duty_bits(LS_WW_CH, color_pwm->WW, rgb_duty_rst);
    vhal_led_set_duty_bits(LS_R_CH, color_pwm->R, rgb_duty_rst);
    vhal_led_set_duty_bits(LS_G_CH, color_pwm->G, rgb_duty_rst);
    vhal_led_set_duty_bits(LS_B_CH, color_pwm->B, rgb_duty_rst);
    return APP_OK;
}


/**
* @brief 计算一个渐变参数的下一个取值
* @param[in]  *change_mode          [渐变参数]
* @param[in]  cur_param             [当前参数]
* @param[in]  tgt_param             [目标参数]
* @return  uint8_t                  [下一个取值]
*/
static uint16_t ls_led_next_param(uint8_t remind_step, uint16_t cur_param, uint16_t tgt_param)
{
    if (1 == remind_step || cur_param == tgt_param)
    {
        return tgt_param;
    }

    bool trend = (tgt_param >= cur_param) ? true : false;  // 判断变化趋势
    uint16_t step_size = trend ? (tgt_param - cur_param) / remind_step:
                                 (cur_param - tgt_param) / remind_step;
    if (0 == step_size)
    {
        return tgt_param;
    }
    else if (true == trend)         // 参数由小变大
    {
        return cur_param + step_size;
    }
    else if (false == trend)        // 由大变小
    {
        return cur_param - step_size;
    }
    return tgt_param;
}

/**
* @brief    渐变切换灯效，最后一步渐变不执行
* @param[in]  gradient_step             [渐变步数]
* @return     uint32_t              [执行结果 APP_OK:渐变结束， APP_FAIL:还在执行中]
*/
uint32_t ls_led_gradient(uint8_t gradient_step)
{
    static ls_led_rgb_t cur_color, tgt_color;
    static uint8_t cur_step = 1;

    if (cur_step == 1)
    {
        uint16_t rgb_pwm[3], cw, ww;
        memset(&cur_color, 0, sizeof(cur_color));
        ls_led_conv_hsv2rgb(&(s_ls_status.cur_color), rgb_pwm);
        ls_led_conv_KL2pwm(&(s_ls_status.cur_color), &cw, &ww);
        cur_color.CW = cw;
        cur_color.WW = ww;
        cur_color.R = rgb_pwm[0];
        cur_color.G = rgb_pwm[1];
        cur_color.B = rgb_pwm[2];

        memset(&tgt_color, 0, sizeof(tgt_color));
        if (s_ls_status.model == LS_MODE_WHITE)
        {
            ls_led_conv_KL2pwm(&(s_led_hsv->color), &cw, &ww);
            tgt_color.CW = cw;
            tgt_color.WW = ww;
        }
        else if (s_ls_status.model == LS_MODE_COLOR)
        {
            ls_led_conv_hsv2rgb(&(s_led_hsv->color), rgb_pwm);
            tgt_color.R = rgb_pwm[0];
            tgt_color.G = rgb_pwm[1];
            tgt_color.B = rgb_pwm[2];
        }
    }

    cur_color.CW = ls_led_next_param(gradient_step - cur_step, cur_color.CW, tgt_color.CW);
    cur_color.WW = ls_led_next_param(gradient_step - cur_step, cur_color.WW, tgt_color.WW);
    cur_color.R = ls_led_next_param(gradient_step - cur_step, cur_color.R, tgt_color.R);
    cur_color.G = ls_led_next_param(gradient_step - cur_step, cur_color.G, tgt_color.G);
    cur_color.B = ls_led_next_param(gradient_step - cur_step, cur_color.B, tgt_color.B);

    // 设置灯光
    ls_led_set_rgb_color(&cur_color, 1024);
    cur_step++;
    if (cur_step == gradient_step)
    {
        cur_step = 1;
        return APP_OK;
    }
    return APP_FAIL;
}


/**
* @brief    rgb渐变呼吸灯
* @param[in]  *pst_breathing_param  [呼吸灯参数]
* @return     uint32_t              [执行结果 APP_OK:执行成功，还在执行中 APP_FAIL:执行失败/执行结束]
*/
uint32_t ls_led_rgb_color_breating(ls_led_diverse_param_t *pst_breathing_param)
{
    if (NULL == pst_breathing_param || NULL == pst_breathing_param->mode_head)
    {
        APP_LOG(LOG_ERROR, "Invalid parameter! \n");
        return APP_FAIL;
    }
    ls_led_rgb_t *tgt_color = NULL;
    ls_led_rgb_t next_color;
    memset(&next_color, 0, sizeof(ls_led_rgb_t));

    if (pst_breathing_param != s_ls_changing_status.last_mode)
    {
        s_ls_changing_status.last_mode = pst_breathing_param;
        s_ls_changing_status.cur_node = pst_breathing_param->first_node;
        s_ls_changing_status.remind_step = pst_breathing_param->step_num;
        s_ls_changing_status.cur_color = *(pst_breathing_param->mode_head + pst_breathing_param->first_node);
        s_ls_changing_status.remind_times = pst_breathing_param->times;

        // 设置灯光
        if (ls_led_set_rgb_color(pst_breathing_param->mode_head + s_ls_changing_status.cur_node, 100))
        {
            APP_LOG(LOG_ERROR, "set color error! \n");
            return APP_FAIL;
        }
        else
        {
            s_ls_changing_status.remind_step--;
            return APP_OK;
        }
    }
     // 呼吸灯效节点切换
    if (0 == s_ls_changing_status.remind_step)
    {
        s_ls_changing_status.cur_node++;
        s_ls_changing_status.remind_step = pst_breathing_param->step_num - 1;
    }
    if (s_ls_changing_status.cur_node == pst_breathing_param->node_num)
    {
        // 一次灯效周期结束
       if (0 != pst_breathing_param->times)
        {
            s_ls_changing_status.remind_times--;
            if (0 == s_ls_changing_status.remind_times)
            {
                // 执行结束
                s_ls_status.diverse_flag = false;
                s_ls_changing_status.last_mode = NULL;
                return APP_FAIL;
            }
        }
        s_ls_changing_status.cur_node = 0;
    }
    tgt_color = pst_breathing_param->mode_head + (s_ls_changing_status.cur_node + 1) % pst_breathing_param->node_num;

    next_color.CW = ls_led_next_param(s_ls_changing_status.remind_step, s_ls_changing_status.cur_color.CW, tgt_color->CW);
    next_color.WW = ls_led_next_param(s_ls_changing_status.remind_step, s_ls_changing_status.cur_color.WW, tgt_color->WW);
    next_color.R = ls_led_next_param(s_ls_changing_status.remind_step, s_ls_changing_status.cur_color.R, tgt_color->R);
    next_color.G = ls_led_next_param(s_ls_changing_status.remind_step, s_ls_changing_status.cur_color.G, tgt_color->G);
    next_color.B = ls_led_next_param(s_ls_changing_status.remind_step, s_ls_changing_status.cur_color.B, tgt_color->B);
    // 设置灯光
    if (ls_led_set_rgb_color(&next_color, 100))
    {
        APP_LOG(LOG_ERROR, "set color error! \n");
        return APP_FAIL;
    }
    else
    {
        s_ls_changing_status.remind_step--;
        s_ls_changing_status.cur_color = next_color;
        return APP_OK;
    }
}


/**
* @brief    rgb渐变呼吸灯 交替时有重叠 重叠时间不定，节点参数为每种颜色组合的最大占空比，变化中最低占空比为0
* @param[out]  *pst_breathing_param     [呼吸灯参数]
* @param[int]  overlap_step             [重叠步数]
* @return  uint32_t                     [执行结果 APP_OK:执行成功，还在执行中 APP_FAIL:执行失败/执行结束]
*/
uint32_t ls_led_rgb_overlap_breathing(ls_led_diverse_param_t *pst_breathing_param, uint8_t overlap_step)
{
    if (NULL == pst_breathing_param || NULL == pst_breathing_param->mode_head)
    {
        APP_LOG(LOG_ERROR, "Invalid parameter! \n");
        return APP_FAIL;
    }

    static uint8_t trend = 0;  // 0 时渐灭，1 时渐亮

    if (pst_breathing_param != s_ls_changing_status.last_mode)
    {
        s_ls_changing_status.last_mode = pst_breathing_param;
        s_ls_changing_status.cur_node = pst_breathing_param->first_node;
        s_ls_changing_status.remind_step = pst_breathing_param->step_num;
        s_ls_changing_status.cur_color = *(pst_breathing_param->mode_head + pst_breathing_param->first_node);
        s_ls_changing_status.remind_times = pst_breathing_param->times;
        trend = 0;

        // 设置灯光
        if (ls_led_set_rgb_color(&s_ls_changing_status.cur_color, 100))
        {
            APP_LOG(LOG_ERROR, "set color error! \n");
        }
        else
        {
            s_ls_changing_status.remind_step--;
            return APP_OK;
        }
    }

    uint16_t *color = &(s_ls_changing_status.cur_color.CW);

    if (0 == s_ls_changing_status.remind_step && 0 ==trend )
    {
        // 前一灯效已经渐灭到0，后一灯效已经亮到交替值
        trend = 1;  // 交替结束真正开始渐亮
        s_ls_changing_status.cur_node++;
        s_ls_changing_status.remind_step = overlap_step;
    }
    else if (pst_breathing_param->step_num == s_ls_changing_status.remind_step && 1 ==trend)
    {
        // 已经渐亮到指定参数
        trend = 0;  // 开始渐灭
    }
    if (s_ls_changing_status.cur_node == pst_breathing_param->node_num)
    {
        // 一次灯效周期结束
        if (0 != pst_breathing_param->times)
        {
            s_ls_changing_status.remind_times--;
            if (0 == s_ls_changing_status.remind_times)
            {
                // 执行结束
                s_ls_status.diverse_flag = false;
                s_ls_changing_status.last_mode = NULL;
                return APP_FAIL;
            }
        }
        s_ls_changing_status.cur_node = 0;
    }

    for (uint8_t i = 0; i < 5; i++)
    {
        // 计算当前模式颜色
        if (0 == *(color + i))
        {
            // 当前模式此颜色不亮
            continue;
        }
        uint16_t step = *(color + i) / s_ls_changing_status.remind_step;   // 丢失精度
        step = step > 0 ? step : 1;
        if (trend)
        {
            *(color + i) += step;
        }
        else
        {
            *(color + i) -= step;
        }
    }
    if (overlap_step > s_ls_changing_status.remind_step)
    {
        // 如果进入重叠渐变，则比较每个灯渐亮和渐灭的亮度，取高的显示
        uint16_t next_mode_steps = overlap_step - s_ls_changing_status.remind_step;
        uint16_t *next_mode_color = &((pst_breathing_param->mode_head +  // 下一节点模式冷光地址
                                       (s_ls_changing_status.cur_node + 1) % pst_breathing_param->node_num)->CW);
        uint16_t temp_color;
        for (uint8_t i = 0; i < 5; i++)
        {
            // 与下一灯效的占空比比较，取较大的
            temp_color = (*(next_mode_color + i)) / pst_breathing_param->step_num * next_mode_steps ; // 丢失精度
            *(color + i) = *(color + i) > temp_color ? *(color + i) : temp_color;
        }
    }

    // 设置灯光
    if (ls_led_set_rgb_color(&s_ls_changing_status.cur_color, 100))
    {
        APP_LOG(LOG_ERROR, "set color error! \n");
        return APP_FAIL;
    }
    else
    {
        if (trend)
        {
            s_ls_changing_status.remind_step++;
        }
        else
        {
            s_ls_changing_status.remind_step--;
        }
    }
    return APP_OK;
}


/**
* @brief    rgb颜色循环,常亮
* @param  *pst_switch_param         [参数]
* @return  uint32_t                 [执行结果 APP_OK:执行成功，还在执行中 APP_FAIL:执行失败/执行结束]
*/
uint32_t ls_led_rgb_color_switch(ls_led_diverse_param_t *pst_switch_param)
{
    if (NULL == pst_switch_param || NULL == pst_switch_param->mode_head )
    {
        APP_LOG(LOG_ERROR, "Invalid parameter! \n");
        return APP_FAIL;
    }

    if (pst_switch_param != s_ls_changing_status.last_mode)
    {
        s_ls_changing_status.last_mode = pst_switch_param;
        s_ls_changing_status.cur_node = pst_switch_param->first_node;
        s_ls_changing_status.remind_step = pst_switch_param->step_num;
        s_ls_changing_status.remind_times = pst_switch_param->times;
        if (ls_led_set_rgb_color(pst_switch_param->mode_head + s_ls_changing_status.cur_node, 100))
        {
            APP_LOG(LOG_ERROR, "set color error! \n");
            return APP_FAIL;
        }
    }
     // 常亮灯效节点切换
    if (0 == s_ls_changing_status.remind_step)
    {
        s_ls_changing_status.cur_node++;
        s_ls_changing_status.remind_step = pst_switch_param->step_num;

        if (s_ls_changing_status.cur_node == pst_switch_param->node_num)
        {
            // 一次灯效周期结束
            if (0 != pst_switch_param->times)
            {
                s_ls_changing_status.remind_times--;
                if (0 == s_ls_changing_status.remind_times)
                {
                    // 执行结束
                    s_ls_status.diverse_flag = false;
                    s_ls_changing_status.last_mode = NULL;
                    return APP_FAIL;
                }
            }
            s_ls_changing_status.cur_node = 0;
        }
        // 设置灯光
        if (ls_led_set_rgb_color(pst_switch_param->mode_head + s_ls_changing_status.cur_node, 100))
        {
            APP_LOG(LOG_ERROR, "set color error! \n");
            return APP_FAIL;
        }
    }
    else
    {
        s_ls_changing_status.remind_step--;
    }

    return APP_OK;
}


/**
 * @brief  给led控制任务发通知
 * @param[in]   event_id        [通知消息]
 * @return     int              [成功：SDK_OK，失败：SDK_FAIL]
 */
static int ls_led_task_notify(ls_led_ev_t *ev)
{
    int ret = vesync_queue_send(s_led_event_queue, ev, VESYNC_OS_NO_WAIT);
    if (ret != VOS_OK)
    {
        APP_LOG(LOG_ERROR, "Event publish failed\n");
        return APP_FAIL;
    }

    return APP_OK;
}

/**
* @brief ledstrip led加载flash配置
* @return  int      [成功APP_OK/失败APP_FAIL]
*/
static int ls_led_install_memory(void)
{
    ls_flash_data_t flash_data;
    memset(&flash_data, 0, sizeof(flash_data));
    if (ls_read_config(&flash_data))
    {
        APP_LOG(LOG_ERROR, "Read flash failed! \n");
        return APP_FAIL;
    }
    else
    {
        if (flash_data.init_flag == false)
        {
            return APP_FAIL;
        }
        else
        {
            ls_led_hsv_param_t *hsv_data = (ls_led_hsv_param_t*)vesync_malloc(sizeof(ls_led_hsv_param_t));
            if (hsv_data == NULL)
            {
                APP_LOG(LOG_ERROR, "Not enough memory \n");
                return APP_FAIL;
            }
            memset(hsv_data, 0, sizeof(ls_led_hsv_param_t));
            // 读取断电前的配置，
            hsv_data->color = flash_data.app_color;
            s_led_hsv = hsv_data;
            s_ls_status.status = flash_data.status;
            s_ls_status.model = flash_data.model;
            s_ls_status.last_app_mode = flash_data.last_app_mode;
            s_ls_status.switch_flag = true;
            s_ls_status.app_color = flash_data.app_color;
            s_led_hsv->color = flash_data.app_color;
            if (s_ls_status.model == LS_MODE_SCENE && flash_data.scene_cnt == 0)
            {
                // 上一次为情景模式时，按键次数为0，初始化为第一个情景模式，意外情况：配网断电，产测断电
                ls_set_button_cnt(1);
            }
            else
            {
                ls_set_button_cnt(flash_data.scene_cnt);
            }

        }
    }

    ls_report_set_chg_rsn(STAT_CHG_RSN_FLASH_STR);
    return APP_OK;
}

/**
* @brief       模式设置
* @param[in]  p_param     [参数]
* @param[in]  src         [来源]
*/
void ls_led_set_led(void *p_param, LS_LED_ACT_SRC_E src)
{
    ls_led_ev_t ev;
    memset(&ev, 0, sizeof(ls_led_ev_t));
    ev.id =LS_LED_EV_SET_LED;
    ev.act_src = src;
    ev.p_data = p_param;
    if (APP_FAIL == ls_led_task_notify(&ev))
    {
        APP_LOG(LOG_ERROR, "set led fail\n");
    }
}

/**
* @brief  获取当前状态
* @param[in]  type                 [获取的颜色参数，false时color为app的设置参数，true时为当前颜色参数]
* @param[out]  *status             [模式参数]
*/
void ls_led_get_status(bool type, ls_led_status_t *status)
{
    if (NULL == status)
    {
        APP_LOG(LOG_ERROR, "NULL pointer! \n");
        return;
    }

    memset(status, 0, sizeof(ls_led_status_t));
    status->status = s_ls_status.status;
    status->model = s_ls_status.model;
    status->last_mode = s_ls_status.last_app_mode;
    if (type)
    {
        (status->color).colortemp = s_ls_status.cur_color.colortemp;
        (status->color).brightness = s_ls_status.cur_color.brightness;
        (status->color).H = s_ls_status.cur_color.H;
        (status->color).S= s_ls_status.cur_color.S;
        (status->color).V = s_ls_status.cur_color.V;
    }
    else
    {
        (status->color).colortemp = s_ls_status.app_color.colortemp;
        (status->color).brightness = s_ls_status.app_color.brightness;
        (status->color).H = s_ls_status.app_color.H;
        (status->color).S = s_ls_status.app_color.S;
        (status->color).V = s_ls_status.app_color.V;
    }

}


/**
* @brief    关闭灯带
*/
void ls_led_off(LS_LED_ACT_SRC_E src)
{
    ls_led_ev_t ev;
    memset(&ev, 0, sizeof(ls_led_ev_t));
    ev.id =LS_LED_EV_OFF;
    ev.act_src = src;
    if (APP_FAIL == ls_led_task_notify(&ev))
    {
        APP_LOG(LOG_ERROR, "set led fail\n");
    }

}


/**
* @brief led控制事件处理函数
* @param  ev        [队列消息]
*/
static void ls_led_event_handle(ls_led_ev_t ev)
{
    switch (ev.id)
    {
        case LS_LED_EV_SET_LED:
            if (NULL == ev.p_data)
                {
                    APP_LOG(LOG_ERROR, "pointer is NULL \n");
                    return;
                }
            if (ev.act_src == LS_LED_ACT_SRC_WIFI
                || ev.act_src == LS_LED_ACT_SRC_PRODUCTION
                || ev.act_src == LS_LED_ACT_SRC_BTN
                || ev.act_src == LS_LED_ACT_SRC_RESET)
            {
                // 内部灯效都属于情景灯效,且都是固定模式
                s_ls_status.model = LS_MODE_SCENE;
                s_led_scene = (ls_led_diverse_param_t*)(ev.p_data);
                if (ev.act_src != LS_LED_ACT_SRC_BTN)
                {
                    // 只有按键触发情景模式时按键次数才不清零
                    ls_set_button_cnt(0); // 按键清零
                }
            }
            else if (ev.act_src == LS_LED_ACT_SRC_OUTSIDE)
            {
                // 外部灯效都属于hsv，数据用malloc
                ls_led_hsv_param_t *param = (ls_led_hsv_param_t*)(ev.p_data);
                if (param == NULL)
                {
                    APP_LOG(LOG_ERROR, "NULL pointer \n");
                    return;
                }
                ls_set_button_cnt(0); // 按键清零
                if (s_ls_status.model != LS_MODE_SCENE && param->mode != LS_MODE_SCENE && s_ls_gradient_enable == true)
                {
                    // 当前状态和设置的状态都不是情景模式时开启渐变
                    s_ls_status.gradient_flag = true;
                }
                else
                {
                    s_ls_status.gradient_flag = false;
                }
                s_ls_status.model = param->mode;
                s_ls_status.last_app_mode = param->mode;
                s_led_hsv = param;
            }
            else
            {
                VCOM_SAFE_FREE(ev.p_data);
                APP_LOG(LOG_ERROR, "led act source error! \n");
                return;
            }
            s_ls_status.status = true;
            APP_LOG(LOG_INFO, "ledstrip is open! \n");
            break;
        case LS_LED_EV_OFF:
            ls_set_button_cnt(0); // 按键清零
            s_ls_status.model = LS_MODE_OFF;
            break;
        default:
            break;
    }
    s_ls_status.switch_flag =true;
}



/**
* @brief LED控制任务
*/
static void ls_led_task(void *args)
{
    ls_led_ev_t ev;
    int ret;
    while(1)
    {

        ret = vesync_queue_recv(s_led_event_queue, &ev, task_cycle);
        if (VOS_OK == ret)
        {
            ls_led_event_handle(ev);
        }

        // 不变换灯效，且当前灯效不会发生变化
        if (false == s_ls_status.switch_flag && false == s_ls_status.diverse_flag)
        {
            continue;
        }
        if (true == s_ls_status.gradient_flag)
        {
            // APP端和云端控制时渐变切换
            if (APP_OK == ls_led_gradient(s_gradient_step))
            {
                s_ls_status.gradient_flag = false;
            }
            else
            {
                s_ls_status.gradient_flag = true;
                continue;
            }
        }

        switch (s_ls_status.model)
        {
            case LS_MODE_WHITE:
                s_ls_status.app_color.brightness = (s_led_hsv->color).brightness;
                s_ls_status.app_color.colortemp = (s_led_hsv->color).colortemp;

                VCOM_SAFE_FREE(s_led_hsv); // 释放之前的数据
                ls_led_set_hsv_color(&(s_ls_status.app_color), LS_LED_SET_WHITE);
                memset(&(s_ls_status.cur_color), 0, sizeof(s_ls_status.cur_color));
                s_ls_status.cur_color.brightness = s_ls_status.app_color.brightness;
                s_ls_status.cur_color.colortemp = s_ls_status.app_color.colortemp;
                s_ls_status.diverse_flag = false;
                s_ls_status.status = true;
                ls_set_voice_off_flag(false);
                break;
            case LS_MODE_COLOR:
                s_ls_status.app_color.H = (s_led_hsv->color).H;
                s_ls_status.app_color.S = (s_led_hsv->color).S;
                s_ls_status.app_color.V = (s_led_hsv->color).V;

                VCOM_SAFE_FREE(s_led_hsv); // 释放之前的数据
                ls_led_set_hsv_color(&(s_ls_status.app_color), LS_LED_SET_COLOR);
                memset(&(s_ls_status.cur_color), 0, sizeof(s_ls_status.cur_color));
                s_ls_status.cur_color.H = s_ls_status.app_color.H;
                s_ls_status.cur_color.S = s_ls_status.app_color.S;
                s_ls_status.cur_color.V = s_ls_status.app_color.V;
                s_ls_status.diverse_flag = false;
                s_ls_status.status = true;
                ls_set_voice_off_flag(false);
                break;
            case LS_MODE_SCENE:
                if (s_led_scene == NULL)
                {
                    APP_LOG(LOG_ERROR, "scene params NULL \n");
                    break;
                }

                s_ls_status.status = true;
                ls_set_voice_off_flag(false);
                switch (s_led_scene->mode)
                {
                    case LS_SCENE_SINGLE:
                        // 固定颜色组合
                        s_ls_status.diverse_flag = false;
                        ls_led_set_rgb_color(s_led_scene->mode_head, 100);
                        break;
                    case LS_SCENE_BREATHING:
                        // 呼吸灯模式
                        s_ls_status.diverse_flag = true;
                        ls_led_rgb_color_breating(s_led_scene);
                        break;
                    case LS_SCENE_SWITCH:
                        // 不同颜色常亮切换
                        s_ls_status.diverse_flag = true;
                        ls_led_rgb_color_switch(s_led_scene);
                        break;
                    case LS_SCENE_OVERLAP:
                        // 呼吸灯切换，交替时颜色重叠
                        s_ls_status.diverse_flag = true;
                        ls_led_rgb_overlap_breathing(s_led_scene, 20);
                        break;
                    default:
                        s_ls_status.diverse_flag = false;
                        APP_LOG(LOG_ERROR, "error scene mode! \n");
                        break;
                }
                break;
            case LS_MODE_OFF:
                if (s_ls_status.status == true)
                {
                    // 关闭灯带
                    APP_LOG(LOG_INFO, "ledstrip turn off! \n");
                    ls_led_set_rgb_color(&s_ls_off, 100);
                    s_ls_status.status = false;
                    memset(&(s_ls_status.cur_color), 0, sizeof(ls_led_hsv_t));
                }
                break;
            default:
                break;
        }
        if (s_ls_status.switch_flag == true)
        {
            // 灯带状态改变,上报、存flash
            ls_flash_data_t data;
            memset(&data, 0, sizeof(ls_flash_data_t));
            data.model = s_ls_status.model;
            data.last_app_mode = s_ls_status.last_app_mode;
            data.app_color = s_ls_status.app_color;
            data.scene_cnt = ls_get_button_cnt();
            ls_save_config(data);
            report_ls_status();
            s_ls_status.switch_flag = false;
        }

    }
}

/**
* @brief  led 控制初始化
*/
void ls_led_init(void)
{
    int ret = APP_OK;

    // led pwm timer配置
    vhal_led_timer_cfg_t led_timer_cfg =
    {
        .duty_resolution = LED_DUTY_RST_13_BIT,
        .freq_hz = 5000,
    };
    ret = vhal_led_timer_cfg(&led_timer_cfg);

    // led gpio 配置
    vhal_led_gpio_cfg_t gpio_cfg[5] =
    {
        {
            .gpio_num = LS_CW_IO, .channel = LS_CW_CH, .duty = 0,
        },
        {
            .gpio_num = LS_WW_IO, .channel = LS_WW_CH, .duty = 0,
        },
        {
            .gpio_num = LS_R_IO, .channel = LS_R_CH, .duty = 0,
        },
        {
            .gpio_num = LS_G_IO, .channel = LS_G_CH, .duty = 0,
        },
        {
            .gpio_num = LS_B_IO, .channel = LS_B_CH, .duty = 0,
        },
    };
    ret = vhal_led_gpio_cfg(LS_LED_NUM, gpio_cfg);
    // 灯带状态初始化赋值
    s_ls_status.status = true;
    s_ls_status.diverse_flag = false;
    s_ls_status.gradient_flag = false;
    s_ls_status.switch_flag = false;
    s_ls_status.model = LS_MODE_SCENE;
    s_ls_status.last_app_mode = LS_MODE_WHITE;
    memset(&(s_ls_status.cur_color), 0, sizeof(ls_led_hsv_t));
    s_ls_status.app_color = s_ls_hsv_init_color;

    s_ls_changing_status.last_mode = NULL;
    s_ls_changing_status.remind_step = 0;
    s_ls_changing_status.remind_times = 0;

    s_led_event_queue = vesync_queue_new(LS__LED_EVENT_QUEUE_MAX_NUM * sizeof(ls_led_ev_t), sizeof(ls_led_ev_t));
    if (s_led_event_queue == NULL)
    {
        APP_LOG(LOG_ERROR, "led event queue create failed\n");
        return;
    }
    if (VOS_OK != vesync_task_new(LS_LED_TASK_NAME, NULL,
                    ls_led_task,
                    NULL,
                    LS_LED_TASK_STACKSIZE,
                    LS_LED_TASK_PRIO, NULL))
    {
        vesync_queue_free(s_led_event_queue);
        ret = APP_FAIL;
    }
    if (APP_FAIL == ls_led_install_memory())
    {
        ls_led_set_rgb_color(&s_ls_rgb_init_color, 100);
    }

    if (ret)
    {
        APP_LOG(LOG_ERROR, "led  init failed.\r\n");
    }
}


