/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_ble.h
 * @brief       BLE模块接口
 * @author      Louis
 * @date        2021-07-21
 */

#ifndef __VESYNC_BLE_H__
#define __VESYNC_BLE_H__

#include "vesync_frame.h"

#ifdef __cplusplus
extern "C" {
#endif


/**
 * @brief BLE数据发送结果
 */
typedef enum
{
    BLE_SEND_RESUT_SUCCESS = 0,
    BLE_SEND_RESUT_FAIL
} VESYNC_BLE_SEND_RESULT_E;

/**
 * @brief BLE数据接收返回应用层透传数据的回调函数，p_data缓存的是完整数据包，且已校验通过
 * @param[in]   p_data          [指向收到BLE数据的缓存]
 * @param[in]   len             [BLE数据长度]
 * @param[in]   need_ack        [是否需要应答]
 */
typedef void (*vesync_ble_data_recv_cb_t)(uint8_t *p_data, uint16_t len, bool need_ack);

/**
 * @brief BLE数据发送结果返回应用层的回调函数
 * @param[in]   event           [发送结果]
 * @param[in]   p_data          [如果收到应答，指向应答数据缓存，否则为NULL]
 * @param[in]   len             [应答数据的长度]
 */
typedef void (*vesync_ble_evt_cb_t)(VESYNC_BLE_SEND_RESULT_E event, uint8_t *p_data, uint16_t len);



/**
 * @brief  发送CMD数据
 * @param[in]  p_data       [数据指针]
 * @param[in]  len          [数据长度]
 * @param[in]  req_flag     [是否需要对端回复]
 * @return  int32_t         [成功：SDK_OK，失败：SDK_FAIL]
 */
int32_t vesync_ble_send_cmd_data(uint8_t *p_data , uint16_t len, uint8_t req_flag);


/**
 * @brief  发送CMD ACK
 * @param[in]  p_data       [数据指针]
 * @param[in]  len          [数据长度]
 * @param[in]  err_flag     [错误码]
 * @return  int32_t         [成功：SDK_OK，失败：SDK_FAIL]
 */
int32_t vesync_ble_send_cmd_ack(uint8_t *p_data , uint16_t len, uint8_t err_flag);


/**
 * @brief  注册CMD数据接收的回调函数
 * @param[in]  cb          [CMD数据接收的回调函数]
 */
void vesync_ble_reg_cmd_recv_cb(vesync_ble_data_recv_cb_t cb);


/**
 * @brief  注册CMD数据发送结果的回调函数
 * @param[in]  cb          [CMD数据发送结果的回调函数]
 */
void vesync_ble_reg_cmd_evt_cb(vesync_ble_evt_cb_t cb);


/**
 * @brief  断开当前蓝牙连接
 * @return  int32_t         [成功：SDK_OK，失败：SDK_FAIL]
 */
int32_t vesync_ble_disconnect(void);


/**
 * @brief  关闭蓝牙从机功能
 * @return  int32_t         [成功：SDK_OK，失败：SDK_FAIL]
 */
int32_t vesync_ble_disable(void);


#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_BLE_H__ */
