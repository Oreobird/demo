/*
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file        vesync_bypass_internal.h
* @brief       bypass处理接口
* @date        2021-05-13
*/

#ifndef __VESYNC_BYPASS_INTERNAL_H__
#define __VESYNC_BYPASS_INTERNAL_H__

#include "vesync_bypass.h"
#include "vesync_list.h"
#include "vesync_report.h"

#ifdef __cplusplus
extern "C" {
#endif


//错误码定义
#define BP_ERR_NO_ERR                               (0)
#define BP_ERR_UNDEFINE                             (-1)            // 未定义错误
#define BP_ERR_PARA_ILLEGAL                         (11000000UL)    // 参数不合法
#define BP_OUT_OF_MEMOTY                            (11001000UL)    // 内存不足
#define BP_ERR_CMD_EXECUTE_FAIL                     (11002000UL)    // 命令执行失败
#define BP_ERR_VALUE_OUT_OF_RANGE                   (11003000UL)    // 数值超出范围
#define BP_ERR_DEVICE_BUSY                          (11004000UL)    // 设备忙，不可升级
#define BP_ERR_DEVICE_STDBY                         (11005000UL)    // 设备处于待机状态
#define BP_ERR_CID_EXIST                            (11100000UL)    // cid 已存在
#define BP_ERR_LANCOMM_CONNECTED                    (11031000UL)    // 局域网通信连接已存在

//通用错误码
#define BP_OVEN_SENSOR_OPEN_ERROR                   (11006000UL)    //传感器开路错误
#define BP_OVEN_SENSOR_SHORT_CIRCUIT_ERROR          (11007000UL)    //传感器短路错误
#define BP_OVEN_COOK_TIME_EXCEED_MAX                (11008000UL)    //时长范围超过上限错误
#define BP_OVEN_COOK_TIME_EXCEED_MIN                (11009000UL)    //时长范围超过下限错误
#define BP_OVEN_COOK_TEMP_EXCEED_MAX                (11010000UL)    //烹饪温度超过上限错误
#define BP_OVEN_COOK_TEMP_EXCEED_MIN                (11011000UL)    //烹饪温度超过下限错误
#define BP_OVEN_COOKING_ERROR                       (11012000UL)    //烤箱烹饪中，不能开启新的烹饪
#define BP_OVEN_VOLTAGE_ERROR                       (11013000UL)    //电压错误
#define BP_ERR_SENSOR_FAULT                         (11014000UL)    // 传感器故障
#define BP_TEMP_ERROR                               (11015000UL)    //高温保护或温度异常保护
#define BP_ERR_NOT_EXEC_IN_MANUAL_MODE              (11016000UL)    // 手动模式下无法执行该操作
#define BP_ERR_NOT_EXEC_IN_CUR_MODE                 (11017000UL)    // 当前模式下不支持该操作
#define BP_ERR_NOT_EXEC_IN_SLEEP_MODE               (11018000UL)    // 睡眠模式下不支持该操作
#define BP_LOW_VOLTAGE_ERROR                        (11019000UL)    //电压过低
#define BP_ALREADY_PAUSED_ERROR                     (11020000UL)    //设备已经暂停
#define BP_ALREADY_STOPPED_ERROR                    (11021000UL)    //设备已经停止
#define BP_ERR_NOT_EXEC_IN_AUTO_MODE                (11022000UL)    // 自动模式下无法执行该操作
#define BP_ERR_BOTTOM_NTC_OPEN_CIRCUIT              (11023000ul)    //底部NTC开路
#define BP_ERR_BOTTOM_NTC_SHORT_CIRCUIT             (11024000ul)    //底部NTC短路
#define BP_ERR_TOP_NTC_SHORT_CIRCUIT                (11025000ul)    //顶部NTC短路
#define BP_ERR_TOP_NTC_OPEN_CIRCUIT                 (11026000ul)    //顶部NTC开路
#define BP_ERR_HEATER_OR_FUSE_OPEN_CIRCUIT          (11027000ul)    //发热管开路或保险丝开路
#define BP_ERR_MOTOR_OPEN_CIRCUIT                   (11028000ul)    //马达开路
#define BP_ERR_WIFI                                 (11029000ul)    //WIFI模块故障
#define BP_METHOD_NOT_SUPPORT                       (11030000UL)    //设备不支持该bypass命令

// 定时器相关错误码
#define BP_TIMER_EXCEED_MAX         (11503000UL)    // timer(倒计时)个数已达上限
#define BP_TIMER_CONFIG_ERROR       (11505000UL)    // Timer倒计时时间必须大于0且小于24个小时
#define BP_TIMER_NOT_FOUND          (11508000UL)    // 相关timer不存在
#define BP_SCHEDULE_EXCEED_MAX      (11502000UL)    // schedule个数已达上限
#define BP_SCHEDULE_NOT_FOUND       (11507000UL)    // 相关Schedule不存在
#define BP_SCHEDULE_CONFLICT        (11510000UL)    // 添加或编辑Schedule与已有的冲突
#define BP_AWAY_EXCEED_MAX          (11504000UL)    // away个数已达上限
#define BP_AWAY_NOT_FOUND           (11509000UL)    // 相关away不存在

//净化器错误码定义
#define BP_PURIFIER_SENSOR_ERROR    (11801000UL //传感器故障
#define BP_PURIFIER_MOTOR_ERROR (11802000UL)    //电机故障
#define BP_PURIFIER_RESET_FILTER_ERROR  (11803000UL)    //重置滤网失败
#define BP_PURIFIER_LEVEL_EXCEED_MAX    (11804000UL)    //调整档位超出上限
#define BP_PURIFIER_LEVEL_EXCEED_MIN    (11805000UL)    //调整档位超出下限

// 加湿器错误码定义
#define BP_ERR_DRY_BURN                 (11601000UL)    // 雾化片干烧
#define BP_ERR_PTC_FAILURE              (11602000UL)    // PTC温度故障
#define BP_ERR_HIGH_TEMP                (11603000UL)    // 雾化板高温故障
#define BP_ERR_DETECTION_FAILURE        (11604000UL)    // 检水板故障
#define BP_ERR_WATER_LACKS              (11605000UL)    // 设备处于缺水状态
#define BP_ERR_WATER_TANK_LIFTED        (11606000UL)    // 水箱被提起

//空气炸锅错误码定义
#define BP_AIRFRYER_PULL_OUT            (11901000UL)    //炸篮拉出
#define BP_AIRFRYER_COOKING_ERROR       (11902000UL)    //设备已经处于烹饪状态
#define BP_AIRFRYER_NOT_COOKING_ERROR   (11903000UL)    //设备未处于烹饪状态

//空气烤架错误码定义
#define BP_AIRGRILL_POT_OUT            (11905000UL)    //无锅

#define BP_OVEN_DOOR_OPEN               BP_AIRFRYER_PULL_OUT    //烤箱门打开
#define BP_OVEN_NOT_COOKING             BP_AIRFRYER_NOT_COOKING_ERROR    //设备未处于烹饪状态
#define BP_OVEN_NOT_FAN_SWITCH_ERROR    (11904000UL)    //当前模式不支持开关风扇



#define BYPASS_METHOD_NAME_MAX_LEN  (64)

// 设备消息来源
#define BP_AUTH_MSG_FROM_DVLPR       (MSG_TAG_DVLPR)                                 // 只允许developer来源的消息
#define BP_AUTH_MSG_FROM_MQTT        (MSG_TAG_MQTT)                                  // 只允许MQTT来源的消息
#define BP_AUTH_MSG_FROM_LOCAL       (MSG_TAG_LOCAL)                                 // 只允许局域网（本地通信）来源的消息
#define BP_AUTH_MSG_FROM_MQTT_LOCAL  (MSG_TAG_MQTT | MSG_TAG_LOCAL)                  // 允许MQTT和局域网来源的消息
#define BP_AUTH_MSG_FROM_ALL         (MSG_TAG_DVLPR | MSG_TAG_MQTT | MSG_TAG_LOCAL)  // 允许所有来源的消息


/**
 * @brief bypass item 数据结构
 */
typedef struct
{
    uint32_t auth_mask;             // 接口授权掩码
    BYPASS_METHOD_ID_E  method_id;  // 接口id
    char method[BYPASS_METHOD_NAME_MAX_LEN]; // 接口名称
    bypass_method_handle_fn_t method_handle;       // 接口json解析回调函数
    bypass_method_cb_t app_cb;                     // 接口应用层回调函数
} bypass_item_data_t;


/**
 * @brief bypass item 数据结构
 */
typedef struct
{
    struct list_head list;
    bypass_item_data_t data;
} bypass_item_t;


/**
 * @brief bypass item 数据结构
 */
typedef struct
{
    int num;
    //vesync_mutex_t mutex;
    struct list_head list;
} bypass_mgt_t;

/**
* @brief 初始化节点
* @param bypass_item_data_t          [节点数据]
* @return bypass_item_t *            [节点指针]
*/
bypass_item_t *vesync_bypass_init_item(bypass_item_data_t *data);

/**
 * @brief 添加节点
 * @param bypass_item_t                [节点]
 * @return                             [SDK_OK/SDK_FAIL]
 */
int vesync_bypass_add_item(bypass_item_t *item);


/**
 * @brief 应用层注册查询串口队列剩余空间 回调函数
 * @param cb                                 [串口队列剩余空间 回调函数]
 * @return void
 */
void vesync_bypass_reg_get_uart_mq_freesize_cb(bypass_get_uart_mq_freesize_cb_t cb);


/**
 * @brief bypass 消息应答函数, 带MQTT消息等级
 * @param[in] code                           [错误码]
 * @param[in] p_trace_msg                    [trace message app发送过来原样返回]
 * @param[in] json                           [返回数据json指针， 如果没返回数据返回空指针]
 * @param[in] qos                            [MQTT消息等级]
 * @param[in] puback_cb                      [收到qos1确认包后的回调函数]
 * @return bypass_err_t
 */
int vesync_bypass_reply_qos(int code, const bypass_trace_msg_t *p_trace_msg, cJSON *json, REPORT_QOS_E qos, void* puback_cb);


/**
 * @brief 通过method id 找到method 的回调函数
 * @param                                [method_id]
 * @return bypass_method_cb_t            [method 回调函数]
 */
bypass_method_cb_t vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_E method_id);

/**
* @brief bypass消息处理入口
* @param[in]  pMsg             [数据指针]
* @param[in]  msg_tag          [消息来源标签]
* @return     none
*/
void vesync_bypass_msg_handle(char *pMsg, uint32_t msg_tag);


/**
* @brief bypass 各类method id功能初始化函数
*/
void vesync_bypass_away_init(void);
void vesync_bypass_childlock_init(void);
void vesync_bypass_cooking_init(void);
void vesync_bypass_device_init(void);
void vesync_bypass_error_upload_init(void);
void vesync_bypass_ffs_setup_init(void);
void vesync_bypass_humidity_init(void);
void vesync_bypass_indicator_init(void);
void vesync_bypass_level_init(void);
void vesync_bypass_light_init(void);
void vesync_bypass_light_switch_init(void);
void vesync_bypass_nightlight_init(void);
void vesync_bypass_nightlight_brightness_init(void);
void vesync_bypass_notify_device_init(void);
void vesync_bypass_plasma_init(void);
void vesync_bypass_purifier_init(void);
void vesync_bypass_range_init(void);
void vesync_bypass_relay_init(void);
void vesync_bypass_schedule_init(void);
void vesync_bypass_set_device_trigger_init(void);
void vesync_bypass_set_display_init(void);
void vesync_bypass_set_temp_unit_init(void);
void vesync_bypass_switch_init(void);
void vesync_bypass_target_temp_init(void);
void vesync_bypass_temp_unit_init(void);
void vesync_bypass_timer_init(void);
void vesync_bypass_upgrade_init(void);
void vesync_bypass_device_init(void);

#ifdef __cplusplus
}
#endif
#endif /* __VESYNC_BYPASS_H__ */

