 /**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_lan_comm.h
 * @brief       局域网通信业务头文件
 * @author      henrikzhou
 * @date        2020-9-21
 */

#ifndef _VESYNC_LAN_COMM_H_
#define _VESYNC_LAN_COMM_H_

#if defined(CONFIG_TARGET_LINUX)
#include <sys/types.h>
#include <sys/socket.h>
#include <unistd.h>
#include <errno.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#else
#include "lwip/netif.h"
#include "lwip/tcpip.h"
#include "lwip/sockets.h"
#include "netif/etharp.h"
#endif
#include "vesync_task.h"

#ifdef __cplusplus
extern "C" {
#endif



/*parameter*/
/*超时时间类*/
#define  LAN_COMM_RECV_TIMEOUT              5       //读取数据超时，单位为毫秒
#define  LAN_COMM_KEY_UPDATE_PERIOD         43200    //密钥更新周期时间，单位为秒
#define  LAN_COMM_IDLE_TIMEOUT              3600    //空闲状态关闭SOCKET超时时间，单位为秒
#define  LAN_COMM_VERIFICATION_TIMEOUT      5       //链路连接成功未收到authkey的超时时间，单位为秒
#define  LAN_COMM_DISCOVERED_TIMEOUT        20      //收到local_auth请求未收到tcp链接请求的超时时间，单位为秒
#define  LAN_COMM_CONNECTED_TIMEOUT         600     //连接状态数据交互静默超时时间，单位为秒
#define  LAN_COMM_TASK_DELAY_TIME           10      //局域网通信功能任务延时时间 单位为ms
#define  LAN_COMM_MUTEX_TIMEOUT             200     //局域网通信互斥锁超时时间

/*通信参数或标记*/
#define  LAN_COMM_DEBUG_ENABLE              1       //使能局域网通信调试日志输出
#define  LAN_COMM_PROTOCOL_VERSION          0x01    //局域网通信当前协议版本
#define  LAN_COMM_UDP_PORT                  62313   //局域网通信UDP端口值
#define  LAN_COMM_TCP_LISTEN_NUM            1       //局域网通信TCP server 监听未连接数量
#define  LAN_COMM_ENCRYPT                   1       //局域网通信加密标记
#define  LAN_COMM_NO_ENCRYPT                0       //局域网通信不加密标记

/*数据长度类*/
#define  LAN_COMM_BUFFER_SIZE               1024    //局域网通信模块数据缓存长度
#define  LAN_COMM_PROT_DATA_HEAD_SIZE       4       //局域网通信数据区头部信息长度
#define  IP_BUFFER_SIZE                     16      //IP地址缓存长度
#define  UDP_REPLY_SIZE                     128     //UDP 单播回复响应长度
#define  LAN_COMM_KEY_SIZE                  16      //局域网通信密钥的长度

/*opcode类*/
#define  LAN_COMM_OP_UDP_BROADCAST          0x8040  //局域网通信协议广播opcode
#define  LAN_COMM_OP_TCP_REQUEST            0x8041  //局域网通信协议数据传输请求opcode
#define  LAN_COMM_OP_TCP_COMMUNICATE        0x8042  //局域网通信协议数据传输opcode
#define  LAN_COMM_OP_TCP_NOTIFY             0x8043  //局域网通信协议状态通知

// 局域网通信任务
#define LAN_COMM_TASK_NAME              "lan_comm"
#define LAN_COMM_TASK_STACSIZE          (1024*4)
#define LAN_COMM_TASK_PRIO              TASK_PRIORITY_NORMAL


/**
 * @brief 局域网接收数据处理回调函数
 */
typedef void(*vesync_lan_msg_recv_callback_t)(void *p_msg);

/**
 * @brief lan_comm状态枚举
 */
typedef enum
{
      LAN_COMM_IDLE = 0,     //空闲状态
      LAN_COMM_DISCOVERY = 1, //设备等待连接
      LAN_COMM_CONNECTED = 2,//设备连接成功
      LAN_COMM_VERIFICATION = 3,//设备校验
      LAN_COMM_SHUTDOWN = 4, //局域网通信功能关闭
} LAN_COMM_STATE_E;

/**
 * @brief LAN_COMM控制块
 */
typedef struct
{
     LAN_COMM_STATE_E state;   //局域网状态
     uint8_t * aes;    //aes密钥
     uint8_t* authkey;//登录密钥
     int udp_socket_fd;  //udp socket 句柄
     int tcp_socket_fd;   //tcp socket 句柄
     int tcp_conn_fd;    //tcp 当前连接的句柄
     uint64_t state_entry_time;  //设备进入状态的时间
     uint64_t key_generate_time;    //aes auth_key生成时间戳
     struct sockaddr_in  udp_addr ;  //udp socket 结构体
     struct sockaddr_in  tcp_addr ;  //tcp socket 结构体
} lan_comm_context_t ;



/* function */

/**
 * @brief     tcp数据回调函数注册
 * @param[in] cb
 */
void vesync_lan_reg_tcp_data_recv_cb(vesync_lan_msg_recv_callback_t cb);

/**
 * @brief 局域网通信功能开启（初始化局域网参数，创建udp socket,创建局域网通信任务）
 * @return int      [成功/失败]
 */
int vesync_lan_comm_start(void);

/**
 * @brief 局域网通信功能关闭
 * @return int      [成功/失败]
 */
void vesync_lan_comm_stop(void);


/**
 * @brief 局域网通信功能开启TCP sever
 * @return int      [成功/失败]
 */
int vesync_lan_comm_tcp_start(void);

/**
 * @brief 局域网通信功能TCP 数据发送
 * @param[in] data              [将要发送的数据]
 * @param[in] len               [数据长度]
 * @param[in] op_code           [指令操作码]
 * @param[in] encrypt_flag      [加密标记位：1为需要加密，0为不需要加密]
 * @param[in] status            [响应状态]
 * @return int                  [成功/失败]
 */
int vesync_lan_comm_tcp_data_send(uint8_t * data,uint32_t len,uint16_t op_code,uint8_t encrypt_flag,uint8_t status);

/**
 * @brief 获取TCP端口号
 * @return uint32-t      [TCP端口号]
 */
uint32_t vesync_lan_comm_get_tcp_port(void);

/**
 * @brief 获取AES字符串
 * @param[in] aes             [存储aes密钥地址，空间至少32个字节]
 * @param[in/out] aes         [输入为缓存最大长度，输出为实际字符串长度]
 * @return int                [0：成功/1：失败]
 */
int vesync_lan_comm_get_aes(uint8_t * aes,uint32_t * len);

/**
 * @brief 获取auth_key字符串
 * @param[in] auth_key        [存储auth_key地址，空间至少32个字节]
 * @return int                [0：成功/1：失败]
 */
int vesync_lan_comm_get_authkey(uint8_t * auth_key);

#ifdef __cplusplus
}
#endif

#endif //_VESYNC_LAN_COMM_H_

