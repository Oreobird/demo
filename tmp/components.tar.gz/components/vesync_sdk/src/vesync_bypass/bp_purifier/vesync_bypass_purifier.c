/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_bypass_purifier.c
 * @brief       bypass处理接口
 * @date        2021-05-17
 */
#include <string.h>

#include "vesync_common.h"
#include "vesync_memory.h"
#include "vesync_log_internal.h"
#include "vesync_bypass_internal.h"

/**
 * @brief 获取净化器状态函数
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  json                     [json数据指针]
 * @return BYPASS_ERR_E                 [错误码]
 */
static BYPASS_ERR_E bypass_method_get_purifier_status_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    BYPASS_ERR_E ret = BP_OK;
    UNUSED(json);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);
    //查询无需解析json
    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_GET_PURIFIER_STATUS);
    if (method_cb)
    {
        method_cb(p_msg_ctx, NULL);
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

    return ret;
}

/**
 * @brief 重置滤网
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  json                     [json数据指针]
 * @return BYPASS_ERR_E                 [错误码]
 */
static BYPASS_ERR_E bypass_method_reset_filter_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    BYPASS_ERR_E ret = BP_OK;
    UNUSED(json);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);
    //查询无需解析json
    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_RESET_FILTER);
    if (method_cb)
    {
        method_cb(p_msg_ctx, NULL);
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

    return ret;
}

/**
 * @brief 设置净化器模式
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  json                     [json数据指针]
 * @return BYPASS_ERR_E                 [错误码]
 */
static BYPASS_ERR_E bypass_method_set_purifier_mode_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    BYPASS_ERR_E ret = BP_OK;
    cJSON* json_data = NULL;

    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    bypass_set_purifier_mode_t *p_purifier_mode = (bypass_set_purifier_mode_t *)vesync_malloc(sizeof(bypass_set_purifier_mode_t));
    if (NULL == p_purifier_mode)
    {
        return BP_ERR_NOMEM;
    }

    memset(p_purifier_mode, 0, sizeof(bypass_set_purifier_mode_t));

    json_data = cJSON_GetObjectItemCaseSensitive(json, "mode");
    if (cJSON_IsString(json_data))
    {
        if (0 == strcmp(json_data->valuestring,"auto"))
        {
            p_purifier_mode->mode = BP_PURIFIER_MODE_AUTO;
        }
        else if (0 == strcmp(json_data->valuestring,"manual"))
        {
            p_purifier_mode->mode = BP_PURIFIER_MODE_MANUAL;
        }
        else if (0 == strcmp(json_data->valuestring,"sleep"))
        {
            p_purifier_mode->mode = BP_PURIFIER_MODE_SLEEP;
        }
        else if (0 == strcmp(json_data->valuestring,"pollen"))
        {
            p_purifier_mode->mode = BP_PURIFIER_MODE_POLLEN;
        }
        else
        {
            ret = BP_ERR_ARG;
            goto _exit;
        }

        SDK_LOG(LOG_DEBUG,"p_purifier_mode : %d\r\n",p_purifier_mode->mode);
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_SET_PURIFIER_MODE);
    if (method_cb)
    {
        method_cb(p_msg_ctx, (void*)p_purifier_mode);
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

_exit:
    vesync_free(p_purifier_mode);
    return ret;
}

/**
 * @brief 设置自动模式偏好
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  json                     [json数据指针]
 * @return BYPASS_ERR_E                 [错误码]
 */
static BYPASS_ERR_E bypass_method_set_auto_preference_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    BYPASS_ERR_E ret = BP_OK;
    cJSON* json_data = NULL;
    cJSON* room_json_data = NULL;

    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    bypass_set_purifier_auto_preference_t *p_auto_pref = (bypass_set_purifier_auto_preference_t *)vesync_malloc(sizeof(bypass_set_purifier_auto_preference_t));
    if (NULL == p_auto_pref)
    {
        return BP_ERR_NOMEM;
    }

    memset(p_auto_pref, 0, sizeof(bypass_set_purifier_auto_preference_t));

    json_data = cJSON_GetObjectItemCaseSensitive(json, "type");
    if (cJSON_IsString(json_data))
    {
        if (0 == strcmp(json_data->valuestring,"default"))
        {
            p_auto_pref->auto_pref = BP_PURIFIER_AUTO_DEFAULT;
        }
        else if (0 == strcmp(json_data->valuestring,"quiet"))
        {
            p_auto_pref->auto_pref = BP_PURIFIER_AUTO_QUIET;
        }
        else if (0 == strcmp(json_data->valuestring,"efficient"))
        {
            p_auto_pref->auto_pref = BP_PURIFIER_AUTO_EFFICIENT;

            room_json_data = cJSON_GetObjectItemCaseSensitive(json, "room_size");
            if (cJSON_IsNumber(room_json_data))
            {
                p_auto_pref->room_size = room_json_data->valueint;
            }
            else
            {
                ret = BP_ERR_ARG;
                goto _exit;
            }

            SDK_LOG(LOG_DEBUG,"p_purifier_auto_preference room_size: %d\r\n",p_auto_pref->room_size);
        }
        else
        {
            ret = BP_ERR_ARG;
            goto _exit;
        }

        SDK_LOG(LOG_DEBUG,"p_purifier_auto_preference : %d\r\n",p_auto_pref->auto_pref);
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_SET_AUTO_PREFERENCE);
    if (method_cb)
    {
        method_cb(p_msg_ctx, (void*)p_auto_pref);
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

_exit:
    vesync_free(p_auto_pref);
    return ret;
}

/***************************** 以下是测试接口 *****************************/
#if defined(PR_FW_TYPE) && (PR_FW_TYPE == 0)
/**
 * @brief 设置滤网使用时间和集尘量
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  json                     [json数据指针]
 * @return BYPASS_ERR_E                 [错误码]
 */
static BYPASS_ERR_E bypass_method_set_filter_use_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    BYPASS_ERR_E ret = BP_OK;
    cJSON* json_data = NULL;

    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    bypass_filter_use_data_t *p_filter_use = (bypass_filter_use_data_t *)vesync_malloc(sizeof(bypass_filter_use_data_t));
    if (NULL == p_filter_use)
    {
        return BP_ERR_NOMEM;
    }

    memset(p_filter_use, 0, sizeof(bypass_filter_use_data_t));

    json_data = cJSON_GetObjectItemCaseSensitive(json, "dust");
    if (cJSON_IsNumber(json_data))
    {
        p_filter_use->dust = json_data->valueint;
        SDK_LOG(LOG_INFO,"set dust value : %d\r\n", p_filter_use->dust);
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }


    json_data = cJSON_GetObjectItemCaseSensitive(json, "useTime");
    if (cJSON_IsNumber(json_data))
    {
        p_filter_use->use_time = json_data->valueint;
        SDK_LOG(LOG_INFO,"set filter use_time : %d\r\n", p_filter_use->use_time);
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_SET_FILTER_USE);
    if (method_cb)
    {
        method_cb(p_msg_ctx, (void*)p_filter_use);
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

_exit:

    vesync_free(p_filter_use);
    return ret;

}

/**
 * @brief 设置滤网损耗加速系数
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  json                     [json数据指针]
 * @return BYPASS_ERR_E                 [错误码]
 */
static BYPASS_ERR_E bypass_method_set_filter_speed_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    BYPASS_ERR_E ret = BP_OK;
    cJSON* json_data = NULL;

    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    bypass_filter_speed_data_t *p_filter_speed = (bypass_filter_speed_data_t *)vesync_malloc(sizeof(bypass_filter_speed_data_t));
    if (NULL == p_filter_speed)
    {
        return BP_ERR_NOMEM;
    }

    memset(p_filter_speed, 0, sizeof(bypass_filter_speed_data_t));

    json_data = cJSON_GetObjectItemCaseSensitive(json, "speed");
    if (cJSON_IsNumber(json_data))
    {
        p_filter_speed->speed = json_data->valueint;
        SDK_LOG(LOG_INFO,"set filter speed : %d\r\n", p_filter_speed->speed);
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_SET_FILTER_SPEED);
    if (method_cb)
    {
        method_cb(p_msg_ctx, (void*)p_filter_speed);
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

_exit:

    vesync_free(p_filter_speed);
    return ret;
}


/**
 * @brief 设置滤网加速打开或者关闭
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  json                     [json数据指针]
 * @return BYPASS_ERR_E                 [错误码]
 */
static BYPASS_ERR_E bypass_method_set_filter_speed_enable_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    BYPASS_ERR_E ret = BP_OK;
    cJSON* json_data = NULL;

    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    bypass_filter_speed_up_t *p_speed_up = (bypass_filter_speed_up_t *)vesync_malloc(sizeof(bypass_filter_speed_up_t));
    if (NULL == p_speed_up)
    {
        return BP_ERR_NOMEM;
    }

    memset(p_speed_up, 0, sizeof(bypass_filter_speed_up_t));

    json_data = cJSON_GetObjectItemCaseSensitive(json, "speedUp");
    if (cJSON_IsBool(json_data))
    {
        p_speed_up->speed_up = json_data->valueint;
        SDK_LOG(LOG_INFO,"set filter speed up : %d\r\n", p_speed_up->speed_up);
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_ENABLE_FILTER_SPEED);
    if (method_cb)
    {
        method_cb(p_msg_ctx, (void*)p_speed_up);
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

_exit:

    vesync_free(p_speed_up);
    return ret;
}

/**
 * @brief 设置净化器的pm25值，用于测试滤网
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  json                     [json数据指针]
 * @return BYPASS_ERR_E                 [错误码]
 */
static BYPASS_ERR_E bypass_method_set_pm25_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    BYPASS_ERR_E ret = BP_OK;
    cJSON* json_data = NULL;

    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    bypass_pm25_data_t *p_pm25_data = (bypass_pm25_data_t *)vesync_malloc(sizeof(bypass_pm25_data_t));
    if (NULL == p_pm25_data)
    {
        return BP_ERR_NOMEM;
    }

    memset(p_pm25_data, 0, sizeof(bypass_pm25_data_t));

    json_data = cJSON_GetObjectItemCaseSensitive(json, "pm25");
    if (cJSON_IsNumber(json_data))
    {
        p_pm25_data->pm25_value = json_data->valueint;
        SDK_LOG(LOG_INFO,"set pm25 value : %d\r\n",p_pm25_data->pm25_value);
    }


    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_SET_PM25);
    if (method_cb)
    {
        method_cb(p_msg_ctx, (void*)p_pm25_data);
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

    vesync_free(p_pm25_data);
    return ret;

}

/**
 * @brief 获取净化器所有状态，用于自动化脚本测试
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  json                     [json数据指针]
 * @return BYPASS_ERR_E                 [错误码]
 */
static BYPASS_ERR_E bypass_method_get_purifier_all_status_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    BYPASS_ERR_E ret = BP_OK;
    UNUSED(json);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);
    //查询无需解析json
    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_GET_PURIFIER_ALL_STATUS);
    if (method_cb)
    {
        method_cb(p_msg_ctx, NULL);
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

    return ret;
}

/**
 * @brief 获取净化器状态上报信息，用于自动化脚本测试
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  json                     [json数据指针]
 * @return BYPASS_ERR_E                 [错误码]
 */
static BYPASS_ERR_E bypass_method_get_purifier_report_info_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    BYPASS_ERR_E ret = BP_OK;
    UNUSED(json);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);
    //查询无需解析json
    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_GET_PURIFIER_REPORT_INFO);
    if (method_cb)
    {
        method_cb(p_msg_ctx, NULL);
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

    return ret;
}
#endif /* defined(PR_FW_TYPE) && (PR_FW_TYPE == 0) */


static bypass_item_data_t purifier_method_tbl[] = {
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_GET_PURIFIER_STATUS,   "getPurifierStatus",    bypass_method_get_purifier_status_handle, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_SET_PURIFIER_MODE,     "setPurifierMode",      bypass_method_set_purifier_mode_handle, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_RESET_FILTER,          "resetFilter",          bypass_method_reset_filter_handle, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_SET_AUTO_PREFERENCE,   "setAutoPreference",    bypass_method_set_auto_preference_handle, NULL},
    //净化器测试接口
#if defined(PR_FW_TYPE) && (PR_FW_TYPE == 0)
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_SET_FILTER_USE,        "setFilterUse",         bypass_method_set_filter_use_handle, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_SET_FILTER_SPEED,      "setFilterSpeed",       bypass_method_set_filter_speed_handle, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_ENABLE_FILTER_SPEED,   "openFilterSpeedUp",    bypass_method_set_filter_speed_enable_handle, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_SET_PM25,              "setAirpurifierData",   bypass_method_set_pm25_handle, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_GET_PURIFIER_ALL_STATUS,"getTestPurifierStatus",bypass_method_get_purifier_all_status_handle, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_GET_PURIFIER_REPORT_INFO,"getPurifierReportInfo",bypass_method_get_purifier_report_info_handle, NULL},
#endif
};

void vesync_bypass_purifier_init(void)
{
    for (int i = 0; i < SIZEOF_ARRAY(purifier_method_tbl); i++)
    {
        bypass_item_t *item = vesync_bypass_init_item(&purifier_method_tbl[i]);
        if (item != NULL)
        {
            vesync_bypass_add_item(item);
        }
    }
}
