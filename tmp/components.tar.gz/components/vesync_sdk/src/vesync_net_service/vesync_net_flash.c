/*
 * Copyright © Vesync Technologies Co.Ltd. 2019-2021. All rights reserved.
 * @file    vesync_net_service.c
 * @brief   网络相关flash操作
 * @author  CharlesMei
 * @date    2021-06-04
 */


#include <stdint.h>
#include "vesync_common.h"
#include "vhal_flash.h"
#include "vesync_flash.h"
#include "vesync_net_service_private.h"
#include "vesync_net_service_internal.h"
#include "vesync_log_internal.h"
#include "vesync_klv.h"
#include "vesync_memory.h"
#include "string.h"

#define  VESYNC_NET_INFO_WRITE_LEN          300

//klv数据key的定义，key不能重用，若新增数据key ID从后面添加，若某项数据废弃后其ID不能删除
typedef enum
{
    NET_KEY_ID_DATA_VERSION =0,
    NET_KEY_ID_SERVER_DN = 1,
    NET_KEY_ID_SERVER_PORT = 2,
    NET_KEY_ID_AUTH_MODE = 3,
    NET_KEY_ID_WIFI_SSID = 4,
    NET_KEY_ID_WIFI_PSW = 5,
    NET_KEY_ID_ACCOUT_ID = 6,
    NET_KEY_ID_CONFIG_KEY = 7,
    NET_KEY_ID_SERVER_IP = 8,
    NET_KEY_ID_MAX
}NET_CFG_KEY_E;



/**
 * @brief       flash写配网信息
 * @param[in]   p_info               [配网参数指针]
 * @return      int                  [成功/失败]
 */
int vesync_net_flash_write_net_info(net_info_t *p_info)
{
    NET_UTIL_MEM_CHECK(p_info, return VERR_FAIL);

    char *write_ptr_buf = NULL;
    int offset = 0;
    int ret = VERR_FAIL;

    write_ptr_buf = vesync_malloc(VESYNC_NET_INFO_WRITE_LEN);
    NET_UTIL_MEM_CHECK(write_ptr_buf, return VERR_FAIL);

    memset(write_ptr_buf, 0, VESYNC_NET_INFO_WRITE_LEN);

    uint8_t version = PR_NET_FLASH_VERSION;
    offset += vesync_klv_set((uint8_t *)write_ptr_buf+offset, VESYNC_NET_INFO_WRITE_LEN - offset,
        NET_KEY_ID_DATA_VERSION, sizeof(p_info->data_version), &version);

    offset += vesync_klv_set((uint8_t *)write_ptr_buf+offset, VESYNC_NET_INFO_WRITE_LEN - offset,
        NET_KEY_ID_CONFIG_KEY, strlen((char *)p_info->configKey), p_info->configKey);

    offset += vesync_klv_set((uint8_t *)write_ptr_buf+offset, VESYNC_NET_INFO_WRITE_LEN - offset,
        NET_KEY_ID_SERVER_DN, strlen((char *)p_info->serverDN), p_info->serverDN);
    offset += vesync_klv_set((uint8_t *)write_ptr_buf+offset, VESYNC_NET_INFO_WRITE_LEN - offset,
        NET_KEY_ID_WIFI_SSID, strlen((char *)p_info->wifiSSID), p_info->wifiSSID);

    offset += vesync_klv_set((uint8_t *)write_ptr_buf+offset, VESYNC_NET_INFO_WRITE_LEN - offset,
        NET_KEY_ID_WIFI_PSW, strlen((char *)p_info->wifiPassword), p_info->wifiPassword);

    offset += vesync_klv_set((uint8_t *)write_ptr_buf+offset, VESYNC_NET_INFO_WRITE_LEN - offset,
        NET_KEY_ID_ACCOUT_ID, strlen((char *)p_info->account_id), p_info->account_id);

    offset += vesync_klv_set((uint8_t *)write_ptr_buf+offset, VESYNC_NET_INFO_WRITE_LEN - offset,
        NET_KEY_ID_SERVER_PORT, sizeof(p_info->serverPort), (uint8_t*)&p_info->serverPort);

    offset += vesync_klv_set((uint8_t *)write_ptr_buf+offset, VESYNC_NET_INFO_WRITE_LEN - offset,
        NET_KEY_ID_AUTH_MODE, sizeof(p_info->auth_mode), (uint8_t*)&p_info->auth_mode);

    offset += vesync_klv_set((uint8_t *)write_ptr_buf+offset, VESYNC_NET_INFO_WRITE_LEN - offset,
        NET_KEY_ID_SERVER_IP, strlen((char *)p_info->serverIP), p_info->serverIP);

    if(VERR_OK != vesync_flash_aes_crypto_write(PARTITION_CFG, USER_CFG_KEY_NET_INFO, (uint8_t*)write_ptr_buf, offset))
    {
        VERR_UPLOAD(VERR_FLASH_WRITE_FAIL, 0);
        ret=  VERR_FAIL;
        NET_LOG(LOG_ERROR, "Write network info error\r\n");
    }
    else
    {
        ret = VERR_OK;
    }

    vesync_free(write_ptr_buf);
    return ret;
}



/**
 * @brief       读取info 设备信息
 * @param[in]   p_info               [配网参数指针]
 * @return      int                  [成功/失败]
 */
int vesync_net_flash_read_net_info(net_info_t *p_info)
{
    char *write_ptr_buf = NULL;
    int ret = SDK_OK;
    uint32_t read_len  = 0;

    NET_UTIL_MEM_CHECK(p_info, return VERR_FAIL);

    write_ptr_buf = vesync_malloc(VESYNC_NET_INFO_WRITE_LEN);
    NET_UTIL_MEM_CHECK(write_ptr_buf, return VERR_FAIL);

    memset(write_ptr_buf,0,VESYNC_NET_INFO_WRITE_LEN);
    memset(p_info,0,sizeof(net_info_t));

    read_len = VESYNC_NET_INFO_WRITE_LEN;
    if (VERR_OK != vesync_flash_aes_crypto_read(PARTITION_CFG, USER_CFG_KEY_NET_INFO, (uint8_t*)write_ptr_buf, &read_len))
    {
        NET_LOG(LOG_WARN, "read flash error\r\n");
        vesync_free(write_ptr_buf);
        return VERR_FAIL;
    }

    ret |= vesync_klv_get((uint8_t *)write_ptr_buf, VESYNC_NET_INFO_WRITE_LEN, NET_KEY_ID_DATA_VERSION,
        sizeof(p_info->data_version),&p_info->data_version);

    ret |= vesync_klv_get((uint8_t *)write_ptr_buf, VESYNC_NET_INFO_WRITE_LEN, NET_KEY_ID_CONFIG_KEY,
        sizeof(p_info->configKey), p_info->configKey);

    ret |= vesync_klv_get((uint8_t *)write_ptr_buf, VESYNC_NET_INFO_WRITE_LEN, NET_KEY_ID_SERVER_DN,
        sizeof(p_info->serverDN), p_info->serverDN);

    ret |= vesync_klv_get((uint8_t *)write_ptr_buf, VESYNC_NET_INFO_WRITE_LEN, NET_KEY_ID_SERVER_PORT,
        sizeof(p_info->serverPort), (uint8_t*)&p_info->serverPort);

    ret |= vesync_klv_get((uint8_t *)write_ptr_buf, VESYNC_NET_INFO_WRITE_LEN, NET_KEY_ID_AUTH_MODE,
        sizeof(p_info->auth_mode), (uint8_t*)&p_info->auth_mode);

    ret |= vesync_klv_get((uint8_t *)write_ptr_buf, VESYNC_NET_INFO_WRITE_LEN, NET_KEY_ID_WIFI_SSID,
        sizeof(p_info->wifiSSID), p_info->wifiSSID);

    ret |= vesync_klv_get((uint8_t *)write_ptr_buf, VESYNC_NET_INFO_WRITE_LEN, NET_KEY_ID_WIFI_PSW,
        sizeof(p_info->wifiPassword), p_info->wifiPassword);

    ret |= vesync_klv_get((uint8_t *)write_ptr_buf, VESYNC_NET_INFO_WRITE_LEN, NET_KEY_ID_ACCOUT_ID,
        sizeof(p_info->account_id), p_info->account_id);

    vesync_klv_get((uint8_t *)write_ptr_buf, VESYNC_NET_INFO_WRITE_LEN, NET_KEY_ID_SERVER_IP,
        sizeof(p_info->serverIP), p_info->serverIP);

    vesync_free(write_ptr_buf);

    if(ret ==SDK_OK)
        return VERR_OK;
    else
        return VERR_FAIL;
}


/**
 * @brief       flash清除配网信息
 * @return      int                  [成功/失败]
 */
int vesync_net_flash_clear_net_info(void)
{
    if (VERR_OK != vesync_flash_erase_key(PARTITION_CFG, USER_CFG_KEY_NET_INFO))
    {
        VERR_UPLOAD(VERR_FLASH_ERASE_FAIL, 0);
        return VERR_FAIL;
    }
    NET_LOG(LOG_DEBUG, "Clear network info success\n");
    return VERR_OK;
}

/**
 * @brief       网络重连原因，保存到flash用户分区
 * @param[in]   reason               [网络重连原因]
 * @return      int                  [成功/失败]
 */
int vesync_net_flash_write_reconnect_reason(uint32_t reason)
{
    if (VERR_OK != vesync_flash_write(PARTITION_CFG, USER_CFG_KEY_RECONNECT_REASON, (uint8_t*)&reason, sizeof(uint32_t)))
    {
        VERR_UPLOAD(VERR_FLASH_WRITE_FAIL, reason);
        return VERR_FAIL;
    }

    return VERR_OK;
}

/**
 * @brief       flash读取网络重连原因
 * @para        p_reason             [网络重连原因]
 * @return      int                  [成功/失败]
 */
int vesync_net_flash_read_reconnect_reason(uint32_t *p_reason)
{
    uint32_t read_len = sizeof(uint32_t);

    NET_UTIL_MEM_CHECK(p_reason, return VERR_FAIL);

    if (VERR_OK != vesync_flash_read(PARTITION_CFG, USER_CFG_KEY_RECONNECT_REASON, (uint8_t*)p_reason, &read_len))
    {
        return VERR_FAIL;
    }

    return VERR_OK;
}


