/**
* Copyright © Vesync Technologies Co.Ltd. 2022. All rights reserved
* @file         white.h
* @brief        白灯场景
* @author       Joshua
* @date         2022-1-24
*/

#include <stdint.h>
#include "vesync_common.h"
#include "scene.h"

#ifndef __WHITE_H__
#define __WHITE_H__

#ifdef __cplusplus
extern "C" {
#endif


/**
 * @brief  白灯开场景灯效实现初始化
 * @return int              [成功：APP_OK， 失败：APP_FAIL]
 */
int white_on_light_scene_impl_init(void);

/**
 * @brief  注册白灯开场景灯效
 * @return  int             [成功：APP_OK，失败：APP_FAIL]
 */
int white_on_light_scene_reg(light_scene_t *light_scene);

/**
 * @brief  注销白灯开场景灯效
 * @param[in] id            [场景ID]
 * @return  int             [成功：APP_OK，失败：APP_FAIL]
 */
int white_on_light_scene_unreg(int id);

/**
 * @brief  白灯关场景灯效实现初始化
 * @return int              [成功：APP_OK， 失败：APP_FAIL]
 */
int white_off_light_scene_impl_init(void);

/**
 * @brief  注册白灯关场景灯效
 * @return  int             [成功：APP_OK，失败：APP_FAIL]
 */
int white_off_light_scene_reg(light_scene_t *light_scene);

/**
 * @brief  注销白灯关场景灯效
 * @param[in] id            [场景ID]
 * @return  int             [成功：APP_OK，失败：APP_FAIL]
 */
int white_off_light_scene_unreg(int id);


#ifdef __cplusplus
}
#endif

#endif





