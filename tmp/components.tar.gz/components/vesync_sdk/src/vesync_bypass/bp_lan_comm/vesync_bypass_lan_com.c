/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_bypass_lan_com.c
 * @brief       bypass处理接口
 * @date        2021-05-17
 */
#include <string.h>

#include "vesync_common.h"
#include "vesync_memory.h"
#include "vesync_log_internal.h"

#include "vhal_utils.h"
#include "vesync_lan_comm.h"
#include "vesync_bypass_internal.h"
#include "vesync_device_internal.h"

/**
 * @brief "localAuth" method数据解析
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  json                     [json数据指针]
 * @return BYPASS_ERR_E                 [错误码]
 */
static BYPASS_ERR_E bypass_method_lan_local_auth_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    BYPASS_ERR_E ret = BP_OK;
    char ip_buf[20] = {0};      // 保存ip空间
    char aes_buf[32 + 1] = {0}; // 保存aes密钥
    uint32_t aes_len = 33;        //保存aes密钥长度
    char authkey_buf[32 + 1] = {0}; //保存authkey
    const char *p_ip;
    const char *p_cid;
    cJSON *json_data = NULL;

    json_data = cJSON_GetObjectItemCaseSensitive(json, "deviceIP");
    if (cJSON_IsString(json_data))
    {
        if (!(p_ip = vhal_utils_get_sta_ip(ip_buf, sizeof(ip_buf))))
        {
            return BP_ERROR;
        }
        if (strcmp(json_data->valuestring, p_ip) != 0)
        {
            return BP_ERR_ARG;
        }
    }
    else
    {
        SDK_LOG(LOG_WARN, "miss deviceIP\r\n");
        return BP_ERR_ARG;
    }
    json_data = cJSON_GetObjectItemCaseSensitive(json, "deviceCID");
    if (cJSON_IsString(json_data))
    {
        if (!(p_cid = vesync_device_get_cid()))
        {
            return BP_ERROR;
        }
        if (strcmp(json_data->valuestring, p_cid) != 0)
        {
            return BP_ERR_ARG;
        }
    }
    else
    {
        SDK_LOG(LOG_WARN, "miss deviceCID\r\n");
        return BP_ERR_ARG;
    }

    if (SDK_FAIL == vesync_lan_comm_tcp_start())
    {
        SDK_LOG(LOG_WARN, "start lan_comm_tcp failed\r\n");
        vesync_bypass_reply_noqos(BP_ERR_LANCOMM_CONNECTED, p_msg_ctx->p_trace_msg, NULL);
        return BP_ERROR;
    }

    json_data = NULL;
    json_data =  cJSON_CreateObject();
    if (NULL == json_data)
    {
        return BP_ERR_NOMEM;
    }
    cJSON_AddNumberToObject(json_data,"port", vesync_lan_comm_get_tcp_port());
    if (vesync_lan_comm_get_aes((uint8_t*)(aes_buf), &aes_len))
    {
        cJSON_Delete(json_data);
        SDK_LOG(LOG_WARN, "get aes failed\r\n");
        return BP_ERROR;
    }
    cJSON_AddStringToObject(json_data,"aes_key", aes_buf);
    if (vesync_lan_comm_get_authkey((uint8_t*)authkey_buf))
    {
        cJSON_Delete(json_data);
        SDK_LOG(LOG_WARN, "get auth_key failed\r\n");
        return BP_ERROR;
    }
    cJSON_AddStringToObject(json_data,"auth_key", authkey_buf);


    vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, json_data);

    return ret;
}


static bypass_item_data_t lan_com_method_tbl[] = {
    {BP_AUTH_MSG_FROM_MQTT, BYPASS_METHOD_ID_LAN_COMM_AUTH, "localAuth", bypass_method_lan_local_auth_handle, NULL},
};

/**
 * @brief bypass lan_com初始化
 */
void vesync_bypass_lan_com_init(void)
{
    for (int i = 0; i < SIZEOF_ARRAY(lan_com_method_tbl); i++)
    {
        bypass_item_t *item = vesync_bypass_init_item(&lan_com_method_tbl[i]);
        if (item != NULL)
        {
            vesync_bypass_add_item(item);
        }
    }
}
