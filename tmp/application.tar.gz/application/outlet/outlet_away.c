/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        outlet_away.c
 * @brief       outlet Away 功能
 * @author      Herve Lin
 * @date        2021-06-29
 */
#include <string.h>
#include <stdio.h>

#include "outlet.h"
#include "outlet_away.h"
#include "outlet_report.h"

#include "vesync_log.h"
#include "vesync_away.h"
#include "vesync_common.h"


// Away模块任务执行回调
static int outlet_module_exec_cb(vesync_away_t *p_cfg, vesync_away_tp_t *p_tp, AWAY_EVENT_E event)
{
    APP_LOG(LOG_INFO, "Away task executes. event:[%d]\n", event);

    outlet_ev_t outlet_ev = {
        id: OUTLET_EV_UNKNOWN,
        act_src: OUTLET_ACT_SRC_TASK,
        rsn: STAT_CHG_RSN_AWAY_STR  // 设置状态变化原因
    };

    switch (event)
    {
        case AWAY_START_ACTION:
        case AWAY_RANDOM_ON:
            outlet_ev.id = OUTLET_EV_ON;
            break;
        case AWAY_END_ACTION:
        case AWAY_RANDOM_OFF:
            outlet_ev.id = OUTLET_EV_OFF;
            break;
        default:
            break;
    }

    char err_msg[32] = {0};
    int ret = outlet_app_task_notify(&outlet_ev);
    if (ret != SDK_OK)
    {
        snprintf(err_msg, sizeof(err_msg), "OUTLET_EV_ON/OFF notify fail");
    }

    char action[32] = {0};
    switch(event)
    {
        case AWAY_START_ACTION:
            snprintf(action, sizeof(action), "switch=start_on");
            break;
        case AWAY_END_ACTION:
            snprintf(action, sizeof(action), "switch=end_off");
            break;
        case AWAY_RANDOM_ON:
            snprintf(action, sizeof(action), "switch=rand_on");
            break;
        case AWAY_RANDOM_OFF:
            snprintf(action, sizeof(action), "switch=rand_off");
            break;
        default:
            snprintf(action, sizeof(action), "unknow");
    }

    outlet_report_away_exec(p_tp->points, p_tp->point_num,
                            p_cfg->repeat_config, p_tp->exec_cnt,
                            action, ret, err_msg);
    return AWAY_OK;
}

//////////////////////////////////////////////////////////////
//////////////////  EXTERNAL IMPLEMENTATION //////////////////
//////////////////////////////////////////////////////////////

/**
 * @brief 初始化Away功能
 * @return int              [返回APP的错误定义： APP_OK, APP_FAIL]
 */
int outlet_away_init(void)
{
    int ret = APP_OK;

    vesync_away_param_t away_callbacks;
    away_callbacks.rd_cfg_cb = NULL;
    away_callbacks.wr_cfg_cb = NULL;
    away_callbacks.exec_app_task_cb = outlet_module_exec_cb;
    ret = vesync_away_init(&away_callbacks);
    if (ret != AWAY_OK)
    {
        APP_LOG(LOG_ERROR, "Away module init error: [%ld]\n", ret);

        return APP_FAIL;
    }

    APP_LOG(LOG_INFO, "Away initialized\n", ret);
    return ret;
}

/**
 * @brief Bypass添加Away配置项
 * @param[in] pst_bp_msg    [Bypass添加的Schedule配置项信息]
 * @return int              [返回BYPASS的错误定义]
 */
int outlet_away_add(bypass_away_base_t *pst_bp_msg)
{
    if (NULL == pst_bp_msg)
    {
        return BP_ERR_PARA_ILLEGAL;
    }

    vesync_away_t away_cfg;
    away_cfg.start_clk_sec = pst_bp_msg->start_clk_sec;
    away_cfg.end_clk_sec = pst_bp_msg->end_clk_sec;
    away_cfg.repeat_config = pst_bp_msg->repeat_config;

    int ret = vesync_away_add(&away_cfg);
    if (ret != AWAY_OK)
    {
        if (ret != AWAY_EXIST_ERR)
        {
            return BP_ERR_UNDEFINE;
        }

        return BP_ERR_AWAY_EXCEED_MAX;
    }

    return BP_ERR_NO_ERR;
}

/**
 * @brief Bypass删除Away配置项
 * @return int  [返回BYPASS的错误定义]
 */
int outlet_away_del(void)
{
    int ret = vesync_away_del();
    if (ret != AWAY_OK)
    {
        if (ret != AWAY_NO_EXIST)
        {
            return BP_ERR_UNDEFINE;
        }

        return BP_ERR_AWAY_NOT_FOUND;
    }

    return BP_ERR_NO_ERR;
}

/**
 * @brief Bypass获取Away配置项
 * @param pst_bp_out            [指向输出获取Away配置结果的缓存]
 * @param pst_rnd_times_point   [随机时间点的输出]
 * @param p_point_num           [随机时间点的数量]
 * @return int                  [返回BYPASS的错误定义]
 */
int outlet_away_get(bypass_away_base_t *pst_bp_out, uint32_t *pst_rnd_times_point, uint32_t *p_point_num)
{
    if (NULL == pst_bp_out || NULL == pst_rnd_times_point || NULL == p_point_num)
    {
        return BP_ERR_PARA_ILLEGAL;
    }

    vesync_away_t away_cfg;
    vesync_away_tp_t away_rnd_times;

    int ret = vesync_away_get(&away_cfg, &away_rnd_times);
    if (ret != AWAY_OK)
    {
        if (ret != AWAY_NO_EXIST)
        {
            return BP_ERR_UNDEFINE;
        }

        return BP_ERR_AWAY_NOT_FOUND;
    }

    pst_bp_out->start_clk_sec = away_cfg.start_clk_sec;
    pst_bp_out->end_clk_sec = away_cfg.end_clk_sec;
    pst_bp_out->repeat_config = away_cfg.repeat_config;

    *p_point_num = away_rnd_times.point_num;

    for (uint32_t cnt = 0; cnt < *p_point_num; cnt++)
    {
        pst_rnd_times_point[cnt] = away_rnd_times.points[cnt];
    }

    return BP_ERR_NO_ERR;
}

/**
 * @brief Bypass获取Away最大和最小时间点（动作）的数量
 * @param[out] p_max    [指向输出最大值的缓存，NULL指针忽略]
 * @param[out] p_min    [指向输出最小值的缓存，NULL指针忽略]
 * @return int          [返回BYPASS的错误定义]
 */
int outlet_away_get_max_min_rnd_times_point_num(uint32_t *p_max, uint32_t *p_min)
{
    if (NULL != p_max)
    {
        *p_max = AWAY_RANDOM_TIME_MAX_NUM;
    }

    if (NULL != p_min)
    {
        *p_min = AWAY_RANDOM_TIME_MIN_NUM;
    }

    return BP_ERR_NO_ERR;
}

/**
 * @brief Away 清除所有配置信息
 * @return int  [返回APP的错误定义： APP_OK, APP_FAIL]
 */
int outlet_away_clear(void)
{
    vesync_away_clear();

    return APP_OK;
}

