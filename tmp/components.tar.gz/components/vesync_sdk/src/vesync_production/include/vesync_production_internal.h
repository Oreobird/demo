/*
 * Copyright © Vesync Technologies Co.Ltd. 2019-2021. All rights reserved.
 * @file    vesync_production_internal.h
 * @brief   产测模块内部接口
 * @author  CharlesMei
 * @date    2021-05-25
 */


#ifndef __VESYNC_PRODUCTION_INTERNAL_H__
#define __VESYNC_PRODUCTION_INTERNAL_H__


#include "vesync_production.h"


#ifdef __cplusplus
extern "C"
{
#endif /* __cplusplus */

/**
 * @brief  产测配置数据初始化
 * @return  int                [成功：SDK_OK，失败：SDK_FAIL]
 */
int vesync_production_cfg_init(void);

/**
 * @brief       强制退出产测模式
 * @note        ！仅用于未产测的设备流入市场后，通过配网接口调用
 */
void vesync_production_force_exit_testmode(void);

/**
 * @brief        从nvs加载上一次产测错误码
 */
void vesync_production_load_error_code(void);

/**
 * @brief       检查是否产测OK
 * @return      bool             [true:已产测；false：未产测]
 */
bool vesync_production_is_completed(void);

#ifdef __cplusplus
}
#endif /* __cplusplus */


#endif /* __VESYNC_PRODUCTION_INTERNAL_H__ */
