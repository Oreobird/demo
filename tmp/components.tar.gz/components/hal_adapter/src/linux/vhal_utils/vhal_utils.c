/**
 *  Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
 * @file        vhal_utils.c
 * @brief       Linux Mock接口封装
 * @author      Joshua
 * @date        2021-06-30
 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <sys/time.h>

#include <unistd.h>
#include <sys/reboot.h>
#include <sys/sysinfo.h>
#include <errno.h>

#include <sys/types.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
//#include <net/if.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <linux/wireless.h>

#include "vesync_common.h"
#include "vesync_log.h"
#include "vhal_utils_internal.h"


/**
 * @brief 重启系统
 * @param[in]  arg                  [定时器参数，未使用]
 * @return     void
 */
void vhal_utils_restart(void *arg)
{
    HAL_LOG(LOG_INFO, "Prepare to restart system!\n");
    sync();
    reboot(RB_AUTOBOOT);
}

/**
 * @brief 通过硬件RNG获取随机数
 * @param[in]  p_buf                [用于存储随机数的缓存空间]
 * @param[in]  buf_len              [缓存空间大小]
 * @return     void
 */
void vhal_utils_get_random(uint8_t *p_buf, int32_t buf_len)
{
    VCOM_NULL_PARAM_CHK(p_buf, return);
    uint8_t *buf_bytes = p_buf;
    int word = 0;

    struct timeval tv;
    gettimeofday(&tv, NULL);
    srand(tv.tv_sec * 1000LL + tv.tv_usec / 1000);
    while (buf_len > 0)
    {
        word = rand();
        uint32_t to_copy = VCOM_MIN(sizeof(word), buf_len);
        memcpy(buf_bytes, &word, to_copy);
        buf_bytes += to_copy;
        buf_len -= to_copy;
    }
}

/**
 * @brief  获取剩余heap大小.
 * @return     uint32_t             [heap空间大小]
 */
uint32_t vhal_utils_get_free_heap_size(void)
{
    struct sysinfo s_info;
    sysinfo(&s_info);
    return (uint32_t)(s_info.freeram / 1024);
}

/**
 * @brief 修改dhcp的hostname
 * @param[in]  p_hostname            [新的hostname]
 * @return     void
 */
void vhal_utils_chg_dhcp_hostname(const char *p_hostname)
{
    int ret;

    if (NULL == p_hostname)
    {
        return;
    }

    // Set the hostname for the default TCP/IP station interface
    ret = sethostname(p_hostname, strlen(p_hostname));
    if (ret != 0)
    {
        HAL_LOG(LOG_ERROR, "Err set hostname: %d\n", errno);
    }
    else
    {
        char name[128] = {0};
        ret = gethostname(name, sizeof(name));
        if (ret != 0)
        {
            HAL_LOG(LOG_ERROR, "Err get hostname: %d\n", errno);
        }
        else
        {
            HAL_LOG(LOG_INFO, "Hostname is %s\n", (name == NULL ? "<None>" : name));
        }
    }
}

/**
 * @brief  获取Wi-Fi模组芯片名称
 * @return     char *               [字符串格式芯片名称]
 */
char *vhal_utils_get_chip_name(void)
{
    return "Linux";
}

/**
 * @brief  获取SDK版本信息
 * @param[out] p_buf              [缓存空间]
 * @param[in]  buf_len            [缓存大小]
 * @return     char *             [字符串格式SDK版本信息]
 */
char *vhal_utils_get_sdk_version(char *p_buf, uint32_t buf_len)
{
    if (NULL == p_buf || 0 == buf_len)
    {
        return "N/A";
    }

    snprintf(p_buf, buf_len, "%s", "N/A");

    return p_buf;
}

/**
 * @brief  设置设备MAC地址
 * @param[in]  p_mac                [MAC地址，使用":"分隔，如：00:01:02:03:04:05]
 * @return     uint32_t             [成功/失败]
 */
int32_t vhal_utils_set_wifi_mac(char *p_mac)
{
    return VHAL_OK;
}

/*
 * @brief 获取设备的MAC地址
 * @param[in]  type                 [详见DEVICE_TYPE_MAC_E定义]
 * @param[out] p_buf                [获取到的MAC地址]
 * @param[in]  buf_len              [缓存大小]
 * @return     int                  [执行成功，返回OK；执行失败，返回FAIL]
 */
int vhal_utils_get_dev_mac(VHAL_MAC_TYPE_E type, char *p_buf, int32_t buf_len)
{
    int ret = 0;
    int sockfd = -1;

    if (NULL == p_buf || buf_len < MAC_ADDR_STR_MAX_LEN)
    {
        HAL_LOG(LOG_ERROR, "Input param error!\n");
        return VHAL_FAIL;
    }

    sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd < 0)
    {
        HAL_LOG(LOG_ERROR, "socket fail!\n");
        return VHAL_FAIL;
    }

    if (VHAL_MAC_WIFI_STA == type || VHAL_MAC_WIFI_SOFTAP == type)
    {
        struct ifreq ifreq;

        memset(&ifreq, 0, sizeof(ifreq));
        strncpy(ifreq.ifr_name, INTERFACE_NAME, sizeof(ifreq.ifr_name));

        ret = ioctl(sockfd, SIOCGIFHWADDR, &ifreq);
        if (ret < 0)
        {
            HAL_LOG(LOG_ERROR, "ioctl fail!\n");
            close(sockfd);
            return VHAL_FAIL;
        }

        snprintf(p_buf, buf_len, MACSTR, MAC2STR(ifreq.ifr_hwaddr.sa_data));
        //snprintf(p_buf, buf_len, "a4:cf:12:e8:74:8f");
        //snprintf(p_buf, buf_len, "a4:cf:12:e8:73:9c");
    }
    else if (VHAL_MAC_ROUTER == type)
    {
        struct iwreq req;

        memset(&req, 0, sizeof(req));
        strncpy(req.ifr_name, INTERFACE_NAME, sizeof(req.ifr_name));

        ret = ioctl(sockfd, SIOCGIWAP, &req);
        if (ret < 0)
        {
            HAL_LOG(LOG_ERROR, "Get Wi-Fi STA cfg fail!\n");
            close(sockfd);
            return VHAL_FAIL;
        }

        snprintf(p_buf, buf_len, MACSTR, MAC2STR(req.u.ap_addr.sa_data));
    }
    else
    {
        HAL_LOG(LOG_ERROR, "Unknow device type = %d!\n", type);

        close(sockfd);
        return VHAL_FAIL;
    }

    close(sockfd);

    return VHAL_OK;
}

/*
 * @brief 设备作为STA时，获取分配到的IP。
 * @param[in]  char *               [保存IP的缓存]
 * @param[in]  int                  [缓存大小]
 * @return     char*                [IP地址]
 */
char* vhal_utils_get_sta_ip(char *p_buf, int32_t buf_len)
{
    int sock = -1;
    struct ifreq ifr;

    if (NULL == p_buf || buf_len < IP_ADDR_STR_MAX_LEN)
    {
        HAL_LOG(LOG_ERROR, "Input param error!\n");
        return NULL;
    }

    sock = socket(AF_INET, SOCK_DGRAM, 0);
    strcpy(ifr.ifr_name, INTERFACE_NAME);
    int ret = ioctl(sock, SIOCGIFADDR, &ifr);
    if (ret < 0)
    {
        //HAL_LOG(LOG_ERROR, "ioctl fail!\n");
        return NULL;
    }

    snprintf(p_buf, buf_len, "%s", inet_ntoa(((struct sockaddr_in *)&ifr.ifr_addr)->sin_addr));
    return inet_ntoa(((struct sockaddr_in *)&ifr.ifr_addr)->sin_addr);
}

/**
 * @brief 获取utc时间戳
 * @param[out]  p_ms                [保存精度到毫秒的时间戳]
 * @param[in]  buf_len              [p_ms大小]
 * @return     int                  [执行成功，返回OK；执行失败，返回FAIL]
 */
int vhal_utils_get_system_time_ms_str(char *p_ms, int buf_len)
{
    if (NULL == p_ms)
    {
        HAL_LOG(LOG_ERROR, "Input parameter contains null pointer!!\n");
        return VHAL_FAIL;
    }

    time_t seconds;
    seconds = time((time_t *)NULL);

    struct timeval te;
    gettimeofday(&te, NULL); // get current time

    uint32_t milliseconds = te.tv_usec / 1000;
    snprintf(p_ms, buf_len, "%u%03u", (unsigned int)seconds, (unsigned int)milliseconds);

    return VHAL_OK;
}

/**
 * @brief 获取utc时间戳
 * @return     uint32_t              [utc时间戳,单位：秒]
 */
uint32_t vhal_utils_get_system_time_sec(void)
{
    uint32_t ts_sec = 0;

    time_t seconds;
    seconds = time((time_t *)NULL);
    ts_sec = (uint32_t)seconds;

    return ts_sec;
}

/**
* @brief 获取utc时间戳
 * @return     long long            [utc时间戳]
 */
long long vhal_utils_get_system_time_ms_int(void)
{
    long long milliseconds = 0;
    struct timeval te;

    gettimeofday(&te, NULL); // get current time

    milliseconds = te.tv_sec * 1000LL + te.tv_usec / 1000;

    return milliseconds;
}

/**
 * @brief 初始化sntp
 */
void vhal_utils_start_sntp(void)
{
    HAL_LOG(LOG_DEBUG, "Initializing SNTP...\n");

    // Set timezone to China Standard Time
    setenv("TZ", "CST-8", 1);
    tzset();
    HAL_LOG(LOG_DEBUG, "Initialized successfully\n");
}

/**
 * @brief 停止sntp服务
 */
void vhal_utils_stop_sntp(void)
{
    HAL_LOG(LOG_DEBUG, "stop SNTP!!!\n");
}

/**
 * @brief 获得上次SNTP更新的时间点
 * @return uint32_t [返回的秒时间戳]
 */
uint32_t vhal_utils_get_sntp_last_sync(void)
{
    HAL_LOG(LOG_DEBUG, "FUNCTION IS UNIMPLEMENTED!\n");
    return 0;
}

/**
 * @brief 设置本地utc时间
 * @param[in]  utc_time     [utc时间戳]
 * @param[in]  time_zone    [时区]
 * @return     void         [无]
 */
void vhal_utils_update_system_time(uint32_t utc_time, int8_t time_zone)
{
    UNUSED(time_zone);
    struct timeval tv ={0, 0};
    struct timezone tz = {0, 0};

    tv.tv_sec = utc_time;
    settimeofday(&tv, &tz);

    struct timeval tv_start;
    gettimeofday(&tv_start, NULL);
    HAL_LOG(LOG_DEBUG, "Update utc time to %ld\n", tv_start.tv_sec);
}

