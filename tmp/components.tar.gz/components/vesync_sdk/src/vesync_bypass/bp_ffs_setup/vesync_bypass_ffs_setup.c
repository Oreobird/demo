/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_bypass_ffs_setup.c
 * @brief       bypass处理接口
 * @date        2021-05-17
 */

#include <string.h>
#include "vesync_common.h"
#include "vesync_memory.h"
#include "vesync_event_internal.h"
#include "vesync_bypass_internal.h"
#include "ffs_certificate.h"
#include "vesync_ffs_internal.h"
#include "vesync_device_internal.h"
#include "vesync_http_internal.h"

/**
 * @brief FFS配网成功,进行设置
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  json                     [json数据指针]
 * @return BYPASS_ERR_E                 [错误码]
 */
static BYPASS_ERR_E bypass_method_ffs_setup_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    BYPASS_ERR_E ret = BP_OK;
    cJSON* json_data = NULL;

    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    json_data = cJSON_GetObjectItemCaseSensitive(json, "accountId");
    if (cJSON_IsString(json_data))
    {
        if (strlen(json_data->valuestring) > 0)
        {
            vesync_device_set_account_id((char*)json_data->valuestring);    // 更新内存中的accountID
            //vesync_device_save_account_id((char*)json_data->valuestring);   // 保存accountID到flash
            char *account_id = vesync_device_get_account_id();
            vesync_ev_t event;
            VESYNC_POPULATE_EV(event, EVENT_FFS_CLOUD_RSP, BYPASS_EVENT_PUBLISH_STR,
                                (account_id == NULL) ? 0 : strlen(account_id), account_id);
            vesync_event_publish(&event);

            vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, NULL);
        }
        else
        {
            ret = BP_ERR_ARG;
        }
    }
    else
    {
        ret = BP_ERR_ARG;
    }

    return ret;
}

/**
 * @brief 更正证书命令
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  json                     [json数据指针]
 * @return BYPASS_ERR_E                 [错误码]
 */
static BYPASS_ERR_E bypass_method_update_certificate_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    BYPASS_ERR_E bp_ret = BP_OK;
    ffs_update_certificate_info_t update_info;

    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

#if CONFIG_VESYNC_SDK_HTTP_ENABLE
    memset(&update_info, 0, sizeof(ffs_update_certificate_info_t));

    cJSON *json_data = cJSON_GetObjectItemCaseSensitive(json, "type");
    if (cJSON_IsString(json_data))
    {
        if (0 == strcmp(json_data->valuestring, "FFS_CA"))
        {
             update_info.get_mode = HTTP_GET_CLI_CA;
        }
        else if (0 == strcmp(json_data->valuestring, "FFS_PrivateKey"))
        {
            update_info.get_mode = HTTP_GET_PRIVATE_KEY;
        }
        else
        {
            bp_ret = BP_ERR_ARG;
            goto exit;
        }
    }
    else
    {
        bp_ret = BP_ERR_ARG;
        goto exit;
    }

    cJSON *json_url = cJSON_GetObjectItemCaseSensitive(json, "url");
    if (cJSON_IsString(json_url))
    {
        snprintf(update_info.url, sizeof(update_info.url), "%s", json_url->valuestring);
    }
    else
    {
        bp_ret = BP_ERR_ARG;
        goto exit;
    }

    cJSON *json_md5 = cJSON_GetObjectItemCaseSensitive(json, "md5");
    if (cJSON_IsString(json_md5))
    {
        strncpy(update_info.md5, json_md5->valuestring, sizeof(update_info.md5));
    }
    else
    {
        bp_ret = BP_ERR_ARG;
        goto exit;
    }

    int ret = vesync_ffs_certificate_update_start(update_info);        //开始更新证书
    if (SDK_OK == ret)
    {
        vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, NULL);
    }
    else
    {
        vesync_bypass_reply_noqos(BP_ERR_CMD_EXECUTE_FAIL, p_msg_ctx->p_trace_msg, NULL);
    }

exit:

#endif

    return bp_ret;
}


static bypass_item_data_t ffs_setup_method_tbl[] = {
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_FFS_SETUP,          "ffsSetupSuccess", bypass_method_ffs_setup_handle, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_UPDATE_CERTIFICATE, "upCert",          bypass_method_update_certificate_handle,NULL},
};

void vesync_bypass_ffs_setup_init(void)
{
    for (int i = 0; i < SIZEOF_ARRAY(ffs_setup_method_tbl); i++)
    {
        bypass_item_t *item = vesync_bypass_init_item(&ffs_setup_method_tbl[i]);
        if (item != NULL)
        {
            vesync_bypass_add_item(item);
        }
    }
}
