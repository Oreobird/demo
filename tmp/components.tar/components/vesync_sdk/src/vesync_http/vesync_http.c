/*
 * Copyright © Vesync Technologies Co.Ltd. 2019-2021. All rights reserved.
 * @file    vesync_http.c
 * @brief   http模块
 * @author  CharlesMei
 * @date    2021-05-21
 */


#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <netdb.h>
#include <sys/socket.h>

#include "sdkconfig.h"
#include "vesync_memory.h"
#include "vhal_wifi.h"
#if CONFIG_VESYNC_HAL_OTA_ENABLE
#include "vhal_ota.h"
#endif /* CONFIG_VESYNC_HAL_OTA_ENABLE */
#include "vesync_http_private.h"


static const char *HTTP_GET = "GET %s HTTP/1.1\r\n"
                             "Host: %s\r\n"
                             "User-Agent: esp-idf/1.0 esp32\r\n"
                             "Accept: */*\r\n"
                             "Accept-Encoding: gzip, deflate\r\n"
                             //"Connection: keep-alive\r\n"
                             "\r\n"
                             ;
static const char *HTTP_POST = "POST %s HTTP/1.0\r\n"
                             "Host: %s\r\n"
                             "User-Agent: esp-idf/1.0 esp32\r\n"
                             "Content-Type:application/json\r\n"
                             "Content-Length:%d\r\n"
                             "\r\n"
                             "%s"
                             ;

static char s_http_host[HTTP_HOST_LEN];

static char s_http_path[HTTP_PATH_LEN];

static uint16_t s_http_port = HTTP_DEFAULT_PORT;


/**
 * @brief           从http的URL中提取host和port
 * @param[in]       url         [入参，完整的URL]
 * @return          int         [成功/失败]
 */
 static int vesync_http_parse_url(const char *url)
{
    const char *ptr1 = url;
    char *ptr2 = NULL;
    int len = 0;

    // 删除"http://"
    if (0 == strncmp(ptr1, "http://", strlen("http://")))
    {
        ptr1 += strlen("http://");
    }
    else
    {
        return VERR_FAIL;
    }

    // 提取path
    ptr2 = strchr(ptr1,'/');    // 查找第一个‘/’所在位置
    if (ptr2)
    {
        len = strlen(ptr1) - strlen(ptr2);
        if (len >= HTTP_HOST_LEN)
        {
            HTTP_LOG(LOG_WARN, "http host is too long\r\n");
            return VERR_FAIL;
        }
        if (*(ptr2 + 1))
        {
            if (strlen(ptr2) >= HTTP_PATH_LEN)
            {
                HTTP_LOG(LOG_WARN, "http path is too long\r\n");
                return VERR_FAIL;
            }
            memcpy(s_http_path, ptr2, strlen(ptr2));
            s_http_path[strlen(ptr2)] = '\0';
        }
        else
        {
            memcpy(s_http_path, "/", 1);
            *(s_http_path + 1) = '\0';
        }
        HTTP_LOG(LOG_DEBUG, "http path: %s\n", s_http_path);
    }

    // 提取host

    memcpy(s_http_host, ptr1, len);
    s_http_host[len] = '\0';
    HTTP_LOG(LOG_DEBUG, "http host: %s\n", s_http_host);

    // 提取port
    ptr2 = strchr(s_http_host,':');
    if (ptr2)
    {
        *ptr2++ = '\0';
        if (atoi(ptr2) > 0xffff)
        {
            HTTP_LOG(LOG_WARN, "http port is too large\r\n");
            return VERR_FAIL;
        }
        s_http_port = atoi(ptr2);
    }
    HTTP_LOG(LOG_DEBUG, "http port: %s\n", s_http_port);

    return VERR_OK;
}

/**
 * @brief         tcp连接
 * @param[out]    sockfd        [tcp绑定的socket]
 * @return        int           [成功或失败]
 */
static int tcp_connect(int *sockfd)
{
    int ret;
    char http_port_string[8];
    const struct addrinfo hints = {
        .ai_family = AF_INET,           // IPV4
        .ai_socktype = SOCK_STREAM,     // TCP协议
    };
    struct addrinfo *res = NULL;
    struct in_addr *addr = NULL;

    memset(http_port_string, 0, sizeof(http_port_string));
    snprintf(http_port_string, sizeof(http_port_string), "%d", s_http_port);

    ret = getaddrinfo(s_http_host, http_port_string, &hints, &res);
    if (ret != 0 || res == NULL)
    {
        HTTP_LOG(LOG_ERROR, "DNS lookup failed err=%d res=%p\n", ret, res);
        return VERR_FAIL;
    }
    addr = &((struct sockaddr_in *)res->ai_addr)->sin_addr;
    HTTP_LOG(LOG_DEBUG, "DNS lookup succeeded. IP=%s\n", inet_ntoa(*addr));

    *sockfd = socket(res->ai_family, res->ai_socktype, 0);
    if (*sockfd < 0)
    {
        HTTP_LOG(LOG_ERROR, "Http Failed to allocate socket.\n");
        freeaddrinfo(res);
        return VERR_FAIL;
    }
    HTTP_LOG(LOG_DEBUG, "Http allocated socket\n");

    //建立连接
    if (connect(*sockfd, res->ai_addr, res->ai_addrlen) != 0)
    {
        HTTP_LOG(LOG_ERROR, "Http socket connect failed errno=%d\n", errno);
        freeaddrinfo(res);
        close(*sockfd);
        return VERR_FAIL;
    }

    HTTP_LOG(LOG_DEBUG, "Http connected\n");
    freeaddrinfo(res);

    return VERR_OK;
}

/**
 * @brief         从http的响应中提取消息内容，需要手动释放内存
 * @param[in/out] p_buf         [输入为接收到的消息，输出为去掉头部的payload]
 * @param[in/out] p_buf_len     [输入为接收到的消息的长度，输出为payload的长度]
 * @param[out]    p_ctx_len     [http内容长度]
 * @return        int           [成功/失败]
 */
static int vesync_http_parse_head(char *p_buf, int *p_buf_len, int *p_ctx_len)
{
    int content_len = 0;
    char *ptmp = NULL;
    char *response = NULL;
    int head_len = 0;

/* 接收到的消息格式如下：
HTTP/1.1 200 OK
Accept-Ranges: bytes
Content-Length: 10363
Content-Type: text/plain; charset=utf-8
Last-Modified: Wed, 18 Sep 2019 12:04:16 GMT
Date: Thu, 19 Sep 2019 07:12:02 GMT


*/
    ptmp = (char*)strstr(p_buf, "HTTP/1.1");
    if (!ptmp)
    {
        HTTP_LOG(LOG_ERROR,"http/1.1 not faind\n");
        return VERR_FAIL;
    }
    if (atoi(ptmp + 9) != 200)
    {
        HTTP_LOG(LOG_ERROR, "result:\n%s\n", p_buf);
        return VERR_FAIL;
    }
    ptmp = (char*)strstr(p_buf, "Content-Length:");   // 内容长度
    if (!ptmp)
    {
        HTTP_LOG(LOG_ERROR, "http header does not contain Content-Length!!\n");
        return VERR_FAIL;
    }
    else
    {
        *p_ctx_len = atoi(ptmp + strlen("Content-Length:") + 1);   // 有一个空格
    }

    ptmp = (char*)strstr(p_buf,"\r\n\r\n");
    if (!ptmp)
    {
        HTTP_LOG(LOG_ERROR, "Not found the end of http head!\n");
        return VERR_FAIL;
    }

    ptmp = ptmp + 4;    //指针偏移到内容
    //content_len = strlen(ptmp);
    head_len = ptmp - p_buf;
    HTTP_LOG(LOG_DEBUG, "head_len = %d\n", head_len);
    if (head_len > *p_buf_len)
    {
        HTTP_LOG(LOG_ERROR, " http head err!\n");
        return VERR_FAIL;
    }
    content_len = *p_buf_len - head_len;

    response = (char *)vesync_malloc(content_len + 1);
    if (!response)
    {
        HTTP_LOG(LOG_ERROR, "vesync_malloc failed!\n");
        return VERR_FAIL;
    }
    memset(response, 0, content_len + 1);

    HTTP_LOG(LOG_DEBUG, "content_len = %d\n", content_len);
    memcpy(response, ptmp, content_len);
    memset(p_buf, 0, *p_buf_len);
    *p_buf_len = content_len;
    memcpy(p_buf, response, *p_buf_len);
    HTTP_UTIL_SAFE_FREE(response);

    return VERR_OK;
}

/**
 * @brief         接受并处理回复
 * @param[in]     http_buffer   [http通信的数据交互缓存区，大小为HTTP_BUFFER_SIZE]
 * @param[in]     sockfd        [tcp绑定的socket]
 * @param[out]    recv_buf      [返回的数据内容缓存buffer]
 * @param[in/out] recv_len      [返回的数据内容长度指针，传入时为缓存buffer的长度，供内部判断buffer大小是否足够，足够时内部把返回的数据拷贝至buffer，并赋值该值为数据长度]
 * @return        int           [成功或失败]
 */
static int vesync_http_receive_respond(char *http_buffer, int sockfd, char *recv_buf, int *recv_len, HTTP_GET_MODE_E mode)
{
    // 接收，设置等待超时10s
    struct timeval receiving_timeout;
    bool is_first_pkt = true;   // 第1个http response需要去掉头部
    int rd_len = 0;
    const int in_recv_len = *recv_len;
    int ctx_len = 0;    // http头部内容长度

    *recv_len = 0;    // 接收累计长度，最终为总数据长度

    receiving_timeout.tv_sec = 10;
    receiving_timeout.tv_usec = 0;
    if (setsockopt(sockfd, SOL_SOCKET, SO_RCVTIMEO, &receiving_timeout, sizeof(receiving_timeout)) < 0)
    {
        HTTP_LOG(LOG_ERROR, "Http failed to set socket receiving timeout\n");
        return VERR_FAIL;
    }
    HTTP_LOG(LOG_DEBUG, "Http set socket receiving timeout success\n");

    while(1)
    {
        memset(http_buffer, 0, HTTP_BUFFER_SIZE);
        rd_len = read(sockfd, http_buffer, HTTP_BUFFER_SIZE-1);// 考虑结束符\0
        if (rd_len < 0)
        {
            HTTP_LOG(LOG_ERROR, "Http read returned 0x%x\n", rd_len);
            if ((ctx_len > 0) && (ctx_len == *recv_len))
            {
                return VERR_OK;
            }
            else
            {
                return VERR_FAIL;
            }
        }
        if (0 == rd_len)
        {
            HTTP_LOG(LOG_INFO, "Http connection closed\n");
            return VERR_OK;
        }
        if (is_first_pkt)
        {
            if (VERR_OK != vesync_http_parse_head(http_buffer, &rd_len, &ctx_len))
            {
                return VERR_FAIL;
            }
            HTTP_LOG(LOG_INFO, "http parse head success, total %d\n", ctx_len);
            is_first_pkt = false;
        }
        // 保存接收到的内容
#if CONFIG_VESYNC_HAL_OTA_ENABLE
        if (HTTP_GET_OTA == mode)
        {
            if (rd_len > 0)
            {
                if (VERR_OK != vhal_ota_save_bin_file(*recv_len, http_buffer, rd_len))
                {
                    HTTP_LOG(LOG_INFO, "Save to flash failed\n");
                }
                *recv_len += rd_len;
            }
        }
        else
#endif /* CONFIG_VESYNC_HAL_OTA_ENABLE */
        {
            HTTP_LOG(LOG_DEBUG, "Http %d bytes read:\n %s\n", rd_len , http_buffer);
            if (NULL == recv_buf)
            {
                HTTP_LOG(LOG_DEBUG, "recv_buf NULL!\n");
                return VERR_FAIL;
            }
            if ((rd_len + *recv_len) < in_recv_len)
            {
                memcpy(&recv_buf[*recv_len], http_buffer, rd_len);
                *recv_len += rd_len;
                recv_buf[*recv_len] = '\0';
            }
            else
            {
                HTTP_LOG(LOG_ERROR, "Http Recv buffer length is too short!\n");
                recv_buf[0] = '\0';
                return VERR_FAIL;
            }
        }
        if (ctx_len == *recv_len)      //如果接受文件长度达到,则断开连接
        {
            HTTP_LOG(LOG_INFO, "Http receive respond finish\n");
            return VERR_OK;
        }
    }

    return VERR_FAIL;
}

/**
 * @brief         http客户端初始化
 * @param[in]     config        [初始化配置，详见vesync_http_client_config_t]
 * @return        int           [成功或失败]
 */
int vesync_http_client_init(vesync_http_client_config_t *config)
{
    HTTP_UTIL_MEM_CHECK(config, return VERR_FAIL);

    memset(s_http_host, 0, sizeof(s_http_host));
    memset(s_http_path, 0, sizeof(s_http_path));
    s_http_port = HTTP_DEFAULT_PORT;

    if (config->url)
    {
        vesync_http_parse_url(config->url);
    }
    else
    {
        HTTP_UTIL_MEM_CHECK(config->host, return VERR_FAIL);

        if (strlen(config->host) >= HTTP_HOST_LEN)
        {
            HTTP_LOG(LOG_WARN, "http host is too long\r\n");
            return VERR_FAIL;
        }
        else
        {
            snprintf(s_http_host, sizeof(s_http_host), "%s", config->host);
        }

        if (strlen(config->path) >= HTTP_PATH_LEN)
        {
            HTTP_LOG(LOG_WARN, "http path is too long\r\n");
            return VERR_FAIL;
        }
        else
        {
            snprintf(s_http_path, sizeof(s_http_path), "%s", config->path);
        }

        if (config->port)
        {
            s_http_port = config->port;
        }
    }

    return VERR_OK;
}

/**
 * @brief http request
 * @param[in]     method        [请求的方法]
 * @param[in]     send_buf      [请求的数据内容]
 * @param[out]    recv_buf      [返回的数据内容缓存buffer]
 * @param[in/out] recv_len      [返回的数据内容长度指针，传入时为缓存buffer的长度，供内部判断buffer大小是否足够，足够时内部把返回的数据拷贝至buffer，并赋值该值为数据长度]
 * @param[in]     mode          [http工作模式，目前只支持ota模式，ota模式下http请求到的数据会写入对应分区；其它模式直接返回]
 * @return        int           [成功或失败]
 */
int vesync_http_request(HTTP_METHOD_TYPE_E method, char *send_buf, char *recv_buf, int *recv_len, HTTP_GET_MODE_E mode)
{
    int ret = -1;
    int sockfd = 0;
    char *http_buffer = NULL;

    HTTP_UTIL_MEM_CHECK(send_buf, return VERR_FAIL);
    HTTP_UTIL_MEM_CHECK(recv_buf, return VERR_FAIL);
    HTTP_UTIL_MEM_CHECK(recv_len, return VERR_FAIL);

    if (HTTP_METHOD_GET != method && HTTP_METHOD_POST != method)
    {
        HTTP_LOG(LOG_ERROR, "Unknow http method type(%d)!\n", method);
        return VERR_FAIL;
    }

    // 判断Wi-Fi网络是否连接成功
    HTTP_LOG(LOG_INFO, "Waiting for network connected...\n");
    if (!vhal_wifi_get_link_status(HTTP_WAIT_TIME_MS))
    {
        HTTP_LOG(LOG_ERROR, "Network was disconnect!\n");
        return VERR_FAIL;
    }
    HTTP_LOG(LOG_INFO, "Network connected.\n");

    if (VERR_FAIL == tcp_connect(&sockfd))
    {
        return VERR_FAIL;
    }

    http_buffer = vesync_malloc(HTTP_BUFFER_SIZE);
    HTTP_UTIL_MEM_CHECK(http_buffer, return VERR_FAIL);
    memset(http_buffer, 0, HTTP_BUFFER_SIZE);
    if (HTTP_METHOD_GET == method)
    {
        snprintf(http_buffer, HTTP_BUFFER_SIZE, HTTP_GET, s_http_path, s_http_host);
    }
    else
    {
        snprintf(http_buffer, HTTP_BUFFER_SIZE, HTTP_POST, s_http_path, s_http_host, strlen(send_buf), send_buf);
    }
    HTTP_LOG(LOG_DEBUG, "\n%s\n", http_buffer);

    if (write(sockfd, http_buffer, strlen(http_buffer)) < 0)
    {
        HTTP_LOG(LOG_ERROR, "Http socket send failed\n");
        ret = -1;
        goto exit;
    }
    HTTP_LOG(LOG_DEBUG, "Http socket send success\n");

    if (VERR_OK != vesync_http_receive_respond(http_buffer, sockfd, recv_buf, recv_len, mode))
    {
        ret = -1;
    }
    else
    {
        ret = 0;
    }

exit:
    close(sockfd);
    HTTP_UTIL_SAFE_FREE(http_buffer);
    return (0 == ret ? VERR_OK : VERR_FAIL);
}

