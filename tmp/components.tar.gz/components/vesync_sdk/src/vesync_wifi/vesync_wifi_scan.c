/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_wifi_scan.c
 * @brief       WIFI扫描列表
 * @date        2021-05-21
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "cJSON.h"
#include "vesync_common.h"
#include "vesync_memory.h"
#include "vesync_log_internal.h"
#include "vesync_wifi_scan.h"


// WIFI扫描列表缓存
static vesync_aplist_t s_wifi_aplist  = {NULL, 0, 0, false};


/**
 * @brief  初始化扫描列表，分配内存空间
 * @param[in]  ap_num           [扫描到AP的总个数]
 * @return     int              [初始化成功或者失败]
 * @note
 */
static int vesync_wifi_aplist_init(uint16_t ap_num)
{
    // AP个数不能超过最大限制
    uint16_t store = ap_num < VESYNC_APLIST_MAX_NUM ? ap_num : VESYNC_APLIST_MAX_NUM;
    SDK_LOG(LOG_DEBUG, "number of scanned ap:%d, buffer size of aplist:%d\r\n", ap_num, store);

    // 先清除之前的扫描结果
    vesync_wifi_aplist_clear();

    // 分配内存
    s_wifi_aplist.aplist = vesync_malloc(sizeof(vesync_bss_info_t) * store);
    if (NULL == s_wifi_aplist.aplist)
    {
        SDK_LOG(LOG_ERROR, "malloc fail!\r\n");
        return SDK_FAIL;
    }

    memset(s_wifi_aplist.aplist, 0, (sizeof(vesync_bss_info_t) * store));
    s_wifi_aplist.ap_max_num = store;

    return SDK_OK;
}


/**
 * @brief  添加一个AP信息到扫描列表
 * @param[in]  bssid            [BSSID，即AP的MAC地址]
 * @param[in]  ssid             [AP的SSID，即名称]
 * @param[in]  rssi             [信号强度]
 * @param[in]  auth_mode        [加密方式]
 * @return     int              [添加成功或者失败]
 * @note  该接口调用须在init成功之后
 */
static int vesync_wifi_add_ap(const uint8_t* bssid, const uint8_t* ssid,
                            const int8_t rssi, const VHAL_WIFI_AUTH_MODE_E auth_mode)
{
    vesync_bss_info_t *p_bss_info;

    // 判断aplist是不是满了
    if (s_wifi_aplist.ap_cnt >= s_wifi_aplist.ap_max_num)
    {
        return SDK_FAIL;
    }

    // 找到最近一个未使用的ap
    p_bss_info = &s_wifi_aplist.aplist[s_wifi_aplist.ap_cnt];
    s_wifi_aplist.ap_cnt ++;

    p_bss_info->authmode = auth_mode;
    p_bss_info->rssi = rssi;
    memcpy((void*)p_bss_info->bssid, (const void*)bssid, WIFI_BSSID_MAX_LEN);
    snprintf((char *)p_bss_info->ssid, WIFI_SSID_MAX_LEN, "%s", (char *)ssid);

    return SDK_OK;
}


/**
 * @brief  VHAL层扫描结果回调函数，添加AP信息到扫描列表
 * @param[in]  bssid            [BSSID，即AP的MAC地址]，是由6个十六进制数组成]
 * @param[in]  ssid             [AP的SSID，即名称，是一个字符串，通常由UTF-8编码]
 * @param[in]  rssi             [信号强度]
 * @param[in]  auth_mode        [加密方式]
 * @param[in]  total_count      [扫描到的AP总个数]
 * @return     int              [添加成功或者失败]
 */
int vesync_wifi_scan_vhal_cb(const uint8_t* bssid, const uint8_t* ssid, const int8_t rssi,
                            const int auth_mode, const uint16_t total_count)
{
    vesync_bss_info_t* apinfo = NULL;

    // 先初始化AP列表
    if (0 != total_count && NULL == s_wifi_aplist.aplist)
    {
        if(SDK_OK != vesync_wifi_aplist_init(total_count))
        {
            return SDK_FAIL;
        }
    }

    if (NULL == bssid || NULL == ssid || strlen((char *)ssid) == 0)
    {
        return SDK_FAIL;
    }

    // 相同SSID的AP只记录信号强度最高的那个
    apinfo = vesync_wifi_get_apinfo_by_ssid(ssid);
    if (NULL != apinfo)
    {
        if (rssi > apinfo->rssi)
        {
            // replace only if it's signal is stronger
            memcpy((void*)apinfo->bssid, (const void*)bssid, WIFI_BSSID_MAX_LEN);
            apinfo->rssi = rssi;
            apinfo->authmode = auth_mode;
        }
        return SDK_OK;
    }

    return vesync_wifi_add_ap(bssid, ssid, rssi, auth_mode);
}


/**
 * @brief  开启扫描
 * @param[in]  void             [无]
 * @return     void             [无]
 * @note
 */
void vesync_wifi_scan_start(void)
{
    if (true == s_wifi_aplist.scanning)
    {
        return;
    }
    s_wifi_aplist.scanning = true;
    vesync_wifi_aplist_clear();
    vhal_wifi_scan_start();
}


/**
 * @brief  扫描完成
 * @param[in]  void             [无]
 * @return     void             [无]
 * @note
 */
void vesync_wifi_scan_done(void)
{
    s_wifi_aplist.scanning = false;
}


/**
 * @brief  释放扫描列表
 * @param[in]  void             [无]
 * @return     void             [无]
 * @note
 */
void vesync_wifi_aplist_clear(void)
{
    VCOM_SAFE_FREE(s_wifi_aplist.aplist);
    s_wifi_aplist.ap_max_num = 0;
    s_wifi_aplist.ap_cnt = 0;
    s_wifi_aplist.scanning = false;
}


/**
 * @brief  获取WIFI列表AP总个数
 * @param[in]  uint16_t         [AP总个数]
 * @return     void             [无]
 * @note
 */
uint16_t vesync_wifi_aplist_get_num(void)
{
    return s_wifi_aplist.ap_cnt;
}


/**
 * @brief  通过序号获取扫描列表中的AP信息
 * @param[in]  index                [AP的序号]
 * @return     vesync_bss_info_t*   [AP信息，不存在则返回空指针]
 * @note
 */
vesync_bss_info_t* vesync_wifi_get_apinfo_by_index(uint16_t index)
{
    if (NULL != s_wifi_aplist.aplist && index < s_wifi_aplist.ap_cnt)
    {
        return &s_wifi_aplist.aplist[index];
    }

    return NULL;
}


/**
 * @brief  通过SSID获取扫描列表中的AP信息
 * @param[in]  ssid                 [AP的SSID]
 * @return     vesync_bss_info_t*   [AP信息，不存在则返回空指针]
 * @note
 */
vesync_bss_info_t* vesync_wifi_get_apinfo_by_ssid(const uint8_t* ssid)
{
    uint16_t apidx = 0;
    vesync_bss_info_t* apinfo = NULL;

    if (NULL == s_wifi_aplist.aplist)
    {
        return NULL;
    }

    for(apidx = 0; apidx < s_wifi_aplist.ap_cnt; apidx ++)
    {
        apinfo = &s_wifi_aplist.aplist[apidx];

        if(0 == strncmp((const char*)ssid, (const char*)apinfo->ssid, WIFI_SSID_MAX_LEN))
        {
            return apinfo;
        }
    }

    return NULL;
}

