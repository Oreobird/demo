/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vhal_bp5758d_test.cpp
 * @brief       vhal_bp5758d测试用例
 * @author      Joshua
 * @date        2021-09-14
 */

#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <gtest/gtest.h>

#include "vdrv_bp5758d.h"
#include "vesync_common.h"
#include "vesync_log.h"

TEST(vdrv_bp5758d_test, vdrv_bp5758d)
{
    int ret = VHAL_FAIL;
    vesync_log_init();

    bp5758d_range_t range;
    memset(&range, 0, sizeof(range));
    range.out_num = 3;
    // 设置OUT1、OUT3和OUT5的电流量程
    range.outs[0] = 1;
    range.outs[1] = 3;
    range.outs[2] = 5;
    uint8_t range_data[3] = {40, 50, 60};
    memcpy(range.data, range_data, sizeof(range_data));
    ret = vdrv_bp5758d_range_cfg(&range);
    EXPECT_EQ(ret, VHAL_OK);


    bp5758d_gray_t gray;
    memset(&gray, 0, sizeof(gray));
    gray.out_num = 2;
    // 设置OUT1、OUT2的灰度
    gray.outs[0] = 1;
    gray.outs[1] = 2;
    uint16_t gray_data[2] = {550, 2};
    memcpy(gray.data, gray_data, sizeof(gray_data));
    ret = vdrv_bp5758d_gray_cfg(&gray);
    EXPECT_EQ(ret, VHAL_OK);

    ret = vdrv_bp5758d_cfg_write();
    EXPECT_EQ(ret, VHAL_OK);
}


