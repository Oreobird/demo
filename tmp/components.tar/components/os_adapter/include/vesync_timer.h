/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_timer.h
 * @brief       timer抽象层，封装timer相关接口
 * @date        2021-04-20
 */

#ifndef __VESYNC_TIMER_H__
#define __VESYNC_TIMER_H__

#include <stdbool.h>
#include "vesync_os.h"

#ifdef __cplusplus
extern "C" {
#endif

/*
* @brief  定时器结构体
*/
typedef struct
{
    long timeout_ms; //定时器超时时间
    bool reload;      //定时类型
    void *handle;    //定时器指针
} vesync_timer_t;

/*
 * @brief  创建定时器
 * @param[in]  timer                 [定时器结构体指针]
 * @param[in]  name                  [定时器名称]
 * @param[in]  cb                    [timout回调函数]
 * @param[in]  cb_arg                [回调函数输入参数]
 * @param[in]  timeout_ms            [超时时间，单位毫秒]
 * @param[in]  reload                [定时类型:
 *                                    0：一次
 *                                    1：周期性]
 * @return int                       [成功：0；失败：-1]
 */
int vesync_timer_new(vesync_timer_t *timer,
                           char *name,
                           void (*cb)(void*),
                           void *cb_arg,
                           long timeout_ms,
                           bool reload);

/*
* @brief  启动定时器
* @param[in]  timer                   [定时器结构体指针]
* @return int                         [成功：0；失败：返回-1]
*/
int vesync_timer_start(vesync_timer_t *timer);

/*
 * @brief  停止定时器
 * @param[in]  timer                   [定时器结构体指针]
 * @return int                         [成功：0；失败：返回-1]
 */
int vesync_timer_stop(vesync_timer_t *timer);

/**
* @brief 修改计时周期
* @param[in] timer                    [定时器结构体指针]
* @param[in] timeout_ms                  [超时时间]
* @return int                         [成功：VOS_OK；失败：VOS_FAIL]
*/
int vesync_timer_change_period(vesync_timer_t *timer, long timeout_ms);

/*
 * @brief  删除定时器
 * @param[in]  timer                   [定时器结构体指针]
 * @return int                         [成功：0；失败：返回-1]
 */
int vesync_timer_free(vesync_timer_t *timer);

#ifdef __cplusplus
}
#endif
#endif /* __VESYNC_TIMER_H__ */

