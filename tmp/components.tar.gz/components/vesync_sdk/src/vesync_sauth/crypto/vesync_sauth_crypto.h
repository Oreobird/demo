/**
 * Copyright © Vesync Technologies Co.Ltd. 2022. All rights reserved.
 * @file        vesync_sauth_crypto.h
 * @brief       Vesync SAUTH模块的加密依赖接口定义
 * @author      Herve
 * @date        2022-01-04
 */
#ifndef __VESYNC_SAUTH_CRYPTO_H__
#define __VESYNC_SAUTH_CRYPTO_H__

#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>

#include "vesync_sauth_private.h"

#ifdef __cplusplus
extern "C" {
#endif

#define SAUTH_CRT_SIG_SZ (64)        // 证书签名值长度
#define SAUTH_X509_CRT_VERSION_1 (0) // X509 V1版本对应值
#define SAUTH_X509_CRT_VERSION_2 (1) // X509 V2版本对应值
#define SAUTH_X509_CRT_VERSION_3 (2) // X509 V3版本对应值
typedef enum
{
    P256R1,
    ED25519
} ECC_CURVE_E;

// ECC-256公钥数据结构定义
typedef uint8_t (ecc256_pk_t)[256 / 8 * 2];
// ECC-256私钥数据结构定义
typedef uint8_t (ecc256_sk_t)[256 / 8];
// ECC-256共享密钥数据结构定义
typedef uint8_t (ecc256_ss_t)[256 / 8];

/**
 * @brief 证书时间信息定义
 */
typedef struct
{
    int year, mon, day;
    int hour, min, sec;
} sauth_crt_time_t;

/**
 * @brief 证书类型定义
 */
typedef enum
{
    SAUTH_DEV_CERT = 1, // 设备证书
    SAUTH_MANU_CERT,    // 厂商证书
    SAUTH_ROOT_CERT,    // 根证书
} SAUTH_CERT_TYPE_E;

/**
 * @brief 证书项Buffer定义
 */
typedef struct
{
    uint8_t *p;
    size_t len;
} sauth_crt_item_t;

/**
 * @brief 设备端证书关键信息定义
 */
typedef struct
{
    sauth_crt_item_t tbs;           // TBSCertificate，证书主体
    sauth_crt_item_t pub;           // SubjectPublicKeyInfo，证书公钥
    sauth_crt_item_t sn;            // CertificateSerialNumber，证书序列号
    sauth_crt_item_t sub_o;         // Name，证书主体名称
    uint8_t sig[SAUTH_CRT_SIG_SZ];  // Dss-Sig-Value，签名值
} sauth_crt_t;

typedef enum
{
    CRYPTO_OK = 0,
    CRYPTO_ERROR = -1,                  // 一般错误：错误参数、锁操作失败或空指针
    CRYPTO_ERR_UNALIGNED_BUF = -2,      // 指针指向未对其的内存缓存区域
    CRYPTO_ERR_SIG_VRF_FAIL = -3,       // 数字签名校验失败
    CRYPTO_ERR_BACKEND = -4,            // 加密后端模块出错
    CRYPTO_ERR_CRT_GET_SUB_O_FAIL = -5, // 读取subject中OrganizationName失败
    CRYPTO_ERR_CRT_EXPIRED = -6,        // 证书已经过期
    CRYPTO_ERR_CRT_INV_FORMAT = -7,     // 证书格式错误
    CRYPTO_ERR_CRT_INV_TBS_FORMAT = -8, // 证书的TBS段格式非法
    CRYPTO_ERR_CRT_INV_TBS_VERSION = -9,// 证书的TBS段版本非法
    CRYPTO_ERR_CRT_INV_TBS_SN = -10,    // 证书的TBS段证书序列号非法
    CRYPTO_ERR_CRT_INV_TBS_SIG = -11,   // 证书的TBS段签名算法标识非法
    CRYPTO_ERR_CRT_INV_TBS_ISS = -12,   // 证书的TBS段签发信息非法
    CRYPTO_ERR_CRT_INV_TBS_VAL = -13,   // 证书的TBS段日期校验信息非法
    CRYPTO_ERR_CRT_INV_TBS_SUB = -14,   // 证书的TBS段主体信息非法
    CRYPTO_ERR_CRT_INV_TBS_PKI = -15,   // 证书的TBS段主体公钥信息非法
    CRYPTO_ERR_CRT_INV_TBS_ALG = -16,   // 证书的TBS段公钥算法标识非法
    CRYPTO_ERR_CRT_INV_TBS_SPK = -17,   // 证书的TBS段公钥信息非法
    CRYPTO_ERR_CRT_INV_SIG_ALG = -18,   // 证书的签名算法标识非法
    CRYPTO_ERR_CRT_INV_SIG_VAL1 = -19,  // 证书的签名信息1非法
    CRYPTO_ERR_CRT_INV_SIG_VAL2 = -20,  // 证书的签名信息1非法
    CRYPTO_ERR_CRT_INV_SIG_VAL3 = -21,  // 证书的签名信息1非法
    CRYPTO_ERR_CRT_INV_SIG_VAL4 = -22,  // 证书的签名信息1非法
    CRYPTO_ERR_CCM_AUTH_FAIL = -23,     // CCM校验不通过
} CRYPTO_ERR_E;

/**
 * @brief 生成一块随机值内存数
 * @param[out]   dest               [指向随机数输出缓存]
 * @param[in]    size               [指定随机数输出缓存大小]
 */
typedef void (*crypto_rnd_block_gen_cb_t)(uint8_t *dest, uint32_t size);

/**
 * @brief SAUTH内部加密模块的初始化
 * @param[in]   cb                  [注册随机数生成回调]
 * @return      int                 [CRYPTO_ERR_E]
 */
int sauth_crypto_init(crypto_rnd_block_gen_cb_t cb);

/**
 * @brief 载入根证书公钥，设备证书私钥和设备证书。通常在测试的时候才会被外部调用。
 * @param[in]   p_root_pub          [指向根证书公钥]
 * @param[in]   root_pub_size       [根证书公钥大小]
 * @param[in]   p_dev_cert_sk       [指向设备证书私钥]
 * @param[in]   dev_cert_sk_size    [设备证书私钥大小]
 * @param[in]   p_dev_cert          [指向设备证书]
 * @param[in]   dev_cert_size       [设备证书大小]
 * @return      int                 [CRYPTO_ERR_E]
 */
int sauth_crypto_load_unsafe_cert(const uint8_t *p_root_pub, int root_pub_size,
                                  const uint8_t *p_dev_cert_sk, int dev_cert_sk_size,
                                  const uint8_t *p_dev_cert, int dev_cert_size);

/**
 * @brief 生成一对ECC公私密钥对，公钥将被返回，私钥会从内部缓存（取决于ECC后端）。
 *          注意这里的密钥对是用于ECDHE，而不是ECDSA。
 * @param[in]   curve               [指定椭圆曲线]
 * @param[out]  pk                  [输出的ECC公钥，缓存需要4字节对其]
 * @return      int                 [CRYPTO_ERR_E]
 */
int sauth_crypto_ecc_keypair_gen(ECC_CURVE_E curve, ecc256_pk_t pk);

/**
 * @brief 根据给定的ECC私钥产生一个ECC公钥
 * @param[in]   curve               [指定椭圆曲线]
 * @param[in]   sk                  [给定的ECC私钥，缓存需要4字节对其]
 * @param[out]  pk                  [输出的ECC公钥，缓存需要4字节对其]
 * @return      int                 [CRYPTO_ERR_E]
 */
int sauth_crypto_ecc_pubkey_compute(ECC_CURVE_E curve, const ecc256_sk_t sk, ecc256_pk_t pk);

/**
 * @brief 根据给定的ECC公私钥对生成共享密钥（私钥不显式给定，会从ECC后端获取）
 * @param[in]   curve               [指定椭圆曲线]
 * @param[in]   pk                  [给定的ECC公钥，缓存需要4字节对其]
 * @param[out]  ss                  [输出的ECC共享密钥，缓存需要4字节对其]
 * @return      int                 [CRYPTO_ERR_E]
 */
int sauth_crypto_ecc_shared_secret_compute(ECC_CURVE_E curve, const ecc256_pk_t pk, ecc256_ss_t ss);

/**
 * @brief 对给定的一个数字摘要进行ECDSA签名（用设备证书的私钥进行签名）
 * @param[in]   curve               [指定椭圆曲线]
 * @param[in]   p_hash              [给定的数字摘要，缓存需要4字节对其]
 * @param[out]  p_sig               [输出的相应的数字签名，缓存需要4字节对其]
 * @return      int                 [CRYPTO_ERR_E]
 */
int sauth_crypto_ecc_sign_by_dev_crt(ECC_CURVE_E curve, const uint8_t *p_hash, uint8_t *p_sig);

/**
 * @brief 通过ECC公钥校验一个ECDSA数字签名
 * @param[in]   curve               [指定椭圆曲线]
 * @param[in]   pk                  [给定的ECC公钥，缓存需要4字节对其]
 * @param[in]   p_hash              [给定的数字摘要。缓存需要4字节对其]
 * @param[in]   p_sig               [给定的数字签名。缓存需要4字节对其]
 * @return      int                 [CRYPTO_ERR_E]
 */
int sauth_crypto_ecc_verify(ECC_CURVE_E curve, const ecc256_pk_t pk, const uint8_t *p_hash, const uint8_t *p_sig);

/**
 * @brief 用根证书公钥校验一个根证书所签发的ECDSA数字签名
 * @param[in]   curve               [指定椭圆曲线]
 * @param[in]   p_hash              [给定的数字摘要。缓存需要4字节对其]
 * @param[in]   p_sig               [给定的数字签名。缓存需要4字节对其]
 * @return      int                 [CRYPTO_ERR_E]
 */
int sauth_crypto_ecc_verify_by_root(ECC_CURVE_E curve, const uint8_t *p_hash, const uint8_t *p_sig);

/**
 * @brief 获取证书长度
 * @param[in]   type                [指定证书类型（设备证书，厂商证书和根证书）]
 * @param[out]  p_cert_len          [指向输出证书长度的缓存]
 * @return      int                 [CRYPTO_ERR_E]
 */
int sauth_crypto_get_crt_len(SAUTH_CERT_TYPE_E type, uint16_t *p_cert_len);

/**
 * @brief 读取二进制DER证书
 * @param[in]   type                [指定证书类型（设备证书，厂商证书和根证书）]
 * @param[out]  p_der               [指向输出DER证书的缓存]
 * @param[in]   der_len             [指定DER证书读取的长度]
 * @return      int                 [CRYPTO_ERR_E]
 */
int sauth_crypto_get_crt_der(SAUTH_CERT_TYPE_E type, uint8_t *p_der, uint16_t der_len);

/**
 * @brief 解析二进制DER证书
 * @param[in]   p_der               [输入的DER证书缓存]
 * @param[in]   der_len             [指定DER证书长度]
 * @param[in]   p_now               [输入的当前GMT时间]
 * @param[out]  p_sauth_crt         [输出的解析得到的证书]
 * @return      int                 [CRYPTO_ERR_E]
 */
int sauth_crypto_crt_parse_der(const uint8_t *p_der, uint16_t der_len, const sauth_crt_time_t *p_now, sauth_crt_t *p_sauth_crt);

/**
 * @brief 计算一段缓存的SHA-256哈希校验值
 * @param[in]   p_in                [指向输入的缓存]
 * @param[in]   in_len              [缓存长度]
 * @param[out]  p_out               [输出的哈希值缓存，要确保字节长度大于32]
 * @return      int                 [CRYPTO_ERR_E]
 */
int sauth_crypto_sha256(uint8_t *p_in, uint32_t in_len, uint8_t *p_out);

/**
 * @brief 基于HMAC-SHA256进行密钥派生
 * @param[in]   key                 [输入的原始密钥材料]
 * @param[in]   key_len             [原始密钥材料长度]
 * @param[in]   salt                [可选的随机元salt]
 * @param[in]   salt_len            [随机数salt的长度]
 * @param[in]   info                [可选的随机元info]
 * @param[in]   info_len            [随机数info的长度]
 * @param[out]  out                 [输出密钥材料]
 * @param[in]   out_len             [输出密钥材料长度]
 * @return      int                 [CRYPTO_ERR_E]
 */
int sauth_crypto_hkdf_sha256(const uint8_t *key, uint8_t key_len,
                             const uint8_t *salt, uint8_t salt_len,
                             const uint8_t *info, uint16_t info_len,
                             uint8_t *out, uint8_t out_len);

/**
 * @brief AES-CCM加密
 * @param[in]   key                 [加密密钥，必须是16字节]
 * @param[in]   iv                  [初始向量（nonce）]
 * @param[in]   iv_len              [初始向量的字节长度，必须是7,8,9,10,11,12或13]
 * @param[in]   add                 [额外数据]
 * @param[in]   add_len             [额外数据的字节长度]
 * @param[in]   in                  [输入的目标加密缓存]
 * @param[in]   in_len              [目标加密缓存的字节长度]
 * @param[out]  out                 [输出的加密完成数据缓存]
 * @param[out]  tag                 [输出的校验值缓存]
 * @param[in]   tag_len             [指定校验值的字节长度，必须是4,6,8,10,12,14或16]
 * @return      int                 [CRYPTO_ERR_E]
 */
int sauth_crypto_ccm_encrypt(const uint8_t *key,
                             const uint8_t *iv, size_t iv_len,
                             const uint8_t *add, size_t add_len,
                             const uint8_t *in, size_t in_len,
                             uint8_t *out,
                             uint8_t *tag, size_t tag_len);

/**
 * @brief AES-CCM解密
 * @param[in]   key                 [加密密钥，必须是16字节]
 * @param[in]   iv                  [初始向量（nonce）]
 * @param[in]   iv_len              [初始向量的字节长度，必须是7,8,9,10,11,12或13]
 * @param[in]   add                 [额外数据]
 * @param[in]   add_len             [额外数据的字节长度]
 * @param[in]   in                  [输入的目标解密缓存]
 * @param[in]   in_len              [目标解密缓存的字节长度]
 * @param[out]  out                 [输出的解密完成数据缓存]
 * @param[in]   tag                 [输入的校验值缓存]
 * @param[in]   tag_len             [指定校验值的字节长度，必须是4,6,8,10,12,14或16]
 * @return      int                 [CRYPTO_ERR_E]
 */
int sauth_crypto_ccm_decrypt(const uint8_t *key,
                             const uint8_t *iv, size_t iv_len,
                             const uint8_t *add, size_t add_len,
                             const uint8_t *in, size_t in_len,
                             uint8_t *out,
                             const uint8_t *tag, size_t tag_len);

#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_SAUTH_CRYPTO_H__ */
