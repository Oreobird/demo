/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        bulb_switch.c
 * @brief       bulb上电触发时间
 * @author      Dave.Ming
 * @date        2021-09-06
 */

#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <stdio.h>

#include "vesync_common.h"
#include "vesync_log.h"
#include "vesync_task.h"
#include "vesync_timer.h"
#include "vesync_production.h"

#include "bulb_flash.h"
#include "bulb_status.h"
#include "bulb_wifi_led.h"
#include "bulb_switch.h"

#include "bulb_board.h"

static vesync_timer_t *s_count_timerhd = NULL; // 定时记录数据定时器

/**
 * @brief 定时器超时回调
 * @param arg        参数(未使用)
 * @return void
 */
static void bulb_count_timer_cb(void *arg)
{
    bulb_flash_upd_cfg(BULB_CFG_POWERNUM, 0);
    bulb_flash_flush_cfg();
}

/**
 * @brief 创建并启动计数置零计时器
 * @param void
 */
static void bulb_count_timer_start(void)
{
    if (NULL == s_count_timerhd)
    {
        // 创建一次性定时器，间隔2000ms。
        s_count_timerhd = vesync_timer_new("bulb_count_timer", bulb_count_timer_cb, NULL, 2000, false);
    }

    if (NULL != s_count_timerhd)
    {
        if (vesync_timer_start(s_count_timerhd) != VOS_OK)
        {
            APP_LOG(LOG_ERROR, "Bulb count timer start fail!!\n");
        }
        else
        {
            APP_LOG(LOG_DEBUG, "Bulb count timer start successful...\n");
        }
    }
    else
    {
        APP_LOG(LOG_ERROR, "Bulb count timer create fail!!\n");
    }
}

/**
 * @brief  判断开关触发配网事件
 */
static void bulb_netcfg_start()
{
    bulb_wifi_led_before_netcfg();
    APP_LOG(LOG_INFO, "Switch trigger config net.\n");
    bulb_ev_t ev;
    ev.act_src = BULB_ACT_SRC_SWITCH;
    ev.id = BULB_EV_NETCFG;
    memset(ev.rsn, 0, sizeof(ev.rsn));
    bulb_app_task_notify(&ev);
}

/**
 * @brief  判断开关触发配设备重置
 */
static void bulb_reset_start(void)
{
    bulb_wifi_led_device_reset();
    APP_LOG(LOG_INFO, "Switch trigger device reset.\n");
    bulb_ev_t ev;
    ev.act_src = BULB_ACT_SRC_SWITCH;
    ev.id = BULB_EV_RESET;
    memset(ev.rsn, 0, sizeof(ev.rsn));
    bulb_app_task_notify(&ev);
}

/**
 * @brief  判断开关触发配设备进入产测
 */
static void bulb_enter_production(void)
{
    APP_LOG(LOG_INFO, "Switch trigger device production test.\n");
    bulb_ev_t ev;
    ev.act_src = BULB_ACT_SRC_SWITCH;
    ev.id = BULB_EV_PRODUCTION;
    memset(ev.rsn, 0, sizeof(ev.rsn));
    bulb_app_task_notify(&ev);
}

void bulb_switch_poweron_cb(void)
{
    int16_t powernum = bulb_flash_get_cfg(BULB_CFG_POWERNUM);

    bulb_count_timer_start();

    if ((BULB_NETCFG_SW_TRG_MIN_TIMES <= powernum) &&
        (BULB_NETCFG_SW_TRG_MAX_TIMES >= powernum))
    {
        bulb_netcfg_start();
    }
    if (BULB_PRD_SW_TRG_MAX_TIMES == powernum)
    {
        bulb_enter_production();
    }
    if ((BULB_RST_SW_TRG_MAX_TIMES <= powernum) &&
        (BULB_PRD_SW_TRG_MAX_TIMES != powernum))
    {
        bulb_reset_start();
    }
}

void bulb_switch_upd_poweron_cnt(void)
{
    int16_t powernum = bulb_flash_get_cfg(BULB_CFG_POWERNUM);

    if (0xFF == powernum)
    {
        APP_LOG(LOG_ERROR, "read powernum fail\n");
        return;
    }
    if (APP_OK != bulb_flash_upd_cfg(BULB_CFG_POWERNUM, powernum + 1))
    {
        APP_LOG(LOG_ERROR, "update powernum fail\n");
    }
    bulb_flash_flush_cfg();
}
