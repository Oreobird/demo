/**
 *  Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vhal_uart.h
 * @brief       UART串口收发接口
 * @date        2021-04-28
 */

#ifndef __VHAL_UART_H__
#define __VHAL_UART_H__

#include <stdint.h>


#ifdef __cplusplus
extern "C"
{
#endif


/**
 * @brief UART外设编号
 */
typedef enum
{
    VHAL_UART_NUM_0 = 0x0,          // UART0
    VHAL_UART_NUM_1 = 0x1,          // UART1
    VHAL_UART_NUM_2 = 0x2,          // UART2
    VHAL_UART_NUM_MAX,
} VHAL_UART_PORT_E;

/**
 * @brief  串口数据接收回调函数指针]
 * @param[in]  uart_num             [串口编号]
 * @param[out] p_buf                [串口数据]
 * @param[in]  buf_len              [串口数据长度]
 * @return     void
 */
typedef void (*vhal_uart_recv_cb_t)(VHAL_UART_PORT_E uart_num, uint8_t *p_buf, uint16_t buf_len);

/**
 * @brief  串口初始化
 * @return     void
 */
void vhal_uart_init(void);

/**
 * @brief  串口参数配置
 * @param[in]  rx_pin               [串口rx引脚]
 * @param[in]  rx_pin               [串口tx引脚]
 * @param[in]  uart_num             [串口编号]
 * @param[in]  baudrate             [串口波特率]
 * @return     void
 */
void vhal_uart_config(uint32_t rx_pin, uint32_t tx_pin, VHAL_UART_PORT_E uart_num, uint32_t baudrate);

/**
 * @brief 注册串口接收数据回调
 * @param[in]  uart_num             [串口编号]
 * @param[in]  cb                   [串口数据接收回调函数]
 * @return     void
 */
void vhal_uart_reg_recv_cb(VHAL_UART_PORT_E uart_num, vhal_uart_recv_cb_t cb);

/**
 * @brief  串口发送数据
 * @param[in]  uart_num             [串口编号]
 * @param[in]  p_buf                [待发送数据]
 * @param[in]  buf_len              [待发送数据长度]
 * @return     int                  [执行结果，0表示成功，其他值表示失败]
 */
int vhal_uart_send(VHAL_UART_PORT_E uart_num, uint8_t *p_buf, uint16_t buf_len);

#ifdef __cplusplus
}
#endif

#endif /* __VHAL_UART_H__ */
