/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_bypass_common.c
 * @brief       bypass处理接口
 * @date        2021-05-14
 */

#include <string.h>
#include <stdio.h>

#include "vhal_utils.h"
#include "vesync_cfg_internal.h"
#include "vesync_common.h"
#include "vesync_device_internal.h"
#include "vesync_log_internal.h"
#include "vesync_bypass_internal.h"
#include "vesync_report_internal.h"
#if CONFIG_VESYNC_SDK_NET_SERVICE_ENABLE
#include "vesync_net_service_internal.h"
#endif
#if CONFIG_VESYNC_SDK_DEVELOPER_ENABLE
#include "vesync_developer_internal.h"
#endif

/**
 * @brief "resetDevice" method数据解析
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  json                     [json数据指针]
 * @return BYPASS_ERR_E                 [错误码]
 */
static BYPASS_ERR_E bypass_method_reset_device(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    SDK_LOG(LOG_DEBUG,"bypass_method_reset_device \r\n");

    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    BYPASS_ERR_E ret = BP_OK;

    cJSON *json_data = cJSON_GetObjectItemCaseSensitive(json, "type");
    if (cJSON_IsString(json_data))
    {
        vesync_bypass_reply_noqos(0, p_msg_ctx->p_trace_msg, NULL);  // 删除设备时会恢复出厂，先回复，再重启
        if (strcmp(json_data->valuestring, "delUser") == 0)
        {
            SDK_LOG(LOG_DEBUG, "delUser\r\n");
            vesync_device_delete_user_data(p_msg_ctx->p_trace_msg->src_type, DEV_DEL_USER_CFG); //删除用户信息
        }
        else if (strcmp(json_data->valuestring, "delDevice") == 0)
        {
            SDK_LOG(LOG_DEBUG, "delDevice\r\n");
            vesync_device_factory_reset(true, p_msg_ctx->p_trace_msg->src_type);  //删除配网信息+复位+用户信息
        }
        else if (strcmp(json_data->valuestring, "delConfig") == 0)
        {
            SDK_LOG(LOG_DEBUG, "delConfig\r\n"); //删除配网信息+复位

            vesync_device_delete_net_cfg_data();
        }
        else if (strcmp(json_data->valuestring, "reboot") == 0)
        {
            SDK_LOG(LOG_DEBUG, "reboot\r\n"); //重启设备

            vesync_device_reboot();
        }
        else
        {
            ret = BP_ERR_ARG;
        }
    }
    else
    {
        ret = BP_ERR_ARG;
    }

    return ret;
}


/**
 * @brief 获取设备信息(非设备状态)
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  json                     [json数据指针]
 * @return BYPASS_ERR_E                 [错误码]
 */
static BYPASS_ERR_E bypass_method_get_dev_info(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    int ret = -1;
    char dev_mac[MAC_ADDR_STR_MAX_LEN] = {0};
    char ap_mac[MAC_ADDR_STR_MAX_LEN] = {0};
    char ip_buf[IP_ADDR_STR_MAX_LEN] = {0};      // 保存ip空间

    cJSON *json_data = NULL;
    net_info_t *p_net_info = NULL;
    bool tcp_debug = false;

    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    // 1.获取设备信息
    ret = vhal_utils_get_dev_mac(VHAL_MAC_WIFI_STA, dev_mac, sizeof(dev_mac));
    if (VHAL_OK != ret || strlen(dev_mac) <= 0)
    {
        snprintf(dev_mac, MAC_ADDR_STR_MAX_LEN, "00:00:00:00:00:00");
    }

    ret = vhal_utils_get_dev_mac(VHAL_MAC_ROUTER, ap_mac, sizeof(ap_mac));
    if (VHAL_OK != ret || strlen(ap_mac) <= 0)
    {
        snprintf(ap_mac, MAC_ADDR_STR_MAX_LEN, "00:00:00:00:00:00");
    }

#if CONFIG_VESYNC_SDK_DEVELOPER_ENABLE
    dbg_cfg_t dbgcfg;
    memset((void *)&dbgcfg, 0, sizeof(dbgcfg));
    vesync_developer_flash_read_dbg_cfg(&dbgcfg);

    if (dbgcfg.enable_developer > 0)    // developer功能开启，才能启动开发者模式
    {
        tcp_debug = true;
    }
#endif

    p_net_info = vesync_net_mgmt_get_net_cfg();

    // 2.json组装
    json_data = cJSON_CreateObject();
    if (NULL != json_data)
    {
        cJSON_AddStringToObject(json_data, "cid", vesync_device_get_cid());
        cJSON_AddStringToObject(json_data, "countryCode", vesync_cfg_get_country_code());
#if defined(PR_FW_TYPE) && (PR_FW_TYPE == 0)
        cJSON_AddStringToObject(json_data, "fwType", "debug");
#else
        cJSON_AddStringToObject(json_data, "fwType", "release");
#endif /* defined(PR_FW_TYPE) && (PR_FW_TYPE == 0) */
        cJSON_AddStringToObject(json_data, "fwVersion", vesync_cfg_get_fw_version());
        cJSON_AddStringToObject(json_data, "mac", dev_mac);
        cJSON_AddStringToObject(json_data, "routerMac", ap_mac);
        cJSON_AddStringToObject(json_data, "wifiSsid", (char *)p_net_info->wifiSSID);
        cJSON_AddStringToObject(json_data, "ip", vhal_utils_get_sta_ip(ip_buf, sizeof(ip_buf)));
        cJSON_AddBoolToObject(json_data,   "tcpDebug", tcp_debug);
    }

    // 3.回复
    vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, json_data);

    return BP_OK;
}


/**
 * @brief 获取设备工作状态 method数据解析
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  json                     [json数据指针]
 * @return BYPASS_ERR_E                 [错误码]
 */
static BYPASS_ERR_E bypass_method_get_working_state_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    UNUSED(json);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    BYPASS_ERR_E ret = BP_OK;
    //查询无需解析json
    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_GET_WORKING_STATE);
    if (method_cb)
    {
        method_cb(p_msg_ctx, NULL);
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

    return ret;
}

static bypass_item_data_t device_method_tbl[] = {
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_RESET_DEVICE, "resetDevice", bypass_method_reset_device, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_GET_DEV_INFO, "getDevInfo",  bypass_method_get_dev_info, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_GET_WORKING_STATE, "getDeviceWorkingState", bypass_method_get_working_state_handle, NULL},
};

void vesync_bypass_device_init(void)
{
    for (int i = 0; i < SIZEOF_ARRAY(device_method_tbl); i++)
    {
        bypass_item_t *item = vesync_bypass_init_item(&device_method_tbl[i]);
        if (item != NULL)
        {
            vesync_bypass_add_item(item);
        }
    }
}

