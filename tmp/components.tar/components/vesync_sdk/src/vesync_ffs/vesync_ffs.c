/**
 * Copyright © Vesync Technologies Co.Ltd. 2019-2021. All rights reserved.
 * @file    vesync_ffs.c
 * @brief   vesync平台与ffs SDK通信接口
 * @author  Dongri.Su
 * @date    20120-02-28
 */

#include "freertos/FreeRTOS.h"
#include "freertos/timers.h"
#include "freertos/queue.h"
#include "freertos/semphr.h"

#include "ffs/common/ffs_result.h"
#include "ffs/common/ffs_check_result.h"
#include "ffs/common/ffs_log_level.h"
#include "ffs/wifi_provisionee/ffs_wifi_provisionee_task.h"

#include "common_def.h"
#include "common_log.h"

#include "vhal_system.h"

#include "vesync_cfgnet.h"
#include "vesync_cfgnet_aplist.h"
#include "vesync_device.h"
#include "vesync_ffs.h"
#include "vesync_ffs_user_context.h"
#include "vesync_flash.h"
#include "vesync_https.h"
#include "vesync_main.h"
#include "vesync_net_service.h"
#include "vesync_task_def.h"
#include "vesync_wifi_led.h"
//#if CONFIG_VESYNC_PLAT_BLE_SERVICE_ENABLE
//#include "vesync_ble_service.h"
//#endif
#include "ffs_pem_file.h"

// 宏定义
#define VESYNC_FFS_PWD "{\"wss_session_tk\":\"%s\",\"signature\":\"%s\",\"host\":\"%s\"}"
#ifdef FFS_SERV_DEBUG
#define VESYNC_FFS_SERV_NAME "test-vdmpmqtt.vesync.com" //测试环境
#else
#define VESYNC_FFS_SERV_NAME "cloud-ffs-mqtt.vesync.com" //预发布环境
#endif

// 全局变量/静态变量
FfsUserContext_t userContext;
FfsResultString_t ffsResult;

// 内部函数/静态函数声明
static TimerHandle_t s_ffs_main_timer = NULL;            // 配网超时判断定时器
static TaskHandle_t s_ffs_taskhd = NULL;                 // FFS任务句柄
static net_info_t *p_ffs_cfg = NULL;                     // 配网数据(FFS配网)
static QueueHandle_t s_ffs_queuehd = NULL;               // FFS数据传输队列
static VESYNC_FFS_STATE_E s_ffs_state = VESYNC_FFS_INIT; // FFS状态
static SemaphoreHandle_t s_wifi_scan_done_sem = NULL;    // WiFi 列表扫描完毕信号量
static bool s_ffs_running_flag = false;                  // FFS运行状态中标志

/**
 * @brief  FFS配网状态获取函数
 * @param[in]  [无]
 * @return     VESYNC_FFS_STATE_E
 */
static VESYNC_FFS_STATE_E get_ffs_state(void)
{
    return s_ffs_state;
}

/**
 * @brief  FFS配网超时判断定时器回调函数
 * @param[in]  arg          [回调函数参数]
 * @return     [无]
 */
static void vesync_ffs_monitor_timeout_cb(void *arg)
{
    (void)arg;

    vesync_ffs_cancel(false);

    vesync_event_center_dispatch_event(EV_CENTER_CFGNET_TIMEOUT, NULL);
    if (NULL != s_ffs_main_timer)
        xTimerStop(s_ffs_main_timer, TIMER_BLOCK_TIME);
}

/**
 * @brief 创建并启动FFS配网监控定时器
 * @param out_time [设置定时器超时时间，单位毫秒]
 */
static int vesync_ffs_monitor_timer_start(uint32_t out_time)
{
    if (NULL == s_ffs_main_timer)
    {
        //创建配FFS网超时定时器，单次模式
        s_ffs_main_timer = xTimerCreate("ffs_main", 1000 / portTICK_RATE_MS, pdFALSE, NULL, vesync_ffs_monitor_timeout_cb);
    }

    if (NULL != s_ffs_main_timer)
    {
        xTimerStop(s_ffs_main_timer, TIMER_BLOCK_TIME);
        xTimerChangePeriod(s_ffs_main_timer, out_time / portTICK_RATE_MS, TIMER_BLOCK_TIME);
        xTimerStart(s_ffs_main_timer, TIMER_BLOCK_TIME);
    }
    else
    {
        PLAT_LOG(LOG_ERROR, "config net timer create fail!!\n");
        return PLAT_FAIL;
    }

    return PLAT_OK;
}

/**
 * @brief 停止并删除FFS配网监控定时器
 */
static void vesync_ffs_monitor_timer_stop(void)
{
    if (NULL != s_ffs_main_timer)
    {
        xTimerStop(s_ffs_main_timer, TIMER_BLOCK_TIME);

        if (pdPASS == xTimerDelete(s_ffs_main_timer, TIMER_BLOCK_TIME))
        {
            s_ffs_main_timer = NULL;
        }
    }
}

/**
 * @brief  给配网任务发消息
 * @param[in]  ulValue      [通知消息，取相应位设置1]
 * @param[in]  p_msg        [给任务通过queue传递的消息内容指针，若无设为NULL]
 * @return     void         [无]
 */
void vesync_ffs_task_notify_withmsg(uint32_t ulValue, void *p_msg)
{
    //PLAT_LOG(LOG_DEBUG, "ulValue = 0x%x \n", ulValue);
    /* send msg to queue first, when cfgnet task get notify, it can get the msg */
    if (vesync_cfgnet_get_mode() != NOT_UNDER_CFGNET)
    {
        if (NULL != p_msg && NULL != s_ffs_queuehd)
        {
            //PLAT_LOG(LOG_DEBUG, "The number of free spaces is %d\n", uxQueueSpacesAvailable(s_ffs_queuehd));
            BaseType_t ret = xQueueSend(s_ffs_queuehd, p_msg, MAX_CFG_NET_QMSG_TR_MS / portTICK_RATE_MS);
            if (pdTRUE != ret)
            {
                /* reset it, we do not plan to store. */
                xQueueReset(s_ffs_queuehd);
                ret = xQueueSend(s_ffs_queuehd, p_msg, MAX_CFG_NET_QMSG_TR_MS / portTICK_RATE_MS);
                if (pdTRUE != ret)
                    PLAT_LOG(LOG_ERROR, "send message to queue fail ret=%d \n", ret);
            }
        }
        if (NULL != s_ffs_taskhd)
        {
            PLAT_LOG(LOG_DEBUG, "ulValue = 0x%x\n", ulValue);
            xTaskNotify(s_ffs_taskhd, ulValue, eSetBits);
        }
    }
    //PLAT_LOG(LOG_DEBUG, "ts: %d\n", vesync_get_system_time_sec());
}

/**
 * @brief 结束FFS配网时清理和重置
 * @param[in] config_mode [配网模式，SMART_CONFIG - smartconfig模式配网；AP_CONFIG - AP模式配网；RESET_NETWORK - 清除配网数据]
 * @param[in] exit_forced [是否强制退出配网，强制退出配网不等发完剩余蓝牙包]
 * @return             [无]
 */
static void vesync_ffs_exit(const config_network_mode_e cfgnet_mode, const bool exit_forced)
{
    VESYNC_SAFE_FREE(p_ffs_cfg);
    VESYNC_SAFE_FREE(ffsResult.signature);
    VESYNC_SAFE_FREE(ffsResult.sessionToken);
    VESYNC_SAFE_FREE(ffsResult.alexaEvtGwEp);
    if (NULL != s_ffs_queuehd)
    {
        vQueueDelete(s_ffs_queuehd);
        s_ffs_queuehd = NULL;
    }

    vhal_wifi_unreg_cfgnet_cb();
    vesync_cfgnet_aplist_clear();
    vesync_ffs_monitor_timer_stop();

    // 之前这段时间窗口期间产生的MQTT重连消息会传递到vesync_event_center_thread().
    vesync_cfgnet_set_mode(NOT_UNDER_CFGNET);
    //vesync_cfgnet_set_status(CONFIG_NET_IDLE);
}

/**
 * @brief FFS配网任务，配网成功或失败后结束该任务。
 */
void vesync_ffs_task(void *args)
{
    BaseType_t notified_ret;
    uint32_t notified_value;
    int subscribe_msgid = -1;
    int mqtt_reconnect_cnt = 0;
    bool ever_connected_success = false;
    config_network_mode_e config_mode = vesync_cfgnet_get_mode();
    bool exit_forced = false;
    bool cfgnet_success = false;

    // 创建定时器
    if (PLAT_OK != vesync_ffs_monitor_timer_start(MAX_FFS_CFG_NET_TIME_MS))
    {
        PLAT_LOG(LOG_ERROR, "Create FFS timer monitor fail!!!\n");
        goto exit;
    }

    // 初始化配网结构体
    p_ffs_cfg = malloc(sizeof(net_info_t));
    if (NULL == p_ffs_cfg)
    {
        PLAT_LOG(LOG_ERROR, "No memory for ffs cfgnet task!\n");
        goto exit;
    }
    memset(p_ffs_cfg, 0, sizeof(net_info_t));

    // 创建队列
    s_ffs_queuehd = xQueueCreate(1, sizeof(void *));
    if (NULL == s_ffs_queuehd)
    {
        PLAT_LOG(LOG_ERROR, "No memory to allocate queue for ffs cfgnet task!\r\n");
        goto exit;
    }

    // 扫描Wi-Fi列表
    vhal_wifi_reg_cfgnet_cb(vesync_cfgnet_aplist_add_hal_cb, NULL);
    vesync_cfgnet_init_bymode(FFS_CONFIG);

    while (1)
    {
        //        PLAT_LOG(LOG_DEBUG,"high_water_mark = %d, free heap %d, ts: %d.\n", vhal_get_stack_high_water_mark(NULL),
        //                vhal_get_min_ever_free_heap_size(), vesync_get_system_time_sec());

        notified_ret = xTaskNotifyWait(0x00000000, 0xFFFFFFFF, &notified_value, RTOS_TASK_WAIT_10000_MS / portTICK_RATE_MS);
        if (pdPASS != notified_ret)
        {
            continue;
        }
        PLAT_LOG(LOG_DEBUG, "notified_value 0x%x\n", notified_value);

        if (notified_value & EV_CENTER_CFGNET_FORCE_EXIT)
        {
            PLAT_LOG(LOG_DEBUG, "config network task exit.\n");

            vesync_wifi_single_led_set_behavior(WIFI_LED_CONFIG_TIMEOUT); // 配网失败，退出配网，灯灭
            vesync_cfgnet_stop_wifi_mqtt();
            exit_forced = true;
            s_ffs_state = VESYNC_FFS_FAIL;
            break;
        }
        else if (notified_value & EV_CENTER_CFGNET_TIMEOUT)
        {
            PLAT_LOG(LOG_DEBUG, "config network timeout.\n");

            vesync_wifi_single_led_set_behavior(WIFI_LED_CONFIG_TIMEOUT); // 配网失败，退出配网，灯灭
            vesync_cfgnet_stop_wifi_mqtt();
            s_ffs_state = VESYNC_FFS_FAIL;

            break;
        }

        if (notified_value & EV_CENTER_WIFI_CONNECTED)
        {
            PLAT_LOG(LOG_DEBUG, "connected wifi.\n");

            //vesync_cfgnet_set_status(CONFIG_NET_CONNECTED_WIFI);
        }

        if (notified_value & EV_CENTER_ROUTER_GOT_IP)
        {
            PLAT_LOG(LOG_DEBUG, "get ip, start mqtt connect.\n");
            //vesync_cfgnet_set_status(CONFIG_NET_GOT_IP);
        }

        if (notified_value & EV_CENTER_CFGNET_RECEIVE_CONFIG)
        {
#if CONFIG_VESYNC_PLAT_MQTT_ENABLE
            if (MQTT_UNINIT == vesync_mqtt_client_get_status())
            {
                char mqtt_pwd[300] = {0};
                snprintf(mqtt_pwd, sizeof(mqtt_pwd), VESYNC_FFS_PWD,
                         ffsResult.sessionToken, ffsResult.signature, ffsResult.alexaEvtGwEp);
                vesync_mqtt_connect(vesync_device_info_get_str(FLAG_DEV_INFO_DEV_CID),
                                    (char *)VESYNC_FFS_SERV_NAME, mqtt_pwd); // pwd需要用token填充
                vesync_event_center_dispatch_event(EV_CENTER_MQTT_RESET, NULL);
            }
#endif
        }

        if (notified_value & EV_CENTER_DNS_RESOLVED)
        {
            PLAT_LOG(LOG_DEBUG, "dns resoved\n");
            //vesync_cfgnet_set_status(CONFIG_NET_DNS_RESOLVED);
        }

        if (notified_value & EV_CENTER_MQTT_CONNECTED)
        {
            PLAT_LOG(LOG_DEBUG, "mqtt connected...\n");

            //vesync_cfgnet_set_status(CONFIG_NET_CONNECTED_SERVER);
            ever_connected_success = true;

            // if(PLAT_OK == vesync_flash_write_net_info(p_ffs_cfg))     // 云端绑定成功后，通知设备才认为是配网成功
            // {
            //     vesync_wifi_single_led_set_behavior(WIFI_LED_LOGIN_SUCCESS);
            //     //vesync_cfgnet_set_status(CFGNET_CFG_SAVE_SUCCESS);
            //     cfgnet_success = true;
            //     break;
            // }
            // else
            // {
            //     PLAT_LOG(LOG_ERROR, "write network config to flash error!\r\n");
            // }

#if CONFIG_VESYNC_PLAT_MQTT_ENABLE
            subscribe_msgid = vesync_subscribe_application_topic();
#endif
            if (-1 == subscribe_msgid)
            {
                /* TODO report subscribe error 72：ERR_CONFIG_SUBSCRIBE_FAIL  */
            }
        }

        if (notified_value & EV_CENTER_MQTT_SUBSCRIBED)
        {

            PLAT_LOG(LOG_DEBUG, "subscribe success.\n");
            //vesync_ffs_monitor_timer_start(MAX_FFS_WAIT_CLOUD_NOTIFY_MS);       // 重新定时（1分钟），等待云绑定用户成功
        }

        if (notified_value & EV_CENTER_FFS_CLOUD_RSP) //18270 恢复原先流程，等待云绑定
        {
            BaseType_t ret = -1;
            uint8_t account_id[ACCOUNT_ID_STR_LEN + BUF_SIZE_4B] = {0};

            if (NULL != s_ffs_queuehd)
            {
                ret = xQueueReceive(s_ffs_queuehd, account_id, MAX_CFG_NET_QMSG_TR_MS);
                if (pdTRUE == ret && NULL != p_ffs_cfg)
                {
                    PLAT_LOG(LOG_DEBUG, "account_id = %s.\n", account_id);
                    if (strlen((char *)account_id) > 0)
                    {
                        snprintf((char *)p_ffs_cfg->user_info.account_id, sizeof(account_id), "%s", account_id);
                    }

                    if (PLAT_OK == vesync_flash_write_net_info(p_ffs_cfg)) // 云端绑定成功后，通知设备才认为是配网成功
                    {
                        vesync_wifi_single_led_set_behavior(WIFI_LED_LOGIN_SUCCESS);
                        //vesync_cfgnet_set_status(CFGNET_CFG_SAVE_SUCCESS);
                        cfgnet_success = true;
                        break;
                    }
                    else
                    {
                        PLAT_LOG(LOG_ERROR, "write network config to flash error!\r\n");
                    }
                }
            }
        }
        if (notified_value & EV_CENTER_MQTT_DISCONNECTED)
        {
            // only calcuate the reconnect count after a successful connect.
            if (true == ever_connected_success)
            {
                mqtt_reconnect_cnt++;
            }

            // reset password after a successful connect.
            if (1 == mqtt_reconnect_cnt)
            {
                char *p_server_domain = (char *)vesync_cfgnet_get_server_domain();
                if (NULL != p_server_domain)
                {
#if CONFIG_VESYNC_PLAT_MQTT_ENABLE
                    vesync_mqtt_client_disconnect_from_cloud();
                    vesync_mqtt_connect(vesync_device_info_get_str(FLAG_DEV_INFO_DEV_CID), p_server_domain, "0");
#endif
                }
            }
        }

        if (notified_value & EV_CENTER_WIFI_SCANDONE)
        {
            PLAT_LOG(LOG_DEBUG, "wifi scan done, total %d APs.\n", vesync_cfgnet_aplist_get_apcount());
            if (s_wifi_scan_done_sem)
            {
                xSemaphoreGive(s_wifi_scan_done_sem);
            }
        }
    }

exit:

    vesync_ffs_exit(config_mode, exit_forced);
    if (true == cfgnet_success)
    {
        // 配网成功，通知平台层
        notified_value = EV_CENTER_CFGNET_SUCCEED;
        vesync_event_center_dispatch_event(notified_value, NULL);
        s_ffs_state = VESYNC_FFS_SUCC;
    }
    PLAT_LOG(LOG_DEBUG, "exit FFS task. notify event_center 0x%x\n", notified_value);
    vTaskDelete(NULL);
}

/**
 * @brief   设置sessionToken
 * @param[in]  userContext     用户定义数据
 * @return  none
 */
static void vesync_ffs_set_session_token(FfsUserContext_t *userContext)
{
    if (!userContext)
    {
        ffsLogError("input params find NULL");
        return;
    }
    uint32_t len = 0;
    char *pString = NULL;

    if (ffsResult.sessionToken)
    {
        free(ffsResult.sessionToken);
    }

    len = strlen(userContext->sessoinToken);
    if (len)
    {
        pString = (char *)malloc(len + 1);
        if (pString)
        {
            ffsResult.sessionToken = pString;
            memcpy(ffsResult.sessionToken, userContext->sessoinToken, len);
            ffsResult.sessionToken[len] = 0;
        }
        PLAT_LOG(LOG_DEBUG, "sessionToken: %s ", userContext->sessoinToken);
    }
}

/**
 * @brief   设置sessionId
 * @param   char* session   sessionID字符串
 * @param   uint8_t len     字符串长度
 * @return  none
 */
static void vesync_ffs_make_signature(FfsUserContext_t *userContext)
{
    if (!userContext)
    {
        ffsLogError("input params find NULL");
        return;
    }
    unsigned char buf[128] = {0};
    unsigned char len = 0;
    if (ffsResult.sessionToken)
    {
        len = vesync_ffs_sign_from_sessionToken(&userContext->devicePrivateKey,
                                                &userContext->devicePublicKey,
                                                ffsResult.sessionToken,
                                                buf);
        if (len)
        {
            char *pString = (char *)malloc(len + 1);
            if (pString)
            {
                ffsResult.signature = pString;
                memcpy(ffsResult.signature, buf, len);
                ffsResult.signature[len] = 0;
            }
        }
    }
}

/**
 * @brief   保存AlexaEventGatewayEndpoint(区分不同地区)
 * @param[in]  userContext   用户定义数据
 * @return  none
 * @note (1) LanguageLocale:"en_GB" AlexaEventGatewayEndpoint":"api.eu.amazonalexa.com";
 *       (2) LanguageLocale:"en_JP" AlexaEventGatewayEndpoint":"api.fe.amazonalexa.com"
 *       (3) LanguageLocale:"en_US" AlexaEventGatewayEndpoint":"api.amazonalexa.com"
 */
static void vesync_ffs_set_alexaEvtGwEp(FfsUserContext_t *userContext)
{
    if (!userContext)
    {
        ffsLogError("input params find NULL");
        return;
    }
    uint32_t len = 0;
    char *pString = NULL;

    if (ffsResult.alexaEvtGwEp)
    {
        free(ffsResult.alexaEvtGwEp);
    }

    len = strlen(userContext->alexaEvtGwEp);
    if (len)
    {
        pString = (char *)malloc(len + 1);
        if (pString)
        {
            ffsResult.alexaEvtGwEp = pString;
            memcpy(ffsResult.alexaEvtGwEp, userContext->alexaEvtGwEp, len);
            ffsResult.alexaEvtGwEp[len] = 0;
        }
        PLAT_LOG(LOG_DEBUG, "alexaEvtGwEp = %s.\n", userContext->alexaEvtGwEp);
    }
}

/**
 * @brief   进入FFS配网模式，并进行MQTT连接、订阅
 * @return  int                 [成功/失败]
 */
int vesync_ffs_start_cfgnet(void)
{
    int ret = FFS_ERROR;
    PLAT_LOG(LOG_INFO, "start ffs cfgnet.\n");
    VESYNC_PRINTF_FREE_HEAP();
    // 读取FFS产测标志位，及是否已使用过的标志位，判断是否继续FFS配网
    ffs_result_flash_data_t fss_result;

    s_wifi_scan_done_sem = xSemaphoreCreateBinary();
    if (NULL == s_wifi_scan_done_sem)
    {
        PLAT_LOG(LOG_ERROR, "wifi scan sem create fail!\n");
        return PLAT_FAIL;
    }

    // Initialize the user context.
    ret = ffsInitializeUserContext(&userContext);
    if (FFS_SUCCESS != ret)
    {
        PLAT_LOG(LOG_ERROR, "Init FFS user context fail!!!\n");
        vSemaphoreDelete(s_wifi_scan_done_sem);
        return PLAT_FAIL;
    }

    // 创建任务
    //vesync_cfgnet_set_status(CONFIG_NET_IDLE);      // so that wifi disconnect event won't send to event_center
    vesync_cfgnet_set_mode(FFS_CONFIG); // Setting mode
    if (pdPASS != xTaskCreate(vesync_ffs_task,
                              FFS_CONFIG_NET_TASK_NAME,
                              FFS_CONFIG_NET_TASK_STACSIZE / sizeof(portSTACK_TYPE),
                              NULL,
                              FFS_CONFIG_NET_TASK_PRIO,
                              &s_ffs_taskhd))
    {
        PLAT_LOG(LOG_ERROR, "Create FFS task fail!!!\n");
        vSemaphoreDelete(s_wifi_scan_done_sem);
        ffsDeinitializeUserContext(&userContext); // Deinitialize the user context.
        return PLAT_FAIL;
    }
    // 记录状态
    vesync_net_set_reconnect_reason(CONFIG_NET_REASON);

    if (xSemaphoreTake(s_wifi_scan_done_sem, pdMS_TO_TICKS(8000)) == pdTRUE) //等待wifi列表扫描同步信号量
    {
        PLAT_LOG(LOG_INFO, "FFS WiFi list scan done!!!\n");
    }

    if (s_wifi_scan_done_sem)
        vSemaphoreDelete(s_wifi_scan_done_sem);

    s_ffs_state = VESYNC_FFS_INIT;
    vesync_wifi_single_led_set_behavior(WIFI_LED_FFS_CONFIGING); // Wi-Fi灯效

    // Execute the Wi-Fi provisionee task.
    s_ffs_running_flag = true; //设ffs流程开始标志
    ret = ffsWifiProvisioneeTask(&userContext);
    s_ffs_running_flag = false; //设ffs流程结束标志
    if ((FFS_SUCCESS != ret) || (userContext.cancel) ||
        (!userContext.setupNetworkSsid) || (!userContext.userNetworkSsid) ||
        (0 == strcmp(userContext.setupNetworkSsid, userContext.userNetworkSsid)))
    {
        PLAT_LOG(LOG_ERROR, "FFS fail!!!\n");
        vesync_event_center_dispatch_event(EV_CENTER_CFGNET_TIMEOUT, NULL); // FFS失败，退出任务
        ffsDeinitializeUserContext(&userContext);                           // Deinitialize the user context.
        vesync_https_finish_and_define();                                   //https release after keep-alive action
        return PLAT_FAIL;
    }

    // 保存配置，用于MQTT连接
    vesync_ffs_set_session_token(&userContext);
    vesync_ffs_set_alexaEvtGwEp(&userContext);
    vesync_ffs_make_signature(&userContext);

    PLAT_LOG(LOG_DEBUG, "FFS backup serverDN %s \n", VESYNC_FFS_SERV_NAME);
    // FFS成功，保存Wi-Fi信息和MQTT信息到结构体中
    p_ffs_cfg->mqtt_config.serverPort = MQTT_DEFAULT_PORT;
    snprintf((char *)p_ffs_cfg->mqtt_config.serverDN, BUF_SIZE_64B, "%s", VESYNC_FFS_SERV_NAME); // MQTT

    if (userContext.userNetworkSsid)
    {
        snprintf((char *)p_ffs_cfg->station_config.wifiSSID, MAX_WIFI_SSID_LEN, "%s", userContext.userNetworkSsid); // Wi-Fi ssid
        PLAT_LOG(LOG_DEBUG, "FFS backup ssid:  %s \n", p_ffs_cfg->station_config.wifiSSID);
    }

    if (userContext.userNetworkPsk && strlen(userContext.userNetworkPsk))
    {
        snprintf((char *)p_ffs_cfg->station_config.wifiPassword, MAX_WIFI_PWD_LEN, "%s", userContext.userNetworkPsk); //Wi-Fi password
        PLAT_LOG(LOG_DEBUG, "FFS backup password:  %s \n", p_ffs_cfg->station_config.wifiPassword);
    }

    // 释放空间
    ffsDeinitializeUserContext(&userContext); // Deinitialize the user context.

    vesync_https_finish_and_define(); //https release after keep-alive action

    // 通知ffs_task进行MQTT连接
    vesync_event_center_dispatch_event(EV_CENTER_CFGNET_RECEIVE_CONFIG, NULL);

    // 等待MQTT连接，最长等待时间由MAX_FFS_CFG_NET_TIME_MS确定
    while (1)
    {
        if (VESYNC_FFS_SUCC == get_ffs_state())
        {
            PLAT_LOG(LOG_DEBUG, "get_ffs_state_SUCC \n");
            ret = PLAT_OK;
            fss_result.magic = FFS_RESULT_MAGIC;
            fss_result.result = true;
            vesync_flash_write_ffs_result_data(&fss_result);
            break;
        }
        else if (VESYNC_FFS_FAIL == get_ffs_state())
        {
            PLAT_LOG(LOG_DEBUG, "get_ffs_state_FAIL \n");
            ret = PLAT_FAIL;
            break;
        }

        vTaskDelay(pdMS_TO_TICKS(250));
    }
    VESYNC_PRINTF_FREE_HEAP();
    return ret;
}

/**
 * @brief   取消FFS配网
 * @param[in]   manual_cancel               [true为手动取消；false为超时取消]
 * @return      void                        [none]
 */
void vesync_ffs_cancel(bool manual_cancel)
{
    // 停止FFS状态机
    userContext.cancel = true;

    // 手动取消
    if (manual_cancel)
    {
        vesync_event_center_dispatch_event(EV_CENTER_CFGNET_FORCE_EXIT, NULL);
    }
}

/**
 * @brief   清除ffs配网及APP配网结果，使设备可以重复进入ffs
 */
void vesync_ffs_result_clean(void)
{
    vesync_flash_clear_ffs_result_data();
    vesync_device_delete_net_config_data();
}

/**
 * @brief   [结束FFS配网并关闭配网进程, 此接口开放给应用层调用]
 * @param   bool true:手动设置停止； false: 自动判断；
 * @return  int    PLAT_OK    停止配网成功
 *                PLAT_FAIL  停止配网失败，但也可能配网进程修改状态延时，可再尝试调用。
 */
int vesync_ffs_stop(bool manual_stop)
{
    if (!manual_stop && FFS_CONFIG != vesync_cfgnet_get_mode())
    {
        return PLAT_OK;
    }
    else
    {
        vesync_ffs_cancel(true);
        uint32_t wait_cnt = 0;
        PLAT_LOG(LOG_DEBUG, " stop ffs task.\n");
        /* wait for ffs STOP and cfgnet task exit. */
        while (s_ffs_running_flag || (vesync_cfgnet_get_mode() != NOT_UNDER_CFGNET))
        {
            vTaskDelay(pdMS_TO_TICKS(100));
            wait_cnt++;
            if (wait_cnt > 100) //最长等待10秒
                break;
        }
        return NOT_UNDER_CFGNET == vesync_cfgnet_get_mode() ? PLAT_OK : PLAT_FAIL;
    }
}

/**
 * @brief  检查ffs配网功能是否有效, 配网成功后即失效
 * @return  int  PLAT_OK FFS配网功能有效, PLAT_FAIL FFS配网功能失效
 */
int vesync_ffs_is_active(void)
{
    int ret = PLAT_OK;
    uint32_t len = 0;

    ffs_result_flash_data_t fss_result;
    len = sizeof(ffs_result_flash_data_t);
    if (vesync_flash_read_ffs_result_data(&fss_result, &len) == PLAT_OK)
    {
        if ((FFS_RESULT_MAGIC == fss_result.magic) && (true == fss_result.result))
        {
            ret = PLAT_FAIL;
        }
    }

#if (FFS_CA_DEBUG == 0)
    int read_len = 0;
    if (vesync_flash_read_cert_chain(NULL, &read_len) == PLAT_FAIL) //FFS证书不存在
    {
        return PLAT_FAIL;
    }

    if (vesync_flash_read_dha_private_key(NULL, &read_len) == PLAT_FAIL) //FFS私钥不存在
    {
        return PLAT_FAIL;
    }
#endif

    return ret;
}

/**
 * @brief  ffs配网功能失能
 * @return  int  PLAT_OK 成功, PLAT_FAIL 失败
 */
int vesync_ffs_disable(void)
{
    ffs_result_flash_data_t fss_result;
    fss_result.magic = FFS_RESULT_MAGIC;
    fss_result.result = true;
    int ret = vesync_flash_write_ffs_result_data(&fss_result);
    return ret;
}
