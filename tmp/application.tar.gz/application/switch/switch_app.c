/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        switch_app.c
 * @brief       switch主任务
 * @author      Charles.Mei
 * @date        2021-07-29
 */


#include <stdio.h>
#include <stdbool.h>
#include <stdint.h>
#include <string.h>

#include "vesync_common.h"
#include "vesync_log.h"

#include "vesync_queue.h"
#include "vesync_task.h"
#include "vesync_memory.h"

#include "vesync_device.h"
#include "vesync_uart.h"
#include "vesync_net_service.h"
#include "vesync_netcfg.h"
#include "vesync_bypass.h"
#include "vesync_ota.h"
#include "vesync_wifi_led.h"

#include "switch_uart_cmd.h"
#include "switch_uart_handle.h"
#include "switch_report.h"
#include "switch.h"
#include "switch_app.h"


#define SWITCH_EVENT_QUEUE_MAX_NUM  16
#define SWITCH_APP_TASK_NAME                   "app_task"
#define SWITCH_APP_TASK_STACSIZE               (1024*4)
#define SWITCH_APP_TASK_PRIO                   TASK_PRIORITY_NORMAL


#if 0
/*
 * @brief 灯配置
 */
typedef struct
{
    uint8_t lightness_min_value;
} light_config_t;

/*
 * @brief 风扇配置
 */
typedef struct
{
} fan_config_t;

/*
 * @brief 主设备，墙壁开关配置
 */
typedef struct
{
    light_config_t light;
    fan_config_t fan;
} switch_config_t;
#endif


/*
 * @brief 网络端1-100%对应的灯实际亮度
 */
typedef struct
{
    uint16_t lightness[SWITCH_LIGHT_PERCENT_MAX];
} switch_light_percents_t;

typedef struct
{
    tl_payload_info_t *p_payload;
    uint16_t payload_len;               // payload长度
    bypass_trace_msg_t *p_trace_msg;
} uart_ack_info_t;


static vesync_queue_t *s_event_queue = NULL;

static switch_status_t s_switch_status;

static switch_light_percents_t s_switch_light_percents;


/**
 * @brief  网络连接成功回调
 */
static void switch_network_connected_cb(void)
{
    switch_ev_t ev;

    memset(&ev, 0, sizeof(ev));
    ev.id = SWITCH_EV_NET_CONNECTED;
    switch_app_task_notify(&ev);
}

/**
 * @brief  配网成功回调
 */
static void switch_network_setup_cb(void)
{
    switch_ev_t ev;

    memset(&ev, 0, sizeof(ev));
    ev.id = SWITCH_EV_NET_SETUP;
    switch_app_task_notify(&ev);
}


/**
 * @brief  串口接收请求回调
 * @param[in]  uart_num                 [串口编号]
 * @param[in]  p_payload                [接收数据字段]
 * @param[in]  payload_len              [payload长度]
 */
static uint32_t switch_uart_recv_request_cb(uint8_t uart_num, void *p_payload, uint16_t payload_len)
{
    UNUSED(uart_num);   // 只用一路串口，不进行校验
    VCOM_NULL_PARAM_CHK(p_payload, return APP_FAIL);
    if (0 == payload_len)
    {
        return APP_FAIL;
    }
    if (UART_TL_PROT_PAYLOAD_VER != ((tl_payload_info_t*)p_payload)->version)
    {
         APP_LOG(LOG_ERROR, "payload version err\n");
         return APP_FAIL;
    }
    if (UART_PAYLOAD_STATUS_NO_ERR != ((tl_payload_info_t*)p_payload)->status_code)
    {
        APP_LOG(LOG_ERROR, "payload status err\n");
        return APP_FAIL;
    }

    switch_ev_t ev;
    ev.buf = vesync_malloc(payload_len);
    if (NULL == ev.buf)
    {
        APP_LOG(LOG_ERROR, "malloc fail\n");
        return APP_FAIL;
    }
    memcpy(ev.buf, p_payload, payload_len);
    ev.id = SWITCH_EV_UART_REQUEST;
    ev.len = payload_len;
    switch_app_task_notify(&ev);

    return APP_OK;
}

/**
 * @brief  串口接收ack回调
 * @param[in]  event                    [串口数据发送成功/失败事件]
 * @param[in]  p_payload                [发送应答帧的数据字段]
 * @param[in]  payload_len              [应答帧的payload长度]
 * @param[in]  p_msg                    [发送的消息]
 */
static uint32_t switch_uart_recv_ack_cb(UART_SEND_TYPE_E event, tl_payload_info_t *p_payload, uint16_t payload_len, uart_msg_send_t *p_msg)
{
    switch_ev_t ev;
    uart_ack_info_t *p_ack_info = NULL;

    memset(&ev, 0, sizeof(ev));

    if (UART_SEND_FAIL == event)
    {
        if (NULL != p_msg)
        {
            APP_LOG(LOG_ERROR, "opcode 0x%04x send fail\n", p_msg->opcode);
        }
        ev.id = SWITCH_EV_UART_FAIL;
    }
    else if (UART_SEND_SUCCESS == event)
    {
        if (UART_TL_PROT_PAYLOAD_VER != p_payload->version)
        {
             APP_LOG(LOG_ERROR, "payload version err\n");
             return APP_FAIL;
        }
        if (UART_PAYLOAD_STATUS_NO_ERR != p_payload->status_code)
        {
            APP_LOG(LOG_ERROR, "payload status err\n");
            return APP_FAIL;
        }
        ev.id = SWITCH_EV_UART_ACK;
    }
    else
    {
        // should not be here
        return APP_FAIL;
    }
    p_ack_info = vesync_malloc(sizeof(uart_ack_info_t));
    if (NULL == p_ack_info)
    {
        APP_LOG(LOG_ERROR, "malloc fail\n");
        return APP_FAIL;
    }
    memset(p_ack_info, 0, sizeof(uart_ack_info_t));
    if (NULL != p_payload)
    {
        p_ack_info->p_payload = vesync_malloc(payload_len);
        if (NULL != p_ack_info->p_payload)
        {
            memcpy(p_ack_info->p_payload, p_payload, payload_len);
        }
        else
        {
            APP_LOG(LOG_ERROR, "malloc fail\n");
            goto exit;
        }
    }
    p_ack_info->payload_len = payload_len;
    if (NULL != p_msg && NULL != p_msg->p_app_data)
    {
        p_ack_info->p_trace_msg = vesync_malloc(sizeof(bypass_trace_msg_t));
        if (NULL != p_ack_info->p_trace_msg)
        {
            memcpy(p_ack_info->p_trace_msg, p_msg->p_app_data, sizeof(bypass_trace_msg_t));
        }
        else
        {
            APP_LOG(LOG_ERROR, "malloc fail\n");
            goto exit;
        }
    }

    ev.len = sizeof(uart_ack_info_t);
    ev.buf = p_ack_info;
    switch_app_task_notify(&ev);
    return APP_OK;

exit:
    VCOM_SAFE_FREE(p_ack_info->p_trace_msg);
    VCOM_SAFE_FREE(p_ack_info->p_payload);
    VCOM_SAFE_FREE(p_ack_info);
    return APP_FAIL;
}

/**
 * @brief  uart请求处理
 * @param[in]  p_payload        [通知消息]
 * @return     payload_len              [成功：SDK_OK，失败：SDK_FAIL]
 */
static void switch_request_payload_handle(tl_payload_info_t *p_payload, uint16_t payload_len)
{

    // payload长度等于data+4，此宏平台未开发给app，建议后续开放
    switch_uart_request_handle(p_payload->op_code, p_payload->payload_data, payload_len - 4);

    VCOM_SAFE_FREE(p_payload);
}

/**
 * @brief  uart回复处理
 * @param[in]  event_id        [通知消息]
 * @return     int              [成功：SDK_OK，失败：SDK_FAIL]
 */
static void switch_ack_payload_handle(uart_ack_info_t *p_ack_info)
{
    int err_code = BP_ERR_CMD_EXECUTE_FAIL;
    // payload长度等于data+4，此宏平台未开发给app，建议后续开放
    if (NULL != p_ack_info->p_payload && p_ack_info->payload_len >= 4)
    {
        APP_LOG(LOG_DEBUG, "opcode : %04x\n", p_ack_info->p_payload->op_code);
        if (UART_PAYLOAD_STATUS_NO_ERR == switch_uart_ack_handle(p_ack_info->p_payload->op_code,
            p_ack_info->p_payload->payload_data, p_ack_info->payload_len - 4))
        {
            err_code = BP_ERR_NO_ERR;
        }
    }
    if (NULL != p_ack_info->p_trace_msg)
    {
        vesync_bypass_reply_noqos(err_code, p_ack_info->p_trace_msg, NULL);
    }
    VCOM_SAFE_FREE(p_ack_info->p_payload);
    VCOM_SAFE_FREE(p_ack_info->p_trace_msg);
    VCOM_SAFE_FREE(p_ack_info);
}

/**
 * @brief  uart发送失败处理
 * @param[in]  event_id        [通知消息]
 * @return     int              [成功：SDK_OK，失败：SDK_FAIL]
 */
static void switch_uart_send_fail_handle(uart_ack_info_t *p_ack_info)
{
    if (NULL != p_ack_info->p_trace_msg)
    {
        vesync_bypass_reply_noqos(BP_ERR_CMD_EXECUTE_FAIL, p_ack_info->p_trace_msg, NULL);
    }
    VCOM_SAFE_FREE(p_ack_info->p_payload);
    VCOM_SAFE_FREE(p_ack_info->p_trace_msg);
    VCOM_SAFE_FREE(p_ack_info);
}


/**
 * @brief  事件处理
 * @param[in]  event_id        [通知消息]
 * @return     int              [成功：SDK_OK，失败：SDK_FAIL]
 */
static void switch_app_event_handle(switch_ev_t *ev)
{
    switch (ev->id)
    {
        case SWITCH_EV_UART_REQUEST:
            switch_request_payload_handle(ev->buf, ev->len);
            break;
        case SWITCH_EV_UART_ACK:
            switch_ack_payload_handle(ev->buf);
            break;
        case SWITCH_EV_UART_FAIL:
            switch_uart_send_fail_handle(ev->buf);
            break;
        case SWITCH_EV_NET_CONNECTED:
            // 强制覆盖设备变化原因，以当前状态立刻更新给云端
            strncpy(s_switch_status.chg_rsn, STAT_CHG_RSN_RECONNECT_STR, sizeof(s_switch_status.chg_rsn) - 1);
            switch_report_status_change(&s_switch_status);
            memset(s_switch_status.chg_rsn, 0, sizeof(s_switch_status.chg_rsn));
            s_switch_status.light.report_flag = 0;
            s_switch_status.fan.report_flag = 0;
            break;
        case SWITCH_EV_NET_SETUP:
            // 强制覆盖设备变化原因，以当前状态立刻更新给云端
            strncpy(s_switch_status.chg_rsn, STAT_CHG_RSN_RECONNECT_STR, sizeof(s_switch_status.chg_rsn) - 1);
            switch_report_status_change(&s_switch_status);
            memset(s_switch_status.chg_rsn, 0, sizeof(s_switch_status.chg_rsn));
            s_switch_status.light.report_flag = 0;
            s_switch_status.fan.report_flag = 0;
            break;
        case SWITCH_EV_UNKNOWN:
        default:
        APP_LOG(LOG_ERROR, "invalid event\n");
    }
}

/**
 * @brief  switch主任务
 */
static void switch_app_task(void *arg)
{
    UNUSED(arg);
    APP_LOG(LOG_DEBUG, "-------app task running--------\n");
#if 1
    switch_ev_t ev;

    while(1)
    {
        int ret = vesync_queue_recv(s_event_queue, &ev, VESYNC_OS_WAIT_FOREVER);
        if (ret != VOS_OK)
        {
            APP_LOG(LOG_ERROR, "Event queue recv fail\n");
            return;
        }

        switch_app_event_handle(&ev);
    }
#else
    switch_uart_inquire_status();
    vesync_sleep(6000);
    switch_uart_set_min_lightness(10, NULL);
    vesync_sleep(6000);
    switch_uart_test_min_lightness(10, 100, NULL);
    vesync_sleep(6000);
    switch_uart_set_light_mode(1, NULL);
    switch_uart_set_light_mode(2, NULL);
    switch_uart_set_light_mode(3, NULL);
    vesync_sleep(6000);
    switch_uart_set_switch(DEVICE_LIGHT, 1, 0, NULL);
    switch_uart_set_switch(DEVICE_LIGHT, 0, 0, NULL);
    vesync_sleep(6000);
    switch_uart_set_switch(DEVICE_LIGHT, 1, 1800, NULL);
    switch_uart_set_switch(DEVICE_LIGHT, 0, 1800, NULL);
    vesync_sleep(6000);
    switch_uart_set_switch(DEVICE_FAN, 1, 0, NULL);
    switch_uart_set_switch(DEVICE_FAN, 0, 0, NULL);
    vesync_sleep(6000);
    switch_uart_set_lightness(60, 0, NULL);
    vesync_sleep(6000);
    switch_uart_set_lightness(60, 1800, NULL);
    vesync_sleep(6000);
    switch_uart_set_level(DEVICE_LIGHT, 2, 0, NULL);
    switch_uart_set_level(DEVICE_LIGHT, 10, 1800, NULL);
    vesync_sleep(6000);
    switch_uart_set_level(DEVICE_FAN, 2, 0, NULL);
    switch_uart_set_level(DEVICE_FAN, 2, 4, NULL);
    vesync_sleep(6000);
    vesync_wifi_led_set_behavior(WIFI_LED_CONFIG_TIMEOUT);
    vesync_sleep(6000);
    vesync_wifi_led_set_behavior(WIFI_LED_CONFIGING);
    vesync_sleep(6000);
    vesync_wifi_led_set_behavior(WIFI_LED_WIFI_DISC);
    vesync_sleep(6000);
    switch_uart_test_cmd();
    vesync_sleep(6000);
    switch_uart_reset_mcu(RESET_RANK_RESTART, NULL);
    switch_uart_reset_mcu(RESET_RANK_FACTORY, NULL);
    switch_uart_reset_mcu(RESET_RANK_ONLY_CLEAR_DATA, NULL);
    vesync_sleep(6000);
    switch_uart_set_production_state(PRODUCTION_START);
    switch_uart_set_production_state(PRODUCTION_RUNNING);
    vesync_sleep(6000);
    switch_uart_set_production_result(PRD_CID_ERR);
#endif
}

/**
 * @brief  网络端亮度转uart端亮度
 * @param[in]  lightness                [网络端亮度]
 * @return     int                      [uart端亮度，0表示执行失败]
 * @note    uart端亮度使用MCU控制的真实百分比
 * @note    网络端亮度是将新的最低亮度替换1%（初始最低亮度）后的新百分比
 * @note    此函数只在初始化时使用，初始化完成后调用提供给外部的转换函数
 */
static uint16_t lightness_net_to_uart(uint8_t lightness)
{
    float gap = 1.0;
    if (lightness > SWITCH_LIGHT_PERCENT_MAX)
    {
        return 0;
    }
    // 最低亮度为初始值，不必转换
    if (SWITCH_LIGHT_LIGHTNESS_MIN == s_switch_status.light.min_lightness)
    {
        return lightness * SWITCH_LIGHT_LIGHTNESS_PRECISION;
    }
    gap = (float)(SWITCH_LIGHT_LIGHTNESS_MAX - s_switch_status.light.min_lightness) /
        (float)(SWITCH_LIGHT_LIGHTNESS_MAX - SWITCH_LIGHT_LIGHTNESS_MIN);
    // 四舍五入
    return (uint16_t)((float)s_switch_status.light.min_lightness + ((float)lightness -
        SWITCH_LIGHT_LIGHTNESS_MIN) * gap + 0.5) / 10 * 10; // 舍弃个位数
}

/**
 * @brief  网络端亮度初始化
 * @note    此函数需要从uart获取到最低亮度后调用
 * @note    网络端亮度是将新的最低亮度替换1%（初始最低亮度）后的新百分比
 */
static void switch_lightness_net_init(void)
{
    uint8_t net_lightness = SWITCH_LIGHT_PERCENT_MIN;

    memset(&s_switch_light_percents, 0, sizeof(s_switch_light_percents));

    for (; net_lightness <= SWITCH_LIGHT_PERCENT_MAX; ++net_lightness)
    {
        s_switch_light_percents.lightness[net_lightness - 1] = lightness_net_to_uart(net_lightness);
    }
}

/**
 * @brief  switch初始化设备状态
 */
static void switch_load_status(void)
{
    // 以合法值初始化，MCU软硬件版本不初始化(用于辨别请求MCU数据是否成功)
    memset(&s_switch_status, 0, sizeof(s_switch_status));
    s_switch_status.light.min_lightness = SWITCH_LIGHT_LIGHTNESS_MIN;
    s_switch_status.light.net_lightness = 1;
    s_switch_status.light.uart_lightness = 10;
    s_switch_status.light.level = 1;
    s_switch_status.light.light_mode = 1;
    s_switch_status.fan.level = 1;

    switch_lightness_net_init();
    switch_uart_inquire_status();
}

/**
 * @brief  获取设备工作状态回调函数
 * @return     bool                     [true:设备运行中，false:设备空闲]
 */
static bool switch_get_work_status_cb(void)
{
    if (false == s_switch_status.light.onoff && false == s_switch_status.fan.onoff)
    {
        return false;
    }
    else
    {
        return true;
    }
}

/**
 * @brief  升级前处理回调，关机
 */
static void switch_ota_mcu_pre_cb()
{
    switch_app_update_status_chg_rsn(STAT_CHG_RSN_PROT_STR);
    switch_uart_set_switch(DEVICE_FAN, 0, 0, NULL);
    switch_uart_set_switch(DEVICE_LIGHT, 0, 0, NULL);
}

/**
 * @brief mcu固件升级结果回调函数
 * @param[in]   err                     [0表示升级成功，其他表示失败错误码]
 */
static void switch_ota_mcu_post_cb(uint32_t err_code)
{
    APP_LOG(LOG_DEBUG, "ota mcu err %d....", err_code);

    if(vesync_net_client_get_status() == NETWORK_ONLINE)
    {
        vesync_wifi_led_set_behavior(WIFI_LED_LOGIN_SUCCESS);   // 设置WiFi灯状态
    }
    switch_load_status();    // 同步设备状态
}

/**
 * @brief  switch主任务初始化
 * @return     int                      [成功：APP_OK，失败：APP_FAIL]
 */
int switch_app_init(void)
{
    s_event_queue = vesync_queue_new(SWITCH_EVENT_QUEUE_MAX_NUM * sizeof(switch_ev_t), sizeof(switch_ev_t));
    if (s_event_queue == NULL)
    {
        APP_LOG(LOG_ERROR, "App event queue create failed\n");
        return APP_FAIL;
    }

    int ret = vesync_task_new(SWITCH_APP_TASK_NAME, NULL, switch_app_task, NULL, SWITCH_APP_TASK_STACSIZE, SWITCH_APP_TASK_PRIO, NULL);
    if (ret != VOS_OK)
    {
        APP_LOG(LOG_ERROR, "App task create failed\n");
        vesync_queue_free(s_event_queue);
        return APP_FAIL;
    }
    vesync_device_update_fw_ver(UPG_TP_MCU, "NULL");
    vesync_device_update_fw_priority(UPG_TP_WIFI, 0);
    vesync_device_update_fw_priority(UPG_TP_MCU, 1);
    vesync_uart_reg_recv_cb(SWITCH_UART_NUM, switch_uart_recv_request_cb);
    vesync_uart_reg_tx_event_cb(SWITCH_UART_NUM, switch_uart_recv_ack_cb);
    switch_load_status();
    vesync_net_event_reg_nwk_conn_cb(switch_network_connected_cb);
    vesync_net_cfg_reg_success_cb(switch_network_setup_cb);

    vesync_ota_reg_get_status_cb(switch_get_work_status_cb);
    vesync_ota_reg_mcu_pre_post_cb(switch_ota_mcu_pre_cb, switch_ota_mcu_post_cb);
    return APP_OK;
}

/**
 * @brief  给switch主任务发通知
 * @param[in]  ev                       [通知消息]
 * @return     int                      [成功：APP_OK，失败：APP_FAIL]
 */
int switch_app_task_notify(switch_ev_t *ev)
{
    int ret = vesync_queue_send(s_event_queue, ev, VESYNC_OS_NO_WAIT);
    if (ret != VOS_OK)
    {
        APP_LOG(LOG_ERROR, "Event send fail\n");
        return SDK_FAIL;
    }

    return SDK_OK;
}


/**
 * @brief  uart端亮度转网络端亮度
 * @param[in]  lightness                [uart端亮度]
 * @return     int                      [网络端亮度，0表示执行失败]
 * @note    uart端亮度可能对应多个网络端亮度，此处取最小的值
 */
static uint8_t lightness_uart_to_net(uint16_t lightness)
{
    uint8_t net_lightness = SWITCH_LIGHT_PERCENT_MIN;

    if (lightness > SWITCH_LIGHT_LIGHTNESS_MAX || lightness < s_switch_status.light.min_lightness)
    {
        return 0;
    }
    if (SWITCH_LIGHT_LIGHTNESS_MIN == s_switch_status.light.min_lightness)
    {
        return lightness / SWITCH_LIGHT_LIGHTNESS_PRECISION;
    }
    for (; net_lightness <= SWITCH_LIGHT_PERCENT_MAX; ++net_lightness)
    {
        if (s_switch_light_percents.lightness[net_lightness - 1] == lightness)
        {
            return net_lightness;
        }
    }

    return ((float)(lightness - s_switch_status.light.min_lightness + 1) /
        ((float)(SWITCH_LIGHT_LIGHTNESS_MAX - s_switch_status.light.min_lightness + 1))) + 0.5;
}

/**
 * @brief  网络端亮度转uart端亮度
 * @param[in]  lightness                [网络端亮度]
 * @return     uint16_t                 [uart端亮度，0表示执行失败]
 * @note    uart端亮度使用MCU控制的真实百分比
 * @note    网络端亮度是将新的最低亮度替换1%（初始最低亮度）后的新百分比
 */
uint16_t switch_lightness_net_to_uart(uint8_t lightness)
{
    if (lightness > SWITCH_LIGHT_PERCENT_MAX || lightness < SWITCH_LIGHT_PERCENT_MIN)
    {
        return 0;
    }
    return s_switch_light_percents.lightness[lightness - 1];
}

/**
 * @brief  设置网络端亮度
 * @param[in]  lightness                [网络端亮度]
 * @note    uart设置亮度时必须先调用此接口
 * @note    由于uart端亮度对应多个网络端亮度，所以设置前必须保存
 */
void switch_app_set_net_lightness(uint8_t lightness)
{
    if (lightness != s_switch_status.light.net_lightness)
    {
        s_switch_status.light.net_lightness = lightness;
        s_switch_status.light.report_flag |= LIGHT_LIGHTNESS_CHANGE_FLAG;
    }
}

/**
 * @brief  更新switch状态
 * @param[in]  status                   [switch状态]
 * @return     int                      [成功：APP_OK，失败：APP_FAIL]
 */
int switch_app_update_status(switch_status_t *status)
{
    static uint8_t init_flag = 0;
    char str_mcu_ver[MAX_SW_VER_STR_LEN];

    if (0 == init_flag)
    {
        init_flag = 1;
        APP_LOG(LOG_DEBUG, "status init\n");
        memcpy(&s_switch_status, status, sizeof(switch_status_t));
        memset(str_mcu_ver, 0, sizeof(str_mcu_ver));
        snprintf(str_mcu_ver, sizeof(str_mcu_ver), "%d.%d.%02d", s_switch_status.mcu_sw_ver[0],
            s_switch_status.mcu_sw_ver[1], s_switch_status.mcu_sw_ver[2]);
        vesync_device_update_fw_ver(UPG_TP_MCU, str_mcu_ver);
        vesync_production_set_mcu_ready();
        switch_lightness_net_init();
        s_switch_status.light.net_lightness = lightness_uart_to_net(s_switch_status.light.uart_lightness);
        memset(s_switch_status.chg_rsn, 0, sizeof(s_switch_status.chg_rsn));
        strncpy(s_switch_status.chg_rsn, STAT_CHG_RSN_NONE_STR, sizeof(s_switch_status.chg_rsn) - 1);
        s_switch_status.light.report_flag = 0;
        s_switch_status.fan.report_flag = 0;
    }
    else
    {
        APP_LOG(LOG_DEBUG, "status update\n");
        if (s_switch_status.light.onoff != status->light.onoff)
        {
            s_switch_status.light.report_flag |= LIGHT_ONOFF_CHANGE_FLAG;
            s_switch_status.light.onoff = status->light.onoff;
        }

        if (s_switch_status.light.min_lightness != status->light.min_lightness)
        {
            s_switch_status.light.report_flag |= LIGHT_MIN_LIGHTNESS_CHANGE_FLAG;
            s_switch_status.light.min_lightness = status->light.min_lightness;

            // 由于最低亮度改变，以下函数需要重新初始化
            switch_lightness_net_init();
            // 最低亮度改变后直接更新uart_lightness
            s_switch_status.light.uart_lightness = status->light.uart_lightness;
            // 调用switch_app_set_net_lightness()后得到的uart_lightness反馈异常说明改变来自设备，更新该值
            if (switch_lightness_net_to_uart(s_switch_status.light.net_lightness) != status->light.uart_lightness)
            {
                s_switch_status.light.report_flag |= LIGHT_LIGHTNESS_CHANGE_FLAG;
                s_switch_status.light.net_lightness = lightness_uart_to_net(s_switch_status.light.uart_lightness);
            }
            if (s_switch_status.light.level != status->light.level)
            {
                s_switch_status.light.report_flag |= LIGHT_LEVEL_CHANGE_FLAG;
                s_switch_status.light.level = status->light.level;
            }
        }
        else
        {
            if (s_switch_status.light.uart_lightness != status->light.uart_lightness)
            {
                s_switch_status.light.uart_lightness = status->light.uart_lightness;
                // 调用switch_app_set_net_lightness()后得到的uart_lightness反馈异常说明改变来自设备，更新该值
                if (switch_lightness_net_to_uart(s_switch_status.light.net_lightness) != status->light.uart_lightness)
                {
                    s_switch_status.light.net_lightness = lightness_uart_to_net(s_switch_status.light.uart_lightness);
                    s_switch_status.light.report_flag |= LIGHT_LIGHTNESS_CHANGE_FLAG;
                }
                if (s_switch_status.light.level != status->light.level)
                {
                    s_switch_status.light.report_flag |= LIGHT_LEVEL_CHANGE_FLAG;
                    s_switch_status.light.level = status->light.level;
                }
            }
        }

        if (s_switch_status.light.light_mode != status->light.light_mode)
        {
            s_switch_status.light.report_flag |= LIGHT_MODE_CHANGE_FLAG;
            s_switch_status.light.light_mode = status->light.light_mode;
        }

        if (s_switch_status.fan.onoff != status->fan.onoff)
        {
            s_switch_status.fan.report_flag |= FAN_ONOFF_CHANGE_FLAG;
            s_switch_status.fan.onoff = status->fan.onoff;
        }

        if (s_switch_status.fan.level != status->fan.level)
        {
            s_switch_status.fan.report_flag |= FAN_LEVEL_CHANGE_FLAG;
            s_switch_status.fan.level = status->fan.level;
        }
    }

    switch_app_update_status_chg_rsn(STAT_CHG_RSN_BTN_STR);
    switch_report_status_change(&s_switch_status);
    memset(s_switch_status.chg_rsn, 0, sizeof(s_switch_status.chg_rsn));
    s_switch_status.light.report_flag = 0;
    s_switch_status.fan.report_flag = 0;

    return APP_OK;
}

/**
 * @brief  更新switch改变原因
 * @param[in]  status                   [switch状态]
 * @return     int                      [成功：APP_OK，失败：APP_FAIL]
 */
int switch_app_update_status_chg_rsn(const char* chg_rsn)
{
    VCOM_NULL_PARAM_CHK(chg_rsn, return APP_FAIL);

    if (0 != strlen(s_switch_status.chg_rsn))
    {
        APP_LOG(LOG_INFO, "change reason can not overwritten\n");
        return APP_FAIL;
    }
    strncpy(s_switch_status.chg_rsn, chg_rsn, sizeof(s_switch_status.chg_rsn) - 1);
    return APP_OK;
}

/**
 * @brief  获取开关状态
 * @param[in]  dev_id                   [设备id]
 * @return     bool                     [开关状态]
 */
bool switch_app_get_switch_onoff(DEVICE_ID_E dev_id)
{
    switch (dev_id)
    {
        case DEVICE_LIGHT:
            return s_switch_status.light.onoff;
        case DEVICE_FAN:
            return s_switch_status.fan.onoff;
        default:
            // 默认返回false
            return false;
    }
    return false;
}

/**
 * @brief  获取档位
 * @param[in]  dev_id                   [设备id]
 * @return     uint8_t                  [档位，0表示获取失败]
 */
uint8_t switch_app_get_level(DEVICE_ID_E dev_id)
{
    switch (dev_id)
    {
        case DEVICE_LIGHT:
            return s_switch_status.light.level;
        case DEVICE_FAN:
            return s_switch_status.fan.level;
        default:
            return 0;
    }
    return 0;
}

/**
 * @brief  获取灯亮度
 * @return     uint8_t                  [亮度，0表示获取失败]
 */
uint8_t switch_app_get_light_lightness(void)
{
    return s_switch_status.light.net_lightness;
}

