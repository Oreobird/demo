/*
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file        vesync_ota.c
* @brief       OTA模块接口实现
* @date        2021-05-19
*/

#include <string.h>

#include "vesync_cfg.h"
#include "vesync_task.h"
#include "vesync_common.h"
#include "vesync_memory.h"
#include "vesync_log_internal.h"

#include "vhal_ota.h"
#include "vhal_wifi.h"
#include "vesync_report_internal.h"
#include "vesync_ota_internal.h"
#include "vesync_ota_mcu_internal.h"

static vesync_ota_t s_ota;

/*-----------------------------------------------------------------------------*
*                                 内部函数实现                          *
*-----------------------------------------------------------------------------*/

/**
 * @brief OTA清除标志位
 */
static void vesync_ota_clear(void)
{
    memset(&s_ota, 0, sizeof(vesync_ota_t));
    s_ota.upg_info.upg_state = UPG_IDLE;
}

/**
* @brief 检测当前设备是否满足升级需求
* @return bool                   [可以升级，返回true；不可以升级，返回false]
*/
static bool vesync_ota_req_check(void)
{
    // 1 电池设备电量检测

    // 2 设备是否在工作

    return true;
}

/**
* @brief  回复固件升级状态及进度
* @param[in] state                [固件升级状态或错误码]
* @param[in] dl_percent           [固件升级进度，在固件升级状态为升级中时才是有效值]
*/
static void vesync_ota_response_upgrade_status(UPGRADE_STATE_E state, uint8_t dl_percent)
{
    int ret = 0;
    static UPGRADE_STATE_E upg_state = UPG_IDLE;

    // 状态发生改变，上报
    if (state != upg_state)
    {
        if ((s_ota.upg_info.upg_entry == UPG_EN_WIFI) /*&& (vesync_mqtt_client_get_status() == MQTT_ONLINE)*/) // Wi-Fi通道升级，从Wi-Fi通道上报状态
        {
            ret = vesync_report_firm_up(s_ota.upg_info.upg_type, s_ota.upg_info.fw_ver, s_ota.upg_info.fw_url, (uint8_t)state, dl_percent);
            SDK_LOG(LOG_DEBUG, "upload ota state, return val = %d.\n", ret);
        }
        else // BLE通道升级，从BLE通道上报状态
        {

        }
    }
}

/**
* @brief OTA升级状态处理回调函数
* @param[in] status                [ota状态]
* @param[in] progress              [固件下载进度]
*/
static void vesync_ota_status_cb(VHAL_OTA_STATE_E status, uint8_t progress)
{
    switch (status)
    {
        case VHAL_OTA_ST_PROCESS:
#if CONFIG_VESYNC_SDK_PRODUCTION_ENABLE
        if(vesync_production_get_status() == PRODUCTION_RUNNING)
        {
            if ((50 == progress)&&(progress != s_ota.upg_info.upg_progress))
            {
                vesync_ota_response_upgrade_status(UPG_DOWNLOADING, progress);
                s_ota.upg_info.upg_progress = progress;
            }
        }
        else
#endif
        {
            if (progress - s_ota.upg_info.upg_progress >= 10) // 按10%的刻度进行上报，要不然上报太频繁了
            {
                vesync_ota_response_upgrade_status(UPG_DOWNLOADING, progress);
                s_ota.upg_info.upg_progress = progress;
            }
        }

            break;
        case VHAL_OTA_ST_DL_COMP:
            vesync_ota_response_upgrade_status(UPG_UPGRADING, progress);
            break;
        case VHAL_OTA_ST_SUCCESS:
            // Wi-Fi固件OTA升级成功，设备重启再上报成功的状态；MCU和BLE升级成功，直接通过接口上报
            if (s_ota.upg_info.upg_entry != UPG_EN_WIFI)
            {
                vesync_ota_response_upgrade_status(UPG_SUCCESS, progress);
                s_ota.upg_code = UPG_SUCCESS;
            }
            break;
        case VHAL_OTA_ST_TIME_OUT:
            vesync_ota_response_upgrade_status(UPG_TIME_OUT, progress);
            s_ota.upg_code = UPG_TIME_OUT;
            break;
        //case VHAL_OTA_ST_MODEL_ILLEGAL:
        //    vesync_ota_response_upgrade_status(UPG_MODEL_ILLEGAL, progress);
        //    break;
        //case VHAL_OTA_ST_SW_VER_ERR:
        //    vesync_ota_response_upgrade_status(UPG_SW_VER_ERR, progress);
        //    break;
        //case VHAL_OTA_ST_HW_VER_ERR:
        //    vesync_ota_response_upgrade_status(UPG_HW_VER_ERR, progress);
        //    break;
        //case VHAL_OTA_ST_COUNTRY_CODE_ERR:
        //    vesync_ota_response_upgrade_status(UPG_COUNTRY_CODE_ERR, progress);
        //    break;
        //case VHAL_OTA_ST_MD5_FAIL:
        //    vesync_ota_response_upgrade_status(UPG_MD5_FAIL, progress);
        //    break;
        case VHAL_OTA_ST_URL_ERR:
            vesync_ota_response_upgrade_status(UPG_URL_ERR, progress);
            s_ota.upg_code = UPG_URL_ERR;
            break;
        case VHAL_OTA_ST_HTTP_CONN_FAIL:
            vesync_ota_response_upgrade_status(UPG_CONN_FAIL, progress);
            s_ota.upg_code = UPG_CONN_FAIL;
            break;
        case VHAL_OTA_ST_DL_FAIL:
            vesync_ota_response_upgrade_status(UPG_DL_FAIL, progress);
            s_ota.upg_code = UPG_DL_FAIL;
            break;
        case VHAL_OTA_ST_OUT_MEM:
        case VHAL_OTA_ST_FLASH_ERR:
        case VHAL_OTA_ST_FAIL:
            vesync_ota_response_upgrade_status(UPG_FAIL, progress);
            s_ota.upg_code = UPG_FAIL;
            break;
        default:
            break;
    }
}

#if (CONFIG_VESYNC_SDK_HTTP_ENABLE)
#if (PR_OTA_TYPE_MCU > 0)
/*
 * @brief MCU进行ota时状态回调函数
 * @param[in] state             [ota状态]
 * @param[in] param             [固件下载状态]
 * @return void
 */
static void vesync_ota_mcu_state_cb(OTA_MCU_STATE_E state, ota_mcu_state_param_u *param)
{
    SDK_LOG(LOG_INFO, "vesync_ota_mcu_state_cb %d\n",state);

    vesync_timer_change_period(&s_ota.timeout_timer, VESYNC_OTA_MCU_TIMEOUT_TIME);

    switch (state)
    {
        case OTA_MCU_STATE_DOWNLOAD_RESULT:
            SDK_LOG(LOG_INFO, "OTA_MCU_STATE_DOWNLOAD_RESULT %d\n", param->download_result);
            break;
        case OTA_MCU_STATE_RESULT:
            SDK_LOG(LOG_INFO, "OTA_MCU_STATE_RESULT %d\n", param->ota_mcu_result);
            break;
        default:
            break;
    }
}
#endif
/**
 * @brief 版本号(x.x.x)转十六进制
 * @param[in] ver
 * @return uint32_t             [版本号十六进制]
 */
static uint32_t version_to_hex(char *ver)
{
    uint32_t acc = 0, ret = 0;

    if(NULL == ver)
    {
        return 0;
    }

    do {
        char cc = *ver;
        switch (cc)
        {
            case '0':
            case '1':
            case '2':
            case '3':
            case '4':
            case '5':
            case '6':
            case '7':
            case '8':
            case '9':
                acc = acc * 10 + (cc - '0');
                break;
            case '.':
                ret = ret << 8 | acc;
                acc = 0;
                break;
            case '\0':
                ret = ret << 8 | acc;
                break;
            default:
                return 0;
        }
    } while (*ver++) ;

    return ret;
}

#endif


/**
* @brief  修改头部内部信息pad
* @param[in]  item               [头部内部信息]
* @param[in]  len                [内部信息长度]
*/
static void vesync_ota_modify_pad(uint8_t *item, uint8_t len)
{
    for (uint8_t idx = 0; idx < len; idx++)
    {
        if (0xFF == item[idx])
        {
            item[idx] = 0x0;
            break;
        }
    }
}

/**
* @brief  校验vesync添加的头部
* @param[in]  header             [vesync添加的头部, 128bytes长度]
* @param[in]  len                [vesync添加的头部长度]
* @return     int                [0表示成功，其他值表示失败]
*/
static int vesync_ota_check_header(uint8_t *p_header, int len)
{
    vesync_ota_header_t header;
    uint8_t percent = 0;

    if (NULL == p_header)
    {
        SDK_LOG(LOG_ERROR, "p_header is an null pointer, return!!\n");
        return SDK_FAIL;
    }

    if (sizeof(vesync_ota_header_t) != len)
    {
        SDK_LOG(LOG_ERROR, "Header len is %d, invalid!!\n", len);
        return SDK_FAIL;
    }

    memset(&header, 0, sizeof(vesync_ota_header_t));
    memcpy(&header, p_header, len);

    //LOG_RAW_HEX(LOG_DEBUG, "OTA head:", (uint8_t *)&header, len);
    vesync_ota_modify_pad(header.md5, sizeof(header.md5));
    vesync_ota_modify_pad(header.model, sizeof(header.model));
    vesync_ota_modify_pad(header.sw_ver, sizeof(header.sw_ver));
    vesync_ota_modify_pad(header.hw_ver, sizeof(header.hw_ver));
    vesync_ota_modify_pad(header.country_list, sizeof(header.country_list));

    //LOG_RAW_HEX(LOG_DEBUG, NULL, header.md5, sizeof(header->md5));
    //LOG_RAW_HEX(LOG_DEBUG, NULL, header.model, sizeof(header->model));
    //LOG_RAW_HEX(LOG_DEBUG, NULL, header.sw_ver, sizeof(header->sw_ver));
    //LOG_RAW_HEX(LOG_DEBUG, NULL, header.hw_ver, sizeof(header->hw_ver));
    //LOG_RAW_HEX(LOG_DEBUG, NULL, header.country_list, sizeof(header->country_list));

    SDK_LOG(LOG_DEBUG, "Vesync header len is %d.\n", sizeof(vesync_ota_header_t));
    SDK_LOG(LOG_DEBUG, "Vesync header md5 is %s.\n", header.md5);
    SDK_LOG(LOG_DEBUG, "Vesync header model is %s.\n", header.model);
    SDK_LOG(LOG_DEBUG, "Vesync header sw_ver is %s.\n", header.sw_ver);
    SDK_LOG(LOG_DEBUG, "Vesync header hw_ve is %s.\n", header.hw_ver);
    SDK_LOG(LOG_DEBUG, "Vesync header country_list is %s.\n", header.country_list);

    if (0 != strcmp((char *)header.model, PR_MODEL) &&
        0 != strcmp((char *)header.model, PR_ALIAS_MODEL))
    {
        vesync_ota_response_upgrade_status(UPG_MODEL_ILLEGAL, percent);   // 产品不匹配
        return SDK_FAIL;
    }
    if (0 != strcmp((char *)header.sw_ver, (char *)s_ota.upg_info.fw_ver))
    {
        vesync_ota_response_upgrade_status(UPG_SW_VER_ERR, percent);   // 软件版本不匹配
        return SDK_FAIL;
    }
    if (0 != strcmp((char *)header.hw_ver, PR_HW_VERSION))
    {   // Wi-Fi模块硬件版本号(非产品硬件版本号)
        vesync_ota_response_upgrade_status(UPG_HW_VER_ERR, percent);   // 硬件版本不匹配
        return SDK_FAIL;
    }
    if (NULL == strstr((char *)header.country_list, PR_COUNTRY_CODE))
    {
        vesync_ota_response_upgrade_status(UPG_COUNTRY_CODE_ERR, percent);   // 国家码不支持
        return SDK_FAIL;
    }

    if (strlen((char *)header.md5) > 0)
    {
        if (NULL == s_ota.p_head_md5)
        {
            s_ota.p_head_md5 = (uint8_t *)vesync_malloc(MAX_MD5_LEN);
            if (NULL != s_ota.p_head_md5)
            {
                memset((char *)s_ota.p_head_md5, 0, MAX_MD5_LEN);
                snprintf((char *)s_ota.p_head_md5, MAX_MD5_LEN, "%s", header.md5);
            }
        }
    }

    return SDK_OK;
}

/**
 * @brief 版本号比较
 * @param[in]  char *               [字符串形式的版本号x.x.xx]
 * @param[in]  char *               [字符串形式的版本号x.x.xx]
 * @return int                      [ver1大于ver2，返回1；ver1小于ver2，返回-1；相等返回0]
 */
static int vesync_ota_version_cmp(char *p_ver1, char *p_ver2)
{
    int vnum1 = 0, vnum2 = 0;
    int vlen1 = 0, vlen2 = 0;
    int i=0, j=0;

    if (NULL == p_ver1 || NULL == p_ver2)
    {
        return 0;
    }

    vlen1 = strlen(p_ver1);
    vlen2 = strlen(p_ver2);
    //  loop untill both string are processed
    for (i=0,j=0; (i < vlen1 || j < vlen2); )
    {
        //  storing numeric part of version 1 in vnum1
        while (i < vlen1 && p_ver1[i] != '.')
        {
            vnum1 = vnum1*10 + (p_ver1[i] - '0');
            i++;
        }

        //  storing numeric part of version 2 in vnum2
        while (j < vlen2 && p_ver2[j] != '.')
        {
            vnum2 = vnum2*10 + (p_ver2[j] - '0');
            j++;
        }

        if (vnum1 > vnum2)
            return 1;

        if (vnum2 > vnum1)
            return -1;

        //  if equal, reset variables and go for next numeric
        vnum1 = 0;
        vnum2 = 0;
        i++;
        j++;
    }

    return 0;
}

/**
* @brief 固件md5校验回调函数指针
* @param[in]  p_md5               [固件实际md5]
* @return     int                 [0表示校验通过，其他值表示校验失败]
*/
static int vesync_ota_check_md5(uint8_t *p_md5)
{
    if (NULL == p_md5 || NULL == s_ota.p_head_md5 || strlen((char *)s_ota.p_head_md5) <= 0)
    {
        vesync_ota_response_upgrade_status(UPG_MD5_FAIL, 100);   // MD5校验失败
        return SDK_FAIL;
    }

    if (0 != strcmp((char *)p_md5, (char *)s_ota.p_head_md5))
    {
        vesync_ota_response_upgrade_status(UPG_MD5_FAIL, 100);   // MD5校验失败
        SDK_LOG(LOG_ERROR, "md5 check fail, p_md5:%s, header.md5:%s.\n", p_md5, s_ota.p_head_md5);
        return SDK_FAIL;
    }

    return SDK_OK;
}

/*
* @brief ota超时处理
* @param[in] arg              [超时回调参数]
*/
static void vesync_ota_timeout_cb(void *arg)
{
    //vesync_response_upgrade_status(UPG_TIME_OUT, 0);
    if (s_ota.upg_info.upg_type == UPG_TP_WIFI)
    { // 停止WiFi模块的升级
        vhal_ota_set_timeout_flag(true);
    }
    else
    {
#if (PR_OTA_TYPE_MCU > 0)
        vesync_ota_mcu_timeout_set();
#endif
        // stop mcu/ble ota process
    }

    SDK_LOG(LOG_INFO, "OTA timeout cb, type = %d\n", s_ota.upg_info.upg_type);
}

/*
 * @brief ota任务处理
 * @param pvParameters   任务创建时传递的参数
 */
static void vesync_ota_task_handler(void *arg)
{
    int ret = -1;
    char url[MAX_URL_LEN] = {0};

    // 创建超时定时器
    ret = vesync_timer_new(&s_ota.timeout_timer, "ota_timer", vesync_ota_timeout_cb, NULL, OTA_TIMEOUT_TIME, false);
    if (ret != VOS_OK)
    {
        SDK_LOG(LOG_ERROR, "create ota timeout timer fail!!!\n");
        vesync_ota_response_upgrade_status(UPG_FAIL, 0);
        //TODO:FIXME
        //VERR_UPLOAD(VERR_LINK_MOD_COM(VERR_TIMER_CREATE_FAIL), vhal_get_free_heap_size());
        goto exit;
    }

    // 启动定时器
    ret = vesync_timer_start(&s_ota.timeout_timer);
    if (ret != VOS_OK)
    {
        SDK_LOG(LOG_ERROR, "start ota timeout timer fail!!!\n");
        vesync_ota_response_upgrade_status(UPG_FAIL, 0);
        //TODO:FIXME
        //VERR_UPLOAD(VERR_LINK_MOD_COM(VERR_TIMER_START_FAIL), UPG_FAIL);
        goto exit;
    }

    // 固件下载链接
    snprintf(url, sizeof(url), "%s", (char *)arg);

    if (UPG_TP_WIFI == s_ota.upg_info.upg_type) // 升级Wi-Fi模块的固件
    {
        SDK_LOG(LOG_INFO, "Waiting Wi-Fi connected......\n");
        if (!vhal_wifi_get_link_status(5000))
        {
            SDK_LOG(LOG_ERROR, "OTA connect Wi-Fi timeout!\n");
            // 上报WiFi连接失败状态
            vesync_ota_response_upgrade_status(UPG_CONN_FAIL, 0);
            goto exit;
        }

        // Wi-Fi固件升级前准备，回调给应用层进行特殊处理
        if (s_ota.wifi_process)
        {
            s_ota.wifi_process(true);
        }

        // 版本比较，判断是升级or降级
        bool dg_flag = false;
        if (vesync_ota_version_cmp(s_ota.upg_info.fw_ver, PR_FW_VERSION) < 0)
        {   // 待升级的版本号 < 固件当前版本号
            dg_flag = true;
            SDK_LOG(LOG_INFO, "Wi-Fi firmware downgrade\n");
        }

//#if defined(CONFIG_IDF_TARGET_ESP8266) && CONFIG_IDF_TARGET_ESP8266
//        vesync_ota_response_upgrade_status(UPG_DOWNLOADING, 0);      //先报一条下载中，esp8266下载过程不上报
//#endif

        ret = vhal_ota_start(url, dg_flag);   // 升级过程状态，在回调函数中进行更新
        if (VHAL_OK != ret)
        {
            SDK_LOG(LOG_ERROR, "OTA failed!\n");
            if (s_ota.wifi_process)          // 升级失败，回调给应用层进行现场恢复
            {
                s_ota.wifi_process(false);
            }
            goto exit;
        }
        SDK_LOG(LOG_INFO, "OTA success.\n");

        // 网络断开原因保存到flash
        //vesync_net_reconnect_reason_set(UPGRATE_REASON);
        if (s_ota.save_reconn_reason)
        {
#if CONFIG_VESYNC_SDK_PRODUCTION_ENABLE
            if (vesync_production_get_status() == PRODUCTION_RUNNING)
            {
                s_ota.save_reconn_reason(PRODUCTION_REASON);
            }
            else
            {
                s_ota.save_reconn_reason(UPGRATE_REASON);
            }
#else
            s_ota.save_reconn_reason(UPGRATE_REASON);
#endif
        }

        // OTA成功，重启设备切换固件分区
        // 重启
        vesync_device_reboot();
    }

#if CONFIG_VESYNC_SDK_HTTP_ENABLE
    else // 升级MCU/BLE的固件
    {
        // 网络判断
        SDK_LOG(LOG_INFO, "Waiting Wi-Fi connected......\n");
        if (vhal_wifi_get_link_status(5000))
        {
            SDK_LOG(LOG_DEBUG, "OTA connect Wi-Fi success!\n");
        }
        else
        {
            SDK_LOG(LOG_INFO, "Wi-Fi connecte fail! Try to use the ble....\n");
            vesync_ota_response_upgrade_status(UPG_CONN_FAIL, 0);

#if (CONFIG_VESYNC_HAL_BLE_ENABLE && PR_OTA_TYPE_MCU > 0)
            if (vhal_ble_is_connected())
            {
                SDK_LOG(LOG_DEBUG, "OTA connect BLE success!\n");
            }
            else
            {
                SDK_LOG(LOG_ERROR, "OTA connect BLE failed!\n");
                // 上报BLE连接失败状态
                vesync_ota_response_upgrade_status(UPG_FAIL, 0);
                goto exit;
            }
#endif
        }

        // 固件下载到flash
        int recv_len = 10;
        char send_buf[10] = {0};
        char recv_buf[10] = {0};

        vesync_http_init(url);
        vesync_ota_response_upgrade_status(UPG_DOWNLOADING, 0);

        ret = vesync_http_request(HTTP_METHOD_GET, send_buf, recv_buf, &recv_len, HTTP_GET_OTA, 3000);
        if (ret != SDK_OK)
        {
            SDK_LOG(LOG_ERROR, "OTA http download fail.\n");
            vesync_ota_response_upgrade_status(UPG_DL_FAIL, 0);
            goto exit;
        }
        SDK_LOG(LOG_DEBUG, "OTA http get firm len = %d.\n", recv_len);

        vesync_ota_response_upgrade_status(UPG_UPGRADING, 100);         //固件下载完成上报6

#if PR_OTA_TYPE_BLE
        if (UPG_TP_BLE == s_ota.upg_info.upg_type)
        { // 升级BLE固件
            SDK_LOG(LOG_DEBUG, "BLE ota.\n");
        }
#endif

#if (PR_OTA_TYPE_MCU > 0)
        if ((UPG_TP_MCU == s_ota.upg_info.upg_type)
#if (PR_OTA_TYPE_MCU > 1)
            || (UPG_TP_MCU2 == s_ota.upg_info.upg_type)
#endif
#if (PR_OTA_TYPE_MCU > 2)
            || (UPG_TP_MCU3 == s_ota.upg_info.upg_type)
#endif
            )
        { // 升级MCU固件
            uint8_t sw_ver[FW_VER_HEX_LEN]={3,2,1};
            uint32_t ver_val = version_to_hex(s_ota.upg_info.fw_ver);
            sw_ver[2] = (ver_val>>16)&0x00ff;
            sw_ver[1] = (ver_val>>8)&0x00ff;
            sw_ver[0] = ver_val&0x00ff;

            //memcpy(sw_ver, s_upg_stat.fw_ver, FW_VERSION_HEX_LEN);
            vesync_ota_mcu_reg_state_cb(vesync_ota_mcu_state_cb);

            uint32_t err_code = vesync_ota_mcu_start(sw_ver,recv_len);
            if(0 != err_code)
            {
                SDK_LOG(LOG_ERROR, "OTA MCU fail.\n");
                vesync_ota_response_upgrade_status(err_code, 0);
            }
            else
            {
                SDK_LOG(LOG_ERROR, "OTA MCU success.\n");
                vesync_ota_response_upgrade_status(UPG_SUCCESS, 100);
            }

            if (s_ota.mcu_upgrade_cb)  //调用回调函数，通知应用层
            {
                s_ota.mcu_upgrade_cb(err_code);
            }
        }
#endif
    }
#endif //CONFIG_VESYNC_SDK_HTTP_ENABLE

exit:
    SDK_LOG(LOG_INFO, "vesync_ota_task delete....\n");
    vesync_timer_free(&s_ota.timeout_timer);
    VCOM_SAFE_FREE(s_ota.p_head_md5);
    vesync_ota_clear(); // 清除标志位
    vesync_task_free(NULL);
}

/*-----------------------------------------------------------------------------*
 *                                 外部函数实现                          *
 *-----------------------------------------------------------------------------*/

/**
 * @brief OTA初始化
 */
void vesync_ota_init(void)
{
    memset(&s_ota, 0, sizeof(vesync_ota_t));
    s_ota.upg_info.upg_state = UPG_IDLE;
    s_ota.save_reconn_reason = vesync_flash_write_reconnect_reason;

#if (CONFIG_VESYNC_SDK_HTTP_ENABLE && PR_OTA_TYPE_MCU > 0)
    vesync_ota_mcu_init();
#endif
}

/**
 * @brief 注册获取工作状态回调函数
 * @param[in] cb              [应用层获取工作状态回调函数]
 */
void vesync_ota_reg_work_status_cb(vesync_ota_get_work_status_cb_t cb)
{
    s_ota.get_work_status_cb = cb;
}

/**
 * @brief 注册停止设备工作回调函数
 * @param[in] cb              [应用层获取工作状态回调函数]
 */
void vesync_ota_reg_stop_work_cb(vesync_ota_stop_work_cb_t cb)
{
    s_ota.stop_device_work_cb = cb;
}

/**
 * @brief 注册"升级前准备工作/升级失败"处理回调函数
 * @param[in] cb              [应用层处理"升级前准备工作/升级失败"函数]
 */
void vesync_ota_reg_before_and_after_process(vesync_ota_process_cb_t cb)
{
    s_ota.wifi_process = cb;
}

#if (CONFIG_VESYNC_SDK_HTTP_ENABLE && PR_OTA_TYPE_MCU > 0)
/**
 * @brief 注册mcu固件升级结果回调函数
 * @param[in]                 [mcu固件升级结果回调函数]
 */
void vesync_ota_reg_mcu_upgrade_result_cb(vesync_ota_mcu_upgrade_cb_t cb)
{
    s_ota.mcu_upgrade_cb = cb;
}
#endif


/**
 * @brief 获取升级错误码
 * @return uint8_t            [升级错误码]
 */
uint8_t vesync_ota_get_upgrade_code(void)
{
    return s_ota.upg_code;
}


/**
 * @brief 检测当前设备是否正在升级
 * @return bool                [正在升级，返回true；不在升级，返回false]
 */
bool vesync_ota_is_upgrading(void)
{
    return UPG_IDLE != s_ota.upg_info.upg_state;
}

/**
 * @brief 获取设备ota升级前的工作状态
 * @return  bool               [true:设备处于工作状态, false:设备不处于工作状态，或者OTA时不关心设备工作状态]
 */
bool vesync_ota_get_device_work_status(void)
{
    bool ret = false;

    if (s_ota.get_work_status_cb)
    {
        ret = s_ota.get_work_status_cb();
    }

    return ret;
}

/**
 * @brief 启动OTA
 * @param[in] upg_info              [升级信息]
 * @return int                      [成功/失败]
 */
int vesync_ota_start(upgrade_info_t upg_info)
{
    // 如果当前正处于升级过程，直接退出
    if (UPG_IDLE != s_ota.upg_info.upg_state)
    {
        SDK_LOG(LOG_ERROR, "Firmware is being upgraded!\n");
        return SDK_FAIL;
    }

    memset(&s_ota.upg_info, 0, sizeof(upgrade_info_t));
    s_ota.upg_info.upg_entry = upg_info.upg_entry;
    s_ota.upg_info.upg_type = upg_info.upg_type;
    s_ota.upg_info.upg_mode = upg_info.upg_mode;
    snprintf(s_ota.upg_info.fw_ver, sizeof(s_ota.upg_info.fw_ver), "%s", upg_info.fw_ver);
    snprintf(s_ota.upg_info.fw_url, sizeof(s_ota.upg_info.fw_url), "%s", upg_info.fw_url);

    // 判断当前设备是否支持OTA
    if (!vesync_ota_req_check())
    {
        SDK_LOG(LOG_ERROR, "This device is currently not upgradeable!!\n");
        // 通过ble/WiFi反馈不可升级状态。
        vesync_ota_response_upgrade_status(UPG_NOT_SUPT, 0);
        goto exit;
    }

    uint32_t  stop_work_tmout = 0;

    //设备工作中并且强制升级
    if ((UPG_MODE_HIGH == s_ota.upg_info.upg_mode) && (true == vesync_ota_get_device_work_status()))
    {
        if (s_ota.stop_device_work_cb)
        {
            s_ota.stop_device_work_cb();

            while (true == vesync_ota_get_device_work_status() && (stop_work_tmout < OTA_STOP_WORK_TIMEOUT/100))
            {
                vesync_sleep(100);
                stop_work_tmout++;
            }

            if (stop_work_tmout >= OTA_STOP_WORK_TIMEOUT/100)      //停止设备工作超时
            {
                vesync_ota_response_upgrade_status(UPG_NOT_SUPT, 0);
                goto  exit;
            }
        }
        else
        {
            SDK_LOG(LOG_INFO, "ota stop work cb not register!\n");
        }
    }

    // 注册HAL层OTA升级状态回调函数
    vhal_ota_status_reg_cb(vesync_ota_status_cb);              // 升级状态
    vhal_ota_check_header_reg_cb(vesync_ota_check_header, sizeof(vesync_ota_header_t));     // vesync固件头部校验(不包含md5校验)
    vhal_ota_check_md5_reg_cb(vesync_ota_check_md5);           // vesync固件头部md5与实际md5对比


    int ret = vesync_task_new(OTA_TASK_NAME, vesync_ota_task_handler, s_ota.upg_info.fw_url, OTA_TASK_STACKSIZE, OTA_TASK_PRIO, NULL);
    if (ret != VOS_OK)
    {
        SDK_LOG(LOG_ERROR, "create OTA task fail!\n");
        //TODO:FIXME
        //VERR_UPLOAD(VERR_TASK_CREATE_FAIL, vhal_get_free_heap_size());
        goto exit;
    }

    return SDK_OK;

exit:
    VCOM_SAFE_FREE(s_ota.p_head_md5);
    // 清除标志位
    vesync_ota_clear();
    return SDK_FAIL;
}


