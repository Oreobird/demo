/**
 *  Copyright © Vesync Technologies Co.Ltd. 2019-2021. All rights reserved.
 * @file        vesync_tl_frame_parse.c
 * @brief       数据帧协议头部解析和封装
 * @author      zhenlang
 * @date        2019-06-25
 */

#include "vesync_tl_frame_parse.h"
#include <string.h>


/**
 * @brief  计算和校验值
 * @param[in]  frame            [被校验数据帧结构]
 * @return    uint8_t           [校验值]
 * @note   该接口用于测试
 */
uint8_t vesync_tl_frame_checksum_cal(tl_frame_recv_info_t *frame)
{
    uint8_t sum = 0;
    uint16_t i = 0;

    if(NULL == frame)
    {
        return 0;
    }

    sum += TL_FRAME_HEAD;
    sum += frame->ctrl.data;
    sum += frame->seq_id;
    sum += (frame->payload_len & 0x00ff);
    sum += ((frame->payload_len >> 8) & 0x00ff);

    for (i = 0; i < frame->payload_len; i++)
    {
        sum += frame->p_payload[i];
    }

    sum = ~sum;

    return sum;
}

/**
 * @brief  验证校验和计算结果
 * @param[in]  frame            [被校验数据帧结构]
 * @return     uint8_t          [校验结果 0:表示校验成功；-1：表示校验失败]
 */
uint8_t vesync_tl_frame_checksum_verify(tl_frame_recv_info_t *frame)
{
    uint8_t sum = 0;
    uint16_t i = 0;

    if (NULL == frame)
    {
        return -1;
    }

    sum += TL_FRAME_HEAD;
    sum += frame->ctrl.data;
    sum += frame->seq_id;
    sum += (frame->payload_len & 0x00ff);
    sum += ((frame->payload_len >> 8) & 0x00ff);
    sum += frame->checksum;

    for (i = 0; i < frame->payload_len; i++)
    {
        sum += frame->p_payload[i];
    }

    return ((0xff == sum )? 0 : -1);
}

/**
 * @brief  传输层(transport layer)协议解析，协议数据按照顺序逐个字节传入
 * @param[in]  byte_data        [当前传入的字节数据]
 * @param[in]  max_pl_len       [payload最大长度]
 * @param[out] frame            [功能模块的结构体指针]
 * @return     uint8_t          [解析的结果，0：完整数据帧；-1:非完整数据帧]
 */
uint8_t vesync_tl_frame_decode(uint8_t byte_data, uint32_t max_pl_len, tl_frame_recv_info_t *frame)
{
    uint8_t ret = -1;
    uint16_t temp = 0;

    if ((NULL == frame) || (max_pl_len <= 0))
    {
        return ret;
    }

    switch (frame->state)
    {
        case TL_FRAME_RECV_HEAD:
            if (TL_FRAME_HEAD == byte_data)            // 确定帧头起始位置
            {
                frame->state = TL_FRAME_RECV_CTRL;
            }
            break;

        case TL_FRAME_RECV_CTRL:
            frame->ctrl.data = byte_data;
            frame->state = TL_FRAME_RECV_SEQ;
            break;

        case TL_FRAME_RECV_SEQ:
            frame->seq_id = byte_data;
            frame->state = TL_FRAME_RECV_LEN_L;
            break;

        case TL_FRAME_RECV_LEN_L:
            frame->payload_len = byte_data;         // 低字节在前
            frame->state = TL_FRAME_RECV_LEN_H;
            break;

        case TL_FRAME_RECV_LEN_H:
            temp = byte_data;
            temp <<= 8;
            frame->payload_len += (temp & 0xff00);        // 高字节在后
            if (frame->payload_len <= max_pl_len) // 帧数据长度有效性判断
            {
                frame->state = TL_FRAME_RECV_SUM;
            }
            else
            {
                frame->state = TL_FRAME_RECV_HEAD;
            }
            break;

        case TL_FRAME_RECV_SUM:
            frame->checksum = byte_data;
            if (frame->payload_len > 0)
            {
                frame->state = TL_FRAME_RECV_PAYLOAD;
                frame->payload_pos = 0;
            }
            else
            {
                frame->state = TL_FRAME_RECV_HEAD;
                ret = 0;
            }
            break;

        case TL_FRAME_RECV_PAYLOAD:
            frame->p_payload[frame->payload_pos++] = byte_data;
            if (frame->payload_pos >= frame->payload_len)
            {
                frame->payload_pos = 0;
                frame->state = TL_FRAME_RECV_HEAD;
                ret = 0;
            }
            break;

        default:
            frame->state = TL_FRAME_RECV_HEAD;
            break;
    }
    return ret;
}

/**
 * @brief  传输层(transport layer)数据帧封包
 * @param[in]  frame            [功能模块的结构体指针]
 * @param[out] out_buf          [封装好的数据帧缓存区指针]
 * @param[out] out_len          [封装数据帧长度]
 * @return     uint8_t          [封包的结果，0：封包成功；-1:封包失败]
 */
uint8_t vesync_tl_frame_encode(tl_frame_send_info_t *frame, uint8_t *out_buf, uint16_t *out_len)
{
    uint16_t i = 0;
    uint8_t sum = 0;
    uint16_t len = 0;

    if ((NULL == frame) ||(NULL == out_buf) || (NULL == out_len))
    {
        return -1;
    }

    if ((frame->payload_len > 0) && (NULL == frame->p_payload))
    {
        return -1;
    }

    out_buf[0] = TL_FRAME_HEAD;                                // 帧头
    out_buf[1] = frame->ctrl.data;                          // 控制码
    out_buf[2] = frame->seq_id;                             // 包计数
    out_buf[3] = (frame->payload_len & 0x00ff);             // 低字节
    out_buf[4] = ((frame->payload_len >> 8) & 0x00ff );     // 高字节
    out_buf[5] = 0;                                         // checksum清零

    memcpy(&out_buf[6], frame->p_payload, frame->payload_len);

    len = frame->payload_len + 6;
    for(i = 0; i < len; i++)
    {
        sum += out_buf[i];      // 计算checksum
    }

    out_buf[5] = ~sum;          // 反码

    *out_len = len;

    return 0;
}
