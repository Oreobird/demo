/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        button_netcfg.c
 * @brief       配网按键业务实现
 * @author      Joshua
 * @date        2021-12-23
 */
#include <stdint.h>
#include <string.h>
#include <stdbool.h>

#include "vesync_log.h"
#include "vesync_common.h"
#include "vesync_task.h"
#include "button.h"

#if CONFIG_VESYNC_APP_BUTTON_COLOR_INFINITE_ADJUST
static void press_down_handle(void)
{
}
static void press_up_handle(void)
{
}
static void long_press_start_handle(void)
{
}
static void long_press_hold_handle(void)
{
    APP_LOG(LOG_DEBUG, "-----------color_infinite_adjust---------\n");
}
#elif CONFIG_VESYNC_APP_BUTTON_BRIGHTNESS_INFINITE_ADJUST
static void press_down_handle(void)
{
}
static void press_up_handle(void)
{
}
static void long_press_start_handle(void)
{
}
static void long_press_hold_handle(void)
{
    APP_LOG(LOG_DEBUG, "-----------brightness_infinite_adjust---------\n");
}
#else
#define press_down_handle NULL
#define press_up_handle NULL
#define long_press_start_handle NULL
#define long_press_hold_handle NULL
#endif

static btn_ev_cb_t s_ev_cb_tbl[] = {
    {EV_PRESS_DOWN, press_down_handle},
    {EV_PRESS_UP, press_up_handle},
    {EV_LONG_PRESS_START, long_press_start_handle},
    {EV_LONG_PRESS_HOLD, long_press_hold_handle}
};

int button_long_press_init(app_btn_cfg_t *app_btn_cfg)
{
    VCOM_NULL_PARAM_CHK(app_btn_cfg, return APP_FAIL);
    int ret = SDK_FAIL;

    btn_cfg_t cfg;

    memset(&cfg, 0, sizeof(btn_cfg_t));
    cfg.gpio = app_btn_cfg->gpio;
    cfg.active_level = app_btn_cfg->active_level;
    cfg.long_press_cb_interval_ms = 1000;

    ret = vesync_button_reg_cb_arr(cfg.gpio, s_ev_cb_tbl, SIZEOF_ARRAY(s_ev_cb_tbl));
    if (ret != SDK_OK)
    {
        ret = vesync_button_add(&cfg);
        if (ret != SDK_OK)
        {
            APP_LOG(LOG_ERROR, "button add fail\n");
            return APP_FAIL;
        }

        ret = vesync_button_reg_cb_arr(cfg.gpio, s_ev_cb_tbl, SIZEOF_ARRAY(s_ev_cb_tbl));
        if (ret != SDK_OK)
        {
            APP_LOG(LOG_ERROR, "button reg cb fail\n");
            vesync_button_del(cfg.gpio);
            return APP_FAIL;
        }
    }

    return APP_OK;
}


int button_long_press_deinit(app_btn_cfg_t *app_btn_cfg)
{
    VCOM_NULL_PARAM_CHK(app_btn_cfg, return APP_FAIL);
    return (SDK_OK == vesync_button_del(app_btn_cfg->gpio)) ? APP_OK : APP_FAIL;
}


