/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        bulb_schedule.c
 * @brief       bulb schedule
 * @author      Dave
 * @date        2021-09-02
 */

#include <string.h>
#include <stdio.h>
#include <stdbool.h>

#include "vesync_common.h"
#include "vesync_log.h"
#include "vesync_memory.h"
#include "vesync_schedule.h"
#include "vesync_device.h"
#include "vesync_klv.h"

#include "vhal_flash.h"

#include "bulb.h"
#include "bulb_report.h"
#include "bulb_schedule.h"
#include "bulb_status.h"
#include "bulb_flash.h"
#include "bulb_bypass.h"

/**
 * @brief  Schedule模块action数据KLV组装
 * @param[in]   app_cfg_buf     [Schedule配置存储buff]
 * @param[in]   action          [Schedule动作]
 * @return int                  [成功：APP_OK， 失败：APP_FAIL]
 */
static int bulb_pack_schedule_action(vesync_buf_t *app_cfg_buf, bulb_action_t *action)
{
    uint8_t *p_buf = (uint8_t *)vesync_calloc(1, BULB_KLV_DATA_LEN);
    if (NULL == p_buf)
    {
        return APP_FAIL;
    }

    int offset = 0;
    // 组装KLV数据
    offset += vesync_klv_set(p_buf + offset, BULB_KLV_DATA_LEN - offset, BULB_KEY_ONOFF, sizeof(action->onoff), &action->onoff);
    offset += vesync_klv_set(p_buf + offset, BULB_KLV_DATA_LEN - offset, BULB_KEY_COLOR_MODE, sizeof(action->mode), &action->mode);
    offset += vesync_klv_set(p_buf + offset, BULB_KLV_DATA_LEN - offset, BULB_KEY_COLOR_TEMP, sizeof(action->temp), &action->temp);
    offset += vesync_klv_set(p_buf + offset, BULB_KLV_DATA_LEN - offset, BULB_KEY_COLOR_BRIGHT, sizeof(action->bright), &action->bright);
    offset += vesync_klv_set(p_buf + offset, BULB_KLV_DATA_LEN - offset, BULB_KEY_COLOR_HUE, sizeof(action->hue), (uint8_t *)&action->hue);
    offset += vesync_klv_set(p_buf + offset, BULB_KLV_DATA_LEN - offset, BULB_KEY_COLOR_SATURATION, sizeof(action->saturation), (uint8_t *)&action->saturation);
    offset += vesync_klv_set(p_buf + offset, BULB_KLV_DATA_LEN - offset, BULB_KEY_COLOR_VALUE, sizeof(action->value), &action->value);
    offset += vesync_klv_set(p_buf + offset, BULB_KLV_DATA_LEN - offset, BULB_KEY_SCENE_ID, sizeof(action->scene_id), (uint8_t *)&action->scene_id);
    vesync_buf_set(app_cfg_buf, (void *)p_buf, offset);

    vesync_free(p_buf);
    return APP_OK;
}

/**
* @brief  Schedule模块action数据KLV组装
* @param[in]   app_cfg_buf     [Schedule配置获取buff]
* @param[in]   action          [Schedule动作]
* @return int                  [成功：APP_OK， 失败：APP_FAIL]
*/
static int bulb_read_scedule_data(vesync_buf_t *app_cfg_buf, bulb_action_t *action)
{
    if (NULL == action)
    {
        return APP_FAIL;
    }
    vesync_klv_get(app_cfg_buf->buf, app_cfg_buf->len, BULB_KEY_ONOFF, sizeof(action->onoff), &action->onoff);
    vesync_klv_get(app_cfg_buf->buf, app_cfg_buf->len, BULB_KEY_COLOR_MODE, sizeof(action->mode), &action->mode);
    vesync_klv_get(app_cfg_buf->buf, app_cfg_buf->len, BULB_KEY_COLOR_BRIGHT, sizeof(action->bright), &action->bright);
    vesync_klv_get(app_cfg_buf->buf, app_cfg_buf->len, BULB_KEY_COLOR_TEMP, sizeof(action->temp), &action->temp);
    vesync_klv_get(app_cfg_buf->buf, app_cfg_buf->len, BULB_KEY_COLOR_HUE, sizeof(action->hue), (uint8_t *)&action->hue);
    vesync_klv_get(app_cfg_buf->buf, app_cfg_buf->len, BULB_KEY_COLOR_SATURATION, sizeof(action->saturation), (uint8_t *)&action->saturation);
    vesync_klv_get(app_cfg_buf->buf, app_cfg_buf->len, BULB_KEY_COLOR_VALUE, sizeof(action->value), (uint8_t *)&action->value);
    vesync_klv_get(app_cfg_buf->buf, app_cfg_buf->len, BULB_KEY_SCENE_ID, sizeof(action->scene_id), (uint8_t *)&action->scene_id);
    return APP_OK;
}

/**
 * @brief  Schedule模块配置写入回调
 * @param[in]   p_wr_buf    [Schedule配置保存buff]
 * @param[in]   len         [Schedule保存buff长度]
 * @return int              [返回Schedule配置写入结果]
 */
static int bulb_sche_wr_cfg_cb(uint8_t *p_wr_buf, uint32_t len)
{
    if (NULL == p_wr_buf || len == 0)
    {
        return SCHE_ERR;
    }

    int ret = vhal_flash_write(PARTITION_CFG, BULB_SCHEDULE_MOD_CFG_KEY, p_wr_buf, len);
    if (VHAL_OK != ret)
    {
        APP_LOG(LOG_WARN, "flash write fail[%d]\n", ret);

        return SCHE_ERR;
    }

    return SCHE_OK;
}

/**
 * @brief   Schedule模块配置读取回调
 * @param[in]   p_rd_buf         [Schedule配置保存buff]
 * @param[in]   p_rd_len         [Schedule配置读取长度]
 * @return int                   [返回Schedule配置读取结果]
 */
static int bulb_sche_rd_cfg_cb(uint8_t *p_rd_buf, uint32_t buf_len, uint32_t *p_rd_len)
{
    UNUSED(buf_len);

    if (NULL == p_rd_len)
    {
        return SCHE_ERR;
    }

    /// @attention: p_rd_buf为NULL，返回存储数据的长度
    int ret = vhal_flash_read(PARTITION_CFG, BULB_SCHEDULE_MOD_CFG_KEY, p_rd_buf, p_rd_len);
    if (VHAL_OK != ret)
    {
        APP_LOG(LOG_WARN, "flash read fail[%d]\n", ret);

        // 将读取长度设为0，当作配置不存在
        *p_rd_len = 0;
    }
    return SCHE_OK;
}

/**
 * @brief 灯schedule执行回调
 * @param[in]   sch_cfg     [Schedule配置]
 * @param[in]   app_cfg     [Schedule动作]
 * @return int              [[返回Schedule执行结果]
 */
static int bulb_schedule_exec_cb(vesync_schedule_t sch_cfg, vesync_buf_t app_cfg)
{
    if (app_cfg.len < sizeof(bulb_action_t))
    {
        return SCHE_ERR;
    }

    bulb_action_t bulb_action;
    memset(&bulb_action, 0, sizeof(bulb_action_t));
    bulb_read_scedule_data(&app_cfg, &bulb_action);

    APP_LOG(LOG_INFO, "Schedule task executes. sche_id:[%ld]\n", sch_cfg.id);

    bulb_status_t bulb_status;
    bulb_status_fetch(&bulb_status);
    bulb_status.enable = (bulb_action.onoff > 0) ? true : false;
    if (true == bulb_status.enable)
    {
        bulb_status.mode = bulb_action.mode;
        switch (bulb_status.mode)
        {
        case BULB_CFG_COLOR_MODE_WHITE:
            bulb_status.white.brightness = bulb_action.bright;
            bulb_status.white.color_temp = bulb_action.temp;
            break;
        case BULB_CFG_COLOR_MODE_HSV:
            bulb_status.hsv.hue = bulb_action.hue;
            bulb_status.hsv.saturation = bulb_action.saturation;
            bulb_status.hsv.value = bulb_action.value;
            break;
        case BULB_CFG_COLOR_MODE_SCENARIO:
            bulb_status.scene_id = bulb_action.scene_id;
            break;
        default:
            break;
        }
    }

    int ret = bulb_status_update(&bulb_status);
    bulb_report_status_change(STAT_CHG_RSN_SCHD_STR);
    bulb_report_schedule_exec(&sch_cfg, &bulb_action, ret, "schedule_executed");
    return SCHE_OK;
}

int bulb_schedule_add(vesync_schedule_t *sch_cfg, void *action, uint32_t *p_out_id)
{
    int err_code = BP_ERR_NO_ERR;
    int ret = SCHE_ERR;

    if (NULL == sch_cfg || NULL == action || NULL == p_out_id)
    {
        return BP_ERR_CMD_EXECUTE_FAIL;
    }
    // 缓存应用层的配置
    vesync_buf_t app_cfg_buf = vesync_buf_new();
    ret = bulb_pack_schedule_action(&app_cfg_buf, action);
    if (ret == APP_FAIL)
    {
        err_code = BP_ERR_OUT_OF_MEMORY;
        goto exit;
    }
    ret = vesync_schedule_add(BULB_SCHE_INS_ID, sch_cfg, &app_cfg_buf, true);
    if (ret != SCHE_OK)
    {
        APP_LOG(LOG_WARN, "Schedule added fail: %d\n", ret);
        if (ret == SCHE_CFLT_ERR)
        {
            err_code = BP_ERR_SCHEDULE_CONFLICT;
            goto exit;
        }
        if (ret == SCHE_EXCEED_MAX)
        {
            err_code = BP_ERR_SCHEDULE_EXCEED_MAX;
            goto exit;
        }
        err_code = BP_ERR_CMD_EXECUTE_FAIL;
        goto exit;
    }
    // 添加的配置项ID返回给BP调用端
    *p_out_id = sch_cfg->id;

exit:
    vesync_buf_clr(&app_cfg_buf);
    return err_code;
}

int bulb_schedule_upd(bypass_schedule_base_t *p_bp_sch, uint32_t *p_out_id)
{
    if (NULL == p_bp_sch || NULL == p_out_id)
    {
        return BP_ERR_CMD_EXECUTE_FAIL;
    }
    if (0 == p_bp_sch->id || BULB_SCHEDULE_MIN_ID > p_bp_sch->id)
    {
        return BP_ERR_PARA_ILLEGAL;
    }

    int err_code = BP_ERR_NO_ERR;
    int ret = SCHE_ERR;

    bulb_action_t action = {0};
    vesync_buf_t app_cfg_buf = vesync_buf_new();
    vesync_schedule_t sch_cfg;
    ret = vesync_schedule_get_by_id(BULB_SCHE_INS_ID, p_bp_sch->id, &sch_cfg, &app_cfg_buf);
    if (ret != SCHE_OK)
    {
        if (ret != SCHE_INV_ID_ERR)
        {
            err_code = BP_ERR_UNDEFINE;
            goto EXIT;
        }
        err_code = BP_ERR_SCHEDULE_NOT_FOUND;
        goto EXIT;
    }

    if (NULL != p_bp_sch->json_action)
    {
        err_code = bulb_bp_parse_action(p_bp_sch->json_action, &action);
        if (BP_ERR_NO_ERR != err_code)
        {
            goto EXIT;
        }
        ret = bulb_pack_schedule_action(&app_cfg_buf, &action);
        if (ret == APP_FAIL)
        {
            err_code = BP_ERR_UNDEFINE;
            goto EXIT;
        }
    }

    sch_cfg.enabled = (NULL != p_bp_sch->enabled) ? (bool)*p_bp_sch->enabled : sch_cfg.enabled;
    sch_cfg.repeat_config = (NULL != p_bp_sch->repeat_config) ? (uint8_t)*p_bp_sch->repeat_config : sch_cfg.repeat_config;

    if (NULL != p_bp_sch->type)
    {
        switch (*p_bp_sch->type)
        {
        case BYPASS_SCHEDULE_JSON_TYPE_TMG_EVT:
            sch_cfg.type = SCHE_TMG_EVT;
            sch_cfg.event_config.timing.clock_sec = (NULL != p_bp_sch->clock_sec) ? (uint32_t)*p_bp_sch->clock_sec : sch_cfg.event_config.timing.clock_sec;
            break;
        case BYPASS_SCHEDULE_JSON_TYPE_SUN_EVT:
            sch_cfg.type = SCHE_SUN_EVT;
            sch_cfg.event_config.sun.is_sunrise = (NULL != p_bp_sch->is_sunrise) ? (bool)*p_bp_sch->is_sunrise : sch_cfg.event_config.sun.is_sunrise;
            if (NULL != p_bp_sch->offset_sec)
            {
                if ((BULB_SCHE_SUN_EVT_TIME_MAX < (int32_t)*p_bp_sch->offset_sec) ||
                    (BULB_SCHE_SUN_EVT_TIME_MIN > (int32_t)*p_bp_sch->offset_sec))
                {
                    err_code = BP_ERR_PARA_ILLEGAL;
                    goto EXIT;
                }
                sch_cfg.event_config.sun.offset_sec = (int32_t)*p_bp_sch->offset_sec;
            }
            break;
        default:
            err_code = BP_ERR_PARA_ILLEGAL;
            goto EXIT;
        }
    }

    ret = vesync_schedule_upd(BULB_SCHE_INS_ID, &sch_cfg, &app_cfg_buf);
    if (ret != SCHE_OK)
    {
        if (ret != SCHE_CFLT_ERR)
        {
            err_code = BP_ERR_CMD_EXECUTE_FAIL;
            goto EXIT;
        }

        err_code = BP_ERR_SCHEDULE_CONFLICT;
        goto EXIT;
    }
    *p_out_id = sch_cfg.id;

EXIT:
    vesync_buf_clr(&app_cfg_buf);
    return err_code;
}

int bulb_schedule_get_mult(uint32_t index, vesync_schedule_t *sche_cfg, bulb_action_t *action, uint32_t *cur_num, uint32_t *total_num)
{
    int ret = SCHE_ERR;
    int err_code = BP_ERR_NO_ERR;
    vesync_buf_t app_cfg_buf[BULB_SCHEDULE_GET_MAX_NUM];

    if (NULL == sche_cfg || NULL == action || NULL == cur_num || NULL == total_num)
    {
        return BP_ERR_CMD_EXECUTE_FAIL;
    }
    for (uint32_t i = 0; i < BULB_SCHEDULE_GET_MAX_NUM; i++)
    {
        app_cfg_buf[i] = vesync_buf_new();
    }
    ret = vesync_schedule_get_by_index(BULB_SCHE_INS_ID, index, BULB_SCHEDULE_GET_MAX_NUM,
                                       total_num, sche_cfg, app_cfg_buf, cur_num);
    for (uint32_t i = 0; i < *cur_num; i++)
    {
        bulb_read_scedule_data(&app_cfg_buf[i], (bulb_action_t *)action + i);
    }
    if (ret != SCHE_OK)
    {
        if (ret == SCHE_INV_IDX_ERR)
        {
            err_code = BP_ERR_SCHEDULE_NOT_FOUND;
            goto exit;
        }

        ret = BP_ERR_CMD_EXECUTE_FAIL;
        goto exit;
    }

exit:
    // 销毁APP配置读取缓存
    for (uint32_t i = 0; i < BULB_SCHEDULE_GET_MAX_NUM; i++)
    {
        vesync_buf_clr(&app_cfg_buf[i]);
    }
    return err_code;
}

int bulb_schedule_del(uint32_t id_to_del)
{
    int ret = SCHE_ERR;
    ret = vesync_schedule_del(BULB_SCHE_INS_ID, id_to_del);
    if (ret != SCHE_OK)
    {
        if (ret != SCHE_INV_ID_ERR)
        {
            return BP_ERR_CMD_EXECUTE_FAIL;
        }
        return BP_ERR_SCHEDULE_NOT_FOUND;
    }
    return BP_ERR_NO_ERR;
}

int bulb_schedule_init(void)
{
    int ret = 0;

    // 初始化Schedule模块
    if (SCHE_OK != vesync_schedule_main_init())
    {
        APP_LOG(LOG_ERROR, "Schedule module init fail\n");

        return APP_FAIL;
    }

    vesync_schedule_param_t schedule_param;
    schedule_param.rd_cfg_cb = bulb_sche_rd_cfg_cb;
    schedule_param.wr_cfg_cb = bulb_sche_wr_cfg_cb;
    schedule_param.exec_app_task_cb = bulb_schedule_exec_cb;
    schedule_param.max_app_cfg_size = BULB_SCHEDULE_MAX_APP_CFG_SIZE;
    schedule_param.max_sche_nbr = BULB_SCHEDULE_MAX_NUM;
    schedule_param.min_id_limit = BULB_SCHEDULE_MIN_ID;
    ret = vesync_schedule_new_instance(BULB_SCHE_INS_ID, &schedule_param);
    if (ret != SCHE_OK)
    {
        APP_LOG(LOG_ERROR, "Schedule instance init error: [%ld]\n", ret);

        return APP_FAIL;
    }

    APP_LOG(LOG_INFO, "Schedule initialized\n");
    return APP_OK;
}

int bulb_schedule_clear(void)
{
    vesync_schedule_clear(BULB_SCHE_INS_ID);
    return APP_OK;
}
