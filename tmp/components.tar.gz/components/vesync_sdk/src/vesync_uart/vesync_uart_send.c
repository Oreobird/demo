/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_uart_send.c
 * @brief       UART模块发送接口
 * @author      Louis
 * @date        2021-08-17
 */

#include <string.h>

#include "vhal_uart.h"
#include "vesync_common.h"
#include "vesync_log_internal.h"
#include "vesync_memory.h"
#include "vesync_loop_timer_internal.h"
#include "vesync_tl_frame_parse.h"
#include "vesync_tl_payload_parse.h"
#include "vesync_uart_private.h"


static vloop_timer_header_t st_timer_header = {0};  // 定时器头部指针
static vesync_uart_send_t s_uart_send[VESYNC_UART_NUM] = {0};


/**
 * @note  本文件中的宏PR_CMPT_RTOS都是为了兼容老平台RTOS，新产品可以完全忽略，ugly!!!
 *        实现目的：UART发送完一包后必须间隔40ms后才能发送下一包
 *        原因：老平台RTOS对接第三方MCU，质量参差不齐，有些MCU无法处理粘包情况，故加入发送间隔
 */
#if defined(PR_CMPT_RTOS) && (PR_CMPT_RTOS == 1)
// 处在发送间隔以内，不允许继续发送，需等到发送间隔时间到了才能继续发下一包
static bool s_uart_send_interval[VESYNC_UART_NUM] = {0};
static vloop_timer_t s_uart_send_interval_timeout[VESYNC_UART_NUM] = {0};

/**
 * @brief  UART发送完整一包数据后等待一定间隔才能发送下一包
 * @param[in]  arg              [回调函数参数]
 */
static void vesync_uart_send_interval_cb(void *arg)
{
    SDK_LOG(LOG_DEBUG, "UART send ok!\n");

    bool *p_uart_send_interval = (bool *)(arg);
    // 将标志位值为false，表示可以继续发包了，然后释放信号量通知收发任务
    *p_uart_send_interval = false;
    vesync_uart_sem_signal();
}

/**
 * @brief  UART间隔发送机制初始化
 */
static void vesync_uart_send_interval_init()
{
    for (uint8_t i= 0; i < VESYNC_UART_NUM; i++)
    {
        s_uart_send_interval_timeout[i].reload = false;
        s_uart_send_interval_timeout[i].period = 40;   // ms
        s_uart_send_interval_timeout[i].cb = vesync_uart_send_interval_cb;
        s_uart_send_interval_timeout[i].arg = &s_uart_send_interval[i];
    }
}

/**
 * @brief 设置发送间隔标志为true，并添加定时器，20ms后超时则将标志改为false
 */
void vesync_uart_add_send_interval(uint8_t idx)
{
    vloop_timer_add(&st_timer_header, &s_uart_send_interval_timeout[idx]);
    s_uart_send_interval[idx] = true;
}

#define VESYNC_UART_SEND_INTERVAL_INIT()    vesync_uart_send_interval_init()
#define VESYNC_UART_ADD_SEND_INTERVAL(i)    vesync_uart_add_send_interval(i)
#define VESYNC_UART_CHECK_SEND_INTERVAL() \
    if (s_uart_send_interval[i]) \
    { \
        continue; \
    }


#else

#define VESYNC_UART_SEND_INTERVAL_INIT()
#define VESYNC_UART_ADD_SEND_INTERVAL(i)
#define VESYNC_UART_CHECK_SEND_INTERVAL()

#endif


/**
 * @brief  组包并发送UART数据
 * @param[in]  idx              [UART编号]
 * @param[in]  send_data        [发送数据指针]
 * @return     int32_t          [SDK_OK/SDK_FAIL]
 */
static int32_t vesync_uart_send_data(uint8_t idx, uart_msg_send_t *send_data)
{
    uint32_t ret = SDK_OK;
    uint8_t *p_buf = NULL;
    uint16_t buf_len = 0;
    tl_frame_send_info_t frame_info = {0};

    if (UART_MSG_TYPE_CMD == send_data->type)
    {
        if (!s_uart_send[idx].busy)
        {
            s_uart_send[idx].seq_id++;
        }
        frame_info.seq_id = s_uart_send[idx].seq_id;
        frame_info.ctrl.bitN.ack_flag = 0;
        frame_info.ctrl.bitN.request_flag = send_data->request_flag;
        frame_info.ctrl.bitN.error_flag = 0;
    }
    else
    {
        frame_info.seq_id = vesync_uart_get_recv_seq_id(idx);   // ack报文seq_id需和请求包一致
        frame_info.ctrl.bitN.ack_flag = 1;
        frame_info.ctrl.bitN.request_flag = 0;
        frame_info.ctrl.bitN.error_flag = send_data->status_code ? 1 : 0;
    }
    frame_info.ctrl.bitN.version = VESYNC_PROTOCO_VERSION;

    frame_info.payload_len = send_data->data_len;
    frame_info.p_payload = send_data->p_data;

    buf_len = send_data->data_len + VESYNC_PROTOCO_HEAD_LEN;
    p_buf = vesync_malloc(buf_len);
    if (NULL == p_buf)
    {
        ret = SDK_FAIL;
        goto EXIT;
    }
    // 组装协议头
    vesync_tl_frame_encode(&frame_info, p_buf, &buf_len);

    if (VHAL_OK != vhal_uart_send(idx, p_buf, buf_len))
    {
        SDK_LOG(LOG_ERROR, "UART send fail!!!\r\n");
        ret = SDK_FAIL;
        goto EXIT;
    }

EXIT:
    VCOM_SAFE_FREE(p_buf);
    return ret;
}


/**
 * @brief  发送后对端回复超时的回调处理函数
 * @param[in]  arg              [回调函数参数]
 */
static void vesync_uart_send_timeout_cb(void *arg)
{
    SDK_LOG(LOG_DEBUG, "UART send timeout!arg:%p\n", arg);
    vesync_uart_send_t *p_uart_send = (vesync_uart_send_t *)arg;

    // 重发次数未达上限则重发，并重置定时器
    if (p_uart_send->repeat_cnt < VESYNC_SEND_REPEAT_MAX_CNT)
    {
        vesync_uart_send_data(p_uart_send->idx, &p_uart_send->cmd_data);
        p_uart_send->repeat_cnt++;
        vesync_uart_add_send_timeout_timer(p_uart_send->idx);
    }
    else    // 超时次数达上限，发送失败通知应用层，重置通道，释放信号量通知收发任务继续处理下一条消息
    {
        vesync_uart_report_tx_event(p_uart_send->idx, UART_SEND_FAIL, (tl_payload_info_t *)p_uart_send->cmd_data.p_data, 0);
        VCOM_SAFE_FREE(p_uart_send->cmd_data.p_data);
        p_uart_send->busy = false;
        vesync_uart_sem_signal();
    }
}



/**
 * @brief  UART模块发送初始化
 * @return     int32_t          [SDK_OK/SDK_FAIL]
 */
int32_t vesync_uart_send_init(void)
{
    for (int i = 0; i < VESYNC_UART_NUM; i++)
    {
        s_uart_send[i].idx = i;

        // 发送ACK消息的缓存队列
        s_uart_send[i].ack_queue = vesync_queue_new(VESYNC_UART_SEND_ACK_QUEUE_MAX_NUM * sizeof(uart_msg_send_t), sizeof(uart_msg_send_t));
        if (NULL == s_uart_send[i].ack_queue)
        {
            SDK_LOG(LOG_ERROR, "queue create fail\n");
            return SDK_FAIL;
        }

        // 发送CMD消息的缓存队列
        s_uart_send[i].cmd_queue = vesync_queue_new(VESYNC_UART_SEND_CMD_QUEUE_MAX_NUM * sizeof(uart_msg_send_t), sizeof(uart_msg_send_t));
        if (NULL == s_uart_send[i].cmd_queue)
        {
            SDK_LOG(LOG_ERROR, "queue create fail\n");
            return SDK_FAIL;
        }

        // 初始化超时重发定时器
        s_uart_send[i].timeout.reload = false;
        s_uart_send[i].timeout.period = VESYNC_SEND_REQUEST_TIMEOUT;
        s_uart_send[i].timeout.cb = vesync_uart_send_timeout_cb;
        s_uart_send[i].timeout.arg = (void*)(&s_uart_send[i]);

        SDK_LOG(LOG_DEBUG, "init!\n");
    }

    // 初始化间隔发送机制，默认40ms
    VESYNC_UART_SEND_INTERVAL_INIT();

    return SDK_OK;
}

/**
 * @brief  UART模块发送退出
 */
void vesync_uart_send_deinit(void)
{
    for (int i = 0; i < VESYNC_UART_NUM; i++)
    {
        if (s_uart_send[i].ack_queue)
        {
            vesync_queue_free(s_uart_send[i].ack_queue);
            s_uart_send[i].ack_queue = NULL;
        }

        if (s_uart_send[i].cmd_queue)
        {
            vesync_queue_free(s_uart_send[i].cmd_queue);
            s_uart_send[i].cmd_queue = NULL;
        }
    }
}

/**
 * @brief  从发送队列中取出数据，然后调用vhal接口发送出去
 * @return     int32_t          [任一队列有读取到信息则返回SDK_OK，所有队列都读取不到信息则返回SDK_FAIL]
 * @note   数据处理优先级：ACK数据、无需对端回复的数据、需要对端回复的数据
 */
int32_t vesync_uart_parse_send_data(void)
{
    int32_t ret = SDK_FAIL;
    uart_msg_send_t data_send = {0};

    for (int i = 0; i < VESYNC_UART_NUM; i++)
    {
        // 检查上一条消息发送间隔是否已经超时
        VESYNC_UART_CHECK_SEND_INTERVAL();

        // 优先处理ACK消息，该类消息不要求对端回复，也不需要超时重发
        if (VOS_OK == vesync_queue_recv(s_uart_send[i].ack_queue, &data_send, VESYNC_OS_NO_WAIT))
        {
            vesync_uart_send_data(i, &data_send);
            VCOM_SAFE_FREE(data_send.p_data);

            // 发送消息设置间隔定时器
            VESYNC_UART_ADD_SEND_INTERVAL(i);

            ret = SDK_OK;
        }

        // 检查上一条消息发送间隔是否已经超时
        VESYNC_UART_CHECK_SEND_INTERVAL();

        // 通道处于非busy状态则开始处理CMD消息
        if (false == s_uart_send[i].busy &&
            VOS_OK == vesync_queue_recv(s_uart_send[i].cmd_queue, &s_uart_send[i].cmd_data, VESYNC_OS_NO_WAIT))
        {
            vesync_uart_send_data(i, &s_uart_send[i].cmd_data);

            // 如果CMD消息要求对端回复，则需阻塞通道等待回复，并启用超时重发定时器
            if (s_uart_send[i].cmd_data.request_flag)
            {
                s_uart_send[i].repeat_cnt = 1;
                vesync_uart_add_send_timeout_timer(i);

                s_uart_send[i].busy = true;
            }
            else
            {
                VCOM_SAFE_FREE(s_uart_send[i].cmd_data.p_data);
            }

            // 发送消息设置间隔定时器
            VESYNC_UART_ADD_SEND_INTERVAL(i);

            ret = SDK_OK;
        }
    }

    // 任一队列读取到消息则该队列可能还有其他消息，处理之后需要重新释放信号量，让收发任务继续处理
    if(SDK_OK == ret)
    {
        vesync_uart_sem_signal();
    }

    return ret;
}

/**
 * @brief 添加超时重发定时器
 */
void vesync_uart_add_send_timeout_timer(uint8_t idx)
{
    vloop_timer_add(&st_timer_header, &s_uart_send[idx].timeout);
}

/**
 * @brief 删除超时重发定时器，然后重置busy标志，并释放信号量通知收发任务继续处理
 */
void vesync_uart_del_send_timeout_timer(uint8_t idx)
{
    vloop_timer_del(&st_timer_header, &s_uart_send[idx].timeout);
    VCOM_SAFE_FREE(s_uart_send[idx].cmd_data.p_data);
    s_uart_send[idx].busy = false;
    vesync_uart_sem_signal();
}

/**
 * @brief 处理已经超时的定时器
 * @return    uint64_t      [下一个即将超时定时器的时间ms]
 */
uint64_t vesync_uart_process_expired_timer(void)
{
    return vloop_timer_process_expired(&st_timer_header);
}

/**
 * @brief  获取发送的sequence id
 * @param[in]  idx                 [串口编号]
 * @return     uint8_t             [sequence id]
 */
uint8_t vesync_uart_get_send_seq_id(uint8_t idx)
{
    return s_uart_send[idx].seq_id;
}

/**
 * @brief  UART串口发送返回事件回调
 * @param[in]  cb                   [发送返回事件回调函数]
 */
void vesync_uart_report_tx_event(uint8_t idx, UART_SEND_TYPE_E event, tl_payload_info_t *p_payload, uint16_t payload_len)
{
    if (idx >= VESYNC_UART_NUM)
    {
        return;
    }

    // 优先执行同属平台层的ota的回调
    if (NULL != s_uart_send[idx].ota_evt_cb)
    {
        // 执行ota回调返回OK，则说明该消息属于ota消息，已经处理，返回即可
        if (SDK_OK == s_uart_send[idx].ota_evt_cb(event, p_payload, payload_len, s_uart_send[idx].cmd_data.p_extra_data))
        {
            return;
        }
    }

    // 执行ota回调返回FAIL，说明非ota消息，继续调用应用层的回调进行处理
    if (NULL != s_uart_send[idx].cmd_evt_cb)
    {
        s_uart_send[idx].cmd_evt_cb(event, p_payload, payload_len, s_uart_send[idx].cmd_data.p_extra_data);
    }
}



/**
 * @brief  待发送数据发送到串口发送队列中
 * @param[in]  idx              [UART编号]
 * @param[in]  p_msg            [数据指针]
 * @return  uint32_t            [SDK_OK/SDK_FAIL]
 */
uint32_t vesync_uart_send(uint8_t idx, uart_msg_send_t *p_msg)
{
    uint32_t ret = SDK_OK;
    uint16_t payload_len = 0;
    uint8_t *p_payload = NULL;
    vesync_queue_t *uart_send_queue = NULL;
    uart_msg_send_t send_data = {0};

    payload_len = p_msg->data_len + TL_PAYLOAD_PROTOCOL_HEAD_LEN;  // payload协议头部长度为4bytes
    if (NULL == p_msg || payload_len > VESYNC_FRAME_PAYLOAD_MAX_LEN)
    {
        return SDK_FAIL;
    }

    // 发送消息目前分两个队列缓存，CMD和ACK，两者处理机制存在差异
    switch (p_msg->type)
    {
    case UART_MSG_TYPE_CMD:
        uart_send_queue = s_uart_send[idx].cmd_queue;
        break;
    case UART_MSG_TYPE_ACK:
        uart_send_queue = s_uart_send[idx].ack_queue;
        break;
    default:
        return SDK_FAIL;
    }

    p_payload = (uint8_t*)vesync_malloc(payload_len);
    if (NULL == p_payload)
    {
        ret = SDK_FAIL;
        goto EXIT;
    }
    memset(p_payload, 0, payload_len);

    // 组装payload
    if(0 != vesync_tl_payload_encode(p_msg->opcode, p_msg->status_code, p_msg->p_data, p_msg->data_len, p_payload, &payload_len))
    {
        ret = SDK_FAIL;
        goto EXIT;
    }

    memcpy(&send_data, p_msg, sizeof(uart_msg_send_t));
    send_data.p_data = p_payload;
    send_data.data_len = payload_len;

    // 将发送消息入队缓存，然后释放信号量通知收发任务处理
    if (VOS_OK != vesync_queue_send(uart_send_queue, &send_data, VESYNC_OS_NO_WAIT))
    {
        SDK_LOG(LOG_ERROR, "send failed\n");
        ret = SDK_FAIL;
        goto EXIT;
    }

EXIT:
    if (SDK_OK == ret)
    {
        vesync_uart_sem_signal();
    }
    else
    {
        VCOM_SAFE_FREE(p_payload);
    }
    return ret;
}

/**
 * @brief  注册UART串口发送返回事件回调函数
 * @param[in]  cb                   [发送返回事件回调函数]
 */
void vesync_uart_reg_tx_event_cb(uint8_t idx, uart_tx_event_cb_t cb)
{
    if (idx < VESYNC_UART_NUM)
    {
        s_uart_send[idx].cmd_evt_cb = cb;
    }
}

/**
 * @brief  注册OTA串口发送返回事件回调函数
 * @param[in]  cb                   [发送返回事件回调函数]
 */
void vesync_uart_reg_ota_event_cb(uint8_t idx, uart_tx_event_cb_t cb)
{
    if (idx < VESYNC_UART_NUM)
    {
        s_uart_send[idx].ota_evt_cb = cb;
    }
}

