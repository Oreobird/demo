/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_bypass_common.c
 * @brief       bypass处理接口
 * @date        2021-05-14
 */

#include <string.h>
#include <stdio.h>

#include "vesync_cfg_internal.h"
#include "vesync_common.h"
#include "vesync_log_internal.h"
#include "vesync_bypass_internal.h"

/**
 * @brief 串口通信测试
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  json                     [json数据指针]
 * @return BYPASS_ERR_E                 [错误码]
 */
static BYPASS_ERR_E bypass_method_test_uart_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    UNUSED(json);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    BYPASS_ERR_E ret = BP_OK;

    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_TEST_UART);
    if (method_cb)
    {
        method_cb(p_msg_ctx, NULL);
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

    return ret;
}

static bypass_item_data_t uart_method_tbl[] = {
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_TEST_UART, "testUart", bypass_method_test_uart_handle, NULL},
};

void vesync_bypass_uart_init(void)
{
    for (int i = 0; i < SIZEOF_ARRAY(uart_method_tbl); i++)
    {
        bypass_item_t *item = vesync_bypass_init_item(&uart_method_tbl[i]);
        if (item != NULL)
        {
            vesync_bypass_add_item(item);
        }
    }
}

