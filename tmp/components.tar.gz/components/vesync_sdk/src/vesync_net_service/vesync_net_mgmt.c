/*
 * Copyright © Vesync Technologies Co.Ltd. 2019-2021. All rights reserved.
 * @file    vesync_net_mgmt.c
 * @brief   网络服务管理
 * @author  CharlesMei
 * @date    2021-06-04
 */


#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>

#include "vhal_utils.h"

#include "vesync_net_service_private.h"

#if CONFIG_VESYNC_SDK_NETCFG_ENABLE
#include "vesync_netcfg.h"
#endif /* CONFIG_VESYNC_SDK_NETCFG_ENABLE */

#if CONFIG_VESYNC_SDK_FFS_ENABLE
#include "vesync_ffs_internal.h"
#endif /* CONFIG_VESYNC_SDK_FFS_ENABLE */


// 设备上线报告
static reconn_data_t s_recon_reason;
// 配网信息，每次启动由flash中读取。
static net_info_t s_net_cfg;


/**
 * @brief       设置重连服务器原因，连上服务器会上报
 * @param[in]   reason               [设备连接服务器的原因]
 */
void vesync_net_mgmt_set_reconnect_reason(RECONNECT_REASON_E reason)
{
    if (!s_recon_reason.flag)
    {
        s_recon_reason.reason = reason;
        s_recon_reason.flag = 0x1;
    }
}

/**
 * @brief       查询重连服务器原因
 * @return      RECONNECT_REASON_E   [设备连接服务器的原因]
 */
RECONNECT_REASON_E vesync_net_mgmt_get_reconnect_reason(void)
{
    return s_recon_reason.reason;
}

/**
 * @brief       返回重连原因的字符串
 * @param[in]   reason               [网络重连原因，详见enum声明]
 * @return      char*                [网络重连原因字符串形式]
 */
const char* vesync_net_mgmt_get_reconnect_reason_str(RECONNECT_REASON_E reason)
{
    switch (reason)
    {

        case CONFIG_NET_REASON:
            return "ConfigNet";
        case NETWORK_REASON:
#if CONFIG_VESYNC_SDK_MQTT_ENABLE
            if (NETWORK_MQTT == vesync_net_client_get_protocol())
            {
                return "MQTT";
            }
#endif /* CONFIG_VESYNC_SDK_MQTT_ENABLE */
#if 0
            if (NETWORK_HTTP == vesync_net_client_get_protocol())
            {
                return "HTTP";
            }
#endif
            return "Unkonw network protocol";
        case WIFI_REASON:
            return "Wi-Fi";
        case UPGRADE_REASON:
        case PRODUCTION_REASON:
            return "Upgrade";
        case POWER_ON_REASON:
        default:
            return "PowerOn";
    }
}

/**
 * @brief       记录Wi-Fi/网络客户端的重连次数
 * @param[in]   fail_type            [网络连接失败错误类型]
 */
void vesync_net_mgmt_set_reconnect_count(DEV_CONNECT_FAIL_TYPE_E fail_type)
{
    if (!s_recon_reason.flag)
    {
        NET_LOG(LOG_INFO, "Current device is not offline\r\n");
        return;
    }

    if (fail_type >= CONNECT_RETRY_TYPE_TOTAL)
    {
        NET_LOG(LOG_ERROR, "invalid connect fail type!!!\r\n");
        return;
    }
    if (NETWORK_RETRY_FAIL == fail_type  && VHAL_WIFI_GOT_IP != vesync_wifi_get_link_status())
    {
        NET_LOG(LOG_INFO, "wifi disconnect, ignore mqtt fail\r\n");
        return;
    }
    s_recon_reason.retry_cnt[fail_type] += 1;
}

/**
 * @brief       设置链路断开->重连成功的时间
 * @param[in]   type                 [掉线类型]
 * @param       bool                 [掉线时间超过10min，返回true；否则返回false]
 */
bool vesync_net_mgmt_set_reconnect_time(DEV_RECORD_TS_E type)
{
    bool ret = false;
    uint32_t ts = vhal_utils_get_system_time_sec();

    if (!s_recon_reason.flag)
    {
        NET_LOG(LOG_INFO, "The device does not currently need to record time\n");
        return ret;
    }

    switch (type)
    {
        case WIFI_DISCONN_TS:
            if (s_recon_reason.wifi_disconn_ts <= 0)
            {
                s_recon_reason.wifi_disconn_ts = ts;
            }
            else
            {
                if (ts - s_recon_reason.wifi_disconn_ts > 600)   // Wi-Fi掉线超过10min
                {
                    ret = true;
                }
            }
            break;
        case WIFI_RECONN_TS:
            if (s_recon_reason.wifi_reconn_ts <= 0 || s_recon_reason.wifi_disconn_ts <= 0)    // MQTT连接失败，重连WiFi也进行更新
            {
                s_recon_reason.wifi_reconn_ts = ts;
            }
            break;
        case NETWORK_DISCONN_TS:
            if (s_recon_reason.network_disconn_ts <= 0)
            {
                s_recon_reason.network_disconn_ts = ts;
            }
            else
            {
                if (ts - s_recon_reason.network_disconn_ts > 600)   // MQTT掉线超过10min
                {
                    ret = true;
                }
            }
            break;
        case NETWORK_RECONN_TS:
            if (s_recon_reason.network_reconn_ts <= 0)
            {
                s_recon_reason.network_reconn_ts = ts;
            }
            break;
    }

    return ret;
}

/**
 * @brief       获取链路断开->重连成功的时间
 * @param[in]   p_data              [保存离线数据]
 */
void vesync_net_mgmt_get_reconnect_data(reconn_data_t *p_data)
{
    NET_UTIL_MEM_CHECK(p_data, return);

    if (s_recon_reason.flag)
    {
        p_data->wifi_disconn_ts = s_recon_reason.wifi_disconn_ts;
        p_data->wifi_reconn_ts = s_recon_reason.wifi_reconn_ts;
        p_data->network_disconn_ts = s_recon_reason.network_disconn_ts;
        p_data->network_reconn_ts = s_recon_reason.network_reconn_ts;
        p_data->reason = s_recon_reason.reason;

        for (int idx = WIFI_RETRY_NO_AP_FOUND; idx < CONNECT_RETRY_TYPE_TOTAL; idx++)
        {
            p_data->retry_cnt[idx] = s_recon_reason.retry_cnt[idx];
        }
    }
    else
    {
        memset(p_data, 0, sizeof(reconn_data_t));
    }
}

/**
 * @brief       清除离线记录信息
 */
void vesync_net_mgmt_clear_reconnect_data(void)
{
    memset((uint8_t *)&s_recon_reason, 0, sizeof(reconn_data_t));
}

/**
 * @brief       从flash中读取网络配置到s_net_cfg中。
 * @return      int                 [成功/失败]
 */
int vesync_net_mgmt_load_net_cfg(void)
{
#if 1
    int ret = VERR_FAIL;

// 接口待实现
    memset(&s_net_cfg, 0, sizeof(s_net_cfg));
    ret = vesync_net_flash_read_net_info(&s_net_cfg);
    if (VERR_OK == ret)
    {
        //设置account id
        vesync_device_set_account_id((char*)s_net_cfg.account_id);
        NET_LOG(LOG_DEBUG, "ssid = %s, pwd = %s\n", (char *)s_net_cfg.wifiSSID, (char *)s_net_cfg.wifiPassword);
    }

    return ret;
#else
    // 测试用
    char sta_mac_str[64];
    memset(sta_mac_str, 0, sizeof(sta_mac_str));
    memset(&s_net_cfg, 0, sizeof(s_net_cfg));
    snprintf((char*)(s_net_cfg.net_config.serverDN), sizeof(s_net_cfg.net_config.serverDN), PR_PRODUCTION_SERVER_ADDR);
    snprintf((char*)(s_net_cfg.station_config.wifiSSID), sizeof(s_net_cfg.station_config.wifiSSID), PR_PRODUCTION_WIFI_SSID);
    snprintf((char*)(s_net_cfg.station_config.wifiPassword), sizeof(s_net_cfg.station_config.wifiPassword), PR_PRODUCTION_WIFI_PWD);
    s_net_cfg.station_config.auth_mode = 0;

    if (VHAL_OK != vhal_utils_get_dev_mac(VHAL_MAC_WIFI_STA, sta_mac_str, sizeof(sta_mac_str)))
    {
        snprintf(sta_mac_str, sizeof(sta_mac_str), "00:00:00:00:00:00");   // 获取mac地址失败，使用0填充
    }
    NET_LOG(LOG_DEBUG, "Production param, cid: %s\n", sta_mac_str);
    vesync_device_set_cid(sta_mac_str);
    return VERR_OK;
#endif
}

/**
 * @brief       清除内存中的网络配置
 * @return      int                 [成功/失败]
 */
int vesync_net_mgmt_clear_net_cfg(void)
{
    memset(&s_net_cfg, 0, sizeof(s_net_cfg));
    return VERR_OK;
}

/**
 * @brief       获取一份网络配置的拷贝。
 * @return      net_info_t          [配网数据]
 */
net_info_t* vesync_net_mgmt_get_net_cfg(void)
{
    return &s_net_cfg;
}

/**
 * @brief       获取云端域名。
 * @return      uint8_t*            [域名地址指针]
 */
uint8_t* vesync_net_mgmt_get_server_domain(void)
{
    return (uint8_t *)s_net_cfg.serverDN;
}

/**
 * @brief       获取云端IP。
 * @return      uint8_t*            [IP地址指针]
 */
uint8_t* vesync_net_mgmt_get_server_ip(void)
{
    return (uint8_t *)s_net_cfg.serverIP;
}

/**
 * @brief       获取云端端口。
 * @return      uint32_t*           [端口数据指针]
 */
uint32_t* vesync_net_mgmt_get_server_port(void)
{
    return (uint32_t *)&s_net_cfg.serverPort;
}

#if CONFIG_VESYNC_SDK_NETCFG_ENABLE
/**
 * @brief  获取当前状态是否处于配网中
 * @param[in]  void         [无]
 * @return     bool         [true-配网中，false-非配网状态]
 */
bool vesync_net_mgmt_netcfg_running(void)
{
    if (vesync_netcfg_is_running())
    {
        return true;
    }

#if CONFIG_VESYNC_SDK_FFS_ENABLE
    if (vesync_ffs_is_running())
    {
        return true;
    }
#endif

    return false;
}
/**
 * @brief  获取设备是否已配网
 * @param[in]  void         [无]
 * @return  bool            [true-配过网，false-未配过网]
 */
bool vesync_net_is_configured(void)
{
    int ret = vesync_net_mgmt_load_net_cfg();

    if (VERR_OK != ret || strlen((char *)s_net_cfg.wifiSSID) < 1)
    {
        return false;
    }

    return true;
}

#endif /* CONFIG_VESYNC_SDK_NETCFG_ENABLE */

