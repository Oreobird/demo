/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
* @file         netcfg.h
* @brief        配网业务逻辑接口
* @author       Joshua
* @date         2021-12-29
*/

#ifndef __APP_NETCFG_H__
#define __APP_NETCFG_H__

#ifdef __cplusplus
extern "C" {
#endif

/**
* @brief 应用配网初始化，注册相关回调接口
*/
void app_netcfg_init(void);

#ifdef __cplusplus
}
#endif

#endif



