/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_netcfg_send.c
 * @brief       配网模块的发送接口
 * @author      Louis
 * @date        2021-05-21
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "cJSON.h"
#if defined(CONFIG_TARGET_LINUX)
#include <arpa/inet.h>
#else
#include "lwip/tcpip.h"
#endif

#include "vhal_utils.h"

#include "vesync_utils.h"
#include "vesync_common.h"
#include "vesync_memory.h"
#include "vesync_aes.h"
#include "vesync_device.h"
#ifdef CONFIG_VESYNC_SDK_BLE_SERVICE_ENABLE
#include "vesync_ble_internal.h"
#endif
#include "vesync_wifi_scan.h"
#include "vesync_log_internal.h"
#include "vesync_net_service_internal.h"
#include "vesync_netcfg_internal.h"
#include "vesync_netcfg_send.h"
#include "vesync_netcfg_recv.h"
#include "vesync_lan_trans_prot.h"
#include "vesync_tcp_server.h"
#include "vesync_json_internal.h"
#include "vesync_cfg_internal.h"

/**
 * @brief 通过局域网发送数据
 * @param[in] p_data            [发送的数据]
 * @param[in] len               [数据长度]
 * @param[in] reply             [是否为回复的数据]
 * @return    int               [发送成功或失败]
 */
static int vesync_netcfg_send_lan_data(uint8_t *p_data, uint32_t len, bool reply)
{
    uint32_t total_len = len + LAN_PROT_HEADER_LEN + 1;
    uint32_t data_len = len;
    uint8_t *p_data_out = vesync_malloc(total_len);
    if (NULL == p_data_out)
    {
        SDK_LOG(LOG_ERROR, "malloc fail!\r\n");
        return SDK_FAIL;
    }

    memset((char *)p_data_out, 0, total_len);

    if (SDK_OK == vesync_lan_trans_prot_pack(p_data_out, p_data, &data_len, reply))
    {
        vesync_tcp_server_send(p_data_out, data_len);
    }
    else
    {
        SDK_LOG(LOG_ERROR, "packet fail!!\n");
    }

    VCOM_SAFE_FREE(p_data_out);
    return SDK_OK;
}


/**
 * @brief 配网传输层发送数据
 * @param[in] p_data            [发送的数据]
 * @param[in] len               [数据长度]
 * @param[in] request_flag      [是否为请求]
 * @return    int               [发送成功或失败]
 */
static void vesync_netcfg_trans_send_data(uint8_t *p_data, uint32_t len, bool request_flag)
{
    if (BLE_CONFIG == vesync_netcfg_get_mode())
    {
#ifdef CONFIG_VESYNC_SDK_BLE_SERVICE_ENABLE
        vesync_ble_send_netcfg_data(p_data, len, request_flag);
#endif
    }
    else if (AP_CONFIG == vesync_netcfg_get_mode())
    {
        vesync_netcfg_send_lan_data(p_data, len, false);
    }

    return;
}


/**
 * @brief 配网传输层发送ACK
 * @param[in] p_data            [发送的数据]
 * @param[in] len               [数据长度]
 * @param[in] err_flag          [错误标识]
 * @return    int               [发送成功或失败]
 */
static void vesync_netcfg_trans_send_ack(uint8_t *p_data, uint32_t len, bool err_flag)
{
    if (BLE_CONFIG == vesync_netcfg_get_mode())
    {
#ifdef CONFIG_VESYNC_SDK_BLE_SERVICE_ENABLE
        vesync_ble_send_netcfg_ack(p_data, len, err_flag);
#endif
    }
    else if (AP_CONFIG == vesync_netcfg_get_mode())
    {
        vesync_netcfg_send_lan_data(p_data, len, true);
    }

    return;
}


/**
 * @brief 根据协议封装数据
 * @param[in]  opcode               [操作码]
 * @param[in]  json_data            [json数据指针]
 * @param[out] out_data             [数据输出缓存区]
 * @param[out] out_len              [数据输出长度]
 * @return    int                   [成功或失败]
 */
static int vesync_netcfg_make_packet(uint16_t opcode, cJSON *json_data, char **out_data, uint32_t *out_len)
{
    int ret = SDK_FAIL;
    char* out = NULL;
    uint8_t *encryptData = NULL;
    int encryptLen = 0;
    payload_info_t *paylaod = NULL;
    uint32_t plen = 0;

    if (json_data)
    {
        out = cJSON_PrintUnformatted(json_data);  //不带缩进格式
        if(NULL == out)
        {
            SDK_LOG(LOG_ERROR, "cJSON_PrintUnformatted failed\r\n");
            goto exit;
        }

        encryptLen = vesync_aes_encrypt((uint8_t*)out, strlen(out), &encryptData);
        if(!encryptLen)
        {
            SDK_LOG(LOG_ERROR, "AES Encrypt fail\r\n");
            goto exit;
        }
    }
    else
    {
        encryptLen = 0;
        encryptData = NULL;
    }

    plen = encryptLen + sizeof(payload_info_t);
    paylaod = (payload_info_t *)vesync_malloc(plen);
    if (NULL == paylaod)
    {
        SDK_LOG(LOG_ERROR, "paylaod malloc fail\r\n");
        goto exit;
    }

    memset(paylaod, 0, plen);
    paylaod->version = vesync_netcfg_config_get_protocol_version();
    paylaod->status_code = 0;

    // BLE通信用的小端字节序，WIFI（局域网）通信用的是大端字节序
    // 需要判断配网的模式
    switch (vesync_netcfg_get_mode())
    {
    case BLE_CONFIG:
        paylaod->opcode = vesync_htole16(opcode);
        break;
    case AP_CONFIG:
    default:
        paylaod->opcode = vesync_htobe16(opcode);
        break;
    }

    if (NULL != encryptData)
    {
        memcpy(paylaod->payload_data, encryptData, encryptLen);
    }

    *out_data = (char*)paylaod;
    *out_len = plen;
    ret = SDK_OK;

exit:
    VCOM_SAFE_FREE(out);
    VCOM_SAFE_FREE(encryptData);
    return ret;
}


/**
 * @brief 配网模块统一的发送接口
 * @param[in]  opcode               [操作码]
 * @param[in]  mtype                [数据类型]
 * @param[in]  json_data            [json数据指针]
 * @return    int                   [成功或失败]
 */
void vesync_netcfg_send_data(uint16_t opcode, NETCFG_MTYPE_E mtype, cJSON *json_data)
{
    char *p_data = NULL;
    uint32_t dlen = 0;

    SDK_LOG(LOG_DEBUG, "op_code = 0x%x, msg_type = %d.\r\n", opcode, mtype);
    vesync_json_print(json_data);

    if(SDK_OK != vesync_netcfg_make_packet(opcode, json_data, &p_data, &dlen))
    {
        SDK_LOG(LOG_ERROR, "make packet fail!!\r\n");
        return;
    }

    switch (mtype)
    {
    case MTYPE_ACK:
        vesync_netcfg_trans_send_ack((uint8_t *)p_data, dlen, 0);
        break;

    case MTYPE_REPORT:
        vesync_netcfg_trans_send_data((uint8_t *)p_data, dlen, 1);
        break;

    case MTYPE_LOG:
        vesync_netcfg_trans_send_data((uint8_t *)p_data, dlen, 0);
        break;

    default:
        SDK_LOG(LOG_ERROR, "unknown mtype\r\n");
        break;
    }

    VCOM_SAFE_FREE(p_data);
    return;
}


/**
 * @brief 返回协议层错误
 * @param[in]  opcode               [操作码]
 * @param[in]  status_code          [状态码]
 */
void vesync_netcfg_send_error(uint16_t opcode, uint16_t status_code)
{
    payload_info_t *p_paylaod = (payload_info_t *)vesync_malloc(sizeof(payload_info_t));
    if (NULL == p_paylaod)
    {
        SDK_LOG(LOG_ERROR, "malloc fail!\r\n");
        return;
    }
    memset(p_paylaod, 0, sizeof(payload_info_t));

    switch (vesync_netcfg_get_mode())
    {
    case BLE_CONFIG:
        p_paylaod->opcode = vesync_htole16(opcode);
        break;
    case AP_CONFIG:
    default:
        p_paylaod->opcode = vesync_htobe16(opcode);
        break;
    }

    p_paylaod->status_code = status_code;
    p_paylaod->version = vesync_netcfg_config_get_protocol_version();
    vesync_netcfg_trans_send_ack((uint8_t *)p_paylaod, sizeof(payload_info_t), 1); // 数据应答
    VCOM_SAFE_FREE(p_paylaod);
}



/**
 * @brief 配网状态上报
 * @param[in]  msg                  [附加的消息内容，格式和内容各阶段事件自定义；NULL则无附加消息]
 */
void vesync_netcfg_report_status(const char* msg)
{
    cJSON *root = NULL;
    char step[8]={0};
    const char* step_names[NETCFG_STATUS_MAX] =
    {
        "DEV_IDLE",
        "DEV_RECEIVE_APP_DATA",
        "DEV_CONNECTED_WIFI",
        "DEV_GOT_IP",
        "DEV_DNS_RESOLVED",
        "DEV_CONNECTED_SERVER",
        "DEV_SUBSCRIBE_SUCCESS",
        "DEV_SAVE_CFG_SUCCESS",
    };
    NETCFG_STATUS_E status = vesync_netcfg_get_status();

    root = cJSON_CreateObject();
    if(NULL == root)
    {
        return ;
    }

    snprintf(step, sizeof(step), "step%d", status);
    step[6] = 0;
    cJSON_AddStringToObject(root, step, step_names[status]);

    switch(status)
    {
    case NETCFG_STATUS_RECV_CFG_DATA:
        {
            char mac_str[MAC_ADDR_STR_MAX_LEN] = {0};
            vesync_bss_info_t* p_ap = NULL;

            net_info_t *p_net_cfg = vesync_net_mgmt_get_net_cfg();

            cJSON_AddStringToObject(root, "deviceCid", vesync_device_get_cid());
            if (VHAL_OK != vhal_utils_get_dev_mac(VHAL_MAC_WIFI_STA, mac_str, sizeof(mac_str)))
            {
                snprintf(mac_str, sizeof(mac_str), "00:00:00:00:00:00");
            }
            cJSON_AddStringToObject(root, "deviceMac", mac_str);
            cJSON_AddStringToObject(root, "firmVersion", vesync_cfg_get_fw_version());

            p_ap = vesync_wifi_get_apinfo_by_ssid(p_net_cfg->wifiSSID);
            // user may manual input, it may not be found.
            if (NULL != p_ap)
            {
                memset((void*)mac_str, 0, MAC_ADDR_STR_MAX_LEN);
                snprintf(mac_str, MAC_ADDR_STR_MAX_LEN, MACSTR, MAC2STR(p_ap->bssid));
                mac_str[MAC_ADDR_STR_MAX_LEN - 1] = 0;
                cJSON_AddStringToObject(root, "routerMac", mac_str);
                cJSON_AddNumberToObject(root, "routerRssi", p_ap->rssi);
            }
            cJSON_AddNumberToObject(root, "free_heap", vhal_utils_get_free_heap_size());
        }
        break;
    case NETCFG_STATUS_CONNECTED_WIFI:
        {
            char gw_mac_str[MAC_ADDR_STR_MAX_LEN] = {0};
            if (VHAL_OK != vhal_utils_get_dev_mac(VHAL_MAC_ROUTER, gw_mac_str, sizeof(gw_mac_str)))
            {
                snprintf(gw_mac_str, sizeof(gw_mac_str), "00:00:00:00:00:00");
            }
            cJSON_AddStringToObject(root, "routerMac", gw_mac_str);
            cJSON_AddNumberToObject(root, "routerRssi", vhal_wifi_get_router_rssi(8));
            cJSON_AddNumberToObject(root, "channel", vhal_wifi_get_channel());
            cJSON_AddNumberToObject(root, "free_heap", vhal_utils_get_free_heap_size());
        }
        break;
    case NETCFG_STATUS_GOT_IP:
        {
            char ip_buf[20] = {0};      // 保存ip空间
            cJSON_AddStringToObject(root, "ip", vhal_utils_get_sta_ip(ip_buf, sizeof(ip_buf)));
            cJSON_AddNumberToObject(root, "free_heap", vhal_utils_get_free_heap_size());
        }
        break;
    case NETCFG_STATUS_DNS_RESOLVED:
        {
            if (NULL != msg)
            {
                cJSON_AddStringToObject(root, "ip", msg);
            }
            cJSON_AddNumberToObject(root, "free_heap", vhal_utils_get_free_heap_size());
        }
        break;
    case NETCFG_STATUS_CONNECTED_SERVER:
        cJSON_AddNumberToObject(root, "free_heap", vhal_utils_get_free_heap_size());
        break;
    case NETCFG_STATUS_SUBSCRIBE_SUCCESS:
        cJSON_AddNumberToObject(root, "free_heap", vhal_utils_get_free_heap_size());
        break;
    default:
        break;
    }

    vesync_netcfg_send_data(OP_NETCFG_STATUS, MTYPE_LOG, root);
    cJSON_Delete(root);
}

/**
 * @brief WIFI断开连接时HAL WIFI传递错误码和错误描述的callback
 * @param[in]  reason_name      [错误描述]
 */
void vesync_netcfg_report_wifi_disconnect(const char* reason_name)
{
    VCOM_NULL_PARAM_CHK(reason_name, return);
    cJSON *root = cJSON_CreateObject();
    if (NULL != root)
    {
        cJSON_AddStringToObject(root,"type", NETCFG_ERR_TYPE_STR_WIFI);
        if (NULL != reason_name)
        {
            cJSON_AddStringToObject(root, "msg", reason_name);
        }

        vesync_netcfg_send_data(OP_ERR_REPORT, MTYPE_LOG, root);
        cJSON_Delete(root);
    }
}

