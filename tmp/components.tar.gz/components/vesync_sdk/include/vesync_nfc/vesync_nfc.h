/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
 * @file        vesync_nfc.h
 * @brief       nfc模块vesync层对外接口
 * @date        2021-11-13
 */

#ifndef __VESYNC_NFC_H__
#define __VESYNC_NFC_H__

#include "vesync_frame.h"
#ifdef __cplusplus
extern "C"
{
#endif

/**
 * @brief NFC数据类型
 */
typedef enum
{
    VESYNC_NFC_TYPE_DEV = 0,             //设备信息
    VESYNC_NFC_TYPE_NETCFG_INFO = 1,     //配网信息
    VESYNC_NFC_TYPE_NETCFG_ERR_INFO = 2, //配网失败信息
    VESYNC_NFC_TYPE_NFC_MAX
} VESYNC_NFC_DATA_TYPE_E;

/**
 * @brief NFC配网事件定义
 */
typedef enum
{
    NFC_EVT_NETCFG_OK = 0,
    NFC_EVT_INTERNAL_ERROR = 1,  //内部错误，配网结束
    NFC_EVT_DATA_READ_ERROR = 2, //读数据失败
    NFC_EVT_MAX
} VESYNC_NFC_EVT_E;

/**
 * @brief 数据接收返回应用层回调函数,将正确的数据帧通过此回调函数传给应用层
 * @param[in]  frame        [接收功能模块的结构体指针]
 */
typedef void (*vesync_nfc_frame_recv_cb_t)(tl_frame_recv_info_t *frame);

/**
 * @brief nfc模块初始化
 * @return  uint32_t     [成功：SDK_OK，失败：SDK_FAIL]
 */
uint32_t vesync_nfc_init(void);

/**
 * @brief  注册配网数据接收的回调函数
 * @param[in]  cb      [配网数据接收的回调函数]
 */
void vesync_nfc_reg_netcfg_recv_cb(vesync_nfc_frame_recv_cb_t cb);

/**
 * @brief  NFC 发送NET 设备信息数据
 * @param[in]  req_flag     [是否需要对端回复]
 * @return  uint32_t         [成功：SDK_OK，失败：SDK_FAIL]
 */
uint32_t vesync_nfc_send_dev_info(uint8_t req_flag);

/**
 * @brief  NFC 发送NET 配网错误信息
 * @param[in]  p_data       [数据指针]
 * @param[in]  len          [数据长度]
 * @param[in]  req_flag     [是否需要对端回复]
 * @return  uint32_t         [成功：SDK_OK，失败：SDK_FAIL]
 */
uint32_t vesync_nfc_send_error_info(uint8_t *p_data, uint16_t len, uint8_t req_flag);

/**
 * @brief  NFC 启动配网
 * @return  uint32_t         [成功：SDK_OK，失败：SDK_FAIL]
 */
uint32_t vesync_nfc_start_netcfg(void);

/**
 * @brief  NFC 停止配网
 * @return  uint32_t         [成功：SDK_OK，失败：SDK_FAIL]
 */
uint32_t vesync_nfc_stop_netcfg(void);

/**
 * @brief  发送nfc命令
 * @param[in]  data_type   [数据类型]
 * @param[in]  p_data      [数据缓存指针]
 * @param[in]  len         [数据长度]
 * @param[in]  req_flag    [req标志] 
 * @return    uint32_t     [成功：SDK_OK，失败：SDK_FAIL]
 */
uint32_t vesync_nfc_send_data(uint8_t data_type, uint8_t *p_data, uint16_t len, uint8_t req_flag);

#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_NFC_H__ */
