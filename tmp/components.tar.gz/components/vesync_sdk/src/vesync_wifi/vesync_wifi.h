/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file    vesync_wifi.h
 * @brief   WIFI提供给内部的管理接口
 * @date    2021-05-27
 */


#ifndef __VESYNC_WIFI_H__
#define __VESYNC_WIFI_H__


#include <stdint.h>
#include <stdbool.h>

#include "vesync_common.h"
#include "vhal_wifi.h"


#ifdef __cplusplus
extern "C"
{
#endif /* __cplusplus */


#ifndef HOSTNAME_MAX_LEN
#define HOSTNAME_MAX_LEN (33)
#endif

#define WIFI_EVENT_PUBLISH_STR  "wifi"

/*
 * @brief   设备重连次数
 */
typedef enum
{
    WIFI_RETRY_NO_AP_FOUND      = 0,    // Wi-Fi连接未找到AP
    WIFI_RETRY_INVALID_PWD,             // Wi-Fi连接返回密码错误
    WIFI_RETRY_CONNECT_FAIL,            // Wi-Fi连接失败
    NETWORK_RETRY_FAIL,                 // 网络(应用层协议)连接失败
    CONNECT_RETRY_TYPE_TOTAL,
} DEV_CONNECT_FAIL_TYPE_E;



/**
 * @brief       用户调用初始化wifi模块
 */
void vesync_wifi_client_init(void);

/**
 * @brief       用户调用关闭wifi模块
 */
void vesync_wifi_client_deinit(void);

/**
 * @brief       vesync客户端连接WiFi
 * @param[in]   p_wifi_ssid          [WiFi账号]
 * @param[in]   p_wifi_pwd           [WiFi密码]
 * @param[in]   auth_mode            [WiFi加密模式]
 */
void vesync_wifi_client_connect(const char *p_wifi_ssid, const char *p_wifi_pwd, VHAL_WIFI_AUTH_MODE_E auth_mode);

/**
 * @brief       vesync客户端断开重连WiFi
 */
void vesync_wifi_client_reconnect(void);

/**
 * @brief       获取Wi-Fi连接状态
 * @return      与HAL相同定义的wifi连接状态
 */
VHAL_WIFI_STATUS_E vesync_wifi_get_link_status(void);

/**
 * @brief       获取Wi-Fi连接连接失败原因
 * @return      与HAL相同定义的wifi连接失败原因
 */
VHAL_WIFI_STATUS_E vesync_wifi_get_fail_rsn(void);


#ifdef __cplusplus
}
#endif /* __cplusplus */


#endif /* __VESYNC_WIFI_H__ */
