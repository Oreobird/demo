/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_buffer.c
 * @brief       Vesync buffer 相关实现
 * @author      Herve Lin
 * @date        2021-08-06
 */
#include <string.h>
#include <stdlib.h>

#include "vesync_buffer.h"
#include "vesync_memory.h"

#define VESYNC_BUFFER_MAGIC_CODE    (0x9527)    // Magic code

/**
 * @brief 新建一个Buffer。需要用vesync_buf_clr()清除以释放内存。
 * @return vesync_buf_t [返回的Buffer]
 */
vesync_buf_t vesync_buf_new(void)
{
    vesync_buf_t buffer = {
        buf: NULL,
        len: 0,
        _mc: VESYNC_BUFFER_MAGIC_CODE,
    };

    return buffer;
}

/**
 * @brief 清空一个Buffer。Buffer需要是由vesync_buf_new()生成的。
 * @param[in] buffer     [指向要被清空的Buffer]
 */
void vesync_buf_clr(vesync_buf_t *buffer)
{
    if (NULL == buffer || buffer->_mc != VESYNC_BUFFER_MAGIC_CODE)
    {
        return;
    }

    vesync_free(buffer->buf);
    buffer->buf = NULL;
    buffer->len = 0;
}

/**
 * @brief 内存重新分配与拷贝
 * @param[in] dest      [指向目的地址]
 * @param[in] dest_len  [指向目的地址数据长度]
 * @param[in] src       [指向源地址]
 * @param[in] src_len   [源地址数据长度]
 */
static void buffer_memcpy(void **dest, uint32_t *dest_len, void *src, uint32_t src_len)
{
    if (*dest_len != src_len)
    {
        /**
         * @note:
         *  如果realloc(ptr, 0)的情况发生，等效于:
         *  @code:
         *  {
         *      free(ptr);
         *      ptr = malloc(0);
         *  }
         *  @endcode
         *  这个时候ptr为有效指针，buf=ptr！=NULL，buf_len==0，是合理的。
         *
         *  初始化后的buffer，buffer->buf不可以随便赋NULL
         */
        void *p_new = vesync_realloc(*dest, src_len);
        // reallc()失败，不进行复制
        if (p_new == NULL)
        {
            return;
        }

        *dest = p_new;
        *dest_len = src_len;
    }

    memcpy(*dest, src, src_len);
}

/**
 * @brief 将一个Buffer拷贝到另一个Buffer
 * @param[in] dest      [指向目的Buffer]
 * @param[in] src       [指向源Buffer]
 */
void vesync_buf_cpy(vesync_buf_t *dest, const vesync_buf_t *src)
{
    if (NULL == dest || dest->_mc != VESYNC_BUFFER_MAGIC_CODE)
    {
        return;
    }

    if (src->_mc != VESYNC_BUFFER_MAGIC_CODE)
    {
        return;
    }

    buffer_memcpy(&dest->buf, &dest->len, src->buf, src->len);
}

/**
 * @brief 向Buffer缓存数据
 * @param[in] buffer    [指向写入的Buffer]
 * @param[in] p_data    [指向缓存数据]
 * @param[in] len       [数据长度]
 */
void vesync_buf_set(vesync_buf_t *buffer, void *p_data, uint32_t len)
{
    if (NULL == buffer || buffer->_mc != VESYNC_BUFFER_MAGIC_CODE)
    {
        return;
    }

    buffer_memcpy(&buffer->buf, &buffer->len, p_data, len);
}

/**
 * @brief 向Buffer读出数据
 * @param[in]  buffer    [指向源数据Buffer]
 * @param[out] p_data    [指向读出数据的缓存]
 * @param[in]  len       [读出数据的缓存长度]
 */
void vesync_buf_get(const vesync_buf_t *buffer, void *p_data, uint32_t len)
{
    if (buffer->_mc != VESYNC_BUFFER_MAGIC_CODE)
    {
        return;
    }

    memcpy(p_data, buffer->buf, buffer->len > len ? len : buffer->len);
}