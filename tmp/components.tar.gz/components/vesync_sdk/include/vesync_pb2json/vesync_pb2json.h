/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_pb2json.h
 * @brief       Protobuf与JSON互转接口
 * @date        2021-12-13
 */

#ifndef __VESYNC_PB2JSON_H__
#define __VESYNC_PB2JSON_H__

#include <stdint.h>
#include <protobuf-c/protobuf-c.h>

#include "cJSON.h"

#ifdef __cplusplus
extern "C" {
#endif

#if PROTOBUF_C_VERSION_NUMBER < 1004000
#error Version of libprotobuf-c below 1.4.0 is not evaluated yet.
#endif /* PROTOBUF_C_VERSION_NUMBER */

/**
 * @brief PB2JSON错误类型定义
 */
typedef enum
{
    PROTOBUF2JSON_ERR_OK = 0,
    PROTOBUF2JSON_ERR_CANNOT_ALLOCATE_MEMORY = -001,
    PROTOBUF2JSON_ERR_UNSUPPORTED_FIELD_TYPE = -002,
    PROTOBUF2JSON_ERR_UNKNOWN_ENUM_VALUE = -003,
    PROTOBUF2JSON_ERR_INVALID_FIELD_TYPE = -004,
    PROTOBUF2JSON_ERR_UNSUPPORTED_FIELD_LABEL = -005,
    PROTOBUF2JSON_ERR_UNKNOWN_FIELD = -401,
    PROTOBUF2JSON_ERR_IS_NOT_OBJECT = -402,
    PROTOBUF2JSON_ERR_IS_NOT_ARRAY = -403,
    PROTOBUF2JSON_ERR_IS_NOT_INTEGER = -404,
    PROTOBUF2JSON_ERR_IS_NOT_INTEGER_OR_REAL = -405,
    PROTOBUF2JSON_ERR_IS_NOT_BOOLEAN = -406,
    PROTOBUF2JSON_ERR_IS_NOT_STRING = -407,
    PROTOBUF2JSON_ERR_REQUIRED_IS_MISSING = -408,
    PROTOBUF2JSON_ERR_DUPLICATE_FIELD = -409,
    PROTOBUF2JSON_ERR_IS_NOT_NUMBERIC_BOOLEAN = -410,
} PROTOBUF2JSON_ERR_E;

/**
 * @brief PB2JSON处理的额外功能枚举
 */
typedef enum
{
    PROC_FLAG_NULL = 0x00,                 // 空标志，不做任何处理
    PROC_FLAG_NUMBERIC_BOOL = 0x01,        // 将布尔值作为数值处理
    PROC_FLAG_NUMBERIC_ENUM = 0x02,        // 将枚举值作为数值处理
    PROC_FLAG_IGNORE_UNKNOWN_FIELD = 0x04, // JSON转PB时，忽略未知的域
    PROC_FLAG_IGNORE_EMPTY_ARRAY = 0x08,   // PB转JSON时，空的Repeated域不转为空的Array
} PROC_FLAG_E;

typedef uint8_t proc_flag_t;

/**
 * @brief Protobuf转JSON
 * @param[in]   flag                [功能选项开关，由PROC_FLAG_E组合得到的值]
 * @param[in]   p_pb_msg            [指向源Protobuf结构体的base成员（实际上指向结构体本身）]
 * @param[out]  p_json_ref          [指向输出的JSON对象的引用]
 * @return      int                 [PROTOBUF2JSON_ERR_E]
 */
int vesync_pb2json(proc_flag_t flag, ProtobufCMessage *p_pb_msg, cJSON **p_json_ref);

/**
 * @brief JSON转Protobuf
 * @param[in]   flag                [功能选项开关，由PROC_FLAG_E组合得到的值]
 * @param[in]   p_json              [指向输入的JSON对象]
 * @param[in]   p_pb_msg_desc       [指向输出Protobuf的描述符]
 * @param[out]  p_pb_msg_ref        [指向输出Protobuf的引用]
 * @return      int                 [PROTOBUF2JSON_ERR_E]
 */
int vesync_json2pb(proc_flag_t flag, cJSON *p_json, const ProtobufCMessageDescriptor *p_pb_msg_desc, ProtobufCMessage **p_pb_msg_ref);

#ifdef __cplusplus
}
#endif

#endif