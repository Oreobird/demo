/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
 * @file        vesync_nfc_card.h
 * @brief       nfc模块card通信模块接口定义
 * @date        2021-11-13
 */

#ifndef __VESYNC_NFC_CARD_H__
#define __VESYNC_NFC_CARD_H__

#include <stdint.h>
#include <stdbool.h>
#include "vesync_nfc.h"

#ifdef __cplusplus
extern "C"
{
#endif

/**
 * @brief NFC卡通信接口
 */
typedef enum
{
    CARD_INTERFACE_IIC = 0, //iic 接口
    CARD_INTERFACE_SPI = 1, //spi 接口
    CARD_INTERFACE_MAX
} VESYNC_NFC_CARD_INTERFACE_E;

/**
 * @brief NFC数据类型
 */
typedef enum
{
    TYPE_DEV = 0,             //设备信息
    TYPE_NETCFG_INFO = 1,     //配网信息
    TYPE_NETCFG_ERR_INFO = 2, //配网失败信息
    TYPE_NFC_MAX
} VESYNC_NFC_CARD_DATA_TYPE_E;

/**
 * @brief  NFC事件回调函数
 * @param[in]  event           [蓝牙事件类型]
 */
typedef void (*vesync_nfc_card_evt_cb_t)(VESYNC_NFC_EVT_E event);

/**
 * @brief  nfc数据接收回调函数
 * @param[in]  p_data          [接收的命令数据]
 * @param[in]  length          [数据长度]
 */
typedef void (*vesync_nfc_card_data_recv_cb_t)(uint8_t *p_data, uint16_t length);

/**
 * @brief NFC 卡唤醒回调函数定义
 * @param[in]  para     [回调函数传进内容,目前为pin脚值]
 */
typedef void (*vesync_nfc_card_wake_up_cb_t)(uint8_t para);

/**
 * @brief NFC卡iic接口初始化参数
*/
typedef struct
{
    uint8_t sda_pin;    //sda pin
    uint8_t scl_pin;    //sda pin
    uint8_t iic_cs_pin; //iic 片选 pin
} vesync_nfc_card_iic_ctrl_t;

/**
 * @brief NFC 卡基本参数
*/
typedef struct
{
    uint32_t dev_info_addr;          //设备信息地址
    uint16_t dev_info_len;           //设备信息长度
    uint32_t netcfg_info_addr;       //配网信息地址
    uint16_t netcfg_info_len;        //配网信息长度
    uint32_t netcfg_error_info_addr; //配网错误信息地址
    uint16_t netcfg_error_info_len;  //配网错误信息长度
    uint16_t uid_len;                //卡片uid长度
} vesync_nfc_card_basic_ctrl_t;

/**
 * @brief NFC 读写卡模式唤醒参数
*/
typedef struct
{
    bool wake_up_en;                   //唤醒功能是否使能
    uint32_t wait_time_after_wakeup_s; //RF被唤醒后等待手机写入数据时间,单位：秒
    uint8_t wake_up_pin;               //nfc无线端进场中断信号产生引脚
} vesync_nfc_card_wake_up_ctrl_t;

/**
 * @brief NFC 睡眠模式参数
*/
typedef struct
{
    bool sleep_en;     //睡眠功能是否使能
    uint8_t sleep_pin; //nfc睡眠功能设置引脚
} vesync_nfc_card_sleep_ctrl_t;

/**
 * @brief NFC基本读写接口定义
*/
typedef union
{
    vesync_nfc_card_iic_ctrl_t iic_ctrl;
} vesync_nfc_card_interface_ctrl_u;

/**
 * @brief NFC卡密码参数
*/
typedef union
{
    bool psw_en;      //密码认证功能是否使能
    uint32_t psw;     //密码值
    uint16_t psw_ack; //密码认证响应值
} vesync_nfc_card_psw_ctrl_t;

/**
 * @brief  NFC卡基本参数初始化函数指针定义
 * @param[in]  sda_io      [iic SDA 引脚]
 * @param[in]  scl_io      [iic scl引脚]
 * @param[in]  cs_pin      [iic 片选脚]
 * @return uint32_t        [成功：SDK_OK，失败：SDK_FAIL]
 */
typedef uint32_t (*vesync_nfc_card_i2c_init_cb)(uint8_t sda_io, uint8_t scl_io, uint8_t cs_pin);

/**
 * @brief  NFC卡硬件接口初始化函数指针联合体定义
 */
typedef union
{
    vesync_nfc_card_i2c_init_cb iic_init_cb;
} vesync_nfc_card_interface_init_ctrl_u;

/**
 * @brief  NFC卡基本参数初始化函数指针定义
 * @param[in]  enable       [NFC卡唤醒功能是否使能]
 * @return uint32_t         [成功：SDK_OK，失败：SDK_FAIL]
 */
typedef uint32_t (*vesync_nfc_card_wake_up_init_cb)(bool enable);

/**
 * @brief  NFC卡密码始化函数指针定义
 * @param[in]  pwd_en      [NFC卡密码功能是否使能]
 * @param[in]  pwd         [NFC卡4byte密码]
 * @param[in]  pwd_ack     [NFC卡密码ACK值]
 * @return uint32_t        [成功：SDK_OK，失败：SDK_FAIL]
 */
typedef uint32_t (*vesync_nfc_card_psw_init_cb)(bool pwd_en, uint32_t pwd, uint16_t pwd_ack);

/**
 * @brief  NFC卡睡眠功能参数初始化函数指针定义
 * @param[in]  sleep_enable      [NFC卡睡眠功能是否使能，1使能，0禁止]
 * @param[in]  pin_num           [NFC卡睡眠功能pin脚]
 * @return uint32_t              [成功：SDK_OK，失败：SDK_FAIL]
 */
typedef uint32_t (*vesync_nfc_card_sleep_init_cb)(bool sleep_enable, uint32_t pin_num);

/**
 * @brief  NFC卡设置卡片无线端休眠/醒来回调
 * @param[in]  sleep_en      [NFC卡无线端休眠/激活]
 * @return uint32_t          [成功：SDK_OK，失败：SDK_FAIL]
 */
typedef uint32_t (*vesync_nfc_card_sleep_en_cb)(bool sleep_en);

/**
 * @brief  NFC卡数据读写回调函数指针定义
 * @param[in]  addr     [读/写数据的地址]
 * @param[in]  buf      [读/写数据指针]
 * @param[in]  len      [读/写数据长度]
 * @return  uint32_t    [成功：SDK_OK，失败：SDK_FAIL]
 */
typedef uint32_t (*vesync_nfc_card_data_read_write_cb)(uint16_t addr, uint8_t *buf, uint16_t len);

/**
 * @brief  NFC卡获取卡片uid回调函数指针定义
 * @param[out]      dev_uid     [uid数据指针]
 * @param[in]       max_len     [uid缓存长度]
 * @return  uint32_t            [成功：SDK_OK，失败：SDK_FAIL]
 */
typedef uint32_t (*vesync_nfc_card_get_uid_cb)(uint8_t *dev_uid, uint8_t max_len);

/**
 * @brief  NFC卡唤醒中断服务函数注册接口，不同卡片注册接口不同
 * @param[in]      wake_up_isr     [GPIO pin 脚中断服务函数]
 * @param[in]      wake_up_pin     [唤醒pin脚]
 */
typedef void (*vesync_nfc_card_wake_up_isr_register)(vesync_nfc_card_wake_up_cb_t wake_up_isr, uint32_t wake_up_pin);

/**
 * @brief  一个NFC卡片实例参数定义
*/
typedef struct
{
    vesync_nfc_card_interface_ctrl_u hw_interface;           //卡片与WIFI接口参数
    vesync_nfc_card_basic_ctrl_t basic_info;                 //卡片基本参数
    vesync_nfc_card_wake_up_ctrl_t wake_up_ctrl;             //唤醒功能参数
    vesync_nfc_card_psw_ctrl_t psw_ctrl;                     //密码功能参数
    vesync_nfc_card_sleep_ctrl_t sleep_ctrl;                 //睡眠功能参数
    vesync_nfc_card_interface_init_ctrl_u interface_init_cb; //基本参数初始化回调
    vesync_nfc_card_wake_up_init_cb wake_up_init_cb;         //唤醒功能初始化回调
    vesync_nfc_card_psw_init_cb psw_inti_cb;                 //密码功能初始化回调
    vesync_nfc_card_sleep_init_cb sleep_init_cb;             //睡眠功能初始化回调
    vesync_nfc_card_sleep_en_cb sleep_set_cb;                //睡眠设置回调
    vesync_nfc_card_data_read_write_cb write_data_cb;        //写数据回调
    vesync_nfc_card_data_read_write_cb read_cb;              //读数据回调
    vesync_nfc_card_get_uid_cb uid_get_cb;                   //获取uid回调
    vesync_nfc_card_wake_up_isr_register nfc_card_wake_up_isr_register_cb;
} vesync_nfc_card_ctrl_t;

/**
 * @brief 创建一张NFC卡,目前仅支持一张卡片情况
 * @param[in]  nfc_crad_ctrl     [卡片参数]
 * @return  uint32_t             [返回卡片唯一ID]
 */
uint32_t vesync_nfc_card_create(vesync_nfc_card_ctrl_t *nfc_card_ctrl);

/**
 * @brief 注册数据接收回调函数
 * @param[cb]  cb          [数据接收回调函数] 
 */
void vesync_nfc_card_reg_recv_cb(vesync_nfc_card_data_recv_cb_t cb);

/**
 * @brief 注册事件回调回调函数
 * @param[cb]  cb          [事件通知回调函数] 
 */
void vesync_nfc_card_reg_event_cb(vesync_nfc_card_evt_cb_t cb);

/**
 * @brief 向NFC卡发送配网数据
 * @param[in]  data_type        [数据类型] 
 * @param[in] p_data            [发送数据指针]
 * @param[in] len               [发送数据长度]
 * @return  uint32_t            [成功：SDK_OK，失败：SDK_FAIL]
 */
uint32_t vesync_nfc_card_netcfg_data_send(VESYNC_NFC_CARD_DATA_TYPE_E data_type, uint8_t *p_data, uint16_t len);

/**
 * @param[out] dev_uid          [获取nfc卡UID]
 * @param[in]  max_len          [dev_uid buffer长度]
 * @return  uint32_t            [成功：SDK_OK，失败：SDK_FAILL]
 */
uint32_t vesync_nfc_card_get_uid(char *dev_uid, uint32_t max_len);

/**
 * @brief  nfc卡配网启动
 * @return  uint32_t  [成功：SDK_OK，失败：SDK_FAIL]
 */
uint32_t vesync_nfc_card_start_netcfg(void);

/**
 * @brief  nfc配网停止
 * @return  uint32_t  [成功：SDK_OK，失败：SDK_FAIL]
 */
uint32_t vesync_nfc_card_stop_netcfg(void);

#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_NFC_CARD_H__ */
