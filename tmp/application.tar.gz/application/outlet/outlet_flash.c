/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file        outlet_flash.c
* @brief       outlet flash接口
* @author      Joshua
* @date        2021-06-04
*/
#include <stdio.h>
#include <string.h>

#include "vesync_common.h"
#include "vesync_log.h"
#include "vesync_flash.h"
#include "vesync_device.h"
#include "vesync_klv.h"
#include "vesync_memory.h"

#include "outlet_flash.h"
#include "outlet_gpio.h"
#include "outlet.h"
#include "outlet_board.h"
#if defined(OUTLET_ELEC_METERING) && (OUTLET_ELEC_METERING == 1)
#include "outlet_metering.h"
#endif



#define  SWITCH_KLV_DATE_LEN    128


static switch_flash_data_t s_sw_cfg;            // 当前配置

/**
 * @brief 保存开关数据到flash
 * @param[in]  switch_flash_data_t  [开关配置]
 * @return     int8_t               [成功/失败]
 */
int8_t switch_save_config(switch_flash_data_t data)
{
    int ret = 0;
    uint8_t *p_buf= NULL;
    int offset = 0;
    uint8_t version = 0;

    if(NULL == (p_buf = (uint8_t *)vesync_malloc(SWITCH_KLV_DATE_LEN)))
    {
        return APP_FAIL;
    }

    memset(p_buf, 0, SWITCH_KLV_DATE_LEN);

    version = OUTLET_APP_DATA_VERSION;

    offset +=  vesync_klv_set(p_buf+offset, SWITCH_KLV_DATE_LEN-offset, SWITCH_KEY_VERSION, sizeof(version), &version);
    offset +=  vesync_klv_set(p_buf+offset, SWITCH_KLV_DATE_LEN-offset, SWITCH_KEY_ONOFF, sizeof(data.switch_onoff), &data.switch_onoff);
    offset +=  vesync_klv_set(p_buf+offset, SWITCH_KLV_DATE_LEN-offset, SWITCH_KEY_INIT_FLAG, sizeof(data.switch_init_flag), &data.switch_init_flag);

#if defined(OUTLET_ELEC_METERING) && (OUTLET_ELEC_METERING == 1)
    uint8_t *p_sub_buf = (uint8_t *)vesync_malloc(SWITCH_KLV_DATE_LEN);
    int sub_offset = 0;
    if(NULL == p_sub_buf)
    {
        vesync_free(p_buf);
        return APP_FAIL;
    }
    sub_offset +=  vesync_klv_set(p_sub_buf+sub_offset, SWITCH_KLV_DATE_LEN-sub_offset, SAVE_ELEC_ENABLE, sizeof(data.save_elec.enable), &data.save_elec.enable);
    sub_offset +=  vesync_klv_set(p_sub_buf+sub_offset, SWITCH_KLV_DATE_LEN-sub_offset, SAVE_ELEC_MAX_ELEC, sizeof(data.save_elec.max_elec), (uint8_t *)&data.save_elec.max_elec);
    offset +=  vesync_klv_set(p_buf+offset, SWITCH_KLV_DATE_LEN-offset, SWITCH_KEY_SAVE_ELEC_MODE, sub_offset, p_sub_buf);

    sub_offset = 0;
    sub_offset +=  vesync_klv_set(p_sub_buf+sub_offset, SWITCH_KLV_DATE_LEN-sub_offset, POW_TRIG_ENABLE, sizeof(data.pow_trig.enable), &data.pow_trig.enable);
    sub_offset +=  vesync_klv_set(p_sub_buf+sub_offset, SWITCH_KLV_DATE_LEN-sub_offset, POW_TRIG_TYPE, sizeof(data.pow_trig.type), &data.pow_trig.type);
    sub_offset +=  vesync_klv_set(p_sub_buf+sub_offset, SWITCH_KLV_DATE_LEN-sub_offset, POW_TRIG_POWER, sizeof(data.pow_trig.power), (uint8_t *)&data.pow_trig.power);
    offset +=  vesync_klv_set(p_buf+offset, SWITCH_KLV_DATE_LEN-offset, SWITCH_KEY_POW_TRIG_MODE, sub_offset, p_sub_buf);
    vesync_free(p_sub_buf);
#endif

    ret = vhal_flash_write(PARTITION_CFG, SWITCH_USER_CFG_KEY_DATA,p_buf,offset);

    vesync_free(p_buf);

    if (VHAL_OK != ret)
    {
        APP_LOG(LOG_ERROR, "Write switch data fail, ret = %d.\n", ret);
        return APP_FAIL;
    }

    return APP_OK;
}

/**
 * @brief 清除开关配置
 * @param void
 * @return int
 */
int switch_clear_config(void)
{
    int ret = VHAL_FAIL;

    ret = vhal_flash_erase_key(PARTITION_CFG, SWITCH_USER_CFG_KEY_DATA);
    if (VHAL_OK != ret)
    {
        APP_LOG(LOG_ERROR, "Clear switch data fail\n");
        return APP_FAIL;
    }

    return APP_OK;
}

/**
 * @brief 从flash中读取开关数据到内存
 * @param[out] switch_flash_data_t  [开关配置]
 * @return     int8_t               [成功/失败]
 */
int8_t switch_read_switch_data(switch_flash_data_t *p_data)
{
    int ret = 0;
    uint32_t len = 0;
    uint8_t *p_buf= NULL;
    uint8_t version = 0;

    if (NULL == p_data)
    {
        APP_LOG(LOG_ERROR, "Input parameters contain null pointers!\n");
        return APP_FAIL;
    }

     if(NULL == (p_buf = (uint8_t *)vesync_malloc(SWITCH_KLV_DATE_LEN)))
    {
        return APP_FAIL;
    }

    len = SWITCH_KLV_DATE_LEN;
    if (VHAL_OK != vhal_flash_read(PARTITION_CFG, SWITCH_USER_CFG_KEY_DATA, p_buf, &len) || 0 == len)
    {
        APP_LOG(LOG_ERROR, "Read switch data fail, ret = %d.\n", ret);
        vesync_free(p_buf);
        return APP_FAIL;
    }

    vesync_klv_get(p_buf, len, SWITCH_KEY_VERSION, sizeof(version), &version);
    vesync_klv_get(p_buf, len, SWITCH_KEY_ONOFF, sizeof(p_data->switch_onoff), &p_data->switch_onoff);
    vesync_klv_get(p_buf, len, SWITCH_KEY_INIT_FLAG, sizeof(p_data->switch_init_flag), &p_data->switch_init_flag);

#if defined(OUTLET_ELEC_METERING) && (OUTLET_ELEC_METERING == 1)
    uint8_t *p_sub_buf = (uint8_t *)vesync_malloc(SWITCH_KLV_DATE_LEN);
    if (NULL == p_sub_buf)
    {
        vesync_free(p_buf);
        return APP_FAIL;
    }
    vesync_klv_get(p_buf, len, SWITCH_KEY_SAVE_ELEC_MODE, SWITCH_KLV_DATE_LEN, p_sub_buf);
    vesync_klv_get(p_sub_buf, SWITCH_KLV_DATE_LEN, SAVE_ELEC_ENABLE, sizeof(p_data->save_elec.enable), &p_data->save_elec.enable);
    vesync_klv_get(p_sub_buf, SWITCH_KLV_DATE_LEN, SAVE_ELEC_MAX_ELEC, sizeof(p_data->save_elec.max_elec), (uint8_t *)&p_data->save_elec.max_elec);

    vesync_klv_get(p_buf, len, SWITCH_KEY_POW_TRIG_MODE, SWITCH_KLV_DATE_LEN, p_sub_buf);
    vesync_klv_get(p_sub_buf, SWITCH_KLV_DATE_LEN, POW_TRIG_ENABLE, sizeof(p_data->pow_trig.enable), &p_data->pow_trig.enable);
    vesync_klv_get(p_sub_buf, SWITCH_KLV_DATE_LEN, POW_TRIG_TYPE, sizeof(p_data->pow_trig.type), &p_data->pow_trig.type);
    vesync_klv_get(p_sub_buf, SWITCH_KLV_DATE_LEN, POW_TRIG_POWER, sizeof(p_data->pow_trig.power), (uint8_t *)&p_data->pow_trig.power);

    vesync_free(p_sub_buf);
#endif

    vesync_free(p_buf);

    return APP_OK;
}

/**
 * @brief 获取开关的配置
 * @param[in]  SWITCH_CFG_FLAG_E    [标识符]
 * @return     const void*          [配置值指针]
 */
const void* switch_get_config(SWITCH_CFG_FLAG_E flag)
{
    switch(flag)
    {
    case SWITCH_CFG_ONOFF:
        return &s_sw_cfg.switch_onoff;
    case SWITCH_CFG_INIT_FLAG:
        return &s_sw_cfg.switch_init_flag;
#if defined(OUTLET_ELEC_METERING) && (OUTLET_ELEC_METERING == 1)
    case SWITCH_CFG_SAVE_ELEC_MODE:
        return &s_sw_cfg.save_elec;
    case SWITCH_CFG_POW_TRIG_MODE:
        return &s_sw_cfg.pow_trig;
#endif
    default:
        return NULL;
    }
}

/**
 * @brief 更新开关的配置
 * @param[in]  SWITCH_CFG_FLAG_E    [标识符]
 * @param[in]  uint8_t              [配置值]
 * @return     int                  [成功/失败]
 */
int switch_update_config(SWITCH_CFG_FLAG_E flag, const void* arg)
{
    VCOM_NULL_PARAM_CHK(arg, return APP_FAIL);
    switch(flag)
    {
    case SWITCH_CFG_ONOFF:
        s_sw_cfg.switch_onoff = *((const uint8_t*)arg);
        break;
    case SWITCH_CFG_INIT_FLAG:
        s_sw_cfg.switch_init_flag = *((const uint8_t*)arg);
        break;
#if defined(OUTLET_ELEC_METERING) && (OUTLET_ELEC_METERING == 1)
    case SWITCH_CFG_SAVE_ELEC_MODE:
        memcpy(&s_sw_cfg.save_elec, (const typeof(s_sw_cfg.save_elec)*)arg, sizeof(s_sw_cfg.save_elec));
        break;
    case SWITCH_CFG_POW_TRIG_MODE:
        memcpy(&s_sw_cfg.pow_trig, (const typeof(s_sw_cfg.pow_trig)*)arg, sizeof(s_sw_cfg.pow_trig));
        break;
#endif
    default:
        APP_LOG(LOG_ERROR, "Unknown flag(=%d).\n", flag);
        return APP_FAIL;
    }

    return switch_save_config(s_sw_cfg);
}

/**
 * @brief 从flash加载开关配置
 * @param[in]  SWITCH_ACT_SRC_E         [动作来源]
 * @return void
 */
void switch_load_config(OUTLET_ACT_SRC_E src)
{
    outlet_ev_t ev;

    // 初始化，默认状态继电器关闭，指示灯亮
    memset((uint8_t *)&s_sw_cfg, 0, sizeof(switch_flash_data_t));
    memset(&ev, 0, sizeof(ev));
    switch_flash_data_t sw_data;
    if (APP_OK == switch_read_switch_data(&sw_data))
    {
        sw_data.switch_init_flag = 1;
        s_sw_cfg = sw_data;
    }

    if (s_sw_cfg.switch_onoff)
    {
        ev.id = OUTLET_EV_ON;
        ev.act_src = src;
    }
    else
    {
        ev.id = OUTLET_EV_OFF;
        ev.act_src = src;
    }

#if defined(OUTLET_ELEC_METERING) && (OUTLET_ELEC_METERING == 1)
    metering_mgmt_conf_t *conf = vesync_malloc(sizeof(metering_mgmt_conf_t));
    double temp_elec = 0;
    float temp_max_power = OUTLET_METERING_MAX_POW;
    if (NULL == conf)
    {
        APP_LOG(LOG_ERROR, "set save elec mode fail\n");
        goto EXIT;
    }
    memset(conf, 0, sizeof(metering_mgmt_conf_t));
    if (s_sw_cfg.save_elec.enable)
    {
        temp_elec = s_sw_cfg.save_elec.max_elec * 1000; // 单位从KWH转换为WH
    }
    conf->max_electrictiy[OUTLET_SWITCH_USED_ELEC_UNIT] = &temp_elec;

    if (s_sw_cfg.pow_trig.enable)
    {
        if (0 == s_sw_cfg.pow_trig.type)
        {
            conf->min_power = &temp_max_power;
            conf->max_power = &s_sw_cfg.pow_trig.power;
        }
        else
        {
            conf->min_power = &s_sw_cfg.pow_trig.power;
            conf->max_power = &temp_max_power;
        }
    }
    else
    {
        conf->min_power = &temp_max_power;
        conf->max_power = &temp_max_power;
    }
    outlet_metering_set_mgmt(conf);
    vesync_free(conf);
EXIT:
#endif

    snprintf(ev.rsn, sizeof(ev.rsn), "%s", STAT_CHG_RSN_FLASH_STR);
    outlet_app_task_notify(&ev);
}
