/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        switch_timing.h
 * @brief       switch timing头文件
 * @author      Charles.Mei
 * @date        2021-08-04
 */


#include <stdint.h>

#include "vesync_timing.h"

#include "switch_app.h"


#ifndef __SWITCH_TIMING_H__
#define __SWITCH_TIMING_H__

#ifdef __cplusplus
    extern "C" {
#endif


/**
 * @brief light timer定时配置
 */
typedef struct
{
    uint16_t id;            // timer id，light最多一个timer
    light_action_t action;
} light_timing_t;

/**
 * @brief fan timer定时配置
 */
typedef struct
{
    uint16_t id;            // timer id，fan最多一个timer
    fan_action_t action;
} fan_timing_t;


/**
 * @brief 新增一个timer
 * @param[in]   dev_id                  [设备id]
 * @param[in]   action                  [timer执行动作]
 * @param[in]   total_sec               [timer定时时间]
 * @param[out]  p_id                    [timer id]
 * @return      int_t                   [成功/失败]
 */
int switch_timing_add(DEVICE_ID_E dev_id, void* action, uint32_t total_sec, uint16_t *p_id);

/**
 * @brief 获取timer执行的动作
 * @param[out] dev_id                   [设备id]
 * @param[in]  action                   [timer执行的动作]
 * @return     int_t                    [成功/失败]
 */
int switch_timing_get_act(DEVICE_ID_E dev_id, const void **action);

/**
 * @brief 删除一个timer
 * @param[in]  uint16_t                 [timer id]
 * @return     int_t                    [成功/失败]
 */
int switch_timing_remove(uint16_t timer_id);

/**
 * @brief 清空timer
 * @param void
 */
int switch_timing_clear(void);

/**
 * @brief 初始化timer
 * @param void
 */
void switch_timing_init(void);


#ifdef __cplusplus
}
#endif

#endif

