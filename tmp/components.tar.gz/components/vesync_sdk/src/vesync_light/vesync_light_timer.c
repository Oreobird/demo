/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file    vesync_light_timer.c
* @brief   灯光照明控制模块定时器接口的实现
* @author  Herve
* @date    2021-11-09
*/
#include <stddef.h>

#include "vesync_common.h"
#include "vesync_memory.h"
#include "vesync_task.h"
#include "vesync_queue.h"

#include "vesync_loop_timer_internal.h"
#include "vesync_log_internal.h"

#include "vesync_light_timer.h"
#include "vesync_light_internal.h"

// 定时器任务信号枚举
enum
{
    LIGHT_TASK_SIG_STOP = 0,
    LIGHT_TASK_SIG_ADD,
    LIGHT_TASK_SIG_DEL,
};

// Loop Timer实例
static vloop_timer_header_t *s_timer_header = {0};
// 定时器任务同步信号量
static vesync_queue_t *s_task_signal = NULL;
// 定时器任务启动标志
static bool s_is_task_start = false;

#define TIMER_POLLING(t) vloop_timer_process_expired(t)
#define TIMER_INIT() (vloop_timer_header_t *)vesync_calloc(1, sizeof(vloop_timer_header_t))
#define TIMER_NEW() (vloop_timer_t *)vesync_calloc(1, sizeof(vloop_timer_t))

// 定时器任务的系统优先级
#define LIGHT_TIMER_TASK_PRIO (TASK_PRIORITY_HIGH)
// 定时器任务的栈大小定义
#define LIGHT_TIMER_TASK_STACKSIZE (1024 * 2)

/**
 * @brief 定时器任务入口函数，主要进行Loop Timer的调度
 */
static void light_timer_task_entry(void *arg)
{
    while (1)
    {
        int sig = -1;
        int ret = vesync_queue_recv(s_task_signal,
                                    &sig,
                                    TIMER_POLLING(s_timer_header));
        if (VOS_OK != ret)
        {
            continue;
        }
        switch (sig)
        {
        case LIGHT_TASK_SIG_STOP:
            // 接收到中止任务的信号，结束任务循环
            SDK_LOG(LOG_INFO, "light timer task abort\n");
            return;
        case LIGHT_TASK_SIG_ADD:
#if 0
            SDK_LOG(LOG_DEBUG, "light timer add\n");
#endif
            break;
        case LIGHT_TASK_SIG_DEL:
#if 0
            SDK_LOG(LOG_DEBUG, "light timer delete\n");
#endif
            break;
        default:
            break;
        }
    }
}

/**
 * @brief 定时器任务的退出函数
 */
static void light_timer_task_exit(void)
{
    VCOM_SAFE_FREE(s_timer_header);
    vesync_queue_free(s_task_signal);
    s_is_task_start = false;
}

int light_timer_task_start(void)
{
    LIGHT_CHECK(false == s_is_task_start, LIGHT_ERR);

    s_timer_header = TIMER_INIT();
    PTR_ASSERT_EXIT(s_timer_header, EXIT);
    s_task_signal = vesync_queue_new(1 * sizeof(int), sizeof(int));
    PTR_ASSERT_EXIT(s_task_signal, EXIT);

    if (VOS_OK != vesync_task_new("light_timer_task",
                                  light_timer_task_exit,
                                  light_timer_task_entry,
                                  NULL,
                                  LIGHT_TIMER_TASK_STACKSIZE,
                                  LIGHT_TIMER_TASK_PRIO,
                                  NULL))
    {
        SDK_LOG(LOG_ERROR, "create task fail\n");
        goto EXIT;
    }

    s_is_task_start = true;
    return LIGHT_OK;

EXIT:
    VCOM_SAFE_FREE(s_timer_header);
    vesync_queue_free(s_task_signal);
    s_task_signal = NULL;
    return LIGHT_ERR;
}

int light_timer_task_stop(void)
{
    LIGHT_CHECK(true == s_is_task_start, LIGHT_ERR);

    const int sig = LIGHT_TASK_SIG_STOP;
    int ret = vesync_queue_send(s_task_signal,
                                (void *)&sig,
                                VESYNC_OS_NO_WAIT);
    if (VOS_OK != ret)
    {
        SDK_LOG(LOG_ERROR, "queue send fail\n");
        return LIGHT_ERR;
    }
    return LIGHT_OK;
}

void *light_timer_new(bool reload, uint32_t intvl, light_timer_cb_t cb, void *arg)
{
    if (intvl < 1)
    {
        return NULL;
    }

    vloop_timer_t *p_timer = TIMER_NEW();
    if (NULL == p_timer)
    {
        return NULL;
    }

    p_timer->reload = reload;
    p_timer->period = (uint64_t)intvl;
    p_timer->cb = cb;
    p_timer->arg = arg;
    return (void *)p_timer;
}

int light_timer_del(void *p_timer)
{
    vesync_free(p_timer);
    return LIGHT_OK;
}

int light_timer_start(void *p_timer)
{
    if (true != vloop_timer_add(s_timer_header, p_timer))
    {
        return LIGHT_ERR;
    }

    const int sig = LIGHT_TASK_SIG_ADD;
    int ret = vesync_queue_send(s_task_signal,
                                (void *)&sig,
                                VESYNC_OS_NO_WAIT);
    if (VOS_OK != ret)
    {
        SDK_LOG(LOG_ERROR, "queue send fail\n");
        return LIGHT_ERR;
    }

    return LIGHT_OK;
}

int light_timer_stop(void *p_timer)
{
    if (true != vloop_timer_del(s_timer_header, p_timer))
    {
        return LIGHT_ERR;
    }

    const int sig = LIGHT_TASK_SIG_DEL;
    int ret = vesync_queue_send(s_task_signal,
                                (void *)&sig,
                                VESYNC_OS_NO_WAIT);
    if (VOS_OK != ret)
    {
        SDK_LOG(LOG_ERROR, "queue send fail\n");
        return LIGHT_ERR;
    }

    return LIGHT_OK;
}
