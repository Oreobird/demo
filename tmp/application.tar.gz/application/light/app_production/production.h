/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
* @file         production.h
* @brief        产测业务逻辑接口
* @author       Joshua
* @date         2021-11-18
*/

#ifndef __PRODUCTION_H__
#define __PRODUCTION_H__

#ifdef __cplusplus
extern "C" {
#endif

/**
* @brief 应用产测初始化
*/
void app_production_init(void);

#ifdef __cplusplus
}
#endif

#endif


