/**
 * Copyright © Vesync Technologies Co.Ltd. 2019-2021. All rights reserved.
 * @file    hal_ota.c
 * @brief   esp32/esp8266的ota功能实现
 * @author  Dongri + Owen（@8266）
 * @date    2019-09-10
 */

//#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include "mbedtls/md5.h"

#include "vesync_log.h"
#include "vesync_common.h"


#include "vhal_ota_internal.h"
#include "vhal_wifi.h"


/*-----------------------------------------------------------------------------*
 *                           内部函数API实现                                         *
 *-----------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------*
 *                           外部函数API实现                                         *
 *-----------------------------------------------------------------------------*/

/**
 * @brief  开始OTA升级
 * @param[in]  p_url            [固件下载URL]
 * @param[in]  dg_flag          [true表示进行降级；false表示进行升级]
 * @return     int              [成功返回0，其他值表示失败]
 */
int vhal_ota_start(char *p_url, bool dg_flag)
{
    int ret = VHAL_OK;

    return ret;
}


/**
 * @brief  注册ota升级状态数据回调
 * @param[in]  cb               [ota升级状态回调函数]
 * @return     void
 */
void vhal_ota_status_reg_cb(vhal_ota_status_cb_t cb)
{
}

/**
 * @brief 注册ota升级头部校验回调
 * @param[in]  cb               [ota头部校验回调函数]
 * @return     void
 */
void vhal_ota_check_header_reg_cb(vhal_ota_check_header_cb_t cb, int32_t head_len)
{
}

/**
 * @brief 注册ota升级md5校验回调
 * @param[in]  cb               [ota头部校验回调函数]
 * @return     void
 */
void vhal_ota_check_md5_reg_cb(vhal_ota_check_md5_cb_t cb)
{
}

/*
 * @brief  设置OTA超时标志位
 * @param[in]  flag             [true表示升级超时，false表示未超时]
 * @return     void
 */
void vhal_ota_set_timeout_flag(bool flag)
{
}

/**
 * @brief  保存文件到flash
 * @param[in]  offset           [偏移地址]
 * @param[in]  p_data           [待保存的数据]
 * @param[in]  data_len         [待保存数据的长度]
 * @return     int              [成功返回0，其他值表示失败]
 * @note   用于存放非自身固件的其他大文件
 */
int vhal_ota_save_bin_file(int offset, char *p_data, int data_len)
{
    if (NULL == p_data)
        return VHAL_FAIL;


    return VHAL_OK;
}

/**
 * @brief 从flash中读出文件
 * @param[in]  offset           [偏移地址]
 * @param[in]  p_data           [待保存的数据]
 * @param[in]  data_len         [待保存数据的长度]
 * @return     int              [成功返回0，其他值表示失败]
 * @note   用于存放非自身固件的其他大文件
 */
int vhal_ota_read_bin_file(int offset ,char *p_data, int data_len)
{
    if (NULL == p_data)
        return VHAL_FAIL;

    return VHAL_OK;
}

