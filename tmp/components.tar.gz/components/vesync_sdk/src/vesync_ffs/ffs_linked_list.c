/**
 * Copyright © Etekcity Technologies Co., Ltd. 2021. All rights reserved.
 * @brief       Linked list data structure.
 * @file        ffs_linked_list.c
 * @author      Owen.zhang
 * @date        2020-04-22
 */

#include "ffs/common/ffs_check_result.h"
#include "ffs_linked_list.h"
#include "vesync_common.h"
#include "vesync_memory.h"

/**
 * @brief: Initialize a Ffs linked list.
 * @param[in] linkedList
 * @return FFS_RESULT
 */
FFS_RESULT ffsLinkedListInitialize(FfsLinkedList_t *linkedList)
{
    if (!linkedList)
    {
        ffsLogError("input params find NULL");
        FFS_FAIL(FFS_OVERRUN);
    }
    linkedList->count = 0;
    linkedList->head = NULL;
    linkedList->tail = NULL;

    return FFS_SUCCESS;
}

/**
 * @brief: Push data to the front of the Ffs linked list.
 * @param[in] FfsLinkedList_t*
 * @param[in] FfsLinkedListData_t *
 * @return FFS_RESULT
 */
FFS_RESULT ffsLinkedListPushFront(FfsLinkedList_t *linkedList, FfsLinkedListData_t *data)
{
    if (!linkedList || !data)
    {
        ffsLogError("input params find NULL");
        FFS_FAIL(FFS_OVERRUN);
    }
    FfsLinkedListNode_t *node = (FfsLinkedListNode_t *)vesync_malloc(sizeof(FfsLinkedListNode_t));
    if (!node)
    {
        FFS_FAIL(FFS_OVERRUN);
    }

    node->data = data;
    node->previous = NULL;
    node->next = linkedList->head;

    if (ffsLinkedListIsEmpty(linkedList))
    {
        linkedList->tail = node;
    }
    else
    {
        linkedList->head->previous = node;
    }

    linkedList->head = node;
    linkedList->count++;

    return FFS_SUCCESS;
}

/**
 * @brief: Push data to the back of the Ffs linked list.
 * @param[in] FfsLinkedList_t*
 * @param[in] FfsLinkedListData_t *
 * @return FFS_RESULT
 */
FFS_RESULT ffsLinkedListPushBack(FfsLinkedList_t *linkedList, FfsLinkedListData_t *data)
{
    if (!linkedList)
    {
        ffsLogError("input params find NULL");
        FFS_FAIL(FFS_OVERRUN);
    }
    FfsLinkedListNode_t *node = (FfsLinkedListNode_t *)vesync_malloc(sizeof(FfsLinkedListNode_t));
    if (!node)
    {
        FFS_FAIL(FFS_OVERRUN);
    }

    node->data = data;
    node->previous = linkedList->tail;
    node->next = NULL;

    if (ffsLinkedListIsEmpty(linkedList))
    {
        linkedList->head = node;
    }
    else
    {
        linkedList->tail->next = node;
    }

    linkedList->tail = node;
    linkedList->count++;

    return FFS_SUCCESS;
}

/**
 * @brief: Removes and retrieves an element from the front of the Ffs linked list.
 * @param[in] FfsLinkedList_t*
 * @param[out] FfsLinkedListData_t **
 * @return FFS_RESULT
 */
FFS_RESULT ffsLinkedListPopFront(FfsLinkedList_t *linkedList, FfsLinkedListData_t **data)
{
    if (!linkedList)
    {
        ffsLogError("input params find NULL");
        FFS_FAIL(FFS_OVERRUN);
    }
    FFS_CHECK_RESULT(ffsLinkedListPeekFront(linkedList, data));

    FfsLinkedListNode_t *newHead = linkedList->head->next;

    VCOM_SAFE_FREE(linkedList->head);
    linkedList->head = newHead;
    linkedList->count--;

    if (newHead == NULL)
    {
        linkedList->tail = NULL;
    }
    else
    {
        newHead->previous = NULL;
    }

    return FFS_SUCCESS;
}

/**
 * @brief: Removes and retrieves an element from the back of the Ffs linked list.
 * @param[in] FfsLinkedList_t*
 * @param[out] FfsLinkedListData_t **
 * @return FFS_RESULT
 */
FFS_RESULT ffsLinkedListPopBack(FfsLinkedList_t *linkedList, FfsLinkedListData_t **data)
{
    if (!linkedList)
    {
        ffsLogError("input params find NULL");
        FFS_FAIL(FFS_OVERRUN);
    }
    FFS_CHECK_RESULT(ffsLinkedListPeekBack(linkedList, data));

    FfsLinkedListNode_t *newTail = linkedList->tail->previous;

    VCOM_SAFE_FREE(linkedList->tail);
    linkedList->tail = newTail;
    linkedList->count--;

    if (newTail == NULL)
    {
        linkedList->head = NULL;
    }
    else
    {
        newTail->next = NULL;
    }

    return FFS_SUCCESS;
}

/**
 * @brief: Removes and retrieves the element at the given index in the Ffs linked list.
 * @param[in] FfsLinkedList_t*
 * @param[in] uint32_t
 * @param[out] FfsLinkedListData_t **
 * @return FFS_RESULT
 */
FFS_RESULT ffsLinkedListPopIndex(FfsLinkedList_t *linkedList, uint32_t index, FfsLinkedListData_t **data)
{
    if (!linkedList)
    {
        ffsLogError("input params find NULL");
        FFS_FAIL(FFS_OVERRUN);
    }
    if (index == 0)
    {
        FFS_CHECK_RESULT(ffsLinkedListPopFront(linkedList, data));
        return FFS_SUCCESS;
    }
    if (index == linkedList->count - 1)
    {
        FFS_CHECK_RESULT(ffsLinkedListPopBack(linkedList, data));
        return FFS_SUCCESS;
    }

    if (index >= linkedList->count)
    {
        FFS_FAIL(FFS_ERROR);
    }

    FfsLinkedListNode_t *node;
    node = linkedList->head;
    for (uint32_t i = 0; i < index; ++i)
    {
        node = node->next;
    }

    *data = node->data;

    node->previous->next = node->next;
    node->next->previous = node->previous;
    VCOM_SAFE_FREE(node);

    linkedList->count--;

    return FFS_SUCCESS;
}

/**
 * @brief: Retrieves an element at the front of the Ffs linked list without removing it.
 * @param[in] FfsLinkedList_t*
 * @param[out] FfsLinkedListData_t **
 * @return FFS_RESULT
 */
FFS_RESULT ffsLinkedListPeekFront(FfsLinkedList_t *linkedList, FfsLinkedListData_t **data)
{
    if (!linkedList)
    {
        ffsLogError("input params find NULL");
        FFS_FAIL(FFS_OVERRUN);
    }
    if (ffsLinkedListIsEmpty(linkedList))
    {
        FFS_FAIL(FFS_ERROR);
    }

    *data = linkedList->head->data;

    return FFS_SUCCESS;
}

/**
 * @brief: Retrieves an element at the back of the Ffs linked list without removing it.
 * @param[in] FfsLinkedList_t*
 * @param[out] FfsLinkedListData_t **
 * @return FFS_RESULT
 */
FFS_RESULT ffsLinkedListPeekBack(FfsLinkedList_t *linkedList, FfsLinkedListData_t **data)
{
    if (!linkedList)
    {
        ffsLogError("input params find NULL");
        FFS_FAIL(FFS_OVERRUN);
    }
    if (ffsLinkedListIsEmpty(linkedList))
    {
        FFS_FAIL(FFS_ERROR);
    }

    *data = linkedList->tail->data;

    return FFS_SUCCESS;
}

/**
 * @brief: Retrieves an element at the index in the Ffs linked list without removing it.
 * @param[in] FfsLinkedList_t*
 * @param[in] uint32_t
 * @param[out] FfsLinkedListData_t **
 * @return FFS_RESULT
 */
FFS_RESULT ffsLinkedListPeekIndex(FfsLinkedList_t *linkedList, uint32_t index, FfsLinkedListData_t **data)
{
    if (!linkedList)
    {
        ffsLogError("input params find NULL");
        FFS_FAIL(FFS_OVERRUN);
    }
    FfsLinkedListNode_t *node;

    if (index >= linkedList->count)
    {
        FFS_FAIL(FFS_ERROR);
    }

    node = linkedList->head;
    for (uint32_t i = 0; i < index; ++i)
    {
        node = node->next;
    }

    *data = node->data;

    return FFS_SUCCESS;
}

/**
 * @brief: Insert an element following the element at the index.
 * @param[in] FfsLinkedList_t*
 * @param[in] uint32_t
 * @param[in] FfsLinkedListData_t *
 * @return FFS_RESULT
 */
FFS_RESULT ffsLinkedListInsertIndex(FfsLinkedList_t *linkedList, uint32_t index,
                                    FfsLinkedListData_t *data)
{
    if (!linkedList)
    {
        ffsLogError("input params find NULL");
        FFS_FAIL(FFS_OVERRUN);
    }
    if (index > linkedList->count)
    {
        FFS_FAIL(FFS_ERROR);
    }

    if (index == 0)
    {
        FFS_CHECK_RESULT(ffsLinkedListPushFront(linkedList, data));
        return FFS_SUCCESS;
    }

    if (index == linkedList->count)
    {
        FFS_CHECK_RESULT(ffsLinkedListPushBack(linkedList, data));
        return FFS_SUCCESS;
    }

    FfsLinkedListNode_t *previousNode;
    previousNode = linkedList->head;
    for (uint32_t i = 0; i < index - 1; ++i)
    {
        previousNode = previousNode->next;
    }

    FfsLinkedListNode_t *node = (FfsLinkedListNode_t *)vesync_malloc(sizeof(FfsLinkedListNode_t));
    if (!node)
    {
        FFS_FAIL(FFS_OVERRUN);
    }

    node->data = data;
    node->previous = previousNode;
    node->next = previousNode->next;
    if (node->next)
    {
        node->next->previous = node;
    }
    else
    {
        linkedList->tail = node;
    }
    previousNode->next = node;

    linkedList->count++;

    return FFS_SUCCESS;
}

/**
 * @brief: Returns the number of elements in the Ffs linked list.
 * @param[in] FfsLinkedList_t*
 * @return size_t
 */
size_t ffsLinkedListGetCount(FfsLinkedList_t *linkedList)
{
    if (!linkedList)
    {
        return 0;
    }
    return linkedList->count;
}

/**
 * @brief: Checks if the Ffs linked list is empty.
 * @param[in] FfsLinkedList_t*
 * @return bool
 */
bool ffsLinkedListIsEmpty(FfsLinkedList_t *linkedList)
{
    if (!linkedList)
    {
        return true;
    }
    return ffsLinkedListGetCount(linkedList) == 0;
}
