/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        ledstrip_button.c
 * @brief       ledstrip button文件
 * @author      Lind
 * @date        2021-08-25
 */

#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <stdio.h>

#include "vhal_gpio.h"

#include "vesync_common.h"
#include "vesync_log.h"
#include "vesync_task.h"
#include "vesync_device.h"
#include "led_strip.h"
#include "led_strip_button.h"

// 短按次数
//static uint8_t s_short_pressed_cnt = 1;
static bool s_task_run = false;     // 按键扫描任务运行标志
static key_status_t s_switch_key;   // 开关按键参数


/**
 * @brief 设置扫描到的瞬时按键值
 * @param[in]   scan_value      [瞬时按键值]
 */
static void button_key_set_scan_value(int8_t scan_value)
{
    uint64_t new_scan_ts = vesync_task_get_tick_ms();

    if (KEY_SCAN_VALUE_MAX_NUM == ++(s_switch_key.key_scan_value_index))
    {
        (s_switch_key.key_scan_value_index) = 0;
    }
    if (scan_value == s_switch_key.key_scan_value[s_switch_key.key_scan_value_index])
    {
        if (1 == scan_value)    // 高电平
        {
            s_switch_key.key_scan_value[(s_switch_key.key_scan_value_index)] = 0;
            --(s_switch_key.key_pressed_num);
            if(KEY_RELEASED_THRESHOLD == (s_switch_key.key_pressed_num))
            {
                s_switch_key.key_status = KEY_RELEASED_1S_LESS;
                s_switch_key.key_upturn_ts = new_scan_ts;
                return;
            }
        }
        else                    // 低电平
        {
            s_switch_key.key_scan_value[(s_switch_key.key_scan_value_index)] = 1;
            ++(s_switch_key.key_pressed_num);
            if(KEY_PRESSED_THRESHOLD == (s_switch_key.key_pressed_num))
            {
                s_switch_key.key_status = KEY_PRESSED_1S_LESS;
                s_switch_key.key_upturn_ts = new_scan_ts;
                return;
            }
        }
    }

    switch (s_switch_key.key_status)
    {
        case KEY_RELEASED_1S_LESS:
            if (new_scan_ts - s_switch_key.key_upturn_ts > 1000)  // 松开按键超过1s
            {
                s_switch_key.key_status = KEY_RELEASED_1S_MORE;
            }
            else if (new_scan_ts - s_switch_key.key_upturn_ts > 100) // 松开按键超过100ms
            {
                s_switch_key.key_status = KEY_RELEASED_100MS;
            }
            break;
        case KEY_PRESSED_1S_LESS:
        case KEY_PRESSED_1S_TO_5S:
        case KEY_PRESSED_5S_TO_15S:
            if (new_scan_ts - s_switch_key.key_upturn_ts > 15000)  // 按下按键超过15s
            {
                s_switch_key.key_status = KEY_PRESSED_15S_MORE;
            }
            else if (new_scan_ts - s_switch_key.key_upturn_ts > 5000)  // 按下按键超过5s
            {
                s_switch_key.key_status = KEY_PRESSED_5S_TO_15S;
            }
            else if (new_scan_ts - s_switch_key.key_upturn_ts > 1000)  // 按下按键超过1s
            {
                s_switch_key.key_status = KEY_PRESSED_1S_TO_5S;
            }
            break;
        case KEY_RELEASED_1S_MORE:
        case KEY_PRESSED_15S_MORE:
        default:
            break;
    }
}

/**
 * @brief 按键扫描任务
 */
static void ls_button_task(void *args)
{
    KEY_STATE_E last_key_status;
    ls_ev_t ev;
    uint64_t btn_ts[5];
    uint8_t button_cnt = 0;
    uint8_t ev_cnt = 0;
    uint64_t new_ts;
    uint64_t old_ts;
    uint64_t last_ts;
    uint64_t start_ts = vesync_task_get_tick_ms();
    ev.act_src = LS_ACT_SRC_BTN;
    s_task_run = true;
    last_ts = start_ts;
    old_ts =  last_ts - 1000;

    while (s_task_run)
    {
        last_key_status = s_switch_key.key_status;
        s_switch_key.key_set_scan_value(vhal_gpio_get_output(LEDSTRIP_BUTTON_GPIO_NUM));
        if (last_key_status != s_switch_key.key_status)
        {
            switch (s_switch_key.key_status)
            {
                case KEY_RELEASED_1S_MORE:
                    break;
                case KEY_RELEASED_100MS:
                    if(ev_cnt == 0)      // 模式循环
                    {
                        ev.event = LS_EV_CHANGE_SCENE;
                        button_cnt = 0;
                        led_strip_app_task_notify(&ev);
                        APP_LOG(LOG_DEBUG, "change scene !!!\r\n");
                    }
                    else
                    {
                        ev_cnt = 0;
                    }
                    break;
                case KEY_PRESSED_5S_TO_15S: // 开始配网等待灯效
                    ev.event = LS_EV_BEFORE_NETCFG;
                    led_strip_app_task_notify(&ev);
                    ev_cnt = 1;
                    APP_LOG(LOG_DEBUG, "start netcfg scene!!!\r\n");

                    break;
                case KEY_PRESSED_15S_MORE:     // 复位重置
                    ev.event = LS_EV_RESET;
                    led_strip_app_task_notify(&ev);
                    ev_cnt = 1;
                    APP_LOG(LOG_DEBUG, "Reset device !!!\r\n");

                    break;
                case KEY_RELEASED_1S_LESS:
                    switch (last_key_status)
                    {
                        case KEY_PRESSED_1S_LESS:    // 短按切换模式
                            new_ts = vesync_task_get_tick_ms();
                            if (((new_ts - last_ts) < 300)&&((last_ts - old_ts) > 300))
                            {
                                ev.event = LS_EV_STATUS_OFF;
                                led_strip_app_task_notify(&ev);
                                ev_cnt = 1;
                                APP_LOG(LOG_DEBUG, "turn off !!!\r\n");
                            }
                            old_ts = last_ts;
                            last_ts = new_ts;

                            if ((new_ts - start_ts) < 10000)
                            {
                                // 上电10s内 可以触发产测模式，要2s内按5次按键
                                btn_ts[button_cnt % 5] = new_ts;
                                button_cnt++;
                                if (button_cnt >= 5 && (new_ts - btn_ts[(button_cnt - 5) % 5]) < 2000)
                                {
                                    ev.event = LS_EV_PRODUCTION;
                                    button_cnt = 0;
                                    ev_cnt = 1;
                                    led_strip_app_task_notify(&ev);
                                    APP_LOG(LOG_DEBUG, "start production !!!\r\n");
                                }
                            }
                            break;
                        case KEY_PRESSED_5S_TO_15S:  // 启动配网事件
                            APP_LOG(LOG_DEBUG, "start netcfg !!\r\n");
                            ev.event = LS_EV_NETCFG;
                            led_strip_app_task_notify(&ev);
                            ev_cnt = 1;
                            break;
                        case KEY_PRESSED_1S_TO_5S:
                        case KEY_PRESSED_15S_MORE:
                        default:
                            break;
                    }
                case KEY_PRESSED_1S_LESS:
                case KEY_PRESSED_1S_TO_5S:
                default:
                    //APP_LOG(LOG_DEBUG, "button KEY_PRESSED_1S_TO_5S!!!\r\n");
                    break;
            }
        }

        vesync_sleep(10);        // 按键扫描10ms一次
    }
}

/**
 * @brief 产测时，强制退出按键扫描任务
 */
void led_strip_button_task_exit(void)
{
    APP_LOG(LOG_DEBUG, "button disable \n");
    s_task_run = false;
}



/**
 * @brief ledstrip button初始化
 */
void ls_button_init(void)
{
    // 初始化触摸按键信号接入GPIO
    vhal_gpio_config_t button_io;
    button_io.pin_bit_mask = (1ULL << LEDSTRIP_BUTTON_GPIO_NUM);
    button_io.mode = GPIO_MODE_IN;
    button_io.pull_up_en = GPIO_PULLUP_EN;
    button_io.pull_down_en = GPIO_PULLDOWN_DIS;
    button_io.intr_type = GPIO_INTR_DIS;
    vhal_gpio_init(button_io);

    memset(&s_switch_key, 0, sizeof(s_switch_key));
    s_switch_key.key_set_scan_value = button_key_set_scan_value;
    if (VOS_OK != vesync_task_new(LEDSTRIP_BUTTON_TASK_NAME, NULL,
                    ls_button_task,
                    NULL,
                    LEDSTRIP_BUTTON_TASK_STACKSIZE,
                    LEDSTRIP_BUTTON_TASK_PRIO, NULL))
    {
        APP_LOG(LOG_ERROR, "button task create fail!!!\r\n");
    }
}

