/**
 * Copyright © Vesync Technologies Co.Ltd. 2019-2021. All rights reserved.
 * @file    vesync_ffs.c
 * @brief   vesync平台与ffs SDK通信接口
 * @author  Dongri.Su
 * @date    20120-02-28
 */

#ifndef _VESYNC_FFS_H_
#define _VESYNC_FFS_H_

// 头文件
#include <string.h>
#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>

// 宏定义
#define MAX_FFS_CFG_NET_TIME_MS                 (120*1000)      // FFS配网定时最大时间
#define MAX_FFS_WAIT_CLOUD_NOTIFY_MS            (60*1000)       // 等待云绑定用户的最大时间

/*
 * @brief FFS配网状态
 */
typedef enum
{
	VESYNC_FFS_INIT         = 0,         // 初始化状态
	VESYNC_FFS_RUNNING      = 1,         // 正在进行中
	VESYNC_FFS_SUCC         = 2,         // 成功
	VESYNC_FFS_FAIL         = 3,         // 失败
}VESYNC_FFS_STATE_E;


/*
 * @brief FFS成功后保存的数据，用于vesync云与Amazon云通信
 */
typedef struct {
    char *signature;
    char *sessionToken;
    //char *ssid;
    //char *pwd;
    char *alexaEvtGwEp;
} FfsResultString_t;

/**
 * @brief   进入FFS配网模式，并进行MQTT连接、订阅
 * @param   void
 */
int vesync_ffs_start_cfgnet(void);

/**
 * @brief   设置sessionToken
 * @param   char* session   sessionToken
 * @param   uint8_t len     长度
 * @return  void
 */
//void vesync_ffs_set_session_token(char* session, uint8_t len);

/**
 * @brief  给配网任务发消息
 * @param[in]  ulValue      [通知消息，取相应位设置1]
 * @param[in]  p_msg        [给任务通过queue传递的消息内容指针，若无设为NULL]
 * @return     void         [无]
 */
void vesync_ffs_task_notify_withmsg(uint32_t ulValue, void* p_msg);

/**
 * @brief   取消FFS配网
 * @param[in]   manual_cancel               [true为手动取消；false为超时取消]
 * @return      void                        [none]
 */
void vesync_ffs_cancel(bool manual_cancel);

/**
 * @brief   清除ffs配网结果，使设备可以重复进入ffs
 */
void vesync_ffs_result_clean(void);

/**
 * @brief   [结束FFS配网并关闭配网进程, 此接口开放给应用层调用]
 * @param   bool true:手动设置停止； false: 自动判断；
 * @return  int    PLAT_OK    停止配网成功
 *                PLAT_FAIL  停止配网失败，但也可能配网进程修改状态延时，可再尝试调用。
 */
int vesync_ffs_stop(bool manual_stop);


/**
 * @brief  检查ffs配网功能是否有效, 配网成功后即失效
 * @return  int  PLAT_OK FFS配网功能有效, PLAT_FAIL FFS配网功能失效
 */
int vesync_ffs_is_active(void);

/**
 * @brief  ffs配网功能失能
 * @return  int  PLAT_OK 成功, PLAT_FAIL 失败
 */
int vesync_ffs_disable(void);

#endif
