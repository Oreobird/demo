/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_report.h
 * @brief       report模块接口定义
 * @date        2021-05-18
 */

#ifndef __VESYNC_REPORT_H__
#define __VESYNC_REPORT_H__

#include <stdint.h>
#include "cJSON.h"
#include "vesync_cfg.h"
#include "vesync_net_service.h"

#ifdef __cplusplus
extern "C" {
#endif


/**
 * @brief  设备上报原因
 */
typedef enum
{
    CAUSE_NULL      = 0,    // 未知(非法制)
    CAUSE_CONNECT,          //连接上报
    CAUSE_TIME,             //定时上报
    CAUSE_CHANGE,           //改变上报
    CAUSE_QUERY,            //设备主动查询
    CAUSE_LOG               //日志上报
} REPORT_CAUSE_E;


/**
 * @brief  vesync report初始化
 */
void vesync_report_init(void);


/**
 * @brief  设备上报云基础接口
 * @param[in]  topic_type              [topic类型]
 * @param[in]  method                  [方法字段]
 * @param[in]  json_data               [json 格式的数据，填充到data对象]
 * @param[in]  cause                   [上报原因]
 * @return  int                        [成功：SDK_OK，失败：SDK_FAIL]
 */
int vesync_report_cloud(NET_DATA_TOPIC_TYPE_E topic_type, const char *method, cJSON *json_data, REPORT_CAUSE_E cause);


/**
 * @brief  设备上报云基础接口
 * @param[in]  topic_type              [topic类型]
 * @param[in]  method                  [方法字段]
 * @param[in]  json_data               [json 格式的数据，填充到data对象]
 * @param[in]  cause                   [上报原因]
 * @param[in]  qos                     [qos level]
 * @param[in]  puback_cb               [收到qos1 ack后的回调]
 * @return  int                        [成功：SDK_OK，失败：SDK_FAIL]
 */
int vesync_report_cloud_qos(NET_DATA_TOPIC_TYPE_E topic_type, const char *method, cJSON *json_data,
                                  REPORT_CAUSE_E cause, SEND_QOS_E qos, void* puback_cb);

/**
 * @brief 设备状态变化上报
 * @param[in]  json_data               [json 格式的数据，填充到data对象]
 * @return  int                        [成功：SDK_OK，失败：SDK_FAIL]
*/
int vesync_report_status_change_nty(cJSON *json_data);


/**
 * @brief 更新设备在云端的属性
 * @return  int                        [成功：SDK_OK，失败：SDK_FAIL]
 */
int vesync_report_update_dev_info(void);


/**
 * @brief 设备上报运行日志
 * @param[in]  json_data               [json 格式的数据，填充到data对象]
 * @return  int                        [成功：SDK_OK，失败：SDK_FAIL]
 */
int vesync_report_device_log(cJSON *json_data);


/**
 * @brief 上报数据埋点到云端
 * @param[in]  json_event_array_data   [上报数据内容]
 * @param[in]  control_type            [控制类型]
 * @return  int                        [成功：SDK_OK，失败：SDK_FAIL]
 */
int vesync_report_analysis_data(cJSON *json_event_array_data, const char* control_type);


/**
 * @brief 获取用户时基信息
 * @param[in] type                     [指定需要获取的时基类型]
 * @return  int                        [成功：SDK_OK，失败：SDK_FAIL]
 */
int vesync_report_get_user_timebase_info(int type);


/**
 * @brief 发起同步服务器时间戳的请求
 * @return  int                        [成功：SDK_OK，失败：SDK_FAIL]
 */
int vesync_report_sync_server_timestamp(void);


#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_REPORT_H__ */


