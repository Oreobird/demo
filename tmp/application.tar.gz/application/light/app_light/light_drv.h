/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
* @file         light_drv.h
* @brief        驱动控制接口
* @author       Joshua
* @date         2021-11-16
*/
#include <stdlib.h>
#include <stdint.h>
#include "vesync_common.h"

#include "light.h"

#ifndef __LIGHT_DRV_H__
#define __LIGHT_DRV_H__

#ifdef __cplusplus
extern "C" {
#endif

struct _light_drv_t;
typedef struct _light_drv_t light_drv_t;

typedef int (*setup_fn_t)(light_drv_t *thiz);
typedef int (*destroy_fn_t)(light_drv_t *thiz);
typedef void (*output_fn_t)(light_drv_t *thiz, uint16_t ch_num, uint32_t *p_ch_duty);

struct _light_drv_t
{
    setup_fn_t setup;
    output_fn_t output;
    destroy_fn_t destroy;
    char priv[0];
};

/**
 * @brief 驱动器销毁
 * @param[in] thiz         [驱动器对象指针]
 * @return int             [成功：APP_OK， 失败：APP_FAIL]
 */
static inline int light_drv_destroy(light_drv_t *thiz)
{
    VCOM_NULL_PARAM_CHK(thiz, return APP_FAIL);
    return (thiz->destroy) ? thiz->destroy(thiz) : APP_FAIL;
}

/**
 * @brief 驱动器配置
 * @param[in] thiz         [驱动器对象指针]
 * @return int             [成功：APP_OK， 失败：APP_FAIL]
 */
static inline int light_drv_setup(light_drv_t *thiz)
{
    VCOM_NULL_PARAM_CHK(thiz, return APP_FAIL);
    return (thiz->setup) ? thiz->setup(thiz) : APP_FAIL;
}


/**
 * @brief 驱动器输出
 * @param[in] opt            [驱动器对象指针]
 * @param[in] ch_num         [回调的通道号]
 * @param[in] p_ch_duty      [回调的个通道的PWM控制量]
 * @return int               [成功：APP_OK， 失败：APP_FAIL]
 */
static inline void light_drv_output(void *opt, uint16_t ch_num, uint32_t *p_ch_duty)
{
    VCOM_NULL_PARAM_CHK(opt, return);
    VCOM_NULL_PARAM_CHK(p_ch_duty, return);
    light_drv_t *thiz = (light_drv_t *)opt;
    if (thiz->output)
    {
        thiz->output(thiz, ch_num, p_ch_duty);
    }
}

/**
 * @brief 创建驱动器
 * @return light_drv_t *        [成功：light_drv_t指针， 失败：NULL]
 */
light_drv_t *light_rmt_drv_create(void);

/**
 * @brief 创建驱动器
 * @return light_drv_t *        [成功：light_drv_t指针， 失败：NULL]
 */
light_drv_t *light_i2c_drv_create(void);


/**
 * @brief 创建驱动器
 * @return light_drv_t *        [成功：light_drv_t指针， 失败：NULL]
 */
light_drv_t *light_pwm_drv_create(void);

#ifdef __cplusplus
}
#endif

#endif



