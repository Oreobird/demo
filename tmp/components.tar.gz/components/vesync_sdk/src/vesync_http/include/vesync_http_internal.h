/*
 * Copyright © Vesync Technologies Co.Ltd. 2019-2021. All rights reserved.
 * @file    vesync_http_internal.h
 * @brief   http提供给内部的接口
 * @author  CharlesMei
 * @date    2021-05-21
 */

#ifndef __VESYNC_HTTP_INTERNAL_H__
#define __VESYNC_HTTP_INTERNAL_H__


#include <stdint.h>
#include <stdbool.h>


#ifdef __cplusplus
extern "C"
{
#endif /* __cplusplus */


/*
 * @brief http请求的方法
 */
typedef enum
{
    HTTP_METHOD_GET        = 0,
    HTTP_METHOD_POST       = 1
} HTTP_METHOD_TYPE_E;

/*
 * @brief http请求模式
 */
typedef enum
{
    HTTP_GET_NORMAL        = 0,
    HTTP_GET_OTA           ,
    HTTP_GET_CLI_CA        ,
    HTTP_GET_PRIVATE_KEY   ,
    HTTP_GET_MAX
} HTTP_GET_MODE_E;

typedef struct {
    char        *url;       /* 完整的URL，如果为空，host必须设置 */
    char        *host;      /* 服务器地址，如果为空，url必须设置 */
    char        *path;      /* 文件路径，优先使用url中的文件路径，其次使用此文件路径，如果都为空，则默认为‘/’ */
    bool        keep_alive; /* 是否使能长连接，true使能，false关闭；默认使能 */
    uint16_t    port;       /* 端口号，优先使用url中的端口号，其次使用此端口号，如果都为空则使用默认端口号HTTP_DEFAULT_PORT */
    uint16_t    timeout_ms; /* 网络超时时间，单位ms */
} vesync_http_client_config_t;

/**
 * @brief         http客户端初始化
 * @param[in]     config        [初始化配置，详见vesync_http_client_config_t]
 * @return        int           [成功或失败]
 */
int vesync_http_client_init(vesync_http_client_config_t *config);

/**
 * @brief         http request
 * @param[in]     method        [请求的方法]
 * @param[in]     send_buf      [请求的数据内容]
 * @param[out]    recv_buf      [返回的数据内容缓存buffer]
 * @param[in/out] recv_len      [返回的数据内容长度指针，传入时为缓存buffer的长度，供内部判断buffer大小是否足够，足够时内部把返回的数据拷贝至buffer，并赋值该值为数据长度]
 * @param[in]     mode          [http工作模式，目前只支持ota模式，ota模式下http请求到的数据会写入对应分区；其它模式直接返回]
 * @return        int           [成功或失败]
 */
int vesync_http_request(HTTP_METHOD_TYPE_E method, char *send_buf, char *recv_buf, int *recv_len, HTTP_GET_MODE_E mode);


#ifdef __cplusplus
}
#endif /* __cplusplus */


#endif /* __VESYNC_HTTP_INTERNAL_H__ */

