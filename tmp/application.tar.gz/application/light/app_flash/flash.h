/**
* Copyright © Vesync Technologies Co.Ltd. 2022. All rights reserved
* @file         flash.h
* @brief        存储处理
* @author       Joshua
* @date         2022-1-7
*/

#include <stdint.h>
#include <stdbool.h>
#include "light.h"

#ifndef __APP_FLASH_H__
#define __APP_FLASH_H__

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief 配置数据key 定义
 */
typedef enum
{
    KEY_VERSION = 0,         // 版本
    KEY_ONOFF,               // 开关状态
    KEY_COLOR_MODE,          // 色彩模式
    KEY_BEAD_NUM,            // 灯珠数量
    KEY_SEG_NUM,             // 分段数
    KEY_SCENE_ID,            // 场景ID
    KEY_COLOR_PARAM,         // 彩色参数
    EXTRA_CFG_SLOT           // 其它配置
} CFG_KEY_E;


#if CONFIG_VESYNC_APP_LIGHT_BULB
#include "bulb_flash.h"
#elif CONFIG_VESYNC_APP_LIGHT_LEDSTRIP
#include "ledstrip_flash.h"
#endif

struct _flash_t;
typedef struct _flash_t flash_t;
struct _flash_cfg_t;
typedef struct _flash_cfg_t flash_cfg_t;

/**
 * @brief flash写入buf长度计算
 * @param[in] *thiz               [flash_t*结构体指针]
 * @return  uint32_t              [buf长度]
 */
typedef uint32_t (*buf_len_cal_fn_t)(flash_t *thiz);

/**
 * @brief 额外配置设置回调
 * @param[in] *thiz               [flash_t*结构体指针]
 * @param[in] *p_buf              [klv写入buf]
 * @param[in] buf_len             [buf长度]
 * @param[in,out] *ofs            [klv写入offset]
 * @param[in] *extra_cfg          [额外配置]
 * @return  int                   [成功：APP_OK，失败：APP_FAIL]
 */
typedef int (*ext_cfg_set_fn_t)(flash_t *thiz, uint8_t *p_buf, uint32_t buf_len, uint32_t *ofs,  extra_cfg_t *extra_cfg);

/**
 * @brief 额外配置设置回调
 * @param[in] *thiz               [flash_t*结构体指针]
 * @param[in] *p_buf              [klv读buf]
 * @param[in] buf_len             [klv读长度]
 * @param[in] *extra_cfg          [额外配置]
 * @return  int                   [成功：APP_OK，失败：APP_FAIL]
 */
typedef int (*ext_cfg_get_fn_t)(flash_t *thiz, uint8_t *p_buf, uint32_t buf_len, extra_cfg_t *extra_cfg);

/**
 * @brief 配置重置回调
 * @param[in] *thiz               [flash_t*结构体指针]
 * @return  int                   [成功：APP_OK，失败：APP_FAIL]
 */
typedef int (*reset_fn_t)(flash_t *thiz);

/**
 * @brief 默认配置初始化回调
 * @param[in] *thiz               [flash_t*结构体指针]
 */
typedef void (*default_init_fn_t)(flash_t *thiz);


/**
 * @brief flash配置结构体
 */
struct _flash_cfg_t
{
    uint8_t onoff;               // 开关状态：0-关闭，1-开启
    uint8_t mode;                // 模式：0-白光，1-彩光，2-分段，3-音乐律动，4-场景
    uint16_t bead_num;           // 灯珠数量
    uint16_t seg_num;            // 分段数
    uint16_t scene_id;           // 当前场景ID
    light_param_t light_param;   // 灯光参数
    extra_cfg_t extra;           // 其它参数
};

/*
 * @brief flash对象结构体
 */
struct _flash_t
{
    buf_len_cal_fn_t len_cal;
    ext_cfg_set_fn_t ext_set;
    ext_cfg_get_fn_t ext_get;
    reset_fn_t reset;
    default_init_fn_t default_init;

    flash_cfg_t cfg; // 暴露数据给使用者
};


/**
 * @brief  设备保存flash配置
 * @param[in] *thiz         [flash_t*结构体指针]
 * @param[in]  *cfg         [设备信息]
 * @return     int          [成功：APP_OK， 失败：APP_FAIL]
 */
int app_flash_cfg_write(flash_t *thiz);

/**
 * @brief 设备读取flash配置
 * @param[in] *thiz         [flash_t*结构体指针]
 * @return     int          [成功：APP_OK， 失败：APP_FAIL]
 */
int app_flash_cfg_read(flash_t *thiz);

/**
 * @brief 清除flash配置
 * @param[in] *thiz         [flash_t*结构体指针]
 * @return int              [成功：APP_OK， 失败：APP_FAIL]
 */
int app_flash_cfg_reset(flash_t *thiz);

/**
 * @brief flash默认配置初始化
 * @param[in] *thiz         [flash_t*结构体指针]
 * @return int              [成功：APP_OK， 失败：APP_FAIL]
 */
int app_flash_cfg_default_init(flash_t * thiz);

/**
 * @brief 销毁flash对象
 * @param[in] *thiz         [flash_t*结构体指针]
 * @return int              [成功：APP_OK， 失败：APP_FAIL]
 */
int app_flash_destroy(flash_t *thiz);


/**
 * @brief 创建flash对象
 * @return flash_t *        [成功：flash实例指针， 失败：NULL]
 */
flash_t *app_flash_create(void);


#ifdef __cplusplus
}
#endif

#endif




