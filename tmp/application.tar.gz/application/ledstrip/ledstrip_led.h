/**
*Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file    ledstrip_led.h
* @brief   ledstrip灯珠控制
* @author  Lindzhou
*@date     2021-08-20
*/

#ifndef __LEDSTRIP_LED_H__
#define __LEDSTRIP_LED_H__

#include <stdbool.h>
#include <stdint.h>

#include "vhal_led.h"

#include "vesync_device.h"

#ifdef __cplusplus
extern "C" {
#endif


// LED 控制任务的参数
#define LS_LED_TASK_NAME       ("LED_task")
#define LS_LED_TASK_STACKSIZE  (1024 * 8)
#define LS_LED_TASK_PRIO       TASK_PRIORITY_HIGH


#define LS__LED_EVENT_QUEUE_MAX_NUM              (4)
#define LS_LED_NUM      (5)         // 配置的led数量
#define LS_BUTTON_MODE_NUM             (8)     // 按键模式总数，最后一个是off


#define LS_CW_CH        LED_CH0      // 冷光的led通道
#define LS_WW_CH        LED_CH1      // 暖光的led通道
#define LS_R_CH         LED_CH2      // 红光的led通道
#define LS_G_CH         LED_CH3      // 绿光的led通道
#define LS_B_CH         LED_CH4      // 蓝光的led通道

#define LS_CW_IO        (3)      // 冷光的led IO
#define LS_WW_IO        (6)      // 暖光的led IO
#define LS_R_IO         (10)      // 红光的led IO
#define LS_G_IO         (5)      // 绿光的led IO
#define LS_B_IO         (4)      // 蓝光的led IO


/*
 * @brief LedStrip 灯光模式
 */
typedef enum
{
    LS_MODE_WHITE = 0,
    LS_MODE_COLOR = 1,
    LS_MODE_SCENE,
    LS_MODE_OFF,
} LS_MODE_E;

/*
 * @brief LedStrip 情景模式下的灯效模式
 */
typedef enum
{
    LS_SCENE_SINGLE = 0,
    LS_SCENE_BREATHING,
    LS_SCENE_OVERLAP,
    LS_SCENE_SWITCH,
} LS_SCENE_MODE_E;

/*
 * @brief LedStrip 颜色种类
 */
typedef enum
{
    LS_LED_COLOR_CW = 0,   // cool white冷光
    LS_LED_COLOR_WW,       // warm white
    LS_LED_COLOR_R,
    LS_LED_COLOR_G,
    LS_LED_COLOR_B,
} LS_LED_COLOR_E;

/*
 * @brief LedStrip hsv颜色设置模式
 */
typedef enum
{
    LS_LED_SET_WHITE = 0,
    LS_LED_SET_COLOR,
    LS_LED_SET_ALL,
} LS_HSV_MODE_E;

/*
 * @brief LedStrip 渐变参数
 */
typedef enum
{
    LS_LED_GRADIENT_COLORTEMP = 0,
    LS_LED_GRADIENT_BRIGHTNESS,
    LS_LED_GRADIENT_H,
    LS_LED_GRADIENT_S,
    LS_LED_GRADIENT_V,
} LS_LED_GRADIENT_PARAM_E;

/*
 * @brief LedStrip RGB
 */
typedef enum
{
    LS_LED_R = 0,
    LS_LED_G,
    LS_LED_B,
} LS_LED_RGB_E;

/*
 * @brief LedStrip led控制事件id
 */
typedef enum
{
    LS_LED_EV_OFF = 0,
    LS_LED_EV_SET_LED,
    LS_LED_EV_UNKNOWN,
} LS_LED_EV_E;

/*
 * @brief LedStrip led控制事件来源
 */
typedef enum
{
    LS_LED_ACT_SRC_OUTSIDE = 0,         // led外控制来源：APP、第三方控制、schedule、timer
    LS_LED_ACT_SRC_WIFI,                // wifi灯效
    LS_LED_ACT_SRC_PRODUCTION,          // 产测
    LS_LED_ACT_SRC_RESET,               // 重置设备
    LS_LED_ACT_SRC_BTN,                 // 按键触发的情景模式
    LS_LED_ACT_SRC_UNKNOW,              // led控制来源：未知
} LS_LED_ACT_SRC_E;

/*
 * @brief LedStrip led控制事件结构体
 */
typedef struct
{
    LS_LED_EV_E id;
    LS_LED_ACT_SRC_E act_src;
    void *p_data;            // 如果是临时的话 记得malloc 和 释放
} ls_led_ev_t;


/*
 * @brief LedStrip 灯光参数 白光亮度色温 彩光HSV
 */
typedef struct
{
    uint16_t colortemp;
    uint16_t brightness;
    uint16_t H;
    uint16_t S;
    uint16_t V;
} ls_led_hsv_t;

/*
 * @brief LedStrip 灯光参数 白光和彩光RGB
 */
typedef struct
{
    uint16_t CW;
    uint16_t WW;
    uint16_t R;
    uint16_t G;
    uint16_t B;
} ls_led_rgb_t;

/*
 * @brief LedStrip rgb 情景灯效切换状态
 */
typedef struct
{
    LS_SCENE_MODE_E mode;                   // 情景灯效模式
    uint8_t node_num;                       // 模式节点总数，灯效节点数
    uint8_t first_node;                     // 模式的第一个状态
    uint8_t step_num;                       // 保持步数，相当于颜色模式存在时间
    uint8_t times;                          // 循环执行次数 ，0代表一直执行
    ls_led_rgb_t *mode_head;                // 模式灯效节点头
} ls_led_diverse_param_t;

/*
 * @brief LedStrip hsv设置参数
 */
typedef struct
{
    LS_MODE_E mode;
    ls_led_hsv_t color;
} ls_led_hsv_param_t;

/*
 * @brief LedStrip 变化灯效状态记录
 */
typedef struct
{
    ls_led_diverse_param_t *last_mode;  // 模式当前的灯效节点1->2 为1
    LS_SCENE_MODE_E mode;               // 情景灯效模式
    uint8_t cur_node;                   // 模式当前的灯效节点1->2 为1
    uint8_t remind_step;                // 灯效节点完全切换的剩余步数，等于时间
    uint8_t remind_times;               // 剩余周期次数
    ls_led_rgb_t cur_color;             // 当前颜色参数
} ls_led_changing_status_t;



/*
 * @brief LedStrip 整体状态（包含模式状态和物理状态）
 */
typedef struct
{
    bool status;
    LS_MODE_E model;
    bool switch_flag;                       // 灯效切换标志位
    bool gradient_flag;                     // 灯效切换渐变模式
    bool diverse_flag;                      // 灯效变化flag
    LS_MODE_E last_app_mode;                // app最新操作的灯光模式
    ls_led_hsv_t app_color;                 // app最近1次的彩光和白光参数
    ls_led_hsv_t cur_color;                 // app灯光参数
} ls_status_t;

/*
 * @brief LedStrip 获取的模式参数
 */
typedef struct
{
    bool status;
    LS_MODE_E model;
    LS_MODE_E last_mode;
    ls_led_hsv_t color;
} ls_led_status_t;


/**
* @brief       模式设置
* @param[in]  p_param     [参数 ls_led_hsv_params_t / ls_led_diverse_param_t]
* @param[in]  src         [来源]
* @return  None
*/
void ls_led_set_led(void *p_param, LS_LED_ACT_SRC_E src);


/**
* @brief  获取当前状态
* @param[in]  type                 [获取的颜色参数，false时color为app的设置参数，true时为当前颜色参数]
* @param[out]  *status             [模式参数]
*/
void ls_led_get_status(bool type, ls_led_status_t *status);


/**
* @brief    关闭灯带
* @param[in]  src         [来源]
*/
void ls_led_off(LS_LED_ACT_SRC_E src);



/**
* @brief    rgb渐变呼吸灯
* @param[in]  *pst_breathing_param  [呼吸灯参数]
* @return  uint32_t                 [执行结果 APP_OK:执行成功，还在执行中 APP_FAIL:执行失败/执行结束]
*/
uint32_t ls_led_rgb_color_breating(ls_led_diverse_param_t *pst_breathing_param);

/**
* @brief    rgb渐变呼吸灯 交替时有重叠 重叠时间不定，节点参数为每种颜色组合的最大占空比，变化中最低占空比为0
* @param[out]  *pst_breathing_param         [呼吸灯参数]
* @param[int]  overlap_step                 [重叠步数]
* @return  uint32_t                         [执行结果 APP_OK:执行成功，还在执行中 APP_FAIL:执行失败/执行结束]
*/
uint32_t ls_led_rgb_overlap_breathing(ls_led_diverse_param_t *pst_breathing_param, uint8_t overlap_step);


/**
* @brief    rgb颜色循环,常亮
* @param[in]  *pst_switch_param     [参数]
* @return  uint32_t                 [执行结果 APP_OK:执行成功，还在执行中 APP_FAIL:执行失败/执行结束]
*/
uint32_t ls_led_rgb_color_switch(ls_led_diverse_param_t *pst_switch_param);

/**
* @brief  led 控制初始化
*/
void ls_led_init(void);

#ifdef __cplusplus
}
#endif

#endif

