/*
 * This file is subject to the terms and conditions defined in
 * file 'LICENSE', which is part of this source code package.
 * Tuan PM <tuanpm at live dot com>
 */


#ifndef __MQTT_UTIL_H__
#define __MQTT_UTIL_H__

#if defined(CONFIG_TARGET_LINUX)
#include <sys/types.h>
#include <sys/socket.h>
#include <unistd.h>
#include <errno.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <unistd.h>
#include <fcntl.h>
#else
#include "lwip/err.h"
#include "lwip/sockets.h"
#include "lwip/sys.h"
#include "lwip/netdb.h"
#include "lwip/dns.h"
#endif

#ifndef STRMAC
#define STR2MAC(a)  (unsigned int *)&(a)[0], (unsigned int *)&(a)[1], (unsigned int *)&(a)[2], \
                    (unsigned int *)&(a)[3], (unsigned int *)&(a)[4], (unsigned int *)&(a)[5]
#define STRMAC "%02x:%02x:%02x:%02x:%02x:%02x"
#endif

#define MQTT_UTIL_MEM_CHECK(a, action)                      \
    if (!(a))                                               \
    {                                                       \
        action;                                             \
    }

#define MQTT_UTIL_SAFE_FREE(ptr)        \
    do{                                 \
        if (NULL != ptr) {              \
            vesync_free(ptr);           \
            ptr = NULL;                 \
        }                               \
    }while(0)


char *mqtt_util_create_id_string(void);
int mqtt_util_random(int max);
long long mqtt_util_tick_get_ms(void);
void mqtt_util_ms_to_timeval(int timeout_ms, struct timeval *tv);

/**
* @brief       create new string according to old string
* @param[in]   ptr                  [point to old string]
* @return      char*                [created string]
*/
char *mqtt_create_string(const char *ptr);

#endif /* __MQTT_UTIL_H__ */

