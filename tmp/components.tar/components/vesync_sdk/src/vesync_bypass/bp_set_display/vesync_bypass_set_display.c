/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_bypass_set_display.c
 * @brief       bypass处理接口
 * @date        2021-05-17
 */

#include <string.h>
#include "vesync_common.h"
#include "vesync_memory.h"
#include "vesync_log_internal.h"
#include "vesync_bypass_internal.h"

/**
 * @brief 设置常规模式的屏显数据
 * @param p_trace_msg trace message
 * @param json数据指针
 * @return BYPASS_ERR_E
 */
static BYPASS_ERR_E bypass_method_set_display_handle(bypass_trace_msg_t *p_trace_msg, cJSON *json)
{
    BYPASS_ERR_E ret = BP_OK;
    cJSON* json_data = NULL;

    if ((NULL == json)||(NULL == p_trace_msg))    return BP_ERROR;

    bypass_normal_display_t *pDisplay_data = (bypass_normal_display_t *)vesync_malloc(sizeof(bypass_normal_display_t));
    if (NULL == pDisplay_data)
    {
        return BP_ERR_NOMEM;
    }

    memset(pDisplay_data, 0, sizeof(bypass_normal_display_t));

    json_data = cJSON_GetObjectItemCaseSensitive(json, "state");
    if (cJSON_IsBool(json_data))
    {
        pDisplay_data->display = json_data->valueint;
        SDK_LOG(LOG_DEBUG,"state : %d\r\n", pDisplay_data->display);
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_SET_DISPLAY);
    if (method_cb)
    {
        method_cb(p_trace_msg, (void*)pDisplay_data, sizeof(bypass_normal_display_t));
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

_exit:
    vesync_free(pDisplay_data);
    return ret;
}

/**
 * @brief 设置熄屏模式
 * @param p_trace_msg trace message
 * @param json数据指针
 * @return BYPASS_ERR_E
 */
static BYPASS_ERR_E bypass_method_set_display_mode_handle(bypass_trace_msg_t *p_trace_msg, cJSON *json)
{
    BYPASS_ERR_E ret = BP_OK;
    cJSON* json_data = NULL;

    if ((NULL == json)||(NULL == p_trace_msg))    return BP_ERROR;

    bypass_display_mode_t * p_display_mode = (bypass_display_mode_t *)vesync_malloc(sizeof(bypass_display_mode_t));
    if (NULL == p_display_mode)
    {
        return BP_ERR_NOMEM;
    }

    memset(p_display_mode, 0, sizeof(bypass_display_mode_t));

    json_data = cJSON_GetObjectItemCaseSensitive(json, "display_forever");
    if (cJSON_IsBool(json_data))
    {
        p_display_mode->display_forever = json_data->valueint;

        SDK_LOG(LOG_DEBUG,"display_forever : %d\r\n", p_display_mode->display_forever);
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_SET_DISPLAY_MODE);
    if (method_cb)
    {
        method_cb(p_trace_msg, (void*)p_display_mode, sizeof(bypass_display_mode_t));
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

_exit:
    vesync_free(p_display_mode);
    return ret;
}


static bypass_item_data_t set_display_method_tbl[] = {
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_SET_DISPLAY,      "setDisplay",     bypass_method_set_display_handle, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_SET_DISPLAY_MODE, "setDisplayMode", bypass_method_set_display_mode_handle, NULL},
};

void vesync_bypass_set_display_init(void)
{
    for (int i = 0; i < SIZEOF_ARRAY(set_display_method_tbl); i++)
    {
        bypass_item_t *item = vesync_bypass_init_item(&set_display_method_tbl[i]);
        if (item != NULL)
        {
            vesync_bypass_add_item(item);
        }
    }
}
