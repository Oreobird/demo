/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
 * @file        vhal_sys.h
 * @brief       通用接口
 * @date        2021-08-26
 */

#ifndef __VHAL_SYS_H__
#define __VHAL_SYS_H__

#ifdef __cplusplus
extern "C"
{
#endif

/**
 * @brief 系统硬件初始化，Vesync SDK初始化前调用
 */
void vhal_sys_board_init(void);

/**
 * @brief 开启系统任务调度
 */
void vhal_sys_task_schedule(void);

#ifdef __cplusplus
}
#endif

#endif /* __VHAL_SYS_H__ */
