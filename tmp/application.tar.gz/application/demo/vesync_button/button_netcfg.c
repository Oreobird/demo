/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        button_netcfg.c
 * @brief       配网按键业务实现
 * @author      Joshua
 * @date        2021-12-23
 */
#include <stdint.h>
#include <string.h>
#include <stdbool.h>

#include "vesync_log.h"
#include "vesync_common.h"
#include "vesync_task.h"
#include "button.h"

#define TRIGGER_NETCFG_TIME_MS  5000
#define TRIGGER_RESET_TIME_MS   15000
#define TRIGGER_PRODUCTION_TIME_MS  2000
#define POWERON_TIME_MS  10000
#define BUTTON_GPIO_NUM 7

static uint64_t s_hold_start_ts = 0;
static uint64_t s_power_on_ts = 0;
static uint8_t s_click_cnt = 0;
static uint64_t s_press_down_ts = 0;
static bool s_press_down_tick = true;

static void press_down_handle(void)
{
    APP_LOG(LOG_DEBUG, "Press down\n");
    if (s_press_down_tick)
    {
        s_press_down_ts = vesync_task_get_tick_ms();
        s_press_down_tick = false;
    }
    s_hold_start_ts = vesync_task_get_tick_ms();
}

static void press_up_handle(void)
{
    uint64_t hold_end_ts = vesync_task_get_tick_ms();
    if (hold_end_ts - s_hold_start_ts > TRIGGER_NETCFG_TIME_MS)
    {
        APP_LOG(LOG_DEBUG, "-------Trigger netcfg: %d-------\n", (int)(hold_end_ts - s_hold_start_ts));
    }
}

static void single_click_handle(void)
{
    uint64_t cur_ts = vesync_task_get_tick_ms();

    if (cur_ts - s_power_on_ts <= POWERON_TIME_MS)  // 上电10秒内
    {
        if (cur_ts - s_press_down_ts < TRIGGER_PRODUCTION_TIME_MS)  // 2s内按5次
        {
            s_click_cnt++;
            APP_LOG(LOG_DEBUG, "click cnt = %d\n", s_click_cnt);
            if (s_click_cnt >= 5)
            {
                s_click_cnt = 0;
                APP_LOG(LOG_DEBUG, "------Trigger production: %d-------\n", (int)(cur_ts - s_press_down_ts));
            }
        }
        else
        {
            s_press_down_ts = vesync_task_get_tick_ms();
            s_click_cnt = 1;
            APP_LOG(LOG_DEBUG, "click cnt = %d\n", s_click_cnt);
        }

    }
}

static void long_press_start_handle(void)
{
    s_hold_start_ts = vesync_task_get_tick_ms();
}

static void long_press_hold_handle(void)
{
    uint64_t hold_ts = vesync_task_get_tick_ms();

    APP_LOG(LOG_DEBUG, "-------Trigger long_press_hold_handle-------\n");
    if (hold_ts - s_hold_start_ts > TRIGGER_RESET_TIME_MS)
    {
        APP_LOG(LOG_DEBUG, "-------Trigger reset: %d-------\n", (int)(hold_ts - s_hold_start_ts));
        s_hold_start_ts = hold_ts;
    }
}

static btn_ev_cb_t s_ev_cb_tbl[] = {
    {EV_PRESS_DOWN, press_down_handle},
    {EV_PRESS_UP, press_up_handle},
    {EV_SINGLE_CLICK, single_click_handle},
    {EV_LONG_PRESS_START, long_press_start_handle},
    {EV_LONG_PRESS_HOLD, long_press_hold_handle}
};

int button_netcfg_init(void)
{
    APP_LOG(LOG_INFO, "Vesync APP Demo start\n");

    int ret = SDK_FAIL;

    s_power_on_ts = vesync_task_get_tick_ms();

    btn_cfg_t cfg;

    memset(&cfg, 0, sizeof(btn_cfg_t));
    cfg.gpio = BUTTON_GPIO_NUM;
    cfg.active_level = ACTIVE_LOW;
    cfg.long_press_cb_interval_ms = 1000;

    ret = vesync_button_add(&cfg);
    if (ret != SDK_OK)
    {
        APP_LOG(LOG_ERROR, "button add fail\n");
        return APP_FAIL;
    }

    ret = vesync_button_reg_cb_arr(BUTTON_GPIO_NUM, s_ev_cb_tbl, SIZEOF_ARRAY(s_ev_cb_tbl));
    if (ret != SDK_OK)
    {
        APP_LOG(LOG_ERROR, "button reg cb fail\n");
        vesync_button_del(BUTTON_GPIO_NUM);
        return APP_FAIL;
    }

    return APP_OK;
}

int button_netcfg_deinit(void)
{
    return (SDK_OK == vesync_button_del(BUTTON_GPIO_NUM)) ? APP_OK : APP_FAIL;
}


