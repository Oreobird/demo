/**
* Copyright © Vesync Technologies Co.Ltd. 2022. All rights reserved
* @file         custom.c
* @brief        自定义场景注册
* @author       Joshua
* @date         2022-1-12
*/

#include <string.h>
#include <stdint.h>
#include "vesync_common.h"
#include "vesync_memory.h"
#include "vesync_log.h"
#include "custom.h"

int custom_scene_max_data_size(void)
{
    return (sizeof(scene_t) + sizeof(custom_light_scene_t) + sizeof(light_color_t) * LIGHT_SEGMENT_MAX_NUM) * CUSTOM_SCENE_MAX_NUM;
}

int custom_scene_id_gen(void)
{
    int id = CUSTOM_SCENE_ID_MIN;
    int id_max = CUSTOM_SCENE_ID_MIN + CUSTOM_SCENE_MAX_NUM;

    for (id = SCENE_DEFAULT_ID_MAX; id < id_max; id++)
    {
        if (scene_registry_get(SCENE_LIGHT, id) == NULL)
        {
            break;
        }
    }

    return (id == id_max) ? SCENE_INVALID_ID : id;
}


int custom_scene_del(int scene_id)
{
    return scene_registry_del(SCENE_LIGHT, scene_id);
}

int custom_scene_add(int *scene_id)
{
    dev_cfg_t *p_dev_cfg = app_device_cfg_get();
    if (p_dev_cfg == NULL || (p_dev_cfg->flash->cfg.mode != LIGHT_MODE_WHITE 
        && p_dev_cfg->flash->cfg.mode != LIGHT_MODE_COLOR 
        && p_dev_cfg->flash->cfg.mode != LIGHT_MODE_MULTI))
    {
        return APP_FAIL;
    }

    int ret = APP_OK;
    scene_t *thiz = NULL;

    int scene_size = sizeof(scene_t) + sizeof(custom_light_scene_t);
    int seg_param_size = (p_dev_cfg->flash->cfg.mode == LIGHT_MODE_WHITE) ? sizeof(light_white_t) : sizeof(light_color_t);
    thiz = (scene_t *)vesync_calloc(1, scene_size + seg_param_size);
    if (thiz == NULL)
    {
        return APP_FAIL;
    }

    thiz->type = SCENE_LIGHT;
    thiz->id = custom_scene_id_gen();

    custom_light_scene_t *ctx = (custom_light_scene_t *)thiz->ctx;
    ctx->reference = 0;
    ctx->mode = p_dev_cfg->flash->cfg.mode;
    ctx->seg_num = p_dev_cfg->flash->cfg.seg_num;
    memcpy(ctx->seg_param, p_dev_cfg->flash->cfg.extra.seg_param, seg_param_size * ctx->seg_num);

    ret = scene_registry_add(thiz);
    if (ret != APP_OK)
    {
        VCOM_SAFE_FREE(thiz);
        return APP_FAIL;
    }

    ret = custom_scene_flash_write();
    if (ret != APP_OK)
    {
        scene_registry_del(thiz->type, thiz->id);
        VCOM_SAFE_FREE(thiz);
        return APP_FAIL;
    }

    *scene_id = thiz->id;

    return ret;
}

int custom_scene_get(int idx)
{
    int ret = custom_scene_flash_read();
    return ret;
}
