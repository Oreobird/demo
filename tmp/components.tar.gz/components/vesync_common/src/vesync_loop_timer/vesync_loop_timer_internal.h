/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
 * @file        vesync_loop_timer_internal.h
 * @brief       运行在任务内部的软件定时器
 * @date        2021-05-21
 */

#ifndef __VESYNC_LOOP_TIMER_INTERNAL_H__
#define __VESYNC_LOOP_TIMER_INTERNAL_H__

#include <stdint.h>
#include <stdbool.h>
#include <sys/types.h>

#ifdef __cplusplus
extern "C" {
#endif


#define VLOOP_TIMER_MAX_PERIOD  (864000000) //最大执行周期（1000*60*60*24*10），为了规避TickType_t溢出的问题
#define VLOOP_MAX_TIMER_ON_LOOP  (8) //vloop_timer_process_expired一次最多处理多少个超时定时器


/**
 * @brief 内部定时器的回调函数
 * @param[in]  args             [回调参数]
 */
typedef void (*vloop_timer_handler_t)(void *args);


/**
 * @brief 内部定时器结构体
 */
typedef struct vloop_timer
{
    bool  reload;              // true-周期执行；false-单次执行
    uint64_t  period;          // 执行周期,单位ms
    vloop_timer_handler_t cb;  // 回调函数
    void *arg;                 // 入参

    uint64_t timeout;          // 超时时间，内部维护，禁止用户修改
    struct vloop_timer *next;  // 指向下一个内部定时器，内部维护，禁止用户修改
} vloop_timer_t;


/**
 * @brief 内部定时器链表头
 */
typedef struct vloop_timer_header
{
    vloop_timer_t *first_node;
} vloop_timer_header_t;


/**
 * @brief 添加内部定时器到链表中，开始倒计时
 * @param[in]  p_timer_header      [内部定时器链表指针]
 * @param[in]  p_timer             [内部定时器地址]
 * @return    bool                 [成功：true，失败：false]
 * @note
 */
bool vloop_timer_add(vloop_timer_header_t *p_timer_header, vloop_timer_t *p_timer);


/**
 * @brief 从链表中删除内部定时器，停止倒计时
 * @param[in]  p_timer_header      [内部定时器链表指针]
 * @param[in]  p_timer             [内部定时器地址]
 * @return    bool                 [成功：true，失败：false]
 * @note
 */
bool vloop_timer_del(vloop_timer_header_t *p_timer_header, vloop_timer_t *p_timer);


/**
 * @brief 获取当前内部定时器还剩多长时间超时
 * @param[in]  p_timer_header      [内部定时器链表指针]
 * @param[in]  p_timer             [内部定时器地址]
 * @return    uint64_t             [剩余超时时间]
 * @note      返回0时，表示该内部定时器不在链表中，或已经执行过并停止倒计时
 */
uint64_t vloop_timer_remaining(vloop_timer_header_t *p_timer_header, vloop_timer_t *p_timer);


/**
 * @brief 执行所有已经超时的内部定时器
 * @param[in]  p_timer_header      [内部定时器链表指针]
 * @return    uint64_t             [下一个内部定时器的剩余超时时间]
 * @note      若链表中没有内部定时器等待执行，则返回portMAX_DELAY
 */
uint64_t vloop_timer_process_expired(vloop_timer_header_t *p_timer_header);


#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_LOOP_TIMER_INTERNAL_H__ */
