/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_flash.h
 * @brief       flash模块接口定义
 * @date        2021-05-17
 */

#ifndef __VESYNC_FLASH_H__
#define __VESYNC_FLASH_H__

#include <stdint.h>
#include "vhal_flash.h"

#ifdef __cplusplus
extern "C" {
#endif


/**
 * @brief  flash初始化
 * @return  int32_t                 [成功：SDK_OK，失败：SDK_FAIL]
 */
int32_t vesync_flash_init(void);


/**
 * @brief  从flash读取数据
 * @param[in]  part_id              [分区ID]
 * @param[in]  key_name             [键值名称]
 * @param[in]  p_data               [读取数据缓存区；如果该读取Buffer为NULL，则返回该数据的长度]
 * @param[in]  p_len                [当前读取的数据长度]
 * @return  int32_t                 [成功：SDK_OK，失败：SDK_FAIL]
 */
int32_t vesync_flash_read(PARTITION_ID_E part_id, const char *key_name, uint8_t *p_data, uint32_t *p_len);


/**
 * @brief  往flash写入数据
 * @param[in]  part_id              [分区ID]
 * @param[in]  key_name             [键值名称]
 * @param[in]  p_data               [写入的数据]
 * @param[in]  len                  [写入数据的长度]
 * @return  int32_t                 [成功：SDK_OK，失败：SDK_FAIL]
 */
int32_t vesync_flash_write(PARTITION_ID_E part_id, const char *key_name, uint8_t *p_data, uint32_t len);


/**
 * @brief  从flash读取加密数据
 * @param[in]  part_id              [分区ID]
 * @param[in]  key_name             [键值名称]
 * @param[in]  p_data               [读取数据缓存区]
 * @param[in,out]  p_len            [当前读取的数据长度]
 * @return  int32_t                 [成功：SDK_OK，失败：SDK_FAIL]
 */
int32_t vesync_flash_aes_crypto_read(PARTITION_ID_E part_id, const char *key_name, uint8_t *p_data, uint32_t *p_len);


/**
 * @brief  往flash加密写入数据
 * @param[in]  part_id              [分区ID]
 * @param[in]  key_name             [键值名称]
 * @param[in]  p_data               [写入的数据]
 * @param[in]  len                  [写入数据的长度]
 * @return  int32_t                 [成功：SDK_OK，失败：SDK_FAIL]
 */
int32_t vesync_flash_aes_crypto_write(PARTITION_ID_E part_id, const char *key_name, uint8_t *p_data, uint32_t len);


/**
 * @brief  从flash读取加密数据
 * @param[in]  part_id              [分区ID]
 * @param[in]  key_name             [键值名称]
 * @param[in]  p_data               [读取数据缓存区]
 * @param[in,out]  p_len            [当前读取的数据长度]
 * @return  int32_t                 [成功：SDK_OK，失败：SDK_FAIL]
 */
int32_t vesync_flash_crypto_read(PARTITION_ID_E part_id, const char *key_name, uint8_t *p_data, uint32_t *p_len);


/**
 * @brief  往flash加密写入数据
 * @param[in]  part_id              [分区ID]
 * @param[in]  key_name             [键值名称]
 * @param[in]  p_data               [写入的数据]
 * @param[in]  len                  [写入数据的长度]
 * @return  int32_t                 [成功：SDK_OK，失败：SDK_FAIL]
 */
int32_t vesync_flash_crypto_write(PARTITION_ID_E part_id, const char *key_name, uint8_t *p_data, uint32_t len);


/**
 * @brief  擦除指定分区
 * @param[in]  part_id              [分区ID]
 * @return  int32_t                 [成功：SDK_OK，失败：SDK_FAIL]
 */
int32_t vesync_flash_erase(PARTITION_ID_E part_id);


/**
 * @brief  擦除指定分区中的指定键值对
 * @param[in]  part_id              [分区ID]
 * @param[in]  key_name             [键值名称]
 * @return  int32_t                 [成功：SDK_OK，失败：SDK_FAIL]
 */
int32_t vesync_flash_erase_key(PARTITION_ID_E part_id, const char *key_name);


#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_FLASH_H__ */


