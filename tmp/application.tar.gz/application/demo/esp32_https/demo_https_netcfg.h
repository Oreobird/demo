/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        demo_https_netcfg.h
 * @brief       https配网示例接口
 * @author      Joshua
 * @date        2021-10-17
 */

#ifndef __DEMO_NETCFG_H__
#define __DEMO_NETCFG_H__

#ifdef __cplusplus
extern "C" {
#endif


/**
 * @brief  配网初始化
 */
void demo_netcfg_init(void);


#ifdef __cplusplus
}
#endif

#endif

