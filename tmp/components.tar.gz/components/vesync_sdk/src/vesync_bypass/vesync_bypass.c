/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_bypass.c
 * @brief       bypass处理接口
 * @date        2021-05-13
 */

#include <string.h>
#include <stdio.h>

#include "vesync_cfg_internal.h"
#include "vesync_common.h"
#include "vesync_memory.h"
#include "vesync_event_internal.h"
#include "vesync_net_service_internal.h"

#include "vesync_report.h"
#include "vesync_device_internal.h"
#include "vesync_bypass_internal.h"
#include "vesync_log_internal.h"
#include "vesync_json_internal.h"

#if defined(CONFIG_VESYNC_SDK_LAN_COMM_ENABLE) && defined(CONFIG_VESYNC_BYPASS_LAN_COMM_SUPPORT)
#include "vesync_lan_comm.h"
#endif
#if defined(CONFIG_VESYNC_SDK_SRPC_ENABLE)
#include "vesync_srpc_internal.h"
#endif

static bypass_mgt_t s_bypass_mgt;


/*-----------------------------------------------------------------------------*
*-----------------------------------内部函数API实现-------------------------------*
*-----------------------------------------------------------------------------*/

/**
 * @brief 通过method_id获取节点
 * @param method_id                   [方法ID]
 * @return bypass_item_t *            [对应的节点指针]
 */
static bypass_item_t *vesync_bypass_get_item_by_id(BYPASS_METHOD_ID_E  method_id)
{
    bypass_item_t *pos, *n;
    struct list_head *head;

    head = &s_bypass_mgt.list;

    list_for_each_entry_safe(pos, n, head, list)
    {
        if (pos->data.method_id == method_id)
        {
            return pos;
        }
    }

    return NULL;
}


/**
 * @brief 通过method名称获取用户定义的节点
 * @param method                       [方法名称]
 * @return bypass_user_item_t *        [对应的节点指针]
 */
static bypass_user_item_t *vesync_bypass_get_user_item_by_method(const char *method)
{
    VCOM_NULL_PARAM_CHK(method, return NULL);

    bypass_user_item_t *pos, *n;
    struct list_head *head;

    head = &s_bypass_mgt.user_list;

    list_for_each_entry_safe(pos, n, head, list)
    {
        if (strcmp(pos->data.method, method) == 0)
        {
            return pos;
        }
    }

    return NULL;
}


/**
* @brief 校验release固件的bypass指令来源是否是授权的
* @param[in]  mask                     [消息支持的来源]
* @param[in]  msg_src                  [消息实际来源]
* @return     bool                     [消息来源是授权的返回true，非授权的返回false]
*/
static bool vesync_bypass_check_auth_msg(uint32_t auth_mask, uint32_t msg_tag)
{
    bool ret = true;

    // release固件才对消息进行过滤，debug固件则不限制
#if defined(PR_FW_TYPE) && (PR_FW_TYPE == 1)
    SDK_LOG(LOG_DEBUG, "auth_mask = 0x%x, msg_tag = 0x%x.\n", auth_mask, msg_tag);
    if ((auth_mask & msg_tag) != msg_tag)
    {
        ret = false;
    }
#endif

    return ret;
}

/**
* @brief net service数据处理回调
*/
static void vesync_bypass_network_data_event_cb(void *data)
{
#if 1
    vesync_bypass_msg_handle(data, MSG_TAG_MQTT);
#else // 调试代码，把MQTT Bypass请求Mock给SRPC处理
    cJSON *p_bp_msg = cJSON_Parse((char *)data);
    if (NULL == p_bp_msg)
    {
        return;
    }

    cJSON *p_bp_pl = cJSON_GetObjectItemCaseSensitive(p_bp_msg, "payload");
    vesync_srpc_mock_for_request_recv(p_bp_pl);
    cJSON_Delete(p_bp_msg);
#endif
}

#if CONFIG_VESYNC_BYPASS_LAN_COMM_SUPPORT
/**
* @brief lan tcp data事件回调
*/
static void vesync_bypass_lan_com_tcp_data_event_cb(void *data)
{
    vesync_bypass_msg_handle(data, MSG_TAG_LOCAL);
}
#endif

/**
* @brief 订阅net service事件
*/
static void vesync_bypass_subscribe_event(void)
{
    vesync_net_reg_bypass_recv_cb(vesync_bypass_network_data_event_cb);
#if defined(CONFIG_VESYNC_SDK_LAN_COMM_ENABLE) && defined(CONFIG_VESYNC_BYPASS_LAN_COMM_SUPPORT)
    vesync_lan_reg_tcp_data_recv_cb(vesync_bypass_lan_com_tcp_data_event_cb);
#endif
}

/**
 * @brief  获取method ctx
 * @param[in]  json_payload         [json数据]
 * @param[out]  *method_ctx         [method上下文结构指针]
 * @return  int                     [-1：参数错误，0：成功，1：无需method_ctx]
 */
static int vesync_bypass_get_method_info(cJSON *json_payload, bypass_method_info_t *method_info)
{
    VCOM_NULL_PARAM_CHK(json_payload, return -1);
    VCOM_NULL_PARAM_CHK(method_info, return -1);

    cJSON *json_dev_type = cJSON_GetObjectItemCaseSensitive(json_payload, "subDeviceType");
    if (cJSON_IsString(json_dev_type))
    {
        cJSON *json_dev_idx = cJSON_GetObjectItemCaseSensitive(json_payload, "subDeviceNo");
        if (json_dev_idx == NULL)
        {
            return -1;
        }
        else if (cJSON_IsNumber(json_dev_idx))
        {
            memset(method_info, 0, sizeof(bypass_method_info_t));
            strncpy(method_info->dev_type, json_dev_type->valuestring, sizeof(method_info->dev_type) - 1);
            method_info->dev_idx = json_dev_idx->valueint;
        }
        else
        {
            return -1;
        }
    }
    else
    {
        return 1;
    }

    return 0;
}

/**
 * @brief 处理Bypass user method
 * @param[in]  p_ctx                    [Bypass Method上下文]
 * @param[in]  msg_tag                  [消息来源标签]
 * @return BYPASS_ERR_E                 [Bypass内部错误返回]
 */
static BYPASS_ERR_E vesync_bypass_handle_inner_method(bypass_msg_ctx_t *p_ctx, uint32_t msg_tag)
{
    BYPASS_ERR_E bp_ret = BP_OK;
    bool eaten = false;
    bypass_item_t *pos, *n;
    struct list_head *head = &s_bypass_mgt.list;
#if 0
    SDK_LOG(LOG_DEBUG,"method : %s\n", trace_msg->p_method_str);
#endif
    list_for_each_entry_safe(pos, n, head, list)
    {
        if (strcmp(p_ctx->p_trace_msg->p_method_str, pos->data.method) == 0)
        {
            eaten = true;

            // 消息授权校验
            if (false == vesync_bypass_check_auth_msg(pos->data.auth_mask, msg_tag))
            {
                bp_ret = BP_ERR_UN_AUTH;
                break;
            }
            if (pos->data.method_handle)
            {
                bp_ret = pos->data.method_handle(p_ctx, p_ctx->p_request);
            }
            break;
        }
    }

    // payload method未找到
    if (!eaten)
    {
        SDK_LOG(LOG_DEBUG, "No inner pre_method found\n");
        bp_ret = BP_ERR_UNDEF_PRE_METHOD;
    }

    return bp_ret;
}

/**
 * @brief 处理Bypass user method
 * @param[in]  p_ctx                    [Bypass Method上下文]
 * @return BYPASS_ERR_E                 [Bypass内部错误返回]
 */
static BYPASS_ERR_E vesync_bypass_handle_user_method(bypass_msg_ctx_t *p_ctx)
{
    BYPASS_ERR_E bp_ret = BP_OK;
    bool eaten = false;
    bypass_user_item_t *pos, *n;
    struct list_head *head = &s_bypass_mgt.user_list;

    list_for_each_entry_safe(pos, n, head, list)
    {
        if (strcmp(p_ctx->p_trace_msg->p_method_str, pos->data.method) == 0)
        {
            eaten = true;

            if (pos->data.method_handle)
            {
                bp_ret = pos->data.method_handle(p_ctx, p_ctx->p_request);
            }
            break;
        }
    }

    // payload method未找到
    if (!eaten)
    {
        SDK_LOG(LOG_DEBUG, "No user method found\n");
        bp_ret = BP_ERR_UNDEF_USER_METHOD;
    }

    return bp_ret;
}

/*-----------------------------------------------------------------------------*
*-----------------------------------SDK层函数API实现-------------------------------*
*-----------------------------------------------------------------------------*/

/**
 * @brief 添加节点
 * @param[in] bypass_item_t            [节点]
 * @return                             [SDK_OK/SDK_FAIL]
 */
int vesync_bypass_add_item(bypass_item_t *item)
{
    VCOM_NULL_PARAM_CHK(item, return SDK_FAIL);

    bypass_item_t *pos = vesync_bypass_get_item_by_id(item->data.method_id);
    if (pos != NULL)
    {
        SDK_LOG(LOG_ERROR, "bypass item add failed\n");
        return SDK_FAIL;
    }

    list_add(&item->list, &s_bypass_mgt.list);
    s_bypass_mgt.num++;
    return SDK_OK;
}


/**
* @brief 初始化节点
* @param[in] bypass_item_data_t        [节点数据]
* @return bypass_item_t *              [节点指针]
*/
bypass_item_t *vesync_bypass_init_item(bypass_item_data_t *data)
{
    bypass_item_t *item = vesync_bypass_get_item_by_id(data->method_id);
    if (item != NULL)
    {
        SDK_LOG(LOG_INFO, "bypass item already exist\n");
        return NULL;
    }

    item = (bypass_item_t *)vesync_malloc(sizeof(bypass_item_t));
    if (item == NULL)
    {
        SDK_LOG(LOG_ERROR, "bypass init item failed\n");
        return NULL;
    }

    memset(item, 0, sizeof(bypass_item_t));
    memcpy(&item->data, data, sizeof(bypass_item_data_t));

    INIT_LIST_HEAD(&item->list);

    return item;
}


/**
 * @brief 通过method id 找到method 的回调函数
 * @param[in]                            [method_id]
 * @return bypass_method_cb_t            [method 回调函数]
 */
bypass_method_cb_t vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_E method_id)
{
    bypass_item_t *pos, *n;
    struct list_head *head;

    head = &s_bypass_mgt.list;

    list_for_each_entry_safe(pos, n, head, list)
    {
        if (pos->data.method_id == method_id)
        {
            return pos->data.app_cb;
        }
    }

    return NULL;
}


/*-----------------------------------------------------------------------------*
*-----------------------------------外部函数API实现-------------------------------*
*-----------------------------------------------------------------------------*/


void vesync_bypass_json_msg_handle(cJSON *p_msg, uint32_t msg_tag)
{
    BYPASS_ERR_E bypass_ret = BP_OK;

    cJSON *json_trceid = NULL;
    cJSON *json_cid = NULL;
    cJSON *json_method = NULL;
    cJSON *json_payload = NULL;
    cJSON *json_request = NULL;
    cJSON *json_request_method = NULL;

    bypass_msg_ctx_t context;
    bypass_method_info_t method_info;
    bypass_trace_msg_t trace_msg;
    memset(&context, 0, sizeof(bypass_msg_ctx_t));
    memset(&method_info, 0, sizeof(bypass_method_info_t));
    memset(&trace_msg, 0, sizeof(bypass_trace_msg_t));

    json_trceid = cJSON_GetObjectItemCaseSensitive(p_msg, "traceId"); // 解析trace id
    if (cJSON_IsString(json_trceid))
    {
        strncpy(trace_msg.trace_id, json_trceid->valuestring, sizeof(trace_msg.trace_id) - 1);
    }
    else
    {
        // 处理参数错误
        SDK_LOG(LOG_WARN, "miss traceID\n");
        bypass_ret = BP_ERR_ARG;

        strncpy(trace_msg.trace_id, "xxxx", sizeof(trace_msg.trace_id) - 1);
        goto EXIT;
    }

    json_cid = cJSON_GetObjectItemCaseSensitive(p_msg, "cid");
    if (cJSON_IsString(json_cid))
    {
        SDK_LOG(LOG_DEBUG, "cid:%s\n", json_cid->valuestring);
    }

    json_method = cJSON_GetObjectItemCaseSensitive(p_msg, "method");
    if (!cJSON_IsString(json_method))
    {
        SDK_LOG(LOG_ERROR, "miss method\n");
        bypass_ret = BP_ERR_ARG;
        goto EXIT;
    }

    if (strcmp(json_method->valuestring, "bypassV2") != 0)
    {
        SDK_LOG(LOG_ERROR, "bypass method error\n");
        bypass_ret = BP_ERR_ARG;
        goto EXIT;
    }

    // 解析payload
    json_payload = cJSON_GetObjectItemCaseSensitive(p_msg, "payload");
    if (!cJSON_IsObject(json_payload))
    {
        SDK_LOG(LOG_ERROR, "paylaod err\n");
        bypass_ret = BP_ERR_ARG;
        goto EXIT;
    }

    cJSON *json_src = cJSON_GetObjectItemCaseSensitive(json_payload, "source");
    if (cJSON_IsString(json_src))
    {
        strncpy(trace_msg.src_type, json_src->valuestring, sizeof(trace_msg.src_type) - 1);
    }
    else
    {
        // 无source字段则默认来源为"APP"
        strncpy(trace_msg.src_type, STAT_CHG_RSN_BP_APP_STR, sizeof(trace_msg.src_type) - 1);
    }
    json_request_method = cJSON_GetObjectItemCaseSensitive(json_payload, "method");
    if (!cJSON_IsString(json_request_method))
    {
        SDK_LOG(LOG_ERROR, "bypass payload method error\n");
        bypass_ret = BP_ERR_ARG;
        goto EXIT;
    }
    trace_msg.p_method_str = json_request_method->valuestring;
    trace_msg.is_responsed = false;
    context.p_trace_msg = &trace_msg;

    // Parse request payload
    json_request = cJSON_GetObjectItemCaseSensitive(json_payload, "data");
    if (cJSON_IsObject(json_request))
    {
        context.p_request = json_request;
    }
    else
    {
        context.p_request = NULL;
    }

    // Parse method info
    switch (vesync_bypass_get_method_info(json_payload, &method_info))
    {
    case 0:
        context.p_method_info = &method_info;
        break;
    case 1:
        context.p_method_info = NULL;
        break;
    default:
        bypass_ret = BP_ERR_ARG;
        goto EXIT;
    }

    context.resp_error_code = BP_ERR_NO_ERR;
    context.p_response = NULL;

    bypass_ret = vesync_bypass_handle_user_method(&context);
    if (BP_ERR_UNDEF_USER_METHOD == bypass_ret)
    {
        bypass_ret = vesync_bypass_handle_inner_method(&context, msg_tag);
        if (bypass_ret != BP_OK)
        {
            goto EXIT;
        }
    }
    else if (bypass_ret != BP_OK)
    {
        SDK_LOG(LOG_ERROR, "user method execute fail[%d]\n", bypass_ret);
    }

EXIT:
    switch (bypass_ret)
    {
    case BP_OK:
        /**
         * @note 建议Bypass Method里的业务处理流程中不调用vesync_bypass_reply_xxx()接口，
         *  而是通过Bypass context返回执行完成的响应，统一由Bypass的平台层进行Response的回复
         */
        if (context.resp_error_code != BP_ERR_NO_ERR)
        {
            vesync_bypass_reply_pkg_err_msg(context.resp_error_code,
                                            context.p_trace_msg,
                                            context.p_resp_error_msg);
        }
        else
        {
            vesync_bypass_reply_noqos(BP_ERR_NO_ERR, context.p_trace_msg, context.p_response);
        }
        break;
    case BP_ERR_ARG:
        SDK_LOG(LOG_ERROR, "bypass arg error\n");
        vesync_bypass_reply_noqos(BP_ERR_PARA_ILLEGAL, context.p_trace_msg, NULL);
        break;
    case BP_ERR_APP_CB_NULL:
        SDK_LOG(LOG_ERROR, "bypass app cb null\n");
        vesync_bypass_reply_noqos(BP_ERR_METHOD_NOT_SUPPORT, context.p_trace_msg, NULL);
        break;
    case BP_ERR_NOMEM:
        SDK_LOG(LOG_ERROR, "bypass not enough memory\n");
        vesync_bypass_reply_noqos(BP_ERR_OUT_OF_MEMORY, context.p_trace_msg, NULL);
        break;
    case BP_ERR_UN_AUTH:
        SDK_LOG(LOG_ERROR, "CMD is not authorized\n");
        vesync_bypass_reply_noqos(BP_ERR_CMD_EXECUTE_FAIL, context.p_trace_msg, NULL);
        break;
    default:
        SDK_LOG(LOG_ERROR, "bypass normal error[%d]\n", bypass_ret);
        vesync_bypass_reply_noqos(BP_ERR_UNDEFINE, context.p_trace_msg, NULL);
        break;
    }

    cJSON_Delete(p_msg);
}


void vesync_bypass_msg_handle(char *p_raw_json, uint32_t msg_tag)
{
    cJSON *root = cJSON_Parse(p_raw_json);
    if (NULL == root)
    {
        SDK_LOG(LOG_ERROR, "json parse fail\n");
        return;
    }
    SDK_LOG(LOG_DEBUG, "===receive data===\n");
#if 0
    vesync_json_print(root);    // json标准格式，带缩进
#endif
    vesync_bypass_json_msg_handle(root, msg_tag);
}


/**
 * @brief 应用层注册bypass method 回调函数
 * @param[in] method_id                [对应的id]
 * @param[in] cb                       [回调函数]
 * @return                             [SDK_OK 注册成功  , SDK_FAIL注册失败]
 */
int vesync_bypass_reg_method_cb(BYPASS_METHOD_ID_E method_id, bypass_method_cb_t cb)
{
    bypass_item_t *pos, *n;
    struct list_head *head;

    head = &s_bypass_mgt.list;
    list_for_each_entry_safe(pos, n, head, list)
    {
        if (pos->data.method_id == method_id)
        {
            pos->data.app_cb = cb;
            return SDK_OK;
        }
    }

    return SDK_FAIL;
}


BYPASS_ERR_E vesync_bypass_reply_noqos(int code, bypass_trace_msg_t *p_trace_msg, cJSON *json)
{
    VCOM_NULL_PARAM_CHK(p_trace_msg, return BP_ERR_ARG);

    // 检查该Bypass Request是否已经回复过了
    if (p_trace_msg->is_responsed)
    {
        return BP_ERR_RESP_ALREADY;
    }
    else
    {
        p_trace_msg->is_responsed = true;
    }

    BYPASS_ERR_E ret = BP_OK;
    cJSON *root = cJSON_CreateObject();
    if (NULL == root)
    {
        if (NULL != json)
        {
            cJSON_Delete(json);
        }
        return BP_ERR_NOMEM;
    }

    cJSON_AddStringToObject(root, "traceId", p_trace_msg->trace_id);
    cJSON_AddNumberToObject(root, "code", code);

    if (NULL != json)
    {
        cJSON_AddItemToObject(root, "result", json);
    }

#if CONFIG_VESYNC_SDK_SRPC_ENABLE
    if (0 == strcmp(p_trace_msg->src_type, STAT_CHG_RSN_BP_SRPC_STR))
    {
        int ret = vesync_srpc_send_response(p_trace_msg->p_method_str, root);
        if (ret != SDK_OK)
        {
            ret = BP_ERROR;
        }
    }
    else
#endif
    {
        char *out_buf = cJSON_PrintUnformatted(root);
        if (NULL != out_buf)
        {
            int tx_ret = -1;
#if CONFIG_VESYNC_BYPASS_LAN_COMM_SUPPORT
            if (0 == strcmp(p_trace_msg->src_type, STAT_CHG_RSN_BP_LAN_STR))
            {
                tx_ret = vesync_lan_comm_tcp_data_send((uint8_t *)(out_buf),
                                                       strlen(out_buf),
                                                       LAN_COMM_OP_TCP_COMMUNICATE,
                                                       LAN_COMM_ENCRYPT,
                                                       code == 0 ? 0 : 1); // 正常执行status为0，否则为1
            }
            else
#endif
            {
                tx_ret = vesync_net_client_send(NET_DATA_TOPIC_RESP, out_buf, strlen(out_buf), SEND_QOS0, NULL);
                if (tx_ret < 0)
                {
                    ret = BP_ERROR;
                }
            }
            vesync_free(out_buf);
        }
    }

#if 1
    vesync_json_print(root);
#endif
    cJSON_Delete(root);
    return ret;
}


void vesync_bypass_reply_pkg_err_msg(int err_code, bypass_trace_msg_t *p_trace_msg, const char *p_msg)
{
    cJSON *json_data = NULL;

    if (NULL != p_msg)
    {
        SDK_LOG(LOG_ERROR, "code = %d, %s\n", err_code, p_msg);

        json_data = cJSON_CreateObject();
        if (NULL != json_data)
        {
            cJSON_AddStringToObject(json_data, "msg", p_msg);
        }
    }

    vesync_bypass_reply_noqos(err_code, p_trace_msg, json_data);
}


int vesync_bypass_reply_qos(int code, bypass_trace_msg_t *p_trace_msg, cJSON *json, SEND_QOS_E qos, void* puback_cb)
{
    int ret = -1;

    VCOM_NULL_PARAM_CHK(p_trace_msg, return SDK_FAIL);

    if (p_trace_msg->is_responsed)
    {
        return BP_ERR_RESP_ALREADY;
    }
    else
    {
        p_trace_msg->is_responsed = true;
    }

    cJSON *root = cJSON_CreateObject();
    if (NULL == root)
    {
        if(json)
        {
            cJSON_Delete(json);
        }
        return BP_ERR_NOMEM;
    }

    cJSON_AddStringToObject(root, "traceId", p_trace_msg->trace_id);
    cJSON_AddNumberToObject(root, "code", code);

    if (NULL != json)
    {
        cJSON_AddItemToObject(root, "result", json);
    }

    char* out_buf = cJSON_PrintUnformatted(root);
    if (out_buf)
    {
        int tx_ret = -1;
        tx_ret = vesync_net_client_send(NET_DATA_TOPIC_RESP, out_buf, strlen(out_buf), qos, puback_cb);

        ret = tx_ret;
        vesync_free(out_buf);
    }

    vesync_json_print(root);
    cJSON_Delete(root);
    return ret;
}


/**
 * @brief 添加节点
 * @param[in] bypass_user_data_t       [节点数据]
 * @return                             [成功：SDK_OK，失败：SDK_FAIL]
 */
int vesync_bypass_add_user_item(bypass_user_data_t *data)
{
    VCOM_NULL_PARAM_CHK(data, return SDK_FAIL);

    bypass_user_item_t *pos = vesync_bypass_get_user_item_by_method(data->method);
    if (pos != NULL)
    {
        SDK_LOG(LOG_ERROR, "bypass user item already exist\n");
        return SDK_FAIL;
    }

    bypass_user_item_t *item = (bypass_user_item_t *)vesync_malloc(sizeof(bypass_user_item_t));
    if (item == NULL)
    {
        SDK_LOG(LOG_ERROR, "bypass add user item failed\n");
        return SDK_FAIL;
    }

    memset(item, 0, sizeof(bypass_user_item_t));
    memcpy(&item->data, data, sizeof(bypass_user_data_t));

    INIT_LIST_HEAD(&item->list);
    list_add(&item->list, &s_bypass_mgt.user_list);

    return SDK_OK;
}


/**
 * @brief bypass 模块初始化
 */
void vesync_bypass_init(void)
{
    memset(&s_bypass_mgt, 0, sizeof(bypass_mgt_t));
    INIT_LIST_HEAD(&s_bypass_mgt.list);
    INIT_LIST_HEAD(&s_bypass_mgt.user_list);

    vesync_bypass_subscribe_event();

#if CONFIG_VESYNC_BYPASS_SWITCH_SUPPORT
    vesync_bypass_switch_init();
#endif

#if CONFIG_VESYNC_BYPASS_INDICATOR_SUPPORT
    vesync_bypass_indicator_init();
#endif

#if CONFIG_VESYNC_BYPASS_TIMER_V2_SUPPORT
    vesync_bypass_timerV2_init();
#endif

#if CONFIG_VESYNC_BYPASS_TIMER_SUPPORT
    vesync_bypass_timer_init();
#endif

#if CONFIG_VESYNC_BYPASS_SCHEDULE_SUPPORT
    vesync_bypass_schedule_init();
#endif

#if CONFIG_VESYNC_BYPASS_TIMEBASE_SUPPORT
    vesync_bypass_timebase_init();
#endif

#if CONFIG_VESYNC_BYPASS_AWAY_SUPPORT
    vesync_bypass_away_init();
#endif

#if CONFIG_VESYNC_BYPASS_TARGET_TEMP_SUPPORT
    vesync_bypass_target_temp_init();
#endif

#if CONFIG_VESYNC_BYPASS_TEMP_UNIT_SUPPORT
    vesync_bypass_temp_unit_init();
#endif

#if CONFIG_VESYNC_BYPASS_LIGHT_SUPPORT
    vesync_bypass_light_init();
#endif

#if CONFIG_VESYNC_BYPASS_COOKING_SUPPORT
    vesync_bypass_cooking_init();
#endif

#if CONFIG_VESYNC_BYPASS_LIGHT_SWITCH_SUPPORT
    vesync_bypass_light_switch_init();
#endif

#if CONFIG_VESYNC_BYPASS_LEVEL_SUPPORT
    vesync_bypass_level_init();
#endif

#if CONFIG_VESYNC_BYPASS_RANGE_SUPPORT
    vesync_bypass_range_init();
#endif

#if CONFIG_VESYNC_BYPASS_SET_TEMP_UNIT_SUPPORT
    vesync_bypass_set_temp_unit_init();
#endif

#if CONFIG_VESYNC_BYPASS_SET_DISPLAY_SUPPORT
    vesync_bypass_set_display_init();
#endif

#if CONFIG_VESYNC_BYPASS_OUTLET_SUPPORT
    vesync_bypass_outlet_init();
#endif

#if CONFIG_VESYNC_BYPASS_HUMIDITY_SUPPORT
    vesync_bypass_humidity_init();
#endif

#if CONFIG_VESYNC_BYPASS_PURIFIER_SUPPORT
    vesync_bypass_purifier_init();
#endif

#if CONFIG_VESYNC_BYPASS_CHILDLOCK_SUPPORT
    vesync_bypass_childlock_init();
#endif

#if CONFIG_VESYNC_BYPASS_RELAY_SUPPORT
    vesync_bypass_relay_init();
#endif

#if CONFIG_VESYNC_BYPASS_NIGHTLIGHT_SUPPORT
    vesync_bypass_nightlight_init();
#endif

#if CONFIG_VESYNC_BYPASS_NIGHTLIGHT_BRIGHTNESS_SUPPORT
    vesync_bypass_nightlight_brightness_init();
#endif

#if CONFIG_VESYNC_BYPASS_NOTIFY_DEVICE_SUPPORT
    vesync_bypass_notify_device_init();
#endif

#if CONFIG_VESYNC_BYPASS_PLASMA_SUPPORT
    vesync_bypass_plasma_init();
#endif

#if CONFIG_VESYNC_BYPASS_SET_DEVICE_TRIGGER_SUPPORT
    vesync_bypass_set_device_trigger_init();
#endif

#if CONFIG_VESYNC_BYPASS_UPGRADE_SUPPORT
    vesync_bypass_upgrade_init();
#endif

#if CONFIG_VESYNC_BYPASS_DEVICE_SUPPORT
    vesync_bypass_device_init();
#endif

#if CONFIG_VESYNC_BYPASS_PRODUCTION_SUPPORT
    vesync_bypass_production_init();
#endif

#if CONFIG_VESYNC_BYPASS_UART_SUPPORT
    vesync_bypass_uart_init();
#endif

#if CONFIG_VESYNC_BYPASS_DEVELOPER_SUPPORT
    vesync_bypass_developer_init();
#endif

#if CONFIG_VESYNC_BYPASS_PERCENT_SUPPORT
    vesync_bypass_percent_init();
#endif

#if CONFIG_VESYNC_BYPASS_LAN_COMM_SUPPORT
    vesync_bypass_lan_com_init();
#endif
}

