/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        bulb.h
 * @brief       bulb公有定义
 * @author      Herve
 * @date        2021-11-16
 */
#ifndef __BULB_DEF_H__
#define __BULB_DEF_H__

#define BULB_DRV_BY_BP5758 (0) // BP5758的驱动类型
#define BULB_DRV_BY_LEDC (1)   // ESP的LEDC PWM驱动类型
#define BULB_DRV_BY_SM2235 (2) // SM2235的驱动类型

#define BULB_INDICATOR_MODE_RGBCWCCT (0) // RGBCW或者RGBCCT的指示灯效模式
#define BULB_INDICATOR_MODE_RGBC (1)     // RGBC的指示灯效模式
#define BULB_INDICATOR_MODE_RGB (2)      // RGB的指示灯效模式
#define BULB_INDICATOR_MODE_CWCCT (3)    // CW或CCT的指示灯效模式
#define BULB_INDICATOR_MODE_C (4)        // C的灯效模式

#define BULB_DEFAULT_HW_VER "1.0" // Bulb的默认硬件版本号，对应BP5758D的默认驱动

#endif /* __BULB_DEF_H__ */