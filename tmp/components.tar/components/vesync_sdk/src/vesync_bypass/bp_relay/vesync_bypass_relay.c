/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_bypass_relay.c
 * @brief       bypass处理接口
 * @date        2021-05-17
 */
#include <string.h>

#include "vesync_common.h"
#include "vesync_memory.h"

#include "vesync_bypass_internal.h"


/**
 * @brief "testRelay"  method数据解析
 * @param p_trace_msg trace message
 * @param json json数据指针
 * @return BYPASS_ERR_E
 */
static BYPASS_ERR_E bypass_method_test_relay_handle(bypass_trace_msg_t *p_trace_msg, cJSON *json)
{
    BYPASS_ERR_E ret = BP_OK;

    if ((NULL == json)||(NULL == p_trace_msg))
        return BP_ERROR;

    bypass_test_relay_data_t *pRelay = vesync_malloc(sizeof(bypass_test_relay_data_t));
    if (NULL == pRelay)
    {
        return BP_ERR_NOMEM;
    }

    memset(pRelay, 0, sizeof(bypass_test_relay_data_t));

    cJSON* json_data = cJSON_GetObjectItemCaseSensitive(json, "start");
    if (cJSON_IsBool(json_data))
    {
        pRelay->start = json_data->valueint;
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_TEST_RELAY);
    if (method_cb)
    {
        method_cb(p_trace_msg, (void*)pRelay, sizeof(bypass_test_relay_data_t));
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

_exit:
    vesync_free(pRelay);

    return ret;
}


static bypass_item_data_t relay_method_tbl[] = {
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_TEST_RELAY, "testRelay", bypass_method_test_relay_handle, NULL},
};

void vesync_bypass_relay_init(void)
{
    for (int i = 0; i < SIZEOF_ARRAY(relay_method_tbl); i++)
    {
        bypass_item_t *item = vesync_bypass_init_item(&relay_method_tbl[i]);
        if (item != NULL)
        {
            vesync_bypass_add_item(item);
        }
    }
}
