/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_list.h
 * @brief       链表接口
 * @date        2021-05-11
 */

#ifndef __VESYNC_LIST_H__
#define __VESYNC_LIST_H__

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif


/**
 * @brief 双向链表表头结构体
 */
struct list_head {
    struct list_head *next, *prev;
};

#define LIST_HEAD_INIT(name) { &(name), &(name) }  //链表头初始化

#define LIST_HEAD(name) \
    struct list_head name = LIST_HEAD_INIT(name)

/**
 * @brief 初始化链表
 * @param[in]  list                  [双向链表指针]
 */
static inline void INIT_LIST_HEAD(struct list_head *list)
{
    list->next = list;
    list->prev = list;
}


/**
 * @brief  增加节点。
 * @param[in]  _new                  [要增加的新节点]
 * @param[in]  prev                  [前节点]
 * @param[in]  next                  [后节点]
 */
static __inline__ void __list_add(struct list_head * _new,
    struct list_head * prev,
    struct list_head * next)
{
    next->prev = _new;
    _new->next = next;
    _new->prev = prev;
    prev->next = _new;
}

/**
 * @brief  增加新节点
 * @param[in]  _new                 [要增加的新节点]
 * @param[in]  head                 [增加新节点的链表表头]
 */
static __inline__ void list_add(struct list_head *_new, struct list_head *head)
{
    __list_add(_new, head, head->next);
}

/**
 * @brief  从链表后增加新节点
 * @param[in]  _new                 [要增加的新节点]
 * @param[in]  head                 [增加新节点的链表表头]
 */
static __inline__ void list_add_tail(struct list_head *_new, struct list_head *head)
{
    __list_add(_new, head->prev, head);
}

/*
 * @brief  删除节点链接
 * @param[in]  prev                 [前向指针]
 * @param[in]  next                 [后向指针]
 */
static __inline__ void __list_del(struct list_head * prev,
                  struct list_head * next)
{
    next->prev = prev;
    prev->next = next;
}

/**
 * @brief  删除节点
 * @param[in]  entry                [从链表上删除链接的节点]
 * @param[in]  next
 */
static __inline__ void list_del(struct list_head *entry)
{
    __list_del(entry->prev, entry->next);
}

/**
 * @brief  删除节点并重新初始化
 * @param[in]  entry                [从链表上删除链接的节点]
 */
static __inline__ void list_del_init(struct list_head *entry)
{
    __list_del(entry->prev, entry->next);
    INIT_LIST_HEAD(entry);
}

/**
 * @brief  判断链表是否为空
 * @param[in]  head                 [链表]
 * @param[out]  int                 [true:为空，false:不为空]
 */
static __inline__ int list_empty(struct list_head *head)
{
    return head->next == head;
}

/**
 * @brief  连接两个链表
 * @param[in]  list                 [需要连接的链表]
 * @param[in]  head                 [添加到第一个链表中的位置]
 */
static __inline__ void list_splice(struct list_head *list, struct list_head *head)
{
    struct list_head *first = list->next;

    if (first != list) {
        struct list_head *last = list->prev;
        struct list_head *at = head->next;

        first->prev = head;
        head->next = first;

        last->next = at;
        at->prev = last;
    }
}

/**
 * @brief  通过结构体成员变量地址获取结构体的地址
 * @param[in]  ptr                 [list_head 结构体指针]
 * @param[in]  type                [包含list_head的数据类型]
 * @param[in]  member              [数据类型中的成员]
 */
#define container_of(ptr, type, member) ( { \
        const typeof( ((type *)0)->member ) *__mptr = (ptr); \
        (type *)( (char *)__mptr - offsetof(type,member) ); } )

/**
 * @brief  获取链表所在的结构体地址
 * @param[in]  ptr                 [list_head 结构体指针]
 * @param[in]  type                [包含list_head的数据类型]
 * @param[in]  member              [数据类型中的成员]
 */
#define list_entry(ptr, type, member) \
        container_of(ptr, type, member)

/**
 * @brief  获取链表第一个元素
 * @param[in]  ptr                 [list_head 结构体指针]
 * @param[in]  type                [包含list_head的数据类型]
 * @param[in]  member              [数据类型中的成员]
 */
#define list_first_entry(ptr, type, member) \
    list_entry((ptr)->next, type, member)


/**
 * @brief  获取链表下一个元素
 * @param[in]  pos                 [位置指针]
 * @param[in]  member              [数据类型中的成员]
 */
#define list_next_entry(pos, member) \
    list_entry((pos)->member.next, typeof(*(pos)), member)

/**
 * @brief  遍历链表
 * @param[in]  pos                 [位置指针]
 * @param[in]  head                [表头]
 */
#define list_for_each(pos, head) \
        for (pos = (head)->next; pos != (head); pos = pos->next)

/**
 * @brief  反向遍历链表
 * @param[in]  pos                 [位置指针]
 * @param[in]  head                [表头]
 */
#define list_for_each_prev(pos, head) \
        for (pos = (head)->prev; pos != (head); pos = pos->prev)

/**
 * @brief  删除条目时安全遍历链表
 * @param[in]  pos                 [位置指针]
 * @param[in]  n                   [临时存储指针]
 * @param[in]  head                [表头]
 */
#define list_for_each_safe(pos, n, head) \
        for (pos = (head)->next, n = pos->next; pos != (head); \
            pos = n, n = pos->next)

/**
 * @brief  删除条目时反向安全遍历链表
 * @param[in]  pos                 [位置指针]
 * @param[in]  n                   [临时存储指针]
 * @param[in]  head                [表头]
 */
#define list_for_each_prev_safe(pos, n, head) \
        for (pos = (head)->prev, n = pos->prev; \
             pos != (head); \
             pos = n, n = pos->prev)

/**
 * @brief  针对给定类型删除条目时安全遍历链表
 * @param[in]  pos                 [位置指针]
 * @param[in]  n                   [临时存储指针]
 * @param[in]  head                [表头]
 * @param[in]  member              [结构体成员]
 */
#define list_for_each_entry_safe(pos, n, head, member) \
        for (pos = list_first_entry(head, typeof(*pos), member),    \
            n = list_next_entry(pos, member);           \
             &pos->member != (head);                    \
             pos = n, n = list_next_entry(n, member))


#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_LIST_H__ */


