/**
 *  Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        hal_gpio.c
 * @brief       乐鑫平台GPIO接口封装
 * @author      Dongri.Su
 * @date        2021-04-22
 */

#include "driver/gpio.h"

#include "esp_idf_version.h"

#include "vesync_log.h"
#include "vesync_common.h"

#include "vhal_gpio.h"


/*-----------------------------------------------------------------------------*
 *                           外部函数API实现                                         *
 *-----------------------------------------------------------------------------*/

/**
 * @brief  GPIO初始化
 * @param[in]  io_conf              [GPIO配置]
 * @return     void
 */
void vhal_gpio_init(vhal_gpio_config_t io_conf)
{
    gpio_config_t gpio_cfg;
    HAL_LOG(LOG_DEBUG, "gpio [%lld] init ...\n", io_conf.pin_bit_mask);

    gpio_cfg.pin_bit_mask = io_conf.pin_bit_mask;
    if (GPIO_MODE_IN == io_conf.mode)
    {
        gpio_cfg.mode = GPIO_MODE_INPUT;
    }
    else if (GPIO_MODE_OUT == io_conf.mode)
    {
        gpio_cfg.mode = GPIO_MODE_OUTPUT;
    }
#if defined(ESP_IDF_VERSION)
#if ESP_IDF_VERSION >= ESP_IDF_VERSION_VAL(4, 2, 0)
    else if (GPIO_MODE_IN_OUT == io_conf.mode)
    {
        gpio_cfg.mode = GPIO_MODE_INPUT_OUTPUT;
    }
#endif /* ESP_IDF_VERSION >= ESP_IDF_VERSION_VAL(4, 2, 0) */
#else
#error "ESP_IDF_VERSION is not defined"
#endif /* ESP_IDF_VERSION  */
    else
    {
        gpio_cfg.mode = GPIO_MODE_DISABLE;
    }
    gpio_cfg.pull_up_en = io_conf.pull_up_en;
    gpio_cfg.pull_down_en = io_conf.pull_down_en;
    gpio_cfg.intr_type = io_conf.intr_type;
    ESP_ERROR_CHECK(gpio_config(&gpio_cfg));
}

/**
 * @brief  GPIO电平获取函数
 * @param[in]  gpio_num             [GPIO编号]
 * @return     int                  [输出电平(0为低电平，1为高电平)]
 */
int32_t vhal_gpio_get_output(uint8_t gpio_num)
{
    gpio_num_t esp_gpio_num = 0;

    esp_gpio_num = gpio_num;

    return gpio_get_level(esp_gpio_num);
}

/**
 * @brief  设置GPIO输出电平函数
 * @param[in]  gpio_num             [GPIO编号]
 * @param[in]  level                [输出电平，0: low ; 1: high]
 * @return     int                  [成功/失败]
 */
int32_t vhal_gpio_set_output(uint8_t gpio_num, uint32_t level)
{
    int32_t ret = -1;
    gpio_num_t esp_gpio_num = 0;

    esp_gpio_num = gpio_num;
    ret = gpio_set_level(esp_gpio_num, level);
    if (ESP_OK != ret)
    {
        return VHAL_FAIL;
    }

    return VHAL_OK;
}

/**
 * @brief  GPIO状态变更
 * @param[in]  gpio_num             [GPIO编号]
 * @param[in]  pullup               [true时表示GPIO需要pullup；false时表示GPIO需要pulldown]
 * @param[in]  enable               [true表示使能pullup/pulldown；false表示禁用pullup/pulldown]
 * @return     void
 */
void vhal_gpio_change_pull_status(uint8_t gpio_num, bool pullup, bool enable)
{
    if (pullup)
    {
        if (enable)
        {
            gpio_pullup_en(gpio_num);
        }
        else
        {
            gpio_pullup_dis(gpio_num);
        }
    }
    else
    {
        if (enable)
        {
            gpio_pulldown_en(gpio_num);
        }
        else
        {
            gpio_pulldown_dis(gpio_num);
        }
    }
}

/**
 * @brief  GPIO设置方向
 * @param[in]  gpio_num             [GPIO编号]
 * @param[in]  mode                 [GPIO方向]
 * @return     void
 */
void vhal_gpio_set_direction(uint8_t gpio_num, GPIO_MODE_E mode)
{
    gpio_num_t esp_gpio_num = 0;
    gpio_mode_t esp_mode = GPIO_MODE_DEF_DISABLE;

    switch (mode)
    {
        case GPIO_MODE_IN:
            esp_mode = GPIO_MODE_INPUT;
            break;
        case GPIO_MODE_OUT:
            esp_mode = GPIO_MODE_OUTPUT;
            break;
#if defined(ESP_IDF_VERSION)
#if ESP_IDF_VERSION >= ESP_IDF_VERSION_VAL(4, 2, 0)
        case GPIO_MODE_IN_OUT:
            esp_mode = GPIO_MODE_INPUT_OUTPUT;
#endif /* ESP_IDF_VERSION >= ESP_IDF_VERSION_VAL(4, 2, 0) */
#else
#error "ESP_IDF_VERSION is not defined"
#endif /* ESP_IDF_VERSION  */
            break;
        default:
            esp_mode = GPIO_MODE_DEF_DISABLE;
    }

    esp_gpio_num = gpio_num;
    ESP_ERROR_CHECK(gpio_set_direction(esp_gpio_num, esp_mode));
}

void vhal_gpio_register_intr_cb(uint8_t gpio_num, GPIO_INTR_TYPE_E intr_type, vhal_gpio_int_cb_t cb_func, void *arg)
{
    gpio_set_intr_type(gpio_num, intr_type);
    gpio_install_isr_service(0);
    gpio_isr_handler_add(gpio_num, cb_func, arg);
}

