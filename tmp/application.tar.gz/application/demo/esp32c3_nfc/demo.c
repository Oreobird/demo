/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        demo.c
 * @brief       SDK入口函数
 * @author      Niki
 * @date        2021-04-22
 */

#include "vesync_init.h"
#include "vesync_log.h"
#include "vesync_cfg.h"
#include "demo_nfc.h"
#include "demo_vesync_nfc_card.h"
#include "vesync_production.h"
#include "string.h"
#include "vesync_device.h"

static void demo_pre_cb(void)
{
    bool result = false;

    APP_LOG(LOG_DEBUG, "Demo pre init callback\n");

    // 设置VeSync SDK的产品配置参数
    vesync_production_set_value_by_key(PRODUCTION_KEY_ID_CID, (uint8_t *)"fwtest-oQcokyh6NOBVP8aUSjq0i1Snz", strlen("fwtest-oQcokyh6NOBVP8aUSjq0i1Snz"));
    vesync_production_set_value_by_key(PRODUCTION_KEY_ID_TEST_FAIL_FLAG, (uint8_t *)&result, sizeof(result));
    vesync_device_set_account_id("1165800");
}

static void demo_app_run(void)
{
    APP_LOG(LOG_INFO, "Vesync APP Demo start\n");
   // demo_vesync_nfc_card_test_init();
   demo_nfc_init();
}

void app_main(void)
{
    vesync_sdk_reg_pre_run_cb(demo_pre_cb);
    vesync_sdk_reg_post_run_cb(demo_app_run);
    vesync_sdk_run();

}
