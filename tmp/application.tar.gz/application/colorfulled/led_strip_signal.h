/**
 *  Copyright © Vesync Technologies Co.Ltd. 2019-2021. All rights reserved
 * @file        vesync_led_strip_signal.h
 * @brief       led strip color generrated signal function
 * @author      henrik
 * @date        2021-09-16
 */
#ifndef __LED_STRIP_SIGNAL_H__
#define __LED_STRIP_SIGNAL_H__

#include <stdio.h>
#include <stdlib.h>
#include "led_display.h"

#define SUCCESS    0
#define FAILURE    1

#define  PI        3.141592658
/*
 *  @brief 灯带调色曲线信号类型枚举
 */
typedef enum
{
    SIGNAL_SIN = 1,
    SIGNAL_TRIANGLE = 2,
    SIGNAL_SQUARE = 3,
    SIGNAL_LINE = 4,
    SIGNAL_SLOPE = 5,
}LED_STRIP_SIGNAL_E;

/*
 *  @brief 灯带调色曲线信息结构体
 */
typedef struct
{
    LED_STRIP_SIGNAL_E signal_type;    // 信号类型
    unsigned short  period ;           // 曲线周期
    float amplitude_max;               // 曲线最大幅值
    float amplitude_min;               // 曲线最小幅值
    float range ;                      // 信号取值范围
} led_strip_signal_info_t;



/*
 *  @brief 灯带hsv曲线结构体
 */
typedef struct
{
//    led_strip_signal_info_t hue;         // 色调曲线
//    led_strip_signal_info_t saturation;  // 饱和度曲线
//    led_strip_signal_info_t value;       // 明度曲线
    rgb_color_t rgb ;                    // rgb参数
    uint32_t  scene;                     // 当前模式
    uint32_t  number ;                   // 灯段总数
    uint32_t  display_num ;              // 显示点个数
    uint32_t  display_pos ;              // 显示起点
    uint32_t  write_pos ;                // rgb点写入位置
    uint32_t  count ;                    // 显示循环计数
    hsv_color_t * hsv   ;                // 色彩点集缓存指针
} led_strip_signal_hsv_t;

#ifdef __cplusplus
{
#endif

typedef  int  (* rgb_calibration_t )(rgb_color_t *rgb);  // 颜色校准接口


/**
 * @brief 注册颜色校准接口
 * @param[in]  cb                            [颜色校准回调接口]
 * @note
 */
void led_strip_reg_rgb_calibrate_cb (rgb_calibration_t cb);


/**
 * @brief hsv颜色空间转化成RGB空间
 * @param[out] rgb                            [rgb 分量 ]
 * @param[in]  hsv                            [hsv 分量]
 * @return     int                            [成功或失败]
 * @note
 */
int led_strip_hsv2rgb(rgb_color_t *rgb, hsv_color_t *hsv);

/**
 * @brief 计算灯带颜色正弦值
 * @param[in]  x                            [曲线 x轴坐标值]
 * @param[out] y                            [曲线 y轴坐标值 正弦值 ]
 * @param[in]  info                         [曲线信息]
 * @return     int                          [成功或失败]
 * @note
 */
int  led_strip_signal_sin(uint32_t x, float * y, led_strip_signal_info_t info);

/**
 * @brief 计算灯带颜色三角曲线值
 * @param[in]  x                            [曲线 x轴坐标值]
 * @param[out] y                            [曲线 y轴坐标值 三角曲线值 ]
 * @param[in]  info                         [曲线信息]
 * @return     int                          [成功或失败]
 * @note
 */
int  led_strip_signal_triangle(uint32_t x, float * y, led_strip_signal_info_t info);

/**
 * @brief 计算灯带颜色方波值
 * @param[in]  x                            [曲线 x轴坐标值]
 * @param[out] y                            [曲线 y轴坐标值 方波值 ]
 * @param[in]  info                         [曲线信息]
 * @return     int                          [成功或失败]
 * @note
 */
int  led_strip_signal_square(uint32_t x, float * y, led_strip_signal_info_t info);

/**
 * @brief 计算灯带颜色斜坡曲线值
 * @param[in]  x                            [曲线 x轴坐标值]
 * @param[out] y                            [曲线 y轴坐标值 斜坡曲线值 ]
 * @param[in]  info                         [曲线信息]
 * @return     int                          [成功或失败]
 * @note
 */
int  led_strip_signal_slope(uint32_t x, float * y, led_strip_signal_info_t info);

/**
 * @brief 计算灯带颜色曲线产生
 * @param[in]  x                            [曲线 x轴坐标值]
 * @param[out] y                            [曲线 y轴坐标值 斜坡曲线值 ]
 * @param[in]  info                         [曲线信息]
 * @return     int                          [成功或失败]
 * @note
 */
int  led_strip_signal_generate(uint32_t x, float * y, led_strip_signal_info_t info);


/**
 * @brief 计算灯带颜色曲线产生
 * @param[in]  x                            [曲线 x轴坐标值]
 * @param[out] led_strip                    [ 灯带色彩点集]
 * @return     int                          [成功或失败]
 * @note
 */
int  led_strip_signal_generate_rgb(uint32_t x, led_strip_signal_hsv_t * led_strip);

/**
 * @brief 计算灯带颜色结构体初始化
 * @param[in/out] led_strip                 [ 灯带色彩点集]
 * @param[in]   number                      [ 灯带点数]
 * @return     int                          [成功或失败]
 * @note
 */
int led_strip_signal_struct_init(led_strip_signal_hsv_t * led_strip, uint32_t number);

/**
 * @brief 计算灯带颜色结构体重置
 * @param[in/out] led_strip                    [ 灯带色彩点集]
 * @return     int                          [成功或失败]
 * @note
 */
int led_strip_signal_struct_deinit(led_strip_signal_hsv_t * led_strip);

#ifdef __cplusplus
}
#endif




#endif