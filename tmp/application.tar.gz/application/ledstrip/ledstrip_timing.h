/**
*Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file    ledstrip_timing.h
* @brief   倒计时接口
* @author  Lind
* @date     2021-09-07
*/

#ifndef __LEDSTRIP_TIMING_H__
#define __LEDSTRIP_TIMING_H__

#include <stdint.h>
#include <stdbool.h>

#include "ledstrip_led.h"

#ifdef __cplusplus
extern "C" {
#endif

#define MAX_LEDSTRIP_TIMER_NUM            1       // timing最大数量
#define MIN_LEDSTRIP_TIMER_ID             1       // itmer最小ID

/**
 * @brief 开关timer定时配置
 */
typedef struct
{
    uint16_t id;            // timer id，最多5个，范围为1~5
    LS_MODE_E mode;         // 模式 关、白光、彩光
    uint32_t total_sec;     // 时间，单位：秒
    ls_led_hsv_t color;    // 颜色
} ls_timing_t;


/**
* @brief 新增一个timer
* @param[in]   mode        [timer执行模式]
* @param[in]   total_sec   [timer定时时间]
* @param[out]  p_id        [timer id]
* @param[in]  *hsv_color   [颜色]
* @return     int          [错误码]
*/
int ls_timing_add(uint32_t total_sec, uint16_t *p_id, LS_MODE_E mode, ls_led_hsv_t *hsv_color);


/**
* @brief 删除一个timer
* @param[in]  uint16_t                 [timer id]
* @return     int_t                    [成功/失败]
*/
int ls_timing_remove(uint16_t timer_id);

/**
* @brief 删除imer
*/
void ls_timing_clear(void);


/**
* @brief 获取timer执行的动作
*/
ls_timing_t *ls_timing_get_act(void);


/**
* @brief 初始化timer
*/
void ls_timing_init(void);



#ifdef __cplusplus
}
#endif

#endif /* __LEDSTRIP_TIMING_H__ */

