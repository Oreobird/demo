/**
*Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file    led_strip.h
* @brief   灯带数据
* @author  henrik
*@date     2021-10-25
*/


#ifndef __LED_STRIP_H__
#define __LED_STRIP_H__

#include <stdio.h>
#include <string.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define LS_EVENT_QUEUE_MAX_NUM       5     // 事件最大数量
#define LS_TASK_RUNNING              1     // 任务运行
#define LS_TASK_STOP                 0     // 任务停止

#define LS_GREEN_CALIBRATE_RATE      777/1000   // 绿色校准比例,有计算优先级，不能加括号
#define LS_BLUE_CALIBRATE_RATE       875/1000   // 蓝色校准比例,有计算优先级，不能加括号

/**
 * @brief  ledstrip应用事件类型id
 */
typedef enum
{
    LS_EV_RESET = 0,       // 恢复出厂灯效事件
    LS_EV_BEFORE_NETCFG,   // 开始配网灯效
    LS_EV_NETCFG,          // 配网任务中灯效
    LS_EV_PRODUCTION,      // 开始产测
    LS_EV_CHANGE_SCENE,    // BYPASS、重上电或按键切换场景
    LS_EV_STATUS_OFF,      // 关闭状态事件
    LS_EV_UNKNOWN,
} LS_EV_E;

/**
 * @brief  ledstrip应用事件来源
 */
typedef enum
{
    LS_ACT_SRC_WIFI_LED = 0,        // 控制来源：WiFi LED
    LS_ACT_SRC_BTN,                 // 控制来源：按键执行
    LS_ACT_SRC_BYPASS,              // 控制来源：BYPASS
    LS_ACT_SRC_PRD,                 // 控制来源：产测
    LS_ACT_SRC_INIT,                // 控制来源：初始化
    LS_ACT_SRC_UNKNOW,              // 控制来源：未知
} LS_ACT_SRC_E;

/**
 * @brief  ledstrip status 来源
 */
typedef enum
{
    LS_STATUS_OFF = 0,        // 灯带关闭
    LS_STATUS_ON,             // 灯带开启
} LS_STATUS_E;

/**
 * @brief  ledstrip应用事件结构体
 */
typedef struct
{
    LS_EV_E event;             // 事件类型
    LS_ACT_SRC_E act_src;      // 事件来源
    uint8_t scene_type;        // 场景类型
    uint16_t scene_id;         // 场景id
} ls_ev_t;

/**
 * @brief  ledstrip控制结构体
 */
typedef struct
{
    uint16_t  id;                //  场景id
    uint16_t  action;           //  控制动作
} ls_ctrl_t;

/**
 * @brief  给ledstrip应用任务发通知
 * @param[in]   ev              [通知消息]
 * @return     int              [成功：APP_OK，失败：APP_FAIL]
 */
int led_strip_app_task_notify(ls_ev_t *ev);

#ifdef __cplusplus
}
#endif

#endif
