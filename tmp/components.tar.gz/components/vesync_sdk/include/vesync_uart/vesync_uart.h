/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_uart.h
 * @brief       UART初始化、UART数据收/发
 * @date        2021-05-08
 */

#ifndef __VESYNC_UART_H__
#define __VESYNC_UART_H__

#include "vesync_frame.h"

#ifdef __cplusplus
extern "C"
{
#endif


/**
 * @brief 串口待发送消息类型
 */
typedef enum
{
    UART_MSG_TYPE_CMD = 0,              // 待发送数据为控制命令
    UART_MSG_TYPE_ACK,                  // 待发送数据为ACK
} UART_MSG_TYPE_E;


/**
 * @brief UART数据发送结果
 */
typedef enum
{
    UART_SEND_SUCCESS = 0,              // 发送成功
    UART_SEND_FAIL                      // 发送失败
} UART_SEND_TYPE_E;


/**
 * @brief 串口发送消息数据结构
 */
typedef struct
{
    UART_MSG_TYPE_E type;               // 消息类型
    uint8_t request_flag;               // CMD包是否要求对端回复的标志
    uint8_t status_code;                // 应答包状态码
    uint32_t opcode;                    // 操作码
    void *p_data;                       // 待发送数据
    uint16_t data_len;                  // 数据长度
    void *p_extra_data;                 // 可选数据
} uart_msg_send_t;


/**
 * @brief  收到数据后，按格式组合成一个完整的帧，校验成功之后通过此函数把正确的数据传给应用层
 * @param[in]  idx                      [串口编号]
 * @param[in]  p_payload                [接收数据字段]
 * @param[in]  payload_len              [payload长度]
 * @return     uint32_t                 [SDK_OK:表示该数据包已处理;SDK_FAIL:表示该数据包未处理，不是OTA功能关注的包]
 */
typedef uint32_t (*uart_recv_data_cb_t)(uint8_t idx, void *p_payload, uint16_t payload_len);


/**
 * @brief  此回调函数是用于通知应用层之前调用发送函数发送数据成功或者失败
 * @param[in]  event                    [串口数据发送成功/失败事件]
 * @param[in]  p_payload                [发送应答帧的数据字段]
 * @param[in]  payload_len              [应答帧的payload长度]
 * @param[in]  p_extra_data             [发送的消息中捎带的自定义数据]
 * @return     uint32_t                 [SDK_OK:表示该数据包已处理;SDK_FAIL:表示该数据包未处理，不是OTA功能关注的包]
 */
typedef uint32_t (*uart_tx_event_cb_t)(UART_SEND_TYPE_E event, tl_payload_info_t *p_payload,
                                        uint16_t payload_len, void *p_extra_data);


/**
 * @brief  待发送数据发送到串口发送队列中
 * @param[in]  idx                      [UART编号]
 * @param[in]  p_msg                    [数据指针]
 * @return  int32_t                     [成功：SDK_OK, 失败：SDK_FAIL]
 * @note   该接口采用拷贝的方式接收p_data数据，调用该接口后需自行释放p_data内存。
 */
uint32_t vesync_uart_send(uint8_t idx, uart_msg_send_t *p_msg);

/**
 * @brief  注册某路串口的接收回调函数，应用层cb处理具体的业务
 * @param[in]  idx                      [UART编号]
 * @param[in]  cb                       [串口数据接收回调函数]
 * @note  cb回调函数内不允许阻塞
 */
void vesync_uart_reg_recv_cb(uint8_t idx, uart_recv_data_cb_t cb);

/**
 * @brief  注册UART串口发送成功/失败后返回事件回调函数，透传的串口不支持此接口
 * @param[in]  idx                      [UART编号]
 * @param[in]  cb                       [发送返回事件回调函数]
 * @note  cb回调函数内不允许阻塞，发送的数据中p_extra_data的内存需在该cb中自行释放
 */
void vesync_uart_reg_tx_event_cb(uint8_t idx, uart_tx_event_cb_t cb);


#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_UART_H__ */
