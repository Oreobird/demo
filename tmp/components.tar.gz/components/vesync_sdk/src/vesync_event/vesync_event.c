/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_event.c
 * @brief       事件处理接口
 * @author      Joshua
 * @date        2021-05-11
 */
#include <string.h>
#include <stdio.h>
#include "vesync_common.h"
#include "vesync_log_internal.h"
#include "vesync_task.h"
#include "vesync_queue.h"
#include "vesync_memory.h"
#include "vesync_event_list.h"
#include "vesync_event_internal.h"
#include "vesync_list.h"

static vesync_queue_t *s_event_queue = NULL;

static event_manage_t s_event_manager;

static const char *event_name[] = {
    FOREACH_EVENT(GEN_STRING)
};

static const char *subcriber_name[] = {
    FOREACH_SUBCRIBER(GEN_STRING)
};

/*-----------------------------------------------------------------------------*
*-----------------------------------内部函数API实现-------------------------------*
*-----------------------------------------------------------------------------*/

/**
* @brief 事件分发处理函数
* @param[in] *event       [事件结构体指针]
* @return int               [成功：SDK_OK，失败：SDK_FAIL]
*/
static int vesync_event_dispatch(vesync_ev_t *event)
{
    event_node_t *pos, *n;
    struct list_head *head;

    VCOM_NULL_PARAM_CHK(event, return SDK_FAIL);

    head = &s_event_manager.node_list;

    vesync_mutex_lock(s_event_manager.mutex);

    list_for_each_entry_safe(pos, n, head, list)
    {
        if (pos->event_id == event->event_id)
        {
            event_subscribe_t *sub_pos, *sub_n;
            struct list_head *sub_head = &pos->subscribe_list;
            vesync_mutex_lock(pos->mutex);
            list_for_each_entry_safe(sub_pos, sub_n, sub_head, list)
            {
                if (sub_pos->event_handle)
                {
                    sub_pos->event_handle(event);
                }
            }
            vesync_mutex_unlock(pos->mutex);
            break;
        }
    }
    vesync_mutex_unlock(s_event_manager.mutex);

    return SDK_OK;
}

/**
* @brief 事件处理中心任务
* @param[in] args       [任务参数]
*/
static void vesync_event_task(void *args)
{
    UNUSED(args);
    vesync_ev_t event;

    while(1)
    {
        memset(&event, 0, sizeof(vesync_ev_t));

        int ret = vesync_queue_recv(s_event_queue, &event, VESYNC_OS_WAIT_FOREVER);
        if (ret != VOS_OK)
        {
            SDK_LOG(LOG_ERROR, "Event queue recv fail\n");
            return;
        }

        if (list_empty(&s_event_manager.node_list))
        {
            continue;
        }

        vesync_event_dispatch(&event);

    }
}

/*-----------------------------------------------------------------------------*
*-----------------------------------SDK内部函数API实现-------------------------------*
*-----------------------------------------------------------------------------*/

/**
* @brief 发布事件通知
* @param[in] *event         [发布的事件结构体指针]
* @return int               [成功：SDK_OK，失败：SDK_FAIL]
*/
int vesync_event_publish(vesync_ev_t *event)
{
    SDK_LOG(LOG_DEBUG, "%s publish event: %s\n", event->publisher, event_name[event->event_id]);

    int ret = vesync_queue_send(s_event_queue, event, VESYNC_OS_NO_WAIT);
    if (ret != VOS_OK)
    {
        SDK_LOG(LOG_ERROR, "Event publish failed\n");
        return SDK_FAIL;
    }

    return SDK_OK;
}

/**
* @brief 订阅事件通知
* @param[in] event_id       [订阅的事件ID]
* @param[in] sub_id         [订阅者ID]
* @param[in] cb             [订阅的回调处理函数]
* @return int               [成功：SDK_OK，失败：SDK_FAIL]
*/
int vesync_event_subscribe(EVENT_ID_E event_id, SUB_ID_E sub_id, event_subscribe_cb_t cb)
{
    SDK_LOG(LOG_DEBUG, "subscriber=%s, event=%s\n", subcriber_name[sub_id], event_name[event_id]);

    event_node_t *node = vesync_event_node_list_add(&s_event_manager, event_id);
    if (node == NULL)
    {
        return SDK_FAIL;
    }

    int ret = vesync_event_subscribe_list_add(sub_id, cb, node);
    if (ret != SDK_OK)
    {
        return SDK_FAIL;
    }

    return SDK_OK;
}

/**
* @brief 取消订阅事件通知
* @param[in] event_id       [取消订阅的事件ID]
* @param[in] sub_id         [取消订阅的订阅者ID]
* @return int               [成功：SDK_OK，失败：SDK_FAIL]
*/
int vesync_event_unsubscribe(EVENT_ID_E event_id, SUB_ID_E sub_id)
{
    SDK_LOG(LOG_DEBUG, "unsubscribe=%s, event=%s\n", subcriber_name[sub_id], event_name[event_id]);

    event_node_t *node = vesync_event_node_get(&s_event_manager, event_id);
    if (node == NULL)
    {
        SDK_LOG(LOG_ERROR, "Event node not found\n");
        return SDK_FAIL;
    }

    vesync_event_subscribe_list_del(&s_event_manager, sub_id, node);

    return SDK_OK;
}


/**
* @brief 初始化事件处理中心
* @return  int                [成功：SDK_OK，失败：SDK_FAIL]
*/
int vesync_event_init(void)
{
    int ret = VOS_FAIL;

    memset(&s_event_manager, 0, sizeof(event_manage_t));
    INIT_LIST_HEAD(&s_event_manager.node_list);

    s_event_manager.mutex = vesync_mutex_new();
    if (s_event_manager.mutex == NULL)
    {
        SDK_LOG(LOG_ERROR, "Event mutex create fail\n");
        return SDK_FAIL;
    }

    s_event_queue = vesync_queue_new(EVENT_QUEUE_MAX_NUM * sizeof(vesync_ev_t), sizeof(vesync_ev_t));
    if (s_event_queue == NULL)
    {
        vesync_mutex_free(s_event_manager.mutex);
        SDK_LOG(LOG_ERROR, "Event queue create fail\n");
        return SDK_FAIL;
    }

    ret = vesync_task_new(EVENT_TASK_NAME,
                          vesync_event_deinit,
                          vesync_event_task,
                          NULL,
                          EVENT_TASK_STACKSIZE,
                          EVENT_TASK_PRIO,
                          NULL);
    if (ret != VOS_OK)
    {
        SDK_LOG(LOG_ERROR, "Event task create fail\n");
        vesync_mutex_free(s_event_manager.mutex);
        vesync_queue_free(s_event_queue);
        return SDK_FAIL;
    }

    return SDK_OK;
}

/**
* @brief 释放事件处理中心资源
*/
void vesync_event_deinit(void)
{
    vesync_queue_free(s_event_queue);
    vesync_mutex_free(s_event_manager.mutex);
}


/**
* @brief 打印事件与订阅链表
*/
void vesync_event_dump_list(void)
{
    event_node_t *pos, *n;
    struct list_head *head;

    printf("\n----------event_dump--------\n");
    head = &s_event_manager.node_list;

    list_for_each_entry_safe(pos, n, head, list)
    {
        printf("event = %s, subscriber = [", event_name[pos->event_id]);

        event_subscribe_t *sub_pos, *sub_n;
        struct list_head *sub_head = &pos->subscribe_list;
        list_for_each_entry_safe(sub_pos, sub_n, sub_head, list)
        {
            printf(" %s ", subcriber_name[sub_pos->sub_id]);
        }
        printf("]\n");
    }
    printf("----------event_dump end--------\n\n");
}


