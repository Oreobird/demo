/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        bulb.h
 * @brief       bulb主任务头文件
 * @author      Dave.Ming
 * @date        2021-08-31
 */
#ifndef __BULB_H__
#define __BULB_H__

#include <stdint.h>

#include "vesync_device.h"

#ifdef __cplusplus
extern "C" {
#endif

#define BULB_EVENT_QUEUE_MAX_NUM             16
#define STAT_CHG_RSN_STR_LEN_MAX             20

/**
 * @brief  灯泡事件类型
 */
typedef enum
{
    BULB_EV_PWOERON = 0,
    BULB_EV_PRODUCTION,
    BULB_EV_BEFORE_NETCFG,
    BULB_EV_NETCFG,
    BULB_EV_NETCFGED,
    BULB_EV_NET_RECONNECTED,
    BULB_EV_RESET,
    BULB_EV_UNKNOWN,
} BULB_EVENT_E;

/**
 * @brief  灯泡动作来源
 */
typedef enum
{
    BULB_ACT_SRC_INIT = 0,        // 初始化
    BULB_ACT_SRC_SWITCH,          // 按键执行
    BULB_ACT_SRC_APP,             // APP、第三方控制
    BULB_ACT_SRC_TASK,            // schedule、timer、away
    BULB_ACT_SRC_RESET,           // 删除设备、恢复出厂
    BULB_ACT_SRC_UNKNOW,          // 未知
} BULB_ACT_SRC_E;

/**
 * @brief  灯泡事件结构体
 */
typedef struct
{
    BULB_EVENT_E id;
    BULB_ACT_SRC_E act_src;
    char rsn[MAX_STAT_CHG_RSN_STR_LEN];
} bulb_ev_t;

/**
 * @brief  灯泡动作类型
 */
typedef struct
{
    uint8_t onoff;  // 开关状态
    uint8_t mode;   // 灯模式，0为白光，1为彩光
    uint8_t bright; // 白光亮度
    uint8_t temp;   // 白光色温
    uint16_t hue;
    uint16_t saturation;
    uint8_t value;
    uint16_t scene_id;
} bulb_action_t;

/**
* @brief  给bulb应用任务发通知
* @param[in]  ev         [事件结构体指针]
* @return     int        [成功：SDK_OK，失败：SDK_FAIL]
*/
int bulb_app_task_notify(bulb_ev_t *ev);

#ifdef __cplusplus
}
#endif

#endif

