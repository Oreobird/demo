/**
 * Copyright © Vesync Technologies Co.Ltd. 2019-2021. All rights reserved
 * @file    mqtt_log.h
 * @brief   mqtt log interface
 * @author  Charles.Mei
 * @date    2021-05-13
 */


#ifndef __MQTT_LOG_H__
#define __MQTT_LOG_H__

/**
 * @brief   "undef the macro" to close the detail error log from mqtt to vasync plat.
 */
#define MQTT_LOG_ENABLE 1


#ifdef MQTT_LOG_ENABLE

#include <stdarg.h>

/**
 * @brief   buffer size for the error message in s_mqtt_log_buf
 */
#define MQTT_LOG_BUFF_MAX 128

/**
 * @brief   MQTT steps: INIT->CONNECT->SUBSCRIBE->RUNNING
 */
enum mqtt_log_step
{
    MLOG_STEP_INIT = 0,             /*!< status before starting to connect >*/
    MLOG_STEP_CONNECTING,           /*!< connect mqtt server >*/
    MLOG_STEP_CONNECTED,            /*!< subscribe topic, config network success only when it success >*/
    MLOG_STEP_UNKNOWN,
};

/**
 * @brief   The function sets the value of current step.
 * @param[in]   step        [the value of new step]
 */
void mqtt_log_set_step(const int step);

/**
 * @brief   The function sets the error message to s_mqtt_log_buf.
 * @param[in]   format
 * @param[in]   ...
 */
void mqtt_log_set_err_msg(const char *format, ...);

/**
 * @brief   set error message which would be transferred to vasync platform.
 */
#define MQTT_LOG_ERROR(format,...)                              \
    do                                                          \
    {                                                           \
        mqtt_log_set_err_msg(format, ##__VA_ARGS__);            \
    }while(0)

/**
 * @brief   set error message which would be transferred to vasync platform.
 */
#define MQTT_LOG_SET_STEP(step)                             \
    do                                                      \
    {                                                       \
        mqtt_log_set_step(step);                            \
    }while(0)

/**
 * @brief   The function gets the pointer to the error message in s_mqtt_log_buf.
 * @return      const char* [pointer to the error message in s_mqtt_log_buf]
 */
const char* mqtt_log_get_err_msg(void);

#else
#include <stddef.h>

/**
 * @brief   do nothing when disable mqtt log.
 */
#define MQTT_LOG_ERROR(format,...)

/**
 * @brief   do nothing when disable mqtt log.
 */
#define MQTT_LOG_SET_STEP(step)

/**
 * @brief   The function gets the pointer to the error message in s_mqtt_log_buf.
 */
inline const char* mqtt_log_get_err_msg(void)
{
    return NULL;
}

#endif /* MQTT_LOG_ENABLE */

#endif /* __MQTT_LOG_H__ */

