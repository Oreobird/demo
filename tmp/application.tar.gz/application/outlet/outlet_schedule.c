/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        outlet_schedule.c
 * @brief       outlet Schedule 功能
 * @author      Herve Lin
 * @date        2021-06-29
 */
#include <time.h>
#include <string.h>
#include <stdio.h>

#include "outlet.h"
#include "outlet_schedule.h"
#include "outlet_report.h"

#include "vesync_os.h"
#include "vesync_memory.h"
#include "vesync_log.h"
#include "vesync_schedule.h"
#include "vesync_common.h"
#include "vesync_report.h"
#include "vesync_device.h"

#define OUTLET_SCHE_INS_ID 0    // Outlet Schedule实例ID


// Schedule模块任务执行回调
static int outlet_module_exec_cb(vesync_schedule_t sch_cfg, vesync_buf_t app_cfg)
{
    if (app_cfg.len < sizeof(outlet_sche_app_cfg_t))
    {
        return SCHE_ERR;
    }

    outlet_sche_app_cfg_t outlet_cfg;
    vesync_buf_get(&app_cfg, &outlet_cfg, sizeof(outlet_sche_app_cfg_t));

    APP_LOG(LOG_INFO, "Schedule task executes. sche_id:[%ld]\n", sch_cfg.id);

    outlet_ev_t outlet_ev = {
        id: OUTLET_EV_UNKNOWN,
        act_src: OUTLET_ACT_SRC_TASK,
        rsn: STAT_CHG_RSN_SCHD_STR  // 记录开关变化原因
    };

    // Turn On
    if (outlet_cfg.act_on_off)
    {
        outlet_ev.id = OUTLET_EV_ON;
    }
    // Turn Off
    else
    {
        outlet_ev.id = OUTLET_EV_OFF;
    }

    char buf[32] = {0};
    int ret = outlet_app_task_notify(&outlet_ev);
    if (ret != SDK_OK)
    {
        snprintf(buf, sizeof(buf), "OUTLET_EV_ON/OFF notify fail");
    }

    outlet_report_schedule_exec(sch_cfg.id, sch_cfg.type, sch_cfg.repeat_config, &outlet_cfg, ret, buf);
    return SCHE_OK;
}

//////////////////////////////////////////////////////////////
//////////////////  EXTERNAL IMPLEMENTATION //////////////////
//////////////////////////////////////////////////////////////

/**
 * @brief 初始化Schedule功能
 * @return int              [返回APP的错误定义： APP_OK, APP_FAIL]
 */
int outlet_schedule_init(void)
{
    // 初始化Schedule模块
    if (SCHE_OK != vesync_schedule_main_init())
    {
        APP_LOG(LOG_ERROR, "Schedule module init fail\n");

        return APP_FAIL;
    }

    vesync_schedule_param_t schedule_param;
    schedule_param.rd_cfg_cb = NULL;
    schedule_param.wr_cfg_cb = NULL;
    schedule_param.exec_app_task_cb = outlet_module_exec_cb;
    schedule_param.max_app_cfg_size = OUTLET_SCHEDULE_MAX_APP_CFG_SIZE;
    schedule_param.max_sche_nbr = OUTLET_SCHEDULE_MAX_NUM;
    schedule_param.min_id_limit = OUTLET_SCHEDULE_MIN_ID;
    int ret = vesync_schedule_new_instance(OUTLET_SCHE_INS_ID, &schedule_param);
    if (ret != SCHE_OK)
    {
        APP_LOG(LOG_ERROR, "Schedule instance init error: [%ld]\n", ret);

        return APP_FAIL;
    }

    APP_LOG(LOG_INFO, "Schedule initialized\n");
    return APP_OK;
}

/**
 * @brief Bypass添加Schedule配置项
 * @param[in]  p_bp_msg     [Bypass添加的Schedule配置项信息]
 * @param[out] p_out_id     [添加成功后，返回生成的ID]
 * @return int              [返回BYPASS的错误定义]
 */
int outlet_schedule_add(bypass_schedule_base_t *p_bp_msg, uint32_t *p_out_id)
{
    if (NULL == p_bp_msg || NULL == p_out_id)
    {
        return BP_ERR_PARA_ILLEGAL;
    }

    vesync_schedule_t sch_cfg;     // Schedule 模块的配置项定义
    outlet_sche_app_cfg_t app_cfg; // Schedule 应用的配置项定义

    // Enabled 是必选项
    // Repeat Config 是必选项
    // Type 是必选项
    if (NULL == p_bp_msg->enabled ||
        NULL == p_bp_msg->repeat_config ||
        NULL == p_bp_msg->type ||
        NULL == p_bp_msg->json_action)
    {
        return BP_ERR_PARA_ILLEGAL;
    }
    sch_cfg.enabled = (bool)*p_bp_msg->enabled;
    sch_cfg.repeat_config = (uint8_t)*p_bp_msg->repeat_config;

    switch (*p_bp_msg->type)
    {
        case BYPASS_SCHEDULE_JSON_TYPE_TMG_EVT:
            sch_cfg.type = SCHE_TMG_EVT;
            //
            if (NULL == p_bp_msg->clock_sec)
            {
                return BP_ERR_PARA_ILLEGAL;
            }
            sch_cfg.event_config.timing.clock_sec = (uint32_t)*p_bp_msg->clock_sec;
            break;
        case BYPASS_SCHEDULE_JSON_TYPE_SUN_EVT:
            sch_cfg.type = SCHE_SUN_EVT;
            //
            if (NULL == p_bp_msg->is_sunrise)
            {
                return BP_ERR_PARA_ILLEGAL;
            }
            if (NULL == p_bp_msg->offset_sec ||
                *p_bp_msg->offset_sec < -VCOM_SECOND_PER_HR || *p_bp_msg->offset_sec > VCOM_SECOND_PER_HR)
            {
                return BP_ERR_PARA_ILLEGAL;
            }
            sch_cfg.event_config.sun.is_sunrise = (bool)*p_bp_msg->is_sunrise;
            sch_cfg.event_config.sun.offset_sec = (int32_t)*p_bp_msg->offset_sec;
            break;
        default:
            return BP_ERR_PARA_ILLEGAL;
    }

    /**
     * @brief JSON action 定义例子
     * @code
        startAct": [{
            "type": "switch",
            "num": 1,
            "act": "on"
        }],
     * @endcode
     */
    // Outlet Action解析结果：switch
    int arr_size = cJSON_GetArraySize(p_bp_msg->json_action);
    for (int idx = 0; idx < arr_size; idx++)
    {
        cJSON *json_obj = cJSON_GetArrayItem(p_bp_msg->json_action, idx);

        if (NULL == json_obj)
        {
            APP_LOG(LOG_ERROR, "JSON parse error.\n");
            return BP_ERR_PARA_ILLEGAL;
        }

        cJSON *json_type = cJSON_GetObjectItemCaseSensitive(json_obj, "type");
        cJSON *json_act = cJSON_GetObjectItemCaseSensitive(json_obj, "act");
        if(cJSON_IsString(json_type) && cJSON_IsString(json_act))
        {
            if (0 != strcmp(json_type->valuestring, "switch"))
            {
                APP_LOG(LOG_ERROR, "Unknow switch type(%s).\n", json_type->valuestring);
                return BP_ERR_PARA_ILLEGAL;
            }
            //
            if (0 == strcmp(json_act->valuestring, "on"))
            {
                app_cfg.act_on_off = true;
            }
            else if (0 == strcmp(json_act->valuestring, "off"))
            {
                app_cfg.act_on_off = false;
            }
            else
            {
                APP_LOG(LOG_ERROR, "Unknow switch act(%s).\n", json_act->valuestring);
                return BP_ERR_PARA_ILLEGAL;
            }
        }
        else
        {
            APP_LOG(LOG_ERROR, "Type/act section is invaild!\n");
            return BP_ERR_PARA_ILLEGAL;
        }

        cJSON *json_num = cJSON_GetObjectItemCaseSensitive(json_obj, "num");
        if (!cJSON_IsNumber(json_num))
        {
            APP_LOG(LOG_ERROR, "Num section is invaild!\n");
            return BP_ERR_PARA_ILLEGAL;
        }
        //
        if (json_num->valueint < 0 || json_num->valueint > 1)
        {
            APP_LOG(LOG_ERROR, "Num(%d) is invaild!\n", json_num->valueint);
            return BP_ERR_PARA_ILLEGAL;
        }
    }

    // 缓存应用层的配置
    vesync_buf_t app_cfg_buf = vesync_buf_new();
    vesync_buf_set(&app_cfg_buf, (void *)&app_cfg, sizeof(outlet_sche_app_cfg_t));
    // 调用模块的添加Schedule接口；Schedule配置项ID由模块生成
    int ret = vesync_schedule_add(OUTLET_SCHE_INS_ID, &sch_cfg, &app_cfg_buf, true);
    if (ret != SCHE_OK)
    {
        APP_LOG(LOG_WARN, "Schedule added fail: %d\n", ret);

        if (ret == SCHE_CFLT_ERR)
        {
            ret = BP_ERR_SCHEDULE_CONFLICT;
            goto EXIT;
        }
        if (ret == SCHE_EXCEED_MAX)
        {
            ret = BP_ERR_SCHEDULE_EXCEED_MAX;
            goto EXIT;
        }
        ret = BP_ERR_CMD_EXECUTE_FAIL;
        goto EXIT;
    }

    // 添加的配置项ID返回给BP调用端
    *p_out_id = sch_cfg.id;
    ret = BP_ERR_NO_ERR;
EXIT:
    // 销毁缓存
    vesync_buf_clr(&app_cfg_buf);
    return ret;
}

/**
 * @brief Bypass更新Schedule配置项
 * @param[in]  p_bp_msg     [Bypass需要修改的相关Schedule配置项信息，注意有的字段是可选的]
 * @param[out] p_out_id     [更新Schedule配置项后返回对于的配置项ID]
 * @return int              [返回BYPASS的错误定义]
 */
int outlet_schedule_upd(bypass_schedule_base_t *p_bp_msg, uint32_t *p_out_id)
{
    if (NULL == p_bp_msg || NULL == p_out_id)
    {
        return BP_ERR_PARA_ILLEGAL;
    }

    // ID 是必选项
    if (0 == p_bp_msg->id || OUTLET_SCHEDULE_MIN_ID > p_bp_msg->id)
    {
        return BP_ERR_PARA_ILLEGAL;
    }
    uint32_t id = (uint32_t)p_bp_msg->id;

    int ret = BP_ERR_UNDEFINE;
    vesync_schedule_t sch_cfg;
    vesync_buf_t app_cfg_buf = vesync_buf_new();
    // 先把更新前的配置读出来作修改
    ret = vesync_schedule_get_by_id(OUTLET_SCHE_INS_ID, id, &sch_cfg, &app_cfg_buf);
    if (ret != SCHE_OK)
    {
        if (ret != SCHE_INV_ID_ERR)
        {
            ret = BP_ERR_UNDEFINE;
            goto EXIT;
        }

        ret = BP_ERR_SCHEDULE_NOT_FOUND;
        goto EXIT;
    }

    // Enabled 是可选项
    sch_cfg.enabled = (NULL != p_bp_msg->enabled) ? (bool)*p_bp_msg->enabled : sch_cfg.enabled;
    // Repeat Config 是可选项
    sch_cfg.repeat_config = (NULL != p_bp_msg->repeat_config) ? (uint8_t)*p_bp_msg->repeat_config : sch_cfg.repeat_config;

    // Type 是可选项
    if (NULL != p_bp_msg->type)
    {
        switch (*p_bp_msg->type)
        {
            case BYPASS_SCHEDULE_JSON_TYPE_TMG_EVT:
                sch_cfg.type = SCHE_TMG_EVT;
                // Clock Second 是可选字段
                sch_cfg.event_config.timing.clock_sec = (NULL != p_bp_msg->clock_sec) ? (uint32_t)*p_bp_msg->clock_sec : sch_cfg.event_config.timing.clock_sec;
                break;
            case BYPASS_SCHEDULE_JSON_TYPE_SUN_EVT:
                sch_cfg.type = SCHE_SUN_EVT;
                // Is Sunrise 是可选字段
                sch_cfg.event_config.sun.is_sunrise = (NULL != p_bp_msg->is_sunrise) ? (bool)*p_bp_msg->is_sunrise : sch_cfg.event_config.sun.is_sunrise;
                // Offset 是可选字段
                if (NULL != p_bp_msg->offset_sec)
                {
                    if (*p_bp_msg->offset_sec < -VCOM_SECOND_PER_HR || *p_bp_msg->offset_sec > VCOM_SECOND_PER_HR)
                    {
                        ret = BP_ERR_PARA_ILLEGAL;
                        goto EXIT;
                    }
                    else
                    {
                        sch_cfg.event_config.sun.offset_sec = *p_bp_msg->offset_sec;
                    }
                }
                else
                {
                    sch_cfg.event_config.sun.offset_sec = sch_cfg.event_config.sun.offset_sec;
                }
                break;
            default:
                ret = BP_ERR_PARA_ILLEGAL;
                goto EXIT;
        }
    }

    if (NULL != p_bp_msg->json_action)
    {
        outlet_sche_app_cfg_t app_cfg;
        int arr_size = cJSON_GetArraySize(p_bp_msg->json_action);
        for (int idx = 0; idx < arr_size; idx++)
        {
            cJSON *json_obj = cJSON_GetArrayItem(p_bp_msg->json_action, idx);

            if (NULL == json_obj)
            {
                APP_LOG(LOG_ERROR, "JSON parse error.\n");
                ret = BP_ERR_PARA_ILLEGAL;
                goto EXIT;
            }

            cJSON *json_type = cJSON_GetObjectItemCaseSensitive(json_obj, "type");
            cJSON *json_act = cJSON_GetObjectItemCaseSensitive(json_obj, "act");
            if(cJSON_IsString(json_type) && cJSON_IsString(json_act))
            {
                if (0 != strcmp(json_type->valuestring, "switch"))
                {
                    APP_LOG(LOG_ERROR, "Unknow switch type(%s).\n", json_type->valuestring);
                    ret = BP_ERR_PARA_ILLEGAL;
                    goto EXIT;
                }
                //
                if (0 == strcmp(json_act->valuestring, "on"))
                {
                    app_cfg.act_on_off = true;
                }
                else if (0 == strcmp(json_act->valuestring, "off"))
                {
                    app_cfg.act_on_off = false;
                }
                else
                {
                    APP_LOG(LOG_ERROR, "Unknow switch act(%s).\n", json_act->valuestring);
                    ret = BP_ERR_PARA_ILLEGAL;
                    goto EXIT;
                }
            }
            else
            {
                APP_LOG(LOG_ERROR, "Type/act section is invaild!\n");
                ret = BP_ERR_PARA_ILLEGAL;
                goto EXIT;
            }

            cJSON *json_num = cJSON_GetObjectItemCaseSensitive(json_obj, "num");
            if (!cJSON_IsNumber(json_num))
            {
                APP_LOG(LOG_ERROR, "Num section is invaild!\n");
                ret = BP_ERR_PARA_ILLEGAL;
                goto EXIT;
            }
            //
            if (json_num->valueint < 0 || json_num->valueint > 1)
            {
                APP_LOG(LOG_ERROR, "Num(%d) is invaild!\n", json_num->valueint);
                ret = BP_ERR_PARA_ILLEGAL;
                goto EXIT;
            }
        }

        // APP配置直接覆盖处理
        vesync_buf_set(&app_cfg_buf, &app_cfg, sizeof(app_cfg));
    }

    ret = vesync_schedule_upd(OUTLET_SCHE_INS_ID, &sch_cfg, &app_cfg_buf);
    if (ret != SCHE_OK)
    {
        if (ret != SCHE_CFLT_ERR)
        {
            ret = BP_ERR_UNDEFINE;
            goto EXIT;
        }
        ret = BP_ERR_SCHEDULE_CONFLICT;
        goto EXIT;
    }

    // 操作的配置项ID返回给BP调用端
    *p_out_id = sch_cfg.id;
    ret = BP_ERR_NO_ERR;
EXIT:
    // 销毁APP配置缓存
    vesync_buf_clr(&app_cfg_buf);
    return ret;
}

/**
 * @brief Bypass按顺序获取Schedule多个配置项
 * @note  返回多少个连续的配置项是由Schedule模块决定
 * @param[in]  index        [要获取的Schedule配置项的初始序号]
 * @param[in]  p_buf        [用于读取Schedule配置项的缓存，函数内会作缓存的分配,调用结束后需要释放]
 * @param[out] p_out_list   [指向输出读取结果的列表]
 * @param[in]  total_num    [配置项总数]
 * @return int              [返回BYPASS的错误定义]
 */
int outlet_schedule_get_mult(uint32_t index, void **p_buf, bypass_schedule_base_t *p_out_list, uint32_t *total_num)
{
    if (NULL == p_buf || NULL == p_out_list)
    {
        return BP_ERR_PARA_ILLEGAL;
    }

    *p_buf = vesync_malloc(OUTLET_SCHEDULE_GET_MAX_NUM * sizeof(vesync_schedule_t));
    if (NULL == *p_buf)
    {
        return BP_ERR_UNDEFINE;
    }
    // Schedule 模块配置读取Buffer
    vesync_schedule_t *p_sch_cfg = (vesync_schedule_t *)*p_buf;
    // Schedule 模块配置读取数量
    uint32_t sch_cfg_num = 0;

    vesync_buf_t app_cfg_buf[OUTLET_SCHEDULE_GET_MAX_NUM];
    // APP配置读取缓存初始化
    for (uint32_t i = 0; i < OUTLET_SCHEDULE_GET_MAX_NUM; i++)
    {
        app_cfg_buf[i] = vesync_buf_new();
    }

    int ret = vesync_schedule_get_by_index(OUTLET_SCHE_INS_ID, index, OUTLET_SCHEDULE_GET_MAX_NUM, total_num, p_sch_cfg, app_cfg_buf, &sch_cfg_num);
    if (ret != SCHE_OK)
    {
        if (ret == SCHE_INV_IDX_ERR)
        {
            ret = BP_ERR_SCHEDULE_NOT_FOUND;
            goto EXIT;
        }

        ret = BP_ERR_UNDEFINE;
        goto EXIT;
    }

    for (uint32_t cnt = 0; cnt < sch_cfg_num; cnt ++)
    {
        p_out_list[cnt].id = p_sch_cfg[cnt].id;

        // 读取应用层的配置
        if (app_cfg_buf[cnt].len > sizeof(outlet_sche_app_cfg_t))
        {
            ret = BP_ERR_UNDEFINE;
            goto EXIT_DEL_JSON;
        }
        outlet_sche_app_cfg_t app_cfg;
        vesync_buf_get(&app_cfg_buf[cnt], &app_cfg, sizeof(app_cfg));

        // startAct JSON Section
        cJSON *json_sch_act = cJSON_CreateArray();
        cJSON *json_sch_switch = cJSON_CreateObject();
        if ((NULL != json_sch_switch) && (NULL != json_sch_act))
        {
            cJSON_AddStringToObject(json_sch_switch, "type", "switch");
            cJSON_AddNumberToObject(json_sch_switch, "num", 0);

            if (app_cfg.act_on_off)
            {
                cJSON_AddStringToObject(json_sch_switch, "act", "on");
            }
            else
            {
                cJSON_AddStringToObject(json_sch_switch, "act", "off");
            }

            cJSON_AddItemToArray(json_sch_act, json_sch_switch);
        }
        else
        {
            APP_LOG(LOG_ERROR, "JSON creates fail.\n");

            cJSON_Delete(json_sch_act);
            cJSON_Delete(json_sch_switch);

            ret = BP_ERR_UNDEFINE;
            goto EXIT_DEL_JSON;
        }
        //
        p_out_list[cnt].json_action = json_sch_act;
        //
        p_out_list[cnt].enabled = (int32_t *)&p_sch_cfg[cnt].enabled;

        if (p_sch_cfg[cnt].type == SCHE_TMG_EVT)
        {
            p_sch_cfg[cnt].type = BYPASS_SCHEDULE_JSON_TYPE_TMG_EVT;
            p_out_list[cnt].clock_sec = (int32_t *)&p_sch_cfg[cnt].event_config.timing.clock_sec;
        }
        else if (p_sch_cfg[cnt].type == SCHE_SUN_EVT)
        {
            p_sch_cfg[cnt].type = BYPASS_SCHEDULE_JSON_TYPE_SUN_EVT;
            p_out_list[cnt].is_sunrise = (int32_t *)&p_sch_cfg[cnt].event_config.sun.is_sunrise;
            p_out_list[cnt].offset_sec = (int32_t *)&p_sch_cfg[cnt].event_config.sun.offset_sec;
        }
        else
        {
            ret = BP_ERR_UNDEFINE;

            goto EXIT_DEL_JSON;
        }
        // Type 处理
        p_out_list[cnt].type = (int32_t *)&p_sch_cfg[cnt].type;

        p_out_list[cnt].repeat_config = (int32_t *)&p_sch_cfg[cnt].repeat_config;
    }

    ret = BP_ERR_NO_ERR;

EXIT:
    // 销毁APP配置读取缓存
    for (uint32_t i = 0; i < OUTLET_SCHEDULE_GET_MAX_NUM; i++)
    {
        vesync_buf_clr(&app_cfg_buf[i]);
    }
    return ret;

EXIT_DEL_JSON:
    for (uint32_t i = 0; i < OUTLET_SCHEDULE_GET_MAX_NUM; i++)
    {
        vesync_buf_clr(&app_cfg_buf[i]);
    }

    for (uint32_t cnt = 0; cnt < sch_cfg_num; cnt ++)
    {
        cJSON_Delete((cJSON *)p_out_list[cnt].json_action);
    }
    return ret;
}

/**
 * @brief Bypass删除指定ID的Schedule配置项
 * @param[in]  id_to_del    [要删除的Schedule配置项ID]
 * @return int              [返回BYPASS的错误定义]
 */
int outlet_schedule_del(uint32_t id_to_del)
{
    int ret = vesync_schedule_del(OUTLET_SCHE_INS_ID, id_to_del);
    if (ret != 0)
    {
        if (ret != SCHE_INV_ID_ERR)
        {
            return BP_ERR_UNDEFINE;
        }
        return BP_ERR_SCHEDULE_NOT_FOUND;
    }

    return BP_ERR_NO_ERR;
}

/**
 * @brief App层调用，复位Schedule的所有配置信息
 * @return int              [返回APP的错误定义： APP_OK, APP_FAIL]
 */
int outlet_schedule_clear(void)
{
    vesync_schedule_clear(OUTLET_SCHE_INS_ID);

    return APP_OK;
}
