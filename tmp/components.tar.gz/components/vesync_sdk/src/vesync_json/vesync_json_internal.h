/*
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file        vesync_json_internal.h
* @brief       json数据处理接口
* @date        2021-05-17
*/
#ifndef __VESYNC_JSON_INTERNAL_H__
#define __VESYNC_JSON_INTERNAL_H__

#include <stdint.h>
#include "cJSON.h"

#ifdef __cplusplus
extern "C" {
#endif


/**
* @brief 获取cjson的number数据
* @param[in] json                     [cjson格式的数据]
* @param[in] key                      [名称]
* @param[out] val                     [数据]
* @return int                         [成功/失败]
*/
int vesync_json_get_number(cJSON *json, const char *key, int *val);

/**
* @brief 获取cjson的str数据
* @param[in] json                     [cjson格式的数据]
* @param[in] key                      [名称]
* @param[out] val                     [数据]
* @return int                         [成功/失败]
*/
int vesync_json_get_string(cJSON *json, const char *key, char **val);

/**
* @brief 获取cjson的obj
* @param[in] json                     [cjson格式的数据]
* @param[in] key                      [名称]
* @param[out] val                     [数据]
* @return int                         [成功/失败]
*/
int vesync_json_get_obj(cJSON *json, const char *key, cJSON **val);



/**
* @brief 直接按照标准缩进格式打印cjson数据，内部实现转换
* @param[in] json                     [cjson格式的数据]
*/
void vesync_json_print(cJSON *json);

#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_JSON_INTERNAL_H__ */


