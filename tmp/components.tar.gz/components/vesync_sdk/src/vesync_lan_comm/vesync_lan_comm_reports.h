/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_lan_comm_reports.h
 * @brief       局域网通信状态更新接口头文件
 * @author      henrikzhou
 * @date        2020-10-21
 */

#ifndef  _VESYNC_LAN_COMM_REPORTS_H_
#define  _VESYNC_LAN_COMM_REPORTS_H_

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief 局域网状态更新通知
 * @return int      [SDK_OK：成功/SDK_FAIL：失败]
 */
int  vesync_lan_comm_status_report(void);


/**
 * @brief 局域网设备离线通知
 * @return int      [SDK_OK：成功/SDK_FAIL：失败]
 */
int  vesync_lan_comm_offline_report(void);

#ifdef __cplusplus
}
#endif

#endif //_VESYNC_LAN_COMM_REPORTS_H_
