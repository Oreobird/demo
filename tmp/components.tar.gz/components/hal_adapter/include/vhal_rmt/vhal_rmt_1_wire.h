/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file    vhal_rmt_1_wire.h
* @brief   rmt接口
* @author  Lind
* @date     2021-11-04
*/


#ifndef __VHAL_RMT_1_WIRE_H__
#define __VHAL_RMT_1_WIRE_H__

#include <stdbool.h>

#include "vhal_rmt.h"

#ifdef __cplusplus
extern "C"
{
#endif

/**
 * @brief rmt发送配置结构体
 */
typedef struct
{
    uint8_t  rmt_tx_gpio;           // 发送io
    uint8_t  clk_div;               // 时钟分频
    uint16_t pixel_data_len;        // 节点数据长度/字节
    uint16_t pixel_num;             // 节点数目
    RMT_IDLE_LEVEL_E idle_level;    // 空闲电平
    // 默认rmt输出脉冲波形：先高电平后低电平
    uint32_t T0H_NS;                // logic0第1个电平时间/ns
    uint32_t T0L_NS;                // logic0第2个电平时间/ns
    uint32_t T1H_NS;                // logic1第1个电平时间/ns
    uint32_t T1L_NS;                // logic1第2个电平时间/ns
} one_wire_tx_cfg_t;


/**
 * @brief 发送自定义信号配置
 */
typedef struct
{
    bool beginning_flag;            // 是否有传输开始信号
    bool end_flag;                  // 是否有传输结束信号
    rmt_item_t beginning_marker;    // 开启信号波形
    rmt_item_t end_marker;          // 结束信号波形
    rmt_item_t logic0;              // 数据 0 波形
    rmt_item_t logic1;              // 数据 1 波形
} one_wire_tx_signal_t;

/**
 * @brief 自定义波形发送接口
 * @param[in] *p_buf                [有效数据buffer]
 * @param[in] bit_len               [数据bit长度/位]
 * @param[in] signal_sample         [信号配置]
 * @param[in] wait_tx_done          [是否阻塞等待发送完成]
 * @return  int                     [VAHL_OK/VHAL_FAIL]
 */
int vhal_1_wire_send_bits(uint8_t *p_buf, uint32_t bit_len, one_wire_tx_signal_t signal_sample, bool wait_tx_done);

/**
 * @brief 设置节点参数（不会实时发送），可设置连读的多个节点
 * @param[in]  begin_pos        [起始设置节点，0为第1个]
 * @param[in]  *p_buf           [数据buffer]
 * @param[in]  buf_len          [数据长度/字节]
 * @return  int                 [VAHL_OK/VHAL_FAIL]
 */
int vhal_1_wire_tx_set_pixels(uint32_t begin_pos, uint8_t *p_buf, uint32_t buf_len);

/**
 * @brief 发送数据
 * @param[in]  timeout_ms      [超时时间]
 * @return  int                [VAHL_OK/VHAL_FAIL]
 */
int vhal_1_wire_tx_refresh(uint32_t timeout_ms);

/**
 * @brief 清0发送buffer
 * @param[in]  timeout_ms      [发送超时时间，为0则表示不发送]
 * @return  int                [VAHL_OK/VHAL_FAIL]
 */
int vhal_1_wire_tx_clear(uint32_t timeout_ms);

/**
 * @brief 发送初始化
 * @param[in]  *p_tx_cfg       [rmt发送初始化结构体]
 * @return  int                [VAHL_OK/VHAL_FAIL]
 */
int vhal_1_wire_tx_init(one_wire_tx_cfg_t *p_tx_cfg);

/**
 * @brief 卸载rmt发送功能
 */
void vhal_1_wire_tx_deinit(void);


#ifdef __cplusplus
}
#endif

#endif /* __VHAL_RMT_1_WIRE_H__ */

