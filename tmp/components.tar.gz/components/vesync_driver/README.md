### Vesync第三方硬件外设驱动

#### 简介
Vesync第三方硬件外设驱动（以下简称`Vesync driver`）向下调用`Vesync HAL`层提供的芯片外设接口，实现了第三方硬件例如温度传感器、湿度传感器或者段数码管驱动器等驱动逻辑，向上暴露了各个外设的公共接口给应用层调用。

#### 开发者调用Vesync driver下的组件
开发者需要在`Product Config`使能相关的`VESYNC_DRV_XXX_ENABLE`宏。

#### 开发者给Vesync driver添加组件
开发者在添加`Vesync driver`组件的时候有两个要注意的地方：
+ 要为GNU Make的构建方式编译脚本导入，也就是在当前目录下的`vesync.mk`中添加相应组件的头文件和源代码文件。
+ 要为CMake的构建方式编译脚本导入，也就是在项目工程目录下的`make/scripts/cmake/prph_driver.cmake`中添加相应组件的头文件和源代码文件。