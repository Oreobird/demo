/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_uart_private.h
 * @brief       串口私有头文件
 * @author      Louis
 * @date        2021-11-19
 */


#ifndef __VESYNC_UART_PRIVATE_H__
#define __VESYNC_UART_PRIVATE_H__


#include "vesync_uart_internal.h"


#ifdef __cplusplus
extern "C"
{
#endif /* __cplusplus */


#define VESYNC_UART_NUM                 (PR_UART_NUM_MAX)

#define VESYNC_UART_TASK_NAME            "vesync_uart_task"
#define VESYNC_UART_TASK_STACSIZE        (PR_UART_TASK_STACSIZE)
#define VESYNC_UART_TASK_PRIO            TASK_PRIORITY_NORMAL

#define VESYNC_UART_SEND_ACK_QUEUE_MAX_NUM          (10)
#define VESYNC_UART_SEND_CMD_QUEUE_MAX_NUM          (20)
#define VESYNC_UART_RECV_QUEUE_MAX_NUM              (10)


#define VESYNC_PROTOCO_VERSION          (2)
#define VESYNC_PROTOCO_HEAD_LEN         (6)


#define VESYNC_SEND_REPEAT_MAX_CNT      (vesync_cfg_get_uart_resend_cnt())
#define VESYNC_SEND_REQUEST_TIMEOUT     (vesync_cfg_get_uart_send_timeout_ms())

#define VESYNC_FRAME_PAYLOAD_MAX_LEN    (vesync_cfg_get_uart_payload_max_len())


#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* __VESYNC_UART_PRIVATE_H__ */

