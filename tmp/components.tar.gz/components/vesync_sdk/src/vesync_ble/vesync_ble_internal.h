/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_ble_internal.h
 * @brief       BLE模块接口
 * @author      Louis
 * @date        2021-07-21
 */

#ifndef __VESYNC_BLE_INTERNAL_H__
#define __VESYNC_BLE_INTERNAL_H__

#include "vesync_task.h"
#include "vesync_ble.h"

#ifdef __cplusplus
extern "C" {
#endif


/**
 * @brief  数据类型，发送还是接收
 */
typedef enum
{
    BLE_DATA_TYPE_SEND,
    BLE_DATA_TYPE_RECV
}BLE_DATA_TYPE_E;

/**
 * @brief  数据通道
 */
typedef enum
{
    BLE_DATA_CHAN_CMD,
    BLE_DATA_CHAN_NETCFG,
    BLE_DATA_CHAN_MAX
}BLE_DATA_CHAN_E;

/**
 * @brief  入队数据头部
 */
#pragma pack(1)
typedef struct
{
    BLE_DATA_TYPE_E type;
    BLE_DATA_CHAN_E chan;
    uint16_t  len;
    uint8_t  *p_data;
}vesync_ble_data_t;
#pragma pack()

/**
 * @brief  CMD通道复用器分发Vesync Frame透传数据的回调函数
 * @param[in]   p_data          [Vesync Frame中的透传数据]
 * @param[in]   len             [透传数据长度]
 * @param[in]   need_ack        [是否需要应答]
 * @return      bool            [消息是否被接收者消费]
 */
typedef bool (*vesync_ble_mux_rx_cb_t)(uint8_t *p_data, uint16_t len, bool need_ack);

/**
 * @brief BLE模块初始化
 * @return  int32_t         [成功：SDK_OK，失败：SDK_FAIL]
 */
int32_t vesync_ble_init(void);

/**
 * @brief  BLE收发模块是否已经初始化
 * @return     bool             [true/false]
 */
bool vesync_ble_is_init(void);

/**
 * @brief  释放信号量，通知收发任务处理
 * @return     int32_t          [SDK_OK/SDK_FAIL]
 */
int32_t vesync_ble_sem_signal(void);

/**
 * @brief  BLE模块发送初始化
 * @return     int32_t          [SDK_OK/SDK_FAIL]
 */
int32_t vesync_ble_send_init(void);

/**
 * @brief  BLE模块发送退出
 */
void vesync_ble_send_deinit(void);

/**
 * @brief  从发送队列中取出数据，然后调用vhal接口发送出去
 * @note   数据处理优先级：ACK数据、无需对端回复的数据、需要对端回复的数据
 */
int32_t vesync_ble_parse_send_data(void);

/**
 * @brief 添加超时重发定时器
 */
void vesync_ble_add_send_timeout_timer(void);

/**
 * @brief 删除超时重发定时器
 */
void vesync_ble_del_send_timeout_timer(void);

/**
 * @brief 处理已经超时的定时器
 * @return    uint64_t      [下一个即将超时定时器的时间ms]
 */
uint64_t vesync_ble_process_expired_timer(void);

/**
 * @brief  获取发送的sequence id
 * @param[in]  chan                [数据通道]
 * @return     uint8_t             [sequence id]
 */
uint8_t vesync_ble_get_send_seq_id(BLE_DATA_CHAN_E chan);

/**
 * @brief  BLE模块接收初始化
 * @return     int32_t          [SDK_OK/SDK_FAIL]
 */
int32_t vesync_ble_recv_init(void);

/**
 * @brief  BLE模块接收退出
 */
void vesync_ble_recv_deinit(void);

/**
 * @brief  从接收队列中取出数据包进行处理，并回调给上层
 * @return     int32_t          [SDK_OK/SDK_FAIL]
 */
int32_t vesync_ble_parse_recv_data(void);

/**
 * @brief  获取收包的sequence id
 * @param[in]  chan             [数据通道]
 * @return     int8_t           [sequence id]
 */
uint8_t vesync_ble_get_recv_seq_id(BLE_DATA_CHAN_E chan);


/**
 * @brief  发送NETCFG数据
 * @param[in]  p_data       [数据指针]
 * @param[in]  len          [数据长度]
 * @param[in]  req_flag     [是否需要对端回复]
 * @return  int32_t         [成功：SDK_OK，失败：SDK_FAIL]
 */
int32_t vesync_ble_send_netcfg_data(uint8_t *p_data , uint16_t len, uint8_t req_flag);


/**
 * @brief  发送NETCFG ACK
 * @param[in]  p_data       [数据指针]
 * @param[in]  len          [数据长度]
 * @param[in]  err_flag     [错误码]
 * @return  int32_t         [成功：SDK_OK，失败：SDK_FAIL]
 */
int32_t vesync_ble_send_netcfg_ack(uint8_t *p_data , uint16_t len, uint8_t err_flag);


/**
 * @brief  注册配网数据接收的回调函数
 * @param[in]  cb               [配网数据接收的回调函数]
 */
void vesync_ble_reg_netcfg_recv_cb(vesync_ble_data_recv_cb_t cb);

/**
 * @brief  注册接收配网数据发送结果的回调函数
 * @param[in]  cb          [配网数据发送结果的回调函数]
 */
void vesync_ble_reg_netcfg_evt_cb(vesync_ble_evt_cb_t cb);

/**
 * @brief  更新配网状态到BLE广播
 * @param[in]  status_info  [配网状态]
 * @return  int32_t         [成功：SDK_OK，失败：SDK_FAIL]
 */
int32_t vesync_ble_adv_update_netcfg_status(uint8_t status_info);

/**
 * @brief 初始化BLE模块CMD通道复用器
 * @return      int32_t         [成功：SDK_OK，失败：SDK_FAIL]
 */
int32_t vesync_ble_muxer_init(void);

/**
 * @brief 给CMD通道复用器增加一个接收者
 * @param[in]   rxer            [接收者]
 * @return      int32_t         [成功：SDK_OK，失败：SDK_FAIL]
 */
int32_t vesync_ble_muxer_add_rxer(vesync_ble_mux_rx_cb_t rxer);

/**
 * @brief 移除CMD通道复用器的一个接收者
 * @param[in]   rxer            [接收者]
 * @return      int32_t         [成功：SDK_OK，失败：SDK_FAIL]
 */
int32_t vesync_ble_muxer_rm_rxer(vesync_ble_mux_rx_cb_t rxer);

/**
 * @brief BLE模块CMD通道复用器的数据接收回调
 * @param[in]   p_data          [蓝牙CMD通道透传过来的数据]
 * @param[in]   len             [数据长度]
 * @param[in]   need_ack        [是否需要回应]
 */
void vesync_ble_muxer_rx_cb(uint8_t *p_data, uint16_t len, bool need_ack);

#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_BLE_INTERNAL_H__ */