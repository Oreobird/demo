/**
 *  Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vhal_flash.c
 * @brief       乐鑫平台nvs-flash读写驱动接口封装
 * @author      Dongri.Su
 * @date        2021-04-23
 */

#include "nvs_flash.h"

#include "vesync_log.h"
#include "vesync_common.h"

#include "vhal_flash.h"
#include "vhal_flash_internal.h"



/*-----------------------------------------------------------------------------*
 *                           内部函数API实现                                         *
 *-----------------------------------------------------------------------------*/
/**
 * @brief  NVS flash分区名映射
 * @param[in]  partition_id             [分区的ID]
 * @return     char*                    [字符串格式的分区名称]
 * @note  分区的名称对应分区表的名字
 */
static char *vhal_nvs_flash_conv_name(PARTITION_ID_E partition_id)
{
    if (partition_id <= PARTITION_MIN || partition_id >= PARTITION_MAX)
    {
        HAL_LOG(LOG_ERROR, "Invalid partition ID(%d)!\n", partition_id);
        return NULL;
    }

    switch (partition_id)
    {
        case PARTITION_DEFAULT:
            return VHAL_ESP_DEFAULT_NVS_NAMESPACE;
        case PARTITION_FAC:
            return VHAL_ESP_FAC_DATA_NAMESPACE;
        case PARTITION_CFG:
            return VHAL_ESP_USER_CFG_NAMESPACE;
        case PARTITION_DATA:
            return VHAL_ESP_DATA_CFG_NAMESPACE;
        case PARTITION_LOG:
            return VHAL_ESP_LOG_NAMESPACE;
        default:
            break;
    }

    return NULL;
}

/*-----------------------------------------------------------------------------*
 *                           外部函数API实现                                         *
 *-----------------------------------------------------------------------------*/

/**
 * @brief  flash初始化
 * @param[in]  part_id              [分区ID]
 * @return     int32_t              [错误码]
 */
int32_t vhal_flash_init(PARTITION_ID_E part_id)
{
    esp_err_t err;

    if (PARTITION_DEFAULT == part_id)
    {   // 初始化默认NVS分区
        err = nvs_flash_init();
        if (err == ESP_ERR_NVS_NO_FREE_PAGES /*|| err == ESP_ERR_NVS_NEW_VERSION_FOUND*/)
        {
            // NVS partition was truncated and needs to be erased
            // Retry nvs_flash_init
            ESP_ERROR_CHECK(nvs_flash_erase());
            err = nvs_flash_init();
        }
    }
    else
    {   // 初始化自定义NVS分区
        err = nvs_flash_init_partition(vhal_nvs_flash_conv_name(part_id));
        if (err == ESP_ERR_NVS_NO_FREE_PAGES /*|| err == ESP_ERR_NVS_NEW_VERSION_FOUND*/)
        {
            // NVS partition was truncated and needs to be erased
            // Retry nvs_flash_init
            ESP_ERROR_CHECK(nvs_flash_erase());
            err = nvs_flash_init_partition(vhal_nvs_flash_conv_name(part_id));
        }
    }

    //ESP_ERROR_CHECK(err);
    if (ESP_OK != err)
    {
        return VHAL_FAIL;
    }

    return VHAL_OK;
}

/**
 * @brief  从flash读取数据
 * @param[in]  part_id              [分区ID]
 * @param[in]  key_name             [键值名称]
 * @param[in]  p_data               [读取数据缓存区；如果该读取Buffer为NULL，则返回该数据的长度]
 * @param[in]  p_len                [当前读取的数据长度]
 * @return  int32_t                 [成功：VHAL_OK，失败：VHAL_FAIL]
 */
int32_t vhal_flash_read(PARTITION_ID_E part_id, const char *key_name, uint8_t *p_data, uint32_t *p_len)
{
    nvs_handle handle;
    esp_err_t err;
    size_t length = 0;

    if (NULL == key_name || NULL == p_len || NULL == vhal_nvs_flash_conv_name(part_id))
    {
        HAL_LOG(LOG_ERROR, "Null ptr!\n");
        return VHAL_FAIL;
    }

    // 1.打开分区表
    if (PARTITION_DEFAULT == part_id)
    {
        err = nvs_open(NVS_DEFAULT_PART_NAME, NVS_READONLY, &handle);   // 打开默认分区表
    }
    else
    {
        err = nvs_open_from_partition(vhal_nvs_flash_conv_name(part_id), key_name, NVS_READONLY, &handle);  // 打开自定义分区表
        //err = nvs_open(part_name, NVS_READONLY, &handle);
    }

    if (ESP_OK != err)
    {
        // 注意，该处打印级别设置为debug，避免release固件上电也打印过多没必要的错误信息
        HAL_LOG(LOG_DEBUG, "Error opening (%s:%s) partition NVS handle, err: %s!\n",
                vhal_nvs_flash_conv_name(part_id), key_name, esp_err_to_name(err));
        return VHAL_FAIL;
    }

    // 2.获取键对应内容
    *p_len = 0;
    err = nvs_get_blob(handle, key_name, NULL, &length);
    if (err == ESP_OK)
    {
        if (p_data)
        {
            err |= nvs_get_blob(handle, key_name, p_data, &length);
            if (err != ESP_OK)
            {
                nvs_close(handle);
                HAL_LOG(LOG_ERROR, "Error nvs get blob, err: %s\n", esp_err_to_name(err));
                return VHAL_FAIL;
            }
        }

        *p_len = length;
    }
//    if (err != ESP_OK && err != ESP_ERR_NVS_NOT_FOUND) return err;

    // 3.关闭
    nvs_close(handle);

    return VHAL_OK;
}

/**
 * @brief  往flash写入数据
 * @param[in]  part_id              [分区ID]
 * @param[in]  key_name             [键值名称]
 * @param[in]  p_data               [写入的数据]
 * @param[in]  len                  [写入数据的长度]
 * @return     int32_t              [0表示写入成功，非0表示写入失败]
 */
int32_t vhal_flash_write(PARTITION_ID_E part_id, const char *key_name, uint8_t *p_data, uint32_t len)
{
    nvs_handle handle;
    esp_err_t err;

    if (NULL == key_name || NULL == p_data || NULL == vhal_nvs_flash_conv_name(part_id))
    {
        HAL_LOG(LOG_ERROR, "Input parameters contain null pointers!\n");
        return VHAL_FAIL;
    }

    // 1.打开分区表
    if (PARTITION_DEFAULT == part_id)
    {
        err = nvs_open(NVS_DEFAULT_PART_NAME, NVS_READWRITE, &handle);  // 打开默认分区表
    }
    else
    {
        err = nvs_open_from_partition(vhal_nvs_flash_conv_name(part_id), key_name, NVS_READWRITE, &handle); // 打开自定义分区表
        //err = nvs_open(part_name, NVS_READWRITE, &handle);
    }

    if (ESP_OK != err)
    {
        HAL_LOG(LOG_ERROR, "Error opening (%s:%s) partition NVS handle, err: %s!\n",
                vhal_nvs_flash_conv_name(part_id), key_name, esp_err_to_name(err));
        return VHAL_FAIL;
    }

    // 2.写入
    err = nvs_set_blob(handle, key_name, p_data, len);
    if (ESP_OK != err)
    {
        HAL_LOG(LOG_ERROR, "Error NVS set blob handle, err: %s!\n", esp_err_to_name(err));
        nvs_close(handle);
        return VHAL_FAIL;
    }

    // 3.写成功后保存
    err = nvs_commit(handle);
    if (ESP_OK != err )
    {
        HAL_LOG(LOG_ERROR, "Error NVS commit handle, err: %s!\n", esp_err_to_name(err));
        nvs_close(handle);
        return VHAL_FAIL;
    }

    // 4.关闭
    nvs_close(handle);

    return VHAL_OK;
}

/**
 * @brief  擦除指定分区
 * @param[in]  part_id              [分区ID]
 * @return     int32_t              [0表示擦除成功，非0表示擦除失败]
 */
int32_t vhal_flash_erase(PARTITION_ID_E part_id)
{
    esp_err_t err;

    if (NULL == vhal_nvs_flash_conv_name(part_id))
    {
        HAL_LOG(LOG_ERROR, "Null ptr!\n");
        return VHAL_FAIL;
    }

    // 1.擦除区表
    if (PARTITION_DEFAULT == part_id)
    {
        err = nvs_flash_erase();
    }
    else
    {
        err = nvs_flash_erase_partition(vhal_nvs_flash_conv_name(part_id));
    }

    if (ESP_OK != err)
    {
        HAL_LOG(LOG_ERROR, "Error NVS flash earse (%s) partition fail, err: %s!\n", vhal_nvs_flash_conv_name(part_id), esp_err_to_name(err));
        return VHAL_FAIL;
    }

    return  VHAL_OK;
}

/**
 * @brief  擦除指定分区中的指定键值对
 * @param[in]  part_id              [分区ID]
 * @param[in]  key_name             [键值名称]
 * @return     int32_t              [0表示擦除成功，非0表示擦除失败]
 */
int32_t vhal_flash_erase_key(PARTITION_ID_E part_id, const char *key_name)
{
    esp_err_t err =0;
    nvs_handle handle;

    if (NULL == vhal_nvs_flash_conv_name(part_id))
    {
        HAL_LOG(LOG_ERROR, "Null ptr!\n");
        return VHAL_FAIL;
    }

    // 1.打开分区表
    if (PARTITION_DEFAULT == part_id)
    {
        err = nvs_open(NVS_DEFAULT_PART_NAME, NVS_READWRITE, &handle);//打开默认分区表
    }
    else
    {
        err = nvs_open_from_partition(vhal_nvs_flash_conv_name(part_id), key_name, NVS_READWRITE, &handle);
    }

    if(err != ESP_OK)
    {
        HAL_LOG(LOG_ERROR, "NVS open partition fail, err:%s!\n", esp_err_to_name(err));
        return VHAL_FAIL;
    }

    // 2. 删除指定的key
    err = nvs_erase_key(handle, key_name);
    if(err != ESP_OK)
    {
        nvs_close(handle);
        HAL_LOG(LOG_ERROR, "NVS erase key(%s) fail, err:%s!\n", key_name, esp_err_to_name(err));
        return VHAL_FAIL;
    }

    // 3.保存
    err = nvs_commit(handle);
    if(err != ESP_OK)
    {
        nvs_close(handle);
        HAL_LOG(LOG_ERROR, "NVS erase key(%s) fail, err:%s!\n", key_name, esp_err_to_name(err));
        return VHAL_FAIL;
    }

    // 4.关闭
    nvs_close(handle);

    return VHAL_OK;
}


