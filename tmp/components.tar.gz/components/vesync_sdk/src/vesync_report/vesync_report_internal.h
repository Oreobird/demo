/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_report_internal.h
 * @brief       report模块接口定义
 * @date        2021-05-18
 */

#ifndef __VESYNC_REPORT_INTERNAL_H__
#define __VESYNC_REPORT_INTERNAL_H__

#include <stdint.h>

#include "cJSON.h"
#include "vesync_report.h"
#include "vesync_device.h"
#include "vesync_net_service_internal.h"
#include "vesync_timer.h"
#if CONFIG_VESYNC_SDK_PRODUCTION_ENABLE
#include "vesync_production_internal.h"
#endif /* CONFIG_VESYNC_SDK_PRODUCTION_ENABLE */

#if CONFIG_VESYNC_SDK_FFS_ENABLE
#include "ffs_certificate.h"
#endif

#ifdef __cplusplus
extern "C" {
#endif

#define MAX_TRACEID_LEN         (32)

/**
* @brief 获取traceid函数
*/
typedef void (*get_traceid_t)(char *p_traceID, int buf_len);

/**
* @brief 上报云函数，包含qos
*/
typedef int (*report_cloud_qos_t)(NET_DATA_TOPIC_TYPE_E topic_type, const char *method,
                                      cJSON *json_data, REPORT_CAUSE_E cause, SEND_QOS_E qos, void* puback_cb);

/**
* @brief 上报云函数
*/
typedef int (*report_cloud_t)(NET_DATA_TOPIC_TYPE_E topic_type, const char *method, cJSON *json_data, REPORT_CAUSE_E cause);

/**
* @brief 添加协议头函数
*/
typedef cJSON *(*json_add_method_head_t)(char *trace_id, char *method, cJSON *p_data, REPORT_CAUSE_E cause);

/**
* @brief 获取重连数据函数
*/
typedef void (*get_reconn_data_t)(reconn_data_t *p_data);

/**
* @brief 获取重连数据函数
*/
typedef const char *(*get_reconn_reason_str_t)(RECONNECT_REASON_E reason);


/**
* @brief 清除重连数据函数
*/
typedef void (*clear_reconn_data_t)(void);

/**
* @brief 保存重连原因函数
*/
typedef int (*save_reconn_reason_t)(uint32_t reason);

/**
* @brief 获取连接状态函数
*/
typedef VESYNC_NETWORK_STATUS_E (*get_cloud_connect_status_t)(void);

/**
* @brief 上报函数
*/
typedef int (*send_to_cloud_t)(NET_DATA_TOPIC_TYPE_E topic_type, const char *pData, int len, SEND_QOS_E qos, net_recv_ack_cb_t ack_cb);

#if CONFIG_VESYNC_SDK_PRODUCTION_ENABLE
/**
 * @brief 获取产测状态
 * @return int        [产测状态值]
 */
typedef PRODUCTION_STATUS_E (*get_production_status_t)(void);
#endif /* CONFIG_VESYNC_SDK_PRODUCTION_ENABLE */

/**
* @brief 协议方法名称
*/
typedef struct
{
    char firm_up[16];
    char reset_dev[16];
    char update_dev_info[16];
    char status_change[20];
} report_method_t;

/**
* @brief 上报管理结构体
*/
typedef struct
{
    char trace_id_head[16];      // v3 新TraceID前缀，格式：3byte(平台ID) + 4byte 身份标识符（mac去掉冒号后4位）
    uint16_t trace_id_count;     // 运行时自增数字，每次上报都会加1
    report_method_t methods;

    get_traceid_t get_traceid;
    report_cloud_t report_cloud;
    report_cloud_qos_t report_cloud_qos;
    json_add_method_head_t json_add_method_head;

    get_reconn_data_t get_reconn_data;
    clear_reconn_data_t clear_reconn_data;
    get_reconn_reason_str_t get_reconn_reason_str;
    save_reconn_reason_t save_reconn_reason;

    get_cloud_connect_status_t get_cloud_connect_status;
    send_to_cloud_t send_to_cloud;
#if CONFIG_VESYNC_SDK_PRODUCTION_ENABLE
    get_production_status_t get_production_status;
#endif /* CONFIG_VESYNC_SDK_PRODUCTION_ENABLE */
} report_mgt_t;


/**
* @brief 上报升级状态到云端(http://34.194.32.46:8080/doc/N5iaViSJO)，方法名：reportFirmUpV2
*        设备升级状态上报(http://34.194.32.46:8080/doc/1Lt80cvinF)，方法名：reportFirmUpV3
* @param[in]  type              [固件类型]
* @param[in]  p_latest_ver      [最新固件版本]
* @param[in]  p_fw_url          [固件的URL]
* @param[in]  status            [升级状态]
* @param[in]  percent           [上报升级进度，单位：%]
* @return     int               [成功/失败]
*/
int vesync_report_firm_up(FW_TYPE_E type, char *p_latest_ver, char *p_fw_url, uint8_t status, uint8_t percent);


/**
* @brief 手动重置设备，通知云端(http://34.194.32.46:8080/doc/N5ZU7Jwgm)，方法名：resetDeviceV2
*        设备重置上报(http://34.194.32.46:8080/doc/1Lt66hVc2N)，方法名：resetDeviceV3
* @return      int      [成功/失败]
*/
int vesync_report_reset_device(void);

/**
 * @brief 返回设备上报原因的字符串
 * @param[in]  cause       [设备上报原因，详见enum声明]
 * @return     char*       [设备上报原因字符串形式]
 */
const char* vesync_report_get_cause_str(REPORT_CAUSE_E cause);


#if CONFIG_VESYNC_SDK_FFS_ENABLE
/**
* @brief 上报证书类型下载结果
* @param[in]  cert_type         [证书类型]
* @param[in]  status            [升级状态]
* @return     int               [成功/失败]
*/
int vesync_report_ffs_cert_update(FFS_CERT_E cert_type, uint8_t status);
#endif

#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_REPORT_INTERNAL_H__ */

