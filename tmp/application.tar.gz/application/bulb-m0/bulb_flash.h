/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        bulb_flash.h
 * @brief       灯泡数据的flash写入
 * @author      Dave
 * @date        2021-09-02
 */
#ifndef __BULB_FLASH_H__
#define __BULB_FLASH_H__

#include"bulb.h"

#ifdef __cplusplus
extern "C" {
#endif

#define BULB_USER_CFG_KEY_DATA "bulb"   // NVS采用key:value格式进行存储
#define BULB_KLV_DATA_LEN (128)

#define BULB_CFG_COLOR_MODE_INVALID (-1)
#define BULB_CFG_COLOR_MODE_WHITE (0)       // BULB_CFG_COLOR_MODE，白光模式的数值
#define BULB_CFG_COLOR_MODE_HSV (1)         // BULB_CFG_COLOR_MODE，彩光模式的数值
#define BULB_CFG_COLOR_MODE_PHONE_MUSIC (2) // BULB_CFG_COLOR_MODE，手机音乐模式
#define BULB_CFG_COLOR_MODE_PHONE_MIC (3)   // BULB_CFG_COLOR_MODE，手机麦克风音乐模式
#define BULB_CFG_COLOR_MODE_SCENARIO (4)    // BULB_CFG_COLOR_MODE，场景模式

#define BULB_CFG_POWEROFF_MEMORY_MODE_1 (0) // 断电记忆模式1：恢复上一次开启的状态
#define BULB_CFG_POWEROFF_MEMORY_MODE_2 (1) // 断电记忆模式2：恢复断电前的状态
#define BULB_CFG_POWEROFF_MEMORY_MODE_3 (2) // 断电记忆模式3：恢复成一个场景

#define BULB_CFG_DEFAULT_FADE_SPEED_MS (1000) // 默认普通白光模式和彩光模式的100%渐变时间是1000毫秒

#define BULB_CFG_EFFECT_MODE_1 (1)  // 默认灯效模式1
#define BULB_CFG_EFFECT_MODE_2 (2)  // 默认灯效模式2
#define BULB_CFG_EFFECT_MODE_3 (3)  // 默认灯效模式3

/**
 * @brief 配置数据key 定义
 */
typedef enum
{
    BULB_KEY_VERSION = 0,         // 版本
    BULB_KEY_ONOFF = 1,           // 开关机
    BULB_KEY_COLOR_MODE,          // 色彩模式
    BULB_KEY_COLOR_TEMP,          // 色温
    BULB_KEY_COLOR_BRIGHT,        // 亮度
    BULB_KEY_COLOR_HUE,
    BULB_KEY_COLOR_SATURATION,
    BULB_KEY_COLOR_VALUE,
    BULB_KEY_POWERNUM,
    BULB_KEY_INIT_FLAG,
    BULB_KEY_AGING_TEST,
    BULB_KEY_AGING_TEST_TIME,
    BULB_KEY_CLOUD_ZERO,
    BULB_KEY_SENSITIVE_TYPE,
    BULB_KEY_SENSITIVE_VALUE,
    BULB_KEY_EFFECT,
    BULB_KEY_SCENE_ID,
    BULB_KEY_POWEROFF_MEMORY_MODE,
    BULB_KEY_POWEROFF_MEMORY_SCENE_ID,
    BULB_KEY_FADE_ENABLE,
    BULB_KEY_FADE_SPEED_MS,
    BULB_KEY_MAX,
}BULB_CFG_KEY_E;

/**
 * @brief 灯泡配置标识符
 */
typedef enum
{
    BULB_CFG_ONOFF = 0,             // 标识bulb_flash_data_t中的bulb_onoff
    BULB_CFG_COLOR_MODE,            // 标识bulb_flash_data_t中的bulb_color_mode
    BULB_CFG_COLOR_TEMP,            // 标识bulb_flash_data_t中的bulb_color_temp
    BULB_CFG_COLOR_BRIGHT,          // 标识bulb_flash_data_t中的bulb_color_bright
    BULB_CFG_COLOR_HUE,             // 标识bulb_flash_data_t中的bulb_color_hue
    BULB_CFG_COLOR_SATURATION,      // 标识bulb_flash_data_t中的bulb_color_saturastion
    BULB_CFG_COLOR_VALUE,           // 标识bulb_flash_data_t中的bulb_color_value
    BULB_CFG_POWERNUM,
    BULB_CFG_INIT_FLAG,
    BULB_CFG_AGING_TEST,
    BULB_CFG_AGING_TEST_TIME,
    BULB_CFG_CLOUD_ZERO,
    BULB_CFG_SENSITIVE_TYPE,
    BULB_CFG_SENSITIVE_VALUE,
    BULB_CFG_EFFECT,
    BULB_CFG_SCENE_ID,
    BULB_CFG_POWEROFF_MEMORY_MODE,
    BULB_CFG_POWEROFF_MEMORY_SCENE_ID,
    BULB_CFG_FADE_ENABLE,
    BULB_CFG_FADE_SPEED_MS,
    BULB_CFG_UNKNOW,                // 未知
} BULB_CFG_FLAG_E;

/**
 * @brief 灯泡存储的flash数据
 */
typedef struct
{
    uint8_t cloud_zero;               // 第三方设置亮度0标识
    uint8_t bulb_aging_test_time;     // 老化测试时长记录
    uint8_t bulb_aging_test;          // 老化标识
    uint8_t bulb_onoff;               // 开关状态，1为开启，0为关闭
    uint8_t bulb_color_mode;          // 灯泡的色彩模式，0为白光，1为彩光
    uint8_t bulb_color_temp;          // 白光模式下的色温
    uint8_t bulb_color_bright;        // 白光模式下的亮度
    uint16_t bulb_color_hue;          // 彩光模式下的色相
    uint16_t bulb_color_saturation;   // 彩光模式下的饱和度
    uint8_t bulb_color_value;         // 彩光模式下的明度
    uint8_t bulb_powernum;            // 设备上电计次
    uint8_t bulb_init_flag;           // 成功从flash中读取到数据，该标志位置位1，默认为0
    uint8_t bulb_sensitive_type;
    uint8_t bulb_sensitive_value;
    uint8_t bulb_effect;
    uint16_t bulb_scene_id;
    uint8_t bulb_fade_enable;
    uint16_t bulb_fade_speed_ms;
} bulb_flash_data_t;

/**
 * @brief 获取灯泡的配置
 * @param[in]  flag             [标识符]
 * @return     int              [配置值]
 */
int bulb_flash_get_cfg(BULB_CFG_FLAG_E flag);

/**
 * @brief 更新灯泡的配置
 * @param[in]  flag             [标识符]
 * @param[in]  val              [配置值]
 * @return     int              [成功：APP_OK， 失败：APP_FAIL]
 */
int bulb_flash_upd_cfg(BULB_CFG_FLAG_E flag, int val);

/**
 * @brief 从flash加载灯泡配置
 * @param[in]  src              [动作来源]
 */
void bulb_flash_load_cfg(BULB_ACT_SRC_E src);

/**
 * @brief 清除灯泡配置
 * @return      int             [成功：APP_OK， 失败：APP_FAIL]
 */
int bulb_flash_reset_cfg(void);

/**
 * @brief 将内存配置刷入flash
 * @return      int             [成功：APP_OK， 失败：APP_FAIL]
 */
int bulb_flash_flush_cfg(void);

#ifdef __cplusplus
}
#endif

#endif

