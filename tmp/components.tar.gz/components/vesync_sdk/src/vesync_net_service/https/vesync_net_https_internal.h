/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_net_https_internal.h
 * @brief       https网络服务头文件
 * @author      Joshua
 * @date        2021-09-24
 */

#ifndef __VESYNC_NET_HTTPS_INTERNAL_H__
#define __VESYNC_NET_HTTPS_INTERNAL_H__

#include <stdint.h>
#include <stdbool.h>

#include "vesync_net_service_private.h"

#ifdef __cplusplus
extern "C"
{
#endif


#define  VESYNC_HTTPS_CFGNET_MAX_BUF_LEN      1024                                     // https配网指令，接收缓存最大长度
#define  VESYNC_HTTPS_CFGNET_URL_PATH         "/cloud/v1/deviceWeb/deviceRegisterV3"   // 接口地址
#define  HTTPS_DEFAULT_PORT                   443

/**
 * @brief https证书结构体
 */
typedef struct
{
    char * ca_cert_pem;
    char * client_cert_pem;
    char * client_key_pem;
} vhttps_ca_t;


/**
 * @brief  https客户端设置
 * @param[in]  p_cli                [客户端结构体指针]
 * @return  int                     [成功：VERR_OK，失败：VERR_FAIL]
 */
int vesync_net_https_cli_setup(vnet_cli_t *p_cli);

#ifdef __cplusplus
}
#endif

#endif  /* __VESYNC_NET_HTTPS_INTERNAL_H__ */

