/**
 *  Copyright © Vesync Technologies Co.Ltd. 2019-2021. All rights reserved
 * @file        led_strip_flash.h
 * @brief       led strip data storage  function
 * @author      henrik
 * @date        2021-10-27
 */
#ifndef __LED_STRIP_FLASH_H__
#define __LED_STRIP_FLASH_H__

#include "led_strip_scene.h"

#ifdef __cplusplus
extern "C" {
#endif

#define LS_USER_INFO_KEY_DATA        "ledstrip"             // NVS采用key:value格式进行存储
#define LS_SCENE_KEY                 "scene"                // ledstrip 场景配置存储KEY


#define LS_INFO_FIXED_LEN            40                     // 灯带信息固定长度
#define LS_SCENE_FIXED_LEN           20                     // 灯带场景固定长度

/*
 * @brief 灯带信息数据key 定义
 */
typedef enum
{
    LS_KEY_MODE = 0,            // 模式
    LS_KEY_STATUS,              // 开关状态
    LS_KEY_BRIGHTNESS,          // 亮度
    LS_KEY_SCENE_NOW,           // 当前场景ID
    LS_KEY_LED_NUM,             // 灯珠总数
    LS_KEY_LAST_ID,             // 上次分发的场景ID
    LS_KEY_COLOR,               // 单色模式下的颜色
    LS_KEY_MULTI_NUM,           // 多段调色模式下的分段数
    LS_KEY_MULTI_COLOR,         // 多段调色模式下的分段颜色
    LS_KEY_MAX
} LS_INFO_KEY_E;

/*
 * @brief 灯带场景数据key 定义
 */
typedef enum
{
    LS_KEY_SCENE_NUM = 0,
    LS_KEY_SCENE_ID,
    LS_KEY_SEG_NUM,
    LS_KEY_SEG_COLOR,
    LS_KEY_SEG_TYPE,
} LS_SCENE_KEY_E;

/**
 * @brief 保存灯带信息
 * @param[in]  data                 [灯带信息]
 * @return     int                  [成功：APP_OK， 失败：APP_FAIL]
 */
int  led_strip_save_info(ls_info_t * data);

/**
 * @brief 从flash中读取灯带信息到内存
 * @param[out] p_data               [灯带信息结构体]
 * @return     int                  [成功：APP_OK， 失败：APP_FAIL]
 */
int  led_strip_read_info(ls_info_t *p_data);

/**
 * @brief 清除灯带信息
 * @return int          [成功：APP_OK， 失败：APP_FAIL]
 */
int led_strip_clear_info(void);

/**
 * @brief 保存场景信息
 * @param[in]  p_data                   [场景信息]
 * @param[in]  num                      [场景数量]
 * @return     int                      [成功：APP_OK， 失败：APP_FAIL]
 */
int  led_strip_save_scene(ls_scene_t * p_data, uint8_t num);

/**
 * @brief 从flash中读取场景信息到内存
 * @param[in]  p_data                   [场景信息]
 * @param[in]  num                      [场景数量]
 * @return     int                      [成功：APP_OK， 失败：APP_FAIL]
 */
int led_strip_read_scene(ls_scene_t     *p_data, uint8_t * p_num);

/**
 * @brief 清除场景信息
 * @return int          [成功：APP_OK， 失败：APP_FAIL]
 */
int led_strip_clear_scene(void);


#ifdef __cplusplus
}
#endif

#endif


