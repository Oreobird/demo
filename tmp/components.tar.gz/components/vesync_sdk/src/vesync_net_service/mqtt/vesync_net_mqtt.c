/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_net_mqtt.h
 * @brief       mqtt网络服务
 * @author      CharlesMei & Joshua
 * @date        2021-05-25
 */
#if CONFIG_VESYNC_SDK_MQTT_ENABLE

#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#include "cJSON.h"
#include "vesync_cfg_internal.h"
#include "vesync_memory.h"
#include "vhal_utils.h"
#include "vhal_wifi.h"
#include "vesync_common.h"
#include "vesync_log_internal.h"
#include "vesync_device_internal.h"
#include "vesync_net_mqtt_internal.h"


static VESYNC_MQTT_STATUS_E s_mqtt_status = MQTT_OFFLINE;    // MQTT连接状态，默认为OFFLINE
static unsigned int s_mqtt_subscribe_ack_count = 0;
static unsigned int s_dns_resolve_failed_count = 0;

static vesync_net_msg_recv_cb_t s_mqtt_data_recv_bypass_cb = NULL;
static vesync_net_msg_recv_cb_t s_mqtt_data_recv_non_bypass_cb = NULL;


/**
 * @brief       get mqtt topic string
 * @param[in]   topic                [topic type]
 * @param[out]  buffer               [buffer to store topic, len must be MAX_MQTT_TOPIC_LEN]
 * @return      int                  [topic string len]
 */
#if defined(PR_REPORT_PROTOCOL_VER) && (PR_REPORT_PROTOCOL_VER == 3)
static int vesync_mqtt_topic_get(MQTT_TOPIC_TYPE_E topic, char *buffer)
{
    memset(buffer, 0, MAX_MQTT_TOPIC_LEN);
    switch (topic)
    {
    case MQTT_TOPIC_REQ:
        snprintf(buffer, MAX_MQTT_TOPIC_LEN, MQTT_TOPIC_PREFIX, PR_REPORT_PROTOCOL_VER, TOPIC_STR_REQ);
        break;
    case MQTT_TOPIC_RSP:
        snprintf(buffer, MAX_MQTT_TOPIC_LEN, MQTT_TOPIC_PREFIX, PR_REPORT_PROTOCOL_VER, TOPIC_STR_RSP);
        break;
    case MQTT_TOPIC_BYPASS:
        snprintf(buffer, MAX_MQTT_TOPIC_LEN, MQTT_TOPIC_PREFIX, PR_BYPASS_PROTOCOL_VER, TOPIC_STR_BYPASS);
        break;
    case MQTT_TOPIC_STR_BYPASS_RSP:
        snprintf(buffer, MAX_MQTT_TOPIC_LEN, MQTT_TOPIC_PREFIX, PR_BYPASS_PROTOCOL_VER, TOPIC_STR_BYPASS_RSP);
        break;
    case MQTT_TOPIC_DATA:
        snprintf(buffer, MAX_MQTT_TOPIC_LEN, MQTT_TOPIC_PREFIX, PR_REPORT_PROTOCOL_VER, TOPIC_STR_DATA);
        break;
    case MQTT_TOPIC_LOG:
        snprintf(buffer, MAX_MQTT_TOPIC_LEN, MQTT_TOPIC_PREFIX, PR_REPORT_PROTOCOL_VER, TOPIC_STR_LOG);
        break;
    default:
        break;
    }
    return strlen(buffer);
}
#else
static int vesync_mqtt_topic_get(MQTT_TOPIC_TYPE_E topic, char *buffer)
{
    memset(buffer, 0, MAX_MQTT_TOPIC_LEN);
    switch (topic)
    {
    case MQTT_TOPIC_REQ:
        snprintf(buffer, MAX_MQTT_TOPIC_LEN, MQTT_TOPIC_PREFIX, vesync_device_get_cid(), PR_REPORT_PROTOCOL_VER, TOPIC_STR_REQ);
        break;
    case MQTT_TOPIC_RSP:
        snprintf(buffer, MAX_MQTT_TOPIC_LEN, MQTT_TOPIC_PREFIX, vesync_device_get_cid(), PR_REPORT_PROTOCOL_VER, TOPIC_STR_RSP);
        break;
    case MQTT_TOPIC_BYPASS:
        snprintf(buffer, MAX_MQTT_TOPIC_LEN, MQTT_TOPIC_PREFIX, vesync_device_get_cid(), PR_BYPASS_PROTOCOL_VER, TOPIC_STR_BYPASS);
        break;
    case MQTT_TOPIC_BYPASS_RSP:
        snprintf(buffer, MAX_MQTT_TOPIC_LEN, MQTT_TOPIC_PREFIX, vesync_device_get_cid(), PR_BYPASS_PROTOCOL_VER, TOPIC_STR_BYPASS_RSP);
        break;
    case MQTT_TOPIC_DATA:
        snprintf(buffer, MAX_MQTT_TOPIC_LEN, MQTT_TOPIC_PREFIX, vesync_device_get_cid(), PR_REPORT_PROTOCOL_VER, TOPIC_STR_DATA);
        break;
    case MQTT_TOPIC_LOG:
        snprintf(buffer, MAX_MQTT_TOPIC_LEN, MQTT_TOPIC_PREFIX, vesync_device_get_cid(), PR_REPORT_PROTOCOL_VER, TOPIC_STR_LOG);
        break;
    default:
        break;
    }
    return strlen(buffer);
}
#endif

/**
 * @brief       mqtt订阅主题确认回调
 */
static void vnet_mqtt_subscribe_ack_cb(void)
{
    s_mqtt_subscribe_ack_count++;
    if (NET_VERIFID_ACK_NUM == s_mqtt_subscribe_ack_count)
    {
        vesync_ev_t event;
        s_mqtt_subscribe_ack_count = 0;
        VESYNC_POPULATE_EV(event, EVENT_NWK_READY, NET_SERVICE_EVENT_PUBLISH_STR, 0, NULL);
        vesync_event_publish(&event);
        return;
    }
}

/**
 * @brief       订阅两个mqtt主题
 */
static int vnet_mqtt_subscribe_topic()
{
    char topic[MAX_MQTT_TOPIC_LEN];

    s_mqtt_subscribe_ack_count = 0;

    vesync_mqtt_topic_get(MQTT_TOPIC_RSP, topic);
    if (vesync_mqtt_subscribe(topic, MQTT_QOS1, vnet_mqtt_subscribe_ack_cb) != SDK_OK)
    {
        SDK_LOG(LOG_INFO, "Error MQTT Subscribe\n");
        return SDK_FAIL;
    }

    vesync_mqtt_topic_get(MQTT_TOPIC_BYPASS, topic);
    if (vesync_mqtt_subscribe(topic, MQTT_QOS1, vnet_mqtt_subscribe_ack_cb) != SDK_OK)
    {
        SDK_LOG(LOG_INFO, "Error MQTT Subscribe\n");
        return SDK_FAIL;
    }

    return SDK_OK;
}



#if MQTT_HEATBEAT_TIME_SYNC_DEPRECATED
/**
 * @brief       比较MQTT心跳回复的时间戳，判断是否更新本地时间
 * @param[in]   uint32_t         [时间戳]
 */
static void vnet_mqtt_ts_check(uint32_t ts)
{
    uint32_t seconds = 0;
    uint32_t update_time_differ = 0;
    uint32_t remote_local_differ = 0;
    static uint32_t last_update_time = 0;
    static uint8_t  continue_differ_count = 0;
    static int continue_differ_sum = 0;

    seconds = vhal_utils_get_system_time_sec();
    NET_LOG(LOG_DEBUG, "new ts: %d, local ts: %d.\n", ts, seconds);

    if (ts >= seconds)
    {
        remote_local_differ = ts - seconds;
    }
    else
    {
        remote_local_differ = seconds - ts;
    }

    if (0 == last_update_time) // 上电第一次启动更新时间
    {
        last_update_time = ts;
        vesync_device_update_system_time(ts, 0);
    }

    if (0 != remote_local_differ)
    {
        continue_differ_count++;
        continue_differ_sum += ts - seconds;

        if (4 <= continue_differ_count)
        {
            // 本地时间与服务器时间戳连续4次不等:
            //1.若时间差小于等于上次更新的时间与本次更新时间的理论时间差，则更新本地为新的时间戳
            //2.若时间差大于上次更新的时间与本次更新时间的理论时间差，则更新时间为本地时间戳加上4次的误差均值
            //理论上乐鑫芯片在休眠状态下，一天误差在十多分钟，所以取休眠状态下，一秒钟的理论误差为256分之一秒
            update_time_differ = ((ts - last_update_time) >> 8);
            continue_differ_sum = (continue_differ_sum >> 2);
            NET_LOG(LOG_DEBUG, "last_update:%d,differ: %d, differ average: %d.\n", last_update_time,\
                                                       remote_local_differ, continue_differ_sum);
            if (update_time_differ >= continue_differ_sum)
            {
                vesync_device_update_system_time(ts, 0);
            }
            else
            {
                vesync_device_update_system_time(seconds + continue_differ_sum, 0);
            }
            last_update_time = ts;
            continue_differ_count = 0;
            continue_differ_sum = 0;
        }
    }
    else
    {
        continue_differ_count = 0;
        continue_differ_sum = 0;
    }
}
#endif

/**
 * @brief  非bypass消息处理
 * @param[in]  data                 [json数据]
 */
static void vnet_mqtt_non_bypass_handle(const char *data)
{
    cJSON *root = NULL;
    cJSON *json_result = NULL;
    cJSON *json_code = NULL;

    root = cJSON_Parse(data);
    if (NULL == root)
    {
        NET_LOG(LOG_ERROR, "Parse cjson error!\r\n");
        return;
    }

    /**
     * @brief 不再处理MQTT心跳里的时间戳
     * @note  新的时间同步方式参考：https://wiki.vesync.cn/pages/viewpage.action?pageId=251986147
     */
#if MQTT_HEATBEAT_TIME_SYNC_DEPRECATED
    cJSON *json_data = NULL;
    // 时间戳处理(MQTT心跳响应)
    json_data = cJSON_GetObjectItemCaseSensitive(root, "ts");
    if (NULL != json_data)
    {
        if (cJSON_IsNumber(json_data))
        {
            int32_t ts = json_data->valueint;
            vnet_mqtt_ts_check(ts);
        }
    }
#endif

    // 请求响应
    json_code = cJSON_GetObjectItemCaseSensitive(root, "code");
    json_result = cJSON_GetObjectItemCaseSensitive(root, "result");
    if (cJSON_IsNumber(json_code) && (0 == json_code->valueint))
    {
        if (cJSON_IsObject(json_result))
        {
            char *str_result = cJSON_Print(json_result);
            if (NULL != s_mqtt_data_recv_non_bypass_cb)
            {
                s_mqtt_data_recv_non_bypass_cb(str_result);
            }

            NET_UTIL_SAFE_FREE(str_result);
        }
    }

   cJSON_Delete(root);
}


/**
 * @brief  初步处理接收到的mqtt数据
 * @param[in]  topic                [接收的主题]
 * @param[in]  topic_len            [主题长度]
 * @param[in]  data                 [接收的数据]
 * @param[in]  data_len             [数据长度]
 */
static void vnet_mqtt_data_handle(char *topic, int topic_len, char *data, int data_len)
{
    NET_LOG(LOG_DEBUG, "DATA=%s\n", data);

    char mqtt_topic[MAX_MQTT_TOPIC_LEN];
    vesync_mqtt_topic_get(MQTT_TOPIC_BYPASS, mqtt_topic);

    if (0 == strncmp(topic, mqtt_topic, topic_len))
    {
        VNET_DATA_RECV_BYPASS_CB(data);   // bypass消息处理
        NET_LOG(LOG_DEBUG, "bypass data .........\n");
    }
    else if (0 == strncmp(topic, MQTT_OFFLINE_MSG_TOPIC, topic_len))
    {
        VNET_DATA_RECV_BYPASS_CB(data);   // bypass消息处理
        NET_LOG(LOG_DEBUG, "offline message .........\n");
    }
    else
    {
        vnet_mqtt_non_bypass_handle(data);     // 非bypass消息处理

        VESYNC_PRINTF_FREE_HEAP();
        NET_LOG(LOG_DEBUG, "cloud data .........\n");
    }
}

/**
 * @brief  mqtt事件回调函数
 * @param[in]  event                [mqtt事件]
 * @return  int                     [错误码]
 */
static int vnet_mqtt_event_handler(vesync_mqtt_event_handle_t event)
{
    NET_LOG(LOG_INFO, "MQTT event_id = %d\n", event->event_id);
    switch (event->event_id)
    {
    case MQTT_EVENT_DNS_RESOLVED:
        vesync_net_event_notify(EVENT_DNS_RESOLVED, (void*)event->data);
        s_dns_resolve_failed_count = 0;
        break;

    case MQTT_EVENT_DNS_RESOLVE_FAILED:
        s_dns_resolve_failed_count ++;
        if (s_dns_resolve_failed_count >= 3)
        {
            vhal_wifi_dns_setserver(0, DNS_PRIMARY);
            vhal_wifi_dns_setserver(1, DNS_SECONDARY);
            s_dns_resolve_failed_count = 0;
        }
        break;

    case MQTT_EVENT_CONNECTED:
        s_mqtt_status = MQTT_ONLINE;
        vnet_mqtt_subscribe_topic();
        vesync_net_event_notify(EVENT_NWK_CONNECTED, NULL);
        break;

    case MQTT_EVENT_DISCONNECTED:
        s_mqtt_status = MQTT_OFFLINE;
        vesync_net_mgmt_set_reconnect_reason(NETWORK_REASON);
        vesync_net_mgmt_set_reconnect_count(NETWORK_RETRY_FAIL); // 离线统计
        vesync_net_event_notify(EVENT_NWK_DISCONNECTED, (void*)event->data);
        break;

    case MQTT_EVENT_DATA:
        s_mqtt_status = MQTT_ONLINE;
        NET_LOG(LOG_INFO, "MQTT event_id = MQTT_EVENT_DATA, topic_len=%d, data_len=%d\n", event->topic_len, event->data_len);
        vnet_mqtt_data_handle(event->topic, event->topic_len, event->data, event->data_len);
        break;

    case MQTT_EVENT_SUBSCRIBED:
    case MQTT_EVENT_UNSUBSCRIBED:
    case MQTT_EVENT_PUBLISHED:
    case MQTT_EVENT_ERROR:
    default:
        break;
    }

    return VERR_OK;
}


/**
 * @brief  vesync平台网络服务客户端断开与服务器的连接
 * @return  int                     [成功：VERR_OK，失败：VERR_FAIL]
 */
static int vnet_mqtt_cli_disconnect(void)
{
    s_mqtt_status = MQTT_OFFLINE;    // 重置MQTT状态

    return vesync_mqtt_disconnect();
}

/**
 * @brief  销毁网络服务客户端，释放内存，重置状态
 */
static void vnet_mqtt_cli_destroy(void)
{
    return;
}

/**
 * @brief  MQTT客户端初始化
 * @return  int                     [成功：VERR_OK，失败：VERR_FAIL]
 */
static int vnet_mqtt_cli_init(void)
{
    vesync_mqtt_config(vesync_device_get_cid(), vnet_mqtt_event_handler);
    NET_LOG(LOG_INFO, "network protocol mqtt init success\n");
    return VERR_OK;
}

/**
 * @brief  网络客户端对有关device的设置进行刷新
 * @note  在device设置更新时（例如进入产测前）调用
 */
static void vnet_mqtt_cli_refresh(void)
{
    vesync_mqtt_config(vesync_device_get_cid(), vnet_mqtt_event_handler);
    return;
}

/**
 * @brief  MQTT客户端连接服务器
 * @param[in]   p_srv                [mqtt服务器地址]
 * @param[in]   p_pwd                [mqtt连接的用户密码，BLE/APN配网时为configKey，断开重连时为"0"，FFS配网时为token]
 * @param[in]   p_port               [mqtt连接端口， 指针置空则连接默认端口]
 * @param[in]   tls                  [tls选项]
 * @return  int                      [成功：VERR_OK，失败：VERR_FAIL]
 */
static int vnet_mqtt_cli_connect(char *p_srv, char *ip, char *p_pwd, uint32_t *p_port, NETWORK_TLS_CA_E tls)
{
    if (NULL == p_srv || NULL == p_pwd)
    {
        NET_LOG(LOG_DEBUG, "Params err\n");
        return VERR_FAIL;
    }

    MQTT_TLS_CA_E net_tls = MQTT_TLS_DSIABLE;
    char username[256];
    uint16_t mqtt_port = MQTT_DEFAULT_PORT;

    memset(username, 0, sizeof(username));

#if defined(PR_CMPT_RTOS) && (PR_CMPT_RTOS == 1)
    snprintf(username, sizeof(username), "%s%s%s", vesync_cfg_get_authkey(), PR_PID, vesync_cfg_get_country_code());
#else
    snprintf(username, sizeof(username), "{\"authKey\":\"%s\",\"configModel\":\"%s\",\"deviceRegion\":\"%s\"}",
            vesync_cfg_get_authkey(), vesync_cfg_get_config_model(), vesync_cfg_get_country_code());
#endif

    if (NULL != p_port)
    {
        mqtt_port = (uint16_t)(*p_port);
    }

    NET_LOG(LOG_DEBUG, "User name: %s\n", username);
    NET_LOG(LOG_DEBUG, "Connect server: %s:%d\n", p_srv, mqtt_port);
    NET_LOG(LOG_DEBUG, "pwd_name: %s\n",  p_pwd);
    NET_LOG(LOG_DEBUG, "server ip: %s\n", ip);
    VESYNC_PRINTF_FREE_HEAP();

    switch (tls)
    {
        case TLS_DSIABLE:
            net_tls = MQTT_TLS_DSIABLE;
            break;
        case TLS_CA_NONE:
            net_tls = MQTT_TLS_CA_NONE;
            break;
        case TLS_CA_SERVER:
            net_tls = MQTT_TLS_CA_SERVER;
            break;
        case TLS_CA_PRODUTION:
            net_tls = MQTT_TLS_CA_PRODUTION;
            break;
        default:
            NET_LOG(LOG_DEBUG, "invalid tls!!!\n");
            return VERR_FAIL;
    }

    // MQTT连接 (会不断重连)
    return vesync_mqtt_connect(p_srv, ip, mqtt_port, username, p_pwd, net_tls);
}


/**
 * @brief  将send_qos转换为mqtt_qos
 * @param[in]  send_qos             [数据上报等级]
 * @return  MQTT_QOS_E              [mqtt发布等级]
 */
static MQTT_QOS_E vnet_get_mqtt_qos(SEND_QOS_E send_qos)
{
    switch (send_qos)
    {
        case SEND_QOS0:
            return MQTT_QOS0;
        case SEND_QOS1:
            return MQTT_QOS1;
        case SEND_QOS2:
            return MQTT_QOS2;
        default:
        NET_LOG(LOG_ERROR, "Unknown report_qos\r\n");
        VERR_UPLOAD(VERR_MQTT_QOS_UNSUPPORT, send_qos);
            return MQTT_QOS0;
    }
}

/**
 * @brief  数据发送，可设置qos及收到回包后回调函数
 * @param[in]  topic_type           [topic类型]
 * @param[in]  pData                [数据指针]
 * @param[in]  len                  [数据的长度]
 * @param[in]  qos                  [qos级别，当前支持0和1]
 * @return  int                     [成功：VERR_OK，失败：VERR_FAIL]
 */
static int vnet_mqtt_cli_send(NET_DATA_TOPIC_TYPE_E topic_type, const char *p_data, int len, SEND_QOS_E qos, net_recv_ack_cb_t ack_cb)
{
    char mqtt_topic[MAX_MQTT_TOPIC_LEN];

    if ((p_data == NULL ) || (0 >= len))
    {
        return SDK_FAIL;
    }

    if (SEND_QOS2 <= qos)
    {
        NET_LOG(LOG_ERROR, "unsupport qos %d\n", qos);
        VERR_UPLOAD(VERR_MQTT_QOS_UNSUPPORT, qos);
        return SDK_FAIL;
    }

    switch (topic_type)
    {
        case NET_DATA_TOPIC_STATUS:
            vesync_mqtt_topic_get(MQTT_TOPIC_REQ, mqtt_topic);
            break;
        case NET_DATA_TOPIC_DATA:
            vesync_mqtt_topic_get(MQTT_TOPIC_REQ, mqtt_topic);
            break;
        case NET_DATA_TOPIC_LOG:
            vesync_mqtt_topic_get(MQTT_TOPIC_LOG, mqtt_topic);
            break;
        case NET_DATA_TOPIC_RESP:
            vesync_mqtt_topic_get(MQTT_TOPIC_BYPASS_RSP, mqtt_topic);
            break;
        default:
            NET_LOG(LOG_ERROR, "invalid topic type!!!\n");
            return SDK_FAIL;
    }

    NET_LOG(LOG_DEBUG, "%d, qos = %d\n", mqtt_topic, qos);
    return vesync_mqtt_publish(mqtt_topic, p_data, len, vnet_get_mqtt_qos(qos), 0, ack_cb);
}


/**
 * @brief  获取网络服务客户端在线状态
 * @return  VESYNC_NETWORK_STATUS_E [mqtt客户端在线状态]
 */
static VESYNC_NETWORK_STATUS_E vnet_mqtt_cli_status_get(void)
{
    switch (s_mqtt_status)
    {
        case MQTT_OFFLINE:
            return NETWORK_OFFLINE;
        case MQTT_ONLINE:
            return NETWORK_ONLINE;
        default:
            return NETWORK_OFFLINE;
    }
}


/**
 * @brief  获取mqtt默认端口
 * @return  int             [端口号，错误返回-1]
 */
static int vnet_mqtt_cli_get_default_port(void)
{
#if CONFIG_VESYNC_SDK_MQTT_ENABLE
    return MQTT_DEFAULT_PORT;
#else
    return -1;
#endif
}

/**
 * @brief  mqtt bypass回调函数注册
 * @param[in]   cb
 */
static void vnet_mqtt_cli_reg_bypass_cb(vesync_net_msg_recv_cb_t cb)
{
    s_mqtt_data_recv_bypass_cb = cb;
}

/**
 * @brief  mqtt非bypass回调函数注册
 * @param[in]   cb
 */
static void vnet_mqtt_cli_reg_non_bypass_cb(vesync_net_msg_recv_cb_t cb)
{
    s_mqtt_data_recv_non_bypass_cb = cb;
}

/**
 * @brief  mqtt客户端设置
 * @param[in]  p_cli                [客户端结构体指针]
 * @return  int                     [成功：VERR_OK，失败：VERR_FAIL]
 */
int vesync_net_mqtt_cli_setup(vnet_cli_t *p_cli)
{
    NET_UTIL_MEM_CHECK(p_cli, return VERR_FAIL);

    p_cli->init = vnet_mqtt_cli_init;
    p_cli->connect = vnet_mqtt_cli_connect;
    p_cli->disconnect = vnet_mqtt_cli_disconnect;
    p_cli->send = vnet_mqtt_cli_send;
    p_cli->destroy = vnet_mqtt_cli_destroy;
    p_cli->status_get = vnet_mqtt_cli_status_get;
    p_cli->fresh = vnet_mqtt_cli_refresh;
    p_cli->get_default_port = vnet_mqtt_cli_get_default_port;

    p_cli->reg_bypass_recv_cb = vnet_mqtt_cli_reg_bypass_cb;
    p_cli->reg_non_bypass_recv_cb = vnet_mqtt_cli_reg_non_bypass_cb;

    return VERR_OK;
}

#endif
