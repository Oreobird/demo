/**
 * Copyright © Vesync Technologies Co.Ltd. 2019-2021. All rights reserved.
 * @file    vesync_uart_service.c
 * @brief   UART初始化、UART数据封装/解析、UART数据收/发
 * @author  Blue.Qi
 * @date    2018-05-15
 */

#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#include "vesync_common.h"
#include "vesync_log_internal.h"
#include "vesync_cfg.h"

#include "vesync_uart.h"
#include "vesync_uart_internal.h"
#include "vesync_tl_payload_parse.h"
#include "vesync_uart_msg_queue.h"

//#define VESYNC_CUR_FILE_IN_MOD MOD_OTA                        // 文件所在模块编号

static uart_send_info_t s_uart_send_info;           // 串口发送信息
static uart_recv_info_t s_uart_recv_info;           // 串口接收信息

/*-----------------------------------------------------------------------------*
 *                           内部函数API实现                                         *
 *-----------------------------------------------------------------------------*/

static bool vesync_uart_tl_send_tmr_start(uint8_t request_flag);
static bool vesync_uart_tl_send_tmr_stop(void);
static UART_ERR_CODE_E vesync_uart_send_raw_data(VHAL_UART_PORT_E uart_num, uint8_t *p_data , uint16_t length);



/**
 * @brief 调用发送函数发送数据成功或者失败 (发送状态函数)
 * @param[in]  event            [发送结果]
 * @param[in]  frame            [收到应答，传入应答数据帧，否则为NULL]
 */
static void vesync_uart_tx_event(UART_SEND_TYPE_E event, tl_frame_recv_info_t *frame)
{
    // SDK_LOG(LOG_DEBUG, "ble_transport_layer_event_cb():%d\r\n",event);
    // if(NULL != frame)
    // {
    //     SDK_LOG(LOG_DEBUG, " frame.ctrl=0x%02x\r\n",frame->ctrl);
    //     SDK_LOG(LOG_DEBUG, " frame.sequence_id=0x%02x\r\n",frame->sequence_id);
    //     SDK_LOG(LOG_DEBUG, " frame.payload_length=0x%04x\r\n",frame->payload_length);
    //     SDK_LOG(LOG_DEBUG, " frame.checksum=0x%02x\r\n",frame->checksum);
    //     SDK_LOG(LOG_DEBUG, " frame_rframeecv_info.payload[0]=0x%02x\r\n",frame->p_payload[0]);
    // }

    vesync_uart_msg_tx_event(event, frame);

    if (NULL != s_uart_send_info.tx_ota_event_cb)
    {
        s_uart_send_info.tx_ota_event_cb(event, (uart_payload_info_t *)frame->p_payload, frame->payload_len, NULL);
    }
}

/**
 * @brief 应答处理函数
 * @param[in]  frame                [接收信息结构体]
 */
static void vesync_uart_handle_ack(tl_frame_recv_info_t *frame)
{
    UART_SEND_TYPE_E event;

    if (frame->seq_id == s_uart_send_info.send_frame_info.seq_id)
    {
        if (1 == frame->ctrl.bitN.error_flag)
        {
            event = UART_SEND_FAIL;
        }
        else
        {
            event = UART_SEND_SUCCESS;
        }

        vesync_uart_tl_send_tmr_stop();

        vesync_uart_tx_event(event, frame);
        s_uart_send_info.send_busy_flag = false;
    }
}

/**
 * @brief 发送超时处理函数
 * @param[in]  arg                  [未使用]
 */
static void vesync_uart_tl_send_tmr_cb(void *arg)
{
    if (0 != s_uart_send_info.send_req_flag)
    {
        if (s_uart_send_info.send_repeat_cnt < PR_UART_MAX_RESEND_CNT)     // 最大重发次数
        {
            s_uart_send_info.send_repeat_cnt++;
            vesync_uart_tl_send_tmr_start(s_uart_send_info.send_req_flag);
            vesync_uart_send_raw_data(s_uart_send_info.uart_num, s_uart_send_info.p_send_buf, s_uart_send_info.send_data_len);
        }
        else
        {
            vesync_uart_tx_event(UART_SEND_FAIL, NULL);
            //VERR_UPLOAD(VERR_UART_SEND_TIMEOUT, s_uart_send_repeat_cnt);
            s_uart_send_info.send_busy_flag = false;
        }
    }
    else
    {
        vesync_uart_tx_event(UART_SEND_SUCCESS, NULL);
        s_uart_send_info.send_busy_flag = false;
    }
}

/**
 * @brief  发送超时定时器启动
 * @param[in]  request_flag             [用于指示接收该数据包的设备是否需要回应答，0：不需要回应答  1：需要回应答；]
 * @return     bool                     [true表示修改定时器成功，反之表示修改定时器失败]
 */
static bool vesync_uart_tl_send_tmr_start(uint8_t request_flag)
{
    int time_ms = 0;
    bool status = false;

    s_uart_send_info.send_req_flag = request_flag;
    if (0 == request_flag)
    {
        time_ms = PR_UART_SEND_NO_RSP_TIMEOUT_MS;       // 无应答的定时器超时时间，单位：毫秒
    }
    else
    {
        time_ms = PR_UART_SEND_RSP_TIMEOUT_MS;          // 有应答的定时器超时时间，单位：毫秒
    }

    if (VOS_OK != vesync_timer_change_period(&s_uart_send_info.timer, time_ms))
    {
        status = false;
    }
    else
    {
        status =  true;
    }

    return status;
}

/**
 * @brief  发送超时定时器停止
 * @return     bool                     [true表示停止定时器成功，反之表示停止定时器失败]
 */
static bool vesync_uart_tl_send_tmr_stop(void)
{
    bool status = false;

    if (VOS_OK != vesync_timer_stop(&s_uart_send_info.timer))
    {
        status = false;
    }
    else
    {
        status = true;
    }

    return status;
}

/**
 * @brief  应用层数据封装和发送函数
 * @param[in]  uart_num                 [串口编号]
 * @param[in]  p_data                   [数据]
 * @param[in]  length                   [数据长度]
 * @param[in]  request_flag             [用于指示接收该数据包的设备是否需要回应答，0：不需要回应答  1：需要回应答；]
 * @return     UART_ERR_CODE_E          [UART_TL_SUCCESS：表示数据传入成功；
 *                                      UART_TL_ERROR_INVALID_POINTER：表示无效指针传入；
 *                                      UART_TL_ERROR_INVALID_LENGTH：表示无效长度传入；
 *                                      UART_TL_ERROR_SEND_BUSY：表示发送忙，需要等待发送回调函数返回结果，再次尝试；
 *                                      UART_TL_ERROR_OTHER：其他；]
 * @note    此函数传入数据和数据长度，内部实现按格式封包，并发送出去，
 *          实现重发机制，发送成功或者失败需要在事件回调函数返回
 */
static UART_ERR_CODE_E vesync_uart_tl_pkg_send_data(VHAL_UART_PORT_E uart_num, uint8_t *p_data, uint16_t length, uint8_t request_flag)
{
    if (NULL == p_data)
    {
        return UART_TL_ERROR_INVALID_POINTER;
    }

    if (length > UART_FRAME_PAYLOAD_MAX_LEN)
    {
        return UART_TL_ERROR_INVALID_LENGTH;
    }

    if (s_uart_send_info.send_busy_flag)
    {
        return UART_TL_ERROR_SEND_BUSY;
    }

    s_uart_send_info.send_frame_info.seq_id++;
    //s_uart_frm_send_info.sequence_id = 0; //todo test
    s_uart_send_info.send_frame_info.ctrl.data              = 0; //
    s_uart_send_info.send_frame_info.ctrl.bitN.version      = TL_PAYLOAD_PROTOCOL_VERSION;
    s_uart_send_info.send_frame_info.ctrl.bitN.request_flag = request_flag;  // 是否需要应答位
    s_uart_send_info.send_frame_info.p_payload              = p_data;
    s_uart_send_info.send_frame_info.payload_len            = length;

    if (0 != vesync_tl_frame_encode(&s_uart_send_info.send_frame_info, s_uart_send_info.p_send_buf, &s_uart_send_info.send_data_len))
    {
        return UART_TL_ERROR_OTHER;
    }

    s_uart_send_info.send_busy_flag = true;
    s_uart_send_info.uart_num = uart_num;
    vesync_uart_send_raw_data(s_uart_send_info.uart_num, s_uart_send_info.p_send_buf, s_uart_send_info.send_data_len);     // 发送数据

    if (0 != request_flag)
    {
        s_uart_send_info.send_repeat_cnt = 1;
    }
    vesync_uart_tl_send_tmr_start(request_flag);

    return UART_TL_SUCCESS;
}


/**
 * @brief 应答发送函数  接收回调通过判断frame_recv_info.ctrl.bitN.request_flag是否需要应答
 * @param[in]  uart_num            [串口编号]
 * @param[in]  err_flag            [错误标志位，0：无错误； 1：错误；]
 * @param[in]  p_data              [数据帧中的payload数据]
 * @param[in]  length              [payload数据长度]
 * @return     void
 */
static void vesync_uart_tl_pkg_send_ack(VHAL_UART_PORT_E uart_num, uint8_t err_flag, uint8_t *p_data, uint16_t length)
{
    tl_frame_send_info_t send_frame;
    uint8_t *p_temp;
    uint16_t len;
    uint8_t temp;

    if (NULL == p_data)
    {
        return;
    }

    memset(&send_frame, 0, sizeof(tl_frame_send_info_t));
    send_frame.ctrl.bitN.version    = TL_PAYLOAD_PROTOCOL_VERSION;
    send_frame.ctrl.bitN.ack_flag   = 1;
    send_frame.ctrl.bitN.error_flag = err_flag;
    send_frame.seq_id               = s_uart_recv_info.recv_frame_record.sequence_id;
    send_frame.payload_len          = length;
    send_frame.p_payload            = p_data;

    p_temp = (uint8_t *)malloc(send_frame.payload_len + 6);
    if (NULL == p_temp)
    {
        SDK_LOG(LOG_INFO, "Malloc fail\r\n");
        return;
    }
    memset(p_temp, 0, send_frame.payload_len + 6);

    s_uart_send_info.uart_num = uart_num;
    temp = vesync_tl_frame_encode(&send_frame, p_temp, &len);
    //SDK_LOG(LOG_INFO, "ACK frame encode:%d\r\n", temp);
    if (0 == temp)
    {
        vesync_uart_send_raw_data(s_uart_send_info.uart_num, p_temp, len);
    }

    free(p_temp);
}

/**
 * @brief 应答发送函数  接收回调通过判断frame_recv_info.ctrl.bitN.request_flag是否需要应答
 * @param[in]  uart_num                 [串口编号]
 * @param[in]  seq_id                   [序列号]
 * @param[in]  err_flag                 [错误标志位，0：无错误； 1：错误；]
 * @param[in]  p_data                   [数据帧中的payload数据]
 * @param[in]  length                   [payload数据长度]
 */
static void vesync_uart_tl_pkg_send_ack_with_seq_id(VHAL_UART_PORT_E uart_num, uint8_t seq_id, uint8_t err_flag, uint8_t *p_data, uint16_t length)
{
    tl_frame_send_info_t send_frame;
    uint8_t *p_temp;
    uint16_t len;
    uint8_t temp;

    if (NULL == p_data)
    {
        return;
    }

    memset(&send_frame,0,sizeof(tl_frame_send_info_t));
    send_frame.ctrl.bitN.version    = TL_PAYLOAD_PROTOCOL_VERSION;
    send_frame.ctrl.bitN.ack_flag   = 1;
    send_frame.ctrl.bitN.error_flag = err_flag;
    send_frame.seq_id               = seq_id;
    send_frame.payload_len          = length;
    send_frame.p_payload            = p_data;

    p_temp = (uint8_t *)malloc(send_frame.payload_len + 6);
    if (NULL == p_temp)
    {
        SDK_LOG(LOG_ERROR, "malloc p_temp fail\r\n");
        return;
    }
    memset(p_temp, 0, send_frame.payload_len + 6);

    temp = vesync_tl_frame_encode(&send_frame, p_temp, &len);
    //SDK_LOG(LOG_DEBUG, "ACK frame encode:%d\r\n", temp);
    if (0 == temp)
    {
        vesync_uart_send_raw_data(uart_num, p_temp, len);
    }

    free(p_temp);
}

/**
 * @brief  UART传输层模块初始化
 */
static void vesync_uart_tl_init(void)
{
    int32_t ret = VOS_FAIL;

    memset(&s_uart_send_info, 0, sizeof(uart_send_info_t));
    memset(&s_uart_recv_info, 0, sizeof(uart_recv_info_t));

    s_uart_send_info.p_send_buf = (uint8_t *)malloc(UART_FRAME_PAYLOAD_MAX_LEN + 6);            // 头部6byte+payload
    s_uart_recv_info.recv_frame_info.p_payload = (uint8_t *)malloc(UART_FRAME_PAYLOAD_MAX_LEN);
    if ((NULL == s_uart_recv_info.recv_frame_info.p_payload) || (NULL == s_uart_send_info.p_send_buf))
    {
        SDK_LOG(LOG_ERROR, "Malloc fail!!!\n");
        return;
    }
    memset(s_uart_recv_info.recv_frame_info.p_payload, 0, UART_FRAME_PAYLOAD_MAX_LEN);
    memset(s_uart_send_info.p_send_buf, 0, UART_FRAME_PAYLOAD_MAX_LEN + 6);

    s_uart_send_info.send_busy_flag = false;

    ret = vesync_timer_new(&s_uart_send_info.timer, "uart_resend", vesync_uart_tl_send_tmr_cb, NULL, 10000, false);
    if (VOS_OK != ret)
    {
        SDK_LOG(LOG_ERROR, "Create timer fail!!!\n");
        //VERR_UPLOAD(VERR_LINK_MOD_COM(VERR_TIMER_CREATE_FAIL), vhal_get_free_heap_size());
        return;
    }
}

/**
 * @brief  BLE传输层数据传出接口函数(ble传输层封装数据，调用该函数进行发送)
 * @param[in]  uart_num                 [串口编号]
 * @param[in]  p_data                   [数据]
 * @param[in]  length                   [数据长度]
 * @return     UART_ERR_CODE_E          [BLE_TL_SUCCESS：表示数据传入成功；
 *                                      BLE_TL_ERROR_INVALID_POINTER：表示无效指针传入
 *                                      BLE_TL_ERROR_INVALID_LENGTH：表示无效长度传入
 *                                      BLE_TL_ERROR_OTHER：其他错误]
 */
static UART_ERR_CODE_E vesync_uart_send_raw_data(VHAL_UART_PORT_E uart_num, uint8_t *p_data , uint16_t length)
{
    LOG_RAW_HEX(LOG_DEBUG, "[TT] uart send: ", p_data, length);

    int ret = vhal_uart_send(uart_num, p_data, length);       // 调用HAL层，进行串口发送数据
    if (VHAL_OK != ret)
    {
        SDK_LOG(LOG_ERROR, "UART send fail!!!\r\n");
        //VERR_UPLOAD(VERR_UART_SEND_FAIL, UART_TL_ERROR_OTHER);
        return UART_TL_ERROR_OTHER;
    }
    //SDK_LOG(LOG_DEBUG, "UART send success.\r\n");

    return UART_TL_SUCCESS;
}

/**
 * @brief 串口数据处理
 * @param[in]  uart_num                 [串口编号]
 * @param[in]  frame                    [接收到的指针]
 * @return     void
 */
static void vesync_uart_handle_rx_data(VHAL_UART_PORT_E uart_num, tl_frame_recv_info_t *frame)
{
    uart_payload_info_t *p_payload = (uart_payload_info_t *)frame->p_payload;

    switch (p_payload->op_code)
    {
        case OPC_OTA_MCU_START:
        case OPC_OTA_MCU_BIN_REQ:
        case OPC_OTA_MCU_DOWNLOAD_RESULT:
        case OPC_OTA_MCU_RESULT:
            if (NULL != s_uart_recv_info.recv_ota_data_cb)
            {
                s_uart_recv_info.recv_ota_data_cb(uart_num, p_payload, frame->payload_len);
            }
            break;

        default:
            if (NULL != s_uart_recv_info.recv_data_cb)
            {
                s_uart_recv_info.recv_data_cb(uart_num, p_payload, frame->payload_len);
            }
            break;
    }
}

/**
 * @brief  UART传输层数据接收传入函数
 * @param[in]  uart_num             [串口编号]
 * @param[in]  p_data               [数据]
 * @param[in]  len                  [数据长度]
 * @return     void
 * @note  UART层接收到数据后通过这个接口传入传输层，BLE层需要按照这个接口格式对接；
 *          传输层通过这个接口获取到输入数据之后，进行组合完整的数据帧，校验成功后把
 *          解析的正确数据返回给应用层
 */
static void vesync_uart_tl_data_decode(VHAL_UART_PORT_E uart_num, uint8_t *p_data, uint16_t len)
{
    uint16_t idx = 0;

    if (NULL == p_data)
    {
        return;
    }

    LOG_RAW_HEX(LOG_DEBUG, "[TT] uart recv: ", p_data, len);

    for (idx = 0; idx < len; idx++)
    {
        if (0 == vesync_tl_frame_decode(p_data[idx], UART_FRAME_PAYLOAD_MAX_LEN, &s_uart_recv_info.recv_frame_info))
        {
            // SDK_LOG(LOG_DEBUG, " s_uart_frm_recv_info.ctrl=0x%02x\r\n", s_uart_frm_recv_info.ctrl);
            // SDK_LOG(LOG_DEBUG, " s_uart_frm_recv_info.sequence_id=0x%02x\r\n", s_uart_frm_recv_info.sequence_id);
            // SDK_LOG(LOG_DEBUG, " s_uart_frm_recv_info.payload_length=0x%04x\r\n", s_uart_frm_recv_info.payload_length);
            // SDK_LOG(LOG_DEBUG, " s_uart_frm_recv_info.checksum=0x%02x\r\n", s_uart_frm_recv_info.checksum);
            // SDK_LOG(LOG_DEBUG, " s_uart_frm_recv_info.payload[0]=0x%02x\r\n", s_uart_frm_recv_info.p_payload[0]);

            if (0 == vesync_tl_frame_checksum_verify(&s_uart_recv_info.recv_frame_info))
            {
                if (TL_PAYLOAD_PROTOCOL_VERSION == s_uart_recv_info.recv_frame_info.ctrl.bitN.version)
                {
                    if (0 == s_uart_recv_info.recv_frame_info.ctrl.bitN.ack_flag)  // 不是应答包
                    {
                        // SDK_LOG(LOG_INFO, " no ack pack\r\n");
                        /* 判断是否为重复接收的数据 */
                        // if( (s_uart_recv_frm_record.sequence_id != s_uart_frm_recv_info.sequence_id) ||
                        //     (s_uart_recv_frm_record.checksum != s_uart_frm_recv_info.checksum) )
                        {
                            s_uart_recv_info.recv_frame_record.sequence_id = s_uart_recv_info.recv_frame_info.seq_id;
                            s_uart_recv_info.recv_frame_record.checksum    = s_uart_recv_info.recv_frame_info.checksum;

                            vesync_uart_handle_rx_data(uart_num, &s_uart_recv_info.recv_frame_info);
                        }
                    }
                    else  //应答包
                    {
                        vesync_uart_handle_ack(&s_uart_recv_info.recv_frame_info);
                    }
                }
                else
                {
                    vesync_uart_tl_pkg_send_ack(uart_num, 1, NULL, 0);        // ACK组包并发送
                    SDK_LOG(LOG_INFO, "Version error\r\n");
                }
                //SDK_LOG(LOG_INFO, "verify_ok\r\n");
            }
            else
            {
                vesync_uart_tl_pkg_send_ack(uart_num, 1, NULL, 0);            // ACK组包并发送
                SDK_LOG(LOG_INFO, "Verify failed, The correct checksum is 0x%02x\r\n", vesync_tl_frame_checksum_cal(&s_uart_recv_info.recv_frame_info));
            }
        }
    }
}


/*-----------------------------------------------------------------------------*
 *                           SDK内部函数API实现                                      *
 *-----------------------------------------------------------------------------*/

/**
 * @brief  应用层串口数据发送函数
 * @param[in] request_flag          [用于指示接收该数据包的设备是否需要回应答，0：不需要回应答  1：需要回应答；]
 * @param[in]  uart_num             [串口编号]
 * @param[in] opcode                [操作码]
 * @param[in] p_dat                 [发送数据，无数据传入NULL（len必须为0）]
 * @param[in] len                   [数据长度]
 * @return    int32_t               [返回0表示发送成功，非零为失败]
 */
int32_t vesycn_uart_send_data(uint8_t request_flag, VHAL_UART_PORT_E uart_num, uint16_t opcode, uint8_t *p_dat, uint16_t len)
{
    int32_t ret = 0;
    uint16_t tx_data_len = 0;
    uint8_t *p_tx_data = NULL;

    p_tx_data = (uint8_t*)malloc(len + 4); // payload协议头部长度为4bytes
    if (NULL == p_tx_data)
    {
        return SDK_FAIL;
    }
    memset(p_tx_data, 0, len + 4);

    ret = vesync_tl_payload_encode(opcode, 0, p_dat, len, p_tx_data, &tx_data_len);
    if(0 != ret)
    {
        free(p_tx_data);
        return SDK_FAIL;
    }

    ret = vesync_uart_tl_pkg_send_data(uart_num, p_tx_data, tx_data_len, request_flag);
    free(p_tx_data);
    if (UART_TL_SUCCESS != ret)
    {
        return SDK_FAIL;
    }

    return SDK_OK;
}

/**
 * @brief  应答发送函数  接收回调通过判断frame_recv_info.ctrl.bitN.request_flag是否需要应答
 * @param[in]  err_flag             [错误标志位，0：无错误； 1：错误；]
 * @param[in]  uart_num             [串口编号]
 * @param[in]  opcode               [操作码]
 * @param[in]  status_code          [状态码]
 * @param[in]  p_dat                [数据，无数据传入NULL（len必须为0）]
 * @param[in]  len                  [数据长度]
 * @return     int32_t              [返回0表示发送成功，非零为失败]
 */
int32_t vesync_uart_send_ack(uint8_t err_flag, VHAL_UART_PORT_E uart_num, uint16_t opcode, uint16_t status_code, uint8_t *p_dat, uint16_t len)
{
    int32_t ret = 0;
    uint16_t tx_data_len = 0;
    uint8_t *p_tx_data = NULL;

    p_tx_data = (uint8_t*)malloc(len + 4); // payload协议头部长度为4bytes
    if (NULL == p_tx_data)
    {
        return SDK_FAIL;
    }
    memset(p_tx_data, 0, len + 4);

    ret = vesync_tl_payload_encode(opcode, status_code, p_dat, len, p_tx_data, &tx_data_len);
    if(0 != ret)
    {
        free(p_tx_data);
        return SDK_FAIL;
    }

    vesync_uart_tl_pkg_send_ack(uart_num, err_flag, p_tx_data, tx_data_len);
    free(p_tx_data);

    return SDK_OK;
}

/**
 * @brief  应答发送函数  接收回调通过判断frame_recv_info.ctrl.bitN.request_flag是否需要应答
 * @param[in]  seq_id               [序列号]
 * @param[in]  err_flag             [错误标志位，0：无错误； 1：错误；]
 * @param[in]  uart_num             [串口编号]
 * @param[in]  opcode               [操作码]
 * @param[in]  status_code          [状态码]
 * @param[in]  p_dat                [数据，无数据传入NULL（len必须为0）]
 * @param[in]  len                  [数据长度]
 * @return     int32_t              [返回0表示发送成功，非零为失败]
 */
int32_t vesync_uart_send_ack_with_seq_id(uint8_t seq_id, uint8_t err_flag,
                VHAL_UART_PORT_E uart_num, uint16_t opcode, uint16_t status_code, uint8_t *p_dat, uint16_t len)
{
    int32_t ret = 0;
    uint16_t tx_data_len = 0;
    uint8_t *p_tx_data = NULL;

    p_tx_data = (uint8_t*)malloc(len + 4); // payload协议头部长度为4bytes
    if (NULL == p_tx_data)
    {
        return SDK_FAIL;
    }
    memset(p_tx_data, 0, len + 4);

    ret = vesync_tl_payload_encode(opcode, status_code, p_dat, len, p_tx_data, &tx_data_len);
    if(0 != ret)
    {
        free(p_tx_data);
        return SDK_FAIL;
    }

    vesync_uart_tl_pkg_send_ack_with_seq_id(uart_num, seq_id, err_flag, p_tx_data, tx_data_len);
    free(p_tx_data);

    return SDK_OK;
}

/**
 * @brief 检查发送是否在忙
 * @return     bool                     [true, 在忙; false, 空闲]
 */
bool vesync_uart_check_send_busy(void)
{
    return s_uart_send_info.send_busy_flag;
}

/**
 * @brief  串口发送后的应答处理
 * @param[in]  event                    [串口数据发送成功/失败事件]
 * @param[in]  p_payload                [发送应答帧的数据字段]
 * @param[in]  payload_len              [应答帧的payload长度]
 * @param[in]  p_msg                    [发送的消息]
 * @return     void
 */
void vesync_uart_rsp_process(UART_SEND_TYPE_E event, tl_payload_info_t *p_payload, uint16_t payload_len, uart_msg_queue_t *p_msg)
{
    if (NULL != s_uart_send_info.tx_data_event_cb)
    {
        if (NULL != p_payload)
        {
            s_uart_send_info.tx_data_event_cb(event, (uart_payload_info_t *)p_payload, payload_len, p_msg);
        }
        else
        {
            s_uart_send_info.tx_data_event_cb(event, NULL, 0, p_msg);
        }
    }
}

/**
 * @brief  注册UART串口服务数据接收回调函数，ota cb处理具体的业务
 * @param[in]  cb                   [串口数据接收回调函数]
 */
void vesync_uart_reg_recv_ota_cb(uart_recv_data_cb_t cb)
{
    s_uart_recv_info.recv_ota_data_cb = cb;
}

/**
 * @brief  注册UART串口发送返回事件回调函数，用于MCU OTA业务
 * @param[in]  cb                   [发送返回事件回调函数]
 */
void vesync_uart_reg_tx_event_ota_cb(uart_tx_event_cb_t cb)
{
    s_uart_send_info.tx_ota_event_cb = cb;
}

/*-----------------------------------------------------------------------------*
 *                           外部函数API实现                                         *
 *-----------------------------------------------------------------------------*/

/**
 * @brief  vesync平台串口服务初始化
 * @param[in]  rx_pin               [接收管脚]
 * @param[in]  tx_pin               [发送管脚]
 * @param[in]  baudrate             [波特率]
 * @return     void
 */
void vesync_uart_init(uint32_t rx_pin, uint32_t tx_pin, uint32_t baudrate)
{
    VHAL_UART_PORT_E uart_num = VHAL_UART_NUM_0;

    if (PR_UART_NUM > VHAL_UART_NUM_2)
    {
        SDK_LOG(LOG_ERROR, "UART port(%d) unsupport!\n", PR_UART_NUM);
        return;
    }

    // 1. 串口初始化配置
    vhal_uart_init();
    vesync_uart_tl_init();          // 串口传输层协议处理配置

    // 2-1. 配置第1路串口
    uart_num = PR_UART_NUM;         // 配置文件指定
    vhal_uart_config(rx_pin, tx_pin, uart_num, baudrate);           // 串口参数配置
    vhal_uart_reg_recv_cb(uart_num, vesync_uart_tl_data_decode);    // HAL层UART接收到数据回调

    // 2-2. 配置第2路串口
    // TODO

    // 3. 发送/接收数据处理

}

/**
 * @brief  待发送数据发送到串口发送队列中
 * @return  int32_t            [0表示发送成功，其他值表示发送失败]
 */
int32_t vesync_uart_send(uart_msg_queue_t *p_msg)
{
    return vesync_uart_msg_queue_put(p_msg);
}

/**
 * @brief  注册UART数据接收回调函数，应用层cb处理具体的业务
 * @param[in]  cb                   [串口数据接收回调函数]
 */
void vesync_uart_reg_recv_cb(uart_recv_data_cb_t cb)
{
    s_uart_recv_info.recv_data_cb = cb;
}

/**
 * @brief  注册UART串口发送返回事件回调函数
 * @param[in]  cb                   [发送返回事件回调函数]
 */
void vesync_uart_reg_tx_event_cb(uart_tx_event_cb_t cb)
{
    s_uart_send_info.tx_data_event_cb = cb;
}


