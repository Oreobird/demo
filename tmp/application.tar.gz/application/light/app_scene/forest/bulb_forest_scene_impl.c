/**
* Copyright © Vesync Technologies Co.Ltd. 2022. All rights reserved
* @file         bulb_forest_scene_impl.c
* @brief        森林场景回调业务实现
* @author       Joshua
* @date         2022-1-14
*/

#include <string.h>
#include "vesync_log.h"
#include "vesync_common.h"
#include "forest.h"
#include "light.h"

static int forest(void *param)
{
    UNUSED(param);
    APP_LOG(LOG_DEBUG, "forest scene\n");
    light_param_t light_param[] = {{0, 0, 1900, 8000, 100}, {0, 0, 2500, 10000, 100}};
    app_light_color_flow(light_param, SIZEOF_ARRAY(light_param), 1, LIGHT_REFLESH_INTERVAL_MS, 0, true);
    return APP_OK;
}

int forest_light_scene_impl_init(void)
{
    light_scene_t light_scene;
    memset(&light_scene, 0, sizeof(light_scene_t));
    light_scene.light_cb = forest;
    return forest_light_scene_reg(&light_scene);
}


