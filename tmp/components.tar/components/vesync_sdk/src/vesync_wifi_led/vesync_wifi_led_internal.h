/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_wifi_led_internal.h
 * @brief       WiFi指示灯控制接口
 * @date        2021-05-08
 */

#ifndef __VESYNC_WIFI_LED_INTERNAL_H__
#define __VESYNC_WIFI_LED_INTERNAL_H__

#include <stdlib.h>
#include <stdint.h>
#include "vesync_timer.h"
#include "vesync_wifi_led.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct
{
    WIFI_LED_BEHAVIOR_E behavior;
    wifi_led_cfg_t led_cfg;
} wifi_led_behavior_cfg_t;


/*
 * @brief wifi LED对象信息
 */
typedef struct
{
    uint32_t blink_count;                       // wifi指示灯闪烁次数
    uint32_t cur_blink_count;                   // 记录当前闪烁的次数
    uint8_t  blink_off_times;                   // WiFi指示灯闪烁时熄灭时间与点亮时间的倍数
    uint8_t  cur_off_times;                     // 记录当前闪烁的关灯时间
    uint8_t  blink_flag;                        // 记录当前闪烁的状态
    uint8_t  double_blink_flag;                 // 双闪标志
    WIFI_LED_STATUS_E led_status_old;           // LED灯的上次亮灭状态
    WIFI_LED_STATUS_E led_status_new;           // LED灯的最新亮灭状态
    WIFI_LED_BEHAVIOR_E led_behavior;           // LED灯当前行为状态
    wifi_led_info_t led_info;                   // LED灯配置信息
    vesync_timer_t led_blink_timer;             // wifi指示灯刷新定时器
    wifi_led_turn_cb_t wifi_led_turn_callback;  // 定义WiFi LED状态切换回调函数指针
    wifi_led_mcu_control_cb_t wifi_led_mcu_control_cb;  // Wi-Fi LED控制回调函数，亮/灭/闪烁由MCU控制，Wi-Fi模块只对灯效进行配置
} wifi_led_t;

/**
 * @brief 获取WIFI指示灯闪烁模式
 * @return                      [wifi指示灯闪烁行为]
 */
WIFI_LED_BEHAVIOR_E vesync_wifi_led_get_behavior(void);

/**
 * @brief 设置MCU指示灯数据
 * @return  bool                [true 由MCU执行 ； false 主设备执行]
 */
bool vesync_wifi_led_set_mcu_data(void);

#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_WIFI_LED_INTERNAL_H__ */

