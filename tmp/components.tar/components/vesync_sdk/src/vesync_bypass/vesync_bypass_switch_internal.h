/*
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file        vesync_bypass_switch_internal.h
* @brief       bypass处理接口
* @date        2021-05-13
*/
#ifndef __VESYNC_BYPASS_INTERNAL_H__
#define __VESYNC_BYPASS_INTERNAL_H__

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief 开关配置
*/
typedef struct
{
    uint8_t id;                     // 0代表总开关，1~N代表分开关
    bool enable;                    // true: 设备开机，false: 设备关机
} bypass_switch_data_t;


#ifdef __cplusplus
}
#endif /* __VESYNC_BYPASS_INTERNAL_H__ */

