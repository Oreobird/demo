/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        ledstrip.h
 * @brief       Application入口函数
 * @author      Lind
 * @date        2021-08-25
 */

#ifndef __LEDSTRIP_H__
#define __LEDSTRIP_H__

#include "vesync_device.h"
#include "vesync_task.h"


#ifdef __cplusplus
 extern "C" {
#endif /* __cplusplus */

#define LS_APP_TASK_NAME                   "app_task"
#define LS_APP_TASK_STACSIZE               (1024*2)
#define LS_APP_TASK_PRIO                   TASK_PRIORITY_NORMAL
#define LS_EVENT_QUEUE_MAX_NUM             16

/**
 * @brief  ledstrip应用事件id
 */
typedef enum
{
    LS_EV_RESET = 0,
    LS_EV_BEFORE_NETCFG,
    LS_EV_NETCFG,
    LS_EV_PRODUCTION,
    LS_EV_UNKNOWN,
} LS_EV_E;

/**
 * @brief  ledstrip应用事件来源
 */
typedef enum
{
    LS_ACT_SRC_INIT = 0,        // 按键/指示灯控制来源：初始化
    LS_ACT_SRC_BTN,             // 按键/指示灯控制来源：按键执行
    LS_ACT_SRC_UNKNOW,          // 按键/指示灯控制来源：未知
} LS_ACT_SRC_E;

/**
 * @brief  ledstrip应用事件结构体
 */
typedef struct
{
    LS_EV_E id;
    LS_ACT_SRC_E act_src;
} ls_ev_t;


/**
 * @brief  给ledstrip应用任务发通知
 * @param[in]   ev              [通知消息]
 * @return     int              [成功：APP_OK，失败：APP_FAIL]
 */
int ls_app_task_notify(ls_ev_t *ev);


#ifdef __cplusplus
 }
#endif /* __cplusplus */
 
#endif /* __LEDSTRIP_H__ */


