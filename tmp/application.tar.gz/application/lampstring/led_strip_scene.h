/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file    led_strip_scene.h
* @brief   灯效模式参数
* @author  Lind
* @date     2021-12-19
*/

#ifndef __LED_STRIP_SCENE_H__
#define __LED_STRIP_SCENE_H__

#include <stdbool.h>
#include <stdint.h>

#include "vesync_mutex.h"

#ifdef __cplusplus
extern "C" {
#endif

/*
 * @brief LedStrip 模式
 */
typedef enum
{
    LS_LED_MODE_OFF = 0,
    LS_LED_MODE_STATIC,
    LS_LED_MODE_DYNAMIC,
} LS_LED_MODE_E;

/*
 * @brief LedStrip 动态灯效模式分类
 */
typedef enum
{
    LS_LED_BREATHING = 0,
    LS_LED_GRADIENT,
    LS_LED_SWITCH,
    LS_LED_SWITCH_STEP,
} LS_LED_DYNAMIC_E;

/*
 * @brief LedStrip 静态灯效模式分类
 */
typedef enum
{
    LS_LED_WHITE = 0,          // 白光
    LS_LED_HSV,                // 彩光
    LS_LED_MULTI_SEG,          // 分段
    LS_LED_OFF,
} LS_LED_STATIC_E;

/*
 * @brief LedStrip 灯光参数 彩光HSV
 */
typedef struct
{
    uint16_t H;
    uint16_t S;
    uint16_t V;
    uint16_t white;
} ls_hsv_t;

/*
 * @brief LedStrip 动态灯效参数
 */
typedef struct
{
    uint8_t node_num;
    uint8_t times;                          // 循环执行次数 ，0代表一直执行
    uint16_t step_num;                      // 保持步数，相当于颜色模式存在时间
    LS_LED_DYNAMIC_E mode;
    uint8_t diff_num;                       // 动态灯效的一个参数
    ls_hsv_t *mode_head;                    // 模式灯效节点头
} ls_dynamic_param_t;

typedef struct
{
    LS_LED_STATIC_E mode;   // 静态灯效模式
    uint8_t node_num;
    ls_hsv_t *color_head;
} ls_static_param_t;

/*
 * @brief LedStrip 情景灯效参数
 */
typedef struct
{
    LS_LED_MODE_E light_mode;                 // 灯效模式
    vesync_mutex_t mutex;                     // 模式锁
    union
    {
        ls_static_param_t *static_param;             // 静态灯效参数，当前最多是30个色彩节点
        ls_dynamic_param_t *dynamic_param;      // 动态灯效参数
    } param;
} ls_scene_t;

/**
* @brief 清除应用层保存的场景数据
*/
void ls_scene_clear(void);

/**
* @brief 获取默认场景参数
* @param[in]  id        [id]
* @return  ls_scene_t*  [场景指针]
*/
ls_scene_t *ls_get_default_scene(uint16_t id);

/**
* @brief 获取sceneId对应的场景序号
* @param[in]  id                [id]
* @param[in]  custom_scene_num  [自定义场景数量]
* @param[out]  *index           [序号]
* @return  int                  [APP_OK/APP_FAIL]
*/
int ls_get_id_index(uint16_t id, uint8_t custom_scene_num, uint8_t *index);

/**
* @brief 获取场景Id对应的参数指针
* @param[in/out]  *scene_id     [场景id]
* @param[in]  custom_scene_num  [自定义场景数量]
* @param[in]  next_flag         [是否获取下一个场景id的参数]
* @param[out] **p_scene         [场景参数]
* @return     int               [APP_OK/APP_FAIL]
*/
int ls_get_scene_pointer(uint16_t *scene_id, uint8_t custom_scene_num, bool next_flag, ls_scene_t **p_scene);

/**
* @brief 设置静态场景参数(来源于bypass)
* @param[out]  **p_scene        [场景参数指针]
* @param[in]  led_mode          [led模式]
* @return     int               [APP_OK/APP_FAIL]
*/
int ls_set_static_scene(ls_scene_t **p_scene, LS_LED_MODE_E led_mode);

/**
* @brief 读取flash中的自定义场景数据
* @param[in]  custom_scene_num      [自定义场景数量]
* @return     int                   [APP_OK/APP_FAIL]
*/
int ls_get_scene(uint8_t custom_scene_num);

/**
* @brief 模式变量初始化
*/
void ls_scene_init(void);

/**
* @brief 对静态灯效显示buf上锁or释放锁
* @param[in]  lock_flag     [true上锁/false释放锁]
*/
void ls_get_scene_lock(bool lock_flag);

/**
* @brief 检查id是否存在
* @param[in]  id                    [id]
* @return  int                      [错误码]
*/
int ls_scene_id_check(uint16_t id);

/**
* @brief 获取id数组
* @return  uint16_t*    [数组指针]
*/
uint16_t* ls_get_id_list(void);

/**
* @brief 生成新的scene id
* @param[in]  custom_scene_num      [自定义场景数量]
* @return  uint16_t                 [新id，0为失败]
*/
uint16_t ls_gen_new_scene_id(uint8_t custom_scene_num);

/**
* @brief    添加自定义场景
* @param[in]  scene_id      [id]
* @return  int              [APP_OK/APP_FAIL]
*/
int ls_add_scene(uint16_t scene_id);

/**
* @brief    删除自定义场景
* @param[in]  scene_id      [id]
* @return  int              [APP_OK/APP_FAIL]
*/
int ls_del_scene(uint16_t scene_id);

/**
* @brief 通过序号获取场景id
* @param[in]  index     [场景序号]
* @return  uint16_t     [id]
*/
uint16_t ls_get_id_by_index(uint8_t index);


#ifdef __cplusplus
}
#endif

#endif

