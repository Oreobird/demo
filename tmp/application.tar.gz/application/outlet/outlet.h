/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        outlet.h
 * @brief       outlet相关功能
 * @author      Joshua
 * @date        2021-06-04
 */
#ifndef __OUTLET_H__
#define __OUTLET_H__

#include <stdint.h>
#include <stdbool.h>
#include "vesync_device.h"
#include "vesync_task.h"
#include "outlet_gpio.h"

#ifdef __cplusplus
extern "C" {
#endif

#define OUTLET_APP_TASK_NAME                    "app_task"
#define OUTLET_APP_TASK_PRIO                    TASK_PRIORITY_NORMAL
#define OUTLET_SWITCH_TURN_ON                   0x00000001   // 开关开启
#define OUTLET_SWITCH_TURN_OFF                  0x00000002   // 开关关闭

typedef enum
{
    OUTLET_EV_ON = 0,
    OUTLET_EV_OFF,
    OUTLET_EV_TOGGLE,
#if defined(OUTLET_ELEC_METERING) && (OUTLET_ELEC_METERING == 1)
    OUTLET_EV_REPORT_EXC,
    OUTLET_EV_SAVE_ELEC,
    OUTLET_EV_REPORT_ELEC,
#endif
    OUTLET_EV_PRODUCTION,
    OUTLET_EV_PCBA_TEST,
    OUTLET_EV_BEFORE_NETCFG,
    OUTLET_EV_NETCFG,
    OUTLET_EV_NET_CONNETED,
    OUTLET_EV_RESET,
    OUTLET_EV_UNKNOWN,
} OUTLET_EVENT_E;

typedef struct
{
    OUTLET_EVENT_E id;
    OUTLET_ACT_SRC_E act_src;
    char rsn[MAX_STAT_CHG_RSN_STR_LEN];
} outlet_ev_t;

/*
 * @brief 开关/设备的on/off状态
 */
 typedef struct
{
    uint8_t switch_idx;               // 开关序号
    bool is_on;                       // 开启/关闭标识
    char rsn[MAX_STAT_CHG_RSN_STR_LEN];     // 状态变更原因
} onoff_status_t;

/**
 * @brief  给switch应用任务发通知
 * @param[in]   event_id        [通知消息]
 * @return     int              [成功：SDK_OK，失败：SDK_FAIL]
 */
int outlet_app_task_notify(outlet_ev_t *ev);


#ifdef __cplusplus
}
#endif

#endif

