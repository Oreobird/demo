/**
* Copyright © Vesync Technologies Co.Ltd. 2022. All rights reserved
* @file         ledstrip_white_scene_impl.c
* @brief        白灯控制场景业务实现
* @author       Joshua
* @date         2022-1-24
*/

#include <string.h>
#include "vesync_log.h"
#include "vesync_common.h"
#include "device.h"
#include "light.h"
#include "white.h"

static int white_on(void *param)
{
    UNUSED(param);
    APP_LOG(LOG_DEBUG, "white on scene\n");

    dev_cfg_t *p_dev_cfg = app_device_cfg_get();
    VCOM_NULL_RET_CHK(p_dev_cfg, return APP_FAIL);
    light_param_t *light_param = &(p_dev_cfg->flash->cfg.light_param);
    app_light_white_on(light_param->color_temp, light_param->brightness, 0, p_dev_cfg->fade);
    return APP_OK;
}

static int white_off(void *param)
{
    UNUSED(param);
    APP_LOG(LOG_DEBUG, "white off scene\n");

    dev_cfg_t *p_dev_cfg = app_device_cfg_get();
    VCOM_NULL_RET_CHK(p_dev_cfg, return APP_FAIL);
    app_light_white_off(0, p_dev_cfg->fade);
    return APP_OK;
}

int white_on_light_scene_impl_init(void)
{
    light_scene_t light_scene;
    memset(&light_scene, 0, sizeof(light_scene_t));
    light_scene.light_cb = white_on;
    return white_on_light_scene_reg(&light_scene);
}

int white_off_light_scene_impl_init(void)
{
    light_scene_t light_scene;
    memset(&light_scene, 0, sizeof(light_scene_t));
    light_scene.light_cb = white_off;
    return white_off_light_scene_reg(&light_scene);
}

