/**
* Copyright © Vesync Technologies Co.Ltd. 2022. All rights reserved
* @file         app_sm2235.c
* @brief        sm2235驱动器创建接口
* @author       Joshua
* @date         2022-1-21
*/
#include <string.h>
#include "vesync_common.h"
#include "vesync_log.h"
#include "vesync_memory.h"
#include "vdrv_sm2235egh.h"
#include "light_drv.h"
#include "app_cfg.h"

static int destroy(light_drv_t *thiz)
{
    VCOM_SAFE_FREE(thiz);
    return APP_OK;
}

static int setup(light_drv_t *thiz)
{
    APP_LOG(LOG_INFO, "powered by sm2234egh\n");

    int ret = vdrv_sm2235egh_init(LIGHT_I2C_SDA_IO, LIGHT_I2C_SCL_IO);
    if (SDK_OK != ret)
    {
        APP_LOG(LOG_WARN, "sm2234egh init fail[%d]\n", ret);
    }
    APP_LOG(LOG_WARN, "1\n");

    ret = vdrv_sm2235egh_set_mode(RGBCW_MODE);
    if (SDK_OK != ret)
    {
        APP_LOG(LOG_WARN, "sm2234egh set mode fail[%d]\n", ret);
    }
    APP_LOG(LOG_WARN, "2\n");

    uint8_t rgb_cr = LIGHT_RED_MAX, cw_cr = LIGHT_COLD_MAX;
    ret = vdrv_sm2235egh_set_cr(&rgb_cr, &cw_cr);
    if (SDK_OK != ret)
    {
        APP_LOG(LOG_WARN, "sm2234egh set cr fail[%d]\n", ret);
    }
    APP_LOG(LOG_WARN, "3\n");

    return APP_OK;
}

static void output(light_drv_t *thiz, uint16_t ch_num, uint32_t *p_ch_duty)
{
    if (ch_num < 5)
    {
        return;
    }

    uint16_t ch_remap[5];
    ch_remap[LIGHT_RED_OUT_IO - 1] = p_ch_duty[LIGHT_CH_IDX_R];
    ch_remap[LIGHT_GREEN_OUT_IO - 1] = p_ch_duty[LIGHT_CH_IDX_G];
    ch_remap[LIGHT_BULE_OUT_IO - 1] = p_ch_duty[LIGHT_CH_IDX_B];
    ch_remap[LIGHT_COLD_OUT_IO - 1] = p_ch_duty[LIGHT_CH_IDX_C];
    ch_remap[LIGHT_WARM_OUT_IO - 1] = p_ch_duty[LIGHT_CH_IDX_W];

    sm2235egh_gray_t rgb, cw;
    rgb.rgb.out_1r = ch_remap[0];
    rgb.rgb.out_2g = ch_remap[1];
    rgb.rgb.out_3b = ch_remap[2];
    cw.cw.out_4c = ch_remap[3];
    cw.cw.out_5w = ch_remap[4];
    int ret = vdrv_sm2235egh_set_output(&rgb, &cw);
    if (ret != SDK_OK)
    {
        APP_LOG(LOG_WARN, "sm2235egh_set_output fail\n");
    }
}

light_drv_t *light_i2c_drv_create(void)
{
    light_drv_t *thiz = (light_drv_t *)vesync_malloc(sizeof(light_drv_t));
    if (thiz != NULL)
    {
        thiz->destroy = destroy;
        thiz->setup = setup;
        thiz->output = output;
    }

    return thiz;
}


