/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vhal_i2c.c
 * @brief       i2c读写接口
 * @author      Joshua
 * @date        2021-09-14
 */

#include "vhal_i2c.h"
#include "vesync_common.h"


int32_t vhal_i2c_master_init(uint8_t i2c_num, uint8_t sda_io, uint8_t scl_io, uint32_t speed)
{
    return VHAL_OK;
}

int32_t vhal_i2c_master_read(uint8_t i2c_num, bool check_ack, uint8_t addr, uint8_t *p_data, int32_t len)
{
    return VHAL_OK;
}

int32_t vhal_i2c_master_write(uint8_t i2c_num, bool check_ack, uint8_t addr, uint8_t *p_data, int32_t len)
{
    return VHAL_OK;
}

int32_t vhal_i2c_master_write_stop_condition(uint8_t i2c_num)
{
    return VHAL_OK;
}

