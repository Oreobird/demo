import hashlib
import hmac
from math import ceil

hash_len = 32
def hmac_sha256(key, data):
    return hmac.new(key, data, hashlib.sha256).digest()

def hkdf(length, ikm, salt=b"", info=b""):
    prk = hmac_sha256(salt, ikm)
    t = b""
    okm = b""
    for i in range(ceil(length / hash_len)):
        t = hmac_sha256(prk, t + info + bytes([1+i]))
        okm += t
    return okm[:length]

mock_ss_key = '5DAD63B9FADC7599B893325F001A3D42484D3A13D03EB225EE59FB98CE7769DE'
mock_ss_key = bytes.fromhex(mock_ss_key)
mock_oob = '010203040506'
mock_oob = bytes.fromhex(mock_oob)
print("mock_ss_key", mock_ss_key.hex())
print("mock_oob", mock_oob.hex())

mock_ltk = hkdf(32, mock_ss_key, mock_oob)
print("ltk", mock_ltk.hex())

mock_eph_key = '3B6ED0754D568F65C5A3F4E38A072BFBC792517EA574C5CA674B8846D5DC52D0'
mock_eph_key = bytes.fromhex(mock_eph_key)
print("mock_eph_key", mock_eph_key.hex())

mock_salt = "salt"
mock_info = "info"
mock_salt = bytes(mock_salt, encoding="utf8")
mock_info = bytes(mock_info, encoding="utf8")
print("mock_salt", mock_salt.hex())
print("mock_info", mock_info.hex())

session_key = hkdf(64, mock_ltk + mock_eph_key, mock_salt, mock_info)
print("session_key.dev_key", session_key[:16].hex())
print("session_key.app_key", session_key[16:32].hex())
print("session_key.dev_iv", session_key[32:36].hex())
print("session_key.app_iv", session_key[36:40].hex())
print("session_key.resv", session_key[40:].hex())
