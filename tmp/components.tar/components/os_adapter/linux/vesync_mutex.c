/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_mutex.c
 * @brief       mutex抽象层，封装linux posix互斥量相关接口
 * @author      Joshua
 * @date        2021-04-20
 */

#include <stdlib.h>
#include <pthread.h>
#include "vesync_common.h"
#include "vesync_os.h"
#include "vesync_mutex.h"

/*
 * @brief  创建mutex
 * @param[in]  mtx                     [互斥量结构体指针]
 * @return int                         [成功：0；失败：-1]
 */
int vesync_mutex_new(vesync_mutex_t *mtx)
{
    VCOM_NULL_PARAM_CHK(mtx, return -1);
    pthread_mutex_t *pmtx = malloc(sizeof(pthread_mutex_t));
    if (pmtx == NULL)
    {
        return -1;
    }

    pthread_mutex_init(pmtx, NULL);
    mtx->handle = pmtx;
    return 0;
}

/*
 * @brief  mutex上锁
 * @param[in]  mtx                     [互斥量结构体指针]
 * @return int                         [成功：0；失败：返回-1]
 */
int vesync_mutex_lock(vesync_mutex_t *mtx)
{
    VCOM_NULL_PARAM_CHK(mtx, return -1);
    VCOM_NULL_PARAM_CHK(mtx->handle, return -1);
    pthread_mutex_lock(mtx->handle);
    return 0;
}

/*
 * @brief  mutex解锁
 * @param[in]  mtx                     [互斥量结构体指针]
 * @return int                         [成功：0；失败：返回-1]
 */
int vesync_mutex_unlock(vesync_mutex_t *mtx)
{
    VCOM_NULL_PARAM_CHK(mtx, return -1);
    VCOM_NULL_PARAM_CHK(mtx->handle, return -1);
    pthread_mutex_unlock(mtx->handle);
    return 0;
}

/*
 * @brief  销毁mutex
 * @param[in]  mtx                     [互斥量结构体指针]
 * @return int                         [成功：0；失败：返回-1]
 */
int vesync_mutex_free(vesync_mutex_t *mtx)
{
    VCOM_NULL_PARAM_CHK(mtx, return -1);
    VCOM_NULL_PARAM_CHK(mtx->handle, return -1);
    pthread_mutex_destroy(mtx->handle);
    free(mtx->handle);
    return 0;
}

