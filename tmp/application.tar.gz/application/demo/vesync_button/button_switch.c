/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        button_switch.c
 * @brief       开关键业务实现
 * @author      Joshua
 * @date        2021-12-23
 */
#include <stdint.h>
#include <string.h>
#include <stdbool.h>

#include "vesync_log.h"
#include "vesync_common.h"

#include "button.h"

#define BUTTON_GPIO_NUM 9

static void single_click_handle(void)
{
    APP_LOG(LOG_DEBUG, "------Trigger single click-------\n");
}

int button_switch_init(void)
{
    APP_LOG(LOG_INFO, "Vesync APP Demo start\n");

    int ret = SDK_FAIL;

    btn_cfg_t cfg;

    memset(&cfg, 0, sizeof(btn_cfg_t));
    cfg.gpio = BUTTON_GPIO_NUM;
    cfg.active_level = ACTIVE_LOW;

    ret = vesync_button_add(&cfg);
    if (ret != SDK_OK)
    {
        APP_LOG(LOG_ERROR, "button add fail\n");
        return APP_FAIL;
    }

    ret = vesync_button_reg_cb(BUTTON_GPIO_NUM, EV_SINGLE_CLICK, single_click_handle);
    if (ret != SDK_OK)
    {
        APP_LOG(LOG_ERROR, "button reg cb fail\n");
        vesync_button_del(BUTTON_GPIO_NUM);
        return APP_FAIL;
    }

    return APP_OK;
}

int button_switch_deinit(void)
{
    return (SDK_OK == vesync_button_del(BUTTON_GPIO_NUM)) ? APP_OK : APP_FAIL;
}

