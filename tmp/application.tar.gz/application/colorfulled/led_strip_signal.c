/**
 *  Copyright © Vesync Technologies Co.Ltd. 2019-2021. All rights reserved
 * @file        vesync_led_strip_signal.c
 * @brief       led strip color generrated signal function
 * @author      henrik
 * @date        2021-09-16
 */
#include <math.h>
#include <string.h>
#include "vesync_memory.h"
#include "led_strip_signal.h"

 static rgb_calibration_t s_led_strip_calibration = NULL;



/**
 * @brief 注册颜色校准接口
 * @param[in]  cb                            [颜色校准回调接口]
 * @note
 */
void led_strip_reg_rgb_calibrate_cb(rgb_calibration_t cb)
{
    s_led_strip_calibration = cb;
}


/**
 * @brief hsv颜色空间转化成RGB空间
 * @param[out] rgb                            [rgb 分量 ]
 * @param[in]  hsv                            [hsv 分量]
 * @return     int                          [成功或失败]
 * @note
 */
int  led_strip_hsv2rgb(rgb_color_t *rgb, hsv_color_t *hsv)
{
    int32_t i = 0 ;
    float   f = 0.0 , H = 0.0;
    float a = 0.0,b = 0.0,c = 0.0;
    int ret = SUCCESS;

    if ((NULL == rgb)||(NULL == hsv))
    {
        return FAILURE;
    }

    if (0.0 == hsv->value)
    {
        rgb->red = rgb->blue = rgb->green = 0;
    }
    else
    {
        H = hsv->hue/60.0;
        i = floor(H);
        f = H - i;
        a = hsv->value * (1 - hsv->saturation)*255;
        b = hsv->value *(1 - hsv->saturation * f)*255;
        c =  hsv->value  * ( 1 - hsv->saturation * ( 1 - f ))*255;

        i = i % 6;
        switch(i)
        {
            case 0:
                rgb->red = (int)(hsv->value*255);
                rgb->green = (int)c;
                rgb->blue = (int)a;
                break;
            case 1:
                rgb->red = (int)b;
                rgb->green = (int)(hsv->value*255);
                rgb->blue = (int)a;
                break;
            case 2:
                rgb->red =(int)a;
                rgb->green = (int)(hsv->value*255);
                rgb->blue = (int)c;
                break;
            case 3:
                rgb->red =(int)a;
                rgb->green = (int)b;
                rgb->blue = (int)(hsv->value*255);
                break;
            case 4:
                rgb->red = (int)c;
                rgb->green = (int) a;
                rgb->blue = (int)(hsv->value*255);
                break;
            case 5:
                rgb->red = (int)(hsv->value*255);
                rgb->green = (int)a;
                rgb->blue = (int)b;
                break;
            default:
                break;
        }
    }

    if (NULL != s_led_strip_calibration)
    {
        ret = s_led_strip_calibration(rgb);
    }

    return ret;
}


/**
 * @brief 计算灯带颜色正弦值
 * @param[in]  x                            [曲线 x轴坐标值]
 * @param[out] y                            [曲线 y轴坐标值 正弦值 ]
 * @param[in]  info                         [曲线信息]
 * @return     int                          [成功或失败]
 * @note
 */
int  led_strip_signal_sin(uint32_t x, float * y, led_strip_signal_info_t info)
{
    float min = info.amplitude_min;
    float max = info.amplitude_max;
    float apm = max - min;
    float w = 2*PI/info.period ;

    if (NULL == y)
    {
        return FAILURE;
    }

    if (apm < 0)
    {
        max  = min + info.range;
        min  = info.amplitude_max;
        apm = max - min;
    }

    *y = apm * sin(w*x) + min + 180;

    if (*y > info.range)
    {
        *y -= info.range;
    }
    return SUCCESS;
}

/**
 * @brief 计算灯带颜色三角曲线值
 * @param[in]  x                            [曲线 x轴坐标值]
 * @param[out] y                            [曲线 y轴坐标值 三角曲线值 ]
 * @param[in]  info                         [曲线信息]
 * @return     int                          [成功或失败]
 * @note
 */
int  led_strip_signal_triangle(uint32_t x, float * y, led_strip_signal_info_t info)
{
    float min = info.amplitude_min;
    float max = info.amplitude_max;
    float apm = max - min;
    uint32_t half_period = info.period>>1;
    uint32_t temp_x = x % info.period;
    float k = 0;

    if ((NULL == y)||(fabs(apm) < 0.000001))
    {
        return FAILURE;
    }

    if (apm < 0)
    {
        max  = min + info.range;
        min  = info.amplitude_max;
        apm = max - min;
    }

    half_period = half_period == 0 ? 1 : half_period;
    k = apm / half_period;
    if (temp_x <= half_period)
    {
        *y = k * temp_x + min;
    }
    else{
        *y = max - k * (temp_x-half_period);
    }

    if (*y > info.range)
    {
        *y -= info.range;
    }
    return SUCCESS;
}

/**
 * @brief 计算灯带颜色方波值
 * @param[in]  x                            [曲线 x轴坐标值]
 * @param[out] y                            [曲线 y轴坐标值 方波值 ]
 * @param[in]  info                         [曲线信息]
 * @return     int                          [成功或失败]
 * @note
 */
int  led_strip_signal_square(uint32_t x, float * y, led_strip_signal_info_t info)
{
    uint32_t half_period = info.period>>1;
    uint32_t temp_x = x % info.period;

    if (NULL == y)
    {
        return FAILURE;
    }

    if (temp_x >= half_period)
    {
        *y = info.amplitude_max;
    }
    else{
        *y = info.amplitude_min;
    }

    if (*y > info.range)
    {
        *y -= info.range;
    }
    return SUCCESS;
}

/**
 * @brief 计算灯带颜色斜坡曲线值
 * @param[in]  x                            [曲线 x轴坐标值]
 * @param[out] y                            [曲线 y轴坐标值 斜坡曲线值 ]
 * @param[in]  info                         [曲线信息]
 * @return     int                          [成功或失败]
 * @note
 */
int  led_strip_signal_slope(uint32_t x, float * y, led_strip_signal_info_t info)
{
    float min = info.amplitude_min;
    float max = info.amplitude_max;
    float apm = max - min;
    uint32_t temp_x = x % info.period;
    float k = 0;

    if ((NULL == y)||(fabs(apm) < 0.000001))
    {
        return FAILURE;
    }

    if (apm < 0)
    {
        max  = min + info.range;
        min  = info.amplitude_max;
        apm = max - min;
    }

    info.period = info.period == 0 ? 1 : info.period;
    k = apm / info.period;
    *y = k * temp_x + min;

    if (*y > info.range)
    {
        *y -= info.range;
    }
    return SUCCESS;
}

/**
 * @brief 计算灯带颜色曲线产生
 * @param[in]  x                            [曲线 x轴坐标值]
 * @param[out] y                            [曲线 y轴坐标值 斜坡曲线值 ]
 * @param[in]  info                         [曲线信息]
 * @return     int                          [成功或失败]
 * @note
 */
int  led_strip_signal_generate(uint32_t x, float * y, led_strip_signal_info_t info)
{
    int ret = SUCCESS;
    if (NULL == y)
    {
        return FAILURE;
    }

    switch (info.signal_type)
    {
    case SIGNAL_SIN:
        ret = led_strip_signal_sin(x, y, info);
        break;

    case SIGNAL_TRIANGLE:
        ret = led_strip_signal_triangle(x, y, info);
        break;

    case SIGNAL_SQUARE:
        ret = led_strip_signal_square(x, y, info);
        break;
    case SIGNAL_LINE:
        if ((info.amplitude_max -info.amplitude_min) > 0.00001)
        {
            ret = FAILURE;
        }

        *y = info.amplitude_max;
        break;
    case SIGNAL_SLOPE:
        ret = led_strip_signal_slope(x, y, info);
        break;
    default:
        break;
    }
    return ret ;
}


/**
 * @brief 计算灯带颜色曲线产生
 * @param[in]  x                            [曲线 x轴坐标值]
 * @param[out] led_strip                    [ 灯带色彩点集]
 * @return     int                          [成功或失败]
 * @note
 */
int  led_strip_signal_generate_rgb(uint32_t x, led_strip_signal_hsv_t * led_strip)
{
    hsv_color_t hsv;
    int ret = SUCCESS;
    if (NULL == led_strip )
    {
        return FAILURE;
    }

//    ret = led_strip_signal_generate(x, &hsv.hue, led_strip->hue);
//    if(ret != SUCCESS)
//    {
//        return ret ;
//    }
//    ret = led_strip_signal_generate(x, &hsv.saturation, led_strip->saturation);
//    if(ret != SUCCESS)
//    {
//        return ret ;
//    }
//    ret = led_strip_signal_generate(x, &hsv.value, led_strip->value);
//    if(ret != SUCCESS)
//    {
//        return ret ;
//    }

    memcpy(led_strip->hsv+led_strip->write_pos, &hsv, sizeof(hsv));
    led_strip->write_pos++;
    if (led_strip->write_pos >= led_strip->display_num)
    {
        led_strip->write_pos = 0;
    }
    return ret;
}


/**
 * @brief 计算灯带颜色曲线产生
 * @param[in/out] led_strip                 [ 灯带色彩点集]
 * @param[in]   number                      [ 灯带点数]
 * @return     int                          [成功或失败]
 * @note
 */
int led_strip_signal_struct_init(led_strip_signal_hsv_t * led_strip, uint32_t number)
{
    if (NULL == led_strip )
    {
        return FAILURE;
    }

    led_strip->hsv = (hsv_color_t *)vesync_malloc(number * sizeof(hsv_color_t));
    led_strip->write_pos = 0;
    led_strip->display_num = led_strip->number = number;
    led_strip->display_pos = 0;

    return SUCCESS;
}

/**
 * @brief 计算灯带颜色曲线产生
 * @param[in/out] led_strip                    [ 灯带色彩点集]
 * @return     int                          [成功或失败]
 * @note
 */
int led_strip_signal_struct_deinit(led_strip_signal_hsv_t * led_strip)
{
    if (NULL == led_strip )
    {
        return FAILURE;
    }

    free(led_strip->hsv);
    led_strip->hsv = NULL;
    led_strip->write_pos = 0;
    led_strip->display_num = led_strip->number = 0;
    led_strip->display_pos = 0;
    return SUCCESS;
}


