/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        bulb_bypass.h
 * @brief       灯泡的bypass应用回调
 * @author      Dave
 * @date        2021-09-02
 */

#ifndef __BULB_BYPASS_H__
#define __BULB_BYPASS_H__

#include <stdint.h>
#include "cJSON.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief setLightStatusV2接口数据解析结构
 */
typedef struct
{
    int *force;             // 相应等级，1时强制响应
    const char *color_mode; // 灯泡模式
    int *color_temp;        // 色温参数
    int *brightness;        // 亮度参数，hsv与white模式共用亮度参数标识
    int *hue;               // 色相参数
    int *saturation;        // 饱和度参数
    int *scene_id;          // 场景ID
    int *rms;               // 音乐RMS参数
    int *sensitive_type;    // 灵敏度参数类型
    int *sensitive_value;   // 灵敏度参数值
    int *effect;            // 灯效参数
} bypass_set_light_status_base_t;

/**
 * @brief adjustPercent接口数据解析结构
 */
typedef struct
{
    const char *type;
    int *step;
} bypass_adjust_percent_base_t;

/**
 * @brief 注册bypass回调函数
 */
void bulb_bypass_reg_cb(void);

/**
 * @brief Bypass解析bulb动作组
 * @param[in]       json_arr        [参数组]
 * @param[in]       action          [动作]
 * @return          int             [通用错误码]
 */
int bulb_bp_parse_action(cJSON *json_arr, bulb_action_t *action);

/**
 * @brief 将color_mode的枚举值解析成相应的字符串值
 * @param[in]       color_mode      [color_mode的枚举值]
 * @return          const char*     [对应字符串]
 */
const char *bulb_bp_get_color_mode_str(int color_mode);

#ifdef __cplusplus
}
#endif

#endif

