/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_event_list.c
 * @brief       事件链表处理接口
 * @author      Joshua
 * @date        2021-07-28
 */
#include <string.h>
#include <stdio.h>
#include "vesync_common.h"
#include "vesync_log_internal.h"
#include "vesync_memory.h"
#include "vesync_event_internal.h"

/**
* @brief 增加事件节点
* @param[in] event_mgt            [事件管理器对象指针]
* @param[in] event_id             [事件ID]
* @return event_node_t*           [添加的事件节点指针]
*/
event_node_t *vesync_event_node_list_add(event_manage_t *event_mgt, EVENT_ID_E event_id)
{
    VCOM_NULL_PARAM_CHK(event_mgt, return NULL);

    event_node_t *pos, *n;
    struct list_head *head;

    head = &event_mgt->node_list;

    list_for_each_entry_safe(pos, n, head, list)
    {
        if (pos->event_id == event_id)
        {
            SDK_LOG(LOG_DEBUG, "Event node already exist.\n");
            return pos;
        }
    }

    event_node_t *node = (event_node_t *) vesync_malloc(sizeof(event_node_t));
    if (node == NULL)
    {
        SDK_LOG(LOG_ERROR, "Event create event node failed\n");
        return NULL;
    }

    memset(node, 0, sizeof(event_node_t));
    node->event_id = event_id;

    node->mutex = vesync_mutex_new();
    if (node->mutex == NULL)
    {
        vesync_free(node);
        SDK_LOG(LOG_ERROR, "Event mutex create fail\n");
        return NULL;
    }

    INIT_LIST_HEAD(&node->subscribe_list);

    vesync_mutex_lock(event_mgt->mutex);
    list_add_tail(&node->list, &event_mgt->node_list);
    event_mgt->event_num++;
    vesync_mutex_unlock(event_mgt->mutex);

    return node;
}


/**
* @brief 删除事件节点
* @param[in] event_mgt            [事件管理器对象指针]
* @param[in] event_id             [事件ID]
*/
void vesync_event_node_list_del(event_manage_t *event_mgt, EVENT_ID_E event_id)
{
    VCOM_NULL_PARAM_CHK(event_mgt, return);

    event_node_t *node_pos, *node_n;
    struct list_head *node_head;

    node_head = &event_mgt->node_list;

    vesync_mutex_lock(event_mgt->mutex);
    list_for_each_entry_safe(node_pos, node_n, node_head, list)
    {
        if (node_pos->event_id == event_id)
        {
            list_del(&node_pos->list);
            INIT_LIST_HEAD(&node_pos->list);

            vesync_mutex_free(node_pos->mutex);
            vesync_free(node_pos);

            event_mgt->event_num--;
            break;
        }
    }
    vesync_mutex_unlock(event_mgt->mutex);
}


/**
* @brief 获取事件节点
* @param[in] event_mgt            [事件管理器对象指针]
* @param[in] event_id             [事件ID]
* @return event_node_t*           [事件节点指针]
*/
event_node_t *vesync_event_node_get(event_manage_t *event_mgt, EVENT_ID_E event_id)
{
    VCOM_NULL_PARAM_CHK(event_mgt, return NULL);

    event_node_t *pos, *n;
    struct list_head *head;

    head = &event_mgt->node_list;

    vesync_mutex_lock(event_mgt->mutex);
    list_for_each_entry_safe(pos, n, head, list)
    {
        if (pos->event_id == event_id)
        {
            vesync_mutex_unlock(event_mgt->mutex);
            return pos;
        }
    }

    vesync_mutex_unlock(event_mgt->mutex);
    return NULL;
}


/**
* @brief 增加订阅节点
* @param[in] sub_id                 [订阅者ID]
* @param[in] cb                     [订阅回调函数]
* @param[in] *node                  [订阅的事件ID]
* @return int                       [SDK_OK/SDK_FAIL]
*/
int vesync_event_subscribe_list_add(SUB_ID_E sub_id, event_subscribe_cb_t cb, event_node_t *node)
{
    event_subscribe_t *pos, *n;
    struct list_head *head;

    VCOM_NULL_PARAM_CHK(node, return SDK_FAIL);

    head = &node->subscribe_list;

    vesync_mutex_lock(node->mutex);
    list_for_each_entry_safe(pos, n, head, list)
    {
        if (pos->sub_id == sub_id)
        {
            SDK_LOG(LOG_INFO, "Already subscribe, update callback\n");
            pos->event_handle = cb;
            vesync_mutex_unlock(node->mutex);
            return SDK_OK;
        }
    }
    vesync_mutex_unlock(node->mutex);

    event_subscribe_t *subscribe = (event_subscribe_t *)vesync_malloc(sizeof(event_subscribe_t));
    if (subscribe == NULL)
    {
        SDK_LOG(LOG_ERROR, "Event create event subscribe failed\n");
        return SDK_FAIL;
    }

    memset(subscribe, 0, sizeof(event_subscribe_t));
    subscribe->sub_id = sub_id;
    subscribe->event_handle = cb;

    vesync_mutex_lock(node->mutex);
    list_add_tail(&subscribe->list, &node->subscribe_list);
    vesync_mutex_unlock(node->mutex);

    return SDK_OK;
}


/**
* @brief 删除订阅节点
* @param[in] event_mgt              [事件管理器对象指针]
* @param[in] sub_id                 [订阅者ID]
* @param[in] *node                  [订阅的事件ID]
*/
void vesync_event_subscribe_list_del(event_manage_t *event_mgt, SUB_ID_E sub_id, event_node_t *node)
{
    VCOM_NULL_PARAM_CHK(event_mgt, return);
    VCOM_NULL_PARAM_CHK(node, return);

    event_subscribe_t *pos, *n;
    struct list_head *head;

    head = &node->subscribe_list;

    vesync_mutex_lock(node->mutex);
    list_for_each_entry_safe(pos, n, head, list)
    {
        if (pos->sub_id == sub_id)
        {
            list_del(&pos->list);
            INIT_LIST_HEAD(&pos->list);
            vesync_free(pos);
            vesync_mutex_unlock(node->mutex);
            break;
        }
    }
    vesync_mutex_unlock(node->mutex);

    // 如果事件节点下的订阅节点为空，则删除该事件节点
    if (list_empty(&node->subscribe_list))
    {
        vesync_event_node_list_del(event_mgt, node->event_id);
    }
}

