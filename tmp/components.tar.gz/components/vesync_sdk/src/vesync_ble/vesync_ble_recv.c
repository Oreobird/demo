/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_ble_recv.c
 * @brief       BLE模块接收接口
 * @author      Louis
 * @date        2021-07-21
 */

#include <string.h>
#include <stdint.h>

#include "vhal_ble.h"
#include "vesync_memory.h"
#include "vesync_queue.h"
#include "vesync_common.h"
#include "vesync_log_internal.h"

#include "vesync_ble.h"
#include "vesync_ble_private.h"
#include "vesync_tl_frame_parse.h"

static vesync_queue_t *s_ble_recv_queue = NULL;

static uint8_t s_recv_seq_id[BLE_DATA_CHAN_MAX] = {0};

static uint8_t s_recv_buf[BLE_DATA_CHAN_MAX][VESYNC_FRAME_HEADER_LEN + VESYNC_FRAME_PAYLOAD_MAX_LEN];

static vesync_ble_data_recv_cb_t vesync_ble_data_recv_cb[BLE_DATA_CHAN_MAX] = {NULL};
static vesync_ble_evt_cb_t vesync_ble_evt_cb[BLE_DATA_CHAN_MAX] = {NULL};

/**
 * @brief  处理vhal层收到的BLE数据，校验完整后缓存到接收队列
 * @param[in]  p_data           [数据指针]
 * @param[in]  len              [数据长度]
 * @param[in]  chan             [数据通道]
 * @return     int32_t          [SDK_OK/SDK_FAIL]
 */
static int32_t vesync_ble_recv_data(uint8_t *p_data, uint16_t len, BLE_DATA_CHAN_E chan)
{
    tl_frame_recv_info_t *frame_header = (tl_frame_recv_info_t *)&(s_recv_buf[chan][0]);
    vesync_ble_data_t recv_data = {0};

    if (vesync_ble_is_init() != true)
    {
        return SDK_FAIL;
    }

    if (NULL == p_data || 0 == len || len > VESYNC_FRAME_PAYLOAD_MAX_LEN)
    {
        return SDK_FAIL;
    }

    for (uint16_t i = 0; i < len; i++)
    {
        // 逐个字节解析
        if (vesync_tl_frame_decode(p_data[i], VESYNC_FRAME_PAYLOAD_MAX_LEN, frame_header))
        {
            continue;
        }

        // 校验checksum
        if (vesync_tl_frame_checksum_verify(frame_header))
        {
            continue;
        }

        recv_data.type = BLE_DATA_TYPE_RECV;
        recv_data.chan = chan;
        recv_data.len = sizeof(tl_frame_recv_info_t) + frame_header->payload_len;
        recv_data.p_data = vesync_malloc(recv_data.len);

        if (NULL == recv_data.p_data)
        {
            continue;
        }

        memcpy(recv_data.p_data, frame_header, recv_data.len);

        // 入队，然后释放信号量通知收发任务
        if (VOS_OK != vesync_queue_send(s_ble_recv_queue, &recv_data, VESYNC_OS_NO_WAIT))
        {
            VCOM_SAFE_FREE(recv_data.p_data);
            continue;
        }
        vesync_ble_sem_signal();
    }

    return SDK_OK;
}

/**
 * @brief  CMD通道收包回调
 * @param[in]  p_data           [数据指针]
 * @param[in]  len              [数据长度]
 * @return     int32_t          [SDK_OK/SDK_FAIL]
 */
static void vesync_ble_recv_cmd_data_cb(uint8_t *p_data, uint16_t len)
{
    vesync_ble_recv_data(p_data, len, BLE_DATA_CHAN_CMD);
}

/**
 * @brief  NETCFG通道收包回调
 * @param[in]  p_data           [数据指针]
 * @param[in]  len              [数据长度]
 * @return     int32_t          [SDK_OK/SDK_FAIL]
 */
static void vesync_ble_recv_netcfg_data_cb(uint8_t *p_data, uint16_t len)
{
    vesync_ble_recv_data(p_data, len, BLE_DATA_CHAN_NETCFG);
}

/**
 * @brief  BLE模块接收初始化
 * @return     int32_t          [SDK_OK/SDK_FAIL]
 */
int32_t vesync_ble_recv_init(void)
{
    // 注册vhal层两个BLE通道的收包回调
    vhal_ble_reg_cmd_recv_cb(vesync_ble_recv_cmd_data_cb);
    vhal_ble_reg_netcfg_recv_cb(vesync_ble_recv_netcfg_data_cb);

    // 创建收包队列
    s_ble_recv_queue = vesync_queue_new(VESYNC_BLE_RECV_QUEUE_MAX_NUM * sizeof(vesync_ble_data_t), sizeof(vesync_ble_data_t));
    if (NULL == s_ble_recv_queue)
    {
        SDK_LOG(LOG_ERROR, "queue create fail\n");
        return SDK_FAIL;
    }
    return SDK_OK;
}

/**
 * @brief  BLE模块接收退出
 */
void vesync_ble_recv_deinit(void)
{
    if (s_ble_recv_queue)
    {
        vesync_queue_free(s_ble_recv_queue);
        s_ble_recv_queue = NULL;
    }
}

/**
 * @brief  从接收队列中取出数据包进行处理，并回调给上层
 * @return     int32_t          [SDK_OK/SDK_FAIL]
 */
int32_t vesync_ble_parse_recv_data(void)
{
    int32_t ret = SDK_OK;
    tl_frame_recv_info_t *frame_header = NULL;
    vesync_ble_data_t ble_data_recv = {0};
    VESYNC_BLE_SEND_RESULT_E send_result;

    if (VOS_OK != vesync_queue_recv(s_ble_recv_queue, &ble_data_recv, VESYNC_OS_NO_WAIT))
    {
        ret = SDK_FAIL;    // recv队列没有消息，返回
        goto EXIT;
    }

    frame_header = (tl_frame_recv_info_t *)ble_data_recv.p_data;
    // 协议版本错误，直接退出
    if (VESYNC_PROTOCO_VERSION != frame_header->ctrl.bitN.version)
    {
        ret = SDK_OK;
        goto EXIT;
    }

    if (frame_header->ctrl.bitN.ack_flag)
    {
        // ACK报文，但sequence id匹配不上，直接退出
        if (frame_header->seq_id != vesync_ble_get_send_seq_id(ble_data_recv.chan))
        {
            ret = SDK_OK;
            goto EXIT;
        }

        // 已经收到回复，删除超时重发定时器
        vesync_ble_del_send_timeout_timer();

        if (frame_header->ctrl.bitN.error_flag)
        {
            send_result = BLE_SEND_RESUT_FAIL;
        }
        else
        {
            send_result = BLE_SEND_RESUT_SUCCESS;
        }

        if (NULL != vesync_ble_evt_cb[ble_data_recv.chan])
        {
            vesync_ble_evt_cb[ble_data_recv.chan](send_result, frame_header->p_payload, frame_header->payload_len);
        }
    }
    else    // 请求报文，记录sequence id后回调给应用层
    {
        s_recv_seq_id[ble_data_recv.chan] = frame_header->seq_id;
        if (NULL != vesync_ble_data_recv_cb[ble_data_recv.chan])
        {
            vesync_ble_data_recv_cb[ble_data_recv.chan](frame_header->p_payload,
                                                        frame_header->payload_len,
                                                        (1 == frame_header->ctrl.bitN.request_flag) ? true: false);
        }
    }

EXIT:
    if (SDK_OK == ret)
    {
        VCOM_SAFE_FREE(ble_data_recv.p_data);
        vesync_ble_sem_signal();    // 释放信号量，通知收发任务可以处理下一包了
    }

    return ret;
}

/**
 * @brief  获取收包的sequence id
 * @param[in]  chan             [数据通道]
 * @return     int8_t           [sequence id]
 */
uint8_t vesync_ble_get_recv_seq_id(BLE_DATA_CHAN_E chan)
{
    return s_recv_seq_id[chan];
}

/**
 * @brief  注册配网数据接收的回调函数
 * @param[in]  cb               [回调函数]
 */
void vesync_ble_reg_netcfg_recv_cb(vesync_ble_data_recv_cb_t cb)
{
    vesync_ble_data_recv_cb[BLE_DATA_CHAN_NETCFG] = cb;
}

/**
 * @brief  注册CMD数据接收的回调函数
 * @param[in]  cb               [回调函数]
 */
void vesync_ble_reg_cmd_recv_cb(vesync_ble_data_recv_cb_t cb)
{
    vesync_ble_data_recv_cb[BLE_DATA_CHAN_CMD] = cb;
}

/**
 * @brief  注册接收配网数据发送结果的回调函数
 * @param[in]  cb               [回调函数]
 */
void vesync_ble_reg_netcfg_evt_cb(vesync_ble_evt_cb_t cb)
{
    vesync_ble_evt_cb[BLE_DATA_CHAN_NETCFG] = cb;
}

/**
 * @brief  注册接收CMD数据发送结果的回调函数
 * @param[in]  cb               [回调函数]
 */
void vesync_ble_reg_cmd_evt_cb(vesync_ble_evt_cb_t cb)
{
    vesync_ble_evt_cb[BLE_DATA_CHAN_CMD] = cb;
}
