/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        bulb_production.c
 * @brief       灯泡的产测
 * @author      Dave.Ming
 * @date        2021-09-02
 */

#include <string.h>

#include "vhal_wifi.h"

#include "vesync_log.h"
#include "vesync_device.h"
#include "vesync_production.h"
#include "vesync_common.h"
#include "vesync_timer.h"
#include "vesync_ble.h"

#include "bulb_status.h"
#include "bulb_wifi_led.h"
#include "bulb_flash.h"
#include "bulb_production.h"

#include "bulb_def.h"
#include "bulb_board.h"

static vesync_timer_t *s_age_timerhd = NULL;       // 定时记录数据定时器

static uint8_t s_age_test_time;
static uint8_t s_age_test_start;

/**
 * @brief 停止定时器
 */
static void bulb_1st_time_ind_timer_stop(void)
{
    if (NULL != s_age_timerhd && VOS_OK == vesync_timer_free(s_age_timerhd))
    {
        s_age_timerhd = NULL;
    }
}

/**
 * @brief 定时器超时回调
 * @param arg        参数(未使用)
 * @return void
 */
static void bulb_1st_time_ind_timer_cb(void *arg)
{
    bulb_1st_time_ind_timer_stop();
    s_age_test_start = 1;
}

/**
 * @brief 创建并启动老化前灯效循环计时器
 */
static void bulb_1st_time_ind_timer_start(void)
{
    if (NULL == s_age_timerhd)
    {
        // 创建一次性定时器，间隔2min
        s_age_timerhd = vesync_timer_new("aging_1st_time_ind", bulb_1st_time_ind_timer_cb, NULL, 120000, false);
    }

    if (NULL != s_age_timerhd)
    {
        if (vesync_timer_start(s_age_timerhd) != VOS_OK)
        {
            APP_LOG(LOG_ERROR, "start timer fail\n");
        }
    }
    else
    {
        APP_LOG(LOG_ERROR, "timer create fail\n");
    }
}

/**
 * @brief 产测前的老化测试回调
 */
void bulb_production_pre_test_cb(void)
{
    s_age_test_time = bulb_get_config(BULB_CFG_AGING_TEST_TIME);
    if (BULB_PRODUCTION_PRE_TEST_MIN > s_age_test_time)
    {
        vesync_ble_disable();
        vhal_wifi_stop();
        s_age_test_start = bulb_get_config(BULB_CFG_AGING_TEST);
        // 第一次老化需进行2min循环灯效
        if (0 == s_age_test_start)
        {
            bulb_1st_time_ind_timer_start();
            production_output_test(s_age_test_start);
            while (0 == s_age_test_start)
            {
                vesync_sleep(1000);
            }
            production_output_test(s_age_test_start);
            bulb_update_config(BULB_CFG_AGING_TEST, s_age_test_start);
            bulb_resave_config();
        }
        for (int i = s_age_test_time; i < BULB_PRODUCTION_PRE_TEST_MIN; i++)
        {

#if BULB_INDICATOR_MODE == BULB_INDICATOR_MODE_RGBCWCCT
            // 计算每个测试项单独的耗时，为总时长除于测试项数
            int step_during_min = BULB_PRODUCTION_PRE_TEST_MIN / 3;
            // 开始冷白老化
            if (i < step_during_min)
            {
                bulb_white_mode_write(BULB_W_COLDEST, BULB_W_FULL_BRIGHT);
                vesync_sleep(60 * 1000);
            }
            // 开始暖白老化
            else if (i < 2 * step_during_min)
            {
                bulb_white_mode_write(BULB_W_WARMEST, BULB_W_FULL_BRIGHT);
                vesync_sleep(60 * 1000);
            }
            // 开始彩灯老化
            else if (i < 3 * step_during_min)
            {
                bulb_color_mode_write(0, 0, 100);
                vesync_sleep(60 * 1000);
            }
#elif BULB_INDICATOR_MODE == BULB_INDICATOR_MODE_CWCCT
            // 计算每个测试项单独的耗时，为总时长除于测试项数
            int step_during_min = BULB_PRODUCTION_PRE_TEST_MIN / 2;
            // 开始冷白老化
            if (i < step_during_min)
            {
                bulb_white_mode_write(BULB_W_COLDEST, BULB_W_FULL_BRIGHT);
                vesync_sleep(60 * 1000);
            }
            // 开始暖白老化
            else if (i < 2 * step_during_min)
            {
                bulb_white_mode_write(BULB_W_WARMEST, BULB_W_FULL_BRIGHT);
                vesync_sleep(60 * 1000);
            }
#else
#error "BULB_INDICATOR_MODE is invalid"
#endif /* BULB_INDICATOR_MODE */

            bulb_update_config(BULB_CFG_AGING_TEST_TIME, i + 1);
            bulb_resave_config();
            APP_LOG(LOG_INFO, "Production age test runing %d\n", i);
        }

#if BULB_INDICATOR_MODE == BULB_INDICATOR_MODE_RGBCWCCT
        // 老化完成亮绿灯
        bulb_color_mode_write(3333, 10000, 100);
#elif BULB_INDICATOR_MODE == BULB_INDICATOR_MODE_CWCCT
        // 老化完成白灯，一半亮度
        bulb_white_mode_write(BULB_W_MODEST, BULB_W_HALF_BRIGHT);
#else
#error "BULB_INDICATOR_MODE is invalid"
#endif /* BULB_INDICATOR_MODE */

        while (1)
        {
            vesync_sleep(1000);
        }
    }
    else
    {
        APP_LOG(LOG_INFO, "Production age test already done\n");
    }
}

/**
 * @brief 产测状态回调函数
 * @param[in]  status          [产测状态码]
 */
static void bulb_production_status_cb(PRODUCTION_STATUS_E status)
{
    switch (status)
    {
    case PRODUCTION_START:
        production_output_test(false);
        break;
    case PRODUCTION_RUNNING:
        production_output_test(true);

#if BULB_INDICATOR_MODE == BULB_INDICATOR_MODE_RGBCWCCT
        // 连接上服务器的灯效恢复，亮白
        bulb_white_mode_write(BULB_W_COLDEST, BULB_W_FULL_BRIGHT);
#elif BULB_INDICATOR_MODE == BULB_INDICATOR_MODE_CWCCT
        // 连接上服务器的灯效恢复，白灯，一半亮度
        bulb_white_mode_write(BULB_W_MODEST, BULB_W_HALF_BRIGHT);
#else
#error "BULB_INDICATOR_MODE is invalid"
#endif /* BULB_INDICATOR_MODE */

        APP_LOG(LOG_INFO, "production running\n");
        break;
    case PRODUCTION_TEST_PASS:

#if BULB_INDICATOR_MODE == BULB_INDICATOR_MODE_RGBCWCCT
        // 产测通过亮绿灯
        bulb_color_mode_write(3333, 10000, 100);
#elif BULB_INDICATOR_MODE == BULB_INDICATOR_MODE_CWCCT
        // 产测通过亮冷白灯，一半亮度
        bulb_white_mode_write(BULB_W_COLDEST, BULB_W_HALF_BRIGHT);
#else
#error "BULB_INDICATOR_MODE is invalid"
#endif /* BULB_INDICATOR_MODE */

        bulb_reset_config();
        APP_LOG(LOG_INFO, "production pass\n");
        break;
    case PRODUCTION_TEST_FAIL:

#if BULB_INDICATOR_MODE == BULB_INDICATOR_MODE_RGBCWCCT
        // 产测失败亮红灯
        bulb_color_mode_write(0, 10000, 100);
#elif BULB_INDICATOR_MODE == BULB_INDICATOR_MODE_CWCCT
        // 产测失败亮暖黄灯，一半亮度
        bulb_white_mode_write(BULB_W_WARMEST, BULB_W_HALF_BRIGHT);
#else
#error "BULB_INDICATOR_MODE is invalid"
#endif /* BULB_INDICATOR_MODE */

        APP_LOG(LOG_INFO, "production fail\n");
        break;
    default:
        break;
    }
}

/**
* @brief 产测结果回调函数
* @param[in]  err_code          [产测状态码]
*/
static void bulb_production_result_cb(PRODUCTION_ERROR_E err_code)
{
    if (PRD_NO_ERR == err_code)
    {
        APP_LOG(LOG_INFO, "production success\n");
    }
    else
    {
        APP_LOG(LOG_INFO, "production error %d\n", err_code);
    }
}

/**
* @brief switch产测功能初始化
* @param void
*/
void bulb_production_init(void)
{
    // 产测前的老化测试回调，产测状态回调及结果回调
    vesync_production_reg_pre_test_cb(bulb_production_pre_test_cb);
    vesync_production_reg_status_cb(bulb_production_status_cb);
    vesync_production_reg_result_cb(bulb_production_result_cb);
}
