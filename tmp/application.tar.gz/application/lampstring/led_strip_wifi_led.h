/**
*Copyright © Vesync Technologies Co.Ltd. 2022. All rights reserved.
* @file    led_strip_wifi_led.h
* @brief   Wi-Fi指示灯配置
* @author  Lind
*@date     2022-01-05
*/

#ifndef __LED_STRIP_WIFI_LED_H__
#define __LED_STRIP_WIFI_LED_H__

#ifdef __cplusplus
extern "C" {
#endif

/**
* @brief  灯效配置
* @return     int             [成功/失败]
*/
int ls_reg_wifi_led(void);

#ifdef __cplusplus
}
#endif

#endif

