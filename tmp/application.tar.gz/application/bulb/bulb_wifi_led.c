/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
* @file        bulb_wifi_led.c
* @brief       灯泡配网时灯效
* @author      Dave.Ming
* @date        2021-09-1
*/

#include <string.h>

#include "vesync_common.h"
#include "vesync_log.h"
#include "vesync_wifi_led.h"
#include "vesync_timing.h"
#include "vesync_task.h"
#include "vesync_timer.h"

#include "bulb_status.h"
#include "bulb_wifi_led.h"

#include "bulb_def.h"
#include "bulb_board.h"

static vesync_timer_t *s_production_led_timerhd = NULL;       // 产测灯效定时器
static uint8_t s_production_count = 0;

/**
 * @brief 停止定时器
 */
static void bulb_production_timer_stop(void)
{
    if (NULL != s_production_led_timerhd && VOS_OK == vesync_timer_free(s_production_led_timerhd))
    {
        s_production_led_timerhd = NULL;
    }
}

/**
 * @brief 产测的开始指示灯效
 * @param arg        [定时器回调参数]
 */
static void bulb_production_timer_cb(void *arg)
{
#if BULB_INDICATOR_MODE == BULB_INDICATOR_MODE_RGBCWCCT
    switch (s_production_count)
    {
    case 0:
        bulb_white_mode_write(BULB_W_COLDEST, BULB_W_FULL_BRIGHT);
        break;
    case 1:
        bulb_white_mode_write(BULB_W_WARMEST, BULB_W_FULL_BRIGHT);
        break;
    case 2:
        bulb_color_mode_write(0, 10000, 100);
        break;
    case 3:
        bulb_color_mode_write(3333, 10000, 100);
        break;
    case 4:
        bulb_color_mode_write(6667, 10000, 100);
        break;
    default:
        break;
    }
    if (4 >= s_production_count)
    {
        s_production_count = 0;
    }
    else
    {
        s_production_count += 1;
    }
#endif /* BULB_INDICATOR_MODE */

#if BULB_INDICATOR_MODE == BULB_INDICATOR_MODE_CWCCT
    switch (s_production_count)
    {
    case 0:
        bulb_white_mode_write(BULB_W_MODEST, BULB_W_HALF_BRIGHT);
        break;
    case 1:
        bulb_white_mode_write(BULB_W_WARMEST, BULB_W_HALF_BRIGHT);
        break;
    default:
        break;
    }
    if (1 >= s_production_count)
    {
        s_production_count = 0;
    }
    else
    {
        s_production_count += 1;
    }
#endif /* BULB_INDICATOR_MODE */
}

/**
 * @brief 创建并启动产测灯效切换计时器
 */
static void bulb_production_timer_start(void)
{
    if (NULL == s_production_led_timerhd)
    {
        // 创建循环定时器，间隔1000ms。
        s_production_led_timerhd = vesync_timer_new("bulb_production_timer", bulb_production_timer_cb, NULL, 1000, true);
    }

    if (NULL != s_production_led_timerhd)
    {
        if (vesync_timer_start(s_production_led_timerhd) != VOS_OK)
        {
            APP_LOG(LOG_ERROR, "start timer fail\n");
        }
    }
    else
    {
        APP_LOG(LOG_ERROR, "timer create fail\n");
    }
}

/**
 * @brief  产测时的输出测试灯效
 */
void production_output_test(bool stop)
{
    if (true == stop)
        bulb_production_timer_stop();
    else
        bulb_production_timer_start();
}

/**
 * @brief  未配网时的提示灯效
 */
void led_before_netcfg(void)
{
#if BULB_INDICATOR_MODE == BULB_INDICATOR_MODE_RGBCWCCT
    int i;
    for (i = 1; i < 100; i = i + 1)
    {
        bulb_color_mode_write(0, 10000, i);
        vesync_sleep(10);
    }
    for (i = 1; i < 100; i = i + 1)
    {
        bulb_color_mode_write(3333, 10000, i);
        vesync_sleep(10);
    }
    for (i = 1; i < 100; i = i + 1)
    {
        bulb_color_mode_write(6667, 10000, i);
        vesync_sleep(10);
    }
#elif BULB_INDICATOR_MODE == BULB_INDICATOR_MODE_CWCCT
    // 等待配网：开关3次（按键配网类设备长按按键5s）进入等待配网状态，
    // 灯效为白光（最高色温 100%）慢闪（500ms亮，500ms灭）3次后常亮白光（最高色温 100%）

    bulb_white_mode_write(BULB_W_COLDEST, BULB_W_FULL_BRIGHT);
    vesync_sleep(500);
    bulb_white_mode_write(BULB_W_COLDEST, 0);
    vesync_sleep(500);

    bulb_white_mode_write(BULB_W_COLDEST, BULB_W_FULL_BRIGHT);
    vesync_sleep(500);
    bulb_white_mode_write(BULB_W_COLDEST, 0);
    vesync_sleep(500);

    bulb_white_mode_write(BULB_W_COLDEST, BULB_W_FULL_BRIGHT);
    vesync_sleep(500);
    bulb_white_mode_write(BULB_W_COLDEST, 0);
    vesync_sleep(500);

    bulb_white_mode_write(BULB_W_COLDEST, BULB_W_FULL_BRIGHT);
#else
#error "BULB_INDICATOR_MODE is invalid"
#endif /* BULB_INDICATOR_MODE */
}

/**
 * @brief  设备重置提示灯效
 */
void led_device_reset(void)
{
#if BULB_INDICATOR_MODE == BULB_INDICATOR_MODE_RGBCWCCT
    bulb_color_mode_write(0, 10000, 100);
    vesync_sleep(500);
    bulb_sleep_mode_write();
    vesync_sleep(500);
    bulb_color_mode_write(0, 10000, 100);
    vesync_sleep(500);
    bulb_sleep_mode_write();
    vesync_sleep(500);
    bulb_color_mode_write(0, 10000, 100);
    vesync_sleep(500);
    bulb_sleep_mode_write();
    vesync_sleep(500);
    bulb_color_mode_write(0, 10000, 100);
    vesync_sleep(500);
    bulb_sleep_mode_write();
    vesync_sleep(500);
    bulb_color_mode_write(0, 10000, 100);
    vesync_sleep(500);
    bulb_white_mode_write(BULB_W_COLDEST, BULB_W_FULL_BRIGHT);
#elif BULB_INDICATOR_MODE == BULB_INDICATOR_MODE_CWCCT
    // 恢复出厂，快速呼吸3次（过程亮->灭渐变，渐变过程0.5秒 最高色温 100%）
    // 1st round
    for (int i = 0; i <=100; i+=5)
    {
        bulb_white_mode_write(BULB_W_COLDEST, i);
        vesync_sleep(25);
    }
    for (int i = 100; i >= 0; i-=5)
    {
        bulb_white_mode_write(BULB_W_COLDEST, i);
        vesync_sleep(25);
    }
    // 2nd round
    for (int i = 0; i <=100; i+=5)
    {
        bulb_white_mode_write(BULB_W_COLDEST, i);
        vesync_sleep(25);
    }
    for (int i = 100; i >= 0; i-=5)
    {
        bulb_white_mode_write(BULB_W_COLDEST, i);
        vesync_sleep(25);
    }
    // 3rd round
    for (int i = 0; i <=100; i+=5)
    {
        bulb_white_mode_write(BULB_W_COLDEST, i);
        vesync_sleep(25);
    }
    for (int i = 100; i >= 0; i-=5)
    {
        bulb_white_mode_write(BULB_W_COLDEST, i);
        vesync_sleep(25);
    }
    bulb_white_mode_write(BULB_W_COLDEST, 0);
#else
#error "BULB_INDICATOR_MODE is invalid"
#endif /* BULB_INDICATOR_MODE */
}
