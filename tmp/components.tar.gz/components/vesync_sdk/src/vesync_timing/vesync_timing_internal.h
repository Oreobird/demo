/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_timing_internal.h
 * @brief       timing内部定义
 * @date        2021-05-27
 */

#ifndef __VESYNC_TIMING_INTERNAL_H__
#define __VESYNC_TIMING_INTERNAL_H__

#include "vesync_timing.h"

#ifdef __cplusplus
extern "C" {
#endif

#define VESYNC_TIMING_NUM_MAX    (5)    // 支持的倒计时最大个数
#define DELAY_TICK_PERIOD        (1000) // 倒计时单位1秒

#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_TIMING_INTERNAL_H__ */




