/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file    vhal_rmt_ir.c
* @brief   红外控制协议
* @author  Lind
* @date     2021-11-16
*/

#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <sys/cdefs.h>
#include <freertos/FreeRTOS.h>

#include "driver/rmt.h"
#include "hal/rmt_types.h"
#include "soc/rmt_struct.h"

#include "ir_tools.h"
#include "vhal_rmt.h"
#include "vhal_rmt_ir.h"
#include "vhal_rmt.h"

#include "vesync_log.h"
#include "vesync_task.h"
#include "vesync_memory.h"
#include "vesync_common.h"
#include "vesync_queue.h"

static vesync_task_t s_rmt_ir_taskhd = NULL;      // 红外控制任务句柄
static rmt_channel_t s_tx_channel = RMT_CHANNEL_MAX;    // 发送通道
static rmt_channel_t s_rx_channel = RMT_CHANNEL_MAX;    // 接收通道
static IR_PROTOCOL_E s_ir_rx_protocol = IR_PROTOCOL_MAX;    // 接收协议
static IR_PROTOCOL_E s_ir_tx_protocol = IR_PROTOCOL_MAX;    // 发送协议
static ir_parser_t *s_ir_parser = NULL;
static ir_builder_t *s_ir_builder = NULL;
static bool s_tx_flag = false;          // 发送标志位
static bool s_tx_repeat_flag = false;   // 发送重复数据标志位
static ir_rx_cb_t s_rx_cb = NULL;
static uint32_t s_addr = 0;
static uint32_t s_cmd = 0;


/**
* @brief 内部红外控制数据发送
* @param[in]  addr          [用户地址数据]
* @param[in]  cmd           [键值数据]
* @param[in]  repeat_flag   [是否重复数据]
*/
static void rmt_ir_send(uint32_t addr, uint32_t cmd, bool repeat_flag)
{
    rmt_item32_t *items = NULL;
    size_t length = 0;
    if (repeat_flag == false)
    {
        // Build new key code
        ESP_ERROR_CHECK(s_ir_builder->build_frame(s_ir_builder, addr, cmd));
    }
    else
    {
        // Build repeat code
        ESP_ERROR_CHECK(s_ir_builder->build_repeat_frame(s_ir_builder));
    }
    //To send data according to the waveform items.
    ESP_ERROR_CHECK(s_ir_builder->get_result(s_ir_builder, &items, &length));
    rmt_write_items(s_tx_channel, items, length, false);
    s_tx_flag = false;
    s_tx_repeat_flag = false;
}


/**
* @brief 红外控制数据发送
* @param[in]  addr          [用户地址数据]
* @param[in]  cmd           [键值数据]
* @param[in]  repeat_flag   [是否重复数据]
* @return  int              [VHAL_OK/VHAL_FAIL]
*/
int vhal_rmt_ir_send(uint32_t addr, uint32_t cmd, bool repeat_flag)
{
    if (s_tx_channel == RMT_CHANNEL_MAX)
    {
        return VHAL_FAIL;
    }

    if (s_rmt_ir_taskhd == NULL)
    {
        rmt_ir_send(addr, cmd, repeat_flag);
    }
    else
    {
        s_tx_flag = true;
        s_tx_repeat_flag = repeat_flag;
        s_addr = addr;
        s_cmd = cmd;
    }

    return VHAL_OK;
}


/**
* @brief 注册红外接收回调函数
* @param[in]  cb        [回调函数]
*/
void vhal_rmt_ir_reg_rx_cb(ir_rx_cb_t cb)
{
     s_rx_cb = cb;
}

/**
* @brief 红外控制任务
*/
static void vhal_rmt_ir_task(void *arg)
{
    RingbufHandle_t read_buf = NULL;
    rmt_item32_t *rx_items = NULL;
    size_t length = 0;
    bool rx_repeat_flag = false;
    uint32_t rx_addr = 0, rx_cmd = 0;
    rmt_get_ringbuf_handle(s_rx_channel, &read_buf);
    assert(read_buf != NULL);
    rmt_rx_start(s_rx_channel, true);

    while(1)
    {
        if (s_tx_flag == true)
        {
            rmt_ir_send(s_addr, s_cmd, s_tx_repeat_flag);
        }
        rx_items = (rmt_item32_t *) xRingbufferReceive(read_buf, &length, 100);
        if (rx_items)
        {
            length /= 4; // one RMT = 4 Bytes
            if (s_ir_parser->input(s_ir_parser, rx_items, length) == ESP_OK)
            {
                if (s_ir_parser->get_scan_code(s_ir_parser, &rx_addr, &rx_cmd, &rx_repeat_flag) == ESP_OK)
                {
                    if (s_rx_cb != NULL)
                    {
                        s_rx_cb(rx_addr, rx_cmd, rx_repeat_flag);
                    }
                    else
                    {
                        HAL_LOG(LOG_INFO,"Scan Code %s --- addr: 0x%04lx cmd: 0x%04lx \n", rx_repeat_flag ? "(repeat)" : "", rx_addr, rx_cmd);
                    }
                }
            }
            vRingbufferReturnItem(read_buf, (void *)rx_items);
        }

        if (s_rmt_ir_taskhd == NULL)
        {
            HAL_LOG(LOG_INFO,"IR RX Task Exit! \n");
            break;
        }
        vesync_sleep(RMT_IR_TASK_PERIOD_MS);
    }
}


/**
* @brief 红外发送初始化
* @param[in]  ir_channel      [通道]
* @param[in]  gpio_num        [IO]
* @param[in]  ir_protocol     [红外协议]
* @param[in]  EXT_PROTO_FLAG  [是否允许扩展（非标准）协议]
* @return  int                [VHAL_OK/VHAL_FAIL]
*/
int vhal_rmt_ir_tx_init(RMT_CH_E ir_channel, uint16_t gpio_num, IR_PROTOCOL_E ir_protocol, bool EXT_PROTO_FLAG)
{
    if (IR_PROTOCOL_MAX <= ir_protocol || s_tx_channel != RMT_CHANNEL_MAX || s_rx_channel == (rmt_channel_t)ir_channel)
    {
        return VHAL_FAIL;
    }

    rmt_config_t rmt_tx_config = RMT_DEFAULT_CONFIG_TX(gpio_num, ir_channel);
    ESP_ERROR_CHECK(rmt_config(&rmt_tx_config));
    ESP_ERROR_CHECK(rmt_driver_install(ir_channel, 0, 0));
    s_tx_channel = ir_channel;
    s_ir_tx_protocol = ir_protocol;
    ir_builder_config_t ir_builder_config = IR_BUILDER_DEFAULT_CONFIG((ir_dev_t)s_tx_channel);
    ir_builder_config.flags |= EXT_PROTO_FLAG;
    if (IR_PROTOCOL_NEC == ir_protocol)
    {
        s_ir_builder = ir_builder_rmt_new_nec(&ir_builder_config);
        HAL_LOG(LOG_INFO, "nec protocol\n");
    }
    else
    {
        s_ir_builder = ir_builder_rmt_new_rc5(&ir_builder_config);
        HAL_LOG(LOG_INFO, "rc5 protocol\n");
    }

    if (s_ir_builder == NULL)
    {
        s_tx_channel = RMT_CHANNEL_MAX;
        return VHAL_FAIL;
    }

    HAL_LOG(LOG_INFO, "rmt ir tx init successfully\n");
    return VHAL_OK;
}

/**
* @brief 红外接收初始化
* @param[in]  ir_channel      [通道]
* @param[in]  gpio_num        [IO]
* @param[in]  ir_protocol     [红外协议]
* @param[in]  rx_buf_size     [底层接收buffer，建议1k]
* @param[in]  EXT_PROTO_FLAG  [是否允许扩展（非标准）协议]
* @return  int                [VHAL_OK/VHAL_FAIL]
*/
int vhal_rmt_ir_rx_init(RMT_CH_E ir_channel, uint16_t gpio_num, IR_PROTOCOL_E ir_protocol, uint32_t rx_buf_size, bool EXT_PROTO_FLAG)
{
    if (4 >= rx_buf_size || IR_PROTOCOL_MAX <= ir_protocol || s_rx_channel != RMT_CHANNEL_MAX || s_tx_channel == (rmt_channel_t)ir_channel)
    {
        return VHAL_FAIL;
    }

    rmt_config_t rmt_rx_config = RMT_DEFAULT_CONFIG_RX(gpio_num, ir_channel);
    ESP_ERROR_CHECK(rmt_config(&rmt_rx_config));
    ESP_ERROR_CHECK(rmt_driver_install(ir_channel, rx_buf_size, 0));
    ir_parser_config_t ir_parser_config = IR_PARSER_DEFAULT_CONFIG((ir_dev_t)ir_channel);
    ir_parser_config.flags |= EXT_PROTO_FLAG;
    if (IR_PROTOCOL_NEC == ir_protocol)
    {
        s_ir_parser = ir_parser_rmt_new_nec(&ir_parser_config);
        HAL_LOG(LOG_INFO, "nec protocol\n");
    }
    else
    {
        s_ir_parser = ir_parser_rmt_new_rc5(&ir_parser_config);
        HAL_LOG(LOG_INFO, "rc5 protocol\n");
    }

    if (s_ir_parser == NULL)
    {
        return VHAL_FAIL;
    }

    s_rx_channel = ir_channel;
    s_ir_rx_protocol = ir_protocol;

    if (s_rmt_ir_taskhd == NULL
        && VOS_OK != vesync_task_new(RMT_IR_TASK_NAME,
                                     NULL,
                                     vhal_rmt_ir_task,
                                     NULL,
                                     RMT_IR_TASK_STACK_SIZE,
                                     RMT_IR_TASK_PRIO,
                                     &s_rmt_ir_taskhd))
    {
        s_rx_channel = RMT_CHANNEL_MAX;
        return VHAL_FAIL;
    }

    HAL_LOG(LOG_INFO, "rmt ir rx init successfully\n");
    return VHAL_OK;
}


/**
* @brief 关闭红外发送
* @param[in]  ir_channel    [通道]
*/
void vhal_rmt_ir_tx_deinit(RMT_CH_E ir_channel)
{
    if (s_tx_channel == (rmt_channel_t)ir_channel)
    {
        s_ir_builder = NULL;
        s_tx_channel = RMT_CHANNEL_MAX;
        rmt_driver_uninstall(ir_channel);
    }
}

/**
* @brief 关闭红外接收
* @param[in]  ir_channel    [通道]
*/
void vhal_rmt_ir_rx_deinit(RMT_CH_E ir_channel)
{

    if (s_rx_channel == (rmt_channel_t)ir_channel)
    {
        s_ir_parser = NULL;
        s_rx_channel = RMT_CHANNEL_MAX;
        rmt_driver_uninstall(ir_channel);
    }

    if (s_rmt_ir_taskhd != NULL)
    {
        s_rmt_ir_taskhd = NULL;
    }
}

