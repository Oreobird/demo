/**
* Copyright © Vesync Technologies Co.Ltd. 2022. All rights reserved
* @file         scene_flash.c
* @brief        场景存储
* @author       Joshua
* @date         2022-3-3
*/

#include <string.h>
#include <stdint.h>
#include "vesync_flash.h"
#include "vesync_klv.h"
#include "vesync_common.h"
#include "vesync_memory.h"
#include "vesync_log.h"
#include "custom.h"
#include "custom_flash.h"
#include "app_cfg.h"


static uint32_t klv_arr_item_iterator(void **p_iter, uint32_t iter_cnt, uint8_t *p_buf, uint32_t len)
{
    UNUSED(iter_cnt);

    scene_t *p_prst = (scene_t *)*p_iter;
    if (NULL == p_prst || p_prst->id < CUSTOM_SCENE_ID_MIN)
    {
        return 0;
    }

    uint32_t ofs = 0;
    custom_light_scene_t *p_ctx = &p_prst->ctx;
    ofs += vesync_klv_set(p_buf, len, ofs, CS_CFG_KEY_ID, sizeof(p_prst->id), (uint8_t *)&p_prst->id);

    ofs += vesync_klv_set(p_buf, len, ofs, CS_CFG_KEY_REF, sizeof(p_ctx->reference), (uint8_t *)&p_ctx->reference);
    ofs += vesync_klv_set(p_buf, len, ofs, CS_CFG_KEY_COLOR_MODE, sizeof(p_ctx->mode), (uint8_t *)&p_ctx->mode);
    ofs += vesync_klv_set(p_buf, len, ofs, CS_CFG_KEY_SEG_NUM, sizeof(p_ctx->seg_num), (uint8_t *)&p_ctx->seg_num);
    switch (p_ctx->mode)
    {
        case LIGHT_MODE_WHITE:
            ofs += vesync_klv_set(p_buf, len, ofs, CS_CFG_KEY_SEG_PARAM, sizeof(light_white_t), (uint8_t *)&p_ctx->seg_param);
            break;
        case LIGHT_MODE_COLOR:
            ofs += vesync_klv_set(p_buf, len, ofs, CS_CFG_KEY_SEG_PARAM, sizeof(light_color_t), (uint8_t *)&p_ctx->seg_param);
            break;
        case LIGHT_MODE_MULTI:
            ofs += vesync_klv_set(p_buf, len, ofs, CS_CFG_KEY_SEG_PARAM, p_ctx->seg_num * sizeof(light_color_t), (uint8_t *)&p_ctx->seg_param);
            break;
        default:
            return 0;
    }
    
    *p_iter = list_next_entry(p_prst, list);
    return ofs;
}

int custom_scene_flash_write(void)
{
    int ret = APP_OK;
    uint8_t *p_buf= NULL;
    uint32_t ofs = 0;
    uint32_t buf_len = custom_scene_max_data_size();
    uint8_t version = 0;

    uint8_t scene_num = scene_registry_get_custom_num();

    p_buf = (uint8_t *)vesync_calloc(1, buf_len);
    if (p_buf == NULL)
    {
        return APP_FAIL;
    }

    ofs += vesync_klv_set(p_buf + ofs, buf_len - ofs, CS_KEY_VERSION, sizeof(version), (uint8_t*)&version);
    ofs += vesync_klv_set(p_buf + ofs, buf_len - ofs, CS_KEY_NUM, sizeof(scene_num), (uint8_t*)&scene_num);

    scene_t *p_first = scene_registry_get(SCENE_LIGHT, CUSTOM_SCENE_ID_MIN);
    if (NULL != p_buf)
    {
        p_buf = p_buf + ofs;
        buf_len = buf_len - ofs;
    }

    ofs += vesync_klv_set_arr_iter(p_buf, buf_len, CS_KEY_ARR, scene_num, p_first, klv_arr_item_iterator);
    if (ofs == 0)
    {
        VCOM_SAFE_FREE(p_buf);
        return APP_FAIL;
    }

    //将数据写入指定flash分区
    ret = vesync_flash_write(PARTITION_CFG, CUSTOM_SCENE_CFG_KEY_DATA, p_buf, ofs);
    if (ret != SDK_OK)
    {
        APP_LOG(LOG_WARN, "write flash fail, ret[%d]\n", ret);
        ret = APP_FAIL;
    }

    VCOM_SAFE_FREE(p_buf);
    return ret;
}

int custom_scene_flash_read(void)
{
    int ret = APP_OK;
    uint8_t *p_buf= NULL;
    uint32_t buf_len = custom_scene_max_data_size();
    uint8_t version = 0;
    int scene_num = 0;

    p_buf = (uint8_t *)vesync_calloc(1, buf_len);
    if (p_buf == NULL)
    {
        return APP_FAIL;
    }

    ret = vesync_flash_read(PARTITION_CFG, CUSTOM_SCENE_CFG_KEY_DATA, p_buf, &buf_len);
    if (ret != SDK_OK)
    {
        APP_LOG(LOG_WARN, "read flash fail, ret[%d]\n", ret);
        VCOM_SAFE_FREE(p_buf);
        return APP_FAIL;
    }

    vesync_klv_get(p_buf, buf_len, CS_KEY_VERSION, sizeof(version), &version);
    vesync_klv_get(p_buf, buf_len, CS_KEY_NUM, sizeof(scene_num), &scene_num);

    APP_LOG(LOG_DEBUG, "scene_num = %d\n", scene_num);

    klv_t klv_node, klv_root;
    memset(&klv_node, 0, sizeof(klv_node));
    memset(&klv_root, 0, sizeof(klv_root));

    ret = vesync_klv_get_ptr(p_buf, buf_len, CS_KEY_ARR, &klv_root);
    if (ret != SDK_OK)
    {
        VCOM_SAFE_FREE(p_buf);
        SDK_LOG(LOG_ERROR, "get scene data error\r\n");
        return APP_FAIL;
    }

    uint32_t cnt;
    for (cnt = 0; cnt < scene_num; cnt++)
    {
        memset(&klv_node, 0, sizeof(klv_node));

        if (SDK_OK == vesync_klv_get_item(klv_root.value, klv_root.len, cnt, &klv_node))
        {
            int scene_id = 0;
            custom_light_scene_t custom_scene;
            memset(&custom_scene, 0, sizeof(custom_light_scene_t));

            vesync_klv_get(klv_node.value, klv_node.len, CS_CFG_KEY_ID, sizeof(id), (uint8_t *)&id);
            vesync_klv_get(klv_node.value, klv_node.len, CS_CFG_KEY_REF, sizeof(custom_scene.reference), (uint8_t *)&custom_scene.reference);
            vesync_klv_get(klv_node.value, klv_node.len, CS_CFG_KEY_COLOR_MODE, sizeof(custom_scene.mode), (uint8_t *)&custom_scene.mode);
            vesync_klv_get(klv_node.value, klv_node.len, CS_CFG_KEY_SEG_NUM, sizeof(custom_scene.seg_num), (uint8_t *)&custom_scene.seg_num);

            scene_t *thiz = NULL;
            int scene_size = sizeof(scene_t) + sizeof(custom_light_scene_t);
            int seg_param_size = (custom_scene.mode == LIGHT_MODE_WHITE) ? sizeof(light_white_t) : sizeof(light_color_t);
            thiz = (scene_t *)vesync_calloc(1, scene_size + seg_param_size);
            if (thiz == NULL)
            {
                ret = APP_FAIL;
                continue;
            }
            thiz->type = SCENE_LIGHT;
            thiz->id = scene_id;
            custom_light_scene_t *ctx = (custom_light_scene_t *)thiz->ctx;
            memcpy(ctx, &custom_scene, scene_size);
            vesync_klv_get(klv_node.value, klv_node.len, CS_CFG_KEY_SEG_PARAM, custom_scene.seg_num * seg_param_size, (uint8_t *)&ctx->seg_param);
        }
    }

    VCOM_SAFE_FREE(p_buf);
    return ret;
}

int custom_scene_flash_clear(void)
{
    int ret = vesync_flash_erase_key(PARTITION_CFG, CUSTOM_SCENE_CFG_KEY_DATA);
    if (ret != SDK_OK)
    {
        APP_LOG(LOG_ERROR, "clear custom scene fail\n");
        return APP_FAIL;
    }
    return APP_OK;
}

