/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
 * @file        switch_production.h
 * @brief       产测功能头文件
 * @author      Charles.Mei
 * @date        2021-07-30
 */



#ifndef __SWITCH_PRODUCTION_H__
#define __SWITCH_PRODUCTION_H__

#ifdef __cplusplus
     extern "C" {
#endif


/**
* @brief switch产测功能初始化
*/
void switch_production_init(void);


#ifdef __cplusplus
}
#endif

#endif

