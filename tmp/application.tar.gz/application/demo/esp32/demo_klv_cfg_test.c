/**
 * Copyright © Vesync Technologies Co.Ltd. 2019-2021. All rights reserved.
 * @file    demo_away_cfg_test.c
 * @brief   Away 配置读写测试
 * @author  Niki
 * @date    2021-07-08
 */
#include <string.h>

#include "vhal_flash.h"
#include "vesync_away_internal.h"
#include "vesync_away.h"
#include "vesync_log.h"
#include "vesync_log_internal.h"
#include "vesync_common.h"
#include "vesync_memory.h"
#include "string.h"
#include "vhal_flash.h"
#include "vesync_klv.h"
#include "vesync_cfg.h"

#define  AWAY_TEST_BUFF_LEN   1000
#define  INCHING_KLV_DATA_BUF_LEN 60


#define SWITCH_INCHING_CFG_KEY_DATA     "inching_cfg"
#define INCHING_CFG_VERSION 1

/**
 * @brief inching配置数据key定义
 */
typedef enum
{
    INCHING_KEY_VERSION = 0,
    INCHING_KEY_TOTAL_SEC = 1,
    INCHING_KEY_MAX
}INCHING_CFG_KEY_E;

/**
 * @brief inching状态
 */
typedef enum
{
    INCHING_STOP = 0,
    INCHING_COUNTDOWN = 1,
    INCHING_SUSPEND = 2,        // 暂未使用
    INCHING_UNKNOW
} INCHING_STATE_E;


/**
 * @brief inching参数
 */
typedef struct
{
    uint32_t remain_sec;
    uint32_t total_sec;
    INCHING_STATE_E state;
} inching_status_t;


// inching参数
static inching_status_t s_inching_status;

/**
 * @brief       设置inching配置
 * @param[in]   total_sec   [inching配置的总时间]
 * @return      int         [成功：APP_OK；失败：APP_FAIL]
 */
static int outlet_inching_set_cfg(uint32_t total_sec)
{
    uint8_t *p_buf = NULL;
    int offset = 0;
    uint8_t version = 0;
    int ret = 0;

   // outlet_inching_stop();
    s_inching_status.total_sec = total_sec;
    s_inching_status.remain_sec = total_sec;

    if(NULL == (p_buf = (uint8_t *)vesync_malloc(INCHING_KLV_DATA_BUF_LEN)))
    {
        APP_LOG(LOG_ERROR, "malloc fail!!\r\n");
        return APP_FAIL;
    }

    memset(p_buf, 0, INCHING_KLV_DATA_BUF_LEN);

    version = INCHING_CFG_VERSION;
    offset +=  vesync_klv_set(p_buf+offset, INCHING_KLV_DATA_BUF_LEN-offset, INCHING_KEY_VERSION, sizeof(version), &version);
    offset +=  vesync_klv_set(p_buf+offset, INCHING_KLV_DATA_BUF_LEN-offset, INCHING_KEY_TOTAL_SEC, sizeof(s_inching_status.total_sec), (uint8_t *)&s_inching_status.total_sec);

    if (VHAL_OK != vhal_flash_write(PARTITION_CFG,SWITCH_INCHING_CFG_KEY_DATA,p_buf,offset))
    {
        APP_LOG(LOG_ERROR, "inching_cfg save fail!\r\n");

        ret =  APP_FAIL;
    }

    vesync_free(p_buf);

    return ret;
}


/**
 * @brief       加载inching配置
 * @return      int         [成功：APP_OK；失败：APP_FAIL]
 */
static int outlet_inching_load_cfg(void)
{
    //uint32_t read_len = 0;
    uint32_t len = 0;
    uint8_t *p_buf= NULL;
    uint8_t version = 0;

    if(NULL == (p_buf = (uint8_t *)vesync_malloc(INCHING_KLV_DATA_BUF_LEN)))
    {
        return APP_FAIL;
    }

    len = INCHING_KLV_DATA_BUF_LEN;

    if(VHAL_OK != vhal_flash_read(PARTITION_CFG, SWITCH_INCHING_CFG_KEY_DATA, p_buf, &len))
    {
        APP_LOG(LOG_INFO, "inching_cfg load fail!!!\r\n");
        vesync_free(p_buf);
        return APP_FAIL;
    }

    memset(&s_inching_status, 0, sizeof(s_inching_status));
    vesync_klv_get(p_buf, len, INCHING_KEY_VERSION, sizeof(version), &version);
    vesync_klv_get(p_buf, len, INCHING_KEY_TOTAL_SEC, sizeof(s_inching_status.total_sec), (uint8_t *)&s_inching_status.total_sec);

    s_inching_status.remain_sec = s_inching_status.total_sec;
    s_inching_status.state = INCHING_STOP;
    APP_LOG(LOG_INFO, "inching_cfg load success.version =%d total =%d \r\n",version,s_inching_status.total_sec);

    vesync_free(p_buf);
    return APP_OK;
}


void  vesync_inching_cfg_test()
{

    outlet_inching_set_cfg(8888);

    memset(&s_inching_status, 0, sizeof(s_inching_status));

    outlet_inching_load_cfg();

    SDK_LOG(LOG_INFO,"inching total sec= %d\n",s_inching_status.total_sec);

}

#if 0
void vesync_away_cfg_test()
{
    uint8_t *p_buf;
    away_config_t pst_cfg;
    away_rnd_times_t pst_rnd_times;
    uint32_t size = 0;

    p_buf = vesync_malloc(AWAY_TEST_BUFF_LEN);

    pst_cfg.end_clk_sec = 4444;
    pst_cfg.start_clk_sec = 5555;
    pst_cfg.repeat_config = 1;
    pst_cfg._enable = 1;
    pst_cfg._modify_local_ts = 8888;
    pst_cfg._exec_cnt = 50;

    pst_rnd_times.points[0] = 1111;
    pst_rnd_times.points[1] = 2222;
    pst_rnd_times.points[2] = 3333;
    pst_rnd_times.points[3] = 44444;
    pst_rnd_times.points[4] = 55578;

    pst_rnd_times.point_num = 5;

    pst_rnd_times._generated_local_ts = 8596;

    vesync_away_cfg_marshal(&pst_cfg, &pst_rnd_times, p_buf, AWAY_TEST_BUFF_LEN, &size);
    //vesync_away_flash_wr_cfg_cb(p_buf, size);

    memset(p_buf, 0, AWAY_TEST_BUFF_LEN);

    size = 0;

    //vesync_away_flash_rd_cfg_cb(p_buf, AWAY_TEST_BUFF_LEN, &size);

    memset(&pst_cfg, 0, sizeof(pst_cfg));
    memset(&pst_rnd_times, 0, sizeof(pst_rnd_times));

    vesync_away_cfg_unmarshal(p_buf, size, &pst_cfg, &pst_rnd_times);

    SDK_LOG(LOG_INFO, "after read:\n\n");
    SDK_LOG(LOG_INFO, "pst_cfg.end_clk_sec = %d\n", pst_cfg.end_clk_sec);
    SDK_LOG(LOG_INFO, "pst_cfg.start_clk_sec = %d\n", pst_cfg.start_clk_sec);

    SDK_LOG(LOG_INFO, "pst_cfg.repeat_config = %d\n", pst_cfg.repeat_config);
    SDK_LOG(LOG_INFO, "pst_cfg._enable = %d\n", pst_cfg._enable);
    SDK_LOG(LOG_INFO, "pst_cfg._modify_local_ts = %d\n", pst_cfg._modify_local_ts);
    SDK_LOG(LOG_INFO, "pst_cfg._exec_cnt = %d\n", pst_cfg._exec_cnt);

    SDK_LOG(LOG_INFO, "pst_rnd_times.point_num = %d\n", pst_rnd_times.point_num);

    SDK_LOG(LOG_INFO, "pst_rnd_times._generated_local_ts = %d\n", pst_rnd_times._generated_local_ts);

    SDK_LOG(LOG_INFO, "pst_rnd_times.point = %d :%d :%d:%d:%d\n", pst_rnd_times.points[0], pst_rnd_times.points[1], pst_rnd_times.points[2], pst_rnd_times.points[3], pst_rnd_times.points[4]);

    vesync_free(p_buf);
}
#endif