/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_ev_center.h
 * @brief       事件处理接口
 * @date        2021-05-11
 */
#include <string.h>
#include <stdio.h>
#include "vesync_common.h"
#include "vesync_log_internal.h"
#include "vesync_task.h"
#include "vesync_queue.h"
#include "vesync_memory.h"
#include "vesync_event_internal.h"

static vesync_queue_t s_event_queue;

static event_manage_t s_event_manager;

/*-----------------------------------------------------------------------------*
*-----------------------------------内部函数API实现-------------------------------*
*-----------------------------------------------------------------------------*/

/**
* @brief 增加订阅节点
* @param sub_id                 [订阅者ID]
* @param cb                     [订阅回调函数]
* @param *node                  [订阅的事件ID]
* @return int                   [SDK_OK/SDK_FAIL]
*/
int vesync_event_subscribe_list_add(int sub_id, event_subscribe_cb cb, event_node_t *node)
{
    VCOM_NULL_PARAM_CHK(node, return SDK_FAIL);

    event_subscribe_t *pos, *n;
    struct list_head *head;

    head = &node->subscribe_list;

    list_for_each_entry_safe(pos, n, head, list)
    {
        if (pos->sub_id == sub_id)
        {
            SDK_LOG(LOG_INFO, "Already subscribe.\n");
            return SDK_FAIL;
        }
    }

    event_subscribe_t *subscribe = (event_subscribe_t *) vesync_malloc(sizeof(event_subscribe_t));
    if (subscribe == NULL)
    {
        SDK_LOG(LOG_ERROR, "Event create event subscribe failed\n");
        return SDK_FAIL;
    }

    memset(subscribe, 0, sizeof(event_subscribe_t));
    subscribe->sub_id = sub_id;
    subscribe->event_handle = cb;

    vesync_mutex_lock(&node->mutex);
    list_add_tail(&subscribe->list, &node->subscribe_list);
    vesync_mutex_unlock(&node->mutex);

    return SDK_OK;
}

/**
* @brief 删除订阅节点
* @param sub_id                 [订阅者ID]
* @param *node                  [订阅的事件ID]
*/
void vesync_event_subscribe_list_del(int sub_id, event_node_t *node)
{    
    VCOM_NULL_PARAM_CHK(node, return);

    event_subscribe_t *pos, *n;
    struct list_head *head;

    head = &node->subscribe_list;

    vesync_mutex_lock(&node->mutex);
    list_for_each_entry_safe(pos, n, head, list)
    {
        if (pos->sub_id == sub_id)
        {
            list_del(&pos->list);
            INIT_LIST_HEAD(&pos->list);
            vesync_free(pos);
            vesync_mutex_unlock(&node->mutex);
            break;
        }
    }
    vesync_mutex_unlock(&node->mutex);

    // 如果事件节点下的订阅节点为空，则删除该事件节点
    if (list_empty(&node->subscribe_list))
    {
        event_node_t *node_pos, *node_n;
        struct list_head *node_head;

        node_head = &s_event_manager.node_list;

        vesync_mutex_lock(&s_event_manager.mutex);
        list_for_each_entry_safe(node_pos, node_n, node_head, list)
        {
            if (node_pos->event_id == node->event_id)
            {
                list_del(&node_pos->list);
                INIT_LIST_HEAD(&node_pos->list);

                vesync_mutex_free(&node_pos->mutex);
                vesync_free(node_pos);

                s_event_manager.event_num--;
                break;
            }
        }
        vesync_mutex_unlock(&s_event_manager.mutex);
    }
}

/**
* @brief 增加事件节点
* @param event_id                 [事件ID]
* @return event_node_t*           [添加的事件节点指针]
*/
event_node_t *vesync_event_node_list_add(EVENT_ID_E event_id)
{
    event_node_t *pos, *n;
    struct list_head *head;

    head = &s_event_manager.node_list;

    list_for_each_entry_safe(pos, n, head, list)
    {
        if (pos->event_id == event_id)
        {
            SDK_LOG(LOG_INFO, "Event node already exit.\n");
            return pos;
        }
    }

    event_node_t *node = (event_node_t *) vesync_malloc(sizeof(event_node_t));
    if (node == NULL)
    {
        SDK_LOG(LOG_ERROR, "Event create event node failed\n");
        return NULL;
    }

    memset(node, 0, sizeof(event_node_t));
    node->event_id = event_id;

    int ret = vesync_mutex_new(&node->mutex);
    if (ret != VOS_OK)
    {
        vesync_free(node);
        SDK_LOG(LOG_ERROR, "Event mutex create fail\n");
        return NULL;
    }

    INIT_LIST_HEAD(&node->subscribe_list);

    vesync_mutex_lock(&s_event_manager.mutex);
    list_add_tail(&node->list, &s_event_manager.node_list);
    s_event_manager.event_num++;
    vesync_mutex_unlock(&s_event_manager.mutex);

    return node;
}


/**
* @brief 获取事件节点
* @param event_id                 [事件ID]
* @return event_node_t*           [事件节点指针]
*/
event_node_t *vesync_event_node_get(EVENT_ID_E event_id)
{
    event_node_t *pos, *n;
    struct list_head *head;

    head = &s_event_manager.node_list;

    list_for_each_entry_safe(pos, n, head, list)
    {
        if (pos->event_id == event_id)
        {
            return pos;
        }
    }

    return NULL;
}

static int vesync_event_dispatch(vesync_ev_t *event)
{
    VCOM_NULL_PARAM_CHK(event, return SDK_FAIL);

    event_node_t *pos, *n;
    struct list_head *head;

    head = &s_event_manager.node_list;

    list_for_each_entry_safe(pos, n, head, list)
    {
        if (pos->event_id == event->event_id)
        {
            event_subscribe_t *sub_pos, *sub_n;
            struct list_head *sub_head = &pos->subscribe_list;
            list_for_each_entry_safe(sub_pos, sub_n, sub_head, list)
            {
                if (sub_pos->event_handle)
                {
                    sub_pos->event_handle(event);
                }
            }
            break;
        }
    }

    return SDK_OK;
}

/**
* @brief 事件处理中心任务
* @param args
*/
void vesync_event_task(void *args)
{
    UNUSED(args);
    vesync_ev_t event;

    while(1)
    {
        memset(&event, 0, sizeof(vesync_ev_t));

        int ret = vesync_queue_recv(&s_event_queue, &event, VESYNC_OS_WAIT_FOREVER);
        if (ret != VOS_OK)
        {
            SDK_LOG(LOG_ERROR, "Event queue recv fail\n");
            return;
        }

        if (list_empty(&s_event_manager.node_list))
        {
            continue;
        }

        vesync_event_dispatch(&event);
    }
}


/*-----------------------------------------------------------------------------*
*-----------------------------------外部函数API实现-------------------------------*
*-----------------------------------------------------------------------------*/

/**
* @brief 初始化事件处理中心
* @return  int                   [成功/失败]
*/
int vesync_event_init(void)
{
    memset(&s_event_manager, 0, sizeof(event_manage_t));
    INIT_LIST_HEAD(&s_event_manager.node_list);

    int ret = vesync_mutex_new(&s_event_manager.mutex);
    if (ret != VOS_OK)
    {
        SDK_LOG(LOG_ERROR, "Event mutex create fail\n");

        return SDK_FAIL;
    }

    ret = vesync_queue_new(&s_event_queue, EVENT_QUEUE_MAX_NUM * sizeof(vesync_ev_t), sizeof(vesync_ev_t));
    if (ret != VOS_OK)
    {
        vesync_mutex_free(&s_event_manager.mutex);
        SDK_LOG(LOG_ERROR, "Event queue create fail\n");
        return SDK_FAIL;
    }

    ret = vesync_task_new(EVENT_TASK_NAME,
                          vesync_event_task,
                          NULL,
                          EVENT_TASK_STACKSIZE,
                          EVENT_TASK_PRIO,
                          NULL);
    if (ret != VOS_OK)
    {
        SDK_LOG(LOG_ERROR, "Event task create fail\n");
        vesync_mutex_free(&s_event_manager.mutex);
        vesync_queue_free(&s_event_queue);
        return SDK_FAIL;
    }

    return SDK_OK;
}

/**
* @brief 释放事件处理中心资源
*/
void vesync_event_deinit(void)
{
    vesync_queue_free(&s_event_queue);
    vesync_mutex_free(&s_event_manager.mutex);
}


/**
* @brief 发布事件通知
*/
int vesync_event_publish(vesync_ev_t *event)
{
    int ret = vesync_queue_send(&s_event_queue, event, VESYNC_OS_NO_WAIT);
    if (ret != VOS_OK)
    {
        SDK_LOG(LOG_ERROR, "Event publish failed\n");
        return SDK_FAIL;
    }

    return SDK_OK;
}

/**
* @brief 订阅事件通知
* @param
* @return int
*/
int vesync_event_subscribe(EVENT_ID_E event_id, int sub_id, event_subscribe_cb cb)
{
    printf("subscribe id=%d, event=%d\n", sub_id, event_id);
    event_node_t *node = vesync_event_node_list_add(event_id);
    if (node == NULL)
    {
        return SDK_FAIL;
    }

    int ret = vesync_event_subscribe_list_add(sub_id, cb, node);
    if (ret != SDK_OK)
    {
        return SDK_FAIL;
    }

    return SDK_OK;
}

/**
* @brief 取消订阅事件通知
* @param
* @return int
*/
int vesync_event_unsubscribe(EVENT_ID_E event_id, int sub_id)
{
    printf("unsubscribe id=%d, event=%d\n", sub_id, event_id);
    event_node_t *node = vesync_event_node_get(event_id);
    if (node == NULL)
    {
        SDK_LOG(LOG_ERROR, "Event node not found\n");
        return SDK_FAIL;
    }

    vesync_event_subscribe_list_del(sub_id, node);

    return SDK_OK;
}

