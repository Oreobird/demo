/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_bypass_nightlight_brightness.c
 * @brief       bypass处理接口
 * @date        2021-05-17
 */
#include <string.h>

#include "vesync_common.h"
#include "vesync_memory.h"
#include "vesync_bypass_internal.h"

/**
 * @brief 设置夜灯亮度
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  json                     [json数据指针]
 * @return BYPASS_ERR_E                 [错误码]
 */
static BYPASS_ERR_E bypass_method_set_nightlight_brightness_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    BYPASS_ERR_E ret = BP_OK;
    cJSON* json_data = NULL;

    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    bypass_nightlight_brightness_t *p_nightlight = (bypass_nightlight_brightness_t *)vesync_malloc(sizeof(bypass_nightlight_brightness_t));
    if (NULL == p_nightlight)
    {
        return BP_ERR_NOMEM;
    }

    memset(p_nightlight, 0, sizeof(bypass_nightlight_brightness_t));

    json_data = cJSON_GetObjectItemCaseSensitive(json, "night_light_brightness");
    if (cJSON_IsNumber(json_data))
    {
        if (json_data->valueint >= 0 && json_data->valueint <= 100)
            p_nightlight->brightness = json_data->valueint;
        else
        {
            ret = BP_ERR_ARG;
            goto _exit;
        }
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_SET_NIGHTLIGHT_BRIGHTNESS);
    if (method_cb)
    {
        method_cb(p_msg_ctx, (void*)p_nightlight);
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

_exit:
    vesync_free(p_nightlight);
    return ret;
}


static bypass_item_data_t nightlight_brightness_method_tbl[] = {
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_SET_NIGHTLIGHT_BRIGHTNESS, "setNightLightBrightness", bypass_method_set_nightlight_brightness_handle, NULL},
};

void vesync_bypass_nightlight_brightness_init(void)
{
    for (int i = 0; i < SIZEOF_ARRAY(nightlight_brightness_method_tbl); i++)
    {
        bypass_item_t *item = vesync_bypass_init_item(&nightlight_brightness_method_tbl[i]);
        if (item != NULL)
        {
            vesync_bypass_add_item(item);
        }
    }
}
