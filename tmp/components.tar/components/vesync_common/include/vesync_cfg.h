/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file       vesync_cfg.h
* @brief      vesync device config information.
* @date       2021-05-13
* @note       File auto generated, DO NOT edit.
*/

#ifndef __VESYNC_CFG_H__
#define __VESYNC_CFG_H__

#ifdef __cplusplus
extern "C" {
#endif

// product_cfg
#define PR_FW_VERSION                      ("1.0.00")
#define PR_HW_VERSION                      ("1.0")
#define PR_BRAND                           ("Etekcity")
#define PR_TYPE                            ("demo")
#define PR_MODEL                           ("esp8266")
#define PR_ALIAS_MODEL                     ("esp8266")
#define PR_COUNTRY_CODE                    ("US")
#define SUPPORT_CTRY_CODE                  ("US")
#define PR_CONFIG_MODEL                    ("WiFiBTOnboardingNotify_AirPurifier_Core400S_US")
#define PR_PID                             ("1pwubaak68rotlsb")
#define PR_AUTHKEY                         ("ww6zvzwtaa6hqjl991g0w1obkeo0sd44")

// event_cfg
#define PR_EVENT_TASK_STACKSIZE            (2048)
#define PR_EVENT_QUEUE_MAX_NUM             (32)
#define PR_EVENT_QUEUE_MSG_MAX_LEN         (1024)

// net_cfg
#define PR_CFGNET_MODE                     ("ap_cfg_net")
#define PR_SSID_PREFIX                     ("vesync")
#define PR_BAN_BLE_BROADCAST               (0)
#define PR_PROT_HEADER_VER                 (0x1)
#define PR_PROT_PAYLOAD_VER                (0x2)

// ble_cfg
#define PR_BLE_TYPE                        (0)
#define PR_BLE_MODEL                       (0)
#define PR_BLE_CMD                         (0)
#define PR_BLE_CFGNET_VER                  (0)
#define PR_BLE_NAME                        ("esp8266")

// protocol_cfg
#define PR_REPORT_PROCOTOL_VER             ("v2")
#define PR_BYPASS_PROCOTOL_VER             ("v2")

// mcu_cfg
#define PR_TOTAL_MCU_NUM                   (0)

// ota_cfg
#define PR_OTA_TYPE_WIFI                   (1)
#define PR_OTA_TYPE_BLE                    (0)
#define PR_OTA_TYPE_MCU                    (0)

// wifi_cfg
#define PR_WIFI_PS_TYPE                    (1)

// uart_cfg
#define PR_UART_NUM                        (1)
#define PR_UART_TX_PIN                     (16)
#define PR_UART_RX_PIN                     (17)
#define PR_UART_BAUD_RATE                  (9600)
#define PR_UART_PAYLOAD_MAX_LEN            (256)
#define PR_UART_MAX_RESEND_CNT             (3)
#define PR_UART_SEND_RSP_TIMEOUT_MS        (2000)
#define PR_UART_SEND_NO_RSP_TIMEOUT_MS     (10)
#define PR_UART_SEND_USE_TIMER             (1)                                                //for test
#define PR_UART_SEND_INTTERVAL_MS          (50)
#define PR_UART_SEND_ACK_QUEUE_LEN         (10)
#define PR_UART_SEND_DATA_QUEUE_LEN        (10)

// production_cfg
#define PRODUCTION_WIFI_SSID               ("VeSync_Pruduction_AP")
#define PRODUCTION_WIFI_PWD                ("VeSync2018@etekcity.com.cn")
#define PRODUCTION_SERVER_ADDR             ("purifierCore400s.us.factory.vesync.cn")
#define PRODUCTION_AUTO_ENTER              (1)

#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_CFG_H__ */
