/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
 * @file        demo_vesync_nfc_card.h
 * @brief       nfc carrd模块测试口
 * @date        2021-11-13
 */
#ifndef __DEMO_VESYNC_NFC_CARD_H__
#define __DEMO_VESYNC_NFC_CARD_H__

#ifdef __cplusplus
extern "C"
{
#endif

/**
 * @brief iic 测试初始化代码
 */
void demo_iic_init();

/**
 * @brief vesync_nfc_card 模块配网测试接口初始化
 */
void demo_vesync_nfc_card_test_init();

#ifdef __cplusplus
}
#endif

#endif /* __DEMO_VESYNC_NFC_CARD_H__ */
