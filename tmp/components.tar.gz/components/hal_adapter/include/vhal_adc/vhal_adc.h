/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file    vhal_adc.c
* @brief   adc接口
* @author  Lind
* @date     2021-12-3
*/

#ifndef _VHAL_ADC_H_
#define _VHAL_ADC_H_

#include <stdint.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C"
{
#endif

#define ADC_MAX_STORE_DATA_NUM   (512)      // 连读模式下每次最大的获取的数据数量

/**
* @brief adc读取的数据结构体
*/
typedef struct
{
    uint32_t data:          13; //ADC real output data info. Resolution: 12 bit.
    uint32_t channel:       3;  //ADC channel index info.
} adc_data_t;

/**
* @brief adc单读数据获取
* @param[in]  adc_io    [adc gpio]
* @param[out]  *p_data  [获取的数据]
* @return  int          [VHAL_OK/VHAL_FAIL]
*/
int vhal_adc_single_read_get_data(uint8_t adc_io, uint32_t *p_data);

/**
* @brief adc连读模式数据获取
* @param[out]  *p_buf           [外部提供缓存数据的buf，用于接口缓存数据]
* @param[in]  data_num          [可存储的数据数量,每次最多读取512个数据]
* @param[out]  *p_data_num      [实际获取到的数据数量]
* @param[in]  max_delay         [最大阻塞读取时间]
* @return  int                  [VHAL_OK/VHAL_FAIL]
*/
int vhal_adc_dma_get_data(adc_data_t *p_buf, uint16_t data_num, uint16_t *p_data_num, uint32_t max_delay);

/**
* @brief adc连读模式初始化
* @param[in]  *adc_io           [adc gpio]
* @param[in]  io_num            [io数量]
* @param[in]  data_num          [期望每次读取的数据数量]
* @param[in]  sample_freq       [采样频率/Hz]
* @return  int                  [VHAL_OK/VHAL_FAIL]
*/
int vhal_adc_dma_init(uint8_t *adc_io, uint16_t io_num, uint16_t sample_freq);

/**
* @brief adc单读模式初始化
* @param[in]  adc_io        [adc gpio]
* @return  int              [VHAL_OK/VHAL_FAIL]
*/
int vhal_adc_single_read_init(uint8_t adc_io);

/**
* @brief adc驱动卸载，卸载所有adc，由于wifi模块会使用adc2，因此影响较大，不建议调用
*/
void vhal_adc_deinit(void);


#ifdef __cplusplus
}
#endif

#endif /* _VHAL_ADC_H_ */

