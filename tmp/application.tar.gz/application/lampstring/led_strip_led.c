/**
* Copyright © Vesync Technologies Co.Ltd. 2022. All rights reserved.
* @file    led_strip_led.c
* @brief   led控制
* @author  Lind
* @date    2022-01-04
*/

#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
#include <stdio.h>

#include "vesync_common.h"
#include "vesync_log.h"
#include "vesync_memory.h"
#include "vesync_task.h"
#include "vesync_queue.h"
#include "vesync_device.h"
#include "vhal_rmt_1_wire.h"

#include "led_strip_led.h"
#include "led_strip_board.h"
#include "led_strip_scene.h"
#include "led_strip_button.h"

// 计算最低亮度为5%后的真实亮度(100分辨率)
#define TRUE_BRIGHTNESS(x)     (LS_LED_MIN_BRIGHTNESS + x * (LS_LED_V_RST - LS_LED_MIN_BRIGHTNESS) / LS_LED_V_RST)

static ls_changing_status_t s_ls_changing_status;
static bool s_change_flag = true;                   // 灯效变化标志位
static ls_scene_t *s_led_scene = NULL;
static LS_LED_MODE_E s_mode = LS_LED_MODE_OFF;
//static int task_cycle = 20; // 任务最长执行间隔一次
static uint8_t s_led_node_num = LED_NODE_NUM;
static ls_hsv_t s_off = {0, 0, 0, 0};

// 关闭LED
static ls_static_param_t s_turn_off =
{
    .node_num = 1,
    .mode = LS_LED_OFF,
    .color_head = &s_off,
};

/**
* @brief  hsv2rgb转换
* @param[in]  *pst_all_color    [模式颜色参数]
* @param[out]  rgb_pwm[3]       [输出的rgb的pwm占空比数组]
*/
static void ls_led_conv_hsv2rgb(ls_hsv_t *pst_all_color, uint8_t rgb_pwm[3])
{
    int i;
    float f, p, q, t, v, s, h;
    h = pst_all_color->H % LS_LED_HS_RST;
    s = pst_all_color->S;
    v = pst_all_color->V;
    if (v == 0)
    {
        rgb_pwm[0] = 0;
        rgb_pwm[1] = 0;
        rgb_pwm[2] = 0;
        return;
    }

    if (v > LS_LED_RST)
    {
        v = LS_LED_RST;
    }

    if(s == 0)
    {
        // achromatic (grey)
        rgb_pwm[0] = rgb_pwm[1] = rgb_pwm[2] = (uint8_t)v;
        return;
    }

    h = h / (LS_LED_HS_RST / 6) ;            // sector 0 to 5
    i = (uint32_t)h;
    f = h - i;          // factorial part of h
    p = v * (1 - s / LS_LED_HS_RST);
    q = v * (1 - s / LS_LED_HS_RST * f);
    t = v * (1 - s / LS_LED_HS_RST * (1 - f));
    switch (i)
    {
        case 0:
            rgb_pwm[0] = (uint8_t)v;
            rgb_pwm[1] = (uint8_t)t;
            rgb_pwm[2] = (uint8_t)p;
            break;
        case 1:
            rgb_pwm[0] = (uint8_t)q;
            rgb_pwm[1] = (uint8_t)v;
            rgb_pwm[2] = (uint8_t)p;
            break;
        case 2:
            rgb_pwm[0] = (uint8_t)p;
            rgb_pwm[1] = (uint8_t)v;
            rgb_pwm[2] = (uint8_t)t;
            break;
        case 3:
            rgb_pwm[0] = (uint8_t)p;
            rgb_pwm[1] = (uint8_t)q;
            rgb_pwm[2] = (uint8_t)v;
            break;
        case 4:
            rgb_pwm[0] = (uint8_t)t;
            rgb_pwm[1] = (uint8_t)p;
            rgb_pwm[2] = (uint8_t)v;
            break;
        default:
            rgb_pwm[0] = (uint8_t)v;
            rgb_pwm[1] = (uint8_t)p;
            rgb_pwm[2] = (uint8_t)q;
            break;
    }

}

/**
* @brief 计算下一参数
* @param[in]  step_num        [总步数]
* @param[in]  remind_step     [剩余步数]
* @param[in]  begin_param     [初始参数]
* @param[in]  end_param       [目标参数]
* @return  uint16_t           [下一参数]
*/
static uint16_t next_param(uint16_t step_num, uint16_t remain_step, uint16_t begin_param, uint16_t end_param)
{
    if (1 == remain_step || begin_param == end_param)
    {
        return end_param;
    }

    if (remain_step == step_num)
    {
        return begin_param;
    }

    return (begin_param * remain_step / step_num + end_param * (step_num - remain_step) / step_num);
}

/**
* @brief    保存新模式动态参数
* @param[in]  *pst_params       [新参数]
*/
static void save_diverse_params(ls_dynamic_param_t *pst_params)
{
    s_ls_changing_status.cur_node = 0;
    s_ls_changing_status.step_num = pst_params->step_num;
    s_ls_changing_status.remain_step = pst_params->step_num;
    s_ls_changing_status.remain_times = pst_params->times;
    s_change_flag = false;
}

/**
* @brief 记录变化状态
* @param[in]  *pst_param  [模式参数]
* @return  int            [执行结果 APP_OK:还在执行中 APP_FAIL:执行结束]
*/
static int save_changing_status(ls_dynamic_param_t *pst_param)
{
    if (0 == s_ls_changing_status.remain_step)
    {
        s_ls_changing_status.cur_node++;
        s_ls_changing_status.remain_step = pst_param->step_num - 1;
    }
    if (s_ls_changing_status.cur_node == pst_param->node_num)
    {
        // 一次灯效周期结束
        if (0 != pst_param->times)
        {
            s_ls_changing_status.remain_times--;
            if (0 == s_ls_changing_status.remain_times)
            {
                // 执行结束
                s_ls_changing_status.remain_step = 0;
                return APP_FAIL;
            }
        }
        s_ls_changing_status.cur_node = 0;
    }

    return APP_OK;
}

/**
* @brief    渐变
* @param[in]  *pst_gradient_param  [参数]
* @return     uint32_t             [执行结果 APP_OK:执行成功，还在执行中 APP_FAIL:执行失败/执行结束]
*/
static int ls_led_gradient(ls_dynamic_param_t *pst_gradient_param)
{
    if (pst_gradient_param == NULL || pst_gradient_param->mode_head == NULL)
    {
        APP_LOG(LOG_ERROR, "Invaild parameters \n");
        return APP_FAIL;
    }

    uint8_t diff_num = pst_gradient_param->diff_num;
    ls_hsv_t *tgt_node_color = NULL;
    ls_hsv_t *cur_node_color = NULL;
    ls_hsv_t next_color;
    uint16_t devia = 0;
    memset(&next_color, 0, sizeof(ls_hsv_t));
    uint8_t rgb[3] = {0};
    uint8_t rgbw[4] = {0};

    if (s_change_flag)
    {
        save_diverse_params(pst_gradient_param);
    }
     // 灯效节点切换
    if (APP_FAIL == save_changing_status(pst_gradient_param))
    {
        s_mode = LS_LED_MODE_STATIC;
        return APP_FAIL;
    }

    // 按节点亮不同灯效节点颜色
    for (uint8_t i = 0; i < s_led_node_num; i++)
    {
        devia = (diff_num == 0 ? (s_ls_changing_status.cur_node + 1) : ((s_ls_changing_status.cur_node + 1) * diff_num + i));
        tgt_node_color = pst_gradient_param->mode_head + devia % pst_gradient_param->node_num;
        devia = (diff_num == 0 ? s_ls_changing_status.cur_node : (s_ls_changing_status.cur_node * diff_num + i));
        cur_node_color = pst_gradient_param->mode_head + devia % pst_gradient_param->node_num;
        next_color.H = next_param(s_ls_changing_status.step_num, s_ls_changing_status.remain_step, cur_node_color->H, tgt_node_color->H);
        next_color.S = next_param(s_ls_changing_status.step_num, s_ls_changing_status.remain_step, cur_node_color->S, tgt_node_color->S);
        next_color.V = next_param(s_ls_changing_status.step_num, s_ls_changing_status.remain_step, cur_node_color->V, tgt_node_color->V);
        ls_led_conv_hsv2rgb(&next_color, rgb);
        memcpy(rgbw + 1, rgb, 3);
        rgbw[0] = tgt_node_color->white;
        vhal_1_wire_tx_set_pixels(i, rgbw, LED_DATA_LEN);
    }

    if (VHAL_OK != vhal_1_wire_tx_refresh(0))
    {
        APP_LOG(LOG_ERROR, "tx refresh error \n");
        return APP_FAIL;
    }

    s_ls_changing_status.remain_step--;
    return APP_OK;
}

/**
* @brief    切换
* @param[in]  *pst_switch_param    [参数]
* @return     uint32_t             [执行结果 APP_OK:执行成功，还在执行中 APP_FAIL:执行失败/执行结束]
*/
static int ls_led_switch(ls_dynamic_param_t *pst_switch_param)
{
    if (pst_switch_param == NULL || pst_switch_param->mode_head == NULL)
    {
        APP_LOG(LOG_ERROR, "Invaild parameters \n");
        return APP_FAIL;
    }
    uint8_t diff_num = pst_switch_param->diff_num;
    ls_hsv_t *tgt_node_color = NULL;
    uint8_t rgb[3] = {0};
    uint8_t rgbw[4] = {0};

    if (s_change_flag)
    {
        save_diverse_params(pst_switch_param);
    }
     // 灯效节点切换
    if (0 == s_ls_changing_status.remain_step || pst_switch_param->step_num == s_ls_changing_status.remain_step)
    {
        if (APP_FAIL == save_changing_status(pst_switch_param))
        {
            s_mode = LS_LED_MODE_STATIC;
            return APP_FAIL;
        }
        uint16_t devia = 0;
        for (uint8_t i = 0; i < s_led_node_num; i++)
        {
            devia = (diff_num == 0 ? s_ls_changing_status.cur_node : (s_ls_changing_status.cur_node * diff_num + i));
            tgt_node_color = pst_switch_param->mode_head + devia % pst_switch_param->node_num;
            ls_led_conv_hsv2rgb(tgt_node_color, rgb);
            memcpy(rgbw + 1, rgb, 3);
            rgbw[0] = tgt_node_color->white;
            vhal_1_wire_tx_set_pixels(i, rgbw, LED_DATA_LEN);
        }
        if (VHAL_OK != vhal_1_wire_tx_refresh(0))
        {
            APP_LOG(LOG_ERROR, "tx refresh error \n");
            return APP_FAIL;
        }
    }

    s_ls_changing_status.remain_step--;
    return APP_OK;
}

/**
* @brief    呼吸
* @param[in]  *pst_breathing_param  [参数]
* @return     uint32_t              [执行结果 APP_OK:执行成功，还在执行中 APP_FAIL:执行失败/执行结束]
*/
static int ls_led_breathing(ls_dynamic_param_t *pst_breathing_param)
{
    if (pst_breathing_param == NULL || pst_breathing_param->mode_head == NULL)
    {
        APP_LOG(LOG_ERROR, "Invaild parameters \n");
        return APP_FAIL;
    }

    uint8_t diff_num = pst_breathing_param->diff_num;
    ls_hsv_t *tgt_node_color = NULL;
    ls_hsv_t *cur_node_color = NULL;
    ls_hsv_t next_color;
    memset(&next_color, 0, sizeof(ls_hsv_t));
    uint8_t rgb[3] = {0};
    uint8_t rgbw[4] = {0};

    if (s_change_flag)
    {
        save_diverse_params(pst_breathing_param);
    }
     // 呼吸灯效节点切换
    if (APP_FAIL == save_changing_status(pst_breathing_param))
    {
        s_mode = LS_LED_MODE_STATIC;
        return APP_FAIL;
    }

    uint16_t devia = 0;
    for (uint8_t i = 0; i < s_led_node_num; i++)
    {
        devia = (diff_num == 0 ? (s_ls_changing_status.cur_node + 1) : ((s_ls_changing_status.cur_node + 1) * diff_num + i));
        tgt_node_color = pst_breathing_param->mode_head + devia % pst_breathing_param->node_num;
        devia = (diff_num == 0 ? s_ls_changing_status.cur_node : (s_ls_changing_status.cur_node * diff_num + i));
        cur_node_color = pst_breathing_param->mode_head + devia % pst_breathing_param->node_num;
        next_color.H = cur_node_color->H;
        next_color.S = cur_node_color->S;
        next_color.V = next_param(s_ls_changing_status.step_num, s_ls_changing_status.remain_step, cur_node_color->V, tgt_node_color->V);
        next_color.white = next_param(s_ls_changing_status.step_num, s_ls_changing_status.remain_step, cur_node_color->white, tgt_node_color->white);
        ls_led_conv_hsv2rgb(&next_color, rgb);
        memcpy(rgbw + 1, rgb, 3);
        rgbw[0] = tgt_node_color->white;
        vhal_1_wire_tx_set_pixels(i, rgbw, LED_DATA_LEN);
    }

    if (VHAL_OK != vhal_1_wire_tx_refresh(0))
    {
        APP_LOG(LOG_ERROR, "tx refresh error \n");
        return APP_FAIL;
    }

    s_ls_changing_status.remain_step--;
    return APP_OK;
}

/**
* @brief 设置静态颜色
* @param[in]  *pst_static_param     [颜色参数]
*/
static void ls_led_set_static_color(ls_static_param_t *pst_static_param)
{
    uint8_t rgb[3] = {0};
    float rate = (float)LS_LED_RST / LS_LED_V_RST;
    uint8_t rgbw[4] = {0};
    ls_hsv_t *hsv_parm = pst_static_param->color_head;
    uint8_t num = pst_static_param->node_num;
    uint8_t node_num = pst_static_param->mode == LS_LED_MULTI_SEG ? num : s_led_node_num;
    if (pst_static_param->mode == LS_LED_WHITE)
    {
        if (hsv_parm->white == 0)
        {
            APP_LOG(LOG_ERROR, "brightness = 0 \n");
            return;
        }
        rgbw[0] = rate * TRUE_BRIGHTNESS(hsv_parm->white);
    }
    else if (pst_static_param->mode == LS_LED_HSV)
    {
        if (hsv_parm->V == 0)
        {
            APP_LOG(LOG_ERROR, "brightness = 0 \n");
            return;
        }

        ls_led_conv_hsv2rgb(hsv_parm, rgb);
        rgb[0] = rate * TRUE_BRIGHTNESS(rgb[0]);
        rgb[1] = rate * TRUE_BRIGHTNESS(rgb[1]);
        rgb[2] = rate * TRUE_BRIGHTNESS(rgb[2]);
        memcpy(rgbw + 1, rgb, 3);
    }

    for (uint8_t i = 0; i < node_num; i++)
    {
        if (pst_static_param->mode == LS_LED_MULTI_SEG)
        {
            ls_led_conv_hsv2rgb(hsv_parm + i, rgb);
            rgb[0] = rate * TRUE_BRIGHTNESS(rgb[0]);
            rgb[1] = rate * TRUE_BRIGHTNESS(rgb[1]);
            rgb[2] = rate * TRUE_BRIGHTNESS(rgb[2]);
            memcpy(rgbw + 1, rgb, 3);
        }

        if (VHAL_OK != vhal_1_wire_tx_set_pixels(i, rgbw, LED_DATA_LEN))
        {
            APP_LOG(LOG_ERROR, "tx set error \n");
        }
    }

    if (VHAL_OK != vhal_1_wire_tx_refresh(0))
    {
        APP_LOG(LOG_ERROR, "tx refresh error \n");
    }

    s_change_flag = false;
}

/**
* @brief    空间上顺序切换
* @param[in]  *pst_switch_param     [参数]
* @return     uint32_t              [执行结果 APP_OK:执行成功，还在执行中 APP_FAIL:执行失败/执行结束]
*/
static int ls_led_switch_step(ls_dynamic_param_t *pst_switch_param)
{
    if (pst_switch_param == NULL || pst_switch_param->mode_head == NULL)
    {
        APP_LOG(LOG_ERROR, "Invaild parameters \n");
        return APP_FAIL;
    }

    static uint8_t cur_led_node = 0;
    static uint8_t rgbw[4] = {0};
    ls_hsv_t next_color;
    uint8_t rgb[3] = {0};
    memset(&next_color, 0, sizeof(ls_hsv_t));

    if (s_change_flag)
    {
        save_diverse_params(pst_switch_param);
        cur_led_node = s_led_node_num - 1;
        next_color = *(pst_switch_param->mode_head + (s_ls_changing_status.cur_node + 1) % pst_switch_param->node_num);
        ls_led_conv_hsv2rgb(&next_color, rgb);
        memcpy(rgbw + 1, rgb, 3);
        s_change_flag = false;
        ls_led_set_static_color(&s_turn_off);
    }
     // 改变LED节点灯效
    if (0 == s_ls_changing_status.remain_step)
    {
        cur_led_node = (cur_led_node + 1) % s_led_node_num;
        vhal_1_wire_tx_set_pixels(cur_led_node, rgbw, LED_DATA_LEN);
        if (VHAL_OK != vhal_1_wire_tx_refresh(0))
        {
            APP_LOG(LOG_ERROR, "tx refresh error \n");
            return APP_FAIL;
        }
        s_ls_changing_status.remain_step = pst_switch_param->step_num - 1;
        if (cur_led_node == (s_led_node_num - 1))
        {
            s_ls_changing_status.cur_node++;
            next_color = *(pst_switch_param->mode_head + (s_ls_changing_status.cur_node + 1) % pst_switch_param->node_num);
            ls_led_conv_hsv2rgb(&next_color, rgb);
            memcpy(rgbw + 1, rgb, 3);
        }

        if (s_ls_changing_status.cur_node == pst_switch_param->node_num)
        {
            // 一次灯效周期结束
           if (0 != pst_switch_param->times)
            {
                s_ls_changing_status.remain_times--;
                if (0 == s_ls_changing_status.remain_times)
                {
                    // 执行结束
                    s_mode = LS_LED_MODE_STATIC;
                    return APP_FAIL;
                }
            }
            s_ls_changing_status.cur_node = 0;
        }
    }
    else
    {
        s_ls_changing_status.remain_step--;
        return APP_OK;
    }

    return APP_OK;
}

/**
* @brief 更新灯效
* @param[in]  *pst_scene    [参数]
*/
void ls_led_set_scene(ls_scene_t *pst_scene)
{
    if (NULL == pst_scene)
    {
        APP_LOG(LOG_ERROR, "NULL pointer \n");
        return;
    }

    s_change_flag = true;
    s_mode = pst_scene->light_mode;
    s_led_scene = pst_scene;
}

/**
* @brief 更新灯珠数量
* @param[in]  num    [参数]
*/
void ls_led_set_led_num(uint8_t num)
{
    s_change_flag = true;
    s_led_node_num = num;
}

/**
* @brief 显示灯效
*/
void ls_led_display_handle(void)
{
    if (s_change_flag == false && s_mode != LS_LED_MODE_DYNAMIC)
    {
        return;
    }

    if (s_led_scene->mutex != NULL)
    {
        vesync_mutex_lock(s_led_scene->mutex);
    }

    switch (s_led_scene->light_mode)
    {
        case LS_LED_MODE_STATIC:
            ls_led_set_static_color(s_led_scene->param.static_param);
            break;
        case LS_LED_MODE_DYNAMIC:
            switch (s_led_scene->param.dynamic_param->mode)
            {
                case LS_LED_BREATHING:
                    ls_led_breathing(s_led_scene->param.dynamic_param);
                    break;
                case LS_LED_GRADIENT:
                    ls_led_gradient(s_led_scene->param.dynamic_param);
                    break;
                case LS_LED_SWITCH:
                    ls_led_switch(s_led_scene->param.dynamic_param);
                    break;
                case LS_LED_SWITCH_STEP:
                    ls_led_switch_step(s_led_scene->param.dynamic_param);
                    break;
                default:
                    ls_led_set_static_color(&s_turn_off);
                    break;
            }
            break;
        default:
            ls_led_set_static_color(&s_turn_off);
            APP_LOG(LOG_INFO, "LED turn off! \n");
            break;
    }

    if (s_led_scene->mutex != NULL)
    {
        vesync_mutex_unlock(s_led_scene->mutex);
    }
}

/**
* @brief  led 控制初始化
*/
void ls_led_init(void)
{

    one_wire_tx_cfg_t cfg =
    {
        .rmt_tx_gpio = LS_RMT_TX_IO,
        .clk_div = 1,
        .pixel_data_len = LED_DATA_LEN,
        .pixel_num = LED_NODE_MAX_NUM,
        .idle_level = RMT_IDLE_LEVEL_L,
        .T0H_NS = WS2814_T0H_NS,
        .T0L_NS = WS2814_T0L_NS,
        .T1H_NS = WS2814_T1H_NS,
        .T1L_NS = WS2814_T1L_NS,
    };

    int ret = vhal_1_wire_tx_init(&cfg);
    if (ret == VHAL_OK)
    {
        APP_LOG(LOG_INFO, "=======rmt init successfully========\n");
    }
    else
    {
        APP_LOG(LOG_ERROR, "=========rmt init failed============\n");
    }
}
