/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
* @file         scene.c
* @brief        场景处理接口
* @author       Joshua
* @date         2021-11-18
*/

#include <stdint.h>
#include <stdbool.h>
#include "vesync_common.h"
#include "device.h"
#include "scene.h"
#include "app_cfg.h"

#if CONFIG_VESYNC_APP_SCENE_WHITE_LIGHT
#include "white.h"
#endif
#if CONFIG_VESYNC_APP_SCENE_COLOR_LIGHT
#include "color.h"
#endif
#if CONFIG_VESYNC_APP_SCENE_SEGMENT_LIGHT
#include "segment.h"
#endif
#if CONFIG_VESYNC_APP_SCENE_OCEAN_LIGHT
#include "ocean.h"
#endif
#if CONFIG_VESYNC_APP_SCENE_FOREST_LIGHT
#include "forest.h"
#endif
#if CONFIG_VESYNC_APP_SCENE_RAINBOW_LIGHT
#include "rainbow.h"
#endif
#if CONFIG_VESYNC_APP_SCENE_STARRY_LIGHT
#include "starry.h"
#endif
#if CONFIG_VESYNC_APP_SCENE_SUNSET_LIGHT
#include "sunset.h"
#endif

/**
 * @brief  灯效场景注册
 */
static void light_scene_impl_init(void)
{
#if CONFIG_VESYNC_APP_SCENE_PRODUCTION_LIGHT
    prd_light_scene_impl_init();
#endif
#if CONFIG_VESYNC_APP_SCENE_NETCFG_LIGHT
    netcfg_light_scene_impl_init();
#endif
#if CONFIG_VESYNC_APP_SCENE_RESET_LIGHT
    reset_light_scene_impl_init();
#endif

#if CONFIG_VESYNC_APP_SCENE_OCEAN_LIGHT
    ocean_light_scene_impl_init();
#endif
#if CONFIG_VESYNC_APP_SCENE_FOREST_LIGHT
    forest_light_scene_impl_init();
#endif
#if CONFIG_VESYNC_APP_SCENE_SUNSET_LIGHT
    sunset_light_scene_impl_init();
#endif
#if CONFIG_VESYNC_APP_SCENE_STARRY_LIGHT
    starry_light_scene_impl_init();
#endif
#if CONFIG_VESYNC_APP_SCENE_RAINBOW_LIGHT
    rainbow_light_scene_impl_init();
#endif

#if CONFIG_VESYNC_APP_SCENE_MUSIC_LIGHT
    music_light_scene_impl_init();
#endif


#if CONFIG_VESYNC_APP_SCENE_WHITE_LIGHT
    if (light_white_is_seperated())
    {
        white_on_light_scene_impl_init();
        white_off_light_scene_impl_init();
    }
#endif
#if CONFIG_VESYNC_APP_SCENE_COLOR_LIGHT
    color_on_light_scene_impl_init();
    color_off_light_scene_impl_init();
#endif
#if CONFIG_VESYNC_APP_SCENE_SEGMENT_LIGHT
    segment_on_light_scene_impl_init();
    segment_off_light_scene_impl_init();
#endif

}

int app_scene_init(void)
{
    int ret = APP_FAIL;

    ret = scene_registry_init();
    if (ret != APP_OK)
    {
        return APP_FAIL;
    }

    light_scene_impl_init();

    return APP_OK;
}

int app_scene_deinit(void)
{
    return scene_registry_deinit();
}

int app_scene_light_apply(scene_t *thiz, void *param)
{
    VCOM_NULL_PARAM_CHK(thiz, return APP_FAIL);
    light_scene_t *ctx = (light_scene_t *)thiz->ctx;
    return (ctx && ctx->light_cb) ? ctx->light_cb(param) : APP_FAIL;
}

int app_scene_info_get_from_mode(uint8_t *scene_type, uint16_t *scene_id)
{
    VCOM_NULL_PARAM_CHK(scene_type, return APP_FAIL);
    VCOM_NULL_PARAM_CHK(scene_id, return APP_FAIL);

    dev_cfg_t *p_dev_cfg = app_device_cfg_get();
    VCOM_NULL_RET_CHK(p_dev_cfg, return APP_FAIL);

    switch (p_dev_cfg->flash->cfg.mode)
    {
        case LIGHT_MODE_WHITE:
            *scene_type = SCENE_ONOFF;
            *scene_id = (p_dev_cfg->flash->cfg.onoff == LIGHT_STATUS_ON) ? SCENE_WHITE_ON : SCENE_WHITE_OFF;
            break;
        case LIGHT_MODE_COLOR:
            *scene_type = SCENE_ONOFF;
            *scene_id = (p_dev_cfg->flash->cfg.onoff == LIGHT_STATUS_ON) ? SCENE_COLOR_ON : SCENE_COLOR_OFF;
            break;
        case LIGHT_MODE_MULTI:
            *scene_type = SCENE_SEGMENT;
            *scene_id = (p_dev_cfg->flash->cfg.onoff == LIGHT_STATUS_ON) ? SCENE_COLOR_ON : SCENE_COLOR_OFF;
            break;
        case LIGHT_MODE_MUSIC:
        case LIGHT_MODE_SCENE:
        default:
            *scene_type = (p_dev_cfg->flash->cfg.onoff == LIGHT_STATUS_ON) ? SCENE_LIGHT : SCENE_ONOFF;
            *scene_id = (p_dev_cfg->flash->cfg.onoff == LIGHT_STATUS_ON) ? p_dev_cfg->flash->cfg.scene_id : SCENE_COLOR_OFF;
            break;
    }

    return APP_OK;
}

