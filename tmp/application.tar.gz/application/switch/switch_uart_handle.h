/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        switch_uart_handle.h
 * @brief       switch串口数据处理头文件
 * @author      Charles.Mei
 * @date        2021-08-03
 */


#ifndef __SWITCH_UART_HANDLE_H__
#define __SWITCH_UART_HANDLE_H__

#ifdef __cplusplus
      extern "C" {
#endif


// 以下为串口协议附录B状态码，请后续提取到VeSync SDK
#define UART_PAYLOAD_STATUS_NO_ERR                  (0U)
#define UART_PAYLOAD_STATUS_INTERNAL_ERR            (1U)
#define UART_PAYLOAD_STATUS_OPCODE_FORMAT_ERR       (21U)
#define UART_PAYLOAD_STATUS_OPCODE_UNSUPPORT        (22U)
#define UART_PAYLOAD_STATUS_VERSION_ERR             (31U)
#define UART_PAYLOAD_STATUS_PAYLOAD_FORMAT_ERR      (51U)
#define UART_PAYLOAD_STATUS_PAYLOAD_DECRYPT_ERR     (52U)


/**
 * @brief  处理串口请求
 * @return     uint8_t                  [status，见串口协议附录B状态码表说明]
 */
uint8_t switch_uart_request_handle(OPCODE_E opcode, uint8_t* p_data, uint16_t data_len);

/**
 * @brief  处理串口ack
 * @return     uint8_t                  [status，见串口协议附录B状态码表说明]
 */
uint8_t switch_uart_ack_handle(OPCODE_E opcode, uint8_t* p_data, uint16_t data_len);


#ifdef __cplusplus
}
#endif

#endif


