/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file        vesync_wifi_led.c
* @brief       WiFi指示灯控制接口
* @author      Joshua
* @date        2021-05-08
*/

#include <string.h>
#include "vesync_common.h"
#include "vesync_log_internal.h"
#include "vesync_memory.h"
#include "vesync_os.h"
#include "vesync_wifi_led.h"
#include "vesync_wifi_led_internal.h"

static wifi_led_t *s_wifi_led = NULL;

/*-----------------------------------------------------------------------------*
*-----------------------------------内部函数API实现     -------------------------------*
*-----------------------------------------------------------------------------*/

/**
 * @brief 定义wifi led指针灯行为ID与配置变量表
 */
#define DECLEAR_LED_BEHAVIOR_CFG_TABLE() wifi_led_behavior_cfg_t behavior_cfg_tbl[] = { \
    {WIFI_LED_STARTUP,          s_wifi_led->led_info.led_startup}, \
    {WIFI_LED_NOT_CONFIG,       s_wifi_led->led_info.led_not_config}, \
    {WIFI_LED_CONFIG_TIMEOUT,   s_wifi_led->led_info.led_config_timeout}, \
    {WIFI_LED_CONFIGING,        s_wifi_led->led_info.led_config_net}, \
    {WIFI_LED_FFS_CONFIGING,    s_wifi_led->led_info.led_ffs_config_net}, \
    {WIFI_LED_CONNECTING,       s_wifi_led->led_info.led_connecting}, \
    {WIFI_LED_WIFI_DISC,        s_wifi_led->led_info.led_wifi_disconnect}, \
    {WIFI_LED_WIFI_TIMEOUT,     s_wifi_led->led_info.led_wifi_timeout}, \
    {WIFI_LED_SERVER_DISC,      s_wifi_led->led_info.led_server_disconnect}, \
    {WIFI_LED_SERVER_TIMEOUT,   s_wifi_led->led_info.led_server_timeout}, \
    {WIFI_LED_LOGIN_SUCCESS,    s_wifi_led->led_info.led_login}, \
    {WIFI_LED_RESET_DEVICE,     s_wifi_led->led_info.led_reset_device}, \
    {WIFI_LED_PRODUCTION_TEST,  s_wifi_led->led_info.led_production_test}}

/**
 * @brief WiFi单指示灯实时变化驱动
 * @param[in]  on                         [WiFi指示灯的实时亮灭状态]
 */
static void vesync_wifi_led_turn(WIFI_LED_IO_STATUS_E on)
{
    VCOM_NULL_PARAM_CHK(s_wifi_led, return);

    if (s_wifi_led->led_IO_status != on)    // 亮灭状态变化了才进行外部驱动的回调，减少频繁调用
    {
        s_wifi_led->led_IO_status = on;

        if (NULL == s_wifi_led->wifi_led_turn_callback)
        {
            SDK_LOG(LOG_ERROR, "wifi_led_turn_callback is NULL pointer!\n");
        }
        else
        {
            s_wifi_led->wifi_led_turn_callback(on);
        }
    }
}

/**
 * @brief WiFi指示灯闪烁定时器回调函数
 * @param[in]  arg                           [回调函数参数]
 */
static void vesync_wifi_led_timer_cb(void *arg)
{
    VCOM_NULL_PARAM_CHK(s_wifi_led, return);

    switch (s_wifi_led->led_status)
    {
        case WIFI_LED_OFF:
            vesync_wifi_led_turn(WIFI_LED_IO_DISABLE);
            break;
        case WIFI_LED_ON:
            vesync_wifi_led_turn(WIFI_LED_IO_LED_ON);
            break;
        case WIFI_LED_BLINK:
            if (s_wifi_led->blink_flag)
            {
                vesync_wifi_led_turn(WIFI_LED_IO_LED_ON);
                s_wifi_led->blink_flag = false;
            }
            else
            {
                vesync_wifi_led_turn(WIFI_LED_IO_LED_OFF);
                s_wifi_led->cur_off_times++;

                if (s_wifi_led->cur_off_times >= s_wifi_led->blink_off_times)
                {
                    s_wifi_led->cur_off_times = 0;
                    s_wifi_led->blink_flag = true;

                    if (s_wifi_led->blink_count != 0) //有限次数的闪烁
                    {
                        s_wifi_led->cur_blink_count++;//每亮灭各完成一次后才算闪烁一次
                        if (s_wifi_led->cur_blink_count >= s_wifi_led->blink_count)
                        {
                            s_wifi_led->led_status = WIFI_LED_OFF;
                            vesync_wifi_led_turn(WIFI_LED_IO_DISABLE);
                            s_wifi_led->cur_blink_count = 0;
                            vesync_timer_stop(s_wifi_led->led_blink_timer);
                        }
                    }
                }
            }
            break;
        case WIFI_LED_DOUBLE_BLINK:
        default:
            break;
    }
}

/**
 * @brief 初始化WiFi指示灯刷新定时器
 * @return  int         [成功：SDK_OK，失败：SDK_FAIL]
 */
static int vesync_wifi_led_timer_init(void)
{
    // 创建LED闪烁控制定时器，周期模式
    s_wifi_led->led_blink_timer = vesync_timer_new("wifi_led_timer",
                                                   vesync_wifi_led_timer_cb,
                                                   NULL,
                                                   1000,
                                                   true);
    if (s_wifi_led->led_blink_timer == NULL)
    {
        SDK_LOG(LOG_ERROR, "wifi_led_blink_timer create fail!");
        return SDK_FAIL;
    }

    return SDK_OK;
}


/**
 * @brief WiFi指示灯闪烁设置
 * @param[in]  led_cfg           [灯的闪烁配置]
 */
static void vesync_wifi_led_set(wifi_led_cfg_t led_cfg)
{
    VCOM_NULL_PARAM_CHK(s_wifi_led, return);
    if (s_wifi_led->led_blink_timer == NULL)
    {
        vesync_wifi_led_timer_init();
    }

    switch (led_cfg.status)
    {
        case WIFI_LED_ON:
        {
            vesync_timer_stop(s_wifi_led->led_blink_timer);
            s_wifi_led->led_status = WIFI_LED_ON;
            vesync_wifi_led_turn(WIFI_LED_IO_LED_ON);
            break;
        }
        case WIFI_LED_OFF:
        {
            vesync_timer_stop(s_wifi_led->led_blink_timer);
            s_wifi_led->led_status = WIFI_LED_OFF;
            vesync_wifi_led_turn(WIFI_LED_IO_DISABLE);
            break;
        }
        case WIFI_LED_BLINK:
        {
            vesync_timer_change_period(s_wifi_led->led_blink_timer, led_cfg.blink_ms);
            s_wifi_led->led_status = WIFI_LED_BLINK;
            s_wifi_led->blink_count = led_cfg.blink_times;
            s_wifi_led->blink_off_times = led_cfg.off_times;
            s_wifi_led->blink_flag = false;
            s_wifi_led->cur_off_times = 0;
            s_wifi_led->cur_blink_count = 0;
            vesync_wifi_led_turn(WIFI_LED_IO_LED_ON);
            break;
        }
        case WIFI_LED_DOUBLE_BLINK:
            // 暂未实现
            break;
        case WIFI_LED_BREATHING:
        {
            // 应用层实现
            vesync_timer_stop(s_wifi_led->led_blink_timer);
            s_wifi_led->led_status = WIFI_LED_BREATHING;
            vesync_wifi_led_turn(WIFI_LED_IO_BREATHING);
            break;
        }
        case WIFI_LED_CUSTOM_MODE:
        {
            vesync_timer_stop(s_wifi_led->led_blink_timer);
            s_wifi_led->led_status = WIFI_LED_CUSTOM_MODE;
            vesync_wifi_led_turn(WIFI_LED_IO_CUSTOM_MODE);
            break;
        }
        default:
        {
            SDK_LOG(LOG_ERROR, "led_status = %d, LED status undefined!\n", led_cfg.status);
            break;
        }
    }
}


/*-----------------------------------------------------------------------------*
*-----------------------------------外部函数API实现     -------------------------------*
*-----------------------------------------------------------------------------*/
/**
 * @brief wifi led初始化函数
 * @return  int              [成功：SDK_OK，失败：SDK_FAIL]
 */
int vesync_wifi_led_init(void)
{
    if (s_wifi_led == NULL)
    {
        s_wifi_led = (wifi_led_t *)vesync_malloc(sizeof(wifi_led_t));
        if (s_wifi_led == NULL)
        {
            SDK_LOG(LOG_ERROR, "WiFi LED init fail\n");
            return SDK_FAIL;
        }

        memset(s_wifi_led, 0, sizeof(wifi_led_t));
    }

    return SDK_OK;
}

/**
* @brief wifi led释放资源函数
*/
void vesync_wifi_led_deinit(void)
{
    VCOM_NULL_PARAM_CHK(s_wifi_led, return);
    vesync_free(s_wifi_led);
    s_wifi_led = NULL;
}

/**
 * @brief 重置WIFI指示灯闪烁模式
 */
void vesync_wifi_led_reset_behavior(void)
{
    VCOM_NULL_PARAM_CHK(s_wifi_led, return);
    s_wifi_led->led_behavior = WIFI_LED_INIT;
}

/**
 * @brief 获取WIFI指示灯闪烁模式
 * @return                      [wifi指示灯闪烁行为]
 */
WIFI_LED_BEHAVIOR_E vesync_wifi_led_get_behavior(void)
{
    VCOM_NULL_PARAM_CHK(s_wifi_led, return WIFI_LED_INIT);
    return s_wifi_led->led_behavior;
}

/**
 * @brief 设置MCU指示灯数据
 * @return  bool                [true 由MCU执行 ； false 主设备执行]
 */
bool vesync_wifi_led_set_mcu_data(void)
{
    VCOM_NULL_PARAM_CHK(s_wifi_led, return false);

    DECLEAR_LED_BEHAVIOR_CFG_TABLE();

    if (s_wifi_led->wifi_led_mcu_control_cb)
    {
        SDK_LOG(LOG_DEBUG, "LED behavior action by MCU!\n");
        for (int i = 0; i < SIZEOF_ARRAY(behavior_cfg_tbl); i++)
        {
            if (s_wifi_led->led_behavior == behavior_cfg_tbl[i].behavior)
            {
                s_wifi_led->wifi_led_mcu_control_cb(behavior_cfg_tbl[i].led_cfg);
                return true;
            }
        }
        SDK_LOG(LOG_ERROR, "LED behavior param undefined!\n");
        return true;
    }

    return false;
}


/**
 * @brief 设置WIFI单指示灯闪烁模式
 * @param[in]  led_behavior         [WiFi指示灯闪烁行为]
 */
void vesync_wifi_led_set_behavior(WIFI_LED_BEHAVIOR_E led_behavior)
{
    VCOM_NULL_PARAM_CHK(s_wifi_led, return);
    SDK_LOG(LOG_DEBUG, "led_behavior = %d, s_wifi_led->led_behavior = %d\n", led_behavior, s_wifi_led->led_behavior);

    if ((led_behavior != s_wifi_led->led_behavior) || (led_behavior == WIFI_LED_RESET_DEVICE))//欲设置的闪烁行为与当前闪烁行为不同才进行更新
    {
        DECLEAR_LED_BEHAVIOR_CFG_TABLE();

        s_wifi_led->led_behavior = led_behavior;

        for (int i = 0; i < SIZEOF_ARRAY(behavior_cfg_tbl); i++)
        {
            if (s_wifi_led->led_behavior == behavior_cfg_tbl[i].behavior)
            {
                // 有MCU的产品，灯效动作交给MCU处理，回调后直接返回
                if (s_wifi_led->wifi_led_mcu_control_cb)
                {
                    s_wifi_led->wifi_led_mcu_control_cb(behavior_cfg_tbl[i].led_cfg);
                }
                else // 灯效由Wi-Fi模块进行控制
                {
                    vesync_wifi_led_set(behavior_cfg_tbl[i].led_cfg);
                }
                return;
            }
        }
        SDK_LOG(LOG_ERROR, "LED behavior param undefined!\n");
    }
}


/**
 * @brief 注册WiFi LED指示灯状态变化回调函数
 * @param[in]  wifi_cb         [WiFi指示灯变化回调函数，每次指示灯进行亮灭变化时都会调用该函数]
 * @param[in]  mcu_cb          [WiFi指示灯变化回调函数，只有配置变更是才会发给MCU]
 */
void vesync_wifi_led_reg_ctrl_cb(wifi_led_turn_cb_t wifi_cb, wifi_led_mcu_control_cb_t mcu_cb)
{
    VCOM_NULL_PARAM_CHK(s_wifi_led, return);
    s_wifi_led->wifi_led_turn_callback = wifi_cb;
    s_wifi_led->wifi_led_mcu_control_cb = mcu_cb;
}


/**
 * @brief APP层向平台层注册WiFi LED单指示灯配置信息
 * @param[in]  led_info         [WiFi单指示灯配置信息]
 */
void vesync_wifi_led_info_set(wifi_led_info_t led_info)
{
    VCOM_NULL_PARAM_CHK(s_wifi_led, return);
    s_wifi_led->led_info = led_info;
}

