/**
*Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file    ledstrip_wifi_led.c
* @brief   Wi-Fi指示灯配置
* @author  Lind
*@date     2021-09-09
*/

#include <string.h>

#include "vhal_led.h"

#include "vesync_common.h"
#include "vesync_wifi_led.h"
#include "vesync_log.h"
#include "vesync_netcfg.h"
#include "vesync_report.h"

#include "ledstrip_wifi_led.h"
#include "ledstrip_led.h"
#include "ledstrip_report.h"

static ls_led_rgb_t s_ls_scene_mode_1 = {50, 0, 0, 0, 0};
static ls_led_rgb_t wifi_led_mode_start[2] = {{0, 0, 0, 0, 0}, {50, 0, 0, 0,0}};
static ls_led_rgb_t wifi_led_mode_breathing[2] = {{50, 0, 0, 0, 0}, {0, 0, 0, 0,0}};
static bool s_ls_netcfg_flag = true;   // 配网标志位

// 配网等待灯效，白光慢闪5次，而后常亮
static ls_led_diverse_param_t s_wifi_led_start =
{
    .mode = LS_SCENE_SWITCH,
    .node_num = 2,
    .first_node = 0,
    .step_num = 25,
    .times = 5,
    .mode_head = wifi_led_mode_start,
};

// 白色呼吸灯
static ls_led_diverse_param_t s_wifi_led_breathing =
{
    .mode = LS_SCENE_BREATHING,
    .node_num = 2,
    .first_node = 0,
    .step_num = 50,
    .times = 0,
    .mode_head = wifi_led_mode_breathing,
};

// 配网成功灯效 ，冷光50%常亮
static ls_led_diverse_param_t s_ls_scene_1 =
{
    .mode = LS_SCENE_SINGLE,
    .node_num = 1,
    .first_node = 0,
    .step_num = 70,
    .times = 0,
    .mode_head = &s_ls_scene_mode_1,
};


/**
* @brief wifi led控制回调
* @param[in]  status    [led状态]
*/
static void ledstrip_wifi_led_ctrl_cb(WIFI_LED_IO_STATUS_E status)
{
    switch (status)
    {
        case WIFI_LED_IO_LED_OFF:
            break;
        case WIFI_LED_IO_LED_ON:
            break;
        case WIFI_LED_IO_DISABLE:
            break;
        case WIFI_LED_IO_CUSTOM_MODE:
            // 开始配网灯效
            if (s_ls_netcfg_flag)
            {
                ls_led_set_led((void*)&s_wifi_led_start, LS_LED_ACT_SRC_WIFI);
            }
            break;
        case WIFI_LED_IO_BREATHING:
            ls_led_set_led((void*)&s_wifi_led_breathing, LS_LED_ACT_SRC_WIFI);
            break;
        default:
            break;
    }
}

/**
* @brief wifi 连接成功回调
*/
static void ledstrip_wifi_success_cb(void)
{
    if (s_ls_netcfg_flag)
    {
        ls_led_set_led((void*)&s_ls_scene_1, LS_LED_ACT_SRC_WIFI);
        ls_report_set_chg_rsn(STAT_CHG_RSN_CONFIG_NET_STR);
    }
    s_ls_netcfg_flag = false;
}

/**
* @brief    设置配网标志位
* @param[in]  flag          [true:未配网/等待配网；false:配网结束/已配网]
*/
void ls_wifi_set_netcfg_flag(bool flag)
{
    s_ls_netcfg_flag = flag;
}

/**
* @brief  灯效配置
* @return     int             [成功/失败]
*/
int ls_reg_wifi_led(void)
{
    wifi_led_info_t led_cfg;

    memset(&led_cfg, 0, sizeof(led_cfg));

    // 未配网，灯效配置
    led_cfg.led_not_config.status = WIFI_LED_CUSTOM_MODE;
    led_cfg.led_not_config.blink_ms = 500; // 500ms
    led_cfg.led_not_config.off_times = 1;
    led_cfg.led_not_config.blink_times = 5;

    // 配网中
    led_cfg.led_config_net.status = WIFI_LED_BREATHING;
    led_cfg.led_config_net.blink_ms = 5000; // 5s
    led_cfg.led_config_net.off_times = 1;
    led_cfg.led_config_net.blink_times = 1;

    // 注册所有情况的灯效规则
    vesync_wifi_led_info_set(led_cfg);

    // 注册闪灯实现函数
    vesync_wifi_led_reg_ctrl_cb(ledstrip_wifi_led_ctrl_cb, NULL);

    // 注册配网成功实现函数
    vesync_net_cfg_reg_success_cb(ledstrip_wifi_success_cb);

    return APP_OK;
}


