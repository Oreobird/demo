/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        outlet_device.h
 * @brief       outlet device头文件
 * @author      CharlesMei
 * @date        2021-06-25
 */


#ifndef __OUTLET_DEVICE_H__
#define __OUTLET_DEVICE_H__

#include "vesync_device.h"

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

/**
 * @brief 恢复出厂重启前其它事务处理函数
 */
void outlet_device_pre_reset_callback(void *args);

/**
 * @brief 清除开关应用层数据
 * @param[in]  rsn              [消息来源]
 * @param[in]  rst_type         [删除用户数据的类型]
 * @return
 */
void outlet_device_clear_all_data(const char* rsn, DEV_RESET_TYPE_E rst_type);

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* __OUTLET_DEVICE_H__ */

