/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        lightstring_bypass.h
 * @brief       lightstring bypass通信接口
 * @author      Lind
 * @date        2021-12-21
 */
#ifndef __LIGHTSTRING_BYPASS__
#define __LIGHTSTRING_BYPASS__

#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

#define TIMER_SEC_MAX           86399   // timing 最大倒计时时间23h 59min 59s
#define TIMER_SEC_MIN           1       // timing 最小倒计时时间1s

/**
* @brief 设置语音关闭标志位，
* @param[in]  flag          [true:语音导致灯带关闭;false:当前状态不是语音关闭]
*/
void ls_set_voice_off_flag(bool flag);

/**
* @brief 注册bypass回调函数
*/
void ls_bypass_reg_cb(void);
#ifdef __cplusplus
}
#endif

#endif

