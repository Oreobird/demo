/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        bulb_bypass.c
 * @brief       bulb bypass
 * @author      Dave
 * @date        2021-08-31
 */


#include <string.h>
#include <stdio.h>
#include <string.h>
#include "cJSON.h"

#include "vhal_flash.h"

#include "vesync_common.h"
#include "vesync_log.h"
#include "vesync_timing.h"
#include "vesync_memory.h"
#include "vesync_task.h"

#include "bulb.h"
#include "bulb_led.h"
#include "bulb_flash.h"
#include "bulb_status.h"
#include "bulb_timing.h"
#include "bulb_schedule.h"
#include "bulb_status.h"
#include "bulb_bypass.h"
#include "bulb_report.h"

// 以下定义见透传接口设计
//https://wiki.vesync.cn/pages/viewpage.action?pageId=259358915#id-%E5%BC%80%E6%94%BE%E5%B9%B3%E5%8F%B0-%E7%81%AF%E6%B3%A1&%E7%81%AF%E5%B8%A6-A19&8B1005-%E9%80%8F%E4%BC%A0%E8%8D%89%E7%A8%BF-3.5.4%E8%AE%BE%E7%BD%AE%E7%81%AF%E6%B3%A1%E7%8A%B6%E6%80%81V2

static bulb_status_t s_bulb_status;
static cJSON *json_bulb_status = NULL;
static bool s_bulb_could_zero_flag;

/**
 * @brief  获取状态改变标识
 * @param[in]    status          [状态改变标识]
 * @return       bulb_status_t   [状态改变结构体指针]
 */
bulb_status_t* bulb_get_report_status_change()
{
    return (&s_bulb_status);
}

void bulb_set_could_zero_flag(bool flag)
{
    s_bulb_could_zero_flag = flag;
}

/**
 * @brief 打包bulb状态
 */
static void bulb_bp_pack_status()
{
    json_bulb_status = cJSON_CreateObject();
    if (NULL == json_bulb_status)
    {
        APP_LOG(LOG_DEBUG,"BP_ERR_NOMEM \r\n");
        return;
    }
    cJSON_AddStringToObject(json_bulb_status, "enabled", bulb_get_config(BULB_CFG_ONOFF) ? "on" : "off");
    cJSON_AddStringToObject(json_bulb_status, "colorMode", bulb_get_config(BULB_CFG_COLOR_MODE) ? "hsv" : "white");
    cJSON_AddNumberToObject(json_bulb_status, "brightness", bulb_get_config(BULB_CFG_COLOR_BRIGHT));
    cJSON_AddNumberToObject(json_bulb_status, "colorTemp", bulb_get_config(BULB_CFG_COLOR_TEMP));
    cJSON_AddNumberToObject(json_bulb_status, "hue", bulb_get_config(BULB_CFG_COLOR_HUE));
    cJSON_AddNumberToObject(json_bulb_status, "saturation", bulb_get_config(BULB_CFG_COLOR_SATURATION));
    cJSON_AddNumberToObject(json_bulb_status, "value", bulb_get_config(BULB_CFG_COLOR_VALUE));
}

/**
 * @brief 解析bulb动作组
 * @param[in]       json_arr        [参数组]
 * @param[in]       action          [动作]
 * @return          int             [通用错误码]
 */
static int bulb_bp_parse_action(cJSON *json_arr, bulb_action_t *action)
{
    int arr_size = 0;
    int arr_idx = 0;
    cJSON* json_obj = NULL;
    cJSON* json_type = NULL;
    cJSON *json_act = NULL;
    cJSON *json_params = NULL;
    bool invalid_arr = false;

    memset(action, 0, sizeof(bulb_action_t));

    arr_size = cJSON_GetArraySize(json_arr);
    if (arr_size <= 0 || arr_size > 2)     //bulb tiemr最多2个参数组
    {
        return BP_ERR_PARA_ILLEGAL;
    }
    for (arr_idx = 0; arr_idx < arr_size; ++arr_idx)
    {
        json_obj = cJSON_GetArrayItem(json_arr, arr_idx);
        if (NULL == json_obj)
        {
            return BP_ERR_PARA_ILLEGAL;
        }
        json_type = cJSON_GetObjectItemCaseSensitive(json_obj, "type");
        json_act = cJSON_GetObjectItemCaseSensitive(json_obj, "act");
        if (cJSON_IsString(json_type) && cJSON_IsString(json_act))
        {
            if(0 == strcmp(json_type->valuestring, "switch"))
            {
                if (0 == strcmp(json_act->valuestring, "on"))
                {
                    action->onoff=true;
                }
                else if (0 == strcmp(json_act->valuestring, "off"))
                {
                    action->onoff = false;
                }
                else
                {
                    return BP_ERR_PARA_ILLEGAL;
                }
                invalid_arr = true;     // 必须要有type switch，否则非法
            }
            else if(0 == strcmp(json_type->valuestring, "color_mode"))
            {
                if(0 == strcmp(json_act->valuestring, "white"))
                {
                    action->mode=0;
                    json_params = cJSON_GetObjectItemCaseSensitive(json_obj, "params");
                    if (NULL == json_params)
                    {
                        return BP_ERR_PARA_ILLEGAL;
                    }
                    cJSON *json_bright = cJSON_GetObjectItemCaseSensitive(json_params, "brightness");
                    cJSON *json_temp = cJSON_GetObjectItemCaseSensitive(json_params, "colorTemp");
                    if (cJSON_IsNumber(json_bright) && cJSON_IsNumber(json_temp))
                    {
                        //白光模式亮度不可为0
                        if(PARAM_MIN >= json_bright->valueint || BRIGHT_MAX < json_bright->valueint || COLOR_TEMP_MAX < json_temp->valueint || PARAM_MIN > json_temp->valueint)
                        {
                            return BP_ERR_PARA_ILLEGAL;
                        }
                        else
                        {
                            action->bright=json_bright->valueint;
                            action->temp=json_temp->valueint;
                        }
                    }
                    else
                    {
                        return BP_ERR_PARA_ILLEGAL;
                    }
                }
                else if(0 == strcmp(json_act->valuestring, "hsv"))
                {
                    action->mode=1;
                    json_params = cJSON_GetObjectItemCaseSensitive(json_obj, "params");
                    if (NULL == json_params)
                    {
                        return BP_ERR_PARA_ILLEGAL;
                    }
                    cJSON *json_hue = cJSON_GetObjectItemCaseSensitive(json_params, "hue");
                    cJSON *json_saturation = cJSON_GetObjectItemCaseSensitive(json_params, "saturation");
                    cJSON *json_value = cJSON_GetObjectItemCaseSensitive(json_params, "value");
                    if (cJSON_IsNumber(json_hue) && cJSON_IsNumber(json_saturation) && cJSON_IsNumber(json_value))
                    {
                        //彩光模式亮度不可为0
                        if(PARAM_MIN >= json_value->valueint || BRIGHT_MAX < json_value->valueint || HSV_PARAM_MAX < json_hue->valueint ||
                              PARAM_MIN > json_hue->valueint || HSV_PARAM_MAX < json_saturation->valueint || PARAM_MIN > json_saturation->valueint)
                        {
                            return BP_ERR_PARA_ILLEGAL;
                        }
                        else
                        {
                            action->hue = json_hue->valueint;
                            action->saturation = json_saturation->valueint;
                            action->value = json_value->valueint;
                        }
                    }
                    else
                    {
                        return BP_ERR_PARA_ILLEGAL;
                    }
                }
                else
                {
                    return BP_ERR_PARA_ILLEGAL;
                }
            }
            else
            {
                return BP_ERR_PARA_ILLEGAL;
            }
        }
        else
        {
            return BP_ERR_PARA_ILLEGAL;
        }
    }
    if (invalid_arr)
    {
        return BP_ERR_NO_ERR;
    }
    return BP_ERR_PARA_ILLEGAL;
}

/**
 * @brief 打包bulb动作组
 * @param[in/out]   json_arr        [参数组]
 * @param[in]       action          [动作]
 * @return          int             [通用错误码]
 */

static int bulb_bp_pack_action(cJSON **json_arr, bulb_action_t *action)
{
    int err_code = BP_ERR_NO_ERR;
    cJSON *json_acts = cJSON_CreateArray();
    cJSON *json_act = NULL;
    cJSON *json_params = NULL;

    if (NULL == json_acts)
    {
        return BP_ERR_OUT_OF_MEMORY;
    }
    cJSON_AddItemToArray(json_acts, json_act = cJSON_CreateObject());
    if (NULL == json_act)
    {
        err_code = BP_ERR_OUT_OF_MEMORY;
        goto exit;
    }
    cJSON_AddStringToObject(json_act, "type", "switch");
    if (true == action->onoff)
    {
        cJSON_AddStringToObject(json_act, "act", "on");
    }
    else
    {
        cJSON_AddStringToObject(json_act, "act", "off");
    }
    cJSON_AddNumberToObject(json_act, "num", 0);
    json_act = NULL;
    if (0 != action->onoff)
    {
        cJSON_AddItemToArray(json_acts, json_act = cJSON_CreateObject());
        if (NULL == json_act)
        {
            err_code = BP_ERR_OUT_OF_MEMORY;
            goto exit;
        }
        cJSON_AddStringToObject(json_act, "type", "color_mode");
        cJSON_AddStringToObject(json_act, "act", action->mode ? "hsv":"white");
        cJSON_AddNumberToObject(json_act, "num", 0);
        cJSON_AddItemToObject(json_act, "params", json_params = cJSON_CreateObject());
        if (NULL == json_params)
        {
            err_code = BP_ERR_OUT_OF_MEMORY;
            goto exit;
        }
        if(true == action->mode)
        {
            cJSON_AddNumberToObject(json_params, "hue", action->hue);
            cJSON_AddNumberToObject(json_params, "saturation", action->saturation);
            cJSON_AddNumberToObject(json_params, "value", action->value);
        }
        else if(false == action->mode)
        {
            cJSON_AddNumberToObject(json_params, "brightness", action->bright);
            cJSON_AddNumberToObject(json_params, "colorTemp", action->temp);
        }
        else
        {
            APP_LOG(LOG_ERROR,"color mode error\n");
        }
        json_act = NULL;
        json_params = NULL;
    }
exit:
    if (BP_ERR_NO_ERR == err_code)
    {
        *json_arr = json_acts;
    }
    else
    {
        cJSON_Delete(json_acts);
    }
    return err_code;
}

/**
* @brief force =0 时设置灯泡状态
* @note  新增bypass method
* @param[in]        p_msg_ctx       [bypass上下文]
* @param[in]        json            [传入json]
* @return           BYPASS_ERR_E
*/
static BYPASS_ERR_E bulb_set_status_soft(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    int ret = BP_OK;
    cJSON* json_data = NULL;
    if (0 == strcmp("hsv",bulb_get_config(BULB_CFG_COLOR_MODE) ? "hsv" : "white"))
    {
        json_data = cJSON_GetObjectItemCaseSensitive(json, "colorTemp");
        if (true == cJSON_IsNumber(json_data))
        {
            ret = BP_ERR_ARG;
            vesync_bypass_reply_noqos(BP_ERR_NOT_EXEC_IN_CUR_MODE, p_msg_ctx->p_trace_msg, NULL);
            goto exit;
        }
        json_data = cJSON_GetObjectItemCaseSensitive(json, "brightness");
        if (true == cJSON_IsNumber(json_data))
        {
            if (BRIGHT_MAX < json_data->valueint || PARAM_MIN > json_data->valueint)
            {
                ret = BP_ERR_ARG;
                vesync_bypass_reply_noqos(BP_ERR_PARA_ILLEGAL, p_msg_ctx->p_trace_msg, NULL);
                goto exit;
            }
            if (0 == json_data->valueint)
            {
                s_bulb_status.changeflag = BULB_ONOFF_CHANGE_FLAG;
                bulb_update_config(BULB_CFG_ONOFF, 0);
                goto exit;
            }
            s_bulb_status.changeflag = (s_bulb_status.changeflag > 0) ? s_bulb_status.changeflag : BULB_HSV_CHANGE_FLAG;
            bulb_update_config(BULB_CFG_COLOR_VALUE, json_data->valueint);
        }
        json_data = cJSON_GetObjectItemCaseSensitive(json, "hue");
        if (true == cJSON_IsNumber(json_data))
        {
            if (HSV_PARAM_MAX < json_data->valueint || PARAM_MIN > json_data->valueint)
            {
                ret = BP_ERR_ARG;
                goto exit;
            }
            s_bulb_status.changeflag = (s_bulb_status.changeflag > 0) ? s_bulb_status.changeflag : BULB_HSV_CHANGE_FLAG;
            bulb_update_config(BULB_CFG_COLOR_HUE, json_data->valueint);
        }
        json_data = cJSON_GetObjectItemCaseSensitive(json, "saturation");
        if (true == cJSON_IsNumber(json_data))
        {
            if (HSV_PARAM_MAX < json_data->valueint || PARAM_MIN > json_data->valueint)
            {
                ret = BP_ERR_ARG;
                goto exit;
            }
            bulb_update_config(BULB_CFG_COLOR_SATURATION, json_data->valueint);
        }
        goto exit;
    }
    else
    {
        json_data = cJSON_GetObjectItemCaseSensitive(json, "hue");
        if (true == cJSON_IsNumber(json_data))
        {
            ret = BP_ERR_ARG;
            vesync_bypass_reply_noqos(BP_ERR_NOT_EXEC_IN_CUR_MODE, p_msg_ctx->p_trace_msg, NULL);
            goto exit;
        }
        json_data = cJSON_GetObjectItemCaseSensitive(json, "brightness");
        if (true == cJSON_IsNumber(json_data))
        {
            if (BRIGHT_MAX < json_data->valueint || PARAM_MIN > json_data->valueint)
            {
                ret = BP_ERR_ARG;
                goto exit;
            }

            if (0 == json_data->valueint)
            {
                s_bulb_status.changeflag = BULB_ONOFF_CHANGE_FLAG;
                bulb_update_config(BULB_CFG_ONOFF, 0);
                goto exit;
            }
            s_bulb_status.changeflag = (s_bulb_status.changeflag > 0) ? s_bulb_status.changeflag :BULB_BRIGHT_CHANGE_FLAG;
            bulb_update_config(BULB_CFG_COLOR_BRIGHT, json_data->valueint);
        }
        json_data = cJSON_GetObjectItemCaseSensitive(json, "colorTemp");
        if (true == cJSON_IsNumber(json_data))
        {
            if (COLOR_TEMP_MAX < json_data->valueint || PARAM_MIN > json_data->valueint)
            {
                ret = BP_ERR_ARG;
                goto exit;
            }

            s_bulb_status.changeflag =  (s_bulb_status.changeflag > 0) ? s_bulb_status.changeflag :BULB_TEMP_CHANGE_FLAG;
            bulb_update_config(BULB_CFG_COLOR_TEMP, json_data->valueint);
        }
        goto exit;
    }
exit:
    if (BP_OK == ret)
    {
        bulb_bp_pack_status();
        vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, json_bulb_status);
        bulb_gradient_new_tgt_set();
        bulb_led_sem_signal();
    }
    return ret;
}

/**
* @brief force =1 时设置灯泡状态
* @note  新增bypass method
* @param[in]        p_msg_ctx       [bypass上下文]
* @param[in]        json            [传入json]
* @return           BYPASS_ERR_E
*/
static BYPASS_ERR_E bulb_set_status_hard(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    int ret = BP_OK;
    cJSON* json_data = NULL;
    bypass_bulb_base_t pBulb_data;
    if (0 == bulb_get_config(BULB_CFG_COLOR_MODE))
    {
        strncpy(pBulb_data.colorMdoe, "white", sizeof(pBulb_data.colorMdoe)-1);
        pBulb_data.brightness = bulb_get_config(BULB_CFG_COLOR_BRIGHT);
        pBulb_data.colorTemp = bulb_get_config(BULB_CFG_COLOR_TEMP);
        pBulb_data.hue = bulb_get_config(BULB_CFG_COLOR_HUE);
        pBulb_data.saturation = bulb_get_config(BULB_CFG_COLOR_SATURATION);
    }
    else
    {
        strncpy(pBulb_data.colorMdoe, "hsv", sizeof(pBulb_data.colorMdoe)-1);
        pBulb_data.brightness = bulb_get_config(BULB_CFG_COLOR_VALUE);
        pBulb_data.colorTemp = bulb_get_config(BULB_CFG_COLOR_TEMP);
        pBulb_data.hue = bulb_get_config(BULB_CFG_COLOR_HUE);
        pBulb_data.saturation = bulb_get_config(BULB_CFG_COLOR_SATURATION);
    }
    json_data = cJSON_GetObjectItemCaseSensitive(json, "colorMode");
    if (cJSON_IsString(json_data))
    {
        if (0 != strcmp(json_data->valuestring,pBulb_data.colorMdoe))
        {
            strncpy(pBulb_data.colorMdoe, json_data->valuestring, sizeof(pBulb_data.colorMdoe)-1);
            s_bulb_status.changeflag = (s_bulb_status.changeflag > 0) ? s_bulb_status.changeflag : BULB_MODE_CHANGE_FLAG;
        }

        if (0 == strcmp(pBulb_data.colorMdoe,"white"))
        {
            json_data = cJSON_GetObjectItemCaseSensitive(json, "colorTemp");
            if (true == cJSON_IsNumber(json_data))
            {
                if (PARAM_MIN <= json_data->valueint && COLOR_TEMP_MAX >= json_data->valueint)
                {
                    if (pBulb_data.colorTemp != json_data->valueint)
                    {
                        pBulb_data.colorTemp = json_data->valueint;
                        s_bulb_status.changeflag = (s_bulb_status.changeflag > 0) ? s_bulb_status.changeflag : BULB_TEMP_CHANGE_FLAG;
                    }
                }
                else
                {
                    ret = BP_ERR_ARG;
                    goto exit;
                }
            }
            json_data = cJSON_GetObjectItemCaseSensitive(json, "brightness");
            if (true == cJSON_IsNumber(json_data))
            {
                if (PARAM_MIN < json_data->valueint && BRIGHT_MAX >= json_data->valueint)
                {
                    pBulb_data.brightness = json_data->valueint;
                    if (pBulb_data.brightness != bulb_get_config(BULB_CFG_COLOR_BRIGHT))
                    {
                        s_bulb_status.changeflag = (s_bulb_status.changeflag > 0) ? s_bulb_status.changeflag : BULB_BRIGHT_CHANGE_FLAG;
                    }
                }
                else
                {
                    ret = BP_ERR_ARG;
                    goto exit;
                }
            }
            goto exit;
        }
        else if (0 == strcmp(pBulb_data.colorMdoe,"hsv"))
        {
            json_data = cJSON_GetObjectItemCaseSensitive(json, "hue");
            if (true == cJSON_IsNumber(json_data))
            {
                if (PARAM_MIN <= json_data->valueint && HSV_PARAM_MAX >= json_data->valueint)
                {
                    if (pBulb_data.hue != json_data->valueint)
                    {
                        pBulb_data.hue = json_data->valueint;
                        s_bulb_status.changeflag = (s_bulb_status.changeflag > 0) ? s_bulb_status.changeflag : BULB_HSV_CHANGE_FLAG;
                    }
                }
                else
                {
                    ret = BP_ERR_ARG;
                    goto exit;
                }
            }
            json_data = cJSON_GetObjectItemCaseSensitive(json, "saturation");
            if (true == cJSON_IsNumber(json_data))
            {
                if (PARAM_MIN <= json_data->valueint && HSV_PARAM_MAX >= json_data->valueint)
                {
                    if (pBulb_data.saturation != json_data->valueint)
                    {
                        pBulb_data.saturation = json_data->valueint;
                        s_bulb_status.changeflag = (s_bulb_status.changeflag > 0) ? s_bulb_status.changeflag : BULB_HSV_CHANGE_FLAG;
                    }
                }
                else
                {
                    ret = BP_ERR_ARG;
                    goto exit;
                }
            }
            json_data = cJSON_GetObjectItemCaseSensitive(json, "brightness");
            if (true == cJSON_IsNumber(json_data))
            {
                if (PARAM_MIN < json_data->valueint && BRIGHT_MAX >= json_data->valueint)
                {
                    pBulb_data.brightness = json_data->valueint;
                    if (pBulb_data.brightness != bulb_get_config(BULB_CFG_COLOR_VALUE))
                    {
                        s_bulb_status.changeflag = (s_bulb_status.changeflag > 0) ? s_bulb_status.changeflag : BULB_HSV_CHANGE_FLAG;
                    }
                }
                else
                {
                    ret = BP_ERR_ARG;
                    goto exit;
                }
            }
            goto exit;
        }
        else
        {
            ret = BP_ERR_ARG;
            goto exit;
        }
    }
    else
    {
         json_data= cJSON_GetObjectItemCaseSensitive(json, "colorTemp");
         if (true == cJSON_IsNumber(json_data))
         {
            if (PARAM_MIN <= json_data->valueint && COLOR_TEMP_MAX >= json_data->valueint)
            {
                pBulb_data.colorTemp = json_data->valueint;
                json_data= cJSON_GetObjectItemCaseSensitive(json, "hue");
                if (true == cJSON_IsNumber(json_data))
                {
                    ret = BP_ERR_ARG;
                    goto exit;
                }
                json_data= cJSON_GetObjectItemCaseSensitive(json, "saturation");
                if (true == cJSON_IsNumber(json_data))
                {
                    ret = BP_ERR_ARG;
                    goto exit;
                }
                if (1 == strcmp(pBulb_data.colorMdoe,"hsv"))
                {
                    strncpy(pBulb_data.colorMdoe, "white", sizeof(pBulb_data.colorMdoe)-1);
                    s_bulb_status.changeflag = (s_bulb_status.changeflag > 0) ? s_bulb_status.changeflag : BULB_MODE_CHANGE_FLAG;
                }
                else
                {
                    s_bulb_status.changeflag = (s_bulb_status.changeflag > 0) ? s_bulb_status.changeflag : BULB_TEMP_CHANGE_FLAG;
                }
            }
            else
            {
                ret = BP_ERR_ARG;
                goto exit;
            }
         }
         else
         {
            json_data = cJSON_GetObjectItemCaseSensitive(json, "hue");
            if (true == cJSON_IsNumber(json_data))
            {
                if (HSV_PARAM_MAX < json_data->valueint || PARAM_MIN > json_data->valueint)
                {
                    ret = BP_ERR_ARG;
                    goto exit;
                }
                if (0 == bulb_get_config(BULB_CFG_COLOR_MODE))
                {
                    bulb_update_config(BULB_CFG_COLOR_MODE, 1);
                    s_bulb_status.changeflag = (s_bulb_status.changeflag > 0) ? s_bulb_status.changeflag : BULB_MODE_CHANGE_FLAG;
                }
                s_bulb_status.changeflag = (s_bulb_status.changeflag > 0) ? s_bulb_status.changeflag : BULB_HSV_CHANGE_FLAG;
                pBulb_data.hue = json_data->valueint;
            }
            json_data = cJSON_GetObjectItemCaseSensitive(json, "saturation");
            if (true == cJSON_IsNumber(json_data))
            {
                if (HSV_PARAM_MAX < json_data->valueint || PARAM_MIN > json_data->valueint)
                {
                    ret = BP_ERR_ARG;
                    goto exit;
                }
                pBulb_data.saturation = json_data->valueint;
            }
         }

         json_data= cJSON_GetObjectItemCaseSensitive(json, "brightness");
         if (true == cJSON_IsNumber(json_data))
         {
            if (BRIGHT_MAX < json_data->valueint || PARAM_MIN > json_data->valueint)
            {
                ret = BP_ERR_ARG;
                goto exit;
            }
            if (0 == json_data->valueint)
            {
                s_bulb_status.changeflag = BULB_ONOFF_CHANGE_FLAG;
                bulb_update_config(BULB_CFG_ONOFF, 0);
                goto exit;
            }
            pBulb_data.brightness = json_data->valueint;
            if (0 == strcmp(pBulb_data.colorMdoe,"white"))
            {
                s_bulb_status.changeflag = (s_bulb_status.changeflag > 0) ? s_bulb_status.changeflag : BULB_BRIGHT_CHANGE_FLAG;
            }
            else
            {
                 s_bulb_status.changeflag = (s_bulb_status.changeflag > 0) ? s_bulb_status.changeflag : BULB_HSV_CHANGE_FLAG;
            }
         }
         goto exit;
    }
exit:
    if (ret == BP_OK)
    {
        if (0 == strcmp(pBulb_data.colorMdoe,"white"))
        {
            bulb_update_config(BULB_CFG_COLOR_MODE, 0);
            bulb_update_config(BULB_CFG_COLOR_BRIGHT, pBulb_data.brightness);
            bulb_update_config(BULB_CFG_COLOR_TEMP, pBulb_data.colorTemp);
            bulb_update_config(BULB_CFG_COLOR_HUE, pBulb_data.hue);
            bulb_update_config(BULB_CFG_COLOR_SATURATION, pBulb_data.saturation);
        }
        else
        {
            bulb_update_config(BULB_CFG_COLOR_MODE, 1);
            bulb_update_config(BULB_CFG_COLOR_VALUE, pBulb_data.brightness);
            bulb_update_config(BULB_CFG_COLOR_TEMP, pBulb_data.colorTemp);
            bulb_update_config(BULB_CFG_COLOR_HUE, pBulb_data.hue);
            bulb_update_config(BULB_CFG_COLOR_SATURATION, pBulb_data.saturation);
        }
        bulb_bp_pack_status();
        vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, json_bulb_status);
        bulb_gradient_new_tgt_set();
        bulb_led_sem_signal();
    }
    return ret;
}

/**
* @brief force =2 时设置灯泡状态
* @note  新增bypass method
* @param[in]        p_msg_ctx       [bypass上下文]
* @param[in]        json            [传入json]
* @return           BYPASS_ERR_E
*/
static BYPASS_ERR_E bulb_set_status_spec(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    int ret = BP_OK;
    cJSON* json_data = NULL;
    json_data = cJSON_GetObjectItemCaseSensitive(json, "brightness");
    if (cJSON_IsNumber(json_data))
    {
        if (100 == json_data->valueint)
        {
            if(0 == bulb_get_config(BULB_CFG_ONOFF))
            {
                s_bulb_status.changeflag = BULB_ONOFF_CHANGE_FLAG;
            }
            bulb_update_config(BULB_CFG_ONOFF, 1);
            if( true == s_bulb_could_zero_flag)
            {
                if(0 == bulb_get_config(BULB_CFG_COLOR_MODE))
                {
                    bulb_update_config(BULB_CFG_COLOR_BRIGHT, 100);
                }
                else
                {
                    bulb_update_config(BULB_CFG_COLOR_VALUE, 100);
                }
            }
        }
        if (0 == json_data->valueint)
        {
            if(1 == bulb_get_config(BULB_CFG_ONOFF))
            {
                s_bulb_status.changeflag = BULB_ONOFF_CHANGE_FLAG;
            }
            bulb_update_config(BULB_CFG_ONOFF, 0);
            s_bulb_could_zero_flag = true;
        }
        if (0 != json_data->valueint && 100 != json_data->valueint)
        {
            ret = BP_ERR_ARG;
            goto exit;
        }
        bulb_bp_pack_status();
        vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, json_bulb_status);
    }
    else
    {
        ret = BP_ERR_ARG;
        goto exit;
    }
    bulb_led_sem_signal();
exit:
    return ret;
}

/**
* @brief 获取设备状态
* @note  新增bypass method
* @param[in]        p_msg_ctx       [bypass上下文]
* @param[in]        json            [传入json]
* @return           BYPASS_ERR_E
*/
static BYPASS_ERR_E bulb_bypass_method_get_status_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    BYPASS_ERR_E ret = BP_OK;
    if (NULL != p_msg_ctx)
    {
        bulb_bp_pack_status();
    }
    else
    {
        return BP_ERROR;
    }

    //bypass正常消息应答
    vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, json_bulb_status);
    return ret;
}

/**
* @brief 设置设备状态
* @note  新增bypass method
* @param[in]        p_msg_ctx       [bypass上下文]
* @param[in]        json            [传入json]
* @return           BYPASS_ERR_E
*/
static BYPASS_ERR_E bulb_bypass_method_set_status_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    BYPASS_ERR_E ret = BP_OK;
    cJSON* json_data = NULL;
    int force = 0;
    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);
    s_bulb_status.changeflag = 0;
    strncpy(s_bulb_status.chg_rsn, p_msg_ctx->p_trace_msg->src_type, sizeof(s_bulb_status.chg_rsn) - 1);
    json_data = cJSON_GetObjectItemCaseSensitive(json, "force");
    if (true == cJSON_IsNumber(json_data))
    {
        force = json_data->valueint;
    }
    if(0 == bulb_get_config(BULB_CFG_ONOFF) && 2 != force)
    {
        bulb_update_config(BULB_CFG_ONOFF, 1);
        s_bulb_status.changeflag = BULB_ONOFF_CHANGE_FLAG;
    }
    switch (force)
    {
        case 0 :
            ret = bulb_set_status_soft(p_msg_ctx, json);
            break;
        case 1 :
            ret = bulb_set_status_hard(p_msg_ctx, json);
            break;
        case 2 :
            ret = bulb_set_status_spec(p_msg_ctx, json);
            break;
        default:
            APP_LOG(LOG_ERROR, "force arg worng");
            ret = BP_ERR_ARG;
            break;
    }
    return ret;
}

/**
* @brief 调节灯泡亮度百分比
* @note  新增bypass method
* @param[in]        p_msg_ctx       [bypass上下文]
* @param[in]        json            [传入json]
* @return           BYPASS_ERR_E
*/

static BYPASS_ERR_E bulb_bypass_method_adjust_percent_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    BYPASS_ERR_E ret = BP_OK;
    cJSON* json_data = NULL;
    cJSON* json_percent = NULL;
    json_percent = cJSON_CreateObject();
    if (NULL == json_percent)
    {
        APP_LOG(LOG_DEBUG,"BP_ERR_NOMEM \r\n");
        return BP_ERR_NOMEM;
    }
    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);
    s_bulb_status.changeflag = 0;
    strncpy(s_bulb_status.chg_rsn,p_msg_ctx->p_trace_msg->src_type, sizeof(s_bulb_status.chg_rsn) - 1);
    bypass_adjustpercent_t *pBulb_data = (bypass_adjustpercent_t *)vesync_malloc(sizeof(bypass_adjustpercent_t));
    if (NULL == pBulb_data)
    {
        return BP_ERR_NOMEM;
    }
    memset(pBulb_data, 0, sizeof(bypass_adjustpercent_t));
    json_data = cJSON_GetObjectItemCaseSensitive(json, "type");
    if (cJSON_IsString(json_data))
    {
        memcpy(pBulb_data->type, json_data->valuestring, sizeof(pBulb_data->type) - 1);
        json_data = cJSON_GetObjectItemCaseSensitive(json, "step");
        if (cJSON_IsNumber(json_data))
        {
             pBulb_data->step = json_data->valueint;
        }

        else
        {
            ret = BP_ERR_ARG;
            goto exit;
        }
        //增加亮度时，若设备关闭以25亮度按上次模式开启
        if ((pBulb_data->step > 0) && (bulb_get_config(BULB_CFG_ONOFF) == 0) && 0 == strcmp("brightness",pBulb_data->type))
        {
           bulb_update_config(BULB_CFG_ONOFF, 1);
           if (0 == bulb_get_config(BULB_CFG_COLOR_MODE))
           {
                bulb_update_config(BULB_CFG_COLOR_BRIGHT, 25);
           }
           if (1 == bulb_get_config(BULB_CFG_COLOR_MODE))
           {
                bulb_update_config(BULB_CFG_COLOR_VALUE, 25);
           }
           cJSON_AddNumberToObject(json_percent, "percent", 25);
           s_bulb_status.changeflag = BULB_ONOFF_CHANGE_FLAG;
           bulb_open();
           vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, json_percent);
           goto exit;
        }
        if ((bulb_get_config(BULB_CFG_ONOFF) == 0) && 0 == strcmp("colorTemp",pBulb_data->type))
        {
            bulb_update_config(BULB_CFG_ONOFF, 1);
            bulb_update_config(BULB_CFG_COLOR_MODE, 0);
            int i = bulb_get_config(BULB_CFG_COLOR_TEMP);
            i = i + pBulb_data->step;
            if (100 < i)
            {
                bulb_update_config(BULB_CFG_COLOR_TEMP, 100);
            }
            else if (0 >= i)
            {
                bulb_update_config(BULB_CFG_COLOR_TEMP, 0);
            }
            else
            {
                bulb_update_config(BULB_CFG_COLOR_TEMP, i);
            }
            cJSON_AddNumberToObject(json_percent, "percent", bulb_get_config(BULB_CFG_COLOR_TEMP));
            s_bulb_status.changeflag = BULB_ONOFF_CHANGE_FLAG;
            bulb_open();
            vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, json_percent);
            goto exit;
        }
        if (bulb_get_config(BULB_CFG_ONOFF) == 0)
        {
            ret = BP_OK;
            cJSON_AddNumberToObject(json_percent, "percent", 0);
            vesync_bypass_reply_noqos(ret, p_msg_ctx->p_trace_msg, json_percent);
            goto exit;
        }
        if (0 == strcmp("brightness",pBulb_data->type))
        {
            if (0 == strcmp("hsv",bulb_get_config(BULB_CFG_COLOR_MODE) ? "hsv" : "white"))
            {
                int i = bulb_get_config(BULB_CFG_COLOR_VALUE);
                i = i + pBulb_data->step;
                if (100 < i )
                {
                    bulb_update_config(BULB_CFG_COLOR_VALUE, 100);
                    s_bulb_status.changeflag = BULB_HSV_CHANGE_FLAG;
                    bulb_open();
                    cJSON_AddNumberToObject(json_percent, "percent", bulb_get_config(BULB_CFG_COLOR_VALUE));
                    vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, json_percent);
                    goto exit;
                }
                else if (0 >= i)
                {
                    bulb_update_config(BULB_CFG_ONOFF, 0);
                    s_bulb_status.changeflag = BULB_ONOFF_CHANGE_FLAG;
                    bulb_open();
                    cJSON_AddNumberToObject(json_percent, "percent", 0);
                    vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, json_percent);
                    goto exit;
                }
                else
                {
                    bulb_update_config(BULB_CFG_COLOR_VALUE, i);
                    bulb_open();
                    s_bulb_status.changeflag = BULB_HSV_CHANGE_FLAG;
                    cJSON_AddNumberToObject(json_percent, "percent", bulb_get_config(BULB_CFG_COLOR_VALUE));
                    vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, json_percent);
                    goto exit;
                }
            }
            else
            {
                int i = bulb_get_config(BULB_CFG_COLOR_BRIGHT);
                i = i + pBulb_data->step;
                if (100 < i)
                {
                    bulb_update_config(BULB_CFG_COLOR_BRIGHT, 100);
                    s_bulb_status.changeflag = BULB_BRIGHT_CHANGE_FLAG;
                    bulb_open();
                    cJSON_AddNumberToObject(json_percent, "percent", bulb_get_config(BULB_CFG_COLOR_BRIGHT));
                    vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, json_percent);
                    goto exit;
                }
                else if (0 >= i)
                {
                    bulb_update_config(BULB_CFG_ONOFF, 0);
                    s_bulb_status.changeflag = BULB_ONOFF_CHANGE_FLAG;
                    bulb_open();
                    cJSON_AddNumberToObject(json_percent, "percent", 0);
                    vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, json_percent);
                    goto exit;
                }
                else
                {
                    bulb_update_config(BULB_CFG_COLOR_BRIGHT, i);
                    s_bulb_status.changeflag = BULB_BRIGHT_CHANGE_FLAG;
                    cJSON_AddNumberToObject(json_percent, "percent", bulb_get_config(BULB_CFG_COLOR_BRIGHT));
                    vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, json_percent);
                    bulb_open();
                    goto exit;
                }
            }
        }
        if (0 == strcmp("colorTemp",pBulb_data->type))
        {
            if (0 == strcmp("hsv",bulb_get_config(BULB_CFG_COLOR_MODE) ? "hsv" : "white"))
            {
                ret = BP_ERR_ARG;
                vesync_bypass_reply_noqos(BP_ERR_NOT_EXEC_IN_CUR_MODE, p_msg_ctx->p_trace_msg, NULL);
                goto exit;
            }
            else
            {
                int i = bulb_get_config(BULB_CFG_COLOR_TEMP);
                i = i + pBulb_data->step;
                s_bulb_status.changeflag = BULB_TEMP_CHANGE_FLAG;
                if (100 < i)
                {
                    bulb_update_config(BULB_CFG_COLOR_TEMP, 100);
                    bulb_open();
                    cJSON_AddNumberToObject(json_percent, "percent", bulb_get_config(BULB_CFG_COLOR_TEMP));
                    vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, json_percent);
                    goto exit;
                }
                else if (0 >= i)
                {
                    bulb_update_config(BULB_CFG_COLOR_TEMP, 0);
                    bulb_open();
                    cJSON_AddNumberToObject(json_percent, "percent", bulb_get_config(BULB_CFG_COLOR_TEMP));
                    vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, json_percent);
                    goto exit;
                }
                else
                {
                    bulb_update_config(BULB_CFG_COLOR_TEMP, i);
                    bulb_open();
                    cJSON_AddNumberToObject(json_percent, "percent", bulb_get_config(BULB_CFG_COLOR_TEMP));
                    vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, json_percent);
                    goto exit;
                }
            }
        }
        else
        {
            ret = BP_ERR_ARG;
            goto exit;
        }
    }
    else
    {
        ret = BP_ERR_ARG;
        goto exit;
    }
exit:
    bulb_report_status_change(&s_bulb_status);
    vesync_free(pBulb_data);
    return ret;
}

/**
* @brief 新增timer
* @note  新增bypass method
* @param[in]        p_msg_ctx       [bypass上下文]
* @param[in]        json            [传入json]
* @return           BYPASS_ERR_E
*/
static BYPASS_ERR_E bulb_bypass_method_add_timer_v2_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    BYPASS_ERR_E ret = BP_OK;
    uint32_t total_sec = 0;
    uint16_t timer_id = 1;
    void* action = NULL;
    cJSON* json_data = NULL;
    cJSON* json_timer = NULL;

    if (NULL == p_msg_ctx || NULL == p_msg_ctx->p_trace_msg || NULL == json)
    {
        return BP_ERROR;
    }

    APP_LOG(LOG_DEBUG, "-------addTimerV2 handle--------\n");
    json_data = cJSON_GetObjectItemCaseSensitive(json, "total");
    if (cJSON_IsNumber(json_data))
    {
        total_sec = json_data->valueint;
        //timer设置的最大时长不超过24h
        if (86400 <= total_sec || 1 > total_sec)
        {
            ret = BP_ERR_ARG;
            goto exit;
        }
        APP_LOG(LOG_INFO, "total_sec %d\r\n",total_sec);
    }
    else
    {
        ret = BP_ERR_ARG;
        goto exit;
    }
    json_data = cJSON_GetObjectItemCaseSensitive(json, "startAct");
    if (cJSON_IsArray(json_data))
    {
        action = vesync_malloc(sizeof(bulb_action_t));
        if (NULL == action)
        {
            vesync_bypass_reply_pkg_err_msg(BP_ERR_OUT_OF_MEMORY, p_msg_ctx->p_trace_msg, NULL);
            goto exit;
        }
        int err_code = bulb_bp_parse_action(json_data, action);
        APP_LOG(LOG_INFO,"err_code %d\r\n",err_code);
        if(BP_ERR_NO_ERR != err_code)
        {
            vesync_bypass_reply_pkg_err_msg(err_code, p_msg_ctx->p_trace_msg, NULL);
            goto exit;
        }
    }
    else
    {
           ret = BP_ERR_ARG;
           goto exit;
    }
    if (APP_OK == bulb_timing_add(action, total_sec, &timer_id) && 0!= timer_id)
    {
        json_timer = cJSON_CreateObject();
        if (NULL != json_timer)
        {
            cJSON_AddNumberToObject(json_timer, "id", timer_id);
            APP_LOG(LOG_DEBUG,"add timer %d\n", timer_id);
            vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, json_timer);
        }
        else
        {
            vesync_bypass_reply_noqos(BP_ERR_CMD_EXECUTE_FAIL, p_msg_ctx->p_trace_msg, json_timer);
        }
    }
    else
    {
        vesync_bypass_reply_pkg_err_msg(BP_ERR_CMD_EXECUTE_FAIL, p_msg_ctx->p_trace_msg, NULL);
        goto exit;
    }

exit:
    return ret;
}

/**
* @brief 获取timer
* @note  新增bypass method
* @param[in]        p_msg_ctx       [bypass上下文]
* @param[in]        json            [传入json]
* @return           BYPASS_ERR_E
*/
static BYPASS_ERR_E bulb_bypass_method_get_timer_v2_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    BYPASS_ERR_E ret = BP_OK;
    uint16_t timer_id = 0;
    timing_data_t tm;
    const void* timing = NULL;
    cJSON *json_data = NULL;
    cJSON *json_timers = NULL;
    cJSON *json_timer = NULL;
    cJSON *json_arr = NULL;

    if (NULL == p_msg_ctx || NULL == p_msg_ctx->p_trace_msg)
    {
        return BP_ERROR;
    }
    UNUSED(json);

    json_data = cJSON_CreateObject();
    if (NULL == json_data)
    {
        return BP_ERR_NOMEM;
    }
    cJSON_AddItemToObject(json_data, "timers", json_timers =  cJSON_CreateArray());
    if (APP_OK == bulb_timing_get_act( &timing) && NULL != timing)
    {
            timer_id = ((bulb_timing_t*)timing)->id;
    }
    else
    {
        vesync_bypass_reply_pkg_err_msg(BP_ERR_CMD_EXECUTE_FAIL, p_msg_ctx->p_trace_msg, NULL);
        ret = BP_OK;
        goto exit;
    }
    if (0 != timer_id && SDK_OK == vesync_timing_get(timer_id, &tm))
    {
        cJSON_AddItemToArray(json_timers, json_timer = cJSON_CreateObject());
        if (NULL == json_timer)
        {
            ret = BP_ERR_NOMEM;
            goto exit;
        }
        cJSON_AddNumberToObject(json_timer, "id", tm.timing_id);
        cJSON_AddNumberToObject(json_timer, "total", tm.total_second);
        cJSON_AddNumberToObject(json_timer, "remain", tm.remain_second);
        if (APP_OK == bulb_timing_get_act(&timing) && NULL != timing)
        {

            int err_code = BP_ERR_CMD_EXECUTE_FAIL;
            err_code = bulb_bp_pack_action(&json_arr, &((bulb_timing_t*)timing)->action);
            if (BP_ERR_NO_ERR == err_code && NULL != json_arr)
            {
                cJSON_AddItemToObject(json_timer, "startAct", json_arr);
            }
            else
            {
                vesync_bypass_reply_pkg_err_msg(err_code, p_msg_ctx->p_trace_msg, NULL);
                ret = BP_OK;
                goto exit;
            }
        }
        else
        {
            vesync_bypass_reply_pkg_err_msg(BP_ERR_CMD_EXECUTE_FAIL, p_msg_ctx->p_trace_msg, NULL);
            return BP_OK;
        }
    }

    vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, json_data);
    return BP_OK;

exit:
    cJSON_Delete(json_data);
    return ret;
}

/**
* @brief 删除timer
* @note  新增bypass method
* @param[in]        p_msg_ctx       [bypass上下文]
* @param[in]        json            [传入json]
* @return           BYPASS_ERR_E
*/
static BYPASS_ERR_E bulb_bypass_method_del_timer_v2_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    if (NULL == p_msg_ctx || NULL == p_msg_ctx->p_trace_msg|| NULL == json)
    {
        return BP_ERROR;
    }

    cJSON *json_data = cJSON_GetObjectItemCaseSensitive(json, "id");
    if (cJSON_IsNumber(json_data))
    {
        if (APP_OK == bulb_timing_remove(json_data->valueint))
        {
            cJSON *json_ret = cJSON_CreateObject();
            if (NULL != json_ret)
            {
                cJSON_AddNumberToObject(json_ret, "id", json_data->valueint);
            }
            vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, json_ret);
        }
        else
        {
            vesync_bypass_reply_pkg_err_msg(BP_ERR_TIMER_NOT_FOUND, p_msg_ctx->p_trace_msg, "Timer remove fail");
        }
    }
    else
    {
        return BP_ERR_ARG;
    }

    return BP_OK;
}

/**
* @brief 设置开关
* @note  新增bypass method
* @param[in]        p_msg_ctx       [bypass上下文]
* @param[in]        p_data            [传入data]
*/
static void bulb_bp_set_switch(bypass_msg_ctx_t *p_msg_ctx, void *p_data)
{
    int err_code = BP_ERR_NO_ERR;
    const char* err_msg = NULL;
    s_bulb_status.changeflag=BULB_ONOFF_CHANGE_FLAG;
    strncpy(s_bulb_status.chg_rsn, p_msg_ctx->p_trace_msg->src_type, sizeof(s_bulb_status.chg_rsn) - 1);
    if (NULL == p_data)
    {
        err_code = BP_ERR_PARA_ILLEGAL;
        goto exit;
    }
    if (1 == ((bypass_switch_data_t*)p_data)->enable)
    {
        if (0 == bulb_get_config(BULB_CFG_ONOFF))
        {
            bulb_update_config(BULB_CFG_ONOFF, 1);
            bulb_open();
        }
        vesync_bypass_reply_noqos(err_code, p_msg_ctx->p_trace_msg, NULL);
    }
    else if (0 == ((bypass_switch_data_t*)p_data)->enable)
    {
        if (1 == bulb_get_config(BULB_CFG_ONOFF))
        {
            bulb_update_config(BULB_CFG_ONOFF, 0);
            bulb_open();
        }
        vesync_bypass_reply_noqos(err_code, p_msg_ctx->p_trace_msg, NULL);
    }
    else
    {
        APP_LOG(LOG_DEBUG,"switch param error\n");
    }
    bulb_report_status_change(&s_bulb_status);
    return;
exit:
    vesync_bypass_reply_pkg_err_msg(err_code, p_msg_ctx->p_trace_msg, err_msg);
}

/**
* @brief 翻转开关
* @note  新增bypass method
* @param[in]        p_msg_ctx       [bypass上下文]
* @param[in]        p_data            [传入data]
*/
static void bulb_bp_toggle_switch(bypass_msg_ctx_t *p_msg_ctx, void *p_data)
{
    // 开关翻转
    bulb_update_config(BULB_CFG_ONOFF, bulb_get_config(BULB_CFG_ONOFF) ? 0:1);
    s_bulb_status.changeflag=BULB_ONOFF_CHANGE_FLAG;
    strncpy(s_bulb_status.chg_rsn, p_msg_ctx->p_trace_msg->src_type, sizeof(s_bulb_status.chg_rsn) - 1);
    if(NULL == p_data)
    {
        goto exit;
    }
    bulb_open();
    vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, NULL);
    bulb_report_status_change(&s_bulb_status);
    return;

exit:
    vesync_bypass_reply_pkg_err_msg(BP_ERR_PARA_ILLEGAL, p_msg_ctx->p_trace_msg, "id is invaild");
}

/**
* @brief 重置老化
* @note  新增bypass method
* @param[in]        p_msg_ctx       [bypass上下文]
* @param[in]        json            [传入json]
* @return           BYPASS_ERR_E
*/
static BYPASS_ERR_E bulb_bypass_method_reset_aging_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);
    bulb_update_config(BULB_CFG_AGING_TEST_TIME, 0);
    bulb_update_config(BULB_CFG_AGING_TEST, 0);
    bulb_resave_config();
    vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, NULL);
    return BP_ERR_NO_ERR;
}

/**
 * @brief bypass 添加Schedule
 * @param[in]       p_msg_ctx       [msg context]
 * @param[in]       p_data          [回调函数传入数据]
 */

static void bulb_bp_add_schedule(bypass_msg_ctx_t *p_msg_ctx, void *p_data)
{
    APP_LOG(LOG_INFO ,"add schedule start\r\n");
    int err_code = BP_ERR_NO_ERR;
    const char *err_msg = NULL;
    bypass_schedule_base_t *p_bp_sch = (bypass_schedule_base_t *)p_data;
    vesync_schedule_t sch_cfg;
    void *action = NULL;
    uint32_t sch_id = 0;
    cJSON *json_sch_ret = NULL;

    if(NULL == p_msg_ctx || NULL == p_msg_ctx->p_trace_msg || NULL == p_data)
    {
        err_code = BP_ERR_PARA_ILLEGAL;
        goto exit;
    }

    // Enabled 是必选项
    // Repeat Config 是必选项
    // Type 是必选项
    if (NULL == p_bp_sch->enabled ||
        NULL == p_bp_sch->repeat_config ||
        NULL == p_bp_sch->type ||
        NULL == p_bp_sch->json_action)
    {
        err_code = BP_ERR_PARA_ILLEGAL;
        err_msg = BP_ERR_PARAM_CONV(p_bp_sch, BP_ERR_PARAM_VAL_INVALID);
        goto exit;
    }
    sch_cfg.enabled = (bool)*p_bp_sch->enabled;
    sch_cfg.repeat_config = (uint8_t)*p_bp_sch->repeat_config;

    switch (*p_bp_sch->type)
    {
        case BYPASS_SCHEDULE_JSON_TYPE_TMG_EVT:
            sch_cfg.type = SCHE_TMG_EVT;
            //
            if (NULL == p_bp_sch->clock_sec)
            {
                err_code = BP_ERR_PARA_ILLEGAL;
                err_msg = BP_ERR_PARAM_CONV(clock_sec, BP_ERR_PARAM_VAL_INVALID);
                goto exit;
            }
            sch_cfg.event_config.timing.clock_sec = (uint32_t)*p_bp_sch->clock_sec;
            break;
        case BYPASS_SCHEDULE_JSON_TYPE_SUN_EVT:
            sch_cfg.type = SCHE_SUN_EVT;
            //
            if (NULL == p_bp_sch->is_sunrise)
            {
                err_code = BP_ERR_PARA_ILLEGAL;
                err_msg = BP_ERR_PARAM_CONV(is_sunrise, BP_ERR_PARAM_VAL_INVALID);
                goto exit;
            }
            if (NULL == p_bp_sch->offset_sec)
            {
                err_code = BP_ERR_PARA_ILLEGAL;
                err_msg = BP_ERR_PARAM_CONV(offset_sec, BP_ERR_PARAM_VAL_INVALID);
                goto exit;
            }
            //日出和日落时schedule时长60min
            if (SUN_EVT_TIME_MAX < (int32_t)*p_bp_sch->offset_sec || SUN_EVT_TIME_MIN > (int32_t)*p_bp_sch->offset_sec)
            {
                err_code = BP_ERR_PARA_ILLEGAL;
                goto exit;
            }
            sch_cfg.event_config.timing.clock_sec = 0;
            sch_cfg.event_config.sun.is_sunrise = (bool)*p_bp_sch->is_sunrise;
            sch_cfg.event_config.sun.offset_sec = (int32_t)*p_bp_sch->offset_sec;
            break;
        default:
            err_code = BP_ERR_PARA_ILLEGAL;
            err_msg = BP_ERR_PARAM_CONV(p_bp_sch, BP_ERR_PARAM_VAL_INVALID);
            goto exit;
    }
    action = vesync_malloc(sizeof(bulb_action_t));
    if (NULL == action)
    {
        err_code = BP_ERR_OUT_OF_MEMORY;
        goto exit;
    }
    err_code = bulb_bp_parse_action(p_bp_sch->json_action, action);
    if (BP_ERR_NO_ERR != err_code)
    {
        goto exit;
    }
    err_code = bulb_schedule_add( &sch_cfg, action, &sch_id);
    if (BP_ERR_NO_ERR != err_code)
    {
        goto exit;
    }
    if (BP_ERR_NO_ERR == err_code)
    {
        // 添加成功，生成回应
        json_sch_ret = cJSON_CreateObject();
        if (NULL != json_sch_ret)
        {
            cJSON_AddNumberToObject(json_sch_ret, "id", sch_id);
        }
    }
exit:
    VCOM_SAFE_FREE(action);
    if (BP_ERR_NO_ERR == err_code)
    {
        vesync_bypass_reply_noqos(err_code, p_msg_ctx->p_trace_msg, json_sch_ret);
    }
    else
    {
        vesync_bypass_reply_pkg_err_msg(err_code, p_msg_ctx->p_trace_msg, err_msg);
    }
}

/**
 * @brief bypass 更新Schedule
 * @param[in]       p_msg_ctx       [msg context]
 * @param[in]       p_data          [回调函数传入数据]
 */

static void bulb_bp_upd_schedule(bypass_msg_ctx_t *p_msg_ctx, void *p_data)
{
    APP_LOG(LOG_INFO ,"update schedule start\r\n");
    int err_code = BP_ERR_NO_ERR;
    const char *err_msg = NULL;
    bypass_schedule_base_t *p_bp_sch = (bypass_schedule_base_t *)p_data;
    vesync_schedule_t sch_cfg;
    void *action = NULL;
    uint32_t sch_id = 0;
    cJSON *json_sch_ret = NULL;
    if(NULL == p_msg_ctx || NULL == p_msg_ctx->p_trace_msg || NULL == p_data)
    {
        err_code = BP_ERR_PARA_ILLEGAL;
        goto exit;
    }
    sch_id = p_bp_sch->id;
    vesync_buf_t app_cfg_buf = vesync_buf_new();
    int ret = SCHE_OK;
    ret = vesync_schedule_get_by_id(BULB_SCHE_INS_ID, sch_id, &sch_cfg, &app_cfg_buf);
    if (NULL == p_bp_sch->json_action)
    {
        action = NULL;
    }
    else
    {
        action = vesync_malloc(sizeof(bulb_action_t));
        if (NULL == action)
        {
            err_code = BP_ERR_OUT_OF_MEMORY;
            goto exit;
        }
        err_code = bulb_bp_parse_action(p_bp_sch->json_action, action);
        if (BP_ERR_NO_ERR != err_code)
        {
            goto exit;
        }
    }
    if (BP_ERR_NO_ERR != err_code)
    {
        goto exit;
    }
    vesync_buf_clr(&app_cfg_buf);
    if (ret != SCHE_OK)
    {
        if (ret != SCHE_INV_ID_ERR)
        {
            err_code = BP_ERR_CMD_EXECUTE_FAIL;
            goto exit;
        }

        err_code = BP_ERR_SCHEDULE_NOT_FOUND;
        goto exit;
    }

    // Enabled 是可选项
    sch_cfg.enabled = (NULL != p_bp_sch->enabled) ? (bool)*p_bp_sch->enabled : sch_cfg.enabled;
    // Repeat Config 是可选项
    sch_cfg.repeat_config = (NULL != p_bp_sch->repeat_config) ? (uint8_t)*p_bp_sch->repeat_config : sch_cfg.repeat_config;

    // Type 是可选项
    if (NULL != p_bp_sch->type)
    {
        switch (*p_bp_sch->type)
        {
            case BYPASS_SCHEDULE_JSON_TYPE_TMG_EVT:
                sch_cfg.type = SCHE_TMG_EVT;
                // Clock Second 是可选字段
                sch_cfg.event_config.timing.clock_sec = (NULL != p_bp_sch->clock_sec) ? (uint32_t)*p_bp_sch->clock_sec : sch_cfg.event_config.timing.clock_sec;
                break;
            case BYPASS_SCHEDULE_JSON_TYPE_SUN_EVT:
                sch_cfg.type = SCHE_SUN_EVT;
                // Is Sunrise 是可选字段
                sch_cfg.event_config.sun.is_sunrise = (NULL != p_bp_sch->is_sunrise) ? (bool)*p_bp_sch->is_sunrise : sch_cfg.event_config.sun.is_sunrise;
                // Offset 是可选字段
                if (NULL != p_bp_sch->offset_sec)
                {
                    // 日出和日落时schedule时长60min
                    if (SUN_EVT_TIME_MAX < (int32_t)*p_bp_sch->offset_sec || SUN_EVT_TIME_MIN > (int32_t)*p_bp_sch->offset_sec)
                    {
                        err_code = BP_ERR_PARA_ILLEGAL;
                        goto exit;
                    }
                    sch_cfg.event_config.sun.offset_sec =  (int32_t)*p_bp_sch->offset_sec;
                }
                break;
            default:
                err_code = BP_ERR_PARA_ILLEGAL;
                goto exit;
        }
    }

    err_code = bulb_schedule_upd( &sch_cfg, action, &sch_id);

    if (BP_ERR_NO_ERR == err_code)
    {
        // 添加成功，生成回应
        json_sch_ret = cJSON_CreateObject();
        if (NULL != json_sch_ret)
        {
            cJSON_AddNumberToObject(json_sch_ret, "id", sch_id);
        }
    }
exit:
    VCOM_SAFE_FREE(action);
    if (BP_ERR_NO_ERR == err_code)
    {
        vesync_bypass_reply_noqos(err_code, p_msg_ctx->p_trace_msg, json_sch_ret);
    }
    else
    {
        vesync_bypass_reply_pkg_err_msg(err_code, p_msg_ctx->p_trace_msg, err_msg);
    }
}

/**
 * @brief bypass 删除Schedule
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  p_data                   [回调函数传入数据]
 */
static void bulb_bp_del_schedule(bypass_msg_ctx_t *p_msg_ctx, void *p_data)
{
    APP_LOG(LOG_INFO ,"del schedule start\r\n");
    int err_code = BP_ERR_NO_ERR;
    const char *err_msg = NULL;
    uint32_t sch_id = 0;
    cJSON *json_sch_ret = NULL;

    if(NULL == p_msg_ctx || NULL == p_msg_ctx->p_trace_msg || NULL == p_data)
    {
        err_code = BP_ERR_PARA_ILLEGAL;
        goto exit;
    }
    sch_id = *((uint32_t *)p_data);
    err_code = bulb_schedule_del(sch_id);
    if (BP_ERR_NO_ERR == err_code)
    {
        // 添加成功，生成回应
        json_sch_ret = cJSON_CreateObject();
        if (NULL != json_sch_ret)
        {
            cJSON_AddNumberToObject(json_sch_ret, "id", sch_id);
        }
    }
exit:
    if (BP_ERR_NO_ERR == err_code)
    {
        vesync_bypass_reply_noqos(err_code, p_msg_ctx->p_trace_msg, json_sch_ret);
    }
    else
    {
        vesync_bypass_reply_pkg_err_msg(err_code, p_msg_ctx->p_trace_msg, err_msg);
    }
}

/**
 * @brief 生成Schedule配置项的JSON
 * @param[in]       json_data       [JSON]
 * @param[in]       sch_cfg         [Schedule配置]
 * @return          int             [Bypass定义的错误]
 */
static int bulb_bp_pack_sch_cfg_json(cJSON **json_data, vesync_schedule_t *sch_cfg)
{
    int err_code = BP_ERR_NO_ERR;
    cJSON *sub_obj = NULL;
    uint8_t type = sch_cfg->type;

    *json_data = cJSON_CreateObject();
    if (NULL == *json_data)
    {
        return BP_ERR_OUT_OF_MEMORY;
    }

    cJSON_AddNumberToObject(*json_data, "id", sch_cfg->id);
    cJSON_AddBoolToObject(*json_data, "enabled", sch_cfg->enabled);
    cJSON_AddNumberToObject(*json_data, "type", type);
    if (BYPASS_SCHEDULE_JSON_TYPE_TMG_EVT == type)
    {
        sub_obj = cJSON_AddObjectToObject(*json_data, "tmgEvt");
        if (NULL == sub_obj)
        {
            err_code = BP_ERR_OUT_OF_MEMORY;
            goto exit;
        }
        cJSON_AddNumberToObject(sub_obj, "clkSec", sch_cfg->event_config.timing.clock_sec);
    }
    else if (BYPASS_SCHEDULE_JSON_TYPE_SUN_EVT == type)
    {
        sub_obj = cJSON_AddObjectToObject(*json_data, "sunEvt");
        if (NULL == sub_obj)
        {
            err_code = BP_ERR_OUT_OF_MEMORY;
            goto exit;
        }
        cJSON_AddBoolToObject(sub_obj, "isRise", sch_cfg->event_config.sun.is_sunrise);
        cJSON_AddNumberToObject(sub_obj, "ofsSec", sch_cfg->event_config.sun.offset_sec);
    }

    cJSON_AddNumberToObject(*json_data, "repeat", sch_cfg->repeat_config);

exit:
    if (BP_ERR_NO_ERR != err_code)
    {
        cJSON_Delete(*json_data);
    }
    return err_code;
}


/**
 * @brief bypass 获取Schedule
 * @param[in]       p_msg_ctx       [msg context]
 * @param[in]       p_data          [回调函数传入数据]
 */
static void bulb_bp_get_schedule(bypass_msg_ctx_t *p_msg_ctx, void *p_data)
{
    APP_LOG(LOG_INFO ,"get schedule start\r\n");
    int err_code = BP_ERR_NO_ERR;
    const char *err_msg = NULL;
    vesync_schedule_t *sche_cfg = NULL;
    void *action = NULL;
    uint32_t index = 0;
    uint32_t cur_num = 0;
    uint32_t total_num = 0;
    cJSON *json_sch_ret = NULL;
    cJSON *json_array = NULL;
    cJSON *json_sche = NULL;
    cJSON *json_acts = NULL;

    if(NULL == p_msg_ctx || NULL == p_msg_ctx->p_trace_msg || NULL == p_data)
    {
        err_code = BP_ERR_PARA_ILLEGAL;
        goto exit;
    }

    index = *((uint32_t *)p_data);
    sche_cfg = vesync_malloc(BULB_SCHEDULE_GET_MAX_NUM * sizeof(vesync_schedule_t));
    if (NULL == sche_cfg)
    {
        err_code = BP_ERR_OUT_OF_MEMORY;
        goto exit;
    }
        action = (bulb_action_t*)vesync_malloc(BULB_SCHEDULE_GET_MAX_NUM * sizeof(bulb_action_t));

    if (NULL == action)
    {
        err_code = BP_ERR_OUT_OF_MEMORY;
        goto exit;
    }
    err_code = bulb_schedule_get_mult(index, sche_cfg, action, &cur_num, &total_num);

    if (BP_ERR_NO_ERR == err_code)
    {
        // 查询成功，生成回应
        json_sch_ret = cJSON_CreateObject();
        if (NULL == json_sch_ret)
        {
            err_code = BP_ERR_OUT_OF_MEMORY;
            goto exit;
        }
        cJSON_AddNumberToObject(json_sch_ret, "total", total_num);
        json_array = cJSON_AddArrayToObject(json_sch_ret, "schedules");
        if (NULL == json_array)
        {
            err_code = BP_ERR_OUT_OF_MEMORY;
            goto exit;
        }
        for (int i = 0; i < cur_num; ++i)
        {
            err_code = bulb_bp_pack_sch_cfg_json(&json_sche, &sche_cfg[i]);
            if (BP_ERR_NO_ERR != err_code || NULL == json_sche)
            {
                goto exit;
            }
            err_code = bulb_bp_pack_action(&json_acts, (bulb_action_t*)action + i);
            if (BP_ERR_NO_ERR != err_code || NULL == json_acts)
            {
                goto exit;
            }
            cJSON_AddItemToObject(json_sche, "startAct", json_acts);
            cJSON_AddItemToArray(json_array, json_sche);
            }
    }
    else if (BP_ERR_SCHEDULE_NOT_FOUND == err_code)
    {
        err_code = BP_ERR_NO_ERR;

        // 生成空回应
        json_sch_ret = cJSON_CreateObject();
        if (NULL != json_sch_ret)
        {
            cJSON_AddNumberToObject(json_sch_ret, "total", total_num);
            cJSON_AddArrayToObject(json_sch_ret, "schedules");
        }
    }
    else
    {
        goto exit;
    }

    VCOM_SAFE_FREE(sche_cfg);
    VCOM_SAFE_FREE(action);
    vesync_bypass_reply_noqos(err_code, p_msg_ctx->p_trace_msg, json_sch_ret);
    return;
exit:
    VCOM_SAFE_FREE(sche_cfg);
    VCOM_SAFE_FREE(action);
    cJSON_Delete(json_sch_ret);
    vesync_bypass_reply_pkg_err_msg(err_code, p_msg_ctx->p_trace_msg, err_msg);
}

//bulb应用自定义bypass_method及其执行函数
static bypass_user_data_t bulb_method_tbl[] = {
    {"getLightStatusV2", bulb_bypass_method_get_status_handle},
    {"setLightStatusV2", bulb_bypass_method_set_status_handle},
    {"adjustPercent", bulb_bypass_method_adjust_percent_handle},
    {"resetAging", bulb_bypass_method_reset_aging_handle},
    // timer
    {"addTimerV2", bulb_bypass_method_add_timer_v2_handle},
    {"getTimerV2", bulb_bypass_method_get_timer_v2_handle},
    {"delTimerV2", bulb_bypass_method_del_timer_v2_handle}
};


/**
 * @brief 注册bypass回调函数
 */
void bulb_bypass_reg_cb()
{

    //注册平台公共自bypass_method的回调
    vesync_bypass_reg_method_cb(BYPASS_METHOD_ID_SET_SWITCH, bulb_bp_set_switch);
    vesync_bypass_reg_method_cb(BYPASS_METHOD_ID_TOGGLE_SWITCH, bulb_bp_toggle_switch);

    // Schedule
    vesync_bypass_reg_method_cb(BYPASS_METHOD_ID_ADD_SCHEDULE_V3, bulb_bp_add_schedule);
    vesync_bypass_reg_method_cb(BYPASS_METHOD_ID_UPD_SCHEDULE_V3, bulb_bp_upd_schedule);
    vesync_bypass_reg_method_cb(BYPASS_METHOD_ID_DEL_SCHEDULE_V3, bulb_bp_del_schedule);
    vesync_bypass_reg_method_cb(BYPASS_METHOD_ID_GET_SCHEDULES_V3, bulb_bp_get_schedule);

    //注册bulb应用自定义bypass_method
    for (int i = 0; i < SIZEOF_ARRAY(bulb_method_tbl); i++)
    {
        vesync_bypass_add_user_item(&bulb_method_tbl[i]);
    }

}
