/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_lan_trans_prot.c
 * @brief       设备与APP局域网通讯协议处理
 * @author      Dongri.Su
 * @date        2020-01-14
 */
#if (CONFIG_TARGET_LINUX)
#include <arpa/inet.h>
#else
#include "lwip/netif.h"
#include "lwip/tcpip.h"
#endif
#include "vesync_common.h"
#include "vesync_log_internal.h"
#include "vesync_memory.h"

#include "vesync_lan_trans_prot.h"


static uint16_t s_seq_id = 0;           // 序列号，从0开始自增


/**
 * @brief  局域网通信协议解析
 * @param[in]  p_frame              [原始数据]
 * @param[in/out]  p_data_len       [输入时，为帧长度(包括头部)；输出时，为数据长度(不包含头部)]
 * @return     int                  [解析的结果，成功/失败]
 */
int vesync_lan_trans_prot_parse(uint8_t *p_frame, uint32_t *p_data_len)
{
    int ret = SDK_FAIL;

    // 参数检测
    if (NULL == p_frame)
    {
        goto exit;
    }

#if 0
    LOG_RAW_HEX(LOG_DEBUG, "TCP msg parse", p_frame, LAN_PROT_HEADER_LEN);   // for debug, print header
    LOG_RAW_HEX(LOG_DEBUG, "TCP msg frame", p_frame, *p_data_len);   // for debug, print header
#endif

    // 头部转换(网络字节序是大端模式，需要转换为小端模式处理)
    lan_trans_prot_t frame;
    frame.protocol = p_frame[0];     // byte 1
    frame.serv_type = p_frame[1];    // byte 2
#if 1
    frame.seq_id = htons(*((uint16_t *)&p_frame[2]));       // byte 3~4
    frame.data_len = htonl(*((uint32_t *)&p_frame[4]));     // byte 5~8
#else
    frame.seq_id = (uint16_t)(p_frame[2] << 8 | p_frame[3]);              // 换为小端模式
    frame.data_len = (uint32_t)(p_frame[4] << 24 | p_frame[5] << 16 | p_frame[6] << 8 | p_frame[7]);    // 换为小端模式
#endif
    //frame.p_data = &p_frame[8];

    // 头部参数校验
    if (LAN_PROT_VER != frame.protocol)
    {
        SDK_LOG(LOG_ERROR, "Unsupported version(0x%02x)!!\n", frame.protocol);
        goto exit;
    }

    if (LAN_PROT_SERV_TYPE != frame.serv_type)
    {
        SDK_LOG(LOG_ERROR, "Unsupported service type(0x%02x)!!\n", frame.serv_type);
        goto exit;
    }

    /*if (frame.seq_id < s_seq_id)  // 不能校验序号，因为当APP杀掉再重新开始时，会从0开始
    {
        SDK_LOG(LOG_ERROR, "Sequence ID is small(0x%04x < 0x%04x)!!\n", frame.seq_id, s_seq_id);
        goto exit;
    }*/

    if (frame.data_len != (*p_data_len - LAN_PROT_HEADER_LEN))
    {
        SDK_LOG(LOG_ERROR, "Data len is %d, but actual received data len is %d!!\n", frame.data_len, *p_data_len - LAN_PROT_HEADER_LEN);
        goto exit;
    }

    *p_data_len = frame.data_len;            // 数据长度
    s_seq_id = frame.seq_id;                 // 保存序列号
    //LOG_RAW_HEX(LOG_DEBUG, "TCP payload", p_data, 4);   // for debug, print header
    ret = SDK_OK;

exit:
    return ret;
}


/**
* @brief    tcp数据帧解析
* @param[in]  *p_frame  [数据buffer]
* @param[in]  frame_len [数据长度]
* @param[in]  cb        [数据处理回调函数]
* @return  int          [下次buffer写入偏移]
*/
int vesync_tcp_data_parse(uint8_t *p_frame, uint32_t frame_len, vesync_tcp_parse_cb_t cb)
{
    // 参数检测
    if (NULL == p_frame || frame_len < LAN_PROT_HEADER_LEN)
    {
        return frame_len;
    }
    uint32_t remain = frame_len;
    uint32_t offset = 0;

#if 0
    vesync_log_hex_print(LOG_INFO, "frame_data:", p_frame, frame_len);
#endif

    do
    {
        // 头部转换(网络字节序是大端模式，需要转换为小端模式处理)
        lan_trans_prot_t frame;
        frame.protocol = p_frame[offset];     // byte 1
        frame.serv_type = p_frame[offset + 1];    // byte 2
        frame.seq_id = htons(*((uint16_t *)&p_frame[offset + 2]));       // byte 3~4
        frame.data_len = htonl(*((uint32_t *)&p_frame[offset + 4]));     // byte 5~8

        // 头部参数校验
        if (LAN_PROT_VER != frame.protocol)
        {
            SDK_LOG(LOG_ERROR, "invalid version:0x%02x\n", frame.protocol);
            return 0;
        }
        if (LAN_PROT_SERV_TYPE != frame.serv_type)
        {
            SDK_LOG(LOG_ERROR, "invalid serv_type:0x%02x\n", frame.serv_type);
            return 0;
        }

        if ((LAN_PROT_HEADER_LEN < remain) && ((frame.data_len + LAN_PROT_HEADER_LEN) <= remain))
        {
            // 剩余数据长度大于报头解析出的数据长度时调用数据处理回调
            if (NULL != cb)
            {
                cb(p_frame + offset, frame.data_len + LAN_PROT_HEADER_LEN);
            }

            offset = (offset + frame.data_len + LAN_PROT_HEADER_LEN);
            remain -= (frame.data_len + LAN_PROT_HEADER_LEN);
            SDK_LOG(LOG_DEBUG, "remain frame len:%u, offset:%u\n", remain, offset);
        }
        else
        {
            // 将不完整的数据拷贝到buffer前端，数据解析结束
            memmove(p_frame, p_frame + offset, remain);
#if 0
            vesync_log_hex_print(LOG_INFO, "remain_data:", p_frame, remain);
#endif
            break;
        }
    } while (remain);

    return remain;
}

/**
 * @brief 局域网通信协议帧封包
 * @param[out] p_frame              [保存输出结果]
 * @param[in]  p_data               [输入数据内容]
 * @param[in/out] p_data_len        [输入时，表示p_data的长度；输出时，表示p_frame的长度]
 * @param[in]  reply                [true表示回复帧；false发送帧]
 * @return     int                  [协议封包结果，成功/失败]
 * @note                            [回复帧序列号不变，主动发送的帧，序号在现有序号基础上增加1]
 */
int vesync_lan_trans_prot_pack(  uint8_t *p_frame, uint8_t *p_data, uint32_t *p_data_len, bool reply)
{
    // 参数检测
    if (NULL == p_frame || NULL == p_data || NULL == p_data_len)
    {
        return SDK_FAIL;
    }

    if (!reply)
    {
        s_seq_id += 1;                          // 设备主动发送的帧，序号增加1
    }

    // 头部填充
    lan_trans_prot_t *p_head = (lan_trans_prot_t *)p_frame;
    p_head->protocol = LAN_PROT_VER;           // 默认
    p_head->serv_type = LAN_PROT_SERV_TYPE;    // 默认
#if 1
    p_head->seq_id = ntohs(s_seq_id);
    p_head->data_len = ntohl(*p_data_len);
#else
    p_head->seq_id = ((s_seq_id&0x00FF)<<8) | ((s_seq_id&0xFF00)>>8);          // 序列号,小端模式转换为网络字节序(大端)
    p_head->data_len = (((*p_data_len&0x000000FFU) << 24) | ((*p_data_len&0xFF000000U) >> 24) |
                        ((*p_data_len&0x0000FF00U) << 8) | ((*p_data_len&0x00FF0000U) >> 8));     // data长度,小端模式转换为网络字节序(大端)
#endif

    memcpy(p_head->p_data, p_data, *p_data_len);    // 业务数据
    *p_data_len += LAN_PROT_HEADER_LEN;             // 更新长度
    //LOG_RAW_HEX(LOG_DEBUG, "TCP msg pack", p_frame, *p_data_len);   // for debug, print header

    return SDK_OK;
}


