/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_task.c
 * @brief       task抽象层，封装freertos任务相关接口
 * @author      Joshua
 * @date        2021-04-20
 */
#include <stdlib.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>

#include "vesync_memory.h"
#include "vesync_common.h"
#include "vesync_task.h"

#define VESYNC_TASK_NAME_MAX_LEN (16)

/*
 * @brief  任务入口函数参数结构体
 */
typedef struct
{
    char name[VESYNC_TASK_NAME_MAX_LEN];
    void (*exit_fn)(void);
    void (*fn)(void *);
    void *arg;
} targ_t;


/*
 * @brief  任务函数执行入口
 */
static void task_entry(void *arg)
{
    targ_t *targ = arg;
    void (*fn)(void *) = targ->fn;
    void (*exit_fn)(void) = targ->exit_fn;
    void *farg = targ->arg;

    fn(farg);

    if (exit_fn)
    {
        exit_fn();
    }

    VCOM_SAFE_FREE(targ);
    vTaskDelete(NULL);
}

int vesync_task_new(const char *name,
                          void (*exit_fn)(void),
                          void (*fn)(void *),
                          void *arg,
                          int stack_size,
                          int prio,
                          vesync_task_t *task)
{
    VCOM_NULL_PARAM_CHK(name, return VOS_FAIL);
    VCOM_NULL_PARAM_CHK(fn, return VOS_FAIL);

    BaseType_t ret;
    TaskHandle_t task_hdl;
    targ_t *targ = (targ_t *)vesync_calloc(1, sizeof(targ_t));
    if (targ == NULL)
    {
        return VOS_FAIL;
    }

    targ->exit_fn = exit_fn;
    targ->fn = fn;
    targ->arg = arg;

    ret = xTaskCreate(task_entry,
                      name,
                      stack_size/sizeof(portSTACK_TYPE),
                      targ,
                      prio,
                      &task_hdl);
    if (ret != pdPASS)
    {
        VCOM_SAFE_FREE(targ);
        return VOS_FAIL;
    }

    if (task)
    {
        *task = (vesync_task_t)task_hdl;
    }

    return VOS_OK;
}


const char *vesync_task_name(void)
{
    TaskHandle_t task = xTaskGetCurrentTaskHandle();
    return pcTaskGetTaskName(task);
}

uint64_t vesync_task_get_max_tick_ms(void)
{
    uint64_t max_tick_ms = portMAX_DELAY * 1000 / configTICK_RATE_HZ;
    return max_tick_ms;
}

uint64_t vesync_task_get_tick_ms(void)
{
    TickType_t ticks = xTaskGetTickCount();
    uint64_t ms = ticks * 1000 / configTICK_RATE_HZ;
    return ms;
}

vesync_task_t vesync_task_get_curr_handle(void)
{
    return (vesync_task_t)xTaskGetCurrentTaskHandle();
}
