/**
 *  Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vhal_gpio_internal.h
 * @brief       GPIO硬件抽象层
 * @date        2021-04-22
 */


#ifndef _VHAL_GPIO_INTERNAL_H_
#define _VHAL_GPIO_INTERNAL_H_

#include <stdint.h>

#include "PinNames.h"

#ifdef __cplusplus
extern "C"
{
#endif

// 管脚转换
//#define RTL_GPIO_PIN_NAME_PA(n)     PA_##n
//#define RTL_GPIO_PIN_NAME_PB(n)     PB_##n

// GPIO数量声明,PinNames.h
#define RTL_GPIO_PA_MAX_NUM         24
#define RTL_GPIO_PB_MAX_NUM         13
#define RTL_GPIO_MAX_NUM            (RTL_GPIO_PA_MAX_NUM + RTL_GPIO_PB_MAX_NUM)


/*
 * @brief GPIO配置(编号和对象)
 */
typedef struct
{
    uint8_t gpio_num;       // GPIO编号
    gpio_t gpio_obj;        // GPIO对象
} rtl_gpio_cfg_t;


/**
 * @brief 获取GPIO管脚名字
 * @param[in]  gpio_num             [GPIO编号]
 * @return     int                  [pin名称]
 * @note 该接口仅用于Realtek平台，不可以为上层提供服务，rtl-amebaz2_v7.1c\component\common\mbed\targets\hal\rtl8710c\PinNames.h
 */
PinName vhal_rtl_giop_get_pin_name(uint8_t gpio_num);


#ifdef __cplusplus
}
#endif

#endif /* _VHAL_GPIO_INTERNAL_H_ */
