/**
 * Copyright © Etekcity Technologies Co., Ltd. 2021. All rights reserved.
 * @file        ffs_pem_file.h
 * @brief       Ffs pem file
 * @author      Owen.zhang
 * @date        2020-04-22
 */
#ifndef _FFS_PEM_FILE_H_
#define _FFS_PEM_FILE_H_

#ifdef __cplusplus
extern "C"
{
#endif

//#define FFS_SSL_AMZON_FULL
#define FFS_CA_DEBUG 0 //1：使用ffs_pem_file； 0： 使用flash储存

#if FFS_CA_DEBUG
#define FFS_CA_PRINTF(fmt, args...) printf(fmt, ##args)
#else
#define FFS_CA_PRINTF(fmt, args...) /* do nothing */
#endif

#if FFS_CA_DEBUG
extern const char *client_cert;
extern const char *private_cert;
#endif

extern const char *ca_cert;
extern const char *cloud_public_cert;
#ifdef HOWSMYSSL
extern const char *howsmyssl_cert;
#endif

#ifdef __cplusplus
}
#endif

#endif //_FFS_PEM_FILE_H_

