/**
* Copyright © Vesync Technologies Co.Ltd. 2022. All rights reserved
* @file         breath.h
* @brief        呼吸灯效控制
* @author       Joshua
* @date         2022-1-7
*/

#include <stdint.h>
#include "vesync_common.h"
#include "scene.h"

#ifndef __LIGHT_BREATH_H__
#define __LIGHT_BREATH_H__

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief  呼吸灯效回调
 * @return  int             [成功：APP_OK，失败：APP_FAIL]
 */
typedef int (*reset_light_cb_t)(void);


/**
 * @brief  呼吸灯效场景结构体
 */
typedef struct
{
    // TODO
} breath_light_scene_t;


/**
 * @brief  呼吸灯效
 * @param[in] thiz          [场景结构体指针]
 * @return  int             [成功：APP_OK，失败：APP_FAIL]
 */
static inline int breath_light_scene_process(scene_t *thiz)
{
    VCOM_NULL_PARAM_CHK(thiz, return APP_FAIL);
    // TODO
}


/**
 * @brief  呼吸场景灯效实现初始化
 * @return int              [成功：APP_OK， 失败：APP_FAIL]
 */
int breath_light_scene_impl_init(void);

/**
 * @brief  注册呼吸场景灯效
 * @return  int             [成功：APP_OK，失败：APP_FAIL]
 */
int breath_light_scene_reg(reset_light_scene_t *light_scene);

/**
 * @brief  注销呼吸场景灯效
 * @return  int             [成功：APP_OK，失败：APP_FAIL]
 */
int breath_light_scene_unreg(void);

#ifdef __cplusplus
}
#endif

#endif



