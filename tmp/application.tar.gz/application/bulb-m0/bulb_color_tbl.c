/**
 * Copyright © Vesync Technologies Co.Ltd. 2022. All rights reserved.
 * @file        bulb_color_tbl.c
 * @brief       bulb颜色表定义
 * @author      Herve.Lin
 * @date        2022-01-19
 */
#include "bulb_color_tbl.h"

const bulb_status_hsv_t g_hsv_red_color = {
    .hue = 0,
    .saturation = 10000,
    .value = 100,
};

const bulb_status_hsv_t g_hsv_orange_color = {
    .hue = 830,
    .saturation = 10000,
    .value = 100,
};

const bulb_status_hsv_t g_hsv_yellow_color = {
    .hue = 1667,
    .saturation = 10000,
    .value = 100,
};

const bulb_status_hsv_t g_hsv_green_color = {
    .hue = 3333,
    .saturation = 10000,
    .value = 100,
};

const bulb_status_hsv_t g_hsv_cyan_color = {
    .hue = 5000,
    .saturation = 10000,
    .value = 100,
};

const bulb_status_hsv_t g_hsv_blue_color = {
    .hue = 6667,
    .saturation = 10000,
    .value = 100,
};

const bulb_status_hsv_t g_hsv_purple_color = {
    .hue = 7575,
    .saturation = 10000,
    .value = 100,
};

const bulb_status_hsv_t g_hsv_white_color_10_pct = {
    .hue = 0,
    .saturation = 0,
    .value = 10,
};

const bulb_status_hsv_t g_hsv_white_color_20_pct = {
    .hue = 0,
    .saturation = 0,
    .value = 20,
};

const bulb_status_hsv_t g_hsv_white_color_30_pct = {
    .hue = 0,
    .saturation = 0,
    .value = 30,
};

const bulb_status_hsv_t g_hsv_white_color_40_pct = {
    .hue = 0,
    .saturation = 0,
    .value = 40,
};

const bulb_status_hsv_t g_hsv_white_color_50_pct = {
    .hue = 0,
    .saturation = 0,
    .value = 50,
};

const bulb_status_hsv_t g_hsv_white_color_60_pct = {
    .hue = 0,
    .saturation = 0,
    .value = 60,
};

const bulb_status_hsv_t g_hsv_white_color_70_pct = {
    .hue = 0,
    .saturation = 0,
    .value = 70,
};

const bulb_status_hsv_t g_hsv_white_color_80_pct = {
    .hue = 0,
    .saturation = 0,
    .value = 80,
};

const bulb_status_hsv_t g_hsv_white_color_90_pct = {
    .hue = 0,
    .saturation = 0,
    .value = 90,
};

const bulb_status_hsv_t g_hsv_white_color = {
    .hue = 0,
    .saturation = 0,
    .value = 100,
};

const bulb_status_hsv_t g_hsv_dark_color = {
    .hue = 0,
    .saturation = 0,
    .value = 0,
};

const bulb_status_hsv_t *g_hsv_rainbow_tbl[] = {
    &g_hsv_red_color,
    &g_hsv_orange_color,
    &g_hsv_yellow_color,
    &g_hsv_green_color,
    &g_hsv_cyan_color,
    &g_hsv_blue_color,
    &g_hsv_purple_color,
};

const bulb_status_hsv_t *g_hsv_grad_white_tbl[] = {
    &g_hsv_dark_color,
    &g_hsv_white_color_10_pct,
    &g_hsv_white_color_20_pct,
    &g_hsv_white_color_30_pct,
    &g_hsv_white_color_40_pct,
    &g_hsv_white_color_50_pct,
    &g_hsv_white_color_60_pct,
    &g_hsv_white_color_70_pct,
    &g_hsv_white_color_80_pct,
    &g_hsv_white_color_90_pct,
    &g_hsv_white_color,
};

const bulb_status_white_t g_white_shutdown = {
    .color_temp = 0,
    .brightness = 0,
};

const bulb_status_white_t g_white_2700k_100 = {
    .color_temp = 0,
    .brightness = 100,
};

const bulb_status_white_t g_white_2700k_50 = {
    .color_temp = 0,
    .brightness = 50,
};

const bulb_status_white_t g_white_4600k_100 = {
    .color_temp = 50,
    .brightness = 100,
};

const bulb_status_white_t g_white_4600k_50 = {
    .color_temp = 50,
    .brightness = 50,
};

const bulb_status_white_t g_white_6500k_100 = {
    .color_temp = 100,
    .brightness = 100,
};

const bulb_status_white_t g_white_6500k_50 = {
    .color_temp = 100,
    .brightness = 50,
};
