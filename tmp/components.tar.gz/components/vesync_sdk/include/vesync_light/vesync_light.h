/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_light.h
 * @brief       灯光照明控制模块接口定义
 * @author      Herve
 * @date        2021-11-09
 */
#ifndef __VESYNC_LIGHT_H__
#define __VESYNC_LIGHT_H__

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief Light结果枚举
 */
typedef enum
{
    LIGHT_OK = 0,       // OK
    LIGHT_ERR = -1,     // 一般错误
    LIGHT_INV_CH = -2,  // 非法的通道号
    LIGHT_N_PTR = -3,   // 空指针
    LIGHT_IS_INIT = -4, // 模块已经注册
    LIGHT_NO_INIT = -5, // 模块未初始化
    LIGHT_INV_ARG = -6, // 非法参数
} LIGHT_RESULT_E;

/**
 * @brief 灯光控制器实例句柄
 */
typedef void *vesync_light_t;

/**
 * @brief 通道PWM控制量输出回调函数类型定义
 * @param[in] opt           [可选的回调参数]
 * @param[in] ch_num        [回调的通道号]
 * @param[in] p_ch_duty     [回调的个通道的PWM控制量]
 */
typedef void (*vesync_light_ctrl_cb_t)(void *opt, uint16_t ch_num, uint32_t *p_ch_duty);

/**
 * @brief 初始化灯光控制模块
 * @return int              [LIGHT_RESULT_E]
 */
int vesync_light_init(void);

/**
 * @brief 反初始化灯光控制模块
 * @return int              [LIGHT_RESULT_E]
 */
int vesync_light_deinit(void);

/**
 * @brief 创建一个灯光控制器实例，灯光控制器的创建数量不能超过LIGHT_NUM_MAX
 * @param[in] ch_num        [控制器的通道数量，通道数量不能超过LIGHT_CH_NUM_MAX]
 * @param[in] step_intvl    [PWM刷新单步的间隔，也就是定时器的Timeout，单位为毫秒]
 * @param[in] max_duty      [占空比的最大值]
 * @param[in] ch_ctrl_cb    [通道PWM控制量输出回调函数]
 * @param[in] cb_arg        [可选的自定义回调参数]
 * @return vesync_light_t   [返回创建的灯光控制器句柄]
 * @return NULL             [创建失败]
 */
vesync_light_t vesync_light_create(uint16_t ch_num, uint32_t step_intvl, uint32_t max_duty, vesync_light_ctrl_cb_t ch_ctrl_cb, void *cb_arg);

/**
 * @brief 销毁一个灯光控制器实例
 * @param[in] hdl           [灯光控制器实例]
 * @return int              [LIGHT_RESULT_E]
 */
int vesync_light_destroy(vesync_light_t hdl);

/**
 * @brief 获取该灯光控制器的特定通道号的当前PWM控制量
 * @param[in] hdl           [灯光控制器实例]
 * @param[in] ch_idx        [目标通道号]
 * @param[out] p_duty       [指向输出占空比的缓存]
 * @return int              [LIGHT_RESULT_E]
 */
int vesync_light_get_duty(vesync_light_t hdl, uint16_t ch_idx, uint32_t *p_duty);

/**
 * @brief 设置该灯光控制器的特定通道号的伽马校正参数
 * @param[in] hdl           [灯光控制器实例]
 * @param[in] ch_idx        [目标通道号]
 * @param[in] gamma         [新的伽马校正参数]
 * @return int              [LIGHT_RESULT_E]
 * @note
 *  gamma < 1， 伽玛压缩，提升低亮度的灰度解析
 *  gamma > 1， 伽玛展开，提升高亮度的灰度解析
 */
int vesync_light_set_gamma(vesync_light_t hdl, uint16_t ch_idx, float gamma);

/**
 * @brief 配置该灯光控制器的特定通道号的PWM控制量，按照规定时长进行渐变的模式
 * @param[in] hdl           [灯光控制器实例]
 * @param[in] ch_idx        [目标通道号]
 * @param[in] bright        [设置的目标亮度，取值范围为[0,1]]
 * @param[in] period        [渐变时长（毫秒），将影响内存占用]
 * @param[in] delay         [启动延时（毫秒）]
 * @return int              [LIGHT_RESULT_E]
 */
int vesync_light_fade_with_time_cfg(vesync_light_t hdl, uint16_t ch_idx, float bright, uint32_t period, uint32_t delay);

/**
 * @brief 配置该灯光控制器的特定通道号的PWM控制量，按照规定步速进行渐变的模式
 * @param[in] hdl           [灯光控制器实例]
 * @param[in] ch_idx        [目标通道号]
 * @param[in] bright        [设置的目标亮度，取值范围为[0,1]]
 * @param[in] scale         [渐变步速，表示单步会改变多少的亮度，取值范围为[0,1]。将影响内存占用]
 * @param[in] delay         [启动延时（毫秒）]
 * @return int              [LIGHT_RESULT_E]
 * @note 单步的时间在创建灯光控制器的时候已经设定
 */
int vesync_light_fade_with_step_cfg(vesync_light_t hdl, uint16_t ch_idx, float bright, float scale, uint32_t delay);

/**
 * @brief 配置该灯光控制器的特定通道号为均匀亮灭的闪烁模式
 * @param[in] hdl           [灯光控制器实例]
 * @param[in] ch_idx        [目标通道号，通道需要已注册]
 * @param[in] bright        [闪烁中的亮状态的对应亮度，取值范围为[0,1]]
 * @param[in] period        [闪烁周期（毫秒），将影响内存占用]
 * @param[in] delay         [启动延时（毫秒）]
 * @param[in] sc_num        [持续半周期数，0为持续]
 * @return int              [LIGHT_RESULT_E]
 * @note 闪烁时序如下：
 *      xxxxxxx         xxxxxxx         xxxxxxx
 *      x     x         x     x         x     x
 *      x     x         x     x         x     x
 * xxxxxx     xxxxxxxxxxx     xxxxxxxxxxx     xxxxxx
 * │  1sx  │  2sc  │  3sc  │  4sc  │  5sc  │  6sc  │
 * ├───────┼───────┼───────┼───────┼───────┼───────┤
 */
int vesync_light_blink_cfg(vesync_light_t hdl, uint16_t ch_idx, float bright, uint32_t period, uint32_t delay, uint32_t sc_num);

/**
 * @brief 配置该灯光控制器的特定通道号为均匀亮灭的呼吸模式
 * @param[in] hdl           [灯光控制器实例]
 * @param[in] ch_idx        [目标通道号，通道需要已注册]
 * @param[in] bright        [呼吸模式中最亮状态对应的亮度，取值范围为[0,1]]
 * @param[in] period        [呼吸周期（毫秒），将影响内存占用]
 * @param[in] delay         [启动延时（毫秒）]
 * @param[in] sc_num        [持续半周期数，0为持续]
 * @return int              [LIGHT_RESULT_E]
 * @note 呼吸时序如下：
 *       xxxxx           xxxxx           xxxxx
 *     xx     xx       xx     xx       xx     xx
 *   xx         xx   xx         xx   xx         xx
 *  xx           xx xx           xx xx           xx
 * xx             xxx             xxx             xx
 * │  1sc  │  2sc  │  3sc  │  4sc  │  5sc  │  6sc  │
 * ├───────┼───────┼───────┼───────┼───────┼───────┤
 */
int vesync_light_breath_cfg(vesync_light_t hdl, uint16_t ch_idx, float bright, uint32_t period, uint32_t delay, uint32_t sc_num);

/**
 * @brief 启动该通道的渐变、闪烁或者呼吸模式
 * @param[in] hdl           [灯光控制器实例]
 * @param[in] ch_idx        [目标通道号，通道需要已注册]
 * @return int              [LIGHT_RESULT_E]
 */
int vesync_light_start(vesync_light_t hdl, uint16_t ch_idx);

/**
 * @brief 停止该通道的渐变、闪烁或者呼吸模式
 * @param[in] hdl           [灯光控制器实例]
 * @param[in] ch_idx        [目标通道号，通道需要已注册]
 * @return int              [LIGHT_RESULT_E]
 */
int vesync_light_stop(vesync_light_t hdl, uint16_t ch_idx);

#ifdef __cplusplus
}
#endif

#endif /*  __VESYNC_LIGHT_H__ */