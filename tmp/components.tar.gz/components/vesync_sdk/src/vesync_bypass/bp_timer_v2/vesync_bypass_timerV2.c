/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_bypass_timerV2.c
 * @brief       Bypass timerV2接口定义
 * @author      Charles.Mei
 * @date        2021-12-22
 */
#include <string.h>

#include "vesync_common.h"
#include "vesync_memory.h"
#include "vesync_bypass_internal.h"


/**
 * @brief "addTimerV2" method数据解析
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  json                     [json数据指针]
 * @return BYPASS_ERR_E                 [错误码]
 */
static BYPASS_ERR_E bypass_method_add_timerV2_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    BYPASS_ERR_E ret = BP_OK;

    bypass_timerV2_data_t timer_base;
    memset(&timer_base, 0, sizeof(bypass_timerV2_data_t));

    cJSON* json_data = cJSON_GetObjectItemCaseSensitive(json, "total");
    if (cJSON_IsNumber(json_data))
    {
        // 执行时间0~86400，最大倒计时24小时
        if (json_data->valueint <= 0 || json_data->valueint >= 86400)
        {
            vesync_bypass_reply_noqos(BP_ERR_TIMER_CONFIG, p_msg_ctx->p_trace_msg ,NULL);  // 回复指定错误码
            ret = BP_ERROR;
            goto EXIT;
        }

        timer_base.total_sec = json_data->valueint;
    }
    else
    {
        ret = BP_ERR_ARG;
        goto EXIT;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "startAct");
    if (cJSON_IsArray(json_data) && cJSON_GetArraySize(json_data))
    {
        timer_base.json_action = json_data;     // startAct 指针传给应用层处理
    }
    else
    {
        ret = BP_ERR_ARG;
        goto EXIT;
    }

    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_ADD_TIMER_V2);
    if (method_cb)
    {
        method_cb(p_msg_ctx, (void*)&timer_base);
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

EXIT:
    return ret;
}

/**
 * @brief "delTimerV2" method数据解析
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  json                     [json数据指针]
 * @return BYPASS_ERR_E                 [错误码]
 */
static BYPASS_ERR_E bypass_method_del_timerV2_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    BYPASS_ERR_E ret = BP_OK;
    int32_t timer_id = 0;


    cJSON* json_data = cJSON_GetObjectItemCaseSensitive(json, "id");
    if (cJSON_IsNumber(json_data))
    {
        timer_id = json_data->valueint;
    }
    else
    {
        ret = BP_ERR_ARG;
        goto EXIT;
    }

    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_DEL_TIMER_V2);
    if (method_cb)
    {
        method_cb(p_msg_ctx, (void*)&timer_id);
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

EXIT:
    return ret;
}

/**
 * @brief "getTimerV2" method数据解析
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  json                     [json数据指针]
 * @return BYPASS_ERR_E                 [错误码]
 */
static BYPASS_ERR_E bypass_method_get_timerV2_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    UNUSED(json);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    BYPASS_ERR_E ret = BP_OK;

    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_GET_TIMER_V2);
    if (method_cb)
    {
        method_cb(p_msg_ctx, NULL);
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

    return ret;
}

static bypass_item_data_t method_tbl[] = {
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_ADD_TIMER_V2, "addTimerV2", bypass_method_add_timerV2_handle, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_DEL_TIMER_V2, "delTimerV2", bypass_method_del_timerV2_handle, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_GET_TIMER_V2, "getTimerV2", bypass_method_get_timerV2_handle, NULL},
};

void vesync_bypass_timerV2_init(void)
{
    for (int i = 0; i < SIZEOF_ARRAY(method_tbl); i++)
    {
        bypass_item_t *item = vesync_bypass_init_item(&method_tbl[i]);
        if (item != NULL)
        {
            vesync_bypass_add_item(item);
        }
    }
}
