/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        queue_test.cpp
 * @brief       os_adapter queue测试用例
 * @author      Joshua
 * @date        2021-04-25
 */


#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <gtest/gtest.h>

#include "vesync_os.h"
#include "vesync_task.h"
#include "vesync_sem.h"
#include "vesync_queue.h"
#include "vesync_common.h"

static vesync_queue_t *g_queue;

static vesync_sem_t *g_sem;

typedef struct
{
    char txt[64];
} test_msg_t;

static void queue_send_task(void *arg)
{
    int ret = -1;
    test_msg_t msg;
    snprintf(msg.txt, sizeof(msg.txt), "task name is %s\n", vesync_task_name());

    ret = vesync_queue_send(g_queue, &msg, VESYNC_OS_NO_WAIT);
    EXPECT_EQ(ret, 0);
}

static void queue_recv_task(void *arg)
{
    int ret = -1;
    test_msg_t msg;

    ret = vesync_queue_recv(g_queue, &msg, VESYNC_OS_WAIT_FOREVER);
    EXPECT_EQ(ret, 0);

    printf("recv msg: %s\n", msg.txt);

    ret = vesync_sem_signal(g_sem);
    EXPECT_EQ(ret, 0);
}

TEST(queue_test, queue_task)
{
    int ret = -1;

    g_queue = vesync_queue_new(sizeof(test_msg_t), sizeof(test_msg_t));
    EXPECT_TRUE(g_queue);

    g_sem = vesync_sem_binary_new();
    EXPECT_TRUE(g_sem);

    ret = vesync_task_new("queue_recv_task", NULL, queue_recv_task, NULL, 1024, 0, NULL);
    EXPECT_EQ(ret, 0);

    ret = vesync_task_new("queue_send_task", NULL, queue_send_task, NULL, 1024, 0, NULL);
    EXPECT_EQ(ret, 0);

    vesync_sem_wait(g_sem, VESYNC_OS_WAIT_FOREVER);
    EXPECT_EQ(ret, 0);

    ret = vesync_sem_free(g_sem);
    EXPECT_EQ(ret, 0);

    ret = vesync_queue_free(g_queue);
    EXPECT_EQ(ret, 0);
}

