/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_rsa.h
 * @brief       RSA加解密相关接口
 * @date        2021-04-25
 */

#ifndef __VESYNC_RSA_H__
#define __VESYNC_RSA_H__

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief 使用rsa public key加密数据
 * @param[in]  in_data              [输入数据]
 * @param[in]  in_data_len          [输入数据长度]
 * @param[out] out_buffer           [输出数据缓冲地址]
 * @param[out] out_len              [输出数据长度]
 * @param[out] out_buffer_size      [输出数据缓冲大小]
 * @param[in]  pk_pem               [public key pem格式]
 * @param[in]  pk_len               [public key 长度]
 * @return  int                     [成功：SDK_OK, 失败：SDK_FAIL]
*/
int vesync_rsa_pk_encrypt(uint8_t *in_data, size_t in_data_len, uint8_t *out_buffer,\
                        size_t *out_len, size_t out_buffer_size, const char *pk_pem, size_t pk_len);


#ifdef __cplusplus
}
#endif
#endif /* __VESYNC_RSA_H__ */

