/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_event_test.cpp
 * @brief       vesync event测试用例
 * @author      Joshua
 * @date        2021-05-13
 */


#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <gtest/gtest.h>
#include "vesync_os.h"
#include "vesync_task.h"
#include "vesync_sem.h"
#include "vesync_common.h"
#include "vesync_event_internal.h"

static vesync_sem_t *g_sem;

static int task1_cb(void *data)
{
    vesync_ev_t *event = (vesync_ev_t*) data;
    printf("task1: event_id=%d, publisher=%s, len=%d, buf=%s\n", event->event_id, event->publisher, event->len,
            (char *)event->buf);
    return SDK_OK;
}

static void subscribe_task1(void *arg)
{
    UNUSED(arg);

    int ret = vesync_event_subscribe(EVENT_WIFI_DISCONNECTED, SUB_ID_BYPASS, task1_cb);
    EXPECT_EQ(ret, SDK_OK);

    vesync_sem_signal(g_sem);
}

static int task2_cb(void *data)
{
    vesync_ev_t *event = (vesync_ev_t*) data;
    printf("task2: event_id=%d, publisher=%s, len=%d, buf=%s\n", event->event_id, event->publisher, event->len,
            (char*)event->buf);

    //int ret = vesync_event_unsubscribe(EVENT_WIFI_CONNECTED, SUB_ID_FFS);
    //EXPECT_EQ(ret, SDK_OK);
    return SDK_OK;
}

static void subscribe_task2(void *arg)
{
    UNUSED(arg);
    int ret = vesync_event_subscribe(EVENT_WIFI_CONNECTED, SUB_ID_FFS, task2_cb);
    EXPECT_EQ(ret, SDK_OK);

    vesync_sem_signal(g_sem);
}

static void publish_task1(void *arg)
{
    vesync_ev_t event;
    char *msg = (char*)"I am task publisher 1";
    VESYNC_POPULATE_EV(event, EVENT_WIFI_CONNECTED, "test_task1", strlen(msg), (char*)msg);
    int ret = vesync_event_publish(&event);
    EXPECT_EQ(ret, SDK_OK);

    VESYNC_POPULATE_EV(event, EVENT_WIFI_DISCONNECTED, "test_task1", 0, NULL);
    ret = vesync_event_publish(&event);
    EXPECT_EQ(ret, SDK_OK);

    vesync_sem_signal(g_sem);
}

static void publish_task2(void *arg)
{
    vesync_ev_t event;
    event.event_id = EVENT_WIFI_CONNECTED;
    char *msg = (char*)"I am task publisher 2";
    VESYNC_POPULATE_EV(event, EVENT_WIFI_CONNECTED, "test_task2", strlen(msg), (char*)msg);
    int ret = vesync_event_publish(&event);
    EXPECT_EQ(ret, SDK_OK);

    vesync_sem_signal(g_sem);
}

TEST(vesync_event_test, multi_publisher)
{
    int ret = -1;
    g_sem = vesync_sem_binary_new();

    ret = vesync_event_init();
    EXPECT_EQ(ret, SDK_OK);

    vesync_task_new("DISCONNECTED", NULL, subscribe_task1, NULL, 1024, 0, NULL);
    vesync_sem_wait(g_sem, VESYNC_OS_WAIT_FOREVER);

    vesync_task_new("CONNECTED", NULL, subscribe_task2, NULL, 1024, 0, NULL);
    vesync_sem_wait(g_sem, VESYNC_OS_WAIT_FOREVER);

    vesync_task_new("publisher_A", NULL, publish_task1, NULL, 1024, 0, NULL);
    vesync_sem_wait(g_sem, VESYNC_OS_WAIT_FOREVER);

    vesync_task_new("publisher_B", NULL, publish_task2, NULL, 1024, 0, NULL);
    vesync_sem_wait(g_sem, VESYNC_OS_WAIT_FOREVER);

    ret = vesync_sem_free(g_sem);
}


