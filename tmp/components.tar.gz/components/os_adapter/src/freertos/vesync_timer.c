/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_timer.c
 * @brief       timer抽象层，封装freertos定时器相关接口
 * @author      Joshua
 * @date        2021-04-20
 */
#ifndef CONFIG_VESYNC_USE_LOOP_TIMER
#include <stdbool.h>
#include <freertos/FreeRTOS.h>
#include <freertos/timers.h>

#include "vesync_log_internal.h"
#include "vesync_os_internal.h"
#include "vesync_timer_internal.h"
#include "vesync_common.h"
#include "vesync_memory.h"
#include "vesync_timer.h"


/**
 * @brief 定时器回调函数执行入口
 * @param[in] timer [FreeRTOS定时器句柄]
 */
static void timer_cb_entry(TimerHandle_t timer)
{
    vesync_timer_t *handle = pvTimerGetTimerID(timer);

    if (NULL != handle)
    {
        handle->cb(handle->cb_arg);
    }
}

/**
 * @brief  定时器超时时间检查
 * @param[in]  timeout_ms            [超时时间，单位毫秒]
 * @return bool                      [通过：true，失败：false]
 */
static bool timer_timeout_is_valid(long timeout_ms)
{
    if (timeout_ms < portTICK_PERIOD_MS)
    {
        OS_LOG(LOG_WARN, "Minimum timeout is %d ms\n", portTICK_PERIOD_MS);
        return false;
    }
    return true;
}

/**
 * @brief  创建定时器
 * @param[in]  name                  [定时器名称]
 * @param[in]  cb                    [timout回调函数]
 * @param[in]  cb_arg                [回调函数输入参数]
 * @param[in]  timeout_ms            [超时时间，单位毫秒]
 * @param[in]  reload                [定时类型:
 *                                    false：一次
 *                                    true：周期性]
 * @return vesync_timer_t            [定时器结构体指针]
 */
vesync_timer_t *vesync_timer_new(const char *name,
                                 void (*cb)(void*),
                                 void *cb_arg,
                                 long timeout_ms,
                                 bool reload)
{
    VCOM_NULL_PARAM_CHK(name, return NULL);
    VCOM_NULL_PARAM_CHK(cb, return NULL);

    if (!timer_timeout_is_valid(timeout_ms))
    {
        timeout_ms = portTICK_PERIOD_MS;
    }

    vesync_timer_t *timer = (vesync_timer_t*)vesync_malloc(sizeof(vesync_timer_t));
    if (timer == NULL)
    {
        return NULL;
    }

    timer->cb = cb;
    timer->cb_arg = cb_arg;
    timer->timeout_ms = timeout_ms;
    timer->reload = reload;
    timer->handle = xTimerCreate(name,
                                 VESYNC_MS_TO_TICKS(timeout_ms),
                                 reload ? pdTRUE : pdFALSE,
                                 timer, // 通过指定ID，把定时器的handle缓存到FreeRTOS的定时器handle
                                 (TimerCallbackFunction_t)timer_cb_entry);
    if (timer->handle == NULL)
    {
        VCOM_SAFE_FREE(timer);
        return NULL;
    }

    return timer;
}

/**
* @brief  启动定时器
* @param[in]  timer                   [定时器结构体指针]
* @return int                         [成功：VOS_OK；失败：VOS_FAIL]
*/
int vesync_timer_start(vesync_timer_t *timer)
{
    VCOM_NULL_PARAM_CHK(timer, return VOS_FAIL);
    VCOM_NULL_PARAM_CHK(timer->handle, return VOS_FAIL);

    BaseType_t ret = pdFAIL;
    ret = xTimerStart(timer->handle, PORT_VESYNC_DELAY);
    if (pdPASS != ret)
    {
        return VOS_FAIL;
    }

    return VOS_OK;
}

/**
 * @brief  停止定时器
 * @param[in]  timer                   [定时器结构体指针]
 * @return int                         [成功：VOS_OK；失败：VOS_FAIL]
 */
int vesync_timer_stop(vesync_timer_t *timer)
{
    VCOM_NULL_PARAM_CHK(timer, return VOS_FAIL);
    VCOM_NULL_PARAM_CHK(timer->handle, return VOS_FAIL);

    BaseType_t ret = pdFAIL;
    ret = xTimerStop(timer->handle, PORT_VESYNC_DELAY);
    if (pdPASS != ret)
    {
        return VOS_FAIL;
    }

    return VOS_OK;
}

/**
* @brief 修改计时周期
* @param[in] timer                    [定时器结构体指针]
* @param[in] timeout_ms               [超时时间]
* @return int                         [成功：VOS_OK；失败：VOS_FAIL]
*/
int vesync_timer_change_period(vesync_timer_t *timer, long timeout_ms)
{
    VCOM_NULL_PARAM_CHK(timer, return VOS_FAIL);
    VCOM_NULL_PARAM_CHK(timer->handle, return VOS_FAIL);

    if (!timer_timeout_is_valid(timeout_ms))
    {
        timeout_ms = portTICK_PERIOD_MS;
    }

    BaseType_t ret = pdFAIL;
    ret = xTimerChangePeriod(timer->handle, VESYNC_MS_TO_TICKS(timeout_ms), PORT_VESYNC_DELAY);
    if (pdPASS != ret)
    {
        return VOS_FAIL;
    }

    return VOS_OK;
}

/**
 * @brief  删除定时器
 * @param[in]  timer                   [定时器结构体指针]
 * @return int                         [成功：VOS_OK；失败：VOS_FAIL]
 */
int vesync_timer_free(vesync_timer_t *timer)
{
    VCOM_NULL_PARAM_CHK(timer, return VOS_FAIL);
    VCOM_NULL_PARAM_CHK(timer->handle, return VOS_FAIL);

    BaseType_t ret = pdFAIL;

    ret = xTimerDelete(timer->handle, PORT_VESYNC_DELAY);
    if (pdPASS != ret)
    {
        return VOS_FAIL;
    }

    timer->handle = NULL;

    VCOM_SAFE_FREE(timer);

    return VOS_OK;
}

#else

#include <string.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include "vesync_common.h"
#include "vesync_queue.h"
#include "vesync_task.h"
#include "vesync_memory.h"
#include "vesync_timer_internal.h"
#include "vesync_timer.h"


static vesync_queue_t *s_event_queue = NULL;
static vesync_task_t s_task_handle = NULL;

static vloop_timer_header_t s_loop_timer_header = {0};


/**
 * @brief  处理定时器事件
 * @param[in]  ev                   [定时器事件指针]
 */
static void timer_event_handle(vesync_timer_ev_t *ev)
{
    switch (ev->id)
    {
    case TIMER_EV_ADD:
        vloop_timer_add(&s_loop_timer_header, ev->loop_timer);
        break;

    case TIMER_EV_DEL:
        vloop_timer_del(&s_loop_timer_header, ev->loop_timer);
        break;

    case TIMER_EV_CH_PERIOD:
        ev->loop_timer->period = ev->period_new;
        vloop_timer_add(&s_loop_timer_header, ev->loop_timer);
        break;

    case TIMER_EV_FREE:
        vloop_timer_del(&s_loop_timer_header, ev->loop_timer);
        VCOM_SAFE_FREE(ev->loop_timer);
        break;

    default:
        break;
    }
}


/**
 * @brief  定时器任务
 */
static void vesync_timer_task(void *arg)
{
    UNUSED(arg);
    vesync_timer_ev_t ev;

    while(1)
    {
        if (VOS_OK == vesync_queue_recv(s_event_queue, &ev, vloop_timer_process_expired(&s_loop_timer_header)))
        {
            timer_event_handle(&ev);
        }
    }
}

/**
 * @brief  初始化定时器任务
 * @return int                         [成功：VOS_OK；失败：VOS_FAIL]
 */
int vesync_timer_init(void)
{
    s_event_queue = vesync_queue_new(TIMER_EVENT_QUEUE_MAX_NUM * sizeof(vesync_timer_ev_t), sizeof(vesync_timer_ev_t));
    if (s_event_queue == NULL)
    {
        return VOS_FAIL;
    }

    int ret = vesync_task_new(VESYNC_TIMER_TASK_NAME, 
                            NULL, 
                            vesync_timer_task, 
                            NULL, 
                            VESYNC_TIMER_TASK_STACKSIZE, 
                            VESYNC_TIMER_TASK_PRIO, 
                            &s_task_handle);
    if (ret != VOS_OK)
    {
        vesync_queue_free(s_event_queue);
        return VOS_FAIL;
    }

    return VOS_OK;
}


/**
 * @brief  创建定时器
 * @param[in]  name                  [定时器名称]
 * @param[in]  cb                    [timout回调函数]
 * @param[in]  cb_arg                [回调函数输入参数]
 * @param[in]  timeout_ms            [超时时间，单位毫秒]
 * @param[in]  reload                [定时类型:
 *                                    false：一次
 *                                    true：周期性]
 * @return vesync_timer_t            [定时器结构体指针]
 */
vesync_timer_t *vesync_timer_new(char *name,
                                void (*cb)(void*),
                                void *cb_arg,
                                long timeout_ms,
                                bool reload)
{
    VCOM_NULL_PARAM_CHK(name, return NULL);
    VCOM_NULL_PARAM_CHK(cb, return NULL);

    vesync_timer_t *timer = (vesync_timer_t*)vesync_malloc(sizeof(vesync_timer_t));
    vloop_timer_t *loop_timer = (vloop_timer_t *)vesync_malloc(sizeof(vloop_timer_t));
    if (timer == NULL || loop_timer == NULL)
    {
        VCOM_SAFE_FREE(timer);
        VCOM_SAFE_FREE(loop_timer);
        return NULL;
    }

    timer->cb = cb;
    timer->cb_arg = cb_arg;
    timer->timeout_ms = timeout_ms;
    timer->reload = reload;
    timer->handle = loop_timer;

    memset(loop_timer, 0, sizeof(vloop_timer_t));
    loop_timer->reload = reload;
    loop_timer->period = timeout_ms;
    loop_timer->cb = cb;
    loop_timer->arg = cb_arg;

    return timer;
}

/**
* @brief  启动定时器
* @param[in]  timer                   [定时器结构体指针]
* @return int                         [成功：VOS_OK；失败：VOS_FAIL]
*/
int vesync_timer_start(vesync_timer_t *timer)
{
    VCOM_NULL_PARAM_CHK(timer, return VOS_FAIL);
    VCOM_NULL_PARAM_CHK(timer->handle, return VOS_FAIL);

    vesync_timer_ev_t ev = {0};

    ev.id = TIMER_EV_ADD;
    ev.loop_timer = timer->handle;

    return vesync_queue_send(s_event_queue, &ev, PORT_VESYNC_DELAY);
}

/**
 * @brief  停止定时器
 * @param[in]  timer                   [定时器结构体指针]
 * @return int                         [成功：VOS_OK；失败：VOS_FAIL]
 */
int vesync_timer_stop(vesync_timer_t *timer)
{
    VCOM_NULL_PARAM_CHK(timer, return VOS_FAIL);
    VCOM_NULL_PARAM_CHK(timer->handle, return VOS_FAIL);

    vesync_timer_ev_t ev = {0};

    ev.id = TIMER_EV_DEL;
    ev.loop_timer = timer->handle;

    return vesync_queue_send(s_event_queue, &ev, PORT_VESYNC_DELAY);
}

/**
* @brief 修改计时周期
* @param[in] timer                    [定时器结构体指针]
* @param[in] timeout_ms               [超时时间]
* @return int                         [成功：VOS_OK；失败：VOS_FAIL]
*/
int vesync_timer_change_period(vesync_timer_t *timer, long timeout_ms)
{
    VCOM_NULL_PARAM_CHK(timer, return VOS_FAIL);
    VCOM_NULL_PARAM_CHK(timer->handle, return VOS_FAIL);

    int ret;
    vesync_timer_ev_t ev = {0};

    ev.id = TIMER_EV_CH_PERIOD;
    ev.loop_timer = timer->handle;
    ev.period_new = timeout_ms;

    ret = vesync_queue_send(s_event_queue, &ev, PORT_VESYNC_DELAY);
    if (VOS_OK == ret)
    {
        timer->timeout_ms = timeout_ms;
    }

    return ret;
}

/**
 * @brief  删除定时器
 * @param[in]  timer                   [定时器结构体指针]
 * @return int                         [成功：VOS_OK；失败：VOS_FAIL]
 */
int vesync_timer_free(vesync_timer_t *timer)
{
    VCOM_NULL_PARAM_CHK(timer, return VOS_FAIL);
    VCOM_NULL_PARAM_CHK(timer->handle, return VOS_FAIL);

    int ret;
    vesync_timer_ev_t ev = {0};

    ev.id = TIMER_EV_FREE;
    ev.loop_timer = timer->handle;

    ret = vesync_queue_send(s_event_queue, &ev, PORT_VESYNC_DELAY);

    if (VOS_OK == ret)
    {
        VCOM_SAFE_FREE(timer);
    }

    return ret;
}

#endif
