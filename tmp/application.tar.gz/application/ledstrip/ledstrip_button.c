/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        ledstrip_button.c
 * @brief       ledstrip button文件
 * @author      Lind
 * @date        2021-08-25
 */


#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <stdio.h>

#include "vhal_gpio.h"

#include "vesync_common.h"
#include "vesync_log.h"
#include "vesync_task.h"
#include "vesync_device.h"

#include "ledstrip_report.h"
#include "ledstrip_button.h"
#include "ledstrip_led.h"
#include "ledstrip.h"

// 短按次数
static uint8_t s_short_pressed_cnt = 1;

// 按键情景模式
static ls_led_rgb_t s_ls_scene_mode_1 = {50, 0, 0, 0, 0};
static ls_led_rgb_t s_ls_scene_mode_2 = {100, 100, 0, 0, 0};
static ls_led_rgb_t s_ls_scene_mode_3 = {0, 50, 0, 0, 0};
static ls_led_rgb_t s_ls_scene_mode_4[2] = {{0, 0, 0, 100, 0},{0, 0, 0, 30, 0}};
static ls_led_rgb_t s_ls_scene_mode_5[6] = {{0, 0, 100, 0, 0}, {0, 0, 0, 100, 0}, {0, 0, 0, 0, 100},
                                            {0, 0, 100, 100, 0}, {0, 0, 0, 100, 100}, {0, 0, 100, 0, 100}};
static ls_led_rgb_t s_ls_scene_mode_6[3] = {{0, 0, 100, 0, 0}, {0, 0, 0, 100, 0}, {0, 0, 0, 0, 100}};
static ls_led_rgb_t s_ls_scene_mode_7[7] = {{0, 0, 100, 0, 0}, {0, 0, 0, 100, 0}, {0, 0, 0, 0, 100},
                                            {0, 0, 100, 100, 100}, {0, 0, 100, 100, 0}, {0, 0, 0, 100, 100},
                                            {0, 0, 100, 0, 100}};

// 冷光50%常亮
static ls_led_diverse_param_t s_ls_scene_1 =
{
    .mode = LS_SCENE_SINGLE,
    .node_num = 1,
    .first_node = 0,
    .step_num = 70,
    .times = 0,
    .mode_head = &s_ls_scene_mode_1,
};

// 白光100%常亮
static ls_led_diverse_param_t s_ls_scene_2 =
{
    .mode = LS_SCENE_SINGLE,
    .node_num = 1,
    .first_node = 0,
    .step_num = 70,
    .times = 0,
    .mode_head = &s_ls_scene_mode_2,
};

// 暖光50%常亮
static ls_led_diverse_param_t s_ls_scene_3 =
{
    .mode = LS_SCENE_SINGLE,
    .node_num = 1,
    .first_node = 0,
    .step_num = 70,
    .times = 0,
    .mode_head = &s_ls_scene_mode_3,
};

// 绿色呼吸灯
static ls_led_diverse_param_t s_ls_scene_4 =
{
    .mode = LS_SCENE_BREATHING,
    .node_num = 2,
    .first_node = 0,
    .step_num = 60,
    .times = 0,
    .mode_head = s_ls_scene_mode_4,
};

// 6种颜色切换
static ls_led_diverse_param_t s_ls_scene_5 =
{
    .mode = LS_SCENE_SWITCH,
    .node_num = 6,
    .first_node = 0,
    .step_num = 60,
    .times = 0,
    .mode_head = s_ls_scene_mode_5,
};

// 红绿蓝三色切换
static ls_led_diverse_param_t s_ls_scene_6 =
{
    .mode = LS_SCENE_SWITCH,
    .node_num = 3,
    .first_node = 0,
    .step_num = 60,
    .times = 0,
    .mode_head = s_ls_scene_mode_6,
};

// 7种颜色组合呼吸切换，颜色交替渐亮渐暗重叠
static ls_led_diverse_param_t s_ls_scene_7 =
{
    .mode = LS_SCENE_OVERLAP,
    .node_num = 7,
    .first_node = 0,
    .step_num = 100,
    .times = 0,
    .mode_head = s_ls_scene_mode_7,
};

static ls_led_diverse_param_t *s_scene_cnt[] = {&s_ls_scene_1, &s_ls_scene_2, &s_ls_scene_3, &s_ls_scene_4,
                                                &s_ls_scene_5, &s_ls_scene_6, &s_ls_scene_7};
static bool s_task_run = false;     // 按键扫描任务运行标志
static key_status_t s_switch_key;   // 开关按键参数


/**
 * @brief 设置扫描到的瞬时按键值
 * @param[in]   scan_value      [瞬时按键值]
 */
static void button_key_set_scan_value(int8_t scan_value)
{
    uint64_t new_scan_ts = vesync_task_get_tick_ms();

    if (KEY_SCAN_VALUE_MAX_NUM == ++(s_switch_key.key_scan_value_index))
    {
        (s_switch_key.key_scan_value_index) = 0;
    }
    if (scan_value == s_switch_key.key_scan_value[s_switch_key.key_scan_value_index])
    {
        if (1 == scan_value)    // 高电平
        {
            s_switch_key.key_scan_value[(s_switch_key.key_scan_value_index)] = 0;
            --(s_switch_key.key_pressed_num);
            if(KEY_RELEASED_THRESHOLD == (s_switch_key.key_pressed_num))
            {
                s_switch_key.key_status = KEY_RELEASED_1S_LESS;
                s_switch_key.key_upturn_ts = new_scan_ts;
                return;
            }
        }
        else                    // 低电平
        {
            s_switch_key.key_scan_value[(s_switch_key.key_scan_value_index)] = 1;
            ++(s_switch_key.key_pressed_num);
            if(KEY_PRESSED_THRESHOLD == (s_switch_key.key_pressed_num))
            {
                s_switch_key.key_status = KEY_PRESSED_1S_LESS;
                s_switch_key.key_upturn_ts = new_scan_ts;
                return;
            }
        }
    }

    switch (s_switch_key.key_status)
    {
        case KEY_RELEASED_1S_LESS:
            if (new_scan_ts - s_switch_key.key_upturn_ts > 1000)  // 松开按键超过1s
            {
                s_switch_key.key_status = KEY_RELEASED_1S_MORE;
            }
            break;
        case KEY_PRESSED_1S_LESS:
        case KEY_PRESSED_1S_TO_5S:
        case KEY_PRESSED_5S_TO_15S:
            if (new_scan_ts - s_switch_key.key_upturn_ts > 15000)  // 按下按键超过15s
            {
                s_switch_key.key_status = KEY_PRESSED_15S_MORE;
            }
            else if (new_scan_ts - s_switch_key.key_upturn_ts > 5000)  // 按下按键超过5s
            {
                s_switch_key.key_status = KEY_PRESSED_5S_TO_15S;
            }
            else if (new_scan_ts - s_switch_key.key_upturn_ts > 1000)  // 按下按键超过1s
            {
                s_switch_key.key_status = KEY_PRESSED_1S_TO_5S;
            }
            break;
        case KEY_RELEASED_1S_MORE:
        case KEY_PRESSED_15S_MORE:
        default:
            break;
    }
}

/**
 * @brief 计数短按次数
 * @param[in]   reset           [true: 清零计数; false: 计数]
 */
static void handle_pressed_key_count(bool reset)
{
    if (reset)
    {
        s_short_pressed_cnt = 0;
    }
    else
    {
        s_short_pressed_cnt++;
        APP_LOG(LOG_DEBUG,"Short press button(cnt = %d).\r\n", s_short_pressed_cnt);
    }
}

/**
 * @brief 按键扫描任务
 */
static void ls_button_task(void *args)
{
    KEY_STATE_E last_key_status;
    ls_ev_t ev;

    s_task_run = true;
    uint64_t start_ts = vesync_task_get_tick_ms();
    uint64_t btn_ts[5];
    uint8_t button_cnt = 0;
    uint64_t new_ts;
    while (s_task_run)
    {
        last_key_status = s_switch_key.key_status;
        s_switch_key.key_set_scan_value(vhal_gpio_get_output(LEDSTRIP_BUTTON_GPIO_NUM));
        if (last_key_status != s_switch_key.key_status)
        {
            switch (s_switch_key.key_status)
            {
                case KEY_RELEASED_1S_MORE:
                    break;
                case KEY_PRESSED_5S_TO_15S:
                    memset(&ev, 0, sizeof(ls_ev_t));
                    ev.id = LS_EV_BEFORE_NETCFG;
                    ev.act_src = LS_ACT_SRC_BTN;
                    ls_app_task_notify(&ev);
                    break;
                case KEY_PRESSED_15S_MORE:
                    handle_pressed_key_count(true);
                    memset(&ev, 0, sizeof(ls_ev_t));
                    ev.id = LS_EV_RESET;
                    ev.act_src = LS_ACT_SRC_INIT;
                    ls_app_task_notify(&ev);
                    break;
                case KEY_RELEASED_1S_LESS:
                    switch (last_key_status)
                    {
                        case KEY_PRESSED_1S_LESS:
                            handle_pressed_key_count(false);
                            new_ts = vesync_task_get_tick_ms();
                            if ((new_ts - start_ts) < 10000)
                            {
                                // 上电10s内 可以触发产测模式，要2s内按5次按键
                                btn_ts[button_cnt % 5] = new_ts;
                                button_cnt++;
                                if (button_cnt >= 5 && (new_ts - btn_ts[(button_cnt - 5) % 5]) < 2000)
                                {
                                    memset(&ev, 0, sizeof(ls_ev_t));
                                    ev.id = LS_EV_PRODUCTION;
                                    ev.act_src = LS_ACT_SRC_BTN;
                                    ls_app_task_notify(&ev);
                                }
                            }
                            // 模式循环
                            s_short_pressed_cnt = s_short_pressed_cnt % LS_BUTTON_MODE_NUM;
                            if (s_short_pressed_cnt == 0)
                            {
                                // 按键模式为关
                                ls_led_off(LS_LED_ACT_SRC_BTN);
                            }
                            else
                            {
                                ls_led_set_led((void*)s_scene_cnt[s_short_pressed_cnt - 1],
                                                LS_LED_ACT_SRC_BTN);
                            }
                            ls_report_set_chg_rsn(STAT_CHG_RSN_BTN_STR);
                            break;
                        case KEY_PRESSED_5S_TO_15S:
                            memset(&ev, 0, sizeof(ls_ev_t));
                            ev.id = LS_EV_NETCFG;
                            ev.act_src = LS_ACT_SRC_BTN;
                            ls_app_task_notify(&ev);
                            ls_report_set_chg_rsn(STAT_CHG_RSN_NONE_STR);
                            report_ls_status();
                            break;
                        case KEY_PRESSED_1S_TO_5S:
                        case KEY_PRESSED_15S_MORE:
                        default:
                            break;
                    }
                case KEY_PRESSED_1S_LESS:
                case KEY_PRESSED_1S_TO_5S:
                default:
                    break;
            }
        }

        vesync_sleep(10);        // 按键扫描10ms一次
    }
}

/**
 * @brief 产测时，强制退出按键扫描任务
 */
void ls_button_task_exit(void)
{
    APP_LOG(LOG_DEBUG, "button disable \n");
    s_short_pressed_cnt = 0;
    s_task_run = false;
}

/**
* @brief 获取按键次数
* @return  uint8_t   按键短按次数
*/
uint8_t ls_get_button_cnt(void)
{
    return s_short_pressed_cnt;
}

/**
* @brief 设置当前按键次数
* @return  uint8_t   按键短按次数
*/
void ls_set_button_cnt(uint8_t cnt)
{
    s_short_pressed_cnt = cnt;
    if (s_short_pressed_cnt != 0)
    {
        ls_led_set_led((void*)s_scene_cnt[s_short_pressed_cnt - 1], LS_LED_ACT_SRC_BTN);
    }
}

/**
 * @brief ledstrip button初始化
 */
void ls_button_init(void)
{
        // 初始化触摸按键信号接入GPIO
    vhal_gpio_config_t button_io;
    button_io.pin_bit_mask = (1ULL << LEDSTRIP_BUTTON_GPIO_NUM);
    button_io.mode = GPIO_MODE_IN;
    button_io.pull_up_en = GPIO_PULLUP_EN;
    button_io.pull_down_en = GPIO_PULLDOWN_DIS;
    button_io.intr_type = GPIO_INTR_DIS;
    vhal_gpio_init(button_io);

    memset(&s_switch_key, 0, sizeof(s_switch_key));
    s_switch_key.key_set_scan_value = button_key_set_scan_value;
    if (VOS_OK != vesync_task_new(LEDSTRIP_BUTTON_TASK_NAME, NULL,
                    ls_button_task,
                    NULL,
                    LEDSTRIP_BUTTON_TASK_STACKSIZE,
                    LEDSTRIP_BUTTON_TASK_PRIO, NULL))
    {
        APP_LOG(LOG_ERROR, "button task create fail!!!\r\n");
    }
}

