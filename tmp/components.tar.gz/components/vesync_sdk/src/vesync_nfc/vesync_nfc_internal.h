/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
 * @file        vesync_nfc_internal.h
 * @brief       nfc模块内部定义
 * @date        2021-11-13
 */

#ifndef __VESYNC_NFC_INTERNAL_H__
#define __VESYNC_NFC_INTERNAL_H__

#include "vesync_frame.h"
#include "vesync_nfc.h"
#ifdef __cplusplus
extern "C"
{
#endif

#define VESYNC_NFC_PROTOCO_VERSION (2)
#define VESYNC_NFC_PROTOCO_HEAD_LEN (6)
#define VESYNC_NFC_PAYLOAD_MAX_LEN 400

/**
 * @brief NFC卡芯片定义
 */
typedef enum
{
    NFC_CARD_FM11NT081DX = 0,
    NFC_CARD_MAX
} VESYNC_NFC_CARD_MCU_E;

/*
 * @brief NFC配网过程使用到的opcode
 */
typedef enum
{
    NFC_OP_QUERY_INFO       = 0x8010,       // APP <-> device, 单向，设备信息
    NFC_OP_CONFIG_INFO      = 0x8012,       // APP <-> device, 双向，发送配网信息
    NFC_OP_NETCFG_RESULT    = 0x8013,       // device -> APP, 单向，设备配网结果上报
    NFC_OP_ERR_REPORT       = 0x8015,       // device -> APP, 单向，上报错误公共通道
}NFC_NETCFG_OPCODE_E;



/**
 * @brief NFC卡通信模式定义
 */
typedef enum
{
    NFC_CARD_MODE = 0,
    NFC_P2P_MODE = 1,
    NFC_MODE_MAX
} VESYNC_NFC_NETCFG_MODE_E;


/**
 * @brief NFC模块发送数据函数指针定义
 */
typedef uint32_t (*vesync_nfc_send_data_cb_t)(VESYNC_NFC_DATA_TYPE_E data_type, uint8_t *p_data, uint16_t len);


/**
 * @brief NFC启动/停止nfc通信回调定义
 */
typedef uint32_t (*vesync_nfc_start_stop_cb_t)(void);


#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_NFC_INTERNAL_H__ */
