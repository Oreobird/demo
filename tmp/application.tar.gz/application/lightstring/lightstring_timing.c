/**
*Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file    lightstring_timing.c
* @brief   倒计时接口
* @author  Lind
* @date     2021-12-20
*/

#include <string.h>
#include <stdio.h>

#include "vesync_common.h"
#include "vesync_log.h"
#include "vesync_timing.h"
#include "vesync_device.h"
#include "vesync_memory.h"

#include "lightstring.h"
#include "lightstring_timing.h"
#include "lightstring_report.h"
#include "lightstring_board.h"

static ls_timing_t s_ls_timing;       // 保存timer

/**
* @brief timer时间到时执行的动作
* @param[in]  uint16_t                 [timer id]
* @return     void                     [none]
*/
static void ls_timing_act(uint16_t id)
{
    ls_ev_t ev;
    memset(&ev, 0, sizeof(ls_ev_t));
    ev.act_src = LS_ACT_SRC_TIMER;
    if (s_ls_timing.mode == LS_MODE_OFF)
    {
        ev.id = LS_EV_OFF;
    }
    else
    {
        ev.id = LS_EV_ON;
        ev.param.mode_param.mode = s_ls_timing.mode;
        ev.param.mode_param.scene_id = s_ls_timing.scene_id;
    }
    ls_report_timing_exec(&s_ls_timing, APP_OK, STAT_CHG_RSN_TIMER_STR);
    ls_app_task_notify(&ev);
    ls_timing_remove(id);                         // 删除应用层数据
}

/**
* @brief 新增一个timer
* @param[in]   mode        [timer执行模式]
* @param[in]   total_sec   [timer定时时间]
* @param[out]  p_id        [timer id]
* @param[in]   scene_id    [场景id]
* @return     int          [APP_OK/APP_FAIL]
*/
int ls_timing_add(uint32_t total_sec, uint16_t *p_id, LS_MODE_E mode, uint8_t scene_id)

{
    int ret = -1;

    if (NULL == p_id || ( LS_MODE_OFF != mode && 0 == scene_id))
    {
        return APP_FAIL;
    }

    *p_id = LIGHTSTRING_TIMER_MIN_ID;

    if (0 != s_ls_timing.id)
    {
        APP_LOG(LOG_ERROR, "Timing is exist!\n");
        return APP_FAIL;
    }

    s_ls_timing.id = *p_id;
    s_ls_timing.mode = mode;
    s_ls_timing.total_sec = total_sec;
    s_ls_timing.scene_id = scene_id;

    ret = vesync_timing_add(s_ls_timing.id, total_sec);
    if (SDK_OK != ret)
    {
        return APP_FAIL;
    }

    return APP_OK;
}

/**
* @brief 获取timer执行的动作
*/
ls_timing_t *ls_timing_get_act(void)
{
    return &s_ls_timing;
}

/**
* @brief 删除一个timer
* @param[in]  uint16_t                 [timer id]
* @return     int_t                    [成功/失败]
*/
int ls_timing_remove(uint16_t timer_id)
{
    if (s_ls_timing.id != timer_id)
    {
        APP_LOG(LOG_ERROR, "Input ID is %d, not equal %d!\n", timer_id, s_ls_timing.id);
        return APP_FAIL;
    }

    // 从队列中删除
    vesync_timing_remove(timer_id);

    // 清除缓存
    memset((uint8_t *)&s_ls_timing, 0, sizeof(ls_timing_t));

    return APP_OK;
}

/**
* @brief 删除imer
*/
void ls_timing_clear(void)
{

    // 从队列中删除
    vesync_timing_clear();

    // 清除缓存
    memset((uint8_t *)&s_ls_timing, 0, sizeof(ls_timing_t));
}

/**
* @brief 初始化timer
* @param void
*/
void ls_timing_init(void)
{
    // 注册定时器动作回调
    vesync_timing_reg_cb(ls_timing_act);
}

