/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        lightstring_flash.h
 * @brief       lightstring flash读写
 * @author      Lind
 * @date        2021-12-20
 */

#ifndef __LIGHTSTRING_FLASH_H__
#define __LIGHTSTRING_FLASH_H__

#include "lightstring.h"

#ifdef __cplusplus
extern "C" {
#endif

#define LS_KLV_DATE_LEN             (60)              // klv 数据长度
#define LS_USER_CFG_KEY_DATA        "lightstring"     // NVS采用key:value格式进行存储
#define LSP_APP_DATA_VERSION    (1)              // APP数据的配置版本


/*
 * @brief 配置数据key 定义
 */
typedef enum
{
    LS_KEY_VERSION = 0,         //版本
    LS_KEY_STATUS,
    LS_KEY_MODEL,
    LS_KEY_TIMER_MODE,
    LS_KEY_SCENE_ID,
    LS_KEY_MUSIC_ID,
    LS_KEY_SPEED,
    LS_KEY_BRIGHTNESS,
    LS_KEY_VOICE_CTRL,
} LS_CFG_KEY_E;

/**
 * @brief 保存数据到flash
 * @param[in]  data                 [开关配置]
 * @return     int               [成功：APP_OK， 失败：APP_FAIL]
 */
int ls_save_config(ls_status_t data);

/**
 * @brief 从flash中读取数据到内存
 * @param[out] p_data               [开关配置]
 * @return     int               [成功：APP_OK， 失败：APP_FAIL]
 */
int ls_read_config(ls_status_t *p_data);

/**
 * @brief 清除配置
 * @return int          [成功：APP_OK， 失败：APP_FAIL]
 */
int ls_clear_config(void);

#ifdef __cplusplus
}
#endif

#endif

