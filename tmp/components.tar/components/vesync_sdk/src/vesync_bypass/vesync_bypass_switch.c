/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_bypass_switch.c
 * @brief       bypass处理接口
 * @date        2021-05-14
 */

#include "vesync_bypass_switch_internal.h"
#include "vesync_bypass_internal.h"

/**
 * @brief "setSwitch"  method数据解析
 * @param p_trace_msg trace message
 * @param json json数据指针
 * @return BYPASS_ERR_E
 */
static BYPASS_ERR_E bypass_method_set_switch_handle(bypass_trace_msg_t *p_trace_msg, cJSON *json)
{
    BYPASS_ERR_E ret = BP_OK;
    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_trace_msg, return BP_ERROR);

    bypass_switch_data_t *pSwitch = (bypass_switch_data_t *)vesync_malloc(sizeof(bypass_switch_data_t));
    if (NULL == pSwitch)
    {
        return BP_ERR_NOMEM;
    }

    memset(pSwitch, 0, sizeof(bypass_switch_data_t));
    //pSwitch->src_type = src_type;

    cJSON* json_data = cJSON_GetObjectItemCaseSensitive(json, "id");
    if(cJSON_IsNumber(json_data))
    {
        pSwitch->id = json_data->valueint & 0xFF;
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "enabled");
    if(cJSON_IsBool(json_data))
    {
        pSwitch->enable = json_data->valueint;
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    bypass_method_cb_t method_cb = get_method_callback_by_id(BYPASS_METHOD_ID_SET_SWITCH);
    if(method_cb)
    {
        method_cb(p_trace_msg, (void*)pSwitch, sizeof(bypass_switch_data_t));
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

_exit:
    free(pSwitch);

    return ret;
}

/**
 * @brief "getSwitch" method数据解析
 * @param p_trace_msg trace message
 * @param json数据指针
 * @return bypass_err_t
 */
static BYPASS_ERR_E bypass_method_get_switch_handle(bypass_trace_msg_t *p_trace_msg, cJSON *json)
{
    if((NULL == json)||(NULL == p_trace_msg))    return BP_ERROR;

    BYPASS_ERR_E ret = BP_OK;

    int *id_buf = (int*)malloc(sizeof(int));
    if(NULL == id_buf)
    {
        return BP_ERR_NOMEM;
    }

    cJSON* json_data = cJSON_GetObjectItemCaseSensitive(json, "id");
    if(cJSON_IsNumber(json_data))
    {
        *id_buf = json_data->valueint;
    }
    else
    {
        ret = BP_ERR_ARG;
        //vesync_bypass_pkg_err_msg(ret, p_trace_msg, BP_PARAM_ERR_CONV(id, BP_PARAM_TYPE_ERR));
        goto _exit;
    }

    bypass_method_cb_t method_cb = get_method_callback_by_id(BYPASS_METHOD_ID_GET_SWITCH);
    if(method_cb)
    {
        method_cb(p_trace_msg, (void*)id_buf, sizeof(int));
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

_exit:
    vesync_free(id_buf);
    return ret;
}


static bypass_item_data_t *method_tbl[] = {
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_SET_SWITCH, "setSwitch", bypass_method_set_switch_handle, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_GET_SWITCH, "getSwitch", bypass_method_get_switch_handle, NULL},
};

void vesync_bypass_switch_init(void)
{
    for (int i = 0; i < SIZEOF_ARRAY(method_tbl); i++)
    {
        bypass_item_t *item = vesync_bypass_init_item(&method_tbl[i]);
        if (item != NULL)
        {
            vesync_bypass_add_item(item);
        }
    }
}

