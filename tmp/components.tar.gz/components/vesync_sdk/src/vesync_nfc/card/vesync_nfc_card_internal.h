/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
 * @file        vesync_nfc_card_internal.h
 * @brief       nfc模块card模块内部定义
 * @date        2021-11-13
 */

#ifndef __VESYNC_NFC_CARD_INTERNAL_H__
#define __VESYNC_NFC_CARD_INTERNAL_H__

#include "vesync_nfc_card.h"

#ifdef __cplusplus
extern "C"
{
#endif

#define VESYNC_NFC_CARD_DEBUG  1

#if VESYNC_NFC_CARD_DEBUG
#define VESYNC_NFC_CARD_LOG SDK_LOG
#else
#define VESYNC_NFC_CARD_LOG  /##/ 
#endif


#define VESYNC_NFC_CARD_TASK_NAME "vesync_nfc_card_task"
#define VESYNC_NFC_CARD_TASK_STACK_SIZE 1024 * 4
#define VESYNC_NFC_CARD_TASK_PRIO 5

#define VESYNC_NFC_CARD_PWD_MAX_LEN 8

/**
 * @brief NFC读写EE方式配网状态定义
 */
typedef enum
{
    STATUS_NETCFG_IDLE = 0,    //空闲状态无配网任务
    STATUS_RFID_WRITE_DATA = 1, //RFID端进场上电，手机端写配网数据
    STATUS_WIFI_READ_DATA = 2,  //手机离开NFC卡,WIFI端读配网数据
    STATUS_MAX
} VHAL_NFC_EE_NETCFG_STATUS_E;

typedef struct
{
    uint32_t card_id;
    vesync_nfc_card_ctrl_t card_info;
    VHAL_NFC_EE_NETCFG_STATUS_E netcfg_status;
    uint16_t wait_cnt;
    uint8_t netcfg_started; //应用层启动了配网标志
} vesync_nfc_card_info_t;






#ifdef __cplusplus
}
#endif
#endif /* __VESYNC_NFC_CARD_INTERNAL_H__ */