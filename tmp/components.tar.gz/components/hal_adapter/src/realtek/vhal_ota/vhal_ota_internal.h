/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vhal_ota.h
 * @brief       amebaZ2的ota功能实现
 * @author      Dongri.Su
 * @date        2019-12-26
 */

#ifndef _VHAL_OTA_INTERNAL_H_
#define _VHAL_OTA_INTERNAL_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#include "vhal_ota.h"

#ifdef __cplusplus
extern "C"
{
#endif

#define MAX_URL_LEN             (256)
#define BUFFSIZE                4096


/*
 * @brief  OTA执行状态
 */
typedef struct
{
    int32_t header_len;                         // 固件头部长度
    VHAL_OTA_STATE_E status;                    // OTA升级状态
    bool timeout_flag;                          // OTA超时标志位
    mbedtls_md5_context *md5;                   // 存放md5计算中间值

    // 回调函数指针
    vhal_ota_status_cb_t status_cb;             // OTA状态更新回调函数
    vhal_ota_check_header_cb_t header_check_cb; // 固件头部校验（不包括md5）回调函数
    vhal_ota_check_md5_cb_t md5_check_cb;       // 固件头部md5与固件实际md5比较回调函数
} vhal_rtl_ota_status_t;



#ifdef __cplusplus
}
#endif

#endif /* _VHAL_OTA_INTERNAL_H_ */
