/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file    vesync_ca_cert.h
 * @brief   vesync平台证书文件
 * @author  Dongri.Su
 * @date    2019-07-22
 */

#ifndef __VESYNC_CA_CERT_H__
#define __VESYNC_CA_CERT_H__

//vesync平台证书文件数组
#if defined(CONFIG_IDF_TARGET_ESP32) || defined(CONFIG_IDF_TARGET_ESP8266)
extern const char vesync_mqtt_ca_cert_pem[]         asm("_binary_mqtt_ca_crt_start");
extern const char vesync_mqtt_client_cert_pem[]     asm("_binary_mqtt_client_crt_start");
extern const char vesync_mqtt_client_key_pem[]      asm("_binary_mqtt_client_key_start");

//中国区证书
extern const char vesync_cn_mqtt_ca_cert_pem[]         asm("_binary_mqtt_ca_cn_crt_start");
extern const char vesync_cn_mqtt_client_cert_pem[]     asm("_binary_mqtt_client_cn_crt_start");
extern const char vesync_cn_mqtt_client_key_pem[]      asm("_binary_mqtt_private_key_cn_pem_start");


#elif defined(CONFIG_TARGET_RTL8710CX) || defined(CONFIG_TARGET_RTL8720CF) || defined(CONFIG_IDF_TARGET_BL602)

extern const char vesync_mqtt_ca_cert_pem[];
extern const char vesync_mqtt_client_cert_pem[];
extern const char vesync_mqtt_client_key_pem[];

extern const char vesync_https_ca_cert_pem[];
extern const char vesync_https_client_cert_pem[];
extern const char vesync_https_client_key_pem[];

extern const char vesync_cn_mqtt_ca_cert_pem[];
extern const char vesync_cn_mqtt_client_cert_pem[];
extern const char vesync_cn_mqtt_client_key_pem[];


#endif

#endif // __VESYNC_CA_CERT_H__