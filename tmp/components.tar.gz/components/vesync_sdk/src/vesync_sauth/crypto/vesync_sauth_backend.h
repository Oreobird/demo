/**
 * Copyright © Vesync Technologies Co.Ltd. 2022. All rights reserved.
 * @file        vesync_sauth_backend.h
 * @brief       Vesync SAUTH模块的后端加密封装接口定义
 * @author      Herve
 * @date        2022-01-04
 */
#ifndef __VESYNC_SAUTH_BACKEND_H__
#define __VESYNC_SAUTH_BACKEND_H__

#include <stdint.h>
#include <stddef.h>

#include "vesync_sauth_crypto.h"

#ifdef __cplusplus
extern "C"
{
#endif

/**
 * @brief Micro-ECC模块初始化
 * @param[in]   p_ctx               [模块上下文]
 * @param[in]   rng_cb              [随机数生成回调]
 */
void micro_ecc_init(void *p_ctx, crypto_rnd_block_gen_cb_t rng_cb);

/**
 * @brief Micro-ECC生成公私密钥对
 * @param[in]   p_ctx               [模块上下文]
 * @param[out]  p_sk                [输出私钥]
 * @param[out]  p_pk                [输出公钥]
 * @return      int                 [成功返回0]
 */
int micro_ecc_keypair_gen(void *p_ctx, uint8_t *p_sk, uint8_t *p_pk);

/**
 * @brief Micro-ECC根据私钥计算公钥
 * @param[in]   p_ctx               [模块上下文]
 * @param[in]   p_sk                [输入私钥]
 * @param[out]  p_pk                [输出公钥]
 * @return      int                 [成功返回0]
 */
int micro_ecc_public_key_compute(void *p_ctx, uint8_t const *p_sk, uint8_t *p_pk);

/**
 * @brief Micro-ECC计算共享密钥
 * @param[in]   p_ctx               [模块上下文]
 * @param[in]   p_sk                [输入的甲方私钥]
 * @param[in]   p_pk                [输入的乙方公钥]
 * @param[out]  p_ss                [输出的共享密钥]
 * @return      int                 [成功返回0]
 */
int micro_ecc_shared_secret_compute(void *p_ctx, uint8_t const *p_sk, uint8_t const *p_pk, uint8_t *p_ss);

/**
 * @brief Micro-ECC对一段摘要进行签名
 * @param[in]   p_ctx               [模块上下文]
 * @param[in]   p_sk                [输入的私钥]
 * @param[in]   p_hash              [输入的摘要]
 * @param[out]  p_sig               [输出的签名值]
 * @return      int                 [成功返回0]
 */
int micro_ecc_sign(void *p_ctx, uint8_t const *p_sk, uint8_t const * p_hash, uint8_t *p_sig);

/**
 * @brief Micro-ECC对一段摘要以及它的签名进行校验
 * @param[in]   p_ctx               [模块上下文]
 * @param[in]   p_pk                [输入的公钥]
 * @param[in]   p_hash              [输入的摘要]
 * @param[out]  p_sig               [输出的签名值]
 * @return      int                 [成功返回0]
 */
int micro_ecc_verify(void *p_ctx, uint8_t const *p_pk, uint8_t const * p_hash, uint8_t const *p_sig);

/**
 * @brief Mbedtls x509 DER证书解析，不依赖Mbedtls X509模块的实现
 * @param[in]   crt                 [输入的DER证书]
 * @param[in]   crt_sz              [给定DER证书大小]
 * @param[in]   now                 [当前的GMT时间。如果为NULL，则不做有效期的校验]
 * @param[out]  parsed_crt          [输出的解析完成证书，注意该输出是对输入的DER Buffer的引用]
 * @return      int                 [CRYPTO_ERR_E]
 */
int mbedtls_crt_parse_der_compact(const unsigned char *raw_crt, size_t crt_sz, const sauth_crt_time_t *now, sauth_crt_t *parsed_crt);

/**
 * @brief Mbedtls x509 DER证书解析
 * @param[in]   crt                 [输入的DER证书]
 * @param[in]   crt_sz              [给定DER证书大小]
 * @param[in]   now                 [当前的GMT时间。如果为NULL，则不做有效期的校验]
 * @param[out]  parsed_crt          [输出的解析完成证书，注意该输出是对输入的DER Buffer的引用]
 * @return      int                 [CRYPTO_ERR_E]
 */
int mbedtls_crt_parse_der(const unsigned char *raw_crt, size_t crt_sz, const sauth_crt_time_t *now, sauth_crt_t *parsed_crt);

/**
 * @brief Mbedtls计算一段缓存的SHA-256哈希校验值
 * @param[in]   p_in                [指向输入的缓存]
 * @param[in]   in_len              [缓存长度]
 * @param[out]  p_out               [输出的哈希值缓存]
 * @return      int                 [CRYPTO_ERR_E]
 */
int mbedtls_sha256_port(uint8_t *p_in, uint32_t in_len, uint8_t *p_out);

/**
 * @brief Mbedtls基于HMAC-SHA256的进行密钥派生
 * @param[in]   key                 [输入的原始密钥材料]
 * @param[in]   key_len             [原始密钥材料长度]
 * @param[in]   salt                [可选的随机元salt]
 * @param[in]   salt_len            [随机数salt的长度]
 * @param[in]   info                [可选的随机元info]
 * @param[in]   info_len            [随机数info的长度]
 * @param[out]  out                 [输出密钥材料]
 * @param[in]   out_len             [输出密钥材料长度]
 * @return      int                 [CRYPTO_ERR_E]
 */
int mbedtls_sha256_hkdf(const uint8_t *key, uint8_t key_len,
                        const uint8_t *salt, uint8_t salt_len,
                        const uint8_t *info, uint16_t info_len,
                        uint8_t *out, uint8_t out_len);

/**
 * @brief Mbedtls CCM加密并返回校验值
 * @param[in]   key                 [加密密钥，必须是16字节]
 * @param[in]   iv                  [初始向量（nonce）]
 * @param[in]   iv_len              [初始向量的字节长度，必须是7,8,9,10,11,12或13]
 * @param[in]   add                 [额外数据]
 * @param[in]   add_len             [额外数据的字节长度]
 * @param[in]   in                  [输入的目标加密缓存]
 * @param[in]   in_len              [目标加密缓存的字节长度]
 * @param[out]  out                 [输出的加密完成数据缓存]
 * @param[out]  tag                 [输出的校验值缓存]
 * @param[in]   tag_len             [指定校验值的字节长度，必须是4,6,8,10,12,14或16]
 * @return      int                 [CRYPTO_ERR_E]
 */
int mbedtls_ccm_encrypt_and_tag_port(const uint8_t *key,
                                     const uint8_t *iv, size_t iv_len,
                                     const uint8_t *add, size_t add_len,
                                     const uint8_t *in, size_t in_len,
                                     uint8_t *out,
                                     uint8_t *tag, size_t tag_len);

/**
 * @brief Mbedtls CCM加密并校验
 * @param[in]   key                 [加密密钥，必须是16字节]
 * @param[in]   iv                  [初始向量（nonce）]
 * @param[in]   iv_len              [初始向量的字节长度，必须是7,8,9,10,11,12或13]
 * @param[in]   add                 [额外数据]
 * @param[in]   add_len             [额外数据的字节长度]
 * @param[in]   in                  [输入的目标解密缓存]
 * @param[in]   in_len              [目标解密缓存的字节长度]
 * @param[out]  out                 [输出的解密完成数据缓存]
 * @param[in]   tag                 [输入的校验值缓存]
 * @param[in]   tag_len             [指定校验值的字节长度，必须是4,6,8,10,12,14或16]
 * @return      int                 [CRYPTO_ERR_E]
 */
int mbedtls_ccm_auth_dencrypt_port(const uint8_t *key,
                                   const uint8_t *iv, size_t iv_len,
                                   const uint8_t *add, size_t add_len,
                                   const uint8_t *in, size_t in_len,
                                   uint8_t *out,
                                   const uint8_t *tag, size_t tag_len);

#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_SAUTH_BACKEND_H__ */
