/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_udp.h
 * @brief       局域网通信-UDP模块
 * @author      henrikzhou
 * @date        2020-9-21
 */

#ifndef _VESYNC_LAN_COMM_UDP_H_
#define _VESYNC_LAN_COMM_UDP_H_

#if defined(CONFIG_TARGET_LINUX)
#include <sys/types.h>
#include <sys/socket.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#else
#include "lwip/netif.h"
#include "lwip/tcpip.h"
#include "lwip/sockets.h"
#include "netif/etharp.h"
#endif

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief 初始化UDP socket
 * @param[in] addr      [udp socket 结构体地址]
 * @param[in] fd        [udp socket 句柄指针]
 * @param[in] port      [udp socket 端口]
 * @return int          [成功/失败]
 */
int  vesync_udp_init(struct sockaddr_in * addr, int* fd ,uint32_t port);

/**
 * @brief UDP 数据接收监听接口
 * @param[in] fd                [udp socket 句柄指针]
 * @param[in] timeout_ms        [udp server 数据接收监听超时时间，单位毫秒]
 * @param[out] buffer           [udp 数据接收缓存起始地址]
 * @param[in]  len              [数据接收缓存的最大长度]
 * @param[out]  addr            [存储远端udp socket 地址结构体指针]
 * @param[out]  socket_len      [存储远端udp socket 地址结构体长度指针]
 * @return int                  [成功/失败/实际接收数据长度]
 */
int  vesync_udp_recv(int fd,int timeout_ms,char*buffer,int len, struct sockaddr_in * addr,uint32_t * socket_len);

/**
 * @brief 关闭UDP socket
 * @param[in] fd             [udp 句柄指针]
 */
void vesync_udp_stop(int* fd);

#ifdef __cplusplus
}
#endif

#endif //_VESYNC_LAN_COMM_UDP_H_
