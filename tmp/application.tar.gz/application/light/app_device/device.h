/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
* @file         device.h
* @brief        设备业务处理
* @author       Joshua
* @date         2021-12-2
*/

#include <stdint.h>
#include <stdbool.h>
#include "vesync_device.h"
#include "flash.h"

#ifndef __APP_DEVICE_H__
#define __APP_DEVICE_H__

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief  设备配置
 */
typedef struct
{
    bool fade;          // 是否渐开/渐关
    bool voice_off;     // 第三方语音设置亮度为0，标志位（wwa认证需求）
    int white_status;   // 白灯状态
    int color_status;   // 彩灯状态
    int timing_cfg_len; // 倒计时配置数据长度
    void *timing_cfg;   // 倒计时配置指针
    flash_t *flash;
} dev_cfg_t;

/**
 * @brief 设备初始化
 * @return int              [成功：APP_OK，失败：APP_FAIL] 
 */
int app_device_init(void);

/**
 * @brief 设备反初始化 
 * @return int              [成功：APP_OK，失败：APP_FAIL]
 */
int app_device_deinit(void);

/**
 * @brief  保存设备配置
 * @param[in] *cfg          [设置配置]
 * @return int              [成功：APP_OK，失败：APP_FAIL]
 */
int app_device_cfg_save(dev_cfg_t *cfg);

/**
 * @brief 设备启动
 * @return int              [成功：APP_OK，失败：APP_FAIL]
 */
int app_device_startup(void);

/**
 * @brief  获取设备配置
 * @return dev_cfg_t *        [成功：设备配置指针，失败：NULL]
 */
dev_cfg_t *app_device_cfg_get(void);

/**
 * @brief  获取设备灯珠配置
 * @return uint16_t        [设备灯珠数量]
 */
uint16_t app_device_bead_num(void);


/**
 * @brief  获取设备工作模式
 * @return uint8_t        [设备工作模式]
 */
uint8_t app_device_work_mode(void);

#ifdef __cplusplus
}
#endif

#endif



