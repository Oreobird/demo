/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_timebase_event.c
 * @brief       Timebase模块事件相关实现
 * @author      Herve.Lin
 * @date        2021-07-15
 */
#include <stdio.h>
#include <string.h>

#include "vesync_timebase_private.h"
#include "vesync_log_internal.h"
#include "vesync_event_internal.h"
#include "vesync_net_service_internal.h"
#include "vesync_report.h"
#include "vesync_bypass.h"
#include "vesync_common.h"
#include "vesync_memory.h"

// 时基信息更新通知回调
static timebase_info_upd_ntf_cb_t s_info_upd_ntf_cb = NULL;

/**
 * @brief 网络就绪的时基请求回调
 * @param[in] p_data    [回调参数]
 * @return int          [SDK_OK; SDK_FAIL]
 */
static int network_ready_req_timebase_handle(void *p_data)
{
    UNUSED(p_data);

    // 网络就绪，请求一次全部时基信息。注意，以异步的方式请求。
    tb_req_upd_and_set_flag(TIMEBASE_JSON_TYPE_ALL);

    return SDK_OK;
}

/**
 * @brief 服务器时间戳请求后，可能的No-bypass消息的时间戳回应处理
 * @param[in] p_data    [可能的字符串数据]
 * @param[in] len       [字符串长度]
 * @return              [true：匹配到服务器时间戳；false：没有匹配到时间戳]
 */
static bool no_bypass_server_time_sync(char *p_data, int len)
{
    UNUSED(len);

    bool ret = false;

    cJSON *result = cJSON_Parse(p_data);
    if (!cJSON_IsObject(result))
    {
        SDK_LOG(LOG_ERROR, "invalid JSON string\n");
    }
    else
    {
        cJSON *json_data = NULL;
        // 处理校时回应，校时回应需要尽可能快地进行处理
        json_data = cJSON_GetObjectItemCaseSensitive(result, "serverTimstamp");
        if (cJSON_IsNumber(json_data))
        {
            uint32_t ts = json_data->valueint;
            tb_check_or_update_server_ts(ts);
            ret = true;
        }
    }

    cJSON_Delete(result);
    return ret;
}

/**
 * @brief 时基更新请求后，可能的No-bypass消息的时基回应处理
 * @param[in] p_data    [可能的字符串数据]
 * @param[in] len       [字符串长度]
 */
static void no_bypass_tb_info_upd(char *p_data, int len)
{
    char **msg_buf = tb_get_no_bp_msg_buf_ptr_ref();

    // 检查是不是已经有要处理的No-bypass数据
    if (NULL == *msg_buf)
    {
        *msg_buf = vesync_malloc(len + 1);
        if (NULL != *msg_buf)
        {
            snprintf((char *)*msg_buf, len + 1, "%s", p_data);
        }
        else
        {
            SDK_LOG(LOG_ERROR, "tb_info buffer malloc fail\n");
        }
    }
}

/**
 * @brief Non-bypass回调处理函数，会拷贝完数据后以异步的方式更新时基
 * @param[in] p_data [no-bypass消息]
 */
static void non_bypass_timebase_handle_cb(void *p_data)
{
    VCOM_NULL_PARAM_CHK(p_data, return);

    int data_len = strlen(p_data);

    if (data_len > 0 && data_len < TIMEBASE_NO_BYPASS_MSG_MAX_STR_LEN)
    {
        // 匹配到服务器时间戳就不作Timebase Info的匹配
        if (no_bypass_server_time_sync((char *)p_data, data_len))
        {
            return;
        }

        no_bypass_tb_info_upd((char *)p_data, data_len);
    }
}

/**
 * @brief Timebase内部函数，订阅Timebase模块依赖的事件
 */
void tb_ev_subscribe_all(void)
{
    // Non-bypass消息事件回调，处理可能的Update Timebase回应
    vesync_net_reg_non_bypass_recv_cb(non_bypass_timebase_handle_cb);
    // 云端网络就绪，请求时基信息回调
    vesync_event_subscribe(EVENT_NWK_READY, SUB_ID_TIMEBASE, network_ready_req_timebase_handle);
}

/**
 * @brief Timebase模块时基信息更新请求处理回调
 * @param req_type  [请求的时基类型]
 * @return int      [TMBS_RESULT_E]
 */
int tb_ev_req_upd_tb_info_cb(TMBS_INFO_TYPE_E req_type)
{
    SDK_LOG(LOG_INFO, "request update timebase. req_type:[%d]\n", req_type);

    switch (req_type)
    {
        case TMBS_ALL:
            vesync_report_get_user_timebase_info(TIMEBASE_JSON_TYPE_ALL);
            break;
        case TMBS_TZ:
            vesync_report_get_user_timebase_info(TIMEBASE_JSON_TYPE_TZ_INFO);
            break;
        case TMBS_SUNTIME:
            vesync_report_get_user_timebase_info(TIMEBASE_JSON_TYPE_SUN_INFO);
            break;
        case TMBS_DST:
            vesync_report_get_user_timebase_info(TIMEBASE_JSON_TYPE_DST_INFO);
            break;
        default:
            break;
    }

    return TMBS_OK;
}

/**
 * @brief Timebase模块请求服务器同步时间回调
 * @return int      [TMBS_RESULT_E]
 */
int tb_ev_req_sync_ts_cb(void)
{
    vesync_report_sync_server_timestamp();

    return TMBS_OK;
}

int tb_ev_no_bp_tb_info_parse_cb(char *json_str, vesync_timebase_t *p_tb)
{
    int ret = TMBS_OK;

    cJSON *result = cJSON_Parse((char *)json_str);
    if (!cJSON_IsObject(result))
    {
        SDK_LOG(LOG_ERROR, "invalid JSON string\n");

        ret = TMBS_ERR;
        goto EXIT;
    }

    TMBS_INFO_TYPE_E type = TMBS_NONE;
    ret = vesync_timebase_bp_tb_info_parse(result, &type, p_tb);
    if (ret != TMBS_OK)
    {
        goto EXIT;
    }
    if (s_info_upd_ntf_cb != NULL)
    {
        s_info_upd_ntf_cb(type);
    }
    SDK_LOG(LOG_INFO, "timebase update success\n");

EXIT:
    cJSON_Delete(result);
    return ret;
}

void vesync_timebase_reg_info_upd_cb(timebase_info_upd_ntf_cb_t cb)
{
    s_info_upd_ntf_cb = cb;
}

timebase_info_upd_ntf_cb_t vesync_timebase_get_reg_info_upd_cb(void)
{
    return s_info_upd_ntf_cb;
}

int vesync_timebase_bp_tb_info_parse(cJSON *json, TMBS_INFO_TYPE_E *p_type, vesync_timebase_t *p_tb)
{
    if (NULL == json || NULL == p_type)
    {
        return TMBS_ERR;
    }

    int ret = TMBS_OK;
    cJSON *json_data = NULL;

    json_data = cJSON_GetObjectItemCaseSensitive(json, "type");
    if (!cJSON_IsNumber(json_data))
    {
        SDK_LOG(LOG_WARN, "parse type error\n");

        ret = TMBS_ERR;
        goto EXIT;
    }
    int type = json_data->valueint;
    switch (type)
    {
    case TIMEBASE_JSON_TYPE_ALL:
        *p_type = TMBS_ALL;
        break;
    case TIMEBASE_JSON_TYPE_TZ_INFO:
        *p_type = TMBS_TZ;
        break;
    case TIMEBASE_JSON_TYPE_SUN_INFO:
        *p_type = TMBS_SUNTIME;
        break;
    case TIMEBASE_JSON_TYPE_DST_INFO:
        *p_type = TMBS_DST;
        break;
    default:
        ret = TMBS_ERR;
        goto EXIT;
    }

    if (TMBS_ALL == *p_type || TMBS_TZ == *p_type)
    {
        json_data = cJSON_GetObjectItemCaseSensitive(cJSON_GetObjectItemCaseSensitive(json, "tzInfo"), "zoneStr");
        if (cJSON_IsString(json_data))
        {
            snprintf((char *)p_tb->tz_info.timezone_str, TIMEBASE_TZ_STR_LENGTH, "%s", json_data->valuestring);
        }
        json_data = cJSON_GetObjectItemCaseSensitive(cJSON_GetObjectItemCaseSensitive(json, "tzInfo"), "ofsSec");
        p_tb->tz_info.timezone_ofs_sec = cJSON_IsNumber(json_data) ? (int32_t)json_data->valueint : p_tb->tz_info.timezone_ofs_sec;
    }
    if (TMBS_ALL == *p_type || TMBS_SUNTIME == *p_type)
    {
        json_data = cJSON_GetObjectItemCaseSensitive(cJSON_GetObjectItemCaseSensitive(cJSON_GetObjectItemCaseSensitive(json, "sunRSInfo"), "loc"), "lng");
        p_tb->sun_rs_info.longitude = cJSON_IsNumber(json_data) ? (int32_t)json_data->valueint : p_tb->sun_rs_info.longitude;
        json_data = cJSON_GetObjectItemCaseSensitive(cJSON_GetObjectItemCaseSensitive(cJSON_GetObjectItemCaseSensitive(json, "sunRSInfo"), "loc"), "lat");
        p_tb->sun_rs_info.latitude = cJSON_IsNumber(json_data) ? (int32_t)json_data->valueint : p_tb->sun_rs_info.latitude;
        json_data = cJSON_GetObjectItemCaseSensitive(cJSON_GetObjectItemCaseSensitive(cJSON_GetObjectItemCaseSensitive(json, "sunRSInfo"), "loc"), "alt");
        p_tb->sun_rs_info.altitude = cJSON_IsNumber(json_data) ? (int32_t)json_data->valueint : p_tb->sun_rs_info.altitude;
        json_data = cJSON_GetObjectItemCaseSensitive(cJSON_GetObjectItemCaseSensitive(cJSON_GetObjectItemCaseSensitive(json, "sunRSInfo"), "sunTime"), "riseUTC");
        p_tb->sun_rs_info.sun_rise_utc = cJSON_IsNumber(json_data) ? (uint32_t)json_data->valueint : p_tb->sun_rs_info.sun_rise_utc;
        json_data = cJSON_GetObjectItemCaseSensitive(cJSON_GetObjectItemCaseSensitive(cJSON_GetObjectItemCaseSensitive(json, "sunRSInfo"), "sunTime"), "setUTC");
        p_tb->sun_rs_info.sun_set_utc = cJSON_IsNumber(json_data) ? (uint32_t)json_data->valueint : p_tb->sun_rs_info.sun_set_utc;
    }
    if (TMBS_ALL == *p_type || TMBS_DST == *p_type)
    {
        json_data = cJSON_GetObjectItemCaseSensitive(cJSON_GetObjectItemCaseSensitive(json, "dstInfo"), "enabled");
        p_tb->dst_info.enabled = cJSON_IsBool(json_data) ? (bool)json_data->valueint : p_tb->dst_info.enabled;
        json_data = cJSON_GetObjectItemCaseSensitive(cJSON_GetObjectItemCaseSensitive(json, "dstInfo"), "curOfsSec");
        p_tb->dst_info.cur_ofs_sec = cJSON_IsNumber(json_data) ? (int32_t)json_data->valueint : p_tb->dst_info.cur_ofs_sec;
        json_data = cJSON_GetObjectItemCaseSensitive(cJSON_GetObjectItemCaseSensitive(json, "dstInfo"), "dstSwUTC");
        p_tb->dst_info.dst_sw_utc = cJSON_IsNumber(json_data) ? (uint32_t)json_data->valueint : p_tb->dst_info.dst_sw_utc;
        json_data = cJSON_GetObjectItemCaseSensitive(cJSON_GetObjectItemCaseSensitive(json, "dstInfo"), "nextOfsSec");
        p_tb->dst_info.next_ofs_sec = cJSON_IsNumber(json_data) ? (int32_t)json_data->valueint : p_tb->dst_info.next_ofs_sec;
    }

EXIT:
    return ret;
}