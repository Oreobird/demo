/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_device_internal.h
 * @brief       设备初始化、配置属性及操作接口
 * @date        2021-05-06
 */

#ifndef __VESYNC_DEVICE_INTERNAL_H__
#define __VESYNC_DEVICE_INTERNAL_H__

#include <stdint.h>
#include "vesync_cfg.h"
#include "vesync_device.h"

#ifdef __cplusplus
extern "C" {
#endif

#define DEVICE_PID_LEN      (16)      // pid长度
#define DEVICE_CID_LEN      (32)      // cid长度



#define VESYNC_DEFAULT_FW_VER               "1.0"       // 固件默认版本
#define VESYNC_WIFI_DEFAULT_FLUGIN_NAME     "mainFw"    // Wi-Fi固件默认plugin name
#define VESYNC_BLE_DEFAULT_FLUGIN_NAME      "bleFw"     // BLE固件默认plugin name
#define VESYNC_MCU_DEFAULT_FLUGIN_NAME      "mcuFw"     // MCU固件默认plugin name
#define VESYNC_MCU2_DEFAULT_FLUGIN_NAME     "mcuFw"     // MCU固件默认plugin name
#define VESYNC_MCU3_DEFAULT_FLUGIN_NAME     "mcuFw"     // MCU固件默认plugin name


#define USER_CFG_KEY_CID                    "cfg_cid"                   // CID
#define USER_CFG_KEY_DBG_CONFIG             "dbg_flag"                  // 调试标志位，详见DEBUG_CONFIG_S结构体定义

/*
* @brief 设备信息结构体
*/
typedef struct
{
    char cid[DEVICE_CID_LEN + 4]; // 存储cid
    char account_id[ACCOUNT_ID_STR_LEN + 4]; //account id
    uint8_t total_ota_num; // 设备可以进行OTA的固件个数
    vesync_device_clear_data_cb_t dev_clear_data_cb;
    dev_fw_info_t fw_info[0]; // 存储Wi-Fi/MCU/BLE固件信息
} vesync_dev_t;


#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_DEVICE_INTERNAL_H__ */

