/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file    vhal_ble_internal.h
 * @brief   蓝牙hal命令通信服务
 * @date    2021-09-03
 */

#ifndef __VHAL_BLE_INTERNAL_H__
#define __VHAL_BLE_INTERNAL_H__

#include <profile_server.h>

#ifdef __cplusplus
extern "C"
{
#endif


#define ATT_OPCODE_HANDLE_LEN   (3)     // 3是蓝牙协议att层数据包的头opcode+handle
#define BLE_SEND_LENTH_DEFAULT  (20)    // 蓝牙一般最大发送长度默认值
#define CONN_ID_INVALID         (0XFF)

#define BLE_SEND_SEMAPHORE_MAX_CNT  (10)
#define MAX_NUMBER_OF_GAP_MESSAGE   (0x20)      // !<  GAP message queue size
#define MAX_NUMBER_OF_IO_MESSAGE    (0x20)      // !<  IO message queue size
#define MAX_NUMBER_OF_EVENT_MESSAGE (MAX_NUMBER_OF_GAP_MESSAGE + MAX_NUMBER_OF_IO_MESSAGE) //!< Event message queue size

#define BLE_MAX_LINKS       (1)     // 蓝牙协议栈最大支持链路
#define BLE_SERVICE_ADD_NUM (2)     // 注册蓝牙服务的个数

#define ADV_NAME_MAX_LEN (GAP_MAX_ADV_LEN - 2)

/* @brief  Default minimum advertising interval when device is discoverable (units of 625us, 160=100ms) */
#define DEFAULT_ADVERTISING_INTERVAL_MIN    (320)
/* @brief  Default Maximum advertising interval */
#define DEFAULT_ADVERTISING_INTERVAL_MAX    (400)

/**
 * @brief 返回给应用的写消息
 */
typedef struct
{
    uint8_t write_index;
    T_WRITE_TYPE write_type;
    uint16_t len;
    uint8_t *p_value;
} vhal_ble_service_msg_write_t;

/**
 * @brief 设置cccd消息
 */
typedef struct
{
    uint8_t cccd_index; // !< ref: @ref SIMP_Service_Notify_Indicate_Info
    uint16_t cccd_val;
}vhal_ble_service_msg_cccd_t;


/**
 * @brief 返回给应用层的消息
 */
typedef union
{
    vhal_ble_service_msg_cccd_t cccd;
    uint8_t read_value_index; // !< ref: @ref SIMP_Service_Read_Info
    vhal_ble_service_msg_write_t write;
}vhal_ble_service_msg_data_t;

/**
 * @brief 通过回调给应用层返回的数据
 */
typedef struct
{
    uint8_t conn_id;
    T_SERVICE_CALLBACK_TYPE msg_type;
    vhal_ble_service_msg_data_t msg_data;
}vhal_ble_service_cb_data_t;


/**
 * @brief 数据类型
 */
typedef enum
{
    VHAL_BLE_DATA_TYPE_CMD_SEND,
    VHAL_BLE_DATA_TYPE_CMD_RECV,
    VHAL_BLE_DATA_TYPE_NET_CFG_SEND,
    VHAL_BLE_DATA_TYPE_NET_CFG_RECV
}VHAL_BLE_DATA_TYPE_E;


/**
 * @brief ble运行过程的一些状态
 */
typedef struct{
    bool init_flag;
    bool stack_inited;
    bool adv_started;
    uint8_t conn_id;
} vhal_ble_status_t;


#ifdef __cplusplus
}
#endif

#endif  /* __VHAL_BLE_INTERNAL_H__ */
