/**
* Copyright © Vesync Technologies Co.Ltd. 2022. All rights reserved
* @file         segment.h
* @brief        分段场景
* @author       Joshua
* @date         2022-2-11
*/

#include <stdint.h>
#include "vesync_common.h"
#include "scene.h"

#ifndef __SEGMENT_H__
#define __SEGMENT_H__

#ifdef __cplusplus
extern "C" {
#endif


/**
 * @brief  分段开场景灯效实现初始化
 * @return int              [成功：APP_OK， 失败：APP_FAIL]
 */
int segment_on_light_scene_impl_init(void);

/**
 * @brief  注册分段开场景灯效
 * @return  int             [成功：APP_OK，失败：APP_FAIL]
 */
int segment_on_light_scene_reg(light_scene_t *light_scene);

/**
 * @brief  注销分段开场景灯效
 * @param[in] id            [场景ID]
 * @return  int             [成功：APP_OK，失败：APP_FAIL]
 */
int segment_on_light_scene_unreg(int id);

/**
 * @brief  分段关场景灯效实现初始化
 * @return int              [成功：APP_OK， 失败：APP_FAIL]
 */
int segment_off_light_scene_impl_init(void);

/**
 * @brief  注册分段关场景灯效
 * @return  int             [成功：APP_OK，失败：APP_FAIL]
 */
int segment_off_light_scene_reg(light_scene_t *light_scene);

/**
 * @brief  注销分段关场景灯效
 * @param[in] id            [场景ID]
 * @return  int             [成功：APP_OK，失败：APP_FAIL]
 */
int segment_off_light_scene_unreg(int id);


#ifdef __cplusplus
}
#endif

#endif





