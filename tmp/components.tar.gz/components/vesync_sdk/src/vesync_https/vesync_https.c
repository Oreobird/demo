/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_https.c
 * @brief       https模块
 * @author      CharlesMei
 * @date        2021-05-24
 */

#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <netdb.h>
#include <sys/socket.h>

#include "vesync_memory.h"
#include "vhal_wifi.h"
#include "vesync_https_private.h"


static const char *HTTPS_REQUEST = "%s " "%s" " HTTP/1.1\r\n"
                                   "Host: %s \r\n"
                                   "Accept: */*\r\n"
                                   "Content-Type:application/json\r\n"
                                   "%s"
                                   "Content-Length:%d\r\n"
                                   "\r\n"
                                   "%s";

static const char* KEEPALIVE_STRING = "Connection:keep-alive\r\n"
                                      "Keep-Alive:150\r\n";

static const char* ANTI_KEEPALIVE_STRING = "Connection:close\r\n";

static vhttps_tls_cfg_t s_tls_cfg;
static vhttps_cli_t s_vhttps_cli;

/**
 * @brief 十六进制字符串转十六进制
 * @param[in]  hex_str          [十六进制字符串]
 * @return  uint32_t            [十六进制值]
 */
static uint32_t hex_str_to_hex(char *ver)
{
    uint32_t result = 0;
    uint8_t temp = 0;

    do
    {
        temp = *ver;
        if ((temp <= '9') && (temp >= '0'))
        {
            temp = temp - 0x30;
        }
        else if ((temp <= 'f') && (temp >= 'a'))
        {
            temp = temp - 0x37;
        }
        else if ((temp <= 'F') && (temp >= 'A'))
        {
            temp = temp - 0x57;
        }
        else
        {
            HTTPS_LOG(LOG_ERROR, "hex string is illegal...\n");
            break;
        }
        result = result << 4;
        temp = temp & 0x0F ;
        result = result | temp;

    }
    while (*(++ver));

    return result;
}


/**
 * @brief           从http的URL中提取host和port
 * @param[in]       url         [入参，完整的URL]
 * @return          int         [成功/失败]
 */
 static int vesync_https_parse_url(const char *url)
{
    char *ptr1 = (char *)url;
    char *ptr2 = NULL;
    int len = 0;

    // 删除"http://"
    if (0 == strncmp(ptr1, "https://", strlen("https://")))
    {
        ptr1 += strlen("https://");
    }
    else
    {
        return VERR_FAIL;
    }

    // 提取path
    ptr2 = strchr(ptr1, '/');    // 查找第一个‘/’所在位置
    if (ptr2)
    {
        len = strlen(ptr1) - strlen(ptr2);
        if (len >= HTTPS_HOST_LEN)
        {
            HTTPS_LOG(LOG_WARN, "https host is too long\r\n");
            return VERR_FAIL;
        }

        if (*(ptr2 + 1))
        {
            if (strlen(ptr2) >= HTTPS_PATH_LEN)
            {
                HTTPS_LOG(LOG_WARN, "https path is too long\r\n");
                return VERR_FAIL;
            }
            memcpy(s_vhttps_cli.path, ptr2, strlen(ptr2));
            s_vhttps_cli.path[strlen(ptr2)] = '\0';
        }
        else
        {
            memcpy(s_vhttps_cli.path, "/", 1);
            *(s_vhttps_cli.path + 1) = '\0';
        }
        HTTPS_LOG(LOG_DEBUG, "https path: %s\n", s_vhttps_cli.path);
    }
    else
    {
        len = strlen(ptr1);
        if (len >= HTTPS_HOST_LEN)
        {
            HTTPS_LOG(LOG_WARN, "https host is too long\r\n");
            return VERR_FAIL;
        }
    }

    // 提取host
    memcpy(s_vhttps_cli.host, ptr1, len);
    s_vhttps_cli.host[len] = '\0';
    HTTPS_LOG(LOG_DEBUG, "http host: %s\n", s_vhttps_cli.host);

    // 提取port
    ptr2 = strchr(s_vhttps_cli.host, ':');
    if (ptr2)
    {
        *ptr2++ = '\0';
        if (atoi(ptr2) > 0xffff)
        {
            HTTPS_LOG(LOG_WARN, "https port is too large\r\n");
            return VERR_FAIL;
        }
        s_vhttps_cli.port = atoi(ptr2);
    }
    HTTPS_LOG(LOG_DEBUG, "https port: %d\n", s_vhttps_cli.port);

    return VERR_OK;
}

/**
 * @brief  从https的响应中提取消息内容
 * @param[in]  p_buf             [输入为接收到的消息]
 * @param[in]  keep_head         [返回的数据内容是否保留头部]
 * @param[in,out]  p_buf_len     [输入为收到的数据长度，如果keep_head为false，则输出长度为内容长度]
 * @param[out]  head_offset      [头部偏移]
 * @param[out]  p_ct_len         [http头部中Content-Length的值]
 * @return  int                  [成功：VERR_OK，失败：VERR_FAIL]
 */
static int vesync_https_parse_head(char *p_buf, bool keep_head, int *p_buf_len, int *head_offset, int *p_ctx_len)
{
    char *p_tmp = NULL;
    int head_len = 0;

    /* 接收到的消息格式如下：
    HTTP/1.1 200 OK
    Accept-Ranges: bytes
    Content-Length: 10363
    Content-Type: text/plain; charset=utf-8
    Last-Modified: Wed, 18 Sep 2019 12:04:16 GMT
    Date: Thu, 19 Sep 2019 07:12:02 GMT

    */
    p_tmp = (char*)strstr(p_buf, "HTTP/1.1");
    if (!p_tmp)
    {
        HTTPS_LOG(LOG_ERROR,"http/1.1 not find\n");
        return VERR_FAIL;
    }

    if (atoi(p_tmp + 9) != 200)
    {
        HTTPS_LOG(LOG_ERROR, "result:\n%s\n", p_buf);
        return VERR_FAIL;
    }

    p_tmp = (char *)strstr(p_buf, "Transfer-Encoding: chunked");
    if (p_tmp)
    {
        s_vhttps_cli.is_chunked = true;
    }
    else
    {
        s_vhttps_cli.is_chunked = false;
        p_tmp = (char *)strstr(p_buf, "Content-Length:");   // 内容长度
        if (!p_tmp)
        {
            HTTPS_LOG(LOG_ERROR, "http header does not contain Content-Length!!\n");
            return VERR_FAIL;
        }
        else
        {
            *p_ctx_len = atoi(p_tmp + strlen("Content-Length:") + 1);   // 有一个空格
        }
    }

    p_tmp = (char*)strstr(p_buf,"\r\n\r\n");
    if (!p_tmp)
    {
        HTTPS_LOG(LOG_ERROR, "Not found the end of http head!\n");
        return VERR_FAIL;
    }

    p_tmp = p_tmp + 4;    //指针偏移到内容
    head_len = p_tmp - p_buf;
    HTTPS_LOG(LOG_DEBUG, "head_len = %d\n", head_len);

    if (head_len > *p_buf_len)
    {
        HTTPS_LOG(LOG_ERROR, " http head err!\n");
        return VERR_FAIL;
    }

    *head_offset = (keep_head == true) ? 0 : head_len;
    *p_buf_len -= *head_offset;

    return VERR_OK;
}

/**
 * @brief        mbedtls 释放空间
 */
static void vesync_https_cli_ssl_deinit(void)
{
    mbedtls_net_free(&s_tls_cfg.server_fd);
    mbedtls_x509_crt_free(&s_tls_cfg.cacert);
    mbedtls_ssl_config_free(&s_tls_cfg.ssl_conf);
    mbedtls_ctr_drbg_free(&s_tls_cfg.ctr_drbg);
    mbedtls_entropy_free(&s_tls_cfg.entropy);

    //双向认证 - client认证
    mbedtls_x509_crt_free(&s_tls_cfg.client_cert);
    mbedtls_pk_free(&s_tls_cfg.pk_ctx);

    mbedtls_ssl_free(&s_tls_cfg.ssl_context);

    VESYNC_PRINTF_FREE_HEAP();
}

/**
 * @brief         初始化mbedtls模块
 * @param[in]     config        [初始化配置，详见vesync_https_client_config_t]
 * @return        int           [成功或失败]
 */
static int vesync_https_cli_ssl_init(vesync_https_cli_cfg_t *config)
{
    int ret = VERR_FAIL;
    char port_string[8];

    memset(&s_tls_cfg, 0, sizeof(s_tls_cfg));
    memset(port_string, 0, sizeof(port_string));

    mbedtls_ssl_init(&s_tls_cfg.ssl_context);
    mbedtls_x509_crt_init(&s_tls_cfg.cacert);

    //双向认证 -- client认证
    mbedtls_x509_crt_init(&s_tls_cfg.client_cert);
    mbedtls_pk_init( &s_tls_cfg.pk_ctx );

    mbedtls_ctr_drbg_init(&s_tls_cfg.ctr_drbg);
    mbedtls_ssl_config_init(&s_tls_cfg.ssl_conf);
    mbedtls_entropy_init(&s_tls_cfg.entropy);

    HTTPS_LOG(LOG_DEBUG, "Seeding the random number generator\n");

    ret = mbedtls_ctr_drbg_seed(&s_tls_cfg.ctr_drbg, mbedtls_entropy_func, &s_tls_cfg.entropy, NULL, 0);
    if (ret != 0)
    {
        HTTPS_LOG(LOG_ERROR, "mbedtls_ctr_drbg_seed returned %d\n", ret);
        goto exit;
    }

    //CA认证 -- CA证书
    HTTPS_LOG(LOG_DEBUG, "Loading the CA root certificate...\n");

    if ((NULL != config->ca_pem) && (strlen(config->ca_pem) != 0 ))
    {
        HTTPS_LOG(LOG_DEBUG,"ca_pem [%p] len: %d\n", config->ca_pem, strlen(config->ca_pem));
        ret = mbedtls_x509_crt_parse(&s_tls_cfg.cacert, (const unsigned char*)config->ca_pem, strlen(config->ca_pem) + 1);
        if (ret < 0)
        {
            HTTPS_LOG(LOG_ERROR, "mbedtls_x509_crt_parse returned -0x%x\n\n", -ret);
            goto exit;
        }
    }

     HTTPS_LOG(LOG_DEBUG, "Setting hostname for TLS session...\n");
    /* Hostname set here should match CN in server certificate */
    ret = mbedtls_ssl_set_hostname(&s_tls_cfg.ssl_context, s_vhttps_cli.host);
    if (ret != 0)
    {
        HTTPS_LOG(LOG_ERROR, "mbedtls_ssl_set_hostname returned -0x%x\n", -ret);
        goto exit;
    }

    HTTPS_LOG(LOG_DEBUG, "Setting up the SSL/TLS structure...\n");
    ret = mbedtls_ssl_config_defaults(&s_tls_cfg.ssl_conf,
                                      MBEDTLS_SSL_IS_CLIENT,
                                      MBEDTLS_SSL_TRANSPORT_STREAM,
                                      MBEDTLS_SSL_PRESET_DEFAULT);
    if (ret != 0)
    {
        HTTPS_LOG(LOG_ERROR, "mbedtls_ssl_config_defaults returned %d\n", ret);
        goto exit;
    }

    /**********************************************************************************
       MBEDTLS_SSL_VERIFY_OPTIONAL is bad for security, in this example it will print
       a warning if CA verification fails but it will continue to connect.
       You should consider using MBEDTLS_SSL_VERIFY_REQUIRED in your own code.
    ***********************************************************************************/
    mbedtls_ssl_conf_authmode(&s_tls_cfg.ssl_conf, MBEDTLS_SSL_VERIFY_REQUIRED);
    //服务器认证
    mbedtls_ssl_conf_ca_chain(&s_tls_cfg.ssl_conf, &s_tls_cfg.cacert, NULL);

    //双向认证 -- client证书
    if ((NULL != config->client_pem) && (strlen(config->client_pem) != 0)
        && (NULL != config->client_key) && (strlen(config->client_key) != 0))
    {
        ret = mbedtls_x509_crt_parse(&s_tls_cfg.client_cert, (const unsigned char *)config->client_pem, strlen(config->client_pem) + 1);
        if (ret != 0)
        {
            HTTPS_LOG(LOG_ERROR, " failed\n  !  mbedtls_x509_crt_parse returned -0x%x\n\n", -ret);
            goto exit;
        }

        ret = mbedtls_pk_parse_key(&s_tls_cfg.pk_ctx, (const unsigned char *)config->client_key, strlen(config->client_key) + 1, NULL, 0);
        if ( ret != 0)
        {
            HTTPS_LOG(LOG_ERROR, " failed\n  !  mbedtls_pk_parse_key returned -0x%x\n\n", -ret);
            goto exit;
        }

        HTTPS_LOG(LOG_DEBUG, "mbedtls_ssl_conf_own_cert config client_cert...\n");
        if ((ret = mbedtls_ssl_conf_own_cert(&s_tls_cfg.ssl_conf, &s_tls_cfg.client_cert, &s_tls_cfg.pk_ctx)) != 0)
        {
            HTTPS_LOG(LOG_ERROR," failed\n  ! mbedtls_ssl_conf_own_cert returned %d\n\n", ret);
            goto exit;
        }
    }

    mbedtls_ssl_conf_rng(&s_tls_cfg.ssl_conf, mbedtls_ctr_drbg_random, &s_tls_cfg.ctr_drbg);

    ret = mbedtls_ssl_setup(&s_tls_cfg.ssl_context, &s_tls_cfg.ssl_conf);
    if (ret != 0)
    {
        HTTPS_LOG(LOG_ERROR, "mbedtls_ssl_setup returned -0x%x\n\n", -ret);
        mbedtls_ssl_session_reset(&s_tls_cfg.ssl_context);
        goto exit;
    }

    return VERR_OK;

exit:
    vesync_https_cli_ssl_deinit();
    return VERR_FAIL;
}



/**
 * @brief         https客户端连接服务
 * @return        int           [成功：SDK_OK，失败：SDK_FAIL]
 */
int vesync_https_cli_connect(void)
{
    int ret = -1;
    char port_string[8] = {0};

    // 判断Wi-Fi网络是否连接成功
    HTTPS_LOG(LOG_INFO, "Waiting for Wi-Fi connected...\n");
    if (!vhal_wifi_get_link_status((int)HTTPS_WAIT_TIME_MS))
    {
        HTTPS_LOG(LOG_ERROR, "Network was disconnect!\n");
        return VERR_FAIL;
    }

    HTTPS_LOG(LOG_INFO, "Wi-Fi connected.\n");

    // 建立连接
    mbedtls_net_init(&s_tls_cfg.server_fd);
    memset(port_string, 0, sizeof(port_string));
    snprintf(port_string, sizeof(port_string), "%d", s_vhttps_cli.port);
    HTTPS_LOG(LOG_DEBUG, "port len %d \n", strlen(port_string));
    HTTPS_LOG(LOG_INFO, "Connecting to %s:%s\n", s_vhttps_cli.host, port_string);

    ret = mbedtls_net_connect(&s_tls_cfg.server_fd, s_vhttps_cli.host, port_string, MBEDTLS_NET_PROTO_TCP);
    if (ret != 0)
    {
        HTTPS_LOG(LOG_ERROR, "mbedtls_net_connect returned -0x%x\n", -ret);
        goto exit;
    }

    HTTPS_LOG(LOG_DEBUG, "Https connected.\n");

    // send/recv 回调
    mbedtls_ssl_set_bio(&s_tls_cfg.ssl_context, &s_tls_cfg.server_fd, mbedtls_net_send, mbedtls_net_recv, NULL);

    // 握手
    HTTPS_LOG(LOG_DEBUG, "Performing the SSL/TLS handshake...\n");

    VESYNC_PRINTF_FREE_HEAP();

    while ((ret = mbedtls_ssl_handshake(&s_tls_cfg.ssl_context)) != 0)
    {
        HTTPS_LOG(LOG_DEBUG, "mbedtls_ssl_handshake  = -0x%x\n", -ret);
        if (ret != MBEDTLS_ERR_SSL_WANT_READ && ret != MBEDTLS_ERR_SSL_WANT_WRITE)
        {
            VESYNC_PRINTF_FREE_HEAP();
            HTTPS_LOG(LOG_ERROR, "mbedtls_ssl_handshake returned -0x%x\n", -ret);
            goto exit;
        }
    }

    HTTPS_LOG(LOG_DEBUG, "Verifying peer X.509 certificate...\n");
    if (0 != mbedtls_ssl_get_verify_result(&s_tls_cfg.ssl_context))
    {
        /* In real life, we probably want to close connection if ret != 0 */
        HTTPS_LOG(LOG_ERROR, "Failed to verify peer certificate!\n");
        goto exit;
    }
    else
    {
        HTTPS_LOG(LOG_INFO, "Certificate verified.\n");
    }

    HTTPS_LOG(LOG_DEBUG, "Cipher suite is %s\n", mbedtls_ssl_get_ciphersuite(&s_tls_cfg.ssl_context));

    return VERR_OK;

exit:
    mbedtls_net_free(&s_tls_cfg.server_fd);
    return VERR_FAIL;
}

/**
 * @brief         https send request
 * @param[in]     method        [请求的方法]
 * @param[in]     https_buffer  [https通信的数据交互缓存区，大小为HTTPS_BUFFER_SIZE]
 * @param[in]     content_buf   [请求的数据内容]
 * @return        int           [成功或失败]
 */
int vesync_https_cli_request(HTTPS_METHOD_TYPE_E method, char *https_buffer, char *content_buf)
{
    int ret;
    char https_method[][8] = {"GET", "POST"};
    char keep_alive_string[100];
    size_t written_bytes = 0;

    memset(keep_alive_string, 0, sizeof(keep_alive_string));

    if (s_vhttps_cli.keep_alive_enable)
    {
        snprintf(keep_alive_string, sizeof(keep_alive_string), "%s", KEEPALIVE_STRING);
    }
    else
    {
        snprintf(keep_alive_string, sizeof(keep_alive_string), "%s", ANTI_KEEPALIVE_STRING);
    }

    memset(https_buffer, 0, HTTPS_BUFFER_SIZE);
    snprintf(https_buffer, HTTPS_BUFFER_SIZE, HTTPS_REQUEST, https_method[method], s_vhttps_cli.path, s_vhttps_cli.host,
            keep_alive_string, strlen(content_buf), content_buf);

    HTTPS_LOG(LOG_DEBUG, "\n%s\n", https_buffer);

    do
    {
        ret = mbedtls_ssl_write(&s_tls_cfg.ssl_context, (const unsigned char *)https_buffer + written_bytes,
                                strlen(https_buffer) - written_bytes);
        if (ret >= 0)
        {
            HTTPS_LOG(LOG_INFO, "%d bytes written\n", ret);
            written_bytes += ret;
        }
        else if (ret != MBEDTLS_ERR_SSL_WANT_WRITE && ret != MBEDTLS_ERR_SSL_WANT_READ)
        {
            HTTPS_LOG(LOG_ERROR, "mbedtls_ssl_write returned -0x%x\n", -ret);
            return VERR_FAIL;
        }
    } while (written_bytes < strlen(https_buffer));

    return VERR_OK;
}

/**
 * @brief  解析chunk长度
 * @param[in]  p_buf            [输入包含chunk-length的数据指针]
 * @param[out]  offset          [chunk-length字符偏移]
 * @return  int                 [成功：返回chunk长度，失败：返回-1]
 */
static int vesync_https_parse_chunk_len(char *p_buf, int *offset)
{
    int chunk_len = -1;
    char chunk_len_str[8] = {0};
    char *p_len = NULL;

    if (p_buf == NULL || offset == NULL)
    {
        return -1;
    }

    p_len = strstr(p_buf, "\r\n");
    if (p_len)
    {
        int chunk_len_str_len = p_len - p_buf;
        memset(chunk_len_str, 0, sizeof(chunk_len_str));
        memcpy(chunk_len_str, p_buf, chunk_len_str_len);
        chunk_len = hex_str_to_hex(chunk_len_str);
        *offset = (chunk_len_str_len + 2); // "${chunk-length}\r\n"
    }

    return chunk_len;
}

/**
 * @brief         接受并处理回复
 * @param[in]     https_buffer  [https通信的数据交互缓存区，大小为HTTPS_BUFFER_SIZE]
 * @param[out]    recv_buf      [返回的数据内容缓存buffer]
 * @param[in,out] recv_len      [返回的数据内容长度指针，传入时为缓存buffer的长度，供内部判断buffer大小是否足够，足够时内部把返回的数据拷贝至buffer，并赋值该值为数据长度]
 * @param[in]   keep_head       [返回的数据内容是否保留头部]
 * @return        int           [成功或失败]
 */
int vesync_https_cli_recv(char *https_buffer, char *recv_buf, int *recv_len, bool keep_head)
{
    int ret;
    int rd_len = 0;
    const int max_recv_len = *recv_len;
    int cum_len = 0;    // 有效数据累计长度
    int ctx_len = 0;    // https头部中Content-Length
    int head_offset = 0;   // https头部偏移

    s_vhttps_cli.head_fetched = false;
    s_vhttps_cli.is_chunked = false;

    memset(recv_buf, 0, *recv_len);

    // 接收
    HTTPS_LOG(LOG_INFO, "Reading HTTPS response...\n");
    do
    {
        head_offset = 0;
        memset(https_buffer, 0, HTTPS_BUFFER_SIZE);

        ret = mbedtls_ssl_read(&s_tls_cfg.ssl_context, (unsigned char *)https_buffer, HTTPS_BUFFER_SIZE - 1);
        if (ret == MBEDTLS_ERR_SSL_WANT_READ || ret == MBEDTLS_ERR_SSL_WANT_WRITE)
        {
            continue;
        }

        if (ret == MBEDTLS_ERR_SSL_PEER_CLOSE_NOTIFY)
        {
            ret = 0;
            HTTPS_LOG(LOG_DEBUG, "MBEDTLS_ERR_SSL_PEER_CLOSE_NOTIFY.\n");
            s_vhttps_cli.is_keep_alive = false;
            return VERR_FAIL;
        }

        if (ret < 0)
        {
            HTTPS_LOG(LOG_ERROR, "mbedtls_ssl_read returned -0x%x\n", -ret);
            s_vhttps_cli.is_keep_alive = false;
            return VERR_FAIL;
        }

        if (ret == 0)
        {
            HTTPS_LOG(LOG_INFO, "connection closed\n");
            s_vhttps_cli.is_keep_alive = false;
            return VERR_FAIL;
        }

        // 保存接收到的内容
        rd_len = ret;

        HTTPS_LOG(LOG_DEBUG, "%d bytes read.\n", rd_len);
        HTTPS_LOG(LOG_DEBUG, "https_receive : %s \n", https_buffer);

        if (!s_vhttps_cli.head_fetched)   // 收到第一包，头部未解析
        {
            if (VERR_OK == vesync_https_parse_head(https_buffer, keep_head, &rd_len, &head_offset, &ctx_len))
            {
                s_vhttps_cli.head_fetched = true;
                HTTPS_LOG(LOG_INFO, "https parse head success, content length: %d\n", ctx_len);
            }
            else
            {
                break;
            }
        }

        if ((rd_len + cum_len) < max_recv_len)
        {
            char *p_payload = https_buffer + head_offset;

            if (!keep_head && s_vhttps_cli.is_chunked)
            {
                int chunk_len = 0;
                int offset = 0;
                chunk_len = vesync_https_parse_chunk_len(p_payload, &offset);
                if (chunk_len < 0)
                {
                    HTTPS_LOG(LOG_ERROR, "chunk len error\n");
                    break;
                }

                memcpy(&recv_buf[cum_len], p_payload + offset, chunk_len);
                cum_len += chunk_len;

                char *end_str = strstr(https_buffer, "0\r\n\r\n");
                if (end_str)
                {
                    *recv_len = cum_len;
                    s_vhttps_cli.is_keep_alive = s_vhttps_cli.keep_alive_enable;
                    HTTPS_LOG(LOG_DEBUG, "https receive finish\n");
                    return VERR_OK;
                }
            }
            else
            {
                memcpy(&recv_buf[cum_len], p_payload, rd_len);
                cum_len += rd_len;

                if (cum_len == ctx_len)
                {
                    *recv_len = cum_len;
                    s_vhttps_cli.is_keep_alive = s_vhttps_cli.keep_alive_enable;
                    HTTPS_LOG(LOG_INFO, "https receive finish\n");
                    return VERR_OK;
                }
            }
        }
        else
        {
            HTTPS_LOG(LOG_ERROR, "Recv buffer length is too short!\n");
            *recv_len = -1;
            recv_buf[0] = '\0';
            s_vhttps_cli.is_keep_alive = false;
            break;
        }
    } while(1);

    return VERR_FAIL;
}



/**
 * @brief         https客户端初始化
 * @param[in]     config        [初始化配置，详见vesync_https_client_config_t]
 * @return        int           [成功或失败]
 */
int vesync_https_cli_init(vesync_https_cli_cfg_t *config)
{
    HTTPS_UTIL_MEM_CHECK(config, return VERR_FAIL);

    memset(&s_vhttps_cli, 0, sizeof(s_vhttps_cli));
    s_vhttps_cli.keep_alive_enable = true;        // true时，http头部填充keepalive字段
    s_vhttps_cli.is_keep_alive = false;           // true时，不需要再初始化mbedtls接口
    s_vhttps_cli.port = HTTPS_DEFAULT_PORT;

    if (config->url)
    {
        if (vesync_https_parse_url(config->url) != VERR_OK)
        {
            return VERR_FAIL;
        }
    }
    else
    {
        HTTPS_UTIL_MEM_CHECK(config->host, return VERR_FAIL);

        if (strlen(config->host) >= HTTPS_HOST_LEN)
        {
            HTTPS_LOG(LOG_WARN, "https host is too long\r\n");
            return VERR_FAIL;
        }
        else
        {
            snprintf(s_vhttps_cli.host, sizeof(s_vhttps_cli.host), "%s", config->host);
        }

        if (strlen(config->path) >= HTTPS_PATH_LEN)
        {
            HTTPS_LOG(LOG_WARN, "https path is too long\r\n");
            return VERR_FAIL;
        }
        else
        {
            snprintf(s_vhttps_cli.path, sizeof(s_vhttps_cli.path), "%s", config->path);
        }

        if (config->port)
        {
            s_vhttps_cli.port = config->port;
        }
    }

    s_vhttps_cli.keep_alive_enable = config->keep_alive;

    VESYNC_PRINTF_FREE_HEAP();

    if (s_vhttps_cli.is_keep_alive)
    {
        return VERR_OK;
    }

    return vesync_https_cli_ssl_init(config);
}

/**
 * @brief         https request
 * @param[in]     method        [请求的方法]
 * @param[in]     send_buf      [请求的数据内容]
 * @param[out]    recv_buf      [返回的数据内容缓存buffer]
 * @param[in/out] recv_len      [返回的数据内容长度指针，传入时为缓存buffer的长度，供内部判断buffer大小是否足够，足够时内部把返回的数据拷贝至buffer，并赋值该值为数据长度]
 * @param[in]     mode          [https工作模式，目前只支持常规模式，即数据一次性放入内存]
 * @return        int           [成功或失败]
 */
int vesync_https_request(HTTPS_METHOD_TYPE_E method, char *send_buf, char *recv_buf, int *recv_len, bool keep_head)
{
    int ret = -1;
    char *https_buffer = NULL;

    HTTPS_UTIL_MEM_CHECK(send_buf, return VERR_FAIL);
    HTTPS_UTIL_MEM_CHECK(recv_buf, return VERR_FAIL);
    HTTPS_UTIL_MEM_CHECK(recv_len, return VERR_FAIL);

    if (HTTPS_METHOD_GET != method && HTTPS_METHOD_POST != method)
    {
        HTTPS_LOG(LOG_ERROR, "Unknow https method type(%d)!\n", method);
        return VERR_FAIL;
    }

    // 判断Wi-Fi网络是否连接成功
    HTTPS_LOG(LOG_INFO, "Waiting for network connected...\n");
    if (!vhal_wifi_get_link_status(HTTPS_WAIT_TIME_MS))
    {
        HTTPS_LOG(LOG_ERROR, "Network was disconnect!\n");
        return VERR_FAIL;
    }
    HTTPS_LOG(LOG_INFO, "Network connected.\n");

    https_buffer = (char *)vesync_malloc(HTTPS_BUFFER_SIZE);
    HTTPS_UTIL_MEM_CHECK(https_buffer, return VERR_FAIL);

    if (VERR_OK != vesync_https_cli_request(method, https_buffer, send_buf))
    {
        goto exit;
    }

    ret = vesync_https_cli_recv(https_buffer, recv_buf, recv_len, keep_head);

    HTTPS_LOG(LOG_DEBUG, "recv %d bytes read; \n\nrecv_buf:\n %s \n", *recv_len, recv_buf);

    HTTPS_LOG(LOG_DEBUG, "https receive succeed ! \n");

    if (s_vhttps_cli.is_keep_alive)
    {
        goto keepalive;
    }

    // 通知服务器关闭
    mbedtls_ssl_close_notify(&s_tls_cfg.ssl_context);

exit:
    s_vhttps_cli.is_keep_alive = false;
    mbedtls_ssl_session_reset(&s_tls_cfg.ssl_context);

    vesync_https_cli_ssl_deinit();

keepalive:

    HTTPS_UTIL_SAFE_FREE(https_buffer);
    if (ret != VERR_OK)
    {
        return VERR_FAIL;
    }

    return VERR_OK;
}

/**
 * @brief         https通知服务器关闭，并释放空间
 */
void vesync_https_cli_deinit(void)
{
    if (s_vhttps_cli.is_keep_alive)
    {
        // 通知服务器关闭
        mbedtls_ssl_close_notify(&s_tls_cfg.ssl_context);
        mbedtls_ssl_session_reset(&s_tls_cfg.ssl_context);
        vesync_https_cli_ssl_deinit();
        s_vhttps_cli.is_keep_alive = false;
    }
}

