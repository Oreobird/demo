/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_queue.c
 * @brief       queue抽象层，封装freertos队列相关接口
 * @author      Joshua
 * @date        2021-04-20
 */
#include <limits.h>

#include <freertos/FreeRTOS.h>
#include <freertos/queue.h>

#include "vesync_os_internal.h"
#include "vesync_common.h"
#include "vesync_queue.h"

/*
 * @brief  创建队列
 * @param[in]  queue                   [队列结构体指针]
 * @param[in]  queue_size              [队列大小(消息大小*消息个数), 单位字节]
 * @param[in]  msg_size                [队列消息大小，单位字节]
 * @return int                         [成功：VOS_OK；失败：VOS_FAIL]
 */
int vesync_queue_new(vesync_queue_t *queue, unsigned int queue_size, unsigned int msg_size)
{
    VCOM_NULL_PARAM_CHK(queue, return VOS_FAIL);
    VCOM_IN_RANGE_CHK(msg_size, 1, UINT_MAX - 1, return VOS_FAIL);

    QueueHandle_t q = xQueueCreate(queue_size / msg_size, msg_size);
    queue->queue_size = queue_size;
    queue->handle = q;
    return q != NULL ? VOS_OK : VOS_FAIL;
}

/*
 * @brief  队列发送
 * @param[in]  queue                   [队列结构体指针]
 * @param[in]  msg                     [消息]
 * @param[in]  timeout_ms              [定义当队列满的情况下，发送方的行为：
 *                                      VESYNC_OS_NO_WAIT: 不等待
 *                                      VESYNC_OS_WAIT_FOREVER: 等待直到队列不满]
 * @return int                         [成功：VOS_OK；失败：VOS_FAIL]
 */
int vesync_queue_send(vesync_queue_t *queue, void *msg, unsigned int timeout_ms)
{
    VCOM_NULL_PARAM_CHK(queue, return VOS_FAIL);
    VCOM_NULL_PARAM_CHK(queue->handle, return VOS_FAIL);
    BaseType_t ret = xQueueSend(queue->handle, msg, timeout_ms == VESYNC_OS_WAIT_FOREVER ? portMAX_DELAY : VESYNC_MS_TO_TICKS(timeout_ms));
    return ret == pdPASS ? VOS_OK : VOS_FAIL;
}

/*
 * @brief  队列接收
 * @param[in]  queue                   [队列结构体指针]
 * @param[in]  msg                     [消息]
 * @param[in]  timeout_ms              [定义当队列为空的情况下，发送方的行为：
 *                                      VESYNC_OS_NO_WAIT: 不等待
 *                                      VESYNC_OS_WAIT_FOREVER: 等待直到队列不为空]
 * @return int                         [成功：VOS_OK；失败：VOS_FAIL]
 */
int vesync_queue_recv(vesync_queue_t *queue, void *msg, unsigned int timeout_ms)
{
    VCOM_NULL_PARAM_CHK(queue, return VOS_FAIL);
    VCOM_NULL_PARAM_CHK(queue->handle, return VOS_FAIL);
    BaseType_t ret = xQueueReceive(queue->handle, msg, timeout_ms == VESYNC_OS_WAIT_FOREVER ? portMAX_DELAY : VESYNC_MS_TO_TICKS(timeout_ms));
    return ret == pdPASS ? VOS_OK : VOS_FAIL;
}

/*
 * @brief  删除队列
 * @param[in]  queue                   [队列结构体指针]
 * @return int                         [成功：VOS_OK；失败：VOS_FAIL]
 */
int vesync_queue_free(vesync_queue_t *queue)
{
    VCOM_NULL_PARAM_CHK(queue, return VOS_FAIL);
    VCOM_NULL_PARAM_CHK(queue->handle, return VOS_FAIL);
    vQueueDelete(queue->handle);
    return VOS_OK;
}

