/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_flash.c
 * @brief       flash接口
 * @author      Joshua
 * @date        2021-05-17
 */

#include "vesync_common.h"
#include "vesync_memory.h"
#include "vesync_flash.h"
#include "vesync_base64.h"


/**
 * @brief  flash初始化
 * @param[in]  part_id              [分区ID]
 * @return     int32_t              [错误码]
 */
int32_t vesync_flash_init(void)
{
    vhal_flash_init(PARTITION_DEFAULT);
    vhal_flash_init(PARTITION_CFG);
    vhal_flash_init(PARTITION_FAC);
    vhal_flash_init(PARTITION_LOG);
    return SDK_OK;
}

/**
 * @brief  从flash读取数据
 * @param[in]  part_id              [分区ID]
 * @param[in]  key_name             [键值名称]
 * @param[in]  p_data               [读取数据缓存区]
 * @param[in/out]  p_len            [当前读取的数据长度]
 * @return     int32_t              [0表示读取成功，非0表示读取失败]
 */
int32_t vesync_flash_read(PARTITION_ID_E part_id, const char *key_name, uint8_t *p_data, uint32_t *p_len)
{
    VCOM_NULL_PARAM_CHK(key_name, return SDK_FAIL);
    VCOM_NULL_PARAM_CHK(p_data, return SDK_FAIL);
    VCOM_NULL_PARAM_CHK(p_len, return SDK_FAIL);

    int32_t ret = vhal_flash_read(part_id, key_name, p_data, p_len);
    return ret == VHAL_OK ? SDK_OK : SDK_FAIL;
}

/**
 * @brief  往flash写入数据
 * @param[in]  part_id              [分区ID]
 * @param[in]  key_name             [键值名称]
 * @param[in]  p_data               [写入的数据]
 * @param[in]  len                  [写入数据的长度]
 * @return     int32_t              [0表示写入成功，非0表示写入失败]
 */
int32_t vesync_flash_write(PARTITION_ID_E part_id, const char *key_name, uint8_t *p_data, uint32_t len)
{
    VCOM_NULL_PARAM_CHK(key_name, return SDK_FAIL);
    VCOM_NULL_PARAM_CHK(p_data, return SDK_FAIL);

    int32_t ret = vhal_flash_write(part_id, key_name, p_data, len);
    return ret == VHAL_OK ? SDK_OK : SDK_FAIL;
}


/**
 * @brief  从flash读取加密数据
 * @param[in]  part_id              [分区ID]
 * @param[in]  key_name             [键值名称]
 * @param[in]  p_data               [读取数据缓存区]
 * @param[in/out]  p_len            [当前读取的数据长度]
 * @return     int32_t              [0表示读取成功，非0表示读取失败]
 */
int32_t vesync_flash_crypto_read(PARTITION_ID_E part_id, const char *key_name, uint8_t *p_data, uint32_t *p_len)
{
    unsigned char *base64_buf = NULL;
    size_t olen = 0;
    size_t buf_len = ((*p_len + 2) / 3) * 4; //ceil(len/3)*4;
    base64_buf = vesync_malloc(buf_len);
    if (base64_buf == NULL)
    {
        return SDK_FAIL;
    }

    memset(base64_buf, 0, buf_len);
    int ret = vhal_flash_read(part_id, key_name, base64_buf, &buf_len);
    if (ret != VHAL_OK)
    {
        vesync_free(base64_buf);
        return SDK_FAIL;
    }

    ret = vesync_base64_decode(p_data, *p_len, &olen, base64_buf, buf_len);
    if (ret != SDK_OK)
    {
        vesync_free(base64_buf);
        return SDK_FAIL;
    }

    *p_len = olen;

    vesync_free(base64_buf);
    return SDK_OK;
}

/**
 * @brief  往flash加密写入数据
 * @param[in]  part_id              [分区ID]
 * @param[in]  key_name             [键值名称]
 * @param[in]  p_data               [写入的数据]
 * @param[in]  len                  [写入数据的长度]
 * @return     int32_t              [0表示写入成功，非0表示写入失败]
 */
int32_t vesync_flash_crypto_write(PARTITION_ID_E part_id, const char *key_name, uint8_t *p_data, uint32_t len)
{
    unsigned char *base64_buf = NULL;
    size_t olen = 0;

    size_t buf_len = ((len + 2) / 3) * 4 + 1; //ceil(len/3)*4 + 1;
    base64_buf = vesync_malloc(sizeof(unsigned char)*buf_len);
    if (base64_buf == NULL)
    {
        return SDK_FAIL;
    }

    memset(base64_buf, 0, buf_len);

    int ret = vesync_base64_encode(base64_buf, buf_len, &olen, p_data, len);
    if (ret != SDK_OK)
    {
        vesync_free(base64_buf);
        return SDK_FAIL;
    }

    ret = vhal_flash_write(part_id, key_name, base64_buf, olen);
    if (ret != VHAL_OK)
    {
        vesync_free(base64_buf);
        return SDK_FAIL;
    }

    vesync_free(base64_buf);
    return SDK_OK;
}


/**
 * @brief  擦除指定分区
 * @param[in]  part_id              [分区ID]
 * @return     int32_t              [0表示擦除成功，非0表示擦除失败]
 */
int32_t vesync_flash_erase(PARTITION_ID_E part_id)
{
    int32_t ret = vhal_flash_erase(part_id);
    return ret == VHAL_OK ? SDK_OK : SDK_FAIL;
}

/**
 * @brief  擦除指定分区中的指定键值对
 * @param[in]  part_id              [分区ID]
 * @param[in]  key_name             [键值名称]
 * @return     int32_t              [0表示擦除成功，非0表示擦除失败]
 */
int32_t vesync_flash_erase_key(PARTITION_ID_E part_id, const char *key_name)
{
    VCOM_NULL_PARAM_CHK(key_name, return SDK_FAIL);

    int32_t ret = vhal_flash_erase_key(part_id, key_name);
    return ret == VHAL_OK ? SDK_OK : SDK_FAIL;
}

