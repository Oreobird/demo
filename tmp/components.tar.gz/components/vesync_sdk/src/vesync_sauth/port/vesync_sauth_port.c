/**
 * Copyright © Vesync Technologies Co.Ltd. 2022. All rights reserved.
 * @file        vesync_sauth_process.c
 * @brief       Vesync SAUTH模块的协议主处理流程实现
 * @author      Herve.Lin
 * @date        2022-01-06
 */
#include <stdio.h>
#include <string.h>

#include "vesync_sauth_port.h"
#include "vesync_sauth_private.h"

#include "vesync_log_internal.h"
#include "vesync_ble_internal.h"

#include "vesync_common.h"
#include "vesync_memory.h"
#if SAUTH_PORT_OS_MUTEX_ENABLE
#include "vesync_mutex.h"
#endif
#include "vesync_utils.h"
#include "vesync_timer.h"
#include "vesync_flash.h"

#include "vesync_tl_payload_parse.h"

#include "vhal_utils.h"

#if SAUTH_PORT_OS_MUTEX_ENABLE
// Sauth模块内部的互斥量
static vesync_mutex_t s_sync;
#endif
// Sauth调度定时器
static vesync_timer_t *s_schd_timer;
// 提供给Sauth内部的大型缓存
static uint8_t s_mass_buf[512];
// LTK储存分区
#define SAUTH_FLASH_LTK_PARTITION PARTITION_CFG
// LTK储存Key
#define SAUTH_FLASH_LTK_USER_CFG_KEY "sauth_ltk"

int sauth_port_read_ltk(uint8_t *p_buf, uint8_t len)
{
    uint32_t rd_len = len;
    int ret = vesync_flash_aes_crypto_read(SAUTH_FLASH_LTK_PARTITION,
                                           SAUTH_FLASH_LTK_USER_CFG_KEY,
                                           p_buf, &rd_len);
    if (ret != VHAL_OK || rd_len != len)
    {
        return SDK_FAIL;
    }
    return SDK_OK;
}

int sauth_port_write_ltk(uint8_t *p_buf, uint8_t len)
{
    int ret = vesync_flash_aes_crypto_write(SAUTH_FLASH_LTK_PARTITION,
                                            SAUTH_FLASH_LTK_USER_CFG_KEY,
                                            p_buf, len);
    if (ret != VHAL_OK)
    {
        return SDK_FAIL;
    }
    return SDK_OK;
}

void sauth_port_rnd_block_gen_cb(uint8_t *dest, uint32_t size)
{
    vhal_utils_get_random(dest, size);
}

void sauth_port_tl_send_data(uint8_t *p_data, uint16_t len)
{
    uint16_t tl_pl_len = len + TL_PAYLOAD_PROTOCOL_HEAD_LEN;
    uint8_t *p_tl_pl = (uint8_t *)vesync_malloc(tl_pl_len);
    if (NULL == p_tl_pl)
    {
        SDK_LOG(LOG_ERROR, "malloc tl_payload fail\n");
        return;
    }
    if (SDK_OK != vesync_tl_payload_encode(SAUTH_PORT_OPCODE_DEV2APP, 0,
                                           p_data, len,
                                           p_tl_pl, &tl_pl_len))
    {
        SDK_LOG(LOG_ERROR, "encode tl_payload fail\n");
        return;
    }
    vesync_ble_send_cmd_data(p_tl_pl, tl_pl_len, false);
    vesync_free(p_tl_pl);
}

bool sauth_port_tl_data_recv_cb(uint8_t *p_data, uint16_t len, bool need_ack)
{
    uint16_t opcode;
    uint8_t status_code;

    uint16_t pl_len;
    uint8_t *p_pl = vesync_tl_payload_decode(p_data, len,
                                             &opcode, &status_code,
                                             &pl_len);
    if (opcode != SAUTH_PORT_OPCODE_APP2DEV)
    {
        return false;
    }

    sauth_msg_recv_cb(p_pl, pl_len);
    return true;
}

void sauth_port_enter_critical(void)
{
#if SAUTH_PORT_OS_MUTEX_ENABLE
    vesync_mutex_lock(s_sync);
#endif
}

void sauth_port_exit_critical(void)
{
#if SAUTH_PORT_OS_MUTEX_ENABLE
    vesync_mutex_unlock(s_sync);
#endif
}

static void sauth_port_schd_timer_cb(void *arg)
{
    UNUSED(arg);

    sauth_schedule();
}

int sauth_port_init(void)
{
    // 注册蓝牙CMD通道数据接收处理回调
    vesync_ble_muxer_add_rxer(sauth_port_tl_data_recv_cb);

    s_schd_timer = vesync_timer_new((char *)"sauth",
                                    sauth_port_schd_timer_cb,
                                    NULL,
                                    50,
                                    true);
    if (NULL == s_schd_timer)
    {
        SDK_LOG(LOG_ERROR, "create timer fail\n");
        return SDK_FAIL;
    }
    if (VOS_OK != vesync_timer_start(s_schd_timer))
    {
        SDK_LOG(LOG_ERROR, "start timer fail\n");
        vesync_timer_free(s_schd_timer);
        s_schd_timer = NULL;
        return SDK_FAIL;
    }
    return SDK_OK;
}

void sauth_port_new_session_cb(void)
{
    sauth_login_out();
}

int vesync_sauth_init(void)
{
    if (SDK_OK != sauth_port_init())
    {
        return SDK_FAIL;
    }
    if (SDK_OK != sauth_internal_init(50, 20000, s_mass_buf, sizeof(s_mass_buf)))
    {
        return SDK_FAIL;
    }
    return SDK_OK;
}
