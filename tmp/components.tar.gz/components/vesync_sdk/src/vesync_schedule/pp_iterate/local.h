/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        local.h
 * @brief       预处理宏纵向重复迭代展开接口
 * @date        2021-10-19
 */
#ifndef __PP_ITERATE_LOCAL_H__
#define __PP_ITERATE_LOCAL_H__

/**
 * @brief 取出迭代边界参数中的数值
 * @details 迭代边界参数分别设置了迭代的起始和结束，该宏可以分别展开用于读取起始值或结束值
 * @param[in] n     [应取得数值的序号]
 * @param[in] tuple [被取数的二元元组]
 */
#define PP_ITERATE_LOCAL_CAT_LIMIT(n, tuple) PP_ITERATE_LOCAL_TUPLE_2_ ## n tuple

/**
 * @brief 返回二元元组的0号元素
 * @details 该宏用于以上的拼接后展开
 */
#define PP_ITERATE_LOCAL_TUPLE_2_0(a, b) a
/**
 * @brief 返回二元元组的1号元素
 * @details 该宏用于以上的拼接后展开
 */
#define PP_ITERATE_LOCAL_TUPLE_2_1(a, b) b

/**
 * @brief 迭代过程中的迭代条件判断，判断当前迭代计数是否在边界范围当中
 * @details PP_ITERATE_LOCAL_S、PP_ITERATE_LOCAL_F分别是预处理中被
 *  置数的临时变量，表示起始序号和结束序号。
 * @param[in] n     [当前迭代计数]
 */
#define PP_ITERATE_LOCAL_C(n) (PP_ITERATE_LOCAL_S) <= n && (PP_ITERATE_LOCAL_F) >= n

/**
 * @brief 在需要进行目标宏纵向展开的位置调用此宏，启动目标宏的迭代展开
 * @details 调用此宏前，请确保目标宏参数PP_ITERATE_LOCAL_MACRO(n)与
 *  边界参数PP_ITERATE_LOCAL_LIMIT已经被设置。
 * @code
 *
 * // 具体使用实例
 * #include "stdio.h"
 * #include "pp_iterate/local.h"
 *
 * // 设置迭代展开的目标宏，这里以展开printf()为例子
 * #define PP_ITERATE_LOCAL_MACRO(n)    printf("%d", n);
 * // 设置迭代边界条件，从序号2开始到序号5结束
 * #define PP_ITERATE_LOCAL_LIMIT       (2, 5)
 * // 开始目标宏的重复展开
 * #include PP_ITERATE_LOCAL()
 *
 * >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
 *
 * // 以上宏定义将最终展开为
 * printf("%d", 2);
 * printf("%d", 3);
 * printf("%d", 4);
 * printf("%d", 5);
 *
 * @endcode
 */
#define PP_ITERATE_LOCAL() "pp_iterate/detail.h"

#endif /* __PP_ITERATE_LOCAL_H__ */
