/*
 * Copyright © Vesync Technologies Co.Ltd. 2022. All rights reserved.
 * @file        schedule.c
 * @brief       add/upd/get/delSchedule处理接口
 * @date        2022-01-24
 */

#include <stdio.h>

#include "vesync_common.h"
#include "vesync_log.h"
#include "vesync_buffer.h"
#include "vesync_klv.h"
#include "vesync_memory.h"
#include "vesync_schedule.h"
#include "app_bypass.h"
#include "event.h"
#include "device.h"
#include "scene.h"
#include "schedule.h"


int request_data_handle_for_add_schedule(bp_add_schedule_request_t *request_data, int *err_code, char *err_msg, void **extra)
{
    int ret = APP_OK;
    vesync_schedule_t sch_cfg;

    if (request_data->enabled == BP_NO_VALUE
        || request_data->repeat == BP_NO_VALUE
        || request_data->sch_type == BP_NO_VALUE
        || request_data->start_act_num <= 0)
    {
        ret = APP_FAIL;
        *err_code = BP_ERR_PARA_ILLEGAL;
        snprintf(err_msg, BP_ERR_MSG_LEN, BP_ERR_PARAM_CONV(param, BP_ERR_PARAM_VAL_INVALID));
        goto EXIT;
    }

    memset(&sch_cfg, 0, sizeof(vesync_schedule_t));
    sch_cfg.enabled = (bool)(request_data->enabled);
    sch_cfg.repeat_config = (uint8_t)(request_data->repeat);

    switch (request_data->sch_type)
    {
        case BP_SCH_TYPE_TIMING:
            sch_cfg.type = SCHE_TMG_EVT;
            if (request_data->tmg_evt.clk_sec == BP_NO_VALUE)
            {
                ret = APP_FAIL;
                *err_code = BP_ERR_PARA_ILLEGAL;
                snprintf(err_msg, BP_ERR_MSG_LEN, BP_ERR_PARAM_CONV(clk_sec, BP_ERR_PARAM_MISS));
                goto EXIT;
            }
            sch_cfg.event_config.timing.clock_sec = (uint32_t)(request_data->tmg_evt.clk_sec);
            break;
        case BP_SCH_TYPE_SUN:
            sch_cfg.type = SCHE_SUN_EVT;
            if (request_data->sun_evt.is_rise == BP_NO_VALUE
                || request_data->sun_evt.ofs_sec == BP_NO_VALUE)
            {
                ret = APP_FAIL;
                *err_code = BP_ERR_PARA_ILLEGAL;
                snprintf(err_msg, BP_ERR_MSG_LEN, BP_ERR_PARAM_CONV(param, BP_ERR_PARAM_MISS));
                goto EXIT;
            }

            sch_cfg.event_config.sun.is_sunrise = (bool)(request_data->sun_evt.is_rise);
            sch_cfg.event_config.sun.offset_sec = (int32_t)(request_data->sun_evt.ofs_sec);
            break;
        default:
            ret = APP_FAIL;
            *err_code = BP_ERR_PARA_ILLEGAL;
            snprintf(err_msg, BP_ERR_MSG_LEN, BP_ERR_PARAM_CONV(param, BP_ERR_PARAM_VAL_INVALID));
            goto EXIT;
    }

    APP_LOG(LOG_DEBUG, "sch_cfg: enabled=%d, repeat=%d, tim.clock_sec=%d\n",
            sch_cfg.type, sch_cfg.repeat_config, sch_cfg.event_config.timing.clock_sec);
    // 保存action的配置
    action_cfg_t act_cfg;
    memset(&act_cfg, BP_NO_VALUE, sizeof(action_cfg_t));

    APP_LOG(LOG_DEBUG, "start_act_num=%d\n", request_data->start_act_num);
    for (int i = 0; i < request_data->start_act_num; i++)
    {
        if (request_data->start_act[i].act_type == BP_START_ACT_ACT_TYPE_SWITCH)
        {
            act_cfg.onoff = request_data->start_act[i].act;
        }

        if (request_data->start_act[i].act_type == BP_START_ACT_ACT_TYPE_SWITCH
            && request_data->start_act[i].act == BP_START_ACT_ACT_OFF) // switch off 不处理其它参数
        {
            break;
        }

        if (request_data->start_act[i].act_type == BP_START_ACT_ACT_TYPE_COLORMODE)
        {
            if (request_data->start_act[i].act == BP_START_ACT_ACT_WHITE)
            {
                act_cfg.color_mode = LIGHT_MODE_WHITE;
                act_cfg.light_param.brightness = request_data->start_act[i].params.brightness;
                act_cfg.light_param.color_temp = request_data->start_act[i].params.color_temp;
            }
            else if (request_data->start_act[i].act == BP_START_ACT_ACT_HSV)
            {
                act_cfg.color_mode = LIGHT_MODE_COLOR;
                act_cfg.light_param.H = request_data->start_act[i].params.hue;
                act_cfg.light_param.S = request_data->start_act[i].params.saturation;
                act_cfg.light_param.V = request_data->start_act[i].params.value;
            }
            else if (request_data->start_act[i].act == BP_START_ACT_ACT_SCENARIO)
            {
                act_cfg.color_mode = LIGHT_MODE_SCENE;
                act_cfg.scene_id = request_data->start_act[i].params.scene_id;
            }
            else if (request_data->start_act[i].act == BP_START_ACT_ACT_MUSIC)
            {
                act_cfg.color_mode = LIGHT_MODE_MUSIC; 
                act_cfg.music_id = request_data->start_act[i].params.music_id;
            }
        }
        else if (request_data->start_act[i].act_type == BP_START_ACT_ACT_TYPE_CHANGESCENE)
        {
            act_cfg.color_mode = LIGHT_MODE_SCENE;
            act_cfg.scene_id = request_data->start_act[i].params.scene_id;
        }
    }

    vesync_buf_t p_cfg_buf = vesync_buf_new();
    light_sche_klv_buf_set(&p_cfg_buf, &act_cfg);

    // 调用模块的添加Schedule接口；Schedule配置项ID由模块生成
    int sdk_ret = vesync_schedule_add(LIGHT_SCHE_INS_ID, &sch_cfg, &p_cfg_buf, true);
    if (sdk_ret != SCHE_OK)
    {
        ret = APP_FAIL;
        vesync_buf_clr(&p_cfg_buf);
        if (sdk_ret == SCHE_CFLT_ERR)
        {
            *err_code = BP_ERR_SCHEDULE_CONFLICT;
            snprintf(err_msg, BP_ERR_MSG_LEN, "sche conflict");
        }
        else if (sdk_ret == SCHE_EXCEED_MAX)
        {
            *err_code = BP_ERR_SCHEDULE_EXCEED_MAX;
            snprintf(err_msg, BP_ERR_MSG_LEN, "sche exceed max");
        }
        else
        {
            *err_code = BP_ERR_UNDEFINE;
            snprintf(err_msg, BP_ERR_MSG_LEN, "err undefine");
        }
        goto EXIT;
    }
    else
    {    
        *extra = vesync_malloc(sizeof(sch_cfg.id));
        if (*extra == NULL)
        {
            *err_code = BP_ERR_OUT_OF_MEMORY;
            snprintf(err_msg, BP_ERR_MSG_LEN, "no enough memory");
            ret = APP_FAIL;
            goto EXIT;
        }
        memcpy(*extra, &(sch_cfg.id), sizeof(sch_cfg.id));
    }

EXIT:
    if (ret != APP_OK)
    {
        VCOM_SAFE_FREE(*extra);
    }

    vesync_buf_clr(&p_cfg_buf);
    return ret;
}

int reply_data_get_for_add_schedule(bp_add_schedule_reply_t *reply_data, int *err_code, char *err_msg, void *extra)
{
    reply_data->uid = *((int *)extra);
    VCOM_SAFE_FREE(extra);
    return APP_OK;
}

int request_data_handle_for_get_schedules(bp_get_schedules_request_t *request_data, int *err_code, char *err_msg, void **extra)
{
    int ret = APP_OK;

    *extra = vesync_malloc(sizeof(uint32_t));
    if (*extra == NULL)
    {
        *err_code = BP_ERR_OUT_OF_MEMORY;
        snprintf(err_msg, BP_ERR_MSG_LEN, "no enough memory");
        ret = APP_FAIL;
        goto EXIT;
    }

    memcpy(*extra, &(request_data->idx), sizeof(uint32_t));
EXIT:
    return ret;
}

int reply_data_get_for_get_schedules(bp_get_schedules_reply_t *reply_data, int *err_code, char *err_msg, void *extra)
{
    int ret = APP_OK;
    uint32_t idx = *((uint32_t*)extra);
    vesync_schedule_t *p_sch_cfg = (vesync_schedule_t *)vesync_malloc(LIGHT_SCHE_GET_MAX_NUM * sizeof(vesync_schedule_t));
    if (p_sch_cfg == NULL)
    {
        *err_code = BP_ERR_OUT_OF_MEMORY;
        snprintf(err_msg, BP_ERR_MSG_LEN, "no enough memory");
        ret = APP_FAIL;
        goto EXIT;
    }

    memset(reply_data, BP_NO_VALUE, sizeof(bp_get_schedules_reply_t));

    vesync_buf_t act_cfg_buf[LIGHT_SCHE_GET_MAX_NUM];
    for (int i = 0; i < LIGHT_SCHE_GET_MAX_NUM; i++)
    {
        act_cfg_buf[i] = vesync_buf_new();
    }

    uint32_t sch_cfg_num = 0;
    int sdk_ret = vesync_schedule_get_by_index(LIGHT_SCHE_INS_ID, idx, LIGHT_SCHE_GET_MAX_NUM, 
                                (uint32_t*)&(reply_data->total_num), p_sch_cfg, act_cfg_buf, &sch_cfg_num);
    if (sdk_ret != SCHE_OK)
    {
        ret = APP_FAIL;
        if (sdk_ret == SCHE_INV_IDX_ERR)
        {
            reply_data->schedules_num = 0;
            *err_code = BP_ERR_SCHEDULE_NOT_FOUND;
            snprintf(err_msg, BP_ERR_MSG_LEN, "sche not found");
        }
        else
        {
            *err_code = BP_ERR_UNDEFINE;
            snprintf(err_msg, BP_ERR_MSG_LEN, "err undef");
        }
        goto EXIT;
    }

    action_cfg_t act_cfg;
    memset(&act_cfg, BP_NO_VALUE, sizeof(action_cfg_t));

    reply_data->schedules_num = sch_cfg_num;
    for (int i = 0; i < sch_cfg_num; i++)
    {
        reply_data->schedules[i].uid = p_sch_cfg[i].id;
        reply_data->schedules[i].enabled = (int)p_sch_cfg[i].enabled;
        reply_data->schedules[i].repeat = (int)p_sch_cfg[i].repeat_config;

        if (p_sch_cfg[i].type == SCHE_TMG_EVT)
        {
            reply_data->schedules[i].sch_type = BP_SCH_TYPE_TIMING;
            reply_data->schedules[i].tmg_evt.clk_sec = (int)(p_sch_cfg[i].event_config.timing.clock_sec);
        }
        else if (p_sch_cfg[i].type == SCHE_SUN_EVT)
        {
            reply_data->schedules[i].sch_type = BP_SCH_TYPE_SUN;
            reply_data->schedules[i].sun_evt.is_rise = (int)(p_sch_cfg[i].event_config.sun.is_sunrise);
            reply_data->schedules[i].sun_evt.ofs_sec = (int)(p_sch_cfg[i].event_config.sun.offset_sec);
        }
        else
        {
            ret = APP_FAIL;
            *err_code = BP_ERR_UNDEFINE;
            snprintf(err_msg, BP_ERR_MSG_LEN, "err undef");
            goto EXIT;
        }

        // 处理startAct
        light_sche_klv_buf_get(&act_cfg_buf[i], &act_cfg);
        
        int act_idx = 0;

        reply_data->schedules[i].start_act[act_idx].num = 0;
        reply_data->schedules[i].start_act[act_idx].act_type = BP_START_ACT_ACT_TYPE_SWITCH;
        reply_data->schedules[i].start_act[act_idx].act = act_cfg.onoff;

        if (act_cfg.onoff == LIGHT_STATUS_ON)
        {
            act_idx++;
            reply_data->schedules[i].start_act[act_idx].num = 0;
            if (act_cfg.color_mode == LIGHT_MODE_WHITE)
            {
                reply_data->schedules[i].start_act[act_idx].act_type = BP_START_ACT_ACT_TYPE_COLORMODE;
                reply_data->schedules[i].start_act[act_idx].act = BP_START_ACT_ACT_WHITE;
                reply_data->schedules[i].start_act[act_idx].params.color_temp = act_cfg.light_param.color_temp;
                reply_data->schedules[i].start_act[act_idx].params.brightness = act_cfg.light_param.brightness;
            }
            else if (act_cfg.color_mode == LIGHT_MODE_COLOR)
            {
                reply_data->schedules[i].start_act[act_idx].act_type = BP_START_ACT_ACT_TYPE_COLORMODE;
                reply_data->schedules[i].start_act[act_idx].act = BP_START_ACT_ACT_HSV;
                reply_data->schedules[i].start_act[act_idx].params.hue = act_cfg.light_param.H;
                reply_data->schedules[i].start_act[act_idx].params.saturation = act_cfg.light_param.S;
                reply_data->schedules[i].start_act[act_idx].params.value = act_cfg.light_param.V;
            }
            else if (act_cfg.color_mode == LIGHT_MODE_SCENE)
            {
                reply_data->schedules[i].start_act[act_idx].act_type = BP_START_ACT_ACT_TYPE_CHANGESCENE;
                reply_data->schedules[i].start_act[act_idx].act = BP_START_ACT_ACT_MANUAL;
                reply_data->schedules[i].start_act[act_idx].params.scene_id = act_cfg.scene_id;
            }
        }

        reply_data->schedules[i].start_act_num = act_idx + 1;
    }

EXIT:
    for (int i = 0; i < LIGHT_SCHE_GET_MAX_NUM; i++)
    {
        vesync_buf_clr(&act_cfg_buf[i]);
    }
    VCOM_SAFE_FREE(p_sch_cfg);
    VCOM_SAFE_FREE(extra);
    return ret;
}

int request_data_handle_for_del_schedule(bp_del_schedule_request_t *request_data, int *err_code, char *err_msg, void **extra)
{
    int ret = APP_OK;
    uint32_t id = (uint32_t)(request_data->uid);
    int sdk_ret = vesync_schedule_del(LIGHT_SCHE_INS_ID, id);
    if (sdk_ret != SCHE_OK)
    {
        ret = APP_FAIL;
        if (sdk_ret != SCHE_INV_ID_ERR)
        {
            *err_code = BP_ERR_UNDEFINE;
            snprintf(err_msg, BP_ERR_MSG_LEN, "err undef");
        }
        else
        {
            *err_code = BP_ERR_SCHEDULE_NOT_FOUND;
            snprintf(err_msg, BP_ERR_MSG_LEN, "sche not found");
        }
        goto EXIT;
    }
    else
    {
        *extra = vesync_malloc(sizeof(id));
        if (*extra == NULL)
        {
            *err_code = BP_ERR_OUT_OF_MEMORY;
            snprintf(err_msg, BP_ERR_MSG_LEN, "no enough memory");
            ret = APP_FAIL;
            goto EXIT;
        }
        else
        {
            memcpy(*extra, &(id), sizeof(id));
        }
    }

EXIT:
    if (ret != APP_OK)
    {
        VCOM_SAFE_FREE(*extra);
    }

    return ret;
}

int reply_data_get_for_del_schedule(bp_del_schedule_reply_t *reply_data, int *err_code, char *err_msg, void *extra)
{
    int ret = APP_OK;
    if (extra == NULL)
    {
        ret = APP_FAIL;
        *err_code = BP_ERR_OUT_OF_MEMORY;
        snprintf(err_msg, BP_ERR_MSG_LEN, "id err");
        goto EXIT;
    }

    reply_data->uid = *((uint32_t *)extra);
    VCOM_SAFE_FREE(extra);
EXIT:
    return ret;
}

int request_data_handle_for_upd_schedule(bp_upd_schedule_request_t *request_data, int *err_code, char *err_msg, void **extra)
{
    int ret = APP_OK;

    if (request_data->uid == BP_NO_VALUE)
    {
        ret = APP_FAIL;
        *err_code = BP_ERR_PARA_ILLEGAL;
        snprintf(err_msg, BP_ERR_MSG_LEN, BP_ERR_PARAM_CONV(id, BP_ERR_PARAM_VAL_INVALID));
        goto EXIT;
    }

    uint32_t id = (uint32_t)(request_data->uid);
    vesync_schedule_t sch_cfg;
    vesync_buf_t act_cfg_buf = vesync_buf_new();

    memset(&sch_cfg, 0, sizeof(vesync_schedule_t));

    int sdk_ret = vesync_schedule_get_by_id(LIGHT_SCHE_INS_ID, id, &sch_cfg, &act_cfg_buf);
    if (sdk_ret != SCHE_OK)
    {
        ret = APP_FAIL;
        if (sdk_ret != SCHE_INV_ID_ERR)
        {
            *err_code = BP_ERR_UNDEFINE;
            snprintf(err_msg, BP_ERR_MSG_LEN, "err undef");
        }
        else
        {
            *err_code = BP_ERR_SCHEDULE_NOT_FOUND;
            snprintf(err_msg, BP_ERR_MSG_LEN, "sche not found");
        }
        goto EXIT;
    }

    sch_cfg.enabled = (request_data->enabled != BP_NO_VALUE) ? (bool)(request_data->enabled) : sch_cfg.enabled;
    sch_cfg.repeat_config = (request_data->repeat != BP_NO_VALUE) ? (uint8_t)(request_data->repeat) : sch_cfg.repeat_config;
    if (request_data->sch_type != BP_NO_VALUE)
    {
        switch (request_data->sch_type)
        {
            case BP_SCH_TYPE_TIMING:
                sch_cfg.type = SCHE_TMG_EVT;
                sch_cfg.event_config.timing.clock_sec = (request_data->tmg_evt.clk_sec != BP_NO_VALUE) ? 
                                                        (uint32_t)(request_data->tmg_evt.clk_sec) :
                                                        sch_cfg.event_config.timing.clock_sec;
                break;
            case BP_SCH_TYPE_SUN:
                sch_cfg.type = SCHE_SUN_EVT;
                sch_cfg.event_config.sun.is_sunrise = (request_data->sun_evt.is_rise != BP_NO_VALUE) ?
                                                        (bool)(request_data->sun_evt.is_rise) :
                                                        sch_cfg.event_config.sun.is_sunrise;
                sch_cfg.event_config.sun.offset_sec = (request_data->sun_evt.ofs_sec != BP_NO_VALUE) ?
                                                        (int32_t)(request_data->sun_evt.ofs_sec) :
                                                        sch_cfg.event_config.sun.offset_sec;
                break;
            default:
                ret = APP_FAIL;
                *err_code = BP_ERR_PARA_ILLEGAL;
                snprintf(err_msg, BP_ERR_MSG_LEN, BP_ERR_PARAM_CONV(param, BP_ERR_PARAM_VAL_INVALID));
                goto EXIT;
        }
    }

    APP_LOG(LOG_DEBUG, "sch_cfg: enabled=%d, repeat=%d, tim.clock_sec=%d\n",
            sch_cfg.type, sch_cfg.repeat_config, sch_cfg.event_config.timing.clock_sec);

    if (request_data->start_act_num > 0)
    {
        action_cfg_t act_cfg;
        memset(&act_cfg, BP_NO_VALUE, sizeof(action_cfg_t));

        APP_LOG(LOG_DEBUG, "start_act_num=%d\n", request_data->start_act_num);
        for (int i = 0; i < request_data->start_act_num; i++)
        {
            if (request_data->start_act[i].act_type == BP_START_ACT_ACT_TYPE_SWITCH)
            {
                act_cfg.onoff = request_data->start_act[i].act;
            }

            if (request_data->start_act[i].act_type == BP_START_ACT_ACT_TYPE_SWITCH
                && request_data->start_act[i].act == BP_START_ACT_ACT_OFF) // switch off 不处理其它参数
            {
                break;
            }

            if (request_data->start_act[i].act_type == BP_START_ACT_ACT_TYPE_COLORMODE)
            {
                if (request_data->start_act[i].act == BP_START_ACT_ACT_WHITE)
                {
                    act_cfg.color_mode = LIGHT_MODE_WHITE;
                    act_cfg.light_param.brightness = request_data->start_act[i].params.brightness;
                    act_cfg.light_param.color_temp = request_data->start_act[i].params.color_temp;
                }
                else if (request_data->start_act[i].act == BP_START_ACT_ACT_HSV)
                {
                    act_cfg.color_mode = LIGHT_MODE_COLOR;
                    act_cfg.light_param.H = request_data->start_act[i].params.hue;
                    act_cfg.light_param.S = request_data->start_act[i].params.saturation;
                    act_cfg.light_param.V = request_data->start_act[i].params.value;
                }
            }
            else if (request_data->start_act[i].act_type == BP_START_ACT_ACT_TYPE_CHANGESCENE)
            {
                act_cfg.color_mode = LIGHT_MODE_SCENE;
                act_cfg.scene_id = request_data->start_act[i].params.scene_id;
            }
        }

        light_sche_klv_buf_set(&act_cfg_buf, &act_cfg);
    }

    sdk_ret = vesync_schedule_upd(LIGHT_SCHE_INS_ID, &sch_cfg, &act_cfg_buf);
    if (sdk_ret != SCHE_OK)
    {
        ret = APP_FAIL;
        if (sdk_ret != SCHE_CFLT_ERR)
        {
            *err_code = BP_ERR_UNDEFINE;
            snprintf(err_msg, BP_ERR_MSG_LEN, "err undef");
        }
        else
        {
            *err_code = BP_ERR_SCHEDULE_CONFLICT;
            snprintf(err_msg, BP_ERR_MSG_LEN, "sche conflict");
        }
        goto EXIT;
    }
    else
    {
        *extra = vesync_malloc(sizeof(sch_cfg.id));
        if (*extra == NULL)
        {
            *err_code = BP_ERR_OUT_OF_MEMORY;
            snprintf(err_msg, BP_ERR_MSG_LEN, "no enough memory");
            ret = APP_FAIL;
            goto EXIT;
        }
        memcpy(*extra, &(sch_cfg.id), sizeof(sch_cfg.id));
    }

EXIT:
    if (ret != APP_OK)
    {
        VCOM_SAFE_FREE(*extra);
    }
    
    vesync_buf_clr(&act_cfg_buf);
    return ret;
}

int reply_data_get_for_upd_schedule(bp_upd_schedule_reply_t *reply_data, int *err_code, char *err_msg, void *extra)
{
    reply_data->uid = *((uint32_t *)extra);
    VCOM_SAFE_FREE(extra);
    return APP_OK;
}

