/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
* @file         app_event.c
* @brief        应用事件接口
* @author       Joshua
* @date         2021-11-16
*/
#include <stdlib.h>
#include <stdint.h>
#include "vesync_common.h"
#include "vesync_log.h"
#include "vesync_queue.h"
#include "event.h"
#include "light.h"
#include "vhal_utils.h"

#define EVENT_RECV_TIMEOUT_MS   LIGHT_REFLESH_INTERVAL_MS

static vesync_queue_t *s_event_queue = NULL;

int app_event_init(void)
{
    if (s_event_queue != NULL)
    {
        APP_LOG(LOG_DEBUG, "APP event queue already init\n");
        return APP_OK;
    }

    s_event_queue = vesync_queue_new(APP_EVENT_QUEUE_MAX_NUM * sizeof(app_event_t), sizeof(app_event_t));
    if (s_event_queue == NULL)
    {
        APP_LOG(LOG_ERROR, "App event queue init failed\n");
        return APP_FAIL;
    }

    return APP_OK;
}

int app_event_deinit(void)
{
    int ret = vesync_queue_free(s_event_queue);
    return (ret != VOS_OK) ? APP_FAIL : APP_OK;
}

int app_event_notify(app_event_t *ev)
{
    VCOM_NULL_PARAM_CHK(ev, return APP_FAIL);

    int ret = vesync_queue_send(s_event_queue, ev, VESYNC_OS_NO_WAIT);
    if (ret != VOS_OK)
    {
        APP_LOG(LOG_ERROR, "Event notify failed\n");
        return APP_FAIL;
    }

    return APP_OK;
}

void app_event_loop_run(void)
{
    app_event_t ev;
    EV_HANDLE_RET handle_ret = EV_HANDLE_OK;

    while(1)
    {
        if (VOS_OK == vesync_queue_recv(s_event_queue, &ev, EVENT_RECV_TIMEOUT_MS))
        {
            handle_ret = app_event_handle(&ev);
        }
        
        if (handle_ret == EV_HANDLE_LOOP)
        {
            app_event_handle(&ev);
        }

        VCOM_PRINT_FREE_HEAP();
    }
}
