/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_mutex.c
 * @brief       mutex抽象层，封装freertos互斥量相关接口
 * @author      Joshua
 * @date        2021-04-20
 */
#include <freertos/FreeRTOS.h>
#include <freertos/semphr.h>

#include "vesync_common.h"
#include "vesync_mutex.h"

vesync_mutex_t vesync_mutex_new(void)
{
    SemaphoreHandle_t mutex = xSemaphoreCreateMutex();
    return (vesync_mutex_t)mutex;
}

int vesync_mutex_lock(vesync_mutex_t mtx)
{
    VCOM_NULL_PARAM_CHK(mtx, return VOS_FAIL);
    BaseType_t ret = xSemaphoreTake((SemaphoreHandle_t)mtx, portMAX_DELAY);
    return ret == pdPASS ? VOS_OK : VOS_FAIL;
}

int vesync_mutex_try_lock(vesync_mutex_t mtx)
{
    VCOM_NULL_PARAM_CHK(mtx, return VOS_FAIL);
    BaseType_t ret = xSemaphoreTake((SemaphoreHandle_t)mtx, 0);
    return ret == pdPASS ? VOS_OK : VOS_FAIL;
}

int vesync_mutex_unlock(vesync_mutex_t mtx)
{
    VCOM_NULL_PARAM_CHK(mtx, return VOS_FAIL);
    BaseType_t ret = xSemaphoreGive(mtx);
    return ret == pdPASS ? VOS_OK : VOS_FAIL;
}

int vesync_mutex_free(vesync_mutex_t mtx)
{
    VCOM_NULL_PARAM_CHK(mtx, return VOS_FAIL);
    vSemaphoreDelete(mtx);
    return VOS_OK;
}

vesync_mutex_t vesync_recursive_mutex_new(void)
{
    SemaphoreHandle_t mutex = xSemaphoreCreateRecursiveMutex();
    return (vesync_mutex_t)mutex;
}

int vesync_recursive_mutex_lock(vesync_mutex_t mtx)
{
    VCOM_NULL_PARAM_CHK(mtx, return VOS_FAIL);
    BaseType_t ret = xSemaphoreTakeRecursive((SemaphoreHandle_t)mtx, portMAX_DELAY);
    return ret == pdPASS ? VOS_OK : VOS_FAIL;
}

int vesync_recursive_mutex_try_lock(vesync_mutex_t mtx)
{
    VCOM_NULL_PARAM_CHK(mtx, return VOS_FAIL);
    BaseType_t ret = xSemaphoreTakeRecursive((SemaphoreHandle_t)mtx, 0);
    return ret == pdPASS ? VOS_OK : VOS_FAIL;
}

int vesync_recursive_mutex_unlock(vesync_mutex_t mtx)
{
    VCOM_NULL_PARAM_CHK(mtx, return VOS_FAIL);
    BaseType_t ret = xSemaphoreGiveRecursive((SemaphoreHandle_t)mtx);
    return ret == pdPASS ? VOS_OK : VOS_FAIL;
}

int vesync_recursive_mutex_free(vesync_mutex_t mtx)
{
    VCOM_NULL_PARAM_CHK(mtx, return VOS_FAIL);
    vSemaphoreDelete(mtx);
    return VOS_OK;
}
