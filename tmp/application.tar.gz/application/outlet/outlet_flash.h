/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        outlet_bypass.h
 * @brief       outlet bypass应用回调
 * @author      Joshua
 * @date        2021-06-04
 */

#ifndef __OUTLET_FLASH_H__
#define __OUTLET_FLASH_H__

#include "outlet_gpio.h"
#include "outlet_board.h"

#ifdef __cplusplus
extern "C" {
#endif

#define SWITCH_USER_CFG_KEY_DATA "switch"   // NVS采用key:value格式进行存储

#if defined(OUTLET_ELEC_METERING) && (OUTLET_ELEC_METERING == 1)
/*
 * @brief 省电模式配置
 */
typedef struct
{
    uint8_t enable;            // 开关状态，1为开启，0为关闭
    double max_elec;           // 限制使用的最大用电量，单位KWH
} switch_save_elec_mode_t;

/*
 * @brief 功率触发模式配置
 */
typedef struct
{
    uint8_t enable;             // 开关状态，1为开启，0为关闭
    uint8_t type;               // 工作模式，1为下限触发，0为上限触发
    float power;                // 限制功率
} switch_pow_trig_mode_t;

/*
 * @brief 省电模式配置标识符
 */
typedef enum
{
    SAVE_ELEC_ENABLE = 0,       // 标识switch_save_elec_mode_t中的enable
    SAVE_ELEC_MAX_ELEC          // 标识switch_save_elec_mode_t中的max_elec
} SAVE_ELEC_FLAG_E;

/*
 * @brief 功率触发模式配置标识符
 */
typedef enum
{
    POW_TRIG_ENABLE = 0,       // 标识switch_pow_trig_mode_t中的enable
    POW_TRIG_TYPE,             // 标识switch_pow_trig_mode_t中的type
    POW_TRIG_POWER             // 标识switch_pow_trig_mode_t中的power
} POW_TRIG_FLAG_E;
#endif
/*
 * @brief 配置数据key 定义
 */
typedef enum
{
    SWITCH_KEY_VERSION = 0,         //版本
    SWITCH_KEY_ONOFF = 1,           //开关机
    SWITCH_KEY_INIT_FLAG = 2,
#if defined(OUTLET_ELEC_METERING) && (OUTLET_ELEC_METERING == 1)
    SWITCH_KEY_SAVE_ELEC_MODE = 3,  // 省电模式
    SWITCH_KEY_POW_TRIG_MODE = 4,   // 功率触发模式
#endif
    SWITCH_KEY_MAX
}SWITCH_CFG_KEY_E;

/*
 * @brief 开关配置标识符
 */
typedef enum
{
    SWITCH_CFG_ONOFF = 0,       // 标识switch_flash_data_t中的switch_onoff
    SWITCH_CFG_INIT_FLAG,       // 标识switch_flash_data_t中的switch_init_flag
#if defined(OUTLET_ELEC_METERING) && (OUTLET_ELEC_METERING == 1)
    SWITCH_CFG_SAVE_ELEC_MODE,  // 标识switch_flash_data_t中的switch_init_flag
    SWITCH_CFG_POW_TRIG_MODE,// 标识switch_flash_data_t中的switch_init_flag
#endif
    SWITCH_CFG_UNKNOW,          // 未知
} SWITCH_CFG_FLAG_E;

/*
 * @brief 开关存储的flash数据
 */
typedef struct
{
    uint8_t switch_onoff;           // 开关状态，1为开启，0为关闭
    uint8_t switch_init_flag;       // 成功从flash中读取到数据，该标志位置位1，默认为0
#if defined(OUTLET_ELEC_METERING) && (OUTLET_ELEC_METERING == 1)
    switch_save_elec_mode_t save_elec;      // 省电模式配置
    switch_pow_trig_mode_t pow_trig;        // 功率触发模式配置
#endif
} switch_flash_data_t;


/**
 * @brief 获取开关的配置
 * @param[in]  SWITCH_CFG_FLAG_E    [标识符]
 * @return     const void*          [配置值指针]
 */
const void* switch_get_config(SWITCH_CFG_FLAG_E flag);

/**
 * @brief 更新开关的配置
 * @param[in]  SWITCH_CFG_FLAG_E    [标识符]
 * @param[in]  arg                  [配置指针]
 * @return     int                  [成功/失败]
 */
int switch_update_config(SWITCH_CFG_FLAG_E flag, const void* arg);

/**
 * @brief 从flash加载开关配置
 * @param[in]  SWITCH_ACT_SRC_E         [动作来源]
 * @return void
 */
void switch_load_config(OUTLET_ACT_SRC_E src);

/**
 * @brief 清除开关配置
 * @param void
 * @return int
 */
int switch_clear_config(void);

/**
 * @brief 保存开关数据到flash
 * @param[in]  switch_flash_data_t  [开关配置]
 * @return     int8_t               [成功/失败]
 */
int8_t switch_save_config(switch_flash_data_t data);

#ifdef __cplusplus
}
#endif

#endif