/*
 * Copyright © Vesync Technologies Co.Ltd. 2019-2021. All rights reserved.
 *
 * This file is subject to the terms and conditions defined in
 * file 'LICENSE', which is part of this source code package.
 * Tuan PM <tuanpm at live dot com>
 */


#include <stdint.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#include "mbedtls/platform.h"

#include "vesync_task.h"
#include "vesync_memory.h"
#include "vhal_utils.h"
#include "vhal_wifi.h"
#include "vesync_common.h"

#include "mqtt_util.h"
#include "mqtt_msg.h"
#include "mqtt_outbox.h"
#include "transport_ssl.h"
#include "vesync_mqtt_private.h"
#include "vesync_ca_cert.h"
#include "vesync_flash_internal.h"
#include "vesync_device_internal.h"

static vesync_mqtt_client_t* s_mqtt_client = NULL;


/**
* @brief       move pending msg into queue
* @param[in]   client               [client handle]
* @return      int                  [success or fail]
*/
static void mqtt_enqueue(vesync_mqtt_client_t * client)
{
    MQTT_UTIL_MEM_CHECK(client, return);

    SDK_LOG(LOG_DEBUG, "mqtt_enqueue id: %d, type=%d, pending_msg_count=%d\n",
             client->mqtt_state.pending_msg_id, client->mqtt_state.pending_msg_type, client->mqtt_state.pending_msg_count);

    if (client->mqtt_state.pending_msg_count > 0)
    {
        outbox_message_t msg = { 0 };
        msg.data = client->mqtt_state.outbound_message->data;
        msg.len =  client->mqtt_state.outbound_message->length;
        msg.msg_id = client->mqtt_state.pending_msg_id;
        msg.msg_type = client->mqtt_state.pending_msg_type;
        msg.msg_qos = client->mqtt_state.pending_publish_qos;
        //Copy to queue buffer
        outbox_enqueue(client->outbox, &msg, mqtt_util_tick_get_ms());
    }
}

/**
* @brief       Writes data into trnasport
* @param[in]   client               [client handle]
* @return      int                  [success or fail]
*/
static int mqtt_write_data(vesync_mqtt_client_t * client)
{
    int write_len = client->transport->_write(client->transport,
                                    (char *)client->mqtt_state.outbound_message->data,
                                    client->mqtt_state.outbound_message->length,
                                    client->network_timeout_ms);

    if (write_len < 0)
    {
        SDK_LOG(LOG_ERROR, "Error write data, written len = %d\n", write_len);
        MQTT_LOG_ERROR("write error, ret=%d, errno=%d.", write_len, errno);
        VERR_UPLOAD(VERR_MQTT_SEND_DATA_FAIL, errno);
        return SDK_FAIL;
    }
    else if (write_len == 0)
    {
        SDK_LOG(LOG_ERROR, "Write data timeout\n");
    }
    else
    {
        client->keepalive_tick = mqtt_util_tick_get_ms();
    }

    return SDK_OK;
}

/**
* @brief       Dispatches mqtt event to application layer
* @param[in]   client               [client handle]
* @return      int                  [success or fail]
*/
static int vesync_mqtt_dispatch_event(vesync_mqtt_client_t * client)
{
    if (client->event_handle)
    {
        return client->event_handle(&client->event);
    }
    return SDK_FAIL;
}

/**
* @brief       Dispatches mqtt event with id to application layer
* @param[in]   client               [client handle]
* @param[in]   offset
* @return      int                  [success or fail]
*/
static int vesync_mqtt_dispatch_event_with_msgid(vesync_mqtt_client_t * client, uint32_t offset)
{
    client->event.msg_id = mqtt_get_id(client->mqtt_state.in_buffer + offset, client->mqtt_state.in_buffer_length - offset);
    return vesync_mqtt_dispatch_event(client);
}

/**
* @brief       Aborts mqtt connection
* @param[in]   client               [client handle]
* @return      int                  [success or fail]
*/
static int vesync_mqtt_abort_connection(vesync_mqtt_client_t * client)
{
#ifdef MQTT_LOG_ENABLE
    /* inform mqtt connect error to event handler */
    client->event.data = (char*)mqtt_log_get_err_msg();
    client->event.data_len = strlen(client->event.data);
#endif

    client->transport->_close(client->transport);

    client->state = MQTT_STATE_DISCONNECTED;
    SDK_LOG(LOG_DEBUG, "Reconnect after %d ms\n", client->wait_reconnect_ms);
    client->wait_for_ping_resp = false;
    client->ping_missed_cnt = 0;

    client->event.event_id = MQTT_EVENT_DISCONNECTED;
    vesync_mqtt_dispatch_event_with_msgid(client, 0);

    return SDK_OK;
}

/**
* @brief       Delivers published message to application layer
* @param[in]   client               [client handle]
* @param[in]   message              [point to message]
* @param[in]   length               [length of message]
*/
static void deliver_publish(vesync_mqtt_client_t * client, uint8_t *message, int length)
{
    const char *mqtt_topic = NULL, *mqtt_data = NULL;
    uint32_t mqtt_topic_length, mqtt_data_length;

    MQTT_UTIL_MEM_CHECK(client, return);
    MQTT_UTIL_MEM_CHECK(message, return);

    mqtt_topic_length = length;
    mqtt_topic = mqtt_get_publish_topic(message, &mqtt_topic_length);
    if (NULL == mqtt_topic)
    {
        return;
    }

    mqtt_data_length = length;
    mqtt_data = mqtt_get_publish_data(message, &mqtt_data_length);
    if (NULL == mqtt_data)
    {
        return;
    }

    client->event.msg_id = mqtt_get_id(message, length);

    SDK_LOG(LOG_DEBUG, "Get data len = %d, topic len = %d\n", mqtt_data_length, mqtt_topic_length);
    client->event.event_id = MQTT_EVENT_DATA;
    client->event.data = (char *)mqtt_data;
    client->event.data_len = mqtt_data_length;
    client->event.topic = (char *)mqtt_topic;
    client->event.topic_len = mqtt_topic_length;
    vesync_mqtt_dispatch_event(client);
}

/**
* @brief       Identifies whether it is a valid message according to the message type and ID
* @param[in]   client               [client handle]
* @param[in]   msg_type             [message type]
* @param[in]   msg_id               [message id]
* @return      bool                 [true - valid; false - invalid]
*/
static bool is_valid_mqtt_msg(vesync_mqtt_client_t * client, int msg_type, int msg_id)
{
    MQTT_UTIL_MEM_CHECK(client, return false);

    SDK_LOG(LOG_DEBUG, "pending_id = %d, pending_msg_count = %d\n", client->mqtt_state.pending_msg_id, client->mqtt_state.pending_msg_count);
    if (0 == client->mqtt_state.pending_msg_count)
    {
        return false;
    }

    if (SDK_OK == outbox_set_pending(client->outbox, msg_id, CONFIRMED))
    {
        outbox_delete(client->outbox, msg_id, msg_type);
        client->mqtt_state.pending_msg_count--;
        return true;
    }

    return false;
}

/**
* @brief       move pending msg into queue when oversized
* @param[in]   client               [client handle]
* @param[in]   remaining_data       [point to remaining data]
* @param[in]   remaining_len        [length of remaining data]
* @return      int                  [success or fail]
*/
static void mqtt_enqueue_oversized(vesync_mqtt_client_t * client, uint8_t *remaining_data, int remaining_len)
{
    MQTT_UTIL_MEM_CHECK(client, return);

    SDK_LOG(LOG_DEBUG, "mqtt_enqueue_oversized id: %d, type=%d, pending_msg_count=%d\n",
             client->mqtt_state.pending_msg_id, client->mqtt_state.pending_msg_type, client->mqtt_state.pending_msg_count);

    outbox_message_t msg = { 0 };
    msg.data = client->mqtt_state.outbound_message->data;
    msg.len =  client->mqtt_state.outbound_message->length;
    msg.msg_id = client->mqtt_state.pending_msg_id;
    msg.msg_type = client->mqtt_state.pending_msg_type;
    msg.msg_qos = client->mqtt_state.pending_publish_qos;
    msg.remaining_data = remaining_data;
    msg.remaining_len = remaining_len;
    //Copy to queue buffer
    outbox_enqueue(client->outbox, &msg, mqtt_util_tick_get_ms());
}

/**
 * @brief       resend mqtt messages in queue
 * @param[in]   client               [client handle]
 * @param[in]   item                 [item handle]
 * @return      int                  [success or fail]
 */
static int mqtt_resend_queued(vesync_mqtt_client_t * client, outbox_item_handle_t item)
{
    if (NULL == client || NULL == item)
    {
        SDK_LOG(LOG_ERROR, "null parameter\n");
        return SDK_FAIL;
    }

    // decode queued data
    client->mqtt_state.outbound_message->data = outbox_item_get_data(item, (size_t *)&client->mqtt_state.outbound_message->length, &client->mqtt_state.pending_msg_id,
            &client->mqtt_state.pending_msg_type, &client->mqtt_state.pending_publish_qos);
    // set duplicate flag for QoS-1 and QoS-2 messages
    if (client->mqtt_state.pending_msg_type == MQTT_MSG_TYPE_PUBLISH && client->mqtt_state.pending_publish_qos > MQTT_QOS0)
    {
        mqtt_set_dup(client->mqtt_state.outbound_message->data);
    }

    SDK_LOG(LOG_DEBUG, "resend msg:id=%d, type=%d, qos=%d, len=%d \n", client->mqtt_state.pending_msg_id, client->mqtt_state.pending_msg_type, \
                                                                client->mqtt_state.pending_publish_qos, client->mqtt_state.outbound_message->length);

    // try to resend the data
    if (mqtt_write_data(client) != SDK_OK)
    {
        SDK_LOG(LOG_ERROR, "Error to resend data ");
        vesync_mqtt_abort_connection(client);
        return SDK_FAIL;
    }
    return SDK_OK;
}

/**
 * @brief       send mqtt ping
 * @param[in]   client               [client handle]
 * @return      int                  [success or fail]
 */
static int vesync_mqtt_client_ping(vesync_mqtt_client_t * client)
{
    client->mqtt_state.outbound_message = mqtt_msg_pingreq(&client->mqtt_state.mqtt_connection);
    if (client->mqtt_state.outbound_message->length == 0)
    {
        SDK_LOG(LOG_ERROR, "Ping message cannot be created");
        return SDK_FAIL;
    }

    if (mqtt_write_data(client) != SDK_OK)
    {
        SDK_LOG(LOG_ERROR, "Error sending ping\n");
        return SDK_FAIL;
    }

    SDK_LOG(LOG_DEBUG, "Sent PING successful\n");
    return SDK_OK;
}

/**
 * @brief       subscribe mqtt topic
 * @param[in]   client               [client handle]
 * @param[in]   topic                [mqtt topic]
 * @param[in]   qos                  [qos level]
 * @return      int                  [success or fail]
 */
static int vesync_mqtt_client_subscribe(vesync_mqtt_client_t *client, const char *topic, int qos, void(*ack_cb)(void))
{
    SDK_LOG(LOG_DEBUG, "Subscribe...\n");

    client->mqtt_state.outbound_message = mqtt_msg_subscribe(&client->mqtt_state.mqtt_connection,
                                          topic, qos,
                                          &client->mqtt_state.pending_msg_id);
    if (0 == client->mqtt_state.outbound_message->length)
    {
        SDK_LOG(LOG_ERROR, "Subscribe message cannot be created");
        VERR_UPLOAD(VERR_MQTT_SUBSCRIBED_FAIL, 0);
        return SDK_FAIL;
    }

    client->mqtt_state.pending_msg_type = mqtt_get_type(client->mqtt_state.outbound_message->data);
    client->mqtt_state.pending_msg_count ++;
    mqtt_enqueue(client); //move pending msg to outbox (if have)
    outbox_set_pending(client->outbox, client->mqtt_state.pending_msg_id, TRANSMITTED);
    if (ack_cb)
    {
        outbox_set_ack_cb(client->outbox, client->mqtt_state.pending_msg_id, ack_cb);
    }

    if (mqtt_write_data(client) != SDK_OK)
    {
        SDK_LOG(LOG_ERROR, "Error to subscribe topic=%s, qos=%d\n", topic, qos);
        VERR_UPLOAD(VERR_MQTT_SUBSCRIBED_FAIL, 0);
        return SDK_FAIL;
    }

    return SDK_OK;
}

/**
* @brief       Destroys and frees config of client
* @param[in]   client               [client handle]
* @return      int                  [success or fail]
*/
static int vesync_mqtt_destroy_config(vesync_mqtt_client_t *client)
{
    VCOM_SAFE_FREE(client->connect_info.will_topic);
    VCOM_SAFE_FREE(client->connect_info.will_message);
    VCOM_SAFE_FREE(client->connect_info.client_id);
    VCOM_SAFE_FREE(client->connect_info.username);
    VCOM_SAFE_FREE(client->connect_info.password);
    memset(&client->connect_info, 0, sizeof(mqtt_connect_info_t));

    VCOM_SAFE_FREE(client->host);
    VCOM_SAFE_FREE(client->ip);
    return SDK_OK;
}

/**
 * @brief       Destroys the client handle
 * @param[in]   client                      [mqtt client handle]
 * @return      int
 */
static int vesync_mqtt_deinit(vesync_mqtt_client_t *client)
{
    MQTT_UTIL_MEM_CHECK(client, return SDK_FAIL);

    vesync_mqtt_destroy_config(client);

    VCOM_SAFE_FREE(client->transport);
    VCOM_SAFE_FREE(client->mqtt_state.in_buffer);
    VCOM_SAFE_FREE(client->mqtt_state.out_buffer);
    outbox_destroy(client->outbox);

    if (client->queue)
    {
        vesync_queue_free(client->queue);
    }
    if (client->lock)
    {
        vesync_recursive_mutex_free(client->lock);
    }

    VCOM_SAFE_FREE(client);
    s_mqtt_client = NULL;

    return SDK_OK;
}

/**
 * @brief       Set configuration structure, typically used when updating the config (i.e. on "before_connect" event)
 * @param[in]   client                      [mqtt client handle]
 * @param[in]   config                      [mqtt configuration structure]
 * @return      int
 */
static int vesync_mqtt_set_config(vesync_mqtt_client_t *client, mqtt_connect_data_t *config)
{
    vesync_transport_handle_t ssl = client->transport;
    int ca_cert_len = 0;
    int client_key_len = 0;
    const unsigned char *ca_cert = NULL;
    const unsigned char *client_cert = NULL;
    unsigned char *client_key = NULL;
    static unsigned char *s_client_key = NULL;

    MQTT_UTIL_MEM_CHECK(config->host, goto _mqtt_set_config_failed);
    MQTT_UTIL_MEM_CHECK(config->username, goto _mqtt_set_config_failed);
    MQTT_UTIL_MEM_CHECK(config->password, goto _mqtt_set_config_failed);

    MQTT_UTIL_SAFE_FREE(client->host);
    client->host = config->host;

    MQTT_UTIL_SAFE_FREE(client->ip);
    client->ip = config->ip;

    client->port = config->port;

    MQTT_UTIL_SAFE_FREE(client->connect_info.username);
    client->connect_info.username = config->username;

    MQTT_UTIL_SAFE_FREE(client->connect_info.password);
    client->connect_info.password = config->password;

    SDK_LOG(LOG_DEBUG, "tls:%d\n", config->tls);

    if (config->tls == client->tls)
    {
        return SDK_OK;
    }
    client->tls = config->tls;

    switch (config->tls)
    {
    case MQTT_TLS_CA_NONE:
        ca_cert = NULL;
        client_cert = vesync_mqtt_client_cert_der;
        client_key_len = vesync_flash_brand_aes_decrypt(vesync_mqtt_client_key_der,
                                                        vesync_mqtt_client_key_der_len,
                                                        &client_key);
        break;
    case MQTT_TLS_CA_SERVER:
        ca_cert = vesync_mqtt_ca_cert_der;
        ca_cert_len = vesync_mqtt_ca_cert_der_len;
        client_cert = vesync_mqtt_client_cert_der;
        client_key_len = vesync_flash_brand_aes_decrypt(vesync_mqtt_client_key_der,
                                                        vesync_mqtt_client_key_der_len,
                                                        &client_key);
        break;
    case MQTT_TLS_CA_PRODUTION:
        ca_cert = vesync_mqtt_production_ca_cert_der;
        ca_cert_len = vesync_mqtt_production_ca_cert_der_len;
        client_cert = vesync_mqtt_client_cert_der;
        client_key_len = vesync_flash_brand_aes_decrypt(vesync_mqtt_client_key_der,
                                                        vesync_mqtt_client_key_der_len,
                                                        &client_key);
        break;
    default:
        SDK_LOG(LOG_ERROR, "tls ca option error\n");
        break;
    }

    if (ca_cert)
    {
        vesync_transport_ssl_set_cert_data_der(ssl, (const char *)ca_cert, ca_cert_len);
    }
    if (client_cert)
    {
        vesync_transport_ssl_set_client_cert_data_der(ssl, (const char *)client_cert, vesync_mqtt_client_cert_der_len);
    }
    if (client_key)
    {
        VCOM_SAFE_FREE(s_client_key);
        s_client_key = client_key;
        vesync_transport_ssl_set_client_key_data_der(ssl, (const char *)client_key, client_key_len);
    }

    return SDK_OK;
_mqtt_set_config_failed:
    VERR_UPLOAD(VERR_LINK_MOD_COM(VERR_MEM_ALLOC_FAIL), vhal_get_free_heap_size());
    VCOM_SAFE_FREE(config->host);
    VCOM_SAFE_FREE(config->username);
    VCOM_SAFE_FREE(config->password);
    return SDK_FAIL;
}


/**
* @brief       Mqtt publish msg
* @param[in]   client               [client handle]
* @return      int                  [success or fail]
*/
static int vesync_mqtt_client_publish(vesync_mqtt_client_t * client, const char *topic, const char *data, int len, int qos, int retain, void (*ack_cb)(void))
{
    int ret = 0;
    uint16_t pending_msg_id = 0;

    if (len <= 0) {
        len = strlen(data);
    }

    mqtt_message_t *publish_msg = mqtt_msg_publish(&client->mqtt_state.mqtt_connection,
                                  topic, data, len, qos, retain, &pending_msg_id);

    if (0 == publish_msg->length)
    {
        SDK_LOG(LOG_ERROR, "Publish message cannot be created\n");
        VERR_UPLOAD(VERR_MQTT_SEND_DATA_FAIL, 0);
        return -1;
    }

    /* We have to set as pending all the qos>0 messages) */
    client->mqtt_state.outbound_message = publish_msg;
    if (qos > MQTT_QOS0)
    {
        client->mqtt_state.pending_msg_type = mqtt_get_type(client->mqtt_state.outbound_message->data);
        client->mqtt_state.pending_msg_id = pending_msg_id;
        client->mqtt_state.pending_publish_qos = qos;
        client->mqtt_state.pending_msg_count ++;
        // by default store as QUEUED (not transmitted yet) only for messages which would fit outbound buffer
        if (0 == client->mqtt_state.mqtt_connection.message.fragmented_msg_total_length)
        {
            mqtt_enqueue(client);
        }
        else
        {
            int first_fragment = client->mqtt_state.outbound_message->length - client->mqtt_state.outbound_message->fragmented_msg_data_offset;
            mqtt_enqueue_oversized(client, ((uint8_t *)data) + first_fragment, len - first_fragment);
        }
    }

    /* Skip sending if not connected (rely on resending) */
    if (client->state != MQTT_STATE_CONNECTED)
    {
        SDK_LOG(LOG_DEBUG, "Publish: client is not connected");
        ret = -1;
        goto cannot_publish;
    }

    /* Provide support for sending fragmented message if it doesn't fit buffer */
    int remaining_len = len;
    const char *current_data = data;
    bool sending = true;

    while (sending)  {
        if (mqtt_write_data(client) != SDK_OK)
        {
            SDK_LOG(LOG_ERROR, "Error to public data to topic=%s, qos=%d\n", topic, qos);
            // not all producet open mqtt_lock, discard the abort operation for safe.
            //vesync_mqtt_abort_connection(client);
            ret = -1;
            goto cannot_publish;
        }

        int data_sent = client->mqtt_state.outbound_message->length - client->mqtt_state.outbound_message->fragmented_msg_data_offset;
        client->mqtt_state.outbound_message->fragmented_msg_data_offset = 0;
        client->mqtt_state.outbound_message->fragmented_msg_total_length = 0;
        remaining_len -= data_sent;
        current_data +=  data_sent;

        if (remaining_len > 0)
        {
            mqtt_connection_t* connection = &client->mqtt_state.mqtt_connection;
            SDK_LOG(LOG_DEBUG, "Sending fragmented message, remains to send %d bytes of %d\n", remaining_len, len);

            if (remaining_len > connection->buffer_length)
            {
                // Continue with sending
                memcpy(connection->buffer, current_data, connection->buffer_length);
                connection->message.length = connection->buffer_length;
                sending = true;
            }
            else
            {
                memcpy(connection->buffer, current_data, remaining_len);
                connection->message.length = remaining_len;
                sending = true;
            }
            connection->message.data = connection->buffer;
            client->mqtt_state.outbound_message = &connection->message;
        }
        else
        {
            // Message was sent correctly
            sending = false;
        }
    }

    if (qos > MQTT_QOS0)
    {
        //Tick is set after transmit to avoid retransmitting too early due slow network speed / big messages
        outbox_set_tick(client->outbox, pending_msg_id, vhal_utils_get_system_time_ms_int());
        outbox_set_pending(client->outbox, pending_msg_id, TRANSMITTED);
        if (ack_cb)
        {
            outbox_set_ack_cb(client->outbox, pending_msg_id, ack_cb);
        }
    }

    return pending_msg_id;

cannot_publish:
    // clear out possible fragmented publish if failed or skipped
    client->mqtt_state.outbound_message->fragmented_msg_total_length = 0;
    if (qos == MQTT_QOS0)
    {
        SDK_LOG(LOG_WARN, "Publish: Losing qos0 data when client not connected");
    }

    return ret;
}


/**
* @brief       Exchange connect massage
* @param[in]   client               [client handle]
* @return      int                  [success or fail]
*/
static int vesync_mqtt_connect_msg_exchange(vesync_mqtt_client_t *client)
{
    int write_len, read_len, connect_rsp_code;
    SDK_LOG(LOG_DEBUG, "Connecting...\n");

    mqtt_msg_init(&client->mqtt_state.mqtt_connection,
                  client->mqtt_state.out_buffer,
                  client->mqtt_state.out_buffer_length);

    client->mqtt_state.outbound_message = mqtt_msg_connect(&client->mqtt_state.mqtt_connection,
                                          client->mqtt_state.connect_info);

    client->mqtt_state.pending_msg_type = mqtt_get_type(client->mqtt_state.outbound_message->data);
    client->mqtt_state.pending_msg_id = mqtt_get_id(client->mqtt_state.outbound_message->data,
                                        client->mqtt_state.outbound_message->length);
    SDK_LOG(LOG_INFO, "Sending MQTT CONNECT message, type: %d, id: %04X\n",
             client->mqtt_state.pending_msg_type,
             client->mqtt_state.pending_msg_id);

    write_len = client->transport->_write(client->transport,
                                (char *)client->mqtt_state.outbound_message->data,
                                client->mqtt_state.outbound_message->length,
                                client->network_timeout_ms);
    if (write_len < 0)
    {
        SDK_LOG(LOG_ERROR, "Writing failed, errno= %d\n", errno);
        MQTT_LOG_ERROR("Writing failed, ret=%d, errno=%d.", write_len, errno);
        VERR_UPLOAD(VERR_MQTT_CONNECT_FAIL, errno);
        return SDK_FAIL;
    }

    /* wait configured network timeout for broker connection response */
    uint64_t connack_recv_started = mqtt_util_tick_get_ms();
    do
    {
        read_len = client->transport->_read(client->transport,
                              (char *)client->mqtt_state.in_buffer,
                              client->mqtt_state.in_buffer_length,
                              client->network_timeout_ms);
    } while (0 == read_len && mqtt_util_tick_get_ms() - connack_recv_started < client->network_timeout_ms);
    if (read_len < 0)
    {
        SDK_LOG(LOG_ERROR, "Error network response\n");
        MQTT_LOG_ERROR("Read error or timeout: ret=%d, errno=%d\n", read_len, errno);
        VERR_UPLOAD(VERR_MQTT_CONNECT_FAIL, errno);
        return SDK_FAIL;
    }
    if (mqtt_get_type(client->mqtt_state.in_buffer) != MQTT_MSG_TYPE_CONNACK)
    {
        SDK_LOG(LOG_ERROR, "Invalid MSG_TYPE response: %d, read_len: %d\n", mqtt_get_type(client->mqtt_state.in_buffer), read_len);
        MQTT_LOG_ERROR("Invalid MSG_TYPE response: %d, read_len: %d\n", mqtt_get_type(client->mqtt_state.in_buffer), read_len);
        VERR_UPLOAD(VERR_MQTT_CONNECT_FAIL, mqtt_get_type(client->mqtt_state.in_buffer));
        return SDK_FAIL;
    }
    connect_rsp_code = mqtt_get_connect_return_code(client->mqtt_state.in_buffer);
    switch (connect_rsp_code)
    {
        case CONNECTION_ACCEPTED:
            SDK_LOG(LOG_DEBUG, "Connected\n");
            return SDK_OK;
        case CONNECTION_REFUSE_PROTOCOL:
            SDK_LOG(LOG_WARN, "Connection refused, bad protocol\n");
            MQTT_LOG_ERROR("Connection refused, bad protocol");
            VERR_UPLOAD(VERR_MQTT_CONNECT_FAIL, CONNECTION_REFUSE_PROTOCOL);
            return SDK_FAIL;
        case CONNECTION_REFUSE_SERVER_UNAVAILABLE:
            SDK_LOG(LOG_WARN, "Connection refused, server unavailable\n");
            MQTT_LOG_ERROR("Connection refused, server unavailable");
            VERR_UPLOAD(VERR_MQTT_CONNECT_FAIL, CONNECTION_REFUSE_SERVER_UNAVAILABLE);
            return SDK_FAIL;
        case CONNECTION_REFUSE_BAD_USERNAME:
            SDK_LOG(LOG_WARN, "Connection refused, bad username or password\n");
            MQTT_LOG_ERROR("Connection refused, bad username or password");
            VERR_UPLOAD(VERR_MQTT_CONNECT_FAIL, CONNECTION_REFUSE_BAD_USERNAME);
            return SDK_FAIL;
        case CONNECTION_REFUSE_NOT_AUTHORIZED:
            SDK_LOG(LOG_WARN, "Connection refused, not authorized\n");
            MQTT_LOG_ERROR("Connection refused, not authorized");
            VERR_UPLOAD(VERR_MQTT_CONNECT_FAIL, CONNECTION_REFUSE_NOT_AUTHORIZED);
            return SDK_FAIL;
        default:
            SDK_LOG(LOG_WARN, "Connection refused, Unknow reason\n");
            MQTT_LOG_ERROR("Connection refused, Unknow reason");
            VERR_UPLOAD(VERR_MQTT_CONNECT_FAIL, -1);
            return SDK_FAIL;
    }
    return SDK_OK;
}

/**
* @brief       Establish a new connect
* @param[in]   client               [client handle]
* @return      int                  [success or fail]
*/
static int vesync_mqtt_new_connect(vesync_mqtt_client_t *client)
{
    int ret = SDK_OK;
    struct addrinfo *ai = NULL;
    struct addrinfo addr_info = {0};
    struct sockaddr ai_addr = {0};

    MQTT_LOG_SET_STEP(MLOG_STEP_CONNECTING);

    ai = vesync_transport_resolve_host(client->host);
    if (ai)
    {
        memcpy(&ai_addr, ai->ai_addr, sizeof(struct sockaddr));
        memcpy(&addr_info, ai, sizeof(struct addrinfo));
        addr_info.ai_addr = &ai_addr;
        freeaddrinfo(ai);

        /* notify dns success */
        struct sockaddr_in *p_ai_addr = (struct sockaddr_in *)(&ai_addr);
        client->event.data = (char*)inet_ntoa(p_ai_addr->sin_addr);
        client->event.data_len = strlen(client->event.data);
        client->event.event_id = MQTT_EVENT_DNS_RESOLVED;
        vesync_mqtt_dispatch_event(client);
    }
    else 
    {
        client->event.data = NULL;
        client->event.data_len = 0;
        client->event.event_id = MQTT_EVENT_DNS_RESOLVE_FAILED;
        vesync_mqtt_dispatch_event(client);
        if (client->ip)
        {
            /* dns fail, and do not have cache ip */
            SDK_LOG(LOG_ERROR, "dns fail, use cache ip\n");
            addr_info.ai_family = AF_INET;
            addr_info.ai_socktype = SOCK_STREAM;
            addr_info.ai_protocol = IPPROTO_IP;
            addr_info.ai_addrlen = 16;
            addr_info.ai_addr = &ai_addr;

            struct sockaddr_in *p_ai_addr = (struct sockaddr_in *)(&ai_addr);
            p_ai_addr->sin_family = AF_INET;
            inet_aton(client->ip, &p_ai_addr->sin_addr);
        }
        else
        {
            SDK_LOG(LOG_ERROR, "dns fail, no cache ip\n");
            ret = SDK_FAIL;
            goto exit;
        }
    }

    VESYNC_PRINTF_FREE_HEAP();
    if (client->transport->_connect(client->transport,
                            &addr_info,
                            client->host,
                            client->port,
                            client->network_timeout_ms) < 0)
    {
        SDK_LOG(LOG_ERROR, "Error transport connect\n");
        ret = SDK_FAIL;
        goto exit;
    }

    SDK_LOG(LOG_DEBUG, "Connected to mqtts://%s:%d\n", client->host, client->port);
    VESYNC_PRINTF_FREE_HEAP();
    if (vesync_mqtt_connect_msg_exchange(client) != SDK_OK)
    {
        SDK_LOG(LOG_INFO, "Error MQTT Connected\n");
        ret = SDK_FAIL;
        goto exit;
    }

    MQTT_LOG_SET_STEP(MLOG_STEP_CONNECTED);

    client->event.event_id = MQTT_EVENT_CONNECTED;
    client->event.session_present = mqtt_get_connect_session_present(client->mqtt_state.in_buffer);
    vesync_mqtt_dispatch_event_with_msgid(client, 0);

    VESYNC_PRINTF_FREE_HEAP();

exit:
    if (SDK_OK != ret)
    {
        client->transport->_close(client->transport);
    }

    return ret;
}

/**
 * @brief       process mqtt received message
 * @param[in]   client               [client handle]
 * @return      int                  [success or fail]
 */
static int mqtt_process_receive(vesync_mqtt_client_t *client)
{
    int read_len;
    uint8_t msg_type;
    uint8_t msg_qos;
    uint16_t msg_id;
    uint32_t massege_len;
    uint32_t offset = 0;
    uint8_t store_byte;

    read_len = client->transport->_read(client->transport, \
                    (char *)client->mqtt_state.in_buffer + client->mqtt_state.in_buffer_offset, \
                    client->mqtt_state.in_buffer_length - client->mqtt_state.in_buffer_offset, \
                    0);

    if (read_len < 0)
    {
        SDK_LOG(LOG_ERROR, "Read error or end of stream errno=%d.\n", errno);
        MQTT_LOG_ERROR("Read error or end of stream: ret=%d, errno=%d.", read_len, errno);
        VERR_UPLOAD(VERR_MQTT_RECV_DATA_FAIL, errno);
        client->mqtt_state.in_buffer_offset = 0;
        return SDK_FAIL;
    }
    if (0 == read_len)
    {
        client->mqtt_state.in_buffer_offset = 0;
        return SDK_OK;
    }

    read_len += client->mqtt_state.in_buffer_offset;
    client->mqtt_state.in_buffer_offset = 0;

    while (offset < read_len)
    {
        if (!mqtt_msg_complete(&client->mqtt_state.in_buffer[offset], read_len - offset))
        {
            SDK_LOG(LOG_DEBUG, "Message is no complete, left size=%d\n", read_len - offset);
            if (offset != 0)
            {
                for (uint32_t i = 0; i < read_len - offset; i++)
                {
                    client->mqtt_state.in_buffer[i] = client->mqtt_state.in_buffer[offset + i];
                }
            }
            client->mqtt_state.in_buffer_offset = read_len - offset;
            break;
        }

        massege_len = mqtt_get_total_length(&client->mqtt_state.in_buffer[offset], read_len - offset);

        if (massege_len > client->mqtt_state.in_buffer_length)
        {
            SDK_LOG(LOG_ERROR, "message is too big, insufficient buffer size!\n");
            break;
        }

        if (!mqtt_msg_has_valid_hdr(&client->mqtt_state.in_buffer[offset], read_len - offset))
        {
            SDK_LOG(LOG_ERROR, "Received a message with an invalid header!\n");
            offset += massege_len;
            continue;
        }

        // If the message was valid, get the type, quality of service and id of the message
        msg_type = mqtt_get_type(&client->mqtt_state.in_buffer[offset]);
        msg_qos = mqtt_get_qos(&client->mqtt_state.in_buffer[offset]);
        msg_id = mqtt_get_id(&client->mqtt_state.in_buffer[offset], read_len - offset);
        SDK_LOG(LOG_DEBUG, "msg_type=%d, msg_id=%d\n", msg_type, msg_id);

        switch (msg_type)
        {
        case MQTT_MSG_TYPE_SUBACK:
            if (is_valid_mqtt_msg(client, MQTT_MSG_TYPE_SUBSCRIBE, msg_id))
            {
                SDK_LOG(LOG_DEBUG, "Subscribe successful\n");
                client->event.event_id = MQTT_EVENT_SUBSCRIBED;
                vesync_mqtt_dispatch_event_with_msgid(client, offset);
            }
            break;
        case MQTT_MSG_TYPE_UNSUBACK:
            if (is_valid_mqtt_msg(client, MQTT_MSG_TYPE_UNSUBSCRIBE, msg_id))
            {
                SDK_LOG(LOG_DEBUG, "UnSubscribe successful\n");
                client->event.event_id = MQTT_EVENT_UNSUBSCRIBED;
                vesync_mqtt_dispatch_event_with_msgid(client, offset);
            }
            break;
        case MQTT_MSG_TYPE_PUBLISH:
            if (1 == msg_qos)
            {
                client->mqtt_state.outbound_message = mqtt_msg_puback(&client->mqtt_state.mqtt_connection, msg_id);
            }
            else if (2 == msg_qos)
            {
                client->mqtt_state.outbound_message = mqtt_msg_pubrec(&client->mqtt_state.mqtt_connection, msg_id);
            }

            if (1 == msg_qos || 2 == msg_qos)
            {
                SDK_LOG(LOG_DEBUG, "Queue response QoS: %d\n", msg_qos);

                if (mqtt_write_data(client) != SDK_OK)
                {
                    SDK_LOG(LOG_ERROR, "Error write qos msg response, qos = %d\n", msg_qos);
                    // TODO: Shoule reconnect?
                    // return SDK_FAIL;
                }
            }

            // Deliver the publish message
            SDK_LOG(LOG_DEBUG, "deliver_publish, read_len=%d, message_length=%d\n", read_len, massege_len);
            store_byte = client->mqtt_state.in_buffer[offset + massege_len];
            client->mqtt_state.in_buffer[offset + massege_len] = '\0';
            deliver_publish(client, &client->mqtt_state.in_buffer[offset], massege_len);
            client->mqtt_state.in_buffer[offset + massege_len] = store_byte;

            break;
        case MQTT_MSG_TYPE_PUBACK:
            if (is_valid_mqtt_msg(client, MQTT_MSG_TYPE_PUBLISH, msg_id))
            {
                SDK_LOG(LOG_DEBUG, "received MQTT_MSG_TYPE_PUBACK, finish QoS1 publish\n");
                client->event.event_id = MQTT_EVENT_PUBLISHED;
                vesync_mqtt_dispatch_event_with_msgid(client, offset);
            }
            break;
        case MQTT_MSG_TYPE_PUBREC:
            SDK_LOG(LOG_DEBUG, "received MQTT_MSG_TYPE_PUBREC\n");
            client->mqtt_state.outbound_message = mqtt_msg_pubrel(&client->mqtt_state.mqtt_connection, msg_id);
            outbox_set_pending(client->outbox, msg_id, ACKNOWLEDGED);
            mqtt_write_data(client);
            break;
        case MQTT_MSG_TYPE_PUBREL:
            SDK_LOG(LOG_DEBUG, "received MQTT_MSG_TYPE_PUBREL\n");
            client->mqtt_state.outbound_message = mqtt_msg_pubcomp(&client->mqtt_state.mqtt_connection, msg_id);
            mqtt_write_data(client);
            break;
        case MQTT_MSG_TYPE_PUBCOMP:
            SDK_LOG(LOG_DEBUG, "received MQTT_MSG_TYPE_PUBCOMP\n");
            if (is_valid_mqtt_msg(client, MQTT_MSG_TYPE_PUBLISH, msg_id))
            {
                SDK_LOG(LOG_DEBUG, "Receive MQTT_MSG_TYPE_PUBCOMP, finish QoS2 publish\n");
                client->event.event_id = MQTT_EVENT_PUBLISHED;
                vesync_mqtt_dispatch_event_with_msgid(client, offset);
            }
            break;
        case MQTT_MSG_TYPE_PINGRESP:
            SDK_LOG(LOG_DEBUG, "MQTT_MSG_TYPE_PINGRESP\n");
            client->wait_for_ping_resp = false;
            break;
        }

        offset += massege_len;
    }

    return SDK_OK;
}

/**
 * @brief       refresh mqtt connect
 * @param[in]   client               [client handle]
 */
static void vesync_mqtt_refresh_connect(vesync_mqtt_client_t *client)
{
    //Delete message after OUTBOX_EXPIRED_TIMEOUT_MS miliseconds
    int deleted = outbox_delete_expired(client->outbox, mqtt_util_tick_get_ms(), OUTBOX_EXPIRED_TIMEOUT_MS);
    client->mqtt_state.pending_msg_count -= deleted;
    if (client->mqtt_state.pending_msg_count < 0)
    {
        client->mqtt_state.pending_msg_count = 0;
    }

    // resend all non-transmitted messages first
    outbox_item_handle_t item = outbox_dequeue(client->outbox, QUEUED, NULL);
    if (item)
    {
        if (SDK_OK == mqtt_resend_queued(client, item))
        {
            outbox_set_pending(client->outbox, client->mqtt_state.pending_msg_id, TRANSMITTED);
        }
        // resend other "transmitted" messages after 1s
    }
    else if (vhal_utils_get_system_time_ms_int() - client->last_retransmit > MQTT_RESEND_PERIOD_MS)
    {
        outbox_tick_t msg_tick = 0;
        client->last_retransmit = vhal_utils_get_system_time_ms_int();
        item = outbox_dequeue(client->outbox, TRANSMITTED, &msg_tick);
        if (item && (client->last_retransmit - msg_tick > 1000))
        {
            mqtt_resend_queued(client, item);
        }
    }

    if (mqtt_util_tick_get_ms() - client->keepalive_tick > client->keepalive * 1000 / 2)
    {
        //No ping resp from last ping => Disconnected
        if (client->wait_for_ping_resp)
        {
            client->ping_missed_cnt ++;
            if (client->ping_missed_cnt >= MQTT_PING_MISSED_MAX_CNT)
            {
                SDK_LOG(LOG_ERROR, "No PING_RESP, disconnected\n");
                MQTT_LOG_ERROR("No PING_RESP, disconnected\n");
                vesync_mqtt_abort_connection(client);
                return;
            }
            else
            {
                SDK_LOG(LOG_WARN, "%d ping missed!\n", client->ping_missed_cnt);
            }
        }
        else
        {
            client->ping_missed_cnt = 0;
        }

        if (SDK_FAIL == vesync_mqtt_client_ping(client))
        {
            SDK_LOG(LOG_ERROR, "Can't send ping, disconnected\n");
            vesync_mqtt_abort_connection(client);
            return;
        }
        else
        {
            SDK_LOG(LOG_DEBUG, "PING sent\n");
            client->wait_for_ping_resp = true;
        }
    }

    // Detete confirmed messages
    outbox_cleanup(client->outbox, OUTBOX_MAX_SIZE);
}

/**
* @brief       parse mqtt event(connect,disconnec,publis)
* @param[in]   client               [client handle]
*/
static void vesync_mqtt_parse_event(vesync_mqtt_client_t *client)
{
    int wait_time = VESYNC_OS_NO_WAIT;
    vesync_mqtt_ev_t ev = {0};

    if (client->state == MQTT_STATE_DISCONNECTED)
    {
        wait_time = client->wait_reconnect_ms;
    }

    if (VOS_OK != vesync_queue_recv(client->queue, &ev, wait_time))
    {
        return;
    }

    SDK_LOG(LOG_DEBUG, "recv queue msg, id:%d\n", ev.id);
    switch(ev.id)
    {
    case MQTT_EV_CONFIG:
        if (ev.data)
        {
            mqtt_config_data_t *data = (mqtt_config_data_t*)ev.data;
            client->event_handle = data->event_handle;
            if (data->client_id)
            {
                VCOM_SAFE_FREE(client->connect_info.client_id);
                client->connect_info.client_id = data->client_id;
            }
            VCOM_SAFE_FREE(ev.data);
        }
        break;
    case MQTT_EV_CONNECT:
        if (ev.data)
        {
            if (client->state == MQTT_STATE_CONNECTED)
                vesync_mqtt_abort_connection(client);
            vesync_mqtt_set_config(client, ev.data);
            VCOM_SAFE_FREE(ev.data);
        }
        client->auto_reconnect = 1;
        client->reconnect_tick = 0;
        client->wait_reconnect_ms = MQTT_RECONNECT_TIMEOUT_MS_STEP;
        outbox_delete_all_items(client->outbox);
        break;

    case MQTT_EV_DISCONNECT:
        if (client->state == MQTT_STATE_CONNECTED)
            vesync_mqtt_abort_connection(client);
        client->auto_reconnect = 0;
        outbox_delete_all_items(client->outbox);
        break;
    case MQTT_EV_PUBLISH:
        if (client->state == MQTT_STATE_DISCONNECTED && client->auto_reconnect == 0)
        {
            VCOM_SAFE_FREE(ev.data);
        }
        else if (ev.data)
        {
            mqtt_publish_data_t *ev_data = (mqtt_publish_data_t *)ev.data;
            vesync_mqtt_client_publish(client, ev_data->topic, ev_data->data, ev_data->len, ev_data->qos, ev_data->retain, ev_data->ack_cb);
            VCOM_SAFE_FREE(ev.data);
        }
    case MQTT_EV_SUBSCRIBE:
        if (client->state != MQTT_STATE_CONNECTED)
        {
            VCOM_SAFE_FREE(ev.data);
        }
        else if (ev.data)
        {
            mqtt_publish_data_t *ev_data = (mqtt_publish_data_t *)ev.data;
            vesync_mqtt_client_subscribe(client, ev_data->topic, ev_data->qos, ev_data->ack_cb);
            VCOM_SAFE_FREE(ev.data);
        }
    default:
        break;
    }

    return;
}

/**
 * @brief       mqtt task
 * @param[in]   pv
 */
static void vesync_mqtt_task(void *pv)
{
    vesync_mqtt_client_t *client = (vesync_mqtt_client_t *) pv;

    client->state = MQTT_STATE_DISCONNECTED;
    while (1)
    {
        vesync_recursive_mutex_lock(client->lock);
        switch (client->state)
        {
        case MQTT_STATE_DISCONNECTED:
            if (!client->auto_reconnect || NULL == client->host)
            {
                break;
            }
            if (!vhal_wifi_get_link_status(0))
            {
                break;
            }
            if (mqtt_util_tick_get_ms() - client->reconnect_tick < client->wait_reconnect_ms)
            {
                break;
            }

            client->reconnect_tick = mqtt_util_tick_get_ms();
            if(SDK_OK == vesync_mqtt_new_connect(client))
            {
                client->state = MQTT_STATE_CONNECTED;
                client->keepalive_tick = mqtt_util_tick_get_ms();
                client->last_retransmit = vhal_utils_get_system_time_ms_int();
                client->wait_reconnect_ms = MQTT_RECONNECT_TIMEOUT_MS_STEP;
            }
            else
            {
                if (client->wait_reconnect_ms < MQTT_RECONNECT_TIMEOUT_MS_MAX)
                {
                    client->wait_reconnect_ms += MQTT_RECONNECT_TIMEOUT_MS_STEP;
                }
                else
                {
                    client->wait_reconnect_ms = MQTT_RECONNECT_TIMEOUT_MS_MAX;
                }
            }
            break;

        case MQTT_STATE_CONNECTED:
            // receive and process data
            if (SDK_FAIL == mqtt_process_receive(client))
            {
                vesync_mqtt_abort_connection(client);
                break;
            }

            vesync_mqtt_refresh_connect(client);
            break;
        }

        vesync_mqtt_parse_event(client);

        vesync_recursive_mutex_unlock(client->lock);

        if (MQTT_STATE_CONNECTED == client->state)
        {
            if(client->transport->_poll_read(client->transport, 1000) < 0)
            {
                vesync_mqtt_abort_connection(client);
            }
        }
    }

    client->transport->_destroy(client->transport);
    vesync_mqtt_deinit(client);
}



int vesync_mqtt_init(void)
{
    int buffer_size = MQTT_BUFFER_SIZE_BYTE;
    vesync_mqtt_client_t *client = NULL;

    client = vesync_calloc(1, sizeof(vesync_mqtt_client_t));
    MQTT_UTIL_MEM_CHECK(client, goto _mqtt_init_failed);

    client->transport = vesync_transport_ssl_init();
    MQTT_UTIL_MEM_CHECK(client->transport, goto _mqtt_init_failed);

    client->mqtt_state.in_buffer = vesync_calloc(1, buffer_size+1);
    MQTT_UTIL_MEM_CHECK(client->mqtt_state.in_buffer, goto _mqtt_init_failed);
    client->mqtt_state.in_buffer_length = buffer_size;
    client->mqtt_state.in_buffer_offset = 0;

    client->mqtt_state.out_buffer = vesync_calloc(1, buffer_size);
    MQTT_UTIL_MEM_CHECK(client->mqtt_state.out_buffer, goto _mqtt_init_failed);
    client->mqtt_state.out_buffer_length = buffer_size;

    client->mqtt_state.connect_info = &client->connect_info;
    client->connect_info.client_id = mqtt_create_string(vesync_device_get_cid());
    client->outbox = outbox_init();
    MQTT_UTIL_MEM_CHECK(client->outbox, goto _mqtt_init_failed);

    client->queue = vesync_queue_new(MQTT_QUEUE_SIZE * sizeof(vesync_mqtt_ev_t), sizeof(vesync_mqtt_ev_t));
    MQTT_UTIL_MEM_CHECK(client->queue, goto _mqtt_init_failed);

    client->lock = vesync_recursive_mutex_new();
    MQTT_UTIL_MEM_CHECK(client->lock, goto _mqtt_init_failed);

    client->keepalive = MQTT_KEEPALIVE_TICK;
    client->wait_reconnect_ms = MQTT_RECONNECT_TIMEOUT_MS_STEP;
    client->network_timeout_ms = MQTT_NETWORK_TIMEOUT_MS;

    if (SDK_OK != vesync_task_new("mqtt_task", NULL, vesync_mqtt_task, client, MQTT_TASK_STACK, MQTT_TASK_PRIORITY, NULL))
    {
        SDK_LOG(LOG_ERROR, "Error create mqtt task\n");
        goto _mqtt_init_failed;
    }

    s_mqtt_client = client;

    return SDK_OK;

_mqtt_init_failed:
    vesync_mqtt_deinit(client);
    VERR_UPLOAD(VERR_LINK_MOD_COM(VERR_MEM_ALLOC_FAIL), vhal_get_free_heap_size());
    return SDK_FAIL;
}

int vesync_mqtt_config(char *client_id, mqtt_event_callback_t event_cb)
{
    vesync_mqtt_ev_t event = {0};
    event.id = MQTT_EV_CONFIG;
    event.data = vesync_calloc(1, sizeof(mqtt_config_data_t));

    mqtt_config_data_t *data = (mqtt_config_data_t*)event.data;
    data->event_handle = event_cb;
    if (client_id)
    {
        data->client_id = mqtt_create_string(client_id);
    }

    int ret = vesync_queue_send(s_mqtt_client->queue, &event, MQTT_API_TIMEOUT_MS);
    if (ret != VOS_OK)
    {
        SDK_LOG(LOG_ERROR, "Event(%d) send failed\n", event.id);
        VCOM_SAFE_FREE(data->client_id);
        VCOM_SAFE_FREE(data);
        return SDK_FAIL;
    }

    return SDK_OK;
}

int vesync_mqtt_connect(char *host, char *ip, uint16_t port,
                        char *username, char *password,
                        int tls)
{
    vesync_mqtt_ev_t event = {0};
    event.id = MQTT_EV_CONNECT;
    event.data = vesync_calloc(1, sizeof(mqtt_connect_data_t));
    
    mqtt_connect_data_t *data = (mqtt_connect_data_t*)event.data;
    data->port = port;
    data->tls = tls;
    data->host = mqtt_create_string(host);
    data->ip = mqtt_create_string(ip);
    data->username = mqtt_create_string(username);
    data->password = mqtt_create_string(password);

    int ret = vesync_queue_send(s_mqtt_client->queue, &event, MQTT_API_TIMEOUT_MS);
    if (ret != VOS_OK)
    {
        SDK_LOG(LOG_ERROR, "Event(%d) send failed\n", event.id);
        VCOM_SAFE_FREE(host);
        VCOM_SAFE_FREE(username);
        VCOM_SAFE_FREE(password);
        VCOM_SAFE_FREE(data);
        return SDK_FAIL;
    }

    return SDK_OK;
}


int vesync_mqtt_disconnect(void)
{
    vesync_mqtt_ev_t event = {0};
    event.id = MQTT_EV_DISCONNECT;
    int ret = vesync_queue_send(s_mqtt_client->queue, &event, MQTT_API_TIMEOUT_MS);
    if (ret != VOS_OK)
    {
        SDK_LOG(LOG_ERROR, "Event(%d) send failed\n", event.id);
        return SDK_FAIL;
    }

    return SDK_OK;
}


int vesync_mqtt_publish(const char *topic, const char *data, int len, int qos, int retain, void (*ack_cb)(void))
{
    vesync_mqtt_ev_t event = {0};
    mqtt_publish_data_t *ev_data = NULL;
    vesync_mqtt_client_t *client = s_mqtt_client;

    MQTT_UTIL_MEM_CHECK(client, return SDK_FAIL);
    MQTT_UTIL_MEM_CHECK(topic, return SDK_FAIL);
    MQTT_UTIL_MEM_CHECK(data, return SDK_FAIL);

    if (len <= 0)
    {
        len = strlen(data);
    }

    if (VOS_OK == vesync_recursive_mutex_try_lock(client->lock))
    {
        int ret = vesync_mqtt_client_publish(client, topic, data, len, qos, retain, ack_cb);
        vesync_recursive_mutex_unlock(client->lock);
        return (ret >= 0 ? SDK_OK : SDK_FAIL);
    }

    /* Skip sending if not connected (rely on resending) */
    if (client->state != MQTT_STATE_CONNECTED)
    {
        SDK_LOG(LOG_DEBUG, "Publish: client is not connected");
        return SDK_FAIL;
    }

    ev_data = vesync_calloc(1, sizeof(mqtt_publish_data_t) + len + strlen(topic) + 2);
    ev_data->topic = ev_data->data + len + 1;
    ev_data->len = len;
    ev_data->qos = qos;
    ev_data->ack_cb = ack_cb;
    ev_data->retain = retain;
    memcpy(ev_data->data, data, len);
    memcpy(ev_data->topic, topic, strlen(topic));

    event.id = MQTT_EV_PUBLISH;
    event.data = ev_data;
    int ret = vesync_queue_send(s_mqtt_client->queue, &event, MQTT_API_TIMEOUT_MS);
    if (ret != VOS_OK)
    {
        SDK_LOG(LOG_ERROR, "Event(%d) send failed\n", event.id);
        vesync_free(ev_data);
        return SDK_FAIL;
    }

    return SDK_OK;
}


int vesync_mqtt_subscribe(const char *topic, int qos, void(*ack_cb)(void))
{
    vesync_mqtt_ev_t event = {0};
    mqtt_publish_data_t *ev_data = NULL;
    vesync_mqtt_client_t *client = s_mqtt_client;

    MQTT_UTIL_MEM_CHECK(client, return SDK_FAIL);
    MQTT_UTIL_MEM_CHECK(topic, return SDK_FAIL);

    if (VOS_OK == vesync_recursive_mutex_try_lock(client->lock))
    {
        int ret = vesync_mqtt_client_subscribe(client, topic, qos, ack_cb);
        vesync_recursive_mutex_unlock(client->lock);
        return (ret >= 0 ? SDK_OK : SDK_FAIL);
    }

    /* Skip sending if not connected (rely on resending) */
    if (client->state != MQTT_STATE_CONNECTED)
    {
        SDK_LOG(LOG_DEBUG, "Publish: client is not connected");
        return SDK_FAIL;
    }

    ev_data = vesync_calloc(1, sizeof(mqtt_publish_data_t) + strlen(topic) + 1);
    ev_data->topic = ev_data->data;
    ev_data->len = strlen(topic) + 1;
    ev_data->qos = qos;
    ev_data->ack_cb = ack_cb;
    memcpy(ev_data->topic, topic, strlen(topic));

    event.id = MQTT_EV_SUBSCRIBE;
    event.data = ev_data;
    int ret = vesync_queue_send(s_mqtt_client->queue, &event, MQTT_API_TIMEOUT_MS);
    if (ret != VOS_OK)
    {
        SDK_LOG(LOG_ERROR, "Event(%d) send failed\n", event.id);
        vesync_free(ev_data);
        return SDK_FAIL;
    }

    return SDK_OK;
}


