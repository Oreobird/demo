/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_https_flash.c
 * @brief       https模块
 * @author      Joshua
 * @date        2021-09-24
 */

#include "vesync_common.h"
#include "vesync_log_internal.h"
#include "vesync_flash.h"
#include "vesync_https_private.h"

/**
 * @brief 写token
 * @param[in]  char            [待写入的token]
 * @param[in]  int             [长度]
 * @return  int                [成功：SDK_OK，失败：SDK_FAIL]
 */
int vesync_https_flash_token_write(char *p_token, int buf_len)
{
    if(NULL == p_token)
    {
         SDK_LOG(LOG_ERROR, "Input parameters contain null pointers!\n");
         return  SDK_FAIL ;
    }

    SDK_LOG(LOG_DEBUG, "TOKEN:%s\n", p_token);

    int ret = vesync_flash_aes_crypto_write(PARTITION_CFG, USER_CFG_KEY_HTTPS_TOKEN, (uint8_t *)p_token, buf_len);
    if (ret != VHAL_OK)
    {
        SDK_LOG(LOG_ERROR, "token write failed\n");
        return SDK_FAIL;
    }

    return SDK_OK;
}

/**
 * @brief 读token
 * @param[out]  p_token         [待读出的token]
 * @param[in,out]  len          [待读出的token长度]
 * @return  int                 [成功：SDK_OK，失败：SDK_FAIL]
 */
int vesync_https_flash_token_read(char *p_token, uint32_t *len)
{
    if ((NULL == p_token) || (NULL == len))
    {
        SDK_LOG(LOG_ERROR, "Input point is NULL!\n");
        return SDK_FAIL;
    }

    int ret = vesync_flash_aes_crypto_read(PARTITION_CFG, USER_CFG_KEY_HTTPS_TOKEN, (uint8_t *)p_token, len);
    SDK_LOG(LOG_DEBUG, "token length:%d\n", len);
    if (ret != VHAL_OK)
    {
        SDK_LOG(LOG_ERROR, "token read failed\n");
        return SDK_FAIL;
    }

    return SDK_OK;
}


/**
 * @brief 清除token
 * @return  int                 [成功：SDK_OK，失败：SDK_FAIL]
 */
int vesync_https_flash_token_clear(void)
{
    int ret = VHAL_FAIL;
    ret = vesync_flash_erase_key(PARTITION_CFG, USER_CFG_KEY_HTTPS_TOKEN);
    if (ret != VHAL_OK)
    {
        SDK_LOG(LOG_ERROR, "token clear failed\n");
        return SDK_FAIL;
    }

    SDK_LOG(LOG_DEBUG, "Token clear success...\n");

    return SDK_OK;
}

