/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        switch_wifi_led.h
 * @brief       switch Wi-Fi指示灯配置头文件
 * @author      Charles.Mei
 * @date        2021-08-02
 */


#ifndef __SWITCH_WIFI_LED_H__
#define __SWITCH_WIFI_LED_H__

#ifdef __cplusplus
extern "C" {
#endif


/**
 * @brief  Wi-Fi灯效初始化
 * @return     int             [成功/失败]
 */
int switch_wifi_led_init(void);


#ifdef __cplusplus
}
#endif

#endif

