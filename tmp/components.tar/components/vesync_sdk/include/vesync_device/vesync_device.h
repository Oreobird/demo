/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_device.h
 * @brief       设备初始化、配置属性及操作接口
 * @date        2021-04-27
 */

#ifndef __VESYNC_DEVICE_H__
#define __VESYNC_DEVICE_H__

#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>

#include "vesync_cfg.h"

#ifdef __cplusplus
extern "C" {
#endif

#define MAX_SW_VER_STR_LEN      (16)      // 软件版本最大长度
#define MAX_PLUGIN_NAME_STR_LEN (16)      // 插件名称最大长度

/*
 * @brief 设备删除信息类型
 */
typedef enum
{
    DEV_DEL_USER_CFG = 0,       // 删除用户配置信息，不包括配网信息
    DEV_DEL_DEVICE,             // 删除用户信息+配网信息+复位
    DEV_DEL_NET_CFG,            // 删除配网信息+复位
    DEV_REBOOT,                 // 仅重启设备，不删除任何信息
} DEV_RESET_TYPE_E;


/*
* @brief 固件类型
*/
typedef enum
{
#if defined(PR_OTA_TYPE_WIFI) && PR_OTA_TYPE_WIFI
    UPG_TP_WIFI = 0x1, /* 固件类型是Wi-Fi */
#endif
#if defined(PR_OTA_TYPE_BLE) && PR_OTA_TYPE_BLE
    UPG_TP_BLE = 0x2, /* 固件类型是BLE */
#endif
#if defined(PR_TOTAL_MCU_NUM) && (PR_TOTAL_MCU_NUM >= 1)
    UPG_TP_MCU = 0x10, /* 固件类型是MCU */
#endif
#if defined(PR_TOTAL_MCU_NUM) && (PR_TOTAL_MCU_NUM >= 2)
    UPG_TP_MCU2 = 0x20, /* 固件类型是MCU */
#endif
#if defined(PR_TOTAL_MCU_NUM) && (PR_TOTAL_MCU_NUM >= 3)
    UPG_TP_MCU3 = 0x40, /* 固件类型是MCU */
#endif
} FW_TYPE_E;


/*
 * @brief 记录各固件版本，上报多固件信息时需要用到的字段
 */
typedef struct
{
    char cur_firm_ver[MAX_SW_VER_STR_LEN];          // 固件版本
    char plugin_name[MAX_PLUGIN_NAME_STR_LEN];      // 插件名称，目前有三种mainFw，mcuxFw，bleFw
    uint8_t priority;                               // 固件优先级
    bool is_upgrade;                                // 是否支持OTA
    bool main_fw;                                   // 是否是主固件
    FW_TYPE_E type;                                 // 固件类型
} dev_fw_info_t;


/**
 * @brief 清除设备数据回调函数指针
 * @param[in]  rsn              [消息来源]
 * @param[in]  rst_type         [删除用户数据的类型]
 * @return     void             [无]
 */
typedef void (*vesync_device_clear_data_cb_t)(const char* rsn, DEV_RESET_TYPE_E rst_type);

/**
 * @brief 注册清除设备数据回调函数
 *
 * @param cb 清除设备数据回调
 * @return int                  [成功/失败]
 */
int vesync_device_reg_clear_data_cb(vesync_device_clear_data_cb_t cb);


/**
 * @brief 恢复出厂前事件处理回调函数指针
 * @param[in]  rsn              [消息来源]
 * @param[in]  rst_type         [删除用户数据的类型]
 * @return     void             [无]
 */
typedef void (*vesync_device_pre_reset_cb_t)(void *arg);



/**
* @brief 初始化设备信息
* @return  int                   [成功/失败]
*/
int vesync_device_init(void);

/**
* @brief 释放设备资源
* @return
*/
void vesync_device_deinit(void);


/**
* @brief 获取产品ota类型配置信息
* @return char         [获取数据内容]
*/
uint8_t vesync_device_get_ota_num(void);


/**
* @brief 更新各固件版本信息
* @param[in] type             [固件类型]
* @param[in] p_ver            [固件版本]
* @return  int                [成功/失败]
*/
int vesync_device_update_fw_ver(FW_TYPE_E type, char *p_ver);


/**
* @brief 更新各固件升级优先顺序
* @param[in] type                [固件类型]
* @param[in] priority            [优先级，数值越小优先级越高]
* @return  int                   [成功/失败]
*/
int vesync_device_update_fw_priority(FW_TYPE_E type, uint8_t priority);

/**
* @brief 更新固件的插件名(plugin_name)，在默认基础上添加后缀
* @param[in] type                [固件类型]
* @param[in] p_suffix            [插件名后缀]
* @return  int                   [成功/失败]
*/
int vesync_device_add_plugin_name_suffix(FW_TYPE_E type, const char *p_suffix);

/**
* @brief 获取固件的插件名(plugin_name)信息
* @param[in] type                [固件类型]
* @return  int                   [成功/失败]
*/
char *vesync_device_get_plugin_name_by_type(FW_TYPE_E type);

/**
* @brief 根据下标获取各固件的信息
* @param[in]  idx                   [下标]
* @param[out] p_firw_info           [返回固件信息]
* @return  int                      [成功/失败]
*/
int vesync_device_get_fw_info_by_idx(uint8_t idx, dev_fw_info_t *p_fw_info);

/**
* @brief 获取各固件的信息
* @param[in]  type                  [固件类型]
* @param[out] p_firw_info           [返回固件信息]
* @return int                       [成功/失败]
*/
int vesync_device_get_fw_info_by_type(FW_TYPE_E type, dev_fw_info_t *p_fw_info);


/**
* @brief 设置设备cid
* @param[in]  cid                   [设备cid]
* @return  int                      [成功/失败]
*/
int vesync_device_set_cid(char *cid);

/**
* @brief 获取设备cid
* @return  char                     [设备cid]
*/
char *vesync_device_get_cid(void);


/**
* @brief 设置account id
* @param[in]  account_id            [用户ID]
* @return  int                      [设置成功/失败]
*/
int vesync_device_set_account_id(char *account_id);

/**
* @brief 获取account id
* @return[out] char*                [账号id]
*/
char *vesync_device_get_account_id(void);

/**
* @brief 重启设备
* @return  none
*/
void vesync_device_reboot(void);

/*
 * @brief  设备恢复出厂，删除所有配置信息
 * @param[in]  src_type             [消息(动作)来源]
 * @param[in]  cb                   [恢复出厂重启前其它事务处理回调函数]
 * @return     none
 */
void vesync_device_factory_reset(const char* src_type, vesync_device_pre_reset_cb_t cb);

#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_DEVICE_H__ */



