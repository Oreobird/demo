/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_srpc_private.h
 * @brief       vesync SRPC模块的私有接口定义
 * @author      Herve
 * @date        2021-12-28
 */
#ifndef __VESYNC_SRPC_PRIVATE_H__
#define __VESYNC_SRPC_PRIVATE_H__

#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>

#include "cJSON.h"

#include "vesync_tl_frame_parse.h"
#include "vesync_frame.h"
#include "vesync_bypass.h"
#include "vesync_mutex.h"

#include "vesync_srpc_internal.h"

#ifdef __cplusplus
extern "C" {
#endif

#define SRPC_OPCODE_REQUEST (0x8050)        // SRPC请求的OPCODE
#define SRPC_OPCODE_RESPONSE (0x8050)       // SRPC响应的OPCODE
#define SRPC_OPCODE_LOG (0x8052)            // SRPC日志的OPCODE
#define SRPC_OPCODE_REPORT (0x8053)         // SRPC上报的OPCODE
#define SRPC_REQUEST_TIMEOUT_SEC (30)       // SRPC请求超时时间

/**
 * @brief Vesync SRPC接收的请求处理回调函数类型定义
 * @param[in]   p_msg               [请求的JSON数据包]
 */
typedef void (*srpc_request_recv_cb_t)(cJSON *p_msg);

/**
 * @brief Vesync SRPC注册接收的请求处理回调
 * @param[in]   cb                  [注册的目标回调]
 */
void srpc_reg_request_recv_cb(srpc_request_recv_cb_t cb);

/**
 * @brief 尝试向Host发送Response数据
 * @param[in]   p_tid               [指向输入用于校验的Trace ID缓存]
 * @param[out]  p_req_method        [指向输出当前处理的Request method]
 * @return      true                [可以继续发送的流程]
 * @return      false               [SRPC繁忙，不可以发送该Respone]
 */
bool srpc_try_tx_resp_to_host(const char *p_tid, int *p_req_method);

/**
 * @brief 完成向Host发送Response，更新SRPC上下文
 */
void srpc_cmplt_tx_resp_to_host(void);

/**
 * @brief 尝试接收来自Host的Request
 * @return      true                [可以继续接收的流程]
 * @return      false               [SRPC繁忙，不可以接收新的Request]
 */
bool srpc_try_rx_req_from_host(void);

/**
 * @brief 完成接收来自Host的Request，更新SRPC上下文
 * @param[in]   p_tid               [指向该Request Trace ID字符串]
 * @param[in]   req_method          [该Request的method]
 */
void srpc_cmplt_rx_req_from_host(const char *p_tid, int req_method);

/**
 * @brief SRPC请求解析成Bypass JSON的接口
 * @note  此为Port接口
 * @param[in]   p_buf               [SRPC请求的二进制PB数据]
 * @param[in]   len                 [二进制PB数据长度]
 * @return      cJSON*              [返回的Bypass JSON对象，需要额外释放]
 */
cJSON *srpc_request_unmarshal(const uint8_t *p_buf, uint32_t len);

/**
 * @brief Bypass JSON Response解析成SRPC响应的接口
 * @note  此为Port接口
 * @param[in]   p_json              [Bypass JSON Response对象]
 * @param[in]   p_len               [输出的SRPC响应二进制PB数据长度]
 * @return      uint8_t*            [返回的SRPC响应二进制PB数据，需要额外释放]
 */
uint8_t *srpc_response_marshal(cJSON *p_json, uint32_t *p_len);

/**
 * @brief Bypass JSON Request解析成SRPC请求的接口，测试用
 * @note  此为Port接口
 * @param[in]   p_json              [Bypass JSON Request对象]
 * @param[in]   p_len               [输出的SRPC请求二进制PB数据长度]
 * @return      uint8_t*            [返回的SRPC请求二进制PB数据，需要额外释放]
 */
uint8_t *srpc_request_marshal(cJSON *p_json, uint32_t *p_len);

/**
 * @brief TODO，未开放接口，SRPC的接口互斥待实现
 * @param[in]   p_json
 */
void srpc_send_log(cJSON *p_json);

/**
 * @brief TODO，未开放接口，SRPC的接口互斥待实现
 * @param[in]   p_json
 */
void srpc_send_report(cJSON *p_json);

/**
 * @brief SRPC传输层发送错误接口
 * @param[in]   opcode              [OPCODE]
 * @param[in]   status_code         [错误码]
 */
void srpc_tl_send_error_ack(uint16_t opcode, uint16_t status_code);

/**
 * @brief 传输层SRPC数据接收处理回调
 * @param[in]   p_data          [Vesync Frame中的透传数据]
 * @param[in]   len             [透传数据长度]
 * @param[in]   need_ack        [是否需要应答]
 * @return      bool            [消息是否被接收者消费]
 */
bool srpc_tl_data_recv_cb(uint8_t *p_data, uint16_t len, bool need_ack);

#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_SRPC_PRIVATE_H__ */