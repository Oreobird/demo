/**
 * Copyright © Vesync Technologies Co.Ltd. 2019-2021. All rights reserved.
 * @file    vesync_ca_cert.c
 * @brief   MQTT与https证书，目前用于Realtek平台
 * @author  Dongri
 * @date    2020-01-02
 */

#include "vesync_ca_cert.h"

#if defined(CONFIG_TARGET_RTL8710CX) || defined(CONFIG_TARGET_RTL8720CF) || defined(CONFIG_IDF_TARGET_BL602)
#define MQTT_CA_CERT_PEM                                                \
"-----BEGIN CERTIFICATE-----\r\n"                                       \
"MIIEBjCCAu6gAwIBAgIIDveWrNX4viYwDQYJKoZIhvcNAQELBQAwgYgxCzAJBgNV\r\n"  \
"BAYTAkNIMQswCQYDVQQIEwJDUTELMAkGA1UEBxMCQ1ExDzANBgNVBAoTBnZlc3lu\r\n"  \
"YzEPMA0GA1UECxMGdmVzeW5jMRMwEQYDVQQDEwp2ZXN5bmNSb290MSgwJgYJKoZI\r\n"  \
"hvcNAQkBFhlsaW51c3BlbmdAZXRla2NpdHkuY29tLmNuMB4XDTE4MDYyMTA2Mjgw\r\n"  \
"MFoXDTI4MDYyMTA2MjgwMFowgYgxCzAJBgNVBAYTAkNIMQswCQYDVQQIEwJDUTEL\r\n"  \
"MAkGA1UEBxMCQ1ExDzANBgNVBAoTBnZlc3luYzEPMA0GA1UECxMGdmVzeW5jMRMw\r\n"  \
"EQYDVQQDEwp2ZXN5bmNSb290MSgwJgYJKoZIhvcNAQkBFhlsaW51c3BlbmdAZXRl\r\n"  \
"a2NpdHkuY29tLmNuMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA5Ew6\r\n"  \
"AlJPj4B+fM9zyXs/mNeG30DypZLzlFv0d3nnqDkXYP97QuGh45ivz/u9O32aaa0k\r\n"  \
"mZIGmlEJeV3/Pz6KqyALcy+wPi6JZJtFu27joVPbzffLxJMVWVQL/FVvaD+0UJ0o\r\n"  \
"iL5If/uqMDRsCz2oER8P0GhhJuO0sU3N9D4ZJRePR66M/5VE5h4NErABEiMw3GkR\r\n"  \
"1Yo0LINVbWcSf/R9tpNPKpF43uBQJS2A0hWFZNye72qS2y1stiG7F1cHdO0SYjhW\r\n"  \
"jQvhvzd3lpkl1NaklI7CAwWqZLrlrmGRskM0pKLu7l4KObDO0LErKfrDadwEG5bD\r\n"  \
"SeSk6gi1qqzmdKtP6wIDAQABo3IwcDAPBgNVHRMBAf8EBTADAQH/MB0GA1UdDgQW\r\n"  \
"BBS1IJsrR7JPYYe4l5yjjMlmoY4P5DALBgNVHQ8EBAMCAYYwEQYJYIZIAYb4QgEB\r\n"  \
"BAQDAgAHMB4GCWCGSAGG+EIBDQQRFg94Y2EgY2VydGlmaWNhdGUwDQYJKoZIhvcN\r\n"  \
"AQELBQADggEBAIG0Cq1SG4JrP3dmB28OytiHduNg3wxvFifWoEAKq11wBC9irCeB\r\n"  \
"gMsxzrzbryxzQeNR7NIBqfVS3o0J51qbAfvzQIqiaa+g9Hymkv2ygdHduxiYz63f\r\n"  \
"KoDLE/X9ih5pqkeqUc8/wwnIsvQlxUSgAo5eYQNN8V52EavwlTuIWaqzaKChgNGf\r\n"  \
"xNyMDzjMkwscVLeHFIBlBqVBj5Ob8iNtvzjnZ82IVM0Yghia821EhxI/CPEcsiyY\r\n"  \
"kZ5kyfrySEzR/qmln3zO3u/eATJWuCbj4EtA1QnDXETcO0Xawq80p6Hx+cQKbB57\r\n"  \
"DqoJumzvMr8ilXgyAfzrn3r0li2VCtWD74w=\r\n"                              \
"-----END CERTIFICATE-----\r\n";

#define MQTT_CLIENT_CERT_PEM                                            \
"-----BEGIN CERTIFICATE-----\r\n"                                       \
"MIIC9jCCAd6gAwIBAgIIeJrvUDSMi7kwDQYJKoZIhvcNAQELBQAwgYgxCzAJBgNV\r\n"  \
"BAYTAkNIMQswCQYDVQQIEwJDUTELMAkGA1UEBxMCQ1ExDzANBgNVBAoTBnZlc3lu\r\n"  \
"YzEPMA0GA1UECxMGdmVzeW5jMRMwEQYDVQQDEwp2ZXN5bmNSb290MSgwJgYJKoZI\r\n"  \
"hvcNAQkBFhlsaW51c3BlbmdAZXRla2NpdHkuY29tLmNuMB4XDTE4MDYyNTA5MzMw\r\n"  \
"MFoXDTE5MDYyNTA5MzMwMFowADCBnzANBgkqhkiG9w0BAQEFAAOBjQAwgYkCgYEA\r\n"  \
"95Ixb+riw/iCjQ4feXtfVR5Yl0u4wLDJXJg0qmS0NSWKGcSB24vEK5/YSkBgINFM\r\n"  \
"f7jZ1+UaWCaQfzIyJmhB/dhuUTQjUBbBepC5bL5AmtEzyfHORE+YQ0i9ndkgkE/O\r\n"  \
"F4vAqwR8jbF/iwkodktSESRfVKPe1O8rjG6ftcBsz/0CAwEAAaNvMG0wDAYDVR0T\r\n"  \
"AQH/BAIwADAdBgNVHQ4EFgQUBJHHbj/WhMVrmGSINWnA/Skf+NUwCwYDVR0PBAQD\r\n"  \
"AgSwMBEGCWCGSAGG+EIBAQQEAwIFoDAeBglghkgBhvhCAQ0EERYPeGNhIGNlcnRp\r\n"  \
"ZmljYXRlMA0GCSqGSIb3DQEBCwUAA4IBAQAeVrdaIHgvTWDCHH2nPaeVTay3G7jb\r\n"  \
"m+vaGR6oNyJeDHvQDBDYFo9PKZqMe8Gcr653Pni6Nb3QiE34b2Wtg8W2vtqdir0Q\r\n"  \
"Tl3ri3431+DiP8dpcNCdptAvPraF/s2+1jvDrlwzxkj5mpvjVCqU0tmPaT80LnEU\r\n"  \
"Wn31KU2WtVhaW6pQP+7AlbkNKcYpyx+w0Z0VmlGKgY60uembzf+SYxRPZpTdCc4O\r\n"  \
"OMBqyy68bBuzOMy8RvnKte3+L6lbujooOmMihfy23Ks+aBtN6wkjHf7dfMqdWIng\r\n"  \
"hxn5EAJyb/xvMdhYTPof2vV1fYFtP9EWAUeFttAiu262j+25J6RjAEvD\r\n"          \
"-----END CERTIFICATE-----\r\n";

#define MQTT_CLIENT_KEY_PEM                                             \
"-----BEGIN RSA PRIVATE KEY-----\r\n"                                   \
"MIICXQIBAAKBgQD3kjFv6uLD+IKNDh95e19VHliXS7jAsMlcmDSqZLQ1JYoZxIHb\r\n"  \
"i8Qrn9hKQGAg0Ux/uNnX5RpYJpB/MjImaEH92G5RNCNQFsF6kLlsvkCa0TPJ8c5E\r\n"  \
"T5hDSL2d2SCQT84Xi8CrBHyNsX+LCSh2S1IRJF9Uo97U7yuMbp+1wGzP/QIDAQAB\r\n"  \
"AoGBAJU9oOW5r9e5MGH92IVwFOkH8RnLgOVP7SMPcfgh2uyK47Ri3HFP0QMHSeiA\r\n"  \
"5DIEWdxIv7HBH19yZ/r1dHvor5Y6XdS39yfgsIHJIuEi2N/CpQoFTz4nwoLEZZv7\r\n"  \
"GewlUWHk8h3s/K9Cx/VSdfmjUvxsRwxQPW+tc5pVAQtuokOBAkEA/qpmuKYjVqAx\r\n"  \
"A/xZPG2j+pEZ3Te4COMRucNZy1mNsXFN3dZ3qOmx1e6D0xJkBx2XB/AXbPkxQxR8\r\n"  \
"u/0qL8q2HQJBAPjeRoYQnmA9DpKFUlnCTpks34LBzEwYP3Ox5xofRVcX7m//6lyC\r\n"  \
"YQC/HmgOl8uIbN75+Bx+Qpd01TTkByGv22ECQDlytzlwQQiJmoULqBW5pgQgN3Vv\r\n"  \
"3FQk5RrCtr7otM4SgT5J4zR3g2Z/J721qFrykd94idBLZpF7TagatCmT0QECQGao\r\n"  \
"efrvfAVC6nHyYQf5qSZyZjiv7LAvCG2XIzeZUqccjhTRQkGq3ozKSaau7lrdCdvo\r\n"  \
"zTojsyB650AMGA0DV8ECQQDLtcdO90hx6Pzh4cjy7NoMCYpWX//lUZuV6VuEGXr8\r\n"  \
"IwhLKT1Lu6V52j9KNMB+FwXzoWL8fwEIC+9L/6MP2UIr\r\n"                      \
"-----END RSA PRIVATE KEY-----\r\n";

#define HTPTS_CA_CERT_PEM                                               \
"-----BEGIN CERTIFICATE-----\r\n"                                       \
"MIIElDCCA3ygAwIBAgIQAf2j627KdciIQ4tyS8+8kTANBgkqhkiG9w0BAQsFADBh\r\n"  \
"MQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3\r\n"  \
"d3cuZGlnaWNlcnQuY29tMSAwHgYDVQQDExdEaWdpQ2VydCBHbG9iYWwgUm9vdCBD\r\n"  \
"QTAeFw0xMzAzMDgxMjAwMDBaFw0yMzAzMDgxMjAwMDBaME0xCzAJBgNVBAYTAlVT\r\n"  \
"MRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMxJzAlBgNVBAMTHkRpZ2lDZXJ0IFNIQTIg\r\n"  \
"U2VjdXJlIFNlcnZlciBDQTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEB\r\n"  \
"ANyuWJBNwcQwFZA1W248ghX1LFy949v/cUP6ZCWA1O4Yok3wZtAKc24RmDYXZK83\r\n"  \
"nf36QYSvx6+M/hpzTc8zl5CilodTgyu5pnVILR1WN3vaMTIa16yrBvSqXUu3R0bd\r\n"  \
"KpPDkC55gIDvEwRqFDu1m5K+wgdlTvza/P96rtxcflUxDOg5B6TXvi/TC2rSsd9f\r\n"  \
"/ld0Uzs1gN2ujkSYs58O09rg1/RrKatEp0tYhG2SS4HD2nOLEpdIkARFdRrdNzGX\r\n"  \
"kujNVA075ME/OV4uuPNcfhCOhkEAjUVmR7ChZc6gqikJTvOX6+guqw9ypzAO+sf0\r\n"  \
"/RR3w6RbKFfCs/mC/bdFWJsCAwEAAaOCAVowggFWMBIGA1UdEwEB/wQIMAYBAf8C\r\n"  \
"AQAwDgYDVR0PAQH/BAQDAgGGMDQGCCsGAQUFBwEBBCgwJjAkBggrBgEFBQcwAYYY\r\n"  \
"aHR0cDovL29jc3AuZGlnaWNlcnQuY29tMHsGA1UdHwR0MHIwN6A1oDOGMWh0dHA6\r\n"  \
"Ly9jcmwzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydEdsb2JhbFJvb3RDQS5jcmwwN6A1\r\n"  \
"oDOGMWh0dHA6Ly9jcmw0LmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydEdsb2JhbFJvb3RD\r\n"  \
"QS5jcmwwPQYDVR0gBDYwNDAyBgRVHSAAMCowKAYIKwYBBQUHAgEWHGh0dHBzOi8v\r\n"  \
"d3d3LmRpZ2ljZXJ0LmNvbS9DUFMwHQYDVR0OBBYEFA+AYRyCMWHVLyjnjUY4tCzh\r\n"  \
"xtniMB8GA1UdIwQYMBaAFAPeUDVW0Uy7ZvCj4hsbw5eyPdFVMA0GCSqGSIb3DQEB\r\n"  \
"CwUAA4IBAQAjPt9L0jFCpbZ+QlwaRMxp0Wi0XUvgBCFsS+JtzLHgl4+mUwnNqipl\r\n"  \
"5TlPHoOlblyYoiQm5vuh7ZPHLgLGTUq/sELfeNqzqPlt/yGFUzZgTHbO7Djc1lGA\r\n"  \
"8MXW5dRNJ2Srm8c+cftIl7gzbckTB+6WohsYFfZcTEDts8Ls/3HB40f/1LkAtDdC\r\n"  \
"2iDJ6m6K7hQGrn2iWZiIqBtvLfTyyRRfJs8sjX7tN8Cp1Tm5gr8ZDOo0rwAhaPit\r\n"  \
"c+LJMto4JQtV05od8GiG7S5BNO98pVAdvzr508EIDObtHopYJeS4d60tbvVS3bR0\r\n"  \
"j6tJLp07kzQoH3jOlOrHvdPJbRzeXDLz\r\n"                                  \
"-----END CERTIFICATE-----\r\n";

#define HTPTS_CLIENT_CERT_PEM                                           \
"-----BEGIN CERTIFICATE-----\r\n"                                       \
"MIIFHzCCBAegAwIBAgIQBtTB549/D2qR5/EnHVYuAjANBgkqhkiG9w0BAQsFADBN\r\n"  \
"MQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMScwJQYDVQQDEx5E\r\n"  \
"aWdpQ2VydCBTSEEyIFNlY3VyZSBTZXJ2ZXIgQ0EwHhcNMTcwNzE0MDAwMDAwWhcN\r\n"  \
"MjAwNzE3MTIwMDAwWjBnMQswCQYDVQQGEwJVUzETMBEGA1UECBMKQ2FsaWZvcm5p\r\n"  \
"YTEPMA0GA1UEBxMGT3JhbmdlMRswGQYDVQQKExJWZVN5bmMgQ29ycG9yYXRpb24x\r\n"  \
"FTATBgNVBAMMDCoudmVzeW5jLmNvbTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCC\r\n"  \
"AQoCggEBALq4M/KJ/2tYQPxcwF9cRtxG5wRIaH+VXCxPYdv/I92tnsMWYRtWXrrf\r\n"  \
"Cb412rAVQsU3lWjMGcFMgqjq4EOjvGWM4UCERg27DtYtO0sIEpdchdxu7czAY5Af\r\n"  \
"vFyKSolU+4vzo2GX5kikvi+kz4WpcNG64C7nZhReylet1y7s2svFQ7IRUCrliEat\r\n"  \
"FOTThXgMUayUDXap4fswq3cuOfK+5HVkfEyGvvZN78CgE0xfRA6W9Ixm3oxMhV53\r\n"  \
"cNh7Br5TcRl7pk4j3prwtVaPyQIr+8nP3vdKaByYKrDLhpfiNiUeSM/Hb5mlwaPQ\r\n"  \
"AxnvrOa3ksS+l+hp/MXw69toG44FY7sCAwEAAaOCAd8wggHbMB8GA1UdIwQYMBaA\r\n"  \
"FA+AYRyCMWHVLyjnjUY4tCzhxtniMB0GA1UdDgQWBBTv8n/IICOgTFvkC42dQ8Lm\r\n"  \
"X2jkHzAjBgNVHREEHDAaggwqLnZlc3luYy5jb22CCnZlc3luYy5jb20wDgYDVR0P\r\n"  \
"AQH/BAQDAgWgMB0GA1UdJQQWMBQGCCsGAQUFBwMBBggrBgEFBQcDAjBrBgNVHR8E\r\n"  \
"ZDBiMC+gLaArhilodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vc3NjYS1zaGEyLWcx\r\n"  \
"LmNybDAvoC2gK4YpaHR0cDovL2NybDQuZGlnaWNlcnQuY29tL3NzY2Etc2hhMi1n\r\n"  \
"MS5jcmwwTAYDVR0gBEUwQzA3BglghkgBhv1sAQEwKjAoBggrBgEFBQcCARYcaHR0\r\n"  \
"cHM6Ly93d3cuZGlnaWNlcnQuY29tL0NQUzAIBgZngQwBAgIwfAYIKwYBBQUHAQEE\r\n"  \
"cDBuMCQGCCsGAQUFBzABhhhodHRwOi8vb2NzcC5kaWdpY2VydC5jb20wRgYIKwYB\r\n"  \
"BQUHMAKGOmh0dHA6Ly9jYWNlcnRzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydFNIQTJT\r\n"  \
"ZWN1cmVTZXJ2ZXJDQS5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOC\r\n"  \
"AQEAUDxm1FvCApznZoh/7DOFfSOOgM+A2YHTXNntHlZXv3BERp6mlBTKPnhMjkXC\r\n"  \
"kKCXZUH9FUGYHABX7wfgLMHNdHJwpUUDDgsvrOUxsTf/GNm/9wUt7vSpHcEHRMkT\r\n"  \
"cGw4L7hKpeUHfDOTgXXalQX1EJXqeUqCso72Txx9BlIUewb21QXQ0ma3G5vZrwD9\r\n"  \
"Q2qrR0vs/SdSffb68+Fe8IQ7LP3pfUyRAxoAtRZRY9rotZ+/GV1goXS1RuS/0poM\r\n"  \
"RpRbSe391CuJq8uyZfJ4QM3naksm5wdpl1TRGZcNtmx/q8x3zoACJvkxkZ88gmkJ\r\n"  \
"mEtJtq9Oe+0UxqvQDtvJqrYeQw==\r\n"                                      \
"-----END CERTIFICATE-----\r\n";

#define HTPTS_CLIENT_KEY_PEM                                            \
"-----BEGIN RSA PRIVATE KEY-----\r\n"                                   \
"MIIEowIBAAKCAQEAurgz8on/a1hA/FzAX1xG3EbnBEhof5VcLE9h2/8j3a2ewxZh\r\n"  \
"G1Zeut8JvjXasBVCxTeVaMwZwUyCqOrgQ6O8ZYzhQIRGDbsO1i07SwgSl1yF3G7t\r\n"  \
"zMBjkB+8XIpKiVT7i/OjYZfmSKS+L6TPhalw0brgLudmFF7KV63XLuzay8VDshFQ\r\n"  \
"KuWIRq0U5NOFeAxRrJQNdqnh+zCrdy458r7kdWR8TIa+9k3vwKATTF9EDpb0jGbe\r\n"  \
"jEyFXndw2HsGvlNxGXumTiPemvC1Vo/JAiv7yc/e90poHJgqsMuGl+I2JR5Iz8dv\r\n"  \
"maXBo9ADGe+s5reSxL6X6Gn8xfDr22gbjgVjuwIDAQABAoIBACjFK+Kbqz/fJ2Fz\r\n"  \
"RzYLShWzDaJrxRWGoXezZaTJ0yUGUhI7Ar0bYNfg95mm3LdyDQBPILqfRkhk0mrb\r\n"  \
"zlg2ml56In0Z5Mn+vECb48SAYL7YHwqA1j/NCnBf3Zs/PwM5oStv6Y7Xwhq+jiCN\r\n"  \
"FhsTYmUJLwZO1IVCJWB7vu6qHSQ88Ok1DDZzxfOyD/KBl1gy+KzNpcdLsdSIFOrd\r\n"  \
"rKJ3FNO6MOoX+TofSv6mVQHTgFqLV7fxPxR6aLsUB6wN5+JSepEbfcSDf3kKv8Wa\r\n"  \
"tUiw6f3T35HEjL7J9Yw7Sec9nRSslKc5F0PIXcvB+0u2VuqtGm808zM7vch3Jxu1\r\n"  \
"kUMGFlECgYEA5xTt9W/0nsypaC5rtMPU656oC6dYajBQerVQu4M62t1nw6rV3BmV\r\n"  \
"sZIDCLqGoWrL4WC8wP2hw6OGohOmJ9HVEnFxrPaYerhXD2hDOlXDENQJwRU1OSNR\r\n"  \
"Acs5eVT0jc5rl615uheKK7jcR+1nWpu42lUUEOy8J4+LuRErH2UZzqUCgYEAztqk\r\n"  \
"q7Ub+6BMPcBJ8TsiTx+78fqDXBhpKbpE+eg0Og9dNMe+fpJKKopT194ndCBGQgSv\r\n"  \
"COHBYiMwBB02sTGl9h33UUBWQiK/jz2TvfLR2I5pB7TbEaWKxsBGDe6IrthnUTaq\r\n"  \
"nmo/6LVlBmMjV2QlvFSgyb5ogqqNtULfnqiFOt8CgYAFeAJVr6ubYn6T351e7s+I\r\n"  \
"L/4MII7AHJqa/NWHSojHCzxcbhuXlOdtB2aY+0kaYtumXtK4wofkiGc0SMDC6n1f\r\n"  \
"bV3iWQesx9YPoEkPBV6TdGEyt5zF2GcfYr7edzs+a+cx9MIPvGThugNElILAqzTJ\r\n"  \
"vf+2ktO1H/mPjK93k73znQKBgQCxngib8C2RCPmuZHiZjN9O9b7abvNwlv1l+S3V\r\n"  \
"MM/3ss2jzogCAvdwQ8rupzFVg4kQkxkBFWiKLhDC15ro1+rbxKtit03aCCBYjNVZ\r\n"  \
"2zDZNJ93IJKjOnRJaTw+Jj5zdBpzH++tiypJVcjjjSkBl1rXtgtCcB8pY+2+YSfH\r\n"  \
"Aok0HQKBgACmMLem2fv5Z1aBzRj8TTlTmo8B999Xaef2yQpkIplH2RskTx1KEjwo\r\n"  \
"TrsyhUejwOGIH+OELjjQcW4yPtZdcZfIB3CH9XOKEIHZlnHqPt4gm/VE0mmc5tMs\r\n"  \
"zgOpxWoEdad1SQSuW2G1ULOooavBcgVWHUGUWMKLJP8KwEi7q6Fq\r\n"              \
"-----END RSA PRIVATE KEY-----\r\n";


//以下为中国区证书
#define  MQTT_CA_CERT_PEM_CN                                            \
"-----BEGIN CERTIFICATE-----\r\n"                                       \
"MIIEGjCCAwKgAwIBAgIIV3ZucBzRAd8wDQYJKoZIhvcNAQELBQAwgZExCzAJBgNV\r\n"  \
"BAYTAlVTMQswCQYDVQQIEwJDQTELMAkGA1UEBxMCQ0ExDzANBgNVBAoTBlZFU1lO\r\n"  \
"QzEPMA0GA1UECxMGVkVTWU5DMRwwGgYDVQQDDBNWRVNZTkNfQ05fRVhURU5USU9O\r\n"  \
"MSgwJgYJKoZIhvcNAQkBFhlsaW51c3BlbmdAZXRla2NpdHkuY29tLmNuMCAXDTIw\r\n"  \
"MDgwNTA2MTQwMFoYDzI1MjAwODA1MDYxNDAwWjCBkTELMAkGA1UEBhMCVVMxCzAJ\r\n"  \
"BgNVBAgTAkNBMQswCQYDVQQHEwJDQTEPMA0GA1UEChMGVkVTWU5DMQ8wDQYDVQQL\r\n"  \
"EwZWRVNZTkMxHDAaBgNVBAMME1ZFU1lOQ19DTl9FWFRFTlRJT04xKDAmBgkqhkiG\r\n"  \
"9w0BCQEWGWxpbnVzcGVuZ0BldGVrY2l0eS5jb20uY24wggEiMA0GCSqGSIb3DQEB\r\n"  \
"AQUAA4IBDwAwggEKAoIBAQDjNeF8bihLfprPYc/zs4BXJiCqDjsDLxHMQDy0zIhV\r\n"  \
"iqtdPs3Xr0oLmT1ilME6w1ukMNtWep/b4zmWZtHnduE2rkrQ053jWx54HUJp9NQG\r\n"  \
"HUVjXAhFH1WUmk1iXQfut/1bJr1E8HFUXoLlMBdzMojXmeXo0POAFV5joyjCnD53\r\n"  \
"MLsnyK9K7LrymiIrRQicy/iupUpx2rkvyNjQ/R0qtQzNYnBwW2twiPSPJie3Lw63\r\n"  \
"QkyiNPqQpIHx06lHNLqgQGgWuLnjsCTkVvB2h4VnM0nT6yQbxQJn0vwHWvcRtq0d\r\n"  \
"oHp/K/KCxx+5/pcKkjNKDyiz6kUx7d0fnsjQoiazsP1DAgMBAAGjcjBwMA8GA1Ud\r\n"  \
"EwEB/wQFMAMBAf8wHQYDVR0OBBYEFAUa9kxhAEFsP1algblWEU8J+omfMAsGA1Ud\r\n"  \
"DwQEAwIBBjARBglghkgBhvhCAQEEBAMCAAcwHgYJYIZIAYb4QgENBBEWD3hjYSBj\r\n"  \
"ZXJ0aWZpY2F0ZTANBgkqhkiG9w0BAQsFAAOCAQEAJJPPFbVKEQdGf542y/z/6oNm\r\n"  \
"ZXwCYOjGGlsDbt8Tdn51Jo/JZmQpqy+KxyGC4sEyWJGQuNXGp6AJ+TCSQWWsu1Qn\r\n"  \
"xAkeZKCYzvXm2t5Zz+TwBcgp3TZtBflb4oyap0D+EBPTCmK/gf+p+0x/Lmo/FAUw\r\n"  \
"jf+7rv9DTCzlys+E7RFfBKRodYh1nRoS3DRG65zbu3u4psZ/SRW2teyeHoxN+TAi\r\n"  \
"sqRIgJIg2sVVDhwGo69Jr0tic4+CerZFOCGxy3MOdzskTzRmnNNVHiozKyJA0Hg6\r\n"  \
"R0+xsAR8UMF/I8HazwWOgN9fGxrvaq+AkMVbcRFyT3fiFDKGK5iVBdZnw11OMg==\r\n"  \
"-----END CERTIFICATE-----\r\n";



#define MQTT_CLIENT_CERT_PEM_CN                                         \
"-----BEGIN CERTIFICATE-----\r\n"                                       \
"MIIDHDCCAgSgAwIBAgIIdligq4TNJyEwDQYJKoZIhvcNAQELBQAwgZExCzAJBgNV\r\n"  \
"BAYTAlVTMQswCQYDVQQIEwJDQTELMAkGA1UEBxMCQ0ExDzANBgNVBAoTBlZFU1lO\r\n"  \
"QzEPMA0GA1UECxMGVkVTWU5DMRwwGgYDVQQDDBNWRVNZTkNfQ05fRVhURU5USU9O\r\n"  \
"MSgwJgYJKoZIhvcNAQkBFhlsaW51c3BlbmdAZXRla2NpdHkuY29tLmNuMCAXDTIw\r\n"  \
"MDgwNTA2MTgwMFoYDzI1MjAwODA1MDYxNDAwWjAbMRkwFwYDVQQDDBB2ZXN5bmNf\r\n"  \
"Y25fZGV2aWNlMIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDeJYVj+zFsLFpt\r\n"  \
"KLYCgRLfM3zgeHV4ZDViHoTsBOX/NCGE0KcOdlog0+xJD7HD0hjRjto0gSsKBcx+\r\n"  \
"lct6NW5M6rewRNwQ1K4bhxu3n6Mn5jC5eNR1MG9t10R16lq4iczt8D0f1+7VPaNz\r\n"  \
"LmnM1IpTOdSPanR/vrmJTd/nY749DQIDAQABo28wbTAMBgNVHRMBAf8EAjAAMB0G\r\n"  \
"A1UdDgQWBBTO54s9a4VOPMM3Y/rkgUeUBe5UTTALBgNVHQ8EBAMCBLAwEQYJYIZI\r\n"  \
"AYb4QgEBBAQDAgWgMB4GCWCGSAGG+EIBDQQRFg94Y2EgY2VydGlmaWNhdGUwDQYJ\r\n"  \
"KoZIhvcNAQELBQADggEBAFIYj51ZNYOhraaGXPLPtaO6tzIm15Wq7TnJpJuriGob\r\n"  \
"iQwT6FZTzss7b3c0xgz8JXuMQYBjY2TnOeKPbEHthjhkp2VoVDNtlrPAC0u2khEG\r\n"  \
"76RKCVkUirEbbq9WfJ6el2S5WzgObQfH4Z7PxE8VWNHAVUYrBREsvHFhtuYy/tvf\r\n"  \
"5BWZQWAgd4MWjZl2gi6bfJ3xbBrEpeeawFiK9lzYXUMC+/zzaspEzvPzFg8SSNld\r\n"  \
"4SqoH9FUMYwt+wNCQliOXp38cL3zoOD2A1zYPZU5e7hTjtzYmu0pmM4iRjKu0lom\r\n"  \
"B297EaXBTifY5hKsSrhAQhHHaI4JoAWQYZe6ev2ETEo=\r\n"                      \
"-----END CERTIFICATE-----\r\n";


#define MQTT_CLIENT_KEY_PEM_CN                                          \
"-----BEGIN RSA PRIVATE KEY-----\r\n"                                   \
"MIICWwIBAAKBgQDeJYVj+zFsLFptKLYCgRLfM3zgeHV4ZDViHoTsBOX/NCGE0KcO\r\n"  \
"dlog0+xJD7HD0hjRjto0gSsKBcx+lct6NW5M6rewRNwQ1K4bhxu3n6Mn5jC5eNR1\r\n"  \
"MG9t10R16lq4iczt8D0f1+7VPaNzLmnM1IpTOdSPanR/vrmJTd/nY749DQIDAQAB\r\n"  \
"AoGAHaD5gpVNSTU9NlP4uqrGfpiabkICwPT0ncqeRfB9UKV+Vv2RWn90k+5QFIqQ\r\n"  \
"ViLehoy8E8aqm+KcHMIT6o/XzxDYfYaThOXnM9Tuz258Eoo8N8XuyaZs6Q+3riSx\r\n"  \
"b8XM5gOJozMmkTA07UQR4TrPr6tXOfXcaXpydre9fe9xl20CQQD01eayuO3XfwYf\r\n"  \
"iUCAx1nUbG+9d/J9CgbmdTiyRHajf17vqvY7PUr/MRCMmUtXVo0UbmOU6r75cVXm\r\n"  \
"HDGSZi63AkEA6EbCTj+AjKjHrBXlWWOb+qqLVLjskWgNkRs24dGnKwVA99qCgVEW\r\n"  \
"TWFEhl431zRYfmf6bIhHWYkvNhZPUG9uWwJAR3GzpCt6nAuhCcrPW8TQXcBWyv8Z\r\n"  \
"b4thgBZsuPhpdkRQu7czqw2zuMvkfGKvLYlAGdosjOQDXl7IJiHMBWBz+QJANmAK\r\n"  \
"MKMxBrykMabWj/x/kUjHYUgBKXEAbA3A5VBdH/cU5HDkyD0hSXARyJrZ26lHZiAV\r\n"  \
"Qb8NZOp2gOTsIFpVrQJANyglPMgFamWhMSG3bRUfqaBBQYz32SgNZljPD3NCe3DE\r\n"  \
"6SO86ADmUxVJj4uMhO94TU0dvyPrxxOiaYQlxuz9+w==\r\n"                      \
"-----END RSA PRIVATE KEY-----\r\n";




const char vesync_mqtt_ca_cert_pem[] = MQTT_CA_CERT_PEM;
const char vesync_mqtt_client_cert_pem[] = MQTT_CLIENT_CERT_PEM;
const char vesync_mqtt_client_key_pem[] = MQTT_CLIENT_KEY_PEM;

const char vesync_cn_mqtt_ca_cert_pem[] = MQTT_CA_CERT_PEM_CN;
const char vesync_cn_mqtt_client_cert_pem[] = MQTT_CLIENT_CERT_PEM_CN;
const char vesync_cn_mqtt_client_key_pem[] = MQTT_CLIENT_KEY_PEM_CN;


const char vesync_https_ca_cert_pem[] = HTPTS_CA_CERT_PEM;
const char vesync_https_client_cert_pem[] = HTPTS_CLIENT_CERT_PEM;
const char vesync_https_client_key_pem[] = HTPTS_CLIENT_KEY_PEM;

#endif

