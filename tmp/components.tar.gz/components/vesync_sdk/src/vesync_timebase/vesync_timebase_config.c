
/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_timebase_config.c
 * @brief       Timebase模块配置相关接口实现
 * @author      Herve
 * @date        2021-08-18
 */
#include <string.h>

#include "vesync_timebase_private.h"
#include "vesync_klv.h"
#include "vesync_log_internal.h"
#include "vesync_common.h"

#include "vhal_flash.h"

// 检查缓存是否为零并且写入KLV
static uint32_t timebase_klv_set(uint8_t *p_buf, uint32_t buf_len, uint32_t wr_len, uint8_t key, uint16_t len, uint8_t *value)
{
    if (NULL != p_buf)
    {
        p_buf = p_buf + wr_len;
        buf_len = buf_len - wr_len;
    }

    return vesync_klv_set(p_buf, buf_len, key, len, value);
}

#define TIMEBASE_KLV_SET_ERR_CHECK(offset, p_buf, buf_len, total_wr, key, len, val) \
    do                                                                              \
    {                                                                               \
        uint32_t out = timebase_klv_set(p_buf, buf_len, total_wr, key, len, val);   \
        if (0 == out)                                                               \
        {                                                                           \
            return TMBS_BUF_ERR;                                                    \
        }                                                                           \
        offset += out;                                                              \
    } while (0)

/**
 * @brief Timebase 序列化
 * @param[in]  p_timebase           [输入的时间数据]
 * @param[out] p_buf                [输出的Buffer]
 * @param[in]  buf_len              [输出的Buffer的长度]
 * @param[out] p_out_size           [序列化的二进制流的长度]
 * @return TMBS_RESULT_E
 */
int tb_cfg_marshal(vesync_timebase_t *p_timebase, uint8_t *p_buf, uint32_t buf_len, uint32_t *p_out_size)
{
    uint8_t version = TIMEBASE_CFG_VERSION;
    uint32_t offset = 0;

    // 输出长度初始化
    *p_out_size = 0;
    if (NULL != p_buf)
    {
        memset(p_buf, 0, buf_len);
    }
    // 组装版本信息
    TIMEBASE_KLV_SET_ERR_CHECK(offset, p_buf, buf_len, offset, TIME_BASE_VERSION, sizeof(version), &version);
    // 组装时基信息
    TIMEBASE_KLV_SET_ERR_CHECK(offset, p_buf, buf_len, offset, TIME_ZONE_KEY_NAME, strlen(p_timebase->tz_info.timezone_str), (uint8_t *)p_timebase->tz_info.timezone_str);
    TIMEBASE_KLV_SET_ERR_CHECK(offset, p_buf, buf_len, offset, TIME_ZONE_KEY_OFFSET, sizeof(p_timebase->tz_info.timezone_ofs_sec), (uint8_t *)&p_timebase->tz_info.timezone_ofs_sec);
    TIMEBASE_KLV_SET_ERR_CHECK(offset, p_buf, buf_len, offset, TIME_SUN_RISE_SET_KEY_LONGITUDE, sizeof(p_timebase->sun_rs_info.longitude), (uint8_t *)&p_timebase->sun_rs_info.longitude);
    TIMEBASE_KLV_SET_ERR_CHECK(offset, p_buf, buf_len, offset, TIME_SUN_RISE_SET_KEY_LATITUDE, sizeof(p_timebase->sun_rs_info.latitude), (uint8_t *)&p_timebase->sun_rs_info.latitude);
    TIMEBASE_KLV_SET_ERR_CHECK(offset, p_buf, buf_len, offset, TIME_SUN_RISE_SET_KEY_ALTITUDE, sizeof(p_timebase->sun_rs_info.altitude), (uint8_t *)&p_timebase->sun_rs_info.altitude);
    TIMEBASE_KLV_SET_ERR_CHECK(offset, p_buf, buf_len, offset, TIME_SUN_RISE_SET_KEY_RISE_TIME, sizeof(p_timebase->sun_rs_info.sun_rise_utc), (uint8_t *)&p_timebase->sun_rs_info.sun_rise_utc);
    TIMEBASE_KLV_SET_ERR_CHECK(offset, p_buf, buf_len, offset, TIME_SUN_RISE_SET_KEY_SET_TIME, sizeof(p_timebase->sun_rs_info.sun_set_utc), (uint8_t *)&p_timebase->sun_rs_info.sun_set_utc);
    TIMEBASE_KLV_SET_ERR_CHECK(offset, p_buf, buf_len, offset, TIME_WINTER_SUMMER_KEY_ENABLED, sizeof(p_timebase->dst_info.enabled), (uint8_t *)&p_timebase->dst_info.enabled);
    TIMEBASE_KLV_SET_ERR_CHECK(offset, p_buf, buf_len, offset, TIME_WINTER_SUMMER_KEY_CUR_OFFSET_SEC, sizeof(p_timebase->dst_info.cur_ofs_sec), (uint8_t *)&p_timebase->dst_info.cur_ofs_sec);
    TIMEBASE_KLV_SET_ERR_CHECK(offset, p_buf, buf_len, offset, TIME_WINTER_SUMMER_KEY_NEXT_OFFSET_SEC, sizeof(p_timebase->dst_info.next_ofs_sec), (uint8_t *)&p_timebase->dst_info.next_ofs_sec);
    TIMEBASE_KLV_SET_ERR_CHECK(offset, p_buf, buf_len, offset, TIME_WINTER_SUMMER_KEY_SW_UTC, sizeof(p_timebase->dst_info.dst_sw_utc), (uint8_t *)&p_timebase->dst_info.dst_sw_utc);
    *p_out_size = offset;

    return TMBS_OK;
}

/**
 * @brief Timebase 反序列化
 * @param[in]  p_buf                [输入的二进制流数据]
 * @param[in]  data_len             [输入的二进制流数据的长度]
 * @param[out] p_timebase           [输出的时基数据]
 * @return TMBS_RESULT_E
 */
int tb_cfg_unmarshal(uint8_t *p_buf, uint32_t data_len, vesync_timebase_t *p_timebase)
{
    uint8_t version = 0;

    if (SDK_FAIL == vesync_klv_get(p_buf, data_len, TIME_BASE_VERSION, sizeof(uint8_t), &version))
    {
#if TIMEBASE_DEBUG_PRINT == 1
        SDK_LOG(LOG_ERROR, "get cfg_version error\n");
#endif
        return TMBS_CFG_ERR;
    }
#if TIMEBASE_DEBUG_PRINT == 1
    SDK_LOG(LOG_ERROR, "get cfg_version: %d\n", version);
#endif

    vesync_klv_get(p_buf, data_len, TIME_ZONE_KEY_NAME, sizeof(p_timebase->tz_info.timezone_str), (uint8_t *)p_timebase->tz_info.timezone_str);
    vesync_klv_get(p_buf, data_len, TIME_ZONE_KEY_OFFSET, sizeof(p_timebase->tz_info.timezone_ofs_sec), (uint8_t *)&p_timebase->tz_info.timezone_ofs_sec);
    vesync_klv_get(p_buf, data_len, TIME_SUN_RISE_SET_KEY_LONGITUDE, sizeof(p_timebase->sun_rs_info.longitude), (uint8_t *)&p_timebase->sun_rs_info.longitude);
    vesync_klv_get(p_buf, data_len, TIME_SUN_RISE_SET_KEY_LATITUDE, sizeof(p_timebase->sun_rs_info.latitude), (uint8_t *)&p_timebase->sun_rs_info.latitude);
    vesync_klv_get(p_buf, data_len, TIME_SUN_RISE_SET_KEY_ALTITUDE, sizeof(p_timebase->sun_rs_info.altitude), (uint8_t *)&p_timebase->sun_rs_info.altitude);
    vesync_klv_get(p_buf, data_len, TIME_SUN_RISE_SET_KEY_RISE_TIME, sizeof(p_timebase->sun_rs_info.sun_rise_utc), (uint8_t *)&p_timebase->sun_rs_info.sun_rise_utc);
    vesync_klv_get(p_buf, data_len, TIME_SUN_RISE_SET_KEY_SET_TIME, sizeof(p_timebase->sun_rs_info.sun_set_utc), (uint8_t *)&p_timebase->sun_rs_info.sun_set_utc);
    vesync_klv_get(p_buf, data_len, TIME_WINTER_SUMMER_KEY_ENABLED, sizeof(p_timebase->dst_info.enabled), (uint8_t *)&p_timebase->dst_info.enabled);
    vesync_klv_get(p_buf, data_len, TIME_WINTER_SUMMER_KEY_CUR_OFFSET_SEC, sizeof(p_timebase->dst_info.cur_ofs_sec), (uint8_t *)&p_timebase->dst_info.cur_ofs_sec);
    vesync_klv_get(p_buf, data_len, TIME_WINTER_SUMMER_KEY_NEXT_OFFSET_SEC, sizeof(p_timebase->dst_info.next_ofs_sec), (uint8_t *)&p_timebase->dst_info.next_ofs_sec);
    vesync_klv_get(p_buf, data_len, TIME_WINTER_SUMMER_KEY_SW_UTC, sizeof(p_timebase->dst_info.dst_sw_utc), (uint8_t *)&p_timebase->dst_info.dst_sw_utc);

    return TMBS_OK;
}

/**
 * @brief Timebase内部函数，默认的读取配置回调
 * @param[out] p_rd_buf      [指向数据读取的Buffer]
 * @param[in]  buf_len       [Buffer的长度]
 * @param[out] p_rd_len      [指向储存读取的长度]
 * @return int               [TMBS_RESULT_E]
 */
int tb_default_rd_cfg_cb(uint8_t *p_rd_buf, uint32_t buf_len, uint32_t *p_rd_len)
{
    UNUSED(buf_len);

    if (NULL == p_rd_len)
    {
        return TMBS_ERR;
    }

    /// @attention: p_rd_buf为NULL，返回存储数据的长度
    int ret = vhal_flash_read(PARTITION_CFG, TIMEBASE_DEFAULT_USER_CFG_KEY, p_rd_buf, p_rd_len);
    if (VHAL_OK != ret)
    {
        SDK_LOG(LOG_WARN, "read flash fail[%d]\n", ret);

        /// @todo: vhal_flash还需要进一步的优化错误处理
        /// @note: 将读取长度设为0，当作配置不存在
        *p_rd_len = 0;
    }

    return TMBS_OK;
}

/**
 * @brief Timebase内部函数，默认的写入配置回调
 * @param[in]  p_wr_buf      [指向被写入的Buffer]
 * @param[in]  len           [将被写入的数据长度]
 * @return int               [TMBS_RESULT_E]
 */
int tb_default_wr_cfg_cb(uint8_t *p_wr_buf, uint32_t len)
{
    if (NULL == p_wr_buf || len == 0)
    {
        return TMBS_ERR;
    }

    int ret = vhal_flash_write(PARTITION_CFG, TIMEBASE_DEFAULT_USER_CFG_KEY, p_wr_buf, len);
    if (VHAL_OK != ret)
    {
        SDK_LOG(LOG_ERROR, "write flash fail[%d]\n", ret);
        return TMBS_ERR;
    }

    return TMBS_OK;
}
