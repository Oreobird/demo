/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_mutex.c
 * @brief       mutex抽象层，封装freertos互斥量相关接口
 * @author      Joshua
 * @date        2021-04-20
 */

#include <freertos/FreeRTOS.h>
#include <freertos/semphr.h>

#include "vesync_common.h"
#include "vesync_mutex.h"

/*
 * @brief  创建mutex
 * @param[in]  mtx                     [互斥量结构体指针]
 * @return int                         [成功：VOS_OK；失败：VOS_FAIL]
 */
int vesync_mutex_new(vesync_mutex_t *mtx)
{
    VCOM_NULL_PARAM_CHK(mtx, return VOS_FAIL);
    SemaphoreHandle_t mutex = xSemaphoreCreateMutex();
    mtx->handle = mutex;
    return mutex != NULL ? VOS_OK : VOS_FAIL;
}

/*
 * @brief  mutex上锁
 * @param[in]  mtx                     [互斥量结构体指针]
 * @return int                         [成功：VOS_OK；失败：VOS_FAIL]
 */
int vesync_mutex_lock(vesync_mutex_t *mtx)
{
    VCOM_NULL_PARAM_CHK(mtx, return VOS_FAIL);
    VCOM_NULL_PARAM_CHK(mtx->handle, return VOS_FAIL);
    BaseType_t ret = xSemaphoreTake(mtx->handle, portMAX_DELAY);
    return ret == pdPASS ? VOS_OK : VOS_FAIL;
}

/*
 * @brief  mutex解锁
 * @param[in]  mtx                     [互斥量结构体指针]
 * @return int                         [成功：VOS_OK；失败：VOS_FAIL]
 */
int vesync_mutex_unlock(vesync_mutex_t *mtx)
{
    VCOM_NULL_PARAM_CHK(mtx, return VOS_FAIL);
    VCOM_NULL_PARAM_CHK(mtx->handle, return VOS_FAIL);
    BaseType_t ret = xSemaphoreGive(mtx->handle);
    return ret == pdPASS ? VOS_OK : VOS_FAIL;
}

/*
 * @brief  销毁mutex
 * @param[in]  mtx                     [互斥量结构体指针]
 * @return int                         [成功：VOS_OK；失败：VOS_FAIL]
 */
int vesync_mutex_free(vesync_mutex_t *mtx)
{
    VCOM_NULL_PARAM_CHK(mtx, return VOS_FAIL);
    VCOM_NULL_PARAM_CHK(mtx->handle, return VOS_FAIL);
    vSemaphoreDelete(mtx->handle);
    return VOS_OK;
}

