/**
 *  Copyright © Vesync Technologies Co.Ltd. 2022. All rights reserved
 * @file        vesync_loop_timer_daemon.c
 * @brief       基于内部定时器封装的事件与定时器处理任务接口实现
 * @author      Herve
 * @date        2022-01-28
 */

#include <stdint.h>
#include <stddef.h>
#include <string.h>

#include "vesync_loop_timer_daemon.h"
#include "vesync_loop_timer.h"

#include "vesync_log_internal.h"
#include "vesync_os.h"
#include "vesync_memory.h"
#include "vesync_common.h"

/**
 * @brief 向vloop推送一个事件
 * @param[in]   td              [vloop任务实例]
 * @param[in]   id              [事件ID]
 * @param[in]   buf             [必要的数据缓存，将被做拷贝而不是引用]
 * @param[in]   len             [数据缓存大小]
 * @return      int             [SDK_OK; SDK_FAIL]
 */
static int event_publish(task_daemon_t *td, int id, const uint8_t *buf, const uint16_t len)
{
    VCOM_NULL_PARAM_CHK(td, return SDK_FAIL);

    vloop_ev_t ev = {0};
    ev.id = id;
    if (buf != NULL)
    {
        ev.buf = (uint8_t *)vesync_malloc(len);
        if (NULL == ev.buf)
        {
            return SDK_FAIL;
        }
        memcpy(ev.buf, buf, len);
        ev.len = len;
    }

    unsigned int timeout = VESYNC_OS_WAIT_FOREVER;
    if (vesync_task_get_curr_handle() == td->task_handle)
    {
        timeout = VESYNC_OS_NO_WAIT;
    }
    int ret = vesync_queue_send(td->event_queue, &ev, timeout);
    if (ret != VOS_OK)
    {
        vesync_free(ev.buf);
        return SDK_FAIL;
    }
    return SDK_OK;
}

/**
 * @brief vloop run任务的执行主体，会消费定时器或者自定义事件
 * @param[in]   arg             [回调vloop任务实例]
 */
static void event_process_task(void *arg)
{
    task_daemon_t *td = (task_daemon_t *)arg;

    while (1)
    {
        vloop_ev_t ev;
        if (VOS_OK == vesync_queue_recv(td->event_queue,
                                        &ev,
                                        vloop_timer_process_expired(&td->timer_header)))
        {
            timer_ev_cont_t *timer_ev = (timer_ev_cont_t *)ev.buf;
            event_sub_t *find_sub = td->event_subs_header;
            switch (ev.id)
            {
            case TIMER_EV_ADD:
                vloop_timer_add(&td->timer_header, timer_ev->timer);
                break;
            case TIMER_EV_DEL:
                vloop_timer_del(&td->timer_header, timer_ev->timer);
                break;
            case TIMER_EV_CH_PERIOD:
                timer_ev->timer->period = timer_ev->new_period;
                vloop_timer_add(&td->timer_header, timer_ev->timer);
                break;
            case TIMER_EV_FREE:
                vloop_timer_del(&td->timer_header, timer_ev->timer);
                vesync_free(timer_ev->timer);
                break;
            default:
                // Dispatch all the other events
                while (find_sub != NULL)
                {
                    if (find_sub->id == ev.id)
                    {
                        find_sub->handle_cb((void *)&ev);
                    }
                    find_sub = find_sub->next;
                }
                break;
            }
            vesync_free(ev.buf);
        }
    }
}

vloop_hdl_t vloop_create(const char *task_name, int stack_size, int prio, int event_queue_size)
{
    task_daemon_t *td = vesync_calloc(1, sizeof(task_daemon_t));
    if (NULL == td)
    {
        return NULL;
    }

    td->event_queue = vesync_queue_new(event_queue_size * sizeof(vloop_ev_t), sizeof(vloop_ev_t));
    if (NULL == td->event_queue)
    {
        goto EXIT;
    }

    int ret = vesync_task_new(task_name,
                              NULL,
                              event_process_task,
                              td,
                              stack_size,
                              prio,
                              &td->task_handle);
    if (ret != VOS_OK)
    {
        goto EXIT;
    }

    return (vloop_hdl_t)td;
EXIT:
    vesync_queue_free(td->event_queue);
    vesync_free(td);
    return NULL;
}

int vloop_destroy(vloop_hdl_t hdl)
{
    // todo: task gracefully exit
    return SDK_FAIL;
}

vesync_timer_t *vloop_timer_new(vloop_hdl_t hdl,
                                const char *name,
                                void (*cb)(void *),
                                void *cb_arg,
                                long timeout_ms,
                                bool reload)
{
    UNUSED(hdl);
    UNUSED(name);

    VCOM_NULL_PARAM_CHK(cb, return NULL);

    vesync_timer_t *timer = NULL;
    vloop_timer_t *base = NULL;

    timer = (vesync_timer_t *)vesync_calloc(1, sizeof(vesync_timer_t));
    base = (vloop_timer_t *)vesync_calloc(1, sizeof(vloop_timer_t));
    if ((timer == NULL) || (base == NULL))
    {
        goto EXIT;
    }

    timer->cb = cb;
    timer->cb_arg = cb_arg;
    timer->timeout_ms = timeout_ms;
    timer->reload = reload;
    timer->handle = base;

    base->reload = reload;
    base->period = timeout_ms;
    base->cb = cb;
    base->arg = cb_arg;

    return timer;
EXIT:
    VCOM_SAFE_FREE(timer);
    VCOM_SAFE_FREE(base);
    return NULL;
}

int vloop_timer_start(vloop_hdl_t hdl, vesync_timer_t *timer)
{
    VCOM_NULL_PARAM_CHK(hdl, return SDK_FAIL);
    VCOM_NULL_PARAM_CHK(timer, return SDK_FAIL);
    VCOM_NULL_PARAM_CHK(timer->handle, return SDK_FAIL);

    task_daemon_t *td = (task_daemon_t *)hdl;

    timer_ev_cont_t timer_ev = {0};
    timer_ev.timer = timer->handle;

    int ret = event_publish(td, TIMER_EV_ADD, (uint8_t *)&timer_ev, sizeof(timer_ev));
    if (SDK_OK != ret)
    {
        return SDK_FAIL;
    }
    return SDK_OK;
}

int vloop_timer_stop(vloop_hdl_t hdl, vesync_timer_t *timer)
{
    VCOM_NULL_PARAM_CHK(hdl, return SDK_FAIL);
    VCOM_NULL_PARAM_CHK(timer, return SDK_FAIL);
    VCOM_NULL_PARAM_CHK(timer->handle, return SDK_FAIL);

    task_daemon_t *td = (task_daemon_t *)hdl;

    timer_ev_cont_t timer_ev = {0};
    timer_ev.timer = timer->handle;

    int ret = event_publish(td, TIMER_EV_DEL, (uint8_t *)&timer_ev, sizeof(timer_ev));
    if (SDK_OK != ret)
    {
        return SDK_FAIL;
    }
    return SDK_OK;
}

int vloop_timer_change_period(vloop_hdl_t hdl, vesync_timer_t *timer, long timeout_ms)
{
    VCOM_NULL_PARAM_CHK(hdl, return SDK_FAIL);
    VCOM_NULL_PARAM_CHK(timer, return SDK_FAIL);
    VCOM_NULL_PARAM_CHK(timer->handle, return SDK_FAIL);

    task_daemon_t *td = (task_daemon_t *)hdl;

    timer_ev_cont_t timer_ev = {0};
    timer_ev.timer = timer->handle;
    timer_ev.new_period = timeout_ms;

    int ret = event_publish(td, TIMER_EV_CH_PERIOD, (uint8_t *)&timer_ev, sizeof(timer_ev));
    if (SDK_OK != ret)
    {
        return SDK_FAIL;
    }
    return SDK_OK;
}

int vloop_timer_free(vloop_hdl_t hdl, vesync_timer_t *timer)
{
    VCOM_NULL_PARAM_CHK(hdl, return SDK_FAIL);
    VCOM_NULL_PARAM_CHK(timer, return SDK_FAIL);
    VCOM_NULL_PARAM_CHK(timer->handle, return SDK_FAIL);

    task_daemon_t *td = (task_daemon_t *)hdl;

    timer_ev_cont_t timer_ev = {0};
    timer_ev.timer = timer->handle;

    int ret = event_publish(td, TIMER_EV_FREE, (uint8_t *)&timer_ev, sizeof(timer_ev));
    if (SDK_OK != ret)
    {
        return SDK_FAIL;
    }

    vesync_free(timer);
    return SDK_OK;
}

int vloop_event_subscribe(vloop_hdl_t hdl, int id, void (*handle_cb)(void *arg))
{
    VCOM_NULL_PARAM_CHK(hdl, return SDK_FAIL);
    VCOM_NULL_PARAM_CHK(handle_cb, return SDK_FAIL);

    if ((id > TIMER_EV_ID_MIN) || (id < TIMER_EV_ID_MAX))
    {
        return SDK_FAIL;
    }

    task_daemon_t *td = (task_daemon_t *)hdl;

    event_sub_t *new_node = vesync_calloc(1, sizeof(event_sub_t));
    if (NULL == new_node)
    {
        return SDK_FAIL;
    }

    new_node->id = id;
    new_node->handle_cb = handle_cb;

    if (NULL == td->event_subs_header)
    {
        td->event_subs_header = new_node;
        return SDK_OK;
    }

    event_sub_t *tail = td->event_subs_header;
    while ((tail != NULL) && (tail->next != NULL))
    {
        tail = tail->next;
    }
    tail->next = new_node;
    return SDK_OK;
}

int vloop_event_publish(vloop_hdl_t hdl, int id, const uint8_t *data, uint16_t len)
{
    VCOM_NULL_PARAM_CHK(hdl, return SDK_FAIL);

    if ((id > TIMER_EV_ID_MIN) || (id < TIMER_EV_ID_MAX))
    {
        return SDK_FAIL;
    }

    task_daemon_t *td = (task_daemon_t *)hdl;
    return event_publish(td, id, data, len);
}
