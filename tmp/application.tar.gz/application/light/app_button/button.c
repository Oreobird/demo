/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        button.c
 * @brief       应用按键接口
 * @author      Joshua
 * @date        2021-12-23
 */
#include <stddef.h>
#include <string.h>

#include "vesync_log.h"
#include "vesync_common.h"
#include "vesync_memory.h"
#include "app_cfg.h"
#include "button.h"


int app_button_cfg_validate(void)
{
#ifndef APP_BUTTON_NUM
    return APP_FAIL;
#endif

#if (APP_BUTTON_NUM < 0) && (APP_BUTTON_NUM > APP_BUTTON_MAX_NUM)
    #error "Error: invalid button number!!!"
#endif
#if (APP_BUTTON_NUM >= 1) && !defined(APP_BUTTON0_CFG)
    #error "Error: invalid button cfg!!!"
#endif
#if (APP_BUTTON_NUM >= 2) && !defined(APP_BUTTON1_CFG)
    #error "Error: invalid button cfg!!!"
#endif
#if (APP_BUTTON_NUM >= 3) && !defined(APP_BUTTON2_CFG)
    #error "Error: invalid button cfg!!!"
#endif
#if (APP_BUTTON_NUM == 4) && !defined(APP_BUTTON3_CFG)
    #error "Error: invalid button cfg!!!"
#endif
    return APP_OK;
}

int app_button_init(void)
{
    if (app_button_cfg_validate() != APP_OK)
    {
        return APP_FAIL;
    }

    app_btn_cfg_t app_btn_cfg[APP_BUTTON_NUM] = {
        APP_BUTTON0_CFG
#ifdef APP_BUTTON1_CFG
        APP_BUTTON1_CFG
#endif
#ifdef APP_BUTTON2_CFG
        APP_BUTTON2_CFG
#endif
#ifdef APP_BUTTON3_CFG
        APP_BUTTON3_CFG
#endif
    };

    for (int i = 0; i < APP_BUTTON_NUM; i++)
    {
        if (app_btn_cfg[i].long_press_type == NETCFG)
        {
            button_netcfg_init(&app_btn_cfg[i]);
        }
#if APP_BUTTON_NUM > 1
        else
        {
            button_long_press_init(&app_btn_cfg[i]);
        }

        if (app_btn_cfg[i].short_press_type != SP_NONE)
        {
            button_short_press_init(&app_btn_cfg[i]);
        }
#endif
    }

    return APP_OK;
}

