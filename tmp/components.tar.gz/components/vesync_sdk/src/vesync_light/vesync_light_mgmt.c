/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file    vesync_light_mgmt.c
* @brief   灯光照明控制模块实现
* @author  Herve
* @date    2021-11-09
*/
#include <string.h>
#include <stdbool.h>
#include <stdint.h>

#include "vesync_common.h"
#include "vesync_memory.h"
#include "vesync_log_internal.h"
#include "vesync_light_internal.h"
#include "vesync_light_timer.h"

#define LIGHT_MGMT_NEW_LOCK() vesync_mutex_new()
#define LIGHT_MGMT_DEL_LOCK(m) \
    do                         \
    {                          \
        vesync_mutex_free(m);  \
        m = NULL;              \
    } while (0)

#define LIGHT_MGMT_LOCK(m) LIGHT_CHECK(VOS_OK == vesync_mutex_lock(m), LIGHT_ERR)
#define LIGHT_MGMT_LOCK_RET(m, ret) LIGHT_CHECK(VOS_OK == vesync_mutex_lock(m), ret)
#define LIGHT_MGMT_UNLOCK(m) vesync_mutex_unlock(m)

// 全局灯光模块管理器
static light_mgmt_t s_light_mgmt = LIGHT_MGMT_INIT_VAL;

/**
 * @brief 创建灯光控制器节点
 * @param[in] pst_head      [灯光控制器组链表头]
 * @return light_node_t*    [返回创建的节点，如果返回NULL，则创建失败]
 */
static light_node_t *light_node_new(struct list_head *pst_head)
{
    light_node_t *p_node = NULL;
    PTR_ASSERT_EXIT(pst_head, EXIT);

    p_node = (light_node_t *)vesync_calloc(1, sizeof(light_node_t));
    if (p_node != NULL)
    {
        list_add(&p_node->list, pst_head);
    }

EXIT:
    return p_node;
}

/**
 * @brief 销毁灯光控制器节点
 * @param[in] p_node        [指向灯光控制器节点]
 */
static void light_node_destroy(light_node_t *p_node)
{
    if (NULL == p_node)
    {
        return;
    }
    list_del_init(&p_node->list);
    vesync_free(p_node);
}

int vesync_light_init(void)
{
    LIGHT_CHECK(false == s_light_mgmt.is_init, LIGHT_IS_INIT);

    int ret = LIGHT_OK;
    memset(&s_light_mgmt, 0, sizeof(light_mgmt_t));
    s_light_mgmt.light_num = 0;
    INIT_LIST_HEAD(&s_light_mgmt.light_grp);

    s_light_mgmt.mutex = LIGHT_MGMT_NEW_LOCK();
    PTR_ASSERT(s_light_mgmt.mutex);

    ret = light_timer_task_start();
    if (LIGHT_OK != ret)
    {
        SDK_LOG(LOG_ERROR, "timer task start fail\n");
        goto EXIT;
    }

    s_light_mgmt.is_init = true;
EXIT:
    if (LIGHT_OK != ret)
    {
        LIGHT_MGMT_DEL_LOCK(s_light_mgmt.mutex);
    }
    return ret;
}

int vesync_light_deinit(void)
{
    LIGHT_CHECK(true == s_light_mgmt.is_init, LIGHT_NO_INIT);
    LIGHT_MGMT_LOCK(s_light_mgmt.mutex);

    int ret = LIGHT_OK;
    if (s_light_mgmt.light_num > 0)
    {
        struct list_head *p_head = &s_light_mgmt.light_grp;
        light_node_t *p_pos, *p_n;
        list_for_each_entry_safe(p_pos, p_n, p_head, list)
        {
            ret = light_obj_destroy(p_pos->light);
            if (LIGHT_OK == ret)
            {
                light_node_destroy(p_pos);
                s_light_mgmt.light_num--;
                continue;
            }
            SDK_LOG(LOG_ERROR, "light_obj_destroy fail[%d]", ret);
            break;
        }
    }
    LIGHT_MGMT_UNLOCK(s_light_mgmt.mutex);
    if (LIGHT_OK == ret)
    {
        LIGHT_MGMT_DEL_LOCK(s_light_mgmt.mutex);
        s_light_mgmt.is_init = false;

        if (LIGHT_OK != light_timer_task_stop())
        {
            SDK_LOG(LOG_ERROR, "timer task stop fail\n");
        }
    }
    return ret;
}

vesync_light_t vesync_light_create(uint16_t ch_num, uint32_t step_intvl, uint32_t max_duty, vesync_light_ctrl_cb_t ch_ctrl_cb, void *cb_arg)
{
    LIGHT_CHECK(ch_num != 0, NULL);
    LIGHT_CHECK(ch_num <= LIGHT_CH_NUM_MAX, NULL);
    LIGHT_CHECK(ch_ctrl_cb != NULL, NULL);

    light_t *p_light = NULL;
    light_node_t *p_node = NULL;

    LIGHT_MGMT_LOCK_RET(s_light_mgmt.mutex, NULL);
    if (s_light_mgmt.light_num >= LIGHT_NUM_MAX)
    {
        goto EXIT;
    }

    p_node = light_node_new(&s_light_mgmt.light_grp);
    PTR_ASSERT_EXIT(p_node, EXIT);

    p_light = light_obj_create(ch_num, step_intvl, max_duty, ch_ctrl_cb, cb_arg);
    PTR_ASSERT_EXIT(p_light, EXIT);

    p_node->light = p_light;
    s_light_mgmt.light_num++;

    LIGHT_MGMT_UNLOCK(s_light_mgmt.mutex);
    return (vesync_light_t)p_light;
EXIT:
    if (p_node != NULL)
    {
        light_node_destroy(p_node);
    }
    LIGHT_MGMT_UNLOCK(s_light_mgmt.mutex);
    return NULL;
}

int vesync_light_destroy(vesync_light_t hdl)
{
    light_t *p_light = (light_t *)hdl;
    PTR_ASSERT(p_light);

    LIGHT_MGMT_LOCK(s_light_mgmt.mutex);

    int ret = LIGHT_ERR;
    if (s_light_mgmt.light_num > 0)
    {
        struct list_head *p_head = &s_light_mgmt.light_grp;
        light_node_t *p_pos, *p_n;
        list_for_each_entry_safe(p_pos, p_n, p_head, list)
        {
            if (p_pos->light != p_light)
            {
                continue;
            }
            ret = light_obj_destroy(p_pos->light);
            if (LIGHT_OK == ret)
            {
                light_node_destroy(p_pos);
                s_light_mgmt.light_num--;
            }
            else
            {
                SDK_LOG(LOG_ERROR, "light_obj_destroy fail");
            }
            break;
        }
    }

    LIGHT_MGMT_UNLOCK(s_light_mgmt.mutex);
    return ret;
}

int vesync_light_get_duty(vesync_light_t hdl, uint16_t ch_idx, uint32_t *p_duty)
{
    light_t *p_light = (light_t *)hdl;
    PTR_ASSERT(p_light);
    return light_obj_get_duty(p_light, ch_idx, p_duty);
}

int vesync_light_set_gamma(vesync_light_t hdl, uint16_t ch_idx, float gamma)
{
    light_t *p_light = (light_t *)hdl;
    PTR_ASSERT(p_light);
    return light_obj_set_gamma(p_light, ch_idx, gamma);
}

int vesync_light_fade_with_time_cfg(vesync_light_t hdl, uint16_t ch_idx, float bright, uint32_t period, uint32_t delay)
{
    light_t *p_light = (light_t *)hdl;
    PTR_ASSERT(p_light);
    return light_obj_fade_with_time_cfg(p_light, ch_idx, bright, period, delay);
}

int vesync_light_fade_with_step_cfg(vesync_light_t hdl, uint16_t ch_idx, float bright, float scale, uint32_t delay)
{
    light_t *p_light = (light_t *)hdl;
    PTR_ASSERT(p_light);
    return light_obj_fade_with_step_cfg(p_light, ch_idx, bright, scale, delay);
}

int vesync_light_blink_cfg(vesync_light_t hdl, uint16_t ch_idx, float bright, uint32_t period, uint32_t delay, uint32_t sc_num)
{
    light_t *p_light = (light_t *)hdl;
    PTR_ASSERT(p_light);
    return light_obj_blink_cfg(p_light, ch_idx, bright, period, delay, sc_num);
}

int vesync_light_breath_cfg(vesync_light_t hdl, uint16_t ch_idx, float bright, uint32_t period, uint32_t delay, uint32_t sc_num)
{
    light_t *p_light = (light_t *)hdl;
    PTR_ASSERT(p_light);
    return light_obj_breath_cfg(p_light, ch_idx, bright, period, delay, sc_num);
}

int vesync_light_start(vesync_light_t hdl, uint16_t ch_idx)
{
    light_t *p_light = (light_t *)hdl;
    PTR_ASSERT(p_light);
    return light_obj_start(p_light, ch_idx);
}

int vesync_light_stop(vesync_light_t hdl, uint16_t ch_idx)
{
    light_t *p_light = (light_t *)hdl;
    PTR_ASSERT(p_light);
    return light_obj_stop(p_light, ch_idx);
}
