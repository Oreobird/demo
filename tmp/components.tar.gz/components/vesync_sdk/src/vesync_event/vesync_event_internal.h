/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_event_internal.h
 * @brief       事件处理接口
 * @date        2021-05-11
 */

#ifndef __VESYNC_EVENT_INTERNAL_H__
#define __VESYNC_EVENT_INTERNAL_H__

#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include "vesync_cfg_internal.h"
#include "vesync_task.h"
#include "vesync_mutex.h"
#include "vesync_list.h"

#ifdef __cplusplus
extern "C" {
#endif


#define EVENT_TASK_NAME           "event_task"
#define EVENT_TASK_PRIO           TASK_PRIORITY_SOFT_REALTIME

#ifndef PR_EVENT_TASK_STACKSIZE
#define EVENT_TASK_STACKSIZE      (1024*3)
#else
#define EVENT_TASK_STACKSIZE      (PR_EVENT_TASK_STACKSIZE)
#endif
#ifndef PR_EVENT_QUEUE_MAX_NUM
#define EVENT_QUEUE_MAX_NUM       (32)
#else
#define EVENT_QUEUE_MAX_NUM       (PR_EVENT_QUEUE_MAX_NUM)
#endif

/**
 * @brief 事件填充宏
 */
#define VESYNC_POPULATE_EV(event, _id, _publisher, _len, _buf) \
    do { \
        memset(&(event), 0, sizeof(vesync_ev_t)); \
        event.event_id = (_id); \
        snprintf((event).publisher, sizeof((event).publisher), (_publisher)); \
        event.len = (_len); \
        event.buf = (_buf); \
    } while (0)

/**
 * @brief 事件定义
 */
#define FOREACH_EVENT(EVENT) \
            EVENT(EVENT_NONE)     \
            EVENT(EVENT_WIFI_CONNECTED)     \
            EVENT(EVENT_WIFI_DISCONNECTED)  \
            EVENT(EVENT_WIFI_SCANDONE)      \
            EVENT(EVENT_BLE_CONNECTED)      \
            EVENT(EVENT_BLE_DISCONNECTED)   \
            EVENT(EVENT_ROUTER_GOT_IP)      \
            EVENT(EVENT_NWK_CONNECTED)     \
            EVENT(EVENT_NWK_DISCONNECTED)  \
            EVENT(EVENT_NWK_RESET)         \
            EVENT(EVENT_DNS_RESOLVED)       \
            EVENT(EVENT_DEL_USER_DATA)      \
            EVENT(EVENT_FFS_CLOUD_RSP)              /*FFS配网时，云回复信息才是成功的   */ \
            EVENT(EVENT_NETCFG_SUCCEED)             \
            EVENT(EVENT_NETCFG_APP_CONNECTED)       \
            EVENT(EVENT_NETCFG_RECEIVE_CONFIG)      \
            EVENT(EVENT_NETCFG_APP_DISCONNECTED)    \
            EVENT(EVENT_NETCFG_STEP_TIMEOUT)        /* timeout for each step after receive the configuration*/ \
            EVENT(EVENT_NETCFG_TIMEOUT)             /* 10mins timeout */ \
            EVENT(EVENT_NETCFG_APP_CANCEL)          /*user cancel netcfg process from the APP*/ \
            EVENT(EVENT_NETCFG_FORCE_EXIT)          /*exit netcfg task*/ \
            EVENT(EVENT_NWK_READY)                  /*业务层网络通信已就绪*/ \
            EVENT(EVENT_LAN_COMM_TCP_DATA)          \
            EVENT(EVENT_DEVELOPER_STOP)             \
            EVENT(EVENT_UNKNOWN)

#define GEN_ENUM(ENUM) ENUM,
#define GEN_STRING(STR) #STR,

typedef enum {
    FOREACH_EVENT(GEN_ENUM)
} EVENT_ID_E;

/**
 * @brief 事件定义
 */
#define FOREACH_SUBCRIBER(SUB) \
    SUB(SUB_ID_NONE)  \
    SUB(SUB_ID_NETCFG)  \
    SUB(SUB_ID_FFS)  \
    SUB(SUB_ID_BYPASS)  \
    SUB(SUB_ID_TIMEBASE)  \
    SUB(SUB_ID_NET_SERVICE)  \
    SUB(SUB_ID_PRODUCTION)  \
    SUB(SUB_ID_DEVELOPER)  \
    SUB(SUB_ID_REPORT)  \
    SUB(SUB_ID_DEVICE)  \
    SUB(SUB_ID_UNKNOWN)

/**
 * @brief 订阅者ID
 */
typedef enum
{
    FOREACH_SUBCRIBER(GEN_ENUM)
} SUB_ID_E;


/**
 * @brief 事件订阅回调函数类型
 * @param[in]  data                 [事件数据指针]
 * @return  int                     [成功：SDK_OK，失败：SDK_FAIL]
 */
typedef int (*event_subscribe_cb_t)(void *data);

/**
 * @brief 事件结构体
 */
typedef struct
{
    EVENT_ID_E event_id;    //事件ID
    char publisher[16];     //事件发布者字符串标识
    int len;                //buf长度
    void *buf;              //消息数据指针
} vesync_ev_t;

/**
 * @brief 订阅节点
 */
typedef struct
{
    int sub_id;                         // 订阅者ID
    event_subscribe_cb_t event_handle;  //订阅的回调处理函数
    struct list_head list;
} event_subscribe_t;


/**
 * @brief 事件节点
 */
typedef struct
{
    EVENT_ID_E event_id;             //事件ID

    vesync_mutex_t mutex;            //链表互斥锁
    struct list_head subscribe_list; //挂接订阅者

    struct list_head list;
} event_node_t;


/**
 * @brief 事件订阅管理
 */
typedef struct
{
    int event_num;              //已订阅的事件数量

    vesync_mutex_t mutex;       //链表互斥锁
    struct list_head node_list; //挂接事件节点
} event_manage_t;


/**
 * @brief 发布事件通知
 * @param[in] *event         [发布的事件结构体指针]
 * @return int               [成功：SDK_OK，失败：SDK_FAIL]
 */
int vesync_event_publish(vesync_ev_t *event);

/**
 * @brief 订阅事件通知
 * @param[in] event_id       [订阅的事件ID]
 * @param[in] sub_id         [订阅者ID]
 * @param[in] cb             [订阅的回调处理函数]
 * @return int               [成功：SDK_OK，失败：SDK_FAIL]
 */
int vesync_event_subscribe(EVENT_ID_E event_id, SUB_ID_E sub_id, event_subscribe_cb_t cb);

/**
 * @brief 取消订阅事件通知
 * @param[in] event_id       [取消订阅的事件ID]
 * @param[in] sub_id         [取消订阅的订阅者ID]
 * @return int               [成功：SDK_OK，失败：SDK_FAIL]
 */
int vesync_event_unsubscribe(EVENT_ID_E event_id, SUB_ID_E sub_id);

/**
 * @brief 初始化事件处理中心
 * @return  int              [成功：SDK_OK，失败：SDK_FAIL]
 */
int vesync_event_init(void);

/**
 * @brief 释放事件处理中心资源
 */
void vesync_event_deinit(void);


/**
 * @brief 打印事件与订阅链表
 */
void vesync_event_dump_list(void);

#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_EVENT_INTERNAL_H__ */



