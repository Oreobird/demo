/**
 *  Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
 * @file        vesync_loop_timer.c
 * @brief       运行在任务内部的定时器，为了区别freeRTOS自带的软件定时器，后续统称内部定时器
 * @author      Louis
 * @date        2021-01-27
 */

#include <string.h>

#include "vesync_log_internal.h"
#include "vesync_loop_timer_internal.h"
#include "vesync_task.h"
#include "vesync_os.h"


/**
 * @brief 获取设备启动时间ms
 * @return    uint64_t          [系统启动时间，ms]
 * @note    需要考虑溢出的情况
 */
static uint64_t vloop_timer_get_uptime(void)
{
    static uint32_t count = 0;
    static uint64_t last_ms = 0;

    uint64_t cur_ms = vesync_task_get_tick_ms();
    if (cur_ms < last_ms)
    {
        count++;
    }
    last_ms = cur_ms;

    return (count * vesync_task_get_max_tick_ms() + cur_ms);
}

/**
 * @brief 添加内部定时器到链表中，开始倒计时
 * @param[in] p_timer_header    [内部定时器链表指针]
 * @param[in] p_timer           [内部定时器地址]
 * @return    bool              [成功/失败]
 * @note
 */
bool vloop_timer_add(vloop_timer_header_t *p_timer_header, vloop_timer_t *p_timer)
{
    vloop_timer_t *p_cur = NULL;
    vloop_timer_t *p_next = NULL;
    uint64_t t_now_ms = 0;

    if (NULL == p_timer_header || NULL == p_timer)
    {
        SDK_LOG(LOG_ERROR, "args is NULL.\n");
        return false;
    }

    // 回调函数不能为空，执行周期必须在(0,VLOOP_TIMER_MAX_PERIOD]
    if (NULL == p_timer->cb
    || p_timer->period <= 0 || p_timer->period > VLOOP_TIMER_MAX_PERIOD)
    {
        SDK_LOG(LOG_ERROR, "args is invalid.\n");
        return false;
    }

    // 若已存在，先从链表中删除
    vloop_timer_del(p_timer_header, p_timer);

    // 计算超时时间，t_timeout禁止用户修改
    t_now_ms = vloop_timer_get_uptime();
    p_timer->timeout = t_now_ms + p_timer->period;

    // 内部定时器链表为空，插入到第一个位置
    if (NULL == p_timer_header->first_node)
    {
        p_timer_header->first_node = p_timer;
        p_timer->next = NULL;
        return true;
    }

    // 超时时间早于第一个内部定时器，插入到第一个位置
    p_cur = p_timer_header->first_node;
    if (p_cur->timeout > p_timer->timeout)
    {
        p_timer_header->first_node = p_timer;
        p_timer->next = p_cur;
        return true;
    }

    // 遍历内部定时器链表，按照超时时间升序插入到正确的位置
    for (p_cur = p_timer_header->first_node; NULL != p_cur; p_cur = p_cur->next)
    {
        p_next = p_cur->next;
        if (NULL == p_next || p_next->timeout > p_timer->timeout)
        {
            p_cur->next = p_timer;
            p_timer->next = p_next;
            return true;
        }
    }

    //不会执行到此
    return false;
}

/**
 * @brief 从链表中删除内部定时器，停止倒计时
 * @param[in] p_timer_header    [内部定时器链表指针]
 * @param[in] p_timer           [内部定时器地址]
 * @return    bool              [成功/失败]
 * @note
 */
bool vloop_timer_del(vloop_timer_header_t *p_timer_header, vloop_timer_t *p_timer)
{
    vloop_timer_t *p_cur = NULL;
    vloop_timer_t *p_next = NULL;

    if (NULL == p_timer_header || NULL == p_timer)
    {
        SDK_LOG(LOG_ERROR, "args is NULL.\n");
        return false;
    }

    // 内部定时器链表已经为空，返回删除成功
    if (NULL == p_timer_header->first_node)
    {
        return true;
    }

    // 当前内部定时器在第一个位置
    p_cur = p_timer_header->first_node;
    if (p_timer == p_cur)
    {
        p_timer_header->first_node = p_cur->next;
        p_timer->timeout = 0;
        p_timer->next = NULL;
        return true;
    }

    // 找到当前内部定时器，并从列表中删除
    for (p_cur = p_timer_header->first_node; NULL != p_cur; p_cur = p_cur->next)
    {
        p_next = p_cur->next;
        if (p_timer == p_next)
        {
            p_cur->next = p_next->next;
            p_timer->timeout = 0;
            p_timer->next = NULL;
            return true;
        }
    }

    return true;
}

/**
 * @brief 获取当前内部定时器还剩多长时间超时
 * @param[in] p_timer_header    [内部定时器链表指针]
 * @param[in] p_timer           [内部定时器地址]
 * @return    uint64_t          [剩余超时时间]
 * @note      返回0时，表示该内部定时器不在链表中，或已经执行过并停止倒计时
 */
uint64_t vloop_timer_remaining(vloop_timer_header_t *p_timer_header, vloop_timer_t *p_timer)
{
    vloop_timer_t *p_cur = NULL;
    uint64_t t_now_ms = 0;

    if (NULL == p_timer_header || NULL == p_timer)
    {
        SDK_LOG(LOG_ERROR, "args is NULL.\n");
        return 0;
    }

    t_now_ms = vloop_timer_get_uptime();

    // 遍历链表找到当前内部定时器
    for (p_cur = p_timer_header->first_node; NULL != p_cur; p_cur = p_cur->next)
    {
        if (p_timer != p_cur)
        {
            continue;
        }

        // 已经超时的内部定时器统一返回0
        if (p_cur->timeout <= t_now_ms)
        {
            return 1;
        }
        else
        {
            return (p_cur->timeout - t_now_ms);
        }
    }

    return 0;
}

/**
 * @brief 执行所有已经超时的内部定时器
 * @param[in] p_timer_header    [内部定时器链表指针]
 * @return    uint64_t          [下一个内部定时器的剩余超时时间]
 * @note      若链表中没有内部定时器等待执行，则返回VESYNC_OS_WAIT_FOREVER
 */
uint64_t vloop_timer_process_expired(vloop_timer_header_t *p_timer_header)
{
    vloop_timer_t *p_header_tmp = NULL;
    vloop_timer_t *p_cur = NULL;
    vloop_timer_t *p_next = NULL;
    uint32_t idx = 0, timeout_count = 0;
    vloop_timer_handler_t p_hander_timeout[VLOOP_MAX_TIMER_ON_LOOP];
    void *p_arg[VLOOP_MAX_TIMER_ON_LOOP];
    uint64_t t_now_ms = 0;

    if (NULL == p_timer_header)
    {
        SDK_LOG(LOG_ERROR, "args is NULL.\n");
        return VESYNC_OS_WAIT_FOREVER;
    }

    // 内部定时器链表为空
    if (NULL == p_timer_header->first_node)
    {
        return VESYNC_OS_WAIT_FOREVER;
    }

    t_now_ms = vloop_timer_get_uptime();
    p_header_tmp = p_timer_header->first_node;

    // 第一个内部定时器还未超时
    if (p_header_tmp->timeout > t_now_ms)
    {
        return (p_header_tmp->timeout - t_now_ms);
    }

    // 遍历链表，执行所有已经超时的内部定时器的回调函数
    memset(p_hander_timeout, 0, sizeof(p_hander_timeout));
    memset(p_arg, 0, sizeof(p_arg));
    for (p_cur = p_timer_header->first_node; NULL != p_cur; p_cur = p_cur->next)
    {
        //p_cur->p_cb(NULL);
        p_hander_timeout[timeout_count] = p_cur->cb;
        p_arg[timeout_count++] = p_cur->arg;

        p_next = p_cur->next;
        if (NULL == p_next || timeout_count >= VLOOP_MAX_TIMER_ON_LOOP
            || p_next->timeout > t_now_ms)
        {
            // 执行完毕，将头部指针后移到未超时的第一个内部定时器
            p_timer_header->first_node = p_cur->next;
            // 置空，截断已经超时的定时器链表
            p_cur->next = NULL;
            break;
        }
    }

    // 遍历所有已经超时的内部定时器，周期执行的重新插入到链表中
    for (p_cur = p_header_tmp; NULL != p_cur; p_cur = p_next)
    {
        p_next = p_cur->next;
        p_cur->next = NULL;
        p_cur->timeout = 0;
        if (true == p_cur->reload)
        {
            vloop_timer_add(p_timer_header, p_cur);
        }
    }

    for (idx = 0; idx < timeout_count; idx++)
    {
        p_hander_timeout[idx](p_arg[idx]);
    }

    // 已经没有定时器
    if (NULL == p_timer_header->first_node)
    {
        return VESYNC_OS_WAIT_FOREVER;
    }

    // 重新获取系统时间，跳过执行回调函数消耗的时间
    t_now_ms = vloop_timer_get_uptime();

    // 处理回调函数的这段时间里已经有新的内部定时器超时，但依然先退出
    p_cur = p_timer_header->first_node;
    if (p_cur->timeout <= t_now_ms)
    {
        return 1;
    }

    // 返回下一个内部定时器的剩余超时时间
    return (p_cur->timeout - t_now_ms);
}

