/**
 *  Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vhal_ota.h
 * @brief       固件OTA接口封装
 * @author      Dongri.Su
 * @date        2021-04-23
 */

#ifndef __VHAL_OTA_H__
#define __VHAL_OTA_H__

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>


#ifdef __cplusplus
extern "C"
{
#endif


/**
 * @brief OTA升级状态
 */
typedef enum
{
    // 状态
    VHAL_OTA_ST_IDLE     = 0,        // 初始状态
    VHAL_OTA_ST_PROCESS,             // 固件下载中
    VHAL_OTA_ST_DL_COMP,             // 固件下载完成
    VHAL_OTA_ST_SUCCESS,             // 升级成功
    //VHAL_OTA_ST_BUSY,

    // 异常错误
    VHAL_OTA_ST_URL_ERR,             // URL错误
    VHAL_OTA_ST_OUT_MEM,             // 内存不足
    VHAL_OTA_ST_TIME_OUT,            // 超时
    VHAL_OTA_ST_FLASH_ERR,           // 查找分区失败或者写flash错误
    VHAL_OTA_ST_HTTP_CONN_FAIL,      // http连接建立失败
    VHAL_OTA_ST_DL_FAIL,             // 下载失败
    VHAL_OTA_ST_FAIL,                // 升级失败(其他原因)
} VHAL_OTA_STATE_E;


/**
 * @brief  固件头部校验回调函数指针
 * @param[in]  p_header         [固件vesync头部]
 * @param[in]  len              [头部长度]
 * @return     int              [0表示校验通过，其他值表示校验失败]
 */
typedef int(*vhal_ota_check_header_cb_t)(uint8_t *p_header, int len);

/**
 * @brief 注册ota升级头部校验回调
 * @param[in]  cb               [ota头部校验回调函数]
 * @return     void
 */
void vhal_ota_check_header_reg_cb(vhal_ota_check_header_cb_t cb, int32_t head_len);

/**
 * @brief  固件md5校验回调函数指针
 * @param[in]  md5              [固件实际md5]
 * @return     int              [0表示校验通过，其他值表示校验失败]
 */
typedef int(*vhal_ota_check_md5_cb_t)(uint8_t *md5);

/**
 * @brief 注册ota升级md5校验回调
 * @param[in]  cb               [ota头部校验回调函数]
 * @return     void
 */
void vhal_ota_check_md5_reg_cb(vhal_ota_check_md5_cb_t cb);

/**
 * @brief  OTA升级状态回调函数指针
 * @param[in]  status           [ota状态]
 * @param[in]  prog             [固件下载进度]
 * @return     void
 */
typedef void(*vhal_ota_status_cb_t)(VHAL_OTA_STATE_E status, uint8_t prog);

/**
 * @brief  注册ota升级状态数据回调
 * @param[in]  cb               [ota升级状态回调函数]
 * @return     void
 */
void vhal_ota_status_reg_cb(vhal_ota_status_cb_t cb);

/*
 * @brief  设置OTA超时标志位
 * @param[in]  flag             [true表示升级超时，false表示未超时]
 * @return     void
 */
void vhal_ota_set_timeout_flag(bool flag);

/**
 * @brief  开始OTA升级
 * @param[in]  p_url            [固件下载URL]
 * @param[in]  dg_flag          [true表示进行降级；false表示进行升级]
 * @return     int              [成功返回0，其他值表示失败]
 */
int vhal_ota_start(char *p_url, bool dg_flag);

/**
 * @brief  保存文件到flash
 * @param[in]  offset           [偏移地址]
 * @param[in]  p_data           [待保存的数据]
 * @param[in]  data_len         [待保存数据的长度]
 * @return     int              [成功返回0，其他值表示失败]
 * @note   用于存放非自身固件的其他大文件
 */
int vhal_ota_save_bin_file(int offset, char *p_data, int data_len);

/**
 * @brief 从flash中读出文件
 * @param[in]  offset           [偏移地址]
 * @param[in]  p_data           [待保存的数据]
 * @param[in]  data_len         [待保存数据的长度]
 * @return     int              [成功返回0，其他值表示失败]
 * @note   用于存放非自身固件的其他大文件
 */
int vhal_ota_read_bin_file(int offset, char *p_data, int data_len);


#ifdef __cplusplus
}
#endif

#endif /* __VHAL_OTA_H__ */
