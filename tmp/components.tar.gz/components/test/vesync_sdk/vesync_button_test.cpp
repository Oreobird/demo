/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_button_test.cpp
 * @brief       vesync button测试用例
 * @author      Joshua
 * @date        2021-12-10
 */

#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <gtest/gtest.h>


#include "vesync_os.h"
#include "vesync_common.h"
#include "vesync_memory.h"
#include "vesync_sem.h"
#include "vesync_button_internal.h"

#include "stub.h" // cpp-stub
#include "vesync_button.c" // cpp-stub needs the source file

static vesync_sem_t *s_sem = NULL;
static uint8_t s_gpio_level = 1;
static BTN_EVENT_E s_ev = EV_NONE_PRESS;

static void press_down_handle(void)
{
    s_ev = EV_PRESS_DOWN;
}

static void press_up_handle(void)
{
    s_ev = EV_PRESS_UP;
}

static void single_click_handle(void)
{
    s_ev = EV_SINGLE_CLICK;
}

static void long_press_hold_handle(void)
{
    s_ev = EV_LONG_PRESS_HOLD;
}

static void double_click_handle(void)
{
    s_ev = EV_DOUBLE_CLICK;
}

static void vhal_gpio_init_mock(vhal_gpio_config_t button_io)
{
    return;
}

static uint8_t vhal_gpio_get_output_mock(void)
{
    return s_gpio_level;
}

static void gpio_mock_task1(void *arg)
{
    s_ev = EV_NONE_PRESS;
    // debounce test
    s_gpio_level = 0;
    vesync_sleep(10);
    s_gpio_level = 1;
    vesync_sleep(10);
    EXPECT_EQ(s_ev, EV_NONE_PRESS);
    s_ev = EV_NONE_PRESS;

    //down test
    s_gpio_level = 0;
    vesync_sleep((DEBOUNCE_TICKS + 1) * TICKS_INTERVAL_MS);
    EXPECT_EQ(s_ev, EV_PRESS_DOWN);
    s_gpio_level = 1;
    s_ev = EV_NONE_PRESS;

    vesync_sem_signal(s_sem);
}

TEST(vesync_button_test, vesync_button_add_once_test)
{
    int ret = SDK_FAIL;

    Stub stub;
    stub.set(vhal_gpio_init, vhal_gpio_init_mock);
    stub.set(vhal_gpio_get_output, vhal_gpio_get_output_mock);

    s_sem = vesync_sem_binary_new();
    EXPECT_TRUE(s_sem);

    ret = vesync_button_init();
    EXPECT_EQ(ret, SDK_OK);

    uint8_t btn_id = 1;
    btn_cfg_t cfg;

    memset(&cfg, 0, sizeof(btn_cfg_t));
    cfg.gpio = btn_id;
    cfg.active_level = ACTIVE_LOW;

    ret = vesync_button_add(&cfg);
    EXPECT_EQ(ret, SDK_OK);

    ret = vesync_button_reg_cb(btn_id, EV_PRESS_DOWN, press_down_handle);
    EXPECT_EQ(ret, SDK_OK);

    ret = vesync_task_new("gpio_mock1", NULL,
                         gpio_mock_task1,
                         NULL,
                         2048,
                         0, NULL);
    EXPECT_EQ(ret, VOS_OK);

    vesync_sem_wait(s_sem, VESYNC_OS_WAIT_FOREVER);
    vesync_sem_free(s_sem);

    ret =vesync_button_del(btn_id);
    EXPECT_EQ(ret, SDK_OK);

    vesync_button_deinit();
}

static void gpio_mock_task2(void *arg)
{
    s_ev = EV_NONE_PRESS;
    s_gpio_level = 0;
    vesync_sleep(100);
    EXPECT_EQ(s_ev, EV_PRESS_DOWN);

    s_gpio_level = 1;
    vesync_sleep(100);
    EXPECT_EQ(s_ev, EV_PRESS_UP);

    vesync_sem_signal(s_sem);
}

TEST(vesync_button_test, vesync_button_add_multi_test)
{
    int ret = SDK_FAIL;

    Stub stub;
    stub.set(vhal_gpio_init, vhal_gpio_init_mock);
    stub.set(vhal_gpio_get_output, vhal_gpio_get_output_mock);

    s_sem = vesync_sem_binary_new();
    EXPECT_TRUE(s_sem);

    ret = vesync_button_init();
    EXPECT_EQ(ret, SDK_OK);

    uint8_t btn_id = 1;
    btn_cfg_t cfg;

    memset(&cfg, 0, sizeof(btn_cfg_t));
    cfg.gpio = btn_id;
    cfg.active_level = ACTIVE_LOW;

    ret = vesync_button_add(&cfg);
    EXPECT_EQ(ret, SDK_OK);

    ret = vesync_button_reg_cb(btn_id, EV_PRESS_DOWN, press_down_handle);
    EXPECT_EQ(ret, SDK_OK);

    uint8_t btn_id2 = 2;
    cfg.gpio = btn_id2;
    ret = vesync_button_add(&cfg);
    EXPECT_EQ(ret, SDK_OK);

    ret = vesync_button_reg_cb(btn_id2, EV_PRESS_UP, press_up_handle);
    EXPECT_EQ(ret, SDK_OK);

    ret = vesync_task_new("gpio_mock2", NULL,
                         gpio_mock_task2,
                         NULL,
                         2048,
                         0, NULL);
    EXPECT_EQ(ret, VOS_OK);

    vesync_sem_wait(s_sem, VESYNC_OS_WAIT_FOREVER);
    vesync_sem_free(s_sem);

    ret = vesync_button_del(btn_id);
    EXPECT_EQ(ret, SDK_OK);

    ret = vesync_button_del(btn_id2);
    EXPECT_EQ(ret, SDK_OK);

    vesync_button_deinit();
}

static void gpio_mock_task3(void *arg)
{
    s_ev = EV_NONE_PRESS;

    // long press test
    s_gpio_level = 0;
    vesync_sleep(1000);
    EXPECT_EQ(s_ev, EV_LONG_PRESS_HOLD);
    s_ev = EV_NONE_PRESS;
    s_gpio_level = 1;
    vesync_sleep((DEBOUNCE_TICKS + SHORT_PRESS_THRESHOLD_TICKS + 1) * TICKS_INTERVAL_MS);

    // single click test
    s_gpio_level = 0;
    vesync_sleep((DEBOUNCE_TICKS + SHORT_PRESS_THRESHOLD_TICKS + 1) * TICKS_INTERVAL_MS);
    s_gpio_level = 1;
    vesync_sleep((2*DEBOUNCE_TICKS + SHORT_PRESS_THRESHOLD_TICKS + 1) * TICKS_INTERVAL_MS);
    EXPECT_EQ(s_ev, EV_SINGLE_CLICK);
    s_ev = EV_NONE_PRESS;

    vesync_sem_signal(s_sem);
}

TEST(vesync_button_test, vesync_button_ev_cb_test1)
{
    int ret = SDK_FAIL;

    Stub stub;
    stub.set(vhal_gpio_init, vhal_gpio_init_mock);
    stub.set(vhal_gpio_get_output, vhal_gpio_get_output_mock);

    s_sem = vesync_sem_binary_new();
    EXPECT_TRUE(s_sem);

    ret = vesync_button_init();
    EXPECT_EQ(ret, SDK_OK);

    uint8_t btn_id = 1;
    btn_cfg_t cfg;

    memset(&cfg, 0, sizeof(btn_cfg_t));
    cfg.gpio = btn_id;
    cfg.active_level = ACTIVE_LOW;

    ret = vesync_button_add(&cfg);
    EXPECT_EQ(ret, SDK_OK);

    btn_ev_cb_t ev_cb_tbl[] = {
        {EV_SINGLE_CLICK, single_click_handle},
        {EV_LONG_PRESS_HOLD, long_press_hold_handle}
    };

    ret = vesync_button_reg_cb_arr(btn_id, ev_cb_tbl, SIZEOF_ARRAY(ev_cb_tbl));
    EXPECT_EQ(ret, SDK_OK);

    ret = vesync_task_new("gpio_mock3", NULL,
                             gpio_mock_task3,
                             NULL,
                             2048,
                             0, NULL);
    EXPECT_EQ(ret, VOS_OK);

    vesync_sem_wait(s_sem, VESYNC_OS_WAIT_FOREVER);
    vesync_sem_free(s_sem);

    ret = vesync_button_del(btn_id);
    EXPECT_EQ(ret, SDK_OK);

    vesync_button_deinit();
}

static void gpio_mock_task4(void *arg)
{
    s_ev = EV_NONE_PRESS;
    // double click test
    for (int i = 0; i < 2; i++)
    {
        s_gpio_level = 0;
        vesync_sleep((DEBOUNCE_TICKS + 1) * TICKS_INTERVAL_MS);
        s_gpio_level = 1;
        vesync_sleep((DEBOUNCE_TICKS + 1) * TICKS_INTERVAL_MS);
    }
    vesync_sleep((SHORT_PRESS_THRESHOLD_TICKS * 2) * TICKS_INTERVAL_MS);
    EXPECT_EQ(s_ev, EV_DOUBLE_CLICK);
    s_ev = EV_NONE_PRESS;

    vesync_sem_signal(s_sem);
}

TEST(vesync_button_test, vesync_button_ev_cb_test2)
{
    int ret = SDK_FAIL;

    Stub stub;
    stub.set(vhal_gpio_init, vhal_gpio_init_mock);
    stub.set(vhal_gpio_get_output, vhal_gpio_get_output_mock);

    s_sem = vesync_sem_binary_new();
    EXPECT_TRUE(s_sem);

    ret = vesync_button_init();
    EXPECT_EQ(ret, SDK_OK);

    uint8_t btn_id = 1;
    btn_cfg_t cfg;

    memset(&cfg, 0, sizeof(btn_cfg_t));
    cfg.gpio = btn_id;
    cfg.active_level = ACTIVE_LOW;
    cfg.long_press_cb_interval_ms = 1000;

    ret = vesync_button_add(&cfg);
    EXPECT_EQ(ret, SDK_OK);


    ret = vesync_button_reg_cb(btn_id, EV_DOUBLE_CLICK, double_click_handle);
    EXPECT_EQ(ret, SDK_OK);


    ret = vesync_task_new("gpio_mock4", NULL,
                             gpio_mock_task4,
                             NULL,
                             2048,
                             0, NULL);
    EXPECT_EQ(ret, VOS_OK);

    vesync_sem_wait(s_sem, VESYNC_OS_WAIT_FOREVER);
    vesync_sem_free(s_sem);

    ret = vesync_button_del(btn_id);
    EXPECT_EQ(ret, SDK_OK);

    vesync_button_deinit();
}

