/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
 * @file        vdrv_buzzer.c
 * @brief       蜂鸣器驱动
 * @author      Joshua
 * @date        2021-09-13
 */

#include "vdrv_buzzer.h"
#include "vhal_led.h"

#define BUZZER_PWM_CHANNEL              LED_CH0
#define BUZZER_FREQ                     3000

#define BUZZER_DUTY_RES                 LED_DUTY_RST_10_BIT
#define BUZZER_DUTY                     512

#define BUZZER_GPIO                     16

vhal_led_gpio_cfg_t s_led_gpio_cfg;
vhal_led_timer_cfg_t s_led_timer_cfg;


/**
 * @brief 开启蜂鸣器
 */
void vdrv_buzzer_on(void)
{
    vhal_led_set_duty_bits(BUZZER_PWM_CHANNEL, BUZZER_DUTY);
}


/**
 * @brief 关闭蜂鸣器
 */
void vdrv_buzzer_off(void)
{
    vhal_led_set_duty_bits(BUZZER_PWM_CHANNEL, 0);
}


/**
 * @brief 初始化蜂鸣器
 */
void vdrv_buzzer_init(void)
{
    s_led_gpio_cfg.gpio_num = BUZZER_GPIO;
    s_led_gpio_cfg.channel = BUZZER_PWM_CHANNEL;
    s_led_gpio_cfg.duty = 0;
    vhal_led_gpio_cfg(1, &s_led_gpio_cfg);

    s_led_timer_cfg.duty_resolution = BUZZER_DUTY_RES;
    s_led_timer_cfg.freq_hz = BUZZER_FREQ;
    vhal_led_timer_cfg(&s_led_timer_cfg);
}

/**
 * @brief 改变蜂鸣器的频率
 * @param[in]  freq_hz          [频率值]
 */
void vdrv_buzzer_freq_change(uint32_t freq_hz)
{
    vdrv_buzzer_off();

    s_led_timer_cfg.freq_hz = freq_hz;
    vhal_led_set_freq(s_led_timer_cfg);

    vdrv_buzzer_on();
}

