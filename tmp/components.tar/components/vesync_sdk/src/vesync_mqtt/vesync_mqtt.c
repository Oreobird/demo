/*
 * Copyright © Vesync Technologies Co.Ltd. 2019-2021. All rights reserved.
 *
 * This file is subject to the terms and conditions defined in
 * file 'LICENSE', which is part of this source code package.
 * Tuan PM <tuanpm at live dot com>
 */


#include <stdint.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#include "mbedtls/platform.h"

#include "vesync_task.h"
#include "vesync_memory.h"
#include "sdkconfig.h"
#include "vhal_utils.h"
//#include "vesync_sntp.h"

#include "mqtt_util.h"
#include "mqtt_msg.h"
#include "mqtt_outbox.h"
#include "transport_ssl.h"
#include "vesync_mqtt_private.h"


static int vesync_mqtt_dispatch_event(vesync_mqtt_client_handle_t client);
static int vesync_mqtt_dispatch_event_with_msgid(vesync_mqtt_client_handle_t client, uint32_t transport_message_offset);
static int vesync_mqtt_destroy_config(vesync_mqtt_client_handle_t client);
static int vesync_mqtt_connect(vesync_mqtt_client_handle_t client, int timeout_ms);
static int vesync_mqtt_abort_connection(vesync_mqtt_client_handle_t client);
static int vesync_mqtt_client_ping(vesync_mqtt_client_handle_t client);
static char *create_string(const char *ptr, int len);


#if defined(CONFIG_IDF_TARGET_BL602)
static char* mqtt_strdup(const char* str)
{
      int len;
      char* copy;

      len = strlen(str) + 1;
      if (!(copy = (char*)vesync_malloc(len))) return 0;
      memcpy(copy,str,len);
      return copy;
}
#else
#define mqtt_strdup strdup
#endif

/**
* @brief       Destroys and frees config of client
* @param[in]   client               [client handle]
* @return      int                  [success or fail]
*/
static int vesync_mqtt_destroy_config(vesync_mqtt_client_handle_t client)
{
    mqtt_config_storage_t *cfg = NULL;

    MQTT_UTIL_MEM_CHECK(client, return VERR_OK);

    MQTT_UTIL_SAFE_FREE(client->connect_info.will_topic);
    MQTT_UTIL_SAFE_FREE(client->connect_info.will_message);
    MQTT_UTIL_SAFE_FREE(client->connect_info.client_id);
    MQTT_UTIL_SAFE_FREE(client->connect_info.username);
    MQTT_UTIL_SAFE_FREE(client->connect_info.password);
    memset(&client->connect_info, 0, sizeof(mqtt_connect_info_t));

    cfg = client->config;
    MQTT_UTIL_MEM_CHECK(cfg, return VERR_OK);

    MQTT_UTIL_SAFE_FREE(cfg->host);
    MQTT_UTIL_SAFE_FREE(cfg->uri);
    MQTT_UTIL_SAFE_FREE(cfg->path);
    MQTT_UTIL_SAFE_FREE(cfg->scheme);
    memset(cfg, 0, sizeof(mqtt_config_storage_t));
    MQTT_UTIL_SAFE_FREE(client->config);

    return VERR_OK;
}

/**
* @brief       Establishes a mqtt connection
* @param[in]   client               [client handle]
* @param[in]   timeout_ms
* @return      int                  [success or fail]
*/
static int vesync_mqtt_connect(vesync_mqtt_client_handle_t client, int timeout_ms)
{
    int write_len, read_len, connect_rsp_code;

    MQTT_UTIL_MEM_CHECK(client, return VERR_FAIL);

    client->wait_for_ping_resp = false;
    mqtt_msg_init(&client->mqtt_state.mqtt_connection,
                  client->mqtt_state.out_buffer,
                  client->mqtt_state.out_buffer_length);
    client->mqtt_state.outbound_message = mqtt_msg_connect(&client->mqtt_state.mqtt_connection,
                                          client->mqtt_state.connect_info);
    client->mqtt_state.pending_msg_type = mqtt_get_type(client->mqtt_state.outbound_message->data);
    client->mqtt_state.pending_msg_id = mqtt_get_id(client->mqtt_state.outbound_message->data,
                                        client->mqtt_state.outbound_message->length);
    MQTT_LOG(LOG_INFO, "Sending MQTT CONNECT message, type: %d, id: %04X\n",
             client->mqtt_state.pending_msg_type,
             client->mqtt_state.pending_msg_id);

    write_len = client->transport->_write(client->transport,
                                (char *)client->mqtt_state.outbound_message->data,
                                client->mqtt_state.outbound_message->length,
                                client->config->network_timeout_ms);
    if (write_len < 0)
    {
        MQTT_LOG(LOG_ERROR, "Writing failed, errno= %d\n", errno);
        MQTT_LOG_ERROR("Writing failed, ret=%d, errno=%d.", write_len, errno);
        VERR_UPLOAD(VERR_MQTT_CONNECT_FAIL, errno);
        return VERR_FAIL;
    }

    /* wait configured network timeout for broker connection response */
    uint64_t connack_recv_started = mqtt_util_tick_get_ms();
    do
    {
        read_len = client->transport->_read(client->transport,
                              (char *)client->mqtt_state.in_buffer,
                              client->mqtt_state.in_buffer_length,
                              client->config->network_timeout_ms);
    } while (0 == read_len && mqtt_util_tick_get_ms() - connack_recv_started < client->config->network_timeout_ms);
    if (read_len < 0)
    {
        MQTT_LOG(LOG_ERROR, "Error network response\n");
        MQTT_LOG_ERROR("Read error or timeout: ret=%d, errno=%d\n", read_len, errno);
        VERR_UPLOAD(VERR_MQTT_CONNECT_FAIL, errno);
        return VERR_FAIL;
    }
    if (mqtt_get_type(client->mqtt_state.in_buffer) != MQTT_MSG_TYPE_CONNACK)
    {
        MQTT_LOG(LOG_ERROR, "Invalid MSG_TYPE response: %d, read_len: %d\n", mqtt_get_type(client->mqtt_state.in_buffer), read_len);
        MQTT_LOG_ERROR("Invalid MSG_TYPE response: %d, read_len: %d\n", mqtt_get_type(client->mqtt_state.in_buffer), read_len);
        VERR_UPLOAD(VERR_MQTT_CONNECT_FAIL, mqtt_get_type(client->mqtt_state.in_buffer));
        return VERR_FAIL;
    }
    connect_rsp_code = mqtt_get_connect_return_code(client->mqtt_state.in_buffer);
    switch (connect_rsp_code)
    {
        case CONNECTION_ACCEPTED:
            MQTT_LOG(LOG_DEBUG, "Connected\n");
            return VERR_OK;
        case CONNECTION_REFUSE_PROTOCOL:
            MQTT_LOG(LOG_WARN, "Connection refused, bad protocol\n");
            MQTT_LOG_ERROR("Connection refused, bad protocol");
            VERR_UPLOAD(VERR_MQTT_CONNECT_FAIL, CONNECTION_REFUSE_PROTOCOL);
            return VERR_FAIL;
        case CONNECTION_REFUSE_SERVER_UNAVAILABLE:
            MQTT_LOG(LOG_WARN, "Connection refused, server unavailable\n");
            MQTT_LOG_ERROR("Connection refused, server unavailable");
            VERR_UPLOAD(VERR_MQTT_CONNECT_FAIL, CONNECTION_REFUSE_SERVER_UNAVAILABLE);
            return VERR_FAIL;
        case CONNECTION_REFUSE_BAD_USERNAME:
            MQTT_LOG(LOG_WARN, "Connection refused, bad username or password\n");
            MQTT_LOG_ERROR("Connection refused, bad username or password");
            VERR_UPLOAD(VERR_MQTT_CONNECT_FAIL, CONNECTION_REFUSE_BAD_USERNAME);
            return VERR_FAIL;
        case CONNECTION_REFUSE_NOT_AUTHORIZED:
            MQTT_LOG(LOG_WARN, "Connection refused, not authorized\n");
            MQTT_LOG_ERROR("Connection refused, not authorized");
            VERR_UPLOAD(VERR_MQTT_CONNECT_FAIL, CONNECTION_REFUSE_NOT_AUTHORIZED);
            return VERR_FAIL;
        default:
            MQTT_LOG(LOG_WARN, "Connection refused, Unknow reason\n");
            MQTT_LOG_ERROR("Connection refused, Unknow reason");
            VERR_UPLOAD(VERR_MQTT_CONNECT_FAIL, -1);
            return VERR_FAIL;
    }
    return VERR_OK;
}

/**
* @brief       Aborts mqtt connection
* @param[in]   client               [client handle]
* @return      int                  [success or fail]
*/
static int vesync_mqtt_abort_connection(vesync_mqtt_client_handle_t client)
{
    MQTT_UTIL_MEM_CHECK(client, return VERR_FAIL);

    MQTT_API_LOCK(client);

#ifdef MQTT_LOG_ENABLE
    /* inform mqtt connect error to event handler */
    client->event.data = (char*)mqtt_log_get_err_msg();
    client->event.total_data_len = client->event.data_len = strlen(client->event.data);
#endif

    client->transport->_close(client->transport);
    if (MQTT_RECONNECT_TIMEOUT_MS_MAX > client->wait_timeout_ms)
    {
        client->wait_timeout_ms += MQTT_RECONNECT_TIMEOUT_MS_STEP;
    }
    else
    {
        client->wait_timeout_ms = MQTT_RECONNECT_TIMEOUT_MS_MAX;
    }
    client->reconnect_tick = mqtt_util_tick_get_ms();
    client->state = MQTT_STATE_WAIT_TIMEOUT;
    MQTT_LOG(LOG_DEBUG, "Reconnect after %d ms\n", client->wait_timeout_ms);
    client->event.event_id = MQTT_EVENT_DISCONNECTED;
    client->wait_for_ping_resp = false;
    vesync_mqtt_dispatch_event_with_msgid(client, 0);

    MQTT_API_UNLOCK(client);

    return VERR_OK;
}

/**
* @brief       create new string according to old string or character array
* @param[in]   ptr                  [point to string or character array]
* @param[in]   len                  [length of string or character array]
* @return      char*                [created string]
*/
static char *create_string(const char *ptr, int len)
{
    char *p_str = NULL;
    if (len <= 0 || NULL == ptr)
    {
        return NULL;
    }

    p_str = vesync_calloc(1, len + 1);
    MQTT_UTIL_MEM_CHECK(
        p_str,
        do
        {
            VERR_UPLOAD(VERR_LINK_MOD_COM(VERR_MEM_ALLOC_FAIL), vhal_get_free_heap_size());
            return NULL;
        }
        while (0));
    memcpy(p_str, ptr, len);

    return p_str;
}

/**
* @brief       Writes data into trnasport
* @param[in]   client               [client handle]
* @return      int                  [success or fail]
*/
static int mqtt_write_data(vesync_mqtt_client_handle_t client)
{
    MQTT_UTIL_MEM_CHECK(client, return VERR_FAIL);

    int write_len = client->transport->_write(client->transport,
                                    (char *)client->mqtt_state.outbound_message->data,
                                    client->mqtt_state.outbound_message->length,
                                    client->config->network_timeout_ms);
    // client->mqtt_state.pending_msg_type = mqtt_get_type(client->mqtt_state.outbound_message->data);
    if (write_len <= 0)
    {
        MQTT_LOG(LOG_ERROR, "Error write data or timeout, written len = %d\n", write_len);
        MQTT_LOG_ERROR("write error, ret=%d, errno=%d.", write_len, errno);
        VERR_UPLOAD(VERR_MQTT_SEND_DATA_FAIL, errno);
        return VERR_FAIL;
    }
    /* we've just sent a mqtt control packet, update keepalive counter
     * [MQTT-3.1.2-23]
     */
    client->keepalive_tick = mqtt_util_tick_get_ms();
    return VERR_OK;
}

/**
* @brief       Dispatches mqtt event to application layer
* @param[in]   client               [client handle]
* @return      int                  [success or fail]
*/
static int vesync_mqtt_dispatch_event(vesync_mqtt_client_handle_t client)
{
    MQTT_UTIL_MEM_CHECK(client, return VERR_FAIL);

    client->event.user_context = client->config->user_context;
    client->event.client = client;

    if (client->config->event_handle)
    {
        return client->config->event_handle(&client->event);
    }
    return VERR_FAIL;
}

/**
* @brief       Dispatches mqtt event with id to application layer
* @param[in]   client               [client handle]
* @param[in]   transport_message_offset
* @return      int                  [success or fail]
*/
static int vesync_mqtt_dispatch_event_with_msgid(vesync_mqtt_client_handle_t client, uint32_t transport_message_offset)
{
    MQTT_UTIL_MEM_CHECK(client, return VERR_FAIL);

    //client->event.msg_id = mqtt_get_id(client->mqtt_state.in_buffer, client->mqtt_state.in_buffer_length);
    client->event.msg_id = mqtt_get_id(client->mqtt_state.in_buffer + transport_message_offset, client->mqtt_state.in_buffer_length - transport_message_offset);
    return vesync_mqtt_dispatch_event(client);
}

/**
* @brief       Delivers published message to application layer
* @param[in]   client               [client handle]
* @param[in]   message              [point to message]
* @param[in]   length               [length of message]
*/
static void deliver_publish(vesync_mqtt_client_handle_t client, uint8_t *message, int length)
{
    const char *mqtt_topic = NULL, *mqtt_data = NULL;
    uint32_t mqtt_topic_length, mqtt_data_length;
    uint32_t mqtt_len = 0, mqtt_offset = 0, total_mqtt_len = 0;
    int len_read= length;
    int buffer_offset = 0;

    MQTT_UTIL_MEM_CHECK(client, return);
    MQTT_UTIL_MEM_CHECK(message, return);

    int max_to_read = client->mqtt_state.in_buffer_length;
    vesync_transport_handle_t transport = client->transport;;

    do
    {
        if (0 == total_mqtt_len)
        {
            /* any further reading only the underlying payload */
            /*
            * By default, the underlying transport layer handle is the handle itself
            */
            /*transport = esp_transport_get_payload_transport_handle(transport);*/
            mqtt_data_length = mqtt_topic_length = length;
            if (NULL == (mqtt_topic = mqtt_get_publish_topic(message, &mqtt_topic_length)) ||
                NULL == (mqtt_data = mqtt_get_publish_data(message, &mqtt_data_length)))
            {
                // mqtt header is not complete, continue reading
                memmove(client->mqtt_state.in_buffer, message, length);
                buffer_offset = length;
                message = client->mqtt_state.in_buffer;
                max_to_read = client->mqtt_state.in_buffer_length - length;
                mqtt_len = 0;
            }
            else
            {
                total_mqtt_len = client->mqtt_state.message_length - client->mqtt_state.message_length_read + mqtt_data_length;
                mqtt_len = mqtt_data_length;
                if (client->mqtt_state.message_length_read < client->mqtt_state.message_length)
                {
                    /* if message is framented -> correct the size for the first DATA event */
                    mqtt_data_length = client->mqtt_state.message_length_read - ((uint8_t*)mqtt_data- message);
                }
                /* read msg id only once */
                client->event.msg_id = mqtt_get_id(client->mqtt_state.in_buffer, client->mqtt_state.in_buffer_length);
            }
        }
        else
        {
            mqtt_len = len_read;
            mqtt_data = (const char*)client->mqtt_state.in_buffer;
            mqtt_topic = NULL;
            mqtt_topic_length = 0;
        }

        if (total_mqtt_len != 0)
        {
            MQTT_LOG(LOG_DEBUG, "Get data len = %d, topic len = %d\n", mqtt_len, mqtt_topic_length);
            client->event.event_id = MQTT_EVENT_DATA;
            client->event.data = (char *)mqtt_data;
            client->event.data_len = mqtt_len;
            client->event.total_data_len = total_mqtt_len;
            client->event.current_data_offset = mqtt_offset;
            client->event.topic = (char *)mqtt_topic;
            client->event.topic_len = mqtt_topic_length;
            vesync_mqtt_dispatch_event(client);
        }

        mqtt_offset += mqtt_len;
        if (client->mqtt_state.message_length_read >= client->mqtt_state.message_length)
        {
            break;
        }

        len_read = client->transport->_read(transport,
                                  (char *)client->mqtt_state.in_buffer + buffer_offset,
                                  client->mqtt_state.message_length - client->mqtt_state.message_length_read > max_to_read ?
                                  max_to_read : client->mqtt_state.message_length - client->mqtt_state.message_length_read,
                                  client->config->network_timeout_ms);
        length = len_read + buffer_offset;
        buffer_offset = 0;
        max_to_read = client->mqtt_state.in_buffer_length;
        if (len_read <= 0)
        {
            MQTT_LOG(LOG_ERROR, "Read error or timeout: len_read = %d, errno = %d\n", len_read, errno);
            VERR_UPLOAD(VERR_MQTT_RECV_DATA_FAIL, errno);
            break;
        }
        client->mqtt_state.message_length_read += len_read;
    } while (1);

}

/**
* @brief       Identifies whether it is a valid message according to the message type and ID
* @param[in]   client               [client handle]
* @param[in]   msg_type             [message type]
* @param[in]   msg_id               [message id]
* @return      bool                 [true - valid; false - invalid]
*/
static bool is_valid_mqtt_msg(vesync_mqtt_client_handle_t client, int msg_type, int msg_id)
{
    MQTT_UTIL_MEM_CHECK(client, return false);

    MQTT_LOG(LOG_DEBUG, "pending_id = %d, pending_msg_count = %d\n", client->mqtt_state.pending_msg_id, client->mqtt_state.pending_msg_count);
    if (0 == client->mqtt_state.pending_msg_count)
    {
        return false;
    }
    if (VERR_OK == outbox_delete(client->outbox, msg_id, msg_type))
    {
        client->mqtt_state.pending_msg_count--;
        return true;
    }

    return false;
}

/**
* @brief       move pending msg into queue when oversized
* @param[in]   client               [client handle]
* @param[in]   remaining_data       [point to remaining data]
* @param[in]   remaining_len        [length of remaining data]
* @return      int                  [success or fail]
*/
static void mqtt_enqueue_oversized(vesync_mqtt_client_handle_t client, uint8_t *remaining_data, int remaining_len)
{
    MQTT_UTIL_MEM_CHECK(client, return);

    MQTT_LOG(LOG_DEBUG, "mqtt_enqueue_oversized id: %d, type=%d, pending_msg_count=%d\n",
             client->mqtt_state.pending_msg_id, client->mqtt_state.pending_msg_type, client->mqtt_state.pending_msg_count);

    //lock mutex
    outbox_message_t msg = { 0 };
    msg.data = client->mqtt_state.outbound_message->data;
    msg.len =  client->mqtt_state.outbound_message->length;
    msg.msg_id = client->mqtt_state.pending_msg_id;
    msg.msg_type = client->mqtt_state.pending_msg_type;
    msg.msg_qos = client->mqtt_state.pending_publish_qos;
    msg.remaining_data = remaining_data;
    msg.remaining_len = remaining_len;
    //Copy to queue buffer
    outbox_enqueue(client->outbox, &msg, mqtt_util_tick_get_ms());

    //unlock
}

/**
* @brief       move pending msg into queue
* @param[in]   client               [client handle]
* @return      int                  [success or fail]
*/
static void mqtt_enqueue(vesync_mqtt_client_handle_t client)
{
    MQTT_UTIL_MEM_CHECK(client, return);

    MQTT_LOG(LOG_DEBUG, "mqtt_enqueue id: %d, type=%d, pending_msg_count=%d\n",
             client->mqtt_state.pending_msg_id, client->mqtt_state.pending_msg_type, client->mqtt_state.pending_msg_count);

    //lock mutex
    if (client->mqtt_state.pending_msg_count > 0)
    {
        outbox_message_t msg = { 0 };
        msg.data = client->mqtt_state.outbound_message->data;
        msg.len =  client->mqtt_state.outbound_message->length;
        msg.msg_id = client->mqtt_state.pending_msg_id;
        msg.msg_type = client->mqtt_state.pending_msg_type;
        msg.msg_qos = client->mqtt_state.pending_publish_qos;
        //Copy to queue buffer
        outbox_enqueue(client->outbox, &msg, mqtt_util_tick_get_ms());
    }
    //unlock
}

/**
 * @brief       process mqtt received message
 * @param[in]   client               [client handle]
 * @return      int                  [success or fail]
 */
static int mqtt_process_receive(vesync_mqtt_client_handle_t client)
{
    int read_len;
    uint8_t msg_type;
    uint8_t msg_qos;
    uint16_t msg_id;
    uint32_t transport_message_offset = 0 ;

    MQTT_UTIL_MEM_CHECK(client, return VERR_FAIL);

    read_len = client->transport->_read(client->transport, (char *)client->mqtt_state.in_buffer, client->mqtt_state.in_buffer_length, 0);
    if (read_len < 0)
    {
        MQTT_LOG(LOG_ERROR, "Read error or end of stream errno=%d.\n", errno);
        MQTT_LOG_ERROR("Read error or end of stream: ret=%d, errno=%d.", read_len, errno);
        VERR_UPLOAD(VERR_MQTT_RECV_DATA_FAIL, errno);
        return VERR_FAIL;
    }

    if (0 == read_len)
    {
        return VERR_OK;
    }

    // In case of fragmented packet (when receiving a large publish message), the deliver_publish function will read the rest of the message with more transport read, which means the MQTT message length will be greater than the initial transport read length. That explains that the stopping condition is not the equality here
    while ( transport_message_offset < read_len )
    {
    // If the message was valid, get the type, quality of service and id of the message
        msg_type = mqtt_get_type(&client->mqtt_state.in_buffer[transport_message_offset]);
        msg_qos = mqtt_get_qos(&client->mqtt_state.in_buffer[transport_message_offset]);
        msg_id = mqtt_get_id(&client->mqtt_state.in_buffer[transport_message_offset], read_len - transport_message_offset);
        MQTT_LOG(LOG_DEBUG, "msg_type=%d, msg_id=%d\n", msg_type, msg_id);

        switch (msg_type)
        {
            case MQTT_MSG_TYPE_SUBACK:
                if (is_valid_mqtt_msg(client, MQTT_MSG_TYPE_SUBSCRIBE, msg_id))
                {
                    MQTT_LOG(LOG_DEBUG, "Subscribe successful\n");
                    client->event.event_id = MQTT_EVENT_SUBSCRIBED;
                    vesync_mqtt_dispatch_event_with_msgid(client, transport_message_offset);
                }
                break;
            case MQTT_MSG_TYPE_UNSUBACK:
                if (is_valid_mqtt_msg(client, MQTT_MSG_TYPE_UNSUBSCRIBE, msg_id))
                {
                    MQTT_LOG(LOG_DEBUG, "UnSubscribe successful\n");
                    client->event.event_id = MQTT_EVENT_UNSUBSCRIBED;
                    vesync_mqtt_dispatch_event_with_msgid(client, transport_message_offset);
                }
                break;
            case MQTT_MSG_TYPE_PUBLISH:
                if (1 == msg_qos)
                {
                    client->mqtt_state.outbound_message = mqtt_msg_puback(&client->mqtt_state.mqtt_connection, msg_id);
                }
                else if (2 == msg_qos)
                {
                    client->mqtt_state.outbound_message = mqtt_msg_pubrec(&client->mqtt_state.mqtt_connection, msg_id);
                }

                if (1 == msg_qos || 2 == msg_qos)
                {
                    MQTT_LOG(LOG_DEBUG, "Queue response QoS: %d\n", msg_qos);

                    if (mqtt_write_data(client) != VERR_OK)
                    {
                        MQTT_LOG(LOG_ERROR, "Error write qos msg repsonse, qos = %d\n", msg_qos);
                        // TODO: Shoule reconnect?
                        // return VERR_FAIL;
                    }
                }

                // Deliver the publish message
                client->mqtt_state.message_length_read = read_len - transport_message_offset;
                client->mqtt_state.message_length = mqtt_get_total_length(&client->mqtt_state.in_buffer[transport_message_offset], client->mqtt_state.message_length_read);
                MQTT_LOG(LOG_DEBUG, "deliver_publish, message_length_read=%d, message_length=%d\n", read_len, client->mqtt_state.message_length);
                deliver_publish(client, &client->mqtt_state.in_buffer[transport_message_offset], client->mqtt_state.message_length_read);
                break;
            case MQTT_MSG_TYPE_PUBACK:
                if (is_valid_mqtt_msg(client, MQTT_MSG_TYPE_PUBLISH, msg_id))
                {
                    MQTT_LOG(LOG_DEBUG, "received MQTT_MSG_TYPE_PUBACK, finish QoS1 publish\n");
                    outbox_set_pending(client->outbox, msg_id, CONFIRMED);
                    client->event.event_id = MQTT_EVENT_PUBLISHED;
                    vesync_mqtt_dispatch_event_with_msgid(client, transport_message_offset);
                }
                break;
            case MQTT_MSG_TYPE_PUBREC:
                MQTT_LOG(LOG_DEBUG, "received MQTT_MSG_TYPE_PUBREC\n");
                client->mqtt_state.outbound_message = mqtt_msg_pubrel(&client->mqtt_state.mqtt_connection, msg_id);
                outbox_set_pending(client->outbox, msg_id, ACKNOWLEDGED);
                mqtt_write_data(client);
                break;
            case MQTT_MSG_TYPE_PUBREL:
                MQTT_LOG(LOG_DEBUG, "received MQTT_MSG_TYPE_PUBREL\n");
                client->mqtt_state.outbound_message = mqtt_msg_pubcomp(&client->mqtt_state.mqtt_connection, msg_id);
                mqtt_write_data(client);
                break;
            case MQTT_MSG_TYPE_PUBCOMP:
                MQTT_LOG(LOG_DEBUG, "received MQTT_MSG_TYPE_PUBCOMP\n");
                if (is_valid_mqtt_msg(client, MQTT_MSG_TYPE_PUBLISH, msg_id))
                {
                    MQTT_LOG(LOG_DEBUG, "Receive MQTT_MSG_TYPE_PUBCOMP, finish QoS2 publish\n");
                    outbox_set_pending(client->outbox, msg_id, CONFIRMED);
                    client->event.event_id = MQTT_EVENT_PUBLISHED;
                    vesync_mqtt_dispatch_event_with_msgid(client, transport_message_offset);
                }
                break;
            case MQTT_MSG_TYPE_PINGRESP:
                MQTT_LOG(LOG_DEBUG, "MQTT_MSG_TYPE_PINGRESP\n");
                client->wait_for_ping_resp = false;
                break;
        }

        transport_message_offset += mqtt_get_total_length(&client->mqtt_state.in_buffer[transport_message_offset], read_len - transport_message_offset) ;
    }

    return VERR_OK;
}

/**
 * @brief       resend mqtt messages in queue
 * @param[in]   client               [client handle]
 * @param[in]   item                 [item handle]
 * @return      int                  [success or fail]
 */
static int mqtt_resend_queued(vesync_mqtt_client_handle_t client, outbox_item_handle_t item)
{
    if (NULL == client || NULL == item)
    {
        MQTT_LOG(LOG_ERROR, "null parameter\n");
        return VERR_FAIL;
    }

    // decode queued data
    client->mqtt_state.outbound_message->data = outbox_item_get_data(item, (size_t *)&client->mqtt_state.outbound_message->length, &client->mqtt_state.pending_msg_id,
            &client->mqtt_state.pending_msg_type, &client->mqtt_state.pending_publish_qos);
    // set duplicate flag for QoS-1 and QoS-2 messages
    if (client->mqtt_state.pending_msg_type == MQTT_MSG_TYPE_PUBLISH && client->mqtt_state.pending_publish_qos > MQTT_QOS0)
    {
        mqtt_set_dup(client->mqtt_state.outbound_message->data);
    }

    MQTT_LOG(LOG_DEBUG, "resend msg:id=%d, type=%d, qos=%d, len=%d \n", client->mqtt_state.pending_msg_id, client->mqtt_state.pending_msg_type, \
                                                                client->mqtt_state.pending_publish_qos, client->mqtt_state.outbound_message->length);

    // try to resend the data
    if (mqtt_write_data(client) != VERR_OK)
    {
        MQTT_LOG(LOG_ERROR, "Error to resend data ");
        vesync_mqtt_abort_connection(client);
        return VERR_FAIL;
    }
    return VERR_OK;
}

/**
 * @brief       send mqtt ping
 * @param[in]   client               [client handle]
 * @return      int                  [success or fail]
 */
static int vesync_mqtt_client_ping(vesync_mqtt_client_handle_t client)
{
    MQTT_UTIL_MEM_CHECK(client, return VERR_FAIL);

    client->mqtt_state.outbound_message = mqtt_msg_pingreq(&client->mqtt_state.mqtt_connection);
    if (client->mqtt_state.outbound_message->length == 0)
    {
        MQTT_LOG(LOG_ERROR, "Ping message cannot be created");
        return VERR_FAIL;
    }

    if (mqtt_write_data(client) != VERR_OK)
    {
        MQTT_LOG(LOG_ERROR, "Error sending ping\n");
        return VERR_FAIL;
    }
    MQTT_LOG(LOG_DEBUG, "Sent PING successful\n");
    return VERR_OK;
}

/**
 * @brief       mqtt task
 * @param[in]   pv
 */
static void vesync_mqtt_task(void *pv)
{
    vesync_mqtt_client_handle_t client = (vesync_mqtt_client_handle_t) pv;
    uint64_t last_retransmit = 0;
    outbox_tick_t msg_tick = 0;
    uint8_t ping_missed_cnt = 0; // count of consecutive missed ping

    MQTT_UTIL_MEM_CHECK(client, return);
    client->run = true;

    //get transport by scheme
    //client->transport = esp_transport_list_get_transport(client->transport_list, client->config->scheme);

    if (NULL == client->transport)
    {
        MQTT_LOG(LOG_ERROR, "There are no transports valid, stop mqtt client, config scheme = %s\n", client->config->scheme);
        client->run = false;
        VERR_UPLOAD(VERR_MQTT_TLS_SETUP_FAIL, 0);
        return;     // ERROR, 此时应该要记录一条异常信息到flash中，待下次联网成功后，上报服务器
    }
    //default port
    if (0 == client->config->port) {
        client->config->port = client->transport->port;
    }

    client->state = MQTT_STATE_INIT;
    client->status_bits.map.zero = 0;
    while (client->run)
    {
        MQTT_API_LOCK(client);

        switch ((int)client->state)
        {
            case MQTT_STATE_INIT:
                client->event.event_id = MQTT_EVENT_BEFORE_CONNECT;
                vesync_mqtt_dispatch_event_with_msgid(client, 0);
                MQTT_LOG_SET_STEP(MLOG_STEP_CONNECTING);
                if (NULL == client->transport)
                {
                    MQTT_LOG(LOG_ERROR, "There are no transport\n");
                    client->run = false;
                    VERR_UPLOAD(VERR_MQTT_TLS_SETUP_FAIL, 0);
                }

                struct addrinfo *ai = NULL;
                bool use_cache_ip = false;
                ai = vesync_transport_resolve_host(client->config->host, &use_cache_ip);
                if (NULL == ai)
                {
                    /* dns fail, and do not have cache ip */
                    MQTT_LOG(LOG_ERROR, "dns fail, and do not have cache ip\n");
                    vesync_mqtt_abort_connection(client);
                    break;
                }
                else if (false == use_cache_ip)
                {
                    /* notify dns success */
                    struct sockaddr_in *p = (struct sockaddr_in *)ai->ai_addr;
                    client->event.data = (char*)inet_ntoa(p->sin_addr);
                    client->event.total_data_len = client->event.data_len = strlen(client->event.data);
                    client->event.event_id = MQTT_EVENT_DNS_RESOLVED;
                    vesync_mqtt_dispatch_event(client);
                }

                if (client->transport->_connect(client->transport,
                                      ai,
                                      client->config->host,
                                      client->config->port,
                                      client->config->network_timeout_ms) < 0)
                {
                    MQTT_LOG(LOG_ERROR, "Error transport connect\n");
                    vesync_mqtt_abort_connection(client);
#if defined(CONFIG_TARGET_RTL8710CX) || defined(CONFIG_TARGET_RTL8720CF) || defined(CONFIG_IDF_TARGET_BL602)
                    if (use_cache_ip)
                        free(ai);
                    else
#endif /* defined(CONFIG_TARGET_RTL8710CX) || defined(CONFIG_TARGET_RTL8720CF) || defined(CONFIG_IDF_TARGET_BL602) */
                    freeaddrinfo(ai);
                    break;
                }
#if defined(CONFIG_TARGET_RTL8710CX) || defined(CONFIG_TARGET_RTL8720CF) || defined(CONFIG_IDF_TARGET_BL602)
                if (use_cache_ip)
                        free(ai);
                else
#endif /* defined(CONFIG_TARGET_RTL8710CX) || defined(CONFIG_TARGET_RTL8720CF) || defined(CONFIG_IDF_TARGET_BL602) */
                freeaddrinfo(ai);

                MQTT_LOG(LOG_DEBUG, "Transport connected to %s://%s:%d\n", client->config->scheme, client->config->host, client->config->port);
                if (vesync_mqtt_connect(client, client->config->network_timeout_ms) != VERR_OK)
                {
                    MQTT_LOG(LOG_INFO, "Error MQTT Connected\n");
                    vesync_mqtt_abort_connection(client);
                    break;
                }
                MQTT_LOG_SET_STEP(MLOG_STEP_CONNECTED);
                client->event.event_id = MQTT_EVENT_CONNECTED;
                client->event.session_present = mqtt_get_connect_session_present(client->mqtt_state.in_buffer);
                client->state = MQTT_STATE_CONNECTED;
                last_retransmit = vhal_utils_get_system_time_ms_int();
                vesync_mqtt_dispatch_event_with_msgid(client, 0);
                client->refresh_connection_tick = mqtt_util_tick_get_ms();

                break;
            case MQTT_STATE_CONNECTED:
                // receive and process data
                if (VERR_FAIL == mqtt_process_receive(client))
                {
                    vesync_mqtt_abort_connection(client);
                    break;
                }

                //Delete message after OUTBOX_EXPIRED_TIMEOUT_MS miliseconds
                int deleted = outbox_delete_expired(client->outbox, mqtt_util_tick_get_ms(), OUTBOX_EXPIRED_TIMEOUT_MS);
                client->mqtt_state.pending_msg_count -= deleted;

                if (client->mqtt_state.pending_msg_count < 0)
                {
                    client->mqtt_state.pending_msg_count = 0;
                }
                // resend all non-transmitted messages first
                outbox_item_handle_t item = outbox_dequeue(client->outbox, QUEUED, NULL);
                if (item)
                {
                    if (VERR_OK == mqtt_resend_queued(client, item))
                    {
                        outbox_set_pending(client->outbox, client->mqtt_state.pending_msg_id, TRANSMITTED);
                    }
                    // resend other "transmitted" messages after 1s
                }
                else if (vhal_utils_get_system_time_ms_int() - last_retransmit > MQTT_RESEND_PERIOD_MS)
                {
                    last_retransmit = vhal_utils_get_system_time_ms_int();
                    item = outbox_dequeue(client->outbox, TRANSMITTED, &msg_tick);
                    if (item && (last_retransmit - msg_tick > 1000))
                    {
                        mqtt_resend_queued(client, item);
                    }
                }

                if (mqtt_util_tick_get_ms() - client->keepalive_tick > client->connect_info.keepalive * 1000 / 2)
                {
                    //No ping resp from last ping => Disconnected
                    if (client->wait_for_ping_resp)
                    {
                        ping_missed_cnt ++;
                        if (ping_missed_cnt >= MQTT_PING_MISSED_MAX_CNT)
                        {
                            MQTT_LOG(LOG_ERROR, "No PING_RESP, disconnected\n");
                            MQTT_LOG_ERROR("No PING_RESP, disconnected\n");
                            ping_missed_cnt = 0;
                            vesync_mqtt_abort_connection(client);
                            client->wait_for_ping_resp = false;
                            break;
                        }
                        else
                        {
                            MQTT_LOG(LOG_WARN, "%d ping missed!\n", ping_missed_cnt);
                        }
                    }
                    else
                    {
                        ping_missed_cnt = 0;
                    }

                    if (VERR_FAIL == vesync_mqtt_client_ping(client))
                    {
                        MQTT_LOG(LOG_ERROR, "Can't send ping, disconnected\n");
                        vesync_mqtt_abort_connection(client);
                        break;
                    }
                    else
                    {
                        client->wait_for_ping_resp = true;
                    }
                    MQTT_LOG(LOG_DEBUG, "PING sent\n");
                }

                if (client->config->refresh_connection_after_ms &&
                    mqtt_util_tick_get_ms() - client->refresh_connection_tick > client->config->refresh_connection_after_ms)
                {
                    MQTT_LOG(LOG_DEBUG, "Refreshing the connection...\n");
                    MQTT_LOG_ERROR("Refreshing the connection...\n");
                    vesync_mqtt_abort_connection(client);
                    client->state = MQTT_STATE_INIT;
                }

                // Detete confirmed messages
                outbox_cleanup(client->outbox, OUTBOX_MAX_SIZE);

                // Delete messages after 30 senconds
                deleted = outbox_delete_expired(client->outbox, mqtt_util_tick_get_ms(), OUTBOX_EXPIRED_TIMEOUT_MS);
                client->mqtt_state.pending_msg_count -= deleted;
                if (client->mqtt_state.pending_msg_count < 0)
                {
                    client->mqtt_state.pending_msg_count = 0;
                }
                break;
            case MQTT_STATE_WAIT_TIMEOUT:

                if (!client->config->auto_reconnect)
                {
                    client->run = false;
                    break;
                }
                if (mqtt_util_tick_get_ms() - client->reconnect_tick > client->wait_timeout_ms)
                {
                    client->state = MQTT_STATE_INIT;
                    client->reconnect_tick = mqtt_util_tick_get_ms();
                    MQTT_LOG(LOG_DEBUG, "Reconnecting...\n");
                }
                MQTT_API_UNLOCK(client);
                vTaskDelay(client->wait_timeout_ms / 2 / portTICK_RATE_MS);
                // continue the while loop instead of break, as the mutex is unlocked
                continue;
        }
        MQTT_API_UNLOCK(client);
        vTaskDelay(100 / portTICK_RATE_MS);
    }
    client->transport->_close(client->transport);
    client->status_bits.map.zero = 1;

    vTaskDelete(NULL);
}

/**
 * @brief       Creates mqtt client handle based on the configuration
 * @param[in]   config                      [mqtt configuration structure]
 * @return      vesync_mqtt_client_handle_t [the handle of mqtt client]
 */
vesync_mqtt_client_handle_t vesync_mqtt_client_init(const vesync_mqtt_client_config_t *config)
{
    MQTT_UTIL_MEM_CHECK(config, return NULL);

    vesync_mqtt_client_handle_t client = vesync_calloc(1, sizeof(struct vesync_mqtt_client));
    MQTT_UTIL_MEM_CHECK(
        client,
        do
        {
            VERR_UPLOAD(VERR_LINK_MOD_COM(VERR_MEM_ALLOC_FAIL), vhal_get_free_heap_size());
            return NULL;
        }
        while (0));

#ifndef MQTT_DISABLE_API_LOCKS
    client->api_lock = vesync_recursive_mutex_new();
    if (client->api_lock == NULL)
    {
        free(client);
        VERR_UPLOAD(VERR_LINK_MOD_COM(VERR_MUTEX_CREATE_FAIL), vhal_get_free_heap_size());
        return NULL;
    }
#endif /* MQTT_DISABLE_API_LOCKS */
    vesync_mqtt_set_config(client, config);
    vesync_transport_handle_t ssl = vesync_transport_ssl_init();
    MQTT_UTIL_MEM_CHECK(ssl, goto _mqtt_init_failed);
    ssl->port = MQTT_SSL_DEFAULT_PORT;
    if (config->cert_pem)
    {
        vesync_transport_ssl_set_cert_data(ssl, config->cert_pem, strlen(config->cert_pem));
    }
    if (config->client_cert_pem)
    {
        vesync_transport_ssl_set_client_cert_data(ssl, config->client_cert_pem, strlen(config->client_cert_pem));
    }
    if (config->client_key_pem)
    {
        vesync_transport_ssl_set_client_key_data(ssl, config->client_key_pem, strlen(config->client_key_pem));
    }

    client->transport = ssl;

    if (MQTT_TRANSPORT_OVER_SSL == config->transport)
    {
        client->config->scheme = create_string("mqtts", 5);
        MQTT_UTIL_MEM_CHECK(client->config->scheme, goto _mqtt_init_failed);
    }

    if (client->config->scheme == NULL) {
        client->config->scheme = create_string("mqtt", 4);
        MQTT_UTIL_MEM_CHECK(client->config->scheme, goto _mqtt_init_failed);
    }

    client->keepalive_tick = mqtt_util_tick_get_ms();
    client->reconnect_tick = mqtt_util_tick_get_ms();
    client->wait_timeout_ms = 0;
    client->refresh_connection_tick = mqtt_util_tick_get_ms();
    client->wait_for_ping_resp = false;
    int buffer_size = config->buffer_size;
    if (buffer_size <= 0)
    {
        buffer_size = MQTT_BUFFER_SIZE_BYTE;
    }
    client->mqtt_state.in_buffer = (uint8_t *)vesync_malloc(buffer_size);
    MQTT_UTIL_MEM_CHECK(client->mqtt_state.in_buffer, goto _mqtt_init_failed);
    memset(client->mqtt_state.in_buffer, 0, buffer_size);
    client->mqtt_state.in_buffer_length = buffer_size;
    client->mqtt_state.out_buffer = (uint8_t *)vesync_malloc(buffer_size);
    MQTT_UTIL_MEM_CHECK(client->mqtt_state.out_buffer, goto _mqtt_init_failed);
    memset(client->mqtt_state.out_buffer, 0, buffer_size);

    client->mqtt_state.out_buffer_length = buffer_size;
    client->mqtt_state.connect_info = &client->connect_info;
    client->outbox = outbox_init();
    MQTT_UTIL_MEM_CHECK(client->outbox, goto _mqtt_init_failed);
    client->status_bits.event_group = 0;
    return client;

_mqtt_init_failed:
    vesync_mqtt_client_destroy(client);
    VERR_UPLOAD(VERR_LINK_MOD_COM(VERR_MEM_ALLOC_FAIL), vhal_get_free_heap_size());
    return NULL;
}

/**
 * @brief       Starts mqtt client with already created client handle
 * @param[in]   client                      [mqtt client handle]
 * @return      int
 */
int vesync_mqtt_client_start(vesync_mqtt_client_handle_t client)
{
    MQTT_UTIL_MEM_CHECK(client, return VERR_FAIL);

    MQTT_API_LOCK(client);

    if (client->state >= MQTT_STATE_INIT)
    {
        MQTT_LOG(LOG_ERROR, "Client has started\n");
        MQTT_API_UNLOCK(client);
        return VERR_FAIL;
    }

    MQTT_LOG(LOG_DEBUG, "Core selection disabled, task_stack = %d, task_prio = %d\n",
                    client->config->task_stack, client->config->task_prio);
    if (vesync_task_new("mqtt_task", vesync_mqtt_task, client, client->config->task_stack, client->config->task_prio, NULL) != VERR_OK)
    {
        MQTT_LOG(LOG_ERROR, "Error create mqtt task\n");
        MQTT_API_UNLOCK(client);
        return VERR_FAIL;
    }

    MQTT_API_UNLOCK(client);

    return VERR_OK;
}

/**
 * @brief       Stops mqtt client tasks
 * @param[in]   client                      [mqtt client handle]
 * @return      int
 */
int vesync_mqtt_client_stop(vesync_mqtt_client_handle_t client)
{
    MQTT_UTIL_MEM_CHECK(client, return VERR_FAIL);

    MQTT_API_LOCK(client);

    if (client->run)
    {
        client->run = false;
        client->state = MQTT_STATE_UNKNOWN;
        MQTT_API_UNLOCK(client);
        vesync_sleep(100);
        return VERR_OK;
    }
    else
    {
        MQTT_LOG(LOG_WARN, "Client asked to stop, but was not started\n");
        MQTT_API_UNLOCK(client);
        return VERR_FAIL;
    }
}

/**
 * @brief       Subscribe the client to defined topic with defined qos
 * @param[in]   client                      [mqtt client handle]
 * @param[in]   topic
 * @param[in]   qos
 * @return      int                         [message_id of the subscribe message on success; -1 on failure]
 * @Notes:
 *              - Client must be connected to send subscribe message
 *              - This API is could be executed from a user task or
 *              from a mqtt event callback i.e. internal mqtt task
 *              (API is protected by internal mutex, so it might block
 *              if a longer data receive operation is in progress.)
 */
int vesync_mqtt_client_subscribe(vesync_mqtt_client_handle_t client, const char *topic, int qos)
{
    uint16_t ret = -1;
    MQTT_UTIL_MEM_CHECK(client, return -1);
    MQTT_UTIL_MEM_CHECK(topic, return -1);

    MQTT_API_LOCK(client);

    if (client->state != MQTT_STATE_CONNECTED)
    {
        MQTT_LOG(LOG_ERROR, "Client has not connected\n");
        MQTT_LOG_ERROR("subscribe error, Client has not connected");
        VERR_UPLOAD(VERR_MQTT_SUBSCRIBED_FAIL, client->state);
        MQTT_API_UNLOCK(client);
        return -1;
    }

    client->mqtt_state.outbound_message = mqtt_msg_subscribe(&client->mqtt_state.mqtt_connection,
                                          topic, qos,
                                          &client->mqtt_state.pending_msg_id);
    if (0 == client->mqtt_state.outbound_message->length)
    {
        MQTT_LOG(LOG_ERROR, "Subscribe message cannot be created");
        VERR_UPLOAD(VERR_MQTT_SUBSCRIBED_FAIL, 0);
        MQTT_API_UNLOCK(client);
        return -1;
    }

    client->mqtt_state.pending_msg_type = mqtt_get_type(client->mqtt_state.outbound_message->data);
    client->mqtt_state.pending_msg_count ++;
    mqtt_enqueue(client); //move pending msg to outbox (if have)
    outbox_set_pending(client->outbox, client->mqtt_state.pending_msg_id, TRANSMITTED);

    if (mqtt_write_data(client) != VERR_OK)
    {
        MQTT_LOG(LOG_ERROR, "Error to subscribe topic=%s, qos=%d\n", topic, qos);
        VERR_UPLOAD(VERR_MQTT_SUBSCRIBED_FAIL, 0);
        MQTT_API_UNLOCK(client);
        return -1;
    }

    MQTT_LOG(LOG_DEBUG, "Sent subscribe topic=%s, id: %d, type=%d successful\n", topic, client->mqtt_state.pending_msg_id, client->mqtt_state.pending_msg_type);
    ret = client->mqtt_state.pending_msg_id;
    MQTT_API_UNLOCK(client);
    return ret;
}

/**
 * @brief       Unsubscribe the client from defined topic
 * @param[in]   client                      [mqtt client handle]
 * @param[in]   topic
 * @return      int                         [message_id of the unsubscribe message on success; -1 on failure]
 * @Notes:
 *              - Client must be connected to send unsubscribe message
 *              - It is thread safe, please refer to `vesync_mqtt_client_subscribe` for details
 */
int vesync_mqtt_client_unsubscribe(vesync_mqtt_client_handle_t client, const char *topic)
{
    uint16_t ret = -1;
    MQTT_UTIL_MEM_CHECK(client, return -1);
    MQTT_UTIL_MEM_CHECK(topic, return -1);

    MQTT_API_LOCK(client);

    if (client->state != MQTT_STATE_CONNECTED)
    {
        MQTT_LOG(LOG_ERROR, "Client has not connected\n");
        VERR_UPLOAD(VERR_MQTT_UNSUBSCRIBED_FAIL, client->state);
        MQTT_API_UNLOCK(client);
        return -1;
    }

    client->mqtt_state.outbound_message = mqtt_msg_unsubscribe(&client->mqtt_state.mqtt_connection,
                                          topic,
                                          &client->mqtt_state.pending_msg_id);
    if (0 == client->mqtt_state.outbound_message->length) {
        MQTT_API_UNLOCK(client);
        MQTT_LOG(LOG_ERROR, "Unubscribe message cannot be created");
        VERR_UPLOAD(VERR_MQTT_UNSUBSCRIBED_FAIL, 0);
        return -1;
    }

    MQTT_LOG(LOG_DEBUG, "unsubscribe, topic\"%s\", id: %d\n", topic, client->mqtt_state.pending_msg_id);

    client->mqtt_state.pending_msg_type = mqtt_get_type(client->mqtt_state.outbound_message->data);
    client->mqtt_state.pending_msg_count ++;
    mqtt_enqueue(client);
    outbox_set_pending(client->outbox, client->mqtt_state.pending_msg_id, TRANSMITTED);

    if (mqtt_write_data(client) != VERR_OK)
    {
        MQTT_LOG(LOG_ERROR, "Error to unsubscribe topic=%s\n", topic);
        VERR_UPLOAD(VERR_MQTT_UNSUBSCRIBED_FAIL, 0);
        MQTT_API_UNLOCK(client);
        return -1;
    }

    MQTT_LOG(LOG_DEBUG, "Sent Unsubscribe topic=%s, id: %d, successful\n", topic, client->mqtt_state.pending_msg_id);
    ret = client->mqtt_state.pending_msg_id;
    MQTT_API_UNLOCK(client);
    return ret;
}

/**
 * @brief       Client to send a publish message to the broker
 * @param[in]   client                      [mqtt client handle]
 * @param[in]   topic                       [topic string]
 * @param[in]   data                        [payload string (set to NULL, sending empty payload message)]
 * @param[in]   len                         [data length, if set to 0, length is calculated from payload string]
 * @param[in]   qos                         [qos of publish message]
 * @param[in]   retain                      [retain flag]
 * @return      int                         [message_id of the publish message(for QoS 0 message_id will always be zero) on success; -1 on failure]
 * @Notes:
 *              - Client doesn't have to be connected to send publish message
 *              (although it would drop all qos=0 messages, qos>1 messages would be enqueued)
 *              - It is thread safe, please refer to `vesync_mqtt_client_subscribe` for details
 */
int vesync_mqtt_client_publish(vesync_mqtt_client_handle_t client, const char *topic, const char *data, int len, int qos, int retain)
{
    uint16_t pending_msg_id = 0;
    int ret = 0;

    MQTT_UTIL_MEM_CHECK(client, return -1);
    MQTT_UTIL_MEM_CHECK(topic, return -1);
    MQTT_UTIL_MEM_CHECK(data, return -1);

    if (len <= 0) {
        len = strlen(data);
    }

    MQTT_API_LOCK(client);

    mqtt_message_t *publish_msg = mqtt_msg_publish(&client->mqtt_state.mqtt_connection,
                                  topic, data, len,
                                  qos, retain,
                                  &pending_msg_id);

    if (0 == publish_msg->length)
    {
        MQTT_LOG(LOG_ERROR, "Publish message cannot be created");
        VERR_UPLOAD(VERR_MQTT_SEND_DATA_FAIL, 0);
        MQTT_API_UNLOCK(client);
        return -1;
    }

    /* We have to set as pending all the qos>0 messages) */
    client->mqtt_state.outbound_message = publish_msg;
    if (qos > MQTT_QOS0)
    {
        client->mqtt_state.pending_msg_type = mqtt_get_type(client->mqtt_state.outbound_message->data);
        client->mqtt_state.pending_msg_id = pending_msg_id;
        client->mqtt_state.pending_publish_qos = qos;
        client->mqtt_state.pending_msg_count ++;
        // by default store as QUEUED (not transmitted yet) only for messages which would fit outbound buffer
        if (0 == client->mqtt_state.mqtt_connection.message.fragmented_msg_total_length)
        {
            mqtt_enqueue(client);
        }
        else
        {
            int first_fragment = client->mqtt_state.outbound_message->length - client->mqtt_state.outbound_message->fragmented_msg_data_offset;
            mqtt_enqueue_oversized(client, ((uint8_t *)data) + first_fragment, len - first_fragment);
        }
    }

    /* Skip sending if not connected (rely on resending) */
    if (client->state != MQTT_STATE_CONNECTED)
    {
        MQTT_LOG(LOG_DEBUG, "Publish: client is not connected");
        ret = -1;
        goto cannot_publish;
    }

    /* Provide support for sending fragmented message if it doesn't fit buffer */
    int remaining_len = len;
    const char *current_data = data;
    bool sending = true;

    while (sending)  {
        if (mqtt_write_data(client) != VERR_OK)
        {
            MQTT_LOG(LOG_ERROR, "Error to public data to topic=%s, qos=%d\n", topic, qos);
            // not all producet open mqtt_lock, discard the abort operation for safe.
            //vesync_mqtt_abort_connection(client);
            ret = -1;
            goto cannot_publish;
        }

        int data_sent = client->mqtt_state.outbound_message->length - client->mqtt_state.outbound_message->fragmented_msg_data_offset;
        client->mqtt_state.outbound_message->fragmented_msg_data_offset = 0;
        client->mqtt_state.outbound_message->fragmented_msg_total_length = 0;
        remaining_len -= data_sent;
        current_data +=  data_sent;

        if (remaining_len > 0)
        {
            mqtt_connection_t* connection = &client->mqtt_state.mqtt_connection;
            MQTT_LOG(LOG_DEBUG, "Sending fragmented message, remains to send %d bytes of %d\n", remaining_len, len);

            if (remaining_len > connection->buffer_length)
            {
                // Continue with sending
                memcpy(connection->buffer, current_data, connection->buffer_length);
                connection->message.length = connection->buffer_length;
                sending = true;
            }
            else
            {
                memcpy(connection->buffer, current_data, remaining_len);
                connection->message.length = remaining_len;
                sending = true;
            }
            connection->message.data = connection->buffer;
            client->mqtt_state.outbound_message = &connection->message;
        }
        else
        {
            // Message was sent correctly
            sending = false;
        }
    }

    if (qos > MQTT_QOS0)
    {
        //Tick is set after transmit to avoid retransmitting too early due slow network speed / big messages
        outbox_set_tick(client->outbox, pending_msg_id, vhal_utils_get_system_time_ms_int());
        outbox_set_pending(client->outbox, pending_msg_id, TRANSMITTED);
    }
    MQTT_API_UNLOCK(client);
    return pending_msg_id;

cannot_publish:
    // clear out possible fragmented publish if failed or skipped
    client->mqtt_state.outbound_message->fragmented_msg_total_length = 0;
    if (qos == MQTT_QOS0)
    {
        MQTT_LOG(LOG_WARN, "Publish: Losing qos0 data when client not connected");
    }
    MQTT_API_UNLOCK(client);

    return ret;
}

/**
 * @brief       Destroys the client handle
 * @param[in]   client                      [mqtt client handle]
 * @return      int
 */
int vesync_mqtt_client_destroy(vesync_mqtt_client_handle_t client)
{
    MQTT_UTIL_MEM_CHECK(client, return VERR_FAIL);

    vesync_mqtt_client_stop(client);
    vesync_mqtt_destroy_config(client);
    outbox_destroy(client->outbox);
    if (NULL != client->transport)
    {
        client->transport->_destroy(client->transport);
        MQTT_UTIL_SAFE_FREE(client->transport);
    }
    client->status_bits.event_group = 0;
    MQTT_UTIL_SAFE_FREE(client->mqtt_state.in_buffer);
    MQTT_UTIL_SAFE_FREE(client->mqtt_state.out_buffer);
#ifndef MQTT_DISABLE_API_LOCKS
    vesync_recursive_mutex_free(client->api_lock);
#endif /* MQTT_DISABLE_API_LOCKS */
    MQTT_UTIL_SAFE_FREE(client);
    return VERR_OK;
}

/**
 * @brief       Set configuration structure, typically used when updating the config (i.e. on "before_connect" event)
 * @param[in]   client                      [mqtt client handle]
 * @param[in]   config                      [mqtt configuration structure]
 * @return      int
 */
int vesync_mqtt_set_config(vesync_mqtt_client_handle_t client, const vesync_mqtt_client_config_t *config)
{
    //Copy user configurations to client context
    int err = VERR_FAIL;
    mqtt_config_storage_t *cfg = NULL;
    MQTT_UTIL_MEM_CHECK(client, return VERR_FAIL);
    MQTT_UTIL_MEM_CHECK(config, return VERR_FAIL);

    MQTT_API_LOCK(client);

    if (client->config)
    {
        cfg = client->config;
    }
    else
    {
        cfg = vesync_calloc(1, sizeof(mqtt_config_storage_t));
        MQTT_UTIL_MEM_CHECK(
            cfg,
            do
            {
                MQTT_API_UNLOCK(client);
                VERR_UPLOAD(VERR_LINK_MOD_COM(VERR_MEM_ALLOC_FAIL), vhal_get_free_heap_size());
                return VERR_FAIL;
            } while(0));
        client->config = cfg;
    }
    if (config->task_prio)
    {
        cfg->task_prio = config->task_prio;
    }

    if (cfg->task_prio <= 0)
    {
        cfg->task_prio = MQTT_TASK_PRIORITY;
    }
    if (config->task_stack)
    {
        cfg->task_stack = config->task_stack;
    }
    if (cfg->task_stack == 0)
    {
        cfg->task_stack = MQTT_TASK_STACK/sizeof(portSTACK_TYPE);
    }
    if (config->port)
    {
        cfg->port = config->port;
    }

    if (config->host)
    {
        MQTT_UTIL_SAFE_FREE(cfg->host);
        cfg->host = mqtt_strdup(config->host);
        MQTT_UTIL_MEM_CHECK(cfg->host, goto _mqtt_set_config_failed);
    }

    if (config->username)
    {
        MQTT_UTIL_SAFE_FREE(client->connect_info.username);
        client->connect_info.username = mqtt_strdup(config->username);
        MQTT_UTIL_MEM_CHECK(client->connect_info.username, goto _mqtt_set_config_failed);
    }

    if (config->password)
    {
        MQTT_UTIL_SAFE_FREE(client->connect_info.password);
        client->connect_info.password = mqtt_strdup(config->password);
        MQTT_UTIL_MEM_CHECK(client->connect_info.password, goto _mqtt_set_config_failed);
    }
    if (config->client_id)
    {
        MQTT_UTIL_SAFE_FREE(client->connect_info.client_id);
        client->connect_info.client_id = mqtt_strdup(config->client_id);
        MQTT_UTIL_MEM_CHECK(client->connect_info.client_id, goto _mqtt_set_config_failed);
    }
    else if (NULL == client->connect_info.client_id)
    {
        client->connect_info.client_id = mqtt_util_create_id_string();
    }
    MQTT_UTIL_MEM_CHECK(client->connect_info.client_id, goto _mqtt_set_config_failed);
    MQTT_LOG(LOG_DEBUG, "MQTT client_id=%s\n", client->connect_info.client_id);

    if (config->uri)
    {
        MQTT_UTIL_SAFE_FREE(cfg->uri);
        cfg->uri = mqtt_strdup(config->uri);
        MQTT_UTIL_MEM_CHECK(cfg->uri, goto _mqtt_set_config_failed);
    }

    if (config->lwt_topic)
    {
        MQTT_UTIL_SAFE_FREE(client->connect_info.will_topic);
        client->connect_info.will_topic = mqtt_strdup(config->lwt_topic);
        MQTT_UTIL_MEM_CHECK(client->connect_info.will_topic, goto _mqtt_set_config_failed);
    }

    if (config->lwt_msg_len && config->lwt_msg)
    {
        MQTT_UTIL_SAFE_FREE(client->connect_info.will_message);
        client->connect_info.will_message = vesync_malloc(config->lwt_msg_len);
        MQTT_UTIL_MEM_CHECK(client->connect_info.will_message, goto _mqtt_set_config_failed);
        memset(client->connect_info.will_message, 0, config->lwt_msg_len);
        memcpy(client->connect_info.will_message, config->lwt_msg, config->lwt_msg_len);
        client->connect_info.will_length = config->lwt_msg_len;
    }
    else if (config->lwt_msg)
    {
        MQTT_UTIL_SAFE_FREE(client->connect_info.will_message);
        client->connect_info.will_message = mqtt_strdup(config->lwt_msg);
        MQTT_UTIL_MEM_CHECK(client->connect_info.will_message, goto _mqtt_set_config_failed);
        client->connect_info.will_length = strlen(config->lwt_msg);
    }

    if (config->lwt_qos)
    {
        client->connect_info.will_qos = config->lwt_qos;
    }
    if (config->lwt_retain)
    {
        client->connect_info.will_retain = config->lwt_retain;
    }

    if (config->disable_clean_session == client->connect_info.clean_session)
    {
        client->connect_info.clean_session = !config->disable_clean_session;
    }
    if (config->keepalive)
    {
        client->connect_info.keepalive = config->keepalive;
    }
    if (0 == client->connect_info.keepalive)
    {
        client->connect_info.keepalive = MQTT_KEEPALIVE_TICK;
    }
    cfg->network_timeout_ms = MQTT_NETWORK_TIMEOUT_MS;
    if (config->user_context)
    {
        cfg->user_context = config->user_context;
    }

    if (config->event_handle)
    {
        cfg->event_handle = config->event_handle;
    }

    if (config->refresh_connection_after_ms)
    {
        cfg->refresh_connection_after_ms = config->refresh_connection_after_ms;
    }

    cfg->auto_reconnect = true;
    if (config->disable_auto_reconnect == cfg->auto_reconnect)
    {
        cfg->auto_reconnect = !config->disable_auto_reconnect;
    }

    MQTT_LOG(LOG_INFO, "MQTT auto_reconnect=%d, disable_auto_reconnect=%d\n", cfg->auto_reconnect, config->disable_auto_reconnect);
    MQTT_API_UNLOCK(client);
    return VERR_OK;
_mqtt_set_config_failed:
    vesync_mqtt_destroy_config(client);
    MQTT_API_UNLOCK(client);
    VERR_UPLOAD(VERR_LINK_MOD_COM(VERR_MEM_ALLOC_FAIL), vhal_get_free_heap_size());
    return err;
}

/**
 * @brief       Sets the configuration of mqtt client over tls
 * @param[in]   client_config               [client configuration structure]
 * @param[in]   client_id                   [client id]
 * @param[in]   server_addr                 [server address]
 * @param[in]   server_port                 [server port]
 * @param[in]   username                    [mqtt client username]
 * @param[in]   password                    [mqtt client password]
 * @param[in]   event_cb                    [mqtt event callback]
 * @param[in]   ca_cert                     [CA certificate]
 * @param[in]   client_cert                 [client certificate]
 * @param[in]   client_key                  [client key]
 * @return      int
 */
int vesync_mqtt_client_config_tls(vesync_mqtt_client_config_t* client_config, char *client_id, char *server_addr, uint16_t server_port,
                                    char *username, char *password, mqtt_event_callback_t event_cb,
                                    const char * ca_cert, const char *client_cert, const char *client_key)
{
    //memset(vesync_client, 0, sizeof(vesync_mqtt_client_t));
    MQTT_UTIL_MEM_CHECK(client_config, return VERR_FAIL);
    MQTT_UTIL_MEM_CHECK(client_id, return VERR_FAIL);
    MQTT_UTIL_MEM_CHECK(server_addr, return VERR_FAIL);
    MQTT_UTIL_MEM_CHECK(username, return VERR_FAIL);
    MQTT_UTIL_MEM_CHECK(password, return VERR_FAIL);
    MQTT_UTIL_MEM_CHECK(ca_cert, return VERR_FAIL);
    MQTT_UTIL_MEM_CHECK(client_cert, return VERR_FAIL);
    MQTT_UTIL_MEM_CHECK(client_key, return VERR_FAIL);

    client_config->client_id = vesync_malloc(strlen(client_id) + 1);
    MQTT_UTIL_MEM_CHECK(client_config->client_id, goto config_tls_failed);
    memset((char*)client_config->client_id, 0, strlen(client_id) + 1);
    strncpy((char*)client_config->client_id, client_id, strlen(client_id));

    client_config->host = vesync_malloc(strlen(server_addr) + 1);
    MQTT_UTIL_MEM_CHECK(client_config->host, goto config_tls_failed);
    memset((char*)client_config->host, 0, strlen(server_addr) + 1);
    strncpy((char*)client_config->host, server_addr, strlen(server_addr));

    client_config->port = server_port;

    client_config->username = vesync_malloc(strlen(username) + 1);
    MQTT_UTIL_MEM_CHECK(client_config->username, goto config_tls_failed);
    memset((char*)client_config->username, 0, strlen(username) + 1);
    strncpy((char*)client_config->username, username, strlen(username));

    client_config->password = vesync_malloc(strlen(password) + 1);
    MQTT_UTIL_MEM_CHECK(client_config->password, goto config_tls_failed);
    memset((char*)client_config->password, 0, strlen(password) + 1);
    strncpy((char*)client_config->password, password, strlen(password));

    client_config->event_handle = event_cb;

    client_config->transport = MQTT_TRANSPORT_OVER_SSL;

    if(NULL != client_config->cert_pem)
        free((char*)client_config->cert_pem);
    if(NULL != client_config->client_cert_pem)
        free((char*)client_config->client_cert_pem);
    if(NULL != client_config->client_key_pem)
        free((char*)client_config->client_key_pem);

    // 此处不检验CA证书，否则会出现tls握手失败
    // client_config->cert_pem = vesync_malloc(strlen(ca_cert) + 1);
    // if(NULL != client_config->cert_pem)
    // 	strcpy((char*)client_config->cert_pem, ca_cert);

    client_config->client_cert_pem = vesync_malloc(strlen(client_cert) + 1);
    MQTT_UTIL_MEM_CHECK(client_config->client_cert_pem, goto config_tls_failed);
    memset((char *)client_config->client_cert_pem, 0, strlen(client_cert) + 1);
    strncpy((char*)client_config->client_cert_pem, client_cert, strlen(client_cert));

    client_config->client_key_pem = vesync_malloc(strlen(client_key) + 1);
    MQTT_UTIL_MEM_CHECK(client_config->client_key_pem, goto config_tls_failed);
    memset((char *)client_config->client_key_pem, 0, strlen(client_key) + 1);
    strncpy((char*)client_config->client_key_pem, client_key, strlen(client_key));

    client_config->keepalive = 30;  // MQTT心跳间隔，修改为30s

	return VERR_OK;

config_tls_failed:
    VERR_UPLOAD(VERR_LINK_MOD_COM(VERR_MEM_ALLOC_FAIL), vhal_get_free_heap_size());
    return VERR_FAIL;
}

/**
 * @brief       Sets the configuration of mqtt client over tcp
 * @param[in]   client_config               [client configuration structure]
 * @param[in]   client_id                   [client id]
 * @param[in]   server_addr                 [server address]
 * @param[in]   server_port                 [server port]
 * @param[in]   username                    [mqtt client username]
 * @param[in]   password                    [mqtt client password]
 * @param[in]   event_cb                    [mqtt event callback]
 * @return      int
 */
int vesync_mqtt_client_config(vesync_mqtt_client_config_t *client_config, char *client_id, char *server_addr, uint16_t server_port,
                                    char *username, char *password, mqtt_event_callback_t event_cb)
{
    //memset(client_config, 0, sizeof(struct vesync_mqtt_client_config_t));
    MQTT_UTIL_MEM_CHECK(client_config, return VERR_FAIL);
    MQTT_UTIL_MEM_CHECK(client_id, return VERR_FAIL);
    MQTT_UTIL_MEM_CHECK(server_addr, return VERR_FAIL);
    MQTT_UTIL_MEM_CHECK(username, return VERR_FAIL);
    MQTT_UTIL_MEM_CHECK(password, return VERR_FAIL);

    client_config->client_id = vesync_malloc(strlen(client_id) + 1);
    MQTT_UTIL_MEM_CHECK(client_config->client_id, goto config_failed);
    memset((char*)client_config->client_id, 0, strlen(client_id) + 1);
    strncpy((char*)client_config->client_id, client_id, strlen(client_id));

    client_config->host = vesync_malloc(strlen(server_addr) + 1);
    MQTT_UTIL_MEM_CHECK(client_config->host, goto config_failed);
    memset((char*)client_config->host, 0, strlen(server_addr) + 1);
    strncpy((char*)client_config->host, server_addr, strlen(server_addr));

    client_config->port = server_port;

    client_config->username = vesync_malloc(strlen(username) + 1);
    MQTT_UTIL_MEM_CHECK(client_config->username, goto config_failed);
    memset((char*)client_config->username, 0, strlen(username) + 1);
    strncpy((char*)client_config->username, username, strlen(username));

    client_config->password = vesync_malloc(strlen(password) + 1);
    MQTT_UTIL_MEM_CHECK(client_config->password, goto config_failed);
    memset((char*)client_config->password, 0, strlen(password) + 1);
    strncpy((char*)client_config->password, password, strlen(password));

    client_config->event_handle = event_cb;

    client_config->keepalive = 30;  // MQTT心跳间隔，修改为30s

    return VERR_OK;

config_failed:
    VERR_UPLOAD(VERR_LINK_MOD_COM(VERR_MEM_ALLOC_FAIL), vhal_get_free_heap_size());
    return VERR_FAIL;
}

/**
 * @brief       Destroys the client configuration structure
 * @param[in]   client_config               [client configuration structure]
 * @return      int
 */
int vesync_mqtt_destroy_client_config(vesync_mqtt_client_config_t *client_config)
{
    if(NULL == client_config)
        return VERR_FAIL;

    if(NULL != client_config->host)
        free((char*)client_config->host);
    if(NULL != client_config->uri)
        free((char*)client_config->uri);
    if(NULL != client_config->client_id)
        free((char*)client_config->client_id);
    if(NULL != client_config->username)
        free((char*)client_config->username);
    if(NULL != client_config->password)
        free((char*)client_config->password);
    if(NULL != client_config->lwt_topic)
        free((char*)client_config->lwt_topic);
    if(NULL != client_config->lwt_msg)
        free((char*)client_config->lwt_msg);

    if(NULL != client_config->user_context)
        free(client_config->user_context);

    if(NULL != client_config->cert_pem)
        free((char*)client_config->cert_pem);
    if(NULL != client_config->client_cert_pem)
        free((char*)client_config->client_cert_pem);
    if(NULL != client_config->client_key_pem)
        free((char*)client_config->client_key_pem);

    return VERR_OK;
}

/*
 * @brief       Saves the address information of server
 */
void vesync_mqtt_update_serv_addr_info(void)
{
    vesync_transport_update_serv_addr_info();
}


