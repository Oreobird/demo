/**
 * Copyright © Vesync Technologies Co.Ltd. 2019-2021. All rights reserved
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


#ifndef __TRANSPORT_SSL_H__
#define __TRANSPORT_SSL_H__

#ifdef __cplusplus
extern "C"
{
#endif


struct vesync_transport_item_t;

typedef struct vesync_transport_item_t* vesync_transport_handle_t;

typedef int (*connect_func)(vesync_transport_handle_t t, const struct addrinfo *ai, const char *hostname, int port, int timeout_ms);
typedef int (*io_func)(vesync_transport_handle_t t, const char *buffer, int len, int timeout_ms);
typedef int (*io_read_func)(vesync_transport_handle_t t, char *buffer, int len, int timeout_ms);
typedef int (*trans_func)(vesync_transport_handle_t t);
typedef int (*poll_func)(vesync_transport_handle_t t, int timeout_ms);
typedef int (*connect_async_func)(vesync_transport_handle_t t, const struct addrinfo *ai, const char *hostname, int port, int timeout_ms);


/**
 * @brief   Transport layer structure, which will provide functions, basic properties for transport types
 */
struct vesync_transport_item_t {
    int             port;
    int             socket;         /*!< Socket to use in this transport */
    char            *scheme;        /*!< Tag name */
    void            *context;       /*!< Context data */
    void            *data;          /*!< Additional transport data */
    connect_func    _connect;       /*!< Connect function of this transport */
    io_read_func    _read;          /*!< Read */
    io_func         _write;         /*!< Write */
    trans_func      _close;         /*!< Close */
    poll_func       _poll_read;     /*!< Poll and read */
    poll_func       _poll_write;    /*!< Poll and write */
    trans_func      _destroy;       /*!< Destroy and free transport */
    connect_async_func _connect_async;      /*!< non-blocking connect function of this transport */
};


/**
 * @brief       Create new SSL transport, the transport handle must be release vesync_transport_destroy callback
 * @return      vesync_transport_handle_t   [the allocated vesync_transport_handle_t, or NULL if the handle can not be allocated]
 */
vesync_transport_handle_t vesync_transport_ssl_init(void);

/**
 * @brief       Set SSL certificate data (as PEM format).
 *              Note that, this function stores the pointer to data, rather than making a copy.
 *              So this data must remain valid until after the connection is cleaned up
 * @param       t                           [ssl transport]
 * @param[in]   data                        [The pem data]
 * @param[in]   len                         [The length]
 */
void vesync_transport_ssl_set_cert_data(vesync_transport_handle_t t, const char *data, int len);

/**
 * @brief       Set SSL certificate data (as DER format).
 *              Note that, this function stores the pointer to data, rather than making a copy.
 *              So this data must remain valid until after the connection is cleaned up
 * @param       t                           [ssl transport]
 * @param[in]   data                        [The pem data]
 * @param[in]   len                         [The length]
 */
void vesync_transport_ssl_set_cert_data_der(vesync_transport_handle_t t, const char *data, int len);

/**
 * @brief       Set SSL client certificate data for mutual authentication (as PEM format).
 *              Note that, this function stores the pointer to data, rather than making a copy.
 *              So this data must remain valid until after the connection is cleaned up
 * @param       t                           [ssl transport]
 * @param[in]   data                        [The pem data]
 * @param[in]   len                         [The length]
 */
void vesync_transport_ssl_set_client_cert_data(vesync_transport_handle_t t, const char *data, int len);

/**
 * @brief       Set SSL client certificate data for mutual authentication (as DER format).
 *              Note that, this function stores the pointer to data, rather than making a copy.
 *              So this data must remain valid until after the connection is cleaned up
 * @param       t                           [ssl transport]
 * @param[in]   data                        [The pem data]
 * @param[in]   len                         [The length]
 */
void vesync_transport_ssl_set_client_cert_data_der(vesync_transport_handle_t t, const char *data, int len);

/**
 * @brief       Set SSL client key data for mutual authentication (as PEM format).
 *              Note that, this function stores the pointer to data, rather than making a copy.
 *              So this data must remain valid until after the connection is cleaned up
 * @param       t                           [ssl transport]
 * @param[in]   data                        [The pem data]
 * @param[in]   len                         [The length]
 */
void vesync_transport_ssl_set_client_key_data(vesync_transport_handle_t t, const char *data, int len);

/**
 * @brief       Set SSL client key data for mutual authentication (as DER format).
 *              Note that, this function stores the pointer to data, rather than making a copy.
 *              So this data must remain valid until after the connection is cleaned up
 * @param       t                           [ssl transport]
 * @param[in]   data                        [The pem data]
 * @param[in]   len                         [The length]
 */
void vesync_transport_ssl_set_client_key_data_der(vesync_transport_handle_t t, const char *data, int len);

/**
 * @brief       Enable global CA store for SSL connection
 * @param       t                           [ssl transport]
 */
void vesync_transport_ssl_enable_global_ca_store(vesync_transport_handle_t t);

/**
 * @brief       dns resolve for the host
 * @param[in]   host                        [pointer to host name]
 * @param[out]  use_cache_ip                [after process, whether it decides to use cached ip]
 * @return      struct addrinfo*            [pointer to the addrinfo, or NULL if can not resolve]
 */
struct addrinfo* vesync_transport_resolve_host(const char *host, bool *use_cache_ip);

/*
 * @brief       Saves the address information of server
 */
void vesync_transport_update_serv_addr_info(void);


#ifdef __cplusplus
}
#endif

#endif /* __TRANSPORT_SSL_H__ */

