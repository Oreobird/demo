/**
 * Copyright © Etekcity Technologies Co., Ltd. 2021. All rights reserved.
 * @file        ffs_wifi_connection_attempt_list.c
 * @brief       Ffs Wi-Fi connection attempt list
 * @author      Owen.zhang
 * @date        2020-04-22
 */

#include "vesync_common.h"
#include "vesync_memory.h"
#include "ffs/common/ffs_result.h"
#include "ffs/common/ffs_check_result.h"
#include "ffs_wifi_connection_attempt_list.h"
#include "ffs_wifi_context.h"

/** Static function prototypes. */
static FFS_RESULT ffsCloneWifiConnectionAttempt(FfsWifiConnectionAttempt_t *connectionAttempt,
                                                FfsWifiConnectionAttempt_t **cloneConnectionAttempt);
static FFS_RESULT ffsFreeWifiConnectionAttempt(FfsWifiConnectionAttempt_t *connectionAttempt);

/**
 * @brief: Store the Wi-Fi connection attempt in the list.
 * @param[in] FfsWifiContext_t*
 * @param[in] FfsWifiConnectionAttempt_t *
 * @return FFS_RESULT
 */
FFS_RESULT ffsWifiConnectionAttemptListPush(FfsWifiContext_t *wifiContext, FfsWifiConnectionAttempt_t *connectionAttempt)
{
    if (!wifiContext || !connectionAttempt)
    {
        ffsLogError("input params find NULL");
        FFS_FAIL(FFS_OVERRUN);
    }

    FfsWifiConnectionAttempt_t *cloneConnectionAttempt;
    FFS_CHECK_RESULT(ffsCloneWifiConnectionAttempt(connectionAttempt, &cloneConnectionAttempt));

    FFS_CHECK_RESULT(ffsLinkedListPushBack(&wifiContext->connectionAttemptList, (FfsLinkedListData_t *)cloneConnectionAttempt));

    return FFS_SUCCESS;
}

/**
 * @brief: Retrieves the next Wi-Fi connection attempt in the list, without removing it.
 * @param[in] FfsWifiContext_t*
 * @param[out] FfsWifiConnectionAttempt_t **
 * @return FFS_RESULT
 */
FFS_RESULT ffsWifiConnectionAttemptListPeek(FfsWifiContext_t *wifiContext, FfsWifiConnectionAttempt_t **connectionAttempt)
{
    if (!wifiContext)
    {
        ffsLogError("input params find NULL");
        FFS_FAIL(FFS_OVERRUN);
    }
    FfsLinkedListData_t *connectionAttemptData;
    FFS_CHECK_RESULT(ffsLinkedListPeekFront(&wifiContext->connectionAttemptList, &connectionAttemptData));

    *connectionAttempt = (FfsWifiConnectionAttempt_t *)connectionAttemptData;

    return FFS_SUCCESS;
}

/**
 * @brief: Removes the next Wi-Fi connection attempt from the list.
 * @param[in] FfsWifiContext_t*
 * @return FFS_RESULT
 */
FFS_RESULT ffsWifiConnectionAttemptListPop(FfsWifiContext_t *wifiContext)
{
    if (!wifiContext)
    {
        ffsLogError("input params find NULL");
        FFS_FAIL(FFS_OVERRUN);
    }

    FfsLinkedListData_t *connectionAttemptData;
    FFS_CHECK_RESULT(ffsLinkedListPopFront(&wifiContext->connectionAttemptList, &connectionAttemptData));

    FfsWifiConnectionAttempt_t *connectionAttempt = (FfsWifiConnectionAttempt_t *)connectionAttemptData;
    FFS_CHECK_RESULT(ffsFreeWifiConnectionAttempt(connectionAttempt));

    return FFS_SUCCESS;
}

/**
 * @brief: Removes all the Wi-Fi connection attempts from the list and frees the resources.
 * @param[in] FfsWifiContext_t*
 * @return FFS_RESULT
 */
FFS_RESULT ffsWifiConnectionAttemptListClear(FfsWifiContext_t *wifiContext)
{
    if (!wifiContext)
    {
        ffsLogError("input params find NULL");
        FFS_FAIL(FFS_OVERRUN);
    }
    while (true)
    {
        bool isEmpty;
        FFS_CHECK_RESULT(ffsWifiConnectionAttemptListIsEmpty(wifiContext, &isEmpty));

        if (isEmpty)
        {
            break;
        }

        FFS_CHECK_RESULT(ffsWifiConnectionAttemptListPop(wifiContext));
    }

    return FFS_SUCCESS;
}

/**
 * @brief: Checks if the Wi-Fi connection attempt list is empty.
 * @param[in] FfsWifiContext_t*
 * @param[in] bool *
 * @return FFS_RESULT
 */
FFS_RESULT ffsWifiConnectionAttemptListIsEmpty(FfsWifiContext_t *wifiContext, bool *isEmpty)
{
    if (!wifiContext || !isEmpty)
    {
        ffsLogError("input params find NULL");
        FFS_FAIL(FFS_OVERRUN);
    }
    *isEmpty = ffsLinkedListIsEmpty(&wifiContext->connectionAttemptList);

    return FFS_SUCCESS;
}

/**
 * @brief: Clones a Wi-Fi connection attempt.
 * @param[in] FfsWifiConnectionAttempt_t*
 * @param[out] FfsWifiConnectionAttempt_t **
 * @return FFS_RESULT
 */
static FFS_RESULT ffsCloneWifiConnectionAttempt(FfsWifiConnectionAttempt_t *connectionAttempt,
                                                FfsWifiConnectionAttempt_t **cloneConnectionAttempt)
{
    if (!connectionAttempt)
    {
        ffsLogError("input params find NULL");
        FFS_FAIL(FFS_OVERRUN);
    }
    FfsWifiConnectionAttempt_t *clone = (FfsWifiConnectionAttempt_t *)vesync_malloc(sizeof(FfsWifiConnectionAttempt_t));
    if (!clone)
    {
        FFS_FAIL(FFS_OVERRUN);
    }

    size_t ssidLength = FFS_STREAM_DATA_SIZE(connectionAttempt->ssidStream);

    uint8_t *ssidBuffer = (uint8_t *)vesync_malloc(ssidLength);
    if (!ssidBuffer)
    {
        VCOM_SAFE_FREE(clone);
        FFS_FAIL(FFS_OVERRUN);
    }

    clone->ssidStream = ffsCreateOutputStream(ssidBuffer, ssidLength);

    FfsStream_t copyStream = connectionAttempt->ssidStream;
    FFS_CHECK_RESULT(ffsAppendStream(&copyStream, &clone->ssidStream));

    clone->securityProtocol = connectionAttempt->securityProtocol;
    clone->state = connectionAttempt->state;
    clone->hasErrorDetails = connectionAttempt->hasErrorDetails;
    clone->errorDetails = connectionAttempt->errorDetails;

    *cloneConnectionAttempt = clone;

    return FFS_SUCCESS;
}

/**
 * @brief: Frees a Wi-Fi connection attempt.
 * @param[in] FfsWifiConnectionAttempt_t*
 * @return FFS_RESULT
 */
static FFS_RESULT ffsFreeWifiConnectionAttempt(FfsWifiConnectionAttempt_t *connectionAttempt)
{

    if (!connectionAttempt)
    {
        ffsLogError("input params find NULL");
        return FFS_SUCCESS;
    }
    VCOM_SAFE_FREE(FFS_STREAM_BUFFER(connectionAttempt->ssidStream));
    VCOM_SAFE_FREE(connectionAttempt);

    return FFS_SUCCESS;
}
