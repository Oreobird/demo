/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        demo_https_netcfg.c
 * @brief       https配网示例
 * @author      Joshua
 * @date        2021-10-17
 */
#include <string.h>
#include "vesync_log.h"
#include "vesync_frame.h"
#include "vesync_ble.h"
#include "vesync_netcfg.h"
#include "demo_https_netcfg.h"
#include "vesync_device.h"

/**
 * @brief  BLE数据帧接收回调
 * @param[in]  frame            [ble接收的数据帧]
 */
static void demo_ble_frame_recv_cb(tl_frame_recv_info_t *frame)
{
    tl_payload_info_t *p_payload_info;

    uint16_t receive_data_len = frame->payload_len - 4;

    if (frame->payload_len >= 4)
    {
        p_payload_info = (tl_payload_info_t *)frame->p_payload;
        APP_LOG(LOG_INFO, "op_code : %04X , len: %d \n", p_payload_info->op_code, receive_data_len);

        switch (p_payload_info->op_code)
        {
            case 0x8019:
            {
                uint8_t pbuf[5];
                uint8_t error_flag = 0;
                memset(pbuf, 0, 5);
                pbuf[0] = 1;
                pbuf[1] = 0x19;
                pbuf[2] = 0x80;

                pbuf[3] = pbuf[4] = error_flag;
                vesync_ble_send_cmd_ack(pbuf, 5, error_flag);

                vesync_netcfg_start();
                break;
            }
            case 0x4129:
            {
                uint8_t pbuf[5];
                uint8_t error_flag = 0;
                memset(pbuf, 0, 5);
                pbuf[0] = 1;
                pbuf[1] = 0x29;
                pbuf[2] = 0x41;

                pbuf[3] = pbuf[4] = error_flag;
                vesync_ble_send_cmd_ack(pbuf, 5, error_flag);
                vesync_device_factory_reset(false, STAT_CHG_RSN_BP_APP_STR);
                break;
            }
            default:
                break;
        }
    }
}


/**
 * @brief  配网初始化
 */
void demo_netcfg_init(void)
{
    vesync_ble_reg_cmd_recv_cb(demo_ble_frame_recv_cb);
}


