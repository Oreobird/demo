/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file    vhal_ble_cmd_service.c
 * @brief   蓝牙hal命令通信服务
 * @date    2021-09-03
 */

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#include "vhal_ble_internal.h"
#include "vhal_ble_cmd_service.h"
#include "gap.h"
#include "gatt.h"
#include "profile_server.h"

static P_FUN_SERVER_GENERAL_CB ble_service_cb = NULL;
static T_SERVER_ID s_cmd_service_id;

/**
 * @brief 设备应用通信服务 业务逻辑交互通道
 */
const T_ATTRIB_APPL cmd_gatt_db[IDX_CMD_NB] =
{
    [IDX_CMD_SVC] =
    {
        (ATTRIB_FLAG_VALUE_INCL | ATTRIB_FLAG_LE),   /* wFlags */
        {   /* bTypeValue */
            LO_WORD(GATT_UUID_PRIMARY_SERVICE),
            HI_WORD(GATT_UUID_PRIMARY_SERVICE),
            LO_WORD(GATTS_SERVICE_CMD_UUID),              /* service UUID */
            HI_WORD(GATTS_SERVICE_CMD_UUID)
        },
        UUID_16BIT_SIZE,                            /* bValueLen */
        NULL,                                       /* pValueContext */
        GATT_PERM_READ                              /* wPermissions */
    },

    [IDX_CHAR_CMD_NOTIFY] =
    {
        ATTRIB_FLAG_VALUE_INCL,                     /* flags */
        {                                          /* type_value */
            LO_WORD(GATT_UUID_CHARACTERISTIC),
            HI_WORD(GATT_UUID_CHARACTERISTIC),
            (GATT_CHAR_PROP_NOTIFY)                 /* characteristic properties */
            /* characteristic UUID not needed here, is UUID of next attrib. */
        },
        1,                                          /* bValueLen */
        NULL,
        GATT_PERM_READ                              /* permissions */
    },

    [IDX_CHAR_VAL_CMD_NOTIFY] =
    {
        ATTRIB_FLAG_VALUE_APPL,                     /* flags */
        {                                         /* type_value */
            LO_WORD(GATTS_CHAR_CMD_NOTIFY_UUID),
            HI_WORD(GATTS_CHAR_CMD_NOTIFY_UUID)
        },
        0,                                          /* bValueLen */
        NULL,
        GATT_PERM_NONE                              /* permissions */
    },

    /* client characteristic configuration */
    [IDX_CHAR_CCCD_CMD_NOTIFY] =
    {
        ATTRIB_FLAG_VALUE_INCL | ATTRIB_FLAG_CCCD_APPL,                 /* flags */
        {                                          /* type_value */
            LO_WORD(GATT_UUID_CHAR_CLIENT_CONFIG),
            HI_WORD(GATT_UUID_CHAR_CLIENT_CONFIG),
            /* NOTE: this value has an instantiation for each client, a write to */
            /* this attribute does not modify this default value: */
            LO_WORD(GATT_CLIENT_CHAR_CONFIG_DEFAULT), /* client char. config. bit field */
            HI_WORD(GATT_CLIENT_CHAR_CONFIG_DEFAULT)
        },
        2,                                          /* bValueLen */
        NULL,
        (GATT_PERM_READ | GATT_PERM_WRITE)          /* permissions */
    },

    [IDX_CHAR_CMD_WRITE] =
    {
        ATTRIB_FLAG_VALUE_INCL,                     /* wFlags */
        {   /* bTypeValue */
            LO_WORD(GATT_UUID_CHARACTERISTIC),
            HI_WORD(GATT_UUID_CHARACTERISTIC),
            (GATT_CHAR_PROP_WRITE | GATT_CHAR_PROP_WRITE_NO_RSP), /* characteristic properties */
        },
        1,                                          /* bValueLen */
        NULL,
        GATT_PERM_READ                              /* wPermissions */
    },

    [IDX_CHAR_VAL_CMD_WRITE] =
    {
        ATTRIB_FLAG_VALUE_APPL,                     /* wFlags */
        {   /* bTypeValue */
            LO_WORD(GATTS_CHAR_CMD_WRITE_UUID),
            HI_WORD(GATTS_CHAR_CMD_WRITE_UUID)
        },
        0,                                          /* variable size */
        NULL,
        GATT_PERM_WRITE             /* wPermissions */
    },
};

/**
 * @brief write characteristic data from service.
 * @param[in] conn_id
 * @param[in] service_id        [ServiceID to be written]
 * @param[in] attrib_index      [Attribute index of characteristic]
 * @param[in] length            [length of value to be written]
 * @param[in] p_value           [value to be written]
 * @return T_APP_RESULT         [Profile procedure result]
*/
static T_APP_RESULT ble_service_attr_write_cb(uint8_t conn_id, T_SERVER_ID service_id,
                                            uint16_t attrib_index, T_WRITE_TYPE write_type, uint16_t length, uint8_t *p_value,
                                            P_FUN_WRITE_IND_POST_PROC *p_write_ind_post_proc)
{
    vhal_ble_service_cb_data_t callback_data;
    T_APP_RESULT  cause = APP_RESULT_SUCCESS;

    *p_write_ind_post_proc = NULL;
    if (IDX_CHAR_VAL_CMD_WRITE == attrib_index)
    {
        /* Make sure written value size is valid. */
        if (p_value == NULL)
        {
            cause  = APP_RESULT_INVALID_VALUE_SIZE;
        }
        else
        {
            /* Notify Application. */
            callback_data.msg_type = SERVICE_CALLBACK_TYPE_WRITE_CHAR_VALUE;
            callback_data.conn_id  = conn_id;
            callback_data.msg_data.write.write_index = attrib_index;
            callback_data.msg_data.write.write_type = write_type;
            callback_data.msg_data.write.len = length;
            callback_data.msg_data.write.p_value = p_value;

            if (ble_service_cb)
            {
                ble_service_cb(service_id, (void *)&callback_data);
            }
        }
    }
    else
    {
        cause = APP_RESULT_ATTR_NOT_FOUND;
    }
    return cause;
}

/**
 * @brief read characteristic data from service.
 * @param[in]  service_id       [ServiceID of characteristic data]
 * @param[in]  attrib_index     [Attribute index of getting characteristic data]
 * @param[in]  offset           [Used for Blob Read]
 * @param[in]  p_length         [length of getting characteristic data]
 * @param[out] pp_value         [data got from service]
 * @return T_APP_RESULT         [Profile procedure result]
*/
static T_APP_RESULT ble_service_attr_read_cb(uint8_t conn_id, T_SERVER_ID service_id,
                                            uint16_t attrib_index, uint16_t offset, 
                                            uint16_t *p_length, uint8_t **pp_value)
{
    (void)offset;
    T_APP_RESULT  cause  = APP_RESULT_SUCCESS;

    switch (attrib_index)
    {
        default:
            cause = APP_RESULT_ATTR_NOT_FOUND;
            break;
    }

    return (cause);
}

/**
 * @brief update CCCD bits from stack.
 * @param[in] conn_id           [connection id]
 * @param[in] service_id        [Service ID]
 * @param[in] index             [Attribute index of characteristic data]
 * @param[in] cccbits           [CCCD bits from stack]
*/
static void ble_service_cccd_update_cb(uint8_t conn_id, T_SERVER_ID service_id, uint16_t index, uint16_t cccbits)
{
    vhal_ble_service_cb_data_t callback_data;

    callback_data.conn_id = conn_id;
    callback_data.msg_type = SERVICE_CALLBACK_TYPE_INDIFICATION_NOTIFICATION;
    callback_data.msg_data.cccd.cccd_index = index;
    callback_data.msg_data.cccd.cccd_val = cccbits;

    if (ble_service_cb)
    {
        ble_service_cb(service_id, (void *)&callback_data);
    }
}

/**
 * @brief ble Service Callbacks.
*/
static const T_FUN_GATT_SERVICE_CBS ble_service_cbs =
{
    ble_service_attr_read_cb,  // Read callback function pointer
    ble_service_attr_write_cb, // Write callback function pointer
    ble_service_cccd_update_cb // CCCD update callback function pointer
};

/**
 * @brief 发送通知
 * @param[in] conn_id       [连接id]
 * @param[in] p_value       [发送数据指针]
 * @param[in] length        [发送数据长度]
 * @return bool             [true表示成功,false表示失败]
 */
bool vhal_ble_cmd_service_notify(uint8_t conn_id, uint8_t *p_value, uint16_t length)
{
    return server_send_data(conn_id, s_cmd_service_id, IDX_CHAR_VAL_CMD_NOTIFY, p_value, length, GATT_PDU_TYPE_NOTIFICATION);
}

/**
 * @brief 命令服务添加
 * @param[in] p_func        [命令服务回调]
 * @return bool             [true表示成功,false表示失败]
 */
bool vhal_ble_cmd_service_add(void *p_func)
{
    ble_service_cb = (P_FUN_SERVER_GENERAL_CB)p_func;

    return server_add_service(&s_cmd_service_id,(uint8_t *)cmd_gatt_db,sizeof(cmd_gatt_db),ble_service_cbs);
}
