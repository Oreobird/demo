/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_bypass_timebase.c
 * @brief       Bypass Timebase接口定义
 * @author      Herve Lin
 * @date        2021-08-23
 */
#include <stdio.h>
#include <string.h>

#include "cJSON.h"

#include "vesync_bypass_internal.h"
#include "vesync_timebase_internal.h"

#include "vesync_common.h"
#include "vesync_memory.h"

/**
 * @brief 生成Timebase Info的JSON
 * @param[in]   json                    [JSON根对象]
 * @param[in]   p_tb_info               [指向Timebase Info]
 * @return      int                     [BYPASS_ERR_E]
 */
static BYPASS_ERR_E timebase_info_json_marshal(cJSON *json, int type, vesync_timebase_t *p_tb_info)
{
    if (!cJSON_IsObject(json))
    {
        return BP_ERROR;
    }

    switch (type)
    {
    case TIMEBASE_JSON_TYPE_ALL:
        // fall-through
    case TIMEBASE_JSON_TYPE_TZ_INFO:
        // fall-through
    case TIMEBASE_JSON_TYPE_SUN_INFO:
        // fall-through
    case TIMEBASE_JSON_TYPE_DST_INFO:
        break;
    default:
        return BP_ERROR;
    }

    cJSON *sub_obj = NULL, *sub_obj_1 = NULL;
    cJSON_AddNumberToObject(json, "type", type);
    if (TIMEBASE_JSON_TYPE_ALL == type || TIMEBASE_JSON_TYPE_TZ_INFO == type)
    {
        sub_obj = cJSON_AddObjectToObject(json, "tzInfo");
        if (!cJSON_IsObject(sub_obj))
        {
            return BP_ERROR;
        }
        cJSON_AddStringToObject(sub_obj, "zoneStr", p_tb_info->tz_info.timezone_str);
        cJSON_AddNumberToObject(sub_obj, "ofsSec", p_tb_info->tz_info.timezone_ofs_sec);
    }
    if (TIMEBASE_JSON_TYPE_ALL == type || TIMEBASE_JSON_TYPE_SUN_INFO == type)
    {
        sub_obj = cJSON_AddObjectToObject(json, "sunRsInfo");
        if (!cJSON_IsObject(sub_obj))
        {
            return BP_ERROR;
        }
        sub_obj_1 = cJSON_AddObjectToObject(sub_obj, "loc");
        if (!cJSON_IsObject(sub_obj_1))
        {
            return BP_ERROR;
        }
        cJSON_AddNumberToObject(sub_obj_1, "lng", p_tb_info->sun_rs_info.longitude);
        cJSON_AddNumberToObject(sub_obj_1, "lat", p_tb_info->sun_rs_info.latitude);
        cJSON_AddNumberToObject(sub_obj_1, "alt", p_tb_info->sun_rs_info.altitude);
        sub_obj_1 = cJSON_AddObjectToObject(sub_obj, "sunTime");
        if (!cJSON_IsObject(sub_obj_1))
        {
            return BP_ERROR;
        }
        cJSON_AddNumberToObject(sub_obj_1, "riseUTC", p_tb_info->sun_rs_info.sun_rise_utc);
        cJSON_AddNumberToObject(sub_obj_1, "setUTC", p_tb_info->sun_rs_info.sun_set_utc);
    }
    if (TIMEBASE_JSON_TYPE_ALL == type || TIMEBASE_JSON_TYPE_DST_INFO == type)
    {
        sub_obj = cJSON_AddObjectToObject(json, "dstInfo");
        if (!cJSON_IsObject(sub_obj))
        {
            return BP_ERROR;
        }
        cJSON_AddBoolToObject(sub_obj, "enabled", p_tb_info->dst_info.enabled);
        cJSON_AddNumberToObject(sub_obj, "curOfsSec", p_tb_info->dst_info.cur_ofs_sec);
        cJSON_AddNumberToObject(sub_obj, "dstSwUTC", p_tb_info->dst_info.dst_sw_utc);
        cJSON_AddNumberToObject(sub_obj, "nextOfsSec", p_tb_info->dst_info.next_ofs_sec);
    }
    return BP_OK;
}

/**
 * @brief "getUserTimeBaseInfo" method数据解析
 * @param[in]   p_msg_ctx               [msg context]
 * @param[in]   json                    [json数据指针]
 * @return      BYPASS_ERR_E            [错误码]
 */
static BYPASS_ERR_E bypass_method_get_timebase_info_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    int type = TMBS_NONE;

    cJSON *json_data = NULL;
    cJSON *json_ret = NULL;

    json_data = cJSON_GetObjectItemCaseSensitive(json, "type");
    if (cJSON_IsNumber(json_data))
    {
        type = json_data->valueint;
    }
    else
    {
        p_msg_ctx->resp_error_code = BP_ERR_PARA_ILLEGAL;
        goto EXIT;
    }

    vesync_timebase_t tb_info;
    if (TMBS_OK != vesync_timebase_get(&tb_info))
    {
        p_msg_ctx->resp_error_code = BP_ERR_UNDEFINE;
        goto EXIT;
    }
    json_ret = cJSON_CreateObject();
    if (NULL != json_ret)
    {
        p_msg_ctx->resp_error_code = BP_ERR_OUT_OF_MEMORY;
        goto EXIT;
    }
    if (BP_OK != timebase_info_json_marshal(json_ret, type, &tb_info))
    {
        p_msg_ctx->resp_error_code = BP_ERR_PARA_ILLEGAL;
        goto EXIT;
    }
    p_msg_ctx->p_response = json_ret;

EXIT:
    if (p_msg_ctx->resp_error_code != BP_ERR_NO_ERR)
    {
        cJSON_Delete(json_ret);
    }
    return BP_OK;
}

/**
 * @brief "updUserTimeBaseInfo" method数据解析
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  json                     [json数据指针]
 * @return BYPASS_ERR_E                 [错误码]
 */
static BYPASS_ERR_E bypass_method_update_timebase_info_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    vesync_timebase_t tb_info;
    if (TMBS_OK != vesync_timebase_get(&tb_info))
    {
        p_msg_ctx->resp_error_code = BP_ERR_UNDEFINE;
        goto EXIT;
    }
    TMBS_INFO_TYPE_E type = TMBS_NONE;
    if (TMBS_OK != vesync_timebase_bp_tb_info_parse(json, &type, &tb_info))
    {
        p_msg_ctx->resp_error_code = BP_ERR_PARA_ILLEGAL;
        goto EXIT;
    }
    if (TMBS_OK != vesync_timebase_update(&tb_info))
    {
        p_msg_ctx->resp_error_code = BP_ERR_CMD_EXECUTE_FAIL;
        goto EXIT;
    }

    timebase_info_upd_ntf_cb_t upd_cb = vesync_timebase_get_reg_info_upd_cb();
    if (upd_cb != NULL)
    {
        upd_cb(type);
    }

EXIT:
    return BP_OK;
}

#if defined(PR_FW_TYPE) && (PR_FW_TYPE == 0)
/**
 * @brief "setUserTimeBaseInfoUpd" method数据解析
 * @note    调试命令
 * @param[in]   p_msg_ctx               [msg context]
 * @param[in]   json                    [json数据指针]
 * @return      BYPASS_ERR_E            [错误码]
 */
static BYPASS_ERR_E bypass_method_set_timebase_upd_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    cJSON *json_data = cJSON_GetObjectItemCaseSensitive(json, "enabled");
    if (!cJSON_IsBool(json_data))
    {
        p_msg_ctx->resp_error_code = BP_ERR_PARA_ILLEGAL;
        goto EXIT;
    }

    bool en = (bool)json_data->valueint;
    if (TMBS_OK != vesync_timebase_set_auto_update(en))
    {
        p_msg_ctx->resp_error_code = BP_ERR_CMD_EXECUTE_FAIL;
        goto EXIT;
    }

EXIT:
    return BP_OK;
}
#endif

static bypass_item_data_t timebase_method_tbl[] = {
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_UPD_TIMEBASE_INFO, "updUserTimeBaseInfo", bypass_method_update_timebase_info_handle, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_GET_TIMEBASE_INFO, "getUserTimeBaseInfo", bypass_method_get_timebase_info_handle, NULL},
#if defined(PR_FW_TYPE) && (PR_FW_TYPE == 0)
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_SET_TIMEBASE_UPD, "setUserTimeBaseInfoUpd", bypass_method_set_timebase_upd_handle, NULL},
#endif
};

void vesync_bypass_timebase_init(void)
{
    for (int i = 0; i < SIZEOF_ARRAY(timebase_method_tbl); i++)
    {
        bypass_item_t *item = vesync_bypass_init_item(&timebase_method_tbl[i]);
        if (item != NULL)
        {
            vesync_bypass_add_item(item);
        }
    }
}
