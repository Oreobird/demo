/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_net_mqtt_internal.h
 * @brief       mqtt网络服务头文件
 * @author      CharlesMei
 * @date        2021-05-25
 */

#ifndef __VESYNC_NET_MQTT_INTERNAL_H__
#define __VESYNC_NET_MQTT_INTERNAL_H__


#include <stdint.h>
#include <stdbool.h>

#include "vesync_mqtt_config.h"
#include "vesync_mqtt_internal.h"
#include "vesync_event_internal.h"
#include "vesync_net_service_private.h"

#ifdef __cplusplus
extern "C"
{
#endif

#define VERR_UPLOAD(x, y)

/* The above is the redirection of the interface called by this module */
#define MQTT_OFFLINE_MSG_TOPIC          "cloud/mqtt/offlineMessage"  // 云下发设备离线消息统一topic
#define MAX_MQTT_TOPIC_LEN              (64)  // mqtt topic最大长度
#define MQTT_DEFAULT_PORT               (MQTT_TCP_DEFAULT_PORT)

/**
 * @brief  MQTT主题定义
 */
#if defined(PR_REPORT_PROTOCOL_VER) && (PR_REPORT_PROTOCOL_VER == 3)      // v3版本协议，topic不带cid
#define MQTT_TOPIC_PREFIX              "mqtt/v%d/%s"
#else
#define MQTT_TOPIC_PREFIX              "mqtt/%s/v%d/%s"
#endif
#define TOPIC_STR_REQ                  "req"
#define TOPIC_STR_RSP                  "rsp"
#define TOPIC_STR_BYPASS               "bypass"
#define TOPIC_STR_BYPASS_RSP           "bypass/rsp"
#define TOPIC_STR_DATA                 "data"
#define TOPIC_STR_LOG                  "log"

// primary dns default 8.8.8.8
#ifndef PR_DNS_PRIMARY
#define DNS_PRIMARY                     "8.8.8.8"
#else
#define DNS_PRIMARY                     PR_DNS_PRIMARY
#endif
// secondary dns default 8.8.4.4
#ifndef PR_DNS_SECONDARY
#define DNS_SECONDARY                   "8.8.4.4"
#else
#define DNS_SECONDARY                   PR_DNS_SECONDARY
#endif

/**
 * @brief  bypass数据处理
 */
#define VNET_DATA_RECV_BYPASS_CB(p_data)            \
    do                                              \
    {                                               \
        if (NULL != s_mqtt_data_recv_bypass_cb)     \
        {                                           \
            s_mqtt_data_recv_bypass_cb(p_data);     \
        }                                           \
    } while (0)


/**
 * @brief MQTT在线/离线状态
 */
typedef enum
{
    MQTT_OFFLINE = 0,       // MQTT连接断开
    MQTT_ONLINE,            // MQTT已连接服务器
} VESYNC_MQTT_STATUS_E;

/**
 * @brief mqtt topic type
 */
typedef enum {
    MQTT_TOPIC_REQ = 0,
    MQTT_TOPIC_RSP,
    MQTT_TOPIC_BYPASS,
    MQTT_TOPIC_BYPASS_RSP,
    MQTT_TOPIC_DATA,
    MQTT_TOPIC_LOG,
} MQTT_TOPIC_TYPE_E;


/**
 * @brief  mqtt客户端设置
 * @param[in]  p_cli                [客户端结构体指针]
 * @return  int                     [成功：VERR_OK，失败：VERR_FAIL]
 */
int vesync_net_mqtt_cli_setup(vnet_cli_t *p_cli);

#ifdef __cplusplus
}
#endif

#endif  /* __VESYNC_NET_MQTT_INTERNAL_H__ */

