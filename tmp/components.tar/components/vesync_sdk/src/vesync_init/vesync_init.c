/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_init.c
 * @brief       SDK初始化接口
 * @author      Joshua
 * @date        2021-04-22
 */

#include <stdio.h>

#include "vhal_utils.h"
#include "vesync_common.h"
#include "vesync_task.h"
#include "vesync_init_internal.h"
#include "vesync_log_internal.h"
#include "vesync_device_internal.h"
#include "vesync_event.h"
#include "vesync_bypass.h"
#include "vesync_flash.h"
#include "vesync_ota_internal.h"
#include "vesync_report.h"
//#include "vesync_wifi.h"
#include "vesync_wifi_led.h"

/**
 * @brief vesync平台入口
 * @param args [无]
 */
void vesync_sdk_entry(void *args)
{
    UNUSED(args);

    vesync_flash_init();

    vesync_log_init(LOG_DEBUG);

    vesync_device_init();

    vesync_event_init();

    //vesync_wifi_init();

    veysnc_bypass_init();

    vesync_report_init();

    vesync_wifi_led_init();

    vesync_ota_init();

    vhal_utils_start_sntp();    // 初始化SNTP服务(必须在Wi-Fi初始化后面)

    vesync_device_print_info();
}

/*
 * @brief  vesync sdk 初始化
 * @return int                         [成功：0；失败：-1]
*/
int vesync_sdk_init(void)
{
    int ret = SDK_FAIL;
    ret = vesync_task_new(VESYNC_TASK_NAME, vesync_sdk_entry, NULL, VESYNC_TASK_STACKSIZE, VESYNC_TASK_PRIO, NULL);
    return ret;
}


