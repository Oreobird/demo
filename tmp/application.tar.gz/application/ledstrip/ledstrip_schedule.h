/**
*Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file    ledstrip_schedule.h
* @brief   schedule模块
* @author  Lind
* @date     2021-09-08
*/

#ifndef __LEDSTRIP_SCHEDULE_H__
#define __LEDSTRIP_SCHEDULE_H__

#include <stdint.h>

#include "vesync_schedule.h"
#include "vesync_buffer.h"
#include "vesync_bypass.h"

#include "ledstrip_led.h"

#ifdef __cplusplus
extern "C" {
#endif


#define LS_SCHEDULE_MIN_ID (100)             // Schedule最小ID
#define LS_SCHEDULE_MAX_NUM (26)             // Schedule最大条目数
#define LS_SCHEDULE_GET_MAX_NUM (6)          // 一次Schedule查询最大的返回数量
#define LS_SCHEDULE_MAX_APP_CFG_SIZE (64)    // 配置读取Buffer大小

#define LS_SCHE_INS_ID 0    // ledstrip Schedule实例ID

#define LS_SCHE_SUNEVT_MAX_SEC          3600    // schedule限制日出后1h
#define LS_SCHE_SUNEVT_MIN_SEC          -3600   // schedule限制日出前1h

/*
 * @brief schedule应用层配置数据key 定义
 */
typedef enum
{
    LS_SCHE_KLV_MODE = 0,
    LS_SCHE_KLV_HSV  = 1
} LS_SCHE_KLV_KEY_E;

/**
* @brief 初始化Schedule功能
* @return int  [返回APP的错误定义： APP_OK, APP_FAIL]
*/
int ls_schedule_init(void);

/**
* @brief Bypass添加Schedule配置项
* @param[in]  p_bp_msg     [Bypass添加的Schedule配置项信息]
* @param[out] p_out_id     [添加成功后，返回生成的ID]
* @return int              [返回BYPASS的错误定义]
*/
int ls_schedule_add(bypass_schedule_base_t *p_bp_msg, uint32_t *p_out_id);

/**
* @brief Bypass更新Schedule配置项
* @param[in]  p_bp_msg     [Bypass需要修改的相关Schedule配置项信息，注意有的字段是可选的]
* @param[out] p_out_id     [更新Schedule配置项后返回对于的配置项ID]
* @return int              [返回BYPASS的错误定义]
*/
int ls_schedule_upd(bypass_schedule_base_t *p_bp_msg, uint32_t *p_out_id);

/**
* @brief Bypass按顺序获取Schedule多个配置项
* @note  返回多少个连续的配置项是由Schedule模块决定
* @param[in]  index        [要获取的Schedule配置项的初始序号]
* @param[in]  p_buf        [用于读取Schedule配置项的缓存，函数内会作缓存的分配,调用结束后需要释放]
* @param[out] p_out_list   [指向输出读取结果的列表]
* @param[in]  total_num    [配置项总数]
* @return int              [返回BYPASS的错误定义]
*/
int ls_schedule_get_mult(uint32_t index, void **p_buf, bypass_schedule_base_t *p_out_list, uint32_t *total_num);

/**
* @brief Bypass删除指定ID的Schedule配置项
* @param[in]  id_to_del    [要删除的Schedule配置项ID]
* @return int              [返回BYPASS的错误定义]
*/
int ls_schedule_del(uint32_t id_to_del);

/**
* @brief App层调用，复位Schedule的所有配置信息
* @return int [返回APP的错误定义： APP_OK, APP_FAIL]
*/
int ls_schedule_clear(void);



#ifdef __cplusplus
}
#endif

#endif


