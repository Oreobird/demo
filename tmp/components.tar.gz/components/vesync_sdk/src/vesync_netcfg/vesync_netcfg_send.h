/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_netcfg_send.h
 * @brief       配网模块的发送接口
 * @author      Louis
 * @date        2021-05-21
 */

#ifndef __VESYNC_NETCFG_SEND_H__
#define __VESYNC_NETCFG_SEND_H__

#include "cJSON.h"

#ifdef __cplusplus
extern "C" {
#endif

// LAN协议头定义
#define LAN_PROT_HEADER_LEN         8       // 局域网通信协议头部长度
#define LAN_PROT_VER                0x01    // 局域网通信协议，协议版本默认值0x01
#define LAN_PROT_SERV_TYPE          0x01    // 局域网通信协议，业务类型默认值0x01


/*
 * @brief 设备发给APP的消息类型
 */
typedef enum
{
    MTYPE_ACK = 0,      // 设备回复APP
    MTYPE_REPORT,       // 设备上报消息给APP
    MTYPE_LOG           // 上报配网日志
}NETCFG_MTYPE_E;



/**
 * @brief  局域网TCP/UDP通信协议
 * @note   参考：http://wiki.vesync.com:8090/pages/viewpage.action?pageId=52592791
 */
typedef struct
{
    uint8_t protocol;                   // 协议版本(Protocol), 1byte
    uint8_t serv_type;                  // 业务类型(ServiceType), 1byte
    uint16_t seq_id;                    // 序列号，从0开始自增(SequenceId), 1byte
    uint32_t data_len;                  // 数据包长度（Data部分的字节数，采用网络字节序）, 4byte
    uint8_t p_data;                     // 数据(包括业务数据头部)
}lan_trans_header_t;


/**
 * @brief 配网模块统一的发送接口
 * @param[in]  opcode               [操作码]
 * @param[in]  mtype                [数据类型]
 * @param[in]  json_data            [json数据指针]
 * @return    int                   [成功或失败]
 */
void vesync_netcfg_send_data(uint16_t opcode, NETCFG_MTYPE_E mtype, cJSON *json_data);

/**
 * @brief 返回协议层错误
 * @param[in]  opcode               [操作码]
 * @param[in]  status_code          [状态码]
 */
void vesync_netcfg_send_error(uint16_t opcode, uint16_t status_code);

/**
 * @brief 配网状态上报
 * @param[in]  msg                  [附加的消息内容，格式和内容各阶段事件自定义；NULL则无附加消息]
 */
void vesync_netcfg_report_status(const char* msg);

/**
 * @brief WIFI断开连接时HAL WIFI传递错误码和错误描述的callback
 * @param[in]  reason_name      [错误描述]
 */
void vesync_netcfg_report_wifi_disconnect(const char* reason_name);

#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_NETCFG_SEND_H__ */

