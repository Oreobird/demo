/**
 * Copyright © Etekcity Technologies Co., Ltd. 2021. All rights reserved.
 * @file        vesync_certificate.h
 * @brief       处理ffs 证书以及相关设备私钥更新
 * @author      Owen.zhang
 * @date        2020-03-02
 */
#ifndef _VESYNC_CERTIFICATE_H_
#define _VESYNC_CERTIFICATE_H_

#include "vesync_http_internal.h"
#include "vesync_task.h"


#ifdef __cplusplus
extern "C"
{
#endif

#define MAX_FFS_CERT_URL_LEN                (256) // 下载固件的URL最大长度
#define FFS_CERT_MD5_SIZE                   (32 + 1)

#define CERTIFICATE_UPDATE_TASK_NAME        "ffs_cert_update"
#define CERTIFICATE_UPDATE_TASK_STACKSIZE   (1024 * 4)
#define CERTIFICATE_UPDATE_TASK_PRIO        TASK_PRIORITY_SOFT_REALTIME

/*
 * @brief FFS证书类型
 */
typedef enum
{
    FFS_CA,
    FFS_PRIVATE_KEY,
} FFS_CERT_E;

//#if CONFIG_VESYNC_SDK_HTTP_ENABLE
/*
 * @brief http证书下载请求配置
 */
typedef struct
{
    HTTP_GET_MODE_E get_mode;           // http请求方法
    char url[MAX_FFS_CERT_URL_LEN];     // http请求链接
    char md5[FFS_CERT_MD5_SIZE];        // 证书md5值
} ffs_update_certificate_info_t;

/*
 * @brief 证书更新结果
 */
typedef enum
{
    FFS_CERT_UP_OK = 0,
    FFS_CERT_UP_VERIFY_ERR = 1, //证书校验失败
    FFS_CERT_UP_DL_FAIL = 2,    //下载失败
    FFS_CERT_UP_TIMEOUT = 3,    //下载超时
    FFS_CERT_UP_PARSE_ERR = 4,  //证书解析失败
} FFS_CERT_UPDATE_E;


/**
* @brief  产测更新证书
* @param[in]  info    [更新证书信息]
* @return int         [成功/失败]
*/
int vesync_ffs_certificate_update_start(ffs_update_certificate_info_t info);
//#endif

#ifdef __cplusplus
}
#endif

#endif //_VESYNC_CERTIFICATE_H_
