/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file        switch_timing.c
* @brief       switch_timing配置
* @author      Charles.Mei
* @date        2021-08-04
*/


#include <string.h>
#include <stdio.h>

#include "vesync_common.h"
#include "vesync_log.h"
#include "vesync_timing.h"
#include "vesync_device.h"

#include "switch_app.h"
#include "switch_report.h"
#include "switch_uart_cmd.h"
#include "switch_timing.h"


/**
 * @brief switch timer定时配置
 */
typedef struct
{
    light_timing_t light;
    fan_timing_t fan;
} switch_timing_t;


#define SWITCH_TIMER_ID_MIN     0   // timer 最小di
#define SWITCH_TIMER_NUM_MAX    1   // 每个设备最多的timer数量


static switch_timing_t s_switch_timing;       // 保存timer

/**
 * @brief 根据设备id获取timer 最小id
 * @param[in]  设备id                   [dev_id]
 * @return     uint16_t                 [timer 最小id，为0时获取失败]
 */
static uint16_t get_timing_min_id(DEVICE_ID_E dev_id)
{
    if (dev_id >= DEVICE_MAX)
    {
        return 0;
    }
    // dev_id为0时代表主设备，目前没有此场景，为主设备预留id段
    return SWITCH_TIMER_ID_MIN + dev_id * SWITCH_TIMER_NUM_MAX;
}

/**
 * @brief 根据timer id获取设备id
 * @param[in]  timer_id                 [timer id]
 * @return     DEVICE_ID_E              [设备id]
 */
static DEVICE_ID_E get_dev_id_from_timing_id(uint16_t timer_id)
{
    if (timer_id >= SWITCH_TIMER_ID_MIN + DEVICE_MAX * SWITCH_TIMER_NUM_MAX)
    {
        return DEVICE_MAX;
    }
    return (DEVICE_ID_E)(timer_id - SWITCH_TIMER_ID_MIN) / SWITCH_TIMER_NUM_MAX;
}

/**
 * @brief timer时间到时执行的动作
 * @param[in]  uint16_t                 [timer id]
 * @return     void                     [none]
 */
static void switch_timing_act(uint16_t id)
{
    int ret = APP_FAIL;

    DEVICE_ID_E dev_id = DEVICE_MAX;
    if (id <= SWITCH_TIMER_ID_MIN)
    {
        return;
    }
    dev_id = get_dev_id_from_timing_id(id);

    switch (dev_id)
    {
        case DEVICE_LIGHT:
            if (id != s_switch_timing.light.id)
            {
                return;
            }
            if (false == s_switch_timing.light.action.onoff)
            {
                ret = switch_uart_set_switch(dev_id, 0, s_switch_timing.light.action.duration,
                    NULL);
            }
            else
            {
                // 以对应亮度开灯，直接调用设置亮度命令
                if (0 != s_switch_timing.light.action.lightness)
                {
                    ret = switch_uart_set_lightness(s_switch_timing.light.action.lightness,
                        s_switch_timing.light.action.duration, NULL);
                }
                else
                {
                    ret = switch_uart_set_switch(dev_id, 1, s_switch_timing.light.action.duration,
                        NULL);
                }
            }
            switch_app_update_status_chg_rsn(STAT_CHG_RSN_TIMER_STR);
            // timer执行结果上报服务器做记录
            switch_report_timing_exec(dev_id, &s_switch_timing.light.action, ret, "");
            switch_timing_remove(id);
            break;
        case DEVICE_FAN:
            if (id != s_switch_timing.fan.id)
            {
                return;
            }
            if (false == s_switch_timing.fan.action.onoff)
            {
                ret = switch_uart_set_switch(dev_id, 0, 0, NULL);
            }
            else
            {
                // 以对应档位开风扇，直接调用设置档位命令
                if (0 != s_switch_timing.fan.action.level)
                {
                    ret = switch_uart_set_level(dev_id, s_switch_timing.fan.action.level, 0, NULL);
                }
                else
                {
                    ret = switch_uart_set_switch(dev_id, 1, 0, NULL);
                }
            }
            switch_app_update_status_chg_rsn(STAT_CHG_RSN_TIMER_STR);
            // timer执行结果上报服务器做记录
            switch_report_timing_exec(dev_id, &s_switch_timing.fan.action, ret, "");
            switch_timing_remove(id);
            break;
        case DEVICE_ALL:
            // 暂不支持
        case DEVICE_MAX:
        default:
            return ;
    }
}

/**
 * @brief 新增一个timer
 * @param[in]   dev_id                  [设备id]
 * @param[in]   action                  [timer执行动作]
 * @param[in]   total_sec               [timer定时时间]
 * @param[out]  p_id                    [timer id]
 * @return      int_t                   [成功/失败]
 */
int switch_timing_add(DEVICE_ID_E dev_id, void* action, uint32_t total_sec, uint16_t *p_id)
{
    VCOM_NULL_PARAM_CHK(action, return APP_FAIL);
    VCOM_NULL_PARAM_CHK(p_id, return APP_FAIL);

    *p_id = get_timing_min_id(dev_id);
    switch (dev_id)
    {
        case DEVICE_LIGHT:
            if (0 != s_switch_timing.light.id)
            {
                APP_LOG(LOG_ERROR, "Timing exist\n");
                return APP_FAIL;
            }
            s_switch_timing.light.id = *p_id;
            memcpy(&s_switch_timing.light.action, (light_action_t*)action, sizeof(s_switch_timing.light.action));
            if (SDK_OK != vesync_timing_add(s_switch_timing.light.id, total_sec))
            {
                return APP_FAIL;
            }
            return APP_OK;
        case DEVICE_FAN:
            if (0 != s_switch_timing.fan.id)
            {
                APP_LOG(LOG_ERROR, "Timing exist\n");
                return APP_FAIL;
            }
            s_switch_timing.fan.id = *p_id;
            memcpy(&s_switch_timing.fan.action, (fan_action_t*)action, sizeof(s_switch_timing.fan.action));
            if (SDK_OK != vesync_timing_add(s_switch_timing.fan.id, total_sec))
            {
                return APP_FAIL;
            }
            return APP_OK;
        case DEVICE_ALL:
            //暂不支持主设备设置timer
        case DEVICE_MAX:
        default:
            return APP_FAIL;
    }

    return APP_FAIL;
}

/**
 * @brief 获取timer执行的动作
 * @param[out] dev_id                   [设备id]
 * @param[in]  action                   [timer执行的动作]
 * @return     int_t                    [成功/失败]
 */
int switch_timing_get_act(DEVICE_ID_E dev_id, const void **action)
{
    if (DEVICE_ALL == dev_id || dev_id >= DEVICE_MAX)
    {
        return APP_FAIL;
    }

    switch (dev_id)
    {
        case DEVICE_LIGHT:
            *action = (const void*)&s_switch_timing.light;
            return APP_OK;
        case DEVICE_FAN:
            *action = (const void*)&s_switch_timing.fan;
            return APP_OK;
        default:
            return APP_FAIL;
    }

    return APP_FAIL;
}

/**
 * @brief 删除一个timer
 * @param[in]  uint16_t                 [timer id]
 * @return     int_t                    [成功/失败]
 */
int switch_timing_remove(uint16_t timer_id)
{
    DEVICE_ID_E dev_id = DEVICE_MAX;

    if (timer_id <= SWITCH_TIMER_ID_MIN)
    {
        return APP_FAIL;
    }

    dev_id = get_dev_id_from_timing_id(timer_id);
    switch (dev_id)
    {
        case DEVICE_LIGHT:
            if (s_switch_timing.light.id != timer_id)
            {
                APP_LOG(LOG_ERROR, "Input ID is %d, not equal %d!\n", timer_id, s_switch_timing.light.id);
                return APP_FAIL;
            }
            // 从队列中删除
            vesync_timing_remove(timer_id);
            // 清除缓存
             memset(&s_switch_timing.light, 0, sizeof(s_switch_timing.light));
            return APP_OK;
        case DEVICE_FAN:
            if (s_switch_timing.fan.id != timer_id)
            {
                APP_LOG(LOG_ERROR, "Input ID is %d, not equal %d!\n", timer_id, s_switch_timing.fan.id);
                return APP_FAIL;
            }
            // 从队列中删除
            vesync_timing_remove(timer_id);
            // 清除缓存
             memset(&s_switch_timing.fan, 0, sizeof(s_switch_timing.fan));
            return APP_OK;
        case DEVICE_ALL:
        case DEVICE_MAX:
        default:
            return APP_FAIL;
    }

    return APP_FAIL;
}

/**
 * @brief 清空timer
 * @param void
 */
int switch_timing_clear(void)
{
    // 清除timer队列
    vesync_timing_clear();

    // 清除缓存
    memset(&s_switch_timing, 0, sizeof(s_switch_timing));

    return APP_OK;
}

/**
 * @brief 初始化timer
 * @param void
 */
void switch_timing_init(void)
{
    // 注册定时器动作回调
    vesync_timing_reg_cb(switch_timing_act);
}


