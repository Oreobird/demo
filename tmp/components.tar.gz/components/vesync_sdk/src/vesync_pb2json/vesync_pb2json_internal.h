/**
 * Copyright © Vesync Technologies Co.Ltd. 2019-2021. All rights reserved.
 * @file    vesync_pb2json_internal.h
 * @brief   Protobuf与JSON互转接口内部声明
 * @author  Herve Lin
 * @date    2021-12-13
 */

#ifndef __VESYNC_PB2JSON_INTERNAL_H__
#define __VESYNC_PB2JSON_INTERNAL_H__

#include <stddef.h>
#include <stdbool.h>

#include "vesync_pb2json.h"

#ifdef __cplusplus
extern "C" {
#endif

#define PB2JSON_DEBUG_ENABLE (1) // 模块调试开关

#if PB2JSON_DEBUG_ENABLE
#define PB2JSON_LOG(level, format, ...) SDK_LOG(level, format, ##__VA_ARGS__)
#else
#define PB2JSON_LOG(level, format, ...)
#endif /* PB2JSON_DEBUG_ENABLE */

#define PB_TRUE (1)  // protobuf_c_boolean：真值枚举
#define PB_FALSE (0) // protobuf_c_boolean：假值枚举

#define BASE64_ENCODED_LEN(len) (((len + 2) / 3) * 4) // 计算编码后长度
#define BASE64_DECODED_LEN(len) (((len + 3) / 4) * 3) // 计算解码后长度

#define SAFE_FREE_BITMAP_AND_MESSAGE()                                 \
    do                                                                 \
    {                                                                  \
        if (presented_fields != NULL)                                  \
        {                                                              \
            bitmap_free(presented_fields);                             \
        }                                                              \
        if (protobuf_message != NULL)                                  \
        {                                                              \
            protobuf_c_message_free_unpacked(*protobuf_message, NULL); \
            *protobuf_message = NULL;                                  \
        }                                                              \
    } while (0)

/**
 * @brief 返回Protobuf类型相应的数据长度（字节）
 * @param[in] type          [Protobuf类型枚举]
 * @return size_t           [返回数据长度]
 */
size_t protobuf2json_value_size_by_type(ProtobufCType type);

/**
 * @brief 将二进制数编码为Base64字符串
 * @param[out]  dst         [字符串输出]
 * @param[in]   src         [二进制数输入]
 * @param[in]   src_len     [二进制数长度]
 * @return size_t           [输出字符串长度]
 */
size_t base64_encode(char *dst, const char *src, size_t src_len);

/**
 * @brief 将Base64字符串解码为二进制数
 * @param[out]  dst         [二进制数输出]
 * @param[in]   src         [字符串输入]
 * @param[in]   src_len     [字符串长度]
 * @return size_t           [输出二进制数长度]
 */
size_t base64_decode(char *dst, const char *src, size_t src_len);

// Bitmap单个字定义
typedef unsigned char bitmap_word_t;
// Bitmap实例定义
typedef bitmap_word_t *bitmap_t;

/**
 * @brief 生成给定大小的Bitmap
 * @param[in] size          [Bitmap大小]
 * @return bitmap_t         [返回Bitmap实例]
 */
bitmap_t bitmap_alloc(int size);

/**
 * @brief 销毁Bitmap
 * @param[in] bitmap        [给定Bitmap实例]
 */
void bitmap_free(bitmap_t bitmap);

/**
 * @brief Bitmap指定数置位
 * @param[in] bitmap        [给定Bitmap实例]
 * @param[in] i             [索引号]
 */
void bitmap_set(bitmap_t bitmap, unsigned int i);

/**
 * @brief Bitmap指定数复位
 * @param[in] bitmap        [给定Bitmap实例]
 * @param[in] i             [索引号]
 */
void bitmap_reset(bitmap_t bitmap, unsigned int i);

/**
 * @brief 获取Bitmap指定数
 * @param[in] bitmap        [给定Bitmap实例]
 * @param[in] i             [索引号]
 * @return bitmap_t         [指定数的二值量0或1]
 */
int bitmap_get(bitmap_t bitmap, unsigned int i);

#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_PB2JSON_INTERNAL_H__ */