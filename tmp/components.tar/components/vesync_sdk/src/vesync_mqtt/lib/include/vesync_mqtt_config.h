/*
 * Copyright © Vesync Technologies Co.Ltd. 2019-2021. All rights reserved.
 *
 * This file is subject to the terms and conditions defined in
 * file 'LICENSE', which is part of this source code package.
 * Tuan PM <tuanpm at live dot com>
 */


#ifndef __MQTT_CONFIG_H__
#define __MQTT_CONFIG_H__

#include "sdkconfig.h"


#ifdef __cplusplus
extern "C" {
#endif


#define MQTT_PROTOCOL_311           CONFIG_MQTT_PROTOCOL_311
#define MQTT_RECONNECT_TIMEOUT_MS_MAX   (8*1000)
#define MQTT_RECONNECT_TIMEOUT_MS_STEP  (2*1000)

#define MQTT_RESEND_PERIOD_MS           (3*1000)    // period to resend unconfirmed qos1 or qos2 packets.

#define MQTT_PING_MISSED_MAX_CNT        2           // count of consecutive missed ping when mqtt trigger reconnection

#ifdef CONFIG_MQTT_BUFFER_SIZE
#define MQTT_BUFFER_SIZE_BYTE       CONFIG_MQTT_BUFFER_SIZE
#else
#define MQTT_BUFFER_SIZE_BYTE       1024
#endif /* CONFIG_MQTT_BUFFER_SIZE */

#define MQTT_MAX_HOST_LEN           64
#define MQTT_MAX_CLIENT_LEN         32
#define MQTT_MAX_USERNAME_LEN       32
#define MQTT_MAX_PASSWORD_LEN       65
#define MQTT_MAX_LWT_TOPIC          32
#define MQTT_MAX_LWT_MSG            128
#define MQTT_TASK_PRIORITY          5

#ifdef CONFIG_MQTT_TASK_STACK_SIZE
#define MQTT_TASK_STACK             CONFIG_MQTT_TASK_STACK_SIZE
#else
#define MQTT_TASK_STACK             (6*1024)
#endif /* CONFIG_MQTT_TASK_STACK_SIZE */

#define MQTT_KEEPALIVE_TICK         (120)
#define MQTT_CMD_QUEUE_SIZE         (10)
#define MQTT_NETWORK_TIMEOUT_MS     (10000)

#ifdef CONFIG_MQTT_TCP_DEFAULT_PORT
#define MQTT_TCP_DEFAULT_PORT       CONFIG_MQTT_TCP_DEFAULT_PORT
#else
#define MQTT_TCP_DEFAULT_PORT       1883
#endif /* CONFIG_MQTT_TCP_DEFAULT_PORT */

#ifdef CONFIG_MQTT_SSL_DEFAULT_PORT
#define MQTT_SSL_DEFAULT_PORT       CONFIG_MQTT_SSL_DEFAULT_PORT
#else
#define MQTT_SSL_DEFAULT_PORT       8883
#endif /* CONFIG_MQTT_SSL_DEFAULT_PORT */

#ifdef CONFIG_MQTT_WS_DEFAULT_PORT
#define MQTT_WS_DEFAULT_PORT        CONFIG_MQTT_WS_DEFAULT_PORT
#else
#define MQTT_WS_DEFAULT_PORT        80
#endif /* CONFIG_MQTT_WS_DEFAULT_PORT */

#ifdef MQTT_WSS_DEFAULT_PORT
#define MQTT_WSS_DEFAULT_PORT       CONFIG_MQTT_WSS_DEFAULT_PORT
#else
#define MQTT_WSS_DEFAULT_PORT       443
#endif /* MQTT_WSS_DEFAULT_PORT */

#define MQTT_CORE_SELECTION_ENABLED CONFIG_MQTT_TASK_CORE_SELECTION_ENABLED

#ifdef CONFIG_MQTT_USE_CORE_0
    #define MQTT_TASK_CORE	0
#else
#ifdef CONFIG_MQTT_USE_CORE_1
    #define MQTT_TASK_CORE 1
#else
    #define MQTT_TASK_CORE 0
#endif /* CONFIG_MQTT_USE_CORE_1 */
#endif /* CONFIG_MQTT_USE_CORE_0 */

#define OUTBOX_EXPIRED_TIMEOUT_MS   (30*1000)
#define OUTBOX_MAX_SIZE             (4*1024)


#ifdef __cplusplus
}
#endif


#endif /* __MQTT_CONFIG_H__ */

