/**
*Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file    ledstrip_timing.c
* @brief   倒计时接口
* @author  Lind
* @date     2021-09-07
*/

#include <string.h>
#include <stdio.h>

#include "vesync_common.h"
#include "vesync_log.h"
#include "vesync_timing.h"
#include "vesync_device.h"
#include "vesync_memory.h"

#include "ledstrip_timing.h"
#include "ledstrip_report.h"
#include "ledstrip.h"

static ls_timing_t s_ls_timing;       // 保存timer

/**
* @brief timer时间到时执行的动作
* @param[in]  uint16_t                 [timer id]
* @return     void                     [none]
*/
static void ls_timing_act(uint16_t id)
{
    ls_led_hsv_param_t *ls_cfg = (ls_led_hsv_param_t*)vesync_malloc(sizeof(ls_led_hsv_param_t));
    if (NULL == ls_cfg)
    {
        APP_LOG(LOG_ERROR, "No enough memory \n");
    }
    else
    {
        if (s_ls_timing.mode == LS_MODE_OFF)
        {
            ls_led_off(LS_LED_ACT_SRC_OUTSIDE);
        }
        else
        {
            ls_cfg->mode = s_ls_timing.mode;
            ls_cfg->color = s_ls_timing.color;
            ls_led_set_led(ls_cfg, LS_LED_ACT_SRC_OUTSIDE);
        }
    }
    ls_report_timing_exec(&s_ls_timing, APP_OK, STAT_CHG_RSN_TIMER_STR);
    ls_timing_remove(id);                         // 删除应用层数据
}

/**
* @brief 新增一个timer
* @param[in]   mode        [timer执行模式]
* @param[in]   total_sec   [timer定时时间]
* @param[out]  p_id        [timer id]
* @param[in]  *hsv_color        [颜色]
* @return     int                    [错误码]
*/
int ls_timing_add(uint32_t total_sec, uint16_t *p_id, LS_MODE_E mode, ls_led_hsv_t *hsv_color)
{
    int ret = -1;

    if (NULL == p_id || ( LS_MODE_OFF != mode && NULL == hsv_color))
    {
        return APP_FAIL;
    }

    *p_id = MIN_LEDSTRIP_TIMER_ID;

    if (0 != s_ls_timing.id)
    {
        APP_LOG(LOG_ERROR, "Timing is exist!\n");
        return APP_FAIL;
    }

    s_ls_timing.id = *p_id;
    s_ls_timing.mode = mode;
    s_ls_timing.total_sec = total_sec;
    s_ls_timing.color = *hsv_color;

    ret = vesync_timing_add(s_ls_timing.id, total_sec);
    if (SDK_OK != ret)
    {
        return APP_FAIL;
    }

    return APP_OK;
}

/**
* @brief 获取timer执行的动作
*/
ls_timing_t *ls_timing_get_act(void)
{
    return &s_ls_timing;
}

/**
* @brief 删除一个timer
* @param[in]  uint16_t                 [timer id]
* @return     int_t                    [成功/失败]
*/
int ls_timing_remove(uint16_t timer_id)
{
    if (s_ls_timing.id != timer_id)
    {
        APP_LOG(LOG_ERROR, "Input ID is %d, not equal %d!\n", timer_id, s_ls_timing.id);
        return APP_FAIL;
    }

    // 从队列中删除
    vesync_timing_remove(timer_id);

    // 清除缓存
    memset((uint8_t *)&s_ls_timing, 0, sizeof(ls_timing_t));

    return APP_OK;
}

/**
* @brief 删除imer
*/
void ls_timing_clear(void)
{

    // 从队列中删除
    vesync_timing_clear();

    // 清除缓存
    memset((uint8_t *)&s_ls_timing, 0, sizeof(ls_timing_t));
}


/**
* @brief 初始化timer
* @param void
*/
void ls_timing_init(void)
{
    // 注册定时器动作回调
    vesync_timing_reg_cb(ls_timing_act);
}

