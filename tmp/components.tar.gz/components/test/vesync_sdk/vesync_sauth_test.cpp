/**
 * Copyright © Vesync Technologies Co.Ltd. 2022. All rights reserved.
 * @file        vesync_sauth_test.cpp
 * @brief       vesync sauth测试用例
 * @author      Herve
 * @date        2022-01-05
 */

#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <gtest/gtest.h>

#include "vesync_log_internal.h"
#include "vesync_memory.h"
#include "vesync_common.h"
#include "vesync_frame.h"
#include "vesync_ble.h"
#include "vesync_sem.h"
#include "vesync_queue.h"
#include "vesync_os.h"
#include "vesync_crc.h"
#include "vesync_tl_payload_parse.h"

#include "vesync_sauth_crypto.h"
#include "vesync_sauth_private.h"
#include "vesync_sauth_proto.h"
#include "vesync_sauth_backend.h"

#include "stub.h"
#include "vesync_sauth_port.c"

static const uint8_t mock_root_pub[] = {
    0xE0, 0x7B, 0x2B, 0x36, 0xBB, 0x86, 0xE4, 0xFE,
    0xC1, 0x25, 0x6A, 0xD6, 0x75, 0x4B, 0xED, 0xA6,
    0x1D, 0xCF, 0xD5, 0x4A, 0xA8, 0x6D, 0xF3, 0xED,
    0x8A, 0xDF, 0xDD, 0xCC, 0xA4, 0xCA, 0xC9, 0x9E,
    0x0F, 0xEE, 0x14, 0x5F, 0xDF, 0x59, 0x72, 0x31,
    0xBB, 0xB9, 0xC1, 0xBE, 0xA1, 0x2B, 0x84, 0x1C,
    0xFB, 0x86, 0xB8, 0xD4, 0x13, 0x85, 0x26, 0xCB,
    0xB9, 0x3D, 0x28, 0x5A, 0x7B, 0x82, 0xD0, 0xFE};
static int mock_root_pub_size = sizeof(mock_root_pub) / sizeof(mock_root_pub[0]);

static const uint8_t mock_dev_cert_sk[] = {
    0x25, 0x05, 0x40, 0x20, 0x44, 0xf2, 0x87, 0x60, 0xb1, 0xef, 0x7a, 0x89, 0x92, 0x5b, 0xec, 0xce,
    0x4b, 0x8d, 0x7c, 0x3c, 0xbb, 0x01, 0xf0, 0x94, 0x93, 0x9e, 0x6d, 0x41, 0xcb, 0x55, 0x56, 0x6f};
static int mock_dev_cert_sk_size = sizeof(mock_dev_cert_sk) / sizeof(mock_dev_cert_sk[0]);

static const uint8_t mock_dev_cert[] = {
    0x30, 0x82, 0x01, 0xa1, 0x30, 0x82, 0x01, 0x47, 0x02, 0x14, 0x6b, 0xb9, 0x4c, 0x46, 0x8a, 0x61,
    0x24, 0x8f, 0xa7, 0x9d, 0xaf, 0xf9, 0xae, 0x26, 0xee, 0x47, 0xe4, 0x9f, 0x41, 0x2c, 0x30, 0x0a,
    0x06, 0x08, 0x2a, 0x86, 0x48, 0xce, 0x3d, 0x04, 0x03, 0x02, 0x30, 0x53, 0x31, 0x0b, 0x30, 0x09,
    0x06, 0x03, 0x55, 0x04, 0x06, 0x13, 0x02, 0x43, 0x4e, 0x31, 0x12, 0x30, 0x10, 0x06, 0x03, 0x55,
    0x04, 0x08, 0x0c, 0x09, 0x47, 0x75, 0x61, 0x6e, 0x67, 0x64, 0x6f, 0x6e, 0x67, 0x31, 0x11, 0x30,
    0x0f, 0x06, 0x03, 0x55, 0x04, 0x07, 0x0c, 0x08, 0x53, 0x68, 0x65, 0x6e, 0x7a, 0x68, 0x65, 0x6e,
    0x31, 0x0f, 0x30, 0x0d, 0x06, 0x03, 0x55, 0x04, 0x0a, 0x0c, 0x06, 0x56, 0x65, 0x73, 0x79, 0x6e,
    0x63, 0x31, 0x0c, 0x30, 0x0a, 0x06, 0x03, 0x55, 0x04, 0x0b, 0x0c, 0x03, 0x52, 0x4e, 0x44, 0x30,
    0x1e, 0x17, 0x0d, 0x32, 0x32, 0x30, 0x31, 0x30, 0x36, 0x30, 0x35, 0x34, 0x38, 0x31, 0x30, 0x5a,
    0x17, 0x0d, 0x33, 0x32, 0x30, 0x31, 0x30, 0x34, 0x30, 0x35, 0x34, 0x38, 0x31, 0x30, 0x5a, 0x30,
    0x53, 0x31, 0x0b, 0x30, 0x09, 0x06, 0x03, 0x55, 0x04, 0x06, 0x13, 0x02, 0x43, 0x4e, 0x31, 0x12,
    0x30, 0x10, 0x06, 0x03, 0x55, 0x04, 0x08, 0x0c, 0x09, 0x47, 0x75, 0x61, 0x6e, 0x67, 0x64, 0x6f,
    0x6e, 0x67, 0x31, 0x11, 0x30, 0x0f, 0x06, 0x03, 0x55, 0x04, 0x07, 0x0c, 0x08, 0x53, 0x68, 0x65,
    0x6e, 0x7a, 0x68, 0x65, 0x6e, 0x31, 0x0f, 0x30, 0x0d, 0x06, 0x03, 0x55, 0x04, 0x0a, 0x0c, 0x06,
    0x56, 0x65, 0x73, 0x79, 0x6e, 0x63, 0x31, 0x0c, 0x30, 0x0a, 0x06, 0x03, 0x55, 0x04, 0x0b, 0x0c,
    0x03, 0x52, 0x4e, 0x44, 0x30, 0x59, 0x30, 0x13, 0x06, 0x07, 0x2a, 0x86, 0x48, 0xce, 0x3d, 0x02,
    0x01, 0x06, 0x08, 0x2a, 0x86, 0x48, 0xce, 0x3d, 0x03, 0x01, 0x07, 0x03, 0x42, 0x00, 0x04, 0x97,
    0x6c, 0xbc, 0x92, 0x94, 0x68, 0x3a, 0x67, 0xc2, 0xe0, 0x72, 0x18, 0x5d, 0xea, 0x90, 0x59, 0xcc,
    0x7d, 0x7f, 0x61, 0xb5, 0x09, 0x66, 0x53, 0xad, 0x99, 0x0a, 0x2f, 0x6e, 0x02, 0x11, 0x1e, 0x76,
    0x4a, 0xaf, 0x01, 0x17, 0x81, 0x17, 0x89, 0xc3, 0xca, 0xb3, 0xa3, 0x9c, 0x53, 0xd7, 0x3c, 0x8d,
    0x5a, 0x02, 0xea, 0x55, 0x4d, 0x47, 0xa6, 0x00, 0x04, 0xc1, 0xfb, 0xc9, 0x28, 0x74, 0x2e, 0x30,
    0x0a, 0x06, 0x08, 0x2a, 0x86, 0x48, 0xce, 0x3d, 0x04, 0x03, 0x02, 0x03, 0x48, 0x00, 0x30, 0x45,
    0x02, 0x21, 0x00, 0xfb, 0x51, 0x79, 0xb1, 0x83, 0xad, 0xb0, 0xfb, 0x32, 0x2a, 0x94, 0x6d, 0xd4,
    0xdc, 0x93, 0xee, 0x56, 0xd9, 0xab, 0xec, 0xe3, 0xcb, 0xee, 0x61, 0xb3, 0x37, 0x59, 0x9a, 0xfe,
    0x54, 0xfb, 0x55, 0x02, 0x20, 0x22, 0xc9, 0xf5, 0xa0, 0x5a, 0x0e, 0x55, 0x5f, 0xae, 0x12, 0xc1,
    0x1e, 0x90, 0x1e, 0xe9, 0x9f, 0x19, 0x47, 0xa4, 0xbf, 0x8a, 0x9c, 0x3a, 0xa9, 0xce, 0xc0, 0x2c,
    0xdc, 0x7c, 0x6b, 0xc2, 0x5d};
static int mock_dev_cert_size = sizeof(mock_dev_cert) / sizeof(mock_dev_cert[0]);

static const uint8_t mock_app_cert_sk[] = {
    0x98, 0x7e, 0xc6, 0xc8, 0x6f, 0x64, 0x1e, 0x8e, 0x53, 0x52, 0x32, 0xc0, 0xe6, 0x40, 0x3b, 0xb1,
    0x0a, 0x27, 0x5a, 0x55, 0xc7, 0xeb, 0x3f, 0xd4, 0x52, 0xe9, 0xa3, 0x2d, 0xc6, 0x28, 0xca, 0xf8};
static int mock_app_cert_sk_size = sizeof(mock_app_cert_sk) / sizeof(mock_app_cert_sk[0]);

static const uint8_t mock_app_cert[] = {
    0x30, 0x82, 0x01, 0xa0, 0x30, 0x82, 0x01, 0x47, 0x02, 0x14, 0x6b, 0xb9, 0x4c, 0x46, 0x8a, 0x61,
    0x24, 0x8f, 0xa7, 0x9d, 0xaf, 0xf9, 0xae, 0x26, 0xee, 0x47, 0xe4, 0x9f, 0x41, 0x2d, 0x30, 0x0a,
    0x06, 0x08, 0x2a, 0x86, 0x48, 0xce, 0x3d, 0x04, 0x03, 0x02, 0x30, 0x53, 0x31, 0x0b, 0x30, 0x09,
    0x06, 0x03, 0x55, 0x04, 0x06, 0x13, 0x02, 0x43, 0x4e, 0x31, 0x12, 0x30, 0x10, 0x06, 0x03, 0x55,
    0x04, 0x08, 0x0c, 0x09, 0x47, 0x75, 0x61, 0x6e, 0x67, 0x64, 0x6f, 0x6e, 0x67, 0x31, 0x11, 0x30,
    0x0f, 0x06, 0x03, 0x55, 0x04, 0x07, 0x0c, 0x08, 0x53, 0x68, 0x65, 0x6e, 0x7a, 0x68, 0x65, 0x6e,
    0x31, 0x0f, 0x30, 0x0d, 0x06, 0x03, 0x55, 0x04, 0x0a, 0x0c, 0x06, 0x56, 0x65, 0x73, 0x79, 0x6e,
    0x63, 0x31, 0x0c, 0x30, 0x0a, 0x06, 0x03, 0x55, 0x04, 0x0b, 0x0c, 0x03, 0x52, 0x4e, 0x44, 0x30,
    0x1e, 0x17, 0x0d, 0x32, 0x32, 0x30, 0x31, 0x30, 0x36, 0x30, 0x35, 0x34, 0x38, 0x34, 0x38, 0x5a,
    0x17, 0x0d, 0x33, 0x32, 0x30, 0x31, 0x30, 0x34, 0x30, 0x35, 0x34, 0x38, 0x34, 0x38, 0x5a, 0x30,
    0x53, 0x31, 0x0b, 0x30, 0x09, 0x06, 0x03, 0x55, 0x04, 0x06, 0x13, 0x02, 0x43, 0x4e, 0x31, 0x12,
    0x30, 0x10, 0x06, 0x03, 0x55, 0x04, 0x08, 0x0c, 0x09, 0x47, 0x75, 0x61, 0x6e, 0x67, 0x64, 0x6f,
    0x6e, 0x67, 0x31, 0x11, 0x30, 0x0f, 0x06, 0x03, 0x55, 0x04, 0x07, 0x0c, 0x08, 0x53, 0x68, 0x65,
    0x6e, 0x7a, 0x68, 0x65, 0x6e, 0x31, 0x0f, 0x30, 0x0d, 0x06, 0x03, 0x55, 0x04, 0x0a, 0x0c, 0x06,
    0x56, 0x65, 0x73, 0x79, 0x6e, 0x63, 0x31, 0x0c, 0x30, 0x0a, 0x06, 0x03, 0x55, 0x04, 0x0b, 0x0c,
    0x03, 0x52, 0x4e, 0x44, 0x30, 0x59, 0x30, 0x13, 0x06, 0x07, 0x2a, 0x86, 0x48, 0xce, 0x3d, 0x02,
    0x01, 0x06, 0x08, 0x2a, 0x86, 0x48, 0xce, 0x3d, 0x03, 0x01, 0x07, 0x03, 0x42, 0x00, 0x04, 0xbe,
    0x98, 0xbf, 0xd8, 0xbb, 0x5d, 0xce, 0x2c, 0xe0, 0xd0, 0x7b, 0xd9, 0x65, 0x31, 0x6b, 0x2e, 0xde,
    0x1f, 0x31, 0x87, 0x17, 0xd4, 0x4b, 0x90, 0x35, 0xcb, 0x76, 0x0d, 0x11, 0xfe, 0xe4, 0xd7, 0x54,
    0xab, 0x24, 0x1a, 0x1a, 0xa6, 0x1b, 0xa8, 0x6e, 0x8d, 0x69, 0x75, 0x0f, 0x1a, 0xd0, 0x89, 0x00,
    0x63, 0xda, 0x2a, 0x9b, 0x08, 0xe9, 0xf2, 0xd9, 0xb4, 0x15, 0xb3, 0xe0, 0x8d, 0x68, 0x86, 0x30,
    0x0a, 0x06, 0x08, 0x2a, 0x86, 0x48, 0xce, 0x3d, 0x04, 0x03, 0x02, 0x03, 0x47, 0x00, 0x30, 0x44,
    0x02, 0x20, 0x2b, 0x51, 0x58, 0x74, 0x4e, 0xbc, 0x25, 0x11, 0x8a, 0x53, 0x3b, 0x51, 0xc2, 0x31,
    0xf0, 0x84, 0x77, 0xf7, 0x56, 0xda, 0xf7, 0xae, 0xdd, 0xd0, 0x39, 0xee, 0xcc, 0x54, 0xec, 0x6f,
    0xf6, 0xa3, 0x02, 0x20, 0x4e, 0x92, 0x06, 0x66, 0x98, 0x92, 0x7b, 0x1f, 0x87, 0x96, 0x58, 0xa6,
    0x1f, 0x81, 0x2d, 0xf2, 0xfb, 0x4b, 0xaa, 0x06, 0xe2, 0xc7, 0xe6, 0x7d, 0x58, 0x47, 0x2f, 0x2e,
    0x4d, 0xe6, 0xff, 0x4d};
static int mock_app_cert_size = sizeof(mock_app_cert) / sizeof(mock_app_cert[0]);

static void rnd_block_gen(uint8_t *dest, uint32_t size)
{
    for (uint32_t i = 0; i < size; i++)
    {
        dest[i] = (uint8_t)rand();
    }
}

static Stub stub;

static vesync_ble_data_recv_cb_t s_ble_recv_cb;

static vesync_queue_t *s_dev_data_queue = NULL;

static uint8_t s_ltk[32];

static sauth_sess_ctx_t s_session_key;

typedef struct
{
    uint8_t *buf;
    uint16_t len;
} buffer_t;

void vesync_ble_send_cmd_data_mock(uint8_t *p_data, uint16_t len, uint8_t req_flag)
{
    tl_payload_info_t *p_payload = (tl_payload_info_t *)p_data;
    uint16_t data_len = len - sizeof(tl_payload_info_t);

    buffer_t buffer;
    buffer.buf = (uint8_t *)vesync_malloc(data_len);
    buffer.len = data_len;
    memcpy(buffer.buf, p_payload->payload_data, data_len);

    SDK_LOG(LOG_DEBUG, "reg cmd_recv_cb, buffer[%p]\n", buffer.buf);

    vesync_queue_send(s_dev_data_queue, &buffer, VESYNC_OS_NO_WAIT);
}

void vesync_ble_reg_cmd_recv_cb_mock(vesync_ble_data_recv_cb_t cb)
{
    SDK_LOG(LOG_DEBUG, "reg cmd_recv_cb\n");
    s_ble_recv_cb = cb;
}

class vesync_sauth_test : public testing::Test
{
protected:
    static void SetUpTestCase()
    {
        vesync_log_init();
        vesync_flash_init();

        stub.set(vesync_ble_send_cmd_data, vesync_ble_send_cmd_data_mock);
        stub.set(vesync_ble_muxer_add_rxer, vesync_ble_reg_cmd_recv_cb_mock);

#if 0
        //sauth_crypto_init(rnd_block_gen);
#endif

        int ret = vesync_sauth_init();
        EXPECT_EQ(ret, SDK_OK);

        // Mock the certificates
        sauth_crypto_load_unsafe_cert(mock_root_pub, mock_root_pub_size,
                                      mock_dev_cert_sk, mock_dev_cert_sk_size,
                                      mock_dev_cert, mock_dev_cert_size);

        s_dev_data_queue = vesync_queue_new(10 * sizeof(buffer_t), sizeof(buffer_t));
        EXPECT_TRUE(s_dev_data_queue);

        buffer_t dummy;
        while (VOS_OK == vesync_queue_recv(s_dev_data_queue, &dummy, VESYNC_OS_NO_WAIT))
            ;

        bool is_registered = vesync_sauth_is_reg();
        bool is_login = vesync_sauth_is_login();

        SDK_LOG(LOG_WARN, "is_registered: %d, is_login: %d\n", is_registered, is_login);
    }

    static void TearDownTestCase()
    {
        vesync_log_deinit();

        vesync_queue_free(s_dev_data_queue);
    }
};

TEST_F(vesync_sauth_test, crypto_crt_verify_test)
{
    int ret = CRYPTO_OK;
    uint16_t dev_crt_len;

    ret = sauth_crypto_get_crt_len(SAUTH_DEV_CERT, &dev_crt_len);
    EXPECT_EQ(ret, CRYPTO_OK);
    EXPECT_EQ(dev_crt_len, mock_dev_cert_size);

    SDK_LOG(LOG_INFO, "device_certificate size: %d\n", dev_crt_len);

    sauth_crt_t sauth_crt;
    uint8_t *p_der = (uint8_t *)vesync_malloc(dev_crt_len);

    ret = sauth_crypto_get_crt_der(SAUTH_DEV_CERT, p_der, dev_crt_len);
    EXPECT_EQ(ret, CRYPTO_OK);

    ret = sauth_crypto_crt_parse_der(p_der, dev_crt_len, NULL, &sauth_crt);
    EXPECT_EQ(ret, CRYPTO_OK);

    EXPECT_EQ(sauth_crt.sub_o.len, 6);
    EXPECT_EQ(sauth_crt.sub_o.p[0], 'V');
    EXPECT_EQ(sauth_crt.sub_o.p[1], 'e');
    EXPECT_EQ(sauth_crt.sub_o.p[2], 's');
    EXPECT_EQ(sauth_crt.sub_o.p[3], 'y');
    EXPECT_EQ(sauth_crt.sub_o.p[4], 'n');
    EXPECT_EQ(sauth_crt.sub_o.p[5], 'c');

    EXPECT_EQ(sauth_crt.sn.len, 20);
    EXPECT_EQ(sauth_crt.sn.p[0], 0x6B);
    EXPECT_EQ(sauth_crt.sn.p[1], 0xB9);
    EXPECT_EQ(sauth_crt.sn.p[2], 0x4C);
    EXPECT_EQ(sauth_crt.sn.p[3], 0x46);
    EXPECT_EQ(sauth_crt.sn.p[4], 0x8A);
    EXPECT_EQ(sauth_crt.sn.p[5], 0x61);
    EXPECT_EQ(sauth_crt.sn.p[6], 0x24);
    EXPECT_EQ(sauth_crt.sn.p[7], 0x8F);
    EXPECT_EQ(sauth_crt.sn.p[8], 0xA7);
    EXPECT_EQ(sauth_crt.sn.p[9], 0x9D);
    EXPECT_EQ(sauth_crt.sn.p[10], 0xAF);
    EXPECT_EQ(sauth_crt.sn.p[11], 0xF9);
    EXPECT_EQ(sauth_crt.sn.p[12], 0xAE);
    EXPECT_EQ(sauth_crt.sn.p[13], 0x26);
    EXPECT_EQ(sauth_crt.sn.p[14], 0xEE);
    EXPECT_EQ(sauth_crt.sn.p[15], 0x47);
    EXPECT_EQ(sauth_crt.sn.p[16], 0xE4);
    EXPECT_EQ(sauth_crt.sn.p[17], 0x9F);
    EXPECT_EQ(sauth_crt.sn.p[18], 0x41);
    EXPECT_EQ(sauth_crt.sn.p[19], 0x2C);

    uint8_t hash[32];
    ret = sauth_crypto_sha256(sauth_crt.tbs.p, sauth_crt.tbs.len, hash);
    EXPECT_EQ(ret, CRYPTO_OK);

#if 0
    LOG_RAW_HEX(LOG_INFO, "tbs", sauth_crt.tbs.p, sauth_crt.tbs.len);
#endif
    LOG_RAW_HEX(LOG_INFO, "tbs_sha256", hash, 32);
    LOG_RAW_HEX(LOG_INFO, "root_pk", (uint8_t *)mock_root_pub, mock_root_pub_size);
    LOG_RAW_HEX(LOG_INFO, "signature", (uint8_t *)sauth_crt.sig, 64);

    ret = sauth_crypto_ecc_verify(P256R1, (uint8_t *)mock_root_pub, hash, sauth_crt.sig);
    EXPECT_EQ(ret, CRYPTO_OK);

    ret = sauth_crypto_ecc_verify_by_root(P256R1, hash, sauth_crt.sig);
    EXPECT_EQ(ret, CRYPTO_OK);

    vesync_free(p_der);
}

TEST_F(vesync_sauth_test, crypto_dev_crt_ecdsa_test)
{
    int ret = CRYPTO_OK;
    sauth_crt_t sauth_crt;
    uint16_t dev_crt_len;

    ret = sauth_crypto_get_crt_len(SAUTH_DEV_CERT, &dev_crt_len);
    EXPECT_EQ(ret, CRYPTO_OK);

    uint8_t *p_der = (uint8_t *)vesync_malloc(dev_crt_len);
    ret = sauth_crypto_get_crt_der(SAUTH_DEV_CERT, p_der, dev_crt_len);
    EXPECT_EQ(ret, CRYPTO_OK);

    ret = sauth_crypto_crt_parse_der(p_der, dev_crt_len, NULL, &sauth_crt);
    EXPECT_EQ(ret, CRYPTO_OK);

    uint8_t for_sign[8] = {1, 2, 3, 4, 5, 6, 7, 8};
    uint8_t hash[32];
    uint8_t sign[64];

    ret = sauth_crypto_sha256(for_sign, 8, hash);
    EXPECT_EQ(ret, CRYPTO_OK);

    ret = sauth_crypto_ecc_sign_by_dev_crt(P256R1, hash, sign);
    EXPECT_EQ(ret, CRYPTO_OK);

    LOG_RAW_HEX(LOG_INFO, "for_sign_sha256", hash, 32);
    LOG_RAW_HEX(LOG_INFO, "signature", (uint8_t *)sign, 64);

    ret = sauth_crypto_ecc_verify(P256R1, sauth_crt.pub.p, hash, sign);
    EXPECT_EQ(ret, CRYPTO_OK);

    vesync_free(p_der);
}

TEST_F(vesync_sauth_test, crypto_ecdhe_test)
{
    int ret;
    ecc256_pk_t a_pk;

    ret = sauth_crypto_ecc_keypair_gen(P256R1, a_pk);
    EXPECT_EQ(ret, CRYPTO_OK);

    LOG_RAW_HEX(LOG_INFO, "a_pk", (uint8_t *)a_pk, 64);

    ecc256_pk_t b_pk;
    ecc256_sk_t b_sk;
    ECC_CURVE_E curve = P256R1;
    ret = micro_ecc_keypair_gen(&curve, b_sk, b_pk);
    EXPECT_EQ(ret, 0);

    LOG_RAW_HEX(LOG_INFO, "b_pk", (uint8_t *)b_pk, 64);
    LOG_RAW_HEX(LOG_INFO, "b_sk", (uint8_t *)b_sk, 32);

    ecc256_ss_t a_ss;
    ret = sauth_crypto_ecc_shared_secret_compute(P256R1, b_pk, a_ss);
    EXPECT_EQ(ret, CRYPTO_OK);

    ecc256_ss_t b_ss;
    ret = micro_ecc_shared_secret_compute(&curve, b_sk, a_pk, b_ss);
    EXPECT_EQ(ret, CRYPTO_OK);

    LOG_RAW_HEX(LOG_INFO, "ss_for_a", (uint8_t *)a_ss, 32);
    LOG_RAW_HEX(LOG_INFO, "ss_for_b", (uint8_t *)b_ss, 32);

    for (int i = 0; i < 32; i++)
    {
        EXPECT_EQ(((uint8_t *)a_ss)[i], ((uint8_t *)b_ss)[i]);
    }
}

TEST_F(vesync_sauth_test, crypto_hkdf_test)
{
    uint8_t mock_ss_key[] = {
        0x5D, 0xAD, 0x63, 0xB9, 0xFA, 0xDC, 0x75, 0x99,
        0xB8, 0x93, 0x32, 0x5F, 0x00, 0x1A, 0x3D, 0x42,
        0x48, 0x4D, 0x3A, 0x13, 0xD0, 0x3E, 0xB2, 0x25,
        0xEE, 0x59, 0xFB, 0x98, 0xCE, 0x77, 0x69, 0xDE};
    uint8_t mock_oob[] = {1, 2, 3, 4, 5, 6};
    uint8_t mock_ltk[32];

    int ret;
    ret = sauth_crypto_hkdf_sha256(mock_ss_key, sizeof(mock_ss_key),
                                   mock_oob, sizeof(mock_oob),
                                   NULL, 0,
                                   mock_ltk, sizeof(mock_ltk));
    EXPECT_EQ(ret, CRYPTO_OK);
    LOG_RAW_HEX(LOG_INFO, "ltk", (uint8_t *)mock_ltk, 32);

    uint8_t mock_eph_key[] = {
        0x3B, 0x6E, 0xD0, 0x75, 0x4D, 0x56, 0x8F, 0x65,
        0xC5, 0xA3, 0xF4, 0xE3, 0x8A, 0x07, 0x2B, 0xFB,
        0xC7, 0x92, 0x51, 0x7E, 0xA5, 0x74, 0xC5, 0xCA,
        0x67, 0x4B, 0x88, 0x46, 0xD5, 0xDC, 0x52, 0xD0};
    uint8_t buffer[64];
    memcpy(buffer, mock_ltk, 32);
    memcpy(buffer + 32, mock_eph_key, 32);

    char mock_salt[] = "salt";
    char mock_info[] = "info";

    LOG_RAW_HEX(LOG_INFO, "ltk_mix_eph_key", buffer, 64);

    sauth_sess_ctx_t s_session_key;
    ret = sauth_crypto_hkdf_sha256(buffer, sizeof(buffer),
                                   (const uint8_t *)mock_salt, sizeof(mock_salt) - 1,
                                   (const uint8_t *)mock_info, sizeof(mock_info) - 1,
                                   (uint8_t *)&s_session_key, sizeof(s_session_key));
    EXPECT_EQ(ret, CRYPTO_OK);

    LOG_RAW_HEX(LOG_INFO, "session_dev_key", s_session_key.dev_key, 16);
    LOG_RAW_HEX(LOG_INFO, "session_app_key", s_session_key.app_key, 16);
    LOG_RAW_HEX(LOG_INFO, "session_dev_iv", s_session_key.dev_iv, 12);
    LOG_RAW_HEX(LOG_INFO, "session_app_iv", s_session_key.app_iv, 12);
    LOG_RAW_HEX(LOG_INFO, "session_reserved", s_session_key.reserve, 8);
}

TEST_F(vesync_sauth_test, crypto_ccm_test)
{
    sauth_sess_ctx_t s_session_key = {
        dev_key : {0xDA, 0xA3, 0xE3, 0x52, 0xE8, 0xCC, 0x7F, 0x14, 0xFB, 0x05, 0x57, 0xA1, 0xC0, 0xB0, 0xA3, 0x23},
        app_key : {0xE8, 0x9E, 0xEF, 0xFC, 0x3B, 0xE5, 0x1A, 0x2A, 0xF7, 0x06, 0xD8, 0x9F, 0x91, 0x65, 0xAA, 0x05},
        dev_iv : {0x53, 0x12, 0x1B, 0x95},
        app_iv : {0xB4, 0x3E, 0x23, 0xE2}
    };

    uint8_t dev_iv_nonce[12] = {0};
    uint8_t app_iv_nonce[12] = {0};

    memcpy(dev_iv_nonce, s_session_key.dev_iv, sizeof(s_session_key.dev_iv));
    memcpy(app_iv_nonce, s_session_key.app_iv, sizeof(s_session_key.app_iv));

    uint8_t data[200] = {
        0x0B, 0xE1, 0x1A, 0x1C, 0x7F, 0x23, 0xF8, 0x29, 0xF8, 0xA4, 0x1B,
        0x13, 0xB5, 0xCA, 0x4E, 0xE8, 0x98, 0x32, 0x38, 0xE0, 0x79, 0x4D,
        0x3D, 0x34, 0xBC, 0x5F, 0x4E, 0x77, 0xFA, 0xCB, 0x6C, 0x05, 0xAC,
        0x86, 0x21, 0x2B, 0xAA, 0x1A, 0x55, 0xA2, 0xBE, 0x70, 0xB5, 0x73,
        0x3B, 0x04, 0x5C, 0xD3, 0x36, 0x94, 0xB3, 0xAF, 0xE2, 0xF0, 0xE4,
        0x9E, 0x4F, 0x32, 0x15, 0x49, 0xFD, 0x82, 0x4E, 0xA9, 0x08, 0x70,
        0xD4, 0xB2, 0x8A, 0x29, 0x54, 0x48, 0x9A, 0x0A, 0xBC, 0xD5, 0x0E,
        0x18, 0xA8, 0x44, 0xAC, 0x5B, 0xF3, 0x8E, 0x4C, 0xD7, 0x2D, 0x9B,
        0x09, 0x42, 0xE5, 0x06, 0xC4, 0x33, 0xAF, 0xCD, 0xA3, 0x84, 0x7F,
        0x2D, 0xAD, 0xD4, 0x76, 0x47, 0xDE, 0x32, 0x1C, 0xEC, 0x4A, 0xC4,
        0x30, 0xF6, 0x20, 0x23, 0x85, 0x6C, 0xFB, 0xB2, 0x07, 0x04, 0xF4,
        0xEC, 0x0B, 0xB9, 0x20, 0xBA, 0x86, 0xC3, 0x3E, 0x05, 0xF1, 0xEC,
        0xD9, 0x67, 0x33, 0xB7, 0x99, 0x50, 0xA3, 0xE3, 0x14, 0xD3, 0xD9,
        0x34, 0xF7, 0x5E, 0xA0, 0xF2, 0x10, 0xA8, 0xF6, 0x05, 0x94, 0x01,
        0xBE, 0xB4, 0xBC, 0x44, 0x78, 0xFA, 0x49, 0x69, 0xE6, 0x23, 0xD0,
        0x1A, 0xDA, 0x69, 0x6A, 0x7E, 0x4C, 0x7E, 0x51, 0x25, 0xB3, 0x48,
        0x84, 0x53, 0x3A, 0x94, 0xFB, 0x31, 0x99, 0x90, 0x32, 0x57, 0x44,
        0xEE, 0x9B, 0xBC, 0xE9, 0xE5, 0x25, 0xCF, 0x08, 0xF5, 0xE9, 0xE2,
        0x5E, 0x53};
    LOG_RAW_HEX(LOG_INFO, "data", data, 200);

    uint8_t encrypted[200];
    uint8_t tag[4];

    int ret;
    ret = sauth_crypto_ccm_encrypt(s_session_key.dev_key,
                                   dev_iv_nonce, 12,
                                   NULL, 0,
                                   data, 200,
                                   encrypted,
                                   tag, 4);
    EXPECT_EQ(ret, CRYPTO_OK);

    LOG_RAW_HEX(LOG_INFO, "encrypted_data", encrypted, 200);
    LOG_RAW_HEX(LOG_INFO, "tag", tag, 4);

    uint8_t wrong_tag[4];
    memcpy(wrong_tag, tag, 4);
    wrong_tag[0] = ~wrong_tag[0];

    LOG_RAW_HEX(LOG_INFO, "wrong_tag", wrong_tag, 4);

    uint8_t decrypted[200];
    ret = sauth_crypto_ccm_decrypt(s_session_key.dev_key,
                                   dev_iv_nonce, 12,
                                   NULL, 0,
                                   encrypted, 200,
                                   decrypted,
                                   wrong_tag, 4);
    EXPECT_EQ(ret, CRYPTO_ERR_CCM_AUTH_FAIL);

    ret = sauth_crypto_ccm_decrypt(s_session_key.dev_key,
                                   dev_iv_nonce, 12,
                                   NULL, 0,
                                   encrypted, 200,
                                   decrypted,
                                   tag, 4);
    EXPECT_EQ(ret, CRYPTO_OK);

    for (int i = 0; i < 200; i++)
    {
        EXPECT_EQ(decrypted[i], data[i]);
    }

    LOG_RAW_HEX(LOG_INFO, "decrypted", decrypted, 200);
}

static void send_to_sauth(uint16_t cmd_code, uint8_t *data, uint16_t len)
{
    uint16_t tl_len = sizeof(tl_payload_info_t) + len + sizeof(cmd_code);
    tl_payload_info_t *tl_pl = (tl_payload_info_t *)vesync_malloc(tl_len);
    tl_pl->version = SAUTH_PORT_BLE_PROTOCOL_VERSION;
    tl_pl->op_code = vesync_htole16(SAUTH_PORT_OPCODE_APP2DEV);
    uint16_t le16_cc = vesync_htole16(cmd_code);
    memcpy(tl_pl->payload_data, (uint8_t *)&le16_cc, sizeof(cmd_code));
    memcpy(tl_pl->payload_data + sizeof(cmd_code), data, len);

    LOG_RAW_HEX(LOG_INFO, "ble frame send to device:", tl_pl, tl_len);
    s_ble_recv_cb((uint8_t *)tl_pl, tl_len, false);
    vesync_free(tl_pl);
}

static int parse_cmd_from_sauth(uint16_t cmd_code, uint8_t *p_data, uint16_t data_len, uint8_t *p_out, uint16_t *p_out_len)
{
    SDK_LOG(LOG_DEBUG, "start parse cmd_code, p_data[%p]\n", p_data);

    uint16_t cmd_code_tmp;
    memcpy((uint8_t *)&cmd_code_tmp, p_data, sizeof(cmd_code_tmp));
    cmd_code_tmp = vesync_le16toh(cmd_code_tmp);

    if (cmd_code_tmp != cmd_code)
    {
        SDK_LOG(LOG_WARN, "wrong_cmd_code:%x\n", cmd_code_tmp);
        return SDK_FAIL;
    }

    SDK_LOG(LOG_DEBUG, "parse cmd_code:%x\n", cmd_code_tmp);
    if (NULL != p_out)
    {
        *p_out_len = data_len - sizeof(cmd_code);
        memcpy(p_out, p_data + sizeof(cmd_code), *p_out_len);
    }
    return SDK_OK;
}

TEST_F(vesync_sauth_test, sauth_reg_test)
{
    int ret;
    buffer_t dev_data_queue;

    ECC_CURVE_E curve = P256R1;

    send_to_sauth(SAUTH_CMD_REG_START, NULL, 0);
    vesync_sleep(200);

    uint16_t dev_crt_len = 0;
    uint8_t dev_crt[512];
    SDK_LOG(LOG_WARN, "wait dev_cert\n");

    ret = vesync_queue_recv(s_dev_data_queue, &dev_data_queue, VESYNC_OS_WAIT_FOREVER);
    EXPECT_EQ(ret, VOS_OK);
    ret = parse_cmd_from_sauth(SAUTH_CMD_INFO_DEV_CERT, dev_data_queue.buf, dev_data_queue.len, dev_crt, &dev_crt_len);
    EXPECT_EQ(ret, SDK_OK);
    vesync_free(dev_data_queue.buf);

    SDK_LOG(LOG_WARN, "dev_cert_len[%d]\n", dev_crt_len);
    sauth_crt_t parsed_dev_crt;
    ret = sauth_crypto_crt_parse_der(dev_crt, dev_crt_len, NULL, &parsed_dev_crt);
    EXPECT_EQ(ret, CRYPTO_OK);

    uint8_t dev_crt_tbs_hash[32];
    ret = sauth_crypto_sha256(parsed_dev_crt.tbs.p, parsed_dev_crt.tbs.len, dev_crt_tbs_hash);
    EXPECT_EQ(ret, CRYPTO_OK);

    ret = micro_ecc_verify(&curve, mock_root_pub, dev_crt_tbs_hash, parsed_dev_crt.sig);
    EXPECT_EQ(ret, 0);

    uint8_t dev_pk[64];
    uint16_t dev_pk_len = 0;
    SDK_LOG(LOG_WARN, "wait dev_pk\n");

    ret = vesync_queue_recv(s_dev_data_queue, &dev_data_queue, VESYNC_OS_WAIT_FOREVER);
    EXPECT_EQ(ret, VOS_OK);
    ret = parse_cmd_from_sauth(SAUTH_CMD_INFO_DEV_PK, dev_data_queue.buf, dev_data_queue.len, dev_pk, &dev_pk_len);
    EXPECT_EQ(ret, SDK_OK);
    vesync_free(dev_data_queue.buf);

    uint8_t app_pk[64];
    uint8_t app_sk[32];
    ret = micro_ecc_keypair_gen(&curve, app_sk, app_pk);
    EXPECT_EQ(ret, 0);

    uint8_t eph_ss[32];
    ret = micro_ecc_shared_secret_compute(&curve, app_sk, dev_pk, eph_ss);
    EXPECT_EQ(ret, 0);

    ret = sauth_crypto_hkdf_sha256(eph_ss, sizeof(eph_ss),
                                   NULL, 0,
                                   NULL, 0,
                                   s_ltk, sizeof(s_ltk));
    EXPECT_EQ(ret, CRYPTO_OK);

    uint8_t ltk_hash[32];
    ret = sauth_crypto_sha256(s_ltk, sizeof(s_ltk), ltk_hash);
    EXPECT_EQ(ret, CRYPTO_OK);

    uint8_t server_sign[64];
    ret = micro_ecc_sign(&curve, mock_app_cert_sk, ltk_hash, server_sign);
    EXPECT_EQ(ret, 0);

    send_to_sauth(SAUTH_CMD_INFO_APP_CERT, (uint8_t *)mock_app_cert, mock_app_cert_size);
    vesync_sleep(150);

    send_to_sauth(SAUTH_CMD_INFO_APP_PK, app_pk, sizeof(app_pk));
    vesync_sleep(150);

    send_to_sauth(SAUTH_CMD_INFO_APP_SIGN, server_sign, sizeof(server_sign));
    vesync_sleep(150);

    uint8_t dev_sign[64];
    uint16_t dev_sign_len = 0;
    SDK_LOG(LOG_WARN, "wait dev_sign\n");

    ret = vesync_queue_recv(s_dev_data_queue, &dev_data_queue, VESYNC_OS_WAIT_FOREVER);
    EXPECT_EQ(ret, VOS_OK);
    ret = parse_cmd_from_sauth(SAUTH_CMD_INFO_DEV_SIGN, dev_data_queue.buf, dev_data_queue.len, dev_sign, &dev_sign_len);
    EXPECT_EQ(ret, SDK_OK);
    vesync_free(dev_data_queue.buf);

    ret = micro_ecc_verify(&curve, parsed_dev_crt.pub.p, ltk_hash, dev_sign);
    EXPECT_EQ(ret, 0);

    send_to_sauth(SAUTH_CMD_REG_SUCCESS, NULL, 0);
    vesync_sleep(300);
}

TEST_F(vesync_sauth_test, sauth_hello_test)
{
    int ret;
    buffer_t dev_data_queue;

    send_to_sauth(SAUTH_CMD_HELLO, NULL, 0);
    vesync_sleep(200);

    sauth_dev_info_t dev_info;
    uint16_t dev_info_data_len;
    ret = vesync_queue_recv(s_dev_data_queue, &dev_data_queue, VESYNC_OS_WAIT_FOREVER);
    EXPECT_EQ(ret, VOS_OK);
    ret = parse_cmd_from_sauth(SAUTH_CMD_INFO_DEV, dev_data_queue.buf, dev_data_queue.len, (uint8_t *)&dev_info, &dev_info_data_len);
    EXPECT_EQ(ret, SDK_OK);
    vesync_free(dev_data_queue.buf);

    dev_info.version = vesync_le16toh(dev_info.version);
    EXPECT_EQ(dev_info.version, SAUTH_PROTOCOL_VERSION);
    EXPECT_EQ(dev_info.cipher_suit, SAUTH_CIPER_SUIT_ECDHE_REG_ECDSA_LOG_AES_128_CCM_SHA256);
    EXPECT_EQ(dev_info.io_capability, SAUTH_OOB_CAPABILITY_NO_WAY);

    SDK_LOG(LOG_WARN, "cipher_status: %x\n", dev_info.cipher_status);
    vesync_sleep(300);
}

TEST_F(vesync_sauth_test, sauth_login_test)
{
    int ret;
    buffer_t dev_data_queue;

    ECC_CURVE_E curve = P256R1;

    send_to_sauth(SAUTH_CMD_LOGIN_START, NULL, 0);
    vesync_sleep(200);

    uint8_t app_pk[64];
    uint8_t app_sk[32];
    ret = micro_ecc_keypair_gen(&curve, app_sk, app_pk);
    EXPECT_EQ(ret, 0);

    send_to_sauth(SAUTH_CMD_INFO_APP_PK, app_pk, sizeof(app_pk));
    vesync_sleep(150);

    uint8_t dev_pk[64];
    uint16_t dev_pk_len = 0;
    SDK_LOG(LOG_WARN, "wait dev_pk\n");

    ret = vesync_queue_recv(s_dev_data_queue, &dev_data_queue, VESYNC_OS_WAIT_FOREVER);
    EXPECT_EQ(ret, VOS_OK);
    ret = parse_cmd_from_sauth(SAUTH_CMD_INFO_DEV_PK, dev_data_queue.buf, dev_data_queue.len, dev_pk, &dev_pk_len);
    EXPECT_EQ(ret, SDK_OK);
    vesync_free(dev_data_queue.buf);

    uint8_t eph_ss[32];
    ret = micro_ecc_shared_secret_compute(&curve, app_sk, dev_pk, eph_ss);
    EXPECT_EQ(ret, 0);

    uint8_t hkdf_buf[128];
    memcpy(hkdf_buf, eph_ss, sizeof(eph_ss));
    memcpy(hkdf_buf + sizeof(eph_ss), s_ltk, sizeof(s_ltk));
    ret = sauth_crypto_hkdf_sha256(hkdf_buf, sizeof(eph_ss) + sizeof(s_ltk),
                                   NULL, 0,
                                   NULL, 0,
                                   (uint8_t *)&s_session_key, sizeof(s_session_key));
    EXPECT_EQ(ret, CRYPTO_OK);

    uint32_t app_crc32;
    vesync_crc32(0, dev_pk, sizeof(dev_pk), &app_crc32);
    uint8_t ciper[4];
    ciper[0] = (uint8_t)app_crc32;
    ciper[1] = (uint8_t)(app_crc32 >> 8);
    ciper[2] = (uint8_t)(app_crc32 >> 16);
    ciper[3] = (uint8_t)(app_crc32 >> 24);

    sauth_login_token_t login_token;
    uint8_t nonce[12] = {0};
    memcpy(nonce, s_session_key.app_iv, sizeof(s_session_key.app_iv));
    ret = sauth_crypto_ccm_encrypt(s_session_key.app_key,
                                   nonce, sizeof(nonce),
                                   NULL, 0,
                                   ciper, sizeof(ciper),
                                   login_token.ciper,
                                   login_token.mic, sizeof(login_token.mic));
    EXPECT_EQ(ret, CRYPTO_OK);

    send_to_sauth(SAUTH_CMD_INFO_LOGIN_TOKEN, (uint8_t *)&login_token, 8);
    vesync_sleep(150);

    SDK_LOG(LOG_WARN, "wait login_success\n");
    ret = vesync_queue_recv(s_dev_data_queue, &dev_data_queue, VESYNC_OS_WAIT_FOREVER);
    EXPECT_EQ(ret, VOS_OK);
    ret = parse_cmd_from_sauth(SAUTH_CMD_LOGIN_SUCCESS, dev_data_queue.buf, dev_data_queue.len, NULL, 0);
    EXPECT_EQ(ret, SDK_OK);
    vesync_free(dev_data_queue.buf);

    vesync_sleep(300);
}

TEST_F(vesync_sauth_test, sauth_hello_after_login_test)
{
    int ret;
    buffer_t dev_data_queue;

    send_to_sauth(SAUTH_CMD_HELLO, NULL, 0);
    vesync_sleep(200);

    sauth_dev_info_t dev_info;
    uint16_t dev_info_data_len;
    ret = vesync_queue_recv(s_dev_data_queue, &dev_data_queue, VESYNC_OS_WAIT_FOREVER);
    EXPECT_EQ(ret, VOS_OK);
    ret = parse_cmd_from_sauth(SAUTH_CMD_INFO_DEV, dev_data_queue.buf, dev_data_queue.len, (uint8_t *)&dev_info, &dev_info_data_len);
    EXPECT_EQ(ret, SDK_OK);
    vesync_free(dev_data_queue.buf);

    dev_info.version = vesync_le16toh(dev_info.version);
    EXPECT_EQ(dev_info.version, SAUTH_PROTOCOL_VERSION);
    EXPECT_EQ(dev_info.cipher_suit, SAUTH_CIPER_SUIT_ECDHE_REG_ECDSA_LOG_AES_128_CCM_SHA256);
    EXPECT_EQ(dev_info.io_capability, SAUTH_OOB_CAPABILITY_NO_WAY);

    SDK_LOG(LOG_WARN, "cipher_status: %x\n", dev_info.cipher_status);
    vesync_sleep(300);
}

TEST_F(vesync_sauth_test, session_ping_pong_test)
{
    const char dev_msg[] = "Hi, i'm device!";
    uint8_t *dev_enc_buf = (uint8_t *)vesync_malloc(sizeof(dev_msg) + 6);
    uint8_t *dev_dec_buf = (uint8_t *)vesync_malloc(sizeof(dev_msg));

    int ret = 0;
    uint16_t cnt_low = 0;

    ret = vesync_sauth_session_encrypt((uint8_t *)dev_msg,
                                       sizeof(dev_msg),
                                       dev_enc_buf,
                                       sizeof(dev_msg) + 6);
    EXPECT_EQ(ret, SDK_OK);

    cnt_low = dev_enc_buf[0] | (uint16_t)dev_enc_buf[1] << 8;
    SDK_LOG(LOG_INFO, "cnt_low for initial dev_nonce: %d\n", cnt_low);
    EXPECT_EQ(cnt_low, 1);

    sauth_sess_nonce_t nonce = {0};
    nonce.counter = 0;
    memcpy(nonce.iv, s_session_key.dev_iv, sizeof(s_session_key.dev_iv));
    ret = sauth_crypto_ccm_decrypt(s_session_key.dev_key,
                                   (uint8_t *)&nonce, sizeof(nonce),
                                   NULL, 0,
                                   dev_enc_buf + 2,
                                   sizeof(dev_msg),
                                   dev_dec_buf,
                                   dev_enc_buf + sizeof(dev_msg) + 2,
                                   4);
    EXPECT_EQ(ret, CRYPTO_ERR_CCM_AUTH_FAIL);

    nonce.counter = 1;
    LOG_RAW_HEX(LOG_INFO, "enc dev_tag:", dev_enc_buf + sizeof(dev_msg) + 2, 4);
    LOG_RAW_HEX(LOG_INFO, "enc dev_nonce:", (uint8_t *)&nonce, sizeof(nonce));
    LOG_RAW_HEX(LOG_INFO, "enc dev_key:", s_session_key.dev_key, sizeof(s_session_key.dev_key));
    ret = sauth_crypto_ccm_decrypt(s_session_key.dev_key,
                                   (uint8_t *)&nonce, sizeof(nonce),
                                   NULL, 0,
                                   dev_enc_buf + 2,
                                   sizeof(dev_msg),
                                   dev_dec_buf,
                                   dev_enc_buf + sizeof(dev_msg) + 2,
                                   4);
    EXPECT_EQ(ret, CRYPTO_OK);
    EXPECT_STREQ((const char *)dev_dec_buf, dev_msg);

    const char app_msg[] = "Hi, i'm app!";
    uint8_t *app_enc_buf = (uint8_t *)vesync_malloc(sizeof(app_msg) + 6);
    uint8_t *app_dec_buf = (uint8_t *)vesync_malloc(sizeof(app_msg));

    memcpy(nonce.iv, s_session_key.app_iv, sizeof(s_session_key.app_iv));

    nonce.counter = 1;
    ret = sauth_crypto_ccm_encrypt(s_session_key.app_key,
                                   (uint8_t *)&nonce, sizeof(nonce),
                                   NULL, 0,
                                   (uint8_t *)app_msg, sizeof(app_msg),
                                   app_enc_buf + 2,
                                   app_enc_buf + 2 + sizeof(app_msg),
                                   4);
    app_enc_buf[0] = nonce.counter;
    app_enc_buf[1] = nonce.counter >> 8;
    EXPECT_EQ(ret, CRYPTO_OK);

    ret = vesync_sauth_session_decrypt(app_enc_buf, sizeof(app_msg) + 6, app_dec_buf, sizeof(app_msg));
    EXPECT_EQ(ret, SDK_OK);
    EXPECT_STREQ((const char *)app_dec_buf, app_msg);

    ret = vesync_sauth_session_decrypt(app_enc_buf, sizeof(app_msg) + 6, app_dec_buf, sizeof(app_msg));
    EXPECT_EQ(ret, SDK_FAIL);

    nonce.counter = 0xffff;
    ret = sauth_crypto_ccm_encrypt(s_session_key.app_key,
                                   (uint8_t *)&nonce, sizeof(nonce),
                                   NULL, 0,
                                   (uint8_t *)app_msg, sizeof(app_msg),
                                   app_enc_buf + 2,
                                   app_enc_buf + 2 + sizeof(app_msg),
                                   4);
    app_enc_buf[0] = nonce.counter;
    app_enc_buf[1] = nonce.counter >> 8;
    EXPECT_EQ(ret, CRYPTO_OK);

    ret = vesync_sauth_session_decrypt(app_enc_buf, sizeof(app_msg) + 6, app_dec_buf, sizeof(app_msg));
    EXPECT_EQ(ret, SDK_OK);

    ret = vesync_sauth_session_decrypt(app_enc_buf, sizeof(app_msg) + 6, app_dec_buf, sizeof(app_msg));
    EXPECT_EQ(ret, SDK_FAIL);

    nonce.counter = 0xffff + 1;
    ret = sauth_crypto_ccm_encrypt(s_session_key.app_key,
                                   (uint8_t *)&nonce, sizeof(nonce),
                                   NULL, 0,
                                   (uint8_t *)app_msg, sizeof(app_msg),
                                   app_enc_buf + 2,
                                   app_enc_buf + 2 + sizeof(app_msg),
                                   4);
    app_enc_buf[0] = nonce.counter;
    app_enc_buf[1] = nonce.counter >> 8;
    EXPECT_EQ(ret, CRYPTO_OK);

    ret = vesync_sauth_session_decrypt(app_enc_buf, sizeof(app_msg) + 6, app_dec_buf, sizeof(app_msg));
    EXPECT_EQ(ret, SDK_OK);

    ret = vesync_sauth_session_decrypt(app_enc_buf, sizeof(app_msg) + 6, app_dec_buf, sizeof(app_msg));
    EXPECT_EQ(ret, SDK_FAIL);

    nonce.counter = 0xffff + 2;
    ret = sauth_crypto_ccm_encrypt(s_session_key.app_key,
                                   (uint8_t *)&nonce, sizeof(nonce),
                                   NULL, 0,
                                   (uint8_t *)app_msg, sizeof(app_msg),
                                   app_enc_buf + 2,
                                   app_enc_buf + 2 + sizeof(app_msg),
                                   4);
    app_enc_buf[0] = nonce.counter;
    app_enc_buf[1] = nonce.counter >> 8;
    EXPECT_EQ(ret, CRYPTO_OK);

    ret = vesync_sauth_session_decrypt(app_enc_buf, sizeof(app_msg) + 6, app_dec_buf, sizeof(app_msg));
    EXPECT_EQ(ret, SDK_OK);

    ret = vesync_sauth_session_decrypt(app_enc_buf, sizeof(app_msg) + 6, app_dec_buf, sizeof(app_msg));
    EXPECT_EQ(ret, SDK_FAIL);

    vesync_free(dev_enc_buf);
    vesync_free(dev_dec_buf);
    vesync_free(app_enc_buf);
    vesync_free(app_dec_buf);
}