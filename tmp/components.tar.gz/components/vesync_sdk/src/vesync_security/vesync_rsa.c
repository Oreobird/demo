/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_security.c
 * @brief       安全相关接口
 * @author      Joshua
 * @date        2021-04-26
 */

#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
#include "mbedtls/pk.h"
#include "mbedtls/ctr_drbg.h"
#include "mbedtls/entropy.h"

#include "vesync_log_internal.h"
#include "vesync_memory.h"
#include "vesync_common.h"
#include "vesync_rsa.h"


#if defined(CONFIG_TARGET_RTL8710CX) || defined(CONFIG_TARGET_RTL8720CF)
#include "mbedtls/platform.h"

#if defined(MBEDTLS_PKCS1_V15)
static int myrand( void *rng_state, unsigned char *output, size_t len )
{
#if !defined(__OpenBSD__)
    size_t i;

    if( rng_state != NULL )
        rng_state  = NULL;

    for( i = 0; i < len; ++i )
        output[i] = rand();
#else
    if( rng_state != NULL )
        rng_state = NULL;

    arc4random_buf( output, len );
#endif /* !OpenBSD */

    return( 0 );
}
#endif /* MBEDTLS_PKCS1_V15 */

/**
 * @brief 使用rsa public key加密数据
 * @param[in]  in_data              [输入数据]
 * @param[in]  in_data_len          [输入数据长度]
 * @param[out] out_buffer           [输出数据缓冲地址]
 * @param[out] out_len              [输出数据长度]
 * @param[out] out_buffer_size      [输出数据缓冲大小]
 * @param[in]  pk_pem               [public key pem格式]
 * @param[in]  pk_len               [public key 长度]
 * @return     int                  [SDK_OK加密成功  , SDK_FAIL加密失败]
 */
int vesync_rsa_pk_encrypt(uint8_t *in_data, size_t in_data_len, uint8_t *out_buffer,
                size_t *out_len, size_t out_buffer_size, const char *pk_pem, size_t pk_len)
{
    VCOM_NULL_PARAM_CHK(in_data, return SDK_FAIL);
    VCOM_NULL_PARAM_CHK(out_buffer, return SDK_FAIL);
    VCOM_NULL_PARAM_CHK(out_len, return SDK_FAIL);
    VCOM_NULL_PARAM_CHK(pk_pem, return SDK_FAIL);

    UNUSED(out_buffer_size);

    int result = -1;
    mbedtls_pk_context pk;

    SDK_LOG(LOG_DEBUG, "pk_len=%d, strlen(pk_pem)=%d\n", pk_len, strlen(pk_pem));

    // 若不调用该API进行注册，会导致系统崩溃，
    mbedtls_platform_set_calloc_free(vesync_calloc, vesync_free);

    mbedtls_pk_init(&pk);

    result = mbedtls_pk_parse_public_key(&pk, (unsigned char *)pk_pem, pk_len);
    if (result != 0)
    {
        SDK_LOG(LOG_ERROR, "mbedtls_pk_parse_public_key failed, ret = 0x%x\n", result);
        mbedtls_pk_free(&pk);
        return SDK_FAIL;
    }

    if (mbedtls_pk_get_type(&pk) == MBEDTLS_PK_RSA)
    {
        mbedtls_rsa_context *rsa = mbedtls_pk_rsa(pk);
        if (mbedtls_rsa_check_pubkey(rsa) != 0)
        {
            SDK_LOG(LOG_ERROR,"mbedtls_rsa_check_pubkey failed\n");
        }

        result = mbedtls_rsa_pkcs1_encrypt(rsa, myrand, NULL, MBEDTLS_RSA_PUBLIC,
                    in_data_len, (unsigned char *)in_data, (unsigned char *)out_buffer);
        if (result != 0)
        {
            SDK_LOG(LOG_ERROR, "mbedtls_rsa_pkcs1_encrypt failed\n");
            *out_len = 0;
            mbedtls_pk_free(&pk);
            return SDK_FAIL;
        }
        else
        {
            // 一次加密的数据长度为:密钥长度(1024bit)／8-11
            if (in_data_len < 128 - 11)
            {
                *out_len = 128;     // RSA1024/AES128/CBC-PKCS1Padding.密文长度为：密钥长度(1024bit)／8
            }
            else
            {
                *out_len = strlen((char *)out_buffer);
            }
            SDK_LOG(LOG_DEBUG, "*out_len = %d\n", *out_len);
        }
    }

    mbedtls_pk_free(&pk);
    return SDK_OK;
}

#else
/**
 * @brief 使用rsa public key加密数据
 * @param[in]  in_data              [输入数据]
 * @param[in]  in_data_len          [输入数据长度]
 * @param[out] out_buffer           [输出数据缓冲地址]
 * @param[out] out_len              [输出数据长度]
 * @param[out] out_buffer_size      [输出数据缓冲大小]
 * @param[in]  pk_pem               [public key pem格式]
 * @param[in]  pk_len               [public key 长度]
 * @return     int                  [SDK_OK加密成功  , SDK_FAIL加密失败]
 */
int vesync_rsa_pk_encrypt(uint8_t *in_data, size_t in_data_len, uint8_t *out_buffer,
                size_t *out_len, size_t out_buffer_size, const char *pk_pem, size_t pk_len)
{
    VCOM_NULL_PARAM_CHK(in_data, return SDK_FAIL);
    VCOM_NULL_PARAM_CHK(out_buffer, return SDK_FAIL);
    VCOM_NULL_PARAM_CHK(out_len, return SDK_FAIL);
    VCOM_NULL_PARAM_CHK(pk_pem, return SDK_FAIL);

    int ret = 1;
    int exit_code = SDK_OK;

    mbedtls_pk_context pk;
    mbedtls_entropy_context entropy;
    mbedtls_ctr_drbg_context ctr_drbg;
    const char *pers = "mbedtls_pk_encrypt";

    mbedtls_ctr_drbg_init(&ctr_drbg);
    mbedtls_entropy_init(&entropy);
    mbedtls_pk_init(&pk);

    do
    {
        ret = mbedtls_ctr_drbg_seed(&ctr_drbg, mbedtls_entropy_func, &entropy,
                                    (const unsigned char *)pers, strlen(pers));
        if (ret != 0)
        {
            SDK_LOG(LOG_ERROR," failed! mbedtls_ctr_drbg_seed returned -0x%04x\n",-ret );
            exit_code = SDK_FAIL;
            break;
        }

        ret = mbedtls_pk_parse_public_key(&pk, (const unsigned char*)pk_pem, pk_len);
        if(ret != 0)
        {
            SDK_LOG(LOG_ERROR,"parse public key fail, ret = -0x%04x\n", -ret);
            exit_code = SDK_FAIL;
            break;
        }

        ret = mbedtls_pk_encrypt(&pk, in_data, in_data_len,
                                 out_buffer, out_len, out_buffer_size,
                                 mbedtls_ctr_drbg_random, &ctr_drbg);
        if (ret != 0)
        {
            SDK_LOG(LOG_ERROR, " failed! mbedtls_pk_encrypt returned -0x%04x\n",-ret );
            exit_code = SDK_FAIL;
            break;
        }
    } while (0);

    mbedtls_pk_free(&pk);
    mbedtls_entropy_free(&entropy);
    mbedtls_ctr_drbg_free(&ctr_drbg);

    return exit_code;
}
#endif

