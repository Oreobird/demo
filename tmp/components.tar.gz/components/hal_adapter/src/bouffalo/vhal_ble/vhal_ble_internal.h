/**
 * Copyright © Vesync Technologies Co.Ltd. 2019-2021. All rights reserved.
 * @file    vhal_ble_internal.h
 * @brief   蓝牙hal配置ble服务属性接口
 * @author  Louis
 * @date    2019-03-24
 */

#ifndef __VHAL_BLE_INTERNAL_H__
#define __VHAL_BLE_INTERNAL_H__

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "vesync_common.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief Attributes Indexs
 */
enum{
    ATTR_IDX_SVC,
    ATTR_IDX_CHAR_NOTIFY,
    ATTR_IDX_CCC,
    ATTR_IDX_CHAR_WRITE,
};



typedef struct
{
    bool    ble_init;
    bool    adv_start;
    bool    notify_flag;
    VHAL_BLE_ADV_WORK_E ble_adv_work;
    struct bt_conn *conn;
    uint16_t    tx_mtu;
}ble_runnint_stat_t;

#define ADV_NAME_MAX_LEN        (29)    // scan rsp最大数据长度
#define APP_ADV_INTERVAL_MIN    (0x200) // The advertising interval (in units of 0.625 ms. This value corresponds to 300 ms).
#define APP_ADV_INTERVAL_MAX    (0x200) // The advertising interval (in units of 0.625 ms. This value corresponds to 300 ms).
#define ATT_OPCODE_HANDLE_LEN   (3)     // 3是蓝牙协议att层数据包的头opcode+handle

/* user Service characteristic*/
#define GATTS_SERVICE_CMD_UUID          BT_UUID_DECLARE_16(0xFFF0)
#define GATTS_CHAR_CMD_NOTIFY_UUID      BT_UUID_DECLARE_16(0xFFF1)
#define GATTS_CHAR_CMD_WRITE_UUID       BT_UUID_DECLARE_16(0xFFF2)

#define GATTS_SERVICE_NET_CFG_UUID      BT_UUID_DECLARE_128(BT_UUID_128_ENCODE(0xF000FFE0, 0x0451, 0x4000, 0xB000, 0x000000000000))
#define GATTS_CHAR_NET_CFG_WRITE_UUID   BT_UUID_DECLARE_128(BT_UUID_128_ENCODE(0xF000FFE1, 0x0451, 0x4000, 0xB000, 0x000000000000))
#define GATTS_CHAR_NET_CFG_NOTIFY_UUID  BT_UUID_DECLARE_128(BT_UUID_128_ENCODE(0xF000FFE2, 0x0451, 0x4000, 0xB000, 0x000000000000))

#define GATTS_UPDATE_SERVICE_UUID       BT_UUID_DECLARE_128(BT_UUID_128_ENCODE(0xF000FFC0, 0x0451, 0x4000, 0xB000, 0x000000000000))
#define GATTS_UPDATE_CHAR_NOTIFY_UUID   BT_UUID_DECLARE_128(BT_UUID_128_ENCODE(0xF000FFC1, 0x0451, 0x4000, 0xB000, 0x000000000000))
#define GATTS_UPDATE_CHAR_WRITE_UUID    BT_UUID_DECLARE_128(BT_UUID_128_ENCODE(0xF000FFC2, 0x0451, 0x4000, 0xB000, 0x000000000000))


/**
 * @brief 关闭蓝牙协议栈，释放蓝牙资源
 */
void vhal_ble_deinit(void);


/**
 * @brief 动态修改广播参数
 * @param product_type
 * @param product_model
 * @return int32_t 0：成功，非零失败
 */
int32_t vhal_ble_set_adv_product_info(uint8_t product_type,uint8_t product_model);

/**
 * @brief 动态修改蓝牙广播名称
 * @param name
 * @return int32_t 0：成功，非零失败
 */
int32_t vhal_ble_set_device_name(char *name);


/**
 * @brief 更新蓝牙连接间隔
 * @param min_interval min_interval = x*1.25ms
 * @param max_interval max_interval = x*1.25ms
 * @param time_out     timeout = x*10ms
 * @return int32_t 0：成功，非零失败
 *
 * interval Max*(slave latency+1)<=2s
 * interval min>=20ms
 * interval min+20ms<=interval max
 * slve latency<=4
 * connsupervisiontimeout <= 6s
 * interval max*(slave latency+1)*3 < connsupervisiontimeout
 */
int32_t vhal_ble_update_connect_interval(uint16_t min_interval,uint16_t max_interval,uint16_t timeout);


/**
 * @brief 蓝牙广播动态修改配网状态
 * @param netcfg_status 设备配网状态
 * @return int32_t 0：成功，非零失败
 */
int32_t vhal_ble_set_adv_netcfg_status(uint8_t netcfg_status);


#ifdef __cplusplus
}
#endif

#endif /* __VHAL_BLE_INTERNAL_H__ */
