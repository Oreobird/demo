/**
 * Copyright © Vesync Technologies Co.Ltd. 2021-2022. All rights reserved.
 * @file        vesync_schedule.c
 * @brief       Schedule 模块实现
 * @author      Herve.Lin & Haley.Huang
 * @date        2022-01-21
 */
#include <time.h>
#include <string.h>

#include "vhal_utils.h"

#include "vesync_timer.h"
#include "vesync_memory.h"
#include "vesync_common.h"
#include "vesync_log_internal.h"
#include "vesync_timebase_internal.h"
#include "vesync_schedule_mgmt.h"

// Schedule内部创建锁宏
#define SCHEDULE_NEW_LOCK(m, err)         \
    do {                                  \
        m = vesync_recursive_mutex_new(); \
        SCHEDULE_CHECK(m != NULL, err);   \
    } while(0)
// Schedule内部销毁锁宏
#define SCHEDULE_DEL_LOCK(m)            \
    do {                                \
        vesync_recursive_mutex_free(m); \
        m = NULL;                       \
    } while(0)
// Schedule内部请求递归锁宏
#define SCHEDULE_LOCK(m, err) SCHEDULE_CHECK(VOS_OK == vesync_recursive_mutex_try_lock(m), err)
// Schedule内部释放递归锁宏
#define SCHEDULE_UNLOCK(m) vesync_recursive_mutex_unlock(m)

#if 0
/**
 * @brief 计算两个32位无符号数的差值
 * @param[in] num_a                 [算数A]
 * @param[in] num_b                 [算数B]
 * @return uint32_t                 [差值]
 */
static uint32_t diff_uint32(uint32_t num_a, uint32_t num_b)
{
    if (num_a >= num_b)
    {
        return num_a - num_b;
    }

    return num_b - num_a;
}
#endif

/**
 * @brief 计算两个32位有符号数的差值
 * @param[in] num_a                 [算数A]
 * @param[in] num_b                 [算数B]
 * @return uint32_t                 [差值]
 */
static int64_t diff_int32(int32_t num_a, int32_t num_b)
{
    if (num_a >= num_b)
    {
        return (int64_t)num_a - (int64_t)num_b;
    }

    return (int64_t)num_b - (int64_t)num_a;
}

/**
 * @brief 基于分钟比较两个时间戳
 * @param[in] ts_a                  [被比较时间戳A]
 * @param[in] ts_b                  [被比较时间戳B]
 * @return int32_t
 *      ret > 0                     [ts_a > ts_b]
 *      ret = 0                     [ts_a = ts_b]
 *      ret < 0                     [ts_a < ts_b]
 */
static int32_t ts_min_cmp(uint32_t ts_a, uint32_t ts_b)
{
    uint32_t ts_a_min = ts_a / (uint32_t)VCOM_SECOND_PER_MIN;
    uint32_t ts_b_min = ts_b / (uint32_t)VCOM_SECOND_PER_MIN;

    return (int32_t)ts_a_min - (int32_t)ts_b_min;
}

/**
 * @brief 获取24小时内到达下一个秒时刻的时间差
 * @param[in] start_sec             [起始时间]
 * @param[in] target_sec            [目标时间]
 * @return uint32_t                 [时间差秒]
 */
static uint32_t get_clock_sec_diff(uint32_t start_sec, uint32_t target_sec)
{
    uint32_t diff_sec = 0;

    if(start_sec < target_sec)
    {
        diff_sec = target_sec - start_sec;
    }
    else
    {
        diff_sec = (uint32_t)VCOM_SECOND_PER_DAY - start_sec + target_sec;
    }

    return diff_sec;
}

/**
 * @brief 基于分钟比较两个偏移值
 * @param[in] ofs_a                 [被比较秒偏移值A]
 * @param[in] ofs_b                 [被比较秒偏移值B]
 * @return int32_t
 *      ret > 0                     [ofs_a > ofs_b]
 *      ret = 0                     [ofs_a = ofs_b]
 *      ret < 0                     [ofs_a < ofs_b]
 */
static int32_t ofs_min_cmp(int32_t ofs_a, int32_t ofs_b)
{
    int32_t ofs_a_min = ofs_a / (int32_t)VCOM_SECOND_PER_MIN;
    int32_t ofs_b_min = ofs_b / (int32_t)VCOM_SECOND_PER_MIN;

    return ofs_a_min - ofs_b_min;
}

/**
 * @brief 检查Schedule配置的参数合法性
 * @param[in] p_sch_cfg             [指向Schedule配置]
 * @return true                     [参数合法]
 * @return false                    [参数非法]
 */
static bool check_schedule_cfg(vesync_schedule_t *p_sch_cfg)
{
    switch (p_sch_cfg->type)
    {
    case SCHE_TMG_EVT:
        // 定时类型的时间时刻设置不允许超过23:59:59
        if (p_sch_cfg->event_config.timing.clock_sec >= VCOM_SECOND_PER_DAY)
        {
            return false;
        }
        break;
    case SCHE_SUN_EVT:
        // 日出日落的偏移设置不允许超过边界条件正负1天
        if (diff_int32(p_sch_cfg->event_config.sun.offset_sec, 0) >= (int64_t)VCOM_SECOND_PER_DAY)
        {
            return false;
        }
        break;
    default:
        return false;
    }

    return true;
}

#if SCHEDULE_DEBUG_PRINT == 1
/**
 * @brief 打印Schedule配置项的调试信息
 * @param[in] p_sch_cfg             [指向Schedule配置项]
 */
static void print_schedule_cfg(vesync_schedule_t *p_sch_cfg)
{
    if (p_sch_cfg->type == SCHE_TMG_EVT)
    {
        SDK_LOG(LOG_DEBUG, "ID:[%ld], en:[%d], type:[%d], clk_sec:[%ld], rpt_cfg:[%d]\n",
                p_sch_cfg->id, p_sch_cfg->enabled, p_sch_cfg->type,
                p_sch_cfg->event_config.timing.clock_sec, p_sch_cfg->repeat_config);
    }

    if (p_sch_cfg->type == SCHE_SUN_EVT)
    {
        SDK_LOG(LOG_DEBUG, "ID:[%ld], en:[%d], type:[%d], is_sr:[%d], ofs_sec:[%ld], rpt_cfg:[%d]\n",
                p_sch_cfg->id, p_sch_cfg->enabled, p_sch_cfg->type,
                p_sch_cfg->event_config.sun.is_sunrise,
                p_sch_cfg->event_config.sun.offset_sec, p_sch_cfg->repeat_config);
    }
}
#endif

/**
 * @brief 把序列化的配置信息读取到Schedule实例中
 * @param[in]  p_obj                [指向Schedule对象]
 * @return int                      [SCHE_RESULT_E]
 */
static int rd_nvm_cfg_to_sche_mgt(schedule_obj_t *p_obj)
{
    int ret = SCHE_OK;

    // 先获取配置长度
    uint32_t cfg_len;
    ret = p_obj->param.rd_cfg_cb(NULL, 0, &cfg_len);
    if (SCHE_OK != ret)
    {
        return SCHE_CFG_ERR;
    }
    if (0 == cfg_len)
    {
        return SCHE_CFG_NO_EXIST;
    }
#if SCHEDULE_DEBUG_PRINT == 1
    SDK_LOG(LOG_DEBUG, "config len:[%ld]\n", cfg_len);
#endif

    // 申请缓存
    uint8_t *p_buf = (uint8_t *)vesync_malloc(cfg_len);
    if (NULL == p_buf)
    {
        SDK_LOG(LOG_ERROR, "buffer malloc fail\n");
        return SCHE_MEM_ERR;
    }

    // 读取配置信息
    uint32_t rd_len;
    ret = p_obj->param.rd_cfg_cb(p_buf, cfg_len, &rd_len);
    if (SCHE_OK != ret)
    {
        goto EXIT;
    }
#if SCHEDULE_DEBUG_PRINT == 1
    SDK_LOG(LOG_DEBUG, "read config, size[%ld]\n", rd_len);
#endif
    if (rd_len != cfg_len)
    {
        ret = SCHE_CFG_ERR;
        goto EXIT;
    }

    // 将配置应用到 Schedule 实例
    ret = sche_cfg_unmarshal(p_buf, rd_len, &p_obj->schedules, &p_obj->schedule_nbr);
    if (SCHE_OK != ret)
    {
        goto EXIT;
    }

EXIT:
    vesync_free(p_buf);
    return ret;
}

/**
 * @brief 把Schedule实例中的配置信息序列化
 * @param[in]  p_obj                [指向Schedule对象]
 * @return int                      [SCHE_RESULT_E]
 */
static int wr_sche_mgt_cfg_to_nvm(schedule_obj_t *p_obj)
{
    int ret = SCHE_OK;

    // 计算序列化完的数据大小用来申请缓存
    uint32_t cfg_len;
    ret = sche_cfg_marshal(p_obj->schedule_nbr, &p_obj->schedules, NULL, 0, &cfg_len);
    if (SCHE_OK != ret)
    {
        return SCHE_CFG_ERR;
    }
#if SCHEDULE_DEBUG_PRINT == 1
    SDK_LOG(LOG_DEBUG, "config len:[%ld]\n", cfg_len);
#endif

    // 申请缓存
    uint8_t *p_buf = (uint8_t *)vesync_malloc(cfg_len);
    if (NULL == p_buf)
    {
        SDK_LOG(LOG_ERROR, "buffer malloc fail\n");
        return SCHE_MEM_ERR;
    }

    // 序列化 Schedule 实例中的配置信息
    uint32_t wr_len = 0;
    ret = sche_cfg_marshal(p_obj->schedule_nbr, &p_obj->schedules, p_buf, cfg_len, &wr_len);
    if (SCHE_OK != ret)
    {
        goto EXIT;
    }
#if SCHEDULE_DEBUG_PRINT == 1
    SDK_LOG(LOG_DEBUG, "write config, size[%ld]\n", wr_len);
#endif
    if (wr_len != cfg_len)
    {
        ret = SCHE_CFG_ERR;
        goto EXIT;
    }

    // 写入配置
    ret = p_obj->param.wr_cfg_cb(p_buf, wr_len);
    if (SCHE_OK != ret)
    {
        goto EXIT;
    }

EXIT:
    vesync_free(p_buf);
    return ret;
}

/**
 * @brief 计算日出日落配置项的执行时刻
 * @param[in]   p_tb_info           [时基信息]
 * @param[in]   p_cfg               [日出日落配置项]
 * @param[out]  p_exec_clk          [输出的执行时刻值]
 * @return      bool                [true:计算成功; false:时基的日出日落时间不合法]
 */
static bool get_suntime_exec_clk(timebase_info_t *p_tb_info, vesync_schedule_t *p_cfg, uint32_t *p_exec_clk)
{
    int32_t suntime_clk = (int32_t)p_cfg->event_config.sun.offset_sec;
    bool is_valid = false;
    if (p_cfg->event_config.sun.is_sunrise)
    {
        suntime_clk += (int32_t)p_tb_info->sunrise_clk;
        is_valid = p_tb_info->is_sunrise_valid;
    }
    else
    {
        suntime_clk += (int32_t)p_tb_info->sunset_clk;
        is_valid = p_tb_info->is_sunset_valid;
    }
    if (!is_valid)
    {
#if SCHEDULE_DEBUG_PRINT == 1
        SDK_LOG(LOG_DEBUG, "invalid sun-time of timebase\n");
#endif
        return false;
    }
    // 有suntime_clk ∈ (-VCOM_SECOND_PER_DAY, 2*VCOM_SECOND_PER_DAY-2)
    if (suntime_clk < 0)
    {
        *p_exec_clk = (uint32_t)(suntime_clk + VCOM_SECOND_PER_DAY);
    }
    else if (suntime_clk >= VCOM_SECOND_PER_DAY)
    {
        *p_exec_clk = (uint32_t)(suntime_clk % VCOM_SECOND_PER_DAY);
    }
    else
    {
        *p_exec_clk = (uint32_t)suntime_clk;
    }
    return true;
}

/**
 * @brief 根据UTC，比较两个配置项是否有冲突
 * @note  冲突判断标准参考WIKI: https://wiki.vesync.cn/pages/viewpage.action?pageId=179568856
 * @param[in] p_tb_info             [时基信息]
 * @param[in] utc                   [指定的UTC值]
 * @param[in] cfg_a                 [待相比较的配置A]
 * @param[in] cfg_b                 [待相比较的配置B]
 * @return int                      [SCHE_OK：没有冲突, SCHE_CFLT_ERR：配置项存在冲突]
 */
static int check_cfg_conflict(timebase_info_t *p_tb_info, uint32_t utc, vesync_schedule_t *cfg_a, vesync_schedule_t *cfg_b)
{
#if SCHEDULE_DEBUG_PRINT == 1
    SDK_LOG(LOG_DEBUG, "Schedule check conflict\n");
    print_schedule_cfg(cfg_a);
    print_schedule_cfg(cfg_b);
#endif

    // 类型不同返回不冲突
    if (cfg_a->type != cfg_b->type)
    {
        return SCHE_OK;
    }
    // 有一个配置不是使能就判断为不冲突
    if (true != (cfg_a->enabled & cfg_b->enabled))
    {
        return SCHE_OK;
    }

    uint32_t local_clk = p_tb_info->local_clk_sec;
    uint32_t exec_clk = 0;

    uint8_t cal_weekday_a = cfg_a->repeat_config;
    uint8_t cal_weekday_b = cfg_b->repeat_config;

    if (cfg_a->type == SCHE_TMG_EVT)
    {
        if (0 != ts_min_cmp(cfg_a->event_config.timing.clock_sec, cfg_b->event_config.timing.clock_sec))
        {
            return SCHE_OK;
        }
        exec_clk = cfg_a->event_config.timing.clock_sec;
    }

    if (cfg_a->type == SCHE_SUN_EVT)
    {
#if SCHEDULE_DEBUG_PRINT == 1
        SDK_LOG(LOG_DEBUG, "check_sr: %d, %d\n", cfg_a->event_config.sun.is_sunrise, cfg_b->event_config.sun.is_sunrise);
#endif
        // 判断日出日落冲突
        if (cfg_a->event_config.sun.is_sunrise != cfg_b->event_config.sun.is_sunrise)
        {
            return SCHE_OK;
        }
#if SCHEDULE_DEBUG_PRINT == 1
        SDK_LOG(LOG_DEBUG, "check_ofs: %d, %d\n", cfg_a->event_config.sun.offset_sec, cfg_b->event_config.sun.offset_sec);
#endif
        // 判断执行时间冲突
        if (0 != ofs_min_cmp(cfg_a->event_config.sun.offset_sec, cfg_b->event_config.sun.offset_sec))
        {
            return SCHE_OK;
        }
        if (false == get_suntime_exec_clk(p_tb_info, cfg_a, &exec_clk))
        {
            // 日出日落时间非法，不做冲突判断
            return SCHE_OK;
        }
#if SCHEDULE_DEBUG_PRINT == 1
        SDK_LOG(LOG_DEBUG, "today_sr_or_ss: %u\n", exec_clk);
#endif
    }
    // 定时Once类型跳一天逻辑的实现和日出日落Once类型跳一天逻辑的实现:
    //   对于Once类型，如果给定的UTC对应的本地时间大于配置里的时刻，
    //   那么Schedule实际上会在那个相应本地时间的后一天被触发
    if (TMBS_ONCE == cal_weekday_a)
    {
        cal_weekday_a = vesync_timebase_ts_to_weekday(p_tb_info->local_ts, (ts_min_cmp(local_clk, exec_clk) > 0) ? 1 : 0);
    }
    if (TMBS_ONCE == cal_weekday_b)
    {
        cal_weekday_b = vesync_timebase_ts_to_weekday(p_tb_info->local_ts, (ts_min_cmp(local_clk, exec_clk) > 0) ? 1 : 0);
    }
#if SCHEDULE_DEBUG_PRINT == 1
    SDK_LOG(LOG_DEBUG, "check_week: %d, %d\n", cal_weekday_a, cal_weekday_b);
#endif
    // 满足了前面的冲突条件，最后判断星期存不存在冲突
    if (cal_weekday_a & cal_weekday_b)
    {
        return SCHE_CFLT_ERR;
    }

    return SCHE_OK;
}

/**
 * @brief Schedule调度器Timer Callback Function
 * @param[in] arg                   [指向Schedule实例对象]
 */
static void schedule_cycle_loop(void *arg)
{
    schedule_obj_t *p_obj = (schedule_obj_t *)arg;
    SCHEDULE_CHECK(p_obj != NULL, return);
    // 读取系统UTC时间
    uint32_t now_utc = vhal_utils_get_system_time_sec();
    // 这里是为了确保一分钟只执行一次的遍历
    if (now_utc / VCOM_SECOND_PER_MIN == p_obj->last_loop_min)
    {
        return;
    }
    // 如果拿不到锁，这一分钟还是要继续轮询
    SCHEDULE_LOCK(p_obj->mutex, return);
    // 更新分钟计数
    p_obj->last_loop_min = now_utc / VCOM_SECOND_PER_MIN;

    timebase_info_t tb_info;
    if (TMBS_OK != vesync_timebase_get_info(now_utc, &tb_info))
    {
#if SCHEDULE_DEBUG_PRINT == 1
        SDK_LOG(LOG_WARN, "get timebase fail\n");
#endif
        SCHEDULE_UNLOCK(p_obj->mutex);
        return;
    }

    bool cfg_changed = false; // 实例中的配置内容是否变更的标志位
    uint32_t now_local_ts = tb_info.local_ts;
    uint32_t now_clk_sec = tb_info.local_clk_sec;
    uint8_t now_weekday = vesync_timebase_ts_to_weekday(tb_info.local_ts, 0);

#if SCHEDULE_DEBUG_PRINT == 1
    SDK_LOG(LOG_DEBUG, "local_clock_sec=%ld, weekday=%d\n", now_clk_sec, now_weekday);
#endif

    schedule_ctx_t *p_ctx = NULL;
    schedule_node_t *p_pos, *p_n;
    struct list_head *p_head = &p_obj->schedules;
    list_for_each_entry_safe(p_pos, p_n, p_head, list)
    {
        p_ctx = &p_pos->data;
        if (!p_ctx->config.enabled)
        {
            continue;
        }

        uint32_t exec_sec_clk = 0;
        if (SCHE_TMG_EVT == p_ctx->config.type)
        {
            exec_sec_clk = p_ctx->config.event_config.timing.clock_sec;
        }
        if (SCHE_SUN_EVT == p_ctx->config.type)
        {
            if (false == get_suntime_exec_clk(&tb_info, &p_ctx->config, &exec_sec_clk))
            {
                continue;
            }
        }

        // 先判断非重复任务是否过期,以避免断电重启产生的过期任务不能及时被刷新，时区同步后仅判断一次。
        if ((!p_obj->is_check_time_out) && (!p_ctx->config.repeat_config))
        {
            // 发现执行的时刻已经超过24小时，认为发生断电，不予执行
            if ((p_ctx->modify_local_ts + VCOM_SECOND_PER_DAY) < (now_local_ts + get_clock_sec_diff(now_clk_sec, exec_sec_clk)))
            {
                p_ctx->config.enabled = false;
                cfg_changed = true;
                SDK_LOG(LOG_WARN, "task expires. sch_id:[%ld], sch_mod_local_ts:%ld, now_local_ts:%ld\n",
                        p_ctx->config.id,
                        p_ctx->modify_local_ts,
                        now_local_ts);
                continue;
            }
        }

        // 判断时刻是否触发
        if (0 != ts_min_cmp(now_clk_sec, exec_sec_clk))
        {
            continue;
        }
        // Weekly 配置
        if (p_ctx->config.repeat_config)
        {
            // 判断星期是否触发
            if (!(p_ctx->config.repeat_config & now_weekday))
            {
                continue;
            }
        }
        // Once 配置
        else
        {
            p_ctx->config.enabled = false;
            cfg_changed = true;
        }
        // 执行任务处理回调
        p_obj->param.exec_app_task_cb(p_ctx->config, p_ctx->app_cfg);
        p_ctx->exec_cnt++;
        cfg_changed = true;
    }

    if (cfg_changed)
    {
        if (wr_sche_mgt_cfg_to_nvm(p_obj) != SCHE_OK)
        {
            SDK_LOG(LOG_ERROR, "write NVM fail\n");
        }
    }

    p_obj->is_check_time_out = true;

    SCHEDULE_UNLOCK(p_obj->mutex);
}

/**
 * @brief 启动Schedule调度器
 * @param[in] obj                   [Schedule实例对象]
 */
static void schedule_cycle_start(schedule_obj_t *p_obj)
{
    if (p_obj->is_running)
    {
        return;
    }

    p_obj->timer = vesync_timer_new("schedule",
                                    schedule_cycle_loop,
                                    p_obj,
                                    SCHEDULE_CYCLE_TIMER_INTERVAL,
                                    true);
    if (NULL == p_obj->timer)
    {
        SDK_LOG(LOG_ERROR, "create timer fail\n");
        return;
    }
    if (VOS_OK != vesync_timer_start(p_obj->timer))
    {
        SDK_LOG(LOG_ERROR, "start timer fail\n");
        // 销毁启动失败的Timer
        vesync_timer_free(p_obj->timer);
        p_obj->timer = NULL;
        return;
    }

    p_obj->is_running = true;
}

/**
 * @brief 停止Schedule调度器
 * @param[in] obj                   [Schedule实例对象]
 */
static void schedule_cycle_stop(schedule_obj_t *p_obj)
{
    if (!p_obj->is_running)
    {
        return;
    }

    if (VOS_OK != vesync_timer_free(p_obj->timer))
    {
        SDK_LOG(LOG_ERROR, "stop timer fail\n");
        return;
    }
    p_obj->timer = NULL;

    p_obj->is_running = false;
}

/**
 * @brief Schedule 申请一个新的ID
 * @param[in]  p_obj                [指向Schedule对象]
 * @param[out] p_new_id             [指向新ID的缓存]
 * @return int                      [SCHE_RESULT_E]
 */
static int get_new_next_id(schedule_obj_t *p_obj, uint32_t *p_new_id)
{
    uint32_t cur_max_id = p_obj->param.min_id_limit;

    schedule_node_t *p_pos, *p_n;
    struct list_head *p_head = &p_obj->schedules;
    list_for_each_entry_safe(p_pos, p_n, p_head, list)
    {
        if ((p_pos->data.config.id > 0) && (p_pos->data.config.id > cur_max_id))
        {
            cur_max_id = p_pos->data.config.id;
        }
    }

    *p_new_id = cur_max_id + 1;

    return SCHE_OK;
}

/**
 * @brief 清空Schedule链表
 * @param[in] p_head                [指向链表头]
 * @return int                      [返回清除的节点数量]
 */
static int clear_sch_cfg_list(struct list_head *p_head)
{
    int cnt = 0;

    // 链表非空，进行遍历删除
    if (!list_empty(p_head))
    {
        schedule_node_t *p_pos, *p_n;
        list_for_each_entry_safe(p_pos, p_n, p_head, list)
        {
            // 实际清除的配置项计数
            cnt++;
            // 销毁链表节点
            sche_node_destroy(p_pos);
        }
    }

    return cnt;
}

schedule_node_t *sche_node_new(struct list_head *pst_head)
{
    schedule_node_t *p_node = NULL;

    if (NULL == pst_head)
    {
        goto EXIT;
    }

    p_node = (schedule_node_t *)vesync_malloc(sizeof(schedule_node_t));
    if (p_node != NULL)
    {
        memset(p_node, 0, sizeof(schedule_node_t));
        // 初始化配置数据Buffer
        p_node->data.app_cfg = vesync_buf_new();
        // 接入链表
        list_add(&p_node->list, pst_head);
    }

EXIT:
    return p_node;
}

void sche_node_destroy(schedule_node_t *p_node)
{
    // 清除APP配置数据
    vesync_buf_clr(&p_node->data.app_cfg);

    // 删除链表节点
    list_del_init(&p_node->list);

    vesync_free(p_node);
}

int sche_obj_init(schedule_obj_t *p_obj, vesync_schedule_param_t *p_sch_param)
{
    SCHEDULE_CHECK(p_obj != NULL, return SCHE_ERR);
    SCHEDULE_CHECK(p_sch_param != NULL, return SCHE_ERR);
    SCHEDULE_CHECK(p_obj->is_init == false, return SCHE_ERR);

    memset(p_obj, 0, sizeof(schedule_obj_t));
    INIT_LIST_HEAD(&p_obj->schedules);

    p_obj->param.max_app_cfg_size = p_sch_param->max_app_cfg_size;
    p_obj->param.min_id_limit = p_sch_param->min_id_limit;
    p_obj->param.max_sche_nbr = p_sch_param->max_sche_nbr;

    if ((NULL == p_sch_param->wr_cfg_cb) ||
        (NULL == p_sch_param->rd_cfg_cb) ||
        (NULL == p_sch_param->exec_app_task_cb))
    {
        return SCHE_ERR;
    }
    p_obj->param.wr_cfg_cb = p_sch_param->wr_cfg_cb;
    p_obj->param.rd_cfg_cb = p_sch_param->rd_cfg_cb;
    p_obj->param.exec_app_task_cb = p_sch_param->exec_app_task_cb;

    int ret = SCHE_OK;
    // 读取配置并应用到 Schedule 实例
    ret = rd_nvm_cfg_to_sche_mgt(p_obj);
    if (SCHE_OK != ret)
    {
        if (SCHE_CFG_NO_EXIST != ret && SCHE_CFG_ERR != ret)
        {
            return ret;
        }

        SDK_LOG(LOG_WARN, "config no found:%d\n", ret);
        // 处理配置不存在的情况，清除可能被载入的配置
        clear_sch_cfg_list(&p_obj->schedules);
        p_obj->schedule_nbr = 0;
        ret = SCHE_OK;
    }

    SCHEDULE_NEW_LOCK(p_obj->mutex, return SCHE_ERR);
    p_obj->is_init = true;
#if SCHEDULE_DEBUG_PRINT == 1
    SDK_LOG(LOG_DEBUG, "module_init done. total_num:%ld.\n", p_obj->schedule_nbr);
#endif

    // 启动调度器
    schedule_cycle_start(p_obj);
    return ret;
}

int sche_obj_deinit(schedule_obj_t *p_obj)
{
    SCHEDULE_CHECK(p_obj != NULL, return SCHE_ERR);
    SCHEDULE_CHECK(p_obj->is_init == true, return SCHE_NO_INIT);

    SCHEDULE_LOCK(p_obj->mutex, return SCHE_ERR);
    // 关闭调度器
    schedule_cycle_stop(p_obj);

    clear_sch_cfg_list(&p_obj->schedules);
    p_obj->schedule_nbr = 0;

    SCHEDULE_UNLOCK(p_obj->mutex);
    SCHEDULE_DEL_LOCK(p_obj->mutex);
    p_obj->is_init = false;
    return SCHE_OK;
}

int sche_obj_add(schedule_obj_t *p_obj, vesync_schedule_t *p_sch_cfg, vesync_buf_t *p_app_cfg, bool is_gen_id)
{
    SCHEDULE_CHECK(p_obj != NULL, return SCHE_ERR);
    SCHEDULE_CHECK(p_sch_cfg != NULL, return SCHE_ERR);
    SCHEDULE_CHECK(p_app_cfg != NULL, return SCHE_ERR);

    // 检查参数的合法性
    if (!check_schedule_cfg(p_sch_cfg))
    {
        return SCHE_INV_CFG_PARAM;
    }

    int ret = SCHE_OK;
    timebase_info_t tb_info;
    uint32_t now_utc = vhal_utils_get_system_time_sec();

    ret = vesync_timebase_get_info(now_utc, &tb_info);
    if (TMBS_OK != ret)
    {
        SDK_LOG(LOG_WARN, "get tb_info fail[%d]\n", ret);
        return SCHE_ERR;
    }

    SCHEDULE_LOCK(p_obj->mutex, return SCHE_ERR);

    uint32_t now_local_ts = tb_info.local_ts;
    schedule_node_t *p_pos, *p_n, *p_node;
    struct list_head *p_head = &p_obj->schedules;

    // 检查APP配置大小是否合法
    if (p_app_cfg->len > p_obj->param.max_app_cfg_size)
    {
        ret = SCHE_INV_APP_CFG_SIZE;
        goto EXIT;
    }

    // 检查配置项的数量有没有超限
    if (p_obj->schedule_nbr >= p_obj->param.max_sche_nbr)
    {
        ret = SCHE_EXCEED_MAX;
        goto EXIT;
    }

    // 生成ID
    if (is_gen_id)
    {
        get_new_next_id(p_obj, &p_sch_cfg->id);
    }

    list_for_each_entry_safe(p_pos, p_n, p_head, list)
    {
        // 检查ID冲突
        if (p_pos->data.config.id == p_sch_cfg->id)
        {
            ret = SCHE_ID_EXIST_ERR;
            goto EXIT;
        }
        // 检查时间冲突
        ret = check_cfg_conflict(&tb_info, now_utc, &p_pos->data.config, p_sch_cfg);
        if (SCHE_OK != ret)
        {
            goto EXIT;
        }
    }
    p_node = sche_node_new(&p_obj->schedules);
    if (NULL == p_node)
    {
        SDK_LOG(LOG_ERROR, "new node fail\n");
        ret = SCHE_MEM_ERR;
        goto EXIT;
    }
    /// @attention: 写入APP数据，不做写入失败的检查
    vesync_buf_cpy(&p_node->data.app_cfg, p_app_cfg);
    // 拷贝Schedule配置
    memcpy(&p_node->data.config, p_sch_cfg, sizeof(vesync_schedule_t));
    // 记录时间戳
    p_node->data.modify_local_ts = now_local_ts;

    // 更新计数
    p_obj->schedule_nbr++;
    // 持久化
    ret = wr_sche_mgt_cfg_to_nvm(p_obj);
    if (SCHE_OK != ret)
    {
        SDK_LOG(LOG_ERROR, "write NVM fail\n");

        goto EXIT;
    }

#if SCHEDULE_DEBUG_PRINT == 1
    print_schedule_cfg(p_sch_cfg);
#else
    SDK_LOG(LOG_INFO, "schedule adds. ID:%ld\n", p_sch_cfg->id);
#endif

EXIT:
    SCHEDULE_UNLOCK(p_obj->mutex);
    return ret;
}

int sche_obj_upd(schedule_obj_t *p_obj, vesync_schedule_t *p_sch_cfg, vesync_buf_t *p_app_cfg)
{
    SCHEDULE_CHECK(p_obj != NULL, return SCHE_ERR);
    SCHEDULE_CHECK(p_sch_cfg != NULL, return SCHE_ERR);
    SCHEDULE_CHECK(p_app_cfg != NULL, return SCHE_ERR);

    // 检查参数的合法性
    if (!check_schedule_cfg(p_sch_cfg))
    {
        return SCHE_INV_CFG_PARAM;
    }

    int ret = SCHE_OK;
    timebase_info_t tb_info;
    uint32_t now_utc = vhal_utils_get_system_time_sec();

    ret = vesync_timebase_get_info(now_utc, &tb_info);
    if (TMBS_OK != ret)
    {
        SDK_LOG(LOG_WARN, "get tb_info fail[%d]\n", ret);
        return SCHE_ERR;
    }

    SCHEDULE_LOCK(p_obj->mutex, return SCHE_ERR);

    schedule_ctx_t *found = NULL;
    uint32_t now_local_ts = tb_info.local_ts;
    schedule_node_t *p_pos, *p_n;
    struct list_head *p_head = &p_obj->schedules;

    // 检查APP配置大小是否合法
    if (p_app_cfg->len > p_obj->param.max_app_cfg_size)
    {
        ret = SCHE_INV_APP_CFG_SIZE;
        goto EXIT;
    }

    // 查找ID、时间冲突
    list_for_each_entry_safe(p_pos, p_n, p_head, list)
    {
        // 找到了目标ID
        if (p_pos->data.config.id == p_sch_cfg->id)
        {
            found = &p_pos->data;
            // 不对这个ID进行冲突对比
            continue;
        }
#if SCHEDULE_DEBUG_PRINT == 1
        SDK_LOG(LOG_DEBUG, "check conflict: %ld, %ld\n", p_pos->data.config.id, p_sch_cfg->id);
#endif
        // 检查冲突
        ret = check_cfg_conflict(&tb_info, now_utc, &p_pos->data.config, p_sch_cfg);
        if (SCHE_OK != ret)
        {
            goto EXIT;
        }
    }

    // ID不存在
    if (NULL == found)
    {
        ret = SCHE_INV_ID_ERR;
        goto EXIT;
    }
    // 写入APP配置数据
    vesync_buf_cpy(&found->app_cfg, p_app_cfg);
    // 拷贝Schedule配置
    memcpy(&found->config, p_sch_cfg, sizeof(vesync_schedule_t));
    /// @note 复位一些变量
    found->exec_cnt = 0;
    found->modify_local_ts = now_local_ts;

    // 持久化
    ret = wr_sche_mgt_cfg_to_nvm(p_obj);
    if (SCHE_OK != ret)
    {
        SDK_LOG(LOG_ERROR, "write NVM fail\n");

        goto EXIT;
    }

#if SCHEDULE_DEBUG_PRINT == 1
    print_schedule_cfg(p_sch_cfg);
#else
    SDK_LOG(LOG_INFO, "schedule updates. ID:%ld\n", p_sch_cfg->id);
#endif

EXIT:
    SCHEDULE_UNLOCK(p_obj->mutex);
    return ret;
}

int sche_obj_del(schedule_obj_t *p_obj, uint32_t sch_id)
{
    SCHEDULE_CHECK(p_obj != NULL, return SCHE_ERR);

    SCHEDULE_LOCK(p_obj->mutex, return SCHE_ERR);

    int ret = SCHE_OK;
    schedule_node_t *found = NULL;
    schedule_node_t *p_pos, *p_n;
    struct list_head *p_head = &p_obj->schedules;
    list_for_each_entry_safe(p_pos, p_n, p_head, list)
    {
        // 找到了目标ID
        if (p_pos->data.config.id == sch_id)
        {
            found = p_pos;
            break;
        }
    }

    // ID不存在
    if (NULL == found)
    {
        ret = SCHE_INV_ID_ERR;
        goto EXIT;
    }
    // 销毁链表节点
    sche_node_destroy(found);

    // 更新计数
    p_obj->schedule_nbr--;
    // 持久化
    ret = wr_sche_mgt_cfg_to_nvm(p_obj);
    if (SCHE_OK != ret)
    {
        SDK_LOG(LOG_ERROR, "write NVM fail\n");

        goto EXIT;
    }

#if SCHEDULE_DEBUG_PRINT == 1
    SDK_LOG(LOG_DEBUG, "schedule deletes. ID:%ld\n", sch_id);
#else
    SDK_LOG(LOG_INFO, "schedule deletes. ID:%ld\n", sch_id);
#endif

EXIT:
    SCHEDULE_UNLOCK(p_obj->mutex);
    return ret;
}

int sche_obj_get_by_id(schedule_obj_t *p_obj, uint32_t sch_id, vesync_schedule_t *p_sch_cfg, vesync_buf_t *p_app_cfg)
{
    SCHEDULE_CHECK(p_obj != NULL, return SCHE_ERR);
    SCHEDULE_CHECK(p_sch_cfg != NULL, return SCHE_ERR);
    SCHEDULE_CHECK(p_app_cfg != NULL, return SCHE_ERR);

    SCHEDULE_LOCK(p_obj->mutex, return SCHE_ERR);

    int ret = SCHE_OK;
    schedule_node_t *found = NULL;
    schedule_node_t *p_pos, *p_n;
    struct list_head *p_head = &p_obj->schedules;
    list_for_each_entry_safe(p_pos, p_n, p_head, list)
    {
        // 找到了目标ID
        if (p_pos->data.config.id == sch_id)
        {
            found = p_pos;
            break;
        }
    }

    // ID不存在
    if (NULL == found)
    {
        ret = SCHE_INV_ID_ERR;
        goto EXIT;
    }
    // 读取配置
    memcpy(p_sch_cfg, &found->data.config, sizeof(vesync_schedule_t));
    // 读取APP配置数据
    vesync_buf_cpy(p_app_cfg, &found->data.app_cfg);

#if SCHEDULE_DEBUG_PRINT == 1
    print_schedule_cfg(p_sch_cfg);
#else
    SDK_LOG(LOG_INFO, "schedule gets. ID:%ld, total_num:%ld\n", sch_id, p_obj->schedule_nbr);
#endif

EXIT:
    SCHEDULE_UNLOCK(p_obj->mutex);
    return ret;
}

int sche_obj_get_next_exc_sec(schedule_obj_t *p_obj, uint32_t *sec)
{
    if ((NULL == p_obj) || (NULL == sec))
    {
        return SCHE_ERR;
    }

    uint32_t now_utc = vhal_utils_get_system_time_sec();
    timebase_info_t tb_info;
    if (TMBS_OK != vesync_timebase_get_info(now_utc, &tb_info))
    {
#if SCHEDULE_DEBUG_PRINT == 1
        SDK_LOG(LOG_WARN, "get timebase fail\n");
#endif
        return SCHE_ERR;
    }
    uint32_t now_clk_sec = tb_info.local_clk_sec;
    uint8_t now_weekday = vesync_timebase_ts_to_weekday(tb_info.local_ts, 0);

    SCHEDULE_LOCK(p_obj->mutex, return SCHE_ERR);

    int ret = SCHE_OK;
    uint32_t last_wait_sec = 0;

    schedule_ctx_t *p_ctx = NULL;
    schedule_node_t *p_get = NULL;
    schedule_node_t *p_pos, *p_n;
    struct list_head *p_head = &p_obj->schedules;
    list_for_each_entry_safe(p_pos, p_n, p_head, list)
    {
        p_ctx = &p_pos->data;
        if (!p_ctx->config.enabled)
        {
            continue;
        }

        uint32_t exec_clk_sec = 0;
        if (SCHE_TMG_EVT == p_ctx->config.type)
        {
            exec_clk_sec = p_ctx->config.event_config.timing.clock_sec;
        }
        if (SCHE_SUN_EVT == p_ctx->config.type)
        {
            if (false == get_suntime_exec_clk(&tb_info, &p_ctx->config, &exec_clk_sec))
            {
                continue;
            }
        }

        int32_t wait_days = 0;
        int32_t wait_sec = ts_min_cmp(exec_clk_sec, now_clk_sec) * VCOM_SECOND_PER_MIN;
        if (p_ctx->config.repeat_config)
        {
            if (p_ctx->config.repeat_config & now_weekday)
            {
                wait_days = (0 >= ts_min_cmp(now_clk_sec, exec_clk_sec)) ? 0 : 1;
            }
            else
            {
                wait_days = 1;
                // 判断第二天是不是还需要执行
                uint8_t weekday = (TMBS_BIT_SUN == now_weekday) ? TMBS_BIT_MON : (now_weekday << 1);
                if (0 == (p_ctx->config.repeat_config & weekday))
                {
                    continue;
                }
            }
            wait_sec += wait_days * VCOM_SECOND_PER_DAY;
        }
        else
        {
            if (0 > ts_min_cmp(exec_clk_sec, now_clk_sec))
            {
                wait_sec += VCOM_SECOND_PER_DAY;
            }
        }
        if ((0 == last_wait_sec) || (last_wait_sec >= (uint32_t)wait_sec))
        {
            last_wait_sec = (uint32_t)wait_sec;
            p_get = p_pos;
        }
    }

    // 无可执行的schedule
    if (NULL == p_get)
    {
        ret = SCHE_INV_ID_ERR;
        goto EXIT;
    }
    SDK_LOG(LOG_INFO, "schedule gets. ID:%ld, wait sec:%ld\n", p_get->data.config.id, last_wait_sec);

EXIT:
    SCHEDULE_UNLOCK(p_obj->mutex);
    if (SCHE_OK == ret)
    {
        *sec = last_wait_sec;
    }
    return ret;
}

int sche_obj_get_by_index(schedule_obj_t *p_obj,
                          uint32_t idx, uint32_t nbr, uint32_t *p_total_num,
                          vesync_schedule_t *p_sch_cfg_list, vesync_buf_t *p_app_cfg_list,
                          uint32_t *p_out_len)
{
    SCHEDULE_CHECK(p_obj != NULL, return SCHE_ERR);
    SCHEDULE_CHECK(p_total_num != NULL, return SCHE_ERR);
    SCHEDULE_CHECK(p_sch_cfg_list != NULL, return SCHE_ERR);
    SCHEDULE_CHECK(p_app_cfg_list != NULL, return SCHE_ERR);
    SCHEDULE_CHECK(p_out_len != NULL, return SCHE_ERR);

    SCHEDULE_LOCK(p_obj->mutex, return SCHE_ERR);

    int ret = SCHE_OK;
    uint32_t sch_cnt = 0;
    schedule_node_t *p_pos, *p_n;
    struct list_head *p_head = &p_obj->schedules;

    // 输出配置项总数
    *p_total_num = p_obj->schedule_nbr;

    // index大于等于现在的Schedule总数
    if (idx >= p_obj->schedule_nbr)
    {
        ret = SCHE_INV_IDX_ERR;
        goto EXIT;
    }

    list_for_each_entry_safe(p_pos, p_n, p_head, list)
    {
        if (sch_cnt >= idx)
        {
            // 读取配置
            memcpy(&p_sch_cfg_list[sch_cnt - idx], &p_pos->data.config, sizeof(vesync_schedule_t));
            // 读取APP配置数据
            vesync_buf_cpy(&p_app_cfg_list[sch_cnt - idx], &p_pos->data.app_cfg);
        }

        sch_cnt++;
        // 读取的配置项已经达到最大数量
        if ((sch_cnt >= idx) && (sch_cnt - idx >= nbr))
        {
            break;
        }
    }

    // 更新输出结果长度
    *p_out_len = sch_cnt - idx;

#if SCHEDULE_DEBUG_PRINT == 1
    SDK_LOG(LOG_DEBUG, "schedule gets. index: %ld, number: %ld, out_nbr: %ld\n", idx, nbr, *p_out_len);
    for (uint32_t cnt = 0; cnt < *p_out_len; cnt++)
    {
        print_schedule_cfg(&p_sch_cfg_list[cnt]);
    }
#else
    SDK_LOG(LOG_INFO, "schedule gets. index: %ld, number: %ld, out_nbr: %ld\n", idx, nbr, *p_out_len);
#endif

EXIT:
    SCHEDULE_UNLOCK(p_obj->mutex);
    return ret;
}

int sche_obj_clear(schedule_obj_t *p_obj)
{
    SCHEDULE_CHECK(p_obj != NULL, return SCHE_ERR);

    SCHEDULE_LOCK(p_obj->mutex, return SCHE_ERR);

    int ret = SCHE_OK;
    // 清空链表
#if SCHEDULE_DEBUG_PRINT == 1
    uint32_t total_num = p_obj->schedule_nbr;
    int cnt = clear_sch_cfg_list(&p_obj->schedules);
#else
    clear_sch_cfg_list(&p_obj->schedules);
#endif
    // 复位Schedule项计数
    p_obj->schedule_nbr = 0;

    // 持久化
    ret = wr_sche_mgt_cfg_to_nvm(p_obj);
    if (SCHE_OK != ret)
    {
        SDK_LOG(LOG_ERROR, "write NVM fail\n");

        goto EXIT;
    }

#if SCHEDULE_DEBUG_PRINT == 1
    SDK_LOG(LOG_DEBUG, "schedule clear all. total_num:%ld, clr_cnt:%ld\n", total_num, cnt);
#else
    SDK_LOG(LOG_INFO, "schedule clear all\n");
#endif

EXIT:
    SCHEDULE_UNLOCK(p_obj->mutex);
    return ret;
}

int sche_obj_get_exec_cnt(schedule_obj_t *p_obj, uint32_t sch_id, uint32_t *p_exec_cnt)
{
    SCHEDULE_CHECK(p_obj != NULL, return SCHE_ERR);
    SCHEDULE_CHECK(p_exec_cnt != NULL, return SCHE_ERR);

    SCHEDULE_LOCK(p_obj->mutex, return SCHE_ERR);

    int ret = SCHE_OK;
    schedule_node_t *found = NULL;
    schedule_node_t *p_pos, *p_n;
    struct list_head *p_head = &p_obj->schedules;
    list_for_each_entry_safe(p_pos, p_n, p_head, list)
    {
        // 找到了目标ID
        if (p_pos->data.config.id == sch_id)
        {
            found = p_pos;
            break;
        }
    }

    // ID不存在
    if (NULL == found)
    {
        ret = SCHE_INV_ID_ERR;
        goto EXIT;
    }
    *p_exec_cnt = found->data.exec_cnt;

EXIT:
    SCHEDULE_UNLOCK(p_obj->mutex);
    return ret;
}

int sche_obj_get_total_num(schedule_obj_t *p_obj, uint32_t *p_num)
{
    SCHEDULE_CHECK(p_obj != NULL, return SCHE_ERR);
    SCHEDULE_CHECK(p_num != NULL, return SCHE_ERR);

    SCHEDULE_LOCK(p_obj->mutex, return SCHE_ERR);
    *p_num = p_obj->schedule_nbr;
    SCHEDULE_UNLOCK(p_obj->mutex);
    return SCHE_OK;
}
