/**
 *  Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
 * @file        vhal_wifi.c
 * @brief       Wi-Fi驱动抽象层，封装厂家乐鑫 SDK提供的Wi-Fi相关接口
 * @author      Dongri.Su
 * @date        2021-04-20
 */
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <stdio.h>
#include <stdlib.h>
#include <linux/wireless.h>
#include <sys/ioctl.h>

#include "vesync_common.h"
#include "vesync_log.h"

#include "vhal_wifi_internal.h"
#include "vhal_utils_internal.h"


// wifi连接状态回调函数指针, vesync_connect_wifi_callback()
static vhal_wifi_status_cb_t s_vhal_wifi_status_cb = NULL;

// 保存扫描结果到WiFi扫描列表管理模块回调函数
static vhal_wifi_scan_cb_t s_vhal_wifi_scan_cb = NULL;

// WIFI断开连接时传递错误码和错误描述的callback
static vhal_wifi_disc_log_cb_t s_vhal_wifi_disc_log_cb = NULL;

static VHAL_WIFI_STATUS_E s_wifi_status = VHAL_WIFI_INIT;       // Wi-Fi连接状态
static VHAL_WIFI_MODE_E s_wifi_mode = VHAL_WIFI_MODE_NULL;      // Wi-Fi工作模式

/**
 * @brief  2G频率信道表
 */
static vhal_hz_channel_2g_t s_hz_channel_2g[] = {
    {2412, 1}, {2417, 2}, {2422, 3}, {2427, 4}, {2432, 5}, {2437, 6}, {2442, 7},
    {2447, 8}, {2452, 9}, {2457, 10}, {2462, 11}, {2467, 12}, {2472, 13}, {2484, 14}
};


/**
 * @brief  设置Wi-Fi状态，当状态发生改变时通知上层
 * @param[in]  new_status               [Wi-Fi状态]
 */
static void vhal_wifi_set_status(VHAL_WIFI_STATUS_E new_status)
{
    /* 网络状态发生改变，主动通知上一层(消息处理中心)     */
    s_wifi_status = new_status;
    HAL_LOG(LOG_DEBUG, "Wi-Fi new status is %d\n", new_status);
    // 定义：vesync_connect_wifi_callback()
    if(NULL != s_vhal_wifi_status_cb)
    {
        s_vhal_wifi_status_cb(new_status);
    }
}

static int vhal_wifi_run_cmd(char *buf)
{
    VCOM_NULL_PARAM_CHK(buf, return VHAL_FAIL);

    char cmd[512] = {0};
    snprintf(cmd, sizeof(cmd), "%s", buf);
    FILE *fp = popen(cmd, "r");
    if (fp == NULL)
    {
        HAL_LOG(LOG_ERROR, "run %s fail\n", buf);
        return VHAL_FAIL;
    }
    pclose(fp);

    return VHAL_OK;
}

/**
 * @brief  stop wifi sta interface
 */
static void vhal_wifi_stop_sta(void)
{
    HAL_LOG(LOG_DEBUG, "wifi sta stop.\r\n");
    char cmd[256] = {0};
    snprintf(cmd, sizeof(cmd), "ifconfig %s down", INTERFACE_NAME);
    vhal_wifi_run_cmd(cmd);
}

static int vhal_wifi_setup_hostap(char *ssid, int chan)
{
    FILE *fp = fopen("/etc/hostapd/hostapd.conf", "w+");
    if (fp == NULL)
    {
        HAL_LOG(LOG_ERROR, "hostapd.conf open fail\n");
        return VHAL_FAIL;
    }

    char buf[1024] = {0};
    snprintf(buf, sizeof(buf),
              "interface=%s\n"
              "driver=nl80211\n"
              "ssid=%s\n"
              "hw_mode=g\n"
              "channel=%d\n"
              "ieee80211n=1\n"
              "wmm_enabled=0\n"
              "macaddr_acl=0\n"
              "auth_algs=1\n"
              "ignore_broadcast_ssid=0\n"
              "wpa=2\n"
              "wpa_passphrase=12345678\n"
              "rsn_pairwise=CCMP\n",
              SOFTAP_INTERFACE_NAME, ssid, chan);
    fwrite(buf, strlen(buf), 1, fp);
    fclose(fp);

    return vhal_wifi_run_cmd("/etc/init.d/hostapd reload");
}

static int vhal_wifi_setup_dhcpcd_cfg(void)
{
    if (access("/etc/dhcpcd.conf.init", F_OK) == 0)
    {
        vhal_wifi_run_cmd("cp /etc/dhcpcd.conf.init /etc/dhcpcd.conf");
    }
    else
    {
        FILE *fp = fopen("/etc/dhcpcd.conf", "a");
        if (fp == NULL)
        {
            HAL_LOG(LOG_ERROR, "dhcpcd.conf open fail\n");
            return VHAL_FAIL;
        }

        char buf[1024] = {0};
        snprintf(buf, sizeof(buf),
                "interface %s\n"
                "static ip_address=192.168.4.1/24\n"
                "static routers=192.168.4.1\n"
                "static domain_name_servers=8.8.8.8\n"
                "nohook wpa_supplicant\n",
                SOFTAP_INTERFACE_NAME);
        fwrite(buf, strlen(buf), 1, fp);
        fclose(fp);

        vhal_wifi_run_cmd("cp /etc/dhcpcd.conf /etc/dhcpcd.conf.init");
    }

    return vhal_wifi_run_cmd("/etc/init.d/dhcpcd reload");
}

static int vhal_wifi_setup_dnsmasq(void)
{
    if (access("/etc/dnsmasq.conf.init", F_OK) == 0)
    {
        vhal_wifi_run_cmd("cp /etc/dnsmasq.conf.init /etc/dnsmasq.conf");
    }
    else
    {
        FILE *fp = fopen("/etc/dnsmasq.conf", "a");
        if (fp == NULL)
        {
            HAL_LOG(LOG_ERROR, "dnsmasq.conf open fail\n");
            return VHAL_FAIL;
        }

        char buf[1024] = {0};
        snprintf(buf, sizeof(buf),
                "interface=%s\n"
                "bind-interfaces\n"
                "domain-needed\n"
                "bogus-priv\n"
                "dhcp-range=192.168.4.100,192.168.4.200,24h\n",
                SOFTAP_INTERFACE_NAME);
        fwrite(buf, strlen(buf), 1, fp);
        fclose(fp);

        vhal_wifi_run_cmd("cp /etc/dnsmasq.conf /etc/dnsmasq.conf.init");
    }

    vhal_wifi_run_cmd("sudo /etc/init.d/dnsmasq restart");

    char cmd[512] = {0};
    snprintf(cmd, sizeof(cmd), "sudo /etc/init.d/dnsmasq restart && echo 1 || echo 0");
    FILE *fp = popen(cmd, "r");
    if (fp != NULL)
    {
        char buf[256] = {0};
        int result = 0;
        while (fgets(buf, sizeof(buf), fp) != NULL)
        {
            sscanf(buf, "%d", &result);
            HAL_LOG(LOG_DEBUG, "dnsmasq status =%d", result);
            if (result == 0)
            {
                HAL_LOG(LOG_DEBUG, "dnsmasq start fail\n");
                vhal_wifi_run_cmd(cmd);
            }
        }

        pclose(fp);
    }

    return VHAL_OK;
}

/*-----------------------------------------------------------------------------*
 *                           外部函数API实现                                         *
 *-----------------------------------------------------------------------------*/
/*
 * @brief  初始化Wi-Fi模块
 * @param[in]  status_cb                [Wi-Fi的连接状态回调函数]
 * @param[in]  power_save               [Wi-Fi节能模式标志位]
 * @param[in]  p_hostname               [DHCP hostname]
 * @param[in]  p_country_code           [长度为2byte的国家码，如：US、EU、CN]
 * @return void
 */
void vhal_wifi_init(vhal_wifi_status_cb_t status_cb, VHAL_WIFI_PS_TYPE_E power_save, char *p_hostname, char *p_country_code)
{
    s_vhal_wifi_status_cb = status_cb;
    HAL_LOG(LOG_INFO, "Init wifi module done.\n");
}

/*
 * @brief  卸载Wi-Fi驱动
 * @return void
 */
void vhal_wifi_deinit(void)
{
    HAL_LOG(LOG_INFO, "Deinit wifi module done.\n");
}

/*
 * @brief  Wi-Fi启动工作
 * @return void
 */
void vhal_wifi_start(void)
{
    if (VHAL_WIFI_MODE_NULL == s_wifi_mode)
    {
        HAL_LOG(LOG_ERROR, "Wi-Fi run no mode.\r\n");

    }
    else if (VHAL_WIFI_MODE_STA == s_wifi_mode)
    {
        HAL_LOG(LOG_DEBUG, "wifi sta start.\r\n");
        char cmd[256] = {0};
        snprintf(cmd, sizeof(cmd), "ifconfig %s up", INTERFACE_NAME);
        FILE *fp = popen(cmd, "r");
        if (fp == NULL)
        {
            HAL_LOG(LOG_ERROR, "stop sta fail\n");
            return;
        }

        pclose(fp);
    }
    else if (VHAL_WIFI_MODE_AP == s_wifi_mode)
    {
        /* nothing */
    }
    else if (VHAL_WIFI_MODE_APSTA == s_wifi_mode)
    {
        s_wifi_mode = VHAL_WIFI_MODE_STA;
        HAL_LOG(LOG_DEBUG, "wifi sta start.\r\n");
        char cmd[256] = {0};
        snprintf(cmd, sizeof(cmd), "ifconfig %s up", INTERFACE_NAME);
        FILE *fp = popen(cmd, "r");
        if (fp == NULL)
        {
            HAL_LOG(LOG_ERROR, "stop sta fail\n");
            return;
        }

        pclose(fp);
    }
    else
    {
        /* start other mode */
    }
    HAL_LOG(LOG_DEBUG, "Wi-Fi start.\n");
}


/*
 * @brief Wi-Fi停止工作
 * @return void
 */
void vhal_wifi_stop(void)
{
    if (VHAL_WIFI_MODE_NULL == s_wifi_mode)
    {
        HAL_LOG(LOG_INFO, " wifi stop already.\r\n");
        return;
    }
    else if (VHAL_WIFI_MODE_STA == s_wifi_mode)
    {
        HAL_LOG(LOG_DEBUG, "wifi sta stop.\r\n");
        vhal_wifi_stop_sta();
    }
    else if (VHAL_WIFI_MODE_AP == s_wifi_mode)
    {
        s_wifi_mode = VHAL_WIFI_MODE_STA;
        vhal_wifi_stop_ap_mode();
        HAL_LOG(LOG_DEBUG, "wifi ap stop.\r\n");
    }
    else if (VHAL_WIFI_MODE_APSTA == s_wifi_mode)
    {
        vhal_wifi_stop_sta();
        vhal_wifi_stop_ap_mode();
        HAL_LOG(LOG_DEBUG, "wifi stop.\r\n");
    }
    else
    {
        /* stop other mode */
    }
    s_wifi_status = VHAL_WIFI_INIT;
}

/*
 * @brief  设备作为STA，主动发起关联AP
 * @param[in]  p_ssid                   [Wi-Fi的名称]
 * @param[in]  p_pwd                    [Wi-Fi的密码]
 * @param[in]  auth_mode                [Wi-Fi加密模式]
 * @return     int                      [执行成功，返回OK；执行失败，返回FAIL]
 */
int vhal_wifi_connect(const char *p_ssid, const char *p_pwd, VHAL_WIFI_AUTH_MODE_E auth_mode)
{
    FILE *fp = fopen("/etc/wpa_supplicant/wpa_supplicant.conf", "w");
    if (fp == NULL)
    {
        HAL_LOG(LOG_ERROR, "wpa conf fail\n");
        return VHAL_FAIL;
    }

    char buf[1024] = {0};
    snprintf(buf, sizeof(buf),
        "ctrl_interface=DIR=/var/run/wpa_supplicant GROUP=netdev\n"
        "update_config=1\n"
        "country=CN\n"
        "network={\n"
        "ssid=\"%s\"\n"
        "psk=\"%s\"\n"
        "}\n",
        p_ssid, p_pwd);
    fwrite(buf, strlen(buf), 1, fp);
    fclose(fp);

    char cmd[512] = {0};
    snprintf(cmd, sizeof(cmd), "wpa_cli -i %s reconfigure", INTERFACE_NAME);
    vhal_wifi_run_cmd(cmd);

    vhal_wifi_set_status(VHAL_WIFI_CONNECTED);

    HAL_LOG(LOG_INFO, "Waiting for ip......\n");

    char ip_buf[IP_ADDR_STR_MAX_LEN] = {0};
    while (vhal_utils_get_sta_ip(ip_buf, sizeof(ip_buf)) == NULL)
    {
        sleep(1);
    }

    vhal_wifi_set_status(VHAL_WIFI_GOT_IP);

    HAL_LOG(LOG_DEBUG, "Got IP %s\n", ip_buf);

    return VHAL_OK;
}

/*
 * @brief  Wi-Fi运行在STA模式时，与router AP的连接状态
 * @param[in]  wait_time_ms             [最大阻塞等待时间]
 * @return     bool                     [关联AP成功且获取IP成功，返回true；否则返回false]
 */
bool vhal_wifi_get_link_status(int32_t wait_time_ms)
{
    if (VHAL_WIFI_GOT_IP == s_wifi_status)
    {
        return true;
    }
    else
    {
        sleep(3);
    }

    return false;
}

/*
 * @brief 设备作为STA时，与AP关联成功，检测到AP的接收信号强度
 * @param[in]  points                   [循环检测的次数]
 * @return     int                      [平均rssi(连续point个测试数据取平均)]
 */
int vhal_wifi_get_router_rssi(int points)
{
    long rssi = 0;
    int averageRSSI = 0;

    int sockfd = -1;
    struct iw_statistics stats;
    struct iwreq req;

    if (points <= 0)
    {
        HAL_LOG(LOG_ERROR, "input error\n");
        return 0;
    }

    memset(&stats, 0, sizeof(stats));
    memset(&req, 0, sizeof(req));

    strncpy(req.ifr_name, INTERFACE_NAME, sizeof(req.ifr_name));
    req.u.data.pointer = &stats;
    req.u.data.length = sizeof(stats);
    req.u.data.flags = 1;

    sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd == -1)
    {
        HAL_LOG(LOG_ERROR, "socket fail\n");
        return 0;
    }

    for (int i = 0; i < points; i++)
    {
        int ret = ioctl(sockfd, SIOCGIWSTATS, &req);
        if (ret == 0 && (stats.qual.updated & IW_QUAL_DBM))
        {
            rssi += stats.qual.level - 256;
        }
        usleep(25000);
    }

    close(sockfd);
    averageRSSI = rssi / points;
    HAL_LOG(LOG_DEBUG, "RSSI strength is %d.\n", averageRSSI);

    return averageRSSI;
}

/*
 * @brief 获取当前Wi-Fi信道
 * @return     int                      [Wi-Fi工作信道]
 */
int vhal_wifi_get_channel(void)
{
    uint8_t primary = 0;
    int sockfd = -1;
    struct iwreq req;

    sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd == -1)
    {
        HAL_LOG(LOG_ERROR, "socket fail\n");
        return VHAL_FAIL;
    }

    memset(&req, 0, sizeof(req));
    strncpy(req.ifr_name, INTERFACE_NAME, sizeof(req.ifr_name));

    int ret = ioctl(sockfd, SIOCGIWFREQ, &req);
    if (ret < 0)
    {
        HAL_LOG(LOG_ERROR, "Get Wi-Fi STA cfg fail!\n");
        close(sockfd);
        return VHAL_FAIL;
    }

    close(sockfd);
    primary = req.u.freq.m;

    for (int i = 0; i < SIZEOF_ARRAY(s_hz_channel_2g); i++)
    {
        if (req.u.freq.m == s_hz_channel_2g[i].freq)
        {
            primary = s_hz_channel_2g[i].channel;
            break;
        }
    }

    HAL_LOG(LOG_ERROR, "Wi-Fi channel %d\n", primary);

    return (int)primary;
}

/*
 * @brief 设备作为STA时，获取当前连接路由器成功所使用的ssid和密码。
 * @param[out] p_sta_cfg                [保存Wi-Fi连接使用的ssid和密码]
 * @return     int                      [执行成功，返回OK；执行失败，返回FAIL]
 */
int vhal_wifi_get_sta_cfg(vhal_wifi_sta_cfg_t *p_sta_cfg)
{
    int sockfd = -1;
    struct iwreq req;
    int ret = -1;

    if (NULL == p_sta_cfg)
    {
        HAL_LOG(LOG_ERROR, "Null ptr!\n");
        return VHAL_FAIL;
    }

    sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd == -1)
    {
        HAL_LOG(LOG_ERROR, "socket fail\n");
        return VHAL_FAIL;
    }

    memset(p_sta_cfg, 0, sizeof(vhal_wifi_sta_cfg_t));

    // 获取ssid
    memset(&req, 0, sizeof(req));
    strncpy(req.ifr_name, INTERFACE_NAME, sizeof(req.ifr_name));
    req.u.essid.pointer = p_sta_cfg->ssid;
    req.u.essid.length = WIFI_SSID_MAX_LEN;
    ret = ioctl(sockfd, SIOCGIWESSID, &req);
    if (ret < 0)
    {
        HAL_LOG(LOG_ERROR, "Get Wi-Fi ssid fail!\n");
        close(sockfd);
        return VHAL_FAIL;
    }
    HAL_LOG(LOG_DEBUG, "Wi-Fi ssid %s\n", p_sta_cfg->ssid);

    // 获取pwd
    memset(&req, 0, sizeof(req));
    req.u.encoding.pointer = p_sta_cfg->pwd;
    req.u.encoding.length = WIFI_PWD_MAX_LEN;
    ret = ioctl(sockfd, SIOCGIWENCODE, &req);
    if (ret < 0)
    {
        HAL_LOG(LOG_ERROR, "Get Wi-Fi pwd fail!\n");
        close(sockfd);
        //return VHAL_FAIL;
    }
    HAL_LOG(LOG_DEBUG, "Wi-Fi pwd %s\n", p_sta_cfg->pwd);

    // 获取auth mode
    memset(&req, 0, sizeof(req));
    req.u.param.flags = IW_AUTH_KEY_MGMT;
    ret = ioctl(sockfd, SIOCGIWAUTH, &req);
    if (ret < 0)
    {
        HAL_LOG(LOG_ERROR, "Get Wi-Fi auth mode fail!\n");
        close(sockfd);
        //return VHAL_FAIL;
    }
    p_sta_cfg->auth_mode = req.u.param.value;
    HAL_LOG(LOG_DEBUG, "Wi-Fi auth mode %d\n", p_sta_cfg->auth_mode);

    close(sockfd);

    return VHAL_OK;
}

/*
 * @brief  注册配网时需要的Wi-Fi回调函数
 * @param[in]  scan_cb                  [Wi-Fi列表扫描结果回调]
 * @param[in]  disconn_cb               [Wi-Fi断开连接时回调]
 * @return void
 */
void vhal_wifi_reg_netcfg_cb(vhal_wifi_scan_cb_t scan_cb, vhal_wifi_disc_log_cb_t disconn_cb)
{
    s_vhal_wifi_scan_cb = scan_cb;
    s_vhal_wifi_disc_log_cb = disconn_cb;
}

/*
 * @brief 撤销注册配网时需要的Wi-Fi回调函数
 */
void vhal_wifi_unreg_netcfg_cb(void)
{
    s_vhal_wifi_scan_cb = NULL;
    s_vhal_wifi_disc_log_cb = NULL;
}

/*
 * @brief 硬件抽象层设置设备为WiFi热点
 * @param[in]  wifi_mode  Wi-Fi模式(AP/APSTA)
 * @param[in]  ssid                     [ssid名称]
 * @param[in]  pwd                      [Wi-Fi密码]
 * @param[in]  chan                     [Wi-Fi信道]
 * @param[in]  auth_mode                [加密方式]
 * @return     int                      [执行成功，返回OK；执行失败，返回FAIL]
 */
int vhal_wifi_setup_ap_cfg(VHAL_WIFI_MODE_E wifi_mode, char *ssid, char* pwd, uint8_t chan, uint8_t auth_mode)
{
    if (VHAL_WIFI_MODE_AP != wifi_mode && VHAL_WIFI_MODE_APSTA != wifi_mode)
    {
        HAL_LOG(LOG_ERROR, "Unknown Wi-Fi mode (%d)!!!\r\n", wifi_mode);
        return VHAL_FAIL;
    }

    if (NULL == ssid)
    {
        HAL_LOG(LOG_ERROR, "ssid null!!!\r\n");
        return VHAL_FAIL;
    }

    if (chan < VHAL_WIFI_2G4_CHAN1 && chan > VHAL_WIFI_2G4_CHAN13)
    {
        HAL_LOG(LOG_ERROR, "channel error!!!\r\n");
        return VHAL_FAIL;
    }

    char cmd[512] = {0};
    memset(cmd, 0, sizeof(cmd));
    snprintf(cmd, sizeof(cmd), "iw dev wlan0 interface add %s type __ap", SOFTAP_INTERFACE_NAME);
    vhal_wifi_run_cmd(cmd);
    sleep(3);

    vhal_wifi_setup_dhcpcd_cfg();

    vhal_wifi_setup_hostap(ssid, chan);

    vhal_wifi_setup_dnsmasq();

    vhal_wifi_run_cmd("killall wpa_supplicant");
    sleep(1);

    snprintf(cmd, sizeof(cmd),
        "wpa_supplicant -B -c/etc/wpa_supplicant/wpa_supplicant.conf -i%s -Dnl80211,wext -fwpa.log",
        INTERFACE_NAME);
    vhal_wifi_run_cmd(cmd);

    sleep(1);
    snprintf(cmd, sizeof(cmd), "ifconfig %s up", INTERFACE_NAME);
    vhal_wifi_run_cmd(cmd);

    char ip_buf[IP_ADDR_STR_MAX_LEN] = {0};
    while (vhal_utils_get_sta_ip(ip_buf, sizeof(ip_buf)) == NULL)
    {
        sleep(1);
    }
    sleep(1);

    s_wifi_mode = wifi_mode;

    return VHAL_OK;
}

/*
 * @brief 关闭Wi-Fi的AP模式，不影响STA接口
 * @return     void            [none]
 */
void vhal_wifi_stop_ap_mode(void)
{
    if (VHAL_WIFI_MODE_AP == s_wifi_mode || VHAL_WIFI_MODE_APSTA == s_wifi_mode)
    {
        s_wifi_mode = VHAL_WIFI_MODE_STA;

        HAL_LOG(LOG_DEBUG, "wifi ap stop.\r\n");
        char cmd[256] = {0};
        snprintf(cmd, sizeof(cmd), "ifconfig %s down", SOFTAP_INTERFACE_NAME);
        vhal_wifi_run_cmd(cmd);
    }
}


/**
 * @brief  认证方式转换
 * @param[in]  auth_mode                [驱动返回的auth mode]
 * @return int                          [转换后的auth mode]
 */
static inline VHAL_WIFI_AUTH_MODE_E vhal_wifi_conv_auth_mode(char *auth_mode)
{
    if (strstr(auth_mode, "WPA-PSK") && strstr(auth_mode, "WPA2-PSK"))
    {
        return VHAL_WIFI_AUTH_WPA_WPA2_PSK;
    }
    else if (strstr(auth_mode, "WPA-PSK"))
    {
        return VHAL_WIFI_AUTH_WPA_PSK;
    }
    else if (strstr(auth_mode, "WPA3-PSK") && strstr(auth_mode, "WPA2-PSK"))
    {
        return VHAL_WIFI_AUTH_WPA2_WPA3_PSK;
    }
    else if (strstr(auth_mode, "WPA2-PSK"))
    {
        return VHAL_WIFI_AUTH_WPA2_PSK;
    }
    else if (strstr(auth_mode, "WPA3-PSK"))
    {
        return VHAL_WIFI_AUTH_WPA3_PSK;
    }
    else if (strstr(auth_mode, "WEP"))
    {
        return VHAL_WIFI_AUTH_WEP;
    }
    else
    {
        return VHAL_WIFI_AUTH_OPEN;
    }
}

/*
 * @brief  Wi-Fi开始扫描周围的AP热点
 * @return      int                     [执行成功，返回OK；执行失败，返回FAIL]
 */
int vhal_wifi_scan_start(void)
{
    char cmd[256] = {0};
    snprintf(cmd, sizeof(cmd), "wpa_cli -i %s scan", INTERFACE_NAME);

    FILE* fp = NULL;
    char buf[512] = {0};
    char *output = NULL;

    char bssid[MAC_ADDR_STR_MAX_LEN] = {0};
    char ssid[WIFI_SSID_MAX_LEN] = {0};
    int rssi = 0;
    char auth[256] = {0};
    int freq = 0;
    int num = 0;

    if ((fp = popen(cmd, "r")) != NULL)
    {
        if (fgets(buf, sizeof(buf), fp) != NULL)
        {
            output = strstr(buf, "OK");
            if (output == NULL)
            {
                HAL_LOG(LOG_ERROR, "scan fail\n");
                pclose(fp);
                return VHAL_FAIL;
            }
        }

        pclose(fp);
    }

    sleep(1);

    snprintf(cmd, sizeof(cmd), "wpa_cli -i %s scan_result | grep -v bssid", INTERFACE_NAME);
    fp = popen(cmd, "r");
    if (fp == NULL)
    {
        HAL_LOG(LOG_ERROR, "scan result fail\n");
        return VHAL_FAIL;
    }

    memset(buf, 0, sizeof(buf));
    while (fgets(buf, sizeof(buf), fp) != NULL)
    {
        num++;
    }
    pclose(fp);

    fp = popen(cmd, "r");
    if (fp == NULL)
    {
        HAL_LOG(LOG_ERROR, "scan result fail\n");
        return VHAL_FAIL;
    }

    memset(buf, 0, sizeof(buf));
    while (fgets(buf, sizeof(buf), fp) != NULL)
    {
        sscanf(buf, "%hhx:%hhx:%hhx:%hhx:%hhx:%hhx %d %d %s %s",
               &bssid[0], &bssid[1], &bssid[2], &bssid[3], &bssid[4], &bssid[5],
               &freq, &rssi, auth, ssid);
#if 0
        HAL_LOG(LOG_DEBUG, "bssid=%x:%x:%x:%x:%x:%x, rssi=%d, auth=%s, ssid=%s\n",
                bssid[0], bssid[1], bssid[2], bssid[3], bssid[4], bssid[5],
                rssi, auth, ssid);
#endif
        s_vhal_wifi_scan_cb((uint8_t *)bssid, (uint8_t *)ssid,
                            rssi, vhal_wifi_conv_auth_mode(auth), num);
    }

    pclose(fp);

    vhal_wifi_set_status(VHAL_WIFI_SCAN_DONE);

    return VHAL_OK;
}

/*
 * @brief  Wi-Fi停止扫描AP热点
 * @return      int                     [执行成功，返回OK；执行失败，返回FAIL]
 */
int vhal_wifi_scan_stop(void)
{
    return VHAL_OK;
}

int vhal_wifi_dns_setserver(uint8_t idx, char *ip_str)
{
    return VHAL_OK;
}
