/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_timebase.c
 * @brief       Timebase模块实现
 * @author      Herve.Lin
 * @date        2021-08-18
 */
#include <time.h>
#include <string.h>
#include <stdio.h>

#include "vhal_utils.h"

#include "vesync_timebase_private.h"
#include "vesync_log_internal.h"
#include "vesync_device_internal.h"
#include "vesync_memory.h"
#include "vesync_common.h"


// 全局Timebase实例定义
static timebase_mgt_t s_timebase_mgt = TIMEBASE_MGT_INIT_VAL;
// No-bypass消息缓存
static char *s_p_no_bypass_msg_buf = NULL;
// 网络初始化，时基信息更新请求标志
static struct
{
    bool should_upd_tb;
    TMBS_INFO_TYPE_E req_type;
} s_update_tb_flag = {should_upd_tb : false, req_type : TMBS_NONE};
// 时基更新的全局控制开关
static bool s_global_dis_upd_tb = false;
// 上一次更新系统时间的时间
static uint32_t s_last_update_time = 0;
// 上一次请求更新系统时间的时间
static uint32_t s_last_req_upd_time = 0;
// SNTP是否有效
static bool s_does_sntp_work = false;

/**
 * @brief 把序列化的配置信息读取到Timebase实例中
 * @return int [TMBS_RESULT_E]
 */
static int rd_nvm_cfg_to_timebase_mgt(void)
{
    int ret = SDK_OK;

    // 读取配置长度
    uint32_t cfg_len;
    ret = tb_default_rd_cfg_cb(NULL, 0, &cfg_len);
    if (SDK_OK != ret)
    {
        return TMBS_CFG_ERR;
    }
    if (0 == cfg_len)
    {
        return TMBS_CFG_NO_EXIST;
    }
#if TIMEBASE_DEBUG_PRINT == 1
    SDK_LOG(LOG_DEBUG, "config len:[%ld]\n", cfg_len);
#endif

    // 申请缓存
    uint8_t *p_buf = (uint8_t *)vesync_malloc(cfg_len);
    if (NULL == p_buf)
    {
        SDK_LOG(LOG_ERROR, "buffer malloc fail\n");
        return TMBS_MEM_ERR;
    }

    // 读取配置信息
    uint32_t rd_len;
    ret = tb_default_rd_cfg_cb(p_buf, cfg_len, &rd_len);
    if (SDK_OK != ret)
    {
        goto EXIT;
    }
#if TIMEBASE_DEBUG_PRINT == 1
    SDK_LOG(LOG_DEBUG, "read config, size[%ld]\n", rd_len);
#endif
    if (rd_len != cfg_len)
    {
        ret = TMBS_CFG_ERR;
        goto EXIT;
    }

    // 将配置应用到Timebase实例
    ret = tb_cfg_unmarshal(p_buf, rd_len, &s_timebase_mgt.timebase);
    if (SDK_OK != ret)
    {
        goto EXIT;
    }

EXIT:
    vesync_free(p_buf);
    return ret;
}

/**
 * @brief 把Timebase实例中的配置信息序列化并写入
 * @return int [TMBS_RESULT_E]
 */
static int wr_timebase_mgt_cfg_to_nvm(void)
{
    int ret = SDK_OK;

    // 计算Buffer
    uint32_t cfg_len;
    ret = tb_cfg_marshal(&s_timebase_mgt.timebase, NULL, 0, &cfg_len);
    if (SDK_OK != ret)
    {
        return TMBS_CFG_ERR;
    }
#if TIMEBASE_DEBUG_PRINT == 1
    SDK_LOG(LOG_DEBUG, "config len:[%ld]\r\n", cfg_len);
#endif

    // 申请缓存
    uint8_t *p_buf = (uint8_t *)vesync_malloc(cfg_len);
    if (NULL == p_buf)
    {
        SDK_LOG(LOG_ERROR, "buffer malloc fail\n");
        return TMBS_MEM_ERR;
    }

    // 序列化Timebase实例中的配置信息
    uint32_t wr_len = 0;
    ret = tb_cfg_marshal(&s_timebase_mgt.timebase, p_buf, cfg_len, &wr_len);
    if (SDK_OK != ret)
    {
        goto EXIT;
    }
#if TIMEBASE_DEBUG_PRINT == 1
    SDK_LOG(LOG_DEBUG, "write config, size[%ld]\n", wr_len);
#endif
    if (wr_len != cfg_len)
    {
        ret = TMBS_CFG_ERR;
        goto EXIT;
    }

    // 写入配置
    ret = tb_default_wr_cfg_cb(p_buf, wr_len);
    if (SDK_OK != ret)
    {
        goto EXIT;
    }

EXIT:
    vesync_free(p_buf);
    return ret;
}

/**
 * @brief 判断是否需要更新时基信息，返回相应的请求类型
 *          1、判断日出日落时间是否过期
 *          2、判断DST的缓存是否需要更新
 *          3、在需要更新的前提下以一定的频率生成更新时间的请求
 * @param[in] utc           [当前的UTC时间戳]
 * @param[in] tb            [缓存的时基信息]
 * @return TMBS_INFO_TYPE_E [需要请求的时基信息类型]
 */
static TMBS_INFO_TYPE_E should_we_upd_timebase(uint32_t utc, vesync_timebase_t *tb)
{
    static uint32_t last_required_utc = 0;

    TMBS_INFO_TYPE_E out = TMBS_NONE;
    bool should_upd_suntime = false;
    bool should_upd_dst = false;

    // 判断日出日落
    if ((utc > tb->sun_rs_info.sun_rise_utc + TIMEBASE_SUNTIME_EXPIRE_PERIOD_SEC) ||
        (utc > tb->sun_rs_info.sun_set_utc + TIMEBASE_SUNTIME_EXPIRE_PERIOD_SEC))
    {
        should_upd_suntime = true;
    }

    // 判断冬夏令时
    if (tb->dst_info.enabled)
    {
        if (utc > tb->dst_info.dst_sw_utc + TIMEBASE_DST_REQ_AFTER_SW_SEC)
        {
            should_upd_dst = true;
        }
    }

    if (should_upd_dst)
    {
        out = TMBS_DST;
    }

    if (should_upd_suntime)
    {
        out = TMBS_SUNTIME;
    }

    if (should_upd_dst && should_upd_suntime)
    {
        out = TMBS_ALL;
    }

    if (out != TMBS_NONE)
    {
        // 距离上一次请求时基信息的时间间隔小于TIMEBASE_INFO_MIN_REQ_PERIOD_SEC，取消这次的请求
        if (utc <= (last_required_utc + TIMEBASE_INFO_MIN_REQ_PERIOD_SEC))
        {
            out = TMBS_NONE;
        }
        // 确认请求，更新请求时间记录
        else
        {
            last_required_utc = utc;
        }
    }

    return out;
}

/**
 * @brief 检查SNTP是否正常或者启动与云服务器同步时间戳
 * @param[in] now_utc   [现在的时间戳]
 */
static void system_time_check(uint32_t now_utc)
{
    uint32_t sntp_update_time = vhal_utils_get_sntp_last_sync();
    // 检查SNTP同步机制是否有效
    if ((now_utc > VCOM_SYSTEM_MIN_TS) && (now_utc < sntp_update_time + TIMEBASE_SNTP_EXPIRED_DURING))
    {
        s_does_sntp_work = true;
        s_last_update_time = sntp_update_time;
#if TIMEBASE_DEBUG_PRINT == 1
        SDK_LOG(LOG_DEBUG, "sntp last sync ts: %d\n", sntp_update_time);
#endif
        return;
    }
    else
    {
        s_does_sntp_work = false;
        // 首次上电，直接请求服务器的同步时间
        if (0 == s_last_update_time)
        {
            tb_ev_req_sync_ts_cb();
        }
        else
        {
            // 限制更新时间的周期
            if (now_utc < s_last_update_time + TIMEBASE_UPDATE_UTC_PERIOD)
            {
#if TIMEBASE_DEBUG_PRINT == 1
                SDK_LOG(LOG_DEBUG, "next sync server ts will be after %d sec\n", TIMEBASE_UPDATE_UTC_PERIOD - (now_utc - s_last_update_time));
#endif
                return;
            }
            // 限制连续请求时间的周期
            if (now_utc < s_last_req_upd_time + TIMEBASE_REQUEST_UTC_PERIOD)
            {
#if TIMEBASE_DEBUG_PRINT == 1
                SDK_LOG(LOG_DEBUG, "next request server ts will be after %d sec\n", TIMEBASE_REQUEST_UTC_PERIOD - (now_utc - s_last_req_upd_time));
#endif
                return;
            }

            tb_ev_req_sync_ts_cb();
            s_last_req_upd_time = now_utc;
        }
    }
}

/**
 * @brief 检查时基信息是否过期并且尝试更新
 * @param[in] now_utc   [现在的时间戳]
 */
static void keep_timebase_updated(uint32_t now_utc)
{
    if (now_utc < VCOM_SYSTEM_MIN_TS)
    {
        return;
    }
    // 这里是为了确保一分钟只执行一次的遍历
    static uint32_t last_loop_min = 0;
    if (now_utc / VCOM_SECOND_PER_MIN == last_loop_min)
    {
        return;
    }
    else
    {
        // 更新分钟计数
        last_loop_min = now_utc / VCOM_SECOND_PER_MIN;
    }

#if TIMEBASE_DEBUG_PRINT == 1
    SDK_LOG(LOG_DEBUG, "now_utc=%d\n", now_utc);
#endif

    // 防止在较小的周期内重复地请求时基
    bool have_upd_td = false;
    if (s_update_tb_flag.should_upd_tb)
    {
        // 检测是否不被允许自发的请求时基信息
        if (!s_global_dis_upd_tb)
        {
            // 回调申请更新时基信息的函数
            tb_ev_req_upd_tb_info_cb(s_update_tb_flag.req_type);
        }
        else
        {
#if TIMEBASE_DEBUG_PRINT == 1
            SDK_LOG(LOG_DEBUG, "timebase update has been disabled\n");
#endif
        }
        // 复位
        s_update_tb_flag.should_upd_tb = false;
        have_upd_td = true;
    }

    bool cfg_changed = false;
    if (VOS_OK != vesync_mutex_lock(s_timebase_mgt.mutex))
    {
        return;
    }

    // 检查是否有可能的时基更新数据
    if (NULL != s_p_no_bypass_msg_buf)
    {
#if TIMEBASE_DEBUG_PRINT == 1
        SDK_LOG(LOG_DEBUG, "parse timebase info and update\n");
#endif
        // 回调应用层的JSON解析方法，解析并更新时基信息
        if (TMBS_OK == tb_ev_no_bp_tb_info_parse_cb(s_p_no_bypass_msg_buf, &s_timebase_mgt.timebase))
        {
            cfg_changed = true;
        }
        // 释放内存
        vesync_free(s_p_no_bypass_msg_buf);
        s_p_no_bypass_msg_buf = NULL;
    }

    // 检查时基信息是否需要更新
    TMBS_INFO_TYPE_E req_type = should_we_upd_timebase(now_utc, &s_timebase_mgt.timebase);
    if (TMBS_NONE != req_type)
    {
#if TIMEBASE_DEBUG_PRINT == 1
        SDK_LOG(LOG_DEBUG, "should update timebase. type:[%d]\n", req_type);
#endif
        if (!have_upd_td)
        {
            // 申请更新时基信息的函数。注意，以异步的方式请求。
            tb_req_upd_and_set_flag(req_type);
        }
    }

    if (cfg_changed)
    {
        if (wr_timebase_mgt_cfg_to_nvm() != TMBS_OK)
        {
            SDK_LOG(LOG_ERROR, "write NVM fail\n");
        }
    }
    vesync_mutex_unlock(s_timebase_mgt.mutex);
}

/**
 * @brief Timebase调度器Timer Callback Function
 * @param[in] arg [可能的定时器回调参数]
 */
static void timebase_cycle_loop(void *arg)
{
    uint32_t now_utc = vhal_utils_get_system_time_sec();

    system_time_check(now_utc);

    keep_timebase_updated(now_utc);
}

/**
 * @brief 启动Timebase定时器
 */
static void timebase_cycle_start(void)
{
    if (s_timebase_mgt.is_running)
    {
        return;
    }

    s_timebase_mgt.timer = vesync_timer_new("timebase",
                                            timebase_cycle_loop,
                                            NULL,
                                            TIMEBASE_CYCLE_TIMER_INTERVAL,
                                            true);
    if (NULL == s_timebase_mgt.timer)
    {
        SDK_LOG(LOG_ERROR, "create timer fail\n");
        return;
    }
    if (VOS_OK != vesync_timer_start(s_timebase_mgt.timer))
    {
        SDK_LOG(LOG_ERROR, "start timer fail\n");
        vesync_timer_free(s_timebase_mgt.timer);
        s_timebase_mgt.timer = NULL;
        return;
    }

    s_timebase_mgt.is_running = true;
}

/**
 * @brief 停止Timebase调度器
 */
static void timebase_cycle_stop(void)
{
    if (!s_timebase_mgt.is_running)
    {
        return;
    }

    if (VOS_OK != vesync_timer_free(s_timebase_mgt.timer))
    {
        SDK_LOG(LOG_ERROR, "stop timer fail\n");
        return;
    }
    s_timebase_mgt.timer = NULL;

    s_timebase_mgt.is_running = false;
}

/**
 * @brief 时间戳换算星期数
 * @param[in] ts    [输入的时间戳]
 * @return TMBS_RPT_CFG_E
 */
static TMBS_RPT_CFG_E ts_to_weekday(uint32_t ts)
{
    struct tm tmp_tm;
    time_t ts_tt = (time_t)ts;

    gmtime_r(&ts_tt, &tmp_tm);

    switch (tmp_tm.tm_wday)
    {
    case 0:
        return TMBS_BIT_SUN;
    case 1:
        return TMBS_BIT_MON;
    case 2:
        return TMBS_BIT_TUE;
    case 3:
        return TMBS_BIT_WED;
    case 4:
        return TMBS_BIT_THU;
    case 5:
        return TMBS_BIT_FRI;
    case 6:
    default:
        return TMBS_BIT_SAT;
    }
}

/**
 * @brief Timebase内部函数，由时基信息，根据UTC计算当地的时间戳，将考虑时区偏移和冬夏令时
 * @param[in] p_tb      [输入时基信息]
 * @param[in] utc       [指定的UTC值]
 * @return uint32_t     [返回的本地时间戳]
 */
static uint32_t utc_to_local_ts(vesync_timebase_t *p_tb, uint32_t utc)
{
    // 本地时区的偏移计算
    int64_t local_ts = ((int64_t)utc + (int64_t)p_tb->tz_info.timezone_ofs_sec);

    // 夏令时的偏移计算
    if (p_tb->dst_info.enabled)
    {
        if (utc < p_tb->dst_info.dst_sw_utc)
        {
            local_ts += (int64_t)p_tb->dst_info.cur_ofs_sec;
        }
        else
        {
            local_ts += (int64_t)p_tb->dst_info.next_ofs_sec;
        }
    }

    return (uint32_t)local_ts;
}

#if 0
/**
 * @brief Timebase内部函数，根据UTC获取本地偏移指定天数是星期几
 * @param[in] p_tb          [输入时基信息]
 * @param[in] utc           [指定的UTC值]
 * @param[in] day_offset    [天的偏移]
 * @return TMBS_RPT_CFG_E
 */
static TMBS_RPT_CFG_E utc_to_local_weekday(vesync_timebase_t *p_tb, uint32_t utc, int32_t day_offset)
{
    // 获得本地时区时间戳
    int64_t local_ts = (int64_t)utc_to_local_ts(p_tb, utc);

    // 偏移一定的天数
    local_ts += ((int64_t)day_offset) * ((int64_t)VCOM_SECOND_PER_DAY);

    return ts_to_weekday((uint32_t)local_ts);
}
#endif

/**
 * @brief Timebase内部函数，根据UTC获取本地时刻秒数
 * @param[in] p_tb          [输入时基信息]
 * @param[in] utc           [指定的UTC值]
 * @return uint32_t         [返回的本地时刻秒数]
 */
static uint32_t utc_to_local_clk_sec(vesync_timebase_t *p_tb, uint32_t utc)
{
    // 获得本地时区时间戳
    uint32_t local_ts = utc_to_local_ts(p_tb, utc);

    return (local_ts % (uint32_t)VCOM_SECOND_PER_DAY);
}

/**
 * @brief Timebase内部函数，获取当地的日出或者日落时刻
 * @param[in]  p_tb         [输入时基信息]
 * @param[in]  is_sunrise   [true - 获得日出的时刻； false - 获得日落的时刻]
 * @param[out] is_valid     [输出UTC的合法性：true - 日出、日落的基准UTC时间合法； false - 日出、日落的基准UTC时间非法]
 * @return uint32_t         [基于秒的时刻值]
 */
static uint32_t get_local_suntime_clk_sec(vesync_timebase_t *p_tb, bool is_sunrise, bool *is_valid)
{
    // 获得日出的UTC时间戳
    uint32_t suntime_utc = 0;

    if (is_sunrise)
    {
        suntime_utc = p_tb->sun_rs_info.sun_rise_utc;
    }
    else
    {
        suntime_utc = p_tb->sun_rs_info.sun_set_utc;
    }

    if (NULL != is_valid)
    {
        if (suntime_utc < VCOM_SYSTEM_MIN_TS)
        {
            *is_valid = false;
        }
        else
        {
            *is_valid = true;
        }
    }

    return utc_to_local_clk_sec(p_tb, suntime_utc);
}

/**
 * @brief Timebase内部函数，获取no bypass消息缓存指针的指针
 * @return char **  [no bypass消息缓存指针的指针]
 */
char **tb_get_no_bp_msg_buf_ptr_ref(void)
{
    return &s_p_no_bypass_msg_buf;
}

/**
 * @brief Timebase内部函数，申请时基更新
 * @param[in] type  [申请更新的类型]
 * @return int      [TMBS_RESULT_E]
 */
int tb_req_upd_and_set_flag(TMBS_INFO_TYPE_E type)
{
    if (s_update_tb_flag.should_upd_tb)
    {
        // 判断是否需要更新类型
        if (type != s_update_tb_flag.req_type)
        {
            s_update_tb_flag.req_type = TMBS_ALL;
        }
    }
    else
    {
        s_update_tb_flag.should_upd_tb = true;
        s_update_tb_flag.req_type = type;
    }

    return TMBS_OK;
}

/**
 * @brief 比较服务器下发的时间戳，判断是否更新本地时间
 * @param[in] uint32_t         [时间戳]
 */
void tb_check_or_update_server_ts(uint32_t ts)
{
    // 时间戳更新周期内误差计算计数
    static uint8_t continue_differ_count = 0;
    // 时间戳更新周期内误差累积
    static int64_t continue_differ_sum = 0;

    uint32_t seconds = 0;
    uint32_t update_time_differ = 0;

    // 上电第一次启动更新时间
    if (0 == s_last_update_time)
    {
        s_last_update_time = ts;
        vesync_device_update_system_time(ts, 0);

        return;
    }

    if (!s_does_sntp_work)
    {
        seconds = vhal_utils_get_system_time_sec();
        SDK_LOG(LOG_DEBUG, "last_update:%d, cloud ts: %d, local ts: %d\n", s_last_update_time, ts, seconds);

        uint32_t new_ts = ts;
        int64_t remote_local_differ = (int64_t)ts - (int64_t)seconds;
        if (0 != remote_local_differ)
        {
            continue_differ_count++;
            continue_differ_sum += remote_local_differ;

#if TIMEBASE_DEBUG_PRINT == 1
            SDK_LOG(LOG_DEBUG, "timebase sync ts, diff_cnt: %d, diff: %ld\n", continue_differ_count, remote_local_differ);
#endif
            if (4 <= continue_differ_count)
            {
                // 本地时间与服务器时间戳连续4次不等:
                //  1.若时间差小于等于上次更新的时间与本次更新时间的理论时间差，则更新本地为新的时间戳
                //  2.若时间差大于上次更新的时间与本次更新时间的理论时间差，则更新时间为本地时间戳加上4次的误差均值
                // 理论上乐鑫芯片在休眠状态下，一天误差在十多分钟，所以取休眠状态下，一秒钟的理论误差为256分之一秒
                update_time_differ = ((ts - s_last_update_time) >> 8);
                int64_t diff_avg = (continue_differ_sum >> 2);

                SDK_LOG(LOG_DEBUG, "diff_average: %d, diff_sum: %ld\n", diff_avg, continue_differ_sum);

                if (update_time_differ < diff_avg)
                {
                    new_ts = (uint32_t)((int64_t)seconds + diff_avg);
                }

                vesync_device_update_system_time(new_ts, 0);
            }
            else
            {
                return;
            }
        }

        s_last_update_time = new_ts;
    }

    continue_differ_count = 0;
    continue_differ_sum = 0;
}

/**
 * @brief Timebase 初始化
 * @return int              [TMBS_RESULT_E]
 */
int vesync_timebase_init(void)
{
    if (s_timebase_mgt.is_init)
    {
        return TMBS_ERR;
    }

    // 读取配置并应用到Timebase实例
    int ret = rd_nvm_cfg_to_timebase_mgt();
    if (TMBS_OK != ret)
    {
        if (TMBS_CFG_NO_EXIST != ret && TMBS_CFG_ERR != ret)
        {
            return ret;
        }

        SDK_LOG(LOG_WARN, "config no found: %d\n", ret);
        // 处理配置不存在的情况
        // 将配置全部复位
        memset(&s_timebase_mgt, 0, sizeof(timebase_mgt_t));
        // 写入出厂时区
        strcpy(s_timebase_mgt.timebase.tz_info.timezone_str, TIMEBASE_TZ_INV_STR);

        ret = TMBS_OK;
    }

    s_timebase_mgt.mutex = vesync_mutex_new();
    if (NULL == s_timebase_mgt.mutex)
    {
        return TMBS_ERR;
    }

    s_timebase_mgt.is_init = true;

    tb_ev_subscribe_all();

    // 启动轮询定时器
    timebase_cycle_start();

    UNUSED(timebase_cycle_stop);

    return ret;
}

/**
 * @brief Timebase信息更新
 * @param[in] p_new_tb      [指向传入的新的Timebase参数]
 * @return int              [TMBS_RESULT_E]
 */
int vesync_timebase_update(vesync_timebase_t *p_new_tb)
{
    if (VOS_OK != vesync_mutex_lock(s_timebase_mgt.mutex))
    {
        return TMBS_ERR;
    }

    // 更新
    memcpy(&s_timebase_mgt.timebase, p_new_tb, sizeof(vesync_timebase_t));

    // 持久化
    int ret = wr_timebase_mgt_cfg_to_nvm();
    if (TMBS_OK != ret)
    {
        SDK_LOG(LOG_ERROR, "write NVM fail\n");

        goto EXIT;
    }

#if TIMEBASE_DEBUG_PRINT == 1
    SDK_LOG(LOG_DEBUG, "timebase updates: tz_str:[%s], tz_ofs:[%ld], long:[%ld], \
lat:[%d], alt:[%d], sr_utc:[%d], ss_utc:[%d], dst_en:[%d], \
dst_cur_ofs:[%ld], dst_sw_utc:[%d], dst_nxt_ofs:[%ld]\n",
            p_new_tb->tz_info.timezone_str, p_new_tb->tz_info.timezone_ofs_sec,
            p_new_tb->sun_rs_info.longitude, p_new_tb->sun_rs_info.latitude, p_new_tb->sun_rs_info.altitude,
            p_new_tb->sun_rs_info.sun_rise_utc, p_new_tb->sun_rs_info.sun_set_utc,
            p_new_tb->dst_info.enabled, p_new_tb->dst_info.cur_ofs_sec, p_new_tb->dst_info.dst_sw_utc, p_new_tb->dst_info.next_ofs_sec);
#else
    SDK_LOG(LOG_INFO, "timebase updates\n");
#endif

EXIT:
    vesync_mutex_unlock(s_timebase_mgt.mutex);
    return ret;
}

/**
 * @brief Timebase信息读取
 * @param[out] p_tb         [指向传出的Timebase Buffer]
 * @return int              [TMBS_RESULT_E]
 */
int vesync_timebase_get(vesync_timebase_t *p_tb)
{
    if (VOS_OK != vesync_mutex_lock(s_timebase_mgt.mutex))
    {
        return TMBS_ERR;
    }

    // 读取
    memcpy(p_tb, &s_timebase_mgt.timebase, sizeof(vesync_timebase_t));

#if TIMEBASE_DEBUG_PRINT == 1
    SDK_LOG(LOG_DEBUG, "timebase gets: tz_str:[%s], tz_ofs:[%ld], long:[%ld], \
lat:[%d], alt:[%d], sr_utc:[%d], ss_utc:[%d], dst_en:[%d], \
dst_cur_ofs:[%ld], dst_sw_utc:[%d], dst_nxt_ofs:[%ld]\n",
            p_tb->tz_info.timezone_str, p_tb->tz_info.timezone_ofs_sec,
            p_tb->sun_rs_info.longitude, p_tb->sun_rs_info.latitude, p_tb->sun_rs_info.altitude,
            p_tb->sun_rs_info.sun_rise_utc, p_tb->sun_rs_info.sun_set_utc,
            p_tb->dst_info.enabled, p_tb->dst_info.cur_ofs_sec, p_tb->dst_info.dst_sw_utc, p_tb->dst_info.next_ofs_sec);
#else
    SDK_LOG(LOG_INFO, "timebase gets\n");
#endif

    vesync_mutex_unlock(s_timebase_mgt.mutex);
    return TMBS_OK;
}

/**
 * @brief Timebase 清除所有信息
 * @return int [TMBS_RESULT_E]
 */
int vesync_timebase_clear(void)
{
    if (VOS_OK != vesync_mutex_lock(s_timebase_mgt.mutex))
    {
        return TMBS_ERR;
    }

    // 复位时基数据
    memset(&s_timebase_mgt.timebase, 0, sizeof(vesync_timebase_t));
    // 恢复出厂时区
    strcpy(s_timebase_mgt.timebase.tz_info.timezone_str, TIMEBASE_TZ_INV_STR);

    // 持久化
    int ret = wr_timebase_mgt_cfg_to_nvm();
    if (TMBS_OK != ret)
    {
        SDK_LOG(LOG_ERROR, "write NVM fail\n");

        goto EXIT;
    }

#if TIMEBASE_DEBUG_PRINT == 1
    SDK_LOG(LOG_DEBUG, "timebase clear all\n");
#else
    SDK_LOG(LOG_INFO, "timebase clear all\n");
#endif

EXIT:
    vesync_mutex_unlock(s_timebase_mgt.mutex);
    return ret;
}

/**
 * @brief Timebase设置时基信息是否自动更新
 * @note  测试接口
 * @param[in] en    [true - 自动更新；false - 禁止自动更新]
 * @return int      [TMBS_RESULT_E]
 */
int vesync_timebase_set_auto_update(bool en)
{
    if (VOS_OK != vesync_mutex_lock(s_timebase_mgt.mutex))
    {
        return TMBS_ERR;
    }

    if (en)
    {
        s_global_dis_upd_tb = false;
    }
    else
    {
        s_global_dis_upd_tb = true;
    }

    vesync_mutex_unlock(s_timebase_mgt.mutex);
    return TMBS_OK;
}

int vesync_timebase_get_info(uint32_t utc, timebase_info_t *p_tb_info)
{
    int ret = TMBS_OK;
    vesync_timebase_t *p_tb = &s_timebase_mgt.timebase;
    bool is_sr_ok = false, is_ss_ok = false;

    if (utc < VCOM_SYSTEM_MIN_TS)
    {
        return TMBS_INV_UTC;
    }

    if (VOS_OK != vesync_mutex_lock(s_timebase_mgt.mutex))
    {
        return TMBS_ERR;
    }

    if (0 == strcmp(p_tb->tz_info.timezone_str, TIMEBASE_TZ_INV_STR))
    {
        ret = TMBS_UNAVBL;
        goto EXIT;
    }

    p_tb_info->local_clk_sec = utc_to_local_clk_sec(p_tb, utc);
    p_tb_info->local_ts = utc_to_local_ts(p_tb, utc);
    p_tb_info->sunrise_clk = get_local_suntime_clk_sec(p_tb, true, &is_sr_ok);
    p_tb_info->sunset_clk = get_local_suntime_clk_sec(p_tb, false, &is_ss_ok);
    p_tb_info->is_sunrise_valid = is_sr_ok;
    p_tb_info->is_sunset_valid = is_ss_ok;

EXIT:
    vesync_mutex_unlock(s_timebase_mgt.mutex);
    return ret;
}

/**
 * @brief Timebase根据时间戳计算偏移指定天数是星期几
 * @param[in] ts            [指定的时间戳]
 * @param[in] day_offset    [天的偏移]
 * @return TMBS_RPT_CFG_E   [返回的结果]
 */
TMBS_RPT_CFG_E vesync_timebase_ts_to_weekday(uint32_t ts, int32_t day_offset)
{
    int64_t local_ts = (int64_t)ts;

    // 偏移一定的天数
    local_ts += ((int64_t)day_offset) * ((int64_t)VCOM_SECOND_PER_DAY);

    return ts_to_weekday((uint32_t)local_ts);
}

/**
 * @brief Timebase判断Repeat配置的数值合法性
 * @param[in] rpt           [输入的Repeat数值]
 * @return true             [该参数合法]
 * @return false            [该参数非法]
 */
bool vesync_timebase_is_rpt_valid(uint32_t rpt)
{
    if (rpt == 0)
    {
        return true;
    }

    if (rpt >= (TMBS_BIT_SUN << 1))
    {
        return false;
    }

    CHECK_REPEAT_BIT_SET(rpt, TMBS_BIT_MON);
    CHECK_REPEAT_BIT_SET(rpt, TMBS_BIT_TUE);
    CHECK_REPEAT_BIT_SET(rpt, TMBS_BIT_WED);
    CHECK_REPEAT_BIT_SET(rpt, TMBS_BIT_THU);
    CHECK_REPEAT_BIT_SET(rpt, TMBS_BIT_FRI);
    CHECK_REPEAT_BIT_SET(rpt, TMBS_BIT_SAT);
    CHECK_REPEAT_BIT_SET(rpt, TMBS_BIT_SUN);

    return false;
}

int vesync_timebase_get_cur_info(timebase_info_t *p_tb_info)
{
    uint32_t now_utc = vhal_utils_get_system_time_sec();

    return vesync_timebase_get_info(now_utc, p_tb_info);
}
