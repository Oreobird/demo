/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_ffs.h
 * @brief       ffs配网接口
 * @date        2021-06-01
 */

#ifndef _VESYNC_FFS_H_
#define _VESYNC_FFS_H_

#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief   结束FFS配网并关闭配网进程, 此接口开放给应用层调用
 * @return  int    [SDK_OK    停止配网成功
 *                  SDK_FAIL  停止配网失败，但也可能配网进程修改状态延时，可再尝试调用]
 */
int vesync_ffs_stop(void);

#ifdef __cplusplus
}
#endif

#endif //_VESYNC_FFS_H_


