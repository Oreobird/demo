/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        outlet_button.h
 * @brief       outlet button头文件
 * @author      CharlesMei
 * @date        2021-06-22
 */


#ifndef __OUTLET_BUTTON_H__
#define __OUTLET_BUTTON_H__

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */


/**
 * @brief 产测时，强制退出按键扫描任务
 */
void outlet_button_task_exit(void);

/**
 * @brief outlet button初始化
 */
void outlet_button_init(void);


#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* __OUTLET_BUTTON_H__ */

