/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
* @file         netcfg.c
* @brief        配网业务逻辑接口
* @author       Joshua
* @date         2021-12-29
*/

#include <string.h>

#include "vhal_wifi.h"

#include "vesync_log.h"
#include "vesync_device.h"
#include "vesync_netcfg.h"
#include "vesync_common.h"
#include "vesync_net_service.h"
#include "scene.h"
#include "netcfg.h"

static void netcfg_success_cb(void)
{
    APP_LOG(LOG_DEBUG, "netcfg success\n");
    scene_t *scene = scene_registry_get(SCENE_NETCFG, 0);
    netcfg_light_scene_success(scene);
}

static void netcfg_process_cb(void)
{
    APP_LOG(LOG_DEBUG, "netcfg success\n");
    scene_t *scene = scene_registry_get(SCENE_NETCFG, 0);
    netcfg_light_scene_process(scene);
}

void app_netcfg_init(void)
{
    vesync_netcfg_reg_ev_cb(NETCFG_EV_SUCCESS, netcfg_success_cb);
    vesync_netcfg_reg_ev_cb(NETCFG_EV_RECV_CONFIG, netcfg_process_cb);
}


