/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
 * @file        vesync_nfc.c
 * @brief       nfc模块vesync层对外接口实现
 * @date        2021-11-13
 */
#include "vesync_tl_frame_parse.h"
#include "vesync_nfc_internal.h"
#include "vesync_common.h"
#include "vesync_log_internal.h"
#include <stdio.h>
#include <string.h>
#include "vesync_memory.h"
#include "vesync_task.h"
#include "vesync_cfg_internal.h"
#if defined(CONFIG_NFC_NETCFG_MODE) && (CONFIG_NFC_NETCFG_MODE == NFC_CARD_MODE)
#include "vesync_nfc_card.h"
#if defined(CONFIG_NFC_CARD_MCU) && (CONFIG_NFC_CARD_MCU == NFC_CARD_FM11NT081DX)
#include "vdrv_fm11nt081dx.h"
#endif
#endif
#include "vesync_json_internal.h"
#include "vesync_device.h"
#include "vesync_netcfg_internal.h"
#include "vesync_net_service_internal.h"
#include "vhal_utils.h"
#include "vesync_utils.h"
#include "vesync_netcfg_recv.h"
#include "vesync_aes.h"

/**
 * @brief 数据接收返回应用层回调函数,将正确的数据帧通过此回调函数传给配网模块
*/
static vesync_nfc_frame_recv_cb_t s_vesync_nfc_frame_cb_func = NULL;

static tl_frame_recv_info_t *sp_nfc_frame_header; // 接收数据包头

//发送nfc数据回调函数
static vesync_nfc_send_data_cb_t s_vesync_nfc_send_data_cb = NULL;

//启动nfc通信回调
static vesync_nfc_start_stop_cb_t s_vesync_nfc_start_cb = NULL;

//停止nfc通信回调
static vesync_nfc_start_stop_cb_t s_vesync_nfc_stop_cb = NULL;

/**
 * @brief  NFC事件回调函数
 * @param[in]  event           [NFC事件类型]
 */
void vesync_nfc_evt_cb(VESYNC_NFC_EVT_E event)
{
    SDK_LOG(LOG_INFO, "event =%d now stop\n", event);
    s_vesync_nfc_stop_cb();
}

/**
 * @brief  nfc数据接收回调函数
 * @param[in]  p_data          [接收的命令数据]
 * @param[in]  length          [数据长度]
 */
void vesync_nfc_recv_cb(uint8_t *p_data, uint16_t length)
{
    uint16_t i = 0;

    SDK_LOG(LOG_DEBUG, "nfc cfg data=%s data len =%d\n", p_data, length);

    if (NULL == p_data || 0 == length || length > VESYNC_NFC_PAYLOAD_MAX_LEN)
    {
        return;
    }

#if 0 //实际应用走这个分支，数据带vesync帧头
    for (i = 0; i < length; i++)
    {
        if (vesync_tl_frame_decode(p_data[i], VESYNC_NFC_PAYLOAD_MAX_LEN, sp_nfc_frame_header))
        {
            continue;
        }
        if (vesync_tl_frame_checksum_verify(sp_nfc_frame_header))
        {
            continue;
        }

        if (s_vesync_nfc_frame_cb_func)
        {
            s_vesync_nfc_frame_cb_func(sp_nfc_frame_header);
        }
    }

#else //demo测试走这个分支
    memcpy(sp_nfc_frame_header->p_payload, p_data, length);
    sp_nfc_frame_header->payload_len = length;

    if (s_vesync_nfc_frame_cb_func)
    {
        s_vesync_nfc_frame_cb_func(sp_nfc_frame_header);
    }

#endif
}

uint32_t vesync_nfc_init(void)
{

#if defined(CONFIG_NFC_NETCFG_MODE) && (CONFIG_NFC_NETCFG_MODE == NFC_CARD_MODE) //读写卡模式
    vesync_nfc_card_ctrl_t nfc_card_ctrl;

    memset(&nfc_card_ctrl, 0, sizeof(nfc_card_ctrl));
    nfc_card_ctrl.hw_interface.iic_ctrl.iic_cs_pin = CONFIG_NFC_IIC_CS_PIN;
    nfc_card_ctrl.hw_interface.iic_ctrl.scl_pin = CONFIG_NFC_IIC_SCL_PIN;
    nfc_card_ctrl.hw_interface.iic_ctrl.sda_pin = CONFIG_NFC_IIC_SDA_PIN;

#if defined(CONFIG_NFC_CARD_INTERFACE) && (CONFIG_NFC_CARD_INTERFACE == CARD_INTERFACE_IIC)
    nfc_card_ctrl.interface_init_cb.iic_init_cb = vdrv_fm11nt081dx_init;
#endif
    nfc_card_ctrl.basic_info.dev_info_addr = CONFIG_NFC_CARD_DEV_INFO_ADDR;
    nfc_card_ctrl.basic_info.dev_info_len = CONFIG_NFC_CARD_DEV_INFO_LEN;
    nfc_card_ctrl.basic_info.netcfg_info_addr = CONFIG_NFC_CARD_DEV_NET_CFG_INFO_ADDR;
    nfc_card_ctrl.basic_info.netcfg_info_len = CONFIG_NFC_CARD_DEV_NET_CFG_INFO_LEN;
    nfc_card_ctrl.basic_info.netcfg_error_info_addr = CONFIG_NFC_CARD_DEV_NET_CFG_ERROR_ADDR;
    nfc_card_ctrl.basic_info.netcfg_error_info_len = CONFIG_NFC_CARD_DEV_NET_CFG_ERROR_LEN;
    nfc_card_ctrl.basic_info.uid_len = CONFIG_NFC_UID_MAX_LEN;

    nfc_card_ctrl.wake_up_ctrl.wait_time_after_wakeup_s = CONFIG_NFC_WAKEUP_WAIT_TIME_S;
    nfc_card_ctrl.wake_up_ctrl.wake_up_en = 1;
    nfc_card_ctrl.wake_up_ctrl.wake_up_pin = CONFIG_NFC_WAKEUP_PIN;
    nfc_card_ctrl.wake_up_init_cb = vdrv_fm11nt081dx_set_wakeup;
    nfc_card_ctrl.nfc_card_wake_up_isr_register_cb = (vesync_nfc_card_wake_up_isr_register)vdrv_fm11nt081dx_register_wake_cb;

    nfc_card_ctrl.psw_ctrl.psw_en = CONFIG_VESYNC_NFC_CARD_PWD_EN;
    nfc_card_ctrl.psw_ctrl.psw = CONFIG_VESYNC_NFC_CARD_PWD;
    nfc_card_ctrl.psw_ctrl.psw_ack = CONFIG_VESYNC_NFC_CARD_PWD_ACK;

    nfc_card_ctrl.psw_inti_cb = vdrv_fm11nt081dx_set_auth_pwd;

    nfc_card_ctrl.write_data_cb = vdrv_fm11nt081dx_write_data;
    nfc_card_ctrl.read_cb = vdrv_fm11nt081dx_read_data;
    nfc_card_ctrl.uid_get_cb = vdrv_fm11nt081dx_get_uid;

    vesync_nfc_card_create(&nfc_card_ctrl);

    vesync_nfc_card_reg_recv_cb(vesync_nfc_recv_cb);

    vesync_nfc_card_reg_event_cb(vesync_nfc_evt_cb);

    s_vesync_nfc_send_data_cb = (vesync_nfc_send_data_cb_t)vesync_nfc_card_netcfg_data_send;
    s_vesync_nfc_start_cb = vesync_nfc_card_start_netcfg;
    s_vesync_nfc_stop_cb = vesync_nfc_card_stop_netcfg;

#else

#endif

    sp_nfc_frame_header = vesync_malloc(sizeof(tl_frame_recv_info_t) + VESYNC_NFC_PAYLOAD_MAX_LEN);

    if (NULL == sp_nfc_frame_header)
    {
        return SDK_FAIL;
    }

    memset(sp_nfc_frame_header, 0, (sizeof(sp_nfc_frame_header) + VESYNC_NFC_PAYLOAD_MAX_LEN));
    return SDK_OK;
}

void vesync_nfc_reg_netcfg_recv_cb(vesync_nfc_frame_recv_cb_t cb)
{
    s_vesync_nfc_frame_cb_func = cb;
}

uint32_t vesync_nfc_send_data(uint8_t data_type, uint8_t *p_data, uint16_t len, uint8_t req_flag)
{
    tl_frame_send_info_t frame_info = {0};
    uint16_t buf_len = 0;
    uint8_t *buf = NULL;
    uint32_t ret = 0;

    frame_info.payload_len = len;
    frame_info.p_payload = p_data;
    frame_info.ctrl.bitN.version = VESYNC_NFC_PROTOCO_VERSION;
    frame_info.ctrl.bitN.ack_flag = 0;
    frame_info.ctrl.bitN.request_flag = req_flag;
    frame_info.ctrl.bitN.error_flag = 0;

    buf_len = len + VESYNC_NFC_PROTOCO_HEAD_LEN;

    buf = vesync_malloc(buf_len);
    if (NULL == buf)
    {
        return SDK_FAIL;
    }

    vesync_tl_frame_encode(&frame_info, buf, &buf_len);
    s_vesync_nfc_send_data_cb(data_type, buf, buf_len);

    vesync_free(buf);

    return ret;
}

uint32_t vesync_nfc_send_dev_info(uint8_t req_flag)
{
    uint32_t ret = SDK_FAIL;
    cJSON *root = NULL;
    net_info_t netcfg_info;
    char *out = NULL;
    char mac_str[MAC_ADDR_STR_MAX_LEN] = {0};
    uint8_t *encryptData = NULL;
    int encryptLen = 0;
    payload_info_t *payload = NULL;
    uint32_t plen = 0;

    root = cJSON_CreateObject();
    if (NULL == root)
    {
        return ret;
    }

    cJSON_AddStringToObject(root, "firmVersion", vesync_cfg_get_fw_version());
    cJSON_AddStringToObject(root, "deviceType", vesync_cfg_get_model());
    cJSON_AddStringToObject(root, "cid", vesync_device_get_cid());

    memset(&netcfg_info, 0, sizeof(netcfg_info));
    if (SDK_OK != vesync_net_flash_read_net_info(&netcfg_info) || strlen((char *)netcfg_info.wifiSSID) < 1)
    {
        /* 1st time to use or reset device config. */
        cJSON_AddNumberToObject(root, "networkStatus", 0);
        cJSON_AddStringToObject(root, "accountId", "");
    }
    else
    {
        cJSON_AddNumberToObject(root, "networkStatus", 1);
        cJSON_AddStringToObject(root, "accountId", vesync_device_get_account_id());
    }

    vhal_utils_get_dev_mac(VHAL_MAC_WIFI_STA, mac_str, sizeof(mac_str));
    // if fail to get mac, it would be "deviceMac":    ""
    cJSON_AddStringToObject(root, "deviceMac", mac_str);
    cJSON_AddStringToObject(root, "deviceRegion", vesync_cfg_get_country_code());

    vesync_json_print(root);

    if (root)
    {
        out = cJSON_PrintUnformatted(root); //不带缩进格式

        if (NULL == out)
        {
            SDK_LOG(LOG_ERROR, "cJSON_PrintUnformatted failed\r\n");
            goto exit;
        }
        SDK_LOG(LOG_INFO, "out = %s \n", out);

        encryptLen = vesync_aes_encrypt((uint8_t *)out, strlen(out), &encryptData);
        if (!encryptLen)
        {
            SDK_LOG(LOG_ERROR, "AES Encrypt fail\r\n");
            goto exit;
        }
    }

    plen = encryptLen + sizeof(payload_info_t);
    payload = (payload_info_t *)vesync_malloc(plen);
    if (NULL == payload)
    {
        SDK_LOG(LOG_ERROR, "paylaod malloc fail\r\n");
        goto exit;
    }

    memset(payload, 0, plen);
    payload->version = vesync_netcfg_config_get_protocol_version();
    payload->status_code = 0;

    payload->opcode = vesync_htobe16(NFC_OP_QUERY_INFO); //小端模式

    if (NULL != encryptData)
    {
        memcpy(payload->payload_data, encryptData, encryptLen);
    }

    ret = vesync_nfc_send_data(TYPE_DEV, (uint8_t *)payload, plen, req_flag);

exit:
    VCOM_SAFE_FREE(out);
    VCOM_SAFE_FREE(encryptData);
    VCOM_SAFE_FREE(payload);
    cJSON_Delete(root);

    return ret;
}

uint32_t vesync_nfc_send_error_info(uint8_t *p_data, uint16_t len, uint8_t req_flag)
{
    return vesync_nfc_send_data(TYPE_NETCFG_ERR_INFO, p_data, len, req_flag);
}

uint32_t vesync_nfc_start_netcfg(void)
{
    return s_vesync_nfc_start_cb();
}

uint32_t vesync_nfc_stop_netcfg(void)
{
    return s_vesync_nfc_stop_cb();
}
