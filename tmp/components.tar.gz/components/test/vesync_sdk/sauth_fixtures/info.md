#### 生成根证书密钥对
`openssl ecparam -out test_root.key -name prime256v1 -genkey`
#### 生成根证书请求
`openssl req -new -sha256 -key test_root.key -out test_root.csr`
#### 用根密钥对自己签发证书
`openssl x509 -days 3650 -req -in test_root.csr -signkey test_root.key -out test_root.crt`

#### 生成设备证书密钥对
`openssl ecparam -out test_dev.key -name prime256v1 -genkey`
#### 生成设备证书请求
`openssl req -new -sha256 -key test_dev.key -out test_dev.csr`
#### 用根证书签发设备证书
`openssl x509 -req -days 3650 -in test_dev.csr -CA test_root.crt -CAkey test_root.key -CAcreateserial -out test_dev.cst`

#### 生成APP证书密钥对
`openssl ecparam -out test_app.key -name prime256v1 -genkey`
#### 生成APP证书请求
`openssl req -new -sha256 -key test_app.key -out test_app.csr`
#### 用根证书签发APP证书
`openssl x509 -req -days 3650 -in test_app.csr -CA test_root.crt -CAkey test_root.key -CAcreateserial -out test_app.cst`
