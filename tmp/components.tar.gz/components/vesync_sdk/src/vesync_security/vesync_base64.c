/*
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file        vesync_base64.c
* @brief       base64编解码相关接口
* @date        2021-05-17
*/

#include "mbedtls/base64.h"
#include "vesync_common.h"
#include "vesync_base64.h"

/**
* @brief  base64编码
* @param[out] dst                   [目标缓冲区]
* @param[in]  dlen                  [目标缓冲区的大小]
* @param[out] olen                  [写入的字节数]
* @param[in]  src                   [待编码数据]
* @param[in]  slen                  [待编码数据长度]
* @return  int                      [成功返回SDK_OK, 失败返回SDK_FAIL]
*/
int vesync_base64_encode(unsigned char *dst, size_t dlen, size_t *olen, const unsigned char *src, size_t slen)
{
    int ret = mbedtls_base64_encode(dst, dlen, olen, src, slen);
    return ret == 0 ? SDK_OK : SDK_FAIL;
}


/**
* @brief  base64解码
* @param[out] dst                   [目标缓冲区]
* @param[in]  dlen                  [目标缓冲区的大小]
* @param[out] olen                  [写入的字节数]
* @param[in]  src                   [待解码数据]
* @param[in]  slen                  [待解码数据长度]
* @return  int                      [成功返回SDK_OK, 失败返回SDK_FAIL]
*/
int vesync_base64_decode(unsigned char *dst, size_t dlen, size_t *olen, const unsigned char *src, size_t slen)
{
    int ret = mbedtls_base64_decode(dst, dlen, olen, src, slen);
    return ret == 0 ? SDK_OK : SDK_FAIL;
}

