/**
 *  Copyright © Vesync Technologies Co.Ltd. 2019-2021. All rights reserved.
 * @file        vesync_uart_internal.h
 * @brief       串口内部处理模块、UART数据封装/解析
 * @author      Dongri.Su
 * @date        2021-05-08
 */

#ifndef __VESYNC_UART_INTERNAL_H__
#define __VESYNC_UART_INTERNAL_H__

#include <stdbool.h>

#include "vesync_cfg.h"
#include "vesync_timer.h"
#include "vesync_uart.h"
#include "vesync_tl_frame_parse.h"
#include "vesync_tl_payload_parse.h"

#ifdef __cplusplus
extern "C"
{
#endif


#define UART_FRAME_PAYLOAD_MAX_LEN      (PR_UART_PAYLOAD_MAX_LEN)    // 串口传输数据最大长度
#define UART_TL_PROT_VER                (2)         // 协议版本

/*
 * @brief UART发送返回码
 */
typedef enum
{
    UART_TL_SUCCESS = 0,            // 发送成功
    UART_TL_ERROR_INVALID_POINTER,  // 发送数据指针非法
    UART_TL_ERROR_INVALID_LENGTH,   // 发送数据长度非法
    UART_TL_ERROR_SEND_BUSY,        // 发送处于忙碌(当前正在发送)
    UART_TL_ERROR_OTHER
} UART_ERR_CODE_E;


/*
 * @brief 记录UART接收数据
 */
typedef struct
{
    uint8_t sequence_id;        // 序列号
    uint8_t checksum;           // 校验和
} repeat_recv_frame_record_t;

/*
 * @brief 串口发送信息记录
 */
typedef struct
{
    vesync_timer_t timer;                               // 定时器
    uart_tx_event_cb_t tx_data_event_cb;                // 发送数据事件回调
    uart_tx_event_cb_t tx_ota_event_cb;                 // 发送数据事件回调(OTA)
    tl_frame_send_info_t send_frame_info;               // UART发送的帧信息
    bool send_busy_flag;                                // UART正在发送标志位
    uint8_t uart_num;                                   // 串口编号
    uint8_t send_repeat_cnt;                            // UART发送重传次数
    uint8_t send_req_flag;                              // 用于指示接收该数据包的设备是否需要回应答，0：不需要回应答  1：需要回应答
    uint16_t send_data_len;                             // UART发送数据长度
    uint8_t *p_send_buf;                                // UART发送缓存
} uart_send_info_t;

/*
 * @brief 串口接收信息记录
 */
typedef struct
{
    uart_recv_data_cb_t recv_data_cb;                   // 接收数据回调
    uart_recv_data_cb_t recv_ota_data_cb;               // 接收数据回调(OTA)
    tl_frame_recv_info_t recv_frame_info;               // UART接收到的帧信息
    repeat_recv_frame_record_t recv_frame_record;       // UART接收帧信息记录
} uart_recv_info_t;


/**
 * @brief 注册UART串口服务数据接收回调函数，ota cb处理具体的业务
 * @param[in]  cb                   [串口数据接收回调函数]
 */
void vesync_uart_reg_recv_ota_cb(uart_recv_data_cb_t cb);

/**
 * @brief 注册UART串口发送返回事件回调函数
 * @param[in]  cb                   [发送返回事件回调函数]
 */
void vesync_uart_reg_tx_event_ota_cb(uart_tx_event_cb_t cb);

/**
 * @brief 应用层串口数据发送函数
 * @param[in] request_flag          [用于指示接收该数据包的设备是否需要回应答，0：不需要回应答  1：需要回应答；]
 * @param[in]  uart_num             [串口编号]
 * @param[in] opcode                [操作码]
 * @param[in] p_dat                 [发送数据，无数据传入NULL（len必须为0）]
 * @param[in] len                   [数据长度]
 * @return    int32_t               [返回0表示发送成功，非零为失败]
 */
int32_t vesycn_uart_send_data(uint8_t request_flag, VHAL_UART_PORT_E uart_num, uint16_t opcode, uint8_t *p_dat, uint16_t len);

/**
 * @brief 应答发送函数  接收回调通过判断frame_recv_info.ctrl.bitN.request_flag是否需要应答
 * @param[in]  err_flag             [错误标志位，0：无错误； 1：错误；]
 * @param[in]  uart_num             [串口编号]
 * @param[in]  opcode               [操作码]
 * @param[in]  status_code          [状态码]
 * @param[in]  p_dat                [数据，无数据传入NULL（len必须为0）]
 * @param[in]  len                  [数据长度]
 * @return     int32_t              [返回0表示发送成功，非零为失败]
 */
int32_t vesync_uart_send_ack(uint8_t err_flag, VHAL_UART_PORT_E uart_num, uint16_t opcode, uint16_t status_code, uint8_t *p_dat, uint16_t len);

/**
 * @brief 应答发送函数  接收回调通过判断frame_recv_info.ctrl.bitN.request_flag是否需要应答
 * @param[in]  seq_id               [序列号]
 * @param[in]  err_flag             [错误标志位，0：无错误； 1：错误；]
 * @param[in]  uart_num             [串口编号]
 * @param[in]  opcode               [操作码]
 * @param[in]  status_code          [状态码]
 * @param[in]  p_dat                [数据，无数据传入NULL（len必须为0）]
 * @param[in]  len                  [数据长度]
 * @return     int32_t              [返回0表示发送成功，非零为失败]
 */
int32_t vesync_uart_send_ack_with_seq_id(uint8_t seq_id, uint8_t err_flag,
                VHAL_UART_PORT_E uart_num, uint16_t opcode, uint16_t status_code, uint8_t *p_dat, uint16_t len);

/**
 * @brief 检查发送是否在忙
 * @return  bool                        [true, 在忙; false, 空闲]
 */
bool vesync_uart_check_send_busy(void);

/**
 * @brief  串口发送后的应答处理
 * @param[in]  event                    [串口数据发送成功/失败事件]
 * @param[in]  p_payload                [发送应答帧的数据字段]
 * @param[in]  payload_len              [应答帧的payload长度]
 * @param[in]  p_msg                    [发送的消息]
 * @return     void
 */
void vesync_uart_rsp_process(UART_SEND_TYPE_E event, tl_payload_info_t *p_payload, uint16_t payload_len, uart_msg_queue_t *p_msg);



#ifdef __cplusplus
}
#endif

#endif
