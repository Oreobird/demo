/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_sem.c
 * @brief       semaphore抽象层，封装freertos信号量相关接口
 * @author      Joshua
 * @date        2021-04-20
 */
#include <freertos/FreeRTOS.h>
#include <freertos/semphr.h>

#include "vesync_log.h"
#include "vesync_memory.h"
#include "vesync_common.h"
#include "vesync_os_internal.h"
#include "vesync_sem.h"

/**
 * @brief  创建二值信号量
 * @return vesync_sem_t                [信号量结构体指针]
 */
vesync_sem_t *vesync_sem_binary_new(void)
{
    vesync_sem_t *p_vsem = (vesync_sem_t *)vesync_malloc(sizeof(vesync_sem_t));
    if (p_vsem == NULL)
    {
        return NULL;
    }

    SemaphoreHandle_t sem_bin = xSemaphoreCreateBinary();
    if (sem_bin == NULL)
    {
        VCOM_SAFE_FREE(p_vsem);
        return NULL;
    }

    p_vsem->max_count = 1;
    p_vsem->handle = sem_bin;

    return p_vsem;
}

/**
 * @brief  创建计数信号量
 * @param[in]  max_count               [信号量最大计数]
 * @return vesync_sem_t                [信号量结构体指针]
 */
vesync_sem_t *vesync_sem_count_new(unsigned int max_count)
{
    if (max_count < 1 || max_count > VESYNC_OS_SEM_MAX_COUNT)
    {
        OS_LOG(LOG_ERROR, "max count should not larger than %d\n", VESYNC_OS_SEM_MAX_COUNT);
        return NULL;
    }

    vesync_sem_t *p_vsem = (vesync_sem_t *)vesync_malloc(sizeof(vesync_sem_t));
    if (p_vsem == NULL)
    {
        return NULL;
    }

    SemaphoreHandle_t sem_count = xSemaphoreCreateCounting(max_count, 0);
    if (sem_count == NULL)
    {
        VCOM_SAFE_FREE(p_vsem);
        return NULL;
    }

    p_vsem->max_count = max_count;
    p_vsem->handle = sem_count;

    return p_vsem;
}

/**
 * @brief  等待信号量
 * @param[in]  sem                     [信号量结构体指针]
 * @param[in]  timeout_ms              [等待时间：
 *                                      VESYNC_OS_NO_WAIT: 不等待
 *                                      VESYNC_OS_WAIT_FOREVER: 等待信号量]
 * @return int                         [成功：VOS_OK；失败：VOS_FAIL]
 */
int vesync_sem_wait(vesync_sem_t *sem, unsigned int timeout_ms)
{
    VCOM_NULL_PARAM_CHK(sem, return VOS_FAIL);
    VCOM_NULL_PARAM_CHK(sem->handle, return VOS_FAIL);
    BaseType_t ret = xSemaphoreTake((SemaphoreHandle_t)sem->handle, timeout_ms == VESYNC_OS_WAIT_FOREVER ? portMAX_DELAY : VESYNC_MS_TO_TICKS(timeout_ms));
    return ret == pdPASS ? VOS_OK : VOS_FAIL;
}

/**
 * @brief  释放信号量
 * @param[in]  sem                     [信号量结构体指针]
 * @return int                         [成功：VOS_OK；失败：VOS_FAIL]
 */
int vesync_sem_signal(vesync_sem_t *sem)
{
    VCOM_NULL_PARAM_CHK(sem, return VOS_FAIL);
    VCOM_NULL_PARAM_CHK(sem->handle, return VOS_FAIL);
    BaseType_t ret = xSemaphoreGive((SemaphoreHandle_t)sem->handle);
    return ret == pdPASS ? VOS_OK : VOS_FAIL;
}

/**
 * @brief  销毁信号量
 * @param[in]  sem                     [信号量结构体指针]
 * @return int                         [成功：VOS_OK；失败：VOS_FAIL]
 */
int vesync_sem_free(vesync_sem_t *sem)
{
    VCOM_NULL_PARAM_CHK(sem, return VOS_FAIL);
    VCOM_NULL_PARAM_CHK(sem->handle, return VOS_FAIL);
    vSemaphoreDelete((SemaphoreHandle_t)sem->handle);
    vesync_free(sem);
    return VOS_OK;
}

