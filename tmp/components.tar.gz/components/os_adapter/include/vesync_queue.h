/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_queue.h
 * @brief       queue抽象层，封装队列相关接口
 * @date        2021-04-20
 */

#ifndef __VESYNC_QUEUE_H__
#define __VESYNC_QUEUE_H__

#include "vesync_os.h"

#ifdef __cplusplus
extern "C" {
#endif

#define VESYNC_QUEUE_MSG_MAX_LEN  (4096)  //最大消息payload长度

/**
* @brief  队列结构体
*/
typedef struct
{
    int msg_size;    //队列消息长度
    void *handle;    //队列指针
} vesync_queue_t;


/**
 * @brief  创建队列
 * @param[in]  queue_size              [队列大小(消息大小*消息个数), 单位字节]
 * @param[in]  msg_size                [队列消息大小，单位字节]
 * @return vesync_queue_t              [队列结构体指针]
 */
vesync_queue_t *vesync_queue_new(unsigned int queue_size, unsigned int msg_size);

/**
 * @brief  队列发送
 * @param[in]  queue                   [队列结构体指针]
 * @param[in]  msg                     [消息]
 * @param[in]  timeout_ms              [定义当队列满的情况下，发送方的行为：
 *                                      VESYNC_OS_NO_WAIT: 不等待
 *                                      VESYNC_OS_WAIT_FOREVER: 等待直到队列不满]
 * @return int                         [成功：VOS_OK；失败：VOS_FAIL]
 */
int vesync_queue_send(vesync_queue_t *queue, void *msg, unsigned int timeout_ms);

/**
 * @brief  队列接收
 * @param[in]  queue                   [队列结构体指针]
 * @param[in]  msg                     [消息]
 * @param[in]  timeout_ms              [定义当队列为空的情况下，发送方的行为：
 *                                      VESYNC_OS_NO_WAIT: 不等待
 *                                      VESYNC_OS_WAIT_FOREVER: 等待直到队列不为空]
 * @return int                         [成功：VOS_OK；失败：VOS_FAIL]
 */
int vesync_queue_recv(vesync_queue_t *queue, void *msg, unsigned int timeout_ms);

/**
 * @brief  清空队列内容
 * @param[in]  queue                   [队列结构体指针]
 * @return int                         [成功：VOS_OK；失败：VOS_FAIL]
 */
int vesync_queue_clear(vesync_queue_t *queue);

/**
 * @brief  删除队列
 * @param[in]  queue                   [队列结构体指针]
 * @return int                         [成功：VOS_OK；失败：VOS_FAIL]
 */
int vesync_queue_free(vesync_queue_t *queue);


#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_QUEUE_H__ */

