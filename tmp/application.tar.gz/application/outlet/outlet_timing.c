/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file        outlet_timing.c
* @brief       outlet timing配置
* @author      Joshua
* @date        2021-06-15
*/
#include <string.h>
#include <stdio.h>

#include "vesync_common.h"
#include "vesync_log.h"
#include "vesync_timing.h"
#include "vesync_device.h"
#include "outlet_timing.h"
#include "outlet_report.h"
#include "outlet.h"

static outlet_timing_t s_outlet_timing;       // 保存timer


/**
 * @brief timer时间到时执行的动作
 * @param[in]  uint16_t                 [timer id]
 * @return     void                     [none]
 */
static void outlet_timing_act(uint16_t id)
{
    outlet_ev_t ev;

    if (s_outlet_timing.on_off)
    {
        ev.id = OUTLET_EV_ON;
        ev.act_src = OUTLET_ACT_SRC_TASK;
    }
    else
    {
        ev.id = OUTLET_EV_OFF;
        ev.act_src = OUTLET_ACT_SRC_TASK;
    }

    snprintf(ev.rsn, sizeof(ev.rsn), "%s", STAT_CHG_RSN_TIMER_STR);

    outlet_app_task_notify(&ev);

    outlet_report_timing_exec(&s_outlet_timing, APP_OK, "");   // timer执行结果上报服务器做记录
    outlet_timing_remove(id);                         // 删除应用层数据
}

/**
 * @brief 新增一个timer
 * @param[in]   action      [timer执行动作]
 * @param[in]   total_sec   [timer定时时间]
 * @param[out]  p_id        [timer id]
 * @return     int_t                    [错误码]
 */
int outlet_timing_add(bool action, uint32_t total_sec, uint16_t *p_id)
{
    int ret = -1;

    if (NULL == p_id)
    {
        return APP_FAIL;
    }

    *p_id = MIN_OUTLET_TIMER_ID;

    if (0 != s_outlet_timing.id)
    {
        APP_LOG(LOG_ERROR, "Timing is exist!\n");
        return APP_FAIL;
    }

    s_outlet_timing.id = *p_id;
    s_outlet_timing.on_off = action;
    s_outlet_timing.total_sec = total_sec;

    APP_LOG(LOG_DEBUG,"on_off = %d, total_sec = %d\n", action, total_sec);

    ret = vesync_timing_add(s_outlet_timing.id, total_sec);
    if (SDK_OK != ret)
    {
        return APP_FAIL;
    }

    return APP_OK;
}

/**
 * @brief 获取timer执行的动作
 * @param[out] uint16_t                 [timer id]
 * @param[in]  bool                     [timer执行的开关动作]
 * @return     int_t                    [错误码]
 */
int outlet_timing_get_act(uint16_t tm_id, bool *p_act)
{
    (void)tm_id;

    if (NULL == p_act)
    {
        APP_LOG(LOG_ERROR, "Input parameters contain null pointers!\n");
        return APP_FAIL;
    }

    *p_act = s_outlet_timing.on_off;

    return APP_OK;
}


/**
 * @brief 删除一个timer
 * @param[in]  uint16_t                 [timer id]
 * @return     int_t                    [成功/失败]
 */
int outlet_timing_remove(uint16_t timer_id)
{
    if (s_outlet_timing.id != timer_id)
    {
        APP_LOG(LOG_ERROR, "Input ID is %d, not equal %d!\n", timer_id, s_outlet_timing.id);
        return APP_FAIL;
    }

    // 从队列中删除
    vesync_timing_remove(timer_id);

    // 清除缓存
    memset((uint8_t *)&s_outlet_timing, 0, sizeof(outlet_timing_t));

    return APP_OK;
}

/**
 * @brief 清空timer
 * @param void
 */
int outlet_timing_clear(void)
{
    // 清除timer队列
    vesync_timing_clear();

    // 清除缓存
    memset((uint8_t *)&s_outlet_timing, 0, sizeof(outlet_timing_t));

    return APP_OK;
}


/**
 * @brief 初始化timer
 * @param void
 */
void outlet_timing_init(void)
{
    // 注册定时器动作回调
    vesync_timing_reg_cb(outlet_timing_act);
}

