/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        timer_test.cpp
 * @brief       os_adapter timer测试用例
 * @author      Joshua
 * @date        2021-04-21
 */

#include <gtest/gtest.h>
#include <pthread.h>

#include "vesync_os.h"
#include "vesync_timer.h"
#include "vesync_sem.h"

static vesync_sem_t g_sem;

typedef struct
{
	int count;
	char msg[128];
} test_arg_t;

static void timeout_cb(void* arg)
{
    test_arg_t *t_arg = (test_arg_t *)arg;
    t_arg->count++;
    printf("timeout_cb arg: count=%d, msg=%s\n", t_arg->count, t_arg->msg);
    if (t_arg->count > 5)
    {
        vesync_sem_signal(&g_sem);
    }
}


TEST(timer_test, timer_start_once)
{
    int ret = 0;
    vesync_timer_t timer;
    long timeout = 500;
    test_arg_t arg;
    arg.count = 0;
    snprintf(arg.msg, sizeof(arg.msg), "%s", "timer_start_once test msg");

    ret = vesync_sem_new(&g_sem);
    EXPECT_EQ(ret, 0);

    ret = vesync_timer_new(&timer, "test_timer", timeout_cb, &arg, timeout, 0);
    EXPECT_EQ(ret, 0);

    ret = vesync_timer_start(&timer);
    EXPECT_EQ(ret, 0);

    vesync_sem_wait(&g_sem, 1000);
    EXPECT_EQ(arg.count, 1);

    ret = vesync_timer_free(&timer);
    EXPECT_EQ(ret, 0);

    vesync_sem_free(&g_sem);
}

TEST(timer_test, timer_start_reload)
{
    int ret = 0;
    vesync_timer_t timer;
    long timeout = 500;
    test_arg_t arg;
    arg.count = 0;
    snprintf(arg.msg, sizeof(arg.msg), "%s", "timer_start_cycle test msg");

    ret = vesync_sem_new(&g_sem);
    EXPECT_EQ(ret, 0);

    ret = vesync_timer_new(&timer, "test_timer", timeout_cb, &arg, timeout, 1);
    EXPECT_EQ(ret, 0);

    ret = vesync_timer_start(&timer);
    EXPECT_EQ(ret, 0);

    vesync_sem_wait(&g_sem, VESYNC_OS_WAIT_FOREVER);

    ret = vesync_timer_free(&timer);
    EXPECT_EQ(ret, 0);

    vesync_sem_free(&g_sem);
}

static void timeout_cb1(void* arg)
{
    test_arg_t *t_arg = (test_arg_t *)arg;
    t_arg->count++;
    printf("timeout_cb1 arg: count=%d, msg=%s\n", t_arg->count, t_arg->msg);
    if (t_arg->count > 3)
    {
        printf("timer stop failed\n");
    }
    vesync_sem_signal(&g_sem);
}

TEST(timer_test, timer_stop)
{
    int ret = 0;
    vesync_timer_t timer;
    long timeout = 500;
    test_arg_t arg;
    arg.count = 0;
    snprintf(arg.msg, sizeof(arg.msg), "%s", "timer_stop test msg");

    ret = vesync_sem_new(&g_sem);
    EXPECT_EQ(ret, 0);

    ret = vesync_timer_new(&timer, "test_timer", timeout_cb1, &arg, timeout, 1);
    EXPECT_EQ(ret, 0);

    ret = vesync_timer_start(&timer);
    EXPECT_EQ(ret, 0);

    while (arg.count < 5)
    {
        vesync_sem_wait(&g_sem, VESYNC_OS_WAIT_FOREVER);
        if (arg.count == 3)
        {
            ret = vesync_timer_stop(&timer);
            EXPECT_EQ(ret, 0);
            arg.count = 0;
            break;
        }
    }

    while (arg.count < 1)
    {
        ret = vesync_timer_start(&timer);
        EXPECT_EQ(ret, 0);
        vesync_sem_wait(&g_sem, VESYNC_OS_WAIT_FOREVER);
    }

    ret = vesync_timer_free(&timer);
    EXPECT_EQ(ret, 0);

    vesync_sem_free(&g_sem);
}


