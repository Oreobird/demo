/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_bypass_common.c
 * @brief       bypass处理接口
 * @date        2021-05-14
 */

#include <string.h>
#include <stdio.h>

#include "vhal_utils.h"
#include "vesync_cfg_internal.h"
#include "vesync_common.h"
#include "vesync_log_internal.h"
#include "vesync_bypass_internal.h"
#include "vesync_report_internal.h"
#include "vesync_device_internal.h"
#if CONFIG_VESYNC_SDK_PRODUCTION_ENABLE
#include "vesync_production_internal.h"
#endif
#if CONFIG_VESYNC_SDK_NETCFG_ENABLE
#include "vesync_netcfg.h"
#endif
#if CONFIG_VESYNC_SDK_FFS_ENABLE
#include "vesync_ffs_internal.h"
#endif
#if CONFIG_VESYNC_SDK_DEVELOPER_ENABLE
#include "vesync_developer_internal.h"
#endif


/**
 * @brief "setTcpDebug" method数据解析，开启/关闭开发者模式
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  json                     [json数据指针]
 * @return BYPASS_ERR_E                 [错误码]
 */
static BYPASS_ERR_E bypass_method_set_developer_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    int ret = SDK_FAIL;
    BYPASS_ERR_E by_ret = BP_OK;
    bool enable = false;
    cJSON *json_data = NULL;
    dbg_cfg_t dbgcfg;

    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    json_data = cJSON_GetObjectItemCaseSensitive(json, "enabled");
    if (cJSON_IsBool(json_data))
    {
        enable = json_data->valueint;
    }
    else
    {
        by_ret = BP_ERR_ARG;
    }

    // 读取flash中的标志位，并和当前设置进行比较，不相同则更新flash中的数据
    memset((void *)&dbgcfg, 0, sizeof(dbgcfg));
    vesync_developer_flash_read_dbg_cfg(&dbgcfg);

    //SDK_LOG(LOG_DEBUG, "enable_developer = 0x%x, enable = 0x%x\n", dbgcfg.enable_developer, enable);
    if (dbgcfg.enable_developer != enable)
    {
        dbgcfg.enable_developer = enable;
        ret = vesync_developer_flash_update_dbg_cfg(&dbgcfg, DBG_CFG_CHANGE_DEVELOPER_FLAG);
        if (SDK_OK != ret)
        {
            SDK_LOG(LOG_ERROR, "Update dbg config fail!\n");
            vesync_bypass_reply_noqos(BP_ERR_CMD_EXECUTE_FAIL, p_msg_ctx->p_trace_msg, NULL);
            by_ret = BP_ERROR;
        }
        else if (enable)
        {
            vesync_developer_start();       // 开启tcp调试口
        }
    }

    if (BP_OK == by_ret)
    {
        vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, NULL);
    }

    return by_ret;
}


/**
 * @brief "setLogLevel" method数据解析
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  json                     [json数据指针]
 * @return BYPASS_ERR_E                 [错误码]
 */
static BYPASS_ERR_E bypass_method_set_log_level(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    uint8_t change = 0;
    dbg_cfg_t dbg_cfg;
    cJSON *log_lvl = NULL;
    cJSON *log_raw_lvl = NULL;

    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    memset((uint8_t *)&dbg_cfg, 0, sizeof(dbg_cfg_t));

    log_lvl = cJSON_GetObjectItemCaseSensitive(json, "logLevel");
    if (cJSON_IsString(log_lvl))
    {
        if (strcmp(log_lvl->valuestring, "OFF") == 0)
        {
            dbg_cfg.log_level = LOG_DISABLE;
        }
        else if (strcmp(log_lvl->valuestring, "ALL") == 0 || strcmp(log_lvl->valuestring, "DEBUG") == 0)
        {
            dbg_cfg.log_level = LOG_DEBUG;
        }
        else if (strcmp(log_lvl->valuestring, "INFO") == 0)
        {
            dbg_cfg.log_level = LOG_INFO;
        }
        else if (strcmp(log_lvl->valuestring, "WARN") == 0)
        {
            dbg_cfg.log_level = LOG_WARN;
        }
        else if (strcmp(log_lvl->valuestring, "ERROR") == 0)
        {
            dbg_cfg.log_level = LOG_ERROR;
        }
        else
        {
            vesync_bypass_reply_pkg_err_msg(BP_ERR_PARA_ILLEGAL, p_msg_ctx->p_trace_msg, "logLevel is invaild!");
            return BP_ERROR;
        }
        change |= DBG_CFG_CHANGE_LOG_LVL_FLAG;
    }

    log_raw_lvl = cJSON_GetObjectItemCaseSensitive(json, "logRawLevel");
    if (cJSON_IsString(log_raw_lvl))
    {
        if (strcmp(log_raw_lvl->valuestring, "OFF") == 0)
        {
            dbg_cfg.log_raw_level = LOG_DISABLE;
        }
        else if (strcmp(log_raw_lvl->valuestring, "ALL") == 0 || strcmp(log_raw_lvl->valuestring, "DEBUG") == 0)
        {
            dbg_cfg.log_raw_level = LOG_DEBUG;
        }
        else if (strcmp(log_raw_lvl->valuestring, "INFO") == 0)
        {
            dbg_cfg.log_raw_level = LOG_INFO;
        }
        else if (strcmp(log_raw_lvl->valuestring, "WARN") == 0)
        {
            dbg_cfg.log_raw_level = LOG_WARN;
        }
        else if (strcmp(log_raw_lvl->valuestring, "ERROR") == 0)
        {
            dbg_cfg.log_raw_level = LOG_ERROR;
        }
        else
        {
            vesync_bypass_reply_pkg_err_msg(BP_ERR_PARA_ILLEGAL, p_msg_ctx->p_trace_msg, "logRawLevel is invaild!");
            return BP_ERROR;
        }

        change |= DBG_CFG_CHANGE_LOG_RAW_LVL_FLAG;
    }

    if (change > 0)
    {
        vesync_developer_flash_update_dbg_cfg(&dbg_cfg, change);
    }

    vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, NULL);

    return BP_OK;
}

#if defined(PR_FW_TYPE) && (PR_FW_TYPE == 0)
/**
 * @brief "set timestamp" method数据解析
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  json                     [json数据指针]
 * @return BYPASS_ERR_E                 [错误码]
 */
static BYPASS_ERR_E bypass_method_set_timestamp(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    BYPASS_ERR_E by_ret = BP_OK;
    uint32_t ts = 0;
    bool ts_update_flag = false;

    cJSON *json_ts = cJSON_GetObjectItemCaseSensitive(json, "ts");
    if (cJSON_IsNumber(json_ts))
    {
        ts = json_ts->valueint;
        SDK_LOG(LOG_DEBUG,"ts = %d.\n", ts);
    }
    else
    {
        by_ret = BP_ERR_ARG;
        goto exit;
    }

    cJSON *json_flag = cJSON_GetObjectItemCaseSensitive(json, "disable");
    if (cJSON_IsBool(json_flag))
    {
        ts_update_flag = json_flag->valueint;
        SDK_LOG(LOG_DEBUG,"disable ts update flag = %d.\n", ts_update_flag);
    }
    else
    {
        by_ret = BP_ERR_ARG;
        goto exit;
    }

    vesync_device_set_ts_update_status(ts, ts_update_flag);

exit:
    if (BP_OK == by_ret)
        vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, NULL);
    else
        vesync_bypass_reply_noqos(BP_ERR_PARA_ILLEGAL, p_msg_ctx->p_trace_msg, NULL);

    return by_ret;
}


/**
 * @brief 修改设备的MAC地址
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  json                     [json数据指针]
 * @return BYPASS_ERR_E                 [错误码]
 */
static BYPASS_ERR_E bypass_method_set_mac_addr(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    int ret = -1;
    BYPASS_ERR_E bp_ret = BP_ERROR;
    char mac[MAC_ADDR_HEX_LEN] = {0};
    char type[8] = {0};
    cJSON *json_data = NULL;

    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

    json_data = cJSON_GetObjectItemCaseSensitive(json, "type");
    if (cJSON_IsString(json_data))
    {
        snprintf(type, sizeof(type), "%s", json_data->valuestring);
    }
    else
    {
        bp_ret = BP_ERR_ARG;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "mac");
    if (cJSON_IsString(json_data))
    {
        snprintf(mac, sizeof(mac), "%s", json_data->valuestring);

        if (0 == strcmp(type, "Wi-Fi"))
        {
            ret = vhal_utils_set_wifi_mac(mac);
        }
#if defined(CONFIG_VESYNC_HAL_BLE_ENABLE) && CONFIG_VESYNC_HAL_BLE_ENABLE
        else if (0 == strcmp(type, "BLE"))
        {
            //ret = vhal_utils_set_ble_mac(mac);
        }
#endif
        else
        {
            bp_ret = BP_ERR_ARG;
        }

        if (VHAL_OK != ret)
        {
            vesync_bypass_reply_pkg_err_msg(BP_ERR_ARG, p_msg_ctx->p_trace_msg, "Set MAC error");
            //bp_ret = BP_ERROR;
        }
        else
        {
            vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, NULL);
            bp_ret = BP_OK;
        }
    }
    else
    {
        bp_ret = BP_ERR_ARG;
    }


    return bp_ret;
}

/**
 * @brief "debug cmd" method数据解析
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  json                     [json数据指针]
 * @return BYPASS_ERR_E                 [错误码]
 */
static BYPASS_ERR_E bypass_method_debug_cmd(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    BYPASS_ERR_E by_ret = BP_OK;
    bool test_fail_flag;

    VCOM_NULL_PARAM_CHK(json, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx, return BP_ERROR);
    VCOM_NULL_PARAM_CHK(p_msg_ctx->p_trace_msg, return BP_ERROR);

#if CONFIG_VESYNC_SDK_PRODUCTION_ENABLE
    cJSON *json_cmd = cJSON_GetObjectItemCaseSensitive(json, "productionTest");
    if (cJSON_IsString(json_cmd))
    {
        if (strcmp(json_cmd->valuestring, "exit") == 0)
        {
            test_fail_flag = false;
            vesync_production_set_value_by_key(PRODUCTION_KEY_ID_TEST_FAIL_FLAG,(uint8_t *)&test_fail_flag,sizeof(test_fail_flag));
        }
#if defined(PR_FW_TYPE) && (PR_FW_TYPE == 0)    // release固件不允许通过该命令进入产测
        else if (strcmp(json_cmd->valuestring, "repeat") == 0)
        {
            test_fail_flag = true;
            vesync_production_set_value_by_key(PRODUCTION_KEY_ID_TEST_FAIL_FLAG,(uint8_t *)&test_fail_flag,sizeof(test_fail_flag));
        }
#endif
        else
        {
            by_ret = BP_ERR_ARG;
        }
    }
#endif /* CONFIG_VESYNC_SDK_PRODUCTION_ENABLE */

    cJSON *json_data = cJSON_GetObjectItemCaseSensitive(json, "cid");
    if (cJSON_IsString(json_data))
    {

#if defined(PR_FW_TYPE) && (PR_FW_TYPE == 0)
        SDK_LOG(LOG_DEBUG,"set cid = %s \r\n", json_data->valuestring);
        // release固件不允许通过该命令修改cid
        if(SDK_OK != vesync_production_set_value_by_key(PRODUCTION_KEY_ID_CID,(uint8_t*)json_data->valuestring,strlen(json_data->valuestring)))
        {
            by_ret = BP_ERR_ARG;
        }
#else
        SDK_LOG(LOG_DEBUG,"Release FW not support!!\n");
#endif
    }

#if CONFIG_VESYNC_SDK_NETCFG_ENABLE
    json_data = cJSON_GetObjectItemCaseSensitive(json, "netconfig");
    if (cJSON_IsString(json_data))
    {
         if ((strcmp(json_data->valuestring, "ble") == 0)||(strcmp(json_data->valuestring, "ap") == 0))
         {
            vesync_netcfg_start();
         }
#if CONFIG_VESYNC_SDK_FFS_ENABLE
         else if (strcmp(json_data->valuestring, "ffs") == 0)
         {
            vesync_ffs_result_clean();
         }
#endif
    }
#endif /* CONFIG_VESYNC_SDK_NETCFG_ENABLE */

    if (BP_OK == by_ret)
        vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, NULL);

    return by_ret;
}

#endif

static bypass_item_data_t developer_method_tbl[] = {
    {BP_AUTH_MSG_FROM_MQTT, BYPASS_METHOD_ID_SET_DEVELOPER,            "setDeveloper",          bypass_method_set_developer_handle, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_SET_LOG_LEVEL,      "setLogLevel",           bypass_method_set_log_level, NULL},
#if defined(PR_FW_TYPE) && (PR_FW_TYPE == 0)
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_SET_TS,             "setTimestamp",          bypass_method_set_timestamp, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_SET_MAC,            "setMacAddr",            bypass_method_set_mac_addr, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_DEBUG_CMD,          "softDebugCmd",          bypass_method_debug_cmd, NULL},
#endif
};


void vesync_bypass_developer_init(void)
{
    for (int i = 0; i < SIZEOF_ARRAY(developer_method_tbl); i++)
    {
        bypass_item_t *item = vesync_bypass_init_item(&developer_method_tbl[i]);
        if (item != NULL)
        {
            vesync_bypass_add_item(item);
        }
    }
}

