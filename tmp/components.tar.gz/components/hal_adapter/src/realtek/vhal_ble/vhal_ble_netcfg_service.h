/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file    vhal_ble_netcfg_service.h
 * @brief   蓝牙hal配网通信服务
 * @date    2021-09-03
 */

#ifndef __VHAL_BLE_NETCFG_SERVICE_H__
#define __VHAL_BLE_NETCFG_SERVICE_H__

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C"
{
#endif

#define GATTS_SERVICE_NET_CFG_UUID            {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xB0, 0x00, 0x40, 0x51, 0x04, 0xE0, 0xFF, 0x00, 0xF0}
#define GATTS_CHAR_NET_CFG_WRITE_UUID         {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xB0, 0x00, 0x40, 0x51, 0x04, 0xE1, 0xFF, 0x00, 0xF0}
#define GATTS_CHAR_NET_CFG_NOTIFY_UUID        {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xB0, 0x00, 0x40, 0x51, 0x04, 0xE2, 0xFF, 0x00, 0xF0}

/**
 * @brief 设备配网服务属性index
 */
typedef enum{
    IDX_NETCFG_SVC = 0,
    IDX_CHAR_NETCFG_NOTIFY,
    IDX_CHAR_VAL_NETCFG_NOTIFY,
    IDX_CHAR_CCCD_NETCFG_NOTIFY,
    IDX_CHAR_NETCFG_WRITE,
    IDX_CHAR_VAL_NETCFG_WRITE,
    IDX_NETCFG_NB
}BLE_NETCFG_SERVICE_IDX_E;

/**
 * @brief 配网服务添加
 * @param[in] p_func        [配网服务回调]
 * @return bool             [true表示成功,false表示失败]
 */
bool vhal_ble_net_cfg_service_add(void *p_func);

/**
 * @brief 发送通知
 * @param[in] conn_id       [连接id]
 * @param[in] p_value       [发送数据指针]
 * @param[in] length        [发送数据长度]
 * @return bool             [true表示成功,false表示失败]
 */
bool vhal_ble_net_cfg_service_notify(uint8_t conn_id, uint8_t *p_value, uint16_t length);

#ifdef __cplusplus
}
#endif

#endif  /* __VHAL_BLE_NETCFG_SERVICE_H__ */
