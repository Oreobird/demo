/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        switch_uart_handle.c
 * @brief       switch串口数据处理
 * @author      Charles.Mei
 * @date        2021-08-03
 */


#include <string.h>
#include <stdint.h>

#include "vesync_common.h"
#include "vesync_log.h"
#include "vesync_klv.h"
#include "vesync_netcfg.h"
#include "vesync_device.h"

#include "switch.h"
#include "switch_uart_cmd.h"
#include "switch_uart_handle.h"

/**
 * @brief 设置WiFi进入配网
 *
 */
typedef enum
{
    NET_CFG_INDICATOR   = 0X01,       // 进入配网灯效指示
    NET_CFG_START       = 0X02,       // 进入配网
} NET_CFG_STATE_E;

/**
 * @brief 设置WiFi恢复出厂
 *
 */
typedef enum
{
    RESET_FACTORY   = 0X00,         // 恢复出厂，清除所有数据
} RESET_WIFI_RANK_E;

/**
 * @brief 设置WiFi进入产测
 *
 */
typedef enum
{
    WIFI_TEST_PRODUCTION   = 0X01,         // 进入产测
} WIFI_TEST_MODE_E;


/**
 * @brief  回复ack
 * @return     int                      [成功/失败]
 */
static int switch_uart_send_ack(uint32_t opcode, uint8_t status_code)
{
    uart_msg_send_t msg;

    memset(&msg, 0, sizeof(msg));
    msg.type = UART_MSG_TYPE_ACK;
    msg.status_code = status_code;
    msg.opcode = opcode;
    if (SDK_OK != vesync_uart_send(SWITCH_UART_NUM, &msg))
    {
        return APP_FAIL;
    }
    return APP_OK;
}


// 上报设备状态和查询设备状态的ack，两者payload组织完全相同，共用key
#define OP_REPORT_OR_OP_REPORT_ACK_KEY_MCU_FW_VERSION       (0x01U)
#define OP_REPORT_OR_OP_REPORT_ACK_KEY_MCU_SW_VERSION       (0x02U)
#define OP_REPORT_OR_OP_REPORT_ACK_KEY_LIGHT_ONOFF          (0x03U)
#define OP_REPORT_OR_OP_REPORT_ACK_KEY_LIGHT_LEVEL          (0x04U)
#define OP_REPORT_OR_OP_REPORT_ACK_KEY_LIGHT_LIGHTNESS      (0x05U)
#define OP_REPORT_OR_OP_REPORT_ACK_KEY_FAN_ONOFF            (0x06U)
#define OP_REPORT_OR_OP_REPORT_ACK_KEY_FAN_LEVEL            (0x07U)
#define OP_REPORT_OR_OP_REPORT_ACK_KEY_LIGHT_MODE           (0x08U)
#define OP_REPORT_OR_OP_REPORT_ACK_KEY_LIGHT_MIN_LIGHTNESS  (0x09U)
#define OP_REPORT_OR_OP_REPORT_ACK_KEY_SWITCH_CTR_DEVICE    (0x0AU)

/**
 * @brief  更新设备状态
 * @return     uint8_t                  [status，见串口协议附录B状态码表说明]
 */
static uint8_t switch_uart_handle_status(uint8_t* p_data, uint16_t data_len)
{
    int ret = SDK_FAIL;
    switch_status_t new_status;

    memset(&new_status, 0, sizeof(new_status));

    ret = vesync_klv_get(p_data, data_len, OP_REPORT_OR_OP_REPORT_ACK_KEY_MCU_FW_VERSION,
        sizeof(new_status.mcu_fw_ver), new_status.mcu_fw_ver);
    if (SDK_OK != ret)
    {
        goto exit;
    }
    ret = vesync_klv_get(p_data, data_len, OP_REPORT_OR_OP_REPORT_ACK_KEY_MCU_SW_VERSION,
        sizeof(new_status.mcu_sw_ver), new_status.mcu_sw_ver);
    if (SDK_OK != ret)
    {
        goto exit;
    }
    ret = vesync_klv_get(p_data, data_len, OP_REPORT_OR_OP_REPORT_ACK_KEY_LIGHT_ONOFF,
        sizeof(uint8_t), (uint8_t*)&new_status.light.onoff);
    if (SDK_OK != ret)
    {
        goto exit;
    }
    ret = vesync_klv_get(p_data, data_len, OP_REPORT_OR_OP_REPORT_ACK_KEY_LIGHT_LEVEL,
        sizeof(new_status.light.level), (uint8_t*)&new_status.light.level);
    if (SDK_OK != ret)
    {
        goto exit;
    }
    ret = vesync_klv_get(p_data, data_len, OP_REPORT_OR_OP_REPORT_ACK_KEY_LIGHT_LIGHTNESS,
        sizeof(new_status.light.uart_lightness), (uint8_t*)&new_status.light.uart_lightness);
    if (SDK_OK != ret)
    {
        goto exit;
    }
    ret = vesync_klv_get(p_data, data_len, OP_REPORT_OR_OP_REPORT_ACK_KEY_FAN_ONOFF,
        sizeof(uint8_t), (uint8_t*)&new_status.fan.onoff);
    if (SDK_OK != ret)
    {
        goto exit;
    }
    ret = vesync_klv_get(p_data, data_len, OP_REPORT_OR_OP_REPORT_ACK_KEY_FAN_LEVEL,
        sizeof(new_status.fan.level), &new_status.fan.level);
    if (SDK_OK != ret)
    {
        goto exit;
    }
    ret = vesync_klv_get(p_data, data_len, OP_REPORT_OR_OP_REPORT_ACK_KEY_LIGHT_MODE,
        sizeof(new_status.light.light_mode), &new_status.light.light_mode);
    if (SDK_OK != ret)
    {
        goto exit;
    }
    ret = vesync_klv_get(p_data, data_len, OP_REPORT_OR_OP_REPORT_ACK_KEY_LIGHT_MIN_LIGHTNESS,
        sizeof(new_status.light.min_lightness), (uint8_t*)&new_status.light.min_lightness);
    if (SDK_OK != ret)
    {
        goto exit;
    }
    ret = vesync_klv_get(p_data, data_len, OP_REPORT_OR_OP_REPORT_ACK_KEY_LIGHT_MIN_LIGHTNESS,
        sizeof(uint8_t), (uint8_t*)&new_status.cur_id);
    if (SDK_OK != ret)
    {
        goto exit;
    }

#if 0
    APP_LOG(LOG_DEBUG, "light switch : %d\n", new_status.light.onoff);
    APP_LOG(LOG_DEBUG, "light lightness : %d\n", new_status.light.uart_lightness);
    APP_LOG(LOG_DEBUG, "light level : %d\n", new_status.light.level);
    APP_LOG(LOG_DEBUG, "fan switch : %d\n", new_status.fan.onoff);
    APP_LOG(LOG_DEBUG, "fan level : %d\n", new_status.fan.level);
#endif
    switch_app_update_status(&new_status);
    return UART_PAYLOAD_STATUS_NO_ERR;

exit:
    return UART_PAYLOAD_STATUS_PAYLOAD_FORMAT_ERR;
}


#define OP_ENTER_NETCFG_KEY_NETCFG_STATE       (0x01U)

/**
 * @brief  设置Wi-Fi进入配网
 * @return     uint8_t                  [status，见串口协议附录B状态码表说明]
 */
static uint8_t switch_uart_set_wifi_net_cfg(uint8_t* p_data, uint16_t data_len)
{
    int ret = SDK_FAIL;
    uint8_t netcfg_state;

    ret = vesync_klv_get(p_data, data_len, OP_ENTER_NETCFG_KEY_NETCFG_STATE,
        sizeof(netcfg_state), &netcfg_state);
    if (SDK_OK != ret)
    {
        switch_uart_send_ack(OP_ENTER_NETCFG, UART_PAYLOAD_STATUS_PAYLOAD_FORMAT_ERR);
        return UART_PAYLOAD_STATUS_PAYLOAD_FORMAT_ERR;
    }
    switch ((NET_CFG_STATE_E)netcfg_state)
    {
        case NET_CFG_INDICATOR:
            switch_uart_send_ack(OP_ENTER_NETCFG, UART_PAYLOAD_STATUS_NO_ERR);
            vesync_wifi_led_set_behavior(WIFI_LED_NOT_CONFIG);
            break;
        case NET_CFG_START:
            switch_uart_send_ack(OP_ENTER_NETCFG, UART_PAYLOAD_STATUS_NO_ERR);
            vesync_netcfg_start();
            break;
        default:
            switch_uart_send_ack(OP_ENTER_NETCFG, UART_PAYLOAD_STATUS_PAYLOAD_FORMAT_ERR);
            return UART_PAYLOAD_STATUS_PAYLOAD_FORMAT_ERR;
    }

    return UART_PAYLOAD_STATUS_NO_ERR;
}

/**
 * @brief  设置Wi-Fi恢复出厂设置
 * @return     uint8_t                  [status，见串口协议附录B状态码表说明]
 */
static uint8_t switch_uart_reset_wifi(uint8_t* p_data, uint16_t data_len)
{
    int ret = SDK_FAIL;
    uint8_t reset_rank;

    ret = vesync_klv_get(p_data, data_len, OP_ENTER_NETCFG_KEY_NETCFG_STATE,
        sizeof(reset_rank), &reset_rank);
    if (SDK_OK != ret)
    {
        switch_uart_send_ack(OP_REST_WIFI, UART_PAYLOAD_STATUS_PAYLOAD_FORMAT_ERR);
        return UART_PAYLOAD_STATUS_PAYLOAD_FORMAT_ERR;
    }
    switch ((RESET_WIFI_RANK_E)reset_rank)
    {
        case RESET_FACTORY:
            switch_uart_send_ack(OP_REST_WIFI, UART_PAYLOAD_STATUS_NO_ERR);
            vesync_device_factory_reset(true, STAT_CHG_RSN_NONE_STR);
            break;
        default:
            switch_uart_send_ack(OP_REST_WIFI, UART_PAYLOAD_STATUS_PAYLOAD_FORMAT_ERR);
            return UART_PAYLOAD_STATUS_PAYLOAD_FORMAT_ERR;
    }

    return UART_PAYLOAD_STATUS_NO_ERR;
}

/**
 * @brief  设置Wi-Fi进入产测
 * @return     uint8_t                  [status，见串口协议附录B状态码表说明]
 */
static uint8_t switch_uart_test_wifi(uint8_t* p_data, uint16_t data_len)
{
    int ret = SDK_FAIL;
    uint8_t test_mode;

    ret = vesync_klv_get(p_data, data_len, OP_ENTER_NETCFG_KEY_NETCFG_STATE,
        sizeof(test_mode), &test_mode);
    if (SDK_OK != ret)
    {
        switch_uart_send_ack(OP_TEST_WIFI, UART_PAYLOAD_STATUS_PAYLOAD_FORMAT_ERR);
        return UART_PAYLOAD_STATUS_PAYLOAD_FORMAT_ERR;
    }
    switch ((WIFI_TEST_MODE_E)test_mode)
    {
        case WIFI_TEST_PRODUCTION:
            switch_uart_send_ack(OP_TEST_WIFI, UART_PAYLOAD_STATUS_NO_ERR);
            vesync_production_enter_testmode(true);;
            break;
        default:
            switch_uart_send_ack(OP_TEST_WIFI, UART_PAYLOAD_STATUS_PAYLOAD_FORMAT_ERR);
            return UART_PAYLOAD_STATUS_PAYLOAD_FORMAT_ERR;
    }

    return UART_PAYLOAD_STATUS_NO_ERR;
}

/**
 * @brief  处理串口请求
 * @return     uint8_t                  [status，见串口协议附录B状态码表说明]
 */
uint8_t switch_uart_request_handle(OPCODE_E opcode, uint8_t* p_data, uint16_t data_len)
{
    uint8_t status_code;

    switch (opcode)
    {
        case OP_REPORT:
            status_code = switch_uart_handle_status(p_data, data_len);
            switch_uart_send_ack(opcode, status_code);
            return status_code;
        case OP_ENTER_NETCFG:
            return switch_uart_set_wifi_net_cfg(p_data, data_len);
        case OP_REST_WIFI:
            return switch_uart_reset_wifi(p_data, data_len);
        case OP_TEST_WIFI:
            return switch_uart_test_wifi(p_data, data_len);
        default:
            switch_uart_send_ack(opcode, UART_PAYLOAD_STATUS_OPCODE_UNSUPPORT);
            return UART_PAYLOAD_STATUS_OPCODE_UNSUPPORT;
    }
}

/**
 * @brief  处理串口ack
 * @return     uint8_t                  [status，见串口协议附录B状态码表说明]
 */
uint8_t switch_uart_ack_handle(OPCODE_E opcode, uint8_t* p_data, uint16_t data_len)
{
    if (NULL == p_data || 0 == data_len)
    {
        return UART_PAYLOAD_STATUS_PAYLOAD_FORMAT_ERR;
    }

    switch (opcode)
    {
        case OP_INQUIRY:
            return switch_uart_handle_status(p_data, data_len);
        case OP_SET_MIN_LIGHTNESS:
        case OP_TEST_LIGHT:
        case OP_SET_LIGHT_MOD:
        case OP_SET_SWITCH:
        case OP_SET_LEVEL:
        case OP_CTR_WIFI_LED:
        case OP_TEST_UART:
        case OP_REST_MCU:
        case OP_SET_PRODUCTION_STATE:
        case OP_SET_PRODUCTION_RESULT:
            return UART_PAYLOAD_STATUS_NO_ERR;
        default:
            return UART_PAYLOAD_STATUS_OPCODE_UNSUPPORT;
    }

    return UART_PAYLOAD_STATUS_OPCODE_UNSUPPORT;
}


