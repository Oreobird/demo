/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_https_internal.h
 * @brief       https提供给内部的接口
 * @author      CharlesMei
 * @date        2021-05-24
 */

#ifndef __VESYNC_HTTPS_INTERNAL_H__
#define __VESYNC_HTTPS_INTERNAL_H__


#include <stdint.h>
#include <stdbool.h>


#ifdef __cplusplus
extern "C"
{
#endif /* __cplusplus */


#define HTTPS_BUFFER_SIZE            (2*1024)    // https通信的数据交互缓存区大小
#define HTTPS_WAIT_TIME_MS           (12000)


/**
 * @brief  http请求的方法
 */
typedef enum
{
    HTTPS_METHOD_GET        = 0,
    HTTPS_METHOD_POST       = 1
} HTTPS_METHOD_TYPE_E;

/**
 * @brief  https配置结构体
 */
typedef struct
{
    char *url;           /* 完整的URL，如果为空，host必须设置 */
    char *host;          /* 服务器地址，如果为空，url必须设置 */
    char *path;          /* 文件路径，优先使用url中的文件路径，其次使用此文件路径，如果都为空，则默认为‘/’ */
    char *ca_pem;        /* 服务器证书 */
    char *client_pem;    /* client证书 */
    char *client_key;    /* client私钥 */
    bool keep_alive;     /* 是否使能长连接，true使能，false关闭；默认使能 */
    uint16_t port;       /* 端口号，优先使用url中的端口号，其次使用此端口号，如果都为空则使用默认端口号HTTP_DEFAULT_PORT */
    uint16_t timeout_ms; /* 网络超时时间，单位ms */
} vesync_https_cli_cfg_t;

/**
 * @brief  https客户端初始化
 * @param[in]  config        [初始化配置，详见vesync_https_client_config_t]
 * @return  int              [成功：SDK_OK，失败：SDK_FAIL]
 */
int vesync_https_cli_init(vesync_https_cli_cfg_t *config);

/**
 * @brief  https客户端连接服务
 * @return  int              [成功：SDK_OK，失败：SDK_FAIL]
 */
int vesync_https_cli_connect(void);

/**
 * @brief  https request
 * @param[in]  method        [请求的方法]
 * @param[in]  send_buf      [请求的数据内容]
 * @param[out]  recv_buf     [返回的数据内容缓存buffer]
 * @param[in,out]  recv_len  [返回的数据内容长度指针，传入时为缓存buffer的长度，供内部判断buffer大小是否足够，足够时内部把返回的数据拷贝至buffer，并赋值该值为数据长度]
 * @param[in]  keep_head     [返回的数据是否需要保留头部]
 * @return  int              [成功或失败]
 */
int vesync_https_request(HTTPS_METHOD_TYPE_E method, char *send_buf, char *recv_buf, int *recv_len, bool keep_head);

/**
 * @brief  https通知服务器关闭，并释放空间
 */
void vesync_https_cli_deinit(void);

/**
 * @brief 写token
 * @param[in]  char          [待写入的token]
 * @param[in]  int           [长度]
 * @return  int              [成功：SDK_OK，失败：SDK_FAIL]
 */
int vesync_https_flash_token_write(char *p_token, int buf_len);

/**
 * @brief 读token
 * @param[out]  p_token       [待读出的token]
 * @param[in,out]  len        [待读出的token长度]
 * @return  int               [成功：SDK_OK，失败：SDK_FAIL]
 */
int vesync_https_flash_token_read(char *p_token, uint32_t *len);

/**
 * @brief 清除token
 * @return  int               [成功：SDK_OK，失败：SDK_FAIL]
 */
int vesync_https_flash_token_clear(void);

#ifdef __cplusplus
}
#endif /* __cplusplus */


#endif /* __VESYNC_HTTPS_INTERNAL_H__ */

