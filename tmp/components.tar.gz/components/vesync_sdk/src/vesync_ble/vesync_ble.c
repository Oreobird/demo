/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_ble.c
 * @brief       BLE收发模块
 * @author      Louis
 * @date        2021-07-21
 */

#include <string.h>
#include <stdint.h>

#include "vhal_ble.h"
#include "vesync_task.h"
#include "vesync_sem.h"
#include "vesync_common.h"
#include "vesync_cfg_internal.h"
#include "vesync_log_internal.h"
#include "vesync_ble.h"
#include "vesync_ble_private.h"
#include "vesync_event_internal.h"

static bool s_vesync_ble_init = false;
static vesync_sem_t *s_vesync_ble_sem = NULL;

/**
 * @brief  蓝牙hal层事件回调函数
 * @param[in]  event            [BLE事件]
 */
static void hal_ble_evt_cb(VHAL_BLE_EVT_E event)
{
    vesync_ev_t ev = {0};

    switch (event)
    {
    case HB_EVT_INIT:
        SDK_LOG(LOG_INFO, "HB_EVT_INIT\n");
        break;
    case HB_EVT_INIT_COMPLETE:
        vhal_ble_advertising_start(); // 开启BLE广播
        SDK_LOG(LOG_INFO, "HB_EVT_INIT_COMPLETE\n");
        break;
    case HB_EVT_CONNECTED:
        SDK_LOG(LOG_INFO, "HB_EVT_CONNECTED\n");
        VESYNC_POPULATE_EV(ev, EVENT_BLE_CONNECTED, VESYNC_BLE_TASK_NAME, 0, NULL);
        vesync_event_publish(&ev);
        break;
    case HB_EVT_DISCONNECTED:
        SDK_LOG(LOG_INFO, "HB_EVT_DISCONNECTED\n");
        VESYNC_POPULATE_EV(ev, EVENT_BLE_DISCONNECTED, VESYNC_BLE_TASK_NAME, 0, NULL);
        vesync_event_publish(&ev);
        break;
    default:
        break;
    }
}

/**
 * @brief  vhal层蓝牙初始化
 * @return     uint32_t         [SDK_OK/SDK_FAIL]
 */
int32_t vesync_ble_up(void)
{
    int32_t err_code = 0;
    ble_adv_mfr_data_t mfr_data = {0};
    mfr_data.product_type = vesync_cfg_get_ble_type() & 0xFF;
    mfr_data.product_model = vesync_cfg_get_ble_model() & 0xFF;
    mfr_data.cmd_code = vesync_cfg_get_ble_cmd() & 0xFF;
    mfr_data.netcfg_ver = PR_BLE_NETCFG_VER & 0xFF;

    // 0x00已经被定义为未配网的标志；设置为0xFF的未初始化值，
    // 配网模块初始化后会更新这个值
    mfr_data.netcfg_status = 0xFF;
    mfr_data.ble_adv_work = BLE_ADV_WORK_NORMAL;

    vhal_ble_reg_evt_cb(hal_ble_evt_cb);

    err_code = vhal_ble_init(vesync_cfg_get_ble_name(), vesync_cfg_get_fw_version(), mfr_data);
    if (0 != err_code)
    {
        SDK_LOG(LOG_ERROR, "err: %d\n", err_code);
        return SDK_FAIL;
    }

    return SDK_OK;
}

/**
 * @brief  BLE收发任务退出后的清理
 */
static void vesync_ble_deinit(void)
{
    return;
}

/**
 * @brief   BLE收发任务
 */
static void vesync_ble_task(void *args)
{
    while (1)
    {
        if (VOS_OK != vesync_sem_wait(s_vesync_ble_sem, vesync_ble_process_expired_timer()))
        {
            continue;   // vesync_sem_wait未等到信号量退出，需要处理定时器vesync_ble_process_expired_timer
        }

        // 等到信号量，开始处理收发包
        vesync_ble_parse_recv_data();
        vesync_ble_parse_send_data();
    }
}

/**
 * @brief  BLE模块初始化
 * @return int32_t          [SDK_OK/SDK_FAIL]
 */
int32_t vesync_ble_init(void)
{
    int32_t ret = SDK_OK;

    if (true == s_vesync_ble_init)
    {
        return SDK_OK;
    }

    // 蓝牙初始化
    if (SDK_OK != vesync_ble_up())
    {
        ret = SDK_FAIL;
        goto EXIT;
    }

    // 该信号量用于通知收发任务开始处理队列中的包
    s_vesync_ble_sem = vesync_sem_binary_new();
    if (NULL == s_vesync_ble_sem)
    {
        ret = SDK_FAIL;
        goto EXIT;
    }

    // BLE收包模块初始化
    if (SDK_OK != vesync_ble_recv_init())
    {
        ret = SDK_FAIL;
        goto EXIT;
    }

    // BLE发包模块初始化
    if (SDK_OK != vesync_ble_send_init())
    {
        ret = SDK_FAIL;
        goto EXIT;
    }

    // 创建BLE收发任务
    if (VOS_OK != vesync_task_new(VESYNC_BLE_TASK_NAME,
                                  vesync_ble_deinit,
                                  vesync_ble_task,
                                  NULL,
                                  VESYNC_BLE_TASK_STACSIZE,
                                  VESYNC_BLE_TASK_PRIO,
                                  NULL))
    {
        SDK_LOG(LOG_ERROR, "Create task fail!\r\n");
        ret = SDK_FAIL;
        goto EXIT;
    }

    if (SDK_OK != vesync_ble_muxer_init())
    {
        ret = SDK_FAIL;
        goto EXIT;
    }
    // 把蓝牙命令通道的数据回调给复用器处理
    vesync_ble_reg_cmd_recv_cb(vesync_ble_muxer_rx_cb);

EXIT:
    if (SDK_FAIL == ret)
    {
        vesync_ble_recv_deinit();
        vesync_ble_send_deinit();
        if (NULL != s_vesync_ble_sem)
        {
            vesync_sem_free(s_vesync_ble_sem);
        }
    }
    else
    {
        SDK_LOG(LOG_INFO, "init success\n");
        s_vesync_ble_init = true;
    }

    return ret;
}

/**
 * @brief  BLE收发模块是否已经初始化
 * @return     bool             [true/false]
 */
bool vesync_ble_is_init(void)
{
    return s_vesync_ble_init;
}

/**
 * @brief  释放信号量，通知收发任务处理
 * @return     int32_t          [SDK_OK/SDK_FAIL]
 */
int32_t vesync_ble_sem_signal(void)
{
    return (VOS_OK == vesync_sem_signal(s_vesync_ble_sem)) ? SDK_OK : SDK_FAIL;
}

/**
 * @brief  断开当前蓝牙连接
 * @return     int32_t          [SDK_OK/SDK_FAIL]
 */
int32_t vesync_ble_disconnect(void)
{
    return (VHAL_OK == vhal_ble_disconnect()) ? SDK_OK : SDK_FAIL;
}

/**
 * @brief  更新配网状态到BLE广播
 * @param[in]  status_info      [配网状态]
 * @return     int32_t          [SDK_OK/SDK_FAIL]
 */
int32_t vesync_ble_adv_update_netcfg_status(uint8_t status_info)
{
    return (VHAL_OK == vhal_ble_set_adv_netcfg_status(status_info)) ? SDK_OK : SDK_FAIL;
}

/**
 * @brief  关闭蓝牙从机功能
 * @return     int32_t          [SDK_OK/SDK_FAIL]
 */
int32_t vesync_ble_disable(void)
{
    return (VHAL_OK == vhal_ble_disable()) ? SDK_OK : SDK_FAIL;
}
