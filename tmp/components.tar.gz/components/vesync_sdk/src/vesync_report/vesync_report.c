/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_report.c
 * @brief       SDK初始化接口
 * @author      Joshua
 * @date        2021-05-18
 */

#include <stdio.h>
#include <string.h>

#include "vhal_utils.h"
#include "vhal_wifi.h"
#if CONFIG_VESYNC_HAL_BLE_ENABLE
#include "vhal_ble.h"
#endif

#include "vesync_json_internal.h"
#include "vesync_common.h"
#include "vesync_memory.h"
#include "vesync_cfg_internal.h"
#include "vesync_log_internal.h"
#include "vesync_ota_internal.h"
#include "vesync_report_internal.h"
#include "vesync_event_internal.h"
#include "vesync_device_internal.h"

static report_mgt_t s_report_mgt;

/*-----------------------------------------------------------------------------*
 *                                 内部函数实现                          *
 *-----------------------------------------------------------------------------*/

/**
 * @brief 设备上报云基础接口
 * @param[in]   topic_type              [MQTT topic类型]
 * @param[in]   method                  [方法字段]
 * @param[in]   json_data               [json 格式的数据，填充到data对象]
 * @param[in]   cause                   [上报原因，目前只在中国区产品上使用]
 * @param[in]   qos                     [MQTT qos level]
 * @param[in]   puback_cb               [收到qos1 ack后的回调]
 * @return      int                     [成功/失败]
 */
static int report_cloud(NET_DATA_TOPIC_TYPE_E topic_type, const char *method, cJSON *json_data, REPORT_CAUSE_E cause, SEND_QOS_E qos, void* puback_cb)
{
    int ret = -1;
    char trace_id[MAX_TRACEID_LEN] = {0,};
    cJSON *p_msg = NULL;

    if (NULL == json_data)
    {
        SDK_LOG(LOG_ERROR, "arg error\n");
        return SDK_FAIL;
    }
    if (NULL == method)
    {
        SDK_LOG(LOG_ERROR, "arg error\n");
        cJSON_Delete(json_data);
        return SDK_FAIL;
    }

    // 获取traceid
    if (s_report_mgt.get_traceid)
    {
        s_report_mgt.get_traceid(trace_id, sizeof(trace_id));
    }

    // 加入头部
    if (s_report_mgt.json_add_method_head)
    {
        p_msg = s_report_mgt.json_add_method_head(trace_id, (char*)method, json_data, cause);
    }

    if (NULL == p_msg)
    {
        cJSON_Delete(json_data);
        return SDK_FAIL;
    }

    // 判断网络连接状态
    if (s_report_mgt.get_cloud_connect_status)
    {
        ret = s_report_mgt.get_cloud_connect_status();
        if (ret != NETWORK_ONLINE)
        {
            SDK_LOG(LOG_WARN, "cloud disconnect. state(%d)\n", ret);
            cJSON_Delete(p_msg);
            return SDK_FAIL;
        }
    }

    // 网络就绪才打印JSON调试信息
    vesync_json_print(p_msg);

    // 发送
    char* out = cJSON_PrintUnformatted(p_msg);
    if (s_report_mgt.send_to_cloud)
    {
        ret = s_report_mgt.send_to_cloud(topic_type, out, strlen(out), qos, puback_cb);
    }

    // 清理
    cJSON_Delete(p_msg);
    VCOM_SAFE_FREE(out);
    if (ret < 0)
    {
        SDK_LOG(LOG_ERROR, "Publish [%s] fail!!\n", method);
        return SDK_FAIL;
    }

    SDK_LOG(LOG_INFO, "Publish [%s] success.\n", method);
    return SDK_OK;
}

#if defined(PR_CMPT_RTOS) && (PR_CMPT_RTOS == 1)
/**
* @brief 为cjson格式的协议方法添加固定的接口头部 v2版本协议
* @param trace_id  [trace id]
* @param method    [接口方法名]
* @param p_data    [data json对线]
* @param cause     [上报原因]
* @return cJSON*   [添加了固定头部后的cjson格式数据，使用完后必须调用cJSON_Delete进行删除！！！]
*/
static cJSON *json_add_method_head(char *trace_id, char *method, cJSON *p_data, REPORT_CAUSE_E cause)
{
    cJSON *root = NULL;
    cJSON *context = NULL;

/* V2版本协议格式如下:
    {
        "context":{
            "traceId":"1567570774911",
            "method":"xxxx",
            "cid":"0LjTxllJv6sWOgGUWXt2wFYgWO5C5Q5T",
            "pid":"mockPid",
            "deviceRegion":"mockRegion"
        },
        "data":{
            "xxx1":"aaa",
            "xxx2":"bbb"
        }
    }
*/
    UNUSED(cause);

    root = cJSON_CreateObject();
    if(NULL == root)
    {
        SDK_LOG(LOG_ERROR, "Create root object fail\n");
        return NULL;
    }

    cJSON_AddItemToObject(root, "context", context = cJSON_CreateObject());
    if (NULL != context)
    {
        cJSON_AddStringToObject(context, "traceId", trace_id);  //==TODO==，需要修改成毫秒级
        cJSON_AddStringToObject(context, "method", method);
        cJSON_AddStringToObject(context, "pid", PR_PID);
        cJSON_AddStringToObject(context, "cid", vesync_device_get_cid());
        cJSON_AddStringToObject(context, "deviceRegion", vesync_cfg_get_country_code());
    }
    else
    { // context创建失败，相当于没有头部，失败返回
        SDK_LOG(LOG_ERROR, "Create context object fail\n");
        cJSON_Delete(root);
        return NULL;
    }

    if (NULL != p_data)
    {
        cJSON_AddItemToObject(root, "data", p_data);
    }

    return root;
}
#else
/**
* @brief 为cjson格式的协议方法添加固定的接口头部 v3版本协议
* @param trace_id  [trace id]
* @param method    [接口方法名]
* @param p_data    [data json对线]
* @param cause     [上报原因]
* @return cJSON*   [添加了固定头部后的cjson格式数据，使用完后必须调用cJSON_Delete进行删除！！！]
*/
static cJSON *json_add_method_head(char *trace_id, char *method, cJSON *p_data, REPORT_CAUSE_E cause)
{
    cJSON *root = NULL;
    cJSON *context = NULL;

/* V3版本协议格式如下:
    {
        "context": {
            "traceId": "",
            "method": "appointmentCanceledV3",
            "cid": "",
            "configModel": "xxx",
            "deviceRegion": "xx",
            "mainFwVersion": "xx.xx.xx",
            "cause": "onTime"
        },

        "data":{
            "xxx1":"aaa",
            "xxx2":"bbb"
        }
    }
*/
    root = cJSON_CreateObject();
    if (NULL == root)
    {
        SDK_LOG(LOG_ERROR, "Create root object fail\n");
        return NULL;
    }

    cJSON_AddItemToObject(root, "context", context = cJSON_CreateObject());
    if (NULL != context)
    {
        cJSON_AddStringToObject(context, "traceId", trace_id);  //==TODO==，需要修改成毫秒级
        cJSON_AddStringToObject(context, "method", method);
        cJSON_AddStringToObject(context, "configModel", vesync_cfg_get_config_model());
        cJSON_AddStringToObject(context, "cid", vesync_device_get_cid());
        cJSON_AddStringToObject(context, "deviceRegion", vesync_cfg_get_country_code());

        dev_fw_info_t firm_info;
        vesync_device_get_fw_info_by_type(UPG_TP_WIFI, &firm_info);
        cJSON_AddStringToObject(context, "mainFwVersion", firm_info.cur_firm_ver);
        cJSON_AddStringToObject(context, "cause", vesync_report_get_cause_str(cause));
    }
    else
    { // context创建失败，相当于没有头部，失败返回
        SDK_LOG(LOG_ERROR, "Create context object fail\n");
        cJSON_Delete(root);
        return NULL;
    }

    if (NULL != p_data)
    {
        //cJSON_AddItemReferenceToObject(root, p_data->string, p_data);
        cJSON_AddItemToObject(root, "data", p_data);
    }

    return root;
}
#endif

#if defined(PR_REPORT_PROTOCOL_VER) && (PR_REPORT_PROTOCOL_VER == 3)

/**
 * @brief 获取traceId
 * @param[out] p_traceID      [字符串形式的时间戳]
 * @param[in]  buf_len        [缓存空间大小]
 * @return     void           [无]
 */
static void get_traceid_v3(char *p_traceID, int buf_len)
{
    VCOM_NULL_PARAM_CHK(p_traceID, return);

    if (strlen(s_report_mgt.trace_id_head) == 0)
    {
        char mac_str[MAC_ADDR_STR_MAX_LEN] = {0,};
        if (VHAL_OK == vhal_utils_get_dev_mac(VHAL_MAC_WIFI_STA, mac_str, sizeof(mac_str)))
        {
            snprintf(s_report_mgt.trace_id_head, 16, "%s%c%c%c%c","DEV", mac_str[12], mac_str[13], mac_str[15], mac_str[16]);
        }
    }

    char timestamp_str[32] = {0};
    vhal_utils_get_system_time_ms_str(timestamp_str, 32);

    snprintf(p_traceID, buf_len, "%s%s-%05d", s_report_mgt.trace_id_head, timestamp_str, s_report_mgt.trace_id_count++);
}

/**
 * @brief 设备上报云v3基础接口
 * @param[in]   topic_type              [MQTT topic类型]
 * @param[in]   method                  [方法字段]
 * @param[in]   json_data               [json 格式的数据，填充到data对象]
 * @param[in]   cause                   [上报原因，目前只在中国区产品上使用]
 * @return      int                     [成功/失败]
 */
static int report_cloud_v3(NET_DATA_TOPIC_TYPE_E topic_type, const char *method, cJSON *json_data, REPORT_CAUSE_E cause)
{
    return report_cloud(topic_type, method, json_data, cause, SEND_QOS0, NULL);
}

/**
 * @brief 设备上报云v2基础接口
 * @param[in]   topic_type              [MQTT topic类型]
 * @param[in]   method                  [方法字段]
 * @param[in]   json_data               [json 格式的数据，填充到data对象]
 * @param[in]   cause                   [上报原因，目前只在中国区产品上使用]
 * @param[in]   qos                     [MQTT qos level]
 * @param[in]   puback_cb               [收到qos1 ack后的回调]
 * @return      int                     [成功/失败]
 */
static int report_cloud_qos_v3(NET_DATA_TOPIC_TYPE_E topic_type, const char *method,
                                    cJSON *json_data, REPORT_CAUSE_E cause, SEND_QOS_E qos, void* puback_cb)
{
    return report_cloud(topic_type, method, json_data, cause, qos, puback_cb);
}

#else

/**
 * @brief 获取traceId
 * @param[out] p_traceID      [字符串形式的时间戳]
 * @param[in]  buf_len        [缓存空间大小]
 * @return     void           [无]
 */
static void get_traceid_v2(char *p_traceID, int buf_len)
{
    vhal_utils_get_system_time_ms_str(p_traceID, buf_len);
}

/**
 * @brief 设备上报云v2基础接口
 * @param[in]   topic_type              [MQTT topic类型]
 * @param[in]   method                  [方法字段]
 * @param[in]   json_data               [json 格式的数据，填充到data对象]
 * @param[in]   cause                   [上报原因，目前只在中国区产品上使用]
 * @return      int                     [成功/失败]
 */
static int report_cloud_v2(NET_DATA_TOPIC_TYPE_E topic_type, const char *method, cJSON *json_data, REPORT_CAUSE_E cause)
{
    return report_cloud(topic_type, method, json_data, cause, SEND_QOS0, NULL);
}

/**
 * @brief 设备上报云v2基础接口
 * @param[in]   topic_type              [MQTT topic类型]
 * @param[in]   method                  [方法字段]
 * @param[in]   json_data               [json 格式的数据，填充到data对象]
 * @param[in]   cause                   [上报原因，目前只在中国区产品上使用]
 * @param[in]   qos                     [MQTT qos level]
 * @param[in]   puback_cb               [收到qos1 ack后的回调]
 * @return      int                     [成功/失败]
 */
static int report_cloud_qos_v2(NET_DATA_TOPIC_TYPE_E topic_type, const char *method,
                                    cJSON *json_data, REPORT_CAUSE_E cause, SEND_QOS_E qos, void* puback_cb)
{
    return report_cloud(topic_type, method, json_data, cause, qos, puback_cb);
}
#endif

/*-----------------------------------------------------------------------------*
 *                           外部函数API实现                                         *
 *-----------------------------------------------------------------------------*/

/**
 * @brief 返回设备上报原因的字符串
 * @param[in]  cause       [设备上报原因，详见enum声明]
 * @return     char*       [设备上报原因字符串形式]
 */
const char* vesync_report_get_cause_str(REPORT_CAUSE_E cause)
{
    switch (cause)
    {
        case CAUSE_CONNECT:
            return "onConn";
        case CAUSE_TIME:
            return "onTime";
        case CAUSE_CHANGE:
            return "onChange";
        case CAUSE_QUERY:
            return "onQuery";
        case CAUSE_LOG:
            return "onLog";
        default:
            return "None";
    }
}

/*
 * @brief  vesync report初始化
*/
void vesync_report_init(void)
{
    memset(&s_report_mgt, 0, sizeof(s_report_mgt));

#if defined(PR_REPORT_PROTOCOL_VER) && (PR_REPORT_PROTOCOL_VER == 3)
    memset(s_report_mgt.trace_id_head, 0, sizeof(s_report_mgt.trace_id_head));
    snprintf(s_report_mgt.methods.firm_up, sizeof(s_report_mgt.methods.firm_up), "reportFirmUpV3");
    snprintf(s_report_mgt.methods.reset_dev, sizeof(s_report_mgt.methods.reset_dev), "resetDeviceV3");
    snprintf(s_report_mgt.methods.update_dev_info, sizeof(s_report_mgt.methods.update_dev_info), "initDev");
    snprintf(s_report_mgt.methods.status_change, sizeof(s_report_mgt.methods.status_change), "statusChangeNtyV3");

    s_report_mgt.trace_id_count = 0;
    s_report_mgt.get_traceid = get_traceid_v3;
    s_report_mgt.report_cloud = report_cloud_v3;
    s_report_mgt.report_cloud_qos = report_cloud_qos_v3;
#else
    snprintf(s_report_mgt.methods.firm_up, sizeof(s_report_mgt.methods.firm_up), "reportFirmUpV2");
    snprintf(s_report_mgt.methods.reset_dev, sizeof(s_report_mgt.methods.reset_dev), "resetDeviceV2");
    snprintf(s_report_mgt.methods.update_dev_info, sizeof(s_report_mgt.methods.update_dev_info), "updateDevInfoV2");
    snprintf(s_report_mgt.methods.status_change, sizeof(s_report_mgt.methods.status_change), "statusChangeNtyV2");

    s_report_mgt.get_traceid = get_traceid_v2;
    s_report_mgt.report_cloud = report_cloud_v2;
    s_report_mgt.report_cloud_qos = report_cloud_qos_v2;
#endif

    s_report_mgt.json_add_method_head = json_add_method_head;
    s_report_mgt.get_reconn_data = vesync_net_mgmt_get_reconnect_data;
    s_report_mgt.save_reconn_reason = vesync_net_flash_write_reconnect_reason;
    s_report_mgt.get_reconn_reason_str = vesync_net_mgmt_get_reconnect_reason_str;
    s_report_mgt.clear_reconn_data = vesync_net_mgmt_clear_reconnect_data;

    s_report_mgt.get_cloud_connect_status = vesync_net_client_get_status;
    s_report_mgt.send_to_cloud = vesync_net_client_send;
#if CONFIG_VESYNC_SDK_PRODUCTION_ENABLE
    s_report_mgt.get_production_status = vesync_production_get_status;
#endif /* CONFIG_VESYNC_SDK_PRODUCTION_ENABLE */
}

/**
* @brief 设备上报云基础接口
* @param[in]   topic_type              [MQTT topic类型]
* @param[in]   method                  [方法字段]
* @param[in]   json_data               [json 格式的数据，填充到data对象]
* @param[in]   cause                   [上报原因]
* @return      int                     [成功/失败]
*/
int vesync_report_cloud(NET_DATA_TOPIC_TYPE_E topic_type, const char *method, cJSON *json_data, REPORT_CAUSE_E cause)
{
    VCOM_NULL_PARAM_CHK(method, return SDK_FAIL);
    VCOM_NULL_PARAM_CHK(json_data, return SDK_FAIL);
    if (s_report_mgt.report_cloud == NULL)
    {
        cJSON_Delete(json_data);
        return SDK_FAIL;
    }
    return s_report_mgt.report_cloud(topic_type, method, json_data, cause);
}

/**
* @brief 设备上报云基础接口
* @param[in]   topic_type              [MQTT topic类型]
* @param[in]   method                  [方法字段]
* @param[in]   json_data               [json 格式的数据，填充到data对象]
* @param[in]   cause                   [上报原因]
* @param[in]   qos                     [MQTT qos level]
* @param[in]   puback_cb               [收到qos1 ack后的回调]
* @return      int                     [成功/失败]
*/
int vesync_report_cloud_qos(NET_DATA_TOPIC_TYPE_E topic_type, const char *method, cJSON *json_data,
                            REPORT_CAUSE_E cause, SEND_QOS_E qos, void *puback_cb)
{
    VCOM_NULL_PARAM_CHK(method, return SDK_FAIL);
    VCOM_NULL_PARAM_CHK(json_data, return SDK_FAIL);
    if (s_report_mgt.report_cloud_qos == NULL)
    {
        cJSON_Delete(json_data);
        return SDK_FAIL;
    }
    return s_report_mgt.report_cloud_qos(topic_type, method, json_data, cause, qos, puback_cb);
}

/**
 * @brief 上报升级状态到云端(http://34.194.32.46:8080/doc/N5iaViSJO)，方法名：reportFirmUpV2
 *        设备升级状态上报(http://34.194.32.46:8080/doc/1Lt80cvinF)，方法名：reportFirmUpV3
 * @param[in]  type              [固件类型]
 * @param[in]  p_latest_ver      [最新固件版本]
 * @param[in]  p_fw_url          [固件的URL]
 * @param[in]  status            [升级状态]
 * @param[in]  percent           [上报升级进度，单位：%]
 * @return     int               [成功/失败]
 */
int vesync_report_firm_up(FW_TYPE_E type, char *p_latest_ver, char *p_fw_url, uint8_t status, uint8_t percent)
{
    int ret = -1;
    dev_fw_info_t firm_info;
    cJSON *json_data = NULL;
    cJSON *upg_status = NULL;

    // 参数判断
    if (NULL == p_latest_ver || NULL == p_fw_url)
    {
        SDK_LOG(LOG_ERROR, "The parameter contains a null pointer!!\n");
        return SDK_FAIL;
    }

    // 获取参数
    memset(&firm_info, 0, sizeof(dev_fw_info_t));
    ret = vesync_device_get_fw_info_by_type(type, &firm_info);
    if (SDK_OK != ret)
    {
        return SDK_FAIL;
    }

    if (NULL == s_report_mgt.report_cloud)
    {
        return SDK_FAIL;
    }

    // json组装
    json_data = cJSON_CreateObject();
    if(NULL == json_data)
    {
        SDK_LOG(LOG_ERROR, "Create data object fail\n");
        return SDK_FAIL;
    }
    cJSON_AddItemToObject(json_data, "upgradeStatus", upg_status = cJSON_CreateObject());
    if (NULL != upg_status)
    {
        cJSON_AddStringToObject(upg_status, "pluginName", firm_info.plugin_name);
        cJSON_AddStringToObject(upg_status, "currentVersion", firm_info.cur_firm_ver);
        cJSON_AddNumberToObject(upg_status, "priority", firm_info.priority);
        cJSON_AddBoolToObject(upg_status, "isMainFw", firm_info.main_fw);
        cJSON_AddStringToObject(upg_status, "latestVersion", p_latest_ver);
        cJSON_AddStringToObject(upg_status, "fwUrl", p_fw_url);
        cJSON_AddNumberToObject(upg_status, "status", status);
        cJSON_AddNumberToObject(upg_status, "percent", percent);
    }

    // 发送
    return s_report_mgt.report_cloud(NET_DATA_TOPIC_STATUS, s_report_mgt.methods.firm_up, json_data, CAUSE_CHANGE);
}

/**
 * @brief 手动重置设备，通知云端(http://34.194.32.46:8080/doc/N5ZU7Jwgm)，方法名：resetDeviceV2
 *        设备重置上报(http://34.194.32.46:8080/doc/1Lt66hVc2N)，方法名：resetDeviceV3
 * @return      int      [成功/失败]
 */
int vesync_report_reset_device(void)
{
    cJSON *json_data = NULL;

    if (NULL == s_report_mgt.report_cloud)
    {
        return SDK_FAIL;
    }

    // json组装
    json_data = cJSON_CreateObject();
    if (NULL == json_data)
    {
        SDK_LOG(LOG_ERROR, "Create data object fail\n");
        return SDK_FAIL;
    }

    cJSON_AddStringToObject(json_data, "mode", "manual");

    // 发送
    return s_report_mgt.report_cloud(NET_DATA_TOPIC_STATUS, s_report_mgt.methods.reset_dev, json_data, CAUSE_CHANGE);
}

/**
 * @brief 上报第三方接口(http://34.194.32.46:8080/doc/POOTQH6Bs)，方法名：statusChangeNtyV2
 *        设备状态上报(http://34.194.32.46:8080/doc/1LsQ4i5jz7)，方法名：statusChangeNtyV3
 * @param[in]  json_data    [json 格式的数据，填充到data对象]
 * @return     int          [成功/失败]
 */
int vesync_report_status_change_nty(cJSON *json_data)
{
    if(NULL == json_data)
    {
        SDK_LOG(LOG_ERROR, "arg error\n");
        return SDK_FAIL;
    }

    if (NULL == s_report_mgt.report_cloud)
    {
        cJSON_Delete(json_data);
        return SDK_FAIL;
    }

#if CONFIG_VESYNC_SDK_PRODUCTION_ENABLE
    // 产测模式下，不上报该消息
    if (s_report_mgt.get_production_status)
    {
        if (s_report_mgt.get_production_status() != PRODUCTION_EXIT)
        {
            SDK_LOG(LOG_WARN, "report abort at production mode\n");
            cJSON_Delete(json_data);
            return SDK_FAIL;
        }
    }
#endif /* CONFIG_VESYNC_SDK_PRODUCTION_ENABLE */

    return s_report_mgt.report_cloud(NET_DATA_TOPIC_STATUS, s_report_mgt.methods.status_change, json_data, CAUSE_CHANGE);
}

/**
 * @brief 设备上报运行日志(http://34.194.32.46:8080/doc/BVH3a8uib)， deviceLogReport
 * @param[in]  json_data    [json 格式的数据，填充到data对象]
 * @return     int          [成功/失败]
 */
int vesync_report_device_log(cJSON *json_data)
{
    if (NULL == json_data)
    {
        SDK_LOG(LOG_ERROR, "arg error\n");
        return SDK_FAIL;
    }

    if (NULL == s_report_mgt.report_cloud)
    {
        cJSON_Delete(json_data);
        return SDK_FAIL;
    }

#if CONFIG_VESYNC_SDK_PRODUCTION_ENABLE
    // 产测模式下，不上报该消息
    if (s_report_mgt.get_production_status)
    {
        if (s_report_mgt.get_production_status() != PRODUCTION_EXIT)
        {
            SDK_LOG(LOG_WARN, "report abort at production mode\n");
            cJSON_Delete(json_data);
            return SDK_FAIL;
        }
    }
#endif /* CONFIG_VESYNC_SDK_PRODUCTION_ENABLE */

    // 发送
    return s_report_mgt.report_cloud(NET_DATA_TOPIC_STATUS, "deviceLogReport", json_data, CAUSE_CHANGE);
}

/**
 * @brief       上报数据埋点到云端(http://wiki.vesync.com:8090/pages/viewpage.action?pageId=79265852)，方法名：uploadAnalyzeData
 * @param[in]   json_event_array_data   [上报数据内容]
 * @param[in]   control_type            [控制类型]
 * @return      int                     [成功/失败]
 */
int vesync_report_analysis_data(cJSON *json_event_array_data, const char* control_type)
{
    // 参数判断
    if (NULL == json_event_array_data)
    {
        SDK_LOG(LOG_ERROR, "The parameter contains a null pointer!!\n");
        return SDK_FAIL;
    }

    if (NULL == s_report_mgt.report_cloud)
    {
        cJSON_Delete(json_event_array_data);
        return SDK_FAIL;
    }

    // json组装
    cJSON *json_data = cJSON_CreateObject();
    if(NULL == json_data)
    {
        SDK_LOG(LOG_ERROR, "Create data object fail\n");
        return SDK_FAIL;
    }

    cJSON_AddNumberToObject(json_data, "reportTime", vhal_utils_get_system_time_sec());
    cJSON_AddStringToObject(json_data, "controlType", control_type);
    cJSON_AddItemToObject(json_data, "eventArray", json_event_array_data);

    // 发送
    return s_report_mgt.report_cloud(NET_DATA_TOPIC_LOG, "uploadAnalyzeData", json_data, CAUSE_CHANGE);
}

/**
 * @brief 更新设备在云端的属性(http://34.194.32.46:8080/doc/N5iaViSJO)，方法名：updateDevInfoV2。
 *        设备初始化(http://34.194.32.46:8080/doc/1Lsk8K8lhN)，方法名：initDev
 * @return int      [成功/失败]
 */
int vesync_report_update_dev_info(void)
{
    int ret = -1;
    int avg_rssi = 0;
    char gw_mac_str[MAC_ADDR_STR_MAX_LEN] = {0,};
    char sta_mac_str[MAC_ADDR_STR_MAX_LEN] = {0,};

    uint8_t ota_num = 0;
    vhal_wifi_sta_cfg_t sta_cfg;
    reconn_data_t reconn_data;
    dev_fw_info_t firm_info;
    cJSON *data = NULL;
    cJSON *conn_info = NULL;
    cJSON *firm_info_arr = NULL;

    // 获取参数
    ret = vhal_utils_get_dev_mac(VHAL_MAC_ROUTER, gw_mac_str, sizeof(gw_mac_str));
    if (VHAL_OK != ret)
    {
        snprintf(gw_mac_str, sizeof(gw_mac_str), "00:00:00:00:00:00");   // 获取mac地址失败，使用0填充
    }

    ret = vhal_utils_get_dev_mac(VHAL_MAC_WIFI_STA, sta_mac_str, sizeof(sta_mac_str));
    if (VHAL_OK != ret)
    {
        snprintf(sta_mac_str, sizeof(sta_mac_str), "00:00:00:00:00:00");   // 获取mac地址失败，使用0填充
    }

    memset(&sta_cfg, 0, sizeof(vhal_wifi_sta_cfg_t));
    ret = vhal_wifi_get_sta_cfg(&sta_cfg);
    if (VHAL_OK != ret)
    {
        snprintf(sta_cfg.ssid, sizeof(sta_cfg.ssid) -1, "Unknown");
    }

    avg_rssi = vhal_wifi_get_router_rssi(10);

    memset(&reconn_data, 0, sizeof(reconn_data_t));

    if (s_report_mgt.get_reconn_data)
    {
        s_report_mgt.get_reconn_data(&reconn_data);
    }

    ota_num = vesync_device_get_ota_num();

#if CONFIG_VESYNC_HAL_BLE_ENABLE
    char bt_mac_str[MAC_ADDR_STR_MAX_LEN] = {0,};
    ret = vhal_ble_get_mac(bt_mac_str, sizeof(bt_mac_str));
    if(VHAL_OK != ret)
    {
        snprintf(bt_mac_str, sizeof(bt_mac_str), "00:00:00:00:00:00");
    }
#endif

    // json组装
    data = cJSON_CreateObject();
    if(NULL == data)
    {
        SDK_LOG(LOG_ERROR, "Create data object fail\n");
        return SDK_FAIL;
    }

    cJSON_AddStringToObject(data, "wifiName", sta_cfg.ssid);
    cJSON_AddStringToObject(data, "mac", sta_mac_str);
    cJSON_AddStringToObject(data, "routerMac", gw_mac_str);
    if (s_report_mgt.get_reconn_reason_str)
    {
        cJSON_AddStringToObject(data, "initState", s_report_mgt.get_reconn_reason_str(reconn_data.reason));
    }
    else
    {
        cJSON_AddStringToObject(data, "initState", "PowerOn");
    }

    cJSON_AddNumberToObject(data, "rssi", avg_rssi);

#if CONFIG_VESYNC_HAL_BLE_ENABLE
    cJSON_AddStringToObject(data, "BTMac", bt_mac_str);
#endif

    if (NETWORK_REASON == reconn_data.reason || WIFI_REASON == reconn_data.reason)
    { // Wi-Fi/MQTT掉线原因，上报这些信息
        cJSON_AddItemToObject(data, "connInfo", conn_info = cJSON_CreateObject());

        if (NULL != conn_info)
        {
            char tmp_buf[32] = {0};
            snprintf(tmp_buf, sizeof(tmp_buf)-1, "W%u,%u,%u,M%u",
                    (unsigned int)reconn_data.retry_cnt[WIFI_RETRY_NO_AP_FOUND], (unsigned int)reconn_data.retry_cnt[WIFI_RETRY_INVALID_PWD],
                    (unsigned int)reconn_data.retry_cnt[WIFI_RETRY_CONNECT_FAIL], (unsigned int)reconn_data.retry_cnt[NETWORK_RETRY_FAIL]);
            cJSON_AddNumberToObject(conn_info, "mqttDisTs", reconn_data.network_disconn_ts);
            cJSON_AddNumberToObject(conn_info, "mqttRecTs", reconn_data.network_reconn_ts);
            cJSON_AddNumberToObject(conn_info, "wifiDisTs", reconn_data.wifi_disconn_ts);
            cJSON_AddNumberToObject(conn_info, "wifiRecTs", reconn_data.wifi_reconn_ts);
            cJSON_AddStringToObject(conn_info, "retry", tmp_buf);
        }
    }

    for (uint8_t idx = 0; idx < ota_num; idx++)
    {  // 获取固件信息
        memset(&firm_info, 0, sizeof(dev_fw_info_t));
        vesync_device_get_fw_info_by_idx(idx, &firm_info);

        if (NULL == firm_info_arr)
        {
            cJSON_AddItemToObject(data, "firmwareInfos", firm_info_arr = cJSON_CreateArray());
        }

        if (NULL != firm_info_arr)
        {
            cJSON *firm_info_num = cJSON_CreateObject();
            if(NULL != firm_info_num)
            {
                cJSON_AddStringToObject(firm_info_num, "pluginName", firm_info.plugin_name);
                cJSON_AddStringToObject(firm_info_num, "version", firm_info.cur_firm_ver);
                cJSON_AddNumberToObject(firm_info_num, "priority", firm_info.priority);
                cJSON_AddBoolToObject(firm_info_num, "isMainFw", firm_info.main_fw);
                cJSON_AddItemToArray(firm_info_arr, firm_info_num);
            }
        }
    }

    // 发送，成功后清除缓存和flash中的记录
    if (s_report_mgt.report_cloud_qos)
    {
        s_report_mgt.report_cloud_qos(NET_DATA_TOPIC_STATUS, s_report_mgt.methods.update_dev_info, data, CAUSE_CONNECT, SEND_QOS1, NULL);
    }

    if (ret == SDK_OK)
    {
        // 在恢复出厂或者ota重启时，才会保存flash，因此也只在这两种情况下清除flash中的记录
        if (UPGRADE_REASON == reconn_data.reason/* || FACTORY_RESET == reconn_data.reason*/\
            || PRODUCTION_REASON == reconn_data.reason)
        {
            if (s_report_mgt.save_reconn_reason)
            {
                s_report_mgt.save_reconn_reason(RECONNECT_NONE_REASON);
            }

#if CONFIG_VESYNC_SDK_OTA_ENABLE
            // 如果是ota，设备连上服务器后，需要将升级成功状态上报给服务器
            vesync_report_firm_up(UPG_TP_WIFI, vesync_cfg_get_fw_version(), "", UPG_SUCCESS, 100);
#endif
        }

        if (s_report_mgt.clear_reconn_data)
        {
            s_report_mgt.clear_reconn_data();
        }
    }

    return ret;
}

#if defined(CONFIG_VESYNC_SDK_FFS_ENABLE) && (PR_REPORT_PROTOCOL_VER == 2)
/**
 * @brief 上报证书类型下载结果
 * @param[in]  cert_type         [证书类型]
 * @param[in]  status            [升级状态]
 * @return     int               [成功/失败]
 */
int vesync_report_ffs_cert_update(FFS_CERT_E cert_type, uint8_t status)
{
    cJSON *json_data = NULL;
    cJSON *upg_status = NULL;

    // json组装
    json_data = cJSON_CreateObject();
    if (NULL == json_data)
    {
        SDK_LOG(LOG_ERROR, "Create data object fail\n");
        return SDK_FAIL;
    }

    cJSON_AddItemToObject(json_data, "upCertStatus", upg_status = cJSON_CreateObject());
    if (NULL != upg_status)
    {
        if (FFS_CA == cert_type)
        {
            cJSON_AddStringToObject(upg_status, "type", "FFS_CA");
        }
        else if (FFS_PRIVATE_KEY == cert_type)
        {
            cJSON_AddStringToObject(upg_status, "type", "FFS_PrivateKey");
        }
        else
        {
            SDK_LOG(LOG_ERROR, "arg error\n");
        }
        cJSON_AddNumberToObject(upg_status, "status", status);
    }

    return report_cloud_v2(NET_DATA_TOPIC_STATUS, "reportCertUp", json_data, 0);
}
#endif

int vesync_report_get_user_timebase_info(int type)
{
    cJSON *json_data = NULL;

#if CONFIG_VESYNC_SDK_PRODUCTION_ENABLE
    // 产测模式下，不上报该消息
    if (s_report_mgt.get_production_status)
    {
        if (s_report_mgt.get_production_status() != PRODUCTION_EXIT)
        {
            SDK_LOG(LOG_WARN, "report abort at production mode\n");
            return SDK_FAIL;
        }
    }
#endif

    if (NULL == s_report_mgt.report_cloud)
    {
        return SDK_FAIL;
    }

    // JSON组装
    json_data = cJSON_CreateObject();
    if (NULL == json_data)
    {
        SDK_LOG(LOG_ERROR, "Create data object fail\n");
        return SDK_FAIL;
    }

    cJSON_AddStringToObject(json_data, "accountId", vesync_device_get_account_id());
    cJSON_AddNumberToObject(json_data, "type", type);

    return s_report_mgt.report_cloud(NET_DATA_TOPIC_STATUS, "getUserTimeBaseInfo", json_data, CAUSE_QUERY);
}

/**
 * @brief 发起同步服务器时间戳的请求
 * @return int  [成功：SDK_OK，失败：SDK_FAIL]
 */
int vesync_report_sync_server_timestamp(void)
{
    cJSON *json_data = NULL;

#if CONFIG_VESYNC_SDK_PRODUCTION_ENABLE
    // 产测模式下，不上报该消息
    if (s_report_mgt.get_production_status)
    {
        if (s_report_mgt.get_production_status() != PRODUCTION_EXIT)
        {
            SDK_LOG(LOG_WARN, "report abort at production mode\n");
            return SDK_FAIL;
        }
    }
#endif

    if (NULL == s_report_mgt.report_cloud)
    {
        return SDK_FAIL;
    }

    // JSON组装
    json_data = cJSON_CreateObject();
    if (NULL == json_data)
    {
        SDK_LOG(LOG_ERROR, "Create data object fail\n");
        return SDK_FAIL;
    }

    return s_report_mgt.report_cloud(NET_DATA_TOPIC_STATUS, "syncServerTimstamp", json_data, CAUSE_QUERY);
}

