/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_event_list.h
 * @brief       事件链表处理接口
 * @author      Joshua
 * @date        2021-07-28
 */

#ifndef __VESYNC_EVENT_LIST_H__
#define __VESYNC_EVENT_LIST_H__

#include "vesync_event_internal.h"

/**
* @brief 增加事件节点
* @param[in] event_mgt              [事件管理器对象指针]
* @param[in] event_id               [事件ID]
* @return event_node_t*             [添加的事件节点指针]
*/
event_node_t *vesync_event_node_list_add(event_manage_t *event_mgt, EVENT_ID_E event_id);

/**
* @brief 删除事件节点
* @param[in] event_mgt              [事件管理器对象指针]
* @param[in] event_id               [事件ID]
*/
void vesync_event_node_list_del(event_manage_t *event_mgt, EVENT_ID_E event_id);

/**
* @brief 获取事件节点
* @param[in] event_mgt              [事件管理器对象指针]
* @param[in] event_id               [事件ID]
* @return event_node_t*             [事件节点指针]
*/
event_node_t *vesync_event_node_get(event_manage_t *event_mgt, EVENT_ID_E event_id);

/**
* @brief 增加订阅节点
* @param[in] sub_id                 [订阅者ID]
* @param[in] cb                     [订阅回调函数]
* @param[in] *node                  [订阅的事件ID]
* @return int                       [SDK_OK/SDK_FAIL]
*/
int vesync_event_subscribe_list_add(SUB_ID_E sub_id, event_subscribe_cb_t cb, event_node_t *node);

/**
* @brief 删除订阅节点
* @param[in] event_mgt              [事件管理器对象指针]
* @param[in] sub_id                 [订阅者ID]
* @param[in] *node                  [订阅的事件ID]
*/
void vesync_event_subscribe_list_del(event_manage_t *event_mgt, SUB_ID_E sub_id, event_node_t *node);


#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_EVENT_LIST_H__ */

