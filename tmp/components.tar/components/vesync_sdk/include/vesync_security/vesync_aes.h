/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_aes.h
 * @brief       AES加解密相关接口
 * @date        2021-04-23
 */

#ifndef __VESYNC_AES_H__
#define __VESYNC_AES_H__

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

// Key length in bytes [128 bit]
#define AES_KEY_LEN              (16)

/**
 * @brief  AES加密
 * @param[in]  in_data              [待加密的数据]
 * @param[in]  in_len               [待加密数据的长度]
 * @param[out] out_data             [加密后的数据]
 * @return     int                  [加密后的数据长度，为0则加密失败]
*/
int vesync_aes_encrypt(uint8_t* in_data, int in_len, uint8_t** out_data);

/**
 * @brief  AES解密
 * @param[in]  in_data              [待解密的数据]
 * @param[in]  in_len               [待解密数据的长度]
 * @param[out] out_data             [解密后的数据]
 * @return int                      [解密后的数据长度，为0则解密失败]
*/
int vesync_aes_decrypt(uint8_t* in_data, int in_len, uint8_t** out_data);

/**
 * @brief 通过随机数生成AES密钥
 * @param[in]  pKey                 [生成的AES密钥]
 * @param[in]  size                 [密钥长度]
* @return  int                      [成功返回SDK_OK, 失败返回SDK_FAIL]
 */
int vesync_aes_generate_key(uint8_t *pKey, int size);

/**
 * @brief AES密钥注册
 * @param[in]  pKey                 [密钥128bits]
 * @param[in]  pIV                  [IV初始向量128bits]
 * @return     void                 [无]
*/
void vesync_aes_reg_key(uint8_t *pKey, uint8_t *pIV);

#ifdef __cplusplus
}
#endif
#endif /* __VESYNC_AES_H__ */

