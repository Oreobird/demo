/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_wifi_led.h
 * @brief       WiFi指示灯控制接口
 * @date        2021-05-08
 */

#ifndef __VESYNC_WIFI_LED_H__
#define __VESYNC_WIFI_LED_H__

#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief wifi指示灯状态
 */
typedef enum
{
    WIFI_LED_OFF            = 0,
    WIFI_LED_ON             = 1,
    WIFI_LED_BLINK          = 2,
    WIFI_LED_DOUBLE_BLINK   = 3
} WIFI_LED_STATUS_E;

/**
 * @brief wifi指示灯行为
 */
typedef enum
{
    WIFI_LED_INIT               = 0,    // 初始状态
    WIFI_LED_STARTUP            = 1,    // 上电时Wi-Fi指示灯状态
    WIFI_LED_NOT_CONFIG         = 2,    // 设备未配网(等待配网)
    WIFI_LED_CONFIG_TIMEOUT     = 3,    // 配网超时
    WIFI_LED_CONFIGING          = 4,    // 配网进行中
    WIFI_LED_FFS_CONFIGING      = 5,    // FFS配网进行中
    WIFI_LED_CONNECTING         = 6,    // 上电时，网络(Wi-Fi和MQTT)连接中
    WIFI_LED_WIFI_DISC          = 7,    // Wi-Fi连接断开
    WIFI_LED_WIFI_TIMEOUT       = 8,    // Wi-Fi连接超时
    WIFI_LED_SERVER_DISC        = 9,    // Wi-Fi连接成功，服务器连接断开
    WIFI_LED_SERVER_TIMEOUT     = 10,   // Wi-Fi连接成功，服务器连接超时
    WIFI_LED_LOGIN_SUCCESS      = 11,   // 连接服务器成功
    WIFI_LED_RESET_DEVICE       = 12,   // 复位设备
    WIFI_LED_PRODUCTION_TEST    = 13,   // 产测未连上服务器的灯效
} WIFI_LED_BEHAVIOR_E;

/**
 * @brief wifi指示灯行为参数
 */
typedef struct
{
    WIFI_LED_STATUS_E   status;         //
    uint32_t            blink_ms;       // 闪烁时点亮时间，单位毫秒
    uint8_t             off_times;      // 闪烁时熄灭时间与点亮时间的倍数(点亮时间/熄灭时间)
    uint32_t            blink_times;    // 闪烁次数，达到次数后自动关闭，设置为0则为连续不断闪烁
} wifi_led_cfg_t;

/*
 * @brief wifi LED各模式的参数信息
 */
typedef struct
{
    wifi_led_cfg_t led_startup;             // 上电时Wi-Fi指示灯状态
    wifi_led_cfg_t led_not_config;          // 未配网(等待配网)的Wi-Fi指示灯状态
    wifi_led_cfg_t led_config_timeout;      // 配网超时Wi-Fi指示灯状态
    wifi_led_cfg_t led_config_net;          // 配网进行中Wi-Fi指示灯状态
    wifi_led_cfg_t led_ffs_config_net;      // FFS配网进行中Wi-Fi指示灯状态
    wifi_led_cfg_t led_connecting;          // 上电时，网络自动连接的Wi-Fi指示灯状态
    wifi_led_cfg_t led_wifi_disconnect;     // Wi-Fi断开连接时Wi-Fi指示灯状态
    wifi_led_cfg_t led_wifi_timeout;        // wifi连接超时的Wi-Fi指示灯状态
    wifi_led_cfg_t led_server_disconnect;   // wifi连接成功,但服务器断开连接时Wi-Fi指示灯状态
    wifi_led_cfg_t led_server_timeout;      // 服务器连接超时的Wi-Fi指示灯状态
    wifi_led_cfg_t led_login;               // 登录服务器成功后Wi-Fi指示灯状态
    wifi_led_cfg_t led_reset_device;        // 复位时Wi-Fi指示灯状态
    wifi_led_cfg_t led_production_test;     // 产测状态未连上服务器的Wi-Fi指示灯状态
} wifi_led_info_t;


/**
 * @brief 状态回调函数指针
 * @param int                   [wifi指示灯当前状态，ON - 亮；OFF - 灭]
 */
typedef void (*wifi_led_turn_cb_t)(int);

/**
 * @brief 状态回调函数指针
 * @param[in]   led_info        [wifi指示灯配置]
 */
typedef void (*wifi_led_mcu_control_cb_t)(wifi_led_cfg_t led_cfg);

/**
 * @brief 重置WIFI指示灯闪烁模式
 */
void vesync_wifi_led_reset_behavior(void);


/**
 * @brief 设置WIFI单指示灯闪烁模式
 * @param  led_behavior         [WiFi指示灯闪烁行为]
 * @return                      [无]
 */
void vesync_wifi_led_set_behavior(WIFI_LED_BEHAVIOR_E led_behavior);

/**
 * @brief 注册WiFi LED指示灯状态变化回调函数
 * @param[in]   wifi_cb         [WiFi指示灯变化回调函数，每次指示灯进行亮灭变化时都会调用该函数]
 * @param[in]   mcu_cb          [WiFi指示灯变化回调函数，只有配置变更时才会发给MCU]
 */
void vesync_wifi_led_regist_cb(wifi_led_turn_cb_t wifi_cb, wifi_led_mcu_control_cb_t mcu_cb);

/**
 * @brief APP层向平台层注册WiFi LED单指示灯配置信息
 * @param led_info              [WiFi单指示灯配置信息]
 */
void vesync_wifi_led_info_set(wifi_led_info_t led_info);

/**
* @brief wifi led初始化函数
* @return int                   [成功:SDK_OK, 失败:SDK_FAIL]
*/
int vesync_wifi_led_init(void);

/**
* @brief wifi led释放资源函数
*/
void vesync_wifi_led_deinit(void);

#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_WIFI_LED_H__ */

