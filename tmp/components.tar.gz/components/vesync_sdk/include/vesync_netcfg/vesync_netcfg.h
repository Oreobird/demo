/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_netcfg.h
 * @brief       配网相关接口
 * @date        2021-05-21
 */

#ifndef __VESYNC_NETCFG_H__
#define __VESYNC_NETCFG_H__


#include <stdbool.h>


#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief 整个配网过程中每一步的事件，目的是让应用层知道配网过程进行到哪一步
 * @note  该事件只有在配网过程中才有效，非配网过程出现的BLE/WIFI/MQTT断连事件不会触发相应的回调
 */
typedef enum
{
    NETCFG_EV_BLE_CONNECTED = 0,            // 蓝牙连接
    NETCFG_EV_BLE_DISCONNECTED,         // 蓝牙断开
    NETCFG_EV_APP_CONNECTED,            // APP连接
    NETCFG_EV_APP_DISCONNECTED,         // APP断开
    NETCFG_EV_RECV_CONFIG,              // 收到配网数据
    NETCFG_EV_WIFI_CONNECTED,           // 设备连上wifi
    NETCFG_EV_GOT_IP,                   // 设备获取到IP地址
    NETCFG_EV_DNS_RESOLVED,             // 云服务器域名解析成功
    NETCFG_EV_SERV_CONNECTED,           // 云服务器连接成功
    NETCFG_EV_SERV_DISCONNECTED,        // 云服务器连接断开
    NETCFG_EV_SUCCESS,                  // 配网成功（mqtt订阅成功）
    NETCFG_EV_APP_CANCEL,               // 配网被取消
    NETCFG_EV_EXIT,                     // 配网退出
    NETCFG_EV_MAX,
} NETCFG_EVT_E;



/**
 * @brief  开启配网模式
 * @return  int                 [成功：SDK_OK，失败：SDK_FAIL]
 * @note   开启配网模式成功后将持续10分钟，直至配网成功或者超时退出，或者调用stop接口退出
 */
int vesync_netcfg_start(void);


/**
 * @brief  关闭配网模式
 * @return  int                 [成功：SDK_OK，失败：SDK_FAIL]
 */
int vesync_netcfg_stop(void);

/**
 * @brief   重新启动配网模式, 此接口开放给应用层调用
 * @return  int                 [成功：SDK_OK，失败：SDK_FAIL]
 * @note    1.配网任务运行中，则会等待退出操作完成后，重新进入配网任务
 *          2.配网任务未运行，直接启动配网任务。
 */
int vesync_netcfg_restart(void);

/**
 * @brief  获取当前状态是否处于配网模式
 * @return  bool                [true-配网中，false-非配网状态]
 */
bool vesync_netcfg_is_running(void);

/**
 * @brief  向配网事件管理注册配网前回调，提供给应用层的接口
 * @param[in]  net_cfg_pre_cb    [配网成功回调函数]
 * @return  int                 [成功：SDK_OK，失败：SDK_FAIL]
 */
int vesync_net_cfg_reg_pre_cb(void (*net_cfg_pre_cb)(void));



/**
 * @brief  向配网事件管理注册配网成功事件回调
 * @param[in]  net_cfg_ok_cb    [配网成功回调函数]
 * @return  int                 [成功：SDK_OK，失败：SDK_FAIL]
 */
int vesync_net_cfg_reg_success_cb(void (*net_cfg_ok_cb)(void));

/**
 * @brief  注册配网事件回调
 * @param[in]  ev               [配网事件]
 * @param[in]  netcfg_ev_cb     [配网事件回调函数]
 * @return  int                 [成功：SDK_OK，失败：SDK_FAIL]
 */
int vesync_netcfg_reg_ev_cb(NETCFG_EVT_E ev, void (*netcfg_ev_cb)(void));


#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_NETCFG_H__ */

