/**
 *  Copyright © Vesync Technologies Co.Ltd. 2019-2021. All rights reserved
 * @file        led_strip_adc.h
 * @brief       led strip voice detecting function
 * @author      henrik
 * @date        2021-09-29
 */

#ifndef __LED_STRIP_SOUND_DETECT_H__
#define __LED_STRIP_SOUND_DETECT_H__

#include <stdio.h>
#include <stdlib.h>


#ifdef __cplusplus
{
#endif

/**
 * @brief 声音监测功能初始化
 * @param[in]  channel                  [监测通道]
 * @param[in]  s_wind                   [存储采样窗口数据缓存]
 * @param[in]  n_samples                [采样窗口点数]
 * @return
 *      - SUCCESS      0
 *      - FAIL         -1
 */

int32_t led_strip_sound_detect_init(uint8_t channel, float *s_wind, int32_t n_samples);

/**
 * @brief      将ADC采样数值经过FFT运算后的值存储在y_cf数组中
 * @param[in]  y_cf             Stores the FFT converted array
 * @param[in]  n_samples        FFT sampling points
 * @param[in]  audio_data       Audio source data
 * @param[in]  s_wind           FFT window array
 * @return
 *      - APP_OK  成功
 *      - APP_FAIL  失败
 */
int32_t led_strip_sound_data_fft(float *y_cf, uint32_t n_samples, \
                                               float *audio_data, float *s_wind);

/**
 * @brief      获取ADC的声音采样数据
 * @param[in]   dc_component       ADC的直流分量
 * @param[in]   audio_data         声音采样数据存储缓存
 * @param[out]  count         声音采样点数
 * @return
 *      - APP_OK  成功
 *      - APP_FAIL  失败
 */
int32_t led_strip_get_sound_data(int32_t dc_component, float *audio_data, int32_t* count);

/**
 * @brief      开始声音采集
 */
void led_strip_start_sound_detect(void);

/**
 * @brief      停止声音采集
 */
void led_strip_stop_sound_detect(void);


#ifdef __cplusplus
}
#endif



#endif
