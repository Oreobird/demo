/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_sem.c
 * @brief       semaphore抽象层，封装linux posix信号量相关接口
 * @author      Joshua
 * @date        2021-04-20
 */

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <semaphore.h>
#include <time.h>
#include <sys/time.h>
#include "vesync_memory.h"
#include "vesync_common.h"
#include "vesync_os.h"
#include "vesync_sem.h"

/*
 * @brief  创建二值信号量
 * @return vesync_sem_t                [信号量结构体指针]
 */
vesync_sem_t *vesync_sem_binary_new(void)
{
    vesync_sem_t *p_vsem = (vesync_sem_t *)vesync_malloc(sizeof(vesync_sem_t));
    if (p_vsem == NULL)
    {
        return NULL;
    }

    sem_t *p_sem = (sem_t *)vesync_malloc(sizeof(sem_t));
    if (p_sem == NULL)
    {
        VCOM_SAFE_FREE(p_vsem);
        return NULL;
    }

    int ret = sem_init(p_sem, 0, 0);
    if (ret != 0)
    {
        VCOM_SAFE_FREE(p_sem);
        VCOM_SAFE_FREE(p_vsem);
        return NULL;
    }

    p_vsem->max_count = 1;
    p_vsem->handle = p_sem;

    return p_vsem;
}


/*
 * @brief  创建计数信号量
 * @param[in]  max_count               [信号量最大计数]
 * @return vesync_sem_t                [信号量结构体指针]
 */
vesync_sem_t *vesync_sem_count_new(unsigned int max_count)
{
    vesync_sem_t *p_vsem = (vesync_sem_t *)vesync_malloc(sizeof(vesync_sem_t));
    if (p_vsem == NULL)
    {
        return NULL;
    }

    sem_t *p_sem = (sem_t *)vesync_malloc(sizeof(sem_t));
    if (p_sem == NULL)
    {
        VCOM_SAFE_FREE(p_vsem);
        return NULL;
    }

    int ret = sem_init(p_sem, 0, 0);
    if (ret != 0)
    {
        VCOM_SAFE_FREE(p_sem);
        VCOM_SAFE_FREE(p_vsem);
        return NULL;
    }

    p_vsem->max_count = max_count;
    p_vsem->handle = p_sem;

    return p_vsem;

}

/*
 * @brief  等待信号量
 * @param[in]  sem                     [信号量结构体指针]
 * @param[in]  timeout_ms              [等待时间：
 *                                      VESYNC_OS_NO_WAIT: 不等待
 *                                      VESYNC_OS_WAIT_FOREVER: 等待信号量]
 * @return int                         [成功：VOS_OK；失败：返回VOS_FAIL]
 */
int vesync_sem_wait(vesync_sem_t *sem, unsigned int timeout_ms)
{
    int sec = 0;
    int nsec = 0;
    int ret = -1;

    VCOM_NULL_PARAM_CHK(sem, return VOS_FAIL);
    VCOM_NULL_PARAM_CHK(sem->handle, return VOS_FAIL);

    if (timeout_ms == VESYNC_OS_WAIT_FOREVER)
    {
        ret = sem_wait((sem_t *)sem->handle);
        return ret != 0 ? VOS_FAIL : VOS_OK;
    }
    else if (timeout_ms == VESYNC_OS_NO_WAIT)
    {
        ret = sem_trywait((sem_t *)sem->handle);
        return ret != 0 ? VOS_FAIL : VOS_OK;
    }

    struct timespec ts;
    clock_gettime(CLOCK_REALTIME, &ts);

    sec = timeout_ms / 1000;
    nsec = (timeout_ms % 1000) * 1000000;

    ts.tv_nsec += nsec;
    sec += (ts.tv_nsec / 1000000000);
    ts.tv_nsec %= 1000000000;
    ts.tv_sec += sec;

    ret = sem_timedwait((sem_t *)sem->handle, &ts);
    return ret != 0 ? VOS_FAIL : VOS_OK;
}

/*
 * @brief  释放信号量
 * @param[in]  sem                     [信号量结构体指针]
 * @return int                         [成功：VOS_OK；失败：返回VOS_FAIL]
 */
int vesync_sem_signal(vesync_sem_t *sem)
{
    VCOM_NULL_PARAM_CHK(sem, return VOS_FAIL);
    VCOM_NULL_PARAM_CHK(sem->handle, return VOS_FAIL);

    int sem_val = 0;
    int ret = sem_getvalue(sem->handle, &sem_val);
    if (ret != 0 || (sem->max_count == 1 && sem_val >= 1))
    {
        return VOS_FAIL;
    }

    ret = sem_post((sem_t *)sem->handle);
    if (ret < 0)
    {
        return VOS_FAIL;
    }

    return VOS_OK;
}

/*
 * @brief  销毁信号量
 * @param[in]  sem                     [信号量结构体指针]
 * @return int                         [成功：VOS_OK；失败：返回VOS_FAIL]
 */
int vesync_sem_free(vesync_sem_t *sem)
{
    VCOM_NULL_PARAM_CHK(sem, return VOS_FAIL);
    VCOM_NULL_PARAM_CHK(sem->handle, return VOS_FAIL);

    int ret = sem_destroy((sem_t *)sem->handle);
    VCOM_SAFE_FREE(sem->handle);
    VCOM_SAFE_FREE(sem);
    return ret != 0 ? VOS_FAIL : VOS_OK;
}

