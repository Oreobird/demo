/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        switch_bypass.c
 * @brief       switch bypass
 * @author      Charles.Mei
 * @date        2021-08-05
 */


#include <stdint.h>
#include <string.h>

#include "vesync_common.h"
#include "vesync_log.h"
#include "vesync_memory.h"
#include "vesync_buffer.h"
#include "vesync_bypass.h"

#include "switch_app.h"
#include "switch_timing.h"
#include "switch_schedule.h"
#include "switch_uart_cmd.h"


// 以下定义见透传接口设计
// https://wiki.vesync.cn/pages/viewpage.action?pageId=247693972#id-%E5%BC%80%E6%94%BE%E5%B9%B3%E5%8F%B0Dimmer%E5%BC%80%E5%85%B3DS03%E9%80%8F%E4%BC%A0%E8%8D%89%E7%A8%BF-1.%E8%83%8C%E6%99%AF
// subDeviceType表示子设备类型
#define SWITCH_SUBDEVICE_TYPE_LIGHT_STR      "light"
#define SWITCH_SUBDEVICE_TYPE_FAN_STR        "fan"
// subDeviceNo表示子设备编号，对应出现同一个类型；多个子设备
#define SWITCH_SUBDEVICE_NO_LIGHT           (1)
#define SWITCH_SUBDEVICE_NO_FAN             (2)


/**
 * @brief 组装light状态的json
 * @return          cJSON*
 */
static cJSON* switch_light_pack_json(void)
{
    cJSON *json_data = cJSON_CreateObject();
    if (NULL == json_data)
    {
        return json_data;
    }

    cJSON_AddBoolToObject(json_data, "switch", switch_app_get_switch_onoff(DEVICE_LIGHT));
    cJSON_AddNumberToObject(json_data, "percent", switch_app_get_light_lightness());

    cJSON_AddStringToObject(json_data, "subDeviceType", SWITCH_SUBDEVICE_TYPE_LIGHT_STR);
    cJSON_AddNumberToObject(json_data, "subDeviceNo", SWITCH_SUBDEVICE_NO_LIGHT);
    return json_data;
}

/**
 * @brief 组装fan状态的json
 * @return      cJSON*
 */
static cJSON* switch_fan_pack_json(void)
{
    cJSON *json_data = cJSON_CreateObject();
    if (NULL == json_data)
    {
        return json_data;
    }

    cJSON_AddBoolToObject(json_data, "switch", switch_app_get_switch_onoff(DEVICE_FAN));
    cJSON_AddNumberToObject(json_data, "level", switch_app_get_level(DEVICE_FAN));

    cJSON_AddStringToObject(json_data, "subDeviceType", SWITCH_SUBDEVICE_TYPE_FAN_STR);
    cJSON_AddNumberToObject(json_data, "subDeviceNo", SWITCH_SUBDEVICE_NO_FAN);
    return json_data;
}

/**
 * @brief 解析light动作组
 * @param[in]       json_arr        [参数组]
 * @param[in]       action          [动作]
 * @return          int             [通用错误码]
 */
static int switch_bp_parse_light_action(cJSON *json_arr, light_action_t *action)
{
    int arr_size = 0;
    int arr_idx = 0;
    cJSON* json_obj = NULL;
    cJSON* json_type = NULL;
    cJSON *json_act = NULL;
    cJSON *json_params = NULL;
    bool invalid_arr = false;

    memset(action, 0, sizeof(light_action_t));

    arr_size = cJSON_GetArraySize(json_arr);
    if (arr_size <= 0 || arr_size > 3)   //light tiemr最多三个参数组
    {
        return BP_ERR_PARA_ILLEGAL;
    }
    for (arr_idx = 0; arr_idx < arr_size; ++arr_idx)
    {
        json_obj = cJSON_GetArrayItem(json_arr, arr_idx);
        if (NULL == json_obj)
        {
            return BP_ERR_PARA_ILLEGAL;
        }
        json_type = cJSON_GetObjectItemCaseSensitive(json_obj, "type");
        json_act = cJSON_GetObjectItemCaseSensitive(json_obj, "act");
        if (cJSON_IsString(json_type) && cJSON_IsString(json_act))
        {
            if (0 == strcmp(json_type->valuestring, "switch"))
            {
                if (0 == strcmp(json_act->valuestring, "on"))
                {
                    action->onoff = true;
                }
                else if (0 == strcmp(json_act->valuestring, "off"))
                {
                    action->onoff = false;
                }
                else
                {
                    return BP_ERR_PARA_ILLEGAL;
                }
                invalid_arr = true;     // 必须要有type switch，否则非法
            }
            else if (0 == strcmp(json_type->valuestring, "set_percent"))
            {
                if (0 == strcmp(json_act->valuestring, "manual"))
                {
                    json_params = cJSON_GetObjectItemCaseSensitive(json_obj, "params");
                    if (NULL == json_params)
                    {
                        return BP_ERR_PARA_ILLEGAL;
                    }
                    cJSON *json_percent = cJSON_GetObjectItemCaseSensitive(json_params, "percent");
                    if (cJSON_IsNumber(json_percent))
                    {
                        action->lightness = json_percent->valueint;
                    }
                    else
                    {
                        return BP_ERR_PARA_ILLEGAL;
                    }
                }
                else
                {
                    return BP_ERR_PARA_ILLEGAL;
                }
            }
            else if (0 == strcmp(json_type->valuestring, "set_gradient"))
            {
                if (0 == strcmp(json_act->valuestring, "manual"))
                {
                    json_params = cJSON_GetObjectItemCaseSensitive(json_obj, "params");
                    if (NULL == json_params)
                    {
                        return BP_ERR_PARA_ILLEGAL;
                    }
                    cJSON *json_duration = cJSON_GetObjectItemCaseSensitive(json_params, "duration");
                    if (cJSON_IsNumber(json_duration))
                    {
                        action->duration = json_duration->valueint;
                    }
                    else
                    {
                        return BP_ERR_PARA_ILLEGAL;
                    }
                }
                else
                {
                    return BP_ERR_PARA_ILLEGAL;
                }
            }
            else
            {
                return BP_ERR_PARA_ILLEGAL;
            }
        }
        else
        {
            return BP_ERR_PARA_ILLEGAL;
        }
    }
    if (invalid_arr)
    {
        return BP_ERR_NO_ERR;
    }
    return BP_ERR_PARA_ILLEGAL;
}

/**
 * @brief 解析fan动作组
 * @param[in]       json_arr        [参数组]
 * @param[in]       action          [动作]
 * @return          int             [通用错误码]
 */
static int switch_bp_parse_fan_action(cJSON *json_arr, fan_action_t *action)
{
    int arr_size = 0;
    int arr_idx = 0;
    cJSON* json_obj = NULL;
    cJSON* json_type = NULL;
    cJSON *json_act = NULL;
    cJSON *json_params = NULL;
    bool invalid_arr = false;

    memset(action, 0, sizeof(fan_action_t));

    arr_size = cJSON_GetArraySize(json_arr);
    if (arr_size <=0 || arr_size > 2)   //fan tiemr最多三个参数组
    {
        return BP_ERR_PARA_ILLEGAL;
    }
    for (arr_idx = 0; arr_idx < arr_size; ++arr_idx)
    {
        json_obj = cJSON_GetArrayItem(json_arr, arr_idx);
        if (NULL == json_obj)
        {
            return BP_ERR_PARA_ILLEGAL;
        }
        json_type = cJSON_GetObjectItemCaseSensitive(json_obj, "type");
        json_act = cJSON_GetObjectItemCaseSensitive(json_obj, "act");
        if (cJSON_IsString(json_type) && cJSON_IsString(json_act))
        {
            if (0 == strcmp(json_type->valuestring, "switch"))
            {
                if (0 == strcmp(json_act->valuestring, "on"))
                {
                    action->onoff = true;
                }
                else if (0 == strcmp(json_act->valuestring, "off"))
                {
                    action->onoff = false;
                }
                else
                {
                    return BP_ERR_PARA_ILLEGAL;
                }
                invalid_arr = true;     // 必须要有type switch，否则非法
            }
            else if (0 == strcmp(json_type->valuestring, "set_level"))
            {
                if (0 == strcmp(json_act->valuestring, "manual"))
                {
                    json_params = cJSON_GetObjectItemCaseSensitive(json_obj, "params");
                    if (NULL == json_params)
                    {
                        return BP_ERR_PARA_ILLEGAL;
                    }
                    cJSON *json_level = cJSON_GetObjectItemCaseSensitive(json_params, "level");
                    if (cJSON_IsNumber(json_level))
                    {
                        action->level = json_level->valueint;
                    }
                    else
                    {
                        return BP_ERR_PARA_ILLEGAL;
                    }
                }
                else
                {
                    return BP_ERR_PARA_ILLEGAL;
                }
            }
            else
            {
                return BP_ERR_PARA_ILLEGAL;
            }
        }
        else
        {
            return BP_ERR_PARA_ILLEGAL;
        }
    }
    if (invalid_arr)
    {
        return BP_ERR_NO_ERR;
    }

    return BP_ERR_PARA_ILLEGAL;
}

/**
 * @brief 打包light动作组
 * @param[in/out]   json_arr        [参数组]
 * @param[in]       action          [动作]
 * @return          int             [通用错误码]
 */
static int switch_bp_pack_light_action(cJSON **json_arr, light_action_t *action)
{
    int err_code = BP_ERR_NO_ERR;
    cJSON *json_acts = cJSON_CreateArray();
    cJSON *json_act = NULL;
    cJSON *json_params = NULL;

    if (NULL == json_acts)
    {
        return BP_ERR_OUT_OF_MEMORY;
    }

    cJSON_AddItemToArray(json_acts, json_act = cJSON_CreateObject());
    if (NULL == json_act)
    {
        err_code = BP_ERR_OUT_OF_MEMORY;
        goto exit;
    }
    cJSON_AddStringToObject(json_act, "type", "switch");
    if (true == action->onoff)
    {
        cJSON_AddStringToObject(json_act, "act", "on");
    }
    else
    {
        cJSON_AddStringToObject(json_act, "act", "off");
    }
    cJSON_AddNumberToObject(json_act, "num", 0);
    json_act = NULL;

    if (0 != action->lightness)
    {
        cJSON_AddItemToArray(json_acts, json_act = cJSON_CreateObject());
        if (NULL == json_act)
        {
            err_code = BP_ERR_OUT_OF_MEMORY;
            goto exit;
        }
        cJSON_AddStringToObject(json_act, "type", "set_percent");
        cJSON_AddStringToObject(json_act, "act", "manual");
        cJSON_AddNumberToObject(json_act, "num", 0);
        cJSON_AddItemToObject(json_act, "params", json_params = cJSON_CreateObject());
        if (NULL == json_params)
        {
            err_code = BP_ERR_OUT_OF_MEMORY;
            goto exit;
        }
        cJSON_AddNumberToObject(json_params, "percent", action->lightness);
        json_act = NULL;
        json_params = NULL;
    }

    if (0 != action->duration)
    {
        cJSON_AddItemToArray(json_acts, json_act = cJSON_CreateObject());
        if (NULL == json_act)
        {
            err_code = BP_ERR_OUT_OF_MEMORY;
            goto exit;
        }
        cJSON_AddStringToObject(json_act, "type", "set_gradient");
        cJSON_AddStringToObject(json_act, "act", "manual");
        cJSON_AddNumberToObject(json_act, "num", 0);
        cJSON_AddItemToObject(json_act, "params", json_params = cJSON_CreateObject());
        if (NULL == json_params)
        {
            err_code = BP_ERR_OUT_OF_MEMORY;
            goto exit;
        }
        cJSON_AddNumberToObject(json_params, "duration", action->duration);
        json_act = NULL;
        json_params = NULL;
    }

exit:
    if (BP_ERR_NO_ERR == err_code)
    {
        *json_arr = json_acts;
    }
    else
    {
        cJSON_Delete(json_acts);
    }
    return err_code;
}

/**
 * @brief 打包fan动作组
 * @param[in/out]   json_arr        [参数组]
 * @param[in]       action          [动作]
 * @return          int             [通用错误码]
 */
static int switch_bp_pack_fan_action(cJSON **json_arr, fan_action_t *action)
{
    int err_code = BP_ERR_NO_ERR;
    cJSON *json_acts = cJSON_CreateArray();
    cJSON *json_act = NULL;
    cJSON *json_params = NULL;

    if (NULL == json_acts)
    {
        return BP_ERR_OUT_OF_MEMORY;
    }

    cJSON_AddItemToArray(json_acts, json_act = cJSON_CreateObject());
    if (NULL == json_act)
    {
        err_code = BP_ERR_OUT_OF_MEMORY;
        goto exit;
    }
    cJSON_AddStringToObject(json_act, "type", "switch");
    if (true == action->onoff)
    {
        cJSON_AddStringToObject(json_act, "act", "on");
    }
    else
    {
        cJSON_AddStringToObject(json_act, "act", "off");
    }
    cJSON_AddNumberToObject(json_act, "num", 0);
    json_act = NULL;

    if (0 != action->level)
    {
        cJSON_AddItemToArray(json_acts, json_act = cJSON_CreateObject());
        if (NULL == json_act)
        {
            err_code = BP_ERR_OUT_OF_MEMORY;
            goto exit;
        }
        cJSON_AddStringToObject(json_act, "type", "set_level");
        cJSON_AddStringToObject(json_act, "act", "manual");
        cJSON_AddNumberToObject(json_act, "num", 0);
        cJSON_AddItemToObject(json_act, "params", json_params = cJSON_CreateObject());
        if (NULL == json_params)
        {
            err_code = BP_ERR_OUT_OF_MEMORY;
            goto exit;
        }
        cJSON_AddNumberToObject(json_params, "level", action->level);
        json_act = NULL;
        json_params = NULL;
    }

exit:
    if (BP_ERR_NO_ERR == err_code)
    {
        *json_arr = json_acts;
    }
    else
    {
        cJSON_Delete(json_acts);
    }
    return err_code;
}

/**
 * @brief 设置开关
 * @param[in]       p_msg_ctx       [bypass上下文]
 * @param[in]       p_Data          [传入数据]
 */
static void switch_bp_set_switch(bypass_msg_ctx_t *p_msg_ctx, void *p_data)
{
    int err_code = BP_ERR_NO_ERR;
    const char* err_msg = NULL;

    if(NULL == p_msg_ctx || NULL == p_msg_ctx->p_trace_msg || NULL == p_msg_ctx->p_method_info || NULL == p_data)
    {
        err_code = BP_ERR_PARA_ILLEGAL;
        goto exit;
    }

    if (0 == strcmp(p_msg_ctx->p_method_info->dev_type, SWITCH_SUBDEVICE_TYPE_LIGHT_STR) &&
        SWITCH_SUBDEVICE_NO_LIGHT == p_msg_ctx->p_method_info->dev_idx)
    {
        switch_uart_set_switch(DEVICE_LIGHT, ((bypass_switch_data_t*)p_data)->enable ? 1 : 0,
            0, p_msg_ctx->p_trace_msg);
    }
    else if (0 == strcmp(p_msg_ctx->p_method_info->dev_type, SWITCH_SUBDEVICE_TYPE_FAN_STR) &&
        SWITCH_SUBDEVICE_NO_FAN == p_msg_ctx->p_method_info->dev_idx)
    {
        switch_uart_set_switch(DEVICE_FAN, ((bypass_switch_data_t*)p_data)->enable ? 1 : 0,
            0, p_msg_ctx->p_trace_msg);
    }
    else
    {
        err_code = BP_ERR_PARA_ILLEGAL;
        err_msg = BP_ERR_PARAM_CONV(dev_type, BP_ERR_PARAM_VAL_INVALID);
        goto exit;
    }

    return;
exit:
    vesync_bypass_reply_pkg_err_msg(err_code, p_msg_ctx->p_trace_msg, err_msg);
}

/**
 * @brief 反转开关
 * @param[in]       p_msg_ctx       [bypass上下文]
 * @param[in]       p_Data          [传入数据]
 */
static void switch_bp_toggle_switch(bypass_msg_ctx_t *p_msg_ctx, void *p_data)
{
    int err_code = BP_ERR_NO_ERR;
    const char* err_msg = NULL;

    if(NULL == p_msg_ctx || NULL == p_msg_ctx->p_trace_msg || NULL == p_msg_ctx->p_method_info || NULL == p_data)
    {
        err_code = BP_ERR_PARA_ILLEGAL;
        goto exit;
    }

    if (0 == strcmp(p_msg_ctx->p_method_info->dev_type, SWITCH_SUBDEVICE_TYPE_LIGHT_STR) &&
        SWITCH_SUBDEVICE_NO_LIGHT == p_msg_ctx->p_method_info->dev_idx)
    {
        // 开关翻转
        switch_uart_set_switch(DEVICE_LIGHT, switch_app_get_switch_onoff(DEVICE_LIGHT) ? 0 : 1,
            0, p_msg_ctx->p_trace_msg);
    }
    else if (0 == strcmp(p_msg_ctx->p_method_info->dev_type, SWITCH_SUBDEVICE_TYPE_FAN_STR) &&
        SWITCH_SUBDEVICE_NO_FAN == p_msg_ctx->p_method_info->dev_idx)
    {
        // 开关翻转
        switch_uart_set_switch(DEVICE_FAN, switch_app_get_switch_onoff(DEVICE_FAN) ? 0 : 1,
            0, p_msg_ctx->p_trace_msg);
    }
    else
    {
        err_code = BP_ERR_PARA_ILLEGAL;
        err_msg = BP_ERR_PARAM_CONV(dev_type, BP_ERR_PARAM_VAL_INVALID);
        goto exit;
    }

    return;
exit:
    vesync_bypass_reply_pkg_err_msg(err_code, p_msg_ctx->p_trace_msg, err_msg);
}

/**
 * @brief 设置开关
 * @param[in]       p_msg_ctx       [bypass上下文]
 * @param[in]       p_Data          [传入数据]
 */
static void switch_bp_set_level(bypass_msg_ctx_t *p_msg_ctx, void *p_data)
{
    int err_code = BP_ERR_NO_ERR;
    const char* err_msg = NULL;

    if(NULL == p_msg_ctx || NULL == p_msg_ctx->p_trace_msg || NULL == p_msg_ctx->p_method_info || NULL == p_data)
    {
        err_code = BP_ERR_PARA_ILLEGAL;
        goto exit;
    }

    if (0 == strcmp(p_msg_ctx->p_method_info->dev_type, SWITCH_SUBDEVICE_TYPE_LIGHT_STR) &&
        SWITCH_SUBDEVICE_NO_LIGHT == p_msg_ctx->p_method_info->dev_idx)
    {
        if (BP_LEVEL_LIGHT != ((bypass_level_para_t*)p_data)->type)
        {
            err_code = BP_ERR_PARA_ILLEGAL;
            err_msg = BP_ERR_PARAM_CONV(level_type, BP_ERR_PARAM_TYPE);
            goto exit;
        }
        if (((bypass_level_para_t*)p_data)->level <= 0 ||
            ((bypass_level_para_t*)p_data)->level > SWITCH_LIGHT_LEVEL_MAX)
        {
            err_code = BP_ERR_VALUE_OUT_OF_RANGE;
            err_msg = BP_ERR_PARAM_CONV(level, BP_ERR_PARAM_VAL_INVALID);
            goto exit;
        }
        switch_uart_set_level(DEVICE_LIGHT, ((bypass_level_para_t*)p_data)->level,
            0, p_msg_ctx->p_trace_msg);
    }
    else if (0 == strcmp(p_msg_ctx->p_method_info->dev_type, SWITCH_SUBDEVICE_TYPE_FAN_STR) &&
        SWITCH_SUBDEVICE_NO_FAN == p_msg_ctx->p_method_info->dev_idx)
    {
        if (BP_LEVEL_WIND != ((bypass_level_para_t*)p_data)->type)
        {
            err_code = BP_ERR_PARA_ILLEGAL;
            err_msg = BP_ERR_PARAM_CONV(level_type, BP_ERR_PARAM_TYPE);
            goto exit;
        }
        if (((bypass_level_para_t*)p_data)->level <= 0 ||
            ((bypass_level_para_t*)p_data)->level > SWITCH_FAN_LEVEL_MAX)
        {
            err_code = BP_ERR_VALUE_OUT_OF_RANGE;
            err_msg = BP_ERR_PARAM_CONV(level, BP_ERR_PARAM_VAL_INVALID);
            goto exit;
        }
        switch_uart_set_level(DEVICE_FAN, ((bypass_level_para_t*)p_data)->level,
            0, p_msg_ctx->p_trace_msg);
    }
    else
    {
        err_code = BP_ERR_PARA_ILLEGAL;
        err_msg = BP_ERR_PARAM_CONV(dev_type, BP_ERR_PARAM_VAL_INVALID);
        goto exit;
    }

    return;
exit:
    vesync_bypass_reply_pkg_err_msg(err_code, p_msg_ctx->p_trace_msg, err_msg);
}

/**
 * @brief 调整档位
 * @param[in]       p_msg_ctx       [bypass上下文]
 * @param[in]       p_Data          [传入数据]
 */
static void switch_bp_adjust_level(bypass_msg_ctx_t *p_msg_ctx, void *p_data)
{
    int err_code = BP_ERR_NO_ERR;
    const char* err_msg = NULL;
    int8_t new_level = 0;

    if(NULL == p_msg_ctx || NULL == p_msg_ctx->p_trace_msg || NULL == p_msg_ctx->p_method_info || NULL == p_data)
    {
        err_code = BP_ERR_PARA_ILLEGAL;
        goto exit;
    }

    if (0 == strcmp(p_msg_ctx->p_method_info->dev_type, SWITCH_SUBDEVICE_TYPE_LIGHT_STR) &&
        SWITCH_SUBDEVICE_NO_LIGHT == p_msg_ctx->p_method_info->dev_idx)
    {
        new_level = switch_app_get_level(DEVICE_LIGHT) + ((bypass_range_v2_t*)p_data)->step;
        switch (((bypass_range_v2_t*)p_data)->rule)
        {
            case BP_RULE_NO_LOOP:
                if (new_level <= 0)
                {
                    new_level = 1;  // 最低档
                }
                else if (new_level > SWITCH_LIGHT_LEVEL_MAX)
                {
                    new_level = SWITCH_LIGHT_LEVEL_MAX;
                }
                break;
            case BP_RULE_UP_LOOP:
                if (new_level <= 0)
                {
                    new_level = 1;  // 最低档
                }
                else if (new_level > SWITCH_LIGHT_LEVEL_MAX)
                {
                    new_level = new_level % (SWITCH_LIGHT_LEVEL_MAX);
                    if (0 == new_level)
                    {
                        new_level = SWITCH_LIGHT_LEVEL_MAX;
                    }
                }
                break;
            default:
                err_code = BP_ERR_PARA_ILLEGAL;
                err_msg = BP_ERR_PARAM_CONV(rule, BP_ERR_PARAM_VAL_INVALID);
                goto exit;
        }

        switch_uart_set_level(DEVICE_LIGHT, new_level, 0, p_msg_ctx->p_trace_msg);
    }
    else if (0 == strcmp(p_msg_ctx->p_method_info->dev_type, SWITCH_SUBDEVICE_TYPE_FAN_STR) &&
        SWITCH_SUBDEVICE_NO_FAN == p_msg_ctx->p_method_info->dev_idx)
    {
        new_level = switch_app_get_level(DEVICE_FAN) + ((bypass_range_v2_t*)p_data)->step;
        switch (((bypass_range_v2_t*)p_data)->rule)
        {
            case BP_RULE_NO_LOOP:
                if (new_level <= 0)
                {
                    new_level = 1;  // 最低档
                }
                else if (new_level > SWITCH_FAN_LEVEL_MAX)
                {
                    new_level = SWITCH_FAN_LEVEL_MAX;
                }
                break;
            case BP_RULE_UP_LOOP:
                if (new_level <= 0)
                {
                    new_level = 1;  // 最低档
                }
                else if (new_level > SWITCH_FAN_LEVEL_MAX)
                {
                    new_level = new_level % (SWITCH_FAN_LEVEL_MAX);
                    if (0 == new_level)
                    {
                        new_level = SWITCH_FAN_LEVEL_MAX;
                    }
                }
                break;
            default:
                err_code = BP_ERR_PARA_ILLEGAL;
                err_msg = BP_ERR_PARAM_CONV(rule, BP_ERR_PARAM_VAL_INVALID);
                goto exit;
        }

        switch_uart_set_level(DEVICE_FAN, new_level, 0, p_msg_ctx->p_trace_msg);
    }
    else
    {
        err_code = BP_ERR_PARA_ILLEGAL;
        err_msg = BP_ERR_PARAM_CONV(dev_type, BP_ERR_PARAM_VAL_INVALID);
        goto exit;
    }

    return;
exit:
    vesync_bypass_reply_pkg_err_msg(err_code, p_msg_ctx->p_trace_msg, err_msg);
}


#define SWITCH_LIGHT_TEST_MIN_LIGHTNESS_TIME_S  (5) //测试灯最低亮度，动作时间固定5s，见DS03产品需求

/**
 * @brief 测试灯最低亮度
 * @param[in]       p_msg_ctx       [bypass上下文]
 * @param[in]       p_Data          [传入数据]
 */
static void switch_bp_test_light_min_lightness(bypass_msg_ctx_t *p_msg_ctx, void *p_data)
{
    int err_code = BP_ERR_NO_ERR;
    const char* err_msg = NULL;

    if(NULL == p_msg_ctx || NULL == p_msg_ctx->p_trace_msg || NULL == p_msg_ctx->p_method_info || NULL == p_data)
    {
        err_code = BP_ERR_PARA_ILLEGAL;
        goto exit;
    }

    if (0 == strcmp(p_msg_ctx->p_method_info->dev_type, SWITCH_SUBDEVICE_TYPE_LIGHT_STR) &&
        SWITCH_SUBDEVICE_NO_LIGHT == p_msg_ctx->p_method_info->dev_idx)
    {
        if (((bypass_percent_t*)p_data)->percent < SWITCH_LIGHT_PERCENT_MIN ||
            ((bypass_percent_t*)p_data)->percent > SWITCH_LIGHT_PERCENT_MAX)
        {
            err_code = BP_ERR_VALUE_OUT_OF_RANGE;
            err_msg = BP_ERR_PARAM_CONV(percent, BP_ERR_PARAM_VAL_INVALID);
            goto exit;
        }
        /*if (((bypass_percent_t*)p_data)->duration <= 0 ||
            ((bypass_percent_t*)p_data)->duration > SWITCH_LIGHT_TEST_LIGHTNESS_TIME_MAX)
        {
            err_code = BP_ERR_VALUE_OUT_OF_RANGE;
            err_msg = BP_ERR_PARAM_CONV(duration, BP_ERR_PARAM_VAL_INVALID);
            goto exit;
        }*/
        switch_uart_test_min_lightness(((bypass_percent_t*)p_data)->percent,
            SWITCH_LIGHT_TEST_MIN_LIGHTNESS_TIME_S, p_msg_ctx->p_trace_msg);
    }
    else
    {
        err_code = BP_ERR_PARA_ILLEGAL;
        err_msg = BP_ERR_PARAM_CONV(dev_type, BP_ERR_PARAM_VAL_INVALID);
        goto exit;
    }

    return;
exit:
    vesync_bypass_reply_pkg_err_msg(err_code, p_msg_ctx->p_trace_msg, err_msg);
}

/**
 * @brief 设置灯最低亮度
 * @param[in]       p_msg_ctx       [bypass上下文]
 * @param[in]       p_Data          [传入数据]
 */
static void switch_bp_set_light_min_lightness(bypass_msg_ctx_t *p_msg_ctx, void *p_data)
{
    int err_code = BP_ERR_NO_ERR;
    const char* err_msg = NULL;

    if(NULL == p_msg_ctx || NULL == p_msg_ctx->p_trace_msg || NULL == p_msg_ctx->p_method_info || NULL == p_data)
    {
        err_code = BP_ERR_PARA_ILLEGAL;
        goto exit;
    }

    if (0 == strcmp(p_msg_ctx->p_method_info->dev_type, SWITCH_SUBDEVICE_TYPE_LIGHT_STR) &&
        SWITCH_SUBDEVICE_NO_LIGHT == p_msg_ctx->p_method_info->dev_idx)
    {
        if (((bypass_percent_t*)p_data)->percent < SWITCH_LIGHT_PERCENT_MIN ||
            ((bypass_percent_t*)p_data)->percent > SWITCH_LIGHT_PERCENT_MAX)
        {
            err_code = BP_ERR_VALUE_OUT_OF_RANGE;
            err_msg = BP_ERR_PARAM_CONV(percent, BP_ERR_PARAM_VAL_INVALID);
            goto exit;
        }
        switch_uart_set_min_lightness(((bypass_percent_t*)p_data)->percent, p_msg_ctx->p_trace_msg);
    }
    else
    {
        err_code = BP_ERR_PARA_ILLEGAL;
        err_msg = BP_ERR_PARAM_CONV(p_device, BP_ERR_PARAM_VAL_INVALID);
        goto exit;
    }

    return;
exit:
    vesync_bypass_reply_pkg_err_msg(err_code, p_msg_ctx->p_trace_msg, err_msg);
}

/**
 * @brief 设置灯亮度
 * @param[in]   p_msg_ctx       [bypass上下文]
 * @param[in]   p_Data          [传入数据]
 */
static void switch_bp_set_light_lightness(bypass_msg_ctx_t *p_msg_ctx, void *p_data)
{
    int err_code = BP_ERR_NO_ERR;
    const char* err_msg = NULL;

    if(NULL == p_msg_ctx || NULL == p_msg_ctx->p_trace_msg || NULL == p_msg_ctx->p_method_info || NULL == p_data)
    {
        err_code = BP_ERR_PARA_ILLEGAL;
        goto exit;
    }

    if (0 == strcmp(p_msg_ctx->p_method_info->dev_type, SWITCH_SUBDEVICE_TYPE_LIGHT_STR) &&
        SWITCH_SUBDEVICE_NO_LIGHT == p_msg_ctx->p_method_info->dev_idx)
    {
        if (((bypass_percent_t*)p_data)->percent < SWITCH_LIGHT_PERCENT_MIN ||
            ((bypass_percent_t*)p_data)->percent > SWITCH_LIGHT_PERCENT_MAX)
        {
            err_code = BP_ERR_VALUE_OUT_OF_RANGE;
            err_msg = BP_ERR_PARAM_CONV(percent, BP_ERR_PARAM_VAL_INVALID);
            goto exit;
        }
        switch_uart_set_lightness(((bypass_percent_t*)p_data)->percent,
            0, p_msg_ctx->p_trace_msg);
    }
    else
    {
        err_code = BP_ERR_PARA_ILLEGAL;
        err_msg = BP_ERR_PARAM_CONV(dev_type, BP_ERR_PARAM_VAL_INVALID);
        goto exit;
    }

    return;
exit:
    vesync_bypass_reply_pkg_err_msg(err_code, p_msg_ctx->p_trace_msg, err_msg);
}

/**
 * @brief 调整灯亮度
 * @param[in]   p_msg_ctx       [bypass上下文]
 * @param[in]   p_Data          [传入数据]
 */
static void switch_bp_adjust_light_lightness(bypass_msg_ctx_t *p_msg_ctx, void *p_data)
{
    int err_code = BP_ERR_NO_ERR;
    const char* err_msg = NULL;
    int16_t new_lightness = 0;

    if(NULL == p_msg_ctx || NULL == p_msg_ctx->p_trace_msg || NULL == p_msg_ctx->p_method_info || NULL == p_data)
    {
        err_code = BP_ERR_PARA_ILLEGAL;
        goto exit;
    }

    if (0 == strcmp(p_msg_ctx->p_method_info->dev_type, SWITCH_SUBDEVICE_TYPE_LIGHT_STR) &&
        SWITCH_SUBDEVICE_NO_LIGHT == p_msg_ctx->p_method_info->dev_idx)
    {
        new_lightness = switch_app_get_light_lightness() + ((bypass_adjust_percent_t*)p_data)->step;
        switch (((bypass_adjust_percent_t*)p_data)->rule)
        {
            case BP_PERCENT_RULE_NO_LOOP:
                if (new_lightness <= 0)
                {
                    new_lightness = SWITCH_LIGHT_PERCENT_MIN;
                }
                else if (new_lightness > SWITCH_LIGHT_PERCENT_MAX)
                {
                    new_lightness = SWITCH_LIGHT_PERCENT_MAX;
                }
                break;
            case BP_PERCENT_RULE_UP_LOOP:
                if (new_lightness <= 0)
                {
                    new_lightness = SWITCH_LIGHT_PERCENT_MIN;
                }
                else if (new_lightness > SWITCH_LIGHT_PERCENT_MAX)
                {
                    new_lightness = new_lightness % (SWITCH_LIGHT_PERCENT_MAX);
                    if (0 == new_lightness)
                    {
                        new_lightness = SWITCH_LIGHT_PERCENT_MAX;
                    }
                }
                break;
            default:
                err_code = BP_ERR_PARA_ILLEGAL;
                err_msg = BP_ERR_PARAM_CONV(rule, BP_ERR_PARAM_VAL_INVALID);
                goto exit;
        }

        switch_uart_set_lightness((uint8_t)new_lightness, 0, p_msg_ctx->p_trace_msg);
    }
    else
    {
        err_code = BP_ERR_PARA_ILLEGAL;
        err_msg = BP_ERR_PARAM_CONV(dev_type, BP_ERR_PARAM_VAL_INVALID);
        goto exit;
    }

    return;
exit:
    vesync_bypass_reply_pkg_err_msg(err_code, p_msg_ctx->p_trace_msg, err_msg);
}

/**
 * @brief bypass 添加Schedule
 * @param[in]       p_msg_ctx       [msg context]
 * @param[in]       p_data          [回调函数传入数据]
 */
static void switch_bp_add_schedule(bypass_msg_ctx_t *p_msg_ctx, void *p_data)
{
    int err_code = BP_ERR_NO_ERR;
    const char *err_msg = NULL;
    bypass_schedule_base_t *p_bp_sch = (bypass_schedule_base_t *)p_data;
    vesync_schedule_t sch_cfg;
    void *action = NULL;
    uint32_t sch_id = 0;
    cJSON *json_sch_ret = NULL;

    if(NULL == p_msg_ctx || NULL == p_msg_ctx->p_trace_msg || NULL == p_msg_ctx->p_method_info || NULL == p_data)
    {
        err_code = BP_ERR_PARA_ILLEGAL;
        goto exit;
    }

    // Enabled 是必选项
    // Repeat Config 是必选项
    // Type 是必选项
    if (NULL == p_bp_sch->enabled ||
        NULL == p_bp_sch->repeat_config ||
        NULL == p_bp_sch->type ||
        NULL == p_bp_sch->json_action)
    {
        err_code = BP_ERR_PARA_ILLEGAL;
        err_msg = BP_ERR_PARAM_CONV(p_bp_sch, BP_ERR_PARAM_VAL_INVALID);
        goto exit;
    }
    sch_cfg.enabled = (bool)*p_bp_sch->enabled;
    sch_cfg.repeat_config = (uint8_t)*p_bp_sch->repeat_config;

    switch (*p_bp_sch->type)
    {
        case BYPASS_SCHEDULE_JSON_TYPE_TMG_EVT:
            sch_cfg.type = SCHE_TMG_EVT;
            //
            if (NULL == p_bp_sch->clock_sec)
            {
                err_code = BP_ERR_PARA_ILLEGAL;
                err_msg = BP_ERR_PARAM_CONV(clock_sec, BP_ERR_PARAM_VAL_INVALID);
                goto exit;
            }
            sch_cfg.event_config.timing.clock_sec = (uint32_t)*p_bp_sch->clock_sec;
            break;
        case BYPASS_SCHEDULE_JSON_TYPE_SUN_EVT:
            sch_cfg.type = SCHE_SUN_EVT;
            //
            if (NULL == p_bp_sch->is_sunrise)
            {
                err_code = BP_ERR_PARA_ILLEGAL;
                err_msg = BP_ERR_PARAM_CONV(is_sunrise, BP_ERR_PARAM_VAL_INVALID);
                goto exit;
            }
            if (NULL == p_bp_sch->offset_sec)
            {
                err_code = BP_ERR_PARA_ILLEGAL;
                err_msg = BP_ERR_PARAM_CONV(offset_sec, BP_ERR_PARAM_VAL_INVALID);
                goto exit;
            }
            sch_cfg.event_config.sun.is_sunrise = (bool)*p_bp_sch->is_sunrise;
            sch_cfg.event_config.sun.offset_sec = (int32_t)*p_bp_sch->offset_sec;
            break;
        default:
            err_code = BP_ERR_PARA_ILLEGAL;
            err_msg = BP_ERR_PARAM_CONV(p_bp_sch, BP_ERR_PARAM_VAL_INVALID);
            goto exit;
    }
    if (0 == strcmp(p_msg_ctx->p_method_info->dev_type, SWITCH_SUBDEVICE_TYPE_LIGHT_STR) &&
        SWITCH_SUBDEVICE_NO_LIGHT == p_msg_ctx->p_method_info->dev_idx)
    {
        action = vesync_malloc(sizeof(light_action_t));
        if (NULL == action)
        {
            err_code = BP_ERR_OUT_OF_MEMORY;
            goto exit;
        }
        err_code = switch_bp_parse_light_action(p_bp_sch->json_action, action);
        if (BP_ERR_NO_ERR != err_code)
        {
            goto exit;
        }
        err_code = switch_schedule_add(DEVICE_LIGHT, &sch_cfg, action, &sch_id);
        if (BP_ERR_NO_ERR != err_code)
        {
            goto exit;
        }
    }
    else if (0 == strcmp(p_msg_ctx->p_method_info->dev_type, SWITCH_SUBDEVICE_TYPE_FAN_STR) &&
        SWITCH_SUBDEVICE_NO_FAN == p_msg_ctx->p_method_info->dev_idx)
    {
        action = vesync_malloc(sizeof(fan_action_t));
        if (NULL == action)
        {
            err_code = BP_ERR_OUT_OF_MEMORY;
            goto exit;
        }
        err_code = switch_bp_parse_fan_action(p_bp_sch->json_action, action);
        if (BP_ERR_NO_ERR != err_code)
        {
            goto exit;
        }
        err_code = switch_schedule_add(DEVICE_FAN, &sch_cfg, action, &sch_id);
        if (BP_ERR_NO_ERR != err_code)
        {
            goto exit;
        }
    }
    else
    {
        err_code = BP_ERR_PARA_ILLEGAL;
        err_msg = BP_ERR_PARAM_CONV(p_method_info, BP_ERR_PARAM_VAL_INVALID);
        goto exit;
    }

    if (BP_ERR_NO_ERR == err_code)
    {
        // 添加成功，生成回应
        json_sch_ret = cJSON_CreateObject();
        if (NULL != json_sch_ret)
        {
            cJSON_AddNumberToObject(json_sch_ret, "id", sch_id);
        }
    }
exit:
    VCOM_SAFE_FREE(action);
    if (BP_ERR_NO_ERR == err_code)
    {
        vesync_bypass_reply_noqos(err_code, p_msg_ctx->p_trace_msg, json_sch_ret);
    }
    else
    {
        vesync_bypass_reply_pkg_err_msg(err_code, p_msg_ctx->p_trace_msg, err_msg);
    }
}

/**
 * @brief bypass 更新Schedule
 * @param[in]       p_msg_ctx       [msg context]
 * @param[in]       p_data          [回调函数传入数据]
 */
static void switch_bp_upd_schedule(bypass_msg_ctx_t *p_msg_ctx, void *p_data)
{
    int err_code = BP_ERR_NO_ERR;
    const char *err_msg = NULL;
    bypass_schedule_base_t *p_bp_sch = (bypass_schedule_base_t *)p_data;
    vesync_schedule_t sch_cfg;
    DEVICE_ID_E dev_id = DEVICE_ALL;
    void *action = NULL;
    uint32_t sch_id = 0;
    cJSON *json_sch_ret = NULL;

    if(NULL == p_msg_ctx || NULL == p_msg_ctx->p_trace_msg || NULL == p_msg_ctx->p_method_info || NULL == p_data)
    {
        err_code = BP_ERR_PARA_ILLEGAL;
        goto exit;
    }

    sch_id = p_bp_sch->id;

    if (0 == strcmp(p_msg_ctx->p_method_info->dev_type, SWITCH_SUBDEVICE_TYPE_LIGHT_STR) &&
        SWITCH_SUBDEVICE_NO_LIGHT == p_msg_ctx->p_method_info->dev_idx)
    {
        dev_id = DEVICE_LIGHT;
    }
    else if (0 == strcmp(p_msg_ctx->p_method_info->dev_type, SWITCH_SUBDEVICE_TYPE_FAN_STR) &&
        SWITCH_SUBDEVICE_NO_FAN == p_msg_ctx->p_method_info->dev_idx)
    {
        dev_id = DEVICE_FAN;
    }
    else
    {
        err_code = BP_ERR_PARA_ILLEGAL;
        err_msg = BP_ERR_PARAM_CONV(p_method_info, BP_ERR_PARAM_VAL_INVALID);
        goto exit;
    }

    vesync_buf_t app_cfg_buf = vesync_buf_new();
    int ret = SCHE_OK;
    if (DEVICE_LIGHT == dev_id)
    {
        ret = vesync_schedule_get_by_id(SWITCH_SCHE_INS_LIGHT_ID, sch_id, &sch_cfg, &app_cfg_buf);
        if (NULL == p_bp_sch->json_action)
        {
            action = NULL;
        }
        else
        {
            action = vesync_malloc(sizeof(light_action_t));
            if (NULL == action)
            {
                err_code = BP_ERR_OUT_OF_MEMORY;
                goto exit;
            }
            err_code = switch_bp_parse_light_action(p_bp_sch->json_action, action);
            if (BP_ERR_NO_ERR != err_code)
            {
                goto exit;
            }
        }
        if (BP_ERR_NO_ERR != err_code)
        {
            goto exit;
        }
    }
    else if (DEVICE_FAN == dev_id)
    {
        ret = vesync_schedule_get_by_id(SWITCH_SCHE_INS_FAN_ID, sch_id, &sch_cfg, &app_cfg_buf);
        if (NULL == p_bp_sch->json_action)
        {
            action = NULL;
        }
        else
        {
            action = vesync_malloc(sizeof(fan_action_t));
            if (NULL == action)
            {
                err_code = BP_ERR_OUT_OF_MEMORY;
                goto exit;
            }
            err_code = switch_bp_parse_fan_action(p_bp_sch->json_action, action);
            if (BP_ERR_NO_ERR != err_code)
            {
                goto exit;
            }
        }
        if (BP_ERR_NO_ERR != err_code)
        {
            goto exit;
        }
    }
    vesync_buf_clr(&app_cfg_buf);
    if (ret != SCHE_OK)
    {
        if (ret != SCHE_INV_ID_ERR)
        {
            err_code = BP_ERR_CMD_EXECUTE_FAIL;
            goto exit;
        }

        err_code = BP_ERR_SCHEDULE_NOT_FOUND;
        goto exit;
    }

    // Enabled 是可选项
    sch_cfg.enabled = (NULL != p_bp_sch->enabled) ? (bool)*p_bp_sch->enabled : sch_cfg.enabled;
    // Repeat Config 是可选项
    sch_cfg.repeat_config = (NULL != p_bp_sch->repeat_config) ? (uint8_t)*p_bp_sch->repeat_config : sch_cfg.repeat_config;

    // Type 是可选项
    if (NULL != p_bp_sch->type)
    {
        switch (*p_bp_sch->type)
        {
            case BYPASS_SCHEDULE_JSON_TYPE_TMG_EVT:
                sch_cfg.type = SCHE_TMG_EVT;
                // Clock Second 是可选字段
                sch_cfg.event_config.timing.clock_sec = (NULL != p_bp_sch->clock_sec) ? (uint32_t)*p_bp_sch->clock_sec : sch_cfg.event_config.timing.clock_sec;
                break;
            case BYPASS_SCHEDULE_JSON_TYPE_SUN_EVT:
                sch_cfg.type = SCHE_SUN_EVT;
                // Is Sunrise 是可选字段
                sch_cfg.event_config.sun.is_sunrise = (NULL != p_bp_sch->is_sunrise) ? (bool)*p_bp_sch->is_sunrise : sch_cfg.event_config.sun.is_sunrise;
                // Offset 是可选字段
                sch_cfg.event_config.sun.offset_sec = (NULL != p_bp_sch->offset_sec) ? (int32_t)*p_bp_sch->offset_sec : sch_cfg.event_config.sun.offset_sec;
                break;
            default:
                err_code = BP_ERR_PARA_ILLEGAL;
                goto exit;
        }
    }

    err_code = switch_schedule_upd(dev_id, &sch_cfg, action, &sch_id);

    if (BP_ERR_NO_ERR == err_code)
    {
        // 添加成功，生成回应
        json_sch_ret = cJSON_CreateObject();
        if (NULL != json_sch_ret)
        {
            cJSON_AddNumberToObject(json_sch_ret, "id", sch_id);
        }
    }
exit:
    VCOM_SAFE_FREE(action);
    if (BP_ERR_NO_ERR == err_code)
    {
        vesync_bypass_reply_noqos(err_code, p_msg_ctx->p_trace_msg, json_sch_ret);
    }
    else
    {
        vesync_bypass_reply_pkg_err_msg(err_code, p_msg_ctx->p_trace_msg, err_msg);
    }
}

/**
 * @brief bypass 删除Schedule
 * @param[in]  p_msg_ctx                [msg context]
 * @param[in]  p_data                   [回调函数传入数据]
 */
static void switch_bp_del_schedule(bypass_msg_ctx_t *p_msg_ctx, void *p_data)
{
    int err_code = BP_ERR_NO_ERR;
    const char *err_msg = NULL;
    uint32_t sch_id = 0;
    cJSON *json_sch_ret = NULL;

    if(NULL == p_msg_ctx || NULL == p_msg_ctx->p_trace_msg || NULL == p_msg_ctx->p_method_info || NULL == p_data)
    {
        err_code = BP_ERR_PARA_ILLEGAL;
        goto exit;
    }

    sch_id = *((uint32_t *)p_data);

    if (0 == strcmp(p_msg_ctx->p_method_info->dev_type, SWITCH_SUBDEVICE_TYPE_LIGHT_STR) &&
        SWITCH_SUBDEVICE_NO_LIGHT == p_msg_ctx->p_method_info->dev_idx)
    {
        err_code = switch_schedule_del(DEVICE_LIGHT, sch_id);
    }
    else if (0 == strcmp(p_msg_ctx->p_method_info->dev_type, SWITCH_SUBDEVICE_TYPE_FAN_STR) &&
        SWITCH_SUBDEVICE_NO_FAN == p_msg_ctx->p_method_info->dev_idx)
    {
        err_code = switch_schedule_del(DEVICE_FAN, sch_id);
    }
    else
    {
        err_code = BP_ERR_PARA_ILLEGAL;
        err_msg = BP_ERR_PARAM_CONV(p_method_info, BP_ERR_PARAM_VAL_INVALID);
        goto exit;
    }
    if (BP_ERR_NO_ERR == err_code)
    {
        // 添加成功，生成回应
        json_sch_ret = cJSON_CreateObject();
        if (NULL != json_sch_ret)
        {
            cJSON_AddNumberToObject(json_sch_ret, "id", sch_id);
        }
    }
exit:
    if (BP_ERR_NO_ERR == err_code)
    {
        vesync_bypass_reply_noqos(err_code, p_msg_ctx->p_trace_msg, json_sch_ret);
    }
    else
    {
        vesync_bypass_reply_pkg_err_msg(err_code, p_msg_ctx->p_trace_msg, err_msg);
    }
}

/**
 * @brief 生成Schedule配置项的JSON
 * @param[in]       json_data       [JSON]
 * @param[in]       sch_cfg         [Schedule配置]
 * @return          int             [Bypass定义的错误]
 */
static int switch_bp_pack_sch_cfg_json(cJSON **json_data, vesync_schedule_t *sch_cfg)
{
    int err_code = BP_ERR_NO_ERR;
    cJSON *sub_obj = NULL;
    uint8_t type = sch_cfg->type;

    *json_data = cJSON_CreateObject();
    if (NULL == *json_data)
    {
        return BP_ERR_OUT_OF_MEMORY;
    }

    cJSON_AddNumberToObject(*json_data, "id", sch_cfg->id);
    cJSON_AddBoolToObject(*json_data, "enabled", sch_cfg->enabled);
    cJSON_AddNumberToObject(*json_data, "type", type);
    if (BYPASS_SCHEDULE_JSON_TYPE_TMG_EVT == type)
    {
        sub_obj = cJSON_AddObjectToObject(*json_data, "tmgEvt");
        if (NULL == sub_obj)
        {
            err_code = BP_ERR_OUT_OF_MEMORY;
            goto exit;
        }
        cJSON_AddNumberToObject(sub_obj, "clkSec", sch_cfg->event_config.timing.clock_sec);
    }
    else if (BYPASS_SCHEDULE_JSON_TYPE_SUN_EVT == type)
    {
        sub_obj = cJSON_AddObjectToObject(*json_data, "sunEvt");
        if (NULL == sub_obj)
        {
            err_code = BP_ERR_OUT_OF_MEMORY;
            goto exit;
        }
        cJSON_AddBoolToObject(sub_obj, "isRise", sch_cfg->event_config.sun.is_sunrise);
        cJSON_AddNumberToObject(sub_obj, "ofsSec", sch_cfg->event_config.sun.offset_sec);
    }

    cJSON_AddNumberToObject(*json_data, "repeat", sch_cfg->repeat_config);

exit:
    if (BP_ERR_NO_ERR != err_code)
    {
        cJSON_Delete(*json_data);
    }
    return err_code;
}

/**
 * @brief bypass 获取Schedule
 * @param[in]       p_msg_ctx       [msg context]
 * @param[in]       p_data          [回调函数传入数据]
 */
static void switch_bp_get_schedule(bypass_msg_ctx_t *p_msg_ctx, void *p_data)
{
    int err_code = BP_ERR_NO_ERR;
    const char *err_msg = NULL;
    vesync_schedule_t *sche_cfg = NULL;
    void *action = NULL;
    DEVICE_ID_E dev_id = DEVICE_ALL;
    uint32_t index = 0;
    uint32_t cur_num = 0;
    uint32_t total_num = 0;
    cJSON *json_sch_ret = NULL;
    cJSON *json_array = NULL;
    cJSON *json_sche = NULL;
    cJSON *json_acts = NULL;

    if(NULL == p_msg_ctx || NULL == p_msg_ctx->p_trace_msg || NULL == p_msg_ctx->p_method_info || NULL == p_data)
    {
        err_code = BP_ERR_PARA_ILLEGAL;
        goto exit;
    }

    index = *((uint32_t *)p_data);
    sche_cfg = vesync_malloc(SWITCH_SCHEDULE_GET_MAX_NUM * sizeof(vesync_schedule_t));
    if (NULL == sche_cfg)
    {
        err_code = BP_ERR_OUT_OF_MEMORY;
        goto exit;
    }

    if (0 == strcmp(p_msg_ctx->p_method_info->dev_type, SWITCH_SUBDEVICE_TYPE_LIGHT_STR) &&
        SWITCH_SUBDEVICE_NO_LIGHT == p_msg_ctx->p_method_info->dev_idx)
    {
        dev_id = DEVICE_LIGHT;
        action = (light_action_t*)vesync_malloc(SWITCH_SCHEDULE_GET_MAX_NUM * sizeof(light_action_t));
    }
    else if (0 == strcmp(p_msg_ctx->p_method_info->dev_type, SWITCH_SUBDEVICE_TYPE_FAN_STR) &&
        SWITCH_SUBDEVICE_NO_FAN == p_msg_ctx->p_method_info->dev_idx)
    {
        dev_id = DEVICE_FAN;
        action = (fan_action_t*)vesync_malloc(SWITCH_SCHEDULE_GET_MAX_NUM * sizeof(fan_action_t));
    }
    else
    {
        err_code = BP_ERR_PARA_ILLEGAL;
        err_msg = BP_ERR_PARAM_CONV(p_method_info, BP_ERR_PARAM_VAL_INVALID);
        goto exit;
    }

    if (NULL == action)
    {
        err_code = BP_ERR_OUT_OF_MEMORY;
        goto exit;
    }
    err_code = switch_schedule_get_mult(dev_id, index, sche_cfg, action, &cur_num, &total_num);

    if (BP_ERR_NO_ERR == err_code)
    {
        // 查询成功，生成回应
        json_sch_ret = cJSON_CreateObject();
        if (NULL == json_sch_ret)
        {
            err_code = BP_ERR_OUT_OF_MEMORY;
            goto exit;
        }
        cJSON_AddNumberToObject(json_sch_ret, "total", total_num);
        json_array = cJSON_AddArrayToObject(json_sch_ret, "schedules");
        if (NULL == json_array)
        {
            err_code = BP_ERR_OUT_OF_MEMORY;
            goto exit;
        }
        if (DEVICE_LIGHT == dev_id)
        {
            for (int i = 0; i < cur_num; ++i)
            {
                err_code = switch_bp_pack_sch_cfg_json(&json_sche, &sche_cfg[i]);
                if (BP_ERR_NO_ERR != err_code || NULL == json_sche)
                {
                    goto exit;
                }
                err_code = switch_bp_pack_light_action(&json_acts, (light_action_t*)action + i);
                if (BP_ERR_NO_ERR != err_code || NULL == json_acts)
                {
                    goto exit;
                }
                cJSON_AddItemToObject(json_sche, "startAct", json_acts);
                cJSON_AddItemToArray(json_array, json_sche);
            }
        }
        else if (DEVICE_FAN == dev_id)
        {
            for (int i = 0; i < cur_num; ++i)
            {
                err_code = switch_bp_pack_sch_cfg_json(&json_sche, &sche_cfg[i]);
                if (BP_ERR_NO_ERR != err_code || NULL == json_sche)
                {
                    goto exit;
                }
                err_code = switch_bp_pack_fan_action(&json_acts, (fan_action_t*)action + i);
                if (BP_ERR_NO_ERR != err_code || NULL == json_acts)
                {
                    goto exit;
                }
                cJSON_AddItemToObject(json_sche, "startAct", json_acts);
                cJSON_AddItemToArray(json_array, json_sche);
            }
        }
        else
        {
            err_code = BP_ERR_CMD_EXECUTE_FAIL;
            goto exit;
        }

    }
    else if (BP_ERR_SCHEDULE_NOT_FOUND == err_code)
    {
        err_code = BP_ERR_NO_ERR;

        // 生成空回应
        json_sch_ret = cJSON_CreateObject();
        if (NULL != json_sch_ret)
        {
            cJSON_AddNumberToObject(json_sch_ret, "total", total_num);
            cJSON_AddArrayToObject(json_sch_ret, "schedules");
        }
    }
    else
    {
        goto exit;
    }

    VCOM_SAFE_FREE(sche_cfg);
    VCOM_SAFE_FREE(action);
    vesync_bypass_reply_noqos(err_code, p_msg_ctx->p_trace_msg, json_sch_ret);
    return;
exit:
    VCOM_SAFE_FREE(sche_cfg);
    VCOM_SAFE_FREE(action);
    cJSON_Delete(json_sch_ret);
    vesync_bypass_reply_pkg_err_msg(err_code, p_msg_ctx->p_trace_msg, err_msg);
}

 /**
 * @brief 助眠和唤醒
 * @note  app自定义bypass method，第三方调用接口
 * @param[in]       p_msg_ctx       [bypass上下文]
 * @param[in]       json            [传入json]
 * @return          BYPASS_ERR_E
 */
static BYPASS_ERR_E switch_bypass_method_set_gradient_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    uint8_t lightness = 0;
    uint16_t duration = 0;

    if (NULL == p_msg_ctx || NULL == p_msg_ctx->p_trace_msg || NULL == p_msg_ctx->p_method_info || NULL == json)
    {
        return BP_ERROR;
    }

    if (0 != strcmp(p_msg_ctx->p_method_info->dev_type, SWITCH_SUBDEVICE_TYPE_LIGHT_STR) ||
        SWITCH_SUBDEVICE_NO_LIGHT != p_msg_ctx->p_method_info->dev_idx)
    {
        vesync_bypass_reply_pkg_err_msg(BP_ERR_PARA_ILLEGAL, p_msg_ctx->p_trace_msg, BP_ERR_PARAM_CONV(dev_type, BP_ERR_PARAM_VAL_INVALID));
        return BP_OK;
    }

    APP_LOG(LOG_DEBUG, "-------setGradient handle--------\n");
    char *out = cJSON_Print(json);
    if (NULL != out)
    {
        APP_LOG(LOG_DEBUG, "\n%s\n", out);
        VCOM_SAFE_FREE(out);
    }

    cJSON *json_data = cJSON_GetObjectItemCaseSensitive(json, "percent");
    if (cJSON_IsNumber(json_data))
    {
        lightness = json_data->valueint;
    }
    else
    {
        vesync_bypass_reply_pkg_err_msg(BP_ERR_PARA_ILLEGAL, p_msg_ctx->p_trace_msg, BP_ERR_PARAM_CONV(percent, BP_ERR_PARAM_VAL_INVALID));
        return BP_OK;
    }
    json_data = cJSON_GetObjectItemCaseSensitive(json, "duration");
    if (cJSON_IsNumber(json_data))
    {
        duration = json_data->valueint;
    }
    else
    {
        vesync_bypass_reply_pkg_err_msg(BP_ERR_PARA_ILLEGAL, p_msg_ctx->p_trace_msg, BP_ERR_PARAM_CONV(duration, BP_ERR_PARAM_VAL_INVALID));
        return BP_OK;
    }
    if (duration <=0 || duration > SWITCH_LIGHT_EXEC_LIGHTNESS_TIME_MAX)
    {
        return BP_ERR_ARG;
    }
    if (0 == lightness)
    {
        switch_uart_set_switch(DEVICE_LIGHT, 0, duration, p_msg_ctx->p_trace_msg);
        return BP_OK;
    }
    else if (lightness < SWITCH_LIGHT_PERCENT_MIN || lightness > SWITCH_LIGHT_PERCENT_MAX)
    {
        return BP_ERR_ARG;
    }
    else
    {
        switch_uart_set_lightness(lightness,
            duration, p_msg_ctx->p_trace_msg);
        return BP_OK;
    }

    return BP_ERROR;
}

/**
* @brief 设置调光模式
* @note  新增bypass method
* @param[in]        p_msg_ctx       [bypass上下文]
* @param[in]        json            [传入json]
* @return           BYPASS_ERR_E
*/
static BYPASS_ERR_E switch_bypass_method_set_light_mode_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    uint8_t mode = 0;

    if (NULL == p_msg_ctx || NULL == p_msg_ctx->p_trace_msg || NULL == p_msg_ctx->p_method_info || NULL == json)
    {
        return BP_ERROR;
    }

    if (0 != strcmp(p_msg_ctx->p_method_info->dev_type, SWITCH_SUBDEVICE_TYPE_LIGHT_STR) ||
        SWITCH_SUBDEVICE_NO_LIGHT != p_msg_ctx->p_method_info->dev_idx)
    {
        vesync_bypass_reply_pkg_err_msg(BP_ERR_PARA_ILLEGAL, p_msg_ctx->p_trace_msg, BP_ERR_PARAM_CONV(dev_type, BP_ERR_PARAM_VAL_INVALID));
        return BP_OK;
    }

    APP_LOG(LOG_DEBUG, "-------setMode handle--------\n");
    char *out = cJSON_Print(json);
    if (NULL != out)
    {
        APP_LOG(LOG_DEBUG, "\n%s\n", out);
        VCOM_SAFE_FREE(out);
    }

    cJSON *json_data = cJSON_GetObjectItemCaseSensitive(json, "mode");
    if (cJSON_IsNumber(json_data))
    {
        mode = json_data->valueint;
    }
    else
    {
        return BP_ERR_ARG;
    }
    if (mode <=0 || mode > SWITCH_LIGHT_MOD_MAX)
    {
        return BP_ERR_ARG;
    }
    switch_uart_set_light_mode(mode, p_msg_ctx->p_trace_msg);

    return BP_OK;
}

/**
* @brief 获取设备状态
* @note  新增bypass method
* @param[in]        p_msg_ctx       [bypass上下文]
* @param[in]        json            [传入json]
* @return           BYPASS_ERR_E
*/
static BYPASS_ERR_E switch_bypass_method_get_status_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    BYPASS_ERR_E ret = BP_OK;
    cJSON *json_data = NULL;
    cJSON *json_array = NULL;
    cJSON *json_status = NULL;

    if (NULL == p_msg_ctx || NULL == p_msg_ctx->p_trace_msg || NULL == p_msg_ctx->p_method_info || NULL == json)
    {
        return BP_ERROR;
    }

    json_data = cJSON_CreateObject();
    if (NULL == json_data)
    {
        return BP_ERR_NOMEM;
    }

    json_array = cJSON_AddArrayToObject(json_data, "data");
    if (NULL == json_array)
    {
        ret = BP_ERR_NOMEM;
        goto exit;
    }

    if (0 == strlen(p_msg_ctx->p_method_info->dev_type))
    {
        cJSON_AddNumberToObject(json_data, "total", 2);  // 总设备数量为2
        json_status = switch_light_pack_json();
        if (NULL == json_status)
        {
            ret = BP_ERR_NOMEM;
            goto exit;
        }
        cJSON_AddItemToArray(json_array, json_status);
        json_status = NULL;
        json_status = switch_fan_pack_json();
        if (NULL == json_status)
        {
            ret = BP_ERR_NOMEM;
            goto exit;
        }
        cJSON_AddItemToArray(json_array, json_status);
    }
    else if (0 == strcmp(p_msg_ctx->p_method_info->dev_type, SWITCH_SUBDEVICE_TYPE_LIGHT_STR) &&
        SWITCH_SUBDEVICE_NO_LIGHT == p_msg_ctx->p_method_info->dev_idx)
    {
        cJSON_AddNumberToObject(json_data, "total", 1);  // 查询设备数量为1
        json_status = switch_light_pack_json();
        if (NULL == json_status)
        {
            ret = BP_ERR_NOMEM;
            goto exit;
        }
        cJSON_AddItemToArray(json_array, json_status);
    }
    else if (0 == strcmp(p_msg_ctx->p_method_info->dev_type, SWITCH_SUBDEVICE_TYPE_FAN_STR) &&
        SWITCH_SUBDEVICE_NO_FAN == p_msg_ctx->p_method_info->dev_idx)
    {
        cJSON_AddNumberToObject(json_data, "total", 1);  // 查询设备数量为1
        json_status = switch_fan_pack_json();
        if (NULL == json_status)
        {
            ret = BP_ERR_NOMEM;
            goto exit;
        }
        cJSON_AddItemToArray(json_array, json_status);
    }
    else
    {
        vesync_bypass_reply_pkg_err_msg(BP_ERR_PARA_ILLEGAL, p_msg_ctx->p_trace_msg, BP_ERR_PARAM_CONV(dev_type, BP_ERR_PARAM_VAL_INVALID));
    }

exit:
    if (BP_OK == ret)
    {
        vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, json_data);
    }
    else
    {
        cJSON_Delete(json_data);
    }
    return ret;
}

/**
* @brief 新增timer
* @note  新增bypass method
* @param[in]        p_msg_ctx       [bypass上下文]
* @param[in]        json            [传入json]
* @return           BYPASS_ERR_E
*/
static BYPASS_ERR_E switch_bypass_method_add_timer_v2_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    BYPASS_ERR_E ret = BP_OK;
    DEVICE_ID_E dev_id = DEVICE_ALL;
    uint32_t total_sec = 0;
    uint16_t timer_id = 0;
    void* action = NULL;
    cJSON* json_data = NULL;
    cJSON* json_timer = NULL;

    if (NULL == p_msg_ctx || NULL == p_msg_ctx->p_trace_msg || NULL == p_msg_ctx->p_method_info || NULL == json)
    {
        return BP_ERROR;
    }

    APP_LOG(LOG_DEBUG, "-------addTimerV2 handle--------\n");

    if (0 == strcmp(p_msg_ctx->p_method_info->dev_type, SWITCH_SUBDEVICE_TYPE_LIGHT_STR) &&
        SWITCH_SUBDEVICE_NO_LIGHT == p_msg_ctx->p_method_info->dev_idx)
    {
        json_data = cJSON_GetObjectItemCaseSensitive(json, "total");
        if (cJSON_IsNumber(json_data))
        {
             total_sec = json_data->valueint;
        }
        else
        {
            ret = BP_ERR_ARG;
            goto exit;
        }
        json_data = cJSON_GetObjectItemCaseSensitive(json, "startAct");
        if (cJSON_IsArray(json_data))
        {
            action = vesync_malloc(sizeof(light_action_t));
            if (NULL == action)
            {
                vesync_bypass_reply_pkg_err_msg(BP_ERR_OUT_OF_MEMORY, p_msg_ctx->p_trace_msg, NULL);
                goto exit;
            }
            int err_code = switch_bp_parse_light_action(json_data, action);
            if (BP_ERR_NO_ERR == err_code)
            {
                dev_id = DEVICE_LIGHT;
            }
            else
            {
                vesync_bypass_reply_pkg_err_msg(err_code, p_msg_ctx->p_trace_msg, NULL);
                goto exit;
            }
        }
        else
        {
            ret = BP_ERR_ARG;
            goto exit;
        }
    }
    else if (0 == strcmp(p_msg_ctx->p_method_info->dev_type, SWITCH_SUBDEVICE_TYPE_FAN_STR) &&
        SWITCH_SUBDEVICE_NO_FAN == p_msg_ctx->p_method_info->dev_idx)
    {
        json_data = cJSON_GetObjectItemCaseSensitive(json, "total");
        if (cJSON_IsNumber(json_data))
        {
             total_sec = json_data->valueint;
        }
        else
        {
            ret = BP_ERR_ARG;
            goto exit;
        }
        json_data = cJSON_GetObjectItemCaseSensitive(json, "startAct");
        if (cJSON_IsArray(json_data))
        {
            action = vesync_malloc(sizeof(fan_action_t));
            if (NULL == action)
            {
                vesync_bypass_reply_pkg_err_msg(BP_ERR_OUT_OF_MEMORY, p_msg_ctx->p_trace_msg, NULL);
                goto exit;
            }
            int err_code = switch_bp_parse_fan_action(json_data, action);
            if (BP_ERR_NO_ERR == err_code)
            {
                dev_id = DEVICE_FAN;
            }
            else
            {
                vesync_bypass_reply_pkg_err_msg(err_code, p_msg_ctx->p_trace_msg, NULL);
                goto exit;
            }
        }
        else
        {
            ret = BP_ERR_ARG;
            goto exit;
        }
    }
    else
    {
        vesync_bypass_reply_pkg_err_msg(BP_ERR_PARA_ILLEGAL, p_msg_ctx->p_trace_msg, BP_ERR_PARAM_CONV(dev_type, BP_ERR_PARAM_VAL_INVALID));
        goto exit;
    }
    if (APP_OK == switch_timing_add(dev_id, action, total_sec, &timer_id) && 0!= timer_id)
    {
        json_timer = cJSON_CreateObject();
        if (NULL != json_timer)
        {
            cJSON_AddNumberToObject(json_timer, "id", timer_id);
            APP_LOG(LOG_DEBUG,"add timer %d\n", timer_id);
            vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, json_timer);
        }
        else
        {
            vesync_bypass_reply_noqos(BP_ERR_CMD_EXECUTE_FAIL, p_msg_ctx->p_trace_msg, json_timer);
        }
    }
    else
    {
        vesync_bypass_reply_pkg_err_msg(BP_ERR_CMD_EXECUTE_FAIL, p_msg_ctx->p_trace_msg, NULL);
        goto exit;
    }

exit:
    return ret;
}

/**
* @brief 获取timer
* @note  新增bypass method
* @param[in]        p_msg_ctx       [bypass上下文]
* @param[in]        json            [传入json]
* @return           BYPASS_ERR_E
*/
static BYPASS_ERR_E switch_bypass_method_get_timer_v2_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    BYPASS_ERR_E ret = BP_OK;
    uint16_t timer_id = 0;
    timing_data_t tm;
    const void* timing = NULL;
    DEVICE_ID_E dev_id = DEVICE_ALL;
    cJSON *json_data = NULL;
    cJSON *json_timers = NULL;
    cJSON *json_timer = NULL;
    cJSON *json_arr = NULL;

    if (NULL == p_msg_ctx || NULL == p_msg_ctx->p_trace_msg || NULL == p_msg_ctx->p_method_info)
    {
        return BP_ERROR;
    }
    UNUSED(json);

    json_data = cJSON_CreateObject();
    if (NULL == json_data)
    {
        return BP_ERR_NOMEM;
    }
    cJSON_AddItemToObject(json_data, "timers", json_timers =  cJSON_CreateArray());
    if (NULL == json_timers)
    {
        ret = BP_ERR_NOMEM;
        goto exit;
    }

    if (0 == strcmp(p_msg_ctx->p_method_info->dev_type, SWITCH_SUBDEVICE_TYPE_LIGHT_STR) &&
        SWITCH_SUBDEVICE_NO_LIGHT == p_msg_ctx->p_method_info->dev_idx)
    {
        dev_id = DEVICE_LIGHT;
    }
    else if (0 == strcmp(p_msg_ctx->p_method_info->dev_type, SWITCH_SUBDEVICE_TYPE_FAN_STR) &&
        SWITCH_SUBDEVICE_NO_FAN == p_msg_ctx->p_method_info->dev_idx)
    {
        dev_id = DEVICE_FAN;
    }
    else
    {
        ret = BP_ERR_ARG;
        goto exit;
    }
    if (APP_OK == switch_timing_get_act(dev_id, &timing) && NULL != timing)
    {
        if (DEVICE_LIGHT == dev_id)
        {
            timer_id = ((light_timing_t*)timing)->id;
        }
        else if (DEVICE_FAN == dev_id)
        {
            timer_id = ((fan_timing_t*)timing)->id;
        }
    }
    else
    {
        vesync_bypass_reply_pkg_err_msg(BP_ERR_CMD_EXECUTE_FAIL, p_msg_ctx->p_trace_msg, NULL);
        ret = BP_OK;
        goto exit;
    }
    if (0 != timer_id && SDK_OK == vesync_timing_get(timer_id, &tm))
    {
        cJSON_AddItemToArray(json_timers, json_timer = cJSON_CreateObject());
        if (NULL == json_timer)
        {
            ret = BP_ERR_NOMEM;
            goto exit;
        }
        cJSON_AddNumberToObject(json_timer, "id", tm.timing_id);
        cJSON_AddNumberToObject(json_timer, "total", tm.total_second);
        cJSON_AddNumberToObject(json_timer, "remain", tm.remain_second);
        if (APP_OK == switch_timing_get_act(dev_id, &timing) && NULL != timing)
        {

            int err_code = BP_ERR_CMD_EXECUTE_FAIL;
            if (DEVICE_LIGHT == dev_id)
            {
                err_code = switch_bp_pack_light_action(&json_arr, &((light_timing_t*)timing)->action);
            }
            else if (DEVICE_FAN == dev_id)
            {
                err_code = switch_bp_pack_fan_action(&json_arr, &((fan_timing_t*)timing)->action);
            }
            if (BP_ERR_NO_ERR == err_code && NULL != json_arr)
            {
                cJSON_AddItemToObject(json_timer, "startAct", json_arr);
            }
            else
            {
                vesync_bypass_reply_pkg_err_msg(err_code, p_msg_ctx->p_trace_msg, NULL);
                ret = BP_OK;
                goto exit;
            }
        }
        else
        {
            vesync_bypass_reply_pkg_err_msg(BP_ERR_CMD_EXECUTE_FAIL, p_msg_ctx->p_trace_msg, NULL);
            return BP_OK;
        }
    }

    vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, json_data);
    return BP_OK;

exit:
    cJSON_Delete(json_data);
    return ret;
}

/**
* @brief 删除timer
* @note  新增bypass method
* @param[in]        p_msg_ctx       [bypass上下文]
* @param[in]        json            [传入json]
* @return           BYPASS_ERR_E
*/
static BYPASS_ERR_E switch_bypass_method_del_timer_v2_handle(bypass_msg_ctx_t *p_msg_ctx, cJSON *json)
{
    if (NULL == p_msg_ctx || NULL == p_msg_ctx->p_trace_msg || NULL == p_msg_ctx->p_method_info || NULL == json)
    {
        return BP_ERROR;
    }

    cJSON *json_data = cJSON_GetObjectItemCaseSensitive(json, "id");
    if (cJSON_IsNumber(json_data))
    {
        if (APP_OK == switch_timing_remove(json_data->valueint))
        {
            cJSON *json_ret = cJSON_CreateObject();
            if (NULL != json_ret)
            {
                cJSON_AddNumberToObject(json_ret, "id", json_data->valueint);
            }
            vesync_bypass_reply_noqos(BP_ERR_NO_ERR, p_msg_ctx->p_trace_msg, json_ret);
        }
        else
        {
            vesync_bypass_reply_pkg_err_msg(BP_ERR_TIMER_NOT_FOUND, p_msg_ctx->p_trace_msg, "Timer remove fail");
        }
    }
    else
    {
        return BP_ERR_ARG;
    }

    return BP_OK;
}

static bypass_user_data_t switch_method_tbl[] = {
    {"getDeviceStatus", switch_bypass_method_get_status_handle},
    {"setGradient", switch_bypass_method_set_gradient_handle},
    {"setMode", switch_bypass_method_set_light_mode_handle},

    // timer
    {"addTimerV2", switch_bypass_method_add_timer_v2_handle},
    {"getTimerV2", switch_bypass_method_get_timer_v2_handle},
    {"delTimerV2", switch_bypass_method_del_timer_v2_handle}
};

/**
 * @brief 注册bypass回调函数
 */
void switch_bypass_reg_cb(void)
{
    // switch
    vesync_bypass_reg_method_cb(BYPASS_METHOD_ID_SET_SWITCH, switch_bp_set_switch);
    vesync_bypass_reg_method_cb(BYPASS_METHOD_ID_TOGGLE_SWITCH, switch_bp_toggle_switch);

    // level
    vesync_bypass_reg_method_cb(BYPASS_METHOD_ID_SET_LEVEL, switch_bp_set_level);

    // range
    vesync_bypass_reg_method_cb(BYPASS_METHOD_ID_ADJUST_REAL_RANGE_V2, switch_bp_adjust_level);

    // percent
    vesync_bypass_reg_method_cb(BYPASS_METHOD_ID_SET_PERCENT, switch_bp_set_light_lightness);
    vesync_bypass_reg_method_cb(BYPASS_METHOD_ID_TEST_MIN_PERCENT, switch_bp_test_light_min_lightness);
    vesync_bypass_reg_method_cb(BYPASS_METHOD_ID_SET_MIN_PERCENT, switch_bp_set_light_min_lightness);
    vesync_bypass_reg_method_cb(BYPASS_METHOD_ID_ADJUST_PERCENT, switch_bp_adjust_light_lightness);

    // Schedule
    vesync_bypass_reg_method_cb(BYPASS_METHOD_ID_ADD_SCHEDULE_V3, switch_bp_add_schedule);
    vesync_bypass_reg_method_cb(BYPASS_METHOD_ID_UPD_SCHEDULE_V3, switch_bp_upd_schedule);
    vesync_bypass_reg_method_cb(BYPASS_METHOD_ID_DEL_SCHEDULE_V3, switch_bp_del_schedule);
    vesync_bypass_reg_method_cb(BYPASS_METHOD_ID_GET_SCHEDULES_V3, switch_bp_get_schedule);

    for (int i = 0; i < SIZEOF_ARRAY(switch_method_tbl); i++)
    {
        vesync_bypass_add_user_item(&switch_method_tbl[i]);
    }
}

