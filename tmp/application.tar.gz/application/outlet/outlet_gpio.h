/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        outlet_gpio.h
 * @brief       outlet gpio配置
 * @author      Joshua
 * @date        2021-06-18
 */

#ifndef __OUTLET_GPIO_H__
#define __OUTLET_GPIO_H__

#include <stdbool.h>
#include "outlet_board.h"

#ifdef __cplusplus
extern "C" {
#endif


#if defined(OUTLET_ELEC_METERING) && (OUTLET_ELEC_METERING == 1)
#define OUTLET_SWITCH_USED_ELEC_UNIT  OUTLET_METERING_ELEC_UNIT1
#endif

/**
 * @brief 开关的按键/指示灯动作(控制)来源
 */
typedef enum
{
    OUTLET_ACT_SRC_INIT = 0,        // 按键/指示灯控制来源：初始化
    OUTLET_ACT_SRC_BTN,             // 按键/指示灯控制来源：按键执行
    OUTLET_ACT_SRC_APP,             // 按键/指示灯控制来源：APP、第三方控制
    OUTLET_ACT_SRC_TASK,            // 按键/指示灯控制来源：schedule、timer、away
#if defined(OUTLET_ELEC_METERING) && (OUTLET_ELEC_METERING == 1)
    OUTLET_ACT_SRC_LOW_POW_TRIG,
    OUTLET_ACT_SRC_HIGH_POW_TRIG,
    OUTLET_ACT_SRC_ELEC_SAVE_OVER,
    OUTLET_ACT_SRC_ELEC_SAVE_TICK,
    OUTLET_ACT_SRC_ELEC_SAVE_CLOCK,
    OUTLET_ACT_SRC_ELEC_SAVE_UPD_TS,
#endif
    OUTLET_ACT_SRC_RESET,           // 按键/指示灯控制来源：删除设备、恢复出厂
    OUTLET_ACT_SRC_UNKNOW,          // 按键/指示灯控制来源：未知
} OUTLET_ACT_SRC_E;


/**
 * @brief 初始化GPIO
 */
void outlet_init_gpio(void);

/**
 * @brief Wi-Fi灯开启/关闭
 * @param[in]   bool            [true时，指示灯开关；false时，指示灯关闭]
 */
void outlet_set_wifi_led_onoff(bool on);

/**
 * @brief 获取开关状态(开启/关闭)
 */
bool outlet_get_switch_onoff(void);

/**
 * @brief 开关翻转
 */
void outlet_set_switch_toggle();

/**
 * @brief 开关开启/关闭
 * @param[in]   bool            [true时，开启开关；false时，关闭开关]
 */
void outlet_set_switch_onoff(bool on);

/**
 * @brief 禁用开关
 */
void outlet_disable_switch(void);

/**
 * @brief 获取硬件保护状态(开启/关闭)
 */
bool outlet_get_protect_status(void);

/**
 * @brief 使能指示灯
 */
void outlet_enable_indicator(void);

/**
 * @brief 禁用指示灯
 */
void outlet_disable_indicator(void);

/**
 * @brief 获取指示灯状态(亮/灭)
 * @return      bool            [true为开关开启，false为开关关闭]
 */
bool outlet_get_indicator_onoff(void);



#ifdef __cplusplus
}
#endif

#endif

