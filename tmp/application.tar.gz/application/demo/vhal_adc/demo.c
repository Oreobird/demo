/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        demo.c
 * @brief       adc demo
 * @author      Lind
 * @date        2021-12-23
 */

#include <stdio.h>

#include "vesync_init.h"
#include "vesync_log.h"
#include "vesync_cfg.h"
#include "vesync_task.h"
#include "vesync_common.h"

#include "vhal_adc.h"

#define test_rx_io (1)

static void demo_pre_cb(void)
{
    APP_LOG(LOG_DEBUG, "Demo pre init callback\n");

    // 设置VeSync SDK的产品配置参数
    vesync_cfg_set_config_model("demo_config_model");
    vesync_cfg_set_authkey("demo_authkey");
    vesync_cfg_set_ble_name("demo_ble_name");
}

void demo_adc_init(void)
{
    uint8_t adc_io = test_rx_io;
    if (vhal_adc_dma_init(&adc_io, 1,20000))
    {
        APP_LOG(LOG_ERROR, "adc init failed\n");
    }
}

void demo_adc_test(void)
{
    adc_data_t adc_data[256] = {0};
    uint16_t data_num = 0;
    int cycle_num = 20;
    while (cycle_num)
    {
        uint32_t data = 0;
        uint32_t num = 0;
        vhal_adc_dma_get_data(adc_data, 256, &data_num, 50);
        for (uint16_t i = 0; i < data_num; i++)
        {
            if (adc_data[i].data > 2500)
            {
                num++;
                data += adc_data[i].data;
            }
        }
        if (num > 0)
        {
            cycle_num--;
            APP_LOG(LOG_DEBUG, "adc data avg [%d]\n", data / num);
        }
        vesync_sleep(10);
    }
}

static void demo_app_run(void)
{
    APP_LOG(LOG_INFO, "Vesync APP Demo start\n");
    demo_adc_init();
    demo_adc_test();
}



void app_main(void)
{
    vesync_sdk_reg_pre_run_cb(demo_pre_cb);
    vesync_sdk_reg_post_run_cb(demo_app_run);

    vesync_sdk_run();
}

