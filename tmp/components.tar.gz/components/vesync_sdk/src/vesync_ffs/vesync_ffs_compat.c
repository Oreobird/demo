/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_ffs_compat.c
 * @brief       ffs SDK中compat层API实现
 * @author      Dongri.Su
 * @date        20120-02-28
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <time.h>
#include <mbedtls/sha256.h>
#include "mbedtls/md.h"
#include "mbedtls/ecdh.h"
#include "mbedtls/entropy.h"
#include "mbedtls/ctr_drbg.h"
#include "mbedtls/ecdsa.h"
#include "mbedtls/platform.h"

#include "ffs/common/ffs_logging.h"
#include "ffs/compat/ffs_common_compat.h"
#include "ffs/compat/ffs_wifi_provisionee_compat.h"
#include "ffs/compat/ffs_dss_client_compat.h"
//#include "ffs/compat/ffs_user_context.h"
#include "ffs/common/ffs_http.h"
#include "ffs/common/ffs_result.h"
#include "ffs/common/ffs_stream.h"
#include "ffs/common/ffs_wifi.h"
#include "ffs/common/ffs_check_result.h"
#include "ffs/common/ffs_log_level.h"
#include "vesync_ffs_user_context.h"
#include "vhal_utils.h"
#include "vhal_wifi.h"
#include "vesync_memory.h"
#include "vesync_common.h"
#include "vesync_log_internal.h"
#include "vesync_net_service_internal.h"
#include "vesync_ffs_crypto.h"
#if 1 //CONFIG_VESYNC_SDK_HTTP_ENABLE
#include "vesync_http_internal.h"
#include "vesync_https_internal.h"
#endif
#include "vesync_common.h"
#include "vesync_ffs_internal.h"
#include "ffs_wifi_connection_attempt_list.h"
#include "ffs_wifi_configuration_list.h"
#include "ffs_pem_file.h"
#include "cJSON.h"

// 宏定义
#define FFS_MAX_TIME_PER_WIFI_CONNECT_SEC (20) // 每个WiFi ssid连接最大时间，单位：秒
#define HEADER_LINE_SEPARATOR ':'

// 全局变量/静态变量
/**
 * @brief Curl callback data.
 */
typedef struct
{
    FfsHttpRequest_t *request; //!< Original request.
    void *callbackDataPointer; //!< Data for the request callbacks.
} FfsHttpClientCallbackData_t;

// 内部函数/静态函数声明
static FFS_LOG_LEVEL currentLogLevel = FFS_LOG_LEVEL_DEBUG;

#if 0
uint32_t last_timestamp = 0;
uint32_t total_timestamp = 0;

/**
 * @brief: print current time and past_time
 * @param void
 * @return void
 */
void print_current_time_and_past_time(void)
{
    SDK_LOG(LOG_DEBUG, "utc %d \n", vhal_utils_get_system_time_sec());
    uint32_t curr_timestamp = esp_timer_get_time() / 1000000;
#define TEST_VESYNC_SYSTEM_MIN_TS 1
    if (curr_timestamp > TEST_VESYNC_SYSTEM_MIN_TS)
    {

        if (last_timestamp > TEST_VESYNC_SYSTEM_MIN_TS)
        {
            total_timestamp += curr_timestamp - last_timestamp;
            SDK_LOG(LOG_DEBUG, "the past time is: %d. total time is %d\n", curr_timestamp - last_timestamp, total_timestamp);
        }
        else
        {
            SDK_LOG(LOG_DEBUG, "The start time is: %d.\n", curr_timestamp);
        }
        last_timestamp = curr_timestamp;
    }
}
#else
void print_current_time_and_past_time(void)
{
}
#endif

/**
 * @brief: Set the current log level.
 * @param FFS_LOG_LEVEL
 * @return void
 */
void ffsSetLogLevel(FFS_LOG_LEVEL logLevel)
{
    currentLogLevel = logLevel;
}

/* ========== ffs_common_compat.h ========== */
/**
 * @brief Log a message.
 *
 * Add a line to the log at the specified logging level (info, debug, warning
 * or error).
 *
 * @param logLevel Logging level
 * @param functionName (the name of the function logging this message)
 * @param lineNumber (the number of the line on which the the logging function appears)
 * @param format printf-style format string
 * @param ... arguments to be logged in the specified format
 *
 * @note The "functionName" string may be null, in which case it should be omitted.
 * @note "lineNumber" may be 0, in which case it should be omitted.
 * @note The "format" string should not include any line
 * termination characters (carriage-return and/or line-feed). These should be
 * added if necessary according to the requirements of the target system.
 *
 * @returns Enumerated [result](@ref FFS_RESULT)
 */
FFS_RESULT ffsLog(FFS_LOG_LEVEL logLevel, const char *functionName, int lineNumber, const char *format, ...)
{
    if (logLevel < currentLogLevel)
    {
        return FFS_SUCCESS;
    }

    // Print the log level.
    switch (logLevel)
    {
    case FFS_LOG_LEVEL_DEBUG:
        printf("[DEBUG]");
        break;
    case FFS_LOG_LEVEL_INFO:
        printf("[INFO]");
        break;
    case FFS_LOG_LEVEL_WARNING:
        printf("[WARNING]");
        break;
    case FFS_LOG_LEVEL_ERROR:
        printf("[ERROR]");
        break;
    default:
        FFS_FAIL(FFS_ERROR);
    }

    printf(" ");

    // Print the function name and line number.
    if (functionName)
    {
        printf("%s:%d: ", functionName, lineNumber);
    }

    // Print the data.
    va_list args;
    va_start(args, format);
    vprintf(format, args);
    va_end(args);

    // Terminate the line.
    printf("\n");
    return FFS_SUCCESS;
}

/**
 * @brief Generate a sequence of random bytes.
 *
 * Generate cryptographic-quality random bytes up to the capacity of the output
 * stream.
 *
 * @param userContext User context
 * @param randomStream Output stream
 *
 * @returns Enumerated [result](@ref FFS_RESULT)
 */
FFS_RESULT ffsRandomBytes(struct FfsUserContext_s *userContext, FfsStream_t *randomStream)
{
    (void)userContext;
#if 0
    while (!ffsStreamIsFull(randomStream)) {
        uint8_t randomByte = rand() % 0xFF;
        FFS_CHECK_RESULT(ffsWriteByteToStream(randomByte, randomStream));
    }
#else
    if (!randomStream)
    {
        ffsLogError("input params find NULL");
        FFS_FAIL(FFS_OVERRUN);
    }
    uint8_t randomByte = 0;
    while (!ffsStreamIsFull(randomStream))
    {
        vhal_utils_get_random(&randomByte, 1);
        FFS_CHECK_RESULT(ffsWriteByteToStream(randomByte, randomStream));
    }
#endif
    return FFS_SUCCESS;
}

/**
 * @brief Calculate a SHA256 hash.
 *
 * Calculate a SHA256 hash. The input and output buffers can overlap. The
 * input stream is not affected otherwise.
 *
 * @param userContext User context
 * @param dataStream Input data stream
 * @param hashStream Output stream for the SHA256 hash
 *
 * @returns Enumerated [result](@ref FFS_RESULT)
 */
FFS_RESULT ffsSha256(struct FfsUserContext_s *userContext, FfsStream_t *dataStream, FfsStream_t *hashStream)
{
    (void)userContext;
    if (!hashStream || !dataStream)
    {
        ffsLogError("input params find NULL");
        FFS_FAIL(FFS_OVERRUN);
    }
    uint8_t hash[SHA256_DIGEST_LENGTH + 2];
    memset(hash, 0, sizeof(hash));
    mbedtls_sha256(FFS_STREAM_NEXT_READ(*dataStream), FFS_STREAM_DATA_SIZE(*dataStream), hash, 0);

    //print
    vesync_ffs_dump_buf("hash", hash, sizeof(hash));

    FFS_CHECK_RESULT(ffsWriteStream(hash, SHA256_DIGEST_LENGTH, hashStream));

    return FFS_SUCCESS;
}

/**
 * @brief Calculate a HMAC-SHA256 MAC.
 *
 * Calculate a HMAC-SHA256 hmac using the given key and data.
 *
 * @param userContext User context
 * @param secretKeyStream Input secret key stream
 * @param dataStream The data to be used to compute the HMAC
 * @param hmacStream Output stream for the HMAC value
 *
 * @returns Enumerated [result](@ref FFS_RESULT)
 */
FFS_RESULT ffsComputeHMACSHA256(struct FfsUserContext_s *userContext, FfsStream_t *secretKeyStream, FfsStream_t *dataStream, FfsStream_t *hmacStream)
{
    (void)userContext;
    if (!hmacStream || !dataStream || !secretKeyStream)
    {
        ffsLogError("input params find NULL");
        FFS_FAIL(FFS_OVERRUN);
    }
    unsigned char digest[SHA256_DIGEST_LENGTH + 2];
    mbedtls_md_context_t sha_ctx;

    mbedtls_md_init(&sha_ctx);
    memset(digest, 0, sizeof(digest));
    int ret = mbedtls_md_setup(&sha_ctx, mbedtls_md_info_from_type(MBEDTLS_MD_SHA256), 1);
    if (ret != 0)
    {
        mbedtls_md_free(&sha_ctx);
        ffsLogError("Failed to Compute HMAC.");
        FFS_FAIL(FFS_ERROR);
    }

    mbedtls_md_hmac_starts(&sha_ctx, FFS_STREAM_NEXT_READ(*secretKeyStream), FFS_STREAM_DATA_SIZE(*secretKeyStream));
    mbedtls_md_hmac_update(&sha_ctx, FFS_STREAM_NEXT_READ(*dataStream), FFS_STREAM_DATA_SIZE(*dataStream));
    mbedtls_md_hmac_finish(&sha_ctx, digest);

    mbedtls_md_free(&sha_ctx);
    FFS_CHECK_RESULT(ffsWriteStream(digest, SHA256_DIGEST_LENGTH, hmacStream));
    return FFS_SUCCESS;
}

/**
 * @brief Calculate a shared secret using ECDH
 *
 * Calculate a shared secret key using ECDH. The public key is the cloud public key.
 * The private key should be of the provisionee. It is expected that the provisionee
 * has access to it's own private key.
 *
 * @param userContext User context
 * @param publicKeyStream The public part of the input
 * @param secretKeyStream The output shared secret stream
 *
 * @returns Enumerated [result](@ref FFS_RESULT)
 */
FFS_RESULT ffsComputeECDHKey(struct FfsUserContext_s *userContext, FfsStream_t *publicKeyStream, FfsStream_t *secretKeyStream)
{
    if (!userContext || !publicKeyStream || !secretKeyStream)
    {
        ffsLogError("input params find NULL");
        FFS_FAIL(FFS_OVERRUN);
    }

    ffsLogDebug("ffsComputeECDHKey:\r\n");
    uint8_t secret_buf[100];
    FfsKeyContext_t private_key = {
        .buf = userContext->devicePrivateKey.buf,
        .len = userContext->devicePrivateKey.len};

    FfsKeyContext_t public_key = {
        .buf = (uint8_t *)FFS_STREAM_NEXT_READ(*publicKeyStream),
        .len = FFS_STREAM_DATA_SIZE(*publicKeyStream)};
    FfsKeyContext_t secret_key = {
        .buf = secret_buf,
        .len = sizeof(secret_buf)};

    VESYNC_ASSERT(vesync_ffs_compute_ecdh_key(&private_key, &public_key, &secret_key));
    FfsStream_t sharedSecretStream = ffsCreateInputStream(secret_key.buf, secret_key.len);
    ffsLogStream("Shared secret before hash", &sharedSecretStream);

    /* Now sha256 hash the shared secret to generate the ultimate secret key. */
    FFS_CHECK_RESULT(ffsSha256(userContext, &sharedSecretStream, secretKeyStream));
    return FFS_SUCCESS;

exit:
    return FFS_ERROR;
}

/**
 * @brief Set a configuration value (\a e.g., country code).
 *
 * @param userContext User context
 * @param configurationKey The configuration key string
 * @param configurationValue The conf122iguration value to set
 *
 * @returns Enumerated [result](@ref FFS_RESULT)
 */
FFS_RESULT ffsSetConfigurationValue(struct FfsUserContext_s *userContext,
                                    const char *configurationKey, FfsMapValue_t *configurationValue)
{
    if (!userContext || !configurationKey || !configurationValue)
    {
        ffsLogError("input params find NULL");
        FFS_FAIL(FFS_OVERRUN);
    }
    FFS_CHECK_RESULT(ffsSetConfigurationMapValue(userContext, configurationKey, configurationValue));
    return FFS_SUCCESS;
}

/**
 * @brief Get a configuration value (\a e.g., country code).
 *
 * Retrieve a configuration value. Not used in all flows.
 *
 * For non-stream values (integer and boolean), the destination map object is
 * simply updated.
 *
 * For stream values (bytes and string), the type field of the destination
 * object will be updated and the payload written to the corresponding stream
 * field. If the stream field is not writable the function will return
 * \ref FFS_ERROR.
 *
 * If the value is not available, this function should return
 * \ref FFS_NOT_IMPLEMENTED.
 *
 * @param userContext User context
 * @param configurationKey The configuration key string
 * @param configurationValue The destination configuration value
 *
 * @returns Enumerated [result](@ref FFS_RESULT)
 */
FFS_RESULT ffsGetConfigurationValue(struct FfsUserContext_s *userContext,
                                    const char *configurationKey, FfsMapValue_t *configurationValue)
{

    if (!userContext || !configurationKey || !configurationValue)
    {
        ffsLogError("input params find NULL");
        FFS_FAIL(FFS_OVERRUN);
    }
    FFS_CHECK_RESULT(ffsGetConfigurationMapValue(userContext, configurationKey, configurationValue));
    return FFS_SUCCESS;
}

/**
 * @brief Set the registration token (session ID).
 *
 * @param userContext User context
 * @param registrationRequest Registration request structure containing token
 *
 * @returns Enumerated [result](@ref FFS_RESULT)
 */
FFS_RESULT ffsSetRegistrationToken(struct FfsUserContext_s *userContext, FfsRegistrationRequest_t *registrationRequest)
{
    if (!userContext)
    {
        ffsLogError("input params find NULL");
        FFS_FAIL(FFS_OVERRUN);
    }
    if (!registrationRequest || ffsStreamIsEmpty(&registrationRequest->tokenStream))
    {
        ffsLogError("tokenStream is NULL");
        FFS_FAIL(FFS_NOT_IMPLEMENTED); //??
    }
    FFS_CHECK_RESULT(ffsFlushStream(&userContext->registrationRequest.tokenStream));
    FFS_CHECK_RESULT(ffsAppendStream(&registrationRequest->tokenStream, &userContext->registrationRequest.tokenStream));
    ffsLogStream("Storing registration token:", &registrationRequest->tokenStream);
    // ffsRewindStream(&registrationRequest->tokenStream);
    // ffs_set_sessionToken(( char*) FFS_STREAM_NEXT_READ(userContext->registrationRequest.tokenStream),
    //                 FFS_STREAM_DATA_SIZE(userContext->registrationRequest.tokenStream));
    return FFS_SUCCESS;
}

/**
 * @brief Get the registration token.
 *
 * Copy the registration token into the given output stream. Not used in all flows.
 *
 * @param userContext User context
 * @param tokenStream Destination registration token stream
 *
 * @returns Enumerated [result](@ref FFS_RESULT)
 */
FFS_RESULT ffsGetRegistrationToken(struct FfsUserContext_s *userContext,
                                   FfsStream_t *tokenStream)
{
    if (!userContext)
    {
        ffsLogError("input params find NULL");
        FFS_FAIL(FFS_OVERRUN);
    }

    if (!tokenStream || ffsStreamIsEmpty(&userContext->registrationRequest.tokenStream))
    {
        ffsLogError("tokenStream is NULL");
        FFS_FAIL(FFS_NOT_IMPLEMENTED); //??
    }
    //tokenStream = &userContext->registrationRequest.tokenStream;
    memcpy(tokenStream, &userContext->registrationRequest.tokenStream, sizeof(userContext->registrationRequest.tokenStream));

    return FFS_SUCCESS;
}

/**
 *  @brief Get the current registration status.
 *
 * @param userContext User context
 * @param registrationDetails Destination registration details object
 *
 * @returns Enumerated [result](@ref FFS_RESULT)
 */
FFS_RESULT ffsGetRegistrationDetails(struct FfsUserContext_s *userContext, FfsRegistrationDetails_t *registrationDetails)
{
    (void)userContext;
    if (!registrationDetails)
    {
        ffsLogError("input params find NULL");
        FFS_FAIL(FFS_OVERRUN);
    }
    registrationDetails->state = FFS_REGISTRATION_STATE_COMPLETE;
    return FFS_SUCCESS;
}

/**
 * @brief Verify a cloud signature.
 *
 * Verify a signature obtained by the provisioner from the cloud. The public
 * key is assumed to be known by the provisionee.
 *
 * @param userContext User context
 * @param payloadStream Input payload stream
 * @param signatureStream Input signature to be verified
 * @param isVerified Set to true if the signature is valid; set to false otherwise
 *
 * @returns Enumerated [result](@ref FFS_RESULT)
 */
FFS_RESULT ffsVerifyCloudSignature(struct FfsUserContext_s *userContext, FfsStream_t *payloadStream,
                                   FfsStream_t *signatureStream, bool *isVerified)
{
    if (!userContext || !payloadStream || !signatureStream || !isVerified)
    {
        ffsLogError("input params find NULL");
        FFS_FAIL(FFS_OVERRUN);
    }

    mbedtls_ecdsa_context ecdsa;
    mbedtls_ecp_keypair public_keypair;
    uint8_t hash[SHA256_DIGEST_LENGTH + 2] = {0};

    memset(hash, 0, sizeof(hash));
    //init the ecdsa context
    mbedtls_ecdsa_init(&ecdsa);
    mbedtls_ecp_keypair_init(&public_keypair);

    //get publiky from cloudPublicKey
    VESYNC_ASSERT(vesync_ffs_load_public_key(MBEDTLS_ECP_DP_SECP256R1,
                                             &public_keypair,
                                             userContext->cloudPublicKey.buf,
                                             userContext->cloudPublicKey.len));
    //get hash from payload
    mbedtls_sha256((const unsigned char *)FFS_STREAM_NEXT_READ(*payloadStream), FFS_STREAM_DATA_SIZE(*payloadStream), hash, 0);
    vesync_ffs_dump_buf("  + Hash:", hash, strlen((char *)hash));

    VESYNC_ASSERT(mbedtls_ecdsa_genkey(&ecdsa, MBEDTLS_ECP_DP_SECP256R1, vesync_ffs_rand, NULL));
    // copy Q
    VESYNC_ASSERT(mbedtls_ecp_copy(&ecdsa.Q, &public_keypair.Q));
    ffsLogStream("signatureStream", signatureStream);
    // HASH + Q -> r compare with SIG.r
    VESYNC_ASSERT(mbedtls_ecdsa_read_signature(&ecdsa,
                                               hash, sizeof(hash),
                                               (unsigned char *)FFS_STREAM_NEXT_READ(*signatureStream),
                                               FFS_STREAM_DATA_SIZE(*signatureStream)));

    *isVerified = true;
    SDK_LOG(LOG_DEBUG, "verify succed!\n");
    mbedtls_ecdsa_free(&ecdsa);
    return FFS_SUCCESS;

exit:
    SDK_LOG(LOG_DEBUG, "verify failed!\n");
    mbedtls_ecdsa_free(&ecdsa);
    mbedtls_ecp_keypair_free(&public_keypair);
    return FFS_ERROR;
}

/*
void ffs_get_sessionId_from_Body_message(char *pMsg)
{
    cJSON *root = cJSON_Parse(pMsg);
    if(NULL == root)
    {
        return;
    }
    cJSON* json_data = cJSON_GetObjectItemCaseSensitive(root, "configuration");    //解析 configuration
    if(json_data)
    {
        cJSON* json_trceid = cJSON_GetObjectItemCaseSensitive(json_data, "FFS.SessionToken");    //解析 SessionToken
        if(cJSON_IsString(json_trceid))
        {
            uint8_t len = strlen(json_trceid->valuestring);
            SDK_LOG(LOG_DEBUG, "SessionToken : %s\r\n",json_trceid->valuestring);
            if(len)
            {
                vesync_ffs_set_session_token(json_trceid->valuestring, len);
            }
        }
    }

    cJSON_Delete(root);
}
*/

/**
 * @brief Handle a response body.
 *
 * @param buffer Response data buffer.
 * @param itemSize Always 1
 * @param itemCount Size of data
 * @param httpClientCallbackData HTTP client callback data
 *
 * @returns Size of the data processed or 0 on failure
 */
static size_t ffsHttpHandleResponseBody(char *buffer, size_t itemSize,
                                        FfsHttpClientCallbackData_t *httpClientCallbackData)
{
    if (!buffer || !httpClientCallbackData)
    {
        ffsLogError("input params find NULL");
        FFS_FAIL(FFS_OVERRUN);
    }

    // Get the body size.
    size_t totalSize = itemSize;
    ffsLogDebug("ffsHttpHandleResponseBody");
    //get sessionID
    //ffs_get_sessionId_from_Body_message(buffer);
    // Is there a callback?
    if (httpClientCallbackData->request->callbacks.handleBody)
    {

        // Wrap the buffer.
        FfsStream_t bodyStream = ffsCreateInputStream((uint8_t *)buffer, totalSize);

        //ffsLogStream("ffsHttpHandleResponseBody", &bodyStream);
        ffsLogDebug("%.*s", totalSize, buffer);

        // Run the callback.
        FFS_RESULT result = httpClientCallbackData->request->callbacks.handleBody(&bodyStream,
                                                                                  httpClientCallbackData->callbackDataPointer);

        // Error?
        if (result != FFS_SUCCESS)
        {
            return 0;
        }
    }

    return totalSize;
}

/**
 * @brief Callback to parse a response header.
 *
 * @param buffer Response header buffer.
 * @param p_buf_len Size of data
 * @param p_ctx_len Size of data
 * @param httpClientCallbackData Callbacks
 *
 * @returns Size of the data processed or 0 on failure
 */
static int ffsHttpHandleResponseHeader(char *buffer, int *p_buf_len, int *p_ctx_len, FfsHttpClientCallbackData_t *httpClientCallbackData)
{
    if (!buffer || !p_buf_len || !p_ctx_len || !httpClientCallbackData)
    {
        ffsLogError("input params find NULL");
        FFS_FAIL(FFS_OVERRUN);
    }

    int content_len = 0;
    char *ptmp = NULL;
    char *response = NULL;
    int head_len = 0;
    char *p_buf = buffer;
    /* 接收到的消息格式如下：
    HTTP/1.1 200 OK
    Accept-Ranges: bytes
    Content-Length: 10363
    Content-Type: text/plain; charset=utf-8
    Last-Modified: Wed, 18 Sep 2019 12:04:16 GMT
    Date: Thu, 19 Sep 2019 07:12:02 GMT
    */

    ptmp = (char *)strstr(p_buf, "HTTP/1.1");
    if (!ptmp)
    {
        SDK_LOG(LOG_ERROR, "http/1.1 not faind\n");
        return SDK_FAIL;
    }
    if (atoi(ptmp + 9) != 200)
    {
        SDK_LOG(LOG_ERROR, "result:\n%s\n", p_buf);
        return SDK_FAIL;
    }

    ptmp = (char *)strstr(p_buf, "Content-Length:"); // 内容长度
    if (!ptmp)
    {
        SDK_LOG(LOG_ERROR, "http header does not contain Content-Length!!\n");
        return SDK_FAIL;
    }
    else
    {
        *p_ctx_len = atoi(ptmp + strlen("Content-Length:") + 1); // 有一个空格
    }

    // Get the total size of the header data.
    size_t totalSize = *p_buf_len - *p_ctx_len;
    ffsLogDebug("ffsHttpHandleResponseHeader len %d ", totalSize);
    // Is there a callback?
    if (httpClientCallbackData->request->callbacks.handleHeader)
    {

        ffsLogDebug("%.*s", totalSize, buffer);
        // Parsing
        char *separator = memchr(p_buf, HEADER_LINE_SEPARATOR, totalSize);
        char *nameStart = (char *)strstr(p_buf, "\r\n");
        nameStart += 2; //escape '\r\n'
        while (totalSize)
        {

            // Status line or custom header.
            separator = memchr(p_buf, HEADER_LINE_SEPARATOR, totalSize);
            if (!separator)
            {
                break;
            }
            char *valueStart = separator + 1; //escape ':'
            while (*valueStart == ' ')        //过滤空格
            {
                valueStart++;
            }
            char *valueEnd = (char *)strstr(separator, "\r\n");
            char *nameEnd = separator - 1;
            if (!valueEnd)
            {
                break;
            }
            FfsStream_t nameStream = ffsCreateInputStream((uint8_t *)nameStart, nameEnd - nameStart + 1);
            FfsStream_t valueStream;
            if (valueStart != valueEnd)
            {
                valueStream = ffsCreateInputStream((uint8_t *)valueStart, valueEnd - valueStart);
            }
            else
            {
                ffsSetStreamToNull(&valueStream);
            }

            // Run the callback.
            FFS_RESULT result = httpClientCallbackData->request->callbacks.handleHeader(&nameStream, &valueStream,
                                                                                        httpClientCallbackData->callbackDataPointer);

            // Error?
            if (result != FFS_SUCCESS)
            {
                break;
            }
            totalSize -= (valueEnd - nameStart);
            ffsLogDebug("free totalSize is %d", totalSize);
            nameStart = valueEnd + 2; //escape '\r\n'
            p_buf = nameStart;
        }
    }

    p_buf = buffer;
    ptmp = (char *)strstr(p_buf, "\r\n\r\n");
    if (!ptmp)
    {
        SDK_LOG(LOG_ERROR, "Not found the end of http head!\n");
        return SDK_FAIL;
    }

    ptmp = ptmp + 4; //指针偏移到内容
    //content_len = strlen(ptmp);
    head_len = ptmp - p_buf;
    SDK_LOG(LOG_DEBUG, "head_len = %d\n", head_len);
    if (head_len > *p_buf_len)
    {
        SDK_LOG(LOG_ERROR, " http head err!\n");
        return SDK_FAIL;
    }
    content_len = *p_buf_len - head_len;

    response = (char *)vesync_malloc(content_len + 1);
    if (!response)
    {
        SDK_LOG(LOG_ERROR, "malloc failed!\n");
        return SDK_FAIL;
    }

    SDK_LOG(LOG_DEBUG, "content_len = %d\n", content_len);
    memcpy(response, ptmp, content_len);
    memset(p_buf, 0, *p_buf_len);
    *p_buf_len = content_len;
    memcpy(p_buf, response, *p_buf_len);
    VCOM_SAFE_FREE(response);

    return SDK_OK;
}

/**
 * @brief Execute an HTTP operation.
 *
 * @param userContext User context
 * @param request HTTP request
 * @param callbackDataPointer Data pointer to pass to the response handlers
 *
 * @returns Enumerated [result](@ref FFS_RESULT)
 */
FFS_RESULT ffsHttpExecute(struct FfsUserContext_s *userContext, FfsHttpRequest_t *request,
                          void *callbackDataPointer)
{

    if (!userContext || !request)
    {
        ffsLogError("input params find NULL");
        FFS_FAIL(FFS_OVERRUN);
    }

    FFS_PRINT_FREE_HEAP();
    char *url = NULL;
    char *send_buf = NULL;
    char *recv_buf = NULL;

    int ctx_len = 0;
    int ret = 0;
    uint16_t url_len = 0;
    uint16_t senddata_len = 0;
    if (!ffsStreamIsEmpty(&request->url.hostStream))
    {
        url_len = FFS_STREAM_DATA_SIZE(request->url.hostStream);
        if (url_len < 2)
        {
            goto exit;
        }
        url = (char *)vesync_malloc(url_len + 1);
        if (!url)
        {
            goto exit;
        }
        // copy the url from request data.
        memcpy(url, FFS_STREAM_NEXT_READ(request->url.hostStream), url_len);
        url[url_len] = 0;
    }

    if (!ffsStreamIsEmpty(&request->bodyStream))
    {
        senddata_len = FFS_STREAM_DATA_SIZE(request->bodyStream);
        if (senddata_len < 2)
        {
            goto exit;
        }
        send_buf = (char *)vesync_malloc(senddata_len + 1);
        if (!send_buf)
        {
            goto exit;
        }
        // copy the senddata from request data.
        memcpy(send_buf, FFS_STREAM_NEXT_READ(request->bodyStream), senddata_len);
        send_buf[senddata_len] = 0;
    }

    if (!url)
    {
        goto exit;
    }
    SDK_LOG(LOG_DEBUG, "request url: %s\n", url);
    SDK_LOG(LOG_DEBUG, "request body:\n   %s\n", send_buf);
    // Construct the HTTP client callback data.
    FfsHttpClientCallbackData_t httpClientCallbackData = {
        .request = request,
        .callbackDataPointer = callbackDataPointer};

    int recv_len = HTTPS_BUFFER_SIZE;
    recv_buf = (char *)vesync_malloc(HTTPS_BUFFER_SIZE);

    if (!recv_buf)
    {
        goto exit;
    }

    //https request
    if (request->url.scheme == FFS_HTTP_SCHEME_HTTPS)
    {
        HTTPS_METHOD_TYPE_E mothod_type = HTTPS_METHOD_POST;
        if (request->operation == FFS_HTTP_OPERATION_GET)
        {
            mothod_type = HTTPS_METHOD_GET;
            SDK_LOG(LOG_DEBUG, "HTTPS_METHOD_GET\n");
        }
        else if (request->operation == FFS_HTTP_OPERATION_POST)
        {
            mothod_type = HTTPS_METHOD_POST;
            SDK_LOG(LOG_DEBUG, "HTTPS_METHOD_POST\n");
        }
        else
        {
            goto exit;
        }

        FFS_PRINT_FREE_HEAP();

        vesync_https_cli_cfg_t https_cfg = {
            .url = url,
            .path = (char *)request->url.path,
            .ca_pem = (char *)getCertKeyString(userContext, FFS_KEY_CA_KEY),
            .client_pem = (char *)getCertKeyString(userContext, FFS_KEY_CLIENT_PUBLIC), //单向认证则设为null
            .client_key = (char *)getCertKeyString(userContext, FFS_KEY_PRIVATE),       //单向认证则设为null
            .keep_alive = true,
            .port = request->url.port,
            .timeout_ms = HTTPS_WAIT_TIME_MS};

        int ret = vesync_https_cli_init(&https_cfg);

        FFS_PRINT_FREE_HEAP();
        if (ret == SDK_OK)
        {
            ret = vesync_https_cli_connect(&https_cfg);
            if (ret == SDK_OK)
            {
                ret = vesync_https_request(mothod_type, send_buf, recv_buf, &recv_len, true);
                if (ret == SDK_OK)
                {
                    print_current_time_and_past_time();
                    SDK_LOG(LOG_DEBUG, "vesync_https_request pass\n");
                    ret = ffsHttpHandleResponseHeader(recv_buf, &recv_len, &ctx_len, &httpClientCallbackData);
                    SDK_LOG(LOG_DEBUG, "after https Header len: %d ,  %s\n", ctx_len, recv_buf);
                    if (ret == SDK_OK && ctx_len)
                    {
                        // handle callback data
                        ret = ffsHttpHandleResponseBody(recv_buf, ctx_len, &httpClientCallbackData);
                        FFS_CHECK_RESULT(request->callbacks.handleStatusCode((int32_t)ret, callbackDataPointer));
                    }
                    else
                    {
                        goto exit;
                    }
                    FFS_PRINT_FREE_HEAP();
                }
            }
            else
            {
                SDK_LOG(LOG_DEBUG, "vesync_https_request failed\n");
                goto exit;
            }
        }
        else
        {
            SDK_LOG(LOG_DEBUG, "vesync_https_module_init failed\n");
            goto exit;
        }
    }
    else //http request
        if (request->url.scheme == FFS_HTTP_SCHEME_HTTP)
    {
        vesync_http_client_config_t http_cfg;
        http_cfg.url = url;
        vesync_http_client_init(&http_cfg);

        // POST operation
        if (request->operation == FFS_HTTP_OPERATION_POST)
        {
            ret = vesync_http_request(HTTP_METHOD_POST, send_buf, recv_buf, &recv_len, HTTPS_GET_NORMAL);
        }
        else if (request->operation == FFS_HTTP_OPERATION_GET)
        {
            ret = vesync_http_request(HTTP_METHOD_GET, send_buf, recv_buf, &recv_len, HTTPS_GET_NORMAL);
        }
        else
        {
            goto exit;
        }

        if (ret != SDK_OK)
        {
            SDK_LOG(LOG_ERROR, "http request download fail.\n");
            goto exit;
        }
    }
    else
    {
        goto exit;
    }

    VCOM_SAFE_FREE(url);
    VCOM_SAFE_FREE(send_buf);
    VCOM_SAFE_FREE(recv_buf);
    FFS_PRINT_FREE_HEAP();
    return FFS_SUCCESS;

exit:
    VCOM_SAFE_FREE(url);
    VCOM_SAFE_FREE(send_buf);
    VCOM_SAFE_FREE(recv_buf);
    FFS_FAIL(FFS_ERROR);
}

/**
 * @brief: Translate a client-facing Wi-Fi security protocol to a DSS Wi-Fi security protocol.
 * @param VHAL_WIFI_AUTH_MODE_E
 * @param FFS_WIFI_SECURITY_PROTOCOL*
 * @return FFS_RESULT
 */
FFS_RESULT ffsConvertApWifiSecurityProtocolToAPI(VHAL_WIFI_AUTH_MODE_E apProtocol,
                                                 FFS_WIFI_SECURITY_PROTOCOL *wifiProtocol)
{
    if (!wifiProtocol)
    {
        ffsLogError("input params find NULL");
        FFS_FAIL(FFS_OVERRUN);
    }

    switch (apProtocol)
    {
    case VHAL_WIFI_AUTH_OPEN:
        *wifiProtocol = FFS_WIFI_SECURITY_PROTOCOL_NONE;
        break;
    case VHAL_WIFI_AUTH_WPA_PSK:
    case VHAL_WIFI_AUTH_WPA2_PSK:
    case VHAL_WIFI_AUTH_WPA_WPA2_PSK:
    case VHAL_WIFI_AUTH_WPA2_ENTERPRISE:
        *wifiProtocol = FFS_WIFI_SECURITY_PROTOCOL_WPA_PSK;
        break;
    case VHAL_WIFI_AUTH_WEP:
        *wifiProtocol = FFS_WIFI_SECURITY_PROTOCOL_WEP;
        break;

    case VHAL_WIFI_AUTH_MAX:
        *wifiProtocol = FFS_WIFI_SECURITY_PROTOCOL_OTHER;
        break;
    default:
        FFS_FAIL(FFS_ERROR);
    }

    return FFS_SUCCESS;
}

/**
 * @brief Get the next Wi-Fi scan result.
 *
 * Get the next Wi-Fi scan result. The given scan result object is initialized
 * with sufficient space to store the longest possible SSID and BSSID.
 *
 * @param userContext User context
 * @param wifiScanResult Destination Wi-Fi scan result object
 * @param isUnderrun Flag indicating that the requested result is not available
 *
 * @returns Enumerated [result](@ref FFS_RESULT)
 */
FFS_RESULT ffsGetWifiScanResult(struct FfsUserContext_s *userContext, FfsWifiScanResult_t *wifiScanResult,
                                bool *isUnderrun)
{

    if (!userContext || !wifiScanResult || !isUnderrun)
    {
        ffsLogError("input params find NULL");
        FFS_FAIL(FFS_OVERRUN);
    }

    static int ap_index = 0;
    int ap_count = vesync_ffs_aplist_get_apcount();

    vesync_bss_info_t *p_apinfo = vesync_ffs_aplist_get_apinfo(ap_index);

    ap_index++;
    //SDK_LOG(LOG_DEBUG, " ap_index: %d @ %d\n", ap_index , ap_count);
    if ((NULL == p_apinfo) || (ap_index == ap_count))
    {
        *isUnderrun = true;
        ap_index = 0;
        userContext->CanPostWifiScanData = true;
        return FFS_SUCCESS;
    }
    else if (!(ap_index % 15)) //分包发送
    {
        *isUnderrun = true;
    }

    //bssid
    uint8_t i = 0;
    FFS_CHECK_RESULT(ffsFlushStream(&wifiScanResult->bssidStream));
    while (!ffsStreamIsFull(&wifiScanResult->bssidStream))
    {
        FFS_CHECK_RESULT(ffsWriteByteToStream(p_apinfo->bssid[i], &wifiScanResult->bssidStream));
        i++;
    }
    // Copy the stored scan result.
    FFS_CHECK_RESULT(ffsFlushStream(&wifiScanResult->ssidStream));
    FFS_CHECK_RESULT(ffsWriteStringToStream((const char *)p_apinfo->ssid, &wifiScanResult->ssidStream));
    FFS_CHECK_RESULT(ffsConvertApWifiSecurityProtocolToAPI(p_apinfo->authmode, &wifiScanResult->securityProtocol));

    //wifiScanResult->frequencyBand = nextWifiScanResult->frequencyBand;
    wifiScanResult->signalStrength = p_apinfo->rssi;
    return FFS_SUCCESS;
}

/**
 * @brief Provide Wi-Fi network credentials to the client.
 *
 * Clients own how credentials are stored, and how many can be stored. If
 * multiple credentials are provided, they will be provided in descending
 * order of priority.
 *
 * @param userContext User context
 * @param wifiConfiguration Wi-Fi network credentials
 *
 * @returns Enumerated [result](@ref FFS_RESULT)
 */
FFS_RESULT ffsAddWifiConfiguration(struct FfsUserContext_s *userContext,
                                   FfsWifiConfiguration_t *wifiConfiguration)
{
    if (!userContext || !wifiConfiguration)
    {
        ffsLogError("input params find NULL");
        FFS_FAIL(FFS_OVERRUN);
    }

    ffsLogDebug("ffsAddWifiConfiguration");
    FFS_CHECK_RESULT(ffsWifiConfigurationListPush(&userContext->wifiContext, wifiConfiguration));

    return FFS_SUCCESS;
}

/**
 * @brief Remove a stored Wi-Fi configuration.
 *
 * Remove all networks with the given SSID from the Wi-Fi configuration list. If
 * the client is currently connected to the given configuration, the client should
 * disconnect from that network.
 *
 * @param userContext User context
 * @param ssidStream SSID to remove
 *
 * @returns Enumerated [result](@ref FFS_RESULT)
 */
FFS_RESULT ffsRemoveWifiConfiguration(struct FfsUserContext_s *userContext, FfsStream_t ssidStream)
{
    ffsLogDebug("ffsRemoveWifiConfiguration");
    if (!userContext)
    {
        ffsLogError("input params find NULL");
        FFS_FAIL(FFS_OVERRUN);
    }

    FfsWifiContext_t *wifiContext = &userContext->wifiContext;

    ffsLogDebug("Remove configurations with SSID '%.*s'", FFS_STREAM_DATA_SIZE(ssidStream),
                (const char *)FFS_STREAM_NEXT_READ(ssidStream));

    vesync_https_cli_deinit();
    vhal_wifi_stop();

    // Remove the configuration.
    FFS_CHECK_RESULT(ffsWifiConfigurationListPopConfiguration(wifiContext, ssidStream));

    return FFS_SUCCESS;
}

/**
 * @brief Update the Wi-Fi connection state.
 *
 * @param userContext User context
 * @param FFS_WIFI_CONNECTION_STATE state
 *
 * @returns Enumerated [result](@ref FFS_RESULT)
 */
FFS_RESULT ffsUpdateWifiConnectionState(FfsWifiContext_t *wifi_context,
                                        FFS_WIFI_CONNECTION_STATE state)
{
    ffsLogDebug("Wi-Fi connection state updated: %d", state);
    if (!wifi_context)
    {
        ffsLogError("input params find NULL");
        FFS_FAIL(FFS_OVERRUN);
    }
    if (state == FFS_WIFI_CONNECTION_STATE_FAILED)
    {
        ffsLogError("Use 'ffsUpdateWifiConnectionFailure' API in the failure case");
        FFS_FAIL(FFS_ERROR);
    }

    wifi_context->state = state;

    return FFS_SUCCESS;
}

/**
 * @brief Update the Wi-Fi connection state.
 *
 * @param userContext User context
 *
 * @returns Enumerated [result](@ref FFS_RESULT)
 */
FFS_RESULT ffsGetWifiConnectionState(struct FfsUserContext_s *userContext)
{
    if (!userContext)
    {
        ffsLogError("input params find NULL");
        FFS_FAIL(FFS_OVERRUN);
    }

    VHAL_WIFI_STATUS_E wifi_connect_state = vesync_wifi_get_link_status();
    SDK_LOG(LOG_INFO, "wifi_connect_state is %d !\n", wifi_connect_state);

    switch (wifi_connect_state)
    {
    case VHAL_WIFI_LOST_IP:
    case VHAL_WIFI_WRONG_PWD:
    case VHAL_WIFI_NO_AP_FOUND:
    case VHAL_WIFI_CONNECT_FAIL:
    {
        SDK_LOG(LOG_ERROR, "Network connect failed!\n");
        userContext->wifiContext.state = FFS_WIFI_CONNECTION_STATE_FAILED;
        break;
    }
    case VHAL_WIFI_STA_DISCONNECT_SOFTAP:
    {
        SDK_LOG(LOG_ERROR, "Network was disconnect!\n");
        userContext->wifiContext.state = FFS_WIFI_CONNECTION_STATE_DISCONNECTED;
        break;
    }

    case VHAL_WIFI_GOT_IP:
    case VHAL_WIFI_SCAN_DONE:
    case VHAL_WIFI_STA_CONNECT_SOFTAP:
    case VHAL_WIFI_CONNECTED:
        SDK_LOG(LOG_INFO, "Network was connected!\n");
        userContext->wifiContext.state = FFS_WIFI_CONNECTION_STATE_ASSOCIATED;
        break;

    default:
        SDK_LOG(LOG_INFO, "Network is connecting!\n");
        userContext->wifiContext.state = FFS_WIFI_CONNECTION_STATE_UNAUTHENTICATED;
        break;
    }

    return FFS_SUCCESS;
}

/**
 * @brief Update the current Wi-Fi connection Attempt Details.
 *
 * @param userContext User context
 * @param FfsWifiConfiguration_t wifiConfiguration
 *
 * @returns Enumerated [result](@ref FFS_RESULT)
 */
FFS_RESULT ffsUpdateWifiConnectionAttemptDetails(struct FfsUserContext_s *userContext, FfsWifiConfiguration_t *wifiConfiguration)
{

    if (!userContext || !wifiConfiguration)
    {
        return FFS_OVERRUN;
    }

    FfsWifiConnectionAttempt_t connectionAttempt;
    connectionAttempt.ssidStream = wifiConfiguration->ssidStream;
    connectionAttempt.securityProtocol = wifiConfiguration->securityProtocol;
    connectionAttempt.hasErrorDetails = false;
    connectionAttempt.state = userContext->wifiContext.state;
    FFS_CHECK_RESULT(ffsWifiConnectionAttemptListPush(&userContext->wifiContext, &connectionAttempt));
    return FFS_SUCCESS;
}

/**
 * @brief backup the current Wi-Fi configrution to userNetwork.
 *
 * @param userContext User context
 * @param FfsWifiConfiguration_t wifiConfiguration
 *
 * @returns Enumerated [result](@ref FFS_RESULT)
 */
FFS_RESULT ffsBackupWifiConfiguration(struct FfsUserContext_s *userContext, FfsWifiConfiguration_t *wifiConfiguration)
{
    FFS_WIFI_PROVISIONEE_STATE state = FFS_WIFI_PROVISIONEE_STATE_NOT_PROVISIONED;
    FFS_RESULT ffs_ret = FFS_ERROR;

    if (!wifiConfiguration || !userContext)
    {
        return FFS_OVERRUN;
    }

    size_t ssidLength = FFS_STREAM_DATA_SIZE(wifiConfiguration->ssidStream);
    size_t keyLength = FFS_STREAM_DATA_SIZE(wifiConfiguration->keyStream);
    if (!ssidLength)
    {
        FFS_FAIL(FFS_OVERRUN);
    }
    char *ssidBuffer = (char *)vesync_malloc(ssidLength + 1);
    if (!ssidBuffer)
    {
        FFS_FAIL(FFS_OVERRUN);
    }

    char *keyBuffer = NULL;

    if (keyLength)
    {
        keyBuffer = (char *)vesync_malloc(keyLength + 1);
    }
    if (!keyBuffer && keyLength > 0)
    {
        VCOM_SAFE_FREE(ssidBuffer);
        FFS_FAIL(FFS_OVERRUN);
    }

    // 获取当前的运行状态
    ffs_ret = ffsGetWifiProvisioneeState(userContext, &state);
    if (ffs_ret != FFS_SUCCESS)
    {
        VCOM_SAFE_FREE(ssidBuffer);
        VCOM_SAFE_FREE(keyBuffer);
    }
    FFS_CHECK_RESULT(ffs_ret);
    if (FFS_WIFI_PROVISIONEE_STATE_CONNECTING_TO_SETUP_NETWORK == state)
    {
        // 先释放之前申请的内存
        VCOM_SAFE_FREE(userContext->setupNetworkSsid);
        VCOM_SAFE_FREE(userContext->setupNetworkPsk);

        // 保存setupNetwork的信息
        userContext->setupNetworkSsid = ssidBuffer;
        memcpy(userContext->setupNetworkSsid, FFS_STREAM_NEXT_READ(wifiConfiguration->ssidStream), ssidLength);
        userContext->setupNetworkSsid[ssidLength] = 0;

        userContext->setupNetworkPsk = keyBuffer;
        if (keyLength)
        {
            memcpy(userContext->setupNetworkPsk, FFS_STREAM_NEXT_READ(wifiConfiguration->keyStream), keyLength);
            userContext->setupNetworkPsk[keyLength] = 0;
        }
    }
    else
    {
        // 保存userNetwork的信息
        userContext->userNetworkSsid = ssidBuffer;
        userContext->userNetworkPsk = keyBuffer;
        memcpy(userContext->userNetworkSsid, FFS_STREAM_NEXT_READ(wifiConfiguration->ssidStream), ssidLength);
        userContext->userNetworkSsid[ssidLength] = 0;
        if (keyLength)
        {
            memcpy(userContext->userNetworkPsk, FFS_STREAM_NEXT_READ(wifiConfiguration->keyStream), keyLength);
            userContext->userNetworkPsk[keyLength] = 0;
        }
    }

    return FFS_SUCCESS;
}

/**
 * @brief handle the current Wi-Fi configuration ssid and key.
 *
 * @param FfsWifiConfiguration_t wifiConfiguration
 * @param ssidBuf
 * @param keyBuf
 * @returns Enumerated [result](@ref FFS_RESULT)
 */
FFS_RESULT ffsPickWifiConfiguration(FfsWifiConfiguration_t *wifiConfiguration, char *ssidBuf, char *keyBuf)
{
    if (!wifiConfiguration)
    {
        return FFS_OVERRUN;
    }

    uint8_t len = FFS_STREAM_DATA_SIZE(wifiConfiguration->ssidStream);

    ffsLogDebug("ssid len: %d.", len);
    if (len && ssidBuf)
    {
        ffsLogStream("wifiConfig.ssidStream", &wifiConfiguration->ssidStream);
        memcpy(ssidBuf, FFS_STREAM_NEXT_READ(wifiConfiguration->ssidStream), len);
        ssidBuf[len] = 0;
    }
    else
    {
        ffsLogError("No ssid !");
        return FFS_UNDERRUN;
    }

    //password
    len = FFS_STREAM_DATA_SIZE(wifiConfiguration->keyStream);
    ffsLogDebug("keyStream len: %d.", len);
    if (len && keyBuf)
    {
        ffsLogStream("wifiConfig.keyStream", &wifiConfiguration->keyStream);
        memcpy(keyBuf, FFS_STREAM_NEXT_READ(wifiConfiguration->keyStream), len);
        keyBuf[len] = 0;
    }
    return FFS_SUCCESS;
}

/**
 * @brief Start connecting to the stored Wi-Fi network(s).
 *
 * Start a connection attempt to the stored Wi-Fi network(s), starting with
 * the highest priority network. To store Wi-Fi networks, first call
 * @ref ffsAddWifiNetwork. This function will wait until the connection
 * attempt(s) complete. If multiple credentials have been provided, it will wait
 * until a successful connection is established or until all stored credentials
 * have been tried.
 *
 * @param userContext User context
 *
 * @returns Enumerated [result](@ref FFS_RESULT)
 */
FFS_RESULT ffsConnectToWifi(struct FfsUserContext_s *userContext)
{
    if (!userContext)
    {
        return FFS_OVERRUN;
    }

    int cnt = 0;
    char ssidBUf[WIFI_SSID_MAX_LEN] = {0};
    char keyBUf[WIFI_PWD_MAX_LEN] = {0};
    VHAL_WIFI_AUTH_MODE_E auth_mode = VHAL_WIFI_AUTH_OPEN;
    bool wifiConfigurationListIsEmpty = false;
    bool fConnect_succed = false;
    bool clientCanProceed = true;
    FfsWifiConfiguration_t *wifiConfiguration;

    ffsLogDebug("ffsConnectToWifi");
    FFS_CHECK_RESULT(ffsUpdateWifiConnectionState(&userContext->wifiContext, FFS_WIFI_CONNECTION_STATE_DISCONNECTED));

    FFS_PRINT_FREE_HEAP();

    while (userContext->wifiContext.state != FFS_WIFI_CONNECTION_STATE_ASSOCIATED)
    {
        // Check that we still have networks in the configuration list.
        FFS_CHECK_RESULT(ffsWifiConfigurationListIsEmpty(&userContext->wifiContext, &wifiConfigurationListIsEmpty));
        if (wifiConfigurationListIsEmpty)
        {
            ffsLogError("No more networks to try connecting to");
            FFS_FAIL(FFS_ERROR);
        }

        // Peek the next network.
        FFS_CHECK_RESULT(ffsWifiConfigurationListPeek(&userContext->wifiContext, &wifiConfiguration));

        //ssid and password
        if (ffsPickWifiConfiguration(wifiConfiguration, ssidBUf, keyBUf) != FFS_SUCCESS)
        {
            continue;
        }

        ffsLogDebug("ssid: %s; key %s", ssidBUf, keyBUf);
        if (strlen((char *)keyBUf) > 0)
            auth_mode = VHAL_WIFI_AUTH_WPA_WPA2_PSK;

        vesync_wifi_client_connect(ssidBUf, keyBUf, auth_mode);

        cnt = 0; // 多个ssid关联时，每个都最大尝试20秒，因此要清零
        do
        {
            // 判断取消标志位，若取消则退出循环
            FFS_CHECK_RESULT(ffsWifiProvisioneeCanProceed(userContext, &clientCanProceed));
            if (!clientCanProceed)
            {
                ffsLogDebug("Ffs Wi-Fi connect stopped by client.");
                return FFS_ERROR;
            }

            fConnect_succed = vhal_wifi_get_link_status(1000);
            cnt++;
        } while (!fConnect_succed && cnt < FFS_MAX_TIME_PER_WIFI_CONNECT_SEC);

        //ffs 连接状态转换
        ffsGetWifiConnectionState(userContext);
        ffsLogDebug("Attempt to connect to Wi-Fi network");
        ffsUpdateWifiConnectionAttemptDetails(userContext, wifiConfiguration);

        // If the attempt failed, pop the bad network.
        if (!fConnect_succed)
        {
            ffsLogDebug("fail, pop another wifi");
            FFS_CHECK_RESULT(ffsWifiConfigurationListPop(&userContext->wifiContext));
        }
        else
        {
            // backup wifi ssid and key
            ffsLogDebug("finish, backup ssid and key");
            ffsBackupWifiConfiguration(userContext, wifiConfiguration);
        }
    }

    return FFS_SUCCESS;
}

/**
 * @brief Get the current Wi-Fi connection state.
 *
 * Fill out the provided Wi-Fi connection details object with the
 * current Wi-Fi connection state. The given details object is initialized
 * with sufficient space to store the longest possible SSID.
 *
 * @param userContext User context
 * @param wifiConnectionDetails Destination Wi-Fi connection details object
 *
 * @returns Enumerated [result](@ref FFS_RESULT)
 */
FFS_RESULT ffsGetWifiConnectionDetails(struct FfsUserContext_s *userContext,
                                       FfsWifiConnectionDetails_t *wifiConnectionDetails)
{
    if (!userContext || !wifiConnectionDetails)
    {
        return FFS_OVERRUN;
    }
    wifiConnectionDetails->state = userContext->wifiContext.state;
    return FFS_SUCCESS;
}

/**
 * @brief Get the next Wi-Fi connection attempt.
 *
 * Fill out the provided Wi-Fi connection attempt object with the
 * next Wi-Fi connection attempt. The given attempt object is initialized
 * with sufficient space to store the longest possible SSID.
 *
 * @param userContext User context
 * @param attempts Destination Wi-Fi connection attempt object
 * @param isUnderrun Flag indicating that the requested attempt is not available
 *
 * @returns Enumerated [result](@ref FFS_RESULT)
 */
FFS_RESULT ffsGetWifiConnectionAttempt(struct FfsUserContext_s *userContext,
                                       FfsWifiConnectionAttempt_t *wifiConnectionAttempt, bool *isUnderrun)
{
    if (!userContext || !wifiConnectionAttempt || !isUnderrun)
    {
        return FFS_OVERRUN;
    }
    bool connectionAttemptListIsEmpty = true;
    FFS_CHECK_RESULT(ffsWifiConnectionAttemptListIsEmpty(&userContext->wifiContext, &connectionAttemptListIsEmpty));
    if (connectionAttemptListIsEmpty)
    {
        *isUnderrun = true;
        return FFS_SUCCESS;
    }

    // Peek the next scan result.
    FfsWifiConnectionAttempt_t *nextWifiConnectionAttempt;
    FFS_CHECK_RESULT(ffsWifiConnectionAttemptListPeek(&userContext->wifiContext, &nextWifiConnectionAttempt));

    // Copy the stored scan result.
    FFS_CHECK_RESULT(ffsAppendStream(&nextWifiConnectionAttempt->ssidStream, &wifiConnectionAttempt->ssidStream));
    wifiConnectionAttempt->securityProtocol = nextWifiConnectionAttempt->securityProtocol;
    wifiConnectionAttempt->state = nextWifiConnectionAttempt->state;
    wifiConnectionAttempt->hasErrorDetails = nextWifiConnectionAttempt->hasErrorDetails;
    wifiConnectionAttempt->errorDetails = nextWifiConnectionAttempt->errorDetails;

    // Pop the stored scan result.
    FFS_CHECK_RESULT(ffsWifiConnectionAttemptListPop(&userContext->wifiContext));
    return FFS_SUCCESS;
}

/* ========== ffs_dss_client_compat.h ========== */
/**
 *  @brief Get the client-allocated buffers used by the Device Setup Service client.
 *
 * @param userContext user context
 * @param hostStream "host" part of the URL (maximum of 253 characters)
 * @param sessionIdStream session ID (maximum of 255 characters plus null terminator)
 * @param nonceStream nonce stream (minimum of 16 bytes)
 * @param bodyStream HTTP POST request/response body buffer
 *
 * @returns Enumerated [result](@ref FFS_RESULT)
 */
FFS_RESULT ffsDssClientGetBuffers(struct FfsUserContext_s *userContext,
                                  FfsStream_t *hostStream, FfsStream_t *sessionIdStream,
                                  FfsStream_t *nonceStream, FfsStream_t *bodyStream)
{
    if (!userContext || !hostStream || !sessionIdStream || !nonceStream || !bodyStream)
    {
        return FFS_OVERRUN;
    }

    if (!userContext->hostNameBuffer || !userContext->sessionIdBuffer || !userContext->nonceBuffer || !userContext->bodyBuffer)
    {
        ffsLogError("One or more DSS buffers not allocated");
        FFS_FAIL(FFS_ERROR);
    }

    *hostStream = ffsCreateOutputStream(userContext->hostNameBuffer, DSS_HOST_NAME_BUFFER_SIZE);
    *sessionIdStream = ffsCreateOutputStream(userContext->sessionIdBuffer, DSS_SESSION_ID_BUFFER_SIZE);
    *nonceStream = ffsCreateOutputStream(userContext->nonceBuffer, DSS_NONCE_BUFFER_SIZE);
    *bodyStream = ffsCreateOutputStream(userContext->bodyBuffer, DSS_BODY_BUFFER_SIZE);

    return FFS_SUCCESS;
}

/* ========== ffs_wifi_provisionee_compat.h ========== */
/**
 * @brief Sets the state of the provisionee.
 *
 * @param userContext User context
 * @param provisioneeState Provisionee state
 *
 * @returns Enumerated [result](@ref FFS_RESULT)
 */
FFS_RESULT ffsSetWifiProvisioneeState(struct FfsUserContext_s *userContext,
                                      FFS_WIFI_PROVISIONEE_STATE provisioneeState)
{
    if (!userContext)
    {
        return FFS_OVERRUN;
    }
    userContext->provisioneeState = provisioneeState;

    return FFS_SUCCESS;
}

/**
 * @brief Gets the state of the provisionee.
 *
 * @param userContext User context
 * @param provisioneeState Destination provisionee state pointer
 *
 * @returns Enumerated [result](@ref FFS_RESULT)
 */
FFS_RESULT ffsGetWifiProvisioneeState(struct FfsUserContext_s *userContext,
                                      FFS_WIFI_PROVISIONEE_STATE *provisioneeState)
{
    if (!userContext || !provisioneeState)
    {
        return FFS_OVERRUN;
    }

    *provisioneeState = userContext->provisioneeState;

    return FFS_SUCCESS;
}

/**
 * @brief Gets the client's custom setup network configuration, if one exists.
 *
 * The provided configuration object has buffers allocated for the maximum length
 * SSID and password. The client can return @ref FFS_NOT_IMPLEMENTED to use the
 * default configuration.
 *
 * @param userContext User context
 * @param wifiConfiguration Destination configuration object
 *
 * @returns Enumerated [result](@ref FFS_RESULT)
 */
FFS_RESULT ffsGetSetupNetworkConfiguration(struct FfsUserContext_s *userContext,
                                           FfsWifiConfiguration_t *wifiConfiguration)
{
    if (!userContext || !wifiConfiguration)
    {
        return FFS_OVERRUN;
    }
    if (userContext->setupNetworkSsid)
    {

        FFS_CHECK_RESULT(ffsFlushStream(&wifiConfiguration->ssidStream));
        FFS_CHECK_RESULT(ffsFlushStream(&wifiConfiguration->keyStream));

        FFS_CHECK_RESULT(ffsWriteStringToStream(userContext->setupNetworkSsid, &wifiConfiguration->ssidStream));

        if (userContext->setupNetworkPsk)
        {
            FFS_CHECK_RESULT(ffsWriteStringToStream(userContext->setupNetworkPsk, &wifiConfiguration->keyStream));
            wifiConfiguration->securityProtocol = FFS_WIFI_SECURITY_PROTOCOL_WPA_PSK;
        }
        else
        {
            wifiConfiguration->securityProtocol = FFS_WIFI_SECURITY_PROTOCOL_NONE;
        }

        return FFS_SUCCESS;
    }

    return FFS_NOT_IMPLEMENTED;
}

/**
 * @brief Let the client kill the Wi-Fi provisionee task with a boolean value.
 *
 * Setting @ref canProceed to false will terminate the Wi-Fi provisionee task
 * after the current state finishes executing.
 *
 * @param userContext User context
 * @param canProceed Destination boolean pointer
 *
 * @returns Enumerated [result](@ref FFS_RESULT)
 */
FFS_RESULT ffsWifiProvisioneeCanProceed(struct FfsUserContext_s *userContext,
                                        bool *canProceed)
{
    if (!userContext || !canProceed)
    {
        return FFS_OVERRUN;
    }

    *canProceed = !userContext->cancel; // 两个标志位功能相反
    //(void) userContext;

    //*canProceed = true;
    return FFS_SUCCESS;
}

/**
 * @brief Let the client control whether the Wi-Fi provisionee task continues to post Wi-Fi scan data.
 *
 * The client can use this callback to control how many attempts the Wi-Fi provisionee task
 * will make to post Wi-Fi scan data to the cloud. Clients should consider the number
 * of credentials found so far and the number of credentials they can store, whether
 * all of a customer's credentials have been found rendering further posts unnecessary.
 *
 * @param userContext User context
 * @param sequenceNumber Sequence number starting from 1, incrementing with each call. Reset to 1 each time we return to the POST_WIFI_SCAN_DATA state
 * @param totalCredentialsFound Total credentials found in scan data posted so far
 * @param allCredentialsFound Boolean indicating whether all of a customer's credentials have been found, across all calls
 * @param canPostWifiScanData Destination boolean pointer
 */
FFS_RESULT ffsWifiProvisioneeCanPostWifiScanData(struct FfsUserContext_s *userContext,
                                                 uint32_t sequenceNumber, uint32_t totalCredentialsFound, bool allCredentialsFound, bool *canPostWifiScanData)
{
    if (!userContext)
    {
        return FFS_OVERRUN;
    }
    // We have no practical limit on the number of credentials we can store.
    (void)totalCredentialsFound;
    (void)sequenceNumber;
    SDK_LOG(LOG_DEBUG, " == ffsWifiProvisioneeCanPostWifiScanData  == \n");

    // Check that we have not found all credentials.
    if (allCredentialsFound)
    {
        *canPostWifiScanData = false;
        SDK_LOG(LOG_DEBUG, "  allCredentialsFound \n");
        return FFS_SUCCESS;
    }

    if (userContext->CanPostWifiScanData)
    {
        userContext->CanPostWifiScanData = false;
        *canPostWifiScanData = false;
        SDK_LOG(LOG_DEBUG, "  CanPostWifiScanData is false \n");
        return FFS_SUCCESS;
    }

    uint16_t ap_count = vesync_ffs_aplist_get_apcount();
    SDK_LOG(LOG_DEBUG, " == ap_count : %d == \n", ap_count);
    if (ap_count)
    {
        *canPostWifiScanData = true;
    }
    else
    {
        *canPostWifiScanData = false;
    }

    return FFS_SUCCESS;
}

/**
 * @brief Let the client control whether the Wi-Fi provisionee task continues to get Wi-Fi credentials.
 *
 * The client can use this callback to control how many attempts the Wi-Fi provisionee task
 * will make to get Wi-Fi credentials from the cloud. Clients should consider the
 * total number of credentials they have already stored and to the number of credentials
 * they can store in total, and whether all credentials have been returned by the cloud.
 *
 * @param userContext User context
 * @param sequenceNumber Sequence number starting from 1, incrementing with each call. Reset to 1 each time we return to the GET_WIFI_CREDENTIALS state
 * @param allCredentialsReturned Boolean indicating whether all of the credentials found by POST_WIFI_SCAN_DATA have been returned, across all calls
 * @param canGetWifiCredentials Destination boolean pointer
 *
 * @returns Enumerated [result](@ref FFS_RESULT)
 */
FFS_RESULT ffsWifiProvisioneeCanGetWifiCredentials(struct FfsUserContext_s *userContext,
                                                   uint32_t sequenceNumber, bool allCredentialsReturned, bool *canGetWifiCredentials)
{
    (void)userContext;
    (void)sequenceNumber;
    if (!canGetWifiCredentials)
    {
        return FFS_OVERRUN;
    }
    // Check that we have not returned all credentials.
    if (allCredentialsReturned)
    {
        *canGetWifiCredentials = false;
        return FFS_SUCCESS;
    }

    *canGetWifiCredentials = true;

    return FFS_SUCCESS;
}
