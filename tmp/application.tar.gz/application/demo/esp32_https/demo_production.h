/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        demo_production.h
 * @brief       产测
 * @author      Joshua
 * @date        2021-10-5
 */

#ifndef __DEMO_PRODUCTION_H__
#define __DEMO_PRODUCTION_H__

#ifdef __cplusplus
extern "C" {
#endif

/**
* @brief 产测功能初始化
*/
void demo_production_init(void);


#ifdef __cplusplus
}
#endif

#endif


