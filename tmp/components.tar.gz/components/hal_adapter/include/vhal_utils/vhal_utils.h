/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
 * @file        vhal_utils.h
 * @brief       通用接口
 * @date        2021-04-20
 */

#ifndef __VHAL_UTILS_H__
#define __VHAL_UTILS_H__

#include <stdbool.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C"
{
#endif

/**
 * @brief 设备侧MAC地址类型
 */
typedef enum
{
    VHAL_MAC_WIFI_STA,          // STA模式时，WiFi的MAC地址
    VHAL_MAC_WIFI_SOFTAP,       // AP模式时，WiFi的MAC地址
    VHAL_MAC_BT,                // 蓝牙MAC地址
    VHAL_MAC_ROUTER,            // 关联上AP的MAC地址
} VHAL_MAC_TYPE_E;

/**
 * @brief 重启系统
 * @param[in]  arg                  [定时器参数，未使用]
 */
void vhal_utils_restart(void *arg);

/**
 * @brief 通过硬件RNG获取随机数
 * @param[in]  p_buf                [用于存储随机数的缓存空间]
 * @param[in]  buf_len              [缓存空间大小]
 */
void vhal_utils_get_random(uint8_t *p_buf, int32_t buf_len);


/**
 * @brief  获取剩余heap大小.
 * @return     uint32_t             [heap空间大小]
 */
uint32_t vhal_utils_get_free_heap_size(void);

/**
 * @brief 修改dhcp的hostname
 * @param[in]  p_hostname           [新的hostname]
 */
void vhal_utils_chg_dhcp_hostname(const char *p_hostname);

/**
 * @brief  获取Wi-Fi模组芯片名称
 * @return     char *               [字符串格式芯片名称]
 */
char *vhal_utils_get_chip_name(void);

/**
 * @brief  获取SDK版本信息
 * @param[out] p_buf                [缓存空间]
 * @param[in]  buf_len              [缓存大小]
 * @return     char *               [字符串格式SDK版本信息]
 */
char *vhal_utils_get_sdk_version(char *p_buf, uint32_t buf_len);

/**
 * @brief 获取设备的MAC地址
 * @param[in]  type                 [详见DEVICE_TYPE_MAC_E定义]
 * @param[out] p_buf                [获取到的MAC地址]
 * @param[in]  buf_len              [缓存大小]
 * @return  int                     [成功：VHAL_OK，失败：VHAL_FAIL]
 */
int vhal_utils_get_dev_mac(VHAL_MAC_TYPE_E type, char *p_buf, int32_t buf_len);

/**
 * @brief  设置设备MAC地址
 * @param[in]  p_mac                [MAC地址，使用":"分隔，如：00:01:02:03:04:05]
 * @return  int32_t                 [成功：VHAL_OK，失败：VHAL_FAIL]
 */
int32_t vhal_utils_set_wifi_mac(char *p_mac);


/**
 * @brief 设备作为STA时，获取分配到的IP。
 * @param[in]  p_buf               [保存IP的缓存]
 * @param[in]  buf_len                  [缓存大小]
 * @return     char*                [IP地址]
 */
char* vhal_utils_get_sta_ip(char *p_buf, int32_t buf_len);

/**
 * @brief 获取utc时间戳
 * @param[in]  p_ms                 [保存精度到毫秒的时间戳]
 * @param[in]  buf_len              [p_ms大小]
 * @return  int                     [成功：VHAL_OK，失败：VHAL_FAIL]
 */
int vhal_utils_get_system_time_ms_str(char *p_ms, int buf_len);


/**
 * @brief 获取utc时间戳
 * @return     uint32_t             [utc时间戳,单位：秒]
 */
uint32_t vhal_utils_get_system_time_sec(void);

/**
 * @brief 获取utc时间戳
 * @return     long long            [utc时间戳]
 */
long long vhal_utils_get_system_time_ms_int(void);


/**
 * @brief 初始化sntp
 */
void vhal_utils_start_sntp(void);

/**
 * @brief 停止sntp服务
 */
void vhal_utils_stop_sntp(void);

/**
 * @brief 获得上次SNTP更新的时间点
 * @return uint32_t                 [返回的秒时间戳]
 */
uint32_t vhal_utils_get_sntp_last_sync(void);

/**
 * @brief 设置本地utc时间
 * @param[in]  utc_time             [utc时间戳]
 * @param[in]  time_zone            [时区]
 */
void vhal_utils_update_system_time(uint32_t utc_time, int8_t time_zone);

#ifdef __cplusplus
}
#endif

#endif /* __VHAL_UTILS_H__ */
