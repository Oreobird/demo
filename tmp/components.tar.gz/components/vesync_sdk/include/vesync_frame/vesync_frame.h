/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_frame.h
 * @brief       数据帧格式定义
 * @date        2021-10-18
 */

#ifndef __VESYNC_FRAME_H__
#define __VESYNC_FRAME_H__

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif


/**
 * @brief 用于数据帧完整帧组包判断过程
 */
typedef enum
{
    TL_FRAME_RECV_HEAD = 0,             // 收到协议头
    TL_FRAME_RECV_CTRL,                 // 收到控制字节
    TL_FRAME_RECV_SEQ,                  // 收到帧计数字节
    TL_FRAME_RECV_LEN_L,                // 收到长度低字节
    TL_FRAME_RECV_LEN_H,                // 收到长度高字节
    TL_FRAME_RECV_SUM,                  // 收到校验和字节
    TL_FRAME_RECV_PAYLOAD               // 收到payload字节
} TL_FRAME_RECV_STATE_E;


/**
 * @brief 数据帧控制字段定义
 */
typedef union
{
    uint8_t data;
    struct
    {
        uint8_t  version:     4;        // 协议版本号；
        uint8_t  ack_flag:    1;        // 用于指示当前数据包是命令还是应答    0：命令    1: 应答；
        uint8_t  request_flag:1;        // 用于指示接收该数据包的设备是否需要回应答，0：不需要回应答  1：需要回应答；
        uint8_t  error_flag:  1;        // 应答包错误指示位
        uint8_t  resv:        1;        // 保留
    } bitN;
} tl_frame_ctrl_u;


/**
 * @brief 数据帧接收信息结构体
 */
typedef struct{
    tl_frame_ctrl_u       ctrl;         // 控制字段
    uint8_t               seq_id;       // 序列号
    uint16_t              payload_len;  // payload长度
    uint8_t               checksum;     // 校验和
    TL_FRAME_RECV_STATE_E state;        // 帧组合过程状态记录
    uint16_t              payload_pos;  // payload缓存计数
    uint8_t               p_payload[0]; // payload指针
} tl_frame_recv_info_t;


#pragma pack(1)
/**
 * @brief payload信息结构体
 * @note  该结构体与uart_payload_info_t相同，该协议适用于串口、BLE等
 */
typedef struct
{
    uint8_t version;                    // payload版本号
    uint16_t op_code;                   // 操作码opcode
    uint8_t status_code;                // 状态码，0表示正常，非0表示异常，详见TL_FRAME_STATUS_CODE_E
    uint8_t payload_data[0];            // 数据
} tl_payload_info_t;
#pragma pack()


#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_FRAME_H__ */
