/**
 * Copyright © Vesync Technologies Co.Ltd. 2022. All rights reserved.
 * @file        led_strip_report.c
 * @brief       led strip 上报云端接口
 * @author      Lind
 * @date        2022-01-07
 */

#include <string.h>
#include <stdio.h>

#include "cJSON.h"

#include "vesync_common.h"
#include "vesync_log.h"
#include "vesync_device.h"
#include "vesync_report.h"
#include "vesync_production.h"
#include "vesync_netcfg.h"
#include "vesync_memory.h"
#include "vesync_net_service.h"

#include "led_strip.h"
#include "led_strip_report.h"

static char s_ls_chg_rsn[MAX_STAT_CHG_RSN_STR_LEN];         // 记录灯带变化的原因


/**
* @brief 上报第三方接口(http://34.194.32.46:8080/doc/POOTQH6Bs)，方法名：statusChangeNtyV2
*
* @deprecated 设备开关状态变化，通知云端(http://34.194.32.46:8080/doc/POgSBTDFF)，方法名：updateOnOffV2
* @return     int               [成功/失败]
*/
int ls_report_status(void)
{
    if (NETWORK_ONLINE != vesync_net_client_get_status())
    {
        APP_LOG(LOG_DEBUG, "Offline, report failed!\n");
        return APP_FAIL;
    }

    APP_LOG(LOG_DEBUG, "Report to cloud !\n");
    char action[2][4] = {{"off"},{"on"}};
    ls_status_t status;
    static uint8_t last_status = 0;
    int temp_color[3] = {0, 0, 0};
    cJSON *data = NULL;
    cJSON *obj_sel = NULL;
    cJSON *array = NULL;
    cJSON *hsv = NULL;
    cJSON *multi_hsv = NULL;

    ls_get_status(&status);

    // json组装
    data = cJSON_CreateObject();
    if(NULL == data)
    {
        APP_LOG(LOG_ERROR, "Create object fail\n");
        return APP_FAIL;
    }

    cJSON *chg_stat = cJSON_AddObjectToObject(data, "changedStatus");
    cJSON *unchg_stat = cJSON_AddObjectToObject(data, "unchangedStatus");
    if(NULL == chg_stat || NULL == unchg_stat)
    {
        APP_LOG(LOG_ERROR, "Create object fail\n");
        goto EXIT;
    }

    // 根据协议，当changeReason为setup/reconnect时，所有状态放在 unchangedStatus
    if (0 == strcmp(s_ls_chg_rsn, STAT_CHG_RSN_CONFIG_NET_STR) || \
        0 == strcmp(s_ls_chg_rsn, STAT_CHG_RSN_RECONNECT_STR))
    {
        obj_sel = unchg_stat;
        last_status = status.status;
        cJSON_AddStringToObject(obj_sel, "action", action[status.status]);
    }
    else
    {
        obj_sel = chg_stat;
        if (last_status != status.status)
        {
              cJSON_AddStringToObject(obj_sel, "action", action[status.status]);
              last_status = status.status;
        }
        else
        {
            cJSON_AddStringToObject(unchg_stat, "action", action[status.status]);
        }
    }

    if (status.status)
    {
        if (status.mode > LS_MODE_OFF)
        {
            APP_LOG(LOG_ERROR, "wrong model \n");
            goto EXIT;
        }

        switch (status.mode)
        {
            case LS_MODE_WHITE:
                cJSON_AddStringToObject(obj_sel, "mode", "white");
                cJSON_AddNumberToObject(obj_sel, "brightness", status.hsvw.white);
                cJSON_AddNumberToObject(obj_sel, "colorTempe", 0);
                break;
            case LS_MODE_HSV:
                cJSON_AddStringToObject(obj_sel, "mode", "color");
                hsv = cJSON_AddObjectToObject(obj_sel, "hsvMode");
                if(NULL == chg_stat )
                {
                    APP_LOG(LOG_ERROR, "Create object fail\n");
                    goto EXIT;
                }
                cJSON_AddNumberToObject(hsv, "hue", status.hsvw.H);
                cJSON_AddNumberToObject(hsv, "saturation", status.hsvw.S);
                cJSON_AddNumberToObject(hsv, "value", status.hsvw.V);
                break;
            case LS_MODE_MULTI_SEG:
                cJSON_AddStringToObject(obj_sel, "mode", "multiHsv");
                multi_hsv = cJSON_AddObjectToObject(obj_sel, "multiHsv");
                if(NULL == multi_hsv )
                {
                    APP_LOG(LOG_ERROR, "Create object fail\n");
                    goto EXIT;
                }
                cJSON_AddNumberToObject(multi_hsv, "cnt", status.node_num);
                hsv = cJSON_AddArrayToObject(multi_hsv, "hsv");
                if(NULL == hsv )
                {
                    APP_LOG(LOG_ERROR, "Create object fail\n");
                    goto EXIT;
                }

                for (int i = 0; i < status.node_num; i++)
                {
                    temp_color[0] = status.multi_hsv[i].H;
                    temp_color[1] = status.multi_hsv[i].S;
                    temp_color[2] = status.multi_hsv[i].V;
                    array = cJSON_CreateIntArray(temp_color, 3);
                    if(NULL == multi_hsv )
                    {
                        APP_LOG(LOG_ERROR, "Create array fail\n");
                        goto EXIT;
                    }

                    cJSON_AddItemToArray(hsv, array);
                }
                break;
            case LS_MODE_SCENE:
                cJSON_AddStringToObject(obj_sel, "mode", "scenario");
                cJSON_AddNumberToObject(obj_sel, "scenceId", status.scene_id);
                break;
            default:
                break;
        }
    }

    cJSON_AddStringToObject(data, "changeReason", s_ls_chg_rsn);

    // 发送
    int ret = vesync_report_status_change_nty(data);
    return ret == SDK_OK ? APP_OK : APP_FAIL;

EXIT:
    cJSON_Delete(data);
    return APP_FAIL;

}

/**
* @brief 设置状态改变原因
* @param  *rsn      状态改变原因
*/
void ls_report_set_chg_rsn(const char* rsn)
{
    memset(s_ls_chg_rsn, 0, sizeof(s_ls_chg_rsn));
    strncpy(s_ls_chg_rsn, rsn, sizeof(s_ls_chg_rsn));
}

/**
* 网络连接成功后上报设备开关状态
*/
static void report_status_for_nwk_connected(void)
{
    // 上报一般网络重连的状态
    memset(s_ls_chg_rsn, 0, sizeof(s_ls_chg_rsn));
    strncpy(s_ls_chg_rsn, STAT_CHG_RSN_RECONNECT_STR, sizeof(s_ls_chg_rsn));
    ls_report_status();
}

/**
* @brief   上报模块初始化
* @return  void
*/
void ls_report_init(void)
{
    vesync_net_event_reg_nwk_conn_cb(report_status_for_nwk_connected);
}

/**
* @brief timer执行结果上报(http://34.194.32.46:8080/doc/BVH3a8uib)， deviceLogReport
* @param[in]  ls_timer_t       [灯带timer结构体]
* @param[in]  ret              [灯带timer执行结果]
* @param[in]  p_err_msg        [灯带timer执行失败原因]
* @return     int              [成功/失败]
*/
int ls_report_timing_exec(ls_timing_t *p_timer, uint8_t ret, char *p_err_msg)
{
    cJSON *json_dat = NULL;
    char buf[8];
    // 参数判断
    if (NULL == p_timer || NULL == p_err_msg)
    {
        APP_LOG(LOG_ERROR, "The parameter contains a null pointer!!\n");
        return APP_FAIL;
    }

    json_dat = cJSON_CreateObject();
    if (NULL == json_dat)
    {
        APP_LOG(LOG_ERROR, "Create data object fail\n");
        return APP_FAIL;
    }

    snprintf(buf, sizeof(buf), "off");
    if (LS_MODE_OFF != p_timer->mode)
    {
        snprintf(buf, sizeof(buf), "on");
    }

    cJSON_AddNumberToObject(json_dat, "timerID", p_timer->id);
    cJSON_AddStringToObject(json_dat, "act", buf);
    if (APP_OK == ret)
    {
        cJSON_AddStringToObject(json_dat, "result", "succ");
    }
    else
    {
        cJSON_AddStringToObject(json_dat, "result", "fail");
        cJSON_AddStringToObject(json_dat, "reason", p_err_msg);
    }

    ls_report_set_chg_rsn(STAT_CHG_RSN_TIMER_STR);
    return vesync_report_device_log(json_dat);

}

/**
* @brief Schedule执行结果上报(http://34.194.32.46:8080/doc/BVH3a8uib)， deviceLogReport
* @param[in] sche_id   [Schedule配置项ID]
* @param[in] type      [Schedule类型]
* @param[in] repeat    [重复配置]
* @param[in] p_app_cfg [APP的Action相关配置]
* @param[in] ret       [执行的返回码]
* @param[in] p_err_msg [指向失败的原因字符串]
* @return int          [成功/失败]
*/
int ls_report_sche_exec(uint32_t sche_id, uint8_t type, uint8_t repeat,
                                ls_schedule_t *p_app_cfg, uint8_t ret, char *p_err_msg)
{
    // Action描述字符串Buffer
    char buf[32] = {0};

    if (NULL == p_app_cfg || NULL == p_err_msg)
    {
        APP_LOG(LOG_ERROR, "The parameter contains a null pointer!\n");
        return APP_FAIL;
    }

    cJSON *json = cJSON_CreateObject();
    if (!cJSON_IsObject(json))
    {
        APP_LOG(LOG_ERROR, "Create data object fail\n");
        return APP_FAIL;
    }

    if (LS_MODE_OFF == p_app_cfg->mode)
    {
        snprintf(buf, sizeof(buf), "off");
    }
    else
    {
        snprintf(buf, sizeof(buf), "on");
    }

    cJSON_AddNumberToObject(json, "schID", sche_id);
    cJSON_AddNumberToObject(json, "type", type);
    cJSON_AddNumberToObject(json, "repeat", repeat);
    cJSON_AddStringToObject(json, "act", buf);

    if (APP_OK == ret)
    {
        cJSON_AddStringToObject(json, "result", "succ");
    }
    else
    {
        cJSON_AddStringToObject(json, "result", "fail");
        cJSON_AddStringToObject(json, "reason", p_err_msg);
    }

    ls_report_set_chg_rsn(STAT_CHG_RSN_SCHD_STR);
    return vesync_report_device_log(json);
}

