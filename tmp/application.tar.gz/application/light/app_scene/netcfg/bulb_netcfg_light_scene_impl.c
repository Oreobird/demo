/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved
* @file         netcfg_scene_impl.c
* @brief        配网场景回调业务实现
* @author       Joshua
* @date         2021-11-23
*/

#include <string.h>
#include "vesync_log.h"
#include "vesync_common.h"
#include "netcfg_light.h"

static int bulb_netcfg_wait(void)
{
    APP_LOG(LOG_DEBUG, "netcfg start\n");

    return APP_OK;
}

static int bulb_netcfg_process(void)
{
    APP_LOG(LOG_DEBUG, "netcfg running\n");

    return APP_OK;
}

static int bulb_netcfg_success(void)
{
    APP_LOG(LOG_DEBUG, "netcfg pass\n");

    return APP_OK;
}

static int bulb_netcfg_fail(void)
{
    APP_LOG(LOG_DEBUG, "netcfg fail\n");

    return APP_OK;
}

int netcfg_light_scene_impl_init(void)
{
    netcfg_light_scene_t light_scene;
    memset(&light_scene, 0, sizeof(netcfg_light_scene_t));
    light_scene.netcfg_waiting_light = bulb_netcfg_wait;
    light_scene.netcfg_process_light = bulb_netcfg_process;
    light_scene.netcfg_success_light = bulb_netcfg_success;
    light_scene.netcfg_fail_light = bulb_netcfg_fail;

    return netcfg_light_scene_reg(&light_scene);
}

