/***
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file    vhal_wifi.h
 * @brief   bl602 Wi-Fi驱动硬件抽象层
 * @author  Charles.Mei
 * @date    2021-3-8
 */

#ifndef _VHAL_WIFI_INTERNAL_H_
#define _VHAL_WIFI_INTERNAL_H_

#include <stdint.h>
#include <stdbool.h>

#include "vesync_common.h"

#ifdef __cplusplus
extern "C" {
#endif


/* copy from wifi_mgmr_ext.c */
#define WIFI_SCAN_MAX_AP      (WIFI_MGMR_SCAN_ITEMS_MAX)  // refer to WIFI_MGMR_SCAN_ITEMS_MAX in bl602_wifidrv\bl60x_wifi_driver\wifi_mgmr.h

// WiFi状态、网络状态事件标志组位定义,置位表示已连接
#define EVENT_BIT_WIFI_STATUS               0X00000001
#define EVENT_BIT_NETWORK_STATUS            0X00000002
#define EVENT_BIT_NET_WIFI_DISCONNECT       0x00000004


#ifdef __cplusplus
}
#endif

#endif

