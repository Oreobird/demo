/**
 * Copyright © Etekcity Technologies Co., Ltd. 2021. All rights reserved.
 * @file        vesync_wifi_context.h
 * @brief       wifi context
 * @author      Owen.zhang
 * @date        2020-04-22
 */

#ifndef _FFS_WIFI_CONTEXT_H_
#define _FFS_WIFI_CONTEXT_H_

#include "ffs/common/ffs_result.h"
#include "ffs/common/ffs_wifi.h"
#include "ffs_linked_list.h"

#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
* @brief Ffs Wi-Fi context structure
 */
typedef struct
{
    FfsLinkedList_t connectionAttemptList;              //!< Wi-Fi connection attempts.
    FfsLinkedList_t configurationList;                  //!< Wi-Fi configuration list.
    FFS_WIFI_CONNECTION_STATE state; //!< Wi-Fi connection state.
} FfsWifiContext_t;

/**
 * @brief Initialize a Ffs Wi-Fi context.
 * @param[in] wifiContext Ffs Wi-Fi context structure
 * @returns Enumerated [result](@ref FFS_RESULT)
 */
FFS_RESULT ffsInitializeWifiContext(FfsWifiContext_t *wifiContext);

/**
 * @brief Deinitialize a Ffs Wi-Fi context.
 * @param[in] wifiContext Ffs Wi-Fi context structure
 * @returns Enumerated [result](@ref FFS_RESULT)
 */
FFS_RESULT ffsDeinitializeWifiContext(FfsWifiContext_t *wifiContext);

/**
 * @brief Update the Wi-Fi connection details.
 * @param[in] wifiContext Ffs Wi-Fi context structure
 * @param[in] configuration Wi-Fi configuration
 * @returns Enumerated [result](@ref FFS_RESULT)
 */
FFS_RESULT ffsUpdateWifiConnectionDetails(FfsWifiContext_t *wifiContext,
        FfsWifiConfiguration_t *configuration);

/**
 * @brief Update the Wi-Fi connection state.
 * @param[in] wifiContext Ffs Wi-Fi context structure
 * @param[in] state Wi-Fi connection state
 * @returns Enumerated [result](@ref FFS_RESULT)
 */
FFS_RESULT ffsUpdateWifiConnectionState(FfsWifiContext_t *wifiContext,
        FFS_WIFI_CONNECTION_STATE state);

/**
 * @brief Update the Wi-Fi connection state in the failure case.
 * @param[in] wifiContext Ffs Wi-Fi context structure
 * @param[in] errorDetails Error details object
 * @returns Enumerated [result](@ref FFS_RESULT)
 */
FFS_RESULT ffsUpdateWifiConnectionFailure(FfsWifiContext_t *wifiContext,
        const FfsErrorDetails_t *errorDetails);

#ifdef __cplusplus
}
#endif

#endif /* _FFS_WIFI_CONTEXT_H_ */
