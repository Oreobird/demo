/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_net_service.h
 * @brief       网络服务接口
 * @date        2021-05-27
 */

#ifndef __VESYNC_NET_SERVICE_H__
#define __VESYNC_NET_SERVICE_H__

#include <stdbool.h>

#ifdef __cplusplus
extern "C"
{
#endif /* __cplusplus */


/**
 * @brief  收到ack回调接口
 */
typedef void (*net_recv_ack_cb_t)(void);


/**
 * @brief 数据topic类型
 */
typedef enum
{
    NET_DATA_TOPIC_STATUS   = 0,    // 状态，设备端的运行状态，通常描述设备的工作情况和运行特征。包含：开关，挡位，速度等。
    NET_DATA_TOPIC_DATA     = 1,    // 数据，设备运行过程中所产生的运行数据，它通常与设备状态无关，包含：用电量，空气质量，湿度等。
    NET_DATA_TOPIC_LOG      = 2,    // 日志，设备运行过程中由软件打印的运行日志，它被用于分析设备状况。
    NET_DATA_TOPIC_RESP     = 3,    // bypass reply/ack topic
    NET_DATA_TOPIC_BYPASS   = 4,    // 云端发送的bypass消息
    NET_DATA_TOPIC_NON_BYPASS = 5,  // 云端发送的非bypass消息
} NET_DATA_TOPIC_TYPE_E;


/**
 * @brief 发送等级 QoS
 */
typedef enum
{
    SEND_QOS0 = 0,
    SEND_QOS1 = 1,
    SEND_QOS2 = 2,
} SEND_QOS_E;


/**
 * @brief 网络在线/离线状态
 */
typedef enum
{
    NETWORK_OFFLINE = 0,           // 连接断开
    NETWORK_ONLINE,                // 已连接服务器
    NETWORK_UNKNOW,
} VESYNC_NETWORK_STATUS_E;


/**
 * @brief  数据发送，可设置qos及收到回包后回调函数
 * @param[in]  topic_type            [topic类型]
 * @param[in]  p_data                 [数据指针]
 * @param[in]  len                   [数据的长度]
 * @param[in]  qos                   [qos级别，当前支持0和1]
 * @param[in]  ack_cb                [收到回包后回调函数指针]
 * @return     int                   [-1:失败, >=0:成功]
 */
int vesync_net_client_send(NET_DATA_TOPIC_TYPE_E topic_type, const char *p_data, int len, SEND_QOS_E qos,
                                net_recv_ack_cb_t ack_cb);


/**
 * @brief  获取设备是否已配网
 * @param[in]  void         [无]
 * @return  bool            [true-配过网，false-未配过网]
 */
bool vesync_net_is_configured(void);


/**
 * @brief  获取网络服务客户端在线状态
 * @return  VESYNC_NETWORK_STATUS_E  [mqtt客户端在线状态]
 */
VESYNC_NETWORK_STATUS_E vesync_net_client_get_status(void);


/**
 * @brief 向网络服务事件注册网络连接成功事件回调，提供给应用层的接口
 * @param[in]  nwk_con_cb            [指向回调函数]
 * @return  int                      [成功：SDK_OK，失败：SDK_FAIL]
 */
int vesync_net_event_reg_nwk_conn_cb(void (*nwk_con_cb)(void));


/**
 * @brief 向网络服务事件注销网络连接成功事件回调，提供给应用层的接口
 * @return  int                      [成功：SDK_OK，失败：SDK_FAIL]
 */
int vesync_net_event_unreg_nwk_conn_cb(void);


#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* __VESYNC_NET_SERVICE_H__ */

