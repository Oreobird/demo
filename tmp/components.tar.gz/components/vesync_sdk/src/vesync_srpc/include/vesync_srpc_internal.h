/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_srpc_internal.h
 * @brief       vesync SRPC模块的内部接口定义
 * @author      Herve
 * @date        2021-12-28
 */
#ifndef __VESYNC_SRPC_INTERNAL_H__
#define __VESYNC_SRPC_INTERNAL_H__

#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>

#include "cJSON.h"

#include "vesync_frame.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief Vesync SRPC初始化接口
 * @return      int                 [SDK_OK/SDK_FAIL]
 */
int vesync_srpc_init(void);

/**
 * @brief Vesync SRPC响应的测试接口，接收Bypass的请求JSON后模拟SRPC的请求调用
 * @param[in]   p_bp_msg            [Bypass JSON请求对象，不会在方法内被销毁]
 */
void vesync_srpc_mock_for_request_recv(cJSON *p_bp_msg);

/**
 * @brief Vesync SRPC发送Bypass JSON响应接口
 * @param[in]   p_method            [该响应的方法名字符串]
 * @param[in]   p_resp              [Bypass JSON响应对象，不会在方法内被销毁]
 * @return      int                 [SDK_OK/SDK_FAIL]
 */
int vesync_srpc_send_response(const char *p_method, cJSON *p_resp);

#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_SRPC_INTERNAL_H__ */