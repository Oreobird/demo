/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        switch_report.c
 * @brief       switch上报
 * @author      Charles.Mei
 * @date        2021-08-03
 */


#include <string.h>

#include "cJSON.h"

#include "vesync_common.h"
#include "vesync_log.h"
#include "vesync_device.h"
#include "vesync_report.h"

#include "switch_app.h"
#include "switch_report.h"

/**
 * @brief 设备状态变化，通知云端(http://34.194.32.46:8080/doc/POOTQH6Bs)，方法名：statusChangeNtyV2
 * @param[in]  status            [开关状态]
 * @return     int               [成功/失败]
 */
int switch_report_status_change(const switch_status_t* status)
{
    int ret = APP_FAIL;
    cJSON *json_data = NULL;
    cJSON *json_chg_stat = NULL;
    cJSON *json_unchg_stat = NULL;
    cJSON *json_chg_device_No1 = NULL;
    cJSON *json_chg_device_No2 = NULL;
    cJSON *json_unchg_device_No1 = NULL;
    cJSON *json_unchg_device_No2 = NULL;

    json_data = cJSON_CreateObject();
    if(NULL == json_data)
    {
        APP_LOG(LOG_ERROR, "Create data object fail");
        return APP_FAIL;
    }

    cJSON_AddItemToObject(json_data, "changedStatus", json_chg_stat = cJSON_CreateObject());
    cJSON_AddItemToObject(json_data, "unchangedStatus", json_unchg_stat = cJSON_CreateObject());
    cJSON_AddStringToObject(json_data, "changeReason", (char*)status->chg_rsn);

    if (NULL == json_chg_stat || NULL == json_unchg_stat)
    {
        APP_LOG(LOG_ERROR, "Create data object fail");
        ret = APP_FAIL;
        goto exit;
    }

    // 当changeReason为Setup/Reconnect/Unknown时，所有状态放在 unchangedStatus
    if (0 == strcmp((char*)status->chg_rsn, STAT_CHG_RSN_NONE_STR) ||
        0 == strcmp((char*)status->chg_rsn, STAT_CHG_RSN_CONFIG_NET_STR) ||
        0 == strcmp((char*)status->chg_rsn, STAT_CHG_RSN_RECONNECT_STR))
    {
        json_unchg_device_No1 = NULL;
        json_unchg_device_No2 = NULL;
        cJSON_AddItemToObject(json_unchg_stat, "subDeviceNo1", json_unchg_device_No1 = cJSON_CreateObject());
        cJSON_AddItemToObject(json_unchg_stat, "subDeviceNo2", json_unchg_device_No2 = cJSON_CreateObject());
        if (NULL == json_unchg_device_No1 || NULL == json_unchg_device_No2)
        {
            ret = APP_FAIL;
            goto exit;
        }

        cJSON_AddStringToObject(json_unchg_device_No1, "switch0", status->light.onoff ? "on" : "off");
        cJSON_AddNumberToObject(json_unchg_device_No1, "percent", status->light.net_lightness);
        cJSON_AddNumberToObject(json_unchg_device_No1, "level", status->light.level);

        cJSON_AddStringToObject(json_unchg_device_No2, "switch0", status->fan.onoff ? "on" : "off");
        cJSON_AddNumberToObject(json_unchg_device_No2, "level", status->fan.level);
    }
    else
    {
        // 没有状态改变，无需上报
        if (0 == status->light.report_flag && 0 == status->fan.report_flag)
        {
            ret = APP_OK;
            goto exit;
        }

        // 子设备无需要上报的则不需要添加对应object
        json_chg_device_No1 = NULL;
        json_unchg_device_No1 = NULL;
        if (LIGHT_ONOFF_CHANGE_FLAG == (status->light.report_flag & LIGHT_ONOFF_CHANGE_FLAG))
        {
            if (NULL == json_chg_device_No1)
            {
                cJSON_AddItemToObject(json_chg_stat, "subDeviceNo1", json_chg_device_No1 = cJSON_CreateObject());
                if (NULL == json_chg_device_No1)
                {
                    ret = APP_FAIL;
                    goto exit;
                }
            }
            cJSON_AddStringToObject(json_chg_device_No1, "switch0", status->light.onoff ? "on" : "off");
        }
        else
        {
            if (NULL == json_unchg_device_No1)
            {
                cJSON_AddItemToObject(json_unchg_stat, "subDeviceNo1", json_unchg_device_No1 = cJSON_CreateObject());
                if (NULL == json_unchg_device_No1)
                {
                    ret = APP_FAIL;
                    goto exit;
                }
            }
            cJSON_AddStringToObject(json_unchg_device_No1, "switch0", status->light.onoff ? "on" : "off");
        }
        if (LIGHT_LIGHTNESS_CHANGE_FLAG == (status->light.report_flag & LIGHT_LIGHTNESS_CHANGE_FLAG))
        {
            if (NULL == json_chg_device_No1)
            {
                cJSON_AddItemToObject(json_chg_stat, "subDeviceNo1", json_chg_device_No1 = cJSON_CreateObject());
                if (NULL == json_chg_device_No1)
                {
                    ret = APP_FAIL;
                    goto exit;
                }
            }
            cJSON_AddNumberToObject(json_chg_device_No1, "percent", status->light.net_lightness);
        }
        else
        {
            if (NULL == json_unchg_device_No1)
            {
                cJSON_AddItemToObject(json_unchg_stat, "subDeviceNo1", json_unchg_device_No1 = cJSON_CreateObject());
                if (NULL == json_unchg_device_No1)
                {
                    ret = APP_FAIL;
                    goto exit;
                }
            }
            cJSON_AddNumberToObject(json_unchg_device_No1, "percent", status->light.net_lightness);
        }
        if (LIGHT_LEVEL_CHANGE_FLAG == (status->light.report_flag & LIGHT_LEVEL_CHANGE_FLAG))
        {
            if (NULL == json_chg_device_No1)
            {
                cJSON_AddItemToObject(json_chg_stat, "subDeviceNo1", json_chg_device_No1 = cJSON_CreateObject());
                if (NULL == json_chg_device_No1)
                {
                    ret = APP_FAIL;
                    goto exit;
                }
            }
            cJSON_AddNumberToObject(json_chg_device_No1, "level", status->light.level);
        }
        else
        {
            if (NULL == json_unchg_device_No1)
            {
                cJSON_AddItemToObject(json_unchg_stat, "subDeviceNo1", json_unchg_device_No1 = cJSON_CreateObject());
                if (NULL == json_chg_device_No1)
                {
                    ret = APP_FAIL;
                    goto exit;
                }
            }
            cJSON_AddNumberToObject(json_unchg_device_No1, "level", status->light.level);
        }

        // 子设备无需要上报的则不需要添加对应object
        json_chg_device_No2 = NULL;
        json_unchg_device_No2 = NULL;
        if (FAN_ONOFF_CHANGE_FLAG == (status->fan.report_flag & FAN_ONOFF_CHANGE_FLAG))
        {
            if (NULL == json_chg_device_No2)
            {
                cJSON_AddItemToObject(json_chg_stat, "subDeviceNo2", json_chg_device_No2 = cJSON_CreateObject());
                if (NULL == json_chg_device_No2)
                {
                    ret = APP_FAIL;
                    goto exit;
                }
            }
            cJSON_AddStringToObject(json_chg_device_No2, "switch0", status->fan.onoff ? "on" : "off");
        }
        else
        {
            if (NULL == json_unchg_device_No2)
            {
                cJSON_AddItemToObject(json_unchg_stat, "subDeviceNo2", json_unchg_device_No2 = cJSON_CreateObject());
                if (NULL == json_unchg_device_No2)
                {
                    ret = APP_FAIL;
                    goto exit;
                }
            }
            cJSON_AddStringToObject(json_unchg_device_No2, "switch0", status->fan.onoff ? "on" : "off");
        }
        if (FAN_LEVEL_CHANGE_FLAG == (status->fan.report_flag & FAN_LEVEL_CHANGE_FLAG))
        {
            if (NULL == json_chg_device_No2)
            {
                cJSON_AddItemToObject(json_chg_stat, "subDeviceNo2", json_chg_device_No2 = cJSON_CreateObject());
                if (NULL == json_chg_device_No2)
                {
                    ret = APP_FAIL;
                    goto exit;
                }
            }
            cJSON_AddNumberToObject(json_chg_device_No2, "level", status->fan.level);
        }
        else
        {
            if (NULL == json_unchg_device_No2)
            {
                cJSON_AddItemToObject(json_unchg_stat, "subDeviceNo2", json_unchg_device_No2 = cJSON_CreateObject());
                if (NULL == json_unchg_device_No2)
                {
                    ret = APP_FAIL;
                    goto exit;
                }
            }
            cJSON_AddNumberToObject(json_unchg_device_No2, "level", status->fan.level);
        }
    }

    if (SDK_OK != vesync_report_status_change_nty(json_data))
    {
        return APP_FAIL;
    }
    return APP_OK;
exit:
    cJSON_Delete(json_data);
    return ret;
}

/**
 * @brief timer执行结果上报(http://34.194.32.46:8080/doc/BVH3a8uib)， deviceLogReport
 * @param[in]  dev_id           [设备id]
 * @param[in]  action           [动作]
 * @param[in]  ret              [timer执行结果]
 * @param[in]  p_err_msg        [timer执行失败原因]
 * @return     int              [成功/失败]
 */
int switch_report_timing_exec(DEVICE_ID_E dev_id, void *action, uint8_t ret, char *p_err_msg)
{
    cJSON *json_data = NULL;

    // 参数判断
    if (dev_id >= DEVICE_MAX || NULL == action || NULL == p_err_msg)
    {
        APP_LOG(LOG_ERROR, "invalid parameter!!\n");
        return APP_FAIL;
    }

    json_data = cJSON_CreateObject();
    if (NULL == json_data)
    {
        APP_LOG(LOG_ERROR, "Create object fail\n");
        return APP_FAIL;
    }

    switch (dev_id)
    {
        case DEVICE_LIGHT:
            cJSON_AddStringToObject(json_data, "subDeviceType", "light");
            if (false == ((light_action_t*)action)->onoff)
            {
                cJSON_AddStringToObject(json_data, "act", "timer exec: switch=off");
            }
            else
            {
                cJSON_AddStringToObject(json_data, "act", "timer exec: switch=on");
                if (0 != ((light_action_t*)action)->lightness)
                {
                    cJSON_AddNumberToObject(json_data, "percent", ((light_action_t*)action)->lightness);
                }
            }
            if (0 != ((light_action_t*)action)->duration)
            {
                cJSON_AddNumberToObject(json_data, "duration", ((light_action_t*)action)->duration);
            }
            break;
        case DEVICE_FAN:
            cJSON_AddStringToObject(json_data, "subDeviceType", "fan");
            if (false == ((fan_action_t*)action)->onoff)
            {
                cJSON_AddStringToObject(json_data, "act", "timer exec: switch=off");
            }
            else
            {
                cJSON_AddStringToObject(json_data, "act", "timer exec: switch=on");
                if (0 != ((fan_action_t*)action)->level)
                {
                    cJSON_AddNumberToObject(json_data, "level", ((fan_action_t*)action)->level);
                }
            }
            break;
        default:
            goto exit;

    }
    if (APP_OK == ret)
    {
        cJSON_AddStringToObject(json_data, "result", "success");
    }
    else
    {
        cJSON_AddStringToObject(json_data, "result", "fail");
        cJSON_AddStringToObject(json_data, "reason", p_err_msg);
    }

    if (SDK_OK != vesync_report_device_log(json_data))
    {
        return APP_FAIL;
    }
    return APP_OK;
exit:
    cJSON_Delete(json_data);
    return APP_FAIL;
}

/**
 * @brief schedule执行结果上报(http://34.194.32.46:8080/doc/BVH3a8uib)， deviceLogReport
 * @param[in]  dev_id           [设备id]
 * @param[in]  sch_cfg          [schedule配置]
 * @param[in]  action           [动作]
 * @param[in]  ret              [schedule执行结果]
 * @param[in]  p_err_msg        [schedule执行失败原因]
 * @return     int              [成功/失败]
 */
int switch_report_schedule_exec(DEVICE_ID_E dev_id, vesync_schedule_t *sch_cfg, void *action, uint8_t ret, char *p_err_msg)
{
    cJSON *json_data = NULL;

    // 参数判断
    if (dev_id >= DEVICE_MAX || NULL == action || NULL == p_err_msg)
    {
        APP_LOG(LOG_ERROR, "invalid parameter!!\n");
        return APP_FAIL;
    }

    json_data = cJSON_CreateObject();
    if (NULL == json_data)
    {
        APP_LOG(LOG_ERROR, "Create object fail\n");
        return APP_FAIL;
    }

    cJSON_AddNumberToObject(json_data, "schID", sch_cfg->id);
    cJSON_AddNumberToObject(json_data, "type", sch_cfg->type);
    cJSON_AddNumberToObject(json_data, "repeat", sch_cfg->repeat_config);

    switch (dev_id)
    {
        case DEVICE_LIGHT:
            cJSON_AddStringToObject(json_data, "subDeviceType", "light");
            if (false == ((light_action_t*)action)->onoff)
            {
                cJSON_AddStringToObject(json_data, "act", "schedule exec: switch=off");
            }
            else
            {
                cJSON_AddStringToObject(json_data, "act", "schedule exec: switch=on");
                if (0 != ((light_action_t*)action)->lightness)
                {
                    cJSON_AddNumberToObject(json_data, "percent", ((light_action_t*)action)->lightness);
                }
            }
            if (0 != ((light_action_t*)action)->duration)
            {
                cJSON_AddNumberToObject(json_data, "duration", ((light_action_t*)action)->duration);
            }
            break;
        case DEVICE_FAN:
            cJSON_AddStringToObject(json_data, "subDeviceType", "fan");
            if (false == ((fan_action_t*)action)->onoff)
            {
                cJSON_AddStringToObject(json_data, "act", "timer exec: switch=off");
            }
            else
            {
                cJSON_AddStringToObject(json_data, "act", "timer exec: switch=on");
                if (0 != ((fan_action_t*)action)->level)
                {
                    cJSON_AddNumberToObject(json_data, "level", ((fan_action_t*)action)->level);
                }
            }
            break;
        default:
            goto exit;

    }

    if (APP_OK == ret)
    {
        cJSON_AddStringToObject(json_data, "result", "success");
    }
    else
    {
        cJSON_AddStringToObject(json_data, "result", "fail");
        cJSON_AddStringToObject(json_data, "reason", p_err_msg);
    }

    if (SDK_OK != vesync_report_device_log(json_data))
    {
        return APP_FAIL;
    }
    return APP_OK;
exit:
    cJSON_Delete(json_data);
    return APP_FAIL;
}


