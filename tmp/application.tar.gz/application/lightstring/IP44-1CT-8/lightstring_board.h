/**
* Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file    lightstring_board.h
* @brief   灯串配置
* @author  Lind
* @date     2021-12-13
*/

#ifndef __LIGHTSTRING_BOARD__
#define __LIGHTSTRING_BOARD__

#include "vhal_led.h"

#ifdef __cplusplus
extern "C" {
#endif

#define LS_MIC_IO           (1)     // mic(adc) io
#define LS_BUTTON_IO        (3)     // 按键io
#define LS_LED_OUT1_IO      (4)     // LED输出1 PWM
#define LS_LED_OUT2_IO      (5)     // LED输出2 PWM
#define LS_IR_RX_IO         (21)     // 红外接收io
#define LS_WIFI_LED_IO      (7)     // wifi指示灯io

#define LS_MODE_NUM         (8)     // 灯串场景模式数量
#define LS_MODE_MUSIC_NUM   (4)     // 音乐模式数量
#define LS_LED_CH0          LED_CH0 // LED通道0
#define LS_LED_CH1          LED_CH1 // LED通道1
#define LS_LED_NUM          (2)     // LED通道数
#define LS_LED_PWM_RST      (1024)  // led pwm分辨率
#define LS_LED_USER_MIN_BRIGHTNESS           (0.15)                  // 用户可调最低亮度
#define LS_LED_MIN_BRIGHTNESS                (0.05)                  // 实际最低亮度
#define LS_LED_MAX_BRIGHTNESS                (0.8)                   // 实际最高亮度

#ifdef __cplusplus
}
#endif

#endif /* __LIGHTSTRING_BOARD__ */

