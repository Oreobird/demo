/**
*Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
* @file    ledstrip_device.h
* @brief   设备重置
* @author  Lind
*@date     2021-09-30
*/

#ifndef __LEDSTRIP_DEVICE_H__
#define __LEDSTRIP_DEVICE_H__

#ifdef __cplusplus
extern "C" {
#endif


/**
* @brief ledstrip设备管理初始化
*/
void ls_device_init(void);

#ifdef __cplusplus
}
#endif

#endif

