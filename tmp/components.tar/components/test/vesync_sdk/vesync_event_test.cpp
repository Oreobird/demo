/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_event_test.cpp
 * @brief       vesync event测试用例
 * @author      Joshua
 * @date        2021-05-13
 */


#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <gtest/gtest.h>
#include "vesync_os.h"
#include "vesync_task.h"
#include "vesync_sem.h"
#include "vesync_common.h"
#include "vesync_event_internal.h"

static vesync_sem_t g_sem;

static int task1_cb(void *data)
{
    vesync_ev_t *event = (vesync_ev_t*) data;
    printf("task1: event_id=%d, pub_id=%d, len=%d\n", event->event_id, event->pub_id, event->len);
    return SDK_OK;
}

static void subscribe_task1(void *arg)
{
    UNUSED(arg);

    int ret = vesync_event_subscribe(EVENT_WIFI_DISCONNECTED, 1, task1_cb);
    EXPECT_EQ(ret, SDK_OK);

    vesync_sem_signal(&g_sem);
    vesync_task_free(0);
}

static int task2_cb(void *data)
{
    vesync_ev_t *event = (vesync_ev_t*) data;
    printf("task2: event_id=%d, pub_id=%d, len=%d\n", event->event_id, event->pub_id, event->len);
    
    int ret = vesync_event_unsubscribe(EVENT_WIFI_CONNECTED, 2);
    EXPECT_EQ(ret, SDK_OK);
    return SDK_OK;
}

static void subscribe_task2(void *arg)
{
    UNUSED(arg);
    int ret = vesync_event_subscribe(EVENT_WIFI_CONNECTED, 2, task2_cb);
    EXPECT_EQ(ret, SDK_OK);
    
    vesync_sem_signal(&g_sem);
    vesync_task_free(0);
}

static void publish_task1(void *arg)
{
    vesync_ev_t event;
    event.event_id = EVENT_WIFI_CONNECTED;
    event.len = 0;
    event.pub_id = 1;
    int ret = vesync_event_publish(&event);
    EXPECT_EQ(ret, SDK_OK);

    event.event_id = EVENT_WIFI_DISCONNECTED;
    event.len = 0;
    event.pub_id = 1;
    ret = vesync_event_publish(&event);
    EXPECT_EQ(ret, SDK_OK);

    vesync_sem_signal(&g_sem);
    vesync_task_free(0);
}

static void publish_task2(void *arg)
{
    vesync_ev_t event;
    event.event_id = EVENT_WIFI_CONNECTED;
    event.len = 0;
    event.pub_id = 2;
    int ret = vesync_event_publish(&event);
    EXPECT_EQ(ret, SDK_OK);

    vesync_sem_signal(&g_sem);
    vesync_task_free(0);
}

TEST(event_test, multi_publisher)
{
    int ret = -1;
    vesync_sem_new(&g_sem);

    ret = vesync_event_init();
    EXPECT_EQ(ret, SDK_OK);

    vesync_task_new("DISCONNECTED", subscribe_task1, NULL, 1024, 0, NULL);
    vesync_sem_wait(&g_sem, VESYNC_OS_WAIT_FOREVER);
    
    vesync_task_new("CONNECTED", subscribe_task2, NULL, 1024, 0, NULL);
    vesync_sem_wait(&g_sem, VESYNC_OS_WAIT_FOREVER);

    vesync_task_new("publisher_A", publish_task1, NULL, 1024, 0, NULL);
    vesync_sem_wait(&g_sem, VESYNC_OS_WAIT_FOREVER);

    vesync_task_new("publisher_B", publish_task2, NULL, 1024, 0, NULL);
    vesync_sem_wait(&g_sem, VESYNC_OS_WAIT_FOREVER);

    ret = vesync_sem_free(&g_sem);
}


