/*
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_bypass_set_device_trigger.c
 * @brief       bypass处理接口
 * @date        2021-05-17
 */

#include <string.h>
#include "vesync_common.h"
#include "vesync_memory.h"
#include "vesync_bypass_internal.h"

//联动触发固定上报时间最小间隔
#define BP_SET_DEVICE_TRIGGER_INTERVAL_MIN      (60)

/**
 * @brief 设置设备触发值数据解析
 * @param p_trace_msg trace message
 * @param json数据指针
 * @return BYPASS_ERR_E
 */
static BYPASS_ERR_E bypass_method_set_device_trigger_handle(bypass_trace_msg_t *p_trace_msg, cJSON *json)
{
    BYPASS_ERR_E ret = BP_OK;
    cJSON* json_data = NULL;

    if ((NULL == json) || (NULL == p_trace_msg))
        return BP_ERROR;

    bypass_set_device_trigger_t *p_trigger_para = (bypass_set_device_trigger_t *)vesync_malloc(sizeof(bypass_set_device_trigger_t));
    if (NULL == p_trigger_para)
    {
        return BP_ERR_NOMEM;
    }

    memset(p_trigger_para, 0, sizeof(bypass_set_device_trigger_t));

    json_data = cJSON_GetObjectItemCaseSensitive(json, "id");
    if (cJSON_IsNumber(json_data))
    {
        p_trigger_para->sensor_id = json_data->valueint;

    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "enabled");
    if (cJSON_IsBool(json_data))
    {
        p_trigger_para->enable = json_data->valueint;
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "type");
    if (cJSON_IsString(json_data))
    {
        if (strncmp(json_data->valuestring, "pm25", strlen("pm25")) == 0)
        {
            p_trigger_para->sensor_type = BP_SENSOR_PM25;
        }
        else if (strncmp(json_data->valuestring, "humidity", strlen("humidity")) == 0)
        {
            p_trigger_para->sensor_type = BP_SENSOR_HUMIDITY;
        }
        else
        {
            ret = BP_ERR_ARG;
            goto _exit;
        }
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "threshold");
    if (cJSON_IsNumber(json_data))
    {
        p_trigger_para->threshold = json_data->valueint;
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    json_data = cJSON_GetObjectItemCaseSensitive(json, "interval_sec");
    if (cJSON_IsNumber(json_data))
    {
        p_trigger_para->interval_sec = json_data->valueint;
        if (p_trigger_para->interval_sec < BP_SET_DEVICE_TRIGGER_INTERVAL_MIN)
        {
            ret = BP_ERR_ARG;
            goto _exit;
        }
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_SET_DEVICE_TRIGGER);
    if (method_cb)
    {
        method_cb(p_trace_msg, (void*)p_trigger_para, sizeof(bypass_set_device_trigger_t));
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

_exit:

    vesync_free(p_trigger_para);
    return ret;
}

/**
 * @brief 获取设备触发值数据
 * @param p_trace_msg trace message
 * @param json数据指针
 * @return BYPASS_ERR_E
 */
static BYPASS_ERR_E bypass_method_get_device_trigger_handle(bypass_trace_msg_t *p_trace_msg, cJSON *json)
{
    BYPASS_ERR_E ret = BP_OK;
    cJSON* json_data = NULL;
    if (NULL == p_trace_msg)   return BP_ERROR;

    bypass_get_device_trigger_t *p_trigger_para = ( bypass_get_device_trigger_t *)vesync_malloc(sizeof(bypass_get_device_trigger_t));
    if (NULL == p_trigger_para)
    {
        return BP_ERR_NOMEM;
    }

    memset(p_trigger_para, 0, sizeof(bypass_get_device_trigger_t));

    json_data = cJSON_GetObjectItemCaseSensitive(json, "id");
    if (cJSON_IsNumber(json_data))
    {
        if (json_data->valueint < 0)
            goto _exit;

        p_trigger_para->sensor_id = json_data->valueint;
    }
    else
    {
        ret = BP_ERR_ARG;
        goto _exit;
    }

    bypass_method_cb_t method_cb = vesync_bypass_get_method_cb_by_id(BYPASS_METHOD_ID_GET_DEVICE_TRIGGER);
    if (method_cb)
    {
        method_cb(p_trace_msg,  (void*)p_trigger_para, sizeof(bypass_get_device_trigger_t));
    }
    else
    {
        ret = BP_ERR_APP_CB_NULL;
    }

_exit:

    vesync_free(p_trigger_para);
    return ret;
}


static bypass_item_data_t set_device_trigger_method_tbl[] = {
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_SET_DEVICE_TRIGGER, "setDeviceTrigger", bypass_method_set_device_trigger_handle, NULL},
    {BP_AUTH_MSG_FROM_MQTT_LOCAL, BYPASS_METHOD_ID_GET_DEVICE_TRIGGER, "getDeviceTrigger", bypass_method_get_device_trigger_handle, NULL},
};

void vesync_bypass_set_device_trigger_init(void)
{
    for (int i = 0; i < SIZEOF_ARRAY(set_device_trigger_method_tbl); i++)
    {
        bypass_item_t *item = vesync_bypass_init_item(&set_device_trigger_method_tbl[i]);
        if (item != NULL)
        {
            vesync_bypass_add_item(item);
        }
    }
}
