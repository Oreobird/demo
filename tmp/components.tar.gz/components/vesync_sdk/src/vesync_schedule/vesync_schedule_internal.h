/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        vesync_schedule_internal.h
 * @brief       Schedule模块接口定义
 * @author      Herve.lin, Niki
 * @date        2021-06-22
 */

#ifndef __VESYNC_SCHEDULE_INTERNAL_H__
#define __VESYNC_SCHEDULE_INTERNAL_H__

#include <stdint.h>
#include <stdbool.h>

#include "vesync_list.h"
#include "vesync_timer.h"
#include "vesync_mutex.h"
#include "vesync_schedule.h"
#include "vesync_cfg_internal.h"

#ifdef __cplusplus
extern "C"
{
#endif

#define SCHEDULE_DEBUG_PRINT 0                          // Schedule 模块内部调试打印开关宏
#define SCHEDULE_CFG_VERSION (PR_SCHEDULE_CFG_VERSION)  // Schedule 配置版本定义
#define SCHEDULE_CYCLE_TIMER_INTERVAL (10000)           // 定时器轮询间隔
#define SCHEDULE_INVALID_MINUTE (0xFF)                  // 非法的分钟数定义，用于分钟类计数的初始化
#define SCHEDULE_DEFAULT_USER_CFG_KEY "sche_cfg"        // Schedule模块配置存储KEY
#define SCHEDULE_MGT_INIT_VAL   {is_init:false}         // Schedule模块管理结构体初始化值

// 允许的最大创建实例数量
#ifdef PR_SCHEDULE_MAX_INST_NBR
#define SCHEDULE_MAX_INSTANCES_NBR (PR_SCHEDULE_MAX_INST_NBR)
#else
#define SCHEDULE_MAX_INSTANCES_NBR (3)
#endif

#define SCHEDULE_CHECK(a, err) if(!(a)) { \
        err;                              \
    }

/**
 * @brief Schedule相关数据一级key定义
 */
typedef enum
{
    SCHEDULE_KEY_VERSION = 0,       // 配置数据版本
    SCHEDULE_KEY_NUMBER = 1,        // Schedule动作数量
    SCHEDULE_KEY_ACTION_ARR = 0xF0, // Schedule动作，为一个数组，因此key定义为FF
    SCHEDULE_KEY_MAX
} SCHEDULE_CFG_KEY_E;

/**
 * @brief Schedule动作信息key定义
 */
typedef enum
{
    ACTION_KEY_ID = 0,              // Schedule ID
    ACTION_KEY_EABLED = 1,          // 配置项是否使能
    ACTION_KEY_TYPE = 2,            // Schedule类型
    ACTION_KEY_EVENT_CFG = 3,       // Schedule类型相关事件配置
    ACTION_KEY_REPEAT_FLAG = 4,     // Schedule的重复功能配置
    ACTION_KEY_APP_CFG = 5,         // 应用层的配置信息，通常是任务Action的定义
    ACTION_KEY_MODIFY_LOCAL_TS = 6, // 配置项修改时的本地时间戳，
    ACTION_KEY_EXEC_CNT = 7,        // 执行次数计数
    ACTION_KEY_MAX
} SCHEDULE_ACTION_KEY_E;

/**
 * @brief Schedule Context
 */
typedef struct
{
    vesync_schedule_t config; // Schedule 配置项
    vesync_buf_t app_cfg;     // 应用层的配置数据，通常是任务Action的定义
    uint32_t modify_local_ts; // 配置项修改时的本地时间戳，可以在判断时，随时区的变化偏移过期的时间
    uint32_t exec_cnt;        // 执行次数计数
} schedule_ctx_t;

/**
 * @brief Schedule 链表节点结构体
 */
typedef struct
{
    schedule_ctx_t data;
    struct list_head list;
} schedule_node_t;

/**
 * @brief Schedule内部函数，配置项序列化
 * @param[in]  sch_nbr              [给定的配置项数量]
 * @param[in]  p_sch_head           [指向Schedule配置项链表头]
 * @param[out] p_buf                [指向序列化二进制输出缓存]
 * @param[out] buf_len              [序列化二进制输出缓存的长度]
 * @param[out] p_out_size           [指向输出序列化二进制长度的缓存]
 * @return int                      [SCHE_RESULT_E]
 */
int sche_cfg_marshal(uint8_t sch_nbr, struct list_head *p_sch_head, uint8_t *p_buf, uint32_t buf_len, uint32_t *p_out_size);

/**
 * @brief Schedule内部函数，配置项反序列化
 * @param[in]  p_buf                [指向输入的序列化二进制缓存]
 * @param[in]  data_len             [输入的序列化二进制缓存数据长度]
 * @param[out] p_sch_head           [指向输出的Schedule配置项链表头]
 * @param[out] p_schedule_nbr       [指向输出Schedule配置项数量的缓存]
 * @return int                      [SCHE_RESULT_E]
 */
int sche_cfg_unmarshal(uint8_t *p_buf, uint32_t data_len, struct list_head *p_sch_head, uint8_t *p_schedule_nbr);

/**
 * @brief 给链表增加一个节点并且返回新节点指针
 * @param[in] pst_head              [指向链表头]
 * @return
 *      - schedule_node_t*          [指向创建的新节点]
 *      - NULL                      [创建新节点失败]
 */
schedule_node_t *sche_node_new(struct list_head *pst_head);

/**
 * @brief 销毁一个链表节点
 * @param[in] p_node                [需要销毁的链表节点]
 */
void sche_node_destroy(schedule_node_t *p_node);

/**
 * @brief 获取相应实例号的默认Schedule读取配置回调
 * @param[in] handle_id             [实例句柄ID]
 * @return
 *      - sche_rd_cfg_cb_t          [返回对应的回调读取接口函数]
 *      - NULL                      [该实例ID无效]
 */
sche_rd_cfg_cb_t sche_get_default_rd_cfg_cb(int handle_id);

/**
 * @brief 获取相应实例号的默认Schedule写入配置回调
 * @param[in] handle_id             [实例句柄ID]
 * @return
 *      - sche_wr_cfg_cb_t          [返回对应的回调写入接口函数]
 *      - NULL                      [该实例ID无效]
 */
sche_wr_cfg_cb_t sche_get_default_wr_cfg_cb(int handle_id);

#ifdef __cplusplus
}
#endif

#endif /* __VESYNC_SCHEDULE_INTERNAL_H__ */
