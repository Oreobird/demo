/**
 * Copyright © Vesync Technologies Co.Ltd. 2021. All rights reserved.
 * @file        button_netcfg.c
 * @brief       配网按键业务实现
 * @author      Joshua
 * @date        2021-12-23
 */
#include <stdint.h>
#include <string.h>
#include <stdbool.h>

#include "vesync_log.h"
#include "vesync_common.h"
#include "vesync_task.h"
#include "button.h"
#include "event.h"
#include "scene.h"
#include "device.h"

#define TRIGGER_NETCFG_TIME_MS  5000
#define TRIGGER_RESET_TIME_MS   15000
#define TRIGGER_PRODUCTION_TIME_MS  2000
#define POWERON_TIME_MS  10000

static uint64_t s_hold_start_ts = 0;       // 长按开始时间
static uint64_t s_power_on_ts = 0;         // 上电时间
static uint8_t s_click_cnt = 0;            // 单击次数
static uint64_t s_prd_press_down_ts = 0;   // 产测按下时间
static bool s_prd_press_down_tick = true;  // 产测锁定按下计时标志
static bool s_pre_netcfg_tick = true;      // 长按触发配网到松开锁定响应标志
static bool s_extra_click_fn_enable = false; // 短按是否定义额外功能，如切换模式，开关等短按功能

static void press_down_handle(void)
{
    if (s_prd_press_down_tick)
    {
        s_prd_press_down_ts = vesync_task_get_tick_ms();
        s_prd_press_down_tick = false;
    }
    s_hold_start_ts = vesync_task_get_tick_ms();
}

static void press_up_handle(void)
{
    uint64_t hold_end_ts = vesync_task_get_tick_ms();
    s_pre_netcfg_tick = true;

    if (hold_end_ts - s_hold_start_ts > TRIGGER_NETCFG_TIME_MS)
    {
        APP_LOG(LOG_DEBUG, "-------Trigger netcfg: %d-------\n", (int)(hold_end_ts - s_hold_start_ts));
        NETCFG_NOTIFY(ACT_SRC_BTN);
    }
}

static void single_click_handle(void)
{
    APP_LOG(LOG_DEBUG, "-------single click---------\n");
    uint64_t cur_ts = vesync_task_get_tick_ms();

    if (cur_ts - s_power_on_ts <= POWERON_TIME_MS)  // 上电10秒内
    {
        if (cur_ts - s_prd_press_down_ts < TRIGGER_PRODUCTION_TIME_MS)  // 2s内按5次
        {
            s_click_cnt++;
            if (s_click_cnt >= 5)
            {
                s_click_cnt = 0;
                APP_LOG(LOG_DEBUG, "------Trigger production: %d-------\n", (int)(cur_ts - s_prd_press_down_ts));
                PRODUCTION_NOTIFY(ACT_SRC_BTN);
            }
        }
        else
        {
            s_prd_press_down_ts = vesync_task_get_tick_ms();
            s_click_cnt = 1;
        }
    }

    if (s_extra_click_fn_enable)
    {
        dev_cfg_t *p_dev_cfg = app_device_cfg_get();
        VCOM_NULL_RET_CHK(p_dev_cfg, return);

        scene_t *scene = NULL;

        APP_LOG(LOG_DEBUG, "status = %d, mode = %d\n", p_dev_cfg->flash->cfg.onoff, p_dev_cfg->flash->cfg.mode);
        if (p_dev_cfg->flash->cfg.onoff == LIGHT_STATUS_OFF ||
            p_dev_cfg->flash->cfg.mode < LIGHT_MODE_MUSIC)
        {
            scene = scene_registry_get(SCENE_LIGHT, p_dev_cfg->flash->cfg.scene_id);
        }
        else
        {
            scene = scene_registry_get_next(SCENE_LIGHT, p_dev_cfg->flash->cfg.scene_id);
        }

        VCOM_NULL_RET_CHK(scene, return);
        p_dev_cfg->flash->cfg.mode = LIGHT_MODE_SCENE;
        p_dev_cfg->flash->cfg.onoff = LIGHT_STATUS_ON;
        p_dev_cfg->flash->cfg.scene_id = scene->id;

        APP_LOG(LOG_DEBUG, "scene_id = %d\n", p_dev_cfg->flash->cfg.scene_id);
        app_device_cfg_save(p_dev_cfg);

        SCENE_SWITCH_NOTIFY(ACT_SRC_BTN, SCENE_LIGHT, scene->id);
    }
}

static void double_click_handle(void)
{
    dev_cfg_t *p_dev_cfg = app_device_cfg_get();
    VCOM_NULL_RET_CHK(p_dev_cfg, return);
    if (p_dev_cfg->flash->cfg.onoff == LIGHT_STATUS_ON)
    {
        p_dev_cfg->flash->cfg.onoff = LIGHT_STATUS_OFF;
        app_device_cfg_save(p_dev_cfg);
        SCENE_SWITCH_NOTIFY(ACT_SRC_BTN, SCENE_ONOFF,
            (p_dev_cfg->flash->cfg.mode == LIGHT_MODE_WHITE) ? SCENE_WHITE_OFF : SCENE_COLOR_OFF);
    }
}

static void long_press_hold_handle(void)
{
    uint64_t hold_ts = vesync_task_get_tick_ms();

    if (hold_ts - s_hold_start_ts > TRIGGER_RESET_TIME_MS)
    {
        APP_LOG(LOG_DEBUG, "-------Trigger reset: %d-------\n", (int)(hold_ts - s_hold_start_ts));
        s_hold_start_ts = hold_ts;
        RESET_NOTIFY(ACT_SRC_BTN);
    }
    else if (hold_ts - s_hold_start_ts > TRIGGER_NETCFG_TIME_MS)
    {
        if (s_pre_netcfg_tick)
        {
            s_pre_netcfg_tick = false;
            APP_LOG(LOG_DEBUG, "-------Trigger pre netcfg: %d-------\n", (int)(hold_ts - s_hold_start_ts));
            PRE_NETCFG_NOTIFY(ACT_SRC_BTN);
        }
    }
}

static btn_ev_cb_t s_ev_cb_tbl[] = {
    {EV_PRESS_DOWN, press_down_handle},
    {EV_PRESS_UP, press_up_handle},
    {EV_SINGLE_CLICK, single_click_handle},
    {EV_DOUBLE_CLICK, double_click_handle},
    {EV_LONG_PRESS_HOLD, long_press_hold_handle}
};

int button_netcfg_init(app_btn_cfg_t *app_btn_cfg)
{
    VCOM_NULL_PARAM_CHK(app_btn_cfg, return APP_FAIL);
    int ret = SDK_FAIL;

    s_power_on_ts = vesync_task_get_tick_ms();

    btn_cfg_t cfg;

    memset(&cfg, 0, sizeof(btn_cfg_t));
    cfg.gpio = app_btn_cfg->gpio;
    cfg.active_level = app_btn_cfg->active_level;
    cfg.long_press_cb_interval_ms = 1000;

    if (app_btn_cfg->short_press_type != SP_NONE)
    {
        s_extra_click_fn_enable = true;
    }

    ret = vesync_button_reg_cb_arr(cfg.gpio, s_ev_cb_tbl, SIZEOF_ARRAY(s_ev_cb_tbl));
    if (ret != SDK_OK)
    {
        ret = vesync_button_add(&cfg);
        if (ret != SDK_OK)
        {
            APP_LOG(LOG_ERROR, "button add fail\n");
            return APP_FAIL;
        }

        ret = vesync_button_reg_cb_arr(cfg.gpio, s_ev_cb_tbl, SIZEOF_ARRAY(s_ev_cb_tbl));
        if (ret != SDK_OK)
        {
            APP_LOG(LOG_ERROR, "button reg cb fail\n");
            vesync_button_del(cfg.gpio);
            return APP_FAIL;
        }
    }

    return APP_OK;
}

int button_netcfg_deinit(app_btn_cfg_t *app_btn_cfg)
{
    VCOM_NULL_PARAM_CHK(app_btn_cfg, return APP_FAIL);
    return (SDK_OK == vesync_button_del(app_btn_cfg->gpio)) ? APP_OK : APP_FAIL;
}


