/**
 * Copyright © Etekcity Technologies Co., Ltd. 2019-2099. All rights reserved.
 * @brief Ffs Wi-Fi configuration list
 * @author  Owen.zhang
 * @date    2020-04-22
 */
#include "ffs/common/ffs_check_result.h"
#include "ffs_wifi_configuration_list.h"

#include <stdint.h>
#include <stdlib.h>

/** Static function prototypes. */
static FFS_RESULT ffsCloneWifiConfiguration(FfsWifiConfiguration_t *configuration,
                                            FfsWifiConfiguration_t **cloneConfiguration);
static FFS_RESULT ffsFreeWifiConfiguration(FfsWifiConfiguration_t *configuration);

/**
 * @brief: Store the Wi-Fi configuration in the list.
 * @param FfsWifiContext_t*
 * @param FfsWifiConfiguration_t *
 * @return FFS_RESULT
 */
FFS_RESULT ffsWifiConfigurationListPush(FfsWifiContext_t *wifiContext, FfsWifiConfiguration_t *configuration)
{
    if (!wifiContext || !configuration)
    {
        ffsLogError("input params find NULL");
        FFS_FAIL(FFS_OVERRUN);
    }
    FfsWifiConfiguration_t *cloneConfiguration;
    FFS_CHECK_RESULT(ffsCloneWifiConfiguration(configuration, &cloneConfiguration));

    FFS_CHECK_RESULT(ffsLinkedListPushBack(&wifiContext->configurationList, (FfsLinkedListData_t *)cloneConfiguration));

    return FFS_SUCCESS;
}

/**
 * @brief: Retrieves the next Wi-Fi configuration in the list, without removing it.
 * @param FfsWifiContext_t*
 * @param FfsWifiConfiguration_t **
 * @return FFS_RESULT
 */
FFS_RESULT ffsWifiConfigurationListPeek(FfsWifiContext_t *wifiContext, FfsWifiConfiguration_t **configuration)
{
    if (!wifiContext)
    {
        ffsLogError("input params find NULL");
        FFS_FAIL(FFS_OVERRUN);
    }
    FfsLinkedListData_t *configurationData;
    FFS_CHECK_RESULT(ffsLinkedListPeekFront(&wifiContext->configurationList, &configurationData));

    *configuration = (FfsWifiConfiguration_t *)configurationData;

    return FFS_SUCCESS;
}

/**
 * @brief: Removes the next Wi-Fi configuration from the list.
 * @param FfsWifiContext_t*
 * @return FFS_RESULT
 */
FFS_RESULT ffsWifiConfigurationListPop(FfsWifiContext_t *wifiContext)
{
    if (!wifiContext)
    {
        ffsLogError("input params find NULL");
        FFS_FAIL(FFS_OVERRUN);
    }
    FfsLinkedListData_t *configurationData;
    FFS_CHECK_RESULT(ffsLinkedListPopFront(&wifiContext->configurationList, &configurationData));

    FfsWifiConfiguration_t *configuration = (FfsWifiConfiguration_t *)configurationData;
    FFS_CHECK_RESULT(ffsFreeWifiConfiguration(configuration));

    return FFS_SUCCESS;
}

/**
 * @brief: Removes a Wi-Fi configuration from the list by SSID.
 * @param FfsWifiContext_t*
 * @param FfsStream_t
 * @return FFS_RESULT
 */
FFS_RESULT ffsWifiConfigurationListPopConfiguration(FfsWifiContext_t *wifiContext, FfsStream_t ssidStream)
{
    if (!wifiContext)
    {
        ffsLogError("input params find NULL");
        FFS_FAIL(FFS_OVERRUN);
    }
    size_t configurationListSize = ffsLinkedListGetCount(&wifiContext->configurationList);
    FfsLinkedListData_t *configurationData;

    for (size_t i = 0; i < configurationListSize; ++i)
    {
        FFS_CHECK_RESULT(ffsLinkedListPeekIndex(&wifiContext->configurationList, i, &configurationData));

        FfsWifiConfiguration_t *configuration = (FfsWifiConfiguration_t *)configurationData;
        if (ffsStreamMatchesStream(&configuration->ssidStream, &ssidStream))
        {

            ffsLogDebug("Removing matching SSID");

            // Pop and delete the configuration.
            FFS_CHECK_RESULT(ffsLinkedListPopIndex(&wifiContext->configurationList, i, &configurationData));
            configuration = (FfsWifiConfiguration_t *)configurationData;
            ffsFreeWifiConfiguration(configuration);

            // Recalculate the size.
            configurationListSize = ffsLinkedListGetCount(&wifiContext->configurationList);
            --i;
        }
    }

    return FFS_SUCCESS;
}

/**
 * @brief: Removes all the Wi-Fi configurations from the list and frees the resources.
 * @param FfsWifiContext_t*
 * @return FFS_RESULT
 */
FFS_RESULT ffsWifiConfigurationListClear(FfsWifiContext_t *wifiContext)
{
    if (!wifiContext)
    {
        ffsLogError("input params find NULL");
        return FFS_SUCCESS;
    }
    while (true)
    {
        bool isEmpty;
        FFS_CHECK_RESULT(ffsWifiConfigurationListIsEmpty(wifiContext, &isEmpty));

        if (isEmpty)
        {
            break;
        }

        FFS_CHECK_RESULT(ffsWifiConfigurationListPop(wifiContext));
    }

    return FFS_SUCCESS;
}

/**
 * @brief: Checks if the Wi-Fi configuration list is empty.
 * @param FfsWifiContext_t*
 * @param bool *
 * @return FFS_RESULT
 */
FFS_RESULT ffsWifiConfigurationListIsEmpty(FfsWifiContext_t *wifiContext, bool *isEmpty)
{
    if (!wifiContext || !isEmpty)
    {
        ffsLogError("input params find NULL");
        FFS_FAIL(FFS_OVERRUN);
    }
    *isEmpty = ffsLinkedListIsEmpty(&wifiContext->configurationList);

    return FFS_SUCCESS;
}

/**
 * @brief: Clones a Wi-Fi configuration.
 * @param FfsWifiConfiguration_t*
 * @param FfsWifiConfiguration_t **
 * @return FFS_RESULT
 */
static FFS_RESULT ffsCloneWifiConfiguration(FfsWifiConfiguration_t *configuration,
                                            FfsWifiConfiguration_t **cloneConfiguration)
{
    if (!configuration)
    {
        ffsLogError("input params find NULL");
        FFS_FAIL(FFS_OVERRUN);
    }

    FfsWifiConfiguration_t *clone = (FfsWifiConfiguration_t *)malloc(sizeof(FfsWifiConfiguration_t));
    if (!clone)
    {
        FFS_FAIL(FFS_OVERRUN);
    }

    size_t ssidLength = FFS_STREAM_DATA_SIZE(configuration->ssidStream);
    size_t keyLength = FFS_STREAM_DATA_SIZE(configuration->keyStream);

    uint8_t *ssidBuffer = (uint8_t *)malloc(ssidLength);
    if (!ssidBuffer)
    {
        free(clone);
        FFS_FAIL(FFS_OVERRUN);
    }

    uint8_t *keyBuffer = (uint8_t *)malloc(keyLength);
    if (!keyBuffer && keyLength > 0)
    {
        free(clone);
        free(ssidBuffer);
        FFS_FAIL(FFS_OVERRUN);
    }

    clone->ssidStream = ffsCreateOutputStream(ssidBuffer, ssidLength);
    clone->keyStream = ffsCreateOutputStream(keyBuffer, keyLength);

    FfsStream_t copyStream = configuration->ssidStream;
    FFS_CHECK_RESULT(ffsAppendStream(&copyStream, &clone->ssidStream));
    copyStream = configuration->keyStream;
    FFS_CHECK_RESULT(ffsAppendStream(&copyStream, &clone->keyStream));

    clone->isHiddenNetwork = configuration->isHiddenNetwork;
    clone->networkPriority = configuration->networkPriority;
    clone->wepIndex = configuration->wepIndex;
    clone->securityProtocol = configuration->securityProtocol;

    *cloneConfiguration = clone;

    return FFS_SUCCESS;
}

/**
 * @brief: Frees a Wi-Fi configuration.
 * @param FfsWifiConfiguration_t*
 * @return FFS_RESULT
 */
static FFS_RESULT ffsFreeWifiConfiguration(FfsWifiConfiguration_t *configuration)
{
    if (!configuration)
    {
        ffsLogError("input params find NULL");
        return FFS_SUCCESS;
    }
    free(configuration->ssidStream.data);
    free(configuration->keyStream.data);

    free(configuration);

    return FFS_SUCCESS;
}
